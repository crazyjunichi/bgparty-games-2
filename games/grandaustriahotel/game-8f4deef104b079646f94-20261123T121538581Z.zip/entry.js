import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { playTurn as o, useSoundEdge as s } from "@bgparty/sdk/sfx";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { ConfirmButton as m } from "@bgparty/sdk/confirm-button";
//#region src/game/data.ts
var h = [
	"strudel",
	"cake",
	"wine",
	"coffee"
], g = () => ({
	strudel: 0,
	cake: 0,
	wine: 0,
	coffee: 0
}), _ = [
	[
		"blue",
		"yellow",
		"red",
		"red",
		"blue"
	],
	[
		"yellow",
		"yellow",
		"red",
		"red",
		"yellow"
	],
	[
		"blue",
		"red",
		"blue",
		"yellow",
		"yellow"
	],
	[
		"blue",
		"red",
		"blue",
		"red",
		"blue"
	]
], v = {
	1: [
		0,
		0,
		0,
		0,
		0
	],
	2: [
		0,
		0,
		0,
		0,
		0
	],
	3: [
		0,
		0,
		0,
		1,
		1
	],
	4: [
		0,
		0,
		2,
		2,
		2
	]
}, y = {
	1: 0,
	2: 1,
	3: 2,
	4: 3
}, b = _.flatMap((e, t) => e.map((e, n) => ({
	color: e,
	floor: t + 1,
	col: n,
	vp: v[t + 1][n]
})));
function x() {
	let e = [], t = /* @__PURE__ */ new Set();
	for (let n = 0; n < b.length; n++) {
		if (t.has(n)) continue;
		let r = b[n].color, i = [n], a = [];
		for (t.add(n); i.length;) {
			let e = i.pop();
			a.push(e);
			let { floor: n, col: o } = b[e], s = [
				e - 1,
				e + 1,
				e - 5,
				e + 5
			];
			for (let e of s) e < 0 || e >= b.length || Math.abs(b[e].floor - n) + Math.abs(b[e].col - o) === 1 && (t.has(e) || b[e].color !== r || (t.add(e), i.push(e)));
		}
		e.push(a.sort((e, t) => e - t));
	}
	return e;
}
var S = x(), C = {
	blue: [
		0,
		2,
		5,
		9,
		15
	],
	red: [
		0,
		1,
		3,
		6,
		10
	],
	yellow: [
		0,
		1,
		3,
		6,
		10
	]
}, w = (e, t, n, r, i) => ({
	id: e,
	color: t,
	vp: n,
	order: r,
	reward: i
}), ee = [
	w(49, "yellow", 0, { wine: 1 }, [{
		t: "prepare",
		n: 1,
		discounts: [99],
		bottomTwo: !0
	}]),
	w(50, "yellow", 0, { wine: 1 }, [{
		t: "staffDraw",
		n: 1
	}, {
		t: "prepare",
		n: 1,
		discounts: [0]
	}]),
	w(51, "yellow", 1, { wine: 1 }, [{
		t: "item",
		item: "strudel",
		n: 1
	}]),
	w(52, "yellow", 0, {
		strudel: 1,
		coffee: 1
	}, [{
		t: "item",
		item: "strudel",
		n: 1
	}, {
		t: "money",
		n: 2
	}]),
	w(53, "yellow", 0, {
		strudel: 1,
		wine: 1
	}, [{
		t: "item",
		item: "coffee",
		n: 1
	}, {
		t: "emperor",
		n: 2
	}]),
	w(54, "yellow", 0, { wine: 2 }, [{
		t: "choiceItem",
		n: 1
	}, {
		t: "money",
		n: 2
	}]),
	w(55, "yellow", 7, { wine: 3 }, [{
		t: "staffDraw",
		n: 2
	}]),
	w(56, "yellow", 0, {
		strudel: 1,
		wine: 2
	}, [{
		t: "item",
		item: "cake",
		n: 1
	}, {
		t: "staffDiscount",
		n: 3
	}]),
	w(57, "yellow", 1, {
		wine: 2,
		coffee: 1
	}, [{
		t: "prepare",
		n: 2,
		discounts: [1, 0]
	}]),
	w(58, "yellow", 7, {
		wine: 3,
		coffee: 1
	}, [{
		t: "occupy",
		n: 1
	}]),
	w(59, "yellow", 5, {
		strudel: 3,
		wine: 1
	}, [{
		t: "item",
		item: "cake",
		n: 1
	}, {
		t: "staffDiscount",
		n: 2
	}]),
	w(60, "yellow", 5, {
		cake: 2,
		wine: 2
	}, [{
		t: "item",
		item: "coffee",
		n: 1
	}, {
		t: "money",
		n: 3
	}]),
	w(61, "yellow", 2, {
		strudel: 1,
		wine: 3
	}, [{
		t: "prepare",
		n: 2,
		discounts: [1, 0]
	}]),
	w(62, "yellow", 4, {
		strudel: 1,
		cake: 1,
		wine: 2
	}, [{
		t: "guestFree",
		n: 1
	}, {
		t: "emperor",
		n: 3
	}]),
	w(63, "blue", 0, { coffee: 1 }, [{
		t: "guestFree",
		n: 1
	}]),
	w(64, "blue", 0, { coffee: 1 }, [{
		t: "staffDiscount",
		n: 1
	}]),
	w(65, "blue", 3, { coffee: 1 }, []),
	w(66, "blue", 3, {
		cake: 1,
		coffee: 1
	}, [{
		t: "staffDiscount",
		n: 1
	}, {
		t: "prepare",
		n: 1,
		discounts: [0]
	}]),
	w(67, "blue", 2, { coffee: 2 }, [{
		t: "staffDraw",
		n: 2
	}, {
		t: "emperor",
		n: 2
	}]),
	w(68, "blue", 4, {
		strudel: 2,
		coffee: 1
	}, [{
		t: "emperor",
		n: 3
	}]),
	w(69, "blue", 7, {
		cake: 2,
		coffee: 1
	}, [{
		t: "money",
		n: 3
	}]),
	w(70, "blue", 1, {
		strudel: 1,
		wine: 1,
		coffee: 1
	}, [{
		t: "staffDiscount",
		n: 1
	}, {
		t: "emperor",
		n: 3
	}]),
	w(71, "blue", 4, {
		strudel: 1,
		coffee: 2
	}, [{
		t: "prepare",
		n: 1,
		discounts: [99]
	}]),
	w(72, "blue", 7, {
		strudel: 1,
		cake: 1,
		coffee: 1
	}, [{
		t: "occupy",
		n: 1
	}]),
	w(73, "blue", 4, {
		wine: 1,
		coffee: 2
	}, [{
		t: "staffDiscount",
		n: 1,
		count: 2
	}]),
	w(74, "blue", 10, {
		cake: 2,
		coffee: 2
	}, [{
		t: "money",
		n: 1
	}]),
	w(75, "blue", 5, {
		wine: 2,
		coffee: 2
	}, [{
		t: "staffDrawPlay",
		count: 3,
		discount: 3
	}]),
	w(76, "blue", 4, {
		strudel: 2,
		coffee: 2
	}, [{
		t: "staffDrawPlay",
		count: 3,
		discount: 99
	}]),
	w(77, "red", 1, { cake: 1 }, [{
		t: "money",
		n: 1
	}]),
	w(78, "red", 0, { cake: 1 }, [{
		t: "guestFree",
		n: 1
	}]),
	w(79, "red", 0, { cake: 1 }, [{
		t: "money",
		n: 1
	}, {
		t: "emperor",
		n: 1
	}]),
	w(80, "red", 4, {
		strudel: 1,
		wine: 1
	}, [{
		t: "guestFree",
		n: 1
	}]),
	w(81, "red", 0, { cake: 2 }, [{
		t: "item",
		item: "wine",
		n: 1
	}, {
		t: "money",
		n: 3
	}]),
	w(82, "red", 7, {
		wine: 1,
		coffee: 1
	}, [{
		t: "occupy",
		n: 1
	}]),
	w(83, "red", 0, {
		strudel: 1,
		cake: 1,
		wine: 1
	}, [{
		t: "money",
		n: 5
	}]),
	w(84, "red", 2, {
		strudel: 1,
		cake: 1,
		wine: 1
	}, [{
		t: "money",
		n: 3
	}, {
		t: "guestFree",
		n: 1
	}]),
	w(85, "red", 3, {
		strudel: 2,
		cake: 1
	}, [{
		t: "money",
		n: 3
	}]),
	w(86, "red", 3, {
		cake: 1,
		wine: 2
	}, [{
		t: "staffDiscount",
		n: 3
	}]),
	w(87, "red", 3, {
		cake: 2,
		coffee: 2
	}, [{
		t: "money",
		n: 3
	}, {
		t: "guestFree",
		n: 2
	}]),
	w(88, "red", 0, { wine: 3 }, [{
		t: "prepare",
		n: 2,
		discounts: [99, 99]
	}]),
	w(89, "red", 5, {
		strudel: 2,
		cake: 1,
		wine: 1
	}, [{
		t: "money",
		n: 4
	}]),
	w(90, "red", 7, { cake: 4 }, [{
		t: "item",
		item: "wine",
		n: 1
	}, {
		t: "money",
		n: 3
	}]),
	w(91, "green", 0, { strudel: 1 }, [{
		t: "staffDraw",
		n: 3
	}]),
	w(92, "green", 0, { strudel: 1 }, [{
		t: "money",
		n: 1
	}]),
	w(93, "green", 0, { strudel: 1 }, [{
		t: "emperor",
		n: 1
	}]),
	w(94, "green", 0, { strudel: 2 }, [{
		t: "staffDiscount",
		n: 1
	}]),
	w(95, "green", 2, {
		strudel: 1,
		cake: 1
	}, [{
		t: "emperor",
		n: 2
	}]),
	w(96, "green", 0, {
		strudel: 1,
		coffee: 1
	}, [{
		t: "staffDiscount",
		n: 3
	}]),
	w(97, "green", 4, {
		strudel: 2,
		wine: 1
	}, [{ t: "imitate" }]),
	w(98, "green", 0, { strudel: 3 }, [{
		t: "money",
		n: 4
	}]),
	w(99, "green", 5, {
		strudel: 1,
		cake: 2
	}, [{
		t: "staffDraw",
		n: 1
	}, {
		t: "emperor",
		n: 2
	}]),
	w(100, "green", 4, { coffee: 3 }, [{
		t: "emperor",
		n: 3
	}, {
		t: "occupy",
		n: 1
	}]),
	w(101, "green", 3, {
		strudel: 3,
		coffee: 1
	}, [{
		t: "emperor",
		n: 3
	}, {
		t: "guestFree",
		n: 1
	}]),
	w(102, "green", 0, {
		strudel: 1,
		coffee: 1
	}, [{
		t: "emperor",
		n: 1
	}, {
		t: "occupy",
		n: 1
	}]),
	w(103, "green", 4, {
		strudel: 1,
		wine: 2
	}, [{
		t: "staffDraw",
		n: 2
	}]),
	w(104, "green", 2, {
		strudel: 1,
		cake: 3
	}, [{
		t: "staffDiscount",
		n: 99
	}])
], T = new Map(ee.map((e) => [e.id, e])), E = [
	{
		id: 1,
		cost: 4,
		kind: "round",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "strudel",
				n: 1
			}]
		}
	},
	{
		id: 2,
		cost: 6,
		kind: "round",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "cake",
				n: 1
			}]
		}
	},
	{
		id: 3,
		cost: 4,
		kind: "round",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "wine",
				n: 1
			}]
		}
	},
	{
		id: 4,
		cost: 6,
		kind: "round",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "coffee",
				n: 1
			}]
		}
	},
	{
		id: 5,
		cost: 4,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "redMoney2"
		}
	},
	{
		id: 6,
		cost: 6,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "blueEmperor1"
		}
	},
	{
		id: 7,
		cost: 4,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "yellowMoney1"
		}
	},
	{
		id: 8,
		cost: 6,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "greenVp2"
		}
	},
	{
		id: 9,
		cost: 4,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "blueFree"
		}
	},
	{
		id: 10,
		cost: 5,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "redFree"
		}
	},
	{
		id: 11,
		cost: 5,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "yellowFree"
		}
	},
	{
		id: 12,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die34Vp2"
		}
	},
	{
		id: 13,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die12Str1"
		}
	},
	{
		id: 14,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die12Prepare"
		}
	},
	{
		id: 15,
		cost: 4,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die4Bootblack"
		}
	},
	{
		id: 16,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die4Vp4"
		}
	},
	{
		id: 17,
		cost: 5,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die6Str1Free"
		}
	},
	{
		id: 18,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die5Str2"
		}
	},
	{
		id: 19,
		cost: 3,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die3Vp5"
		}
	},
	{
		id: 20,
		cost: 2,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die5Emperor2"
		}
	},
	{
		id: 21,
		cost: 3,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "itemAll",
				n: 1
			}]
		}
	},
	{
		id: 22,
		cost: 3,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "die3Staff"
		}
	},
	{
		id: 23,
		cost: 4,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "occupyMoney1"
		}
	},
	{
		id: 24,
		cost: 1,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "serveFree"
		}
	},
	{
		id: 25,
		cost: 6,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "queueFree"
		}
	},
	{
		id: 26,
		cost: 5,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "emperorPayIgnore"
		}
	},
	{
		id: 27,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "red3"
		}
	},
	{
		id: 28,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "blue3"
		}
	},
	{
		id: 29,
		cost: 5,
		kind: "end",
		effect: {
			t: "end",
			kind: "secretary"
		}
	},
	{
		id: 30,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "yellow3"
		}
	},
	{
		id: 31,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "room1"
		}
	},
	{
		id: 32,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "staff2"
		}
	},
	{
		id: 33,
		cost: 5,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "guest4ItemsVp4"
		}
	},
	{
		id: 34,
		cost: 5,
		kind: "end",
		effect: {
			t: "end",
			kind: "tile1"
		}
	},
	{
		id: 35,
		cost: 2,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "occupy",
				n: 2
			}]
		}
	},
	{
		id: 36,
		cost: 2,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "wine",
				n: 4
			}]
		}
	},
	{
		id: 37,
		cost: 3,
		kind: "end",
		effect: {
			t: "end",
			kind: "group2"
		}
	},
	{
		id: 38,
		cost: 5,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{ t: "fillOrder" }]
		}
	},
	{
		id: 39,
		cost: 3,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "cake",
				n: 4
			}]
		}
	},
	{
		id: 40,
		cost: 2,
		kind: "end",
		effect: {
			t: "end",
			kind: "objective5"
		}
	},
	{
		id: 41,
		cost: 3,
		kind: "end",
		effect: {
			t: "end",
			kind: "emperor2x"
		}
	},
	{
		id: 42,
		cost: 3,
		kind: "perm",
		effect: {
			t: "perm",
			kind: "emperorRewardVp5"
		}
	},
	{
		id: 43,
		cost: 3,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "coffee",
				n: 4
			}]
		}
	},
	{
		id: 44,
		cost: 2,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "item",
				item: "strudel",
				n: 4
			}]
		}
	},
	{
		id: 45,
		cost: 1,
		kind: "once",
		effect: {
			t: "ops",
			ops: [{
				t: "emperor",
				n: 3
			}]
		}
	},
	{
		id: 46,
		cost: 2,
		kind: "end",
		effect: {
			t: "end",
			kind: "floor5"
		}
	},
	{
		id: 47,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "column5"
		}
	},
	{
		id: 48,
		cost: 4,
		kind: "end",
		effect: {
			t: "end",
			kind: "set4"
		}
	}
], D = new Map(E.map((e) => [e.id, e]));
function O(e, t) {
	let n = [...e];
	for (let e = n.length - 1; e > 0; e--) {
		let r = t(e + 1);
		[n[e], n[r]] = [n[r], n[e]];
	}
	return n;
}
var k = [
	{
		id: "A1",
		group: "A",
		kind: "money20"
	},
	{
		id: "A2",
		group: "A",
		kind: "emperor10"
	},
	{
		id: "A3",
		group: "A",
		kind: "staff6"
	},
	{
		id: "A4",
		group: "A",
		kind: "tiles12"
	},
	{
		id: "B1",
		group: "B",
		kind: "floors2"
	},
	{
		id: "B2",
		group: "B",
		kind: "columns2"
	},
	{
		id: "B3",
		group: "B",
		kind: "colorAll"
	},
	{
		id: "B4",
		group: "B",
		kind: "groups6"
	},
	{
		id: "C1",
		group: "C",
		kind: "c3each"
	},
	{
		id: "C2",
		group: "C",
		kind: "r4y3"
	},
	{
		id: "C3",
		group: "C",
		kind: "y4b3"
	},
	{
		id: "C4",
		group: "C",
		kind: "b4r3"
	}
];
new Map(k.map((e) => [e.id, e]));
var A = [
	15,
	10,
	5
], j = [
	{
		id: "A1",
		group: "A",
		reward: [{
			t: "money",
			n: 3
		}],
		penalty: "money3"
	},
	{
		id: "A2",
		group: "A",
		reward: [{
			t: "choiceItem",
			n: 2
		}],
		penalty: "itemsAll"
	},
	{
		id: "A3",
		group: "A",
		reward: [{
			t: "staffDrawPlay",
			count: 3,
			discount: 3
		}],
		penalty: "staff2"
	},
	{
		id: "A4",
		group: "A",
		reward: [{
			t: "prepare",
			n: 1,
			discounts: [99]
		}],
		penalty: "vacant1"
	},
	{
		id: "B1",
		group: "B",
		reward: [
			{
				t: "item",
				item: "strudel",
				n: 1
			},
			{
				t: "item",
				item: "cake",
				n: 1
			},
			{
				t: "item",
				item: "wine",
				n: 1
			},
			{
				t: "item",
				item: "coffee",
				n: 1
			}
		],
		penalty: "itemsAllGuests"
	},
	{
		id: "B2",
		group: "B",
		reward: [{
			t: "money",
			n: 5
		}],
		penalty: "money5"
	},
	{
		id: "B3",
		group: "B",
		reward: [{
			t: "staffDrawPlay",
			count: 3,
			discount: 99
		}],
		penalty: "staff3"
	},
	{
		id: "B4",
		group: "B",
		reward: [{
			t: "prepareOccupy",
			n: 1,
			discounts: [99],
			bottomTwo: !0
		}],
		penalty: "vacant2"
	},
	{
		id: "C1",
		group: "C",
		reward: [{
			t: "vp",
			n: 8
		}],
		penalty: "vp8"
	},
	{
		id: "C2",
		group: "C",
		reward: [{
			t: "prepareOccupy",
			n: 1,
			discounts: [99]
		}],
		penalty: "occupied2"
	},
	{
		id: "C3",
		group: "C",
		reward: [{
			t: "vpStaff",
			per: 2
		}],
		penalty: "vpPerStaff"
	},
	{
		id: "C4",
		group: "C",
		reward: [{
			t: "staffDiscount",
			n: 99
		}],
		penalty: "staffRemove"
	}
], te = new Map(j.map((e) => [e.id, e])), ne = [
	0,
	1,
	1,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	9
], re = [
	3,
	2,
	1,
	0,
	0
], ie = {
	2: 10,
	3: 12,
	4: 14
}, ae = {
	id: "grandaustriahotel",
	uuid: "f0c4e5a2-9d61-4f0d-9a3e-6b2c8d7e41a5",
	tier: "alpha",
	mechanics: [
		"dice-rolling",
		"drafting",
		"set-collection",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.grandaustriahotel.name",
	descKey: "games.grandaustriahotel.desc",
	rulesKey: "games.grandaustriahotel.rules",
	icon: "🏨",
	iconImg: "games/grandaustriahotel.webp",
	rulesUrl: { en: "https://www.boardgamehelpers.com/GrandAustriaHotel/Images/RevisedDeluxeRules.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#b8863b",
	releasedAt: "2026-11-23T19:47:05+08:00",
	search: {
		py: "ao di li da fan dian",
		init: "adldfd"
	},
	hotseat: "cover"
}, M = t.string(), oe = t.enum([
	"strudel",
	"cake",
	"wine",
	"coffee"
]), N = t.object({
	strudel: t.int().nonnegative(),
	cake: t.int().nonnegative(),
	wine: t.int().nonnegative(),
	coffee: t.int().nonnegative()
}), P = t.int().min(0).max(19), F = t.string().regex(/^[ABC][1-4]$/), se = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("guest"),
		index: t.int().min(0).max(4)
	}),
	t.object({ type: t.literal("skipGuest") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("die"),
		space: t.int().min(1).max(6),
		boost: t.boolean().default(!1),
		dishes: t.object({
			strudel: t.int().nonnegative(),
			cake: t.int().nonnegative()
		}).optional(),
		drinks: t.object({
			wine: t.int().nonnegative(),
			coffee: t.int().nonnegative()
		}).optional(),
		rooms: t.array(P).optional(),
		favor: t.object({
			emperor: t.int().nonnegative(),
			money: t.int().nonnegative()
		}).optional(),
		staffIid: t.string().optional(),
		imitateSpace: t.int().min(1).max(5).optional()
	}),
	t.object({
		type: t.literal("choose"),
		id: t.string()
	}),
	t.object({
		type: t.literal("serve"),
		guest: t.int().min(0).max(2),
		items: N.partial()
	}),
	t.object({
		type: t.literal("move"),
		guest: t.int().min(0).max(2),
		cell: P
	}),
	t.object({
		type: t.literal("claim"),
		card: F
	}),
	t.object({
		type: t.literal("staff"),
		iid: t.string()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("prepareExtra"),
		cell: P
	}),
	t.object({
		type: t.literal("staffPlay"),
		iid: t.string()
	}),
	t.object({ type: t.literal("continue") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), I = t.object({
	id: t.string(),
	kind: t.enum([
		"cell",
		"staff",
		"queue",
		"item",
		"space",
		"yes",
		"no",
		"skip"
	]),
	cell: P.optional(),
	iid: t.string().optional(),
	card: t.string().optional(),
	index: t.int().optional(),
	item: oe.optional(),
	space: t.int().optional(),
	cost: t.int().optional(),
	disabled: t.boolean().optional()
}), L = t.object({
	round: t.int().min(1).max(7),
	phase: t.enum([
		"turns",
		"emperor",
		"final",
		"done"
	]),
	queue: t.array(t.string()),
	guestDeckCount: t.int().nonnegative(),
	staffDeckCount: t.int().nonnegative(),
	emperor: t.object({
		A: F,
		B: F,
		C: F
	}),
	objectives: t.object({
		A: F,
		B: F,
		C: F
	}),
	claims: t.record(F, t.array(t.object({
		rid: M,
		vp: t.int(),
		slot: t.int()
	}))),
	dice: t.array(t.number()),
	dustbin: t.number(),
	roundTurns: t.record(M, t.int()),
	turn: t.object({
		seat: M.nullable(),
		stage: t.enum([
			"guest",
			"main",
			"after"
		]).nullable(),
		order: t.array(M),
		passed: t.array(M)
	}),
	players: t.array(t.object({
		rid: M,
		money: t.int(),
		vp: t.int(),
		emperor: t.int(),
		hotel: t.array(t.enum([
			"empty",
			"vacant",
			"occupied"
		])),
		cafe: t.array(t.object({
			guest: t.string(),
			items: N
		})),
		kitchen: N,
		handCount: t.int().nonnegative(),
		staff: t.array(t.object({
			iid: t.string(),
			card: t.string(),
			used: t.boolean()
		})),
		markers: t.array(t.object({
			card: t.string(),
			vp: t.int()
		})),
		staffPlayed: t.int(),
		covered: t.int().min(0).max(2),
		tile: t.array(t.int()).length(2)
	})),
	pending: t.object({
		seat: M,
		kind: t.string(),
		title: t.string(),
		options: t.array(I)
	}).nullable(),
	extra: t.object({
		prepare: t.boolean(),
		staff: t.boolean()
	}),
	emperorReport: t.object({
		round: t.int(),
		group: t.string(),
		tile: t.string(),
		retreat: t.int(),
		entries: t.array(t.object({
			rid: M,
			outcome: t.enum([
				"reward",
				"penalty",
				"none"
			]),
			vp: t.int(),
			money: t.int(),
			emperorFrom: t.int(),
			emperorTo: t.int(),
			kitchen: t.int(),
			hand: t.int(),
			staff: t.int(),
			rooms: t.int()
		}))
	}).nullable(),
	final: t.object({
		ranking: t.array(M),
		scores: t.record(M, t.int()),
		tie: t.record(M, t.int()).optional(),
		breakdown: t.record(M, t.object({
			base: t.int(),
			staff: t.int(),
			rooms: t.int(),
			leftover: t.int(),
			cafe: t.int(),
			total: t.int()
		}))
	}).nullable()
}), ce = t.object({
	hand: t.array(t.object({
		iid: t.string(),
		card: t.string()
	})),
	seat: t.int()
}), R = (e) => ({ code: `games.grandaustriahotel.${e}` });
function z(e) {
	let t = g();
	for (let n of h) t[n] = e[n] ?? 0;
	return t;
}
function B(e) {
	return h.reduce((t, n) => t + e[n], 0);
}
function V(t) {
	return t.deckGuests.length || (t.deckGuests = O(t.discardGuests, (n) => e(t.seed, t.cursor++, n)), t.discardGuests = []), t.deckGuests.pop();
}
function H(e, t) {
	e.money = Math.min(20, Math.max(0, e.money + t));
}
function U(e, t, n) {
	n <= 0 || (t.emperor + n > 13 ? (t.vp += t.emperor + n - 13, t.emperor = 13) : t.emperor += n);
}
function W(e, t) {
	return e.display.some((e) => {
		let n = D.get(e.card);
		return n?.effect.t === "perm" && n.effect.kind === t;
	});
}
function le(e, t) {
	return W(e, t === "blue" ? "blueFree" : t === "red" ? "redFree" : "yellowFree");
}
function ue(e, t) {
	return rt(e.hotel, t);
}
function de(e, t, n) {
	let r = b[t].color;
	return le(e, r) ? 0 : Math.max(0, y[b[t].floor] - n);
}
function G(e, t, n = !1) {
	let r = [];
	for (let i = 0; i < b.length; i += 1) e.hotel[i] === "empty" && (n && b[i].floor > 2 || ue(e, i) && r.push({
		cell: i,
		cost: de(e, i, t)
	}));
	return r;
}
function K(e, t, n, r) {
	let i = e.p[t];
	if (!i || n < 0 || n >= b.length || i.hotel[n] !== "empty" || !ue(i, n)) return !1;
	let a = de(i, n, r);
	return i.money < a ? !1 : (i.money -= a, i.hotel[n] = "vacant", i.vp += b[n].vp, !0);
}
function fe(e) {
	return S.findIndex((t) => t.includes(e));
}
function pe(e, t, n) {
	let r = e.p[t], i = fe(n);
	if (i < 0) return;
	let a = S[i];
	if (e.groupBonus[t][i] || !a.every((e) => r.hotel[e] === "occupied")) return;
	e.groupBonus[t][i] = !0;
	let o = b[a[0]].color, s = C[o][a.length] ?? 0;
	o === "blue" ? r.vp += s : o === "red" ? H(r, s) : U(e, r, s);
}
function q(e, t) {
	return b.reduce((n, r, i) => n + +(r.color === t && e.hotel[i] === "occupied"), 0);
}
function me(e) {
	return S.filter((t) => t.every((t) => e.hotel[t] === "occupied")).length;
}
function J(e) {
	let t = 0;
	for (let n = 1; n <= 4; n += 1) [
		0,
		1,
		2,
		3,
		4
	].every((t) => e.hotel[(n - 1) * 5 + t] === "occupied") && (t += 1);
	return t;
}
function he(e) {
	let t = 0;
	for (let n = 0; n < 5; n += 1) [
		0,
		1,
		2,
		3
	].every((t) => e.hotel[t * 5 + n] === "occupied") && (t += 1);
	return t;
}
function ge(e) {
	let t = T.get(e.guest);
	return t ? h.every((n) => (e.items[n] ?? 0) >= (t.order[n] ?? 0)) : !1;
}
function Y(e, t, n) {
	let r = e.p[t];
	for (let e of h) {
		let t = n[e];
		if (t) {
			for (let n of r.cafe) {
				let r = T.get(n.guest);
				if (!r) continue;
				let i = (r.order[e] ?? 0) - (n.items[e] ?? 0);
				if (i > 0) {
					let r = Math.min(t, i);
					n.items[e] = (n.items[e] ?? 0) + r, t -= r;
				}
			}
			r.kitchen[e] += t;
		}
	}
}
function _e(t, n) {
	return t[e(n.seed, n.cursor++, t.length)];
}
function ve(t, n, r) {
	let i = 0, a = {
		seed: r,
		cursor: i,
		players: n,
		p: {},
		round: 1,
		phase: "turns",
		deckGuests: [],
		discardGuests: [],
		queue: [],
		deckStaff: [],
		objectives: {
			A: "A1",
			B: "B1",
			C: "C1"
		},
		emperors: {
			A: "A1",
			B: "B1",
			C: "C1"
		},
		claims: {},
		groupBonus: {},
		dice: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		dustbin: 0,
		turn: null,
		stage: "guest",
		passed: [],
		boostUsed: !1,
		pending: null,
		ops: [],
		final: null,
		extraPrepare: !1,
		extraStaff: !1,
		settle: null,
		emperorReport: null
	};
	a.deckGuests = O(ee.map((e) => e.id), (t) => e(r, i++, t));
	for (let e = 0; e < 5; e += 1) a.queue.push(V(a));
	a.deckStaff = O(E.map((e) => e.id), (t) => e(r, i++, t)), a.cursor = i;
	for (let e of [
		"A",
		"B",
		"C"
	]) a.objectives[e] = _e(k.filter((t) => t.group === e), a).id, a.emperors[e] = _e(j.filter((t) => t.group === e), a).id;
	for (let e of k) a.claims[e.id] = [];
	return n.forEach((e, t) => {
		let r = {
			rid: e,
			money: 10,
			vp: 0,
			emperor: 0,
			hotel: Array.from({ length: 20 }, () => "empty"),
			cafe: [],
			kitchen: z({
				strudel: 1,
				cake: 1,
				wine: 1,
				coffee: 1
			}),
			hand: [],
			display: [],
			markers: [],
			staffPlayed: 0,
			tile: [t + 1, n.length * 2 - t],
			covered: 0
		};
		for (let e = 0; e < 6; e += 1) r.hand.push(a.deckStaff.pop());
		r.hotel[0] = "vacant", r.hotel[1] = "vacant", r.hotel[2] = "vacant", a.p[e] = r, a.groupBonus[e] = S.map(() => !1);
		let i = a.queue.shift();
		i !== void 0 && r.cafe.push({
			guest: i,
			items: g()
		}), a.queue.push(V(a));
	}), Se(a), {
		state: a,
		fx: [{
			kind: "deal",
			data: {
				round: 1,
				dice: a.dice
			}
		}]
	};
}
function ye(e) {
	let t = null, n = Infinity;
	for (let r of e.players) {
		let i = e.p[r];
		if (i.covered >= 2 || e.passed.includes(r)) continue;
		let a = i.tile[i.covered];
		a < n && (n = a, t = r);
	}
	return t;
}
function be(e) {
	return e.dice.reduce((e, t) => e + t, 0);
}
function xe(t, n) {
	t.dice = [
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (let r = 0; r < n; r += 1) {
		let n = e(t.seed, t.cursor++, 6);
		t.dice[n] += 1;
	}
}
function Se(e) {
	e.phase = "turns", e.stage = "guest", e.passed = [], e.boostUsed = !1, e.turn = null, e.pending = null, e.ops = [], e.settle = null, e.emperorReport = null;
	for (let t of e.players) {
		e.p[t].covered = 0;
		for (let n of e.p[t].display) n.used = !1;
	}
	e.dustbin = 0, xe(e, ie[e.players.length] ?? 10), e.turn = ye(e);
}
function Ce(e) {
	return e.players.findIndex((t) => e.p[t].tile[0] === 1);
}
function we(e) {
	if (e.pending = null, e.ops = [], e.extraPrepare = !1, e.extraStaff = !1, e.turn = ye(e), e.turn) {
		e.stage = "guest";
		return;
	}
	if (e.players.every((t) => e.p[t].covered >= 2)) {
		Ee(e);
		return;
	}
	if (be(e) === 0) {
		Ee(e);
		return;
	}
	let t = 0;
	for (let n = 1; n < 6; n += 1) e.dice[n] > e.dice[t] && (t = n);
	--e.dice[t], e.dustbin += 1;
	let n = be(e);
	if (n === 0) {
		Ee(e);
		return;
	}
	xe(e, n), e.passed = [], e.turn = ye(e), e.stage = "guest", e.turn || Ee(e);
}
function Te(e) {
	let t = e.players.map((t) => e.p[t].tile);
	e.players.forEach((n, r) => {
		e.p[n].tile = t[(r + 1) % e.players.length];
	}), e.round += 1, Se(e);
}
function Ee(e) {
	if (e.turn = null, e.round === 3 || e.round === 5 || e.round === 7) {
		Oe(e);
		return;
	}
	Te(e);
}
function De(e) {
	return {
		vp: e.vp,
		money: e.money,
		kitchen: B(e.kitchen),
		hand: e.hand.length,
		staff: e.display.length,
		rooms: e.hotel.filter((e) => e !== "empty").length
	};
}
function Oe(e) {
	e.phase = "emperor", e.turn = null;
	let t = e.round === 3 ? "A" : e.round === 5 ? "B" : "C", n = e.round === 3 ? 3 : e.round === 5 ? 5 : 7;
	e.pending = null, e.ops = [], e.settle = {
		round: e.round,
		group: t,
		tile: e.emperors[t],
		retreat: n,
		start: Ce(e),
		idx: 0,
		current: null
	}, e.emperorReport = {
		round: e.round,
		group: t,
		tile: e.emperors[t],
		retreat: n,
		entries: []
	}, ke(e);
}
function ke(e) {
	let t = e.settle;
	if (t && !e.pending) {
		for (; t.idx < e.players.length || t.current;) {
			if (e.ops.length && (X(e), e.pending || e.ops.length)) return;
			if (t.current) {
				let n = t.current, r = e.p[n.rid];
				n.vp = r.vp - n.preVp, n.money = r.money - n.preMoney, n.kitchen = B(r.kitchen) - n.preKitchen, n.hand = r.hand.length - n.preHand, n.staff = r.display.length - n.preStaff, n.rooms = r.hotel.filter((e) => e !== "empty").length - n.preRooms, n.emperorTo = r.emperor, e.emperorReport?.entries.push(n), t.current = null, t.idx += 1;
				continue;
			}
			let n = e.players[(t.start + t.idx) % e.players.length], r = e.p[n], i = De(r), a = r.emperor;
			r.vp += ne[a] ?? 0, r.emperor = Math.max(0, a - t.retreat);
			let o = "none", s = te.get(t.tile);
			r.emperor >= 3 ? (o = "reward", W(r, "emperorRewardVp5") && (r.vp += 5), s && e.ops.push({
				rid: n,
				ops: s.reward,
				idx: 0,
				auto: !0
			})) : r.emperor === 0 && (o = "penalty", W(r, "emperorPayIgnore") && r.money >= 1 ? --r.money : s && Pe(e, n, s.penalty)), t.current = {
				rid: n,
				outcome: o,
				vp: 0,
				money: 0,
				emperorFrom: a,
				emperorTo: r.emperor,
				kitchen: 0,
				hand: 0,
				staff: 0,
				rooms: 0,
				preVp: i.vp,
				preMoney: i.money,
				preKitchen: i.kitchen,
				preHand: i.hand,
				preStaff: i.staff,
				preRooms: i.rooms
			};
		}
		e.settle = null;
	}
}
function Ae(e) {
	e.pending || e.settle || (e.round === 7 ? Le(e) : Te(e));
}
function je(e, t, n) {
	let r = e.p[t], i = r.hotel.map((e, t) => ({
		state: e,
		i: t
	})).filter((e) => e.state === "vacant").map((e) => e.i);
	i.sort((e, t) => b[t].floor - b[e].floor);
	let a = i.slice(0, n);
	for (let e of a) r.hotel[e] = "empty";
	return a.length;
}
function Me(e, t, n) {
	let r = e.p[t], i = r.hotel.map((e, t) => ({
		state: e,
		i: t
	})).filter((e) => e.state === "occupied").map((e) => e.i);
	i.sort((e, t) => b[t].floor - b[e].floor);
	let a = i.slice(0, n);
	for (let e of a) r.hotel[e] = "empty";
	return a.length;
}
function Ne(e, t, n, r) {
	let i = e.p[t];
	if (i.hand.length < n) {
		i.vp -= r;
		return;
	}
	for (let t = 0; t < n; t += 1) {
		let t = i.hand.pop();
		t !== void 0 && e.deckStaff.unshift(t);
	}
}
function Pe(e, t, n) {
	let r = e.p[t];
	switch (n) {
		case "money3":
			r.money >= 3 ? r.money -= 3 : r.vp -= 5;
			break;
		case "money5":
			r.money >= 5 ? r.money -= 5 : r.vp -= 7;
			break;
		case "vp8":
			r.vp -= 8;
			break;
		case "itemsAll":
			r.kitchen = g();
			break;
		case "itemsAllGuests":
			r.kitchen = g();
			for (let e of r.cafe) e.items = g();
			break;
		case "staff2":
			Ne(e, t, 2, 5);
			break;
		case "staff3":
			Ne(e, t, 3, 7);
			break;
		case "vacant1":
			je(e, t, 1) === 0 && (r.vp -= 5);
			break;
		case "vacant2":
			r.hotel.filter((e) => e === "vacant").length < 2 ? r.vp -= 7 : je(e, t, 2);
			break;
		case "occupied2":
			Me(e, t, 2);
			break;
		case "vpPerStaff":
			r.vp -= 2 * r.staffPlayed;
			break;
		case "staffRemove": {
			let e = r.display.findIndex((e) => D.get(e.card)?.kind === "round");
			e >= 0 ? r.display.splice(e, 1) : r.vp -= 10;
			break;
		}
	}
}
function Fe(e, t) {
	switch (t) {
		case "red3": return 3 * q(e, "red");
		case "blue3": return 3 * q(e, "blue");
		case "yellow3": return 3 * q(e, "yellow");
		case "room1": return e.hotel.filter((e) => e === "occupied").length;
		case "staff2": return 2 * e.staffPlayed;
		case "tile1": return e.hotel.filter((e) => e !== "empty").length;
		case "group2": return 2 * me(e);
		case "objective5": return 5 * e.markers.length;
		case "emperor2x": return 2 * e.emperor;
		case "floor5": return 5 * J(e);
		case "column5": return 5 * he(e);
		case "set4": return 4 * Math.min(q(e, "red"), q(e, "blue"), q(e, "yellow"));
		default: return 0;
	}
}
function Ie(e, t) {
	let n = 0;
	for (let r of e.display) {
		let i = D.get(r.card)?.effect;
		if (i?.t === "end") {
			if (i.kind === "secretary") {
				let r = 0;
				for (let n of t) for (let t of n.display) {
					let n = D.get(t.card)?.effect;
					n?.t === "end" && n.kind !== "secretary" && (r = Math.max(r, Fe(e, n.kind)));
				}
				n += r;
				continue;
			}
			n += Fe(e, i.kind);
		}
	}
	return n;
}
function Le(e) {
	e.phase = "final", e.turn = null;
	let t = {}, n = {};
	for (let r of e.players) {
		let i = e.p[r];
		i.vp += Ie(i, e.players.filter((e) => e !== r).map((t) => e.p[t]));
		for (let e = 1; e <= 4; e += 1) for (let t = 0; t < 5; t += 1) i.hotel[(e - 1) * 5 + t] === "occupied" && (i.vp += e);
		let a = B(i.kitchen) + i.money;
		i.vp += a, i.vp -= 5 * i.cafe.length, t[r] = i.vp, n[r] = a;
	}
	e.final = {
		ranking: [...e.players].sort((r, i) => t[i] - t[r] || n[i] - n[r] || e.players.indexOf(r) - e.players.indexOf(i)),
		scores: t,
		tie: n
	}, e.phase = "done";
}
function Re(e) {
	let t = {};
	for (let n of e.players) {
		let r = e.p[n], i = Ie(r, e.players.filter((e) => e !== n).map((t) => e.p[t])), a = 0;
		for (let e = 1; e <= 4; e += 1) for (let t = 0; t < 5; t += 1) r.hotel[(e - 1) * 5 + t] === "occupied" && (a += e);
		let o = B(r.kitchen) + r.money, s = 5 * r.cafe.length, c = e.final?.scores[n] ?? r.vp;
		t[n] = {
			base: c - i - a - o + s,
			staff: i,
			rooms: a,
			leftover: o,
			cafe: s,
			total: c
		};
	}
	return t;
}
function ze(e, t, n) {
	let r = e.p[t];
	for (let t = 0; t < n; t += 1) {
		let t = e.deckStaff.pop();
		if (t === void 0) break;
		r.hand.push(t);
	}
}
function Be(e, t, n, r) {
	let i = e.p[t], a = i.hand.indexOf(n), o = D.get(n);
	if (a < 0 || !o) return !1;
	let s = Math.max(0, o.cost - r);
	return i.money < s ? !1 : (i.hand.splice(a, 1), i.money -= s, i.staffPlayed += 1, i.display.push({
		iid: String(n),
		card: n,
		used: !1
	}), o.effect.t === "ops" && e.ops.push({
		rid: t,
		ops: o.effect.ops,
		idx: 0,
		auto: !1
	}), !0);
}
function Ve(e, t, n, r) {
	let i = e.p[t], a = D.get(n);
	if (!a) return !1;
	let o = Math.max(0, a.cost - r);
	return i.money < o ? !1 : (i.money -= o, i.staffPlayed += 1, i.display.push({
		iid: String(n),
		card: n,
		used: !1
	}), a.effect.t === "ops" && e.ops.push({
		rid: t,
		ops: a.effect.ops,
		idx: 0,
		auto: !1
	}), !0);
}
function He(e, t, n) {
	let r = e.p[t], i = [...r.hand].sort((e, t) => (D.get(e)?.cost ?? 0) - (D.get(t)?.cost ?? 0));
	for (let a of i) {
		let i = D.get(a);
		if (i && Math.max(0, i.cost - n) <= r.money) return Be(e, t, a, n);
	}
	return !1;
}
function Ue(e, t, n, r) {
	for (let i = 0; i < r && He(e, t, n); i += 1);
}
function We(e, t) {
	let n = [];
	for (let r = 0; r < t; r += 1) {
		let t = e.deckStaff.pop();
		if (t === void 0) break;
		n.push(t);
	}
	return n;
}
function Ge(e, t, n, r) {
	let i = We(e, n);
	i.length && (e.pending = {
		rid: t,
		kind: "staffDrawPlay",
		n: 1,
		discounts: [r],
		bottomTwo: !1,
		strength: 0,
		cards: i
	});
}
function Ke(e) {
	let t = "strudel", n = -1;
	for (let r of h) {
		let i = 0;
		for (let t of e.cafe) {
			let e = T.get(t.guest);
			e && (i += Math.max(0, (e.order[r] ?? 0) - (t.items[r] ?? 0)));
		}
		i > n && (n = i, t = r);
	}
	return t;
}
function qe(e, t, n) {
	let r = g();
	r[n] += 1, Y(e, t, r);
}
function Je(e, t, n, r, i) {
	let a = e.p[t];
	for (let o = 0; o < n; o += 1) {
		let n = r.length ? r.shift() : 0, o = G(a, n, i).sort((e, t) => e.cost - t.cost || e.cell - t.cell).find((e) => e.cost <= a.money);
		if (!o) break;
		K(e, t, o.cell, n);
	}
}
function Ye(e, t, n) {
	let r = e.p[t];
	r.hotel[n] = "occupied", pe(e, t, n), W(r, "occupyMoney1") && H(r, 1);
}
function Xe(e, t, n, r, i) {
	let a = e.p[t];
	for (let o = 0; o < n; o += 1) {
		let n = r.length ? r.shift() : 0, o = G(a, n, i).sort((e, t) => e.cost - t.cost || e.cell - t.cell).find((e) => e.cost <= a.money);
		if (!o || !K(e, t, o.cell, n)) break;
		Ye(e, t, o.cell);
	}
}
function Ze(e, t, n) {
	let r = e.p[t];
	for (let i = 0; i < n; i += 1) {
		let n = r.hotel.map((e, t) => ({
			state: e,
			cell: t
		})).filter((e) => e.state === "vacant").map((e) => e.cell);
		if (!n.length) return;
		Ye(e, t, n.find((e) => {
			let t = fe(e);
			return t >= 0 && S[t].every((t) => t === e || r.hotel[t] === "occupied");
		}) ?? n.sort((e, t) => b[t].floor - b[e].floor)[0]);
	}
}
function Qe(e, t, n, r) {
	let i = e.p[t];
	if (i.cafe.length >= 3 || n < 0 || n >= e.queue.length) return !1;
	let a = r || W(i, "queueFree") ? 0 : re[n] ?? 0;
	if (i.money < a) return !1;
	i.money -= a;
	let o = e.queue.splice(n, 1)[0];
	return o !== void 0 && (e.queue.unshift(V(e)), i.cafe.push({
		guest: o,
		items: g()
	}), !0);
}
function $e(e, t) {
	let n = e.p[t];
	if (n.cafe.length >= 3) return !1;
	let r = 0, i = -Infinity;
	return e.queue.forEach((e, t) => {
		let a = T.get(e), o = (a?.vp ?? 0) - B(z(a?.order ?? {})) * .1 - (W(n, "queueFree") ? 0 : re[t] ?? 0);
		o > i && (i = o, r = t);
	}), Qe(e, t, r, !0);
}
function et(e, t) {
	let n = e.p[t], r = null, i = -1;
	for (let e of n.cafe) {
		if (ge(e)) continue;
		let t = T.get(e.guest)?.vp ?? 0;
		t > i && (i = t, r = e);
	}
	if (!r) return;
	let a = T.get(r.guest);
	if (a) for (let e of h) r.items[e] = a.order[e] ?? 0;
}
function tt(e, t, n, r) {
	let i = e.p[t];
	if (n === 1) {
		let n = g(), a = 0;
		for (let e of i.cafe) {
			let t = T.get(e.guest);
			t && (a += Math.max(0, (t.order.cake ?? 0) - (e.items.cake ?? 0)));
		}
		let o = Math.min(a, Math.floor(r / 2));
		n.cake = o, n.strudel = r - o, Y(e, t, n);
	} else if (n === 2) {
		let n = g(), a = 0;
		for (let e of i.cafe) {
			let t = T.get(e.guest);
			t && (a += Math.max(0, (t.order.coffee ?? 0) - (e.items.coffee ?? 0)));
		}
		let o = Math.min(a, Math.floor(r / 2));
		n.coffee = o, n.wine = r - o, Y(e, t, n);
	} else n === 3 ? Je(e, t, r, [], !1) : n === 4 ? U(e, i, r) : n === 5 && He(e, t, r);
}
function nt(e, t, n) {
	let r = t.rid, i = e.p[r];
	switch (n.t) {
		case "item": {
			let t = g();
			t[n.item] += n.n, Y(e, r, t);
			break;
		}
		case "itemAll":
			for (let t of h) {
				let i = g();
				i[t] += n.n, Y(e, r, i);
			}
			break;
		case "choiceItem":
			if (t.auto) for (let t = 0; t < n.n; t += 1) qe(e, r, Ke(i));
			else e.pending = {
				rid: r,
				kind: "item",
				n: n.n,
				discounts: [],
				bottomTwo: !1,
				strength: 0
			};
			break;
		case "money":
			H(i, n.n);
			break;
		case "emperor":
			U(e, i, n.n);
			break;
		case "vp":
			i.vp += n.n;
			break;
		case "vpStaff":
			i.vp += n.per * i.staffPlayed;
			break;
		case "prepare":
			t.auto ? Je(e, r, n.n, [...n.discounts], n.bottomTwo ?? !1) : e.pending = {
				rid: r,
				kind: "prepare",
				n: n.n,
				discounts: [...n.discounts],
				bottomTwo: n.bottomTwo ?? !1,
				strength: 0
			};
			break;
		case "prepareOccupy":
			Xe(e, r, n.n, [...n.discounts], n.bottomTwo ?? !1);
			break;
		case "occupy":
			Ze(e, r, n.n);
			break;
		case "staffDraw":
			ze(e, r, n.n);
			break;
		case "staffDiscount":
			t.auto ? Ue(e, r, n.n, n.count ?? 1) : e.pending = {
				rid: r,
				kind: "staff",
				n: n.count ?? 1,
				discounts: [n.n],
				bottomTwo: !1,
				strength: 0
			};
			break;
		case "staffDrawPlay":
			Ge(e, r, n.count, n.discount);
			break;
		case "guestFree":
			if (t.auto) for (let t = 0; t < n.n; t += 1) $e(e, r);
			else e.pending = {
				rid: r,
				kind: "guestFree",
				n: n.n,
				discounts: [],
				bottomTwo: !1,
				strength: 0
			};
			break;
		case "imitate":
			if (t.auto) {
				let t = 1;
				for (let n = 1; n < 5; n += 1) e.dice[n] > e.dice[t - 1] && (t = n + 1);
				let n = e.dice[t - 1];
				n > 0 && tt(e, r, t, n);
			} else e.pending = {
				rid: r,
				kind: "imitate",
				n: 1,
				discounts: [],
				bottomTwo: !1,
				strength: 0
			};
			break;
		case "fillOrder": et(e, r);
	}
}
function X(e) {
	for (; e.ops.length;) {
		if (e.pending) return;
		let t = e.ops[e.ops.length - 1];
		if (t.idx >= t.ops.length) {
			e.ops.pop();
			continue;
		}
		let n = t.ops[t.idx];
		t.idx += 1, nt(e, t, n);
	}
}
function rt(e, t) {
	let n = b[t].col;
	return [
		t - 5,
		t + 5,
		n > 0 ? t - 1 : -1,
		n < 4 ? t + 1 : -1
	].some((t) => t >= 0 && t < 20 && e[t] !== "empty");
}
function it(e, t) {
	let n = 0;
	return (t === 1 || t === 2) && W(e, "die12Str1") && (n += 1), t === 5 && W(e, "die5Str2") && (n += 2), t === 6 && W(e, "die6Str1Free") && (n += 1), n;
}
function at(e, t, n) {
	let r = e.p[t];
	(n === 3 || n === 4) && W(r, "die34Vp2") && (r.vp += 2), n === 4 && W(r, "die4Vp4") && (r.vp += 4), n === 3 && W(r, "die3Vp5") && (r.vp += 5), n === 5 && W(r, "die5Emperor2") && U(e, r, 2);
}
function ot(e, t, n, r, i) {
	let a = e.p[t];
	if (n === 1) {
		let e = i.type === "die" ? i.dishes : void 0;
		if (!e) return R("errChoice");
		let t = e.strudel ?? 0, n = e.cake ?? 0;
		return t + n === r ? t < n ? R("errDishMix") : null : R("errSum");
	}
	if (n === 2) {
		let e = i.type === "die" ? i.drinks : void 0;
		if (!e) return R("errChoice");
		let t = e.wine ?? 0, n = e.coffee ?? 0;
		return t + n === r ? t < n ? R("errDrinkMix") : null : R("errSum");
	}
	if (n === 3) {
		let e = i.type === "die" ? i.rooms ?? [] : [];
		if (e.length > r) return R("errTooManyRooms");
		let t = [...a.hotel], n = a.money;
		for (let r of e) {
			if (r < 0 || r >= 20 || t[r] !== "empty") return R("errRoom");
			if (!rt(t, r)) return R("errRoomAdjacent");
			let e = de(a, r, 0);
			if (n < e) return R("errMoney");
			n -= e, t[r] = "vacant";
		}
		return null;
	}
	if (n === 4) {
		let e = i.type === "die" ? i.favor : void 0;
		return e ? (e.emperor ?? 0) + (e.money ?? 0) === r ? null : R("errSum") : R("errChoice");
	}
	if (n === 5) {
		let e = i.type === "die" ? i.staffIid : void 0;
		if (!e) return null;
		let t = Number(e), n = D.get(t);
		return !n || !a.hand.includes(t) ? R("errStaff") : Math.max(0, n.cost - r) > a.money ? R("errMoney") : null;
	}
	if (n === 6) {
		if (!W(a, "die6Str1Free") && a.money < 1) return null;
		let n = i.type === "die" ? i.imitateSpace : void 0;
		return n ? n < 1 || n > 5 ? R("errChoice") : ot(e, t, n, r, i) : null;
	}
	return R("errChoice");
}
function st(e, t, n, r, i) {
	let a = e.p[t];
	if (n === 1) {
		let n = g();
		n.strudel = i.type === "die" ? i.dishes?.strudel ?? 0 : 0, n.cake = i.type === "die" ? i.dishes?.cake ?? 0 : 0, Y(e, t, n);
		return;
	}
	if (n === 2) {
		let n = g();
		n.wine = i.type === "die" ? i.drinks?.wine ?? 0 : 0, n.coffee = i.type === "die" ? i.drinks?.coffee ?? 0 : 0, Y(e, t, n);
		return;
	}
	if (n === 3) {
		let n = i.type === "die" ? i.rooms ?? [] : [];
		for (let r of n) K(e, t, r, 0);
		return;
	}
	if (n === 4) {
		let t = i.type === "die" ? i.favor : void 0;
		t && (U(e, a, t.emperor ?? 0), H(a, t.money ?? 0));
		return;
	}
	if (n === 5) {
		Be(e, t, Number(i.type === "die" ? i.staffIid : ""), r);
		return;
	}
	if (n === 6) {
		let n = i.type === "die" ? i.imitateSpace ?? 0 : 0;
		n >= 1 && n <= 5 && st(e, t, n, r, i);
	}
}
function ct(e, t) {
	switch (t) {
		case "money20": return e.money >= 20;
		case "emperor10": return e.emperor >= 10;
		case "staff6": return e.staffPlayed >= 6;
		case "tiles12": return e.hotel.filter((e) => e !== "empty").length >= 12;
		case "floors2": return J(e) >= 2;
		case "columns2": return he(e) >= 2;
		case "colorAll": return [
			"blue",
			"red",
			"yellow"
		].some((t) => b.every((n, r) => n.color !== t || e.hotel[r] === "occupied"));
		case "groups6": return me(e) >= 6;
		case "c3each": return q(e, "red") >= 3 && q(e, "yellow") >= 3 && q(e, "blue") >= 3;
		case "r4y3": return q(e, "red") >= 4 && q(e, "yellow") >= 3;
		case "y4b3": return q(e, "yellow") >= 4 && q(e, "blue") >= 3;
		case "b4r3": return q(e, "blue") >= 4 && q(e, "red") >= 3;
		default: return !1;
	}
}
function lt(e, t) {
	let n = e.turn;
	if (!n) return R("errTurn");
	let r = e.p[n], i = t.type === "die" ? t.space : 0;
	if (i < 1 || i > 6) return R("errChoice");
	if (e.dice[i - 1] <= 0) return R("errNoDie");
	if (t.type === "die" && t.boost && e.boostUsed) return R("errBoost");
	let a = (t.type === "die" && t.boost ? 1 : 0) + +(i === 6 && !W(r, "die6Str1Free") && r.money >= 1);
	if (r.money < a) return R("errMoney");
	let o = e.dice[i - 1] + (t.type === "die" && t.boost ? 1 : 0) + it(r, i);
	return ot(e, n, i, o, t) || (t.type === "die" && t.boost && (--r.money, e.boostUsed = !0), i === 6 && !W(r, "die6Str1Free") && r.money >= 1 && --r.money, --e.dice[i - 1], at(e, n, i), i === 4 && W(r, "die4Bootblack") ? (H(r, o), U(e, r, o)) : st(e, n, i, o, t), e.extraPrepare = (i === 1 || i === 2) && W(r, "die12Prepare"), e.extraStaff = i === 3 && W(r, "die3Staff"), e.stage = "after", X(e), null);
}
function ut(e, t, n, r) {
	let i = e.p[t], a = i.cafe[n];
	if (!a) return R("errGuest");
	if (!ge(a)) return R("errOrder");
	if (r < 0 || r >= 20 || i.hotel[r] !== "vacant") return R("errRoom");
	let o = T.get(a.guest);
	if (!o) return R("errGuest");
	let s = b[r];
	return o.color !== "green" && o.color !== s.color ? R("errColor") : (i.hotel[r] = "occupied", W(i, "occupyMoney1") && H(i, 1), i.vp += o.vp, i.cafe.splice(n, 1), e.discardGuests.push(o.id), pe(e, t, r), o.color === "red" && W(i, "redMoney2") && H(i, 2), o.color === "blue" && W(i, "blueEmperor1") && U(e, i, 1), o.color === "yellow" && W(i, "yellowMoney1") && H(i, 1), o.color === "green" && W(i, "greenVp2") && (i.vp += 2), B(z(o.order)) >= 4 && W(i, "guest4ItemsVp4") && (i.vp += 4), e.ops.push({
		rid: t,
		ops: o.reward,
		idx: 0,
		auto: !1
	}), X(e), null);
}
function dt(e, t, n, r) {
	let i = e.p[t], a = i.cafe[n];
	if (!a) return R("errGuest");
	let o = T.get(a.guest);
	if (!o) return R("errGuest");
	let s = B(r);
	if (s <= 0 || s > 3) return R("errServeCount");
	for (let e of h) {
		let t = r[e];
		if (t < 0) return R("errServeCount");
		if (i.kitchen[e] < t) return R("errKitchen");
		if ((a.items[e] ?? 0) + t > (o.order[e] ?? 0)) return R("errServeOver");
	}
	let c = +!W(i, "serveFree");
	if (i.money < c) return R("errMoney");
	i.money -= c;
	for (let e of h) i.kitchen[e] -= r[e], a.items[e] = (a.items[e] ?? 0) + r[e];
	return null;
}
function ft(e, t, n) {
	let r = e.p[t], i = k.find((e) => e.id === n);
	if (!i || !Object.values(e.objectives).includes(n)) return R("errObjective");
	if (r.markers.some((e) => e.card === n)) return R("errClaimed");
	let a = e.claims[n] ?? [];
	if (a.length >= 3) return R("errClaimed");
	if (!ct(r, i.kind)) return R("errNotMet");
	let o = A[a.length] ?? 0;
	return r.vp += o, r.markers.push({
		card: n,
		vp: o
	}), a.push({
		rid: t,
		vp: o,
		slot: a.length
	}), e.claims[n] = a, null;
}
function pt(e, t, n) {
	let r = e.pending;
	if (!r) return R("errNoPending");
	if (r.rid !== t) return R("errTurn");
	let i = e.p[t], a = !1;
	if (r.kind === "item") {
		if (!h.includes(n)) return R("errChoice");
		qe(e, t, n), --r.n, r.n <= 0 && (a = !0);
	} else if (r.kind === "prepare") {
		if (n === "done") a = !0;
		else {
			if (!K(e, t, Number(n.replace("cell:", "")), r.discounts.length ? r.discounts[0] : 0)) return R("errRoom");
			r.discounts.length && r.discounts.shift(), --r.n;
			let o = G(i, r.discounts.length ? r.discounts[0] : 0, r.bottomTwo).filter((e) => e.cost <= i.money);
			(r.n <= 0 || o.length === 0) && (a = !0);
		}
	} else if (r.kind === "staff") {
		if (n === "skip") a = !0;
		else {
			if (!Be(e, t, Number(n.replace("staff:", "")), r.discounts[0] ?? 0)) return R("errStaff");
			--r.n, r.n <= 0 && (a = !0);
		}
	} else if (r.kind === "staffDrawPlay") {
		let i = r.cards ?? [];
		if (n === "skip") i.length && e.deckStaff.unshift(...i), a = !0;
		else {
			let o = Number(n.replace("staff:", ""));
			if (!i.includes(o) || !Ve(e, t, o, r.discounts[0] ?? 0)) return R("errStaff");
			let s = i.filter((e) => e !== o);
			s.length && e.deckStaff.unshift(...s), a = !0;
		}
	} else if (r.kind === "guestFree") {
		if (n === "skip") a = !0;
		else {
			if (!Qe(e, t, Number(n.replace("queue:", "")), !0)) return R("errGuest");
			--r.n, (r.n <= 0 || i.cafe.length >= 3) && (a = !0);
		}
	} else if (r.kind === "imitate") {
		let r = Number(n.replace("space:", ""));
		if (r < 1 || r > 5) return R("errChoice");
		let i = e.dice[r - 1];
		if (i <= 0) return R("errNoDie");
		tt(e, t, r, i), a = !0;
	}
	return a && (e.pending = null), X(e), e.phase === "emperor" && !e.pending && ke(e), null;
}
function mt(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	let r = structuredClone(e);
	if (r.phase === "emperor") return r.pending ? t.type === "choose" ? pt(r, n.by, t.id) || {
		state: r,
		fx: []
	} : R("errPending") : t.type === "continue" ? (Ae(r), {
		state: r,
		fx: []
	}) : R("errPhase");
	if (r.phase !== "turns") return R("errPhase");
	if (r.pending) return t.type === "choose" ? pt(r, n.by, t.id) || {
		state: r,
		fx: []
	} : R("errPending");
	let i = r.turn;
	if (!i || n.by !== i) return R("errTurn");
	let a = r.p[i];
	if (r.stage === "guest") return t.type === "guest" ? Qe(r, i, t.index, !1) ? (r.stage = "main", {
		state: r,
		fx: []
	}) : R("errGuest") : t.type === "skipGuest" ? (r.stage = "main", {
		state: r,
		fx: []
	}) : t.type === "pass" ? (r.passed.push(i), r.turn = null, we(r), {
		state: r,
		fx: []
	}) : R("errChoice");
	if (r.stage === "main") return t.type === "die" ? lt(r, t) || {
		state: r,
		fx: []
	} : R("errChoice");
	if (t.type === "move") return ut(r, i, t.guest, t.cell) || {
		state: r,
		fx: []
	};
	if (t.type === "serve") {
		let e = z(t.items);
		return dt(r, i, t.guest, e) || {
			state: r,
			fx: []
		};
	}
	if (t.type === "claim") return ft(r, i, t.card) || {
		state: r,
		fx: []
	};
	if (t.type === "staff") {
		let e = a.display.find((e) => e.iid === t.iid), n = e ? D.get(e.card) : void 0;
		return !e || !n || e.used || n.kind !== "round" ? R("errStaff") : (e.used = !0, n.effect.t === "ops" && r.ops.push({
			rid: i,
			ops: n.effect.ops,
			idx: 0,
			auto: !1
		}), X(r), {
			state: r,
			fx: []
		});
	}
	return t.type === "prepareExtra" ? r.extraPrepare ? K(r, i, t.cell, 0) ? (r.extraPrepare = !1, {
		state: r,
		fx: []
	}) : R("errRoom") : R("errChoice") : t.type === "staffPlay" ? r.extraStaff ? Be(r, i, Number(t.iid), 0) ? (r.extraStaff = !1, X(r), {
		state: r,
		fx: []
	}) : R("errStaff") : R("errChoice") : t.type === "endTurn" ? (a.covered += 1, r.boostUsed = !1, r.stage = "guest", we(r), {
		state: r,
		fx: []
	}) : R("errChoice");
}
function ht(e, t, n) {
	let r = e.p[t.rid];
	if (n !== t.rid && (t.kind === "staff" || t.kind === "staffDrawPlay")) return [];
	if (t.kind === "item") return h.map((e) => ({
		id: e,
		kind: "item",
		item: e
	}));
	if (t.kind === "prepare") return [...G(r, t.discounts.length ? t.discounts[0] : 0, t.bottomTwo).filter((e) => e.cost <= r.money).map((e) => ({
		id: `cell:${e.cell}`,
		kind: "cell",
		cell: e.cell,
		cost: e.cost
	})), {
		id: "done",
		kind: "skip"
	}];
	if (t.kind === "staff") {
		let e = t.discounts[0] ?? 0;
		return [...r.hand.map((t) => {
			let n = Math.max(0, (D.get(t)?.cost ?? 0) - e);
			return {
				id: `staff:${t}`,
				kind: "staff",
				iid: String(t),
				card: String(t),
				cost: n,
				disabled: n > r.money
			};
		}), {
			id: "skip",
			kind: "skip"
		}];
	}
	if (t.kind === "staffDrawPlay") {
		let e = t.discounts[0] ?? 0;
		return [...(t.cards ?? []).map((t) => {
			let n = Math.max(0, (D.get(t)?.cost ?? 0) - e);
			return {
				id: `staff:${t}`,
				kind: "staff",
				iid: String(t),
				card: String(t),
				cost: n,
				disabled: n > r.money
			};
		}), {
			id: "skip",
			kind: "skip"
		}];
	}
	if (t.kind === "guestFree") return [...e.queue.map((e, t) => ({
		id: `queue:${t}`,
		kind: "queue",
		index: t,
		card: String(e),
		disabled: r.cafe.length >= 3
	})), {
		id: "skip",
		kind: "skip"
	}];
	let i = [];
	for (let t = 1; t <= 5; t += 1) e.dice[t - 1] > 0 && i.push({
		id: `space:${t}`,
		kind: "space",
		space: t
	});
	return i;
}
function gt(e, t) {
	let n = e.p[t], r = e.players.filter((t) => e.p[t].covered < 2).sort((t, n) => e.p[t].tile[e.p[t].covered] - e.p[n].tile[e.p[n].covered] || e.players.indexOf(t) - e.players.indexOf(n));
	return {
		public: {
			round: e.round,
			phase: e.phase,
			queue: e.queue.map(String),
			guestDeckCount: e.deckGuests.length,
			staffDeckCount: e.deckStaff.length,
			emperor: e.emperors,
			objectives: e.objectives,
			claims: e.claims,
			dice: e.dice,
			dustbin: e.dustbin,
			roundTurns: Object.fromEntries(e.players.map((t) => [t, 2 - e.p[t].covered])),
			turn: {
				seat: e.phase === "turns" ? e.turn : null,
				stage: e.phase === "turns" ? e.stage : null,
				order: r,
				passed: e.passed
			},
			players: e.players.map((t) => {
				let n = e.p[t];
				return {
					rid: t,
					money: n.money,
					vp: n.vp,
					emperor: n.emperor,
					hotel: n.hotel,
					cafe: n.cafe.map((e) => ({
						guest: String(e.guest),
						items: e.items
					})),
					kitchen: n.kitchen,
					handCount: n.hand.length,
					staff: n.display.map((e) => ({
						iid: e.iid,
						card: String(e.card),
						used: e.used
					})),
					markers: n.markers,
					staffPlayed: n.staffPlayed,
					covered: n.covered,
					tile: n.tile
				};
			}),
			pending: e.pending ? {
				seat: e.pending.rid,
				kind: e.pending.kind,
				title: e.pending.kind,
				options: ht(e, e.pending, t)
			} : null,
			extra: {
				prepare: e.extraPrepare,
				staff: e.extraStaff
			},
			emperorReport: e.emperorReport ? {
				round: e.emperorReport.round,
				group: e.emperorReport.group,
				tile: e.emperorReport.tile,
				retreat: e.emperorReport.retreat,
				entries: e.emperorReport.entries.map((e) => ({
					rid: e.rid,
					outcome: e.outcome,
					vp: e.vp,
					money: e.money,
					emperorFrom: e.emperorFrom,
					emperorTo: e.emperorTo,
					kitchen: e.kitchen,
					hand: e.hand,
					staff: e.staff,
					rooms: e.rooms
				}))
			} : null,
			final: e.final ? {
				...e.final,
				breakdown: Re(e)
			} : null
		},
		private: {
			hand: n.hand.map((e) => ({
				iid: String(e),
				card: String(e)
			})),
			seat: e.players.indexOf(t)
		}
	};
}
function _t(e) {
	if (e.phase !== "done" || !e.final) return { phase: e.phase };
	let t = e.final.ranking[0];
	return {
		phase: "done",
		winner: e.final.ranking.filter((n) => e.final.scores[n] === e.final.scores[t] && e.final.tie[n] === e.final.tie[t]),
		ranking: e.final.ranking,
		scores: e.final.scores
	};
}
var vt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ae,
	schemas: {
		action: se,
		publicView: L,
		privateView: ce
	},
	setup: ve,
	reduce: mt,
	viewFor: gt,
	status: _t
}, yt = {
	name: "奥地利大饭店",
	desc: "在维也纳的黄金年代经营酒店，安排宾客、准备客房并取悦皇帝",
	rules: [
		"目标：经过七轮经营，把咖啡馆中的宾客安置进客房并满足他们的餐饮订单，同时取悦皇帝。终局时胜利点数最高的玩家获胜。",
		"开局准备：每名玩家拥有 10 克朗、一块酒店版图、一块金钱轨、一块皇帝轨与三枚目标标记。底层左侧的三间客房在开局时已经免费准备好；厨房中各有 1 份果卷、1 份蛋糕、1 份红葡萄酒与 1 份咖啡；手中抽取 6 张员工卡，咖啡馆中安置 1 位宾客。",
		"公共区域按 A、B、C 三组各随机翻开 1 张目标卡与 1 张皇帝板块。宾客牌堆洗匀后，在版图下方组成 5 位宾客的队列。",
		"每轮流程：起始玩家掷出全部骰子（2 人 10 枚、3 人 12 枚、4 人 14 枚），按点数放到行动板上对应的行动格。每名玩家在每轮各有两次行动机会，按自己回合顺序板上当前可见的最小数字依次行动。",
		"你的回合开始时，可以先从队列中迎接 1 位宾客，也可以跳过。迎接宾客须支付队列位置标示的费用（依次为 3、2、1、0、0 克朗），随后把宾客放到咖啡馆的空桌位；咖啡馆最多容纳 3 位宾客。",
		"随后你必须选择一个至少还有 1 枚骰子的行动格，取走 1 枚骰子，并以该行动格的骰子数量作为行动强度。你可以支付 1 克朗把强度提高 1，每回合最多一次。取走的骰子用于遮住你回合顺序板上当前最小的数字。",
		"跳过：你也可以在轮到你时不行动而选择跳过。跳过不会放弃回合，只会把行动推迟到重新掷骰之后。当其他所有玩家也都跳过或已完成两次行动时，从行动板上取走剩余骰子，把其中一枚放到垃圾桶，其余骰子重新掷出并按点数放回行动格，然后由回合顺序数字最小的玩家继续决定行动或跳过。若玩家继续跳过，就重复这一过程，直到所有玩家都完成两次行动，或没有骰子可以重掷为止。",
		"取餐点：获得等于强度的果卷与蛋糕，其中果卷数量不得少于蛋糕。",
		"饮品台：获得等于强度的红葡萄酒与咖啡，其中红葡萄酒数量不得少于咖啡。",
		"客房准备：最多准备等于强度的客房。新客房必须与已有客房上下左右相邻，颜色须与版图格一致，并按楼层支付费用（一层免费，二层 1 克朗，三层 2 克朗，四层 3 克朗）。右上角带胜利点数的客房在放置时立即得分。",
		"皇帝与金币：把等于强度的点数自由分配给皇帝轨和金钱轨。皇帝轨走到 13 格后，每多走 1 格改为获得 1 点胜利点数；金钱最多保留 20 克朗。",
		"聘请员工：从手中打出 1 张员工卡，费用按行动强度减免，最低为 0。员工卡打出后留在展示区，其效果立即结算。",
		"模仿行动：支付 1 克朗，选择其余五种主要行动之一，以模仿行动格上的骰子数量作为强度执行。被模仿的行动格不需要仍有骰子。",
		"获得食材与饮品时，系统会自动把它们放到咖啡馆中能够匹配的宾客订单上，无法放置的部分进入厨房。你也可以在回合中的任意时点从厨房取用。",
		"附加行动：在你的回合中，除主要行动外还可以任意次执行以下附加行动。",
		"· 上菜：支付 1 克朗，从厨房把至多 3 份食材或饮品移到一位或多位宾客的订单上。",
		"· 完成目标：若满足某张目标卡的条件，把一枚标记放到该卡剩余的最高分位置并立即得分。每张目标卡每人只能领取一次。",
		"· 使用员工：展示区中带每轮可用标记的员工卡每轮可使用一次，使用后横置。",
		"· 送客入住：当一位宾客的订单全部满足后，可以把他送入一间颜色相符的空置客房，并把该客房翻开为已入住。绿色宾客可以入住任意颜色。随后获得宾客卡上的胜利点数与奖励，订单上的食材归还供应堆。",
		"入住奖励：当某一组同色客房全部入住时，立即获得该组的入住奖励：蓝色给胜利点数，红色给克朗，黄色给皇帝轨步数。每组只奖励一次。",
		"皇帝结算：第 3、5、7 轮结束时进行皇帝结算。先按皇帝轨当前位置获得胜利点数（0 至 13 格依次为 0、1、1、3、4、4、5、5、6、6、7、7、8、9 分），再后退 3、5、7 格。后退后位于 3 格或以上时获得当轮皇帝板块上半部的奖励；位于 1 至 2 格时无事发生；位于 0 格时承受下半部的惩罚。皇帝轨不会因结算清零。",
		"终局计分：第 7 轮皇帝结算后进行终局计分。先结算展示区中带终局标记的员工卡，再按已入住客房的楼层计分（一至四层每间分别为 1、2、3、4 分），然后厨房中每份剩余食材与金钱轨上每 1 克朗各获得 1 分，最后咖啡馆中每位尚未入住的宾客扣 5 分。",
		"平手判定：胜利点数相同时，比较终局计分第三步所得分数（剩余食材与克朗），较高者获胜。",
		"系统说明：皇帝板块的奖励与惩罚、皇帝奖励中要准备或翻为已入住的客房、以及获得食材与饮品的放置位置，均由系统自动处理。如果奖励要求你从抽到的员工卡中打出 1 张，则由你亲自选择打出的卡。终局时，秘书会自动复制对手展示区中收益最高的一项终局效果，另一位秘书的复制效果不计入；行李员会自动为胜利点数最高的未完成订单补满全部食材与饮品；宾客奖励或员工效果要求把空置客房翻为已入住时，系统也会自动选择客房。其余选择由你亲自决定。"
	].join("\n"),
	roundChip: "第 {{n}} 轮",
	yourTurn: "轮到你行动",
	waitTurn: "等待 {{name}} 行动",
	emperorPhase: "皇帝结算",
	finalPhase: "终局计分",
	donePhase: "本局结束",
	stageGuest: "先决定是否从队列迎接一位宾客",
	stageMain: "选择一个行动格取走骰子",
	stageAfter: "可以上菜、送客入住、完成目标或使用员工",
	pickRoom: "选择要准备的客房",
	pickStaff: "选择要打出的员工卡",
	pickGuest: "选择要迎接的宾客",
	pickItem: "选择一份食材或饮品",
	pickSpace: "选择要模仿的行动",
	queue: "宾客队列",
	deckN: "牌堆 {{n}}",
	actionBoard: "行动板",
	objectives: "目标",
	emperorTiles: "皇帝板块",
	hotel: "酒店",
	cafe: "咖啡馆",
	kitchen: "厨房",
	hand: "手牌",
	staffDisplay: "员工展示区",
	money: "克朗",
	vp: "胜利点",
	free: "免费",
	emperorTrack: "皇帝轨",
	pass: "跳过",
	skipGuest: "不迎接宾客",
	takeGuest: "迎接宾客",
	endTurn: "结束回合",
	serve: "上菜",
	moveTo: "送入客房",
	claim: "完成目标",
	useStaff: "使用员工",
	confirm: "确认",
	cancel: "取消",
	boost: "支付 1 克朗，强度 +1",
	noDice: "没有骰子",
	emptyRoom: "空地",
	vacant: "空置",
	occupied: "已入住",
	remainingTurns: "剩余 {{n}} 次行动",
	turnNumber: "顺序 {{n}}",
	items: {
		strudel: "果卷",
		cake: "蛋糕",
		wine: "红葡萄酒",
		coffee: "咖啡"
	},
	colors: {
		blue: "贵族",
		red: "市民",
		yellow: "艺术家",
		green: "游客"
	},
	colorShort: {
		blue: "蓝",
		red: "红",
		yellow: "黄",
		green: "绿"
	},
	spaces: {
		1: "取餐点",
		2: "饮品台",
		3: "客房准备",
		4: "皇帝与金币",
		5: "聘请员工",
		6: "模仿行动"
	},
	spaceHints: {
		1: "获得等于强度的果卷与蛋糕",
		2: "获得等于强度的红葡萄酒与咖啡",
		3: "最多准备等于强度的客房",
		4: "把强度分配给皇帝轨与金钱",
		5: "打出 1 张员工卡，费用按强度减免",
		6: "支付 1 克朗，模仿一种主要行动"
	},
	skip: "跳过",
	pendingItem: "选择一份食材或饮品",
	pendingPrepare: "选择要准备的客房，也可以跳过",
	pendingStaff: "选择要打出的员工卡，也可以跳过",
	pendingGuest: "选择要迎接的宾客，也可以跳过",
	pendingImitate: "选择要模仿的行动格",
	objectiveDone: "已领取",
	objectiveSpots: "剩余 {{n}} 个位置",
	noObjective: "条件未满足",
	staffUsed: "本轮已用",
	staffRound: "每轮",
	seatOrder: "行动顺序",
	log: "记录",
	parenOpen: "（",
	parenClose: "）",
	comma: "，",
	listSep: "、",
	rooms: "客房",
	playerColors: [
		"蓝色",
		"橙色",
		"紫色",
		"金色"
	],
	continueBtn: "继续",
	emperorContinueHint: "所有玩家结算完毕后，点击继续进入下一阶段。",
	extraPrepareHint: "可以额外准备 1 间客房。",
	extraStaffHint: "可以额外打出 1 张员工卡。",
	brand: "奥地利大饭店",
	brandLatin: "GRAND AUSTRIA HOTEL",
	brandMotto: "维也纳 · 黄金年代",
	yourHotel: "你的酒店",
	railTitle: "行动顺序",
	dustbin: "垃圾桶",
	emptyTable: "空桌",
	reservado: "Reservado",
	readyOrder: "订单完成",
	strength: "强度",
	dice: "骰子",
	myTurnBadge: "轮到你",
	pickCafeHint: "先点选咖啡馆中的宾客，再点金色客房送入。",
	endKicker: "账房结算",
	endTitle: "终局总账",
	endWinner: "{{name}} 成为维也纳最出色的酒店主人",
	endCoWinners: "{{names}} 并列第一",
	endRank: "排名",
	endBreakdown: "计分明细",
	endBase: "经营得分",
	endStaff: "员工卡终局效果",
	endRooms: "已入住客房",
	endLeftover: "剩余食材与克朗",
	endCafe: "咖啡馆未入住宾客",
	endCafeEach: "每客 −5",
	endTotal: "终局总分",
	endPoints: "分",
	endTieNote: "同分时比较剩余食材与克朗。",
	confirmAgain: "确认再开一局？",
	confirmLobby: "确认返回大厅？",
	emperorSettleTitle: "第 {{round}} 轮皇帝结算 · {{tile}} · 后退 {{retreat}} 格",
	emperorReward: "奖励",
	emperorPenalty: "惩罚",
	emperorNone: "无事发生",
	emperorVp: "胜利点",
	objectiveText: {
		A1: "拥有 20 克朗。",
		A2: "皇帝轨位于 10 格或更高。",
		A3: "已打出至少 6 张员工卡。",
		A4: "酒店中至少有 12 间客房，空置或已入住均可。",
		B1: "至少有 2 层楼全部入住。",
		B2: "至少有 2 列客房全部入住。",
		B3: "至少一种颜色的客房全部入住。",
		B4: "至少有 6 组客房全部入住。",
		C1: "红、黄、蓝三色各至少有 3 间已入住客房。",
		C2: "至少有 4 间红色与 3 间黄色已入住客房。",
		C3: "至少有 4 间黄色与 3 间蓝色已入住客房。",
		C4: "至少有 4 间蓝色与 3 间红色已入住客房。"
	},
	objectiveName: {
		A1: "财富",
		A2: "圣眷",
		A3: "班底",
		A4: "扩张",
		B1: "满楼",
		B2: "满列",
		B3: "纯色",
		B4: "连片",
		C1: "三色齐备",
		C2: "红黄并举",
		C3: "黄蓝相映",
		C4: "蓝红交辉"
	},
	emperorName: {
		A1: "赏金",
		A2: "御膳",
		A3: "举荐",
		A4: "赐宅",
		B1: "四珍",
		B2: "厚赏",
		B3: "钦点",
		B4: "赐第",
		C1: "荣光",
		C2: "恩宅",
		C3: "论功",
		C4: "特恩"
	},
	emperorText: {
		A1: {
			reward: "获得 3 克朗。",
			penalty: "失去 3 克朗；不足 3 克朗时改为失去 5 点胜利点数。"
		},
		A2: {
			reward: "由系统自动获得 2 份食材或饮品。",
			penalty: "厨房中的食材与饮品全部归还供应堆。"
		},
		A3: {
			reward: "抽 3 张员工卡并立即打出其中 1 张，费用减免至多 3 克朗。",
			penalty: "从手中退回 2 张员工卡；不足 2 张时失去 5 点胜利点数。"
		},
		A4: {
			reward: "免费准备 1 间客房。",
			penalty: "从最高楼层移除 1 间空置客房；没有空置客房时失去 5 点胜利点数。"
		},
		B1: {
			reward: "获得 1 份果卷、1 份蛋糕、1 份红葡萄酒与 1 份咖啡。",
			penalty: "厨房与咖啡馆宾客订单上的食材、饮品全部归还供应堆。"
		},
		B2: {
			reward: "获得 5 克朗。",
			penalty: "失去 5 克朗；不足 5 克朗时改为失去 7 点胜利点数。"
		},
		B3: {
			reward: "抽 3 张员工卡并立即免费打出其中 1 张。",
			penalty: "从手中退回 3 张员工卡；不足 3 张时失去 7 点胜利点数。"
		},
		B4: {
			reward: "免费准备 1 间客房并立即入住，须位于最下面两层。",
			penalty: "从最高楼层移除 2 间空置客房；空置客房不足 2 间时失去 7 点胜利点数。"
		},
		C1: {
			reward: "获得 8 点胜利点数。",
			penalty: "失去 8 点胜利点数。"
		},
		C2: {
			reward: "免费准备 1 间客房并立即入住。",
			penalty: "从最高楼层移除 1 间已入住客房，并尽可能再移除 1 间。"
		},
		C3: {
			reward: "每张已打出的员工卡得 2 点胜利点数。",
			penalty: "每张已打出的员工卡失去 2 点胜利点数。"
		},
		C4: {
			reward: "免费打出 1 张员工卡。",
			penalty: "从展示区移除 1 张每轮可用的员工卡；没有这类员工时失去 10 点胜利点数。"
		}
	},
	staffNames: {
		1: "早餐服务员",
		2: "女侍者",
		3: "酒吧侍者",
		4: "副主厨",
		5: "马夫",
		6: "马厩管理员",
		7: "按摩师",
		8: "导游",
		9: "管家",
		10: "司机",
		11: "花艺师",
		12: "行政客房主管",
		13: "餐厅经理",
		14: "装饰师",
		15: "擦鞋匠",
		16: "洗衣妇",
		17: "厨房帮工",
		18: "稽核员",
		19: "室内设计师",
		20: "侦探",
		21: "主厨",
		22: "员工经理",
		23: "管理员",
		24: "侍者领班",
		25: "送货男孩",
		26: "会议经理",
		27: "预订经理",
		28: "礼宾员",
		29: "秘书",
		30: "前台职员",
		31: "客房女佣",
		32: "副经理",
		33: "男楼层客房主管",
		34: "接待员",
		35: "门童",
		36: "侍酒师",
		37: "客房服务",
		38: "行李员",
		39: "糕点师",
		40: "市场总监",
		41: "接线员",
		42: "园丁",
		43: "咖啡师",
		44: "冷厨",
		45: "泳池服务员",
		46: "女楼层客房主管",
		47: "电梯员",
		48: "酒店经理"
	},
	staffEffects: {
		1: "每轮一次：获得 1 份果卷。",
		2: "每轮一次：获得 1 份蛋糕。",
		3: "每轮一次：获得 1 份红葡萄酒。",
		4: "每轮一次：获得 1 份咖啡。",
		5: "每完成一位红色宾客的订单，获得 2 克朗。",
		6: "每完成一位蓝色宾客的订单，皇帝轨前进 1 格。",
		7: "每完成一位黄色宾客的订单，获得 1 克朗。",
		8: "每完成一位绿色宾客的订单，获得 2 点胜利点数。",
		9: "准备蓝色客房始终免费。",
		10: "准备红色客房始终免费。",
		11: "准备黄色客房始终免费。",
		12: "每取走点数为 3 或 4 的骰子，获得 2 点胜利点数。",
		13: "每取走点数为 1 或 2 的骰子，行动强度 +1。",
		14: "每取走点数为 1 或 2 的骰子，可按正常费用额外准备 1 间客房。",
		15: "取走点数为 4 的骰子时，每枚骰子给你 1 克朗与皇帝轨 1 格。",
		16: "每取走点数为 4 的骰子，获得 4 点胜利点数。",
		17: "取走点数为 6 的骰子免除 1 克朗费用，且行动强度 +1。",
		18: "每取走点数为 5 的骰子，行动强度 +2。",
		19: "每取走点数为 3 的骰子，获得 5 点胜利点数。",
		20: "每取走点数为 5 的骰子，皇帝轨前进 2 格。",
		21: "立即（仅一次）获得各 1 份果卷、蛋糕、红葡萄酒与咖啡。",
		22: "每取走点数为 3 的骰子，可额外打出 1 张员工卡。",
		23: "每次入住一间客房，获得 1 克朗。",
		24: "从厨房上菜不再支付克朗。",
		25: "从队列迎接宾客不再支付费用。",
		26: "皇帝结算时可支付 1 克朗免除惩罚。",
		27: "终局：每间已入住红色客房得 3 点胜利点数。",
		28: "终局：每间已入住蓝色客房得 3 点胜利点数。",
		29: "终局：复制一位对手展示区中带终局计分标记的一张员工卡的终局效果。不能复制你自己的员工；对手没有这类员工时不得分。",
		30: "终局：每间已入住黄色客房得 3 点胜利点数。",
		31: "终局：每间已入住客房得 1 点胜利点数。",
		32: "终局：每张已打出的员工卡得 2 点胜利点数，包含此卡。",
		33: "每次完成需要 4 份或更多食材的宾客订单，额外获得 4 点胜利点数。",
		34: "终局：酒店中每间客房得 1 点胜利点数，空置或已入住均可。",
		35: "立即（仅一次）把至多 2 间空置客房翻为已入住。",
		36: "立即（仅一次）获得 4 份红葡萄酒。",
		37: "终局：每组全部入住的客房得 2 点胜利点数。",
		38: "立即（仅一次）从供应堆补齐一位宾客的订单。",
		39: "立即（仅一次）获得 4 份蛋糕。",
		40: "终局：每张有你标记的目标卡得 5 点胜利点数。",
		41: "终局：皇帝轨每格得 2 点胜利点数。",
		42: "每次皇帝结算获得奖励时，额外获得 5 点胜利点数。",
		43: "立即（仅一次）获得 4 份咖啡。",
		44: "立即（仅一次）获得 4 份果卷。",
		45: "立即（仅一次）皇帝轨前进 3 格。",
		46: "终局：每层全部入住的楼层得 5 点胜利点数。",
		47: "终局：每列全部入住的列得 5 点胜利点数。",
		48: "终局：每套红、蓝、黄各 1 间已入住客房得 4 点胜利点数。"
	},
	guestNames: {
		49: "雕塑家",
		50: "乐师",
		51: "作曲家",
		52: "裁缝",
		53: "弗拉门戈舞者",
		54: "肖像画家",
		55: "摄影师",
		56: "歌手",
		57: "建筑师",
		58: "女演员",
		59: "诗人",
		60: "珠宝设计师",
		61: "画家",
		62: "歌剧演员",
		63: "贵妇",
		64: "女公爵",
		65: "帝国骑士",
		66: "方伯",
		67: "君主",
		68: "公主",
		69: "女伯爵",
		70: "选帝侯",
		71: "男爵",
		72: "亲王",
		73: "伯爵",
		74: "英式伯爵",
		75: "女男爵",
		76: "公爵",
		77: "药剂师",
		78: "邮政参事",
		79: "枢密参事",
		80: "荣休教授",
		81: "将军",
		82: "高级参事",
		83: "商务参事",
		84: "宫廷参事",
		85: "少校",
		86: "兽医参事",
		87: "医药参事",
		88: "检察官",
		89: "高级专员",
		90: "高级法律秘书",
		91: "特斯卡特利波卡",
		92: "戈尔德哈肯上尉",
		93: "霍尔萨先生",
		94: "英格尔斯先生",
		95: "博伊德尔先生",
		96: "温多先生",
		97: "吉齐亚",
		98: "马可·波罗",
		99: "克拉默索弗勒斯",
		100: "农夫弗朗茨",
		101: "乌韦修士",
		102: "列车长",
		103: "杜尔戈因",
		104: "麦克劳德"
	},
	botGuest: "从队列迎接一位宾客",
	botSkipGuest: "跳过迎接宾客，直接选择主要行动",
	botPass: "本轮暂不行动，等待重新掷骰",
	botDie: "选择第 {{n}} 个行动格",
	botChoose: "完成当前选择",
	botServe: "从厨房上菜",
	botMove: "把宾客送入客房",
	botClaim: "完成一张目标卡",
	botStaff: "使用一张每轮员工卡",
	botEnd: "结束回合",
	errPhase: "当前阶段不能执行这个动作。",
	errPending: "请先完成当前的选择。",
	errTurn: "现在不是你的行动时机。",
	errChoice: "请选择有效的行动。",
	errGuest: "无法迎接这位宾客。",
	errSum: "分配的总数必须等于行动强度。",
	errDishMix: "果卷数量不得少于蛋糕。",
	errDrinkMix: "红葡萄酒数量不得少于咖啡。",
	errTooManyRooms: "准备的客房数量超过了行动强度。",
	errRoom: "这间客房无法使用。",
	errRoomAdjacent: "新客房必须与已有客房相邻。",
	errMoney: "克朗不足。",
	errNoDie: "这个行动格没有骰子。",
	errBoost: "本回合已经提高过强度。",
	errStaff: "这张员工卡无法使用。",
	errOrder: "这位宾客的订单尚未完成。",
	errColor: "客房颜色与宾客不符。",
	errKitchen: "厨房中的食材不足。",
	errServeCount: "一次最多移动 3 份食材或饮品。",
	errServeOver: "放入的食材超过了订单需要。",
	errClaimed: "这张目标卡已经领取过了。",
	errNotMet: "尚未满足这张目标卡的条件。",
	errObjective: "这张目标卡不在本局中。",
	errNoPending: "当前没有待处理的选择。"
}, bt = {
	name: "Grand Austria Hotel",
	desc: "Run a Viennese hotel in the golden age: seat guests, prepare rooms and win the Emperor’s favour",
	rules: [
		"Goal: over seven rounds, move guests from your café into hotel rooms, fulfil their food and drink orders and earn the Emperor’s favour. The player with the most victory points wins.",
		"Setup: each player starts with 10 krones, a hotel board, a money track, an Emperor track and three objective markers. The three rooms at the bottom left are already prepared for free. Your kitchen holds 1 strudel, 1 cake, 1 wine and 1 coffee. Draw 6 staff cards into your hand and seat 1 guest in your café.",
		"For each letter A, B and C, reveal one random objective card and one random Emperor tile in the common area. Shuffle the guest deck and form a queue of 5 guests below the board.",
		"Round flow: the start player rolls all dice (10 for 2 players, 12 for 3, 14 for 4) and places them on the matching action spaces. Each player takes two turns per round, acting in increasing order of the lowest visible number on their turn order tile.",
		"At the start of your turn, you may take 1 guest from the queue or skip this step. Taking a guest costs the amount shown under its queue position (3, 2, 1, 0 and 0 krones) and places the guest at an empty table in your café, which holds at most 3 guests.",
		"Then you must choose an action space with at least 1 die, take 1 die from it and use the number of dice on that space as the action strength. You may pay 1 krone to increase the strength by 1, at most once per turn. The die you take covers the lowest visible number on your turn order tile.",
		"Passing: instead of taking a turn, you may pass. Passing does not forfeit your turn; it only postpones it until the dice are rerolled. Once every other player has also passed or taken both of their turns, take the remaining dice from the action board, remove one die and place it on the dustbin, reroll the rest and distribute them on the action spaces as before, then continue with the player showing the lowest number on their turn order tile. If players keep passing, repeat this until all players have taken both turns or no dice remain to reroll.",
		"Taking Dishes: gain strudel and cake equal to the strength. You must take at least as much strudel as cake.",
		"Taking Drinks: gain wine and coffee equal to the strength. You must take at least as much wine as coffee.",
		"Preparing Rooms: prepare up to a number of rooms equal to the strength. Each new room must be orthogonally adjacent to an existing room, match the colour of its space and pay the floor cost (floor 1 free, floor 2 costs 1 krone, floor 3 costs 2, floor 4 costs 3). Rooms with a victory point symbol score immediately when placed.",
		"Gaining Favour and Money: split the strength between the Emperor track and your money. Past space 13 on the Emperor track, each further step scores 1 victory point instead. Money is capped at 20 krones.",
		"Playing a Staff Card: play 1 staff card from your hand, reducing its cost by the action strength to a minimum of 0. The card stays in your display and its effect resolves immediately.",
		"Imitating a Main Action: pay 1 krone, choose one of the other five main actions and carry it out with the number of dice on the imitation space as its strength. The imitated space does not need any dice left.",
		"When you gain dishes or drinks, the game automatically places them on matching guest orders in your café and puts whatever cannot be placed into your kitchen. You may also use items from your kitchen at any time during your turn.",
		"Additional actions: during your turn you may take any number of the following additional actions in addition to your main action.",
		"· Serving Items: pay 1 krone to move up to 3 dishes or drinks from your kitchen onto one or more guest orders.",
		"· Completing an Objective: if you meet an objective card’s requirement, place a marker on its highest remaining scoring spot and score that many victory points immediately. Each player may claim each objective card only once.",
		"· Using a Staff Card: a staff card in your display with the once-per-round symbol may be used once each round; turn it sideways after use.",
		"· Moving a Guest to a Room: when a guest’s order is complete, move that guest into a vacant room of matching colour and turn the room to its occupied side. Green guests may enter any colour. Score the guest’s victory points and resolve its reward, then return the order items to the supply.",
		"Occupancy bonus: when every room in a group of the same colour is occupied, gain that group’s bonus immediately: blue gives victory points, red gives krones and yellow advances the Emperor track. Each group pays its bonus only once.",
		"Emperor scoring: at the end of rounds 3, 5 and 7, score victory points for your position on the Emperor track (spaces 0 to 13 are worth 0, 1, 1, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8 and 9 points), then retreat 3, 5 and 7 spaces respectively. After retreating, a position of 3 or more gains the reward on the current Emperor tile; 1 or 2 does nothing; 0 suffers the penalty. The Emperor track is not reset by scoring.",
		"Final scoring: after the Emperor scoring of round 7, score staff cards with the final-scoring symbol, then score occupied rooms by floor (1, 2, 3 and 4 victory points per room on floors 1 to 4), then 1 victory point for each item left in your kitchen and each krone left on your money track, and finally lose 5 victory points for each guest still in your café.",
		"Tie-break: if victory points are equal, the player with the higher score from step 3 of final scoring (leftover items and krones) wins.",
		"System note: the game handles Emperor tile rewards and penalties automatically, including which rooms an Emperor reward prepares or occupies and where the dishes and drinks you gain are placed. If a reward asks you to play one of the staff cards you drew, you choose which card to play. At final scoring, the Secretary automatically copies the highest-scoring end-game effect among your opponents’ staff cards, not counting another Secretary; the Porter automatically fills every dish and drink on the order of the unfinished guest worth the most victory points; and when a guest reward or staff effect turns vacant rooms into occupied rooms, the game also selects the rooms. All other choices are made by you."
	].join("\n"),
	roundChip: "Round {{n}}",
	yourTurn: "Your turn",
	waitTurn: "Waiting for {{name}}",
	emperorPhase: "Emperor scoring",
	finalPhase: "Final scoring",
	donePhase: "Game over",
	stageGuest: "Decide whether to take a guest from the queue",
	stageMain: "Choose an action space and take a die",
	stageAfter: "You may serve, move a guest, claim an objective or use staff",
	pickRoom: "Choose a room to prepare",
	pickStaff: "Choose a staff card to play",
	pickGuest: "Choose a guest to take",
	pickItem: "Choose a dish or drink",
	pickSpace: "Choose an action to imitate",
	queue: "Guest queue",
	deckN: "Deck {{n}}",
	actionBoard: "Action board",
	objectives: "Objectives",
	emperorTiles: "Emperor tiles",
	hotel: "Hotel",
	cafe: "Café",
	kitchen: "Kitchen",
	hand: "Hand",
	staffDisplay: "Staff display",
	money: "Krones",
	vp: "Victory points",
	free: "free",
	emperorTrack: "Emperor track",
	pass: "Pass",
	skipGuest: "Skip guest",
	takeGuest: "Take guest",
	endTurn: "End turn",
	serve: "Serve items",
	moveTo: "Move to room",
	claim: "Claim objective",
	useStaff: "Use staff",
	confirm: "Confirm",
	cancel: "Cancel",
	boost: "Pay 1 krone for +1 strength",
	noDice: "No dice",
	emptyRoom: "Empty space",
	vacant: "Vacant",
	occupied: "Occupied",
	remainingTurns: "{{n}} turns left",
	turnNumber: "Order {{n}}",
	items: {
		strudel: "Strudel",
		cake: "Cake",
		wine: "Wine",
		coffee: "Coffee"
	},
	colors: {
		blue: "Nobles",
		red: "Citizens",
		yellow: "Artists",
		green: "Tourists"
	},
	colorShort: {
		blue: "Blue",
		red: "Red",
		yellow: "Yellow",
		green: "Green"
	},
	spaces: {
		1: "Take Dishes",
		2: "Take Drinks",
		3: "Prepare Rooms",
		4: "Favour & Money",
		5: "Play Staff",
		6: "Imitate Action"
	},
	spaceHints: {
		1: "Gain strudel and cake equal to the strength",
		2: "Gain wine and coffee equal to the strength",
		3: "Prepare up to a number of rooms equal to the strength",
		4: "Split the strength between the Emperor track and money",
		5: "Play 1 staff card, reduced by the strength",
		6: "Pay 1 krone to imitate a main action"
	},
	skip: "Skip",
	pendingItem: "Choose a dish or drink",
	pendingPrepare: "Choose a room to prepare, or skip",
	pendingStaff: "Choose a staff card to play, or skip",
	pendingGuest: "Choose a guest to take, or skip",
	pendingImitate: "Choose an action space to imitate",
	objectiveDone: "Claimed",
	objectiveSpots: "{{n}} spots left",
	noObjective: "Requirement not met",
	staffUsed: "Used this round",
	staffRound: "Each round",
	seatOrder: "Turn order",
	log: "Log",
	parenOpen: " (",
	parenClose: ")",
	comma: ", ",
	listSep: ", ",
	rooms: "Rooms",
	playerColors: [
		"Blue",
		"Orange",
		"Purple",
		"Gold"
	],
	continueBtn: "Continue",
	emperorContinueHint: "Once every player has settled, click continue to proceed to the next phase.",
	extraPrepareHint: "You may prepare one more room.",
	extraStaffHint: "You may play one more staff card.",
	brand: "Grand Austria Hotel",
	brandLatin: "GRAND AUSTRIA HOTEL",
	brandMotto: "Vienna · Golden Age",
	yourHotel: "Your hotel",
	railTitle: "Turn order",
	dustbin: "Dustbin",
	emptyTable: "Empty table",
	reservado: "Reservado",
	readyOrder: "Order complete",
	strength: "Strength",
	dice: "Dice",
	myTurnBadge: "Your turn",
	pickCafeHint: "Select a guest in your café, then tap a gold room to move them in.",
	endKicker: "The books close",
	endTitle: "Final ledger",
	endWinner: "{{name}} is the finest host in Vienna",
	endCoWinners: "{{names}} share first place",
	endRank: "Ranking",
	endBreakdown: "Score breakdown",
	endBase: "Running score",
	endStaff: "Staff final effects",
	endRooms: "Occupied rooms",
	endLeftover: "Leftover items and krones",
	endCafe: "Guests left in the café",
	endCafeEach: "−5 each",
	endTotal: "Final score",
	endPoints: "pts",
	endTieNote: "Ties are broken by leftover items and krones.",
	confirmAgain: "Start another game?",
	confirmLobby: "Return to the lobby?",
	emperorSettleTitle: "Emperor scoring for round {{round}} · {{tile}} · retreat {{retreat}} spaces",
	emperorReward: "Reward",
	emperorPenalty: "Penalty",
	emperorNone: "No effect",
	emperorVp: "VP",
	objectiveText: {
		A1: "You have 20 krones.",
		A2: "Your marker is on space 10 or higher of the Emperor track.",
		A3: "You have played at least 6 staff cards.",
		A4: "You have at least 12 room tiles in your hotel, vacant or occupied.",
		B1: "At least 2 floors are fully occupied.",
		B2: "At least 2 columns are fully occupied.",
		B3: "All rooms of at least one colour are occupied.",
		B4: "At least 6 groups of rooms are fully occupied.",
		C1: "At least 3 occupied rooms in each of red, blue and yellow.",
		C2: "At least 4 occupied red rooms and 3 occupied yellow rooms.",
		C3: "At least 4 occupied yellow rooms and 3 occupied blue rooms.",
		C4: "At least 4 occupied blue rooms and 3 occupied red rooms."
	},
	objectiveName: {
		A1: "Wealth",
		A2: "Favour",
		A3: "Retinue",
		A4: "Expansion",
		B1: "Full Floors",
		B2: "Full Columns",
		B3: "Single Colour",
		B4: "Many Groups",
		C1: "Three Colours",
		C2: "Red and Yellow",
		C3: "Yellow and Blue",
		C4: "Blue and Red"
	},
	emperorName: {
		A1: "Bounty",
		A2: "Royal Table",
		A3: "Recommendation",
		A4: "Gifted House",
		B1: "Four Delicacies",
		B2: "Rich Reward",
		B3: "Imperial Choice",
		B4: "Gifted Estate",
		C1: "Glory",
		C2: "Grace of a Home",
		C3: "Merit",
		C4: "Special Favour"
	},
	emperorText: {
		A1: {
			reward: "Gain 3 krones.",
			penalty: "Lose 3 krones; if you have fewer than 3, lose 5 victory points instead."
		},
		A2: {
			reward: "The game automatically gives you 2 dishes or drinks.",
			penalty: "Return all dishes and drinks in your kitchen to the supply."
		},
		A3: {
			reward: "Draw 3 staff cards and immediately play one of them, paying up to 3 krones less.",
			penalty: "Return 2 staff cards from hand; if you have fewer than 2, lose 5 victory points instead."
		},
		A4: {
			reward: "Prepare one room for free.",
			penalty: "Remove one vacant room from as high a floor as possible; if you have none, lose 5 victory points instead."
		},
		B1: {
			reward: "Gain 1 strudel, 1 cake, 1 wine and 1 coffee.",
			penalty: "Return all dishes and drinks from your kitchen and from guest orders in your café to the supply."
		},
		B2: {
			reward: "Gain 5 krones.",
			penalty: "Lose 5 krones; if you have fewer than 5, lose 7 victory points instead."
		},
		B3: {
			reward: "Draw 3 staff cards and immediately play one of them for free.",
			penalty: "Return 3 staff cards from hand; if you have fewer than 3, lose 7 victory points instead."
		},
		B4: {
			reward: "Prepare one room for free and occupy it immediately; it must be on one of the bottom two floors.",
			penalty: "Remove 2 vacant rooms from as high a floor as possible; if you have fewer than 2 vacant rooms, lose 7 victory points instead."
		},
		C1: {
			reward: "Score 8 victory points.",
			penalty: "Lose 8 victory points."
		},
		C2: {
			reward: "Prepare one room for free and occupy it immediately.",
			penalty: "Remove an occupied room from the highest possible floor and, if possible, a second one."
		},
		C3: {
			reward: "Score 2 victory points for each staff card you have played.",
			penalty: "Lose 2 victory points for each staff card you have played."
		},
		C4: {
			reward: "Play one staff card for free.",
			penalty: "Remove one once-per-round staff card from your display; if you have none, lose 10 victory points instead."
		}
	},
	staffNames: {
		1: "Breakfast Server",
		2: "Waitress",
		3: "Barkeeper",
		4: "Sous-Chef",
		5: "Groom",
		6: "Stableman",
		7: "Masseuse",
		8: "Tour Guide",
		9: "Butler",
		10: "Chauffeur",
		11: "Florist",
		12: "Executive Housekeeper",
		13: "Restaurant Manager",
		14: "Decorator",
		15: "Bootblack",
		16: "Laundress",
		17: "Kitchen Hand",
		18: "Checker",
		19: "Interior Architect",
		20: "Detective",
		21: "Chef",
		22: "Staff Manager",
		23: "Custodian",
		24: "Chief Waiter",
		25: "Delivery Boy",
		26: "Conference Manager",
		27: "Booking Manager",
		28: "Concierge",
		29: "Secretary",
		30: "Reception Clerk",
		31: "Chambermaid",
		32: "Assistant Manager",
		33: "Male Floor Housekeeper",
		34: "Receptionist",
		35: "Page Boy",
		36: "Sommelier",
		37: "Room Service",
		38: "Porter",
		39: "Confectioner",
		40: "Marketing Director",
		41: "Operator",
		42: "Gardener",
		43: "Barista",
		44: "Larder Cook",
		45: "Pool Attendant",
		46: "Female Floor Housekeeper",
		47: "Liftboy",
		48: "Hotel Manager"
	},
	staffEffects: {
		1: "Once per round: gain 1 strudel.",
		2: "Once per round: gain 1 cake.",
		3: "Once per round: gain 1 wine.",
		4: "Once per round: gain 1 coffee.",
		5: "Whenever you complete a red guest’s order, gain 2 krones.",
		6: "Whenever you complete a blue guest’s order, advance 1 space on the Emperor track.",
		7: "Whenever you complete a yellow guest’s order, gain 1 krone.",
		8: "Whenever you complete a green guest’s order, score 2 victory points.",
		9: "Preparing blue rooms is always free.",
		10: "Preparing red rooms is always free.",
		11: "Preparing yellow rooms is always free.",
		12: "Whenever you take a die showing 3 or 4, score 2 victory points.",
		13: "Whenever you take a die showing 1 or 2, add 1 to the action strength.",
		14: "Whenever you take a die showing 1 or 2, you may also prepare one room at its normal cost.",
		15: "When you take a die showing 4, each die gives you 1 krone and 1 space on the Emperor track.",
		16: "Whenever you take a die showing 4, score 4 victory points.",
		17: "Taking a die showing 6 costs no krone and adds 1 to the action strength.",
		18: "Whenever you take a die showing 5, add 2 to the action strength.",
		19: "Whenever you take a die showing 3, score 5 victory points.",
		20: "Whenever you take a die showing 5, advance 2 spaces on the Emperor track.",
		21: "Immediately and only once: gain 1 strudel, 1 cake, 1 wine and 1 coffee.",
		22: "Whenever you take a die showing 3, you may also play one staff card.",
		23: "Whenever you occupy a room, gain 1 krone.",
		24: "Serving items from your kitchen is free.",
		25: "Taking guests from the queue is free.",
		26: "During Emperor scoring you may pay 1 krone to ignore the penalty.",
		27: "Final scoring: 3 victory points for each occupied red room.",
		28: "Final scoring: 3 victory points for each occupied blue room.",
		29: "Final scoring: copy the final-scoring effect of one opponent’s staff card that has the final-scoring symbol, applied to your hotel. You cannot copy one of your own staff; if no opponent has such a staff card, score nothing.",
		30: "Final scoring: 3 victory points for each occupied yellow room.",
		31: "Final scoring: 1 victory point for each occupied room.",
		32: "Final scoring: 2 victory points for each staff card you played, including this one.",
		33: "Whenever you complete a guest order requiring 4 or more items, score 4 victory points.",
		34: "Final scoring: 1 victory point for each room tile in your hotel, vacant or occupied.",
		35: "Immediately and only once: occupy up to 2 vacant rooms.",
		36: "Immediately and only once: gain 4 wine.",
		37: "Final scoring: 2 victory points for each fully occupied group of rooms.",
		38: "Immediately and only once: fill one guest’s order from the supply.",
		39: "Immediately and only once: gain 4 cake.",
		40: "Final scoring: 5 victory points for each objective card with your marker on it.",
		41: "Final scoring: 2 victory points for each space on the Emperor track.",
		42: "Whenever you gain a reward during Emperor scoring, also score 5 victory points.",
		43: "Immediately and only once: gain 4 coffee.",
		44: "Immediately and only once: gain 4 strudel.",
		45: "Immediately and only once: advance 3 spaces on the Emperor track.",
		46: "Final scoring: 5 victory points for each fully occupied floor.",
		47: "Final scoring: 5 victory points for each fully occupied column.",
		48: "Final scoring: 4 victory points for each set of one occupied red, blue and yellow room."
	},
	guestNames: {
		49: "Sculptor",
		50: "Musician",
		51: "Composer",
		52: "Tailor",
		53: "Flamenco Dancer",
		54: "Portrait Painter",
		55: "Photographer",
		56: "Vocalist",
		57: "Architect",
		58: "Actress",
		59: "Poet",
		60: "Jewelry Designer",
		61: "Painter",
		62: "Opera Singer",
		63: "Dame",
		64: "Duchess",
		65: "Knight of the Empire",
		66: "Landgrave",
		67: "Sovereign",
		68: "Princess",
		69: "Countess",
		70: "Elector",
		71: "Baron",
		72: "Prince",
		73: "Count",
		74: "Earl",
		75: "Baroness",
		76: "Duke",
		77: "Apothecary",
		78: "Post Councillor",
		79: "Privy Councillor",
		80: "Professor Emeritus",
		81: "General",
		82: "Senior Councillor",
		83: "Councillor of Commerce",
		84: "Court Councillor",
		85: "Major",
		86: "Veterinary Councillor",
		87: "Medicinal Councillor",
		88: "Procurator",
		89: "Lord High Commissioner",
		90: "Senior Legal Secretary",
		91: "Tezcatlipoca",
		92: "Capt. Goldhaken",
		93: "Mr. Horsa",
		94: "M. Ingalls",
		95: "Mr. Boydell",
		96: "Mr. Oundo",
		97: "E. Gizia",
		98: "M. Polo",
		99: "Cramersopholus",
		100: "Farmer Franz",
		101: "Brother Uwe",
		102: "Conductor",
		103: "Durgoing",
		104: "MacLeod"
	},
	botGuest: "Take a guest from the queue",
	botSkipGuest: "Skip taking a guest and choose a main action",
	botPass: "Pass for now and wait for the reroll",
	botDie: "Use action space {{n}}",
	botChoose: "Resolve the current choice",
	botServe: "Serve items from the kitchen",
	botMove: "Move a guest into a room",
	botClaim: "Claim an objective card",
	botStaff: "Use a once-per-round staff card",
	botEnd: "End the turn",
	errPhase: "This action is not available in the current phase.",
	errPending: "Finish the current choice first.",
	errTurn: "It is not your turn.",
	errChoice: "Choose a valid action.",
	errGuest: "That guest cannot be taken.",
	errSum: "The distribution must equal the action strength.",
	errDishMix: "You must take at least as much strudel as cake.",
	errDrinkMix: "You must take at least as much wine as coffee.",
	errTooManyRooms: "You chose more rooms than the action strength.",
	errRoom: "That room cannot be used.",
	errRoomAdjacent: "A new room must be adjacent to an existing room.",
	errMoney: "Not enough krones.",
	errNoDie: "That action space has no dice.",
	errBoost: "You have already boosted this turn.",
	errStaff: "That staff card cannot be used.",
	errOrder: "That guest’s order is not complete.",
	errColor: "The room colour does not match the guest.",
	errKitchen: "Not enough items in the kitchen.",
	errServeCount: "You may move at most 3 items at a time.",
	errServeOver: "That would exceed the order requirement.",
	errClaimed: "That objective has already been claimed by you.",
	errNotMet: "You do not meet that objective’s requirement.",
	errObjective: "That objective is not in this game.",
	errNoPending: "There is no choice to resolve."
}, xt = {
	strudel: "strudel",
	cake: "cake",
	wine: "wine",
	coffee: "coffee"
}, St = {
	blue: "gah-blue",
	red: "gah-red",
	yellow: "gah-yellow",
	green: "gah-green"
}, Ct = {
	1: "strudel",
	2: "wine",
	3: "room",
	4: "emperor",
	5: "staff",
	6: "imitate"
};
function Z({ name: e }) {
	let t = `gah-ic gah-ic-${e}`, n = (e) => /* @__PURE__ */ f("svg", {
		className: t,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		focusable: "false",
		children: e
	});
	switch (e) {
		case "strudel": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("path", {
				d: "M3.4 16.1c1.4-5.2 5.3-8.6 10.4-9.1 3.4-.3 6.4 1.1 6.8 3.4.3 1.9-1.2 3.6-3.6 4.4",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M4.1 16.6c4.6 1.8 11.2 1 15.3-2.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M7.4 13.6c.9-2.1 2.4-3.5 4.4-4.2M10.4 15c.8-1.9 2.1-3.2 3.8-3.9",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".5",
				strokeWidth: "1.1",
				strokeLinecap: "round"
			})
		] }));
		case "cake": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("path", {
				d: "M5.4 20h13.2l-1.7-8.4H7.1z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M7.9 14.4h8.2",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".55",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M9.2 11.6V8.4m5.6 3.2V8.4",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "5.6",
				r: "1.35",
				fill: "currentColor"
			})
		] }));
		case "wine": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("path", {
				d: "M7.8 4.2h8.4l-.9 6.6a3.3 3.3 0 0 1-6.6 0z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 14.1v5.1m-3 0h6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8.9 6.4h6.2",
				stroke: "#fff",
				strokeOpacity: ".45",
				strokeWidth: "1.1"
			})
		] }));
		case "coffee": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("path", {
				d: "M4.8 8.2h10.8v5.4a4.3 4.3 0 0 1-4.3 4.3H9.1a4.3 4.3 0 0 1-4.3-4.3z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M15.6 10h1.7a2.1 2.1 0 0 1 0 4.2h-1.7",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ f("path", {
				d: "M3.4 20.2h13.6",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8 5.2c-.6-.8.6-1.4 0-2.2m3.6 2.2c-.6-.8.6-1.4 0-2.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2",
				strokeLinecap: "round",
				strokeOpacity: ".7"
			})
		] }));
		case "room": return n(/* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
			d: "M4.6 20.4V5.6h9.2v14.8M13.8 10h5.6v10.4M3 20.4h18",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.8",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("circle", {
			cx: "11",
			cy: "13",
			r: "1",
			fill: "currentColor"
		})] }));
		case "staff": return n(/* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "7.2",
			r: "3.1",
			fill: "currentColor"
		}), /* @__PURE__ */ f("path", {
			d: "M4.8 20.2c0-4 3.1-6.4 7.2-6.4s7.2 2.4 7.2 6.4z",
			fill: "currentColor"
		})] }));
		case "imitate": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("rect", {
				x: "4",
				y: "4",
				width: "10.4",
				height: "10.4",
				rx: "1.8",
				fill: "currentColor",
				opacity: ".55"
			}),
			/* @__PURE__ */ f("rect", {
				x: "9.6",
				y: "9.6",
				width: "10.4",
				height: "10.4",
				rx: "1.8",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12.4 14.8h4.8M14.8 12.4v4.8",
				stroke: "#fff",
				strokeOpacity: ".7",
				strokeWidth: "1.2",
				strokeLinecap: "round"
			})
		] }));
		case "money": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("rect", {
				x: "2.6",
				y: "6",
				width: "18.8",
				height: "12",
				rx: "1.6",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("rect", {
				x: "4.3",
				y: "7.7",
				width: "15.4",
				height: "8.6",
				rx: "1",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".5",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "12",
				r: "3",
				fill: "none",
				stroke: "#fff",
				strokeOpacity: ".7",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 9.9v4.2",
				stroke: "#fff",
				strokeOpacity: ".8",
				strokeWidth: "1.1",
				strokeLinecap: "round"
			})
		] }));
		case "vp": return n(/* @__PURE__ */ f("path", {
			d: "M12 3.2l2.5 5.2 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8z",
			fill: "currentColor"
		}));
		case "emperor": return n(/* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("path", {
				d: "M4.2 18.4h15.6l-1.1-9-4 3.8-2.7-5.8-2.7 5.8-4-3.8z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ f("path", {
				d: "M4.2 18.4v2.2h15.6v-2.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.8",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "7",
				r: ".9",
				fill: "#fff",
				fillOpacity: ".65"
			})
		] }));
		case "trash": return n(/* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
			d: "M5 7h14M9.2 7V4.4h5.6V7M7 7l1 13h8l1-13",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ f("path", {
			d: "M10.2 11v5.4m3.6-5.4V16.4",
			stroke: "currentColor",
			strokeWidth: "1.4",
			strokeLinecap: "round"
		})] }));
	}
}
var wt = {
	1: [[50, 50]],
	2: [[32, 32], [68, 68]],
	3: [
		[30, 30],
		[50, 50],
		[70, 70]
	],
	4: [
		[32, 32],
		[68, 32],
		[32, 68],
		[68, 68]
	],
	5: [
		[32, 32],
		[68, 32],
		[50, 50],
		[32, 68],
		[68, 68]
	],
	6: [
		[32, 27],
		[68, 27],
		[32, 50],
		[68, 50],
		[32, 73],
		[68, 73]
	]
};
function Tt({ face: e }) {
	return /* @__PURE__ */ f("svg", {
		className: "gah-die",
		viewBox: "0 0 100 100",
		role: "img",
		"aria-label": String(e),
		children: (wt[e] ?? []).map(([t, n], r) => /* @__PURE__ */ f("circle", {
			cx: t,
			cy: n,
			r: e === 1 ? 14 : 9,
			fill: "currentColor"
		}, r))
	});
}
function Et() {
	return /* @__PURE__ */ f("svg", {
		className: "gah-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ f("rect", {
			x: "1",
			y: "1",
			width: "98",
			height: "98",
			rx: "1.6",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
function Dt() {
	return /* @__PURE__ */ p("svg", {
		className: "gah-crest",
		viewBox: "0 0 48 48",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M24 3.5l16 6.2v13.6c0 9.4-6.4 17.3-16 21.2-9.6-3.9-16-11.8-16-21.2V9.7z",
				fill: "#7c2a3a",
				stroke: "#d8b467",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M24 9.4l10 4v9.7c0 6.5-4 12.2-10 15.2-6-3-10-8.7-10-15.2v-9.7z",
				fill: "none",
				stroke: "#e7cf96",
				strokeWidth: "1.1",
				strokeOpacity: ".75"
			}),
			/* @__PURE__ */ f("path", {
				d: "M18 26.6h12l-.9-5.6-3.4 2.8-1.7-4.2-1.7 4.2-3.4-2.8z",
				fill: "#e7cf96"
			})
		]
	});
}
function Ot({ bag: e }) {
	let t = h.filter((t) => (e[t] ?? 0) > 0);
	return t.length ? /* @__PURE__ */ f("span", {
		className: "gah-bag",
		children: t.map((t) => /* @__PURE__ */ p("span", {
			className: "gah-bag-item",
			children: [/* @__PURE__ */ f(Z, { name: t }), /* @__PURE__ */ f("b", { children: e[t] })]
		}, t))
	}) : /* @__PURE__ */ f("span", {
		className: "gah-bag-empty",
		children: "—"
	});
}
function kt(e, t) {
	let n = (e) => t.items[xt[e]];
	switch (e.t) {
		case "item": return `${n(e.item)}×${e.n}`;
		case "itemAll": return h.map((t) => `${n(t)}×${e.n}`).join(t.listSep);
		case "choiceItem": return `${t.pickItem}×${e.n}`;
		case "money": return `${t.money}+${e.n}`;
		case "emperor": return `${t.emperorTrack}+${e.n}`;
		case "vp": return `${t.vp}+${e.n}`;
		case "vpStaff": return `${t.vp}+${e.per}×${t.staffDisplay}`;
		case "prepare": return `${t.pickRoom}×${e.n}${e.discounts?.some((e) => e >= 99) ? `${t.parenOpen}${t.free}${t.parenClose}` : ""}`;
		case "occupy": return `${t.occupied}×${e.n}`;
		case "staffDraw": return `${t.hand}+${e.n}`;
		case "staffDiscount": return `${t.pickStaff}${t.parenOpen}${e.n >= 99 ? t.free : `-${e.n}`}${t.parenClose}`;
		case "staffDrawPlay": return `${t.pickStaff}${t.parenOpen}${t.hand}+${e.count}${t.comma}${e.discount >= 99 ? t.free : `-${e.discount}`}${t.parenClose}`;
		case "guestFree": return `${t.takeGuest}×${e.n}`;
		case "imitate": return t.pickSpace;
		case "fillOrder": return t.serve;
		default: return "";
	}
}
function At({ guest: e, L: t, selected: n }) {
	let r = T.get(e);
	if (!r) return null;
	let i = r.reward.map((e) => kt(e, t)).filter(Boolean);
	return /* @__PURE__ */ p("div", {
		className: `gah-guest ${St[r.color]}${n ? " is-selected" : ""}`,
		"data-guest": r.id,
		children: [/* @__PURE__ */ p("span", {
			className: "gah-guest-tray",
			children: [
				/* @__PURE__ */ f("span", {
					className: "gah-guest-crest",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ f("b", {
					className: "gah-guest-name",
					children: t.guestNames[r.id]
				}),
				/* @__PURE__ */ p("span", {
					className: `gah-guest-vp${r.vp > 0 ? "" : " is-zero"}`,
					"aria-label": `${t.vp} ${r.vp}`,
					children: [/* @__PURE__ */ f(Z, { name: "vp" }), /* @__PURE__ */ f("b", { children: r.vp })]
				})
			]
		}), /* @__PURE__ */ p("span", {
			className: "gah-guest-cloth",
			children: [/* @__PURE__ */ p("span", {
				className: "gah-guest-slip",
				children: [/* @__PURE__ */ f("i", { children: t.reservado }), /* @__PURE__ */ f(Ot, { bag: r.order })]
			}), i.length > 0 && /* @__PURE__ */ f("span", {
				className: "gah-guest-reward",
				children: i.join(t.listSep)
			})]
		})]
	});
}
function jt({ guest: e, L: t, selected: n, onClick: r, takeable: i }) {
	let a = `gah-guest-wrap${i ? " is-takeable" : ""}`;
	return r ? /* @__PURE__ */ f("button", {
		type: "button",
		className: a,
		onClick: r,
		children: /* @__PURE__ */ f(At, {
			guest: e,
			L: t,
			selected: n
		})
	}) : /* @__PURE__ */ f("div", {
		className: a,
		children: /* @__PURE__ */ f(At, {
			guest: e,
			L: t,
			selected: n
		})
	});
}
function Mt({ card: e, L: t, used: n, usable: r, onClick: i, showEffect: a, inHand: o }) {
	let s = Number(e), c = D.get(Number(e)), l = c?.kind === "round";
	return /* @__PURE__ */ p("button", {
		type: "button",
		className: `gah-staff${n ? " is-used" : ""}${r ? " is-usable" : ""}${o ? " is-hand" : ""}`,
		title: t.staffEffects[s],
		onClick: r && i ? i : void 0,
		disabled: !r,
		children: [
			/* @__PURE__ */ f("span", {
				className: "gah-staff-clip",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ p("span", {
				className: "gah-staff-head",
				children: [/* @__PURE__ */ f("b", {
					className: "gah-staff-name",
					children: t.staffNames[s]
				}), /* @__PURE__ */ p("span", {
					className: "gah-staff-cost",
					"aria-label": `${t.money} ${c?.cost ?? 0}`,
					children: [/* @__PURE__ */ f(Z, { name: "money" }), /* @__PURE__ */ f("b", { children: c?.cost ?? 0 })]
				})]
			}),
			/* @__PURE__ */ f("span", {
				className: "gah-staff-figure",
				"aria-hidden": "true",
				children: /* @__PURE__ */ f(Z, { name: "staff" })
			}),
			a && /* @__PURE__ */ f("span", {
				className: "gah-staff-effect",
				children: t.staffEffects[s]
			}),
			l && /* @__PURE__ */ f("span", {
				className: "gah-staff-badge",
				children: t.staffRound
			}),
			n && /* @__PURE__ */ f("span", {
				className: "gah-staff-used",
				children: t.staffUsed
			})
		]
	});
}
function Nt({ p: e, L: t, legal: n, selected: r, onCell: i }) {
	return /* @__PURE__ */ f("div", {
		className: "gah-building",
		children: [
			4,
			3,
			2,
			1
		].map((a) => /* @__PURE__ */ p("div", {
			className: "gah-storey",
			children: [/* @__PURE__ */ p("span", {
				className: "gah-storey-tab",
				children: [/* @__PURE__ */ f("b", { children: a }), /* @__PURE__ */ p("i", { children: [/* @__PURE__ */ f(Z, { name: "money" }), y[a]] })]
			}), /* @__PURE__ */ f("div", {
				className: "gah-doors",
				children: Array.from({ length: 5 }, (o, s) => {
					let c = (a - 1) * 5 + s, l = b[c], u = e.hotel[c], d = r?.includes(c), m = !!n && n.includes(c), h = m && !!i, g = u === "empty" ? t.emptyRoom : u === "vacant" ? t.vacant : t.occupied;
					return /* @__PURE__ */ p("button", {
						type: "button",
						className: `gah-door ${St[l.color]} is-${u}${d ? " is-selected" : ""}${m ? " is-legal" : ""}`,
						onClick: h ? () => i?.(c) : void 0,
						disabled: !h,
						"aria-pressed": d || void 0,
						"aria-label": `${t.rooms} ${a}-${s + 1} · ${t.colorShort[l.color]} · ${g}`,
						children: [
							/* @__PURE__ */ f("span", {
								className: "gah-door-frame",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ f("span", {
								className: "gah-door-panel",
								"aria-hidden": "true",
								children: /* @__PURE__ */ f("span", {
									className: "gah-door-plate",
									"aria-hidden": "true"
								})
							}),
							u === "occupied" && /* @__PURE__ */ f("span", {
								className: "gah-door-guest",
								"aria-hidden": "true"
							}),
							u !== "empty" && /* @__PURE__ */ f("span", {
								className: "gah-door-knob",
								"aria-hidden": "true"
							}),
							l.vp > 0 && /* @__PURE__ */ p("span", {
								className: "gah-door-vp",
								children: [/* @__PURE__ */ f(Z, { name: "vp" }), /* @__PURE__ */ f("b", { children: l.vp })]
							}),
							m && /* @__PURE__ */ f(Et, {})
						]
					}, c);
				})
			})]
		}, a))
	});
}
function Pt({ p: e, L: t }) {
	let n = [
		15,
		16,
		17,
		18,
		19,
		10,
		11,
		12,
		13,
		14,
		5,
		6,
		7,
		8,
		9,
		0,
		1,
		2,
		3,
		4
	], r = e.hotel.filter((e) => e === "occupied").length, i = e.hotel.filter((e) => e === "vacant").length;
	return /* @__PURE__ */ f("span", {
		className: "gah-mini",
		role: "img",
		"aria-label": `${t.occupied} ${r} · ${t.vacant} ${i}`,
		children: n.map((t) => /* @__PURE__ */ f("i", { className: `${St[b[t].color]} is-${e.hotel[t]}` }, t))
	});
}
function Ft({ p: e, L: t }) {
	return e.markers.length === 0 ? null : /* @__PURE__ */ f("span", {
		className: "gah-seals",
		children: e.markers.map((e) => /* @__PURE__ */ p("span", {
			className: "gah-seal",
			"aria-label": `${e.card} ${t.vp} ${e.vp}`,
			children: [e.card, /* @__PURE__ */ f("b", { children: e.vp })]
		}, e.card))
	});
}
function It({ p: e, member: t, seat: n, active: r, L: i, isMe: a, variant: o, cafePick: s, onCafe: u, legal: d, onRoom: m, selectedRooms: g, onStaffUse: _, hand: v, onHandPick: y }) {
	let b = l[(t?.colorIndex ?? n) % l.length], x = t?.name || i.playerColors[n % 4], S = c[(t?.avatar ?? n) % c.length], C = e.tile[Math.min(e.covered, 1)], w = o === "hero";
	return /* @__PURE__ */ p("section", {
		className: `gah-facade is-${o}${r ? " is-active" : ""}${a ? " is-me" : ""}`,
		style: { "--seat": b.hex },
		children: [
			/* @__PURE__ */ p("header", {
				className: "gah-roof",
				children: [
					/* @__PURE__ */ f("span", {
						className: "gah-roof-stripe",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ p("span", {
						className: "gah-roof-id",
						children: [/* @__PURE__ */ f("span", {
							className: "gah-roof-avatar",
							children: /* @__PURE__ */ f("img", {
								src: S,
								alt: "",
								draggable: !1
							})
						}), /* @__PURE__ */ p("span", {
							className: "gah-roof-name",
							children: [/* @__PURE__ */ f("b", { children: x }), /* @__PURE__ */ p("i", { children: [
								a ? `${i.yourHotel} · ` : "",
								i.turnNumber.replace("{{n}}", String(C)),
								" · ",
								i.remainingTurns.replace("{{n}}", String(2 - e.covered))
							] })]
						})]
					}),
					r && /* @__PURE__ */ f("span", {
						className: "gah-turn-seal",
						children: i.myTurnBadge
					}),
					/* @__PURE__ */ p("span", {
						className: "gah-stats",
						children: [
							/* @__PURE__ */ p("span", {
								className: "gah-stat",
								"aria-label": `${i.money} ${e.money}`,
								children: [/* @__PURE__ */ f("i", { children: /* @__PURE__ */ f(Z, { name: "money" }) }), /* @__PURE__ */ f("b", { children: e.money })]
							}),
							/* @__PURE__ */ p("span", {
								className: "gah-stat",
								"aria-label": `${i.vp} ${e.vp}`,
								children: [/* @__PURE__ */ f("i", { children: /* @__PURE__ */ f(Z, { name: "vp" }) }), /* @__PURE__ */ f("b", { children: e.vp })]
							}),
							/* @__PURE__ */ p("span", {
								className: "gah-stat",
								"aria-label": `${i.emperorTrack} ${e.emperor}`,
								children: [/* @__PURE__ */ f("i", { children: /* @__PURE__ */ f(Z, { name: "emperor" }) }), /* @__PURE__ */ f("b", { children: e.emperor })]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "gah-hotel-body",
				children: [w ? /* @__PURE__ */ f(Nt, {
					p: e,
					L: i,
					legal: d,
					selected: g,
					onCell: m
				}) : /* @__PURE__ */ f(Pt, {
					p: e,
					L: i
				}), w ? /* @__PURE__ */ p("div", {
					className: "gah-grounds",
					children: [/* @__PURE__ */ p("div", {
						className: "gah-cafe",
						children: [/* @__PURE__ */ f("span", {
							className: "gah-kicker",
							children: i.cafe
						}), /* @__PURE__ */ f("div", {
							className: "gah-tables",
							children: [
								0,
								1,
								2
							].map((t) => {
								let n = e.cafe[t];
								if (!n) return /* @__PURE__ */ p("div", {
									className: "gah-table is-empty",
									children: [/* @__PURE__ */ f("span", {
										className: "gah-table-cloth",
										"aria-hidden": "true"
									}), /* @__PURE__ */ p("span", {
										className: "gah-setting",
										"aria-hidden": "true",
										children: [
											/* @__PURE__ */ f("i", { className: "gah-plate" }),
											/* @__PURE__ */ f("i", { className: "gah-fork" }),
											/* @__PURE__ */ f("i", { className: "gah-knife" })
										]
									})]
								}, t);
								let r = T.get(Number(n.guest)), a = Lt(n), o = !!r && a && r.color !== "green";
								return /* @__PURE__ */ p("div", {
									className: `gah-table is-seated${s === t ? " is-selected" : ""}`,
									children: [
										/* @__PURE__ */ f("span", {
											className: "gah-table-cloth",
											"aria-hidden": "true"
										}),
										u && /* @__PURE__ */ f("button", {
											type: "button",
											className: "gah-table-hit",
											onClick: () => u(t),
											"aria-label": `${i.cafe} ${t + 1} · ${i.guestNames[Number(n.guest)]}`
										}),
										/* @__PURE__ */ f(jt, {
											guest: Number(n.guest),
											L: i,
											selected: s === t
										}),
										/* @__PURE__ */ f("span", {
											className: "gah-placed",
											children: /* @__PURE__ */ f(Ot, { bag: n.items })
										}),
										a && /* @__PURE__ */ f("span", {
											className: "gah-ready-stamp",
											children: i.readyOrder
										}),
										u && a && /* @__PURE__ */ f(Et, {}),
										o && /* @__PURE__ */ f("span", {
											className: "gah-table-color",
											"aria-hidden": "true"
										})
									]
								}, t);
							})
						})]
					}), /* @__PURE__ */ p("div", {
						className: "gah-service",
						children: [/* @__PURE__ */ p("div", {
							className: "gah-pantry",
							children: [/* @__PURE__ */ f("span", {
								className: "gah-kicker",
								children: i.kitchen
							}), /* @__PURE__ */ f("div", {
								className: "gah-jars",
								children: h.map((t) => /* @__PURE__ */ p("span", {
									className: `gah-jar${(e.kitchen[t] ?? 0) > 0 ? "" : " is-empty"}`,
									"aria-label": `${i.items[xt[t]]} ${e.kitchen[t] ?? 0}`,
									children: [/* @__PURE__ */ f(Z, { name: t }), /* @__PURE__ */ f("b", { children: e.kitchen[t] ?? 0 })]
								}, t))
							})]
						}), e.markers.length > 0 && /* @__PURE__ */ p("div", {
							className: "gah-goals",
							children: [/* @__PURE__ */ f("span", {
								className: "gah-kicker",
								children: i.objectives
							}), /* @__PURE__ */ f(Ft, {
								p: e,
								L: i
							})]
						})]
					})]
				}) : /* @__PURE__ */ p("div", {
					className: "gah-compact-info",
					children: [
						/* @__PURE__ */ f("span", {
							className: "gah-compact-cafe",
							children: e.cafe.length === 0 ? /* @__PURE__ */ f("span", {
								className: "gah-muted",
								children: "—"
							}) : e.cafe.map((e, t) => /* @__PURE__ */ f("span", {
								className: `gah-cafechip ${St[T.get(Number(e.guest))?.color ?? "green"]}${Lt(e) ? " is-ready" : ""}`,
								children: i.guestNames[Number(e.guest)]
							}, t))
						}),
						/* @__PURE__ */ p("span", {
							className: "gah-compact-staff",
							children: [/* @__PURE__ */ f(Z, { name: "staff" }), /* @__PURE__ */ f("b", { children: e.staff.length })]
						}),
						/* @__PURE__ */ f(Ft, {
							p: e,
							L: i
						})
					]
				})]
			}),
			w && /* @__PURE__ */ p("footer", {
				className: "gah-facade-foot",
				children: [e.staff.length > 0 && /* @__PURE__ */ p("div", {
					className: "gah-staffrow",
					children: [/* @__PURE__ */ f("span", {
						className: "gah-kicker",
						children: i.staffDisplay
					}), /* @__PURE__ */ f("div", {
						className: "gah-drawer scrollbar-none",
						children: e.staff.map((e) => {
							let t = D.get(Number(e.card)), n = a && t?.kind === "round" && !e.used && !!_;
							return /* @__PURE__ */ f(Mt, {
								card: e.card,
								L: i,
								used: e.used,
								usable: n,
								onClick: n ? () => _?.(e.iid) : void 0,
								showEffect: a
							}, e.iid);
						})
					})]
				}), a && v && /* @__PURE__ */ p("div", {
					className: "gah-handrow",
					children: [/* @__PURE__ */ p("span", {
						className: "gah-kicker",
						children: [
							i.hand,
							i.parenOpen,
							v.length,
							i.parenClose
						]
					}), /* @__PURE__ */ f("div", {
						className: "gah-drawer scrollbar-none",
						children: v.map((e) => /* @__PURE__ */ f(Mt, {
							card: e.card,
							L: i,
							usable: !!y,
							onClick: y ? () => y(e.iid) : void 0,
							showEffect: !0,
							inHand: !0
						}, e.iid))
					})]
				})]
			})
		]
	});
}
function Lt(e) {
	let t = T.get(Number(e.guest));
	return t ? h.every((n) => (e.items[n] ?? 0) >= (t.order[n] ?? 0)) : !1;
}
function Rt(e) {
	let t = g();
	for (let n of e.cafe) {
		let e = T.get(Number(n.guest));
		if (e) for (let r of h) t[r] += Math.max(0, (e.order[r] ?? 0) - (n.items[r] ?? 0));
	}
	return t;
}
function zt(e, t) {
	let n = b[t].col;
	return [
		t - 5,
		t + 5,
		n > 0 ? t - 1 : -1,
		n < 4 ? t + 1 : -1
	].some((t) => t >= 0 && t < 20 && e[t] !== "empty");
}
function Bt(e, t) {
	let n = b[t].color;
	return e.staff.some((e) => {
		let t = D.get(Number(e.card));
		return t?.effect.t === "perm" && t.effect.kind === (n === "blue" ? "blueFree" : n === "red" ? "redFree" : "yellowFree");
	}) || b[t].floor === 1 ? 0 : b[t].floor === 2 ? 1 : b[t].floor === 3 ? 2 : 3;
}
function Vt(e, t) {
	let n = 0;
	for (let r of e.staff) {
		let e = D.get(Number(r.card));
		e?.effect.t === "perm" && ((t === 1 || t === 2) && e.effect.kind === "die12Str1" && (n += 1), t === 5 && e.effect.kind === "die5Str2" && (n += 2), t === 6 && e.effect.kind === "die6Str1Free" && (n += 1));
	}
	return n;
}
function Ht(e, t) {
	let n = (t) => b.reduce((n, r, i) => n + +(r.color === t && e.hotel[i] === "occupied"), 0), r = S.filter((t) => t.every((t) => e.hotel[t] === "occupied")).length;
	switch (t) {
		case "money20": return e.money >= 20;
		case "emperor10": return e.emperor >= 10;
		case "staff6": return e.staffPlayed >= 6;
		case "tiles12": return e.hotel.filter((e) => e !== "empty").length >= 12;
		case "floors2": {
			let t = 0;
			for (let n = 0; n < 4; n += 1) [
				0,
				1,
				2,
				3,
				4
			].every((t) => e.hotel[n * 5 + t] === "occupied") && (t += 1);
			return t >= 2;
		}
		case "columns2": {
			let t = 0;
			for (let n = 0; n < 5; n += 1) [
				0,
				1,
				2,
				3
			].every((t) => e.hotel[t * 5 + n] === "occupied") && (t += 1);
			return t >= 2;
		}
		case "colorAll": return [
			"blue",
			"red",
			"yellow"
		].some((t) => b.every((n, r) => n.color !== t || e.hotel[r] === "occupied"));
		case "groups6": return r >= 6;
		case "c3each": return n("red") >= 3 && n("yellow") >= 3 && n("blue") >= 3;
		case "r4y3": return n("red") >= 4 && n("yellow") >= 3;
		case "y4b3": return n("yellow") >= 4 && n("blue") >= 3;
		case "b4r3": return n("blue") >= 4 && n("red") >= 3;
		default: return !1;
	}
}
function Ut(e, t) {
	let n = T.get(Number(t.guest));
	if (!n) return {};
	let r = {}, i = 0;
	for (let a of h) {
		let o = Math.min(e.kitchen[a] ?? 0, Math.max(0, (n.order[a] ?? 0) - (t.items[a] ?? 0))), s = Math.min(o, 3 - i);
		if (s > 0 && (r[a] = s, i += s), i >= 3) break;
	}
	return r;
}
function Wt(e) {
	a();
	let t = e.public, m = e.private ?? {
		hand: [],
		seat: 0
	}, h = i(), _ = r((e) => e.locale) === "zh" ? yt : bt, v = t.players.find((t) => t.rid === e.myRid), y = t.phase === "turns" && t.turn.seat === e.myRid, x = t.pending?.seat === e.myRid, [S, C] = n(null), [w, ee] = n(!1), [E, O] = n([]), [A, j] = n(null), [te, ne] = n(null), [ie, ae] = n(null), [M, oe] = n(null), [N, P] = n(null), F = (t) => e.members.find((e) => e.rid === t), se = (e) => {
		if (!e) return "";
		let n = F(e)?.name;
		if (n) return n;
		let r = t.players.findIndex((t) => t.rid === e);
		return r < 0 ? "" : h(l[r % l.length].nameKey);
	}, I = (t) => e.send(t), L = (e) => (t.dice[e - 1] ?? 0) + +!!w + (v ? Vt(v, e) : 0), ce = v ? Rt(v) : g(), R = Math.max(0, Math.min(ce.cake, Math.floor(L(1) / 2))), z = A === null ? R : Math.min(A, R), B = Math.max(0, Math.min(ce.coffee, Math.floor(L(2) / 2))), V = A === null ? B : Math.min(A, B), H = te === null ? Math.min(L(4), Math.max(0, 10 - (v?.emperor ?? 0))) : Math.min(te, L(4)), U = /* @__PURE__ */ new Map();
	if (v && S === 3) {
		let e = [...v.hotel], t = v.money;
		for (let n of E) e[n] = "vacant", t -= Bt(v, n);
		for (let n = 0; n < 20; n += 1) {
			if (e[n] !== "empty" || !zt(e, n)) continue;
			let r = Bt(v, n);
			r <= t && U.set(n, r);
		}
	}
	let W = [];
	if (v && N !== null) {
		let e = v.cafe[N], t = e ? T.get(Number(e.guest)) : void 0;
		if (e && t && Lt(e)) for (let e = 0; e < 20; e += 1) v.hotel[e] === "vacant" && (t.color === "green" || b[e].color === t.color) && W.push(e);
	}
	let le = [];
	if (v && t.extra?.prepare && N === null) for (let e = 0; e < 20; e += 1) v.hotel[e] === "empty" && zt(v.hotel, e) && Bt(v, e) <= v.money && le.push(e);
	let ue = (e) => {
		if (S === 3 && U.has(e)) {
			O((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < L(3) ? [...t, e] : t);
			return;
		}
		if (t.turn.stage === "after" && N !== null && W.includes(e)) {
			I({
				type: "move",
				guest: N,
				cell: e
			}), P(null);
			return;
		}
		t.turn.stage === "after" && le.includes(e) && I({
			type: "prepareExtra",
			cell: e
		});
	}, de = (e) => {
		if (!v || v.markers.some((t) => t.card === e) || (t.claims[e]?.length ?? 0) >= 3) return !1;
		let n = k.find((t) => t.id === e);
		return !!n && Ht(v, n.kind);
	}, G = t.phase === "done" ? "done" : y || x ? "accent" : "info", K = t.phase === "done" ? h("games.grandaustriahotel.donePhase") : t.phase === "emperor" ? h("games.grandaustriahotel.emperorPhase") : t.phase === "final" ? h("games.grandaustriahotel.finalPhase") : y ? h("games.grandaustriahotel.yourTurn") : t.turn.seat ? h("games.grandaustriahotel.waitTurn", { name: se(t.turn.seat) }) : h("games.grandaustriahotel.emperorPhase"), fe = x ? _.pendingItem : y ? t.turn.stage === "guest" ? h("games.grandaustriahotel.stageGuest") : t.turn.stage === "main" ? h("games.grandaustriahotel.stageMain") : h("games.grandaustriahotel.stageAfter") : "", pe = (e) => e.kind === "item" && e.item ? _.items[e.item] : e.kind === "cell" ? `${_.vacant} ${e.cost ?? 0}` : e.kind === "staff" && e.card ? _.staffNames[Number(e.card)] : e.kind === "queue" && e.card ? _.guestNames[Number(e.card)] : e.kind === "space" && e.space ? _.spaces[e.space] : e.kind === "skip" ? _.skip : e.id, q = () => {
		if (!S) return;
		let e = {
			type: "die",
			space: S,
			boost: w
		};
		if (S === 1) I({
			...e,
			dishes: {
				strudel: L(1) - z,
				cake: z
			}
		});
		else if (S === 2) I({
			...e,
			drinks: {
				wine: L(2) - V,
				coffee: V
			}
		});
		else if (S === 3) I({
			...e,
			rooms: E
		});
		else if (S === 4) I({
			...e,
			favor: {
				emperor: H,
				money: L(4) - H
			}
		});
		else if (S === 5) I({
			...e,
			staffIid: ie ?? J
		});
		else if (S === 6) {
			let t = M ?? 2, n = L(6), r = Rt(v);
			I(t === 1 ? {
				...e,
				imitateSpace: 1,
				dishes: {
					strudel: n - Math.min(r.cake, Math.floor(n / 2)),
					cake: Math.min(r.cake, Math.floor(n / 2))
				}
			} : t === 2 ? {
				...e,
				imitateSpace: 2,
				drinks: {
					wine: n - Math.min(r.coffee, Math.floor(n / 2)),
					coffee: Math.min(r.coffee, Math.floor(n / 2))
				}
			} : t === 3 ? {
				...e,
				imitateSpace: 3,
				rooms: Gt(v, n)
			} : t === 4 ? {
				...e,
				imitateSpace: 4,
				favor: {
					emperor: n,
					money: 0
				}
			} : {
				...e,
				imitateSpace: 5,
				staffIid: ie ?? J
			});
		}
		C(null);
	}, me = m.hand ?? [], J = (() => {
		let e = L(S === 6 ? 6 : 5);
		return [...me].sort((e, t) => (D.get(Number(e.card))?.cost ?? 0) - (D.get(Number(t.card))?.cost ?? 0)).find((t) => Math.max(0, (D.get(Number(t.card))?.cost ?? 99) - e) <= (v?.money ?? 0))?.iid ?? "";
	})(), he = t.pending ? t.pending.kind === "item" ? _.pendingItem : t.pending.kind === "prepare" ? _.pendingPrepare : t.pending.kind === "staff" ? _.pendingStaff : t.pending.kind === "guestFree" ? _.pendingGuest : _.pendingImitate : "", ge = (() => {
		if (!v || N === null) return !1;
		let e = v.cafe[N];
		return !!e && Lt(e) && Object.keys(Ut(v, e)).length > 0;
	})(), Y = !!v && v.cafe.some((e) => Lt(e)), _e = t.pending && x ? /* @__PURE__ */ p("div", {
		className: "gah-desk",
		children: [/* @__PURE__ */ f("div", {
			className: "gah-desk-line",
			children: /* @__PURE__ */ f("span", {
				className: "gah-desk-title",
				children: he
			})
		}), /* @__PURE__ */ f("div", {
			className: "gah-desk-line is-params",
			children: t.pending.options.map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				className: "gah-btn",
				disabled: e.disabled,
				onClick: () => I({
					type: "choose",
					id: e.id
				}),
				children: pe(e)
			}, e.id))
		})]
	}) : t.phase === "emperor" ? /* @__PURE__ */ f("div", {
		className: "gah-desk",
		children: /* @__PURE__ */ p("div", {
			className: "gah-desk-line",
			children: [
				/* @__PURE__ */ f("span", {
					className: "gah-desk-title",
					children: h("games.grandaustriahotel.emperorPhase")
				}),
				/* @__PURE__ */ f("span", {
					className: "gah-desk-hint",
					children: _.emperorContinueHint
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn is-primary",
					onClick: () => I({ type: "continue" }),
					children: _.continueBtn
				})
			]
		})
	}) : t.phase === "turns" ? y ? t.turn.stage === "guest" ? /* @__PURE__ */ f("div", {
		className: "gah-desk",
		children: /* @__PURE__ */ p("div", {
			className: "gah-desk-line",
			children: [
				/* @__PURE__ */ f("span", {
					className: "gah-desk-title",
					children: h("games.grandaustriahotel.stageGuest")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn",
					onClick: () => I({ type: "skipGuest" }),
					children: h("games.grandaustriahotel.skipGuest")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn",
					onClick: () => I({ type: "pass" }),
					children: h("games.grandaustriahotel.pass")
				})
			]
		})
	}) : t.turn.stage === "main" ? /* @__PURE__ */ p("div", {
		className: "gah-desk",
		children: [/* @__PURE__ */ f("div", {
			className: "gah-desk-line",
			children: S === null ? /* @__PURE__ */ f("span", {
				className: "gah-desk-title",
				children: h("games.grandaustriahotel.stageMain")
			}) : /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("span", {
					className: "gah-desk-title",
					children: [_.spaces[S], /* @__PURE__ */ p("em", { children: [
						_.strength,
						" ",
						L(S)
					] })]
				}),
				/* @__PURE__ */ p("label", {
					className: "gah-boost",
					children: [/* @__PURE__ */ f("input", {
						type: "checkbox",
						checked: w,
						onChange: (e) => ee(e.target.checked)
					}), h("games.grandaustriahotel.boost")]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn is-primary",
					onClick: q,
					disabled: S === 3 && E.length === 0 || S === 5 && !(ie ?? J),
					children: h("games.grandaustriahotel.confirm")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn is-ghost",
					onClick: () => C(null),
					children: h("games.grandaustriahotel.cancel")
				})
			] })
		}), S !== null && /* @__PURE__ */ p("div", {
			className: "gah-desk-line is-params",
			children: [
				S === 1 && /* @__PURE__ */ p("label", {
					className: "gah-range",
					children: [
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "strudel" }), L(1) - z] }),
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "cake" }), z] }),
						/* @__PURE__ */ f("input", {
							type: "range",
							min: 0,
							max: R,
							value: z,
							onChange: (e) => j(Number(e.target.value))
						})
					]
				}),
				S === 2 && /* @__PURE__ */ p("label", {
					className: "gah-range",
					children: [
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "wine" }), L(2) - V] }),
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "coffee" }), V] }),
						/* @__PURE__ */ f("input", {
							type: "range",
							min: 0,
							max: B,
							value: V,
							onChange: (e) => j(Number(e.target.value))
						})
					]
				}),
				S === 3 && /* @__PURE__ */ p("span", {
					className: "gah-desk-hint",
					children: [
						_.pickRoom,
						_.parenOpen,
						E.length,
						"/",
						L(3),
						_.parenClose
					]
				}),
				S === 4 && /* @__PURE__ */ p("label", {
					className: "gah-range",
					children: [
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "emperor" }), H] }),
						/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { name: "money" }), L(4) - H] }),
						/* @__PURE__ */ f("input", {
							type: "range",
							min: 0,
							max: L(4),
							value: H,
							onChange: (e) => ne(Number(e.target.value))
						})
					]
				}),
				S === 5 && me.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: `gah-btn is-small${(ie ?? J) === e.iid ? " is-selected" : ""}`,
					onClick: () => ae(e.iid),
					children: [
						_.staffNames[Number(e.card)],
						" · ",
						Math.max(0, (D.get(Number(e.card))?.cost ?? 0) - L(5))
					]
				}, e.iid)),
				S === 6 && [
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: `gah-btn is-small${(M ?? 2) === e ? " is-selected" : ""}`,
					onClick: () => oe(e),
					children: [
						/* @__PURE__ */ f(Z, { name: Ct[e] }),
						" ",
						_.spaces[e]
					]
				}, e))
			]
		})]
	}) : /* @__PURE__ */ p("div", {
		className: "gah-desk",
		children: [/* @__PURE__ */ p("div", {
			className: "gah-desk-line",
			children: [
				/* @__PURE__ */ f("span", {
					className: "gah-desk-title",
					children: h("games.grandaustriahotel.stageAfter")
				}),
				N !== null && v && /* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn",
					disabled: !ge,
					onClick: () => {
						let e = Ut(v, v.cafe[N]);
						Object.keys(e).length && I({
							type: "serve",
							guest: N,
							items: e
						});
					},
					children: h("games.grandaustriahotel.serve")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "gah-btn is-primary",
					onClick: () => I({ type: "endTurn" }),
					children: h("games.grandaustriahotel.endTurn")
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "gah-desk-line is-params",
			children: [
				t.extra.prepare && /* @__PURE__ */ f("span", {
					className: "gah-desk-hint is-warn",
					children: _.extraPrepareHint
				}),
				t.extra.staff && /* @__PURE__ */ f("span", {
					className: "gah-desk-hint is-warn",
					children: _.extraStaffHint
				}),
				Y && /* @__PURE__ */ f("span", {
					className: "gah-desk-hint",
					children: _.pickCafeHint
				})
			]
		})]
	}) : /* @__PURE__ */ f("div", {
		className: "gah-desk",
		children: /* @__PURE__ */ f("div", {
			className: "gah-desk-line",
			children: /* @__PURE__ */ f("span", {
				className: "gah-desk-title",
				children: h("games.grandaustriahotel.waitTurn", { name: se(t.turn.seat ?? "") })
			})
		})
	}) : /* @__PURE__ */ f("div", {
		className: "gah-desk",
		children: /* @__PURE__ */ f("div", {
			className: "gah-desk-line",
			children: /* @__PURE__ */ f("span", {
				className: "gah-desk-hint",
				children: K
			})
		})
	}), ve = (e) => re[e] ?? 0, ye = y && t.turn.stage === "guest" && (v?.cafe.length ?? 3) < 3, be = [
		"A",
		"B",
		"C"
	].map((e) => t.objectives[e]), xe = [
		"A",
		"B",
		"C"
	].map((e) => t.emperor[e]), Se = (e) => {
		let n = t.players.find((t) => t.rid === e);
		return n ? n.tile[Math.min(n.covered, 1)] : 99;
	}, Ce = [...e.members].filter((e) => t.players.some((t) => t.rid === e.rid)).sort((e, n) => Se(e.rid) - Se(n.rid) || t.players.findIndex((t) => t.rid === e.rid) - t.players.findIndex((e) => e.rid === n.rid)), we = [...t.players].sort((n, r) => n.rid === e.myRid ? -1 : r.rid === e.myRid ? 1 : t.players.indexOf(n) - t.players.indexOf(r)), Te = v ? y && t.turn.stage === "main" && S === 3 ? [...U.keys()] : y && t.turn.stage === "after" ? N === null ? le : W : void 0 : void 0;
	return s(G === "accent", o), /* @__PURE__ */ f(u, {
		className: "gah-screen",
		banner: /* @__PURE__ */ p("div", {
			className: `gah-marquee is-${G}`,
			role: "status",
			children: [
				/* @__PURE__ */ f(Dt, {}),
				/* @__PURE__ */ p("div", {
					className: "gah-marquee-brand",
					children: [/* @__PURE__ */ f("strong", { children: _.brandLatin }), /* @__PURE__ */ p("span", { children: [
						_.brand,
						" · ",
						_.brandMotto
					] })]
				}),
				/* @__PURE__ */ p("div", {
					className: "gah-marquee-turn tile-enter",
					children: [/* @__PURE__ */ f("b", { children: K }), fe && /* @__PURE__ */ f("span", { children: fe })]
				}, K),
				/* @__PURE__ */ f("span", {
					className: "gah-round-plaque",
					children: h("games.grandaustriahotel.roundChip", { n: t.round })
				})
			]
		}),
		overlay: t.phase === "emperor" && t.emperorReport ? /* @__PURE__ */ f("div", {
			className: "gah-settle-float pointer-events-auto",
			children: /* @__PURE__ */ p("section", {
				className: "gah-settle",
				"aria-live": "polite",
				children: [/* @__PURE__ */ p("header", {
					className: "gah-settle-head",
					children: [/* @__PURE__ */ f("span", {
						className: "gah-kicker",
						children: _.emperorPhase
					}), /* @__PURE__ */ f("h3", { children: _.emperorSettleTitle.replace("{{round}}", String(t.emperorReport.round)).replace("{{tile}}", _.emperorName[t.emperorReport.tile] ?? t.emperorReport.tile).replace("{{retreat}}", String(t.emperorReport.retreat)) })]
				}), /* @__PURE__ */ f("div", {
					className: "gah-settle-rows",
					children: t.emperorReport.entries.map((e) => {
						let n = F(e.rid), r = n?.colorIndex ?? Math.max(0, t.players.findIndex((t) => t.rid === e.rid)), i = [
							[_.money, e.money],
							[_.kitchen, e.kitchen],
							[_.hand, e.hand],
							[_.staffDisplay, e.staff],
							[_.rooms, e.rooms]
						];
						return /* @__PURE__ */ p("div", {
							className: `gah-settle-row is-${e.outcome}`,
							style: { "--seat": l[r % l.length].hex },
							children: [
								/* @__PURE__ */ p("span", {
									className: "gah-settle-player",
									children: [/* @__PURE__ */ f("img", {
										src: c[(n?.avatar ?? r) % c.length],
										alt: "",
										draggable: !1
									}), /* @__PURE__ */ f("b", { children: se(e.rid) })]
								}),
								/* @__PURE__ */ f("span", {
									className: "gah-settle-outcome",
									children: e.outcome === "reward" ? _.emperorReward : e.outcome === "penalty" ? _.emperorPenalty : _.emperorNone
								}),
								/* @__PURE__ */ p("span", {
									className: "gah-settle-track",
									children: [
										_.emperorTrack,
										" ",
										e.emperorFrom,
										"→",
										e.emperorTo
									]
								}),
								/* @__PURE__ */ p("span", {
									className: "gah-settle-vp",
									children: [
										_.emperorVp,
										" ",
										e.vp > 0 ? `+${e.vp}` : e.vp
									]
								}),
								/* @__PURE__ */ f("span", {
									className: "gah-settle-deltas",
									children: i.filter(([, e]) => e !== 0).map(([e, t]) => /* @__PURE__ */ p("i", { children: [
										e,
										" ",
										t > 0 ? `+${t}` : t
									] }, e))
								})
							]
						}, e.rid);
					})
				})]
			})
		}) : void 0,
		actions: _e,
		actionsHeight: "h-24",
		children: /* @__PURE__ */ p("div", {
			className: "gah-root",
			children: [/* @__PURE__ */ p("div", {
				className: "gah-main",
				children: [/* @__PURE__ */ p("section", {
					className: "gah-public",
					children: [/* @__PURE__ */ p("div", {
						className: "gah-garden",
						children: [
							/* @__PURE__ */ p("div", {
								className: "gah-panel gah-panel-clouds",
								children: [/* @__PURE__ */ f("h3", {
									className: "gah-panel-title",
									children: h("games.grandaustriahotel.objectives")
								}), /* @__PURE__ */ f("div", {
									className: "gah-clouds scrollbar-none",
									children: be.map((e) => {
										let n = t.claims[e] ?? [], r = v?.markers.some((t) => t.card === e), i = y && t.turn.stage === "after" && de(e);
										return /* @__PURE__ */ p("button", {
											type: "button",
											className: `gah-objective${i ? " is-claimable" : ""}${r ? " is-done" : ""}`,
											disabled: !i,
											onClick: () => I({
												type: "claim",
												card: e
											}),
											children: [
												/* @__PURE__ */ f("span", {
													className: "gah-objective-letter",
													"aria-hidden": "true",
													children: e.slice(0, 1)
												}),
												/* @__PURE__ */ f("span", {
													className: "gah-objective-name",
													children: _.objectiveName[e] ?? e
												}),
												/* @__PURE__ */ f("span", {
													className: "gah-objective-text",
													children: _.objectiveText[e] ?? ""
												}),
												/* @__PURE__ */ f("span", {
													className: "gah-objective-seals",
													children: [
														15,
														10,
														5
													].map((e, t) => /* @__PURE__ */ f("i", {
														className: n.length > t ? "is-taken" : "",
														children: e
													}, e))
												}),
												i && /* @__PURE__ */ f("span", {
													className: "gah-stamp",
													children: h("games.grandaustriahotel.claim")
												}),
												r && /* @__PURE__ */ f("span", {
													className: "gah-stamp is-done",
													children: h("games.grandaustriahotel.objectiveDone")
												})
											]
										}, e);
									})
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "gah-panel gah-panel-imperial",
								children: [/* @__PURE__ */ f("h3", {
									className: "gah-panel-title is-dark",
									children: h("games.grandaustriahotel.emperorTiles")
								}), /* @__PURE__ */ f("div", {
									className: "gah-decrees scrollbar-none",
									children: xe.map((e) => {
										let t = _.emperorText[e];
										return /* @__PURE__ */ p("div", {
											className: "gah-decree",
											children: [
												/* @__PURE__ */ p("span", {
													className: "gah-decree-head",
													children: [
														/* @__PURE__ */ f("i", {
															className: "gah-decree-crown",
															"aria-hidden": "true",
															children: /* @__PURE__ */ f(Z, { name: "emperor" })
														}),
														/* @__PURE__ */ f("b", { children: _.emperorName[e] ?? e }),
														/* @__PURE__ */ f("i", {
															className: "gah-decree-letter",
															children: e
														})
													]
												}),
												/* @__PURE__ */ f("span", {
													className: "gah-decree-good",
													children: t?.reward ?? ""
												}),
												/* @__PURE__ */ f("span", {
													className: "gah-decree-bad",
													children: t?.penalty ?? ""
												})
											]
										}, e);
									})
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "gah-panel gah-panel-banquet",
								children: [/* @__PURE__ */ p("h3", {
									className: "gah-panel-title",
									children: [/* @__PURE__ */ f("small", { children: h("games.grandaustriahotel.deckN", { n: t.guestDeckCount }) }), h("games.grandaustriahotel.queue")]
								}), /* @__PURE__ */ f("div", {
									className: "gah-queue scrollbar-none",
									children: t.queue.map((e, t) => {
										let n = ve(t), r = ye && (v?.money ?? 0) >= n;
										return /* @__PURE__ */ p("div", {
											className: `gah-queue-table${r ? " is-open" : ""}`,
											children: [/* @__PURE__ */ f(jt, {
												guest: Number(e),
												L: _,
												takeable: r,
												onClick: r ? () => I({
													type: "guest",
													index: t
												}) : void 0
											}), /* @__PURE__ */ p("span", {
												className: "gah-ribbon",
												"aria-label": `${_.money} ${n}`,
												children: [/* @__PURE__ */ f(Z, { name: "money" }), /* @__PURE__ */ f("b", { children: n })]
											})]
										}, `${e}-${t}`);
									})
								})]
							})
						]
					}), /* @__PURE__ */ p("section", {
						className: "gah-terrace",
						children: [/* @__PURE__ */ p("div", {
							className: "gah-rail",
							children: [/* @__PURE__ */ p("div", {
								className: "gah-rail-head",
								children: [/* @__PURE__ */ f("span", {
									className: "gah-kicker",
									children: _.railTitle
								}), /* @__PURE__ */ p("span", {
									className: "gah-dust",
									"aria-label": `${_.dustbin} ${t.dustbin}`,
									children: [/* @__PURE__ */ f(Z, { name: "trash" }), /* @__PURE__ */ f("b", { children: t.dustbin })]
								})]
							}), /* @__PURE__ */ f("ol", {
								className: "gah-seats scrollbar-none",
								children: Ce.map((n) => {
									let r = t.players.find((e) => e.rid === n.rid);
									if (!r) return null;
									let i = t.players.indexOf(r), a = l[(n.colorIndex ?? i) % l.length], o = t.phase === "turns" && t.turn.seat === n.rid, s = r.covered >= 2, u = Math.max(0, 2 - r.covered);
									return /* @__PURE__ */ p("li", {
										className: `gah-seat${o ? " is-active" : ""}${s ? " is-done" : ""}${n.rid === e.myRid ? " is-me" : ""}`,
										style: { "--seat": a.hex },
										"aria-label": `${n.name || h(a.nameKey)} · ${_.turnNumber.replace("{{n}}", String(r.tile[Math.min(r.covered, 1)]))} · ${_.remainingTurns.replace("{{n}}", String(u))}`,
										children: [
											/* @__PURE__ */ f("span", {
												className: "gah-seat-order",
												children: r.tile[Math.min(r.covered, 1)]
											}),
											/* @__PURE__ */ f("img", {
												className: "gah-seat-avatar",
												src: c[(n.avatar ?? i) % c.length],
												alt: "",
												draggable: !1
											}),
											/* @__PURE__ */ p("span", {
												className: "gah-seat-id",
												children: [/* @__PURE__ */ f("b", { children: n.name || h(a.nameKey) }), /* @__PURE__ */ f("i", {
													className: "gah-seat-dots",
													"aria-hidden": "true",
													children: [0, 1].map((e) => /* @__PURE__ */ f("em", { className: e < u ? "is-on" : "" }, e))
												})]
											})
										]
									}, n.rid);
								})
							})]
						}), /* @__PURE__ */ f("div", {
							className: "gah-spaces",
							children: [
								1,
								2,
								3,
								4,
								5,
								6
							].map((e) => {
								let n = t.dice[e - 1] ?? 0, r = y && t.turn.stage === "main" && n > 0, i = v ? Vt(v, e) : 0;
								return /* @__PURE__ */ p("button", {
									type: "button",
									className: `gah-space${r ? " is-pickable" : ""}${S === e ? " is-selected" : ""}${n === 0 ? " is-empty" : ""}`,
									disabled: !r,
									onClick: () => {
										C(e), j(null), ne(null), ae(null), oe(null), O([]);
									},
									children: [
										/* @__PURE__ */ f("span", {
											className: "gah-space-flag",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ f("span", {
											className: "gah-space-medal",
											children: /* @__PURE__ */ f(Z, { name: Ct[e] })
										}),
										/* @__PURE__ */ p("span", {
											className: "gah-space-body",
											children: [/* @__PURE__ */ f("b", { children: _.spaces[e] }), /* @__PURE__ */ f("small", { children: n > 0 ? _.spaceHints[e] : h("games.grandaustriahotel.noDice") })]
										}),
										/* @__PURE__ */ p("span", {
											className: "gah-space-dice",
											"aria-label": `${_.dice} ${n}`,
											children: [n > 0 ? Array.from({ length: n }, (t, n) => /* @__PURE__ */ f(Tt, { face: e }, n)) : /* @__PURE__ */ f("span", {
												className: "gah-space-nodice",
												"aria-hidden": "true",
												children: "0"
											}), i > 0 && /* @__PURE__ */ p("em", {
												className: "gah-space-bonus",
												children: ["+", i]
											})]
										}),
										r && /* @__PURE__ */ f(Et, {})
									]
								}, e);
							})
						})]
					})]
				}), /* @__PURE__ */ f("div", {
					className: "gah-mine",
					children: we.filter((t) => t.rid === e.myRid).map((e) => /* @__PURE__ */ f(It, {
						p: e,
						member: F(e.rid),
						seat: t.players.indexOf(e),
						active: t.turn.seat === e.rid,
						L: _,
						isMe: !0,
						variant: "hero",
						cafePick: N,
						onCafe: y && t.turn.stage === "after" ? (e) => P(e) : void 0,
						legal: Te,
						onRoom: ue,
						selectedRooms: E,
						onStaffUse: y && t.turn.stage === "after" ? (e) => I({
							type: "staff",
							iid: e
						}) : void 0,
						hand: me,
						onHandPick: y && (t.turn.stage === "main" && S === 5 || t.turn.stage === "after" && t.extra.staff) ? (e) => {
							t.turn.stage === "after" ? I({
								type: "staffPlay",
								iid: e
							}) : ae(e);
						} : void 0
					}, e.rid))
				})]
			}), /* @__PURE__ */ f("div", {
				className: "gah-others",
				children: we.filter((t) => t.rid !== e.myRid).map((e) => /* @__PURE__ */ f(It, {
					p: e,
					member: F(e.rid),
					seat: t.players.indexOf(e),
					active: t.turn.seat === e.rid,
					L: _,
					isMe: !1,
					variant: "compact"
				}, e.rid))
			})]
		})
	});
}
function Gt(e, t) {
	let n = [];
	for (let t = 0; t < 20; t += 1) e.hotel[t] === "empty" && zt(e.hotel, t) && n.push({
		cell: t,
		cost: Bt(e, t)
	});
	n.sort((e, t) => e.cost - t.cost || e.cell - t.cell);
	let r = e.money, i = [];
	for (let e of n) {
		if (i.length >= t) break;
		e.cost > r || (r -= e.cost, i.push(e.cell));
	}
	return i;
}
//#endregion
//#region src/game/bot.ts
function Q(e, t) {
	return e.staff.some((e) => {
		let n = D.get(Number(e.card));
		return n?.effect.t === "perm" && n.effect.kind === t;
	});
}
function Kt(e, t, n) {
	let r = e.dice[n - 1] ?? 0;
	return (n === 1 || n === 2) && Q(t, "die12Str1") && (r += 1), n === 5 && Q(t, "die5Str2") && (r += 2), n === 6 && Q(t, "die6Str1Free") && (r += 1), r;
}
function qt(e, t) {
	let n = b[t].col;
	return [
		t - 5,
		t + 5,
		n > 0 ? t - 1 : -1,
		n < 4 ? t + 1 : -1
	].some((t) => t >= 0 && t < 20 && e[t] !== "empty");
}
function Jt(e, t) {
	return Q(e, t === "blue" ? "blueFree" : t === "red" ? "redFree" : "yellowFree");
}
function Yt(e, t) {
	let n = b[t].color;
	return Jt(e, n) || b[t].floor === 1 ? 0 : b[t].floor === 2 ? 1 : b[t].floor === 3 ? 2 : 3;
}
function Xt(e, t) {
	let n = [];
	for (let t = 0; t < 20; t += 1) e.hotel[t] === "empty" && qt(e.hotel, t) && n.push({
		cell: t,
		cost: Yt(e, t)
	});
	n.sort((e, t) => e.cost - t.cost || e.cell - t.cell);
	let r = e.money, i = [];
	for (let e of n) {
		if (i.length >= t) break;
		e.cost > r || (r -= e.cost, i.push(e.cell));
	}
	return i;
}
function Zt(e) {
	let t = g();
	for (let n of e.cafe) {
		let e = T.get(Number(n.guest));
		if (e) for (let r of h) t[r] += Math.max(0, (e.order[r] ?? 0) - (n.items[r] ?? 0));
	}
	return t;
}
function Qt(e) {
	let t = T.get(Number(e.guest));
	return t ? h.every((n) => (e.items[n] ?? 0) >= (t.order[n] ?? 0)) : !1;
}
function $t(e, t) {
	let n = T.get(t);
	if (!n) return null;
	for (let t = 0; t < 20; t += 1) if (e.hotel[t] === "vacant" && (n.color === "green" || b[t].color === n.color)) return t;
	return null;
}
function $(e, t) {
	return b.reduce((n, r, i) => n + +(r.color === t && e.hotel[i] === "occupied"), 0);
}
function en(e) {
	return S.filter((t) => t.every((t) => e.hotel[t] === "occupied")).length;
}
function tn(e, t) {
	switch (t) {
		case "money20": return e.money >= 20;
		case "emperor10": return e.emperor >= 10;
		case "staff6": return e.staffPlayed >= 6;
		case "tiles12": return e.hotel.filter((e) => e !== "empty").length >= 12;
		case "floors2": {
			let t = 0;
			for (let n = 0; n < 4; n += 1) [
				0,
				1,
				2,
				3,
				4
			].every((t) => e.hotel[n * 5 + t] === "occupied") && (t += 1);
			return t >= 2;
		}
		case "columns2": {
			let t = 0;
			for (let n = 0; n < 5; n += 1) [
				0,
				1,
				2,
				3
			].every((t) => e.hotel[t * 5 + n] === "occupied") && (t += 1);
			return t >= 2;
		}
		case "colorAll": return [
			"blue",
			"red",
			"yellow"
		].some((t) => b.every((n, r) => n.color !== t || e.hotel[r] === "occupied"));
		case "groups6": return en(e) >= 6;
		case "c3each": return $(e, "red") >= 3 && $(e, "yellow") >= 3 && $(e, "blue") >= 3;
		case "r4y3": return $(e, "red") >= 4 && $(e, "yellow") >= 3;
		case "y4b3": return $(e, "yellow") >= 4 && $(e, "blue") >= 3;
		case "b4r3": return $(e, "blue") >= 4 && $(e, "red") >= 3;
		default: return !1;
	}
}
function nn(e, t) {
	let n = e.pending;
	if (!n) return null;
	let r = n.options.filter((e) => !e.disabled);
	if (!r.length) return null;
	if (n.kind === "item") {
		let e = Zt(t);
		return [...r].sort((t, n) => (e[n.item ?? "strudel"] ?? 0) - (e[t.item ?? "strudel"] ?? 0))[0]?.id ?? null;
	}
	if (n.kind === "prepare") {
		let e = r.filter((e) => e.kind === "cell").sort((e, t) => (e.cost ?? 0) - (t.cost ?? 0));
		return e.length && (e[0].cost ?? 0) === 0 || e.length && t.hotel.filter((e) => e !== "empty").length < 12 ? e[0].id : r.find((e) => e.kind === "skip")?.id ?? r[0].id;
	}
	return n.kind === "staff" || n.kind === "staffDrawPlay" ? r.filter((e) => e.kind === "staff").sort((e, t) => (e.cost ?? 0) - (t.cost ?? 0))[0]?.id ?? r.find((e) => e.kind === "skip")?.id ?? r[0].id : n.kind === "guestFree" ? r.filter((e) => e.kind === "queue").sort((e, t) => {
		let n = T.get(Number(e.card))?.vp ?? 0;
		return (T.get(Number(t.card))?.vp ?? 0) - n;
	})[0]?.id ?? r.find((e) => e.kind === "skip")?.id ?? r[0].id : r.filter((e) => e.kind === "space").sort((t, n) => (e.dice[(n.space ?? 1) - 1] ?? 0) - (e.dice[(t.space ?? 1) - 1] ?? 0))[0]?.id ?? null;
}
function rn(e, t) {
	if (t.cafe.length >= 3) return { type: "skipGuest" };
	let n = Q(t, "queueFree"), r = -1, i = -Infinity;
	return e.queue.forEach((e, a) => {
		let o = T.get(Number(e));
		if (!o) return;
		let s = n ? 0 : re[a] ?? 0;
		if (t.money < s) return;
		let c = b.some((e, n) => o.color === "green" || e.color === o.color && t.hotel[n] !== "empty"), l = o.vp * 2 + (c ? 4 : 0) - s;
		l > i && (i = l, r = a);
	}), r < 0 ? { type: "skipGuest" } : {
		type: "guest",
		index: r
	};
}
function an(e, t, n) {
	let r = Zt(n), i = [];
	for (let a = 1; a <= 6; a += 1) {
		if ((e.dice[a - 1] ?? 0) <= 0) continue;
		let o = Kt(e, n, a), s;
		s = a === 1 ? (r.strudel + r.cake) * 2 + 1 : a === 2 ? (r.wine + r.coffee) * 2 + 1 : a === 3 ? Xt(n, o).length ? n.hotel.filter((e) => e !== "empty").length < 12 ? 7 : 2 : -99 : a === 4 ? n.emperor < 10 ? 6 : 3 : a === 5 ? (t?.hand ?? []).reduce((e, t) => Math.min(e, Math.max(0, (D.get(Number(t.card))?.cost ?? 99) - o)), 99) <= n.money ? 8 : -99 : n.money >= 1 ? 4 : -99, i.push({
			space: a,
			score: s
		});
	}
	i.sort((e, t) => t.score - e.score);
	let a = i[0]?.space ?? 1, o = Kt(e, n, a);
	if (a === 1) {
		let e = Math.min(r.cake, Math.floor(o / 2));
		return {
			type: "die",
			space: 1,
			boost: !1,
			dishes: {
				strudel: o - e,
				cake: e
			}
		};
	}
	if (a === 2) {
		let e = Math.min(r.coffee, Math.floor(o / 2));
		return {
			type: "die",
			space: 2,
			boost: !1,
			drinks: {
				wine: o - e,
				coffee: e
			}
		};
	}
	if (a === 3) {
		let e = Xt(n, o);
		if (e.length) return {
			type: "die",
			space: 3,
			boost: !1,
			rooms: e
		};
	}
	if (a === 4) {
		let e = Math.min(o, Math.max(0, 10 - n.emperor));
		return {
			type: "die",
			space: 4,
			boost: !1,
			favor: {
				emperor: e,
				money: o - e
			}
		};
	}
	if (a === 5) {
		let e = [...t?.hand ?? []].sort((e, t) => (D.get(Number(e.card))?.cost ?? 0) - (D.get(Number(t.card))?.cost ?? 0)).find((e) => Math.max(0, (D.get(Number(e.card))?.cost ?? 99) - o) <= n.money);
		if (e) return {
			type: "die",
			space: 5,
			boost: !1,
			staffIid: e.iid
		};
	}
	if (a === 6 && n.money >= 1) {
		if ((r.wine + r.coffee >= r.strudel + r.cake ? 2 : 1) == 2) {
			let e = Math.min(r.coffee, Math.floor(o / 2));
			return {
				type: "die",
				space: 6,
				boost: !1,
				imitateSpace: 2,
				drinks: {
					wine: o - e,
					coffee: e
				}
			};
		}
		let e = Math.min(r.cake, Math.floor(o / 2));
		return {
			type: "die",
			space: 6,
			boost: !1,
			imitateSpace: 1,
			dishes: {
				strudel: o - e,
				cake: e
			}
		};
	}
	for (let t of [1, 2]) {
		if ((e.dice[t - 1] ?? 0) <= 0) continue;
		let i = Kt(e, n, t);
		if (t === 1) {
			let e = Math.min(r.cake, Math.floor(i / 2));
			return {
				type: "die",
				space: 1,
				boost: !1,
				dishes: {
					strudel: i - e,
					cake: e
				}
			};
		}
		let a = Math.min(r.coffee, Math.floor(i / 2));
		return {
			type: "die",
			space: 2,
			boost: !1,
			drinks: {
				wine: i - a,
				coffee: a
			}
		};
	}
	return {
		type: "die",
		space: a,
		boost: !1
	};
}
function on(e, t) {
	let n = t.cafe.map((e, n) => ({
		index: n,
		cell: $t(t, Number(e.guest)),
		vp: T.get(Number(e.guest))?.vp ?? 0,
		complete: Qt(e)
	})).filter((e) => e.complete && e.cell !== null).sort((e, t) => t.vp - e.vp);
	if (n.length) return {
		type: "move",
		guest: n[0].index,
		cell: n[0].cell
	};
	for (let n of [
		e.objectives.A,
		e.objectives.B,
		e.objectives.C
	]) {
		if (t.markers.some((e) => e.card === n)) continue;
		let r = k.find((e) => e.id === n);
		if (r && !((e.claims[n]?.length ?? 0) >= 3) && tn(t, r.kind)) return {
			type: "claim",
			card: n
		};
	}
	let r = +!Q(t, "serveFree");
	if (t.money >= r) for (let e of t.cafe) {
		let n = T.get(Number(e.guest));
		if (!n) continue;
		let r = {}, i = 0;
		for (let a of h) {
			let o = Math.min(t.kitchen[a] ?? 0, Math.max(0, (n.order[a] ?? 0) - (e.items[a] ?? 0))), s = Math.min(o, 3 - i);
			if (s > 0 && (r[a] = s, i += s), i >= 3) break;
		}
		if (i > 0) return {
			type: "serve",
			guest: t.cafe.indexOf(e),
			items: r
		};
	}
	let i = t.staff.find((e) => !e.used && D.get(Number(e.card))?.kind === "round");
	return i ? {
		type: "staff",
		iid: i.iid
	} : { type: "endTurn" };
}
var sn = ({ public: e, private: t }, n) => {
	let r = e.players.find((e) => e.rid === n.rid);
	if (e.phase === "emperor") {
		if (e.pending) {
			if (e.pending.seat !== n.rid || !r) return null;
			let t = nn(e, r);
			return t ? { action: {
				type: "choose",
				id: t
			} } : null;
		}
		return { action: { type: "continue" } };
	}
	if (e.phase !== "turns" || !r) return null;
	if (e.pending) {
		if (e.pending.seat !== n.rid) return null;
		let t = nn(e, r);
		return t ? { action: {
			type: "choose",
			id: t
		} } : null;
	}
	return e.turn.seat === n.rid ? e.turn.stage === "guest" ? { action: rn(e, r) } : e.turn.stage === "main" ? { action: an(e, t, r) } : { action: on(e, r) } : null;
}, cn = {
	blue: "gah-blue",
	red: "gah-red",
	yellow: "gah-yellow",
	green: "gah-green"
}, ln = [
	15,
	16,
	17,
	18,
	19,
	10,
	11,
	12,
	13,
	14,
	5,
	6,
	7,
	8,
	9,
	0,
	1,
	2,
	3,
	4
];
function un({ hotel: e, label: t }) {
	let n = e.filter((e) => e === "occupied").length;
	return /* @__PURE__ */ p("div", {
		className: "gah-ledger-hotel",
		children: [/* @__PURE__ */ p("div", {
			className: "gah-ledger-hotel-head",
			children: [/* @__PURE__ */ f("span", { children: t }), /* @__PURE__ */ p("b", { children: [n, /* @__PURE__ */ p("small", { children: ["/", e.length] })] })]
		}), /* @__PURE__ */ f("div", {
			className: "gah-ledger-hotel-grid",
			"aria-hidden": "true",
			children: ln.map((t) => /* @__PURE__ */ f("i", { className: `${cn[b[t].color]} is-${e[t]}` }, t))
		})]
	});
}
function dn() {
	return /* @__PURE__ */ p("svg", {
		className: "gah-over-wreath",
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M32 58c-13 0-22-10-22-24 0-8 3-15 8-20",
				fill: "none",
				stroke: "#cba650",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M32 58c13 0 22-10 22-24 0-8-3-15-8-20",
				fill: "none",
				stroke: "#cba650",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			[
				0,
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("ellipse", {
				cx: 13 + e * 3.4,
				cy: 44 - e * 6.4,
				rx: "3.4",
				ry: "1.9",
				transform: `rotate(${-50 + e * 6} ${13 + e * 3.4} ${44 - e * 6.4})`,
				fill: "#9a7325"
			}), /* @__PURE__ */ f("ellipse", {
				cx: 51 - e * 3.4,
				cy: 44 - e * 6.4,
				rx: "3.4",
				ry: "1.9",
				transform: `rotate(${50 - e * 6} ${51 - e * 3.4} ${44 - e * 6.4})`,
				fill: "#cba650"
			})] }, e)),
			/* @__PURE__ */ f("path", {
				d: "M27 21h10l-1.4 9a3.6 3.6 0 0 1-7.2 0z",
				fill: "#cba650"
			}),
			/* @__PURE__ */ f("path", {
				d: "M32 33v6m-4 0h8",
				fill: "none",
				stroke: "#cba650",
				strokeWidth: "2",
				strokeLinecap: "round"
			})
		]
	});
}
function fn({ result: e, public: t, members: n, myRid: a, onPlayAgain: o, onBackToLobby: s }) {
	let d = t, h = i(), g = r((e) => e.locale) === "zh" ? yt : bt, _ = d.final, v = _?.ranking ?? d.players.map((e) => e.rid), y = new Map(n.map((e) => [e.rid, e])), b = (e) => {
		let t = y.get(e), n = t?.colorIndex ?? Math.max(0, d.players.findIndex((t) => t.rid === e));
		return t?.name || h(l[n % l.length].nameKey);
	}, x = e.winner.map(b).join(g.listSep), S = e.winner.length > 1 ? g.endCoWinners.replace("{{names}}", x) : g.endWinner.replace("{{name}}", x), C = (e) => _?.scores[e] ?? d.players.find((t) => t.rid === e)?.vp ?? 0, w = (e) => 1 + v.filter((t) => C(t) > C(e)).length;
	return /* @__PURE__ */ f(u, {
		className: "gah-screen gah-over-screen",
		actionsHeight: "h-16",
		actions: /* @__PURE__ */ p("div", {
			className: "gah-over-actions",
			children: [
				o && /* @__PURE__ */ f(m, {
					compact: !0,
					label: h("session.result.playAgain"),
					confirmLabel: g.confirmAgain,
					onConfirm: o
				}),
				s && /* @__PURE__ */ f(m, {
					compact: !0,
					label: h("session.result.backToLobby"),
					confirmLabel: g.confirmLobby,
					onConfirm: s
				}),
				!o && !s && /* @__PURE__ */ f("span", {
					className: "gah-over-wait",
					children: h("session.result.waitHost")
				})
			]
		}),
		banner: /* @__PURE__ */ p("div", {
			className: "gah-marquee is-done",
			children: [
				/* @__PURE__ */ f(dn, {}),
				/* @__PURE__ */ p("div", {
					className: "gah-marquee-brand",
					children: [/* @__PURE__ */ f("strong", { children: g.brandLatin }), /* @__PURE__ */ p("span", { children: [
						g.brand,
						" · ",
						g.endKicker
					] })]
				}),
				/* @__PURE__ */ p("div", {
					className: "gah-marquee-turn",
					children: [/* @__PURE__ */ f("b", { children: g.endTitle }), /* @__PURE__ */ f("span", { children: S })]
				})
			]
		}),
		children: /* @__PURE__ */ p("div", {
			className: "gah-over-main",
			children: [/* @__PURE__ */ f("div", {
				className: `gah-over-grid players-${Math.max(1, Math.min(v.length, 4))}`,
				children: v.map((t) => {
					let n = d.players.find((e) => e.rid === t), r = y.get(t), i = r?.colorIndex ?? Math.max(0, v.indexOf(t)), o = l[i % l.length], s = e.winner.includes(t), u = w(t), m = n?.markers.length ?? 0, x = _?.breakdown[t];
					return /* @__PURE__ */ p("article", {
						className: `gah-ledger${s ? " is-winner" : ""}${t === a ? " is-me" : ""}`,
						style: { "--seat": o.hex },
						children: [
							/* @__PURE__ */ p("header", {
								className: "gah-ledger-head",
								children: [
									/* @__PURE__ */ f("span", {
										className: "gah-ledger-rank",
										"aria-label": `${g.endRank} ${u}`,
										children: u
									}),
									/* @__PURE__ */ f("img", {
										className: "gah-ledger-avatar",
										src: c[(r?.avatar ?? i) % c.length],
										alt: "",
										draggable: !1
									}),
									/* @__PURE__ */ p("div", {
										className: "gah-ledger-id",
										children: [/* @__PURE__ */ f("b", { children: b(t) }), /* @__PURE__ */ p("span", { children: [h(o.nameKey), m > 0 ? `${g.comma}${g.objectives} ${g.parenOpen}${m}${g.parenClose}` : ""] })]
									}),
									/* @__PURE__ */ p("div", {
										className: "gah-ledger-total",
										children: [/* @__PURE__ */ f("b", { children: C(t) }), /* @__PURE__ */ f("span", { children: g.endPoints })]
									})
								]
							}),
							n && /* @__PURE__ */ f(un, {
								hotel: n.hotel,
								label: g.rooms
							}),
							x ? /* @__PURE__ */ p("dl", {
								className: "gah-ledger-lines",
								children: [
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: g.endBase }), /* @__PURE__ */ f("dd", { children: x.base })] }),
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: g.endStaff }), /* @__PURE__ */ p("dd", { children: ["+", x.staff] })] }),
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: g.endRooms }), /* @__PURE__ */ p("dd", { children: ["+", x.rooms] })] }),
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: g.endLeftover }), /* @__PURE__ */ p("dd", { children: ["+", x.leftover] })] }),
									/* @__PURE__ */ p("div", {
										className: "is-minus",
										children: [/* @__PURE__ */ p("dt", { children: [g.endCafe, /* @__PURE__ */ f("small", { children: g.endCafeEach })] }), /* @__PURE__ */ p("dd", { children: ["−", x.cafe] })]
									})
								]
							}) : /* @__PURE__ */ p("p", {
								className: "gah-muted",
								children: [g.endBreakdown, " —"]
							}),
							/* @__PURE__ */ p("footer", {
								className: "gah-ledger-foot",
								children: [/* @__PURE__ */ f("span", { children: g.endTotal }), /* @__PURE__ */ f("b", { children: x?.total ?? C(t) })]
							})
						]
					}, t);
				})
			}), /* @__PURE__ */ f("p", {
				className: "gah-over-note",
				children: g.endTieNote
			})]
		})
	});
}
//#endregion
//#region src/index.tsx
var pn = {
	definition: vt,
	View: Wt,
	bot: sn,
	OverView: fn,
	locales: {
		zh: yt,
		en: bt
	}
};
//#endregion
export { pn as default };
