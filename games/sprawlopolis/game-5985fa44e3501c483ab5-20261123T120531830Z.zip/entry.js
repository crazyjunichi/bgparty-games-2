import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconRecenter as c, IconRotate as l } from "@bgparty/sdk/icons";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var v = [
	{
		id: 1,
		zones: [
			"I",
			"R",
			"P",
			"C"
		],
		roads: [{
			cells: [0],
			from: "W",
			to: "N"
		}, {
			cells: [1, 3],
			from: "N",
			to: "S"
		}]
	},
	{
		id: 2,
		zones: [
			"P",
			"I",
			"R",
			"C"
		],
		roads: [{
			cells: [
				2,
				3,
				1
			],
			from: "W",
			to: "N"
		}]
	},
	{
		id: 3,
		zones: [
			"C",
			"R",
			"I",
			"P"
		],
		roads: [{
			cells: [0, 1],
			from: "W",
			to: "E"
		}, {
			cells: [2],
			from: "W",
			to: "S"
		}]
	},
	{
		id: 4,
		zones: [
			"P",
			"C",
			"I",
			"R"
		],
		roads: [{
			cells: [2, 3],
			from: "W",
			to: "E"
		}, {
			cells: [1],
			from: "N",
			to: "E"
		}]
	},
	{
		id: 5,
		zones: [
			"R",
			"I",
			"C",
			"P"
		],
		roads: [{
			cells: [
				1,
				0,
				2
			],
			from: "E",
			to: "S"
		}]
	},
	{
		id: 6,
		zones: [
			"C",
			"R",
			"I",
			"P"
		],
		roads: [{
			cells: [0, 2],
			from: "N",
			to: "S"
		}, {
			cells: [1],
			from: "N",
			to: "E"
		}]
	},
	{
		id: 7,
		zones: [
			"C",
			"P",
			"R",
			"I"
		],
		roads: [{
			cells: [
				0,
				2,
				3
			],
			from: "N",
			to: "E"
		}]
	},
	{
		id: 8,
		zones: [
			"R",
			"C",
			"P",
			"I"
		],
		roads: [{
			cells: [
				0,
				1,
				3
			],
			from: "W",
			to: "S"
		}]
	},
	{
		id: 9,
		zones: [
			"I",
			"R",
			"P",
			"C"
		],
		roads: [{
			cells: [0, 1],
			from: "W",
			to: "E"
		}, {
			cells: [3],
			from: "S",
			to: "E"
		}]
	},
	{
		id: 10,
		zones: [
			"P",
			"R",
			"C",
			"I"
		],
		roads: [{
			cells: [
				1,
				3,
				2
			],
			from: "N",
			to: "W"
		}]
	},
	{
		id: 11,
		zones: [
			"I",
			"P",
			"C",
			"R"
		],
		roads: [{
			cells: [0],
			from: "N",
			to: "W"
		}, {
			cells: [2, 3],
			from: "W",
			to: "E"
		}]
	},
	{
		id: 12,
		zones: [
			"R",
			"C",
			"P",
			"I"
		],
		roads: [{
			cells: [0],
			from: "W",
			to: "N"
		}, {
			cells: [1, 3],
			from: "N",
			to: "S"
		}]
	},
	{
		id: 13,
		zones: [
			"C",
			"I",
			"P",
			"R"
		],
		roads: [{
			cells: [
				0,
				1,
				3
			],
			from: "W",
			to: "S"
		}]
	},
	{
		id: 14,
		zones: [
			"C",
			"I",
			"P",
			"R"
		],
		roads: [{
			cells: [0],
			from: "W",
			to: "N"
		}, {
			cells: [1, 3],
			from: "N",
			to: "S"
		}]
	},
	{
		id: 15,
		zones: [
			"R",
			"I",
			"C",
			"P"
		],
		roads: [{
			cells: [0, 2],
			from: "N",
			to: "S"
		}, {
			cells: [1],
			from: "N",
			to: "E"
		}]
	},
	{
		id: 16,
		zones: [
			"C",
			"I",
			"P",
			"R"
		],
		roads: [{
			cells: [0, 1],
			from: "W",
			to: "E"
		}, {
			cells: [3],
			from: "E",
			to: "S"
		}]
	},
	{
		id: 17,
		zones: [
			"I",
			"C",
			"R",
			"P"
		],
		roads: [{
			cells: [0, 2],
			from: "N",
			to: "S"
		}, {
			cells: [1],
			from: "N",
			to: "E"
		}]
	},
	{
		id: 18,
		zones: [
			"I",
			"C",
			"R",
			"P"
		],
		roads: [{
			cells: [0, 1],
			from: "W",
			to: "E"
		}, {
			cells: [2],
			from: "W",
			to: "S"
		}]
	}
], y = new Map(v.map((e) => [e.id, e])), b = v.map((e) => e.id), x = {
	R: "#e0a35c",
	C: "#3f97bd",
	I: "#98a1a8",
	P: "#6fb84c"
}, S = {
	N: [0, -1],
	E: [1, 0],
	S: [0, 1],
	W: [-1, 0]
}, C = {
	N: "S",
	S: "N",
	E: "W",
	W: "E"
}, w = [
	[0, 0],
	[1, 0],
	[0, 1],
	[1, 1]
], T = (e, t) => `${e},${t}`, E = (e, t) => t ? 3 - e : e;
function D(e) {
	let t = y.get(e.id);
	return {
		card: e,
		def: t,
		blocks: w.map((n, r) => {
			let i = E(r, e.rot);
			return {
				p: r,
				bx: e.x + n[0],
				by: e.y + n[1],
				zone: t.zones[i]
			};
		}),
		roads: t.roads.map((t) => {
			let n = t.cells.map((t) => {
				let n = E(t, e.rot);
				return {
					bx: e.x + w[n][0],
					by: e.y + w[n][1]
				};
			});
			return {
				cells: n,
				ports: [{
					...n[0],
					dir: e.rot ? C[t.from] : t.from
				}, {
					...n[n.length - 1],
					dir: e.rot ? C[t.to] : t.to
				}]
			};
		})
	};
}
function O(e, t, n) {
	return `${e * 2 + (n === "E" ? 2 : n === "W" ? 0 : 1)},${t * 2 + (n === "S" ? 2 : n === "N" ? 0 : 1)}`;
}
function k(e, t, n) {
	return n === "N" ? [e + .5, t] : n === "S" ? [e + .5, t + 1] : n === "W" ? [e, t + .5] : [e + 1, t + .5];
}
function A(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of D(n).blocks) t.add(T(e.bx, e.by));
	return t;
}
function j(e, t, n) {
	if (e.length === 0) return !0;
	let r = A(e), i = !1, a = !1;
	for (let e of w) {
		let o = t + e[0], s = n + e[1];
		if (r.has(T(o, s))) {
			i = !0;
			continue;
		}
		for (let e of [
			"N",
			"E",
			"S",
			"W"
		]) {
			let [t, n] = S[e];
			if (r.has(T(o + t, s + n))) {
				a = !0;
				break;
			}
		}
	}
	return i || a;
}
function M(e) {
	if (e.length === 0) return [{
		x: 0,
		y: 0
	}];
	let t = /* @__PURE__ */ new Set(), n = [], r = (r, i) => {
		let a = T(r, i);
		t.has(a) || (t.add(a), j(e, r, i) && n.push({
			x: r,
			y: i
		}));
	};
	for (let t of e) for (let e of D(t).blocks) {
		for (let t of w) r(e.bx - t[0], e.by - t[1]);
		for (let t of [
			"N",
			"E",
			"S",
			"W"
		]) {
			let [n, i] = S[t];
			for (let t of w) r(e.bx + n - t[0], e.by + i - t[1]);
		}
	}
	return n;
}
function ee(e) {
	let t = /* @__PURE__ */ new Map(), n = e.map((e) => D(e));
	n.forEach((e, n) => {
		for (let r of e.blocks) {
			let e = T(r.bx, r.by);
			t.set(e, {
				key: e,
				bx: r.bx,
				by: r.by,
				zone: r.zone,
				owner: n
			});
		}
	});
	let r = /* @__PURE__ */ new Map(), i = (e, n) => {
		let i = T(e, n), a = r.get(i);
		return a || (a = {
			key: i,
			bx: e,
			by: n,
			zone: t.get(i).zone,
			links: /* @__PURE__ */ new Set(),
			open: []
		}, r.set(i, a)), a;
	}, a = (e, t) => {
		r.get(e).links.add(t), r.get(t).links.add(e);
	}, o = /* @__PURE__ */ new Map();
	n.forEach((e, n) => {
		for (let r of e.roads) {
			let e = r.cells.map((e) => {
				let r = T(e.bx, e.by);
				return t.get(r)?.owner === n ? (i(e.bx, e.by), r) : null;
			});
			for (let t = 0; t + 1 < e.length; t += 1) {
				let n = e[t], r = e[t + 1];
				n && r && a(n, r);
			}
			let s = (e, t) => {
				if (!t) return;
				let n = O(e.bx, e.by, e.dir);
				o.has(n) || o.set(n, []), o.get(n).push({
					cell: t,
					dir: e.dir,
					matched: !1
				});
			};
			s(r.ports[0], e[0] ?? null), s(r.ports[1], e[e.length - 1] ?? null);
		}
	});
	for (let e of o.values()) {
		if (e.length !== 2) continue;
		let [t, n] = e;
		t.cell !== n.cell && t.dir === C[n.dir] && (t.matched = !0, n.matched = !0, a(t.cell, n.cell));
	}
	for (let e of o.values()) for (let n of e) {
		if (n.matched) continue;
		let e = r.get(n.cell), [i, a] = S[n.dir];
		e.open.push({
			dir: n.dir,
			atEdge: !t.has(T(e.bx + i, e.by + a))
		});
	}
	let s = /* @__PURE__ */ new Map(), c = (e) => {
		let t = e;
		for (; s.get(t) !== t;) t = s.get(t);
		for (; s.get(e) !== t;) {
			let n = s.get(e);
			s.set(e, t), e = n;
		}
		return t;
	};
	for (let e of r.keys()) s.set(e, e);
	for (let e of r.values()) for (let t of e.links) {
		let n = c(e.key), r = c(t);
		n !== r && s.set(n, r);
	}
	let l = /* @__PURE__ */ new Map();
	for (let e of r.values()) {
		let t = c(e.key), n = l.get(t);
		n || (n = {
			cells: [],
			atEdge: !1,
			zones: /* @__PURE__ */ new Set()
		}, l.set(t, n)), n.cells.push(e.key), n.zones.add(e.zone), e.open.some((e) => e.atEdge) && (n.atEdge = !0);
	}
	return {
		cells: t,
		roads: r,
		components: [...l.values()]
	};
}
function N(e, t) {
	for (let n of [
		"N",
		"E",
		"S",
		"W"
	]) {
		let [r, i] = S[n];
		if (!e.cells.has(T(t.bx + r, t.by + i))) return !0;
	}
	return !1;
}
function P(e, t) {
	let n = (n) => {
		let [r, i] = S[n];
		return !e.cells.has(T(t.bx + r, t.by + i));
	}, r = n("N"), i = n("S"), a = n("W"), o = n("E");
	return r && a || r && o || i && a || i && o;
}
function F(e, t) {
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e.cells.values()) {
		if (i.zone !== t || n.has(i.key)) continue;
		let a = [i];
		n.add(i.key);
		let o = [];
		for (; a.length;) {
			let r = a.pop();
			o.push(r);
			for (let i of [
				"N",
				"E",
				"S",
				"W"
			]) {
				let [o, s] = S[i], c = T(r.bx + o, r.by + s), l = e.cells.get(c);
				l && l.zone === t && !n.has(c) && (n.add(c), a.push(l));
			}
		}
		r.push(o);
	}
	return r;
}
function I(e) {
	let t = Infinity, n = -Infinity, r = Infinity, i = -Infinity;
	for (let a of e.cells.values()) t = Math.min(t, a.bx), n = Math.max(n, a.bx), r = Math.min(r, a.by), i = Math.max(i, a.by);
	return Number.isFinite(t) ? {
		minX: t,
		maxX: n,
		minY: r,
		maxY: i
	} : {
		minX: 0,
		maxX: 0,
		minY: 0,
		maxY: 0
	};
}
//#endregion
//#region src/game/meta.ts
var L = {
	id: "sprawlopolis",
	uuid: "be4644da-ce52-45d3-83b1-009aff76ab7c",
	tier: "alpha",
	mechanics: ["tile-placement"],
	interactionTags: ["cooperative"],
	nameKey: "games.sprawlopolis.name",
	descKey: "games.sprawlopolis.desc",
	rulesKey: "games.sprawlopolis.rules",
	icon: "🏙️",
	iconImg: "games/sprawlopolis.webp",
	minPlayers: 1,
	maxPlayers: 4,
	accent: "#b45309",
	releasedAt: "2026-11-23T11:53:55+08:00",
	search: {
		py: "wu xian du shi",
		init: "wxds"
	},
	hotseat: "cover"
};
t.enum([
	"R",
	"C",
	"I",
	"P"
]);
var R = t.enum([
	"easy",
	"normal",
	"hard"
]), z = t.object({
	id: t.int().min(1).max(18),
	x: t.int().min(-64).max(64),
	y: t.int().min(-64).max(64),
	rot: t.union([t.literal(0), t.literal(180)])
}), B = t.object({
	type: t.literal("place"),
	card: t.int().min(1).max(18),
	x: t.int().min(-64).max(64),
	y: t.int().min(-64).max(64),
	rot: t.union([t.literal(0), t.literal(180)])
}), V = t.object({ difficulty: R.catch("normal") }).default({ difficulty: "normal" }), H = t.string(), te = t.object({
	phase: t.enum(["play", "done"]),
	difficulty: R,
	goals: t.array(t.int().min(1).max(18)).length(3),
	target: t.int().positive(),
	turn: t.object({
		idx: t.int().nonnegative(),
		rid: H
	}).nullable(),
	players: t.array(t.object({
		rid: H,
		handCount: t.int().nonnegative()
	})),
	cards: t.array(z),
	deckCount: t.int().nonnegative(),
	deckTop: t.int().min(1).max(18).nullable(),
	score: t.object({
		total: t.int(),
		target: t.int(),
		win: t.boolean(),
		groups: t.object({
			R: t.int().nonnegative(),
			C: t.int().nonnegative(),
			I: t.int().nonnegative(),
			P: t.int().nonnegative()
		}),
		blockScore: t.int(),
		roadCount: t.int().nonnegative(),
		roadPenalty: t.int(),
		goalPoints: t.array(t.object({
			id: t.int().min(1).max(18),
			points: t.int()
		})).length(3)
	}),
	lastPlaced: z.nullable()
}), ne = t.object({ hand: t.array(t.int().min(1).max(18)) }), re = [
	"R",
	"C",
	"I",
	"P"
], ie = [
	S.N,
	S.E,
	S.S,
	S.W
], ae = [
	[-1, -1],
	[-1, 0],
	[-1, 1],
	[0, -1],
	[0, 1],
	[1, -1],
	[1, 0],
	[1, 1]
];
function U(e, t) {
	let n = [];
	for (let [r, i] of ie) {
		let a = e.cells.get(T(t.bx + r, t.by + i));
		a && n.push(a);
	}
	return n;
}
function W(e, t) {
	let n = 0;
	for (let r of F(e, t)) n = Math.max(n, r.length);
	return n;
}
function oe(e, t) {
	let n = F(e, t), r = 0;
	for (let e of n) r = Math.max(r, e.length);
	return n.filter((e) => e.length === r);
}
function G(e, t) {
	let n = [];
	for (let r of e.cells.values()) r.zone === t && n.push(r);
	return n;
}
function se(e, t) {
	return t.cells.filter((t) => (e.roads.get(t)?.links.size ?? 0) === 1);
}
function ce(e) {
	let t = 0;
	for (let n of e.components) t += n.atEdge ? -1 : 1;
	return t;
}
function le(e) {
	if (e.cells.size === 0) return 0;
	let { minX: t, maxX: n, minY: r, maxY: i } = I(e), a = 0;
	for (let o = r; o <= i; o += 1) {
		let r = 0;
		for (let i = t; i <= n; i += 1) e.cells.get(T(i, o))?.zone === "P" && (r += 1);
		r === 3 ? a += 1 : r === 0 && --a;
	}
	for (let o = t; o <= n; o += 1) {
		let t = 0;
		for (let n = r; n <= i; n += 1) e.cells.get(T(o, n))?.zone === "P" && (t += 1);
		t === 3 ? a += 1 : t === 0 && --a;
	}
	return a;
}
function ue(e) {
	return G(e, "P").length - 3 * G(e, "I").length;
}
var de = [
	-8,
	-5,
	-2,
	1,
	4
];
function fe(e) {
	let t = 0;
	for (let n of e.cells.values()) {
		let r = e.cells.get(T(n.bx + 1, n.by)), i = e.cells.get(T(n.bx, n.by + 1)), a = e.cells.get(T(n.bx + 1, n.by + 1));
		r?.zone === n.zone && i?.zone === n.zone && a?.zone === n.zone && (t += 1);
	}
	return t >= 5 ? 7 : de[t];
}
function pe(e) {
	let t = 0;
	for (let n of G(e, "I")) {
		let r = U(e, n);
		r.length > 0 && r.every((e) => e.zone === "C" || e.zone === "I") && (t += 1);
	}
	return t * 2;
}
function me(e) {
	return W(e, "R") - W(e, "I");
}
function he(e) {
	let t = 0;
	for (let n of G(e, "P")) t += N(e, n) ? -2 : 1;
	return t;
}
function ge(e) {
	let t = oe(e, "R"), n = -Infinity;
	for (let r of t) {
		let t = new Set(r.map((e) => e.key)), i = (n) => U(e, n).some((e) => t.has(e.key)), a = 0;
		for (let t of G(e, "P")) i(t) && (a += 1);
		for (let t of G(e, "I")) i(t) && (a -= 2);
		n = Math.max(n, a);
	}
	return n === -Infinity ? 0 : n;
}
function _e(e) {
	let t = 0;
	for (let n of G(e, "I")) ae.some(([t, r]) => e.cells.get(T(n.bx + t, n.by + r))?.zone === "I") && (t += 1);
	return t;
}
function ve(e) {
	if (e.cells.size === 0) return 0;
	let { minX: t, maxX: n, minY: r, maxY: i } = I(e), a = 0;
	for (let o = r; o <= i; o += 1) {
		let r = 0;
		for (let i = t; i <= n; i += 1) e.cells.get(T(i, o))?.zone === "C" && (r += 1);
		a = Math.max(a, r);
	}
	for (let o = t; o <= n; o += 1) {
		let t = 0;
		for (let n = r; n <= i; n += 1) e.cells.get(T(o, n))?.zone === "C" && (t += 1);
		a = Math.max(a, t);
	}
	return a;
}
function ye(e) {
	let t = 0;
	for (let n of G(e, "C")) {
		let r = e.roads.get(n.key);
		if (!r) continue;
		let i = 0;
		for (let t of r.links) e.cells.get(t)?.zone === "R" && (i += 1);
		i >= 2 && (t += 1);
	}
	return t * 2;
}
function be(e) {
	let t = 0;
	for (let n of e.components) t = Math.max(t, n.cells.length);
	return Math.floor(t / 2);
}
function xe(e) {
	let t = 0;
	for (let n of e.components) new Set(se(e, n).filter((t) => e.cells.get(t)?.zone === "P")).size >= 2 && (t += 1);
	return t * 3;
}
function Se(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e.roads.values()) for (let e of r.links) {
		let i = r.key < e ? `${r.key}|${e}` : `${e}|${r.key}`;
		n.has(i) || (n.add(i), t.push(r.key < e ? [r.key, e] : [e, r.key]));
	}
	let r = t, i = t.length > 0;
	for (; i;) {
		i = !1;
		let e = /* @__PURE__ */ new Map();
		for (let [t, n] of r) e.set(t, (e.get(t) ?? 0) + 1), e.set(n, (e.get(n) ?? 0) + 1);
		let t = r.filter(([t, n]) => (e.get(t) ?? 0) > 1 && (e.get(n) ?? 0) > 1);
		t.length !== r.length && (r = t, i = !0);
	}
	let a = /* @__PURE__ */ new Set();
	for (let [e, t] of r) a.add(e), a.add(t);
	return a.size;
}
function Ce(e) {
	let t = 0;
	for (let n of G(e, "R")) U(e, n).filter((e) => e.zone === "I").length >= 2 && (t += 1);
	return t * 2;
}
function we(e) {
	let t = 0;
	for (let n of e.components) n.zones.has("R") && n.zones.has("C") && (t += 1);
	return t * 2;
}
function Te(e) {
	let t = 0;
	for (let n of G(e, "C")) N(e, n) && (t += 1, P(e, n) && (t += 1));
	return t;
}
function Ee(e) {
	if (e.cells.size === 0) return 0;
	let { minX: t, maxX: n, minY: r, maxY: i } = I(e), a = 0;
	for (let o = r; o <= i; o += 1) {
		let r = 0;
		for (let i = t; i <= n; i += 1) e.cells.has(T(i, o)) && (r += 1);
		a = Math.max(a, r);
	}
	let o = 0;
	for (let a = t; a <= n; a += 1) {
		let t = 0;
		for (let n = r; n <= i; n += 1) e.cells.has(T(a, n)) && (t += 1);
		o = Math.max(o, t);
	}
	return a + o;
}
var De = {
	1: ce,
	2: le,
	3: ue,
	4: fe,
	5: pe,
	6: me,
	7: he,
	8: ge,
	9: _e,
	10: ve,
	11: ye,
	12: be,
	13: xe,
	14: Se,
	15: Ce,
	16: we,
	17: Te,
	18: Ee
};
function Oe(e, t, n) {
	let r = {
		R: 0,
		C: 0,
		I: 0,
		P: 0
	};
	for (let t of re) r[t] = W(e, t);
	let i = n === "hard" ? Math.max(r.R, r.C, r.I, r.P) : r.R + r.C + r.I + r.P, a = e.components.length, o = n === "easy" ? 0 : a, s = t.map((t) => ({
		id: t,
		points: De[t]?.(e) ?? 0
	})), c = s.reduce((e, t) => e + t.points, 0), l = t.reduce((e, t) => e + t, 0), u = i - o + c;
	return {
		groups: r,
		blockScore: i,
		roadCount: a,
		roadPenalty: o,
		goals: s,
		goalTotal: c,
		total: u,
		target: l,
		win: u >= l
	};
}
function K(e, t, n) {
	return Oe(ee(e), t, n);
}
var q = 3;
function ke(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ae(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		difficulty: e.difficulty,
		goals: [],
		deck: [],
		hands: {},
		cards: [],
		turnIdx: 0,
		phase: "play",
		lastPlaced: null
	}, i = ke(r, b);
	r.goals = i.slice(0, q), r.deck = i.slice(q);
	let a = {
		id: r.deck.pop(),
		x: 0,
		y: 0,
		rot: 0
	};
	return r.cards.push(a), r.lastPlaced = a, r.hands = Object.fromEntries(t.map((e) => [e, []])), t.forEach((e, t) => {
		let n = t === 0 ? 3 : 1;
		for (let t = 0; t < n; t += 1) r.hands[e].push(r.deck.pop());
	}), { state: r };
}
function je(e, t, n) {
	if (e.phase !== "play") return { code: "games.sprawlopolis.errPhase" };
	let r = e.players[e.turnIdx];
	if (n.by !== r) return { code: "games.sprawlopolis.errNotYourTurn" };
	if (!(e.hands[r] ?? []).includes(t.card)) return { code: "games.sprawlopolis.errCardNotInHand" };
	if (!j(e.cards, t.x, t.y)) return { code: "games.sprawlopolis.errBadPlacement" };
	let i = structuredClone(e), a = i.hands[r].indexOf(t.card);
	i.hands[r].splice(a, 1);
	let o = {
		id: t.card,
		x: t.x,
		y: t.y,
		rot: t.rot
	};
	i.cards.push(o), i.lastPlaced = o;
	let s = i.players[(i.turnIdx + 1) % i.players.length], c = i.hands[r];
	return i.hands[r] = [], i.hands[s] = [...i.hands[s] ?? [], ...c], i.deck.length > 0 && i.hands[r].push(i.deck.pop()), i.turnIdx = (i.turnIdx + 1) % i.players.length, i.cards.length >= 15 && (i.phase = "done"), {
		state: i,
		fx: [{
			kind: "place",
			rid: r,
			data: {
				card: o.id,
				x: o.x,
				y: o.y,
				rot: o.rot
			}
		}]
	};
}
function Me(e, t) {
	let n = K(e.cards, e.goals, e.difficulty);
	return {
		public: {
			phase: e.phase,
			difficulty: e.difficulty,
			goals: [...e.goals].sort((e, t) => e - t),
			target: n.target,
			turn: e.phase === "play" ? {
				idx: e.turnIdx,
				rid: e.players[e.turnIdx]
			} : null,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t]?.length ?? 0
			})),
			cards: e.cards,
			deckCount: e.deck.length,
			deckTop: e.deck.length > 0 ? e.deck[e.deck.length - 1] : null,
			score: {
				total: n.total,
				target: n.target,
				win: n.win,
				groups: n.groups,
				blockScore: n.blockScore,
				roadCount: n.roadCount,
				roadPenalty: n.roadPenalty,
				goalPoints: n.goals.map((e) => ({
					id: e.id,
					points: e.points
				}))
			},
			lastPlaced: e.lastPlaced
		},
		private: { hand: [...e.hands[t] ?? []].sort((e, t) => e - t) }
	};
}
function Ne(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = K(e.cards, e.goals, e.difficulty);
	return {
		phase: "done",
		winner: t.win ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((e) => [e, t.total]))
	};
}
var Pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: B,
		publicView: te,
		privateView: ne,
		config: V
	},
	setup: Ae,
	reduce: je,
	viewFor: Me,
	status: Ne
}, J = 100;
function Fe(e) {
	let t = e.cells[0], n = e.cells[e.cells.length - 1], r = [k(w[t][0], w[t][1], e.from)];
	for (let t of e.cells) r.push([w[t][0] + .5, w[t][1] + .5]);
	return r.push(k(w[n][0], w[n][1], e.to)), r.map(([e, t]) => `${e},${t}`).join(" ");
}
function Ie({ zone: e, x: t, y: n }) {
	let r = "rgba(44, 36, 25, 0.78)";
	return /* @__PURE__ */ h("g", {
		transform: `translate(${t} ${n})`,
		pointerEvents: "none",
		children: [
			e === "R" && /* @__PURE__ */ h("g", {
				fill: r,
				children: [/* @__PURE__ */ m("path", { d: "M-0.2 0.02 L0 -0.23 L0.2 0.02 Z" }), /* @__PURE__ */ m("rect", {
					x: -.13,
					y: .02,
					width: .26,
					height: .2,
					rx: .015
				})]
			}),
			e === "C" && /* @__PURE__ */ h("g", {
				fill: r,
				children: [
					/* @__PURE__ */ m("rect", {
						x: -.17,
						y: -.04,
						width: .34,
						height: .26,
						rx: .02
					}),
					/* @__PURE__ */ m("path", { d: "M-0.23 -0.26 H0.23 L0.17 -0.06 H-0.17 Z" }),
					/* @__PURE__ */ m("rect", {
						x: -.045,
						y: .06,
						width: .09,
						height: .16,
						fill: "#f4eddc"
					})
				]
			}),
			e === "I" && /* @__PURE__ */ h("g", {
				fill: r,
				children: [/* @__PURE__ */ m("path", { d: "M-0.2 0.21 V-0.01 L-0.07 -0.11 V0.03 L0.06 -0.07 V0.21 Z" }), /* @__PURE__ */ m("rect", {
					x: .06,
					y: -.24,
					width: .06,
					height: .15
				})]
			}),
			e === "P" && /* @__PURE__ */ h("g", {
				fill: r,
				children: [/* @__PURE__ */ m("rect", {
					x: -.028,
					y: .02,
					width: .056,
					height: .17,
					rx: .01
				}), /* @__PURE__ */ m("circle", {
					cy: -.06,
					r: .15
				})]
			})
		]
	});
}
function Y({ id: e, ghost: t }) {
	let n = y.get(e);
	return n ? /* @__PURE__ */ h("g", {
		opacity: t ? .55 : 1,
		children: [
			/* @__PURE__ */ m("rect", {
				x: 0,
				y: 0,
				width: 2,
				height: 2,
				rx: .07,
				fill: "#3f382e"
			}),
			w.map(([e, t], r) => /* @__PURE__ */ h("g", { children: [
				/* @__PURE__ */ m("rect", {
					x: e + .012,
					y: t + .012,
					width: .976,
					height: .976,
					rx: .03,
					fill: x[n.zones[r]]
				}),
				/* @__PURE__ */ m("rect", {
					x: e + .012,
					y: t + .012,
					width: .976,
					height: .976,
					rx: .03,
					fill: "none",
					stroke: "rgba(44, 36, 25, 0.35)",
					strokeWidth: .012
				}),
				/* @__PURE__ */ m(Ie, {
					zone: n.zones[r],
					x: e + .5,
					y: t + .5
				})
			] }, r)),
			n.roads.map((e, t) => {
				let n = Fe(e);
				return /* @__PURE__ */ h("g", {
					fill: "none",
					strokeLinejoin: "round",
					strokeLinecap: "round",
					pointerEvents: "none",
					children: [/* @__PURE__ */ m("polyline", {
						points: n,
						stroke: "rgba(44, 36, 25, 0.55)",
						strokeWidth: .17
					}), /* @__PURE__ */ m("polyline", {
						points: n,
						stroke: "#f2ebda",
						strokeWidth: .1
					})]
				}, `r${t}`);
			}),
			/* @__PURE__ */ m("rect", {
				x: .012,
				y: .012,
				width: 1.976,
				height: 1.976,
				rx: .06,
				fill: "none",
				stroke: "#3f382e",
				strokeWidth: .03,
				strokeDasharray: t ? "0.12 0.08" : void 0
			})
		]
	}) : null;
}
function X(e) {
	return !window.matchMedia("(orientation: landscape)").matches || e.w < 900 || e.h < 420 ? 1.4 : Math.max(1.2, Math.min(e.h / 400, 2));
}
function Z(e, t) {
	let n = 0, r = 2, i = 0, a = 2;
	if (e.length > 0) {
		n = Infinity, i = Infinity, r = -Infinity, a = -Infinity;
		for (let t of e) n = Math.min(n, t.x), i = Math.min(i, t.y), r = Math.max(r, t.x + 2), a = Math.max(a, t.y + 2);
	}
	let o = .7;
	n -= o, i -= o, r += o, a += o;
	let s = (n + r) / 2 * J, c = (i + a) / 2 * J;
	return t.w === 0 ? {
		cx: s,
		cy: c,
		s: 1
	} : {
		cx: s,
		cy: c,
		s: Math.min(t.w / ((r - n) * J), t.h / ((a - i) * J), X(t))
	};
}
function Le({ cards: e, spots: t, ghost: r, lastPlaced: o, fitKey: s, onTapOrigin: c, controls: l, controlsSize: u = {
	width: 216,
	height: 56
} }) {
	let d = i(null), [f, p] = a({
		w: 0,
		h: 0
	}), [g, _] = a(null), v = i({
		cx: 0,
		cy: 0,
		s: 1
	});
	n(() => {
		let e = d.current, t = new ResizeObserver(() => p({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let y = `${s}:${f.w}x${f.h}`, [b, x] = a("");
	b !== y && f.w > 0 && f.h > 0 && (x(y), _(Z(e, f)));
	let S = g ?? Z(e, f);
	n(() => {
		v.current = S;
	}), n(() => {
		let e = d.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = v.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .2), X(f) * 1.8), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			v.current = u, _(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [f]);
	let C = i(/* @__PURE__ */ new Map()), w = i(0), T = i(0), E = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), C.current.size === 1 && (w.current = 0), C.current.size === 2) {
			let [e, t] = [...C.current.values()];
			T.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, D = (e) => {
		let t = C.current.get(e.pointerId);
		if (!t) return;
		let n = d.current.getBoundingClientRect();
		if (C.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			w.current += Math.abs(n) + Math.abs(r);
			let i = v.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			v.current = a, _(a);
		} else if (C.current.size === 2) {
			C.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...C.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (T.current > 0 && i > 0) {
				let e = v.current, a = Math.min(Math.max(e.s * i / T.current, .2), X(f) * 1.8), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				v.current = u, _(u);
			}
			T.current = i, w.current = 99;
			return;
		}
		C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, O = (e) => {
		let n = C.current.size === 1 && w.current < 10;
		if (C.current.delete(e.pointerId), T.current = 0, !n || !t || !c) return;
		let r = d.current.getBoundingClientRect(), i = v.current, a = i.cx + (e.clientX - r.left - r.width / 2) / i.s, o = i.cy + (e.clientY - r.top - r.height / 2) / i.s, s = null, l = J * 1.6;
		for (let e of t) {
			let t = Math.hypot((e.x + 1) * J - a, (e.y + 1) * J - o);
			t < l && (l = t, s = e);
		}
		s && c(s.x, s.y);
	}, k = r && l && f.w > 0 && f.h > 0 ? ((e, t) => {
		let n = f.w / 2 + (e * J - S.cx) * S.s, r = f.h / 2 + (t * J - S.cy) * S.s, i = J * S.s, a = u.width / 2, o = u.height / 2, s = r + i + o + 10, c = r - i - o - 10, l = n + i + a + 10, d = n - i - a - 10, p = s <= f.h - o - 8 || c < o + 8 ? s : c;
		return {
			left: Math.max(a + 4, Math.min(f.w - a - 4, l <= f.w - a - 4 ? l : d)),
			top: Math.max(o + 8, Math.min(f.h - o - 8, p > f.h - o - 8 ? c : p))
		};
	})(r.x + 1, r.y + 1) : null;
	return /* @__PURE__ */ h("div", {
		ref: d,
		className: "sprawl-board relative h-full w-full overflow-hidden",
		children: [/* @__PURE__ */ m("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: E,
			onPointerMove: D,
			onPointerUp: O,
			onPointerCancel: O,
			children: /* @__PURE__ */ h("g", {
				transform: `translate(${f.w / 2 - S.cx * S.s}, ${f.h / 2 - S.cy * S.s}) scale(${S.s})`,
				children: [
					e.map((e, t) => /* @__PURE__ */ m("g", {
						transform: `translate(${e.x * J} ${e.y * J}) scale(${J}) rotate(${e.rot} 1 1)`,
						children: /* @__PURE__ */ m(Y, { id: e.id })
					}, `${e.id}:${t}`)),
					o && /* @__PURE__ */ m("rect", {
						x: o.x * J + 2,
						y: o.y * J + 2,
						width: 196,
						height: 196,
						rx: J * .06,
						fill: "none",
						className: "stroke-ink",
						strokeWidth: 2.5,
						strokeDasharray: "7 7",
						opacity: .45,
						pointerEvents: "none"
					}),
					t?.map((e) => /* @__PURE__ */ h("g", {
						transform: `translate(${(e.x + 1) * J} ${(e.y + 1) * J})`,
						pointerEvents: "none",
						children: [/* @__PURE__ */ m("rect", {
							x: -.18 * J,
							y: -.18 * J,
							width: .36 * J,
							height: .36 * J,
							rx: .06 * J,
							fill: "var(--color-info-soft)",
							fillOpacity: .55,
							className: "stroke-info-ink",
							strokeWidth: 3,
							strokeDasharray: "8 6"
						}), /* @__PURE__ */ m("rect", {
							x: -.03 * J,
							y: -.03 * J,
							width: .06 * J,
							height: .06 * J,
							rx: 3,
							className: "fill-info-ink"
						})]
					}, `${e.x},${e.y}`)),
					r && /* @__PURE__ */ m("g", {
						transform: `translate(${r.x * J} ${r.y * J}) scale(${J}) rotate(${r.rot} 1 1)`,
						pointerEvents: "none",
						children: /* @__PURE__ */ m("g", {
							className: "sprawl-ghost-bob",
							children: /* @__PURE__ */ m(Y, {
								id: r.id,
								ghost: !0
							})
						})
					})
				]
			})
		}), k && /* @__PURE__ */ m("div", {
			className: "sprawl-board-controls",
			style: k,
			children: l
		})]
	});
}
//#endregion
//#region src/game/view-player.tsx
var Q = {
	1: "games.sprawlopolis.goal1Name",
	2: "games.sprawlopolis.goal2Name",
	3: "games.sprawlopolis.goal3Name",
	4: "games.sprawlopolis.goal4Name",
	5: "games.sprawlopolis.goal5Name",
	6: "games.sprawlopolis.goal6Name",
	7: "games.sprawlopolis.goal7Name",
	8: "games.sprawlopolis.goal8Name",
	9: "games.sprawlopolis.goal9Name",
	10: "games.sprawlopolis.goal10Name",
	11: "games.sprawlopolis.goal11Name",
	12: "games.sprawlopolis.goal12Name",
	13: "games.sprawlopolis.goal13Name",
	14: "games.sprawlopolis.goal14Name",
	15: "games.sprawlopolis.goal15Name",
	16: "games.sprawlopolis.goal16Name",
	17: "games.sprawlopolis.goal17Name",
	18: "games.sprawlopolis.goal18Name"
}, Re = {
	1: "games.sprawlopolis.goal1Text",
	2: "games.sprawlopolis.goal2Text",
	3: "games.sprawlopolis.goal3Text",
	4: "games.sprawlopolis.goal4Text",
	5: "games.sprawlopolis.goal5Text",
	6: "games.sprawlopolis.goal6Text",
	7: "games.sprawlopolis.goal7Text",
	8: "games.sprawlopolis.goal8Text",
	9: "games.sprawlopolis.goal9Text",
	10: "games.sprawlopolis.goal10Text",
	11: "games.sprawlopolis.goal11Text",
	12: "games.sprawlopolis.goal12Text",
	13: "games.sprawlopolis.goal13Text",
	14: "games.sprawlopolis.goal14Text",
	15: "games.sprawlopolis.goal15Text",
	16: "games.sprawlopolis.goal16Text",
	17: "games.sprawlopolis.goal17Text",
	18: "games.sprawlopolis.goal18Text"
}, ze = {
	easy: "games.sprawlopolis.difficultyEasy",
	normal: "games.sprawlopolis.difficultyNormal",
	hard: "games.sprawlopolis.difficultyHard"
};
function Be(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(Ve, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ve({ pub: e, priv: t, members: n, myRid: i, send: g }) {
	let _ = s(), [v, y] = a(null), [b, x] = a(null), [S, C] = a(!1), [w, T] = a(0), E = t?.hand ?? [], D = e.phase === "play" && e.turn?.rid === i, O = `${e.turn?.rid ?? "-"}:${e.cards.length}:${E.join(",")}`, [k, A] = a(O);
	k !== O && (A(O), y(null), x(null));
	let j = r(() => D && v !== null ? M(e.cards) : void 0, [
		D,
		v,
		e.cards
	]), ee = (e) => n.find((t) => t.rid === e)?.name ?? e, N = _(ze[e.difficulty]), P = "info", F;
	e.phase === "done" ? (P = "done", F = _("games.sprawlopolis.turnDone")) : D ? (P = "accent", F = _(v === null ? "games.sprawlopolis.turnYouPick" : "games.sprawlopolis.turnYouPlace")) : F = _("games.sprawlopolis.turnWait", { name: ee(e.turn?.rid ?? "") });
	let I = new Map(e.score.goalPoints.map((e) => [e.id, e.points])), R = (e, t) => {
		D && v !== null && x({
			x: e,
			y: t,
			rot: b?.rot ?? 0
		});
	}, z = () => x((e) => e && {
		...e,
		rot: e.rot === 0 ? 180 : 0
	}), B = () => {
		D && v !== null && b && (g({
			type: "place",
			card: v,
			x: b.x,
			y: b.y,
			rot: b.rot
		}), y(null), x(null));
	};
	return /* @__PURE__ */ h(u, {
		adaptive: !0,
		className: "sprawl-game",
		scroll: !1,
		banner: /* @__PURE__ */ h("div", {
			className: "sprawl-header flex flex-col gap-2",
			children: [
				/* @__PURE__ */ m(d, {
					tone: P,
					text: F,
					chip: _("games.sprawlopolis.scoreChip", {
						score: e.score.total,
						target: e.score.target
					}),
					sub: `${_("games.sprawlopolis.cityChip", {
						n: e.cards.length,
						t: 15
					})} · ${_("games.sprawlopolis.difficultyChip", { name: N })}`,
					accent: L.accent
				}),
				/* @__PURE__ */ m("div", {
					className: "sprawl-goals",
					role: "group",
					"aria-label": _("games.sprawlopolis.goalsAria"),
					children: e.goals.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: "sprawl-goal-chip",
						onClick: () => C(!0),
						"aria-label": `${_(Q[e])} · ${_("games.sprawlopolis.goalPoints", { n: I.get(e) ?? 0 })}`,
						children: [
							/* @__PURE__ */ m("span", {
								className: "sprawl-goal-chip__num",
								children: e
							}),
							/* @__PURE__ */ m("span", {
								className: "sprawl-goal-chip__name",
								children: _(Q[e])
							}),
							/* @__PURE__ */ m("span", {
								className: "sprawl-goal-chip__pts",
								children: I.get(e) ?? 0
							})
						]
					}, e))
				}),
				/* @__PURE__ */ m("div", {
					className: "sprawl-players",
					children: /* @__PURE__ */ m(f, {
						members: n.filter((t) => e.players.some((e) => e.rid === t.rid)),
						myRid: i,
						variant: "mini",
						adaptive: !0,
						action: (t) => e.phase === "play" && e.turn?.rid === t ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t)?.handCount ?? 0;
							return /* @__PURE__ */ m("span", {
								className: "sprawl-seat-count",
								"aria-label": _("games.sprawlopolis.handCount", { n }),
								children: n
							});
						}
					})
				})
			]
		}),
		actionsHeight: "sprawl-actions",
		actions: /* @__PURE__ */ h("div", {
			className: "sprawl-hand",
			children: [/* @__PURE__ */ h("div", {
				className: "sprawl-hand__main",
				children: [/* @__PURE__ */ m("span", {
					className: "sprawl-hand__label",
					children: _(D ? "games.sprawlopolis.handTitle" : "games.sprawlopolis.waitOthers")
				}), /* @__PURE__ */ h("div", {
					className: "sprawl-hand__cards scrollbar-none",
					children: [E.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						disabled: !D,
						"aria-label": _("games.sprawlopolis.handCardAria", { n: t + 1 }),
						"aria-pressed": v === e,
						className: `sprawl-hand-card${v === e ? " is-selected" : ""}`,
						onClick: () => {
							D && (y((t) => t === e ? null : e), x(null));
						},
						children: /* @__PURE__ */ m("svg", {
							viewBox: "0 0 2 2",
							"aria-hidden": !0,
							children: /* @__PURE__ */ m(Y, { id: e })
						})
					}, `${e}:${t}`)), E.length === 0 && /* @__PURE__ */ m("span", {
						className: "sprawl-hand__empty",
						children: _("games.sprawlopolis.handEmpty")
					})]
				})]
			}), /* @__PURE__ */ h("div", {
				className: "sprawl-deck",
				children: [/* @__PURE__ */ h("span", {
					className: "sprawl-deck__label",
					children: [
						_("games.sprawlopolis.deckTitle"),
						" · ",
						_("games.sprawlopolis.deckCount", { n: e.deckCount })
					]
				}), e.deckTop !== null && /* @__PURE__ */ m("svg", {
					className: "sprawl-deck__card",
					viewBox: "0 0 2 2",
					"aria-label": _("games.sprawlopolis.deckTopAria"),
					role: "img",
					children: /* @__PURE__ */ m(Y, { id: e.deckTop })
				})]
			})]
		}),
		children: [/* @__PURE__ */ h("div", {
			className: "sprawl-stage relative h-full min-h-0",
			children: [
				/* @__PURE__ */ m(Le, {
					cards: e.cards,
					spots: j,
					ghost: b ? {
						...b,
						id: v
					} : null,
					lastPlaced: e.lastPlaced,
					fitKey: String(w),
					onTapOrigin: R,
					controls: b && v !== null ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("button", {
						type: "button",
						"aria-label": _("games.sprawlopolis.rotateAria"),
						onClick: z,
						className: "sprawl-board-rotate",
						children: [/* @__PURE__ */ m(l, {
							size: 20,
							"aria-hidden": !0
						}), /* @__PURE__ */ m("span", {
							"aria-hidden": !0,
							children: _("games.sprawlopolis.rotate")
						})]
					}), /* @__PURE__ */ m("button", {
						type: "button",
						onClick: B,
						className: "sprawl-board-confirm",
						style: { background: L.accent },
						children: _("games.sprawlopolis.confirm")
					})] }) : void 0
				}),
				D && v !== null && !b && /* @__PURE__ */ m("p", {
					className: "sprawl-hint",
					"aria-hidden": !0,
					children: _("games.sprawlopolis.selectHint")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					"aria-label": _("games.sprawlopolis.recenter"),
					onClick: () => T((e) => e + 1),
					className: "sprawl-recenter",
					children: /* @__PURE__ */ m(c, {
						size: 20,
						"aria-hidden": !0
					})
				})
			]
		}), /* @__PURE__ */ m(o, {
			open: S,
			onClose: () => C(!1),
			keepMounted: !0,
			label: _("games.sprawlopolis.goalSheetTitle"),
			title: _("games.sprawlopolis.goalSheetTitle"),
			children: /* @__PURE__ */ h("div", {
				className: "sprawl-goal-sheet",
				children: [
					/* @__PURE__ */ m("p", {
						className: "sprawl-goal-sheet__diff",
						children: _("games.sprawlopolis.difficultyChip", { name: N })
					}),
					e.goals.map((e) => /* @__PURE__ */ h("div", {
						className: "sprawl-goal-row",
						children: [/* @__PURE__ */ m("span", {
							className: "sprawl-goal-row__num",
							children: e
						}), /* @__PURE__ */ h("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ h("div", {
								className: "sprawl-goal-row__head",
								children: [/* @__PURE__ */ m("span", { children: _(Q[e]) }), /* @__PURE__ */ m("span", {
									className: "sprawl-goal-row__pts",
									children: _("games.sprawlopolis.goalPoints", { n: I.get(e) ?? 0 })
								})]
							}), /* @__PURE__ */ m("p", {
								className: "sprawl-goal-row__text",
								children: _(Re[e])
							})]
						})]
					}, e)),
					/* @__PURE__ */ m("p", {
						className: "sprawl-goal-sheet__hint",
						children: _("games.sprawlopolis.optHint")
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/game/bot.ts
function $(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var He = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || !n.turn || n.turn.rid !== t.rid) return null;
	let r = e.private?.hand ?? [];
	if (r.length === 0) return null;
	let i = M(n.cards);
	if (i.length === 0) return null;
	if (t.difficulty === "weak") {
		let e = $(r), t = $(i), n = $([0, 180]);
		return { action: {
			type: "place",
			card: e,
			x: t.x,
			y: t.y,
			rot: n
		} };
	}
	let a = null, o = -Infinity;
	for (let e of r) for (let t of i) for (let r of [0, 180]) {
		let i = {
			id: e,
			x: t.x,
			y: t.y,
			rot: r
		}, s = K([...n.cards, i], n.goals, n.difficulty), c = s.total * 100 - s.roadCount;
		c > o && (o = c, a = {
			type: "place",
			card: e,
			x: t.x,
			y: t.y,
			rot: r
		});
	}
	return a ? { action: a } : null;
}, Ue = [
	{
		value: "easy",
		key: "games.sprawlopolis.optEasy"
	},
	{
		value: "normal",
		key: "games.sprawlopolis.optNormal"
	},
	{
		value: "hard",
		key: "games.sprawlopolis.optHard"
	}
];
function We({ value: e, onChange: t }) {
	let n = s(), r = V.safeParse(e), i = r.success ? r.data : V.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ m(_, {
			title: n("games.sprawlopolis.optDifficulty"),
			columns: 3,
			children: Ue.map((e) => /* @__PURE__ */ m(g, {
				name: "sprawlopolis-difficulty",
				value: e.value,
				checked: i.difficulty === e.value,
				label: n(e.key),
				accent: L.accent,
				onChange: () => t({ difficulty: e.value })
			}, e.value))
		}), /* @__PURE__ */ m("p", {
			className: "text-xs text-ink/70",
			children: n("games.sprawlopolis.optHint")
		})]
	});
}
//#endregion
//#region src/index.tsx
var Ge = {
	definition: Pe,
	View: Be,
	bot: He,
	Options: We,
	locales: {
		zh: {
			name: "无限都市",
			desc: "合作摆放卡牌，一起建起不断扩张的城市",
			rules: "目标:你们合作建造一座城市。十五张卡全部放入城市后，把区块得分与三张计分条件的得分相加，再减去道路扣分；总分不低于目标分时，全队获胜。\n组件:\n· 十八张双面卡：一面是二乘二的四格区块，分为住宅、商业、工业与公园四种；另一面印着计分条件与编号。\n· 本局随机抽出三张计分条件卡作为公开条件，卡上的编号就是这条条件的分值，三个编号之和就是目标分。\n分牌:\n· 洗混十八张卡，抽出三张条件卡正面朝上放在一旁。\n· 从剩余的卡牌中取一张放到中央，作为城市的第一张卡；其余卡牌叠成牌堆，区块面朝上，顶牌公开。\n· 起始玩家拿三张手牌，其他玩家各拿一张。手牌不能给其他玩家看。\n回合:\n· 轮到你时，从手牌中选择一张卡，放到城市的合法位置。\n· 放好后，把手中剩余的卡牌全部交给左手边的玩家，该玩家成为新的起始玩家。\n· 随后你从牌堆顶抽一张牌，让手牌回到一张；牌堆抽空后不再补牌。\n· 当十五张卡全部放入城市时，游戏立即结束并进入结算。\n落位:\n· 新卡的区块至少要有一条边与已有区块相接，或者盖住已有的一格或多格区块；覆盖时新卡在上。\n· 不允许把卡塞到已有卡下面，也不允许只靠角相接；城市内部可以留下空洞。\n· 每张卡可以旋转一百八十度，但必须保持竖放。\n计分:\n· 区块得分：四种区块各自找出最大的正交连通组，组内每格计一分，再把四组得分相加。\n· 道路扣分：城市中每一条独立道路扣一分。道路是连续的一条带状路面，在卡片交界处没有接通时断开。\n· 条件得分：三条计分条件按各自的说明结算，可能出现负分。\n· 总分等于区块得分加上条件得分，再减去道路扣分。\n难度:\n· 简单难度不扣道路分。\n· 标准难度按上述规则计分。\n· 困难难度只取四种区块中最大的一个连通组，其余区块组不计入区块得分。\n单人:\n· 单人游戏按同样的流程进行：每放下一张卡后把手牌补回三张，直到牌堆用完。",
			optDifficulty: "难度",
			optEasy: "简单",
			optNormal: "标准",
			optHard: "困难",
			optHint: "简单难度不扣道路分；困难难度只取最大的一个区块组计分。",
			turnYouPick: "选一张手牌，再点城市中的落位",
			turnYouPlace: "调整朝向，确认后放置",
			turnWait: "等 {{name}} 放牌…",
			turnDone: "城市建成，进入结算",
			cityChip: "城市 {{n}}/{{t}}",
			goalSheetTitle: "本局计分条件",
			goalPoints: "{{n}} 分",
			goalsAria: "计分条件",
			scoreChip: "得分 {{score}} · 目标 {{target}}",
			difficultyChip: "{{name}}难度",
			difficultyEasy: "简单",
			difficultyNormal: "标准",
			difficultyHard: "困难",
			handTitle: "我的手牌",
			handEmpty: "没有手牌",
			handCardAria: "手牌第 {{n}} 张",
			deckTitle: "牌堆",
			deckTopAria: "牌堆顶牌",
			deckCount: "{{n}} 张",
			handCount: "{{n}} 张手牌",
			waitOthers: "等待其他玩家放牌",
			selectHint: "选中一张手牌，城市中出现可放置的虚线位置。",
			rotate: "旋转",
			rotateAria: "旋转待放置的卡",
			confirm: "放这里",
			recenter: "回到城市",
			resultTitle: "城市结算",
			resultWin: "挑战成功",
			resultLose: "挑战失败",
			resultWinSub: "总分达到目标分，这座城市顺利完工。",
			resultLoseSub: "总分没有达到目标分，大家可以再试一次。",
			resultBlocks: "区块得分",
			resultRoads: "道路扣分",
			resultRoadCount: "共 {{n}} 条道路",
			resultGoals: "计分条件",
			resultTotal: "总分",
			resultTarget: "目标分",
			resultReview: "回看城市",
			resultReopen: "结算",
			zoneR: "住宅",
			zoneC: "商业",
			zoneI: "工业",
			zoneP: "公园",
			goal1Name: "城郊",
			goal1Text: "不终止于城市边缘的道路，每条加一分；终止于城市边缘的道路，每条扣一分。",
			goal2Name: "花开遍地",
			goal2Text: "每一行或每一列恰好包含三个公园区块时加一分；一行或一列没有公园区块时扣一分。",
			goal3Name: "绿化",
			goal3Text: "每个公园区块加一分；每个工业区块扣三分。",
			goal4Name: "街区派对",
			goal4Text: "统计四格同色的二乘二方块：零组扣八分，一组扣五分，两组扣二分，三组加一分，四组加四分，五组及以上加七分。",
			goal5Name: "高楼林立",
			goal5Text: "只与商业区块或工业区块相邻的工业区块，每个加二分。",
			goal6Name: "总体规划",
			goal6Text: "最大住宅连通组的格数减去最大工业连通组的格数，结果就是这条条件的得分，可以为负。",
			goal7Name: "市中心",
			goal7Text: "位于城市内部的公园区块每个加一分；位于城市边缘的公园区块每个扣二分。",
			goal8Name: "郊区",
			goal8Text: "与最大住宅连通组相邻的公园区块每个加一分，与它相邻的工业区块每个扣二分；住宅连通组并列时，取得分最高的一组计算。",
			goal9Name: "水泥丛林",
			goal9Text: "与至少一个其他工业区块共角或共边的工业区块，每个加一分。",
			goal10Name: "商业街",
			goal10Text: "选择一行或一列，其中商业区块的数量就是这条条件的得分。",
			goal11Name: "便利店",
			goal11Text: "夹在两个住宅区块之间，并且同一条道路依次穿过这三格的商业区块，每个加二分。",
			goal12Name: "高速公路",
			goal12Text: "最长的一条道路每包含两个道路段加一分，不足两个的部分不计。",
			goal13Name: "公园跳跃",
			goal13Text: "起于一个公园区块、止于另一个公园区块的道路，每条加三分。",
			goal14Name: "环路",
			goal14Text: "构成闭环的每个道路段加一分。",
			goal15Name: "贫民窟",
			goal15Text: "与两个或更多工业区块相邻的住宅区块，每个加二分。",
			goal16Name: "通勤",
			goal16Text: "同时穿过住宅区块与商业区块的道路，每条加二分。",
			goal17Name: "旅游陷阱",
			goal17Text: "位于城市边缘的商业区块每个加一分；其中位于角上的商业区块再加一分。",
			goal18Name: "无限都市",
			goal18Text: "最长一行中的区块数与最长一列中的区块数之和，就是这条条件的得分；空洞不计入，但跨过空洞继续计数。",
			errPhase: "对局已经结束",
			errNotYourTurn: "还没轮到你",
			errCardNotInHand: "手里没有这张卡",
			errBadPlacement: "这个位置不能放置"
		},
		en: {
			name: "Sprawlopolis",
			desc: "Place cards together to grow one sprawling city",
			rules: "Goal: you build one city together. After all fifteen cards are in the city, add the block score and the three scoring conditions, then subtract the road penalty; the team wins when the total meets the target.\nComponents:\n· Eighteen double-sided cards: one side shows a grid of four blocks in residential, commercial, industrial, and park types; the other side shows a scoring condition and its number.\n· Three condition cards drawn at random are public for the game, and the number on each card is both the points for that condition and part of the target total.\nDeal:\n· Shuffle the eighteen cards and turn three of them condition-side up as the public conditions.\n· Take one of the remaining cards and place it in the middle as the first card of the city; stack the rest block-side up so the top card is public.\n· The starting player takes three cards, and every other player takes one. Hands stay private.\nTurns:\n· On your turn, choose one card from your hand and place it in a legal spot in the city.\n· After placing it, pass all the cards left in your hand to the player on your left, who becomes the new starting player.\n· Then draw the top card of the stack so your hand is back to one card; once the stack is empty, no more cards are drawn.\n· The game ends immediately when all fifteen cards are in the city and scoring begins.\nPlacement:\n· The new card must share at least one block edge with existing blocks, or cover one or more existing blocks; when cards overlap, the new card sits on top.\n· You cannot tuck a card under existing cards, and touching only at a corner is not allowed; empty holes may remain inside the city.\n· Each card may be rotated by one hundred eighty degrees, but it must stay upright.\nScoring:\n· Block score: for each of the four block types, find its largest connected group of blocks; each block in that group scores one point, then add the four group scores together.\n· Road penalty: each separate road in the city costs one point. A road is a continuous strip of road, and it ends where the road is not connected across a card edge.\n· Condition score: the three conditions score by their own text and may be negative.\n· The total is the block score plus the condition score, minus the road penalty.\nDifficulty:\n· Easy does not subtract road points.\n· Normal scores as described above.\n· Hard counts only the single largest block group among the four types for the block score.\nSolo:\n· Solo play follows the same flow: after each card is placed, refill your hand to three cards until the stack runs out.",
			optDifficulty: "Difficulty",
			optEasy: "Easy",
			optNormal: "Normal",
			optHard: "Hard",
			optHint: "Easy does not subtract road points; hard counts only the largest block group.",
			turnYouPick: "Pick a card, then a spot",
			turnYouPlace: "Rotate if needed, then place",
			turnWait: "Waiting for {{name}} to place a card…",
			turnDone: "City complete — scoring now",
			cityChip: "City {{n}}/{{t}}",
			goalSheetTitle: "Scoring conditions",
			goalPoints: "{{n}} pts",
			goalsAria: "Scoring conditions",
			scoreChip: "Score {{score}} · Target {{target}}",
			difficultyChip: "{{name}} difficulty",
			difficultyEasy: "Easy",
			difficultyNormal: "Normal",
			difficultyHard: "Hard",
			handTitle: "My hand",
			handEmpty: "No cards in hand",
			handCardAria: "Hand card {{n}}",
			deckTitle: "Deck",
			deckTopAria: "Top card of the deck",
			deckCount: "{{n}} cards",
			handCount: "{{n}} cards in hand",
			waitOthers: "Waiting for the other players to place a card",
			selectHint: "Pick a card in your hand to see the legal spots in the city.",
			rotate: "Rotate",
			rotateAria: "Rotate the card you are placing",
			confirm: "Place here",
			recenter: "Back to the city",
			resultTitle: "City scoring",
			resultWin: "Challenge complete",
			resultLose: "Challenge failed",
			resultWinSub: "The total met the target, and this city is finished.",
			resultLoseSub: "The total fell short of the target; everyone can try again.",
			resultBlocks: "Block score",
			resultRoads: "Road penalty",
			resultRoadCount: "{{n}} roads",
			resultGoals: "Scoring conditions",
			resultTotal: "Total",
			resultTarget: "Target",
			resultReview: "Review the city",
			resultReopen: "Scoring",
			zoneR: "Residential",
			zoneC: "Commercial",
			zoneI: "Industrial",
			zoneP: "Park",
			goal1Name: "The Outskirts",
			goal1Text: "Each road that does not end at the edge of the city scores one point; each road that ends at the edge of the city costs one point.",
			goal2Name: "Bloom Boom",
			goal2Text: "Each row or column that contains exactly three park blocks scores one point; a row or column with no park block costs one point.",
			goal3Name: "Go Green",
			goal3Text: "Each park block scores one point; each industrial block costs three points.",
			goal4Name: "Block Party",
			goal4Text: "Count the squares of four blocks of one type in a two-by-two area: zero squares costs eight points, one square costs five, two squares cost two, three squares score one, four squares score four, and five or more squares score seven.",
			goal5Name: "Stacks and Scrapers",
			goal5Text: "Each industrial block that touches only commercial or industrial blocks scores two points.",
			goal6Name: "Master Planned",
			goal6Text: "The size of the largest residential group minus the size of the largest industrial group is the score for this condition and may be negative.",
			goal7Name: "Central Perks",
			goal7Text: "Each park block inside the city scores one point; each park block at the edge of the city costs two points.",
			goal8Name: "The 'Burbs",
			goal8Text: "Each park block next to the largest residential group scores one point, and each industrial block next to it costs two points; if several residential groups tie for largest, use the one that scores best.",
			goal9Name: "Concrete Jungle",
			goal9Text: "Each industrial block that shares a corner or an edge with at least one other industrial block scores one point.",
			goal10Name: "The Strip",
			goal10Text: "Choose one row or one column; the number of commercial blocks in it is the score for this condition.",
			goal11Name: "Mini Marts",
			goal11Text: "Each commercial block that sits between two residential blocks, with one road running through all three blocks in order, scores two points.",
			goal12Name: "Superhighway",
			goal12Text: "The longest road scores one point for each pair of road blocks it contains, ignoring any leftover single block.",
			goal13Name: "Park Hopping",
			goal13Text: "Each road that starts at one park block and ends at another park block scores three points.",
			goal14Name: "Looping Lanes",
			goal14Text: "Each road block that lies on a closed loop scores one point.",
			goal15Name: "Skid Row",
			goal15Text: "Each residential block next to two or more industrial blocks scores two points.",
			goal16Name: "Morning Commute",
			goal16Text: "Each road that passes through both residential and commercial blocks scores two points.",
			goal17Name: "Tourist Traps",
			goal17Text: "Each commercial block at the edge of the city scores one point, and a commercial block at a corner scores one more.",
			goal18Name: "Sprawlopolis",
			goal18Text: "The number of blocks in the longest row plus the number in the longest column is the score for this condition; holes are not counted, but counting continues across them.",
			errPhase: "The game has ended",
			errNotYourTurn: "Not your turn yet",
			errCardNotInHand: "That card is not in your hand",
			errBadPlacement: "The card cannot go there"
		}
	}
};
//#endregion
export { Ge as default };
