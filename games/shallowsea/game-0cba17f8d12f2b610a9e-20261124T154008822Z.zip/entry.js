import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { IconMove as s, IconRecenter as c, IconRotate as l, IconUpdate as u, IconZoomIn as d, IconZoomOut as f } from "@bgparty/sdk/icons";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h, SeatBadgedAvatar as ee, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
//#region src/game/data.ts
var b = [
	"red",
	"yellow",
	"green",
	"purple"
], x = {
	red: "#e15b52",
	yellow: "#f0b429",
	green: "#5fa86a",
	purple: "#9b6bc6"
}, S = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], C = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
], w = [
	{
		r: 0,
		qs: [
			0,
			1,
			2,
			3
		]
	},
	{
		r: 1,
		qs: [
			-1,
			0,
			1,
			2,
			3
		]
	},
	{
		r: 2,
		qs: [
			-1,
			0,
			1,
			2
		]
	},
	{
		r: 3,
		qs: [
			-2,
			-1,
			0,
			1,
			2
		]
	},
	{
		r: 4,
		qs: [
			-2,
			-1,
			0,
			1
		]
	}
], T = /* @__PURE__ */ new Set([
	"0,1",
	"1,1",
	"2,1",
	"-1,2",
	"0,2",
	"1,2",
	"2,2",
	"-1,3",
	"0,3",
	"1,3"
]), E = w.flatMap(({ r: e, qs: t }) => t.map((t) => {
	let n = `${t},${e}`;
	return {
		id: n,
		q: t,
		r: e,
		inner: T.has(n)
	};
})), D = Object.fromEntries(E.map((e) => [e.id, e])), O = E.length;
function k(e, t) {
	return `${e},${t}`;
}
function A(e, t) {
	let n = D[e];
	if (!n) return null;
	let [r, i] = S[t], a = k(n.q + r, n.r + i);
	return D[a] ? a : null;
}
function j(e, t) {
	let n = D[e], [r, i] = C[(t % 4 + 4) % 4];
	return `${2 * n.q + n.r + r},${n.r + i}`;
}
var M = Object.fromEntries(E.map((e) => [`${2 * e.q + e.r},${e.r}`, e.id]));
function N(e) {
	let [t, n] = e.split(",").map(Number);
	return C.map(([e, r]) => M[`${t + e},${n + r}`]).filter((e) => !!e);
}
function P(e) {
	return {
		x: 2 * e.q + e.r,
		y: e.r
	};
}
var F = {
	2: [0, 2],
	3: [
		0,
		1,
		2
	],
	4: [
		0,
		1,
		2,
		3
	]
};
function te() {
	let e = [], t = [
		{
			vp: 5,
			count: 7
		},
		{
			vp: 7,
			count: 7
		},
		{
			vp: 9,
			count: 5
		}
	], n = 0;
	for (let r of b) for (let i of t) {
		let t = F[i.vp === 5 ? 2 : i.vp === 7 ? 3 : 4];
		for (let a = 0; a < i.count; a += 1) {
			let a = [
				null,
				null,
				null,
				null
			];
			t.forEach((e, t) => {
				a[e] = b[(n + t) % b.length];
			}), e.push({
				id: `c${n}`,
				color: r,
				vp: i.vp,
				corners: a
			}), n += 1;
		}
	}
	return e;
}
function ne() {
	return te();
}
var I = {
	A1: {
		id: "A1",
		cls: "A",
		kind: "sameCoral",
		need: 3,
		vp: 10,
		partial: 3,
		offsets: [
			0,
			2,
			4
		]
	},
	A4: {
		id: "A4",
		cls: "A",
		kind: "diffFish",
		need: 3,
		vp: 9,
		partial: 3,
		offsets: [
			1,
			3,
			5
		]
	},
	B1: {
		id: "B1",
		cls: "B",
		kind: "dirSameCoral",
		need: 4,
		vp: 10,
		partial: 2,
		dirs: [0, 3],
		twoWay: !0
	},
	C2: {
		id: "C2",
		cls: "C",
		kind: "diffCoral",
		need: 2,
		vp: 6,
		partial: 2,
		offsets: [0, 3]
	},
	C4: {
		id: "C4",
		cls: "C",
		kind: "dirSameFish",
		need: 2,
		vp: 5,
		partial: 2,
		dirs: [1, 4],
		twoWay: !0
	},
	D1: {
		id: "D1",
		cls: "D",
		kind: "sameCoral",
		need: 3,
		vp: 7,
		partial: 2,
		offsets: [
			1,
			3,
			5
		]
	},
	D4: {
		id: "D4",
		cls: "D",
		kind: "diffFish",
		need: 3,
		vp: 7,
		partial: 2,
		offsets: [
			0,
			2,
			4
		]
	},
	E1: {
		id: "E1",
		cls: "E",
		kind: "dirSameCoral",
		need: 3,
		vp: 8,
		partial: 2,
		dirs: [2],
		twoWay: !1
	},
	E4: {
		id: "E4",
		cls: "E",
		kind: "dirDiffFish",
		need: 3,
		vp: 7,
		partial: 2,
		dirs: [3],
		twoWay: !1
	},
	F2: {
		id: "F2",
		cls: "F",
		kind: "anyAllCoral",
		need: 4,
		vp: 6,
		partial: 1
	}
}, re = [
	"A1",
	"A4",
	"B1",
	"C2",
	"C4",
	"D1",
	"D4",
	"E1",
	"E4",
	"F2"
], L = {
	O1: {
		id: "O1",
		cls: "orange"
	},
	O2: {
		id: "O2",
		cls: "orange"
	},
	O3: {
		id: "O3",
		cls: "orange"
	},
	O4: {
		id: "O4",
		cls: "orange"
	},
	O5: {
		id: "O5",
		cls: "orange"
	},
	O6: {
		id: "O6",
		cls: "orange"
	},
	O7: {
		id: "O7",
		cls: "orange"
	},
	B1: {
		id: "B1",
		cls: "blue"
	},
	B2: {
		id: "B2",
		cls: "blue"
	},
	B3: {
		id: "B3",
		cls: "blue"
	},
	B4: {
		id: "B4",
		cls: "blue"
	},
	B5: {
		id: "B5",
		cls: "blue"
	},
	B6: {
		id: "B6",
		cls: "blue"
	},
	B7: {
		id: "B7",
		cls: "blue"
	}
}, R = Object.values(L).filter((e) => e.cls === "orange").map((e) => e.id), z = Object.values(L).filter((e) => e.cls === "blue").map((e) => e.id);
function B(e) {
	return e >= 4 ? 24 : e === 3 ? 19 : e === 2 ? 14 : 9;
}
function V(e) {
	return e >= 4 ? 4 : e === 3 ? 3 : 2;
}
//#endregion
//#region src/game/meta.ts
var H = {
	id: "shallowsea",
	uuid: "cea5e489-ab47-4de7-81a1-0e46f9f4753e",
	tier: "alpha",
	mechanics: ["tile-placement", "set-collection"],
	interactionTags: [],
	nameKey: "games.shallowsea.name",
	descKey: "games.shallowsea.desc",
	rulesKey: "games.shallowsea.rules",
	icon: "🪸",
	iconImg: "games/shallowsea.webp",
	rulesUrl: { en: "https://c.tabletopia.com/games/shallow-sea/rules/shallow-sea-rulebook/en" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#0e8f9b",
	releasedAt: "2026-11-23T19:57:00+08:00",
	search: {
		py: "qian hai",
		init: "qh"
	},
	hotseat: "open"
}, U = t.enum([
	"red",
	"yellow",
	"green",
	"purple"
]), W = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("refresh"),
		pool: t.enum([
			"coral",
			"sealife",
			"fish"
		])
	}),
	t.object({
		type: t.literal("setupPlace"),
		index: t.int().min(0).max(4),
		cell: t.string(),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("select"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"])
	}),
	t.object({
		type: t.literal("selectAny"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"]),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("placeTile"),
		cell: t.string(),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("placeFish"),
		bubble: t.string().regex(/^-?\d+,-?\d+$/)
	}),
	t.object({
		type: t.literal("moveFish"),
		from: t.string().regex(/^-?\d+,-?\d+$/),
		to: t.string().regex(/^-?\d+,-?\d+$/)
	}),
	t.object({ type: t.literal("endTurn") })
]), ie = t.union([
	t.literal(5),
	t.literal(7),
	t.literal(9)
]), ae = t.object({
	id: t.string(),
	color: U,
	vp: ie,
	corners: t.array(U.nullable()).length(4)
}), oe = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("coral"),
	color: U,
	vp: ie,
	corners: t.array(U.nullable()).length(4),
	rot: t.int().min(0).max(3),
	completed: t.boolean(),
	lockedFish: U.nullable()
}), t.object({
	kind: t.literal("sealife"),
	typeId: t.string(),
	rot: t.int().min(0).max(5),
	completed: t.boolean()
})]), se = t.object({
	cells: t.record(t.string(), oe),
	bubbles: t.record(t.string(), U)
}), G = t.object({
	orange: t.number(),
	blue: t.number(),
	coralVp: t.number(),
	sealifeVp: t.number(),
	partialVp: t.number(),
	variety: t.number(),
	fishBonus: t.number(),
	total: t.number()
}), ce = t.object({
	players: t.array(t.string()),
	boards: t.record(t.string(), se),
	pools: t.object({
		coral: t.array(ae.nullable()).length(5),
		sealife: t.array(t.string().nullable()).length(5),
		fish: t.array(U.nullable()).length(5)
	}),
	ecosystems: t.object({
		orange: t.string(),
		blue: t.string()
	}),
	shells: t.record(t.string(), t.int().min(0).max(5)),
	active: t.string().nullable(),
	phase: t.enum([
		"setup",
		"select",
		"tile",
		"fish",
		"end",
		"done"
	]),
	turnCount: t.int().nonnegative(),
	selection: t.object({
		fish: U,
		fishIdx: t.int(),
		tileKind: t.enum(["coral", "sealife"]),
		coral: ae.nullable(),
		sealife: t.string().nullable()
	}).nullable(),
	lastPlaced: t.object({
		rid: t.string(),
		cell: t.string()
	}).nullable(),
	scores: t.record(t.string(), t.number()).nullable(),
	breakdown: t.record(t.string(), G).nullable()
}), le = t.object({});
t.object({
	orange: t.string().optional(),
	blue: t.string().optional()
});
//#endregion
//#region src/game/rules.ts
function K(e, t) {
	return e.corners[((t - e.rot) % 4 + 4) % 4];
}
function ue(e, t) {
	if (!D[t] || e.cells[t]) return !1;
	let n = D[t];
	return S.some(([t, r]) => {
		let i = `${n.q + t},${n.r + r}`;
		return !!e.cells[i];
	});
}
function q(e) {
	return Object.keys(D).filter((t) => ue(e, t));
}
function J(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of Object.keys(e.cells)) for (let i = 0; i < 4; i += 1) {
		let a = j(r, i);
		n.has(a) || e.bubbles[a] || (n.add(a), t.push(a));
	}
	return t;
}
function de(e, t, n) {
	for (let r = 0; r < 4; r += 1) {
		let i = K(n, r);
		if (i && e.bubbles[j(t, r)] !== i) return !1;
	}
	return !0;
}
function fe(e, t, n) {
	for (let r = 0; r < 4; r += 1) {
		if (!n.corners[r]) continue;
		let i = j(t, (r + n.rot) % 4), a = e.bubbles[i];
		if (a) return {
			key: i,
			color: a
		};
	}
	return null;
}
function Y(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.color : null;
}
function pe(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.lockedFish : null;
}
function me(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	let n = 0;
	for (let e of t.values()) n = Math.max(n, e);
	return n;
}
function he(e) {
	return new Set(e).size;
}
function ge(e, t) {
	let n = [], r = e;
	for (; r = A(r, t), r;) n.push(r);
	return n;
}
function _e(e, t, n, r) {
	let i = (e) => (e + n.rot) % 6;
	switch (r.kind) {
		case "sameCoral": return me((r.offsets ?? []).map((e) => A(t, i(e))).map((t) => t ? Y(e, t) : null).filter((e) => !!e));
		case "diffCoral": return he((r.offsets ?? []).map((e) => A(t, i(e))).map((t) => t ? Y(e, t) : null).filter((e) => !!e));
		case "sameFish": return me((r.offsets ?? []).map((e) => A(t, i(e))).map((t) => t ? pe(e, t) : null).filter((e) => !!e));
		case "diffFish": return he((r.offsets ?? []).map((e) => A(t, i(e))).map((t) => t ? pe(e, t) : null).filter((e) => !!e));
		case "dirSameCoral":
		case "dirDiffCoral":
		case "dirSameFish":
		case "dirDiffFish": {
			let n = (r.dirs ?? []).map(i), a = r.twoWay ? n.flatMap((e) => ge(t, e)) : ge(t, n[0] ?? 0), o = [...new Set(a)], s = r.kind === "dirSameFish" || r.kind === "dirDiffFish", c = o.map((t) => s ? pe(e, t) : Y(e, t)).filter((e) => !!e);
			return r.kind === "dirSameCoral" || r.kind === "dirSameFish" ? me(c) : he(c);
		}
		case "anyAllCoral": return he(Object.keys(e.cells).map((t) => Y(e, t)).filter((e) => !!e));
	}
}
function ve(e, t) {
	e.shells[t] = Math.min(5, (e.shells[t] ?? 0) + 1);
}
function ye(e, t) {
	let n = e.boards[t], r = [];
	for (let i = 0; i < O; i += 1) {
		let i = Object.keys(n.cells).sort().find((e) => {
			let t = n.cells[e];
			return t.kind === "coral" && !t.completed && de(n, e, t);
		});
		if (!i) break;
		let a = n.cells[i], o = fe(n, i, a);
		o && delete n.bubbles[o.key], a.completed = !0, a.lockedFish = o?.color ?? null, ve(e, t), r.push(i);
	}
	for (let i of Object.keys(n.cells).sort()) {
		let a = n.cells[i];
		if (a.kind !== "sealife" || a.completed) continue;
		let o = I[a.typeId];
		o && _e(n, i, a, o) >= o.need && (a.completed = !0, ve(e, t), r.push(i));
	}
	return r.length > 0 ? [{
		kind: "shallow-complete",
		rid: t,
		data: { cells: r }
	}] : [];
}
function be(e) {
	return Object.keys(e.cells).filter((t) => Y(e, t) != null);
}
function xe(e) {
	return Object.keys(e.cells).filter((t) => {
		let n = e.cells[t];
		return n.kind === "sealife" && n.completed;
	});
}
function Se(e) {
	let t = [];
	for (let n of Object.keys(e.cells)) {
		let r = pe(e, n);
		r && t.push({
			cell: n,
			color: r
		});
	}
	return t;
}
function Ce(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of be(e)) {
		let r = Y(e, n);
		t.set(r, (t.get(r) ?? 0) + 1);
	}
	return t;
}
function we(e) {
	let t = e.length;
	if (t < 2) return 0;
	let n = new Map(e.map((e, t) => [e, t])), r = e.map((e) => {
		let t = D[e], r = [];
		for (let [e, i] of S) {
			let a = n.get(`${t.q + e},${t.r + i}`);
			a !== void 0 && r.push(a);
		}
		return r;
	}), i = /* @__PURE__ */ new Map(), a = (e) => {
		if (e === 0) return 0;
		let t = i.get(e);
		if (t !== void 0) return t;
		let n = 31 - Math.clz32(e & -e), o = a(e & ~(1 << n));
		for (let t of r[n]) e & 1 << t && (o = Math.max(o, 1 + a(e & ~(1 << n) & ~(1 << t))));
		return i.set(e, o), o;
	};
	return a((1 << t) - 1);
}
function Te(e, t) {
	let n = be(e), r = xe(e);
	switch (t) {
		case "O1": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish === r.color ? 2 : 0);
		}, 0);
		case "O2": {
			let t = 0;
			for (let n of Ce(e).values()) t += Math.floor(n / 2) * 3;
			return t;
		}
		case "O3": {
			let t = /* @__PURE__ */ new Map();
			for (let n of Se(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) n = Math.max(n, e);
			return Math.min(n * 3, 18);
		}
		case "O4": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish != null && r.lockedFish !== r.color ? 2 : 0);
		}, 0);
		case "O5": {
			let t = /* @__PURE__ */ new Map();
			for (let r of n) {
				let n = D[r].r, i = Y(e, r), a = t.get(n) ?? /* @__PURE__ */ new Map();
				a.set(i, (a.get(i) ?? 0) + 1), t.set(n, a);
			}
			let r = 0;
			for (let e of t.values()) [...e.values()].some((e) => e >= 2) && (r += 4);
			return r;
		}
		case "O6": {
			let e = new Set(n), t = /* @__PURE__ */ new Set(), r = 0;
			for (let i of n) {
				if (t.has(i)) continue;
				let n = [i];
				t.add(i);
				let a = 0;
				for (; n.length > 0;) {
					let r = n.pop();
					a += 1;
					let i = D[r];
					for (let [r, a] of S) {
						let o = `${i.q + r},${i.r + a}`;
						e.has(o) && !t.has(o) && (t.add(o), n.push(o));
					}
				}
				r = Math.max(r, a);
			}
			return r * 2;
		}
		case "O7": {
			let t = /* @__PURE__ */ new Map();
			for (let n of Se(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) e >= 3 && (n += 4);
			return n;
		}
		case "B1": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = D[t].r;
				e.set(n, (e.get(n) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n >= 2 && (t += 4);
			return t;
		}
		case "B2": return r.filter((e) => D[e].inner).length * 3;
		case "B3": return r.filter((t) => {
			let n = D[t];
			return S.some(([t, r]) => {
				let i = e.cells[`${n.q + t},${n.r + r}`];
				return i?.kind === "sealife" && i.completed;
			});
		}).length * 2;
		case "B4": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = D[t], r = 2 * n.q + n.r;
				e.set(r, (e.get(r) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n === 1 && (t += 2);
			return t;
		}
		case "B5": return we(r) * 4;
		case "B6":
		case "B7": {
			let n = t === "B6", r = /* @__PURE__ */ new Set();
			for (let t of Object.keys(e.cells)) {
				if (D[t].inner !== n) continue;
				let i = e.cells[t];
				r.add(i.kind === "coral" ? `c:${i.color}` : `s:${i.typeId}`);
			}
			return r.size * 2;
		}
		default: return 0;
	}
}
function Ee(e) {
	let t = 0;
	for (let n of Object.keys(e.bubbles)) for (let r of N(n)) {
		let n = e.cells[r];
		n && n.kind === "coral" && n.completed && (t += 1);
	}
	return t;
}
function De(e, t) {
	let n = 0;
	for (let t of be(e)) {
		let r = e.cells[t];
		n += r.vp;
	}
	let r = 0, i = 0, a = /* @__PURE__ */ new Set();
	for (let t of Object.keys(e.cells)) {
		let n = e.cells[t];
		if (n.kind !== "sealife") continue;
		let o = I[n.typeId];
		o && (n.completed ? (r += o.vp, a.add(n.typeId)) : i += Math.min(_e(e, t, n, o), o.need) * o.partial);
	}
	let o = a.size * 2, s = Te(e, t.orange), c = Te(e, t.blue), l = Ee(e);
	return {
		orange: s,
		blue: c,
		coralVp: n,
		sealifeVp: r,
		partialVp: i,
		variety: o,
		fishBonus: l,
		total: s + c + n + r + i + o + l
	};
}
function Oe(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.n, i + 1);
		r.n += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function ke(e) {
	let t = V(e);
	return re.flatMap((e) => Array(t).fill(e));
}
function Ae(e) {
	let t = B(e);
	return b.flatMap((e) => Array(t).fill(e));
}
function je(e) {
	for (let t = 0; t < 5; t += 1) e.pools.coral[t] || (e.pools.coral[t] = e.coralDeck.pop() ?? null), e.pools.sealife[t] || (e.pools.sealife[t] = e.sealifeDeck.pop() ?? null), e.pools.fish[t] || (e.pools.fish[t] = e.fishDeck.pop() ?? null);
}
function Me(t, n, r) {
	let i = t ?? {}, a = typeof i.orange == "string" && R.includes(i.orange) ? i.orange : "O1", o = typeof i.blue == "string" && z.includes(i.blue) ? i.blue : "B1", s = { n: 0 }, c = Oe(ne(), r, s), l = Oe(ke(n.length), r, s), u = Oe(Ae(n.length), r, s), d = {}, f = {};
	for (let e of n) d[e] = {
		cells: {},
		bubbles: {}
	}, f[e] = 2;
	let p = n[e(r, s.n, n.length)], m = n.indexOf(p), h = {
		players: [...n],
		boards: d,
		pools: {
			coral: [],
			sealife: [],
			fish: []
		},
		coralDeck: c,
		sealifeDeck: l,
		fishDeck: u,
		ecosystems: {
			orange: a,
			blue: o
		},
		shells: f,
		active: n[(m - 1 + n.length) % n.length],
		phase: "setup",
		turnCount: 0,
		first: p,
		setupPlaced: 0,
		selection: null,
		lastPlaced: null
	};
	for (let e = 0; e < 5; e += 1) h.pools.coral.push(c.pop() ?? null), h.pools.sealife.push(l.pop() ?? null), h.pools.fish.push(u.pop() ?? null);
	return {
		state: h,
		fx: []
	};
}
function Ne() {
	return { code: "games.shallowsea.errNotYourTurn" };
}
function Pe(e) {
	if (e.turnCount += 1, e.turnCount >= e.players.length * 17) {
		e.phase = "done", e.active = null;
		return;
	}
	let t = e.players.indexOf(e.active ?? e.players[0]);
	e.active = e.players[(t + 1) % e.players.length], e.phase = "select";
}
function Fe(e, t, n) {
	if (e.phase === "done" || e.active !== n.by) return Ne();
	let r = structuredClone(e);
	switch (t.type) {
		case "refresh": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = r.pools[t.pool];
			if (i.every((e) => e == null)) return { code: "games.shallowsea.errPoolEmpty" };
			let a = !1;
			if (t.pool === "coral") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.coral) t && e.set(t.color, (e.get(t.color) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			} else if (t.pool === "fish") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.fish) t && e.set(t, (e.get(t) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			}
			if (!a) {
				if ((r.shells[n.by] ?? 0) < 1) return { code: "games.shallowsea.errNoShell" };
				--r.shells[n.by];
			}
			for (let e = 0; e < i.length; e += 1) t.pool === "coral" ? r.pools.coral[e] = r.coralDeck.pop() ?? null : t.pool === "sealife" ? r.pools.sealife[e] = r.sealifeDeck.pop() ?? null : r.pools.fish[e] = r.fishDeck.pop() ?? null;
			return {
				state: r,
				fx: []
			};
		}
		case "setupPlace": {
			if (e.phase !== "setup") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.boards[n.by], a = r.pools.sealife[t.index];
			if (!a) return { code: "games.shallowsea.errPoolEmpty" };
			if (!D[t.cell] || i.cells[t.cell]) return { code: "games.shallowsea.errBadCell" };
			if (i.cells[t.cell] = {
				kind: "sealife",
				typeId: a,
				rot: t.rot,
				completed: !1
			}, r.pools.sealife[t.index] = null, r.setupPlaced += 1, r.lastPlaced = {
				rid: n.by,
				cell: t.cell
			}, r.setupPlaced >= r.players.length) je(r), r.active = r.first, r.phase = "select";
			else {
				let e = r.players.indexOf(r.first);
				r.active = r.players[(e - 1 + r.setupPlaced + r.players.length) % r.players.length];
			}
			return {
				state: r,
				fx: []
			};
		}
		case "select":
		case "selectAny": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = t.fish, a = t.type === "select" ? t.fish : t.index;
			if (t.type === "selectAny" && (r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let o = r.pools.fish[i];
			if (!o) return { code: "games.shallowsea.errPoolEmpty" };
			let s = null, c = null;
			if (t.tile === "coral") {
				if (s = r.pools.coral[a] ?? null, !s) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.coral[a] = null;
			} else {
				if (c = r.pools.sealife[a] ?? null, !c) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.sealife[a] = null;
			}
			return r.pools.fish[i] = null, t.type === "selectAny" && (r.shells[n.by] -= 2), r.selection = {
				fish: o,
				fishIdx: i,
				tileKind: t.tile,
				coral: s,
				sealife: c
			}, r.phase = "tile", {
				state: r,
				fx: []
			};
		}
		case "placeTile": {
			if (e.phase !== "tile") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			if (!ue(a, t.cell)) return { code: "games.shallowsea.errBadCell" };
			if (i.tileKind === "coral" && i.coral) {
				if (t.rot > 3) return { code: "games.shallowsea.errBadRotate" };
				a.cells[t.cell] = {
					kind: "coral",
					color: i.coral.color,
					vp: i.coral.vp,
					corners: [...i.coral.corners],
					rot: t.rot,
					completed: !1,
					lockedFish: null
				};
			} else if (i.tileKind === "sealife" && i.sealife) a.cells[t.cell] = {
				kind: "sealife",
				typeId: i.sealife,
				rot: t.rot,
				completed: !1
			};
			else return { code: "games.shallowsea.errNoSelection" };
			return r.lastPlaced = {
				rid: n.by,
				cell: t.cell
			}, r.phase = "fish", {
				state: r,
				fx: ye(r, n.by)
			};
		}
		case "placeFish": {
			if (e.phase !== "fish") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			return a.bubbles[t.bubble] || !N(t.bubble).some((e) => a.cells[e]) ? { code: "games.shallowsea.errBadBubble" } : (a.bubbles[t.bubble] = i.fish, r.phase = "end", {
				state: r,
				fx: ye(r, n.by)
			});
		}
		case "moveFish": {
			if (e.phase !== "tile" && e.phase !== "fish" && e.phase !== "end") return { code: "games.shallowsea.errWrongPhase" };
			if ((r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let i = r.boards[n.by], a = i.bubbles[t.from];
			return !a || i.bubbles[t.to] || !N(t.to).some((e) => i.cells[e]) ? { code: "games.shallowsea.errBadBubble" } : (delete i.bubbles[t.from], i.bubbles[t.to] = a, r.shells[n.by] -= 2, {
				state: r,
				fx: ye(r, n.by)
			});
		}
		case "endTurn": return e.phase === "end" ? (r.selection = null, je(r), Pe(r), {
			state: r,
			fx: []
		}) : { code: "games.shallowsea.errWrongPhase" };
	}
	return { code: "games.shallowsea.errWrongPhase" };
}
function Ie(e) {
	let t = e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, De(e.boards[t], e.ecosystems)])) : null, n = t ? Object.fromEntries(Object.entries(t).map(([e, t]) => [e, t.total])) : null;
	return {
		public: {
			players: e.players,
			boards: e.boards,
			pools: e.pools,
			ecosystems: e.ecosystems,
			shells: e.shells,
			active: e.active,
			phase: e.phase,
			turnCount: e.turnCount,
			selection: e.selection,
			lastPlaced: e.lastPlaced,
			scores: n,
			breakdown: t
		},
		private: {}
	};
}
function Le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => ({
		rid: t,
		...De(e.boards[t], e.ecosystems)
	})), n = Object.fromEntries(t.map((e) => [e.rid, e.total])), r = new Map(e.players.map((e, t) => [e, t])), i = [...e.players].sort((t, i) => {
		if (n[i] !== n[t]) return n[i] - n[t];
		let a = (e.shells[i] ?? 0) - (e.shells[t] ?? 0);
		return a === 0 ? (r.get(t) ?? 0) - (r.get(i) ?? 0) : a;
	}), a = i[0];
	return {
		phase: "done",
		winner: i.filter((t) => n[t] === n[a] && (e.shells[t] ?? 0) === (e.shells[a] ?? 0)),
		ranking: i,
		scores: n
	};
}
var Re = {
	saveCompatibility: {
		version: "3",
		migrate: () => null
	},
	meta: H,
	schemas: {
		action: W,
		publicView: ce,
		privateView: le
	},
	setup: Me,
	reduce: Fe,
	viewFor: Ie,
	status: Le
}, ze = .74, X = .27, Be = [
	[1, -.27],
	[1, X],
	[X, 1],
	[-.27, 1],
	[-1, X],
	[-1, -.27],
	[-.27, -1],
	[X, -1]
], Ve = [
	[[1, -.27], [1, X]],
	[[1, -.27], [X, -1]],
	[[-.27, -1], [-1, -.27]],
	[[-1, X], [-1, -.27]],
	[[-1, X], [-.27, 1]],
	[[X, 1], [1, X]]
].map(([e, t]) => [(e[0] + t[0]) / 2, (e[1] + t[1]) / 2]), He = [
	[[-.27, -1], [X, -1]],
	[[1, -.27], [1, X]],
	[[X, 1], [-.27, 1]],
	[[-1, X], [-1, -.27]]
], Ue = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
], We = [
	-90,
	0,
	90,
	180
], Ge = .52, Z = {
	x: -2.6,
	y: -1.2,
	w: 11.2,
	h: 6.4
}, Ke = `${Z.x} ${Z.y} ${Z.w} ${Z.h}`, qe = 3, Je = 1.4, Ye = 1.6, Xe = {
	scale: 1,
	cx: Z.x + Z.w / 2,
	cy: Z.y + Z.h / 2
};
function Ze(e) {
	let t = Z.w / e.scale, n = Z.h / e.scale;
	return {
		x: e.cx - t / 2,
		y: e.cy - n / 2,
		w: t,
		h: n
	};
}
function Qe(e) {
	let t = Math.min(qe, Math.max(1, e.scale)), n = Z.w / t, r = Z.h / t;
	return {
		scale: t,
		cx: Math.min(Z.x + Z.w - n / 2, Math.max(Z.x + n / 2, e.cx)),
		cy: Math.min(Z.y + Z.h - r / 2, Math.max(Z.y + r / 2, e.cy))
	};
}
function $e(e, t) {
	return Math.min(t.w / e.w, t.h / e.h);
}
function et(e, t, n, r) {
	let i = $e(n, r), a = (r.w - n.w * i) / 2, o = (r.h - n.h * i) / 2;
	return {
		x: n.x + (e - a) / i,
		y: n.y + (t - o) / i
	};
}
function tt(e, t, n, r, i, a) {
	let o = Qe({
		...e,
		scale: i
	}), s = $e(Ze(o), a);
	return Qe({
		scale: o.scale,
		cx: t.x - (n - a.w / 2) / s,
		cy: t.y - (r - a.h / 2) / s
	});
}
var nt = {
	red: "games.shallowsea.fishRed",
	yellow: "games.shallowsea.fishYellow",
	green: "games.shallowsea.fishGreen",
	purple: "games.shallowsea.fishPurple"
}, rt = {
	A1: "games.shallowsea.slSameCoral3",
	A4: "games.shallowsea.slDiffFish3",
	B1: "games.shallowsea.slDirSameCoral4",
	C2: "games.shallowsea.slDiffCoral2",
	C4: "games.shallowsea.slDirSameFish2",
	D1: "games.shallowsea.slSameCoral3",
	D4: "games.shallowsea.slDiffFish3",
	E1: "games.shallowsea.slDirSameCoral3",
	E4: "games.shallowsea.slDirDiffFish3",
	F2: "games.shallowsea.slAnyAllCoral"
}, it = {
	O1: "games.shallowsea.ecoO1",
	O2: "games.shallowsea.ecoO2",
	O3: "games.shallowsea.ecoO3",
	O4: "games.shallowsea.ecoO4",
	O5: "games.shallowsea.ecoO5",
	O6: "games.shallowsea.ecoO6",
	O7: "games.shallowsea.ecoO7",
	B1: "games.shallowsea.ecoB1",
	B2: "games.shallowsea.ecoB2",
	B3: "games.shallowsea.ecoB3",
	B4: "games.shallowsea.ecoB4",
	B5: "games.shallowsea.ecoB5",
	B6: "games.shallowsea.ecoB6",
	B7: "games.shallowsea.ecoB7"
}, at = {
	O1: "games.shallowsea.ecoO1Cond",
	O2: "games.shallowsea.ecoO2Cond",
	O3: "games.shallowsea.ecoO3Cond",
	O4: "games.shallowsea.ecoO4Cond",
	O5: "games.shallowsea.ecoO5Cond",
	O6: "games.shallowsea.ecoO6Cond",
	O7: "games.shallowsea.ecoO7Cond",
	B1: "games.shallowsea.ecoB1Cond",
	B2: "games.shallowsea.ecoB2Cond",
	B3: "games.shallowsea.ecoB3Cond",
	B4: "games.shallowsea.ecoB4Cond",
	B5: "games.shallowsea.ecoB5Cond",
	B6: "games.shallowsea.ecoB6Cond",
	B7: "games.shallowsea.ecoB7Cond"
};
function ot(e, t, n = 1) {
	return Be.map(([r, i]) => `${e + r * ze * n},${t + i * ze * n}`).join(" ");
}
function Q(e, t, n = 1) {
	return Be.map(([r, i]) => `${e + r * n},${t + i * n}`).join(" ");
}
function st(e) {
	return rt[e] ?? null;
}
function ct(e) {
	let t = e.public;
	return /* @__PURE__ */ v(dt, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function lt(e) {
	return {
		key: e,
		fishPick: null,
		setupPick: null,
		freeMode: !1,
		pendingCell: null,
		rot: 0,
		movingFrom: !1,
		moveFrom: null
	};
}
function ut(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!n) continue;
		let e = typeof n == "string" ? n : n.color;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	return [...t.values()].some((e) => e >= 4);
}
function dt({ pub: e, members: t, myRid: c, send: u }) {
	let d = o(), f = a((e) => e.locale), b = r(null), [x, S] = i(1);
	n(() => {
		let e = b.current, t = window.matchMedia("(orientation: landscape)"), n = () => {
			let { width: n, height: r } = e.getBoundingClientRect();
			S(t.matches && n >= 900 && r >= 520 ? Math.max(1, Math.min(n / 900, r / 640, 1.5)) : 1);
		}, r = new ResizeObserver(n);
		return r.observe(e), t.addEventListener("change", n), n(), () => {
			r.disconnect(), t.removeEventListener("change", n);
		};
	}, []);
	let C = (e) => t.find((t) => t.rid === e)?.name ?? e, w = e.boards[c], T = e.shells[c] ?? 0, O = e.selection, k = e.phase, A = e.active === c, j = `${e.turnCount}:${k}:${e.active ?? ""}`, [M, N] = i(() => lt(j));
	M.key !== j && N(lt(j));
	let P = (e) => N((t) => ({
		...t,
		...e
	})), F = M.freeMode && T >= 2, te = ut(e.pools.coral), ne = ut(e.pools.fish), I = "info", re;
	if (k === "done") I = "done", re = d("games.shallowsea.doneBanner");
	else if (A) I = "accent", re = k === "setup" ? d("games.shallowsea.setupPrompt") : k === "select" ? d(F ? "games.shallowsea.selectAnyMode" : "games.shallowsea.selectPrompt") : k === "tile" ? d("games.shallowsea.tilePrompt") : k === "fish" ? d("games.shallowsea.fishPrompt", { fish: O ? d(nt[O.fish]) : "" }) : M.movingFrom ? d("games.shallowsea.movingFrom") : M.moveFrom ? d("games.shallowsea.movingTo") : d("games.shallowsea.endPrompt");
	else {
		let t = e.active ? C(e.active) : "";
		re = d(k === "setup" ? "games.shallowsea.setupWaiting" : k === "select" ? "games.shallowsea.selectWaiting" : "games.shallowsea.waitingFor", { name: t });
	}
	let L = k === "setup" && M.setupPick != null ? e.pools.sealife[M.setupPick] ?? null : null, R = k === "setup" && w && L ? E.filter((e) => !w.cells[e.id]).map((e) => e.id) : [], z = k === "tile" && w ? q(w) : R, B, V;
	k === "fish" && w ? (B = new Set(J(w)), V = (e) => u({
		type: "placeFish",
		bubble: e
	})) : k === "end" && w && M.movingFrom ? (B = new Set(Object.keys(w.bubbles)), V = (e) => P({
		movingFrom: !1,
		moveFrom: e
	})) : k === "end" && w && M.moveFrom && (B = new Set(J(w)), V = (e) => {
		M.moveFrom != null && u({
			type: "moveFish",
			from: M.moveFrom,
			to: e
		});
	});
	let U = (() => {
		if (k === "tile" && O) {
			if (O.tileKind === "coral" && O.coral) return {
				kind: "coral",
				color: O.coral.color,
				vp: O.coral.vp,
				corners: O.coral.corners,
				rot: M.rot,
				completed: !1,
				lockedFish: null
			};
			if (O.tileKind === "sealife" && O.sealife) return {
				kind: "sealife",
				typeId: O.sealife,
				rot: M.rot,
				completed: !1
			};
		}
		return k === "setup" && L ? {
			kind: "sealife",
			typeId: L,
			rot: M.rot,
			completed: !1
		} : null;
	})(), W = U && M.pendingCell ? {
		cell: M.pendingCell,
		tile: U
	} : null, ie = W && W.tile.kind === "sealife" ? mt(W.tile.typeId, W.cell, M.rot) : void 0, ae = e.lastPlaced && e.lastPlaced.rid === c ? e.lastPlaced.cell : null, oe = A && M.pendingCell != null && (k === "tile" && O != null || k === "setup" && L != null), se = U?.kind === "coral" ? 4 : 6, G = () => {
		M.pendingCell && (k === "setup" ? M.setupPick != null && u({
			type: "setupPlace",
			index: M.setupPick,
			cell: M.pendingCell,
			rot: M.rot
		}) : u({
			type: "placeTile",
			cell: M.pendingCell,
			rot: M.rot
		}));
	}, ce = /* @__PURE__ */ y("div", {
		className: "shallowsea-banner flex flex-col",
		children: [
			/* @__PURE__ */ v(m, {
				tone: I,
				text: re,
				accent: H.accent
			}),
			/* @__PURE__ */ v("div", {
				className: "shallowsea-strip-wide",
				children: /* @__PURE__ */ v(h, {
					variant: "plate",
					members: t,
					myRid: c,
					status: (t) => {
						let n = e.scores?.[t];
						return /* @__PURE__ */ y("span", {
							className: "shallowsea-player-status",
							children: [/* @__PURE__ */ y("span", {
								className: "shallowsea-count",
								children: [/* @__PURE__ */ v(vt, { size: 13 }), d("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 })]
							}), n != null && /* @__PURE__ */ v("span", {
								className: "shallowsea-player-score",
								children: d("games.shallowsea.scoreShort", { n })
							})]
						});
					},
					action: (t) => e.active === t && k !== "done" ? "pending" : null
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "shallowsea-strip-short",
				children: t.map((t) => /* @__PURE__ */ y("span", {
					className: "shallowsea-shortseat",
					children: [
						/* @__PURE__ */ v(ee, {
							m: t,
							myRid: c,
							action: e.active === t.rid && k !== "done" ? "pending" : null,
							anchorName: null,
							box: "size-6",
							img: "size-5"
						}),
						/* @__PURE__ */ v("span", {
							className: "shallowsea-shortname",
							children: g(t, f)
						}),
						/* @__PURE__ */ y("span", {
							className: "shallowsea-shortshells",
							children: [/* @__PURE__ */ v(vt, { size: 12 }), d("games.shallowsea.shellsShort", { n: e.shells[t.rid] ?? 0 })]
						})
					]
				}, t.rid))
			})
		]
	}), le = (() => {
		if (k === "done") return /* @__PURE__ */ v("div", { className: "shallowsea-tray" });
		if (!A) return /* @__PURE__ */ v("div", { className: "shallowsea-tray shallowsea-tray-idle" });
		if (k === "setup") return /* @__PURE__ */ y("div", {
			className: "shallowsea-tray is-setup",
			children: [U && U.kind === "sealife" && /* @__PURE__ */ y("div", {
				className: "shallowsea-pending is-setup-preview",
				children: [/* @__PURE__ */ v(Vt, { tile: U }), /* @__PURE__ */ v("span", {
					className: "shallowsea-pending-text",
					children: ft(U.typeId, d)
				})]
			}), /* @__PURE__ */ v("div", {
				className: "shallowsea-pool-row is-setup",
				role: "group",
				"aria-label": d("games.shallowsea.sealifePool"),
				children: e.pools.sealife.map((e, t) => /* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-chip",
					"data-selected": M.setupPick === t,
					disabled: !A || !e,
					"aria-label": e ? d("games.shallowsea.sealifeAria", {
						id: e,
						desc: ft(e, d)
					}) : d("games.shallowsea.poolEmpty"),
					onClick: () => P({
						setupPick: t,
						pendingCell: null
					}),
					children: e ? /* @__PURE__ */ v(Bt, { typeId: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
				}, t))
			})]
		});
		if (k === "select") {
			let t = (e) => M.fishPick != null && (F || M.fishPick === e);
			return /* @__PURE__ */ y("div", {
				className: "shallowsea-tray",
				children: [
					/* @__PURE__ */ v("div", {
						className: "shallowsea-tray-head",
						children: /* @__PURE__ */ y("button", {
							type: "button",
							className: "shallowsea-free",
							"data-on": F,
							"aria-pressed": F,
							disabled: T < 2 && !F,
							onClick: () => P({ freeMode: !M.freeMode }),
							children: [
								d("games.shallowsea.anyMode"),
								" · ",
								d("games.shallowsea.anyModeCost")
							]
						})
					}),
					/* @__PURE__ */ v(Ut, {
						pool: "coral",
						label: d("games.shallowsea.coralPool"),
						refreshLabel: d("games.shallowsea.refreshCoral"),
						cost: d(te ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !te && T < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "coral"
						}),
						children: e.pools.coral.map((e, n) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? d("games.shallowsea.coralAria", { vp: e.vp }) : d("games.shallowsea.poolEmpty"),
							onClick: () => M.fishPick != null && u(F ? {
								type: "selectAny",
								fish: M.fishPick,
								tile: "coral",
								index: n
							} : {
								type: "select",
								fish: M.fishPick,
								tile: "coral"
							}),
							children: e ? /* @__PURE__ */ v(Pt, { coral: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, n))
					}),
					/* @__PURE__ */ v(Ut, {
						pool: "fish",
						label: d("games.shallowsea.fishPool"),
						refreshLabel: d("games.shallowsea.refreshFish"),
						cost: d(ne ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !ne && T < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "fish"
						}),
						children: e.pools.fish.map((e, t) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === t,
							disabled: !e,
							"aria-label": d(e ? nt[e] : "games.shallowsea.poolEmpty"),
							onClick: () => e && P({ fishPick: M.fishPick === t ? null : t }),
							children: e ? /* @__PURE__ */ v(Ht, { color: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, t))
					}),
					/* @__PURE__ */ v(Ut, {
						pool: "sealife",
						label: d("games.shallowsea.sealifePool"),
						refreshLabel: d("games.shallowsea.refreshSealife"),
						cost: d("games.shallowsea.refreshCost"),
						refreshDisabled: T < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "sealife"
						}),
						children: e.pools.sealife.map((e, n) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? d("games.shallowsea.sealifeAria", {
								id: e,
								desc: ft(e, d)
							}) : d("games.shallowsea.poolEmpty"),
							onClick: () => M.fishPick != null && u(F ? {
								type: "selectAny",
								fish: M.fishPick,
								tile: "sealife",
								index: n
							} : {
								type: "select",
								fish: M.fishPick,
								tile: "sealife"
							}),
							children: e ? /* @__PURE__ */ v(Bt, { typeId: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, n))
					})
				]
			});
		}
		if (k === "tile") {
			let e = O?.tileKind === "sealife" && O.sealife ? st(O.sealife) : null;
			return /* @__PURE__ */ v("div", {
				className: "shallowsea-tray shallowsea-tray-actions",
				children: U && /* @__PURE__ */ y("div", {
					className: "shallowsea-pending",
					children: [/* @__PURE__ */ v(Vt, { tile: U }), /* @__PURE__ */ y("div", {
						className: "shallowsea-pending-info",
						children: [e && /* @__PURE__ */ v("span", {
							className: "shallowsea-pending-text",
							children: d(e)
						}), M.pendingCell && /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-btn",
							onClick: () => P({ pendingCell: null }),
							children: d("games.shallowsea.cancel")
						})]
					})]
				})
			});
		}
		return k === "fish" ? /* @__PURE__ */ v("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ y("div", {
				className: "shallowsea-pending",
				children: [O && /* @__PURE__ */ v(Ht, {
					color: O.fish,
					size: 40
				}), /* @__PURE__ */ v("span", {
					className: "shallowsea-pending-text",
					children: O ? d("games.shallowsea.fishPrompt", { fish: d(nt[O.fish]) }) : d("games.shallowsea.selectPrompt")
				})]
			})
		}) : /* @__PURE__ */ v("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ y("div", {
				className: "shallowsea-buttons",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-btn is-primary",
					onClick: () => u({ type: "endTurn" }),
					children: d("games.shallowsea.endTurn")
				}), !M.movingFrom && !M.moveFrom ? /* @__PURE__ */ y("button", {
					type: "button",
					className: "shallowsea-btn",
					disabled: T < 2,
					onClick: () => P({ movingFrom: !0 }),
					children: [/* @__PURE__ */ v(s, {
						size: 16,
						"aria-hidden": !0
					}), /* @__PURE__ */ y("span", { children: [
						d("games.shallowsea.moveFish"),
						" · ",
						d("games.shallowsea.moveCost")
					] })]
				}) : /* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-btn",
					onClick: () => P({
						movingFrom: !1,
						moveFrom: null
					}),
					children: d("games.shallowsea.cancelMove")
				})]
			})
		});
	})();
	return /* @__PURE__ */ v("div", {
		ref: b,
		className: "shallowsea-screen h-full min-h-0",
		style: { "--shallowsea-ui-scale": x },
		children: /* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "shallowsea-game",
			scroll: k === "done",
			banner: ce,
			actions: le,
			actionsHeight: "shallowsea-actions",
			children: /* @__PURE__ */ y("div", {
				className: `shallowsea-table${k === "done" ? " is-done" : ""}`,
				children: [
					k === "done" && /* @__PURE__ */ v(Wt, {
						pub: e,
						nameOf: C
					}),
					/* @__PURE__ */ v("section", {
						className: "shallowsea-main",
						children: /* @__PURE__ */ v(ht, {
							board: w,
							label: d("games.shallowsea.myBoard"),
							placeAria: (e) => {
								let t = D[e];
								return t ? d("games.shallowsea.placeAria", {
									row: t.r + 1,
									col: t.q + 3
								}) : "";
							},
							fishAria: (e) => d(nt[e]),
							bubbleAria: d("games.shallowsea.emptyBubbleAria"),
							legalCells: A ? new Set(z) : void 0,
							onCell: A ? (e) => P({ pendingCell: e }) : void 0,
							bubbleTargets: A ? B : void 0,
							onBubble: A ? V : void 0,
							markers: ie,
							preview: W,
							lastPlaced: ae,
							zoomable: !0,
							controlsCell: oe ? M.pendingCell : null,
							controlsScale: x,
							controls: oe ? /* @__PURE__ */ y(_, { children: [
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-rotate",
									"aria-label": d("games.shallowsea.rotateLeft"),
									onClick: () => P({ rot: (M.rot + se - 1) % se }),
									children: /* @__PURE__ */ v(l, {
										size: 20,
										className: "shallowsea-mirror",
										"aria-hidden": !0
									})
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-rotate",
									"aria-label": d("games.shallowsea.rotateRight"),
									onClick: () => P({ rot: (M.rot + 1) % se }),
									children: /* @__PURE__ */ v(l, {
										size: 20,
										"aria-hidden": !0
									})
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-confirm",
									onClick: G,
									children: d("games.shallowsea.confirmPlace")
								})
							] }) : void 0
						})
					}),
					/* @__PURE__ */ y("div", {
						className: "shallowsea-side",
						children: [e.players.length > 1 && /* @__PURE__ */ v("aside", {
							className: "shallowsea-others",
							children: e.players.filter((e) => e !== c).map((t) => /* @__PURE__ */ y("div", {
								className: "shallowsea-mini",
								children: [/* @__PURE__ */ y("div", {
									className: "shallowsea-mini-head",
									children: [/* @__PURE__ */ v("span", {
										className: "truncate",
										children: C(t)
									}), /* @__PURE__ */ y("span", {
										className: "shallowsea-count font-mono tabular-nums",
										children: [/* @__PURE__ */ v(vt, { size: 12 }), d("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 })]
									})]
								}), /* @__PURE__ */ v(ht, {
									board: e.boards[t],
									label: d("games.shallowsea.boardOf", { name: C(t) })
								})]
							}, t))
						}), /* @__PURE__ */ v(pt, { pub: e })]
					})
				]
			})
		})
	});
}
function ft(e, t) {
	let n = st(e);
	return n ? t(n) : e;
}
function pt({ pub: e }) {
	let t = o(), n = it[e.ecosystems.orange] ?? null, r = it[e.ecosystems.blue] ?? null, i = at[e.ecosystems.orange], a = at[e.ecosystems.blue];
	return !n && !r ? null : /* @__PURE__ */ y("section", {
		className: "shallowsea-eco",
		"aria-label": t("games.shallowsea.ecoCards"),
		children: [/* @__PURE__ */ v("div", {
			className: "shallowsea-eco-head",
			children: t("games.shallowsea.ecoCards")
		}), /* @__PURE__ */ y("div", {
			className: "shallowsea-eco-cards",
			children: [n && /* @__PURE__ */ y("div", {
				className: "shallowsea-eco-card is-orange",
				children: [/* @__PURE__ */ y("div", {
					className: "shallowsea-eco-top",
					children: [/* @__PURE__ */ v("span", {
						className: "shallowsea-eco-tag",
						children: t("games.shallowsea.ecoOrange")
					}), /* @__PURE__ */ v("span", {
						className: "shallowsea-eco-name",
						children: t(n)
					})]
				}), i && /* @__PURE__ */ v("p", {
					className: "shallowsea-eco-cond",
					children: t(i)
				})]
			}), r && /* @__PURE__ */ y("div", {
				className: "shallowsea-eco-card is-blue",
				children: [/* @__PURE__ */ y("div", {
					className: "shallowsea-eco-top",
					children: [/* @__PURE__ */ v("span", {
						className: "shallowsea-eco-tag",
						children: t("games.shallowsea.ecoBlue")
					}), /* @__PURE__ */ v("span", {
						className: "shallowsea-eco-name",
						children: t(r)
					})]
				}), a && /* @__PURE__ */ v("p", {
					className: "shallowsea-eco-cond",
					children: t(a)
				})]
			})]
		})]
	});
}
function mt(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = I[e];
	if (!i) return r;
	for (let e of i.offsets ?? []) {
		let i = A(t, (e + n) % 6);
		i && r.add(i);
	}
	for (let e of i.dirs ?? []) {
		let i = t;
		for (;;) {
			let t = A(i, (e + n) % 6);
			if (!t) break;
			r.add(t), i = t;
		}
	}
	return r;
}
function ht({ board: e, label: t, placeAria: a, fishAria: s, bubbleAria: l, legalCells: u, onCell: p, bubbleTargets: m, onBubble: h, markers: ee, preview: g, lastPlaced: _, controls: b, controlsCell: x, controlsScale: S = 1, zoomable: C = !1 }) {
	let w = o(), T = r(null), O = r(null), k = r(null), [A, M] = i({
		w: 0,
		h: 0
	}), [N, F] = i({
		w: 214,
		h: 46
	}), [te, ne] = i(200), [I, re] = i(() => C && typeof window < "u" && window.innerWidth < 700 && window.innerHeight >= 520 ? Qe({
		...Xe,
		scale: Ye
	}) : Xe), L = r(I), R = r(/* @__PURE__ */ new Map()), z = r(0), B = r(0), V = r(null), H = (e) => {
		let t = Qe(e);
		L.current = t, re(t);
	};
	n(() => {
		let e = T.current, t = () => M({
			w: e.clientWidth,
			h: e.clientHeight
		}), n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, []), n(() => {
		let e = k.current;
		if (!e) return;
		let t = () => {
			F({
				w: e.offsetWidth,
				h: e.offsetHeight
			});
			let t = parseFloat(getComputedStyle(e).getPropertyValue("--shallowsea-ui-scale")) || 1;
			t > 0 && ne(e.offsetWidth / t);
		}, n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, [x]), n(() => {
		let e = O.current, t = T.current;
		if (!C || !e || !t) return;
		let n = (e) => {
			e.preventDefault();
			let n = t.getBoundingClientRect(), r = {
				w: n.width,
				h: n.height
			}, i = Ze(L.current), a = et(e.clientX - n.left, e.clientY - n.top, i, r), o = e.deltaY < 0 ? 1.15 : 1 / 1.15;
			H(tt(L.current, a, e.clientX - n.left, e.clientY - n.top, L.current.scale * o, r));
		};
		return e.addEventListener("wheel", n, { passive: !1 }), () => e.removeEventListener("wheel", n);
	}, [C]), n(() => {
		if (!C) return;
		let e = (e) => {
			R.current.delete(e.pointerId), R.current.size < 2 && (V.current = null);
		};
		return window.addEventListener("pointerup", e), window.addEventListener("pointercancel", e), () => {
			window.removeEventListener("pointerup", e), window.removeEventListener("pointercancel", e);
		};
	}, [C]);
	let U = (e) => {
		let t = T.current.getBoundingClientRect();
		return {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		};
	}, W = (e) => {
		if (C) {
			if (R.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), R.current.size === 1) z.current = 0, B.current = 0;
			else if (R.current.size === 2) {
				let [e, t] = [...R.current.values()], n = U({
					clientX: (e.x + t.x) / 2,
					clientY: (e.y + t.y) / 2
				}), r = Ze(L.current);
				V.current = {
					dist: Math.max(1, Math.hypot(t.x - e.x, t.y - e.y)),
					view: L.current,
					anchor: et(n.x, n.y, r, A)
				}, z.current = 99, B.current = performance.now() + 400;
			}
		}
	}, ie = (e) => {
		if (!C) return;
		if (e.pointerType === "mouse" && e.buttons === 0) {
			R.current.delete(e.pointerId), V.current = null;
			return;
		}
		let t = R.current.get(e.pointerId);
		if (t) {
			if (R.current.size === 1) {
				let n = e.clientX - t.x, r = e.clientY - t.y;
				z.current += Math.abs(n) + Math.abs(r), z.current > 8 && (B.current = performance.now() + 400);
				let i = $e(Ze(L.current), A);
				H({
					...L.current,
					cx: L.current.cx - n / i,
					cy: L.current.cy - r / i
				}), R.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				return;
			}
			if (R.current.size === 2) {
				R.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				let t = V.current;
				if (!t) return;
				let [n, r] = [...R.current.values()], i = U({
					clientX: (n.x + r.x) / 2,
					clientY: (n.y + r.y) / 2
				}), a = Math.max(1, Math.hypot(r.x - n.x, r.y - n.y));
				H(tt(t.view, t.anchor, i.x, i.y, t.view.scale * (a / t.dist), A)), z.current = 99, B.current = performance.now() + 400;
			}
		}
	}, ae = (e) => {
		C && (R.current.size === 1 && z.current > 8 && (B.current = performance.now() + 400), R.current.delete(e.pointerId), V.current = null);
	}, oe = (e) => {
		R.current.delete(e.pointerId), V.current = null;
	}, se = (e) => {
		performance.now() >= B.current || O.current?.contains(e.target) && (e.preventDefault(), e.stopPropagation());
	}, G = Ze(I), ce = `${Math.round(G.x * 1e4) / 1e4} ${Math.round(G.y * 1e4) / 1e4} ${Math.round(G.w * 1e4) / 1e4} ${Math.round(G.h * 1e4) / 1e4}`, le = [], K = /* @__PURE__ */ new Set();
	for (let e of E) {
		let t = P(e);
		for (let n = 0; n < 4; n += 1) {
			let r = j(e.id, n);
			if (K.has(r)) continue;
			K.add(r);
			let [i, a] = Ue[n];
			le.push({
				key: r,
				corner: n,
				x: t.x + i,
				y: t.y + a
			});
		}
	}
	let ue = g ? D[g.cell] : null, q = ue ? P(ue) : null, J = x ? D[x] : null, de = S * (A.w && te > 0 ? Math.min(1, (A.w - 16) / te) : 1), fe = (() => {
		if (!b || !J || !A.w || !A.h) return null;
		let e = P(J), t = $e(G, A), n = (A.w - G.w * t) / 2, r = (A.h - G.h * t) / 2, i = (e.x - G.x) * t + n, a = (e.y - G.y) * t + r, o = N.w / 2, s = N.h / 2, c = a + t + 10 * de + s, l = a - t - 10 * de - s, d = (e) => e >= s + 8 && e <= A.h - s - 8, f = Math.max(o + 8, Math.min(A.w - o - 8, i)), p = [...u ?? []].filter((e) => e !== x && D[e]).map((e) => P(D[e])), m = (e) => p.reduce((i, a) => i + +(Math.abs((a.x - G.x) * t + n - f) < o + t && Math.abs((a.y - G.y) * t + r - e) < s + t), 0), h = d(c), ee = d(l);
		return {
			left: f,
			top: h && ee ? m(c) <= m(l) ? c : l : h ? c : ee ? l : Math.max(s + 8, Math.min(A.h - s - 8, c))
		};
	})();
	return /* @__PURE__ */ y("div", {
		ref: T,
		className: `shallowsea-board-frame${C ? " is-zoomable" : ""}`,
		onClickCapture: C ? se : void 0,
		children: [
			/* @__PURE__ */ v(gt, {}),
			/* @__PURE__ */ y("svg", {
				ref: O,
				viewBox: ce,
				className: `shallowsea-board-svg${C ? " is-zoomable" : ""}`,
				role: "group",
				"aria-label": t,
				onPointerDown: C ? W : void 0,
				onPointerMove: C ? ie : void 0,
				onPointerUp: C ? ae : void 0,
				onPointerCancel: C ? oe : void 0,
				children: [
					E.map((t) => {
						let n = P(t), r = e?.cells[t.id], i = !!(u?.has(t.id) && p);
						return /* @__PURE__ */ y("g", { children: [
							/* @__PURE__ */ v("polygon", {
								points: ot(n.x, n.y, .985),
								className: `shallowsea-hex${i ? " is-legal" : ""}`,
								onClick: i && p ? () => p(t.id) : void 0,
								onKeyDown: i && p ? (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), p(t.id));
								} : void 0,
								role: i ? "button" : void 0,
								tabIndex: i ? 0 : void 0,
								"aria-label": i && a ? a(t.id) : void 0
							}),
							ee?.has(t.id) && /* @__PURE__ */ v("polygon", {
								points: ot(n.x, n.y, .8),
								className: "shallowsea-hex-mark"
							}),
							r && (r.kind === "coral" ? /* @__PURE__ */ v(St, {
								tile: r,
								x: n.x,
								y: n.y
							}) : /* @__PURE__ */ v(Mt, {
								tile: r,
								x: n.x,
								y: n.y
							})),
							_ === t.id && /* @__PURE__ */ v("polygon", {
								points: ot(n.x, n.y, 1),
								className: "shallowsea-hex-last"
							})
						] }, t.id);
					}),
					le.map((t) => {
						let n = e?.bubbles[t.key], r = !!(m?.has(t.key) && h);
						return /* @__PURE__ */ y("g", { children: [n ? /* @__PURE__ */ v(xt, {
							x: t.x,
							y: t.y,
							color: n,
							scale: Ge,
							rot: We[t.corner]
						}) : r ? /* @__PURE__ */ y("g", {
							className: "shallowsea-pearl is-target",
							"aria-hidden": !0,
							children: [
								/* @__PURE__ */ v("circle", {
									cx: t.x,
									cy: t.y,
									r: .135,
									className: "shallowsea-pearl-body"
								}),
								/* @__PURE__ */ v("circle", {
									cx: t.x - .045,
									cy: t.y - .045,
									r: .036,
									className: "shallowsea-pearl-shine"
								}),
								/* @__PURE__ */ v("circle", {
									cx: t.x,
									cy: t.y,
									r: .27,
									className: "shallowsea-pearl-ring"
								})
							]
						}) : /* @__PURE__ */ v("circle", {
							cx: t.x,
							cy: t.y,
							r: .055,
							className: "shallowsea-socket",
							"aria-hidden": !0
						}), r && h && /* @__PURE__ */ v("circle", {
							cx: t.x,
							cy: t.y,
							r: .34,
							className: "shallowsea-hit",
							role: "button",
							tabIndex: 0,
							"aria-label": n && s ? s(n) : l,
							onClick: () => h(t.key),
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), h(t.key));
							}
						})] }, t.key);
					}),
					g && q && /* @__PURE__ */ y("g", {
						className: "shallowsea-preview",
						children: [g.tile.kind === "coral" ? /* @__PURE__ */ v(St, {
							tile: g.tile,
							x: q.x,
							y: q.y
						}) : /* @__PURE__ */ v(Mt, {
							tile: g.tile,
							x: q.x,
							y: q.y
						}), /* @__PURE__ */ v("polygon", {
							points: ot(q.x, q.y, 1),
							className: "shallowsea-hex-preview"
						})]
					})
				]
			}),
			C && /* @__PURE__ */ y("div", {
				className: "shallowsea-zoom",
				role: "group",
				"aria-label": w("games.shallowsea.zoomControls"),
				children: [
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.zoomOut"),
						disabled: I.scale <= 1.001,
						onClick: () => H({
							...L.current,
							scale: L.current.scale / Je
						}),
						children: /* @__PURE__ */ v(f, {
							size: 18,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.zoomIn"),
						disabled: I.scale >= 2.999,
						onClick: () => H({
							...L.current,
							scale: L.current.scale * Je
						}),
						children: /* @__PURE__ */ v(d, {
							size: 18,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.fitBoard"),
						disabled: I.scale <= 1.001,
						onClick: () => H(Xe),
						children: /* @__PURE__ */ v(c, {
							size: 18,
							"aria-hidden": !0
						})
					})
				]
			}),
			b && J && /* @__PURE__ */ v("div", {
				ref: k,
				className: "shallowsea-place-controls",
				style: {
					...fe ?? {
						left: 0,
						top: 0,
						visibility: "hidden"
					},
					"--shallowsea-ui-scale": de
				},
				children: b
			})
		]
	});
}
function gt() {
	return /* @__PURE__ */ y("svg", {
		className: "shallowsea-reef",
		viewBox: Ke,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("g", {
				fill: "#0b4a5f",
				opacity: "0.12",
				children: [/* @__PURE__ */ v("path", { d: "M-2.6,5.2 L-2.2,4.98 C-1.9,4.86 -1.6,5.04 -1.3,4.92 L-0.9,5.2 Z" }), /* @__PURE__ */ v("path", { d: "M5.4,5.2 L5.95,4.9 C6.4,4.72 6.8,4.98 7.3,4.86 L8.6,5.2 Z" })]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#f2fffd",
				opacity: "0.2",
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -1.85,
						cy: 4.86,
						r: .26
					}),
					/* @__PURE__ */ v("circle", {
						cx: -1.55,
						cy: 4.62,
						r: .34
					}),
					/* @__PURE__ */ v("circle", {
						cx: -1.22,
						cy: 4.9,
						r: .2
					}),
					/* @__PURE__ */ v("path", {
						d: "M-1.9,5.2 L-1.9,4.84 M-1.62,5.2 L-1.62,4.5 M-1.3,5.2 L-1.3,4.86",
						stroke: "#f2fffd",
						strokeWidth: .09,
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.15,
						cy: 4.78,
						r: .22
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.5,
						cy: 4.6,
						r: .3
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.85,
						cy: 4.86,
						r: .18
					}),
					/* @__PURE__ */ v("path", {
						d: "M7.2,5.2 L7.2,4.74 M7.52,5.2 L7.52,4.5 M7.86,5.2 L7.86,4.84",
						stroke: "#f2fffd",
						strokeWidth: .09,
						strokeLinecap: "round"
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				fill: "none",
				stroke: "#d8fbf5",
				strokeWidth: .08,
				strokeLinecap: "round",
				opacity: "0.22",
				children: [/* @__PURE__ */ v("path", { d: "M8.24,5.2 C8.06,4.7 8.32,4.3 8.12,3.86 C7.96,3.5 8.2,3.16 8.06,2.82" }), /* @__PURE__ */ v("path", { d: "M-2.28,5.2 C-2.42,4.86 -2.2,4.56 -2.36,4.24" })]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#ffffff",
				opacity: "0.3",
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -.35,
						cy: 4.55,
						r: .05
					}),
					/* @__PURE__ */ v("circle", {
						cx: .1,
						cy: 4.76,
						r: .04
					}),
					/* @__PURE__ */ v("circle", {
						cx: 5.9,
						cy: 4.62,
						r: .045
					})
				]
			})
		]
	});
}
function _t() {
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.94 C0.2,0.9 0.07,0.58 0.15,0.34 C0.24,0.1 0.37,0.05 0.5,0.05 C0.63,0.05 0.76,0.1 0.85,0.34 C0.93,0.58 0.8,0.9 0.5,0.94 Z",
			fill: "#f4c66d",
			stroke: "#8a5a2b",
			strokeWidth: .07
		}),
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.88 C0.34,0.7 0.3,0.42 0.5,0.24 C0.7,0.42 0.66,0.7 0.5,0.88 Z",
			fill: "none",
			stroke: "#8a5a2b",
			strokeWidth: .045,
			opacity: .65
		}),
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.88 L0.5,0.26 M0.34,0.82 L0.38,0.32 M0.66,0.82 L0.62,0.32",
			fill: "none",
			stroke: "#8a5a2b",
			strokeWidth: .03,
			opacity: .5
		})
	] });
}
function vt({ size: e = 14 }) {
	return /* @__PURE__ */ v("svg", {
		className: "shallowsea-shell",
		width: e,
		height: e,
		viewBox: "0 0 1 1",
		"aria-hidden": "true",
		children: /* @__PURE__ */ v(_t, {})
	});
}
function yt({ color: e, x: t, y: n, scale: r }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: .02,
				cy: .56,
				rx: .34,
				ry: .1,
				fill: "#083c46",
				opacity: .12
			}),
			/* @__PURE__ */ y("g", {
				fill: "none",
				stroke: e,
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M0,0.58 L0,0.12",
						strokeWidth: .19
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.34 C-0.14,0.24 -0.24,0.08 -0.32,-0.14",
						strokeWidth: .14
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.28 C0.14,0.18 0.24,0.02 0.32,-0.2",
						strokeWidth: .14
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.12 C-0.06,-0.04 -0.06,-0.2 -0.02,-0.38",
						strokeWidth: .13
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.16 C0.08,0.02 0.12,-0.1 0.14,-0.32",
						strokeWidth: .11
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#fff",
				opacity: .35,
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -.31,
						cy: -.16,
						r: .045
					}),
					/* @__PURE__ */ v("circle", {
						cx: .31,
						cy: -.22,
						r: .045
					}),
					/* @__PURE__ */ v("circle", {
						cx: -.02,
						cy: -.4,
						r: .04
					})
				]
			})
		]
	});
}
function bt({ shell: e = [.5, -.5] }) {
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v("polygon", {
			points: Q(0, 0, .9),
			fill: "none",
			stroke: "#10b1a6",
			strokeWidth: .08,
			strokeDasharray: "0.22 0.12"
		}),
		/* @__PURE__ */ v("circle", {
			cx: e[0],
			cy: e[1],
			r: .13,
			fill: "#fffdf6",
			stroke: "#10b1a6",
			strokeWidth: .05
		}),
		/* @__PURE__ */ v("g", {
			transform: `translate(${e[0] - .12} ${e[1] - .12}) scale(0.24)`,
			children: /* @__PURE__ */ v(_t, {})
		})
	] });
}
function xt({ x: e, y: t, color: n, scale: r = 1, rot: i = 0 }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) rotate(${i}) scale(${r})`,
		className: "shallowsea-fish-token",
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: .05,
				cy: .11,
				rx: .27,
				ry: .16,
				fill: "#04323c",
				opacity: .2
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.06,0 L-0.18,-0.18 L-0.35,-0.11 L-0.26,0 L-0.35,0.11 L-0.18,0.18 Z",
				fill: n,
				stroke: "#083038",
				strokeWidth: .04,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.12,-0.05 C-0.06,-0.21 0.14,-0.21 0.25,-0.06 L0.31,-0.02 L0.31,0.02 L0.25,0.06 C0.14,0.21 -0.06,0.21 -0.12,0.05 Z",
				fill: n,
				stroke: "#083038",
				strokeWidth: .045
			}),
			/* @__PURE__ */ v("path", {
				d: "M0.0,-0.15 L0.1,-0.25 L0.15,-0.09 Z",
				fill: "#fff",
				opacity: .3
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: .07,
				cy: -.09,
				rx: .09,
				ry: .033,
				fill: "#fff",
				opacity: .35
			}),
			/* @__PURE__ */ v("circle", {
				cx: .18,
				cy: -.03,
				r: .035,
				fill: "#083038"
			})
		]
	});
}
function St({ tile: e, x: t, y: n }) {
	let r = x[e.color];
	return /* @__PURE__ */ y("g", {
		className: "shallowsea-face",
		transform: `translate(${t} ${n}) scale(${ze})`,
		children: [
			/* @__PURE__ */ v("polygon", {
				points: Q(.03, .05, .97),
				fill: "#04323c",
				opacity: .22
			}),
			/* @__PURE__ */ v("polygon", {
				points: Q(0, 0, .97),
				fill: "#fffdf6",
				stroke: "#0b3a43",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("polygon", {
				points: Q(0, 0, .9),
				fill: r,
				fillOpacity: e.completed ? .16 : .1
			}),
			e.completed && /* @__PURE__ */ v(bt, {}),
			[
				0,
				1,
				2,
				3
			].map((t) => {
				let n = K(e, t);
				if (!n) return null;
				let [r, i] = He[t];
				return /* @__PURE__ */ v("line", {
					x1: r[0] * .88,
					y1: r[1] * .88,
					x2: i[0] * .88,
					y2: i[1] * .88,
					stroke: x[n],
					strokeWidth: .14,
					strokeLinecap: "round"
				}, t);
			}),
			/* @__PURE__ */ v(yt, {
				color: r,
				x: 0,
				y: .08,
				scale: .95
			}),
			/* @__PURE__ */ v("circle", {
				cx: -.52,
				cy: -.52,
				r: .13,
				fill: r,
				stroke: "#fffdf6",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("circle", {
				cx: .44,
				cy: .44,
				r: .24,
				fill: "#8a5a2b",
				stroke: "#fffdf6",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("text", {
				x: .44,
				y: .545,
				textAnchor: "middle",
				fontSize: .29,
				fontWeight: 900,
				fill: "#fff",
				children: e.vp
			}),
			e.lockedFish && /* @__PURE__ */ v(xt, {
				x: .02,
				y: -.34,
				color: e.lockedFish,
				scale: .86
			})
		]
	});
}
var Ct = "#2f7fd0", wt = "#d9534f";
function Tt(e) {
	return e === "sameCoral" || e === "sameFish" || e === "dirSameCoral" || e === "dirSameFish";
}
function Et(e) {
	return e === "anyAllCoral" ? "all" : e.includes("Fish") ? "fish" : "coral";
}
function Dt({ color: e }) {
	return /* @__PURE__ */ y("g", {
		stroke: e,
		strokeWidth: .12,
		strokeLinecap: "round",
		fill: "none",
		children: [
			/* @__PURE__ */ v("path", { d: "M0,0.46 L0,0.02" }),
			/* @__PURE__ */ v("path", { d: "M0,0.10 C-0.12,0.02 -0.22,-0.12 -0.27,-0.30" }),
			/* @__PURE__ */ v("path", { d: "M0,0.10 C0.12,0.02 0.22,-0.12 0.27,-0.30" }),
			/* @__PURE__ */ v("path", { d: "M0,0.02 L0,-0.34" }),
			/* @__PURE__ */ v("path", { d: "M-0.27,-0.30 L-0.37,-0.42" }),
			/* @__PURE__ */ v("path", { d: "M0.27,-0.30 L0.37,-0.42" })
		]
	});
}
function Ot({ color: e }) {
	return /* @__PURE__ */ y("g", {
		fill: e,
		children: [/* @__PURE__ */ v("ellipse", {
			cx: .06,
			cy: 0,
			rx: .3,
			ry: .2
		}), /* @__PURE__ */ v("path", { d: "M-0.18,0 L-0.46,-0.24 L-0.46,0.24 Z" })]
	});
}
function kt({ kind: e, x: t, y: n, scale: r }) {
	let i = Et(e), a = i === "fish" ? Ot : Dt;
	return i === "all" ? /* @__PURE__ */ v("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: b.map((e, t) => /* @__PURE__ */ v("g", {
			transform: `translate(${(t - 1.5) * .52} 0) scale(0.72)`,
			children: /* @__PURE__ */ v(Dt, { color: x[e] })
		}, e))
	}) : Tt(e) ? /* @__PURE__ */ v("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: /* @__PURE__ */ v(a, { color: Ct })
	}) : /* @__PURE__ */ y("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: [/* @__PURE__ */ v("g", {
			transform: "translate(-0.16 0) scale(0.72)",
			children: /* @__PURE__ */ v(a, { color: wt })
		}), /* @__PURE__ */ v("g", {
			transform: "translate(0.16 0) scale(0.72)",
			children: /* @__PURE__ */ v(a, { color: Ct })
		})]
	});
}
function At({ kind: e, x: t, y: n }) {
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
		cx: t,
		cy: n,
		r: .145,
		fill: "#fffdf6",
		stroke: "#0a4f58",
		strokeWidth: .035
	}), /* @__PURE__ */ v(kt, {
		kind: e,
		x: t,
		y: n,
		scale: .16
	})] });
}
function jt({ type: e, x: t, y: n }) {
	let r = Tt(e.kind);
	return /* @__PURE__ */ y("g", {
		transform: `translate(${t} ${n})`,
		children: [/* @__PURE__ */ v("polygon", {
			points: Q(0, 0, .28),
			fill: "#0b3a43"
		}), /* @__PURE__ */ v("text", {
			y: .115,
			textAnchor: "middle",
			fontSize: .32,
			fontWeight: 900,
			fill: r ? "#5ef2a8" : "#ffb0a6",
			children: r ? "=" : "≠"
		})]
	});
}
function Mt({ tile: e, x: t, y: n }) {
	let r = I[e.typeId], i = r?.kind === "anyAllCoral";
	return /* @__PURE__ */ y("g", {
		className: "shallowsea-face",
		transform: `translate(${t} ${n}) scale(${ze})`,
		children: [
			/* @__PURE__ */ v("polygon", {
				points: Q(.03, .05, .97),
				fill: "#04323c",
				opacity: .22
			}),
			/* @__PURE__ */ v("polygon", {
				points: Q(0, 0, .97),
				fill: "#f7fffd",
				stroke: "#0b3a43",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("polygon", {
				points: Q(0, 0, .9),
				fill: "#7fd8d0",
				fillOpacity: e.completed ? .22 : .13
			}),
			e.completed && /* @__PURE__ */ v(bt, { shell: [0, -.58] }),
			r && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("text", {
					y: -.86,
					textAnchor: "middle",
					fontSize: .12,
					fontWeight: 800,
					fill: "#0a4f58",
					opacity: .35,
					children: e.typeId
				}),
				r.offsets?.map((t) => {
					let [n, i] = Ve[(t + e.rot) % 6];
					return /* @__PURE__ */ v(At, {
						kind: r.kind,
						x: n * .78,
						y: i * .78
					}, `o${t}`);
				}),
				r.dirs?.map((t) => /* @__PURE__ */ v(Nt, {
					kind: r.kind,
					x: 0,
					y: 0,
					dir: (t + e.rot) % 6
				}, `d${t}`)),
				i ? /* @__PURE__ */ v(kt, {
					kind: r.kind,
					x: 0,
					y: -.1,
					scale: .26
				}) : /* @__PURE__ */ v(jt, {
					type: r,
					x: 0,
					y: -.1
				}),
				/* @__PURE__ */ v("text", {
					y: .54,
					textAnchor: "middle",
					fontSize: .32,
					fontWeight: 900,
					fill: "#0b3a43",
					children: r.need
				}),
				/* @__PURE__ */ v("circle", {
					cx: -.3,
					cy: .72,
					r: .14,
					fill: "#8a5a2b",
					stroke: "#fffdf6",
					strokeWidth: .04
				}),
				/* @__PURE__ */ v("text", {
					x: -.3,
					y: .792,
					textAnchor: "middle",
					fontSize: .2,
					fontWeight: 900,
					fill: "#fff",
					children: r.partial
				}),
				/* @__PURE__ */ v("circle", {
					cx: .3,
					cy: .72,
					r: .14,
					fill: "#0b3a43",
					stroke: "#fffdf6",
					strokeWidth: .04
				}),
				/* @__PURE__ */ v("text", {
					x: .3,
					y: .792,
					textAnchor: "middle",
					fontSize: .2,
					fontWeight: 900,
					fill: "#fff",
					children: r.vp
				})
			] })
		]
	});
}
function Nt({ kind: e, x: t, y: n, dir: r }) {
	let [i, a] = Ve[r], o = Math.hypot(i, a), s = i / o, c = a / o, l = -c, u = s, d = t + s * .55, f = n + c * .55, p = t + s * .82, m = n + c * .82;
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v(kt, {
		kind: e,
		x: t + s * .45,
		y: n + c * .45,
		scale: .2
	}), /* @__PURE__ */ y("g", {
		stroke: "#0a5963",
		strokeWidth: .05,
		fill: "none",
		opacity: .8,
		children: [/* @__PURE__ */ v("line", {
			x1: d,
			y1: f,
			x2: p,
			y2: m
		}), /* @__PURE__ */ v("path", {
			d: `M${p},${m} L${p - s * .16 + l * .09},${m - c * .16 + u * .09} L${p - s * .16 - l * .09},${m - c * .16 - u * .09} Z`,
			fill: "#0a5963",
			stroke: "none"
		})]
	})] });
}
function Pt({ coral: e, size: t }) {
	return /* @__PURE__ */ y("span", {
		className: "shallowsea-chip-visual",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: [
			/* @__PURE__ */ v("span", {
				className: "shallowsea-chip-fill",
				style: { background: x[e.color] }
			}),
			/* @__PURE__ */ v("span", {
				className: "shallowsea-chip-vp",
				children: e.vp
			}),
			e.corners.map((e, t) => e ? /* @__PURE__ */ v("span", {
				"data-corner": t,
				className: "shallowsea-chip-edge",
				style: { background: x[e] }
			}, t) : null)
		]
	});
}
var $ = 22, Ft = 20, It = 4.6, Lt = 11.4;
function Rt({ kind: e, dir: t }) {
	let [n, r] = Ve[t], i = Math.hypot(n, r), a = $ + n / i * Lt, o = Ft + r / i * Lt;
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
		cx: a,
		cy: o,
		r: It,
		fill: "#fffdf6",
		stroke: "#0a4f58",
		strokeWidth: .9
	}), /* @__PURE__ */ v(kt, {
		kind: e,
		x: a,
		y: o,
		scale: 6.8
	})] });
}
function zt({ kind: e, dir: t }) {
	let [n, r] = Ve[t], i = Math.hypot(n, r), a = n / i, o = r / i, s = -o, c = a, l = $ + a * 8.9, u = Ft + o * 8.9, d = $ + a * 11.4, f = Ft + o * 11.4, p = $ + a * 14.4, m = Ft + o * 14.4;
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v(kt, {
		kind: e,
		x: l,
		y: u,
		scale: 6.8
	}), /* @__PURE__ */ y("g", {
		stroke: "#0a5963",
		strokeWidth: 1.1,
		fill: "none",
		opacity: .85,
		children: [/* @__PURE__ */ v("line", {
			x1: d,
			y1: f,
			x2: p,
			y2: m
		}), /* @__PURE__ */ v("path", {
			d: `M${p},${m} L${p - a * 2.9 + s * 1.6},${m - o * 2.9 + c * 1.6} L${p - a * 2.9 - s * 1.6},${m - o * 2.9 - c * 1.6} Z`,
			fill: "#0a5963",
			stroke: "none"
		})]
	})] });
}
function Bt({ typeId: e, size: t, rot: n = 0 }) {
	let r = I[e], i = r ? Tt(r.kind) : !1, a = r?.kind === "anyAllCoral";
	return /* @__PURE__ */ v("span", {
		className: "shallowsea-chip-visual is-sealife",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: /* @__PURE__ */ y("svg", {
			viewBox: "0 0 44 44",
			className: "shallowsea-chip-sealife",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ v("text", {
				x: $,
				y: 5.9,
				textAnchor: "middle",
				fontSize: 7,
				fontWeight: 900,
				fill: "#0a4f58",
				opacity: .68,
				children: e
			}), r && /* @__PURE__ */ y(_, { children: [
				r.offsets?.map((e) => /* @__PURE__ */ v(Rt, {
					kind: r.kind,
					dir: (e + n) % 6
				}, `o${e}`)),
				r.dirs?.map((e) => /* @__PURE__ */ v(zt, {
					kind: r.kind,
					dir: (e + n) % 6
				}, `d${e}`)),
				a ? /* @__PURE__ */ v(kt, {
					kind: r.kind,
					x: $,
					y: 18.4,
					scale: 10.4
				}) : /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("polygon", {
					points: Q($, Ft, 5.1),
					fill: "#0b3a43",
					opacity: .95
				}), /* @__PURE__ */ v("text", {
					x: $,
					y: 22.8,
					textAnchor: "middle",
					fontSize: 8.2,
					fontWeight: 900,
					fill: i ? "#5ef2a8" : "#ffb0a6",
					children: i ? "=" : "≠"
				})] }),
				/* @__PURE__ */ v("circle", {
					cx: 8.6,
					cy: 38.2,
					r: 4.4,
					fill: "#8a5a2b",
					stroke: "#fffdf6",
					strokeWidth: .7
				}),
				/* @__PURE__ */ v("text", {
					x: 8.6,
					y: 40.4,
					textAnchor: "middle",
					fontSize: 6.1,
					fontWeight: 900,
					fill: "#fff",
					children: r.partial
				}),
				/* @__PURE__ */ v("circle", {
					cx: 35.4,
					cy: 38.2,
					r: 4.4,
					fill: "#0b3a43",
					stroke: "#fffdf6",
					strokeWidth: .7
				}),
				/* @__PURE__ */ v("text", {
					x: 35.4,
					y: 40.4,
					textAnchor: "middle",
					fontSize: 6.1,
					fontWeight: 900,
					fill: "#fff",
					children: r.vp
				}),
				/* @__PURE__ */ v("text", {
					x: $,
					y: 41.4,
					textAnchor: "middle",
					fontSize: 8.2,
					fontWeight: 900,
					fill: "#0b3a43",
					children: r.need
				})
			] })]
		})
	});
}
function Vt({ tile: e }) {
	return /* @__PURE__ */ v("span", {
		className: "shallowsea-tile-preview",
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("svg", {
			viewBox: "-0.86 -0.86 1.72 1.72",
			children: e.kind === "coral" ? /* @__PURE__ */ v(St, {
				tile: e,
				x: 0,
				y: 0
			}) : /* @__PURE__ */ v(Mt, {
				tile: e,
				x: 0,
				y: 0
			})
		})
	});
}
function Ht({ color: e, size: t }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "-0.4 -0.4 0.8 0.8",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		className: "shallowsea-fish-chip",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("circle", {
				r: .36,
				fill: x[e],
				stroke: "#08252c",
				strokeWidth: .06
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.22,0 L-0.03,-0.12 L-0.03,0.12 Z",
				fill: "#fff"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: .07,
				cy: 0,
				rx: .15,
				ry: .09,
				fill: "#fff"
			})
		]
	});
}
function Ut({ pool: e, label: t, refreshLabel: n, cost: r, refreshDisabled: i, onRefresh: a, children: o }) {
	return /* @__PURE__ */ y("div", {
		className: "shallowsea-pool-row",
		"data-pool": e,
		role: "group",
		"aria-label": t,
		children: [
			/* @__PURE__ */ v("span", {
				className: "shallowsea-pool-label",
				"aria-hidden": !0,
				children: t
			}),
			o,
			/* @__PURE__ */ y("button", {
				type: "button",
				className: "shallowsea-refresh",
				"aria-label": n,
				disabled: i,
				onClick: a,
				children: [/* @__PURE__ */ v(u, {
					size: 13,
					"aria-hidden": !0
				}), /* @__PURE__ */ v("span", { children: r })]
			})
		]
	});
}
function Wt({ pub: e, nameOf: t }) {
	let n = o(), r = it[e.ecosystems.orange] ?? null, i = it[e.ecosystems.blue] ?? null;
	return /* @__PURE__ */ y("div", {
		className: "shallowsea-scores",
		children: [/* @__PURE__ */ v("h2", {
			className: "shallowsea-scores-title",
			children: n("games.shallowsea.scoreTitle")
		}), /* @__PURE__ */ v("div", {
			className: "shallowsea-score-grid",
			children: e.players.map((a) => {
				let o = e.breakdown?.[a];
				return /* @__PURE__ */ y("div", {
					className: "shallowsea-score-card",
					children: [/* @__PURE__ */ y("div", {
						className: "shallowsea-score-head",
						children: [/* @__PURE__ */ v("span", {
							className: "truncate",
							children: t(a)
						}), /* @__PURE__ */ v("span", {
							className: "shallowsea-score-total font-mono tabular-nums",
							children: n("games.shallowsea.scoreShort", { n: e.scores?.[a] ?? o?.total ?? 0 })
						})]
					}), o && /* @__PURE__ */ y("ul", {
						className: "shallowsea-score-rows",
						children: [
							r && /* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n(r) }), /* @__PURE__ */ v("span", { children: o.orange })] }),
							i && /* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n(i) }), /* @__PURE__ */ v("span", { children: o.blue })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreCoral") }), /* @__PURE__ */ v("span", { children: o.coralVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreSealife") }), /* @__PURE__ */ v("span", { children: o.sealifeVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scorePartial") }), /* @__PURE__ */ v("span", { children: o.partialVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreVariety") }), /* @__PURE__ */ v("span", { children: o.variety })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreFish") }), /* @__PURE__ */ v("span", { children: o.fishBonus })] }),
							/* @__PURE__ */ y("li", {
								className: "is-total",
								children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreTotal") }), /* @__PURE__ */ v("span", { children: o.total })]
							})
						]
					})]
				}, a);
			})
		})]
	});
}
//#endregion
//#region src/game/bot.ts
function Gt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Kt() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function qt(e, t, n, r) {
	let i = r ? {
		...e.bubbles,
		[r.key]: r.color
	} : e.bubbles;
	return {
		cells: {
			...e.cells,
			[t]: n
		},
		bubbles: i
	};
}
function Jt(e, t) {
	let n = 0;
	for (let r of Object.keys(e.cells)) {
		let i = e.cells[r];
		if (!(i.kind !== "coral" || i.completed)) for (let a = 0; a < 4; a += 1) K(i, a) === t && e.bubbles[j(r, a)] !== t && (n += 1);
	}
	return n;
}
function Yt(e, t) {
	let n = I[t];
	if (!n) return 0;
	let r = 0;
	for (let i of q(e)) for (let a = 0; a < 6; a += 1) {
		let o = {
			kind: "sealife",
			typeId: t,
			rot: a,
			completed: !1
		};
		r = Math.max(r, _e(qt(e, i, o), i, o, n));
	}
	return r;
}
function Xt(e, t, n) {
	let r = /* @__PURE__ */ new Set();
	for (let i of e.offsets ?? []) {
		let e = A(t, (i + n) % 6);
		e && r.add(e);
	}
	for (let i of e.dirs ?? []) {
		let e = t;
		for (;;) {
			let t = A(e, (i + n) % 6);
			if (!t) break;
			r.add(t), e = t;
		}
	}
	return r.size;
}
function Zt(e, t, n) {
	let r = 0, i = 0, a = 0;
	for (let o of q(e)) {
		let s = 0, c = 0, l = 0;
		for (let r = 0; r < 4; r += 1) {
			let i = K(t, r);
			if (!i) continue;
			l += 1;
			let a = j(o, r), u = e.bubbles[a];
			u === i ? s += 1 : !u && i === n && (c += 1);
		}
		l !== 0 && (s > r || s === r && c > i) && (r = s, i = c, a = l);
	}
	let o = a > 0 && r === a;
	return t.vp * .9 + r * 2 + i * 2.5 + (o ? 12 : 0);
}
//#endregion
//#region src/index.tsx
var Qt = {
	definition: Re,
	View: ct,
	bot: (e, t) => {
		let n = e.public;
		if (n.phase === "done" || n.active !== t.rid) return null;
		let r = n.boards[t.rid];
		if (!r) return null;
		let i = t.difficulty === "weak";
		if (n.phase === "setup") {
			let e = [];
			n.pools.sealife.forEach((t, n) => {
				t && e.push({
					index: n,
					typeId: t
				});
			});
			let t = E.filter((e) => !r.cells[e.id]);
			if (e.length === 0 || t.length === 0) return null;
			let a = [];
			for (let n of e) {
				let e = I[n.typeId];
				for (let r of t) for (let t = 0; t < 6; t += 1) {
					let i = (e ? Xt(e, r.id, t) : 0) * 2 + (r.inner ? 3 : 0) + (e ? e.vp * .6 + e.partial : 0);
					a.push({
						action: {
							type: "setupPlace",
							index: n.index,
							cell: r.id,
							rot: t
						},
						score: i
					});
				}
			}
			if (i) return { action: Gt(a).action };
			for (let e of a) e.score += Kt();
			return a.sort((e, t) => t.score - e.score), { action: a[0].action };
		}
		if (n.phase === "select") {
			let e = [], a = [], o = n.pools, s = (e) => 2 + Jt(r, e) * 1.2;
			for (let t = 0; t < 5; t += 1) {
				let n = o.fish[t];
				if (!n) continue;
				let i = o.coral[t];
				if (i) {
					let r = s(n) + i.vp * .8 + 1;
					e.push({
						action: {
							type: "select",
							fish: t,
							tile: "coral"
						},
						score: r
					});
				}
				let a = o.sealife[t];
				if (a) {
					let i = I[a], o = Yt(r, a), c = s(n) + (i ? i.vp * (o / i.need) * 1.4 : 0) + (i && o >= i.need ? 10 : 0);
					e.push({
						action: {
							type: "select",
							fish: t,
							tile: "sealife"
						},
						score: c
					});
				}
			}
			if ((n.shells[t.rid] ?? 0) >= 2) for (let e = 0; e < 5; e += 1) {
				let t = o.fish[e];
				if (t) for (let n = 0; n < 5; n += 1) {
					let i = o.coral[n];
					i && a.push({
						action: {
							type: "selectAny",
							fish: e,
							tile: "coral",
							index: n
						},
						score: s(t) + i.vp * .8
					});
					let c = o.sealife[n];
					if (c) {
						let i = I[c], o = Yt(r, c);
						a.push({
							action: {
								type: "selectAny",
								fish: e,
								tile: "sealife",
								index: n
							},
							score: s(t) + (i ? i.vp * (o / i.need) * 1.4 : 0)
						});
					}
				}
			}
			let c = e.sort((e, t) => t.score - e.score)[0], l = a.sort((e, t) => t.score - e.score)[0];
			if (i) {
				let r = (n.shells[t.rid] ?? 0) >= 2 ? [...e, ...a] : e;
				return r.length === 0 ? null : { action: Gt(r).action };
			}
			if (l && (!c || l.score > c.score + 3)) return { action: l.action };
			if (c) return { action: c.action };
			for (let e of ["coral", "fish"]) {
				let t = e === "coral" ? o.coral : o.fish, n = /* @__PURE__ */ new Map();
				for (let r of t) {
					if (!r) continue;
					let t = e === "coral" ? r.color : r;
					n.set(t, (n.get(t) ?? 0) + 1);
				}
				if ([...n.values()].some((e) => e >= 4)) return { action: {
					type: "refresh",
					pool: e
				} };
			}
			return null;
		}
		let a = n.selection;
		if (!a) return null;
		if (n.phase === "tile") {
			let e = q(r);
			if (e.length === 0) return null;
			let t = [];
			for (let n of e) if (a.tileKind === "coral" && a.coral) for (let e = 0; e < 4; e += 1) {
				let i = {
					kind: "coral",
					color: a.coral.color,
					vp: a.coral.vp,
					corners: [...a.coral.corners],
					rot: e,
					completed: !1,
					lockedFish: null
				};
				t.push({
					action: {
						type: "placeTile",
						cell: n,
						rot: e
					},
					score: Zt(r, i, a.fish)
				});
			}
			else if (a.tileKind === "sealife" && a.sealife) {
				let e = I[a.sealife];
				for (let i = 0; i < 6; i += 1) {
					let o = {
						kind: "sealife",
						typeId: a.sealife,
						rot: i,
						completed: !1
					}, s = e ? _e(qt(r, n, o), n, o, e) : 0, c = e ? s >= e.need : !1;
					t.push({
						action: {
							type: "placeTile",
							cell: n,
							rot: i
						},
						score: s * 4 + (c && e ? e.vp + 12 : 0)
					});
				}
			}
			if (t.length === 0) return null;
			if (i) return { action: Gt(t).action };
			for (let e of t) e.score += Kt();
			return t.sort((e, t) => t.score - e.score), { action: t[0].action };
		}
		if (n.phase === "fish") {
			let e = J(r);
			if (e.length === 0) return null;
			let t = [];
			for (let n of e) {
				let e = {
					cells: r.cells,
					bubbles: {
						...r.bubbles,
						[n]: a.fish
					}
				}, i = 0;
				for (let t of N(n)) {
					let o = r.cells[t];
					if (o && o.kind === "coral") {
						if (o.completed) {
							i += .8;
							continue;
						}
						if (de(e, t, o)) i += o.vp + 8;
						else for (let e = 0; e < 4; e += 1) K(o, e) === a.fish && j(t, e) === n && (i += 2.5);
					}
				}
				t.push({
					action: {
						type: "placeFish",
						bubble: n
					},
					score: i
				});
			}
			if (i) return { action: Gt(t).action };
			for (let e of t) e.score += Kt();
			return t.sort((e, t) => t.score - e.score), { action: t[0].action };
		}
		let o = t.memory ?? {};
		if (n.phase === "end") {
			if (!i && (n.shells[t.rid] ?? 0) >= 2 && o.movedTurn !== n.turnCount) for (let e of Object.keys(r.cells)) {
				let t = r.cells[e];
				if (t.kind !== "coral" || t.completed) continue;
				let i = null, a = !0;
				for (let n = 0; n < 4; n += 1) {
					let o = K(t, n);
					if (!o) continue;
					let s = r.bubbles[j(e, n)];
					if (s !== o) {
						if (!s && !i) {
							i = {
								corner: n,
								color: o
							};
							continue;
						}
						a = !1;
						break;
					}
				}
				if (!a || !i) continue;
				let o = j(e, i.corner);
				for (let e of Object.keys(r.bubbles)) if (e !== o && r.bubbles[e] === i.color) return {
					action: {
						type: "moveFish",
						from: e,
						to: o
					},
					memory: { movedTurn: n.turnCount }
				};
			}
			return {
				action: { type: "endTurn" },
				memory: { movedTurn: o.movedTurn }
			};
		}
		return null;
	},
	locales: {
		zh: {
			name: "浅海",
			desc: "为珊瑚礁搭配鱼群，完成珊瑚与海洋生物，终局比拼分值",
			rules: "目标:\n每名玩家各自经营一片海洋。通过不断放入珊瑚与海洋生物，配合鱼群完成它们，获得海螺并积累分值。所有玩家完成各自的回合后计分，总分最高者获胜。\n准备:\n· 每名玩家取一块海洋板。板面共 22 格，开局时全部留空，随后每人先放 1 张海洋生物。\n· 每名玩家拿取 2 枚海螺，海螺最多持有 5 枚。\n· 洗混珊瑚堆、海洋生物堆与鱼堆，分别抽出 5 张摆成珊瑚池、生物池与鱼池。三个池子按位置一一配对：第 1 条鱼与珊瑚池、生物池各自的第 1 张对应，依此类推。\n· 由系统随机决定先手，之后按座位顺序轮流行动。\n· 从末位玩家开始，每名玩家依次从生物池选取 1 张海洋生物，正面朝上放到自己板上的任意空格；放置时可以旋转。所有玩家都放好后，补满生物池，再由先手玩家开始第一个回合。\n回合:\n每回合依次完成三件事：选牌、放置、结算。\n· 选牌时，从鱼池取 1 条鱼，并从珊瑚池或生物池取与这条鱼位置相同的 1 张地块。鱼池第 n 条鱼只能搭配两个池子中第 n 张地块。\n· 也可以花费 1 枚海螺刷新任意一个池子，再照常选牌。珊瑚池中有至少 4 张同色珊瑚时，刷新珊瑚池免费；鱼池中有至少 4 条同色鱼时，刷新鱼池免费。\n· 花费 2 枚海螺可以无视配对，任取 1 条鱼与 1 张地块。\n· 放置时，地块可以任意旋转，但必须放在与已有地块相邻的空格上。随后把刚选的鱼放到一处空的角气泡上。四块相邻地块在角部交会处形成一处气泡，每块地块都有北、东、南、西四处气泡；一处气泡最多由四块相邻地块共享，只能放 1 条鱼。\n· 放置完成后，检查因这次放置而满足条件的珊瑚与海洋生物，完成它们并获得海螺。\n珊瑚完成:\n· 珊瑚地块的四角印有若干条彩色标记，标记的颜色表示它需要的鱼色。当每处带标记的角所朝气泡上都放着对应颜色的鱼时，这块珊瑚完成。\n· 完成时把珊瑚翻面，并从满足条件的鱼中锁定 1 条放到珊瑚背面，这条鱼成为完成鱼，不再用于其他珊瑚。其余满足条件的鱼仍留在气泡上，仍属于未完成鱼。\n· 一次放鱼可能同时满足多块珊瑚。此时按格子顺序依次结算，先完成的珊瑚会锁定并取走一条鱼，其他珊瑚因此可能不再满足。\n海洋生物:\n· 海洋生物只统计已完成的珊瑚与完成鱼，满足条件即完成。\n· 每张海洋生物都印有指定的格位或方向，地块放置时通过旋转改变它观察的格位与方向。\n· 同色条件要求指定格或指定方向上的已完成珊瑚、完成鱼颜色相同；异色条件要求它们的颜色各不相同。\n· 方向条件沿箭头方向逐格计数，中间隔着不符合条件的格也不影响；两方向条件可以落在任意一侧，也可以合并两侧一起计数。\n· 本作首发使用 10 种海洋生物：A1 与 D1 要求指定 3 格为同色已完成珊瑚；A4 与 D4 要求指定 3 格为异色完成鱼；B1 要求两方向内 4 张同色已完成珊瑚；C2 要求指定 2 格为异色已完成珊瑚；C4 要求两方向内 2 条同色完成鱼；E1 要求单一方向内 3 张同色已完成珊瑚；E4 要求单一方向内 3 条异色完成鱼；F2 要求全板集齐四色已完成珊瑚。\n海洋生物图示:\n· 地块中央的深色徽记表示比较方式：绿色等号表示同色，红色不等号表示异色。\n· 地块边缘的圆形图标表示它观察的格位，带箭头的图标表示它沿该方向逐格观察。图标为单个蓝色珊瑚或蓝色鱼时要求同色，红色与蓝色图标并排时要求异色。\n· 徽记下方的数字表示完成所需的单元数。右下角深色圆圈中的数字是完成分值，左下角棕色星圈中的数字是每满足 1 个单元获得的部分分。\n· 全板条件以四色珊瑚图标表示，需要集齐红、黄、绿、紫四色的已完成珊瑚各 1 张。\n海螺:\n· 每完成 1 张珊瑚或海洋生物，获得 1 枚海螺，最多持有 5 枚。\n· 花费 1 枚海螺可以刷新一个池子；花费 2 枚海螺可以无视配对任选鱼与地块。\n· 花费 2 枚海螺可以移动自己板上 1 条未完成的鱼到另一处空角气泡。完成鱼不能移动；移动后触发的完成立即结算。\n结束与计分:\n· 每名玩家各完成 17 个回合后游戏结束。海洋板共 22 格，减去起始的 1 张生物与最后留空的 4 格，正好放置 17 张地块。\n· 先结算两张生态卡，再统计已完成珊瑚与已完成海洋生物的分值。\n· 未完成的海洋生物按已经满足的单元数获得部分分。\n· 每一种完成过的海洋生物额外获得 2 分。\n· 每条留在气泡上的未完成鱼，每相邻 1 张已完成珊瑚获得 1 分。\n· 总分最高者获胜。总分相同时，剩余海螺较多的玩家获胜；仍然相同则共享胜利。\n生态卡:\n开局固定使用 1 张橙色生态卡与 1 张蓝色生态卡，默认使用 O1 与 B1。对局中在设置里可以更换。\n· O1 保护色：背面放有同色完成鱼的已完成珊瑚，每张 2 分。\n· O2 珊瑚成对：同色已完成珊瑚每 2 张获得 3 分。\n· O3 潮汐交响：完成鱼数量最多的一种颜色，每条完成鱼 3 分，最多 18 分。\n· O4 错配：背面放有异色完成鱼的已完成珊瑚，每张 2 分。\n· O5 深层同调：某一横行中有至少 2 张同色已完成珊瑚时，该行获得 4 分。\n· O6 巨珊瑚礁：面积最大的一片相邻已完成珊瑚，每张 2 分。\n· O7 潮汐：某种颜色的完成鱼达到 3 条及以上时，该颜色获得 4 分。\n· B1 富饶深处：某一横行中有至少 2 张已完成海洋生物时，该行获得 4 分。\n· B2 丰饶洞穴：位于内圈的已完成海洋生物，每张 3 分。\n· B3 水下群落：与至少 1 张已完成海洋生物相邻的已完成海洋生物，每张 2 分。\n· B4 聚光灯：某一纵列恰好有 1 张已完成海洋生物时，该列获得 2 分。\n· B5 生物双联：每对相邻的已完成海洋生物获得 4 分，每张海洋生物最多计入一对。\n· B6 辉光洞穴：内圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。\n· B7 多样边界：外圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。",
			setupPrompt: "从生物池选 1 张，放到任意空格",
			setupWaiting: "等 {{name}} 放置起始海洋生物…",
			selectPrompt: "选 1 条鱼，再选同序号的地块",
			selectAnyMode: "自由搭配：先点鱼，再点地块",
			selectWaiting: "等 {{name}} 选牌…",
			waitingFor: "等 {{name}} 行动…",
			tilePrompt: "旋转地块，放到相邻的空格",
			fishPrompt: "把{{fish}}放到一处空角气泡上",
			endPrompt: "结束回合，或移动一条鱼",
			movingFrom: "点选要移动的鱼",
			movingTo: "再点一处空角气泡放下",
			doneBanner: "终局计分",
			coralPool: "珊瑚池",
			sealifePool: "生物池",
			fishPool: "鱼池",
			pairLabel: "第 {{n}} 组",
			refreshCoral: "刷新珊瑚池",
			refreshSealife: "刷新生物池",
			refreshFish: "刷新鱼池",
			refreshFree: "免费",
			refreshCost: "1 海螺",
			anyMode: "自由搭配",
			anyModeCost: "2 海螺",
			cancel: "取消",
			confirmPlace: "放这里",
			moveCost: "2 海螺",
			coralAria: "珊瑚，{{vp}} 分",
			poolEmpty: "空位",
			myBoard: "我的海洋",
			boardOf: "{{name}} 的海洋",
			shellsShort: "{{n}} 海螺",
			scoreShort: "{{n}} 分",
			emptyBubbleAria: "空的角气泡",
			fishAria: "{{fish}}",
			placeAria: "放到第 {{row}} 行第 {{col}} 列",
			rotateLeft: "向左旋转",
			rotateRight: "向右旋转",
			zoomControls: "盘面缩放",
			zoomIn: "放大",
			zoomOut: "缩小",
			fitBoard: "回到全板",
			ecoCards: "本局生态卡",
			ecoOrange: "橙色生态卡",
			ecoBlue: "蓝色生态卡",
			endTurn: "结束回合",
			moveFish: "移动鱼",
			cancelMove: "取消移动",
			activeBadge: "行动中",
			completedBadge: "已完成",
			fishRed: "红鱼",
			fishYellow: "黄鱼",
			fishGreen: "绿鱼",
			fishPurple: "紫鱼",
			slSameCoral3: "3 格同色珊瑚",
			slDiffFish3: "3 格异色完成鱼",
			slDirSameCoral4: "两方向 4 张同色珊瑚",
			slDiffCoral2: "2 格异色珊瑚",
			slDirSameFish2: "两方向 2 条同色完成鱼",
			slDirSameCoral3: "单方向 3 张同色珊瑚",
			slDirDiffFish3: "单方向 3 条异色完成鱼",
			slAnyAllCoral: "全板四色珊瑚各 1",
			sealifeAria: "{{id}}，{{desc}}",
			ecoO1: "保护色",
			ecoO2: "珊瑚成对",
			ecoO3: "潮汐交响",
			ecoO4: "错配",
			ecoO5: "深层同调",
			ecoO6: "巨珊瑚礁",
			ecoO7: "潮汐",
			ecoB1: "富饶深处",
			ecoB2: "丰饶洞穴",
			ecoB3: "水下群落",
			ecoB4: "聚光灯",
			ecoB5: "生物双联",
			ecoB6: "辉光洞穴",
			ecoB7: "多样边界",
			ecoO1Cond: "已完成珊瑚背面有同色完成鱼时，每张得 2 分",
			ecoO2Cond: "同色已完成珊瑚每 2 张得 3 分",
			ecoO3Cond: "完成鱼最多的一种颜色，每条得 3 分，最多 18 分",
			ecoO4Cond: "已完成珊瑚背面有异色完成鱼时，每张得 2 分",
			ecoO5Cond: "某一横行有至少 2 张同色已完成珊瑚时，该行得 4 分",
			ecoO6Cond: "最大的相邻已完成珊瑚群，每张得 2 分",
			ecoO7Cond: "某种颜色的完成鱼达到 3 条时，该颜色得 4 分",
			ecoB1Cond: "某一横行有至少 2 张已完成海洋生物时，该行得 4 分",
			ecoB2Cond: "内圈的已完成海洋生物，每张得 3 分",
			ecoB3Cond: "与已完成海洋生物相邻的已完成海洋生物，每张得 2 分",
			ecoB4Cond: "某一纵列恰好有 1 张已完成海洋生物时，该列得 2 分",
			ecoB5Cond: "相邻的已完成海洋生物每对得 4 分，每张最多计入一对",
			ecoB6Cond: "内圈每出现一种不同的地块得 2 分；珊瑚按颜色、海洋生物按种类区分",
			ecoB7Cond: "外圈每出现一种不同的地块得 2 分；珊瑚按颜色、海洋生物按种类区分",
			scoreTitle: "终局计分",
			scoreCoral: "已完成珊瑚",
			scoreSealife: "已完成海洋生物",
			scorePartial: "未完成生物部分分",
			scoreVariety: "生物种类",
			scoreFish: "未完成鱼",
			scoreTotal: "总分",
			errNotYourTurn: "现在轮不到你",
			errWrongPhase: "当前步骤不能这样操作",
			errAlreadySelected: "本回合已经选好牌了",
			errPoolEmpty: "这个池子没有可选的牌",
			errNoShell: "海螺不够",
			errNoSelection: "还没有选牌",
			errBadCell: "这格不能放",
			errBadBubble: "这里不能放鱼",
			errBadRotate: "这个朝向不能放"
		},
		en: {
			name: "Shallow Sea",
			desc: "Pair fish with tiles to complete corals and sea life, then compare scores",
			rules: "Goal:\nEach player tends their own sea. By placing corals and sea life and pairing them with fish, you complete them, earn shells, and build up points. After every player has taken all their turns, the highest score wins.\nSetup:\n· Each player takes one ocean board. The board has 22 spaces, all empty at the start; each player will first place 1 sea life tile on it.\n· Each player takes 2 shells. A player may hold at most 5 shells.\n· Shuffle the coral tiles, sea life tiles, and fish, then deal 5 of each into the coral pool, sea life pool, and fish pool. The pools are paired by position: the first fish pairs with the first coral and the first sea life, and so on.\n· The app randomly chooses the first player; play then proceeds in seat order.\n· Starting with the last player, each player in turn takes 1 sea life tile from the sea life pool and places it face up in any empty space on their own board; the tile may be rotated. Once every player has placed a tile, refill the sea life pool and the first player begins the first turn.\nTurn:\nEach turn is taken in three steps: choose, place, resolve.\n· When choosing, take 1 fish from the fish pool and 1 tile from either the coral pool or the sea life pool in the same position as that fish. The nth fish can only pair with the nth coral or the nth sea life.\n· You may instead spend 1 shell to refresh any one pool and then choose normally. Refreshing the coral pool is free when it holds at least 4 corals of one color, and refreshing the fish pool is free when it holds at least 4 fish of one color.\n· Spending 2 shells lets you ignore pairing and take any 1 fish with any 1 tile.\n· When placing, rotate the tile however you like, but it must go on an empty space adjacent to a tile already on your board. Then place the fish you chose on an empty corner bubble. Where four adjacent tiles meet at their corners, they form one bubble. Every tile has four corner bubbles, to the north, east, south, and west; each bubble is shared by up to four adjacent tiles and holds only 1 fish.\n· After placing, check which corals and sea life are now satisfied by this placement, and complete them to earn shells.\nCorals:\n· Each coral tile shows colored marks at some of its corners. A mark names the fish color it needs. The coral is completed when the bubble at every marked corner holds a fish of the matching color.\n· When a coral completes, flip it over and lock 1 of the satisfied fish onto its back. That fish becomes a completed fish and is no longer used by other corals. Any other satisfied fish stay on their bubbles and remain unfinished fish.\n· One fish may satisfy several corals at once. In that case they resolve in board order: the first coral to complete locks and removes a fish, so another coral may no longer be satisfied.\nSea life:\n· Sea life counts only completed corals and completed fish, and completes as soon as its condition is met.\n· Each sea life tile names specific spaces or directions; rotating the tile when placing changes which spaces or directions it looks at.\n· Same-color conditions require the completed corals or completed fish in the named spaces or directions to share one color. Different-color conditions require them to all differ.\n· Directional conditions count along the arrow, and a tile that does not match in between does not interrupt the count. Two-way conditions may count on either side or combine both sides.\n· This release uses 10 sea life types: A1 and D1 need same-color completed corals in 3 named spaces; A4 and D4 need different-color completed fish in 3 named spaces; B1 needs 4 same-color completed corals across its two directions; C2 needs different-color completed corals in 2 named spaces; C4 needs 2 same-color completed fish across its two directions; E1 needs 3 same-color completed corals in one direction; E4 needs 3 different-color completed fish in one direction; F2 needs completed corals of all four colors anywhere on the board.\nSea life icons:\n· The dark badge in the middle of a tile shows how colors are compared: a green equals sign means same color, and a red not-equals sign means different colors.\n· Round icons along the tile edges mark the spaces it observes, and an icon with an arrow marks a direction it observes space by space. A single blue coral or blue fish icon asks for one color; a red and a blue icon side by side ask for different colors.\n· The number under the badge is how many units are needed to complete the tile. The number in the dark circle at the lower right is the completion score, and the number in the brown star circle at the lower left is the partial score for each unit satisfied.\n· An anywhere-on-the-board condition is drawn with four colored coral icons and needs one completed coral of each of the four colors.\nShells:\n· Each completed coral or sea life earns 1 shell, up to a maximum of 5 shells.\n· Spending 1 shell refreshes one pool; spending 2 shells ignores pairing and lets you take any fish with any tile.\n· Spending 2 shells lets you move 1 unfinished fish on your own board to another empty corner bubble. Completed fish cannot be moved, and any completion triggered by the move resolves immediately.\nEnd and scoring:\n· The game ends after each player has taken 17 turns. A board has 22 spaces; after the 1 starting sea life and the 4 spaces left empty, exactly 17 tiles are placed.\n· Score the two ecosystem cards first, then the completed corals and completed sea life.\n· Unfinished sea life scores partial points for the units it has satisfied.\n· Each distinct type of completed sea life scores 2 bonus points.\n· Each unfinished fish still on a bubble scores 1 point for each completed coral adjacent to it.\n· The highest total wins. On a tie, the player with more shells remaining wins; if still tied, the players share the victory.\nEcosystem cards:\nEach game uses 1 orange and 1 blue ecosystem card, defaulting to O1 and B1. They can be changed in the setup options.\n· O1 Cryptic Coloration: each completed coral with a same-color completed fish on its back scores 2.\n· O2 Coral Duo: each pair of same-color completed corals scores 3.\n· O3 Symphony of the Tides: the color with the most completed fish scores 3 per fish, up to 18.\n· O4 Mismatched: each completed coral with a different-color completed fish on its back scores 2.\n· O5 Depths Alike: a row with at least 2 same-color completed corals scores 4.\n· O6 Colossal Coral Reef: the largest connected group of adjacent completed corals scores 2 per coral.\n· O7 Tides: each color with at least 3 completed fish scores 4.\n· B1 Rich Depths: a row with at least 2 completed sea life scores 4.\n· B2 Bountiful Caves: each completed sea life on an inner space scores 3.\n· B3 Underwater Community: each completed sea life adjacent to at least 1 completed sea life scores 2.\n· B4 Spotlight: a column with exactly 1 completed sea life scores 2.\n· B5 Sealife Duet: each pair of adjacent completed sea life scores 4, and each sea life may count in at most one pair.\n· B6 Radiant Caves: each distinct tile in the inner spaces scores 2. Corals count by color and sea life by type.\n· B7 Borders of Diversity: each distinct tile on the outer ring scores 2. Corals count by color and sea life by type.",
			setupPrompt: "Pick 1 tile from the sea life pool and place it on any empty space",
			setupWaiting: "Waiting for {{name}} to place a starting sea life tile…",
			selectPrompt: "Pick 1 fish, then a tile in the same slot",
			selectAnyMode: "Free pairing: pick a fish, then a tile",
			selectWaiting: "Waiting for {{name}} to choose…",
			waitingFor: "Waiting for {{name}}…",
			tilePrompt: "Rotate the tile and place it on an adjacent space",
			fishPrompt: "Place the {{fish}} on an empty corner bubble",
			endPrompt: "End your turn, or move a fish",
			movingFrom: "Pick the fish to move",
			movingTo: "Pick an empty corner bubble for it",
			doneBanner: "Final scoring",
			coralPool: "Coral pool",
			sealifePool: "Sea life pool",
			fishPool: "Fish pool",
			pairLabel: "Slot {{n}}",
			refreshCoral: "Refresh coral pool",
			refreshSealife: "Refresh sea life pool",
			refreshFish: "Refresh fish pool",
			refreshFree: "Free",
			refreshCost: "1 shell",
			anyMode: "Free pairing",
			anyModeCost: "2 shells",
			cancel: "Cancel",
			confirmPlace: "Place here",
			moveCost: "2 shells",
			coralAria: "Coral, {{vp}} points",
			poolEmpty: "Empty slot",
			myBoard: "My sea",
			boardOf: "{{name}}'s sea",
			shellsShort: "{{n}} shells",
			scoreShort: "{{n}} pts",
			emptyBubbleAria: "Empty corner bubble",
			fishAria: "{{fish}}",
			placeAria: "Place at row {{row}}, column {{col}}",
			rotateLeft: "Rotate left",
			rotateRight: "Rotate right",
			zoomControls: "Board zoom",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fitBoard: "Fit board",
			ecoCards: "Ecosystem cards",
			ecoOrange: "Orange card",
			ecoBlue: "Blue card",
			endTurn: "End turn",
			moveFish: "Move fish",
			cancelMove: "Cancel move",
			activeBadge: "Acting",
			completedBadge: "Completed",
			fishRed: "red fish",
			fishYellow: "yellow fish",
			fishGreen: "green fish",
			fishPurple: "purple fish",
			slSameCoral3: "3 spaces, same-color corals",
			slDiffFish3: "3 spaces, different-color fish",
			slDirSameCoral4: "two ways, 4 same-color corals",
			slDiffCoral2: "2 spaces, different-color corals",
			slDirSameFish2: "two ways, 2 same-color fish",
			slDirSameCoral3: "one way, 3 same-color corals",
			slDirDiffFish3: "one way, 3 different-color fish",
			slAnyAllCoral: "all four coral colors",
			sealifeAria: "{{id}}, {{desc}}",
			ecoO1: "Cryptic Coloration",
			ecoO2: "Coral Duo",
			ecoO3: "Symphony of the Tides",
			ecoO4: "Mismatched",
			ecoO5: "Depths Alike",
			ecoO6: "Colossal Coral Reef",
			ecoO7: "Tides",
			ecoB1: "Rich Depths",
			ecoB2: "Bountiful Caves",
			ecoB3: "Underwater Community",
			ecoB4: "Spotlight",
			ecoB5: "Sealife Duet",
			ecoB6: "Radiant Caves",
			ecoB7: "Borders of Diversity",
			ecoO1Cond: "Scores 2 VP for each completed coral with a same-color locked fish.",
			ecoO2Cond: "Scores 3 VP for every 2 completed corals of the same color.",
			ecoO3Cond: "Scores 3 VP per completed fish of the most common color, up to 18 VP.",
			ecoO4Cond: "Scores 2 VP for each completed coral with a different-color locked fish.",
			ecoO5Cond: "Scores 4 VP for each row with at least 2 same-color completed corals.",
			ecoO6Cond: "Scores 2 VP per coral in the largest connected group of completed corals.",
			ecoO7Cond: "Scores 4 VP for each color with at least 3 completed fish.",
			ecoB1Cond: "Scores 4 VP for each row with at least 2 completed sea life tiles.",
			ecoB2Cond: "Scores 3 VP for each completed sea life tile in the inner ring.",
			ecoB3Cond: "Scores 2 VP for each completed sea life tile adjacent to another completed sea life tile.",
			ecoB4Cond: "Scores 2 VP for each column with exactly 1 completed sea life tile.",
			ecoB5Cond: "Scores 4 VP per adjacent pair of completed sea life tiles; each tile counts in at most one pair.",
			ecoB6Cond: "Scores 2 VP for each different kind of tile in the inner ring; corals count by color and sea life by type.",
			ecoB7Cond: "Scores 2 VP for each different kind of tile in the outer ring; corals count by color and sea life by type.",
			scoreTitle: "Final scoring",
			scoreCoral: "Completed corals",
			scoreSealife: "Completed sea life",
			scorePartial: "Partial sea life",
			scoreVariety: "Sea life types",
			scoreFish: "Unfinished fish",
			scoreTotal: "Total",
			errNotYourTurn: "It is not your turn",
			errWrongPhase: "This action is not allowed right now",
			errAlreadySelected: "You already chose this turn",
			errPoolEmpty: "That pool has nothing to take",
			errNoShell: "Not enough shells",
			errNoSelection: "Choose a fish and tile first",
			errBadCell: "That space is not available",
			errBadBubble: "That spot is not available",
			errBadRotate: "That orientation is not available"
		}
	}
};
//#endregion
export { Qt as default };
