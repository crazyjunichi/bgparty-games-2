import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { IconMove as a, IconRotate as o, IconUpdate as s } from "@bgparty/sdk/icons";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u, SeatBadgedAvatar as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/game/data.ts
var h = [
	"red",
	"yellow",
	"green",
	"purple"
], g = {
	red: "#e15b52",
	yellow: "#f0b429",
	green: "#5fa86a",
	purple: "#9b6bc6"
}, _ = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], v = [
	{
		r: 0,
		qs: [
			0,
			1,
			2,
			3
		]
	},
	{
		r: 1,
		qs: [
			-1,
			0,
			1,
			2,
			3
		]
	},
	{
		r: 2,
		qs: [
			0,
			1,
			2,
			3
		]
	},
	{
		r: 3,
		qs: [
			-1,
			0,
			1,
			2,
			3
		]
	},
	{
		r: 4,
		qs: [
			0,
			1,
			2,
			3
		]
	}
], y = /* @__PURE__ */ new Set([
	"0,1",
	"1,1",
	"2,1",
	"0,2",
	"1,2",
	"2,2",
	"3,2",
	"0,3",
	"1,3",
	"2,3"
]), b = "1,2", x = v.flatMap(({ r: e, qs: t }) => t.map((t) => {
	let n = `${t},${e}`;
	return {
		id: n,
		q: t,
		r: e,
		inner: y.has(n),
		center: n === b
	};
})), S = Object.fromEntries(x.map((e) => [e.id, e])), C = x.length;
function w(e, t) {
	return `${e},${t}`;
}
function T(e, t) {
	let n = S[e];
	if (!n) return null;
	let [r, i] = _[t], a = w(n.q + r, n.r + i);
	return S[a] ? a : null;
}
function E(e, t) {
	let n = T(e, t);
	if (n) {
		let [t, r] = [e, n].sort();
		return {
			key: `${t}|${r}`,
			cells: [t, r]
		};
	}
	return {
		key: `B:${e}:${t}`,
		cells: [e]
	};
}
function D(e, t) {
	return {
		x: t * Math.sqrt(3) * (e.q + e.r / 2),
		y: t * 1.5 * e.r
	};
}
var O = {
	2: [0, 3],
	3: [
		0,
		2,
		4
	],
	4: [
		0,
		1,
		3,
		4
	]
};
function k() {
	let e = [], t = [
		{
			vp: 5,
			count: 7
		},
		{
			vp: 7,
			count: 7
		},
		{
			vp: 9,
			count: 5
		}
	], n = 0;
	for (let r of h) for (let i of t) {
		let t = O[i.vp === 5 ? 2 : i.vp === 7 ? 3 : 4];
		for (let a = 0; a < i.count; a += 1) {
			let a = [
				null,
				null,
				null,
				null,
				null,
				null
			];
			t.forEach((e, t) => {
				a[e] = h[(n + t) % h.length];
			}), e.push({
				id: `c${n}`,
				color: r,
				vp: i.vp,
				edges: a
			}), n += 1;
		}
	}
	return e;
}
function ee() {
	return k();
}
var A = {
	A1: {
		id: "A1",
		cls: "A",
		kind: "sameCoral",
		need: 3,
		vp: 6,
		partial: 2,
		offsets: [
			0,
			2,
			4
		]
	},
	A4: {
		id: "A4",
		cls: "A",
		kind: "diffFish",
		need: 3,
		vp: 8,
		partial: 2,
		offsets: [
			1,
			3,
			5
		]
	},
	B1: {
		id: "B1",
		cls: "B",
		kind: "dirSameCoral",
		need: 4,
		vp: 10,
		partial: 2,
		dirs: [0, 3],
		twoWay: !0
	},
	C2: {
		id: "C2",
		cls: "C",
		kind: "diffCoral",
		need: 2,
		vp: 5,
		partial: 2,
		offsets: [0, 3]
	},
	C4: {
		id: "C4",
		cls: "C",
		kind: "dirSameFish",
		need: 2,
		vp: 5,
		partial: 2,
		dirs: [1, 4],
		twoWay: !0
	},
	D1: {
		id: "D1",
		cls: "D",
		kind: "sameCoral",
		need: 3,
		vp: 9,
		partial: 3,
		offsets: [
			1,
			3,
			5
		]
	},
	D4: {
		id: "D4",
		cls: "D",
		kind: "diffFish",
		need: 3,
		vp: 10,
		partial: 3,
		offsets: [
			0,
			2,
			4
		]
	},
	E1: {
		id: "E1",
		cls: "E",
		kind: "dirSameCoral",
		need: 3,
		vp: 8,
		partial: 2,
		dirs: [2],
		twoWay: !1
	},
	E4: {
		id: "E4",
		cls: "E",
		kind: "dirDiffFish",
		need: 3,
		vp: 8,
		partial: 2,
		dirs: [3],
		twoWay: !1
	},
	F2: {
		id: "F2",
		cls: "F",
		kind: "anyAllCoral",
		need: 4,
		vp: 6,
		partial: 1
	}
}, j = [
	"A1",
	"A4",
	"B1",
	"C2",
	"C4",
	"D1",
	"D4",
	"E1",
	"E4",
	"F2"
], M = {
	O1: {
		id: "O1",
		cls: "orange"
	},
	O2: {
		id: "O2",
		cls: "orange"
	},
	O3: {
		id: "O3",
		cls: "orange"
	},
	O4: {
		id: "O4",
		cls: "orange"
	},
	O5: {
		id: "O5",
		cls: "orange"
	},
	O6: {
		id: "O6",
		cls: "orange"
	},
	O7: {
		id: "O7",
		cls: "orange"
	},
	B1: {
		id: "B1",
		cls: "blue"
	},
	B2: {
		id: "B2",
		cls: "blue"
	},
	B3: {
		id: "B3",
		cls: "blue"
	},
	B4: {
		id: "B4",
		cls: "blue"
	},
	B5: {
		id: "B5",
		cls: "blue"
	},
	B6: {
		id: "B6",
		cls: "blue"
	},
	B7: {
		id: "B7",
		cls: "blue"
	}
}, te = Object.values(M).filter((e) => e.cls === "orange").map((e) => e.id), N = Object.values(M).filter((e) => e.cls === "blue").map((e) => e.id);
function P(e) {
	return e >= 4 ? 24 : e === 3 ? 19 : e === 2 ? 14 : 9;
}
function F(e) {
	return e >= 4 ? 4 : e === 3 ? 3 : 2;
}
//#endregion
//#region src/game/meta.ts
var ne = {
	id: "shallowsea",
	uuid: "cea5e489-ab47-4de7-81a1-0e46f9f4753e",
	tier: "alpha",
	mechanics: ["tile-placement", "set-collection"],
	interactionTags: [],
	nameKey: "games.shallowsea.name",
	descKey: "games.shallowsea.desc",
	rulesKey: "games.shallowsea.rules",
	icon: "🪸",
	iconImg: "games/shallowsea.webp",
	rulesUrl: { en: "https://c.tabletopia.com/games/shallow-sea/rules/shallow-sea-rulebook/en" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#0e8f9b",
	releasedAt: "2026-11-23T19:57:00+08:00",
	search: {
		py: "qian hai",
		init: "qh"
	},
	hotseat: "open"
}, I = t.enum([
	"red",
	"yellow",
	"green",
	"purple"
]), re = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("refresh"),
		pool: t.enum([
			"coral",
			"sealife",
			"fish"
		])
	}),
	t.object({
		type: t.literal("select"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"])
	}),
	t.object({
		type: t.literal("selectAny"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"]),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("placeTile"),
		cell: t.string(),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("placeFish"),
		cell: t.string(),
		dir: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("moveFish"),
		fromCell: t.string(),
		fromDir: t.int().min(0).max(5),
		toCell: t.string(),
		toDir: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("endTurn") })
]), L = t.union([
	t.literal(5),
	t.literal(7),
	t.literal(9)
]), R = t.object({
	id: t.string(),
	color: I,
	vp: L,
	edges: t.array(I.nullable()).length(6)
}), ie = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("coral"),
	color: I,
	vp: L,
	edges: t.array(I.nullable()).length(6),
	rot: t.int().min(0).max(5),
	completed: t.boolean(),
	lockedFish: I.nullable()
}), t.object({
	kind: t.literal("sealife"),
	typeId: t.string(),
	rot: t.int().min(0).max(5),
	completed: t.boolean()
})]), ae = t.object({
	cells: t.record(t.string(), ie),
	bubbles: t.record(t.string(), I)
}), oe = t.object({
	orange: t.number(),
	blue: t.number(),
	coralVp: t.number(),
	sealifeVp: t.number(),
	partialVp: t.number(),
	variety: t.number(),
	fishBonus: t.number(),
	total: t.number()
}), se = t.object({
	players: t.array(t.string()),
	boards: t.record(t.string(), ae),
	pools: t.object({
		coral: t.array(R.nullable()).length(5),
		sealife: t.array(t.string().nullable()).length(5),
		fish: t.array(I.nullable()).length(5)
	}),
	ecosystems: t.object({
		orange: t.string(),
		blue: t.string()
	}),
	shells: t.record(t.string(), t.int().min(0).max(5)),
	active: t.string().nullable(),
	phase: t.enum([
		"select",
		"tile",
		"fish",
		"end",
		"done"
	]),
	turnCount: t.int().nonnegative(),
	selection: t.object({
		fish: I,
		fishIdx: t.int(),
		tileKind: t.enum(["coral", "sealife"]),
		coral: R.nullable(),
		sealife: t.string().nullable()
	}).nullable(),
	lastPlaced: t.object({
		rid: t.string(),
		cell: t.string()
	}).nullable(),
	scores: t.record(t.string(), t.number()).nullable(),
	breakdown: t.record(t.string(), oe).nullable()
}), ce = t.object({});
t.object({
	orange: t.string().optional(),
	blue: t.string().optional()
});
//#endregion
//#region src/game/rules.ts
function z(e, t) {
	return e.edges[((t - e.rot) % 6 + 6) % 6];
}
function le(e) {
	return e.startsWith("B:") ? [e.split(":")[1]] : e.split("|");
}
function ue(e, t) {
	if (!S[t] || e.cells[t]) return !1;
	let n = S[t];
	return _.some(([t, r]) => {
		let i = `${n.q + t},${n.r + r}`;
		return !!e.cells[i];
	});
}
function B(e) {
	return Object.keys(S).filter((t) => ue(e, t));
}
function V(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of Object.keys(e.cells)) for (let i = 0; i < 6; i += 1) {
		let { key: a } = E(r, i);
		n.has(a) || e.bubbles[a] || (n.add(a), t.push({
			cell: r,
			dir: i,
			key: a
		}));
	}
	return t;
}
function de(e, t, n) {
	for (let r = 0; r < 6; r += 1) {
		let i = z(n, r);
		if (i && e.bubbles[E(t, r).key] !== i) return !1;
	}
	return !0;
}
function fe(e, t, n) {
	for (let r = 0; r < 6; r += 1) {
		if (!n.edges[r]) continue;
		let { key: i } = E(t, (r + n.rot) % 6), a = e.bubbles[i];
		if (a) return {
			key: i,
			color: a
		};
	}
	return null;
}
function H(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.color : null;
}
function U(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.lockedFish : null;
}
function W(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	let n = 0;
	for (let e of t.values()) n = Math.max(n, e);
	return n;
}
function G(e) {
	return new Set(e).size;
}
function pe(e, t) {
	let n = [], r = e;
	for (; r = T(r, t), r;) n.push(r);
	return n;
}
function K(e, t, n, r) {
	let i = (e) => (e + n.rot) % 6;
	switch (r.kind) {
		case "sameCoral": return W((r.offsets ?? []).map((e) => T(t, i(e))).map((t) => t ? H(e, t) : null).filter((e) => !!e));
		case "diffCoral": return G((r.offsets ?? []).map((e) => T(t, i(e))).map((t) => t ? H(e, t) : null).filter((e) => !!e));
		case "sameFish": return W((r.offsets ?? []).map((e) => T(t, i(e))).map((t) => t ? U(e, t) : null).filter((e) => !!e));
		case "diffFish": return G((r.offsets ?? []).map((e) => T(t, i(e))).map((t) => t ? U(e, t) : null).filter((e) => !!e));
		case "dirSameCoral":
		case "dirDiffCoral":
		case "dirSameFish":
		case "dirDiffFish": {
			let n = (r.dirs ?? []).map(i), a = r.twoWay ? n.flatMap((e) => pe(t, e)) : pe(t, n[0] ?? 0), o = [...new Set(a)], s = r.kind === "dirSameFish" || r.kind === "dirDiffFish", c = o.map((t) => s ? U(e, t) : H(e, t)).filter((e) => !!e);
			return r.kind === "dirSameCoral" || r.kind === "dirSameFish" ? W(c) : G(c);
		}
		case "anyAllCoral": return G(Object.keys(e.cells).map((t) => H(e, t)).filter((e) => !!e));
	}
}
function me(e, t) {
	e.shells[t] = Math.min(5, (e.shells[t] ?? 0) + 1);
}
function q(e, t) {
	let n = e.boards[t], r = [];
	for (let i = 0; i < C; i += 1) {
		let i = Object.keys(n.cells).sort().find((e) => {
			let t = n.cells[e];
			return t.kind === "coral" && !t.completed && de(n, e, t);
		});
		if (!i) break;
		let a = n.cells[i], o = fe(n, i, a);
		o && delete n.bubbles[o.key], a.completed = !0, a.lockedFish = o?.color ?? null, me(e, t), r.push(i);
	}
	for (let i of Object.keys(n.cells).sort()) {
		let a = n.cells[i];
		if (a.kind !== "sealife" || a.completed) continue;
		let o = A[a.typeId];
		o && K(n, i, a, o) >= o.need && (a.completed = !0, me(e, t), r.push(i));
	}
	return r.length > 0 ? [{
		kind: "shallow-complete",
		rid: t,
		data: { cells: r }
	}] : [];
}
function J(e) {
	return Object.keys(e.cells).filter((t) => H(e, t) != null);
}
function he(e) {
	return Object.keys(e.cells).filter((t) => {
		let n = e.cells[t];
		return n.kind === "sealife" && n.completed;
	});
}
function ge(e) {
	let t = [];
	for (let n of Object.keys(e.cells)) {
		let r = U(e, n);
		r && t.push({
			cell: n,
			color: r
		});
	}
	return t;
}
function _e(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of J(e)) {
		let r = H(e, n);
		t.set(r, (t.get(r) ?? 0) + 1);
	}
	return t;
}
function ve(e) {
	let t = e.length;
	if (t < 2) return 0;
	let n = new Map(e.map((e, t) => [e, t])), r = e.map((e) => {
		let t = S[e], r = [];
		for (let [e, i] of _) {
			let a = n.get(`${t.q + e},${t.r + i}`);
			a !== void 0 && r.push(a);
		}
		return r;
	}), i = /* @__PURE__ */ new Map(), a = (e) => {
		if (e === 0) return 0;
		let t = i.get(e);
		if (t !== void 0) return t;
		let n = 31 - Math.clz32(e & -e), o = a(e & ~(1 << n));
		for (let t of r[n]) e & 1 << t && (o = Math.max(o, 1 + a(e & ~(1 << n) & ~(1 << t))));
		return i.set(e, o), o;
	};
	return a((1 << t) - 1);
}
function ye(e, t) {
	let n = J(e), r = he(e);
	switch (t) {
		case "O1": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish === r.color ? 2 : 0);
		}, 0);
		case "O2": {
			let t = 0;
			for (let n of _e(e).values()) t += Math.floor(n / 2) * 3;
			return t;
		}
		case "O3": {
			let t = /* @__PURE__ */ new Map();
			for (let n of ge(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) n = Math.max(n, e);
			return Math.min(n * 3, 18);
		}
		case "O4": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish != null && r.lockedFish !== r.color ? 2 : 0);
		}, 0);
		case "O5": {
			let t = /* @__PURE__ */ new Map();
			for (let r of n) {
				let n = S[r].r, i = H(e, r), a = t.get(n) ?? /* @__PURE__ */ new Map();
				a.set(i, (a.get(i) ?? 0) + 1), t.set(n, a);
			}
			let r = 0;
			for (let e of t.values()) [...e.values()].some((e) => e >= 2) && (r += 4);
			return r;
		}
		case "O6": {
			let e = new Set(n), t = /* @__PURE__ */ new Set(), r = 0;
			for (let i of n) {
				if (t.has(i)) continue;
				let n = [i];
				t.add(i);
				let a = 0;
				for (; n.length > 0;) {
					let r = n.pop();
					a += 1;
					let i = S[r];
					for (let [r, a] of _) {
						let o = `${i.q + r},${i.r + a}`;
						e.has(o) && !t.has(o) && (t.add(o), n.push(o));
					}
				}
				r = Math.max(r, a);
			}
			return r * 2;
		}
		case "O7": {
			let t = /* @__PURE__ */ new Map();
			for (let n of ge(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) e >= 3 && (n += 4);
			return n;
		}
		case "B1": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = S[t].r;
				e.set(n, (e.get(n) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n >= 2 && (t += 4);
			return t;
		}
		case "B2": return r.filter((e) => S[e].inner).length * 3;
		case "B3": return r.filter((t) => {
			let n = S[t];
			return _.some(([t, r]) => {
				let i = e.cells[`${n.q + t},${n.r + r}`];
				return i?.kind === "sealife" && i.completed;
			});
		}).length * 2;
		case "B4": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = S[t], r = 2 * n.q + n.r;
				e.set(r, (e.get(r) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n === 1 && (t += 2);
			return t;
		}
		case "B5": return ve(r) * 4;
		case "B6":
		case "B7": {
			let n = t === "B6", r = /* @__PURE__ */ new Set();
			for (let t of Object.keys(e.cells)) {
				if (S[t].inner !== n) continue;
				let i = e.cells[t];
				r.add(i.kind === "coral" ? `c:${i.color}` : `s:${i.typeId}`);
			}
			return r.size * 2;
		}
		default: return 0;
	}
}
function be(e) {
	let t = 0;
	for (let n of Object.keys(e.bubbles)) for (let r of le(n)) {
		let n = e.cells[r];
		n && n.kind === "coral" && n.completed && (t += 1);
	}
	return t;
}
function xe(e, t) {
	let n = 0;
	for (let t of J(e)) {
		let r = e.cells[t];
		n += r.vp;
	}
	let r = 0, i = 0, a = /* @__PURE__ */ new Set();
	for (let t of Object.keys(e.cells)) {
		let n = e.cells[t];
		if (n.kind !== "sealife") continue;
		let o = A[n.typeId];
		o && (n.completed ? (r += o.vp, a.add(n.typeId)) : i += Math.min(K(e, t, n, o), o.need) * o.partial);
	}
	let o = a.size * 2, s = ye(e, t.orange), c = ye(e, t.blue), l = be(e);
	return {
		orange: s,
		blue: c,
		coralVp: n,
		sealifeVp: r,
		partialVp: i,
		variety: o,
		fishBonus: l,
		total: s + c + n + r + i + o + l
	};
}
function Y(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.n, i + 1);
		r.n += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function Se(e) {
	let t = F(e);
	return j.flatMap((e) => Array(t).fill(e));
}
function Ce(e) {
	let t = P(e);
	return h.flatMap((e) => Array(t).fill(e));
}
function we(e) {
	for (let t = 0; t < 5; t += 1) e.pools.coral[t] || (e.pools.coral[t] = e.coralDeck.pop() ?? null), e.pools.sealife[t] || (e.pools.sealife[t] = e.sealifeDeck.pop() ?? null), e.pools.fish[t] || (e.pools.fish[t] = e.fishDeck.pop() ?? null);
}
function Te(t, n, r) {
	let i = t ?? {}, a = typeof i.orange == "string" && te.includes(i.orange) ? i.orange : "O1", o = typeof i.blue == "string" && N.includes(i.blue) ? i.blue : "B1", s = { n: 0 }, c = Y(ee(), r, s), l = Y(Se(n.length), r, s), u = Y(Ce(n.length), r, s), d = {}, f = {};
	for (let t of n) {
		let n = l.pop() ?? j[0], i = e(r, s.n, 6);
		s.n += 1, d[t] = {
			cells: { "1,2": {
				kind: "sealife",
				typeId: n,
				rot: i,
				completed: !1
			} },
			bubbles: {}
		}, f[t] = 2;
	}
	let p = {
		players: [...n],
		boards: d,
		pools: {
			coral: [],
			sealife: [],
			fish: []
		},
		coralDeck: c,
		sealifeDeck: l,
		fishDeck: u,
		ecosystems: {
			orange: a,
			blue: o
		},
		shells: f,
		active: null,
		phase: "select",
		turnCount: 0,
		selection: null,
		lastPlaced: null
	};
	for (let e = 0; e < 5; e += 1) p.pools.coral.push(c.pop() ?? null), p.pools.sealife.push(l.pop() ?? null), p.pools.fish.push(u.pop() ?? null);
	return p.active = n[e(r, s.n, n.length)], {
		state: p,
		fx: []
	};
}
function Ee() {
	return { code: "games.shallowsea.errNotYourTurn" };
}
function De(e) {
	if (e.turnCount += 1, e.turnCount >= e.players.length * 17) {
		e.phase = "done", e.active = null;
		return;
	}
	let t = e.players.indexOf(e.active ?? e.players[0]);
	e.active = e.players[(t + 1) % e.players.length], e.phase = "select";
}
function Oe(e, t, n) {
	if (e.phase === "done" || e.active !== n.by) return Ee();
	let r = structuredClone(e);
	switch (t.type) {
		case "refresh": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = r.pools[t.pool];
			if (i.every((e) => e == null)) return { code: "games.shallowsea.errPoolEmpty" };
			let a = !1;
			if (t.pool === "coral") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.coral) t && e.set(t.color, (e.get(t.color) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			} else if (t.pool === "fish") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.fish) t && e.set(t, (e.get(t) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			}
			if (!a) {
				if ((r.shells[n.by] ?? 0) < 1) return { code: "games.shallowsea.errNoShell" };
				--r.shells[n.by];
			}
			for (let e = 0; e < i.length; e += 1) t.pool === "coral" ? r.pools.coral[e] = r.coralDeck.pop() ?? null : t.pool === "sealife" ? r.pools.sealife[e] = r.sealifeDeck.pop() ?? null : r.pools.fish[e] = r.fishDeck.pop() ?? null;
			return {
				state: r,
				fx: []
			};
		}
		case "select":
		case "selectAny": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = t.fish, a = t.type === "select" ? t.fish : t.index;
			if (t.type === "selectAny" && (r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let o = r.pools.fish[i];
			if (!o) return { code: "games.shallowsea.errPoolEmpty" };
			let s = null, c = null;
			if (t.tile === "coral") {
				if (s = r.pools.coral[a] ?? null, !s) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.coral[a] = null;
			} else {
				if (c = r.pools.sealife[a] ?? null, !c) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.sealife[a] = null;
			}
			return r.pools.fish[i] = null, t.type === "selectAny" && (r.shells[n.by] -= 2), r.selection = {
				fish: o,
				fishIdx: i,
				tileKind: t.tile,
				coral: s,
				sealife: c
			}, r.phase = "tile", {
				state: r,
				fx: []
			};
		}
		case "placeTile": {
			if (e.phase !== "tile") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			if (!ue(a, t.cell)) return { code: "games.shallowsea.errBadCell" };
			if (i.tileKind === "coral" && i.coral) a.cells[t.cell] = {
				kind: "coral",
				color: i.coral.color,
				vp: i.coral.vp,
				edges: [...i.coral.edges],
				rot: t.rot,
				completed: !1,
				lockedFish: null
			};
			else if (i.tileKind === "sealife" && i.sealife) a.cells[t.cell] = {
				kind: "sealife",
				typeId: i.sealife,
				rot: t.rot,
				completed: !1
			};
			else return { code: "games.shallowsea.errNoSelection" };
			return r.lastPlaced = {
				rid: n.by,
				cell: t.cell
			}, r.phase = "fish", {
				state: r,
				fx: q(r, n.by)
			};
		}
		case "placeFish": {
			if (e.phase !== "fish") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			if (!a.cells[t.cell]) return { code: "games.shallowsea.errBadBubble" };
			let { key: o } = E(t.cell, t.dir);
			return a.bubbles[o] ? { code: "games.shallowsea.errBadBubble" } : (a.bubbles[o] = i.fish, r.phase = "end", {
				state: r,
				fx: q(r, n.by)
			});
		}
		case "moveFish": {
			if (e.phase !== "tile" && e.phase !== "fish" && e.phase !== "end") return { code: "games.shallowsea.errWrongPhase" };
			if ((r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let i = r.boards[n.by], a = E(t.fromCell, t.fromDir), o = E(t.toCell, t.toDir), s = i.bubbles[a.key];
			return !s || !i.cells[t.toCell] || i.bubbles[o.key] ? { code: "games.shallowsea.errBadBubble" } : (delete i.bubbles[a.key], i.bubbles[o.key] = s, r.shells[n.by] -= 2, {
				state: r,
				fx: q(r, n.by)
			});
		}
		case "endTurn": return e.phase === "end" ? (r.selection = null, we(r), De(r), {
			state: r,
			fx: []
		}) : { code: "games.shallowsea.errWrongPhase" };
	}
	return { code: "games.shallowsea.errWrongPhase" };
}
function ke(e) {
	let t = e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, xe(e.boards[t], e.ecosystems)])) : null, n = t ? Object.fromEntries(Object.entries(t).map(([e, t]) => [e, t.total])) : null;
	return {
		public: {
			players: e.players,
			boards: e.boards,
			pools: e.pools,
			ecosystems: e.ecosystems,
			shells: e.shells,
			active: e.active,
			phase: e.phase,
			turnCount: e.turnCount,
			selection: e.selection,
			lastPlaced: e.lastPlaced,
			scores: n,
			breakdown: t
		},
		private: {}
	};
}
function Ae(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => ({
		rid: t,
		...xe(e.boards[t], e.ecosystems)
	})), n = Object.fromEntries(t.map((e) => [e.rid, e.total])), r = new Map(e.players.map((e, t) => [e, t])), i = [...e.players].sort((t, i) => {
		if (n[i] !== n[t]) return n[i] - n[t];
		let a = (e.shells[i] ?? 0) - (e.shells[t] ?? 0);
		return a === 0 ? (r.get(t) ?? 0) - (r.get(i) ?? 0) : a;
	}), a = i[0];
	return {
		phase: "done",
		winner: i.filter((t) => n[t] === n[a] && (e.shells[t] ?? 0) === (e.shells[a] ?? 0)),
		ranking: i,
		scores: n
	};
}
var je = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ne,
	schemas: {
		action: re,
		publicView: se,
		privateView: ce
	},
	setup: Te,
	reduce: Oe,
	viewFor: ke,
	status: Ae
}, X = Math.sqrt(3) / 2, Me = [
	[0, -1],
	[X, -.5],
	[X, .5],
	[0, 1],
	[-X, .5],
	[-X, -.5]
], Ne = [
	[[X, -.5], [X, .5]],
	[[0, -1], [X, -.5]],
	[[-X, -.5], [0, -1]],
	[[-X, .5], [-X, -.5]],
	[[0, 1], [-X, .5]],
	[[X, .5], [0, 1]]
], Pe = Ne.map(([e, t]) => [(e[0] + t[0]) / 2, (e[1] + t[1]) / 2]), Z = {
	x: -2.15,
	y: -1.2,
	w: 12.4,
	h: 8.4
}, Fe = `${Z.x} ${Z.y} ${Z.w} ${Z.h}`, Q = {
	red: "games.shallowsea.fishRed",
	yellow: "games.shallowsea.fishYellow",
	green: "games.shallowsea.fishGreen",
	purple: "games.shallowsea.fishPurple"
}, Ie = {
	A1: "games.shallowsea.slSameCoral3",
	A4: "games.shallowsea.slDiffFish3",
	B1: "games.shallowsea.slDirSameCoral4",
	C2: "games.shallowsea.slDiffCoral2",
	C4: "games.shallowsea.slDirSameFish2",
	D1: "games.shallowsea.slSameCoral3",
	D4: "games.shallowsea.slDiffFish3",
	E1: "games.shallowsea.slDirSameCoral3",
	E4: "games.shallowsea.slDirDiffFish3",
	F2: "games.shallowsea.slAnyAllCoral"
}, Le = {
	O1: "games.shallowsea.ecoO1",
	O2: "games.shallowsea.ecoO2",
	O3: "games.shallowsea.ecoO3",
	O4: "games.shallowsea.ecoO4",
	O5: "games.shallowsea.ecoO5",
	O6: "games.shallowsea.ecoO6",
	O7: "games.shallowsea.ecoO7",
	B1: "games.shallowsea.ecoB1",
	B2: "games.shallowsea.ecoB2",
	B3: "games.shallowsea.ecoB3",
	B4: "games.shallowsea.ecoB4",
	B5: "games.shallowsea.ecoB5",
	B6: "games.shallowsea.ecoB6",
	B7: "games.shallowsea.ecoB7"
};
function $(e, t, n = 1) {
	return Me.map(([r, i]) => `${e + r * n},${t + i * n}`).join(" ");
}
function Re(e) {
	return Ie[e] ?? null;
}
function ze(e) {
	let t = e.public;
	return /* @__PURE__ */ p(He, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Be(e) {
	return {
		key: e,
		fishPick: null,
		freeMode: !1,
		pendingCell: null,
		rot: 0,
		movingFrom: !1,
		moveFrom: null
	};
}
function Ve(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!n) continue;
		let e = typeof n == "string" ? n : n.color;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	return [...t.values()].some((e) => e >= 4);
}
function He({ pub: e, members: t, myRid: s, send: h }) {
	let g = i(), _ = r((e) => e.locale), v = (e) => t.find((t) => t.rid === e)?.name ?? e, y = e.boards[s], b = e.shells[s] ?? 0, x = e.selection, C = e.phase, w = e.active === s, T = `${e.turnCount}:${C}`, [E, D] = n(() => Be(T));
	E.key !== T && D(Be(T));
	let O = (e) => D((t) => ({
		...t,
		...e
	})), k = E.freeMode && b >= 2, ee = Ve(e.pools.coral), A = Ve(e.pools.fish), j = "info", M;
	if (C === "done") j = "done", M = g("games.shallowsea.doneBanner");
	else if (w) j = "accent", M = C === "select" ? g(k ? "games.shallowsea.selectAnyMode" : "games.shallowsea.selectPrompt") : C === "tile" ? g("games.shallowsea.tilePrompt") : C === "fish" ? g("games.shallowsea.fishPrompt", { fish: x ? g(Q[x.fish]) : "" }) : E.movingFrom ? g("games.shallowsea.movingFrom") : E.moveFrom ? g("games.shallowsea.movingTo") : g("games.shallowsea.endPrompt");
	else {
		let t = e.active ? v(e.active) : "";
		M = g(C === "select" ? "games.shallowsea.selectWaiting" : "games.shallowsea.waitingFor", { name: t });
	}
	let te = C === "tile" && y ? B(y) : [], N, P;
	C === "fish" && y ? (N = new Set(V(y).map((e) => e.key)), P = (e, t) => h({
		type: "placeFish",
		cell: e,
		dir: t
	})) : C === "end" && y && E.movingFrom ? (N = new Set(Object.keys(y.bubbles)), P = (e, t) => O({
		movingFrom: !1,
		moveFrom: {
			cell: e,
			dir: t
		}
	})) : C === "end" && y && E.moveFrom && (N = new Set(V(y).map((e) => e.key)), P = (e, t) => {
		E.moveFrom && h({
			type: "moveFish",
			fromCell: E.moveFrom.cell,
			fromDir: E.moveFrom.dir,
			toCell: e,
			toDir: t
		});
	});
	let F = null, I;
	C === "tile" && x && E.pendingCell && (x.tileKind === "coral" && x.coral ? F = {
		cell: E.pendingCell,
		tile: {
			kind: "coral",
			color: x.coral.color,
			vp: x.coral.vp,
			edges: x.coral.edges,
			rot: E.rot,
			completed: !1,
			lockedFish: null
		}
	} : x.tileKind === "sealife" && x.sealife && (F = {
		cell: E.pendingCell,
		tile: {
			kind: "sealife",
			typeId: x.sealife,
			rot: E.rot,
			completed: !1
		}
	}, I = We(x.sealife, E.pendingCell, E.rot)));
	let re = e.lastPlaced && e.lastPlaced.rid === s ? e.lastPlaced.cell : null, L = /* @__PURE__ */ m("div", {
		className: "shallowsea-banner flex flex-col",
		children: [
			/* @__PURE__ */ p(l, {
				tone: j,
				text: M,
				accent: ne.accent
			}),
			/* @__PURE__ */ p("div", {
				className: "shallowsea-strip-wide",
				children: /* @__PURE__ */ p(u, {
					variant: "plate",
					members: t,
					myRid: s,
					status: (t) => {
						let n = e.scores?.[t];
						return /* @__PURE__ */ m("span", {
							className: "shallowsea-player-status",
							children: [/* @__PURE__ */ p("span", { children: g("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 }) }), n != null && /* @__PURE__ */ p("span", {
								className: "shallowsea-player-score",
								children: g("games.shallowsea.scoreShort", { n })
							})]
						});
					},
					action: (t) => e.active === t && C !== "done" ? "pending" : null
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "shallowsea-strip-short",
				children: t.map((t) => /* @__PURE__ */ m("span", {
					className: "shallowsea-shortseat",
					children: [
						/* @__PURE__ */ p(d, {
							m: t,
							myRid: s,
							action: e.active === t.rid && C !== "done" ? "pending" : null,
							anchorName: null,
							box: "size-6",
							img: "size-5"
						}),
						/* @__PURE__ */ p("span", {
							className: "shallowsea-shortname",
							children: f(t, _)
						}),
						/* @__PURE__ */ p("span", {
							className: "shallowsea-shortshells",
							children: g("games.shallowsea.shellsShort", { n: e.shells[t.rid] ?? 0 })
						})
					]
				}, t.rid))
			})
		]
	}), R = (() => {
		if (C === "done") return /* @__PURE__ */ p("div", { className: "shallowsea-tray" });
		if (C === "select") {
			let t = (e) => E.fishPick != null && (k || E.fishPick === e);
			return /* @__PURE__ */ m("div", {
				className: "shallowsea-tray",
				children: [
					/* @__PURE__ */ m("div", {
						className: "shallowsea-tray-head",
						children: [/* @__PURE__ */ p("span", {
							className: "shallowsea-tray-hint",
							children: g(k ? "games.shallowsea.selectAnyMode" : "games.shallowsea.selectPrompt")
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "shallowsea-free",
							"data-on": k,
							"aria-pressed": k,
							disabled: b < 2 && !k,
							onClick: () => O({ freeMode: !E.freeMode }),
							children: [
								g("games.shallowsea.anyMode"),
								" · ",
								g("games.shallowsea.anyModeCost")
							]
						})]
					}),
					/* @__PURE__ */ p($e, {
						label: g("games.shallowsea.coralPool"),
						refreshLabel: g("games.shallowsea.refreshCoral"),
						cost: g(ee ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !ee && b < 1,
						onRefresh: () => h({
							type: "refresh",
							pool: "coral"
						}),
						children: e.pools.coral.map((e, n) => /* @__PURE__ */ p("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": E.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? g("games.shallowsea.coralAria", { vp: e.vp }) : g("games.shallowsea.poolEmpty"),
							onClick: () => E.fishPick != null && h(k ? {
								type: "selectAny",
								fish: E.fishPick,
								tile: "coral",
								index: n
							} : {
								type: "select",
								fish: E.fishPick,
								tile: "coral"
							}),
							children: e ? /* @__PURE__ */ p(Xe, { coral: e }) : /* @__PURE__ */ p("span", { className: "shallowsea-chip-empty" })
						}, n))
					}),
					/* @__PURE__ */ p($e, {
						label: g("games.shallowsea.fishPool"),
						refreshLabel: g("games.shallowsea.refreshFish"),
						cost: g(A ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !A && b < 1,
						onRefresh: () => h({
							type: "refresh",
							pool: "fish"
						}),
						children: e.pools.fish.map((e, t) => /* @__PURE__ */ p("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": E.fishPick === t,
							disabled: !e,
							"aria-label": g(e ? Q[e] : "games.shallowsea.poolEmpty"),
							onClick: () => e && O({ fishPick: E.fishPick === t ? null : t }),
							children: e ? /* @__PURE__ */ p(Qe, { color: e }) : /* @__PURE__ */ p("span", { className: "shallowsea-chip-empty" })
						}, t))
					}),
					/* @__PURE__ */ p($e, {
						label: g("games.shallowsea.sealifePool"),
						refreshLabel: g("games.shallowsea.refreshSealife"),
						cost: g("games.shallowsea.refreshCost"),
						refreshDisabled: b < 1,
						onRefresh: () => h({
							type: "refresh",
							pool: "sealife"
						}),
						children: e.pools.sealife.map((e, n) => /* @__PURE__ */ p("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": E.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? g("games.shallowsea.sealifeAria", {
								id: e,
								desc: Ue(e, g)
							}) : g("games.shallowsea.poolEmpty"),
							onClick: () => E.fishPick != null && h(k ? {
								type: "selectAny",
								fish: E.fishPick,
								tile: "sealife",
								index: n
							} : {
								type: "select",
								fish: E.fishPick,
								tile: "sealife"
							}),
							children: e ? /* @__PURE__ */ p(Ze, { typeId: e }) : /* @__PURE__ */ p("span", { className: "shallowsea-chip-empty" })
						}, n))
					})
				]
			});
		}
		if (C === "tile") {
			let e = x?.tileKind === "sealife" && x.sealife ? Re(x.sealife) : null;
			return /* @__PURE__ */ m("div", {
				className: "shallowsea-tray shallowsea-tray-actions",
				children: [x && /* @__PURE__ */ m("div", {
					className: "shallowsea-pending",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "shallowsea-rot",
							"aria-label": g("games.shallowsea.rotateLeft"),
							onClick: () => O({ rot: (E.rot + 5) % 6 }),
							children: /* @__PURE__ */ p(o, {
								size: 18,
								className: "shallowsea-mirror",
								"aria-hidden": !0
							})
						}),
						x.tileKind === "coral" && x.coral ? /* @__PURE__ */ p(Xe, {
							coral: x.coral,
							size: 52
						}) : x.sealife ? /* @__PURE__ */ p(Ze, {
							typeId: x.sealife,
							size: 52
						}) : null,
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "shallowsea-rot",
							"aria-label": g("games.shallowsea.rotateRight"),
							onClick: () => O({ rot: (E.rot + 1) % 6 }),
							children: /* @__PURE__ */ p(o, {
								size: 18,
								"aria-hidden": !0
							})
						}),
						e && /* @__PURE__ */ p("span", {
							className: "shallowsea-pending-text",
							children: g(e)
						})
					]
				}), /* @__PURE__ */ m("div", {
					className: "shallowsea-buttons",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "shallowsea-btn is-primary",
						disabled: !E.pendingCell,
						onClick: () => E.pendingCell && h({
							type: "placeTile",
							cell: E.pendingCell,
							rot: E.rot
						}),
						children: g("games.shallowsea.confirmPlace")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "shallowsea-btn",
						disabled: !E.pendingCell,
						onClick: () => O({ pendingCell: null }),
						children: g("games.shallowsea.cancel")
					})]
				})]
			});
		}
		return C === "fish" ? /* @__PURE__ */ p("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ m("div", {
				className: "shallowsea-pending",
				children: [x && /* @__PURE__ */ p(Qe, {
					color: x.fish,
					size: 40
				}), /* @__PURE__ */ p("span", {
					className: "shallowsea-pending-text",
					children: x ? g("games.shallowsea.fishPrompt", { fish: g(Q[x.fish]) }) : g("games.shallowsea.selectPrompt")
				})]
			})
		}) : /* @__PURE__ */ p("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ m("div", {
				className: "shallowsea-buttons",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "shallowsea-btn is-primary",
					onClick: () => h({ type: "endTurn" }),
					children: g("games.shallowsea.endTurn")
				}), !E.movingFrom && !E.moveFrom ? /* @__PURE__ */ m("button", {
					type: "button",
					className: "shallowsea-btn",
					disabled: b < 2,
					onClick: () => O({ movingFrom: !0 }),
					children: [/* @__PURE__ */ p(a, {
						size: 16,
						"aria-hidden": !0
					}), /* @__PURE__ */ m("span", { children: [
						g("games.shallowsea.moveFish"),
						" · ",
						g("games.shallowsea.moveCost")
					] })]
				}) : /* @__PURE__ */ p("button", {
					type: "button",
					className: "shallowsea-btn",
					onClick: () => O({
						movingFrom: !1,
						moveFrom: null
					}),
					children: g("games.shallowsea.cancelMove")
				})]
			})
		});
	})();
	return /* @__PURE__ */ p("div", {
		className: "shallowsea-screen h-full min-h-0",
		children: /* @__PURE__ */ p(c, {
			adaptive: !0,
			banner: L,
			actions: R,
			actionsHeight: "shallowsea-actions",
			children: /* @__PURE__ */ m("div", {
				className: "shallowsea-table",
				children: [
					C === "done" && /* @__PURE__ */ p(et, {
						pub: e,
						nameOf: v
					}),
					/* @__PURE__ */ m("section", {
						className: "shallowsea-main",
						children: [/* @__PURE__ */ m("div", {
							className: "shallowsea-board-head",
							children: [/* @__PURE__ */ p("span", { children: g("games.shallowsea.myBoard") }), /* @__PURE__ */ p("span", {
								className: "font-mono tabular-nums",
								children: g("games.shallowsea.shellsShort", { n: b })
							})]
						}), /* @__PURE__ */ p(Ge, {
							board: y,
							label: g("games.shallowsea.myBoard"),
							placeAria: (e) => {
								let t = S[e];
								return t ? g("games.shallowsea.placeAria", {
									row: t.r + 1,
									col: t.q + 2
								}) : "";
							},
							fishAria: (e) => g(Q[e]),
							bubbleAria: g("games.shallowsea.emptyBubbleAria"),
							legalCells: w ? new Set(te) : void 0,
							onCell: w ? (e) => O({ pendingCell: e }) : void 0,
							bubbleTargets: w ? N : void 0,
							onBubble: w ? P : void 0,
							markers: I,
							preview: F,
							lastPlaced: re
						})]
					}),
					e.players.length > 1 && /* @__PURE__ */ p("aside", {
						className: "shallowsea-others",
						children: e.players.filter((e) => e !== s).map((t) => /* @__PURE__ */ m("div", {
							className: "shallowsea-mini",
							children: [/* @__PURE__ */ m("div", {
								className: "shallowsea-mini-head",
								children: [/* @__PURE__ */ p("span", {
									className: "truncate",
									children: v(t)
								}), /* @__PURE__ */ p("span", {
									className: "font-mono tabular-nums",
									children: g("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 })
								})]
							}), /* @__PURE__ */ p(Ge, {
								board: e.boards[t],
								label: g("games.shallowsea.boardOf", { name: v(t) })
							})]
						}, t))
					})
				]
			})
		})
	});
}
function Ue(e, t) {
	let n = Re(e);
	return n ? t(n) : e;
}
function We(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = A[e];
	if (!i) return r;
	for (let e of i.offsets ?? []) {
		let i = T(t, (e + n) % 6);
		i && r.add(i);
	}
	for (let e of i.dirs ?? []) {
		let i = t;
		for (;;) {
			let t = T(i, (e + n) % 6);
			if (!t) break;
			r.add(t), i = t;
		}
	}
	return r;
}
function Ge({ board: e, label: t, placeAria: n, fishAria: r, bubbleAria: i, legalCells: a, onCell: o, bubbleTargets: s, onBubble: c, markers: l, preview: u, lastPlaced: d }) {
	let f = [], h = /* @__PURE__ */ new Set();
	for (let e of x) {
		let t = D(e, 1);
		for (let n = 0; n < 6; n += 1) {
			let { key: r } = E(e.id, n);
			if (h.has(r)) continue;
			h.add(r);
			let [i, a] = Pe[n];
			f.push({
				key: r,
				cell: e.id,
				dir: n,
				x: t.x + i,
				y: t.y + a
			});
		}
	}
	let g = u ? S[u.cell] : null, _ = g ? D(g, 1) : null;
	return /* @__PURE__ */ p("div", {
		className: "shallowsea-board-frame",
		children: /* @__PURE__ */ m("svg", {
			viewBox: Fe,
			className: "shallowsea-board-svg",
			role: "group",
			"aria-label": t,
			children: [
				x.map((t) => {
					let r = D(t, 1), i = e?.cells[t.id], s = !!(a?.has(t.id) && o);
					return /* @__PURE__ */ m("g", { children: [
						/* @__PURE__ */ p("polygon", {
							points: $(r.x, r.y, .985),
							className: `shallowsea-hex${s ? " is-legal" : ""}`,
							onClick: s && o ? () => o(t.id) : void 0,
							onKeyDown: s && o ? (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o(t.id));
							} : void 0,
							role: s ? "button" : void 0,
							tabIndex: s ? 0 : void 0,
							"aria-label": s && n ? n(t.id) : void 0
						}),
						l?.has(t.id) && /* @__PURE__ */ p("polygon", {
							points: $(r.x, r.y, .8),
							className: "shallowsea-hex-mark"
						}),
						i && (i.kind === "coral" ? /* @__PURE__ */ p(qe, {
							tile: i,
							x: r.x,
							y: r.y
						}) : /* @__PURE__ */ p(Je, {
							tile: i,
							x: r.x,
							y: r.y
						})),
						d === t.id && /* @__PURE__ */ p("polygon", {
							points: $(r.x, r.y, 1),
							className: "shallowsea-hex-last"
						})
					] }, t.id);
				}),
				f.map((t) => {
					let n = e?.bubbles[t.key], a = !!(s?.has(t.key) && c);
					return /* @__PURE__ */ m("g", { children: [n ? /* @__PURE__ */ p(Ke, {
						x: t.x,
						y: t.y,
						color: n
					}) : a && /* @__PURE__ */ p("circle", {
						cx: t.x,
						cy: t.y,
						r: .14,
						className: "shallowsea-bubble-dot"
					}), a && c && /* @__PURE__ */ p("circle", {
						cx: t.x,
						cy: t.y,
						r: .32,
						className: "shallowsea-hit",
						role: "button",
						tabIndex: 0,
						"aria-label": n && r ? r(n) : i,
						onClick: () => c(t.cell, t.dir),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), c(t.cell, t.dir));
						}
					})] }, t.key);
				}),
				u && _ && /* @__PURE__ */ m("g", {
					className: "shallowsea-preview",
					children: [u.tile.kind === "coral" ? /* @__PURE__ */ p(qe, {
						tile: u.tile,
						x: _.x,
						y: _.y
					}) : /* @__PURE__ */ p(Je, {
						tile: u.tile,
						x: _.x,
						y: _.y
					}), /* @__PURE__ */ p("polygon", {
						points: $(_.x, _.y, 1),
						className: "shallowsea-hex-preview"
					})]
				})
			]
		})
	});
}
function Ke({ x: e, y: t, color: n }) {
	return /* @__PURE__ */ m("g", {
		transform: `translate(${e} ${t})`,
		className: "shallowsea-fish-token",
		children: [
			/* @__PURE__ */ p("circle", {
				r: .25,
				fill: g[n],
				stroke: "#08252c",
				strokeWidth: .05
			}),
			/* @__PURE__ */ p("path", {
				d: "M-0.16,0 L-0.02,-0.09 L-0.02,0.09 Z",
				fill: "#fff"
			}),
			/* @__PURE__ */ p("ellipse", {
				cx: .05,
				cy: 0,
				rx: .11,
				ry: .065,
				fill: "#fff"
			})
		]
	});
}
function qe({ tile: e, x: t, y: n }) {
	let r = g[e.color];
	return /* @__PURE__ */ m("g", {
		className: "shallowsea-face",
		children: [
			/* @__PURE__ */ p("polygon", {
				points: $(t, n, .97),
				fill: r,
				fillOpacity: e.completed ? .55 : .42,
				stroke: "#08252c",
				strokeWidth: .055
			}),
			[
				0,
				1,
				2,
				3,
				4,
				5
			].map((r) => {
				let i = z(e, r);
				if (!i) return null;
				let [a, o] = Ne[r];
				return /* @__PURE__ */ p("line", {
					x1: t + a[0] * .86,
					y1: n + a[1] * .86,
					x2: t + o[0] * .86,
					y2: n + o[1] * .86,
					stroke: g[i],
					strokeWidth: .19,
					strokeLinecap: "round"
				}, r);
			}),
			/* @__PURE__ */ p("text", {
				x: t,
				y: n + .15,
				textAnchor: "middle",
				fontSize: .4,
				fontWeight: 800,
				fill: "#08252c",
				children: e.vp
			}),
			e.completed && /* @__PURE__ */ p("polygon", {
				points: $(t, n, .9),
				fill: "none",
				stroke: "#10b1a6",
				strokeWidth: .08,
				strokeDasharray: "0.22 0.12"
			}),
			e.lockedFish && /* @__PURE__ */ p(Ke, {
				x: t,
				y: n - .5,
				color: e.lockedFish
			})
		]
	});
}
function Je({ tile: e, x: t, y: n }) {
	let r = A[e.typeId];
	return /* @__PURE__ */ m("g", {
		className: "shallowsea-face",
		children: [
			/* @__PURE__ */ p("polygon", {
				points: $(t, n, .97),
				fill: "#7fd8d0",
				fillOpacity: e.completed ? .5 : .28,
				stroke: "#08252c",
				strokeWidth: .055
			}),
			r?.offsets?.map((r) => /* @__PURE__ */ p(Ye, {
				x: t,
				y: n,
				dir: (r + e.rot) % 6
			}, `o${r}`)),
			r?.dirs?.map((r) => /* @__PURE__ */ p(Ye, {
				x: t,
				y: n,
				dir: (r + e.rot) % 6
			}, `d${r}`)),
			/* @__PURE__ */ p("text", {
				x: t,
				y: n + .15,
				textAnchor: "middle",
				fontSize: .4,
				fontWeight: 800,
				fill: "#0a4f58",
				children: e.typeId
			}),
			e.completed && /* @__PURE__ */ p("polygon", {
				points: $(t, n, .9),
				fill: "none",
				stroke: "#10b1a6",
				strokeWidth: .08,
				strokeDasharray: "0.22 0.12"
			})
		]
	});
}
function Ye({ x: e, y: t, dir: n }) {
	let [r, i] = Pe[n], a = Math.hypot(r, i), o = r / a, s = i / a, c = -s, l = o, u = e + o * .34, d = t + s * .34, f = e + o * .8, h = t + s * .8;
	return /* @__PURE__ */ m("g", {
		stroke: "#0a5963",
		strokeWidth: .05,
		fill: "none",
		opacity: .75,
		children: [/* @__PURE__ */ p("line", {
			x1: u,
			y1: d,
			x2: f,
			y2: h
		}), /* @__PURE__ */ p("path", {
			d: `M${f},${h} L${f - o * .16 + c * .09},${h - s * .16 + l * .09} L${f - o * .16 - c * .09},${h - s * .16 - l * .09} Z`,
			fill: "#0a5963",
			stroke: "none"
		})]
	});
}
function Xe({ coral: e, size: t }) {
	return /* @__PURE__ */ m("span", {
		className: "shallowsea-chip-visual",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: [
			/* @__PURE__ */ p("span", {
				className: "shallowsea-chip-fill",
				style: { background: g[e.color] }
			}),
			/* @__PURE__ */ p("span", {
				className: "shallowsea-chip-vp",
				children: e.vp
			}),
			e.edges.map((e, t) => e ? /* @__PURE__ */ p("span", {
				"data-dir": t,
				className: "shallowsea-chip-edge",
				style: { background: g[e] }
			}, t) : null)
		]
	});
}
function Ze({ typeId: e, size: t }) {
	return /* @__PURE__ */ p("span", {
		className: "shallowsea-chip-visual is-sealife",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: /* @__PURE__ */ p("span", {
			className: "shallowsea-chip-type",
			children: e
		})
	});
}
function Qe({ color: e, size: t }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "-0.4 -0.4 0.8 0.8",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		className: "shallowsea-fish-chip",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("circle", {
				r: .36,
				fill: g[e],
				stroke: "#08252c",
				strokeWidth: .06
			}),
			/* @__PURE__ */ p("path", {
				d: "M-0.22,0 L-0.03,-0.12 L-0.03,0.12 Z",
				fill: "#fff"
			}),
			/* @__PURE__ */ p("ellipse", {
				cx: .07,
				cy: 0,
				rx: .15,
				ry: .09,
				fill: "#fff"
			})
		]
	});
}
function $e({ label: e, refreshLabel: t, cost: n, refreshDisabled: r, onRefresh: i, children: a }) {
	return /* @__PURE__ */ m("div", {
		className: "shallowsea-pool-row",
		role: "group",
		"aria-label": e,
		children: [a, /* @__PURE__ */ m("button", {
			type: "button",
			className: "shallowsea-refresh",
			"aria-label": t,
			disabled: r,
			onClick: i,
			children: [/* @__PURE__ */ p(s, {
				size: 13,
				"aria-hidden": !0
			}), /* @__PURE__ */ p("span", { children: n })]
		})]
	});
}
function et({ pub: e, nameOf: t }) {
	let n = i(), r = Le[e.ecosystems.orange] ?? null, a = Le[e.ecosystems.blue] ?? null;
	return /* @__PURE__ */ m("div", {
		className: "shallowsea-scores",
		children: [/* @__PURE__ */ p("h2", {
			className: "shallowsea-scores-title",
			children: n("games.shallowsea.scoreTitle")
		}), /* @__PURE__ */ p("div", {
			className: "shallowsea-score-grid",
			children: e.players.map((i) => {
				let o = e.breakdown?.[i];
				return /* @__PURE__ */ m("div", {
					className: "shallowsea-score-card",
					children: [/* @__PURE__ */ m("div", {
						className: "shallowsea-score-head",
						children: [/* @__PURE__ */ p("span", {
							className: "truncate",
							children: t(i)
						}), /* @__PURE__ */ p("span", {
							className: "shallowsea-score-total font-mono tabular-nums",
							children: n("games.shallowsea.scoreShort", { n: e.scores?.[i] ?? o?.total ?? 0 })
						})]
					}), o && /* @__PURE__ */ m("ul", {
						className: "shallowsea-score-rows",
						children: [
							r && /* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n(r) }), /* @__PURE__ */ p("span", { children: o.orange })] }),
							a && /* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n(a) }), /* @__PURE__ */ p("span", { children: o.blue })] }),
							/* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scoreCoral") }), /* @__PURE__ */ p("span", { children: o.coralVp })] }),
							/* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scoreSealife") }), /* @__PURE__ */ p("span", { children: o.sealifeVp })] }),
							/* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scorePartial") }), /* @__PURE__ */ p("span", { children: o.partialVp })] }),
							/* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scoreVariety") }), /* @__PURE__ */ p("span", { children: o.variety })] }),
							/* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scoreFish") }), /* @__PURE__ */ p("span", { children: o.fishBonus })] }),
							/* @__PURE__ */ m("li", {
								className: "is-total",
								children: [/* @__PURE__ */ p("span", { children: n("games.shallowsea.scoreTotal") }), /* @__PURE__ */ p("span", { children: o.total })]
							})
						]
					})]
				}, i);
			})
		})]
	});
}
//#endregion
//#region src/game/bot.ts
function tt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function nt() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function rt(e, t, n, r) {
	let i = r ? {
		...e.bubbles,
		[r.key]: r.color
	} : e.bubbles;
	return {
		cells: {
			...e.cells,
			[t]: n
		},
		bubbles: i
	};
}
function it(e, t) {
	let n = 0;
	for (let r of Object.keys(e.cells)) {
		let i = e.cells[r];
		if (!(i.kind !== "coral" || i.completed)) for (let a = 0; a < 6; a += 1) z(i, a) === t && e.bubbles[E(r, a).key] !== t && (n += 1);
	}
	return n;
}
function at(e, t) {
	let n = A[t];
	if (!n) return 0;
	let r = 0;
	for (let i of B(e)) for (let a = 0; a < 6; a += 1) {
		let o = {
			kind: "sealife",
			typeId: t,
			rot: a,
			completed: !1
		};
		r = Math.max(r, K(rt(e, i, o), i, o, n));
	}
	return r;
}
function ot(e, t, n) {
	let r = 0, i = 0, a = 0;
	for (let o of B(e)) {
		let s = 0, c = 0, l = 0;
		for (let r = 0; r < 6; r += 1) {
			let i = z(t, r);
			if (!i) continue;
			l += 1;
			let { key: a } = E(o, r), u = e.bubbles[a];
			u === i ? s += 1 : !u && i === n && (c += 1);
		}
		l !== 0 && (s > r || s === r && c > i) && (r = s, i = c, a = l);
	}
	let o = a > 0 && r === a;
	return t.vp * .9 + r * 2 + i * 2.5 + (o ? 12 : 0);
}
var st = (e, t) => {
	let n = e.public;
	if (n.phase === "done" || n.active !== t.rid) return null;
	let r = n.boards[t.rid];
	if (!r) return null;
	let i = t.difficulty === "weak";
	if (n.phase === "select") {
		let e = [], a = [], o = n.pools, s = (e) => 2 + it(r, e) * 1.2;
		for (let t = 0; t < 5; t += 1) {
			let n = o.fish[t];
			if (!n) continue;
			let i = o.coral[t];
			if (i) {
				let r = s(n) + i.vp * .8 + 1;
				e.push({
					action: {
						type: "select",
						fish: t,
						tile: "coral"
					},
					score: r
				});
			}
			let a = o.sealife[t];
			if (a) {
				let i = A[a], o = at(r, a), c = s(n) + (i ? i.vp * (o / i.need) * 1.4 : 0) + (i && o >= i.need ? 10 : 0);
				e.push({
					action: {
						type: "select",
						fish: t,
						tile: "sealife"
					},
					score: c
				});
			}
		}
		if ((n.shells[t.rid] ?? 0) >= 2) for (let e = 0; e < 5; e += 1) {
			let t = o.fish[e];
			if (t) for (let n = 0; n < 5; n += 1) {
				let i = o.coral[n];
				i && a.push({
					action: {
						type: "selectAny",
						fish: e,
						tile: "coral",
						index: n
					},
					score: s(t) + i.vp * .8
				});
				let c = o.sealife[n];
				if (c) {
					let i = A[c], o = at(r, c);
					a.push({
						action: {
							type: "selectAny",
							fish: e,
							tile: "sealife",
							index: n
						},
						score: s(t) + (i ? i.vp * (o / i.need) * 1.4 : 0)
					});
				}
			}
		}
		let c = e.sort((e, t) => t.score - e.score)[0], l = a.sort((e, t) => t.score - e.score)[0];
		if (i) {
			let r = (n.shells[t.rid] ?? 0) >= 2 ? [...e, ...a] : e;
			return r.length === 0 ? null : { action: tt(r).action };
		}
		if (l && (!c || l.score > c.score + 3)) return { action: l.action };
		if (c) return { action: c.action };
		for (let e of ["coral", "fish"]) {
			let t = e === "coral" ? o.coral : o.fish, n = /* @__PURE__ */ new Map();
			for (let r of t) {
				if (!r) continue;
				let t = e === "coral" ? r.color : r;
				n.set(t, (n.get(t) ?? 0) + 1);
			}
			if ([...n.values()].some((e) => e >= 4)) return { action: {
				type: "refresh",
				pool: e
			} };
		}
		return null;
	}
	let a = n.selection;
	if (!a) return null;
	if (n.phase === "tile") {
		let e = B(r);
		if (e.length === 0) return null;
		let t = [];
		for (let n of e) for (let e = 0; e < 6; e += 1) if (a.tileKind === "coral" && a.coral) {
			let i = {
				kind: "coral",
				color: a.coral.color,
				vp: a.coral.vp,
				edges: [...a.coral.edges],
				rot: e,
				completed: !1,
				lockedFish: null
			};
			t.push({
				action: {
					type: "placeTile",
					cell: n,
					rot: e
				},
				score: ot(r, i, a.fish)
			});
		} else if (a.tileKind === "sealife" && a.sealife) {
			let i = A[a.sealife], o = {
				kind: "sealife",
				typeId: a.sealife,
				rot: e,
				completed: !1
			}, s = i ? K(rt(r, n, o), n, o, i) : 0, c = i ? s >= i.need : !1;
			t.push({
				action: {
					type: "placeTile",
					cell: n,
					rot: e
				},
				score: s * 4 + (c && i ? i.vp + 12 : 0)
			});
		}
		if (t.length === 0) return null;
		if (i) return { action: tt(t).action };
		for (let e of t) e.score += nt();
		return t.sort((e, t) => t.score - e.score), { action: t[0].action };
	}
	if (n.phase === "fish") {
		let e = V(r);
		if (e.length === 0) return null;
		let t = [];
		for (let n of e) {
			let e = rt(r, n.cell, r.cells[n.cell], {
				key: n.key,
				color: a.fish
			}), i = 0, o = /* @__PURE__ */ new Set();
			for (let t of [n.cell, ...ct(n.key)]) {
				if (o.has(t)) continue;
				o.add(t);
				let s = r.cells[t];
				if (s && s.kind === "coral" && !s.completed) {
					if (de(e, t, s)) i += s.vp + 8;
					else for (let e = 0; e < 6; e += 1) z(s, e) === a.fish && E(t, e).key === n.key && (i += 2.5);
				}
			}
			for (let e of ct(n.key)) {
				let t = r.cells[e];
				t && t.kind === "coral" && t.completed && (i += .8);
			}
			t.push({
				action: {
					type: "placeFish",
					cell: n.cell,
					dir: n.dir
				},
				score: i
			});
		}
		if (i) return { action: tt(t).action };
		for (let e of t) e.score += nt();
		return t.sort((e, t) => t.score - e.score), { action: t[0].action };
	}
	let o = t.memory ?? {};
	if (n.phase === "end") {
		if (!i && (n.shells[t.rid] ?? 0) >= 2 && o.movedTurn !== n.turnCount) for (let e of Object.keys(r.cells)) {
			let t = r.cells[e];
			if (t.kind !== "coral" || t.completed) continue;
			let i = null, a = !0;
			for (let n = 0; n < 6; n += 1) {
				let o = z(t, n);
				if (!o) continue;
				let s = r.bubbles[E(e, n).key];
				if (s !== o) {
					if (!s && !i) {
						i = {
							dir: n,
							color: o
						};
						continue;
					}
					a = !1;
					break;
				}
			}
			if (!a || !i) continue;
			let o = E(e, i.dir).key;
			for (let t of Object.keys(r.bubbles)) {
				if (t === o || r.bubbles[t] !== i.color) continue;
				let a = ct(t);
				for (let r of a) for (let a = 0; a < 6; a += 1) if (E(r, a).key === t) return {
					action: {
						type: "moveFish",
						fromCell: r,
						fromDir: a,
						toCell: e,
						toDir: i.dir
					},
					memory: { movedTurn: n.turnCount }
				};
			}
		}
		return {
			action: { type: "endTurn" },
			memory: { movedTurn: o.movedTurn }
		};
	}
	return null;
};
function ct(e) {
	return e.startsWith("B:") ? [e.split(":")[1]] : e.split("|");
}
//#endregion
//#region src/index.tsx
var lt = {
	definition: je,
	View: ze,
	bot: st,
	locales: {
		zh: {
			name: "浅海",
			desc: "为珊瑚礁搭配鱼群，完成珊瑚与海洋生物，终局比拼分值",
			rules: "目标:\n每名玩家各自经营一片海洋。通过不断放入珊瑚与海洋生物，配合鱼群完成它们，获得海螺并积累分值。所有玩家完成各自的回合后计分，总分最高者获胜。\n准备:\n· 每名玩家取一块海洋板。板面共 22 格：中央格先放 1 张未完成的海洋生物，其余格子留空。\n· 每名玩家拿取 2 枚海螺，海螺最多持有 5 枚。\n· 洗混珊瑚堆、海洋生物堆与鱼堆，分别抽出 5 张摆成珊瑚池、生物池与鱼池。三个池子按位置一一配对：第 1 条鱼与珊瑚池、生物池各自的第 1 张对应，依此类推。\n· 随机决定先手，之后按座位顺序轮流行动。\n回合:\n每回合依次完成三件事：选牌、放置、结算。\n· 选牌时，从鱼池取 1 条鱼，并从珊瑚池或生物池取与这条鱼位置相同的 1 张地块。鱼池第 n 条鱼只能搭配两个池子中第 n 张地块。\n· 也可以花费 1 枚海螺刷新任意一个池子，再照常选牌。珊瑚池中有至少 4 张同色珊瑚时，刷新珊瑚池免费；鱼池中有至少 4 条同色鱼时，刷新鱼池免费。\n· 花费 2 枚海螺可以无视配对，任取 1 条鱼与 1 张地块。\n· 放置时，地块可以任意旋转，但必须放在与已有地块相邻的空格上。随后把刚选的鱼放到一条空的边气泡上。地块的每条边就是一处气泡，相邻两块地共享同一条边上的气泡，每处气泡只能放 1 条鱼。\n· 放置完成后，检查因这次放置而满足条件的珊瑚与海洋生物，完成它们并获得海螺。\n珊瑚完成:\n· 珊瑚地块上印有若干条彩色边，彩色边的颜色表示它需要的鱼色。当每条彩色边所朝气泡上都放着对应颜色的鱼时，这块珊瑚完成。\n· 完成时把珊瑚翻面，并从满足条件的鱼中锁定 1 条放到珊瑚背面，这条鱼成为完成鱼，不再用于其他珊瑚。其余满足条件的鱼仍留在气泡上，仍属于未完成鱼。\n· 一次放鱼可能同时满足多块珊瑚。此时按格子顺序依次结算，先完成的珊瑚会锁定并取走一条鱼，其他珊瑚因此可能不再满足。\n海洋生物:\n· 海洋生物只统计已完成的珊瑚与完成鱼，满足条件即完成。\n· 每张海洋生物都印有指定的格位或方向，地块放置时通过旋转改变它观察的格位与方向。\n· 同色条件要求指定格或指定方向上的已完成珊瑚、完成鱼颜色相同；异色条件要求它们的颜色各不相同。\n· 方向条件沿箭头方向逐格计数，中间隔着不符合条件的格也不影响；两方向条件可以落在任意一侧，也可以合并两侧一起计数。\n· 本作首发使用 10 种海洋生物：A1 与 D1 要求指定 3 格为同色已完成珊瑚；A4 与 D4 要求指定 3 格为异色完成鱼；B1 要求两方向内 4 张同色已完成珊瑚；C2 要求指定 2 格为异色已完成珊瑚；C4 要求两方向内 2 条同色完成鱼；E1 要求单一方向内 3 张同色已完成珊瑚；E4 要求单一方向内 3 条异色完成鱼；F2 要求全板集齐四色已完成珊瑚。\n海螺:\n· 每完成 1 张珊瑚或海洋生物，获得 1 枚海螺，最多持有 5 枚。\n· 花费 1 枚海螺可以刷新一个池子；花费 2 枚海螺可以无视配对任选鱼与地块。\n· 花费 2 枚海螺可以移动自己板上 1 条未完成的鱼到另一处空边气泡。完成鱼不能移动；移动后触发的完成立即结算。\n结束与计分:\n· 每名玩家各完成 17 个回合后游戏结束。海洋板共 22 格，减去起始的 1 张生物与最后留空的 4 格，正好放置 17 张地块。\n· 先结算两张生态卡，再统计已完成珊瑚与已完成海洋生物的分值。\n· 未完成的海洋生物按已经满足的单元数获得部分分。\n· 每一种完成过的海洋生物额外获得 2 分。\n· 每条留在气泡上的未完成鱼，每相邻 1 张已完成珊瑚获得 1 分。\n· 总分最高者获胜。总分相同时，剩余海螺较多的玩家获胜；仍然相同则共享胜利。\n生态卡:\n开局固定使用 1 张橙色生态卡与 1 张蓝色生态卡，默认使用 O1 与 B1。对局中在设置里可以更换。\n· O1 保护色：背面放有同色完成鱼的已完成珊瑚，每张 2 分。\n· O2 珊瑚成对：同色已完成珊瑚每 2 张获得 3 分。\n· O3 潮汐交响：完成鱼数量最多的一种颜色，每条完成鱼 3 分，最多 18 分。\n· O4 错配：背面放有异色完成鱼的已完成珊瑚，每张 2 分。\n· O5 深层同调：某一横行中有至少 2 张同色已完成珊瑚时，该行获得 4 分。\n· O6 巨珊瑚礁：面积最大的一片相邻已完成珊瑚，每张 2 分。\n· O7 潮汐：某种颜色的完成鱼达到 3 条及以上时，该颜色获得 4 分。\n· B1 富饶深处：某一横行中有至少 2 张已完成海洋生物时，该行获得 4 分。\n· B2 丰饶洞穴：位于内圈的已完成海洋生物，每张 3 分。\n· B3 水下群落：与至少 1 张已完成海洋生物相邻的已完成海洋生物，每张 2 分。\n· B4 聚光灯：某一纵列恰好有 1 张已完成海洋生物时，该列获得 2 分。\n· B5 生物双联：每对相邻的已完成海洋生物获得 4 分，每张海洋生物最多计入一对。\n· B6 辉光洞穴：内圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。\n· B7 多样边界：外圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。",
			selectPrompt: "选 1 条鱼，再选同序号的地块",
			selectAnyMode: "自由搭配：先点鱼，再点地块",
			selectWaiting: "等 {{name}} 选牌…",
			waitingFor: "等 {{name}} 行动…",
			tilePrompt: "旋转地块，放到相邻的空格",
			fishPrompt: "把{{fish}}放到一条空边上",
			endPrompt: "结束回合，或移动一条鱼",
			movingFrom: "点选要移动的鱼",
			movingTo: "再点一条空边放下",
			doneBanner: "终局计分",
			coralPool: "珊瑚池",
			sealifePool: "生物池",
			fishPool: "鱼池",
			pairLabel: "第 {{n}} 组",
			refreshCoral: "刷新珊瑚池",
			refreshSealife: "刷新生物池",
			refreshFish: "刷新鱼池",
			refreshFree: "免费",
			refreshCost: "1 海螺",
			anyMode: "自由搭配",
			anyModeCost: "2 海螺",
			cancel: "取消",
			confirmPlace: "放这里",
			moveCost: "2 海螺",
			coralAria: "珊瑚，{{vp}} 分",
			poolEmpty: "空位",
			myBoard: "我的海洋",
			boardOf: "{{name}} 的海洋",
			shellsShort: "{{n}} 海螺",
			scoreShort: "{{n}} 分",
			emptyBubbleAria: "空的边气泡",
			fishAria: "{{fish}}",
			placeAria: "放到第 {{row}} 行第 {{col}} 列",
			rotateLeft: "向左旋转",
			rotateRight: "向右旋转",
			endTurn: "结束回合",
			moveFish: "移动鱼",
			cancelMove: "取消移动",
			activeBadge: "行动中",
			completedBadge: "已完成",
			fishRed: "红鱼",
			fishYellow: "黄鱼",
			fishGreen: "绿鱼",
			fishPurple: "紫鱼",
			slSameCoral3: "3 格同色珊瑚",
			slDiffFish3: "3 格异色完成鱼",
			slDirSameCoral4: "两方向 4 张同色珊瑚",
			slDiffCoral2: "2 格异色珊瑚",
			slDirSameFish2: "两方向 2 条同色完成鱼",
			slDirSameCoral3: "单方向 3 张同色珊瑚",
			slDirDiffFish3: "单方向 3 条异色完成鱼",
			slAnyAllCoral: "全板四色珊瑚各 1",
			sealifeAria: "{{id}}，{{desc}}",
			ecoO1: "保护色",
			ecoO2: "珊瑚成对",
			ecoO3: "潮汐交响",
			ecoO4: "错配",
			ecoO5: "深层同调",
			ecoO6: "巨珊瑚礁",
			ecoO7: "潮汐",
			ecoB1: "富饶深处",
			ecoB2: "丰饶洞穴",
			ecoB3: "水下群落",
			ecoB4: "聚光灯",
			ecoB5: "生物双联",
			ecoB6: "辉光洞穴",
			ecoB7: "多样边界",
			scoreTitle: "终局计分",
			scoreCoral: "已完成珊瑚",
			scoreSealife: "已完成海洋生物",
			scorePartial: "未完成生物部分分",
			scoreVariety: "生物种类",
			scoreFish: "未完成鱼",
			scoreTotal: "总分",
			errNotYourTurn: "现在轮不到你",
			errWrongPhase: "当前步骤不能这样操作",
			errAlreadySelected: "本回合已经选好牌了",
			errPoolEmpty: "这个池子没有可选的牌",
			errNoShell: "海螺不够",
			errNoSelection: "还没有选牌",
			errBadCell: "这格不能放",
			errBadBubble: "这条边不能放鱼"
		},
		en: {
			name: "Shallow Sea",
			desc: "Pair fish with tiles to complete corals and sea life, then compare scores",
			rules: "Goal:\nEach player tends their own sea. By placing corals and sea life and pairing them with fish, you complete them, earn shells, and build up points. After every player has taken all their turns, the highest score wins.\nSetup:\n· Each player takes one ocean board. The board has 22 spaces: place 1 unfinished sea life tile on the center space and leave the rest empty.\n· Each player takes 2 shells. A player may hold at most 5 shells.\n· Shuffle the coral tiles, sea life tiles, and fish, then deal 5 of each into the coral pool, sea life pool, and fish pool. The pools are paired by position: the first fish pairs with the first coral and the first sea life, and so on.\n· The first player is chosen at random; play then proceeds in seat order.\nTurn:\nEach turn is taken in three steps: choose, place, resolve.\n· When choosing, take 1 fish from the fish pool and 1 tile from either the coral pool or the sea life pool in the same position as that fish. The nth fish can only pair with the nth coral or the nth sea life.\n· You may instead spend 1 shell to refresh any one pool and then choose normally. Refreshing the coral pool is free when it holds at least 4 corals of one color, and refreshing the fish pool is free when it holds at least 4 fish of one color.\n· Spending 2 shells lets you ignore pairing and take any 1 fish with any 1 tile.\n· When placing, rotate the tile however you like, but it must go on an empty space adjacent to a tile already on your board. Then place the fish you chose on an empty edge bubble. Each edge of a tile is one bubble; two adjacent tiles share the bubble on their common edge, and each bubble holds only 1 fish.\n· After placing, check which corals and sea life are now satisfied by this placement, and complete them to earn shells.\nCorals:\n· Each coral tile shows several colored edges. A colored edge names the fish color it needs. The coral is completed when every colored edge has a fish of the matching color on the bubble it faces.\n· When a coral completes, flip it over and lock 1 of the satisfied fish onto its back. That fish becomes a completed fish and is no longer used by other corals. Any other satisfied fish stay on their bubbles and remain unfinished fish.\n· One fish may satisfy several corals at once. In that case they resolve in board order: the first coral to complete locks and removes a fish, so another coral may no longer be satisfied.\nSea life:\n· Sea life counts only completed corals and completed fish, and completes as soon as its condition is met.\n· Each sea life tile names specific spaces or directions; rotating the tile when placing changes which spaces or directions it looks at.\n· Same-color conditions require the completed corals or completed fish in the named spaces or directions to share one color. Different-color conditions require them to all differ.\n· Directional conditions count along the arrow, and a tile that does not match in between does not interrupt the count. Two-way conditions may count on either side or combine both sides.\n· This release uses 10 sea life types: A1 and D1 need same-color completed corals in 3 named spaces; A4 and D4 need different-color completed fish in 3 named spaces; B1 needs 4 same-color completed corals across its two directions; C2 needs different-color completed corals in 2 named spaces; C4 needs 2 same-color completed fish across its two directions; E1 needs 3 same-color completed corals in one direction; E4 needs 3 different-color completed fish in one direction; F2 needs completed corals of all four colors anywhere on the board.\nShells:\n· Each completed coral or sea life earns 1 shell, up to a maximum of 5 shells.\n· Spending 1 shell refreshes one pool; spending 2 shells ignores pairing and lets you take any fish with any tile.\n· Spending 2 shells lets you move 1 unfinished fish on your own board to another empty edge bubble. Completed fish cannot be moved, and any completion triggered by the move resolves immediately.\nEnd and scoring:\n· The game ends after each player has taken 17 turns. A board has 22 spaces; after the 1 starting sea life and the 4 spaces left empty, exactly 17 tiles are placed.\n· Score the two ecosystem cards first, then the completed corals and completed sea life.\n· Unfinished sea life scores partial points for the units it has satisfied.\n· Each distinct type of completed sea life scores 2 bonus points.\n· Each unfinished fish still on a bubble scores 1 point for each completed coral adjacent to it.\n· The highest total wins. On a tie, the player with more shells remaining wins; if still tied, the players share the victory.\nEcosystem cards:\nEach game uses 1 orange and 1 blue ecosystem card, defaulting to O1 and B1. They can be changed in the setup options.\n· O1 Cryptic Coloration: each completed coral with a same-color completed fish on its back scores 2.\n· O2 Coral Duo: each pair of same-color completed corals scores 3.\n· O3 Symphony of the Tides: the color with the most completed fish scores 3 per fish, up to 18.\n· O4 Mismatched: each completed coral with a different-color completed fish on its back scores 2.\n· O5 Depths Alike: a row with at least 2 same-color completed corals scores 4.\n· O6 Colossal Coral Reef: the largest connected group of adjacent completed corals scores 2 per coral.\n· O7 Tides: each color with at least 3 completed fish scores 4.\n· B1 Rich Depths: a row with at least 2 completed sea life scores 4.\n· B2 Bountiful Caves: each completed sea life on an inner space scores 3.\n· B3 Underwater Community: each completed sea life adjacent to at least 1 completed sea life scores 2.\n· B4 Spotlight: a column with exactly 1 completed sea life scores 2.\n· B5 Sealife Duet: each pair of adjacent completed sea life scores 4, and each sea life may count in at most one pair.\n· B6 Radiant Caves: each distinct tile in the inner spaces scores 2. Corals count by color and sea life by type.\n· B7 Borders of Diversity: each distinct tile on the outer ring scores 2. Corals count by color and sea life by type.",
			selectPrompt: "Pick 1 fish, then a tile in the same slot",
			selectAnyMode: "Free pairing: pick a fish, then a tile",
			selectWaiting: "Waiting for {{name}} to choose…",
			waitingFor: "Waiting for {{name}}…",
			tilePrompt: "Rotate the tile and place it on an adjacent space",
			fishPrompt: "Place the {{fish}} on an empty edge",
			endPrompt: "End your turn, or move a fish",
			movingFrom: "Pick the fish to move",
			movingTo: "Pick an empty edge for it",
			doneBanner: "Final scoring",
			coralPool: "Coral pool",
			sealifePool: "Sea life pool",
			fishPool: "Fish pool",
			pairLabel: "Slot {{n}}",
			refreshCoral: "Refresh coral pool",
			refreshSealife: "Refresh sea life pool",
			refreshFish: "Refresh fish pool",
			refreshFree: "Free",
			refreshCost: "1 shell",
			anyMode: "Free pairing",
			anyModeCost: "2 shells",
			cancel: "Cancel",
			confirmPlace: "Place here",
			moveCost: "2 shells",
			coralAria: "Coral, {{vp}} points",
			poolEmpty: "Empty slot",
			myBoard: "My sea",
			boardOf: "{{name}}'s sea",
			shellsShort: "{{n}} shells",
			scoreShort: "{{n}} pts",
			emptyBubbleAria: "Empty edge bubble",
			fishAria: "{{fish}}",
			placeAria: "Place at row {{row}}, column {{col}}",
			rotateLeft: "Rotate left",
			rotateRight: "Rotate right",
			endTurn: "End turn",
			moveFish: "Move fish",
			cancelMove: "Cancel move",
			activeBadge: "Acting",
			completedBadge: "Completed",
			fishRed: "red fish",
			fishYellow: "yellow fish",
			fishGreen: "green fish",
			fishPurple: "purple fish",
			slSameCoral3: "3 spaces, same-color corals",
			slDiffFish3: "3 spaces, different-color fish",
			slDirSameCoral4: "two ways, 4 same-color corals",
			slDiffCoral2: "2 spaces, different-color corals",
			slDirSameFish2: "two ways, 2 same-color fish",
			slDirSameCoral3: "one way, 3 same-color corals",
			slDirDiffFish3: "one way, 3 different-color fish",
			slAnyAllCoral: "all four coral colors",
			sealifeAria: "{{id}}, {{desc}}",
			ecoO1: "Cryptic Coloration",
			ecoO2: "Coral Duo",
			ecoO3: "Symphony of the Tides",
			ecoO4: "Mismatched",
			ecoO5: "Depths Alike",
			ecoO6: "Colossal Coral Reef",
			ecoO7: "Tides",
			ecoB1: "Rich Depths",
			ecoB2: "Bountiful Caves",
			ecoB3: "Underwater Community",
			ecoB4: "Spotlight",
			ecoB5: "Sealife Duet",
			ecoB6: "Radiant Caves",
			ecoB7: "Borders of Diversity",
			scoreTitle: "Final scoring",
			scoreCoral: "Completed corals",
			scoreSealife: "Completed sea life",
			scorePartial: "Partial sea life",
			scoreVariety: "Sea life types",
			scoreFish: "Unfinished fish",
			scoreTotal: "Total",
			errNotYourTurn: "It is not your turn",
			errWrongPhase: "This action is not allowed right now",
			errAlreadySelected: "You already chose this turn",
			errPoolEmpty: "That pool has nothing to take",
			errNoShell: "Not enough shells",
			errNoSelection: "Choose a fish and tile first",
			errBadCell: "That space is not available",
			errBadBubble: "That edge is not available"
		}
	}
};
//#endregion
export { lt as default };
