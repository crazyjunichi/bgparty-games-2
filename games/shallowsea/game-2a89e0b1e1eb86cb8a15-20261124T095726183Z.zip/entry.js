import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { IconMove as s, IconRecenter as c, IconRotate as l, IconUpdate as u, IconZoomIn as d, IconZoomOut as f } from "@bgparty/sdk/icons";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as h, SeatBadgedAvatar as ee, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
//#region src/game/data.ts
var b = [
	"red",
	"yellow",
	"green",
	"purple"
], x = {
	red: "#e15b52",
	yellow: "#f0b429",
	green: "#5fa86a",
	purple: "#9b6bc6"
}, S = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], C = [
	{
		r: 0,
		qs: [
			0,
			1,
			2,
			3
		]
	},
	{
		r: 1,
		qs: [
			-1,
			0,
			1,
			2,
			3
		]
	},
	{
		r: 2,
		qs: [
			-1,
			0,
			1,
			2
		]
	},
	{
		r: 3,
		qs: [
			-2,
			-1,
			0,
			1,
			2
		]
	},
	{
		r: 4,
		qs: [
			-2,
			-1,
			0,
			1
		]
	}
], w = /* @__PURE__ */ new Set([
	"0,1",
	"1,1",
	"2,1",
	"-1,2",
	"0,2",
	"1,2",
	"2,2",
	"-1,3",
	"0,3",
	"1,3"
]), T = C.flatMap(({ r: e, qs: t }) => t.map((t) => {
	let n = `${t},${e}`;
	return {
		id: n,
		q: t,
		r: e,
		inner: w.has(n)
	};
})), E = Object.fromEntries(T.map((e) => [e.id, e])), D = T.length;
function O(e, t) {
	return `${e},${t}`;
}
function k(e, t) {
	let n = E[e];
	if (!n) return null;
	let [r, i] = S[t], a = O(n.q + r, n.r + i);
	return E[a] ? a : null;
}
function A(e, t) {
	let n = k(e, t);
	if (n) {
		let [t, r] = [e, n].sort();
		return {
			key: `${t}|${r}`,
			cells: [t, r]
		};
	}
	return {
		key: `B:${e}:${t}`,
		cells: [e]
	};
}
function j(e) {
	return {
		x: 2 * e.q + e.r,
		y: e.r
	};
}
var M = {
	2: [0, 3],
	3: [
		0,
		2,
		4
	],
	4: [
		0,
		1,
		3,
		4
	]
};
function te() {
	let e = [], t = [
		{
			vp: 5,
			count: 7
		},
		{
			vp: 7,
			count: 7
		},
		{
			vp: 9,
			count: 5
		}
	], n = 0;
	for (let r of b) for (let i of t) {
		let t = M[i.vp === 5 ? 2 : i.vp === 7 ? 3 : 4];
		for (let a = 0; a < i.count; a += 1) {
			let a = [
				null,
				null,
				null,
				null,
				null,
				null
			];
			t.forEach((e, t) => {
				a[e] = b[(n + t) % b.length];
			}), e.push({
				id: `c${n}`,
				color: r,
				vp: i.vp,
				edges: a
			}), n += 1;
		}
	}
	return e;
}
function N() {
	return te();
}
var P = {
	A1: {
		id: "A1",
		cls: "A",
		kind: "sameCoral",
		need: 3,
		vp: 10,
		partial: 3,
		offsets: [
			0,
			2,
			4
		]
	},
	A4: {
		id: "A4",
		cls: "A",
		kind: "diffFish",
		need: 3,
		vp: 9,
		partial: 3,
		offsets: [
			1,
			3,
			5
		]
	},
	B1: {
		id: "B1",
		cls: "B",
		kind: "dirSameCoral",
		need: 4,
		vp: 10,
		partial: 2,
		dirs: [0, 3],
		twoWay: !0
	},
	C2: {
		id: "C2",
		cls: "C",
		kind: "diffCoral",
		need: 2,
		vp: 6,
		partial: 2,
		offsets: [0, 3]
	},
	C4: {
		id: "C4",
		cls: "C",
		kind: "dirSameFish",
		need: 2,
		vp: 5,
		partial: 2,
		dirs: [1, 4],
		twoWay: !0
	},
	D1: {
		id: "D1",
		cls: "D",
		kind: "sameCoral",
		need: 3,
		vp: 7,
		partial: 2,
		offsets: [
			1,
			3,
			5
		]
	},
	D4: {
		id: "D4",
		cls: "D",
		kind: "diffFish",
		need: 3,
		vp: 7,
		partial: 2,
		offsets: [
			0,
			2,
			4
		]
	},
	E1: {
		id: "E1",
		cls: "E",
		kind: "dirSameCoral",
		need: 3,
		vp: 8,
		partial: 2,
		dirs: [2],
		twoWay: !1
	},
	E4: {
		id: "E4",
		cls: "E",
		kind: "dirDiffFish",
		need: 3,
		vp: 7,
		partial: 2,
		dirs: [3],
		twoWay: !1
	},
	F2: {
		id: "F2",
		cls: "F",
		kind: "anyAllCoral",
		need: 4,
		vp: 6,
		partial: 1
	}
}, F = [
	"A1",
	"A4",
	"B1",
	"C2",
	"C4",
	"D1",
	"D4",
	"E1",
	"E4",
	"F2"
], I = {
	O1: {
		id: "O1",
		cls: "orange"
	},
	O2: {
		id: "O2",
		cls: "orange"
	},
	O3: {
		id: "O3",
		cls: "orange"
	},
	O4: {
		id: "O4",
		cls: "orange"
	},
	O5: {
		id: "O5",
		cls: "orange"
	},
	O6: {
		id: "O6",
		cls: "orange"
	},
	O7: {
		id: "O7",
		cls: "orange"
	},
	B1: {
		id: "B1",
		cls: "blue"
	},
	B2: {
		id: "B2",
		cls: "blue"
	},
	B3: {
		id: "B3",
		cls: "blue"
	},
	B4: {
		id: "B4",
		cls: "blue"
	},
	B5: {
		id: "B5",
		cls: "blue"
	},
	B6: {
		id: "B6",
		cls: "blue"
	},
	B7: {
		id: "B7",
		cls: "blue"
	}
}, L = Object.values(I).filter((e) => e.cls === "orange").map((e) => e.id), R = Object.values(I).filter((e) => e.cls === "blue").map((e) => e.id);
function z(e) {
	return e >= 4 ? 24 : e === 3 ? 19 : e === 2 ? 14 : 9;
}
function B(e) {
	return e >= 4 ? 4 : e === 3 ? 3 : 2;
}
//#endregion
//#region src/game/meta.ts
var V = {
	id: "shallowsea",
	uuid: "cea5e489-ab47-4de7-81a1-0e46f9f4753e",
	tier: "alpha",
	mechanics: ["tile-placement", "set-collection"],
	interactionTags: [],
	nameKey: "games.shallowsea.name",
	descKey: "games.shallowsea.desc",
	rulesKey: "games.shallowsea.rules",
	icon: "🪸",
	iconImg: "games/shallowsea.webp",
	rulesUrl: { en: "https://c.tabletopia.com/games/shallow-sea/rules/shallow-sea-rulebook/en" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#0e8f9b",
	releasedAt: "2026-11-23T19:57:00+08:00",
	search: {
		py: "qian hai",
		init: "qh"
	},
	hotseat: "open"
}, H = t.enum([
	"red",
	"yellow",
	"green",
	"purple"
]), U = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("refresh"),
		pool: t.enum([
			"coral",
			"sealife",
			"fish"
		])
	}),
	t.object({
		type: t.literal("setupPlace"),
		index: t.int().min(0).max(4),
		cell: t.string(),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("select"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"])
	}),
	t.object({
		type: t.literal("selectAny"),
		fish: t.int().min(0).max(4),
		tile: t.enum(["coral", "sealife"]),
		index: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("placeTile"),
		cell: t.string(),
		rot: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("placeFish"),
		cell: t.string(),
		dir: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("moveFish"),
		fromCell: t.string(),
		fromDir: t.int().min(0).max(5),
		toCell: t.string(),
		toDir: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("endTurn") })
]), W = t.union([
	t.literal(5),
	t.literal(7),
	t.literal(9)
]), G = t.object({
	id: t.string(),
	color: H,
	vp: W,
	edges: t.array(H.nullable()).length(6)
}), K = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("coral"),
	color: H,
	vp: W,
	edges: t.array(H.nullable()).length(6),
	rot: t.int().min(0).max(5),
	completed: t.boolean(),
	lockedFish: H.nullable()
}), t.object({
	kind: t.literal("sealife"),
	typeId: t.string(),
	rot: t.int().min(0).max(5),
	completed: t.boolean()
})]), ne = t.object({
	cells: t.record(t.string(), K),
	bubbles: t.record(t.string(), H)
}), re = t.object({
	orange: t.number(),
	blue: t.number(),
	coralVp: t.number(),
	sealifeVp: t.number(),
	partialVp: t.number(),
	variety: t.number(),
	fishBonus: t.number(),
	total: t.number()
}), ie = t.object({
	players: t.array(t.string()),
	boards: t.record(t.string(), ne),
	pools: t.object({
		coral: t.array(G.nullable()).length(5),
		sealife: t.array(t.string().nullable()).length(5),
		fish: t.array(H.nullable()).length(5)
	}),
	ecosystems: t.object({
		orange: t.string(),
		blue: t.string()
	}),
	shells: t.record(t.string(), t.int().min(0).max(5)),
	active: t.string().nullable(),
	phase: t.enum([
		"setup",
		"select",
		"tile",
		"fish",
		"end",
		"done"
	]),
	turnCount: t.int().nonnegative(),
	selection: t.object({
		fish: H,
		fishIdx: t.int(),
		tileKind: t.enum(["coral", "sealife"]),
		coral: G.nullable(),
		sealife: t.string().nullable()
	}).nullable(),
	lastPlaced: t.object({
		rid: t.string(),
		cell: t.string()
	}).nullable(),
	scores: t.record(t.string(), t.number()).nullable(),
	breakdown: t.record(t.string(), re).nullable()
}), ae = t.object({});
t.object({
	orange: t.string().optional(),
	blue: t.string().optional()
});
//#endregion
//#region src/game/rules.ts
function q(e, t) {
	return e.edges[((t - e.rot) % 6 + 6) % 6];
}
function oe(e) {
	return e.startsWith("B:") ? [e.split(":")[1]] : e.split("|");
}
function se(e, t) {
	if (!E[t] || e.cells[t]) return !1;
	let n = E[t];
	return S.some(([t, r]) => {
		let i = `${n.q + t},${n.r + r}`;
		return !!e.cells[i];
	});
}
function J(e) {
	return Object.keys(E).filter((t) => se(e, t));
}
function ce(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of Object.keys(e.cells)) for (let i = 0; i < 6; i += 1) {
		let { key: a } = A(r, i);
		n.has(a) || e.bubbles[a] || (n.add(a), t.push({
			cell: r,
			dir: i,
			key: a
		}));
	}
	return t;
}
function Y(e, t, n) {
	for (let r = 0; r < 6; r += 1) {
		let i = q(n, r);
		if (i && e.bubbles[A(t, r).key] !== i) return !1;
	}
	return !0;
}
function le(e, t, n) {
	for (let r = 0; r < 6; r += 1) {
		if (!n.edges[r]) continue;
		let { key: i } = A(t, (r + n.rot) % 6), a = e.bubbles[i];
		if (a) return {
			key: i,
			color: a
		};
	}
	return null;
}
function X(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.color : null;
}
function ue(e, t) {
	let n = e.cells[t];
	return n && n.kind === "coral" && n.completed ? n.lockedFish : null;
}
function de(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	let n = 0;
	for (let e of t.values()) n = Math.max(n, e);
	return n;
}
function fe(e) {
	return new Set(e).size;
}
function pe(e, t) {
	let n = [], r = e;
	for (; r = k(r, t), r;) n.push(r);
	return n;
}
function me(e, t, n, r) {
	let i = (e) => (e + n.rot) % 6;
	switch (r.kind) {
		case "sameCoral": return de((r.offsets ?? []).map((e) => k(t, i(e))).map((t) => t ? X(e, t) : null).filter((e) => !!e));
		case "diffCoral": return fe((r.offsets ?? []).map((e) => k(t, i(e))).map((t) => t ? X(e, t) : null).filter((e) => !!e));
		case "sameFish": return de((r.offsets ?? []).map((e) => k(t, i(e))).map((t) => t ? ue(e, t) : null).filter((e) => !!e));
		case "diffFish": return fe((r.offsets ?? []).map((e) => k(t, i(e))).map((t) => t ? ue(e, t) : null).filter((e) => !!e));
		case "dirSameCoral":
		case "dirDiffCoral":
		case "dirSameFish":
		case "dirDiffFish": {
			let n = (r.dirs ?? []).map(i), a = r.twoWay ? n.flatMap((e) => pe(t, e)) : pe(t, n[0] ?? 0), o = [...new Set(a)], s = r.kind === "dirSameFish" || r.kind === "dirDiffFish", c = o.map((t) => s ? ue(e, t) : X(e, t)).filter((e) => !!e);
			return r.kind === "dirSameCoral" || r.kind === "dirSameFish" ? de(c) : fe(c);
		}
		case "anyAllCoral": return fe(Object.keys(e.cells).map((t) => X(e, t)).filter((e) => !!e));
	}
}
function he(e, t) {
	e.shells[t] = Math.min(5, (e.shells[t] ?? 0) + 1);
}
function ge(e, t) {
	let n = e.boards[t], r = [];
	for (let i = 0; i < D; i += 1) {
		let i = Object.keys(n.cells).sort().find((e) => {
			let t = n.cells[e];
			return t.kind === "coral" && !t.completed && Y(n, e, t);
		});
		if (!i) break;
		let a = n.cells[i], o = le(n, i, a);
		o && delete n.bubbles[o.key], a.completed = !0, a.lockedFish = o?.color ?? null, he(e, t), r.push(i);
	}
	for (let i of Object.keys(n.cells).sort()) {
		let a = n.cells[i];
		if (a.kind !== "sealife" || a.completed) continue;
		let o = P[a.typeId];
		o && me(n, i, a, o) >= o.need && (a.completed = !0, he(e, t), r.push(i));
	}
	return r.length > 0 ? [{
		kind: "shallow-complete",
		rid: t,
		data: { cells: r }
	}] : [];
}
function _e(e) {
	return Object.keys(e.cells).filter((t) => X(e, t) != null);
}
function ve(e) {
	return Object.keys(e.cells).filter((t) => {
		let n = e.cells[t];
		return n.kind === "sealife" && n.completed;
	});
}
function ye(e) {
	let t = [];
	for (let n of Object.keys(e.cells)) {
		let r = ue(e, n);
		r && t.push({
			cell: n,
			color: r
		});
	}
	return t;
}
function be(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of _e(e)) {
		let r = X(e, n);
		t.set(r, (t.get(r) ?? 0) + 1);
	}
	return t;
}
function xe(e) {
	let t = e.length;
	if (t < 2) return 0;
	let n = new Map(e.map((e, t) => [e, t])), r = e.map((e) => {
		let t = E[e], r = [];
		for (let [e, i] of S) {
			let a = n.get(`${t.q + e},${t.r + i}`);
			a !== void 0 && r.push(a);
		}
		return r;
	}), i = /* @__PURE__ */ new Map(), a = (e) => {
		if (e === 0) return 0;
		let t = i.get(e);
		if (t !== void 0) return t;
		let n = 31 - Math.clz32(e & -e), o = a(e & ~(1 << n));
		for (let t of r[n]) e & 1 << t && (o = Math.max(o, 1 + a(e & ~(1 << n) & ~(1 << t))));
		return i.set(e, o), o;
	};
	return a((1 << t) - 1);
}
function Se(e, t) {
	let n = _e(e), r = ve(e);
	switch (t) {
		case "O1": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish === r.color ? 2 : 0);
		}, 0);
		case "O2": {
			let t = 0;
			for (let n of be(e).values()) t += Math.floor(n / 2) * 3;
			return t;
		}
		case "O3": {
			let t = /* @__PURE__ */ new Map();
			for (let n of ye(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) n = Math.max(n, e);
			return Math.min(n * 3, 18);
		}
		case "O4": return n.reduce((t, n) => {
			let r = e.cells[n];
			return t + (r.kind === "coral" && r.lockedFish != null && r.lockedFish !== r.color ? 2 : 0);
		}, 0);
		case "O5": {
			let t = /* @__PURE__ */ new Map();
			for (let r of n) {
				let n = E[r].r, i = X(e, r), a = t.get(n) ?? /* @__PURE__ */ new Map();
				a.set(i, (a.get(i) ?? 0) + 1), t.set(n, a);
			}
			let r = 0;
			for (let e of t.values()) [...e.values()].some((e) => e >= 2) && (r += 4);
			return r;
		}
		case "O6": {
			let e = new Set(n), t = /* @__PURE__ */ new Set(), r = 0;
			for (let i of n) {
				if (t.has(i)) continue;
				let n = [i];
				t.add(i);
				let a = 0;
				for (; n.length > 0;) {
					let r = n.pop();
					a += 1;
					let i = E[r];
					for (let [r, a] of S) {
						let o = `${i.q + r},${i.r + a}`;
						e.has(o) && !t.has(o) && (t.add(o), n.push(o));
					}
				}
				r = Math.max(r, a);
			}
			return r * 2;
		}
		case "O7": {
			let t = /* @__PURE__ */ new Map();
			for (let n of ye(e)) t.set(n.color, (t.get(n.color) ?? 0) + 1);
			let n = 0;
			for (let e of t.values()) e >= 3 && (n += 4);
			return n;
		}
		case "B1": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = E[t].r;
				e.set(n, (e.get(n) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n >= 2 && (t += 4);
			return t;
		}
		case "B2": return r.filter((e) => E[e].inner).length * 3;
		case "B3": return r.filter((t) => {
			let n = E[t];
			return S.some(([t, r]) => {
				let i = e.cells[`${n.q + t},${n.r + r}`];
				return i?.kind === "sealife" && i.completed;
			});
		}).length * 2;
		case "B4": {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) {
				let n = E[t], r = 2 * n.q + n.r;
				e.set(r, (e.get(r) ?? 0) + 1);
			}
			let t = 0;
			for (let n of e.values()) n === 1 && (t += 2);
			return t;
		}
		case "B5": return xe(r) * 4;
		case "B6":
		case "B7": {
			let n = t === "B6", r = /* @__PURE__ */ new Set();
			for (let t of Object.keys(e.cells)) {
				if (E[t].inner !== n) continue;
				let i = e.cells[t];
				r.add(i.kind === "coral" ? `c:${i.color}` : `s:${i.typeId}`);
			}
			return r.size * 2;
		}
		default: return 0;
	}
}
function Ce(e) {
	let t = 0;
	for (let n of Object.keys(e.bubbles)) for (let r of oe(n)) {
		let n = e.cells[r];
		n && n.kind === "coral" && n.completed && (t += 1);
	}
	return t;
}
function we(e, t) {
	let n = 0;
	for (let t of _e(e)) {
		let r = e.cells[t];
		n += r.vp;
	}
	let r = 0, i = 0, a = /* @__PURE__ */ new Set();
	for (let t of Object.keys(e.cells)) {
		let n = e.cells[t];
		if (n.kind !== "sealife") continue;
		let o = P[n.typeId];
		o && (n.completed ? (r += o.vp, a.add(n.typeId)) : i += Math.min(me(e, t, n, o), o.need) * o.partial);
	}
	let o = a.size * 2, s = Se(e, t.orange), c = Se(e, t.blue), l = Ce(e);
	return {
		orange: s,
		blue: c,
		coralVp: n,
		sealifeVp: r,
		partialVp: i,
		variety: o,
		fishBonus: l,
		total: s + c + n + r + i + o + l
	};
}
function Te(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.n, i + 1);
		r.n += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function Ee(e) {
	let t = B(e);
	return F.flatMap((e) => Array(t).fill(e));
}
function De(e) {
	let t = z(e);
	return b.flatMap((e) => Array(t).fill(e));
}
function Oe(e) {
	for (let t = 0; t < 5; t += 1) e.pools.coral[t] || (e.pools.coral[t] = e.coralDeck.pop() ?? null), e.pools.sealife[t] || (e.pools.sealife[t] = e.sealifeDeck.pop() ?? null), e.pools.fish[t] || (e.pools.fish[t] = e.fishDeck.pop() ?? null);
}
function ke(t, n, r) {
	let i = t ?? {}, a = typeof i.orange == "string" && L.includes(i.orange) ? i.orange : "O1", o = typeof i.blue == "string" && R.includes(i.blue) ? i.blue : "B1", s = { n: 0 }, c = Te(N(), r, s), l = Te(Ee(n.length), r, s), u = Te(De(n.length), r, s), d = {}, f = {};
	for (let e of n) d[e] = {
		cells: {},
		bubbles: {}
	}, f[e] = 2;
	let p = n[e(r, s.n, n.length)], m = n.indexOf(p), h = {
		players: [...n],
		boards: d,
		pools: {
			coral: [],
			sealife: [],
			fish: []
		},
		coralDeck: c,
		sealifeDeck: l,
		fishDeck: u,
		ecosystems: {
			orange: a,
			blue: o
		},
		shells: f,
		active: n[(m - 1 + n.length) % n.length],
		phase: "setup",
		turnCount: 0,
		first: p,
		setupPlaced: 0,
		selection: null,
		lastPlaced: null
	};
	for (let e = 0; e < 5; e += 1) h.pools.coral.push(c.pop() ?? null), h.pools.sealife.push(l.pop() ?? null), h.pools.fish.push(u.pop() ?? null);
	return {
		state: h,
		fx: []
	};
}
function Ae() {
	return { code: "games.shallowsea.errNotYourTurn" };
}
function je(e) {
	if (e.turnCount += 1, e.turnCount >= e.players.length * 17) {
		e.phase = "done", e.active = null;
		return;
	}
	let t = e.players.indexOf(e.active ?? e.players[0]);
	e.active = e.players[(t + 1) % e.players.length], e.phase = "select";
}
function Me(e, t, n) {
	if (e.phase === "done" || e.active !== n.by) return Ae();
	let r = structuredClone(e);
	switch (t.type) {
		case "refresh": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = r.pools[t.pool];
			if (i.every((e) => e == null)) return { code: "games.shallowsea.errPoolEmpty" };
			let a = !1;
			if (t.pool === "coral") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.coral) t && e.set(t.color, (e.get(t.color) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			} else if (t.pool === "fish") {
				let e = /* @__PURE__ */ new Map();
				for (let t of r.pools.fish) t && e.set(t, (e.get(t) ?? 0) + 1);
				a = [...e.values()].some((e) => e >= 4);
			}
			if (!a) {
				if ((r.shells[n.by] ?? 0) < 1) return { code: "games.shallowsea.errNoShell" };
				--r.shells[n.by];
			}
			for (let e = 0; e < i.length; e += 1) t.pool === "coral" ? r.pools.coral[e] = r.coralDeck.pop() ?? null : t.pool === "sealife" ? r.pools.sealife[e] = r.sealifeDeck.pop() ?? null : r.pools.fish[e] = r.fishDeck.pop() ?? null;
			return {
				state: r,
				fx: []
			};
		}
		case "setupPlace": {
			if (e.phase !== "setup") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.boards[n.by], a = r.pools.sealife[t.index];
			if (!a) return { code: "games.shallowsea.errPoolEmpty" };
			if (!E[t.cell] || i.cells[t.cell]) return { code: "games.shallowsea.errBadCell" };
			if (i.cells[t.cell] = {
				kind: "sealife",
				typeId: a,
				rot: t.rot,
				completed: !1
			}, r.pools.sealife[t.index] = null, r.setupPlaced += 1, r.lastPlaced = {
				rid: n.by,
				cell: t.cell
			}, r.setupPlaced >= r.players.length) Oe(r), r.active = r.first, r.phase = "select";
			else {
				let e = r.players.indexOf(r.first);
				r.active = r.players[(e - 1 + r.setupPlaced + r.players.length) % r.players.length];
			}
			return {
				state: r,
				fx: []
			};
		}
		case "select":
		case "selectAny": {
			if (e.phase !== "select") return { code: "games.shallowsea.errWrongPhase" };
			if (r.selection) return { code: "games.shallowsea.errAlreadySelected" };
			let i = t.fish, a = t.type === "select" ? t.fish : t.index;
			if (t.type === "selectAny" && (r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let o = r.pools.fish[i];
			if (!o) return { code: "games.shallowsea.errPoolEmpty" };
			let s = null, c = null;
			if (t.tile === "coral") {
				if (s = r.pools.coral[a] ?? null, !s) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.coral[a] = null;
			} else {
				if (c = r.pools.sealife[a] ?? null, !c) return { code: "games.shallowsea.errPoolEmpty" };
				r.pools.sealife[a] = null;
			}
			return r.pools.fish[i] = null, t.type === "selectAny" && (r.shells[n.by] -= 2), r.selection = {
				fish: o,
				fishIdx: i,
				tileKind: t.tile,
				coral: s,
				sealife: c
			}, r.phase = "tile", {
				state: r,
				fx: []
			};
		}
		case "placeTile": {
			if (e.phase !== "tile") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			if (!se(a, t.cell)) return { code: "games.shallowsea.errBadCell" };
			if (i.tileKind === "coral" && i.coral) a.cells[t.cell] = {
				kind: "coral",
				color: i.coral.color,
				vp: i.coral.vp,
				edges: [...i.coral.edges],
				rot: t.rot,
				completed: !1,
				lockedFish: null
			};
			else if (i.tileKind === "sealife" && i.sealife) a.cells[t.cell] = {
				kind: "sealife",
				typeId: i.sealife,
				rot: t.rot,
				completed: !1
			};
			else return { code: "games.shallowsea.errNoSelection" };
			return r.lastPlaced = {
				rid: n.by,
				cell: t.cell
			}, r.phase = "fish", {
				state: r,
				fx: ge(r, n.by)
			};
		}
		case "placeFish": {
			if (e.phase !== "fish") return { code: "games.shallowsea.errWrongPhase" };
			let i = r.selection;
			if (!i) return { code: "games.shallowsea.errNoSelection" };
			let a = r.boards[n.by];
			if (!a.cells[t.cell]) return { code: "games.shallowsea.errBadBubble" };
			let { key: o } = A(t.cell, t.dir);
			return a.bubbles[o] ? { code: "games.shallowsea.errBadBubble" } : (a.bubbles[o] = i.fish, r.phase = "end", {
				state: r,
				fx: ge(r, n.by)
			});
		}
		case "moveFish": {
			if (e.phase !== "tile" && e.phase !== "fish" && e.phase !== "end") return { code: "games.shallowsea.errWrongPhase" };
			if ((r.shells[n.by] ?? 0) < 2) return { code: "games.shallowsea.errNoShell" };
			let i = r.boards[n.by], a = A(t.fromCell, t.fromDir), o = A(t.toCell, t.toDir), s = i.bubbles[a.key];
			return !s || !i.cells[t.toCell] || i.bubbles[o.key] ? { code: "games.shallowsea.errBadBubble" } : (delete i.bubbles[a.key], i.bubbles[o.key] = s, r.shells[n.by] -= 2, {
				state: r,
				fx: ge(r, n.by)
			});
		}
		case "endTurn": return e.phase === "end" ? (r.selection = null, Oe(r), je(r), {
			state: r,
			fx: []
		}) : { code: "games.shallowsea.errWrongPhase" };
	}
	return { code: "games.shallowsea.errWrongPhase" };
}
function Ne(e) {
	let t = e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, we(e.boards[t], e.ecosystems)])) : null, n = t ? Object.fromEntries(Object.entries(t).map(([e, t]) => [e, t.total])) : null;
	return {
		public: {
			players: e.players,
			boards: e.boards,
			pools: e.pools,
			ecosystems: e.ecosystems,
			shells: e.shells,
			active: e.active,
			phase: e.phase,
			turnCount: e.turnCount,
			selection: e.selection,
			lastPlaced: e.lastPlaced,
			scores: n,
			breakdown: t
		},
		private: {}
	};
}
function Pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => ({
		rid: t,
		...we(e.boards[t], e.ecosystems)
	})), n = Object.fromEntries(t.map((e) => [e.rid, e.total])), r = new Map(e.players.map((e, t) => [e, t])), i = [...e.players].sort((t, i) => {
		if (n[i] !== n[t]) return n[i] - n[t];
		let a = (e.shells[i] ?? 0) - (e.shells[t] ?? 0);
		return a === 0 ? (r.get(t) ?? 0) - (r.get(i) ?? 0) : a;
	}), a = i[0];
	return {
		phase: "done",
		winner: i.filter((t) => n[t] === n[a] && (e.shells[t] ?? 0) === (e.shells[a] ?? 0)),
		ranking: i,
		scores: n
	};
}
var Fe = {
	saveCompatibility: {
		version: "2",
		migrate: () => null
	},
	meta: V,
	schemas: {
		action: U,
		publicView: ie,
		privateView: ae
	},
	setup: ke,
	reduce: Me,
	viewFor: Ne,
	status: Pe
}, Ie = .74, Z = .27, Le = [
	[1, -.27],
	[1, Z],
	[Z, 1],
	[-.27, 1],
	[-1, Z],
	[-1, -.27],
	[-.27, -1],
	[Z, -1]
], Re = [
	[[1, -.27], [1, Z]],
	[[1, -.27], [Z, -1]],
	[[-.27, -1], [-1, -.27]],
	[[-1, Z], [-1, -.27]],
	[[-1, Z], [-.27, 1]],
	[[Z, 1], [1, Z]]
], ze = Re.map(([e, t]) => [(e[0] + t[0]) / 2, (e[1] + t[1]) / 2]), Be = [
	[1, 0],
	[.5, -.5],
	[-.5, -.5],
	[-1, 0],
	[-.5, .5],
	[.5, .5]
], Q = {
	x: -2.6,
	y: -1.2,
	w: 11.2,
	h: 6.4
}, Ve = `${Q.x} ${Q.y} ${Q.w} ${Q.h}`, He = 3, Ue = 1.4, We = 1.6, Ge = {
	scale: 1,
	cx: Q.x + Q.w / 2,
	cy: Q.y + Q.h / 2
};
function Ke(e) {
	let t = Q.w / e.scale, n = Q.h / e.scale;
	return {
		x: e.cx - t / 2,
		y: e.cy - n / 2,
		w: t,
		h: n
	};
}
function qe(e) {
	let t = Math.min(He, Math.max(1, e.scale)), n = Q.w / t, r = Q.h / t;
	return {
		scale: t,
		cx: Math.min(Q.x + Q.w - n / 2, Math.max(Q.x + n / 2, e.cx)),
		cy: Math.min(Q.y + Q.h - r / 2, Math.max(Q.y + r / 2, e.cy))
	};
}
function Je(e, t) {
	return Math.min(t.w / e.w, t.h / e.h);
}
function Ye(e, t, n, r) {
	let i = Je(n, r), a = (r.w - n.w * i) / 2, o = (r.h - n.h * i) / 2;
	return {
		x: n.x + (e - a) / i,
		y: n.y + (t - o) / i
	};
}
function Xe(e, t, n, r, i, a) {
	let o = qe({
		...e,
		scale: i
	}), s = Je(Ke(o), a);
	return qe({
		scale: o.scale,
		cx: t.x - (n - a.w / 2) / s,
		cy: t.y - (r - a.h / 2) / s
	});
}
var Ze = {
	red: "games.shallowsea.fishRed",
	yellow: "games.shallowsea.fishYellow",
	green: "games.shallowsea.fishGreen",
	purple: "games.shallowsea.fishPurple"
}, Qe = {
	A1: "games.shallowsea.slSameCoral3",
	A4: "games.shallowsea.slDiffFish3",
	B1: "games.shallowsea.slDirSameCoral4",
	C2: "games.shallowsea.slDiffCoral2",
	C4: "games.shallowsea.slDirSameFish2",
	D1: "games.shallowsea.slSameCoral3",
	D4: "games.shallowsea.slDiffFish3",
	E1: "games.shallowsea.slDirSameCoral3",
	E4: "games.shallowsea.slDirDiffFish3",
	F2: "games.shallowsea.slAnyAllCoral"
}, $e = {
	O1: "games.shallowsea.ecoO1",
	O2: "games.shallowsea.ecoO2",
	O3: "games.shallowsea.ecoO3",
	O4: "games.shallowsea.ecoO4",
	O5: "games.shallowsea.ecoO5",
	O6: "games.shallowsea.ecoO6",
	O7: "games.shallowsea.ecoO7",
	B1: "games.shallowsea.ecoB1",
	B2: "games.shallowsea.ecoB2",
	B3: "games.shallowsea.ecoB3",
	B4: "games.shallowsea.ecoB4",
	B5: "games.shallowsea.ecoB5",
	B6: "games.shallowsea.ecoB6",
	B7: "games.shallowsea.ecoB7"
};
function $(e, t, n = 1) {
	return Le.map(([r, i]) => `${e + r * Ie * n},${t + i * Ie * n}`).join(" ");
}
function et(e) {
	return Qe[e] ?? null;
}
function tt(e) {
	let t = e.public;
	return /* @__PURE__ */ v(it, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function nt(e) {
	return {
		key: e,
		fishPick: null,
		setupPick: null,
		freeMode: !1,
		pendingCell: null,
		rot: 0,
		movingFrom: !1,
		moveFrom: null
	};
}
function rt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!n) continue;
		let e = typeof n == "string" ? n : n.color;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	return [...t.values()].some((e) => e >= 4);
}
function it({ pub: e, members: t, myRid: c, send: u }) {
	let d = o(), f = a((e) => e.locale), b = r(null), [x, S] = i(1);
	n(() => {
		let e = b.current, t = window.matchMedia("(orientation: landscape)"), n = () => {
			let { width: n, height: r } = e.getBoundingClientRect();
			S(t.matches && n >= 900 && r >= 520 ? Math.max(1, Math.min(n / 900, r / 640, 1.5)) : 1);
		}, r = new ResizeObserver(n);
		return r.observe(e), t.addEventListener("change", n), n(), () => {
			r.disconnect(), t.removeEventListener("change", n);
		};
	}, []);
	let C = (e) => t.find((t) => t.rid === e)?.name ?? e, w = e.boards[c], D = e.shells[c] ?? 0, O = e.selection, k = e.phase, A = e.active === c, j = `${e.turnCount}:${k}:${e.active ?? ""}`, [M, te] = i(() => nt(j));
	M.key !== j && te(nt(j));
	let N = (e) => te((t) => ({
		...t,
		...e
	})), P = M.freeMode && D >= 2, F = rt(e.pools.coral), I = rt(e.pools.fish), L = "info", R;
	if (k === "done") L = "done", R = d("games.shallowsea.doneBanner");
	else if (A) L = "accent", R = k === "setup" ? d("games.shallowsea.setupPrompt") : k === "select" ? d(P ? "games.shallowsea.selectAnyMode" : "games.shallowsea.selectPrompt") : k === "tile" ? d("games.shallowsea.tilePrompt") : k === "fish" ? d("games.shallowsea.fishPrompt", { fish: O ? d(Ze[O.fish]) : "" }) : M.movingFrom ? d("games.shallowsea.movingFrom") : M.moveFrom ? d("games.shallowsea.movingTo") : d("games.shallowsea.endPrompt");
	else {
		let t = e.active ? C(e.active) : "";
		R = d(k === "setup" ? "games.shallowsea.setupWaiting" : k === "select" ? "games.shallowsea.selectWaiting" : "games.shallowsea.waitingFor", { name: t });
	}
	let z = k === "setup" && M.setupPick != null ? e.pools.sealife[M.setupPick] ?? null : null, B = k === "setup" && w && z ? T.filter((e) => !w.cells[e.id]).map((e) => e.id) : [], H = k === "tile" && w ? J(w) : B, U, W;
	k === "fish" && w ? (U = new Set(ce(w).map((e) => e.key)), W = (e, t) => u({
		type: "placeFish",
		cell: e,
		dir: t
	})) : k === "end" && w && M.movingFrom ? (U = new Set(Object.keys(w.bubbles)), W = (e, t) => N({
		movingFrom: !1,
		moveFrom: {
			cell: e,
			dir: t
		}
	})) : k === "end" && w && M.moveFrom && (U = new Set(ce(w).map((e) => e.key)), W = (e, t) => {
		M.moveFrom && u({
			type: "moveFish",
			fromCell: M.moveFrom.cell,
			fromDir: M.moveFrom.dir,
			toCell: e,
			toDir: t
		});
	});
	let G = null, K;
	k === "setup" && z && M.pendingCell ? (G = {
		cell: M.pendingCell,
		tile: {
			kind: "sealife",
			typeId: z,
			rot: M.rot,
			completed: !1
		}
	}, K = st(z, M.pendingCell, M.rot)) : k === "tile" && O && M.pendingCell && (O.tileKind === "coral" && O.coral ? G = {
		cell: M.pendingCell,
		tile: {
			kind: "coral",
			color: O.coral.color,
			vp: O.coral.vp,
			edges: O.coral.edges,
			rot: M.rot,
			completed: !1,
			lockedFish: null
		}
	} : O.tileKind === "sealife" && O.sealife && (G = {
		cell: M.pendingCell,
		tile: {
			kind: "sealife",
			typeId: O.sealife,
			rot: M.rot,
			completed: !1
		}
	}, K = st(O.sealife, M.pendingCell, M.rot)));
	let ne = e.lastPlaced && e.lastPlaced.rid === c ? e.lastPlaced.cell : null, re = A && M.pendingCell != null && (k === "tile" && O != null || k === "setup" && z != null), ie = () => {
		M.pendingCell && (k === "setup" ? M.setupPick != null && u({
			type: "setupPlace",
			index: M.setupPick,
			cell: M.pendingCell,
			rot: M.rot
		}) : u({
			type: "placeTile",
			cell: M.pendingCell,
			rot: M.rot
		}));
	}, ae = /* @__PURE__ */ y("div", {
		className: "shallowsea-banner flex flex-col",
		children: [
			/* @__PURE__ */ v(m, {
				tone: L,
				text: R,
				accent: V.accent
			}),
			/* @__PURE__ */ v("div", {
				className: "shallowsea-strip-wide",
				children: /* @__PURE__ */ v(h, {
					variant: "plate",
					members: t,
					myRid: c,
					status: (t) => {
						let n = e.scores?.[t];
						return /* @__PURE__ */ y("span", {
							className: "shallowsea-player-status",
							children: [/* @__PURE__ */ y("span", {
								className: "shallowsea-count",
								children: [/* @__PURE__ */ v(dt, { size: 13 }), d("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 })]
							}), n != null && /* @__PURE__ */ v("span", {
								className: "shallowsea-player-score",
								children: d("games.shallowsea.scoreShort", { n })
							})]
						});
					},
					action: (t) => e.active === t && k !== "done" ? "pending" : null
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "shallowsea-strip-short",
				children: t.map((t) => /* @__PURE__ */ y("span", {
					className: "shallowsea-shortseat",
					children: [
						/* @__PURE__ */ v(ee, {
							m: t,
							myRid: c,
							action: e.active === t.rid && k !== "done" ? "pending" : null,
							anchorName: null,
							box: "size-6",
							img: "size-5"
						}),
						/* @__PURE__ */ v("span", {
							className: "shallowsea-shortname",
							children: g(t, f)
						}),
						/* @__PURE__ */ y("span", {
							className: "shallowsea-shortshells",
							children: [/* @__PURE__ */ v(dt, { size: 12 }), d("games.shallowsea.shellsShort", { n: e.shells[t.rid] ?? 0 })]
						})
					]
				}, t.rid))
			})
		]
	}), q = (() => {
		if (k === "done") return /* @__PURE__ */ v("div", { className: "shallowsea-tray" });
		if (!A) return /* @__PURE__ */ v("div", { className: "shallowsea-tray shallowsea-tray-idle" });
		if (k === "setup") return /* @__PURE__ */ v("div", {
			className: "shallowsea-tray is-setup",
			children: /* @__PURE__ */ v("div", {
				className: "shallowsea-pool-row is-setup",
				role: "group",
				"aria-label": d("games.shallowsea.sealifePool"),
				children: e.pools.sealife.map((e, t) => /* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-chip",
					"data-selected": M.setupPick === t,
					disabled: !A || !e,
					"aria-label": e ? d("games.shallowsea.sealifeAria", {
						id: e,
						desc: at(e, d)
					}) : d("games.shallowsea.poolEmpty"),
					onClick: () => N({
						setupPick: t,
						pendingCell: null
					}),
					children: e ? /* @__PURE__ */ v(Ot, { typeId: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
				}, t))
			})
		});
		if (k === "select") {
			let t = (e) => M.fishPick != null && (P || M.fishPick === e);
			return /* @__PURE__ */ y("div", {
				className: "shallowsea-tray",
				children: [
					/* @__PURE__ */ v("div", {
						className: "shallowsea-tray-head",
						children: /* @__PURE__ */ y("button", {
							type: "button",
							className: "shallowsea-free",
							"data-on": P,
							"aria-pressed": P,
							disabled: D < 2 && !P,
							onClick: () => N({ freeMode: !M.freeMode }),
							children: [
								d("games.shallowsea.anyMode"),
								" · ",
								d("games.shallowsea.anyModeCost")
							]
						})
					}),
					/* @__PURE__ */ v(At, {
						pool: "coral",
						label: d("games.shallowsea.coralPool"),
						refreshLabel: d("games.shallowsea.refreshCoral"),
						cost: d(F ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !F && D < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "coral"
						}),
						children: e.pools.coral.map((e, n) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? d("games.shallowsea.coralAria", { vp: e.vp }) : d("games.shallowsea.poolEmpty"),
							onClick: () => M.fishPick != null && u(P ? {
								type: "selectAny",
								fish: M.fishPick,
								tile: "coral",
								index: n
							} : {
								type: "select",
								fish: M.fishPick,
								tile: "coral"
							}),
							children: e ? /* @__PURE__ */ v(Dt, { coral: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, n))
					}),
					/* @__PURE__ */ v(At, {
						pool: "fish",
						label: d("games.shallowsea.fishPool"),
						refreshLabel: d("games.shallowsea.refreshFish"),
						cost: d(I ? "games.shallowsea.refreshFree" : "games.shallowsea.refreshCost"),
						refreshDisabled: !I && D < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "fish"
						}),
						children: e.pools.fish.map((e, t) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === t,
							disabled: !e,
							"aria-label": d(e ? Ze[e] : "games.shallowsea.poolEmpty"),
							onClick: () => e && N({ fishPick: M.fishPick === t ? null : t }),
							children: e ? /* @__PURE__ */ v(kt, { color: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, t))
					}),
					/* @__PURE__ */ v(At, {
						pool: "sealife",
						label: d("games.shallowsea.sealifePool"),
						refreshLabel: d("games.shallowsea.refreshSealife"),
						cost: d("games.shallowsea.refreshCost"),
						refreshDisabled: D < 1,
						onRefresh: () => u({
							type: "refresh",
							pool: "sealife"
						}),
						children: e.pools.sealife.map((e, n) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-chip",
							"data-selected": M.fishPick === n,
							"data-dim": !t(n),
							disabled: !e || !t(n),
							"aria-label": e ? d("games.shallowsea.sealifeAria", {
								id: e,
								desc: at(e, d)
							}) : d("games.shallowsea.poolEmpty"),
							onClick: () => M.fishPick != null && u(P ? {
								type: "selectAny",
								fish: M.fishPick,
								tile: "sealife",
								index: n
							} : {
								type: "select",
								fish: M.fishPick,
								tile: "sealife"
							}),
							children: e ? /* @__PURE__ */ v(Ot, { typeId: e }) : /* @__PURE__ */ v("span", { className: "shallowsea-chip-empty" })
						}, n))
					})
				]
			});
		}
		if (k === "tile") {
			let e = O?.tileKind === "sealife" && O.sealife ? et(O.sealife) : null;
			return /* @__PURE__ */ v("div", {
				className: "shallowsea-tray shallowsea-tray-actions",
				children: O && /* @__PURE__ */ y("div", {
					className: "shallowsea-pending",
					children: [
						O.tileKind === "coral" && O.coral ? /* @__PURE__ */ v(Dt, {
							coral: O.coral,
							size: 40
						}) : O.sealife ? /* @__PURE__ */ v(Ot, {
							typeId: O.sealife,
							size: 40
						}) : null,
						e && /* @__PURE__ */ v("span", {
							className: "shallowsea-pending-text",
							children: d(e)
						}),
						M.pendingCell && /* @__PURE__ */ v("button", {
							type: "button",
							className: "shallowsea-btn",
							onClick: () => N({ pendingCell: null }),
							children: d("games.shallowsea.cancel")
						})
					]
				})
			});
		}
		return k === "fish" ? /* @__PURE__ */ v("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ y("div", {
				className: "shallowsea-pending",
				children: [O && /* @__PURE__ */ v(kt, {
					color: O.fish,
					size: 40
				}), /* @__PURE__ */ v("span", {
					className: "shallowsea-pending-text",
					children: O ? d("games.shallowsea.fishPrompt", { fish: d(Ze[O.fish]) }) : d("games.shallowsea.selectPrompt")
				})]
			})
		}) : /* @__PURE__ */ v("div", {
			className: "shallowsea-tray shallowsea-tray-actions",
			children: /* @__PURE__ */ y("div", {
				className: "shallowsea-buttons",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-btn is-primary",
					onClick: () => u({ type: "endTurn" }),
					children: d("games.shallowsea.endTurn")
				}), !M.movingFrom && !M.moveFrom ? /* @__PURE__ */ y("button", {
					type: "button",
					className: "shallowsea-btn",
					disabled: D < 2,
					onClick: () => N({ movingFrom: !0 }),
					children: [/* @__PURE__ */ v(s, {
						size: 16,
						"aria-hidden": !0
					}), /* @__PURE__ */ y("span", { children: [
						d("games.shallowsea.moveFish"),
						" · ",
						d("games.shallowsea.moveCost")
					] })]
				}) : /* @__PURE__ */ v("button", {
					type: "button",
					className: "shallowsea-btn",
					onClick: () => N({
						movingFrom: !1,
						moveFrom: null
					}),
					children: d("games.shallowsea.cancelMove")
				})]
			})
		});
	})();
	return /* @__PURE__ */ v("div", {
		ref: b,
		className: "shallowsea-screen h-full min-h-0",
		style: { "--shallowsea-ui-scale": x },
		children: /* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "shallowsea-game",
			scroll: k === "done",
			banner: ae,
			actions: q,
			actionsHeight: "shallowsea-actions",
			children: /* @__PURE__ */ y("div", {
				className: `shallowsea-table${k === "done" ? " is-done" : ""}`,
				children: [
					k === "done" && /* @__PURE__ */ v(jt, {
						pub: e,
						nameOf: C
					}),
					/* @__PURE__ */ v("section", {
						className: "shallowsea-main",
						children: /* @__PURE__ */ v(ct, {
							board: w,
							label: d("games.shallowsea.myBoard"),
							placeAria: (e) => {
								let t = E[e];
								return t ? d("games.shallowsea.placeAria", {
									row: t.r + 1,
									col: t.q + 3
								}) : "";
							},
							fishAria: (e) => d(Ze[e]),
							bubbleAria: d("games.shallowsea.emptyBubbleAria"),
							legalCells: A ? new Set(H) : void 0,
							onCell: A ? (e) => N({ pendingCell: e }) : void 0,
							bubbleTargets: A ? U : void 0,
							onBubble: A ? W : void 0,
							markers: K,
							preview: G,
							lastPlaced: ne,
							zoomable: !0,
							controlsCell: re ? M.pendingCell : null,
							controlsScale: x,
							controls: re ? /* @__PURE__ */ y(_, { children: [
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-rotate",
									"aria-label": d("games.shallowsea.rotateLeft"),
									onClick: () => N({ rot: (M.rot + 5) % 6 }),
									children: /* @__PURE__ */ v(l, {
										size: 20,
										className: "shallowsea-mirror",
										"aria-hidden": !0
									})
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-rotate",
									"aria-label": d("games.shallowsea.rotateRight"),
									onClick: () => N({ rot: (M.rot + 1) % 6 }),
									children: /* @__PURE__ */ v(l, {
										size: 20,
										"aria-hidden": !0
									})
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "shallowsea-place-confirm",
									onClick: ie,
									children: d("games.shallowsea.confirmPlace")
								})
							] }) : void 0
						})
					}),
					/* @__PURE__ */ y("div", {
						className: "shallowsea-side",
						children: [e.players.length > 1 && /* @__PURE__ */ v("aside", {
							className: "shallowsea-others",
							children: e.players.filter((e) => e !== c).map((t) => /* @__PURE__ */ y("div", {
								className: "shallowsea-mini",
								children: [/* @__PURE__ */ y("div", {
									className: "shallowsea-mini-head",
									children: [/* @__PURE__ */ v("span", {
										className: "truncate",
										children: C(t)
									}), /* @__PURE__ */ y("span", {
										className: "shallowsea-count font-mono tabular-nums",
										children: [/* @__PURE__ */ v(dt, { size: 12 }), d("games.shallowsea.shellsShort", { n: e.shells[t] ?? 0 })]
									})]
								}), /* @__PURE__ */ v(ct, {
									board: e.boards[t],
									label: d("games.shallowsea.boardOf", { name: C(t) })
								})]
							}, t))
						}), /* @__PURE__ */ v(ot, { pub: e })]
					})
				]
			})
		})
	});
}
function at(e, t) {
	let n = et(e);
	return n ? t(n) : e;
}
function ot({ pub: e }) {
	let t = o(), n = $e[e.ecosystems.orange] ?? null, r = $e[e.ecosystems.blue] ?? null;
	return !n && !r ? null : /* @__PURE__ */ y("section", {
		className: "shallowsea-eco",
		"aria-label": t("games.shallowsea.ecoCards"),
		children: [/* @__PURE__ */ v("div", {
			className: "shallowsea-eco-head",
			children: t("games.shallowsea.ecoCards")
		}), /* @__PURE__ */ y("div", {
			className: "shallowsea-eco-cards",
			children: [n && /* @__PURE__ */ y("div", {
				className: "shallowsea-eco-card is-orange",
				children: [/* @__PURE__ */ v("span", {
					className: "shallowsea-eco-tag",
					children: t("games.shallowsea.ecoOrange")
				}), /* @__PURE__ */ v("span", {
					className: "shallowsea-eco-name",
					children: t(n)
				})]
			}), r && /* @__PURE__ */ y("div", {
				className: "shallowsea-eco-card is-blue",
				children: [/* @__PURE__ */ v("span", {
					className: "shallowsea-eco-tag",
					children: t("games.shallowsea.ecoBlue")
				}), /* @__PURE__ */ v("span", {
					className: "shallowsea-eco-name",
					children: t(r)
				})]
			})]
		})]
	});
}
function st(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = P[e];
	if (!i) return r;
	for (let e of i.offsets ?? []) {
		let i = k(t, (e + n) % 6);
		i && r.add(i);
	}
	for (let e of i.dirs ?? []) {
		let i = t;
		for (;;) {
			let t = k(i, (e + n) % 6);
			if (!t) break;
			r.add(t), i = t;
		}
	}
	return r;
}
function ct({ board: e, label: t, placeAria: a, fishAria: s, bubbleAria: l, legalCells: u, onCell: p, bubbleTargets: m, onBubble: h, markers: ee, preview: g, lastPlaced: _, controls: b, controlsCell: x, controlsScale: S = 1, zoomable: C = !1 }) {
	let w = o(), D = r(null), O = r(null), k = r(null), [M, te] = i({
		w: 0,
		h: 0
	}), [N, P] = i({
		w: 214,
		h: 46
	}), [F, I] = i(200), [L, R] = i(() => C && typeof window < "u" && window.innerWidth < 700 && window.innerHeight >= 520 ? qe({
		...Ge,
		scale: We
	}) : Ge), z = r(L), B = r(/* @__PURE__ */ new Map()), V = r(0), H = r(0), U = r(null), W = (e) => {
		let t = qe(e);
		z.current = t, R(t);
	};
	n(() => {
		let e = D.current, t = () => te({
			w: e.clientWidth,
			h: e.clientHeight
		}), n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, []), n(() => {
		let e = k.current;
		if (!e) return;
		let t = () => {
			P({
				w: e.offsetWidth,
				h: e.offsetHeight
			});
			let t = parseFloat(getComputedStyle(e).getPropertyValue("--shallowsea-ui-scale")) || 1;
			t > 0 && I(e.offsetWidth / t);
		}, n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, [x]), n(() => {
		let e = O.current, t = D.current;
		if (!C || !e || !t) return;
		let n = (e) => {
			e.preventDefault();
			let n = t.getBoundingClientRect(), r = {
				w: n.width,
				h: n.height
			}, i = Ke(z.current), a = Ye(e.clientX - n.left, e.clientY - n.top, i, r), o = e.deltaY < 0 ? 1.15 : 1 / 1.15;
			W(Xe(z.current, a, e.clientX - n.left, e.clientY - n.top, z.current.scale * o, r));
		};
		return e.addEventListener("wheel", n, { passive: !1 }), () => e.removeEventListener("wheel", n);
	}, [C]), n(() => {
		if (!C) return;
		let e = (e) => {
			B.current.delete(e.pointerId), B.current.size < 2 && (U.current = null);
		};
		return window.addEventListener("pointerup", e), window.addEventListener("pointercancel", e), () => {
			window.removeEventListener("pointerup", e), window.removeEventListener("pointercancel", e);
		};
	}, [C]);
	let G = (e) => {
		let t = D.current.getBoundingClientRect();
		return {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		};
	}, K = (e) => {
		if (C) {
			if (B.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), B.current.size === 1) V.current = 0, H.current = 0;
			else if (B.current.size === 2) {
				let [e, t] = [...B.current.values()], n = G({
					clientX: (e.x + t.x) / 2,
					clientY: (e.y + t.y) / 2
				}), r = Ke(z.current);
				U.current = {
					dist: Math.max(1, Math.hypot(t.x - e.x, t.y - e.y)),
					view: z.current,
					anchor: Ye(n.x, n.y, r, M)
				}, V.current = 99, H.current = performance.now() + 400;
			}
		}
	}, ne = (e) => {
		if (!C) return;
		if (e.pointerType === "mouse" && e.buttons === 0) {
			B.current.delete(e.pointerId), U.current = null;
			return;
		}
		let t = B.current.get(e.pointerId);
		if (t) {
			if (B.current.size === 1) {
				let n = e.clientX - t.x, r = e.clientY - t.y;
				V.current += Math.abs(n) + Math.abs(r), V.current > 8 && (H.current = performance.now() + 400);
				let i = Je(Ke(z.current), M);
				W({
					...z.current,
					cx: z.current.cx - n / i,
					cy: z.current.cy - r / i
				}), B.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				return;
			}
			if (B.current.size === 2) {
				B.current.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				});
				let t = U.current;
				if (!t) return;
				let [n, r] = [...B.current.values()], i = G({
					clientX: (n.x + r.x) / 2,
					clientY: (n.y + r.y) / 2
				}), a = Math.max(1, Math.hypot(r.x - n.x, r.y - n.y));
				W(Xe(t.view, t.anchor, i.x, i.y, t.view.scale * (a / t.dist), M)), V.current = 99, H.current = performance.now() + 400;
			}
		}
	}, re = (e) => {
		C && (B.current.size === 1 && V.current > 8 && (H.current = performance.now() + 400), B.current.delete(e.pointerId), U.current = null);
	}, ie = (e) => {
		B.current.delete(e.pointerId), U.current = null;
	}, ae = (e) => {
		performance.now() >= H.current || O.current?.contains(e.target) && (e.preventDefault(), e.stopPropagation());
	}, q = Ke(L), oe = `${Math.round(q.x * 1e4) / 1e4} ${Math.round(q.y * 1e4) / 1e4} ${Math.round(q.w * 1e4) / 1e4} ${Math.round(q.h * 1e4) / 1e4}`, se = [], J = /* @__PURE__ */ new Set();
	for (let e of T) {
		let t = j(e);
		for (let n = 0; n < 6; n += 1) {
			let { key: r } = A(e.id, n);
			if (J.has(r)) continue;
			J.add(r);
			let [i, a] = Be[n];
			se.push({
				key: r,
				cell: e.id,
				dir: n,
				x: t.x + i,
				y: t.y + a
			});
		}
	}
	let ce = g ? E[g.cell] : null, Y = ce ? j(ce) : null, le = x ? E[x] : null, X = S * (M.w && F > 0 ? Math.min(1, (M.w - 16) / F) : 1), ue = (() => {
		if (!b || !le || !M.w || !M.h) return null;
		let e = j(le), t = Je(q, M), n = (M.w - q.w * t) / 2, r = (M.h - q.h * t) / 2, i = (e.x - q.x) * t + n, a = (e.y - q.y) * t + r, o = N.w / 2, s = N.h / 2, c = a + t + 10 * X + s, l = a - t - 10 * X - s, d = (e) => e >= s + 8 && e <= M.h - s - 8, f = Math.max(o + 8, Math.min(M.w - o - 8, i)), p = [...u ?? []].filter((e) => e !== x && E[e]).map((e) => j(E[e])), m = (e) => p.reduce((i, a) => i + +(Math.abs((a.x - q.x) * t + n - f) < o + t && Math.abs((a.y - q.y) * t + r - e) < s + t), 0), h = d(c), ee = d(l);
		return {
			left: f,
			top: h && ee ? m(c) <= m(l) ? c : l : h ? c : ee ? l : Math.max(s + 8, Math.min(M.h - s - 8, c))
		};
	})();
	return /* @__PURE__ */ y("div", {
		ref: D,
		className: `shallowsea-board-frame${C ? " is-zoomable" : ""}`,
		onClickCapture: C ? ae : void 0,
		children: [
			/* @__PURE__ */ v(lt, {}),
			/* @__PURE__ */ y("svg", {
				ref: O,
				viewBox: oe,
				className: `shallowsea-board-svg${C ? " is-zoomable" : ""}`,
				role: "group",
				"aria-label": t,
				onPointerDown: C ? K : void 0,
				onPointerMove: C ? ne : void 0,
				onPointerUp: C ? re : void 0,
				onPointerCancel: C ? ie : void 0,
				children: [
					T.map((t) => {
						let n = j(t), r = e?.cells[t.id], i = !!(u?.has(t.id) && p);
						return /* @__PURE__ */ y("g", { children: [
							/* @__PURE__ */ v("polygon", {
								points: $(n.x, n.y, .985),
								className: `shallowsea-hex${i ? " is-legal" : ""}`,
								onClick: i && p ? () => p(t.id) : void 0,
								onKeyDown: i && p ? (e) => {
									(e.key === "Enter" || e.key === " ") && (e.preventDefault(), p(t.id));
								} : void 0,
								role: i ? "button" : void 0,
								tabIndex: i ? 0 : void 0,
								"aria-label": i && a ? a(t.id) : void 0
							}),
							ee?.has(t.id) && /* @__PURE__ */ v("polygon", {
								points: $(n.x, n.y, .8),
								className: "shallowsea-hex-mark"
							}),
							r && (r.kind === "coral" ? /* @__PURE__ */ v(ht, {
								tile: r,
								x: n.x,
								y: n.y
							}) : /* @__PURE__ */ v(Tt, {
								tile: r,
								x: n.x,
								y: n.y
							})),
							_ === t.id && /* @__PURE__ */ v("polygon", {
								points: $(n.x, n.y, 1),
								className: "shallowsea-hex-last"
							})
						] }, t.id);
					}),
					se.map((t) => {
						let n = e?.bubbles[t.key], r = !!(m?.has(t.key) && h);
						return /* @__PURE__ */ y("g", { children: [n ? /* @__PURE__ */ v(mt, {
							x: t.x,
							y: t.y,
							color: n
						}) : r ? /* @__PURE__ */ y("g", {
							className: "shallowsea-pearl is-target",
							"aria-hidden": !0,
							children: [
								/* @__PURE__ */ v("circle", {
									cx: t.x,
									cy: t.y,
									r: .135,
									className: "shallowsea-pearl-body"
								}),
								/* @__PURE__ */ v("circle", {
									cx: t.x - .045,
									cy: t.y - .045,
									r: .036,
									className: "shallowsea-pearl-shine"
								}),
								/* @__PURE__ */ v("circle", {
									cx: t.x,
									cy: t.y,
									r: .27,
									className: "shallowsea-pearl-ring"
								})
							]
						}) : /* @__PURE__ */ v("circle", {
							cx: t.x,
							cy: t.y,
							r: .055,
							className: "shallowsea-socket",
							"aria-hidden": !0
						}), r && h && /* @__PURE__ */ v("circle", {
							cx: t.x,
							cy: t.y,
							r: .34,
							className: "shallowsea-hit",
							role: "button",
							tabIndex: 0,
							"aria-label": n && s ? s(n) : l,
							onClick: () => h(t.cell, t.dir),
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), h(t.cell, t.dir));
							}
						})] }, t.key);
					}),
					g && Y && /* @__PURE__ */ y("g", {
						className: "shallowsea-preview",
						children: [g.tile.kind === "coral" ? /* @__PURE__ */ v(ht, {
							tile: g.tile,
							x: Y.x,
							y: Y.y
						}) : /* @__PURE__ */ v(Tt, {
							tile: g.tile,
							x: Y.x,
							y: Y.y
						}), /* @__PURE__ */ v("polygon", {
							points: $(Y.x, Y.y, 1),
							className: "shallowsea-hex-preview"
						})]
					})
				]
			}),
			C && /* @__PURE__ */ y("div", {
				className: "shallowsea-zoom",
				role: "group",
				"aria-label": w("games.shallowsea.zoomControls"),
				children: [
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.zoomOut"),
						disabled: L.scale <= 1.001,
						onClick: () => W({
							...z.current,
							scale: z.current.scale / Ue
						}),
						children: /* @__PURE__ */ v(f, {
							size: 18,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.zoomIn"),
						disabled: L.scale >= 2.999,
						onClick: () => W({
							...z.current,
							scale: z.current.scale * Ue
						}),
						children: /* @__PURE__ */ v(d, {
							size: 18,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "shallowsea-zoom-btn",
						"aria-label": w("games.shallowsea.fitBoard"),
						disabled: L.scale <= 1.001,
						onClick: () => W(Ge),
						children: /* @__PURE__ */ v(c, {
							size: 18,
							"aria-hidden": !0
						})
					})
				]
			}),
			b && le && /* @__PURE__ */ v("div", {
				ref: k,
				className: "shallowsea-place-controls",
				style: {
					...ue ?? {
						left: 0,
						top: 0,
						visibility: "hidden"
					},
					"--shallowsea-ui-scale": X
				},
				children: b
			})
		]
	});
}
function lt() {
	return /* @__PURE__ */ y("svg", {
		className: "shallowsea-reef",
		viewBox: Ve,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("g", {
				fill: "#0b4a5f",
				opacity: "0.12",
				children: [/* @__PURE__ */ v("path", { d: "M-2.6,5.2 L-2.2,4.98 C-1.9,4.86 -1.6,5.04 -1.3,4.92 L-0.9,5.2 Z" }), /* @__PURE__ */ v("path", { d: "M5.4,5.2 L5.95,4.9 C6.4,4.72 6.8,4.98 7.3,4.86 L8.6,5.2 Z" })]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#f2fffd",
				opacity: "0.2",
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -1.85,
						cy: 4.86,
						r: .26
					}),
					/* @__PURE__ */ v("circle", {
						cx: -1.55,
						cy: 4.62,
						r: .34
					}),
					/* @__PURE__ */ v("circle", {
						cx: -1.22,
						cy: 4.9,
						r: .2
					}),
					/* @__PURE__ */ v("path", {
						d: "M-1.9,5.2 L-1.9,4.84 M-1.62,5.2 L-1.62,4.5 M-1.3,5.2 L-1.3,4.86",
						stroke: "#f2fffd",
						strokeWidth: .09,
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.15,
						cy: 4.78,
						r: .22
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.5,
						cy: 4.6,
						r: .3
					}),
					/* @__PURE__ */ v("circle", {
						cx: 7.85,
						cy: 4.86,
						r: .18
					}),
					/* @__PURE__ */ v("path", {
						d: "M7.2,5.2 L7.2,4.74 M7.52,5.2 L7.52,4.5 M7.86,5.2 L7.86,4.84",
						stroke: "#f2fffd",
						strokeWidth: .09,
						strokeLinecap: "round"
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				fill: "none",
				stroke: "#d8fbf5",
				strokeWidth: .08,
				strokeLinecap: "round",
				opacity: "0.22",
				children: [/* @__PURE__ */ v("path", { d: "M8.24,5.2 C8.06,4.7 8.32,4.3 8.12,3.86 C7.96,3.5 8.2,3.16 8.06,2.82" }), /* @__PURE__ */ v("path", { d: "M-2.28,5.2 C-2.42,4.86 -2.2,4.56 -2.36,4.24" })]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#ffffff",
				opacity: "0.3",
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -.35,
						cy: 4.55,
						r: .05
					}),
					/* @__PURE__ */ v("circle", {
						cx: .1,
						cy: 4.76,
						r: .04
					}),
					/* @__PURE__ */ v("circle", {
						cx: 5.9,
						cy: 4.62,
						r: .045
					})
				]
			})
		]
	});
}
function ut() {
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.94 C0.2,0.9 0.07,0.58 0.15,0.34 C0.24,0.1 0.37,0.05 0.5,0.05 C0.63,0.05 0.76,0.1 0.85,0.34 C0.93,0.58 0.8,0.9 0.5,0.94 Z",
			fill: "#f4c66d",
			stroke: "#8a5a2b",
			strokeWidth: .07
		}),
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.88 C0.34,0.7 0.3,0.42 0.5,0.24 C0.7,0.42 0.66,0.7 0.5,0.88 Z",
			fill: "none",
			stroke: "#8a5a2b",
			strokeWidth: .045,
			opacity: .65
		}),
		/* @__PURE__ */ v("path", {
			d: "M0.5,0.88 L0.5,0.26 M0.34,0.82 L0.38,0.32 M0.66,0.82 L0.62,0.32",
			fill: "none",
			stroke: "#8a5a2b",
			strokeWidth: .03,
			opacity: .5
		})
	] });
}
function dt({ size: e = 14 }) {
	return /* @__PURE__ */ v("svg", {
		className: "shallowsea-shell",
		width: e,
		height: e,
		viewBox: "0 0 1 1",
		"aria-hidden": "true",
		children: /* @__PURE__ */ v(ut, {})
	});
}
function ft({ color: e, x: t, y: n, scale: r }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: .02,
				cy: .56,
				rx: .34,
				ry: .1,
				fill: "#083c46",
				opacity: .12
			}),
			/* @__PURE__ */ y("g", {
				fill: "none",
				stroke: e,
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M0,0.58 L0,0.12",
						strokeWidth: .19
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.34 C-0.14,0.24 -0.24,0.08 -0.32,-0.14",
						strokeWidth: .14
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.28 C0.14,0.18 0.24,0.02 0.32,-0.2",
						strokeWidth: .14
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.12 C-0.06,-0.04 -0.06,-0.2 -0.02,-0.38",
						strokeWidth: .13
					}),
					/* @__PURE__ */ v("path", {
						d: "M0,0.16 C0.08,0.02 0.12,-0.1 0.14,-0.32",
						strokeWidth: .11
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				fill: "#fff",
				opacity: .35,
				children: [
					/* @__PURE__ */ v("circle", {
						cx: -.31,
						cy: -.16,
						r: .045
					}),
					/* @__PURE__ */ v("circle", {
						cx: .31,
						cy: -.22,
						r: .045
					}),
					/* @__PURE__ */ v("circle", {
						cx: -.02,
						cy: -.4,
						r: .04
					})
				]
			})
		]
	});
}
function pt() {
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v("polygon", {
			points: $(0, 0, .9),
			fill: "none",
			stroke: "#10b1a6",
			strokeWidth: .08,
			strokeDasharray: "0.22 0.12"
		}),
		/* @__PURE__ */ v("circle", {
			cx: .52,
			cy: -.5,
			r: .17,
			fill: "#fffdf6",
			stroke: "#10b1a6",
			strokeWidth: .05
		}),
		/* @__PURE__ */ v("g", {
			transform: "translate(0.38 -0.63) scale(0.28)",
			children: /* @__PURE__ */ v(ut, {})
		})
	] });
}
function mt({ x: e, y: t, color: n, scale: r = 1 }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) scale(${r})`,
		className: "shallowsea-fish-token",
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: .05,
				cy: .11,
				rx: .27,
				ry: .16,
				fill: "#04323c",
				opacity: .2
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.06,0 L-0.18,-0.18 L-0.35,-0.11 L-0.26,0 L-0.35,0.11 L-0.18,0.18 Z",
				fill: n,
				stroke: "#083038",
				strokeWidth: .04,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.12,-0.05 C-0.06,-0.21 0.14,-0.21 0.25,-0.06 L0.31,-0.02 L0.31,0.02 L0.25,0.06 C0.14,0.21 -0.06,0.21 -0.12,0.05 Z",
				fill: n,
				stroke: "#083038",
				strokeWidth: .045
			}),
			/* @__PURE__ */ v("path", {
				d: "M0.0,-0.15 L0.1,-0.25 L0.15,-0.09 Z",
				fill: "#fff",
				opacity: .3
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: .07,
				cy: -.09,
				rx: .09,
				ry: .033,
				fill: "#fff",
				opacity: .35
			}),
			/* @__PURE__ */ v("circle", {
				cx: .18,
				cy: -.03,
				r: .035,
				fill: "#083038"
			})
		]
	});
}
function ht({ tile: e, x: t, y: n }) {
	let r = x[e.color];
	return /* @__PURE__ */ y("g", {
		className: "shallowsea-face",
		transform: `translate(${t} ${n}) scale(${Ie})`,
		children: [
			/* @__PURE__ */ v("polygon", {
				points: $(.03, .05, .97),
				fill: "#04323c",
				opacity: .22
			}),
			/* @__PURE__ */ v("polygon", {
				points: $(0, 0, .97),
				fill: "#fffdf6",
				stroke: "#0b3a43",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("polygon", {
				points: $(0, 0, .9),
				fill: r,
				fillOpacity: e.completed ? .16 : .1
			}),
			[
				0,
				1,
				2,
				3,
				4,
				5
			].map((t) => {
				let n = q(e, t);
				if (!n) return null;
				let [r, i] = Re[t], a = t === 0 || t === 3;
				return /* @__PURE__ */ v("line", {
					x1: r[0] * .84,
					y1: r[1] * .84,
					x2: i[0] * .84,
					y2: i[1] * .84,
					stroke: x[n],
					strokeWidth: a ? .14 : .2,
					strokeLinecap: "round"
				}, t);
			}),
			/* @__PURE__ */ v(ft, {
				color: r,
				x: 0,
				y: .12,
				scale: .84
			}),
			/* @__PURE__ */ v("circle", {
				cx: -.52,
				cy: -.52,
				r: .13,
				fill: r,
				stroke: "#fffdf6",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("circle", {
				cx: .48,
				cy: .48,
				r: .26,
				fill: "#8a5a2b",
				stroke: "#fffdf6",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("text", {
				x: .48,
				y: .585,
				textAnchor: "middle",
				fontSize: .31,
				fontWeight: 900,
				fill: "#fff",
				children: e.vp
			}),
			e.completed && /* @__PURE__ */ v(pt, {}),
			e.lockedFish && /* @__PURE__ */ v(mt, {
				x: .02,
				y: -.34,
				color: e.lockedFish,
				scale: .86
			})
		]
	});
}
var gt = "#2f7fd0", _t = "#d9534f";
function vt(e) {
	return e === "sameCoral" || e === "sameFish" || e === "dirSameCoral" || e === "dirSameFish";
}
function yt(e) {
	return e === "anyAllCoral" ? "all" : e.includes("Fish") ? "fish" : "coral";
}
function bt({ color: e }) {
	return /* @__PURE__ */ y("g", {
		stroke: e,
		strokeWidth: .12,
		strokeLinecap: "round",
		fill: "none",
		children: [
			/* @__PURE__ */ v("path", { d: "M0,0.46 L0,0.02" }),
			/* @__PURE__ */ v("path", { d: "M0,0.10 C-0.12,0.02 -0.22,-0.12 -0.27,-0.30" }),
			/* @__PURE__ */ v("path", { d: "M0,0.10 C0.12,0.02 0.22,-0.12 0.27,-0.30" }),
			/* @__PURE__ */ v("path", { d: "M0,0.02 L0,-0.34" }),
			/* @__PURE__ */ v("path", { d: "M-0.27,-0.30 L-0.37,-0.42" }),
			/* @__PURE__ */ v("path", { d: "M0.27,-0.30 L0.37,-0.42" })
		]
	});
}
function xt({ color: e }) {
	return /* @__PURE__ */ y("g", {
		fill: e,
		children: [/* @__PURE__ */ v("ellipse", {
			cx: .06,
			cy: 0,
			rx: .3,
			ry: .2
		}), /* @__PURE__ */ v("path", { d: "M-0.18,0 L-0.46,-0.24 L-0.46,0.24 Z" })]
	});
}
function St({ kind: e, x: t, y: n, scale: r }) {
	let i = yt(e), a = i === "fish" ? xt : bt;
	return i === "all" ? /* @__PURE__ */ v("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: b.map((e, t) => /* @__PURE__ */ v("g", {
			transform: `translate(${(t - 1.5) * .52} 0) scale(0.72)`,
			children: /* @__PURE__ */ v(bt, { color: x[e] })
		}, e))
	}) : vt(e) ? /* @__PURE__ */ v("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: /* @__PURE__ */ v(a, { color: gt })
	}) : /* @__PURE__ */ y("g", {
		transform: `translate(${t} ${n}) scale(${r})`,
		children: [/* @__PURE__ */ v("g", {
			transform: "translate(-0.16 0) scale(0.72)",
			children: /* @__PURE__ */ v(a, { color: _t })
		}), /* @__PURE__ */ v("g", {
			transform: "translate(0.16 0) scale(0.72)",
			children: /* @__PURE__ */ v(a, { color: gt })
		})]
	});
}
function Ct({ kind: e, x: t, y: n }) {
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
		cx: t,
		cy: n,
		r: .2,
		fill: "#fffdf6",
		stroke: "#0a4f58",
		strokeWidth: .035
	}), /* @__PURE__ */ v(St, {
		kind: e,
		x: t,
		y: n,
		scale: .22
	})] });
}
function wt({ type: e, x: t, y: n }) {
	let r = vt(e.kind);
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("polygon", {
		points: $(t, n - .04, .32),
		fill: "#0b3a43"
	}), /* @__PURE__ */ v("text", {
		x: t,
		y: n + .08,
		textAnchor: "middle",
		fontSize: .36,
		fontWeight: 900,
		fill: r ? "#5ef2a8" : "#ffb0a6",
		children: r ? "=" : "≠"
	})] });
}
function Tt({ tile: e, x: t, y: n, showId: r = !0 }) {
	let i = P[e.typeId];
	return /* @__PURE__ */ y("g", {
		className: "shallowsea-face",
		transform: `translate(${t} ${n}) scale(${Ie})`,
		children: [
			/* @__PURE__ */ v("polygon", {
				points: $(.03, .05, .97),
				fill: "#04323c",
				opacity: .22
			}),
			/* @__PURE__ */ v("polygon", {
				points: $(0, 0, .97),
				fill: "#f7fffd",
				stroke: "#0b3a43",
				strokeWidth: .05
			}),
			/* @__PURE__ */ v("polygon", {
				points: $(0, 0, .9),
				fill: "#7fd8d0",
				fillOpacity: e.completed ? .22 : .13
			}),
			i && /* @__PURE__ */ y(_, { children: [
				i.offsets?.map((t) => {
					let [n, r] = ze[(t + e.rot) % 6];
					return /* @__PURE__ */ v(Ct, {
						kind: i.kind,
						x: n * .7,
						y: r * .7
					}, `o${t}`);
				}),
				i.dirs?.map((t) => /* @__PURE__ */ v(Et, {
					kind: i.kind,
					x: 0,
					y: 0,
					dir: (t + e.rot) % 6
				}, `d${t}`)),
				i.kind === "anyAllCoral" && /* @__PURE__ */ v(St, {
					kind: i.kind,
					x: 0,
					y: -.52,
					scale: .27
				}),
				/* @__PURE__ */ v(wt, {
					type: i,
					x: 0,
					y: 0
				}),
				/* @__PURE__ */ v("text", {
					y: .57,
					textAnchor: "middle",
					fontSize: .34,
					fontWeight: 900,
					fill: "#0b3a43",
					children: i.need
				}),
				/* @__PURE__ */ v("circle", {
					cx: -.55,
					cy: .33,
					r: .24,
					fill: "#8a5a2b",
					stroke: "#fffdf6",
					strokeWidth: .04
				}),
				/* @__PURE__ */ v("text", {
					x: -.55,
					y: .435,
					textAnchor: "middle",
					fontSize: .3,
					fontWeight: 900,
					fill: "#fff",
					children: i.partial
				}),
				/* @__PURE__ */ v("circle", {
					cx: .55,
					cy: .33,
					r: .24,
					fill: "#0b3a43",
					stroke: "#fffdf6",
					strokeWidth: .04
				}),
				/* @__PURE__ */ v("text", {
					x: .55,
					y: .435,
					textAnchor: "middle",
					fontSize: .3,
					fontWeight: 900,
					fill: "#fff",
					children: i.vp
				}),
				r && /* @__PURE__ */ v("text", {
					y: .79,
					textAnchor: "middle",
					fontSize: .25,
					fontWeight: 900,
					fill: "#0b3a43",
					stroke: "#f7fffd",
					strokeWidth: .04,
					paintOrder: "stroke",
					children: e.typeId
				})
			] }),
			e.completed && /* @__PURE__ */ v(pt, {})
		]
	});
}
function Et({ kind: e, x: t, y: n, dir: r }) {
	let [i, a] = ze[r], o = Math.hypot(i, a), s = i / o, c = a / o, l = -c, u = s, d = t + s * .5, f = n + c * .5, p = t + s * .82, m = n + c * .82;
	return /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v(St, {
		kind: e,
		x: t + s * .38,
		y: n + c * .38,
		scale: .22
	}), /* @__PURE__ */ y("g", {
		stroke: "#0a5963",
		strokeWidth: .05,
		fill: "none",
		opacity: .8,
		children: [/* @__PURE__ */ v("line", {
			x1: d,
			y1: f,
			x2: p,
			y2: m
		}), /* @__PURE__ */ v("path", {
			d: `M${p},${m} L${p - s * .16 + l * .09},${m - c * .16 + u * .09} L${p - s * .16 - l * .09},${m - c * .16 - u * .09} Z`,
			fill: "#0a5963",
			stroke: "none"
		})]
	})] });
}
function Dt({ coral: e, size: t }) {
	return /* @__PURE__ */ y("span", {
		className: "shallowsea-chip-visual",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: [
			/* @__PURE__ */ v("span", {
				className: "shallowsea-chip-fill",
				style: { background: x[e.color] }
			}),
			/* @__PURE__ */ v("span", {
				className: "shallowsea-chip-vp",
				children: e.vp
			}),
			e.edges.map((e, t) => e ? /* @__PURE__ */ v("span", {
				"data-dir": t,
				className: "shallowsea-chip-edge",
				style: { background: x[e] }
			}, t) : null)
		]
	});
}
function Ot({ typeId: e, size: t }) {
	let n = P[e];
	return /* @__PURE__ */ v("span", {
		className: "shallowsea-chip-visual is-sealife",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		children: n ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("svg", {
			viewBox: "-0.78 -0.78 1.56 1.56",
			className: "shallowsea-chip-sealife",
			"aria-hidden": !0,
			children: /* @__PURE__ */ v(Tt, {
				tile: {
					typeId: e,
					rot: 0,
					completed: !1
				},
				x: 0,
				y: 0,
				showId: !1
			})
		}), /* @__PURE__ */ v("span", {
			className: "shallowsea-chip-type",
			children: e
		})] }) : /* @__PURE__ */ v("span", {
			className: "shallowsea-chip-type",
			children: e
		})
	});
}
function kt({ color: e, size: t }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "-0.4 -0.4 0.8 0.8",
		style: t ? {
			width: t,
			height: t
		} : void 0,
		className: "shallowsea-fish-chip",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("circle", {
				r: .36,
				fill: x[e],
				stroke: "#08252c",
				strokeWidth: .06
			}),
			/* @__PURE__ */ v("path", {
				d: "M-0.22,0 L-0.03,-0.12 L-0.03,0.12 Z",
				fill: "#fff"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: .07,
				cy: 0,
				rx: .15,
				ry: .09,
				fill: "#fff"
			})
		]
	});
}
function At({ pool: e, label: t, refreshLabel: n, cost: r, refreshDisabled: i, onRefresh: a, children: o }) {
	return /* @__PURE__ */ y("div", {
		className: "shallowsea-pool-row",
		"data-pool": e,
		role: "group",
		"aria-label": t,
		children: [
			/* @__PURE__ */ v("span", {
				className: "shallowsea-pool-label",
				"aria-hidden": !0,
				children: t
			}),
			o,
			/* @__PURE__ */ y("button", {
				type: "button",
				className: "shallowsea-refresh",
				"aria-label": n,
				disabled: i,
				onClick: a,
				children: [/* @__PURE__ */ v(u, {
					size: 13,
					"aria-hidden": !0
				}), /* @__PURE__ */ v("span", { children: r })]
			})
		]
	});
}
function jt({ pub: e, nameOf: t }) {
	let n = o(), r = $e[e.ecosystems.orange] ?? null, i = $e[e.ecosystems.blue] ?? null;
	return /* @__PURE__ */ y("div", {
		className: "shallowsea-scores",
		children: [/* @__PURE__ */ v("h2", {
			className: "shallowsea-scores-title",
			children: n("games.shallowsea.scoreTitle")
		}), /* @__PURE__ */ v("div", {
			className: "shallowsea-score-grid",
			children: e.players.map((a) => {
				let o = e.breakdown?.[a];
				return /* @__PURE__ */ y("div", {
					className: "shallowsea-score-card",
					children: [/* @__PURE__ */ y("div", {
						className: "shallowsea-score-head",
						children: [/* @__PURE__ */ v("span", {
							className: "truncate",
							children: t(a)
						}), /* @__PURE__ */ v("span", {
							className: "shallowsea-score-total font-mono tabular-nums",
							children: n("games.shallowsea.scoreShort", { n: e.scores?.[a] ?? o?.total ?? 0 })
						})]
					}), o && /* @__PURE__ */ y("ul", {
						className: "shallowsea-score-rows",
						children: [
							r && /* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n(r) }), /* @__PURE__ */ v("span", { children: o.orange })] }),
							i && /* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n(i) }), /* @__PURE__ */ v("span", { children: o.blue })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreCoral") }), /* @__PURE__ */ v("span", { children: o.coralVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreSealife") }), /* @__PURE__ */ v("span", { children: o.sealifeVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scorePartial") }), /* @__PURE__ */ v("span", { children: o.partialVp })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreVariety") }), /* @__PURE__ */ v("span", { children: o.variety })] }),
							/* @__PURE__ */ y("li", { children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreFish") }), /* @__PURE__ */ v("span", { children: o.fishBonus })] }),
							/* @__PURE__ */ y("li", {
								className: "is-total",
								children: [/* @__PURE__ */ v("span", { children: n("games.shallowsea.scoreTotal") }), /* @__PURE__ */ v("span", { children: o.total })]
							})
						]
					})]
				}, a);
			})
		})]
	});
}
//#endregion
//#region src/game/bot.ts
function Mt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Nt() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function Pt(e, t, n, r) {
	let i = r ? {
		...e.bubbles,
		[r.key]: r.color
	} : e.bubbles;
	return {
		cells: {
			...e.cells,
			[t]: n
		},
		bubbles: i
	};
}
function Ft(e, t) {
	let n = 0;
	for (let r of Object.keys(e.cells)) {
		let i = e.cells[r];
		if (!(i.kind !== "coral" || i.completed)) for (let a = 0; a < 6; a += 1) q(i, a) === t && e.bubbles[A(r, a).key] !== t && (n += 1);
	}
	return n;
}
function It(e, t) {
	let n = P[t];
	if (!n) return 0;
	let r = 0;
	for (let i of J(e)) for (let a = 0; a < 6; a += 1) {
		let o = {
			kind: "sealife",
			typeId: t,
			rot: a,
			completed: !1
		};
		r = Math.max(r, me(Pt(e, i, o), i, o, n));
	}
	return r;
}
function Lt(e, t, n) {
	let r = /* @__PURE__ */ new Set();
	for (let i of e.offsets ?? []) {
		let e = k(t, (i + n) % 6);
		e && r.add(e);
	}
	for (let i of e.dirs ?? []) {
		let e = t;
		for (;;) {
			let t = k(e, (i + n) % 6);
			if (!t) break;
			r.add(t), e = t;
		}
	}
	return r.size;
}
function Rt(e, t, n) {
	let r = 0, i = 0, a = 0;
	for (let o of J(e)) {
		let s = 0, c = 0, l = 0;
		for (let r = 0; r < 6; r += 1) {
			let i = q(t, r);
			if (!i) continue;
			l += 1;
			let { key: a } = A(o, r), u = e.bubbles[a];
			u === i ? s += 1 : !u && i === n && (c += 1);
		}
		l !== 0 && (s > r || s === r && c > i) && (r = s, i = c, a = l);
	}
	let o = a > 0 && r === a;
	return t.vp * .9 + r * 2 + i * 2.5 + (o ? 12 : 0);
}
var zt = (e, t) => {
	let n = e.public;
	if (n.phase === "done" || n.active !== t.rid) return null;
	let r = n.boards[t.rid];
	if (!r) return null;
	let i = t.difficulty === "weak";
	if (n.phase === "setup") {
		let e = [];
		n.pools.sealife.forEach((t, n) => {
			t && e.push({
				index: n,
				typeId: t
			});
		});
		let t = T.filter((e) => !r.cells[e.id]);
		if (e.length === 0 || t.length === 0) return null;
		let a = [];
		for (let n of e) {
			let e = P[n.typeId];
			for (let r of t) for (let t = 0; t < 6; t += 1) {
				let i = (e ? Lt(e, r.id, t) : 0) * 2 + (r.inner ? 3 : 0) + (e ? e.vp * .6 + e.partial : 0);
				a.push({
					action: {
						type: "setupPlace",
						index: n.index,
						cell: r.id,
						rot: t
					},
					score: i
				});
			}
		}
		if (i) return { action: Mt(a).action };
		for (let e of a) e.score += Nt();
		return a.sort((e, t) => t.score - e.score), { action: a[0].action };
	}
	if (n.phase === "select") {
		let e = [], a = [], o = n.pools, s = (e) => 2 + Ft(r, e) * 1.2;
		for (let t = 0; t < 5; t += 1) {
			let n = o.fish[t];
			if (!n) continue;
			let i = o.coral[t];
			if (i) {
				let r = s(n) + i.vp * .8 + 1;
				e.push({
					action: {
						type: "select",
						fish: t,
						tile: "coral"
					},
					score: r
				});
			}
			let a = o.sealife[t];
			if (a) {
				let i = P[a], o = It(r, a), c = s(n) + (i ? i.vp * (o / i.need) * 1.4 : 0) + (i && o >= i.need ? 10 : 0);
				e.push({
					action: {
						type: "select",
						fish: t,
						tile: "sealife"
					},
					score: c
				});
			}
		}
		if ((n.shells[t.rid] ?? 0) >= 2) for (let e = 0; e < 5; e += 1) {
			let t = o.fish[e];
			if (t) for (let n = 0; n < 5; n += 1) {
				let i = o.coral[n];
				i && a.push({
					action: {
						type: "selectAny",
						fish: e,
						tile: "coral",
						index: n
					},
					score: s(t) + i.vp * .8
				});
				let c = o.sealife[n];
				if (c) {
					let i = P[c], o = It(r, c);
					a.push({
						action: {
							type: "selectAny",
							fish: e,
							tile: "sealife",
							index: n
						},
						score: s(t) + (i ? i.vp * (o / i.need) * 1.4 : 0)
					});
				}
			}
		}
		let c = e.sort((e, t) => t.score - e.score)[0], l = a.sort((e, t) => t.score - e.score)[0];
		if (i) {
			let r = (n.shells[t.rid] ?? 0) >= 2 ? [...e, ...a] : e;
			return r.length === 0 ? null : { action: Mt(r).action };
		}
		if (l && (!c || l.score > c.score + 3)) return { action: l.action };
		if (c) return { action: c.action };
		for (let e of ["coral", "fish"]) {
			let t = e === "coral" ? o.coral : o.fish, n = /* @__PURE__ */ new Map();
			for (let r of t) {
				if (!r) continue;
				let t = e === "coral" ? r.color : r;
				n.set(t, (n.get(t) ?? 0) + 1);
			}
			if ([...n.values()].some((e) => e >= 4)) return { action: {
				type: "refresh",
				pool: e
			} };
		}
		return null;
	}
	let a = n.selection;
	if (!a) return null;
	if (n.phase === "tile") {
		let e = J(r);
		if (e.length === 0) return null;
		let t = [];
		for (let n of e) for (let e = 0; e < 6; e += 1) if (a.tileKind === "coral" && a.coral) {
			let i = {
				kind: "coral",
				color: a.coral.color,
				vp: a.coral.vp,
				edges: [...a.coral.edges],
				rot: e,
				completed: !1,
				lockedFish: null
			};
			t.push({
				action: {
					type: "placeTile",
					cell: n,
					rot: e
				},
				score: Rt(r, i, a.fish)
			});
		} else if (a.tileKind === "sealife" && a.sealife) {
			let i = P[a.sealife], o = {
				kind: "sealife",
				typeId: a.sealife,
				rot: e,
				completed: !1
			}, s = i ? me(Pt(r, n, o), n, o, i) : 0, c = i ? s >= i.need : !1;
			t.push({
				action: {
					type: "placeTile",
					cell: n,
					rot: e
				},
				score: s * 4 + (c && i ? i.vp + 12 : 0)
			});
		}
		if (t.length === 0) return null;
		if (i) return { action: Mt(t).action };
		for (let e of t) e.score += Nt();
		return t.sort((e, t) => t.score - e.score), { action: t[0].action };
	}
	if (n.phase === "fish") {
		let e = ce(r);
		if (e.length === 0) return null;
		let t = [];
		for (let n of e) {
			let e = Pt(r, n.cell, r.cells[n.cell], {
				key: n.key,
				color: a.fish
			}), i = 0, o = /* @__PURE__ */ new Set();
			for (let t of [n.cell, ...Bt(n.key)]) {
				if (o.has(t)) continue;
				o.add(t);
				let s = r.cells[t];
				if (s && s.kind === "coral" && !s.completed) {
					if (Y(e, t, s)) i += s.vp + 8;
					else for (let e = 0; e < 6; e += 1) q(s, e) === a.fish && A(t, e).key === n.key && (i += 2.5);
				}
			}
			for (let e of Bt(n.key)) {
				let t = r.cells[e];
				t && t.kind === "coral" && t.completed && (i += .8);
			}
			t.push({
				action: {
					type: "placeFish",
					cell: n.cell,
					dir: n.dir
				},
				score: i
			});
		}
		if (i) return { action: Mt(t).action };
		for (let e of t) e.score += Nt();
		return t.sort((e, t) => t.score - e.score), { action: t[0].action };
	}
	let o = t.memory ?? {};
	if (n.phase === "end") {
		if (!i && (n.shells[t.rid] ?? 0) >= 2 && o.movedTurn !== n.turnCount) for (let e of Object.keys(r.cells)) {
			let t = r.cells[e];
			if (t.kind !== "coral" || t.completed) continue;
			let i = null, a = !0;
			for (let n = 0; n < 6; n += 1) {
				let o = q(t, n);
				if (!o) continue;
				let s = r.bubbles[A(e, n).key];
				if (s !== o) {
					if (!s && !i) {
						i = {
							dir: n,
							color: o
						};
						continue;
					}
					a = !1;
					break;
				}
			}
			if (!a || !i) continue;
			let o = A(e, i.dir).key;
			for (let t of Object.keys(r.bubbles)) {
				if (t === o || r.bubbles[t] !== i.color) continue;
				let a = Bt(t);
				for (let r of a) for (let a = 0; a < 6; a += 1) if (A(r, a).key === t) return {
					action: {
						type: "moveFish",
						fromCell: r,
						fromDir: a,
						toCell: e,
						toDir: i.dir
					},
					memory: { movedTurn: n.turnCount }
				};
			}
		}
		return {
			action: { type: "endTurn" },
			memory: { movedTurn: o.movedTurn }
		};
	}
	return null;
};
function Bt(e) {
	return e.startsWith("B:") ? [e.split(":")[1]] : e.split("|");
}
//#endregion
//#region src/index.tsx
var Vt = {
	definition: Fe,
	View: tt,
	bot: zt,
	locales: {
		zh: {
			name: "浅海",
			desc: "为珊瑚礁搭配鱼群，完成珊瑚与海洋生物，终局比拼分值",
			rules: "目标:\n每名玩家各自经营一片海洋。通过不断放入珊瑚与海洋生物，配合鱼群完成它们，获得海螺并积累分值。所有玩家完成各自的回合后计分，总分最高者获胜。\n准备:\n· 每名玩家取一块海洋板。板面共 22 格，开局时全部留空，随后每人先放 1 张海洋生物。\n· 每名玩家拿取 2 枚海螺，海螺最多持有 5 枚。\n· 洗混珊瑚堆、海洋生物堆与鱼堆，分别抽出 5 张摆成珊瑚池、生物池与鱼池。三个池子按位置一一配对：第 1 条鱼与珊瑚池、生物池各自的第 1 张对应，依此类推。\n· 由系统随机决定先手，之后按座位顺序轮流行动。\n· 从末位玩家开始，每名玩家依次从生物池选取 1 张海洋生物，正面朝上放到自己板上的任意空格；放置时可以旋转。所有玩家都放好后，补满生物池，再由先手玩家开始第一个回合。\n回合:\n每回合依次完成三件事：选牌、放置、结算。\n· 选牌时，从鱼池取 1 条鱼，并从珊瑚池或生物池取与这条鱼位置相同的 1 张地块。鱼池第 n 条鱼只能搭配两个池子中第 n 张地块。\n· 也可以花费 1 枚海螺刷新任意一个池子，再照常选牌。珊瑚池中有至少 4 张同色珊瑚时，刷新珊瑚池免费；鱼池中有至少 4 条同色鱼时，刷新鱼池免费。\n· 花费 2 枚海螺可以无视配对，任取 1 条鱼与 1 张地块。\n· 放置时，地块可以任意旋转，但必须放在与已有地块相邻的空格上。随后把刚选的鱼放到一条空的边气泡上。地块的每条边就是一处气泡，相邻两块地共享同一条边上的气泡，每处气泡只能放 1 条鱼。\n· 放置完成后，检查因这次放置而满足条件的珊瑚与海洋生物，完成它们并获得海螺。\n珊瑚完成:\n· 珊瑚地块上印有若干条彩色边，彩色边的颜色表示它需要的鱼色。当每条彩色边所朝气泡上都放着对应颜色的鱼时，这块珊瑚完成。\n· 完成时把珊瑚翻面，并从满足条件的鱼中锁定 1 条放到珊瑚背面，这条鱼成为完成鱼，不再用于其他珊瑚。其余满足条件的鱼仍留在气泡上，仍属于未完成鱼。\n· 一次放鱼可能同时满足多块珊瑚。此时按格子顺序依次结算，先完成的珊瑚会锁定并取走一条鱼，其他珊瑚因此可能不再满足。\n海洋生物:\n· 海洋生物只统计已完成的珊瑚与完成鱼，满足条件即完成。\n· 每张海洋生物都印有指定的格位或方向，地块放置时通过旋转改变它观察的格位与方向。\n· 同色条件要求指定格或指定方向上的已完成珊瑚、完成鱼颜色相同；异色条件要求它们的颜色各不相同。\n· 方向条件沿箭头方向逐格计数，中间隔着不符合条件的格也不影响；两方向条件可以落在任意一侧，也可以合并两侧一起计数。\n· 本作首发使用 10 种海洋生物：A1 与 D1 要求指定 3 格为同色已完成珊瑚；A4 与 D4 要求指定 3 格为异色完成鱼；B1 要求两方向内 4 张同色已完成珊瑚；C2 要求指定 2 格为异色已完成珊瑚；C4 要求两方向内 2 条同色完成鱼；E1 要求单一方向内 3 张同色已完成珊瑚；E4 要求单一方向内 3 条异色完成鱼；F2 要求全板集齐四色已完成珊瑚。\n海洋生物图示:\n· 地块中央的深色徽记表示比较方式：绿色等号表示同色，红色不等号表示异色。\n· 地块边缘的圆形图标表示它观察的格位，带箭头的图标表示它沿该方向逐格观察。图标为单个蓝色珊瑚或蓝色鱼时要求同色，红色与蓝色图标并排时要求异色。\n· 徽记下方的数字表示完成所需的单元数。右下角深色圆圈中的数字是完成分值，左下角棕色星圈中的数字是每满足 1 个单元获得的部分分。\n· 全板条件以四色珊瑚图标表示，需要集齐红、黄、绿、紫四色的已完成珊瑚各 1 张。\n海螺:\n· 每完成 1 张珊瑚或海洋生物，获得 1 枚海螺，最多持有 5 枚。\n· 花费 1 枚海螺可以刷新一个池子；花费 2 枚海螺可以无视配对任选鱼与地块。\n· 花费 2 枚海螺可以移动自己板上 1 条未完成的鱼到另一处空边气泡。完成鱼不能移动；移动后触发的完成立即结算。\n结束与计分:\n· 每名玩家各完成 17 个回合后游戏结束。海洋板共 22 格，减去起始的 1 张生物与最后留空的 4 格，正好放置 17 张地块。\n· 先结算两张生态卡，再统计已完成珊瑚与已完成海洋生物的分值。\n· 未完成的海洋生物按已经满足的单元数获得部分分。\n· 每一种完成过的海洋生物额外获得 2 分。\n· 每条留在气泡上的未完成鱼，每相邻 1 张已完成珊瑚获得 1 分。\n· 总分最高者获胜。总分相同时，剩余海螺较多的玩家获胜；仍然相同则共享胜利。\n生态卡:\n开局固定使用 1 张橙色生态卡与 1 张蓝色生态卡，默认使用 O1 与 B1。对局中在设置里可以更换。\n· O1 保护色：背面放有同色完成鱼的已完成珊瑚，每张 2 分。\n· O2 珊瑚成对：同色已完成珊瑚每 2 张获得 3 分。\n· O3 潮汐交响：完成鱼数量最多的一种颜色，每条完成鱼 3 分，最多 18 分。\n· O4 错配：背面放有异色完成鱼的已完成珊瑚，每张 2 分。\n· O5 深层同调：某一横行中有至少 2 张同色已完成珊瑚时，该行获得 4 分。\n· O6 巨珊瑚礁：面积最大的一片相邻已完成珊瑚，每张 2 分。\n· O7 潮汐：某种颜色的完成鱼达到 3 条及以上时，该颜色获得 4 分。\n· B1 富饶深处：某一横行中有至少 2 张已完成海洋生物时，该行获得 4 分。\n· B2 丰饶洞穴：位于内圈的已完成海洋生物，每张 3 分。\n· B3 水下群落：与至少 1 张已完成海洋生物相邻的已完成海洋生物，每张 2 分。\n· B4 聚光灯：某一纵列恰好有 1 张已完成海洋生物时，该列获得 2 分。\n· B5 生物双联：每对相邻的已完成海洋生物获得 4 分，每张海洋生物最多计入一对。\n· B6 辉光洞穴：内圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。\n· B7 多样边界：外圈每出现一种不同的地块，获得 2 分。珊瑚按颜色区分，海洋生物按种类区分。",
			setupPrompt: "从生物池选 1 张，放到任意空格",
			setupWaiting: "等 {{name}} 放置起始海洋生物…",
			selectPrompt: "选 1 条鱼，再选同序号的地块",
			selectAnyMode: "自由搭配：先点鱼，再点地块",
			selectWaiting: "等 {{name}} 选牌…",
			waitingFor: "等 {{name}} 行动…",
			tilePrompt: "旋转地块，放到相邻的空格",
			fishPrompt: "把{{fish}}放到一条空边上",
			endPrompt: "结束回合，或移动一条鱼",
			movingFrom: "点选要移动的鱼",
			movingTo: "再点一条空边放下",
			doneBanner: "终局计分",
			coralPool: "珊瑚池",
			sealifePool: "生物池",
			fishPool: "鱼池",
			pairLabel: "第 {{n}} 组",
			refreshCoral: "刷新珊瑚池",
			refreshSealife: "刷新生物池",
			refreshFish: "刷新鱼池",
			refreshFree: "免费",
			refreshCost: "1 海螺",
			anyMode: "自由搭配",
			anyModeCost: "2 海螺",
			cancel: "取消",
			confirmPlace: "放这里",
			moveCost: "2 海螺",
			coralAria: "珊瑚，{{vp}} 分",
			poolEmpty: "空位",
			myBoard: "我的海洋",
			boardOf: "{{name}} 的海洋",
			shellsShort: "{{n}} 海螺",
			scoreShort: "{{n}} 分",
			emptyBubbleAria: "空的边气泡",
			fishAria: "{{fish}}",
			placeAria: "放到第 {{row}} 行第 {{col}} 列",
			rotateLeft: "向左旋转",
			rotateRight: "向右旋转",
			zoomControls: "盘面缩放",
			zoomIn: "放大",
			zoomOut: "缩小",
			fitBoard: "回到全板",
			ecoCards: "本局生态卡",
			ecoOrange: "橙色生态卡",
			ecoBlue: "蓝色生态卡",
			endTurn: "结束回合",
			moveFish: "移动鱼",
			cancelMove: "取消移动",
			activeBadge: "行动中",
			completedBadge: "已完成",
			fishRed: "红鱼",
			fishYellow: "黄鱼",
			fishGreen: "绿鱼",
			fishPurple: "紫鱼",
			slSameCoral3: "3 格同色珊瑚",
			slDiffFish3: "3 格异色完成鱼",
			slDirSameCoral4: "两方向 4 张同色珊瑚",
			slDiffCoral2: "2 格异色珊瑚",
			slDirSameFish2: "两方向 2 条同色完成鱼",
			slDirSameCoral3: "单方向 3 张同色珊瑚",
			slDirDiffFish3: "单方向 3 条异色完成鱼",
			slAnyAllCoral: "全板四色珊瑚各 1",
			sealifeAria: "{{id}}，{{desc}}",
			ecoO1: "保护色",
			ecoO2: "珊瑚成对",
			ecoO3: "潮汐交响",
			ecoO4: "错配",
			ecoO5: "深层同调",
			ecoO6: "巨珊瑚礁",
			ecoO7: "潮汐",
			ecoB1: "富饶深处",
			ecoB2: "丰饶洞穴",
			ecoB3: "水下群落",
			ecoB4: "聚光灯",
			ecoB5: "生物双联",
			ecoB6: "辉光洞穴",
			ecoB7: "多样边界",
			scoreTitle: "终局计分",
			scoreCoral: "已完成珊瑚",
			scoreSealife: "已完成海洋生物",
			scorePartial: "未完成生物部分分",
			scoreVariety: "生物种类",
			scoreFish: "未完成鱼",
			scoreTotal: "总分",
			errNotYourTurn: "现在轮不到你",
			errWrongPhase: "当前步骤不能这样操作",
			errAlreadySelected: "本回合已经选好牌了",
			errPoolEmpty: "这个池子没有可选的牌",
			errNoShell: "海螺不够",
			errNoSelection: "还没有选牌",
			errBadCell: "这格不能放",
			errBadBubble: "这条边不能放鱼"
		},
		en: {
			name: "Shallow Sea",
			desc: "Pair fish with tiles to complete corals and sea life, then compare scores",
			rules: "Goal:\nEach player tends their own sea. By placing corals and sea life and pairing them with fish, you complete them, earn shells, and build up points. After every player has taken all their turns, the highest score wins.\nSetup:\n· Each player takes one ocean board. The board has 22 spaces, all empty at the start; each player will first place 1 sea life tile on it.\n· Each player takes 2 shells. A player may hold at most 5 shells.\n· Shuffle the coral tiles, sea life tiles, and fish, then deal 5 of each into the coral pool, sea life pool, and fish pool. The pools are paired by position: the first fish pairs with the first coral and the first sea life, and so on.\n· The app randomly chooses the first player; play then proceeds in seat order.\n· Starting with the last player, each player in turn takes 1 sea life tile from the sea life pool and places it face up in any empty space on their own board; the tile may be rotated. Once every player has placed a tile, refill the sea life pool and the first player begins the first turn.\nTurn:\nEach turn is taken in three steps: choose, place, resolve.\n· When choosing, take 1 fish from the fish pool and 1 tile from either the coral pool or the sea life pool in the same position as that fish. The nth fish can only pair with the nth coral or the nth sea life.\n· You may instead spend 1 shell to refresh any one pool and then choose normally. Refreshing the coral pool is free when it holds at least 4 corals of one color, and refreshing the fish pool is free when it holds at least 4 fish of one color.\n· Spending 2 shells lets you ignore pairing and take any 1 fish with any 1 tile.\n· When placing, rotate the tile however you like, but it must go on an empty space adjacent to a tile already on your board. Then place the fish you chose on an empty edge bubble. Each edge of a tile is one bubble; two adjacent tiles share the bubble on their common edge, and each bubble holds only 1 fish.\n· After placing, check which corals and sea life are now satisfied by this placement, and complete them to earn shells.\nCorals:\n· Each coral tile shows several colored edges. A colored edge names the fish color it needs. The coral is completed when every colored edge has a fish of the matching color on the bubble it faces.\n· When a coral completes, flip it over and lock 1 of the satisfied fish onto its back. That fish becomes a completed fish and is no longer used by other corals. Any other satisfied fish stay on their bubbles and remain unfinished fish.\n· One fish may satisfy several corals at once. In that case they resolve in board order: the first coral to complete locks and removes a fish, so another coral may no longer be satisfied.\nSea life:\n· Sea life counts only completed corals and completed fish, and completes as soon as its condition is met.\n· Each sea life tile names specific spaces or directions; rotating the tile when placing changes which spaces or directions it looks at.\n· Same-color conditions require the completed corals or completed fish in the named spaces or directions to share one color. Different-color conditions require them to all differ.\n· Directional conditions count along the arrow, and a tile that does not match in between does not interrupt the count. Two-way conditions may count on either side or combine both sides.\n· This release uses 10 sea life types: A1 and D1 need same-color completed corals in 3 named spaces; A4 and D4 need different-color completed fish in 3 named spaces; B1 needs 4 same-color completed corals across its two directions; C2 needs different-color completed corals in 2 named spaces; C4 needs 2 same-color completed fish across its two directions; E1 needs 3 same-color completed corals in one direction; E4 needs 3 different-color completed fish in one direction; F2 needs completed corals of all four colors anywhere on the board.\nSea life icons:\n· The dark badge in the middle of a tile shows how colors are compared: a green equals sign means same color, and a red not-equals sign means different colors.\n· Round icons along the tile edges mark the spaces it observes, and an icon with an arrow marks a direction it observes space by space. A single blue coral or blue fish icon asks for one color; a red and a blue icon side by side ask for different colors.\n· The number under the badge is how many units are needed to complete the tile. The number in the dark circle at the lower right is the completion score, and the number in the brown star circle at the lower left is the partial score for each unit satisfied.\n· An anywhere-on-the-board condition is drawn with four colored coral icons and needs one completed coral of each of the four colors.\nShells:\n· Each completed coral or sea life earns 1 shell, up to a maximum of 5 shells.\n· Spending 1 shell refreshes one pool; spending 2 shells ignores pairing and lets you take any fish with any tile.\n· Spending 2 shells lets you move 1 unfinished fish on your own board to another empty edge bubble. Completed fish cannot be moved, and any completion triggered by the move resolves immediately.\nEnd and scoring:\n· The game ends after each player has taken 17 turns. A board has 22 spaces; after the 1 starting sea life and the 4 spaces left empty, exactly 17 tiles are placed.\n· Score the two ecosystem cards first, then the completed corals and completed sea life.\n· Unfinished sea life scores partial points for the units it has satisfied.\n· Each distinct type of completed sea life scores 2 bonus points.\n· Each unfinished fish still on a bubble scores 1 point for each completed coral adjacent to it.\n· The highest total wins. On a tie, the player with more shells remaining wins; if still tied, the players share the victory.\nEcosystem cards:\nEach game uses 1 orange and 1 blue ecosystem card, defaulting to O1 and B1. They can be changed in the setup options.\n· O1 Cryptic Coloration: each completed coral with a same-color completed fish on its back scores 2.\n· O2 Coral Duo: each pair of same-color completed corals scores 3.\n· O3 Symphony of the Tides: the color with the most completed fish scores 3 per fish, up to 18.\n· O4 Mismatched: each completed coral with a different-color completed fish on its back scores 2.\n· O5 Depths Alike: a row with at least 2 same-color completed corals scores 4.\n· O6 Colossal Coral Reef: the largest connected group of adjacent completed corals scores 2 per coral.\n· O7 Tides: each color with at least 3 completed fish scores 4.\n· B1 Rich Depths: a row with at least 2 completed sea life scores 4.\n· B2 Bountiful Caves: each completed sea life on an inner space scores 3.\n· B3 Underwater Community: each completed sea life adjacent to at least 1 completed sea life scores 2.\n· B4 Spotlight: a column with exactly 1 completed sea life scores 2.\n· B5 Sealife Duet: each pair of adjacent completed sea life scores 4, and each sea life may count in at most one pair.\n· B6 Radiant Caves: each distinct tile in the inner spaces scores 2. Corals count by color and sea life by type.\n· B7 Borders of Diversity: each distinct tile on the outer ring scores 2. Corals count by color and sea life by type.",
			setupPrompt: "Pick 1 tile from the sea life pool and place it on any empty space",
			setupWaiting: "Waiting for {{name}} to place a starting sea life tile…",
			selectPrompt: "Pick 1 fish, then a tile in the same slot",
			selectAnyMode: "Free pairing: pick a fish, then a tile",
			selectWaiting: "Waiting for {{name}} to choose…",
			waitingFor: "Waiting for {{name}}…",
			tilePrompt: "Rotate the tile and place it on an adjacent space",
			fishPrompt: "Place the {{fish}} on an empty edge",
			endPrompt: "End your turn, or move a fish",
			movingFrom: "Pick the fish to move",
			movingTo: "Pick an empty edge for it",
			doneBanner: "Final scoring",
			coralPool: "Coral pool",
			sealifePool: "Sea life pool",
			fishPool: "Fish pool",
			pairLabel: "Slot {{n}}",
			refreshCoral: "Refresh coral pool",
			refreshSealife: "Refresh sea life pool",
			refreshFish: "Refresh fish pool",
			refreshFree: "Free",
			refreshCost: "1 shell",
			anyMode: "Free pairing",
			anyModeCost: "2 shells",
			cancel: "Cancel",
			confirmPlace: "Place here",
			moveCost: "2 shells",
			coralAria: "Coral, {{vp}} points",
			poolEmpty: "Empty slot",
			myBoard: "My sea",
			boardOf: "{{name}}'s sea",
			shellsShort: "{{n}} shells",
			scoreShort: "{{n}} pts",
			emptyBubbleAria: "Empty edge bubble",
			fishAria: "{{fish}}",
			placeAria: "Place at row {{row}}, column {{col}}",
			rotateLeft: "Rotate left",
			rotateRight: "Rotate right",
			zoomControls: "Board zoom",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fitBoard: "Fit board",
			ecoCards: "Ecosystem cards",
			ecoOrange: "Orange card",
			ecoBlue: "Blue card",
			endTurn: "End turn",
			moveFish: "Move fish",
			cancelMove: "Cancel move",
			activeBadge: "Acting",
			completedBadge: "Completed",
			fishRed: "red fish",
			fishYellow: "yellow fish",
			fishGreen: "green fish",
			fishPurple: "purple fish",
			slSameCoral3: "3 spaces, same-color corals",
			slDiffFish3: "3 spaces, different-color fish",
			slDirSameCoral4: "two ways, 4 same-color corals",
			slDiffCoral2: "2 spaces, different-color corals",
			slDirSameFish2: "two ways, 2 same-color fish",
			slDirSameCoral3: "one way, 3 same-color corals",
			slDirDiffFish3: "one way, 3 different-color fish",
			slAnyAllCoral: "all four coral colors",
			sealifeAria: "{{id}}, {{desc}}",
			ecoO1: "Cryptic Coloration",
			ecoO2: "Coral Duo",
			ecoO3: "Symphony of the Tides",
			ecoO4: "Mismatched",
			ecoO5: "Depths Alike",
			ecoO6: "Colossal Coral Reef",
			ecoO7: "Tides",
			ecoB1: "Rich Depths",
			ecoB2: "Bountiful Caves",
			ecoB3: "Underwater Community",
			ecoB4: "Spotlight",
			ecoB5: "Sealife Duet",
			ecoB6: "Radiant Caves",
			ecoB7: "Borders of Diversity",
			scoreTitle: "Final scoring",
			scoreCoral: "Completed corals",
			scoreSealife: "Completed sea life",
			scorePartial: "Partial sea life",
			scoreVariety: "Sea life types",
			scoreFish: "Unfinished fish",
			scoreTotal: "Total",
			errNotYourTurn: "It is not your turn",
			errWrongPhase: "This action is not allowed right now",
			errAlreadySelected: "You already chose this turn",
			errPoolEmpty: "That pool has nothing to take",
			errNoShell: "Not enough shells",
			errNoSelection: "Choose a fish and tile first",
			errBadCell: "That space is not available",
			errBadBubble: "That edge is not available"
		}
	}
};
//#endregion
export { Vt as default };
