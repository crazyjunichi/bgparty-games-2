import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useMemo as n, useState as r } from "react";
import { GameScreen as i } from "@bgparty/sdk/ui/game-screen";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { seatName as c } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as l } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Confetti as m } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/game/schema.ts
var _ = t.enum([
	"grass",
	"desert",
	"mountain",
	"sea"
]), v = t.enum([
	"avenia",
	"aghon",
	"kazan",
	"cnidaria"
]), y = t.object({
	map: v.default("avenia"),
	solo: t.boolean().default(!1)
}).prefault({}), b = t.object({
	c: t.int().min(0).max(30),
	r: t.int().min(0).max(30)
}), x = t.object({
	kind: t.enum([
		"pool",
		"line",
		"path",
		"anchorAdj",
		"anchorLine",
		"seaThenCoin",
		"seaThenCity",
		"twoVillageLine"
	]),
	allow: t.array(_),
	max: t.number(),
	perTerrain: t.record(t.string(), t.number()).optional(),
	coinMult: t.number().optional(),
	coinTerrains: t.array(_).optional(),
	region: t.boolean().optional(),
	extraTreasurePerRuin: t.boolean().optional(),
	anchor: _.optional(),
	seaMax: t.number().optional(),
	coinMax: t.number().optional()
}), ee = t.object({
	kind: t.enum([
		"explorer",
		"coins",
		"vase",
		"village_terrain",
		"per_settlements",
		"per_towers"
	]),
	terrain: _.optional(),
	per: t.int().optional()
}), te = t.object({
	rid: t.string(),
	coins: t.int().nonnegative(),
	marks: t.record(t.string(), t.enum([
		"explorer",
		"village",
		"tower"
	])),
	posts: t.record(t.string(), _),
	looted: t.array(t.string()),
	crystals: t.array(t.string()),
	crystalSum: t.int().nonnegative(),
	treasures: t.array(ee),
	investigate: t.array(t.int().nullable()).length(3),
	goals: t.array(t.int()),
	explored: t.array(t.string()),
	bestRoute: t.int().nonnegative()
}), S = t.object({
	id: t.string(),
	map: v,
	high: t.int(),
	low: t.int(),
	completedBy: t.array(t.string()),
	firstTurn: t.int().nullable()
}), ne = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("investigate"),
		rid: t.string(),
		options: t.array(t.int()).length(2),
		slot: t.int()
	}),
	t.object({
		kind: t.literal("useInvestigate"),
		rid: t.string(),
		options: t.array(t.int()).length(3)
	}),
	t.object({
		kind: t.literal("village"),
		rid: t.string(),
		region: t.array(t.string()),
		cells: t.array(t.string())
	}),
	t.object({
		kind: t.literal("post"),
		rid: t.string(),
		cities: t.array(t.string()).length(2)
	}),
	t.object({
		kind: t.literal("treasureExplorer"),
		rid: t.string()
	})
]), re = t.object({
	rid: t.string(),
	spec: x,
	placed: t.array(t.string()),
	counts: t.record(_, t.number()),
	mode: t.enum([
		"main",
		"coin",
		"city"
	]),
	anchorCell: t.string().nullable(),
	ended: t.boolean()
}), C = t.object({
	map: v,
	solo: t.boolean(),
	phase: t.enum([
		"turn",
		"decide",
		"eraEnd",
		"done"
	]),
	era: t.int().min(1).max(4),
	round: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	investigateCount: t.int().nonnegative(),
	card: t.int(),
	actor: t.string().nullable(),
	turnNo: t.int(),
	players: t.array(te),
	goals: t.array(S),
	pending: ne.nullable(),
	cur: re.nullable(),
	last: t.object({
		rid: t.string(),
		cells: t.array(t.string()),
		kind: t.enum([
			"explore",
			"village",
			"tower",
			"post",
			"treasure",
			"goal",
			"era"
		]),
		serial: t.int()
	}).nullable()
}), w = t.object({}), T = {
	type: t.literal("decide"),
	card: t.int().optional(),
	cell: b.optional()
}, ie = t.union([
	t.object({
		type: t.literal("place"),
		cell: b
	}),
	t.object({ type: t.literal("endExplore") }),
	t.object({
		...T,
		choice: t.enum([
			"investigate",
			"useInvestigate",
			"village",
			"post",
			"treasureExplorer"
		])
	})
]), ae = {
	id: "guildofmerchantexplorers",
	uuid: "a7c1f3d2-5b64-4e19-9c2a-3f8e1b6d4c07",
	tier: "alpha",
	mechanics: [
		"roll-and-write",
		"route-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.guildofmerchantexplorers.name",
	descKey: "games.guildofmerchantexplorers.desc",
	rulesKey: "games.guildofmerchantexplorers.rules",
	icon: "⛵",
	iconImg: "games/guildofmerchantexplorers.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#8a6d3b",
	releasedAt: "2026-11-22T23:30:00+08:00",
	search: {
		py: "ti ge mei gong hui",
		init: "tgmgh"
	},
	hotseat: "open",
	botDelayMs: 360
}, E = {
	avenia: [
		{
			c: 2,
			r: 6,
			terrain: "mountain",
			city: 3
		},
		{
			c: 2,
			r: 7,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 8,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 9,
			terrain: "mountain"
		},
		{
			c: 3,
			r: 1,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 3,
			r: 2,
			terrain: "sea"
		},
		{
			c: 3,
			r: 3,
			terrain: "sea"
		},
		{
			c: 3,
			r: 4,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 3,
			r: 5,
			terrain: "sea"
		},
		{
			c: 3,
			r: 6,
			terrain: "grass"
		},
		{
			c: 3,
			r: 7,
			terrain: "grass"
		},
		{
			c: 3,
			r: 8,
			terrain: "desert",
			coins: 1
		},
		{
			c: 3,
			r: 9,
			terrain: "grass"
		},
		{
			c: 3,
			r: 10,
			terrain: "grass"
		},
		{
			c: 4,
			r: 1,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 4,
			r: 2,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 4,
			r: 3,
			terrain: "grass"
		},
		{
			c: 4,
			r: 4,
			terrain: "sea"
		},
		{
			c: 4,
			r: 5,
			terrain: "sea"
		},
		{
			c: 4,
			r: 6,
			terrain: "sea"
		},
		{
			c: 4,
			r: 7,
			terrain: "grass",
			coins: 2
		},
		{
			c: 4,
			r: 8,
			terrain: "desert"
		},
		{
			c: 4,
			r: 9,
			terrain: "desert"
		},
		{
			c: 4,
			r: 10,
			terrain: "grass",
			coins: 1
		},
		{
			c: 4,
			r: 11,
			terrain: "grass",
			discovery: !0
		},
		{
			c: 5,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 5,
			r: 2,
			terrain: "mountain"
		},
		{
			c: 5,
			r: 3,
			terrain: "grass"
		},
		{
			c: 5,
			r: 4,
			terrain: "sea"
		},
		{
			c: 5,
			r: 5,
			terrain: "sea"
		},
		{
			c: 5,
			r: 6,
			terrain: "sea"
		},
		{
			c: 5,
			r: 7,
			terrain: "sea"
		},
		{
			c: 5,
			r: 8,
			terrain: "sea"
		},
		{
			c: 5,
			r: 9,
			terrain: "mountain"
		},
		{
			c: 5,
			r: 10,
			terrain: "grass",
			coins: 1
		},
		{
			c: 6,
			r: 1,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 6,
			r: 2,
			terrain: "mountain"
		},
		{
			c: 6,
			r: 3,
			terrain: "grass",
			city: 3
		},
		{
			c: 6,
			r: 4,
			terrain: "sea"
		},
		{
			c: 6,
			r: 5,
			terrain: "sea"
		},
		{
			c: 6,
			r: 6,
			terrain: "sea"
		},
		{
			c: 6,
			r: 7,
			terrain: "desert"
		},
		{
			c: 6,
			r: 8,
			terrain: "sea"
		},
		{
			c: 6,
			r: 9,
			terrain: "sea"
		},
		{
			c: 6,
			r: 10,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 6,
			r: 11,
			terrain: "grass",
			city: 3
		},
		{
			c: 7,
			r: 1,
			terrain: "sea"
		},
		{
			c: 7,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 7,
			r: 3,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 7,
			r: 4,
			terrain: "sea"
		},
		{
			c: 7,
			r: 5,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 7,
			r: 6,
			terrain: "sea"
		},
		{
			c: 7,
			r: 7,
			terrain: "sea"
		},
		{
			c: 7,
			r: 8,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 7,
			r: 9,
			terrain: "sea"
		},
		{
			c: 7,
			r: 10,
			terrain: "grass"
		},
		{
			c: 7,
			r: 12,
			terrain: "sea"
		},
		{
			c: 8,
			r: 1,
			terrain: "sea"
		},
		{
			c: 8,
			r: 2,
			terrain: "grass"
		},
		{
			c: 8,
			r: 3,
			terrain: "sea"
		},
		{
			c: 8,
			r: 4,
			terrain: "desert"
		},
		{
			c: 8,
			r: 5,
			terrain: "sea"
		},
		{
			c: 8,
			r: 6,
			terrain: "sea"
		},
		{
			c: 8,
			r: 7,
			terrain: "mountain"
		},
		{
			c: 8,
			r: 8,
			terrain: "mountain"
		},
		{
			c: 8,
			r: 9,
			terrain: "sea"
		},
		{
			c: 8,
			r: 10,
			terrain: "sea"
		},
		{
			c: 8,
			r: 11,
			terrain: "sea"
		},
		{
			c: 8,
			r: 12,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 9,
			r: 1,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 9,
			r: 2,
			terrain: "sea"
		},
		{
			c: 9,
			r: 3,
			terrain: "desert",
			city: 3
		},
		{
			c: 9,
			r: 4,
			terrain: "desert"
		},
		{
			c: 9,
			r: 5,
			terrain: "sea"
		},
		{
			c: 9,
			r: 6,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 9,
			r: 7,
			terrain: "grass"
		},
		{
			c: 9,
			r: 8,
			terrain: "sea"
		},
		{
			c: 9,
			r: 9,
			terrain: "desert",
			ruin: "land"
		},
		{
			c: 9,
			r: 10,
			terrain: "sea"
		},
		{
			c: 9,
			r: 11,
			terrain: "sea"
		},
		{
			c: 9,
			r: 12,
			terrain: "sea"
		},
		{
			c: 10,
			r: 1,
			terrain: "grass",
			coins: 2
		},
		{
			c: 10,
			r: 2,
			terrain: "sea"
		},
		{
			c: 10,
			r: 3,
			terrain: "desert"
		},
		{
			c: 10,
			r: 4,
			terrain: "sea"
		},
		{
			c: 10,
			r: 5,
			terrain: "sea"
		},
		{
			c: 10,
			r: 6,
			terrain: "sea",
			capital: !0
		},
		{
			c: 10,
			r: 7,
			terrain: "grass",
			coins: 1
		},
		{
			c: 10,
			r: 8,
			terrain: "grass",
			city: 2
		},
		{
			c: 10,
			r: 9,
			terrain: "desert"
		},
		{
			c: 10,
			r: 10,
			terrain: "sea"
		},
		{
			c: 10,
			r: 11,
			terrain: "desert"
		},
		{
			c: 10,
			r: 12,
			terrain: "desert",
			coins: 2
		},
		{
			c: 11,
			r: 0,
			terrain: "desert",
			coins: 2
		},
		{
			c: 11,
			r: 1,
			terrain: "desert"
		},
		{
			c: 11,
			r: 2,
			terrain: "sea"
		},
		{
			c: 11,
			r: 3,
			terrain: "sea"
		},
		{
			c: 11,
			r: 4,
			terrain: "desert"
		},
		{
			c: 11,
			r: 5,
			terrain: "desert"
		},
		{
			c: 11,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 11,
			r: 7,
			terrain: "grass"
		},
		{
			c: 11,
			r: 8,
			terrain: "sea"
		},
		{
			c: 11,
			r: 9,
			terrain: "sea"
		},
		{
			c: 11,
			r: 10,
			terrain: "sea"
		},
		{
			c: 11,
			r: 11,
			terrain: "desert"
		},
		{
			c: 11,
			r: 12,
			terrain: "desert"
		},
		{
			c: 12,
			r: 1,
			terrain: "desert"
		},
		{
			c: 12,
			r: 2,
			terrain: "grass"
		},
		{
			c: 12,
			r: 3,
			terrain: "sea"
		},
		{
			c: 12,
			r: 4,
			terrain: "sea"
		},
		{
			c: 12,
			r: 5,
			terrain: "desert",
			coins: 1
		},
		{
			c: 12,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 12,
			r: 7,
			terrain: "grass",
			coins: 1
		},
		{
			c: 12,
			r: 8,
			terrain: "desert"
		},
		{
			c: 12,
			r: 9,
			terrain: "sea"
		},
		{
			c: 12,
			r: 10,
			terrain: "grass"
		},
		{
			c: 12,
			r: 11,
			terrain: "mountain"
		},
		{
			c: 12,
			r: 12,
			terrain: "mountain",
			city: 4
		},
		{
			c: 13,
			r: 1,
			terrain: "desert",
			city: 3
		},
		{
			c: 13,
			r: 2,
			terrain: "grass"
		},
		{
			c: 13,
			r: 3,
			terrain: "sea"
		},
		{
			c: 13,
			r: 4,
			terrain: "grass",
			city: 2
		},
		{
			c: 13,
			r: 5,
			terrain: "grass"
		},
		{
			c: 13,
			r: 6,
			terrain: "grass"
		},
		{
			c: 13,
			r: 7,
			terrain: "grass"
		},
		{
			c: 13,
			r: 8,
			terrain: "sea"
		},
		{
			c: 13,
			r: 9,
			terrain: "desert",
			coins: 1
		},
		{
			c: 13,
			r: 10,
			terrain: "grass"
		},
		{
			c: 13,
			r: 11,
			terrain: "desert",
			coins: 1
		},
		{
			c: 13,
			r: 12,
			terrain: "desert"
		},
		{
			c: 14,
			r: 1,
			terrain: "desert"
		},
		{
			c: 14,
			r: 2,
			terrain: "desert"
		},
		{
			c: 14,
			r: 3,
			terrain: "sea"
		},
		{
			c: 14,
			r: 4,
			terrain: "sea"
		},
		{
			c: 14,
			r: 5,
			terrain: "grass"
		},
		{
			c: 14,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 14,
			r: 7,
			terrain: "mountain"
		},
		{
			c: 14,
			r: 8,
			terrain: "sea"
		},
		{
			c: 14,
			r: 9,
			terrain: "grass"
		},
		{
			c: 14,
			r: 10,
			terrain: "grass",
			coins: 1
		},
		{
			c: 14,
			r: 11,
			terrain: "sea"
		},
		{
			c: 14,
			r: 12,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 15,
			r: 1,
			terrain: "desert",
			coins: 1
		},
		{
			c: 15,
			r: 2,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 15,
			r: 3,
			terrain: "sea"
		},
		{
			c: 15,
			r: 4,
			terrain: "sea"
		},
		{
			c: 15,
			r: 5,
			terrain: "sea"
		},
		{
			c: 15,
			r: 6,
			terrain: "sea"
		},
		{
			c: 15,
			r: 7,
			terrain: "sea"
		},
		{
			c: 15,
			r: 8,
			terrain: "sea"
		},
		{
			c: 15,
			r: 9,
			terrain: "grass"
		},
		{
			c: 15,
			r: 10,
			terrain: "sea"
		},
		{
			c: 15,
			r: 11,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 16,
			r: 1,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 2,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 16,
			r: 3,
			terrain: "desert"
		},
		{
			c: 16,
			r: 4,
			terrain: "sea"
		},
		{
			c: 16,
			r: 5,
			terrain: "desert"
		},
		{
			c: 16,
			r: 6,
			terrain: "sea"
		},
		{
			c: 16,
			r: 7,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 16,
			r: 8,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 16,
			r: 9,
			terrain: "desert",
			ruin: "land"
		},
		{
			c: 16,
			r: 10,
			terrain: "desert"
		},
		{
			c: 16,
			r: 11,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 17,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 17,
			r: 2,
			terrain: "desert"
		},
		{
			c: 17,
			r: 3,
			terrain: "sea"
		},
		{
			c: 17,
			r: 4,
			terrain: "desert",
			coins: 1
		},
		{
			c: 17,
			r: 5,
			terrain: "desert"
		},
		{
			c: 17,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 17,
			r: 7,
			terrain: "grass",
			coins: 1
		},
		{
			c: 17,
			r: 8,
			terrain: "grass"
		},
		{
			c: 17,
			r: 9,
			terrain: "grass",
			coins: 2
		},
		{
			c: 17,
			r: 10,
			terrain: "desert",
			coins: 1
		},
		{
			c: 18,
			r: 1,
			terrain: "grass"
		},
		{
			c: 18,
			r: 2,
			terrain: "grass",
			city: 3
		},
		{
			c: 18,
			r: 3,
			terrain: "sea"
		},
		{
			c: 18,
			r: 4,
			terrain: "sea"
		},
		{
			c: 18,
			r: 5,
			terrain: "desert"
		},
		{
			c: 18,
			r: 6,
			terrain: "grass"
		},
		{
			c: 18,
			r: 7,
			terrain: "grass",
			city: 3
		},
		{
			c: 18,
			r: 8,
			terrain: "grass"
		},
		{
			c: 18,
			r: 9,
			terrain: "desert"
		},
		{
			c: 18,
			r: 10,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 19,
			r: 0,
			terrain: "grass",
			discovery: !0
		},
		{
			c: 19,
			r: 1,
			terrain: "grass",
			coins: 2
		},
		{
			c: 19,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 19,
			r: 3,
			terrain: "grass"
		},
		{
			c: 19,
			r: 4,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 19,
			r: 5,
			terrain: "desert",
			coins: 1
		},
		{
			c: 19,
			r: 6,
			terrain: "grass",
			coins: 1
		},
		{
			c: 19,
			r: 7,
			terrain: "grass"
		},
		{
			c: 19,
			r: 8,
			terrain: "mountain"
		},
		{
			c: 19,
			r: 9,
			terrain: "mountain",
			coins: 1
		}
	],
	aghon: [
		{
			c: 3,
			r: 0,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 10,
			r: 0,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 17,
			r: 0,
			terrain: "mountain",
			discovery: !0
		},
		{
			c: 3,
			r: 1,
			terrain: "desert"
		},
		{
			c: 5,
			r: 1,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 6,
			r: 1,
			terrain: "sea"
		},
		{
			c: 7,
			r: 1,
			terrain: "grass",
			coins: 1
		},
		{
			c: 8,
			r: 1,
			terrain: "grass",
			coins: 2
		},
		{
			c: 9,
			r: 1,
			terrain: "sea"
		},
		{
			c: 10,
			r: 1,
			terrain: "desert"
		},
		{
			c: 11,
			r: 1,
			terrain: "desert"
		},
		{
			c: 12,
			r: 1,
			terrain: "desert",
			city: 2
		},
		{
			c: 13,
			r: 1,
			terrain: "desert"
		},
		{
			c: 14,
			r: 1,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 15,
			r: 1,
			terrain: "grass",
			coins: 1
		},
		{
			c: 17,
			r: 1,
			terrain: "desert"
		},
		{
			c: 3,
			r: 2,
			terrain: "desert"
		},
		{
			c: 4,
			r: 2,
			terrain: "desert",
			coins: 1
		},
		{
			c: 5,
			r: 2,
			terrain: "desert",
			city: 3
		},
		{
			c: 6,
			r: 2,
			terrain: "sea"
		},
		{
			c: 7,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 8,
			r: 2,
			terrain: "grass",
			city: 2
		},
		{
			c: 9,
			r: 2,
			terrain: "sea"
		},
		{
			c: 10,
			r: 2,
			terrain: "desert",
			coins: 1
		},
		{
			c: 11,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 12,
			r: 2,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 13,
			r: 2,
			terrain: "mountain"
		},
		{
			c: 14,
			r: 2,
			terrain: "sea"
		},
		{
			c: 15,
			r: 2,
			terrain: "sea"
		},
		{
			c: 16,
			r: 2,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 17,
			r: 2,
			terrain: "grass",
			coins: 2
		},
		{
			c: 1,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 3,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 4,
			r: 3,
			terrain: "sea"
		},
		{
			c: 5,
			r: 3,
			terrain: "desert",
			coins: 1
		},
		{
			c: 6,
			r: 3,
			terrain: "sea"
		},
		{
			c: 7,
			r: 3,
			terrain: "sea"
		},
		{
			c: 8,
			r: 3,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 9,
			r: 3,
			terrain: "sea"
		},
		{
			c: 10,
			r: 3,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 11,
			r: 3,
			terrain: "grass"
		},
		{
			c: 12,
			r: 3,
			terrain: "grass"
		},
		{
			c: 13,
			r: 3,
			terrain: "grass",
			city: 3
		},
		{
			c: 14,
			r: 3,
			terrain: "sea"
		},
		{
			c: 15,
			r: 3,
			terrain: "sea"
		},
		{
			c: 16,
			r: 3,
			terrain: "sea"
		},
		{
			c: 17,
			r: 3,
			terrain: "desert"
		},
		{
			c: 18,
			r: 3,
			terrain: "desert",
			coins: 1
		},
		{
			c: 19,
			r: 3,
			terrain: "desert"
		},
		{
			c: 2,
			r: 4,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 3,
			r: 4,
			terrain: "sea"
		},
		{
			c: 4,
			r: 4,
			terrain: "sea"
		},
		{
			c: 5,
			r: 4,
			terrain: "sea"
		},
		{
			c: 6,
			r: 4,
			terrain: "sea"
		},
		{
			c: 7,
			r: 4,
			terrain: "sea"
		},
		{
			c: 8,
			r: 4,
			terrain: "sea"
		},
		{
			c: 9,
			r: 4,
			terrain: "desert"
		},
		{
			c: 10,
			r: 4,
			terrain: "mountain"
		},
		{
			c: 11,
			r: 4,
			terrain: "mountain"
		},
		{
			c: 12,
			r: 4,
			terrain: "sea"
		},
		{
			c: 13,
			r: 4,
			terrain: "sea",
			coins: 1
		},
		{
			c: 14,
			r: 4,
			terrain: "sea"
		},
		{
			c: 15,
			r: 4,
			terrain: "desert",
			coins: 1
		},
		{
			c: 16,
			r: 4,
			terrain: "sea",
			coins: 1
		},
		{
			c: 17,
			r: 4,
			terrain: "mountain",
			city: 4
		},
		{
			c: 18,
			r: 4,
			terrain: "mountain"
		},
		{
			c: 1,
			r: 5,
			terrain: "desert"
		},
		{
			c: 2,
			r: 5,
			terrain: "sea"
		},
		{
			c: 3,
			r: 5,
			terrain: "sea"
		},
		{
			c: 4,
			r: 5,
			terrain: "sea"
		},
		{
			c: 5,
			r: 5,
			terrain: "sea"
		},
		{
			c: 6,
			r: 5,
			terrain: "sea"
		},
		{
			c: 7,
			r: 5,
			terrain: "sea"
		},
		{
			c: 8,
			r: 5,
			terrain: "sea"
		},
		{
			c: 9,
			r: 5,
			terrain: "desert"
		},
		{
			c: 10,
			r: 5,
			terrain: "desert",
			capital: !0
		},
		{
			c: 11,
			r: 5,
			terrain: "grass",
			coins: 1
		},
		{
			c: 12,
			r: 5,
			terrain: "grass"
		},
		{
			c: 13,
			r: 5,
			terrain: "sea"
		},
		{
			c: 14,
			r: 5,
			terrain: "sea"
		},
		{
			c: 15,
			r: 5,
			terrain: "desert"
		},
		{
			c: 16,
			r: 5,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 17,
			r: 5,
			terrain: "grass",
			coins: 1
		},
		{
			c: 18,
			r: 5,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 19,
			r: 5,
			terrain: "desert"
		},
		{
			c: 1,
			r: 6,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 2,
			r: 6,
			terrain: "grass",
			coins: 2
		},
		{
			c: 3,
			r: 6,
			terrain: "sea"
		},
		{
			c: 4,
			r: 6,
			terrain: "sea"
		},
		{
			c: 5,
			r: 6,
			terrain: "desert"
		},
		{
			c: 6,
			r: 6,
			terrain: "desert",
			city: 2
		},
		{
			c: 7,
			r: 6,
			terrain: "sea"
		},
		{
			c: 8,
			r: 6,
			terrain: "sea"
		},
		{
			c: 9,
			r: 6,
			terrain: "sea"
		},
		{
			c: 10,
			r: 6,
			terrain: "sea"
		},
		{
			c: 11,
			r: 6,
			terrain: "sea"
		},
		{
			c: 12,
			r: 6,
			terrain: "grass"
		},
		{
			c: 13,
			r: 6,
			terrain: "sea"
		},
		{
			c: 14,
			r: 6,
			terrain: "sea"
		},
		{
			c: 15,
			r: 6,
			terrain: "sea"
		},
		{
			c: 16,
			r: 6,
			terrain: "sea"
		},
		{
			c: 17,
			r: 6,
			terrain: "desert"
		},
		{
			c: 18,
			r: 6,
			terrain: "desert"
		},
		{
			c: 19,
			r: 6,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 1,
			r: 7,
			terrain: "desert"
		},
		{
			c: 2,
			r: 7,
			terrain: "sea"
		},
		{
			c: 3,
			r: 7,
			terrain: "sea",
			coins: 1
		},
		{
			c: 4,
			r: 7,
			terrain: "sea"
		},
		{
			c: 5,
			r: 7,
			terrain: "sea"
		},
		{
			c: 6,
			r: 7,
			terrain: "sea"
		},
		{
			c: 7,
			r: 7,
			terrain: "sea"
		},
		{
			c: 8,
			r: 7,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 9,
			r: 7,
			terrain: "sea"
		},
		{
			c: 10,
			r: 7,
			terrain: "sea"
		},
		{
			c: 11,
			r: 7,
			terrain: "sea"
		},
		{
			c: 12,
			r: 7,
			terrain: "sea"
		},
		{
			c: 13,
			r: 7,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 14,
			r: 7,
			terrain: "mountain"
		},
		{
			c: 15,
			r: 7,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 16,
			r: 7,
			terrain: "sea"
		},
		{
			c: 17,
			r: 7,
			terrain: "sea"
		},
		{
			c: 18,
			r: 7,
			terrain: "desert"
		},
		{
			c: 19,
			r: 7,
			terrain: "desert"
		},
		{
			c: 2,
			r: 8,
			terrain: "mountain",
			city: 4
		},
		{
			c: 3,
			r: 8,
			terrain: "mountain"
		},
		{
			c: 4,
			r: 8,
			terrain: "sea"
		},
		{
			c: 5,
			r: 8,
			terrain: "sea",
			coins: 1
		},
		{
			c: 6,
			r: 8,
			terrain: "sea"
		},
		{
			c: 7,
			r: 8,
			terrain: "grass"
		},
		{
			c: 8,
			r: 8,
			terrain: "sea"
		},
		{
			c: 9,
			r: 8,
			terrain: "desert",
			coins: 1
		},
		{
			c: 10,
			r: 8,
			terrain: "sea"
		},
		{
			c: 11,
			r: 8,
			terrain: "desert",
			coins: 1
		},
		{
			c: 12,
			r: 8,
			terrain: "sea"
		},
		{
			c: 13,
			r: 8,
			terrain: "sea"
		},
		{
			c: 14,
			r: 8,
			terrain: "mountain"
		},
		{
			c: 15,
			r: 8,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 8,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 17,
			r: 8,
			terrain: "sea"
		},
		{
			c: 18,
			r: 8,
			terrain: "sea"
		},
		{
			c: 3,
			r: 9,
			terrain: "grass",
			discovery: !0
		},
		{
			c: 4,
			r: 9,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 5,
			r: 9,
			terrain: "grass"
		},
		{
			c: 6,
			r: 9,
			terrain: "sea",
			ruin: "sea"
		},
		{
			c: 7,
			r: 9,
			terrain: "grass",
			city: 2
		},
		{
			c: 8,
			r: 9,
			terrain: "sea"
		},
		{
			c: 9,
			r: 9,
			terrain: "sea"
		},
		{
			c: 10,
			r: 9,
			terrain: "desert"
		},
		{
			c: 11,
			r: 9,
			terrain: "desert",
			city: 3
		},
		{
			c: 12,
			r: 9,
			terrain: "sea"
		},
		{
			c: 13,
			r: 9,
			terrain: "desert",
			coins: 1
		},
		{
			c: 14,
			r: 9,
			terrain: "sea"
		},
		{
			c: 15,
			r: 9,
			terrain: "sea"
		},
		{
			c: 16,
			r: 9,
			terrain: "sea"
		},
		{
			c: 17,
			r: 9,
			terrain: "mountain",
			discovery: !0
		},
		{
			c: 18,
			r: 9,
			terrain: "desert"
		},
		{
			c: 8,
			r: 10,
			terrain: "grass",
			coins: 2
		},
		{
			c: 10,
			r: 10,
			terrain: "sea"
		},
		{
			c: 11,
			r: 10,
			terrain: "desert"
		},
		{
			c: 14,
			r: 10,
			terrain: "sea",
			ruin: "sea"
		}
	],
	kazan: [
		{
			c: 3,
			r: 1,
			terrain: "desert",
			discovery: !0
		},
		{
			c: 5,
			r: 1,
			terrain: "desert",
			coins: 1
		},
		{
			c: 6,
			r: 1,
			terrain: "desert",
			coins: 2
		},
		{
			c: 7,
			r: 1,
			terrain: "desert",
			city: 3
		},
		{
			c: 8,
			r: 1,
			terrain: "sea"
		},
		{
			c: 9,
			r: 1,
			terrain: "sea"
		},
		{
			c: 10,
			r: 1,
			terrain: "sea",
			ruin: "D"
		},
		{
			c: 11,
			r: 1,
			terrain: "sea"
		},
		{
			c: 12,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 13,
			r: 1,
			terrain: "mountain",
			city: 3
		},
		{
			c: 14,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 15,
			r: 1,
			terrain: "desert",
			ruin: "H"
		},
		{
			c: 3,
			r: 2,
			terrain: "desert",
			coins: 1
		},
		{
			c: 4,
			r: 2,
			terrain: "desert"
		},
		{
			c: 5,
			r: 2,
			terrain: "sea"
		},
		{
			c: 6,
			r: 2,
			terrain: "sea"
		},
		{
			c: 7,
			r: 2,
			terrain: "sea",
			ruin: "C"
		},
		{
			c: 8,
			r: 2,
			terrain: "sea"
		},
		{
			c: 9,
			r: 2,
			terrain: "grass"
		},
		{
			c: 10,
			r: 2,
			terrain: "grass",
			coins: 2
		},
		{
			c: 11,
			r: 2,
			terrain: "sea",
			ruin: "F"
		},
		{
			c: 12,
			r: 2,
			terrain: "mountain"
		},
		{
			c: 13,
			r: 2,
			terrain: "sea"
		},
		{
			c: 14,
			r: 2,
			terrain: "grass"
		},
		{
			c: 15,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 16,
			r: 2,
			terrain: "desert",
			coins: 1
		},
		{
			c: 17,
			r: 2,
			terrain: "desert"
		},
		{
			c: 1,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 3,
			r: 3,
			terrain: "grass",
			coins: 2
		},
		{
			c: 4,
			r: 3,
			terrain: "sea"
		},
		{
			c: 5,
			r: 3,
			terrain: "sea"
		},
		{
			c: 6,
			r: 3,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 7,
			r: 3,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 8,
			r: 3,
			terrain: "grass"
		},
		{
			c: 9,
			r: 3,
			terrain: "grass"
		},
		{
			c: 10,
			r: 3,
			terrain: "grass"
		},
		{
			c: 11,
			r: 3,
			terrain: "sea"
		},
		{
			c: 12,
			r: 3,
			terrain: "sea"
		},
		{
			c: 13,
			r: 3,
			terrain: "sea"
		},
		{
			c: 14,
			r: 3,
			terrain: "sea"
		},
		{
			c: 15,
			r: 3,
			terrain: "sea"
		},
		{
			c: 16,
			r: 3,
			terrain: "grass",
			coins: 1
		},
		{
			c: 17,
			r: 3,
			terrain: "desert",
			discovery: !0
		},
		{
			c: 18,
			r: 3,
			terrain: "desert",
			coins: 2
		},
		{
			c: 1,
			r: 4,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 4,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 3,
			r: 4,
			terrain: "grass"
		},
		{
			c: 4,
			r: 4,
			terrain: "grass",
			city: 5
		},
		{
			c: 5,
			r: 4,
			terrain: "sea"
		},
		{
			c: 6,
			r: 4,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 7,
			r: 4,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 8,
			r: 4,
			terrain: "desert",
			city: 2
		},
		{
			c: 9,
			r: 4,
			terrain: "desert",
			coins: 1
		},
		{
			c: 10,
			r: 4,
			terrain: "sea"
		},
		{
			c: 11,
			r: 4,
			terrain: "mountain",
			ruin: "G"
		},
		{
			c: 12,
			r: 4,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 13,
			r: 4,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 14,
			r: 4,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 15,
			r: 4,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 4,
			terrain: "sea"
		},
		{
			c: 17,
			r: 4,
			terrain: "sea",
			ruin: "I"
		},
		{
			c: 18,
			r: 4,
			terrain: "desert"
		},
		{
			c: 19,
			r: 4,
			terrain: "desert",
			city: 4
		},
		{
			c: 1,
			r: 5,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 2,
			r: 5,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 3,
			r: 5,
			terrain: "grass"
		},
		{
			c: 4,
			r: 5,
			terrain: "sea"
		},
		{
			c: 5,
			r: 5,
			terrain: "sea"
		},
		{
			c: 6,
			r: 5,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 7,
			r: 5,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 8,
			r: 5,
			terrain: "desert"
		},
		{
			c: 9,
			r: 5,
			terrain: "desert"
		},
		{
			c: 10,
			r: 5,
			terrain: "sea"
		},
		{
			c: 11,
			r: 5,
			terrain: "mountain"
		},
		{
			c: 12,
			r: 5,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 13,
			r: 5,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 14,
			r: 5,
			terrain: "mountain",
			volcano: !0
		},
		{
			c: 15,
			r: 5,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 5,
			terrain: "grass"
		},
		{
			c: 17,
			r: 5,
			terrain: "grass",
			coins: 2
		},
		{
			c: 18,
			r: 5,
			terrain: "sea"
		},
		{
			c: 2,
			r: 6,
			terrain: "grass"
		},
		{
			c: 3,
			r: 6,
			terrain: "sea"
		},
		{
			c: 4,
			r: 6,
			terrain: "sea"
		},
		{
			c: 5,
			r: 6,
			terrain: "desert"
		},
		{
			c: 6,
			r: 6,
			terrain: "grass"
		},
		{
			c: 7,
			r: 6,
			terrain: "grass",
			coins: 1
		},
		{
			c: 8,
			r: 6,
			terrain: "grass",
			coins: 1
		},
		{
			c: 9,
			r: 6,
			terrain: "desert"
		},
		{
			c: 10,
			r: 6,
			terrain: "grass",
			capital: !0
		},
		{
			c: 11,
			r: 6,
			terrain: "desert",
			coins: 1
		},
		{
			c: 12,
			r: 6,
			terrain: "desert",
			coins: 1
		},
		{
			c: 13,
			r: 6,
			terrain: "desert",
			coins: 1
		},
		{
			c: 14,
			r: 6,
			terrain: "desert"
		},
		{
			c: 15,
			r: 6,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 6,
			terrain: "desert",
			city: 2
		},
		{
			c: 17,
			r: 6,
			terrain: "grass"
		},
		{
			c: 18,
			r: 6,
			terrain: "grass"
		},
		{
			c: 2,
			r: 7,
			terrain: "sea",
			ruin: "A"
		},
		{
			c: 3,
			r: 7,
			terrain: "desert",
			coins: 1
		},
		{
			c: 4,
			r: 7,
			terrain: "grass"
		},
		{
			c: 5,
			r: 7,
			terrain: "grass"
		},
		{
			c: 6,
			r: 7,
			terrain: "grass",
			city: 2
		},
		{
			c: 7,
			r: 7,
			terrain: "desert"
		},
		{
			c: 8,
			r: 7,
			terrain: "desert"
		},
		{
			c: 9,
			r: 7,
			terrain: "sea"
		},
		{
			c: 10,
			r: 7,
			terrain: "sea"
		},
		{
			c: 11,
			r: 7,
			terrain: "grass",
			coins: 1
		},
		{
			c: 12,
			r: 7,
			terrain: "grass"
		},
		{
			c: 13,
			r: 7,
			terrain: "desert",
			coins: 1
		},
		{
			c: 14,
			r: 7,
			terrain: "desert"
		},
		{
			c: 15,
			r: 7,
			terrain: "mountain"
		},
		{
			c: 16,
			r: 7,
			terrain: "sea"
		},
		{
			c: 17,
			r: 7,
			terrain: "sea"
		},
		{
			c: 18,
			r: 7,
			terrain: "sea"
		},
		{
			c: 19,
			r: 7,
			terrain: "sea",
			ruin: "J"
		},
		{
			c: 2,
			r: 8,
			terrain: "desert",
			coins: 1
		},
		{
			c: 3,
			r: 8,
			terrain: "desert"
		},
		{
			c: 4,
			r: 8,
			terrain: "desert"
		},
		{
			c: 5,
			r: 8,
			terrain: "desert"
		},
		{
			c: 6,
			r: 8,
			terrain: "sea"
		},
		{
			c: 7,
			r: 8,
			terrain: "sea"
		},
		{
			c: 8,
			r: 8,
			terrain: "sea"
		},
		{
			c: 9,
			r: 8,
			terrain: "sea"
		},
		{
			c: 10,
			r: 8,
			terrain: "sea"
		},
		{
			c: 11,
			r: 8,
			terrain: "grass"
		},
		{
			c: 12,
			r: 8,
			terrain: "sea"
		},
		{
			c: 13,
			r: 8,
			terrain: "grass",
			coins: 1
		},
		{
			c: 14,
			r: 8,
			terrain: "desert"
		},
		{
			c: 15,
			r: 8,
			terrain: "sea"
		},
		{
			c: 16,
			r: 8,
			terrain: "sea"
		},
		{
			c: 17,
			r: 8,
			terrain: "sea"
		},
		{
			c: 18,
			r: 8,
			terrain: "sea"
		},
		{
			c: 3,
			r: 9,
			terrain: "desert"
		},
		{
			c: 4,
			r: 9,
			terrain: "desert"
		},
		{
			c: 5,
			r: 9,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 6,
			r: 9,
			terrain: "sea",
			ruin: "B"
		},
		{
			c: 7,
			r: 9,
			terrain: "grass"
		},
		{
			c: 8,
			r: 9,
			terrain: "grass"
		},
		{
			c: 9,
			r: 9,
			terrain: "grass",
			city: 2
		},
		{
			c: 10,
			r: 9,
			terrain: "sea",
			ruin: "E"
		},
		{
			c: 11,
			r: 9,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 12,
			r: 9,
			terrain: "mountain"
		},
		{
			c: 13,
			r: 9,
			terrain: "grass",
			city: 3
		},
		{
			c: 14,
			r: 9,
			terrain: "desert"
		},
		{
			c: 15,
			r: 9,
			terrain: "grass"
		},
		{
			c: 16,
			r: 9,
			terrain: "sea"
		},
		{
			c: 17,
			r: 9,
			terrain: "sea"
		},
		{
			c: 18,
			r: 9,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 7,
			r: 10,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 8,
			r: 10,
			terrain: "grass",
			coins: 2
		},
		{
			c: 10,
			r: 10,
			terrain: "mountain"
		},
		{
			c: 12,
			r: 10,
			terrain: "grass"
		},
		{
			c: 14,
			r: 10,
			terrain: "grass",
			coins: 2
		}
	],
	cnidaria: [
		{
			c: 1,
			r: 1,
			terrain: "desert",
			discovery: !0
		},
		{
			c: 2,
			r: 0,
			terrain: "desert",
			coins: 2
		},
		{
			c: 2,
			r: 1,
			terrain: "desert"
		},
		{
			c: 2,
			r: 2,
			terrain: "desert"
		},
		{
			c: 2,
			r: 3,
			terrain: "grass",
			coins: 1
		},
		{
			c: 2,
			r: 4,
			terrain: "desert"
		},
		{
			c: 2,
			r: 5,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 6,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 2,
			r: 7,
			terrain: "grass",
			coins: 2
		},
		{
			c: 2,
			r: 8,
			terrain: "grass",
			coins: 2
		},
		{
			c: 3,
			r: 0,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 3,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 3,
			r: 2,
			terrain: "grass"
		},
		{
			c: 3,
			r: 3,
			terrain: "desert",
			coins: 1
		},
		{
			c: 3,
			r: 4,
			terrain: "mountain"
		},
		{
			c: 3,
			r: 5,
			terrain: "grass"
		},
		{
			c: 3,
			r: 6,
			terrain: "grass"
		},
		{
			c: 3,
			r: 7,
			terrain: "desert"
		},
		{
			c: 3,
			r: 8,
			terrain: "desert",
			coins: 2
		},
		{
			c: 4,
			r: 0,
			terrain: "desert",
			coins: 2
		},
		{
			c: 4,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 4,
			r: 2,
			terrain: "grass"
		},
		{
			c: 4,
			r: 3,
			terrain: "sea",
			ruin: "square"
		},
		{
			c: 4,
			r: 4,
			terrain: "desert"
		},
		{
			c: 4,
			r: 5,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 4,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 4,
			r: 7,
			terrain: "desert",
			city: 4
		},
		{
			c: 4,
			r: 8,
			terrain: "desert"
		},
		{
			c: 5,
			r: 0,
			terrain: "desert"
		},
		{
			c: 5,
			r: 1,
			terrain: "desert"
		},
		{
			c: 5,
			r: 2,
			terrain: "sea"
		},
		{
			c: 5,
			r: 3,
			terrain: "sea"
		},
		{
			c: 5,
			r: 4,
			terrain: "sea"
		},
		{
			c: 5,
			r: 5,
			terrain: "sea"
		},
		{
			c: 5,
			r: 6,
			terrain: "sea"
		},
		{
			c: 5,
			r: 7,
			terrain: "sea"
		},
		{
			c: 5,
			r: 8,
			terrain: "sea"
		},
		{
			c: 5,
			r: 9,
			terrain: "mountain"
		},
		{
			c: 6,
			r: 1,
			terrain: "grass",
			coins: 1
		},
		{
			c: 6,
			r: 2,
			terrain: "grass"
		},
		{
			c: 6,
			r: 3,
			terrain: "sea"
		},
		{
			c: 6,
			r: 4,
			terrain: "sea"
		},
		{
			c: 6,
			r: 5,
			terrain: "sea"
		},
		{
			c: 6,
			r: 6,
			terrain: "sea"
		},
		{
			c: 6,
			r: 7,
			terrain: "sea"
		},
		{
			c: 6,
			r: 8,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 6,
			r: 9,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 6,
			r: 10,
			terrain: "mountain",
			ruin: "circle"
		},
		{
			c: 7,
			r: 0,
			terrain: "grass",
			coins: 1
		},
		{
			c: 7,
			r: 1,
			terrain: "grass",
			city: 4
		},
		{
			c: 7,
			r: 2,
			terrain: "grass"
		},
		{
			c: 7,
			r: 3,
			terrain: "sea"
		},
		{
			c: 7,
			r: 4,
			terrain: "grass",
			coins: 1
		},
		{
			c: 7,
			r: 5,
			terrain: "grass"
		},
		{
			c: 7,
			r: 6,
			terrain: "grass",
			coins: 1
		},
		{
			c: 7,
			r: 7,
			terrain: "sea"
		},
		{
			c: 7,
			r: 8,
			terrain: "desert"
		},
		{
			c: 7,
			r: 9,
			terrain: "desert"
		},
		{
			c: 7,
			r: 10,
			terrain: "grass"
		},
		{
			c: 8,
			r: 0,
			terrain: "desert",
			crystal: 3
		},
		{
			c: 8,
			r: 1,
			terrain: "desert"
		},
		{
			c: 8,
			r: 2,
			terrain: "desert"
		},
		{
			c: 8,
			r: 3,
			terrain: "sea"
		},
		{
			c: 8,
			r: 4,
			terrain: "sea"
		},
		{
			c: 8,
			r: 5,
			terrain: "desert"
		},
		{
			c: 8,
			r: 6,
			terrain: "grass"
		},
		{
			c: 8,
			r: 7,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 8,
			r: 8,
			terrain: "sea"
		},
		{
			c: 8,
			r: 9,
			terrain: "desert"
		},
		{
			c: 8,
			r: 10,
			terrain: "grass",
			coins: 1
		},
		{
			c: 9,
			r: 0,
			terrain: "desert"
		},
		{
			c: 9,
			r: 1,
			terrain: "sea",
			ruin: "circle"
		},
		{
			c: 9,
			r: 2,
			terrain: "sea"
		},
		{
			c: 9,
			r: 3,
			terrain: "sea"
		},
		{
			c: 9,
			r: 4,
			terrain: "desert"
		},
		{
			c: 9,
			r: 5,
			terrain: "grass"
		},
		{
			c: 9,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 9,
			r: 7,
			terrain: "desert",
			coins: 1
		},
		{
			c: 9,
			r: 8,
			terrain: "sea"
		},
		{
			c: 9,
			r: 9,
			terrain: "sea"
		},
		{
			c: 9,
			r: 10,
			terrain: "grass",
			coins: 2
		},
		{
			c: 10,
			r: 0,
			terrain: "desert",
			coins: 2
		},
		{
			c: 10,
			r: 1,
			terrain: "sea"
		},
		{
			c: 10,
			r: 2,
			terrain: "sea",
			coins: 1
		},
		{
			c: 10,
			r: 3,
			terrain: "sea"
		},
		{
			c: 10,
			r: 4,
			terrain: "desert",
			coins: 1
		},
		{
			c: 10,
			r: 5,
			terrain: "grass",
			city: 2
		},
		{
			c: 10,
			r: 6,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 10,
			r: 7,
			terrain: "mountain"
		},
		{
			c: 10,
			r: 8,
			terrain: "desert",
			coins: 1
		},
		{
			c: 10,
			r: 9,
			terrain: "sea"
		},
		{
			c: 10,
			r: 10,
			terrain: "grass"
		},
		{
			c: 11,
			r: 0,
			terrain: "sea",
			reef: !0
		},
		{
			c: 11,
			r: 1,
			terrain: "sea",
			reef: !0
		},
		{
			c: 11,
			r: 2,
			terrain: "sea",
			reef: !0
		},
		{
			c: 11,
			r: 3,
			terrain: "sea"
		},
		{
			c: 11,
			r: 4,
			terrain: "desert"
		},
		{
			c: 11,
			r: 5,
			terrain: "desert",
			capital: !0
		},
		{
			c: 11,
			r: 6,
			terrain: "desert"
		},
		{
			c: 11,
			r: 7,
			terrain: "desert"
		},
		{
			c: 11,
			r: 8,
			terrain: "sea"
		},
		{
			c: 11,
			r: 9,
			terrain: "sea"
		},
		{
			c: 11,
			r: 10,
			terrain: "sea"
		},
		{
			c: 11,
			r: 11,
			terrain: "desert"
		},
		{
			c: 12,
			r: 1,
			terrain: "grass",
			coins: 1
		},
		{
			c: 12,
			r: 2,
			terrain: "grass"
		},
		{
			c: 12,
			r: 3,
			terrain: "sea"
		},
		{
			c: 12,
			r: 4,
			terrain: "sea"
		},
		{
			c: 12,
			r: 5,
			terrain: "sea"
		},
		{
			c: 12,
			r: 6,
			terrain: "grass",
			city: 2
		},
		{
			c: 12,
			r: 7,
			terrain: "grass",
			crystal: 1
		},
		{
			c: 12,
			r: 8,
			terrain: "sea"
		},
		{
			c: 12,
			r: 9,
			terrain: "sea",
			coins: 1
		},
		{
			c: 12,
			r: 10,
			terrain: "sea",
			reef: !0
		},
		{
			c: 12,
			r: 11,
			terrain: "sea",
			ruin: "square"
		},
		{
			c: 13,
			r: 0,
			terrain: "grass",
			crystal: 2
		},
		{
			c: 13,
			r: 1,
			terrain: "grass",
			city: 4
		},
		{
			c: 13,
			r: 2,
			terrain: "sea"
		},
		{
			c: 13,
			r: 3,
			terrain: "sea",
			coins: 2
		},
		{
			c: 13,
			r: 4,
			terrain: "sea"
		},
		{
			c: 13,
			r: 5,
			terrain: "mountain",
			coins: 1
		},
		{
			c: 13,
			r: 6,
			terrain: "grass",
			coins: 1
		},
		{
			c: 13,
			r: 7,
			terrain: "grass"
		},
		{
			c: 13,
			r: 8,
			terrain: "sea"
		},
		{
			c: 13,
			r: 9,
			terrain: "sea",
			reef: !0
		},
		{
			c: 13,
			r: 10,
			terrain: "sea",
			reef: !0
		},
		{
			c: 13,
			r: 11,
			terrain: "sea",
			ruin: "triangle"
		},
		{
			c: 14,
			r: 1,
			terrain: "grass"
		},
		{
			c: 14,
			r: 2,
			terrain: "desert"
		},
		{
			c: 14,
			r: 3,
			terrain: "sea"
		},
		{
			c: 14,
			r: 4,
			terrain: "sea"
		},
		{
			c: 14,
			r: 5,
			terrain: "mountain"
		},
		{
			c: 14,
			r: 6,
			terrain: "mountain"
		},
		{
			c: 14,
			r: 7,
			terrain: "grass"
		},
		{
			c: 14,
			r: 8,
			terrain: "sea"
		},
		{
			c: 14,
			r: 9,
			terrain: "sea",
			ruin: "square"
		},
		{
			c: 14,
			r: 10,
			terrain: "sea",
			reef: !0
		},
		{
			c: 14,
			r: 11,
			terrain: "sea",
			discovery: !0
		},
		{
			c: 15,
			r: 0,
			terrain: "grass"
		},
		{
			c: 15,
			r: 1,
			terrain: "desert"
		},
		{
			c: 15,
			r: 2,
			terrain: "desert",
			coins: 1
		},
		{
			c: 15,
			r: 3,
			terrain: "mountain"
		},
		{
			c: 15,
			r: 4,
			terrain: "sea"
		},
		{
			c: 15,
			r: 5,
			terrain: "sea"
		},
		{
			c: 15,
			r: 6,
			terrain: "sea"
		},
		{
			c: 15,
			r: 7,
			terrain: "sea"
		},
		{
			c: 15,
			r: 8,
			terrain: "sea"
		},
		{
			c: 15,
			r: 9,
			terrain: "sea",
			reef: !0
		},
		{
			c: 15,
			r: 10,
			terrain: "sea",
			reef: !0
		},
		{
			c: 16,
			r: 1,
			terrain: "desert",
			ruin: "triangle"
		},
		{
			c: 16,
			r: 2,
			terrain: "desert"
		},
		{
			c: 16,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 16,
			r: 4,
			terrain: "sea"
		},
		{
			c: 16,
			r: 5,
			terrain: "sea"
		},
		{
			c: 16,
			r: 6,
			terrain: "sea"
		},
		{
			c: 16,
			r: 7,
			terrain: "sea"
		},
		{
			c: 16,
			r: 8,
			terrain: "sea"
		},
		{
			c: 16,
			r: 9,
			terrain: "sea"
		},
		{
			c: 16,
			r: 10,
			terrain: "sea",
			reef: !0
		},
		{
			c: 16,
			r: 11,
			terrain: "sea",
			reef: !0
		},
		{
			c: 17,
			r: 1,
			terrain: "mountain"
		},
		{
			c: 17,
			r: 2,
			terrain: "mountain"
		},
		{
			c: 17,
			r: 3,
			terrain: "mountain",
			coins: 2
		},
		{
			c: 17,
			r: 4,
			terrain: "sea"
		},
		{
			c: 17,
			r: 5,
			terrain: "sea"
		},
		{
			c: 17,
			r: 6,
			terrain: "sea"
		},
		{
			c: 17,
			r: 7,
			terrain: "grass",
			coins: 2
		},
		{
			c: 17,
			r: 8,
			terrain: "grass"
		},
		{
			c: 17,
			r: 9,
			terrain: "grass",
			coins: 1
		},
		{
			c: 17,
			r: 10,
			terrain: "desert",
			city: 5
		},
		{
			c: 17,
			r: 11,
			terrain: "desert",
			coins: 3
		},
		{
			c: 18,
			r: 1,
			terrain: "grass",
			discovery: !0
		},
		{
			c: 18,
			r: 2,
			terrain: "grass",
			coins: 1
		},
		{
			c: 18,
			r: 3,
			terrain: "desert"
		},
		{
			c: 18,
			r: 4,
			terrain: "desert"
		},
		{
			c: 18,
			r: 5,
			terrain: "desert",
			coins: 1
		},
		{
			c: 18,
			r: 6,
			terrain: "sea",
			ruin: "circle"
		},
		{
			c: 18,
			r: 7,
			terrain: "sea"
		},
		{
			c: 18,
			r: 8,
			terrain: "sea"
		},
		{
			c: 18,
			r: 9,
			terrain: "mountain"
		},
		{
			c: 18,
			r: 10,
			terrain: "grass"
		},
		{
			c: 18,
			r: 11,
			terrain: "desert"
		},
		{
			c: 18,
			r: 12,
			terrain: "desert",
			crystal: 4
		},
		{
			c: 18,
			r: 13,
			terrain: "sea"
		},
		{
			c: 19,
			r: 2,
			terrain: "grass"
		},
		{
			c: 19,
			r: 3,
			terrain: "grass"
		},
		{
			c: 19,
			r: 4,
			terrain: "grass",
			coins: 2
		},
		{
			c: 19,
			r: 6,
			terrain: "desert",
			coins: 2
		},
		{
			c: 19,
			r: 7,
			terrain: "desert"
		},
		{
			c: 19,
			r: 8,
			terrain: "desert"
		},
		{
			c: 19,
			r: 9,
			terrain: "desert",
			coins: 2
		},
		{
			c: 19,
			r: 10,
			terrain: "grass"
		},
		{
			c: 19,
			r: 11,
			terrain: "desert"
		},
		{
			c: 19,
			r: 12,
			terrain: "sea"
		},
		{
			c: 20,
			r: 3,
			terrain: "grass",
			ruin: "circle"
		},
		{
			c: 20,
			r: 4,
			terrain: "grass"
		},
		{
			c: 20,
			r: 8,
			terrain: "desert"
		},
		{
			c: 20,
			r: 10,
			terrain: "mountain",
			coins: 3
		},
		{
			c: 20,
			r: 11,
			terrain: "grass"
		},
		{
			c: 20,
			r: 12,
			terrain: "desert",
			ruin: "triangle"
		},
		{
			c: 20,
			r: 13,
			terrain: "sea"
		},
		{
			c: 21,
			r: 8,
			terrain: "desert",
			discovery: !0
		}
	]
}, D = Object.fromEntries(Object.keys(E).map((e) => {
	let t = E[e];
	return [e, {
		id: e,
		cells: t,
		index: new Map(t.map((e) => [`${e.c},${e.r}`, e]))
	}];
})), O = (e) => `${e.c},${e.r}`, k = (e) => {
	let [t, n] = e.split(",").map(Number);
	return {
		c: t,
		r: n
	};
};
function A(e) {
	let { c: t, r: n } = e;
	return t % 2 == 0 ? [
		{
			c: t,
			r: n - 1
		},
		{
			c: t,
			r: n + 1
		},
		{
			c: t - 1,
			r: n - 1
		},
		{
			c: t - 1,
			r: n
		},
		{
			c: t + 1,
			r: n - 1
		},
		{
			c: t + 1,
			r: n
		}
	] : [
		{
			c: t,
			r: n - 1
		},
		{
			c: t,
			r: n + 1
		},
		{
			c: t - 1,
			r: n
		},
		{
			c: t - 1,
			r: n + 1
		},
		{
			c: t + 1,
			r: n
		},
		{
			c: t + 1,
			r: n + 1
		}
	];
}
var oe = (e) => [e.c, e.r - Math.floor(e.c / 2)];
function se(e) {
	if (e.length <= 2) return !0;
	let [t, n] = oe(e[0]), r = /* @__PURE__ */ new Set();
	for (let i of e.slice(1)) {
		let [e, a] = oe(i), o = e - t, s = a - n, c = ce(Math.abs(o), Math.abs(s)) || 1;
		o /= c, s /= c, r.add(`${o},${s}`);
	}
	return r.size === 1;
}
function ce(e, t) {
	for (; t;) [e, t] = [t, e % t];
	return e;
}
function j(e) {
	return e.length <= 1 || se(e) && le(e);
}
function le(e) {
	if (e.length <= 1) return !0;
	let t = new Set(e.map(O)), n = e[0], r = /* @__PURE__ */ new Set([O(n)]), i = [n];
	for (; i.length;) {
		let e = i.pop();
		for (let n of A(e)) {
			let e = O(n);
			t.has(e) && !r.has(e) && (r.add(e), i.push(n));
		}
	}
	return r.size === e.length;
}
//#endregion
//#region src/game/board.ts
var M = (e) => e === "grass" || e === "desert" || e === "mountain", N = (e) => M(e.terrain) && !e.discovery && !e.crystal && !e.capital, P = (e) => N(e) && !e.city && !e.coins && !e.ruin && !e.volcano && !e.discovery && !e.crystal && !e.capital;
function ue(e) {
	let t = /* @__PURE__ */ new Map(), n = [];
	for (let r of e.cells) {
		let i = O(r);
		if (!N(r) || t.has(i)) continue;
		let a = n.length, o = [], s = [r];
		for (t.set(i, a); s.length;) {
			let n = s.pop();
			o.push(O(n));
			for (let r of A(n)) {
				let i = O(r), o = e.index.get(i);
				o && N(o) && o.terrain === n.terrain && !t.has(i) && (t.set(i, a), s.push(o));
			}
		}
		n.push(o);
	}
	return {
		of: t,
		list: n
	};
}
function de(e) {
	let t = /* @__PURE__ */ new Map(), n = 0;
	for (let r of e.cells) {
		let i = O(r);
		if (!M(r.terrain) || r.crystal || r.discovery || t.has(i)) continue;
		let a = n++, o = [r];
		for (t.set(i, a); o.length;) {
			let n = o.pop();
			for (let r of A(n)) {
				let n = O(r), i = e.index.get(n);
				i && M(i.terrain) && !i.crystal && !i.discovery && !t.has(n) && (t.set(n, a), o.push(i));
			}
		}
	}
	return {
		of: t,
		count: n
	};
}
function fe(e, t) {
	let n = e.index.get(t);
	return n ? A(n).some((t) => !e.index.has(O(t))) : !1;
}
function pe(e) {
	return e.cells.filter((e) => !!e.discovery);
}
var me = /* @__PURE__ */ new Map();
function F(e) {
	let t = me.get(e.id);
	return t || (t = ue(e), me.set(e.id, t)), t;
}
var he = /* @__PURE__ */ new Map();
function ge(e) {
	let t = he.get(e.id);
	return t || (t = de(e), he.set(e.id, t)), t;
}
//#endregion
//#region src/game/goals.ts
var I = (e) => Object.keys(e.marks).filter((t) => e.marks[t] === "village"), _e = (e) => Object.keys(e.marks).filter((t) => e.marks[t] === "tower"), L = (e, t) => e.looted.map((e) => t.index.get(e)).filter(Boolean), ve = (e, t) => {
	let n = /* @__PURE__ */ new Set(), r = e.index.get(t);
	if (!r) return n;
	for (let t of A(r)) {
		let r = e.index.get(O(t));
		r && n.add(r.terrain);
	}
	return n;
}, ye = (e, t, n) => I(e).some((e) => {
	let r = t.index.get(e);
	return r && A(r).some((e) => {
		let r = t.index.get(O(e));
		return r && n(r);
	});
}), be = {
	avenia: [
		{
			id: "av-towers",
			map: "avenia",
			title: "Place 2 discovery towers",
			check: (e) => _e(e).length >= 2
		},
		{
			id: "av-region5",
			map: "avenia",
			title: "Village on a region of 5+ spaces",
			check: (e, t) => {
				let n = F(t);
				return I(e).some((e) => {
					let t = n.of.get(e);
					return t !== void 0 && n.list[t].length >= 5;
				});
			}
		},
		{
			id: "av-lands",
			map: "avenia",
			title: "Villages on 3 different lands",
			check: (e, t) => {
				let n = ge(t).of;
				return new Set(I(e).map((e) => n.get(e)).filter((e) => e !== void 0)).size >= 3;
			}
		},
		{
			id: "av-v5",
			map: "avenia",
			title: "Discover 5 villages",
			check: (e) => I(e).length >= 5
		},
		{
			id: "av-borderruins",
			map: "avenia",
			title: "Explore 3 ruin spaces on the map border",
			check: (e, t) => L(e, t).filter((e) => e && fe(t, O(e))).length >= 3
		},
		{
			id: "av-posts",
			map: "avenia",
			title: "2 trading posts on cities valued 3+",
			check: (e, t) => Object.keys(e.posts).filter((e) => (t.index.get(e)?.city ?? 0) >= 3).length >= 2
		}
	],
	aghon: [
		{
			id: "ag-mountain2",
			map: "aghon",
			title: "Villages on 2 mountain spaces",
			check: (e, t) => I(e).filter((e) => t.index.get(e)?.terrain === "mountain").length >= 2
		},
		{
			id: "ag-three",
			map: "aghon",
			title: "Villages on grassland, desert and mountain",
			check: (e, t) => {
				let n = new Set(I(e).map((e) => t.index.get(e)?.terrain).filter(Boolean));
				return n.has("grass") && n.has("desert") && n.has("mountain");
			}
		},
		{
			id: "ag-ruinterrains",
			map: "aghon",
			title: "Explore ruins adjacent to grassland, desert and mountain",
			check: (e, t) => {
				let n = /* @__PURE__ */ new Set();
				for (let r of L(e, t)) if (r) for (let e of ve(t, O(r))) n.add(e);
				return n.has("grass") && n.has("desert") && n.has("mountain");
			}
		},
		{
			id: "ag-route12",
			map: "aghon",
			title: "Complete a trade route worth 12+",
			check: (e) => e.bestRoute >= 12
		},
		{
			id: "ag-villagetower",
			map: "aghon",
			title: "Village adjacent to a discovery tower",
			check: (e, t) => ye(e, t, (t) => !!t.discovery && e.marks[O(t)] === "tower")
		},
		{
			id: "ag-posterrains",
			map: "aghon",
			title: "Trading posts on grassland, desert and mountain",
			check: (e) => {
				let t = new Set(Object.values(e.posts));
				return t.has("grass") && t.has("desert") && t.has("mountain");
			}
		}
	],
	kazan: [
		{
			id: "kz-aj",
			map: "kazan",
			title: "Explore ruin spaces A and J",
			check: (e, t) => {
				let n = new Set(L(e, t).map((e) => e?.ruin));
				return n.has("A") && n.has("J");
			}
		},
		{
			id: "kz-netowerC",
			map: "kazan",
			title: "Explore the northeastern discovery tower and ruin C",
			check: (e, t) => {
				let n = xe(t), r = n && e.marks[n] === "tower", i = L(e, t).some((e) => e?.ruin === "C");
				return !!r && i;
			}
		},
		{
			id: "kz-bd",
			map: "kazan",
			title: "Explore ruin spaces B and D",
			check: (e, t) => {
				let n = new Set(L(e, t).map((e) => e?.ruin));
				return n.has("B") && n.has("D");
			}
		},
		{
			id: "kz-chain",
			map: "kazan",
			title: "Connect 2 cities and 2 ruins with an unbroken chain",
			check: (e, t) => Se(e, t)
		},
		{
			id: "kz-coins3",
			map: "kazan",
			title: "Explore a space with at least 3 coins",
			check: (e, t) => e.explored.some((e) => (t.index.get(e)?.coins ?? 0) >= 3)
		},
		{
			id: "kz-villageruin",
			map: "kazan",
			title: "Village adjacent to a ruin space",
			check: (e, t) => ye(e, t, (e) => !!e.ruin)
		}
	],
	cnidaria: [
		{
			id: "cn-crystalvillages",
			map: "cnidaria",
			title: "2 villages adjacent to crystal spaces",
			check: (e, t) => I(e).filter((e) => {
				let n = t.index.get(e);
				return n && A(n).some((e) => t.index.get(O(e))?.crystal);
			}).length >= 2
		},
		{
			id: "cn-sameregion",
			map: "cnidaria",
			title: "3 villages on the same region type",
			check: (e, t) => {
				let n = {};
				for (let r of I(e)) {
					let e = t.index.get(r)?.terrain;
					e && (n[e] = (n[e] ?? 0) + 1);
				}
				return Object.values(n).some((e) => e >= 3);
			}
		},
		{
			id: "cn-shapes",
			map: "cnidaria",
			title: "Explore a ruin of each shape",
			check: (e, t) => {
				let n = new Set(L(e, t).map((e) => e?.ruin));
				return n.has("triangle") && n.has("circle") && n.has("square");
			}
		},
		{
			id: "cn-sameshape3",
			map: "cnidaria",
			title: "Explore 3 ruins of the same shape",
			check: (e, t) => {
				let n = {};
				for (let r of L(e, t)) {
					let e = r?.ruin;
					e && (n[e] = (n[e] ?? 0) + 1);
				}
				return Object.entries(n).some(([e, t]) => [
					"triangle",
					"circle",
					"square"
				].includes(e) && t >= 3);
			}
		},
		{
			id: "cn-route16",
			map: "cnidaria",
			title: "Complete a trade route worth 16+",
			check: (e) => e.bestRoute >= 16
		},
		{
			id: "cn-crystal2",
			map: "cnidaria",
			title: "Explore 2 crystal spaces",
			check: (e) => e.crystals.length >= 2
		}
	]
};
function xe(e) {
	let t = pe(e);
	if (!t.length) return null;
	let n = t[0], r = -1e9;
	for (let e of t) {
		let t = e.c - e.r * 1.2;
		t > r && (r = t, n = e);
	}
	return O(n);
}
function Se(e, t) {
	let n = new Set(Object.keys(e.marks).filter((t) => e.marks[t] === "explorer" || e.marks[t] === "village")), r = t.cells.find((e) => e.capital);
	r && n.add(O(r));
	let i = /* @__PURE__ */ new Set();
	for (let e of n) {
		if (i.has(e)) continue;
		let r = [e];
		i.add(e);
		let a = 0, o = 0;
		for (; r.length;) {
			let e = r.pop(), s = t.index.get(e);
			if (s) {
				s.city && a++, s.ruin && o++;
				for (let e of A(s)) {
					let t = O(e);
					n.has(t) && !i.has(t) && (i.add(t), r.push(t));
				}
			}
		}
		if (a >= 2 && o >= 2) return !0;
	}
	return !1;
}
//#endregion
//#region src/game/cards.ts
var Ce = [
	"grass",
	"desert",
	"mountain",
	"sea"
], we = [
	"grass",
	"desert",
	"mountain"
], Te = [
	{
		kind: "pool",
		allow: ["grass"],
		max: 2
	},
	{
		kind: "pool",
		allow: ["desert"],
		max: 2
	},
	{
		kind: "pool",
		allow: ["mountain"],
		max: 1
	},
	{
		kind: "line",
		allow: ["sea"],
		max: 3
	},
	{
		kind: "path",
		allow: Ce,
		max: 2
	}
], R = [
	{
		kind: "pool",
		allow: ["sea", "mountain"],
		perTerrain: {
			sea: 1,
			mountain: 3
		},
		max: 4
	},
	{
		kind: "pool",
		allow: [
			"desert",
			"grass",
			"mountain",
			"sea"
		],
		perTerrain: {
			desert: 1,
			grass: 1,
			mountain: 1,
			sea: 2
		},
		max: 5
	},
	{
		kind: "anchorAdj",
		allow: ["mountain"],
		anchor: "mountain",
		max: 5
	},
	{
		kind: "anchorLine",
		allow: ["mountain"],
		anchor: "mountain",
		max: 3
	},
	{
		kind: "anchorAdj",
		allow: ["sea"],
		anchor: "sea",
		max: 5
	},
	{
		kind: "pool",
		allow: ["sea"],
		max: 4,
		extraTreasurePerRuin: !0
	},
	{
		kind: "pool",
		allow: ["desert"],
		max: 4,
		coinMult: 3,
		coinTerrains: ["desert"]
	},
	{
		kind: "seaThenCoin",
		allow: ["sea"],
		max: 4,
		seaMax: 4,
		coinMax: 2
	},
	{
		kind: "pool",
		allow: we,
		max: 4,
		region: !0
	},
	{
		kind: "anchorLine",
		allow: ["grass"],
		anchor: "grass",
		max: 3
	},
	{
		kind: "line",
		allow: [
			"grass",
			"desert",
			"mountain"
		],
		max: 99
	},
	{
		kind: "pool",
		allow: ["sea", "desert"],
		perTerrain: {
			sea: 1,
			desert: 4
		},
		max: 5
	},
	{
		kind: "anchorLine",
		allow: ["sea"],
		anchor: "sea",
		max: 3
	},
	{
		kind: "line",
		allow: ["sea"],
		max: 99
	},
	{
		kind: "anchorAdj",
		allow: ["grass"],
		anchor: "grass",
		max: 5
	},
	{
		kind: "twoVillageLine",
		allow: Ce,
		max: 3
	},
	{
		kind: "path",
		allow: ["grass", "sea"],
		max: 5
	},
	{
		kind: "pool",
		allow: ["mountain"],
		max: 3,
		coinMult: 2,
		coinTerrains: ["mountain"]
	},
	{
		kind: "pool",
		allow: ["mountain", "grass"],
		perTerrain: {
			mountain: 2,
			grass: 3
		},
		max: 5
	},
	{
		kind: "seaThenCity",
		allow: ["sea"],
		max: 4,
		seaMax: 4
	},
	{
		kind: "pool",
		allow: ["mountain", "desert"],
		perTerrain: {
			mountain: 2,
			desert: 3
		},
		max: 5
	},
	{
		kind: "pool",
		allow: ["sea"],
		max: 5
	},
	{
		kind: "pool",
		allow: ["grass"],
		max: 4,
		coinMult: 3,
		coinTerrains: ["grass"]
	},
	{
		kind: "path",
		allow: ["desert", "sea"],
		max: 5
	},
	{
		kind: "pool",
		allow: ["sea", "grass"],
		perTerrain: {
			sea: 1,
			grass: 4
		},
		max: 5
	},
	{
		kind: "anchorAdj",
		allow: ["desert"],
		anchor: "desert",
		max: 5
	},
	{
		kind: "path",
		allow: ["mountain", "sea"],
		max: 4
	},
	{
		kind: "anchorLine",
		allow: ["desert"],
		anchor: "desert",
		max: 3
	}
], Ee = (e) => Te[e], z = (e) => R[e], De = (e) => e - 5;
//#endregion
//#region src/game/treasure.ts
function Oe(e) {
	return e <= 0 ? 0 : e <= 4 ? e * e : 16 + 4 * (e - 4);
}
function B(e, t = {}) {
	return {
		kind: e,
		...t
	};
}
var ke = [
	...Array.from({ length: 8 }, () => B("explorer")),
	...Array.from({ length: 8 }, () => B("coins", { n: 2 })),
	...Array.from({ length: 10 }, () => B("vase")),
	B("village_terrain", { terrain: "grass" }),
	B("village_terrain", { terrain: "grass" }),
	B("village_terrain", { terrain: "desert" }),
	B("village_terrain", { terrain: "desert" }),
	B("village_terrain", { terrain: "mountain" }),
	B("village_terrain", { terrain: "mountain" }),
	B("per_settlements", { per: 2 }),
	B("per_settlements", { per: 2 }),
	...Array.from({ length: 6 }, () => B("per_towers"))
], Ae = [10, 5], je = [
	1,
	2,
	3,
	5
], Me = [
	6,
	8,
	10,
	14
], V = (e) => ({ code: `games.guildofmerchantexplorers.${e}` }), H = (e) => D[e.config.map], Ne = (e) => !!e.discovery || !!e.crystal;
function U(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Pe(e) {
	let t = [
		0,
		1,
		2,
		3,
		4,
		5
	];
	return e >= 2 && t.push(6), e >= 3 && t.push(7), e >= 4 && t.push(8), t;
}
function Fe(e) {
	return {
		rid: e,
		coins: 0,
		marks: {},
		posts: {},
		looted: [],
		crystals: [],
		crystalSum: 0,
		treasures: [],
		investigate: [
			null,
			null,
			null
		],
		goals: [],
		explored: [],
		bestRoute: 0
	};
}
function Ie(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		config: e,
		era: 1,
		round: 0,
		turnNo: 0,
		card: -1,
		deck: [],
		investigateDeck: [],
		treasureDeck: [],
		actor: 0,
		phase: "turn",
		players: t.map(Fe),
		goals: [],
		pendingQueue: [],
		cur: null,
		last: null,
		serial: 0
	};
	return r.goals = U(r, be[e.map].map((e, t) => t)).slice(0, 3).sort((e, t) => e - t).map((t) => ({
		id: be[e.map][t].id,
		map: e.map,
		high: Ae[0],
		low: Ae[1],
		completedBy: [],
		firstTurn: null
	})), r.investigateDeck = U(r, Array.from({ length: 28 }, (e, t) => t)), r.treasureDeck = U(r, ke.map((e, t) => t)), r.deck = U(r, Pe(1)), Le(r), { state: r };
}
function Le(e) {
	if (e.deck.length === 0) {
		Ve(e);
		return;
	}
	e.card = e.deck.pop(), e.round++, e.turnNo = e.round, e.actor = 0, e.cur = null, e.pendingQueue = [], Re(e);
}
function Re(e) {
	let t = e.players[e.actor];
	if (!t) {
		e.phase = "done";
		return;
	}
	e.cur = null;
	let n = e.card;
	if (n >= 5 && n <= 7) {
		let r = De(n);
		if (t.investigate[r] === null) {
			let n = e.investigateDeck.pop(), i = e.investigateDeck.pop();
			if (n === void 0 || i === void 0) {
				e.phase = "turn";
				return;
			}
			e.pendingQueue.push({
				kind: "investigate",
				rid: t.rid,
				options: [n, i],
				slot: r
			}), e.phase = "decide";
			return;
		}
		e.cur = W(t, z(t.investigate[r])), e.phase = "turn";
		return;
	}
	if (n === 8) {
		let n = t.investigate.filter((e) => e !== null);
		if (!n.length) {
			e.phase = "turn";
			return;
		}
		if (n.length === 1) {
			e.cur = W(t, z(n[0])), e.phase = "turn";
			return;
		}
		e.pendingQueue.push({
			kind: "useInvestigate",
			rid: t.rid,
			options: n
		}), e.phase = "decide";
		return;
	}
	e.cur = W(t, Ee(n)), e.phase = "turn";
}
function W(e, t) {
	return {
		rid: e.rid,
		spec: t,
		placed: [],
		counts: {
			grass: 0,
			desert: 0,
			mountain: 0,
			sea: 0
		},
		mode: "main",
		anchorCell: null,
		ended: !1
	};
}
function ze(e) {
	e.cur = null, e.actor++, e.actor >= e.players.length ? Be(e) : Re(e);
}
function Be(e) {
	e.deck.length === 0 ? Ve(e) : Le(e);
}
function Ve(e) {
	for (let t of e.players) for (let e of Object.keys(t.marks)) t.marks[e] === "explorer" && delete t.marks[e];
	if (e.era >= 4) {
		e.phase = "done";
		return;
	}
	e.era++, e.deck = U(e, Pe(e.era)), Le(e);
}
function He(e) {
	let t = e.spec;
	return t.kind === "anchorAdj" || t.kind === "anchorLine" ? 1 + t.max : t.kind === "seaThenCoin" ? (t.seaMax ?? 4) + (t.coinMax ?? 2) : t.kind === "seaThenCity" ? Infinity : t.max;
}
var Ue = (e) => {
	let t = e.cells.find((e) => e.capital);
	return t ? O(t) : null;
};
function G(e, t, n) {
	let r = Ue(t);
	return A(n).some((t) => {
		let n = O(t);
		if (n === r) return !0;
		let i = e.marks[n];
		return i === "village" || i === "explorer";
	});
}
function We(e, t) {
	return Ne(t) ? e.allow.length === 1 ? e.allow[0] : e.allow.includes(t.terrain) ? t.terrain : e.allow[0] : t.terrain;
}
function Ge(e, t, n) {
	let r = e.cur;
	if (!r || r.ended) return !1;
	let i = H(e), a = i.index.get(O(n));
	if (!a || a.volcano || a.reef || a.capital || t.marks[O(a)] || r.placed.length >= He(r)) return !1;
	let o = r.spec, s = Ne(a), c = s || o.allow.includes(a.terrain), l = () => {
		if (o.perTerrain) {
			let e = We(o, a);
			return r.counts[e] < (o.perTerrain[e] ?? 0);
		}
		return !0;
	}, u = r.placed.length === 0, d = r.placed[r.placed.length - 1], f = d ? i.index.get(d) : void 0, p = r.placed.map((e) => i.index.get(e));
	if (o.kind === "pool") {
		if (!c || !l()) return !1;
		if (o.region && !u) {
			let e = F(i), t = e.of.get(r.placed[0]);
			if (e.of.get(O(a)) !== t) return !1;
		}
		return G(t, i, a);
	}
	if (o.kind === "path") return c ? u ? G(t, i, a) : !!f && A(f).some((e) => O(e) === O(a)) : !1;
	if (o.kind === "line") return c ? u ? G(t, i, a) : p.some((e) => A(e).some((e) => O(e) === O(a))) ? j([...p, a]) : !1 : !1;
	if (o.kind === "twoVillageLine") {
		if (!c) return !1;
		if (u) {
			if (!G(t, i, a)) return !1;
		} else if (!p.some((e) => A(e).some((e) => O(e) === O(a)))) return !1;
		if (!j([...p, a])) return !1;
		let e = new Set(Object.keys(t.marks).filter((e) => t.marks[e] === "village")), n = /* @__PURE__ */ new Set();
		for (let t of [...p, a]) for (let r of A(t)) {
			let t = O(r);
			e.has(t) && n.add(t);
		}
		return n.size >= 2;
	}
	if (o.kind === "anchorAdj") {
		if (u) return (a.terrain === o.anchor || s) && G(t, i, a);
		let e = r.anchorCell ? i.index.get(r.anchorCell) : void 0;
		return !!e && A(e).some((e) => O(e) === O(a));
	}
	if (o.kind === "anchorLine") return u ? (a.terrain === o.anchor || s) && G(t, i, a) : !f || !A(f).some((e) => O(e) === O(a)) ? !1 : j([...p, a]);
	if (o.kind === "seaThenCoin") {
		let e = r.counts.sea, n = r.placed.length - e;
		return !n && a.terrain === "sea" && e < (o.seaMax ?? 4) && G(t, i, a) ? !0 : (a.coins ?? 0) > 0 && n < (o.coinMax ?? 2) && p.some((e) => e.terrain === "sea" && A(e).some((e) => O(e) === O(a)));
	}
	if (o.kind === "seaThenCity") {
		let e = r.counts.sea;
		return a.terrain === "sea" && e < (o.seaMax ?? 4) && G(t, i, a) ? !0 : a.city ? p.some((e) => e.terrain === "sea" && A(e).some((e) => O(e) === O(a))) : !1;
	}
	return !1;
}
function Ke(e) {
	return Me[Math.min(e - 1, 3)];
}
function qe(e, t) {
	if (e.treasureDeck.length === 0) return;
	let n = e.treasureDeck.pop(), r = ke[n];
	r.kind === "coins" ? (t.coins += r.n ?? 2, e.treasureDeck.unshift(n)) : r.kind === "explorer" ? (e.treasureDeck.unshift(n), e.pendingQueue.push({
		kind: "treasureExplorer",
		rid: t.rid
	})) : t.treasures.push({
		kind: r.kind,
		terrain: r.terrain,
		per: r.per
	});
}
function Je(e, t, n, r) {
	let i = O(n);
	if (t.explored.includes(i) || t.explored.push(i), n.discovery) {
		delete t.marks[i], t.marks[i] = "tower";
		let n = Object.values(t.marks).filter((e) => e === "tower").length;
		t.coins += Ke(n), e.last = {
			rid: t.rid,
			cells: [i],
			kind: "tower",
			serial: ++e.serial
		};
		return;
	}
	if (n.crystal ? (t.marks[i] = "explorer", t.crystals.includes(i) || (t.coins += n.crystal + t.crystalSum, t.crystalSum += n.crystal, t.crystals.push(i))) : t.marks[i] = "explorer", n.coins) {
		let e = 1;
		r.coinMult && r.coinTerrains && r.coinTerrains.includes(n.terrain) && (e = r.coinMult), t.coins += n.coins * e;
	}
	n.ruin && !t.looted.includes(i) && (t.looted.push(i), qe(e, t), r.extraTreasurePerRuin && qe(e, t)), N(n) && Ye(e, t, n);
}
function Ye(e, t, n) {
	let r = H(e), i = F(r), a = i.of.get(O(n));
	if (a === void 0) return;
	let o = i.list[a];
	if (o.some((e) => t.marks[e] === "village") || !o.every((e) => !!t.marks[e])) return;
	let s = o.filter((e) => {
		let n = r.index.get(e);
		return n && P(n) && t.marks[e] === "explorer";
	});
	s.length && e.pendingQueue.push({
		kind: "village",
		rid: t.rid,
		region: o,
		cells: s
	});
}
function K(e, t) {
	if (e.pendingQueue.some((e) => e.kind === "post")) return;
	let n = H(e), r = Ue(n), i = /* @__PURE__ */ new Set();
	for (let e of Object.keys(t.marks)) (t.marks[e] === "explorer" || t.marks[e] === "village") && i.add(e);
	r && i.add(r);
	let a = /* @__PURE__ */ new Set();
	for (let r of i) {
		if (a.has(r)) continue;
		let o = [r];
		a.add(r);
		let s = [];
		for (; o.length;) {
			let e = o.pop();
			s.push(e);
			let t = n.index.get(e);
			if (t) for (let e of A(t)) {
				let t = O(e);
				i.has(t) && !a.has(t) && (a.add(t), o.push(t));
			}
		}
		let c = s.filter((e) => {
			let r = n.index.get(e);
			return r && r.city && !t.posts[e] && t.marks[e] === "explorer";
		});
		if (c.length >= 2) {
			e.pendingQueue.push({
				kind: "post",
				rid: t.rid,
				cities: [c[0], c[1]]
			});
			return;
		}
	}
}
function Xe(e, t) {
	let n = H(e);
	e.goals.forEach((r, i) => {
		if (t.goals.includes(i)) return;
		let a = be[n.id].find((e) => e.id === r.id);
		if (!a || !a.check(t, n)) return;
		let o;
		r.firstTurn === null ? (r.firstTurn = e.turnNo, r.completedBy = [t.rid], o = r.high) : r.firstTurn === e.turnNo && !r.completedBy.includes(t.rid) ? (r.completedBy.push(t.rid), o = r.high) : (r.completedBy.includes(t.rid) || r.completedBy.push(t.rid), o = r.low), t.coins += o, t.goals.push(i), e.last = {
			rid: t.rid,
			cells: [],
			kind: "goal",
			serial: ++e.serial
		};
	});
}
function q(e) {
	for (let t = 0; t < 400; t++) {
		if (e.phase === "done") return;
		if (e.pendingQueue.length) {
			e.phase = "decide";
			return;
		}
		if (e.phase = "turn", e.cur && (e.cur.ended || e.cur.placed.length >= He(e.cur))) {
			ze(e);
			continue;
		}
		return;
	}
}
function Ze(e, t, n) {
	if (e.phase === "done") return V("done");
	let r = structuredClone(e), i = r.players.find((e) => e.rid === n.by);
	if (!i) return V("seat");
	if (t.type === "decide") {
		let e = r.pendingQueue[0];
		if (r.phase !== "decide" || !e || e.rid !== n.by) return V("notDecider");
		if (t.choice === "investigate") {
			if (e.kind !== "investigate" || t.card === void 0 || !e.options.includes(t.card)) return V("badChoice");
			let n = e.options.find((e) => e !== t.card);
			return i.investigate[e.slot] = t.card, n !== void 0 && r.investigateDeck.unshift(n), r.pendingQueue.shift(), r.last = {
				rid: i.rid,
				cells: [],
				kind: "era",
				serial: ++r.serial
			}, r.cur = W(i, z(t.card)), r.phase = "turn", { state: r };
		}
		if (t.choice === "useInvestigate") return e.kind !== "useInvestigate" || t.card === void 0 || !e.options.includes(t.card) ? V("badChoice") : (r.pendingQueue.shift(), r.cur = W(i, z(t.card)), r.phase = "turn", { state: r });
		if (t.choice === "village") {
			if (e.kind !== "village" || !t.cell) return V("badChoice");
			let n = O(t.cell);
			return e.cells.includes(n) ? (i.marks[n] = "village", i.coins += je[r.era - 1], r.pendingQueue.shift(), r.last = {
				rid: i.rid,
				cells: [n],
				kind: "village",
				serial: ++r.serial
			}, Xe(r, i), K(r, i), q(r), { state: r }) : V("badChoice");
		}
		if (t.choice === "post") {
			if (e.kind !== "post" || !t.cell) return V("badChoice");
			let n = O(t.cell);
			if (!e.cities.includes(n)) return V("badChoice");
			let a = H(r), o = a.index.get(e.cities[0]), s = a.index.get(e.cities[1]);
			if (!o || !s) return V("badChoice");
			let c = (o.city ?? 0) * (s.city ?? 0);
			return i.posts[n] = a.index.get(n)?.terrain ?? "grass", i.coins += c, i.bestRoute = Math.max(i.bestRoute, c), r.pendingQueue.shift(), r.last = {
				rid: i.rid,
				cells: [n],
				kind: "post",
				serial: ++r.serial
			}, Xe(r, i), K(r, i), q(r), { state: r };
		}
		if (t.choice === "treasureExplorer") {
			if (e.kind !== "treasureExplorer" || !t.cell) return V("badChoice");
			let n = H(r), a = n.index.get(O(t.cell));
			return !a || a.volcano || a.reef || a.capital || i.marks[O(a)] || !G(i, n, a) ? V("badChoice") : (r.pendingQueue.shift(), i.marks[O(a)] = "explorer", i.explored.includes(O(a)) || i.explored.push(O(a)), Je(r, i, a, {
				kind: "pool",
				allow: [a.terrain],
				max: 1
			}), Xe(r, i), K(r, i), q(r), { state: r });
		}
		return V("badChoice");
	}
	if (t.type === "endExplore") return r.phase !== "turn" || !r.cur || r.cur.rid !== n.by ? V("notActor") : (r.cur.ended = !0, q(r), { state: r });
	if (t.type === "place") {
		if (r.phase !== "turn" || !r.cur || r.cur.rid !== n.by) return V("notActor");
		let e = H(r).index.get(O(t.cell));
		if (!e || !Ge(r, i, e)) return V("illegal");
		let a = r.cur, o = We(a.spec, e);
		return i.marks[O(e)] = "explorer", a.placed.push(O(e)), a.counts[o] = (a.counts[o] ?? 0) + 1, (a.spec.kind === "anchorAdj" || a.spec.kind === "anchorLine") && (a.anchorCell ||= O(e)), r.last = {
			rid: i.rid,
			cells: [O(e)],
			kind: "explore",
			serial: ++r.serial
		}, Je(r, i, e, a.spec), Xe(r, i), K(r, i), q(r), { state: r };
	}
	return V("action");
}
function Qe(e) {
	let t = e.pendingQueue[0] ?? null;
	return {
		public: {
			map: e.config.map,
			solo: e.config.solo,
			phase: e.phase,
			era: e.era,
			round: e.round,
			deckCount: e.deck.length,
			investigateCount: e.investigateDeck.length,
			card: e.card,
			actor: e.phase === "done" ? null : e.players[e.actor]?.rid ?? null,
			turnNo: e.turnNo,
			players: e.players,
			goals: e.goals,
			pending: t,
			cur: e.cur,
			last: e.last
		},
		private: {}
	};
}
function J(e, t) {
	let n = e.coins, r = 0;
	for (let i of e.treasures) i.kind === "vase" ? r++ : i.kind === "village_terrain" ? n += Object.keys(e.marks).filter((n) => e.marks[n] === "village" && t.index.get(n)?.terrain === i.terrain).length : i.kind === "per_towers" ? n += Object.values(e.marks).filter((e) => e === "tower").length : i.kind === "per_settlements" && (n += Math.floor(Object.values(e.marks).filter((e) => e === "village").length / (i.per ?? 2)));
	return n += Oe(r), n;
}
function $e(e) {
	let t = D[e.config.map], n = Object.fromEntries(e.players.map((n) => [n.rid, e.phase === "done" ? J(n, t) : n.coins]));
	if (e.phase !== "done") return {
		phase: e.phase,
		scores: n
	};
	let r = (e) => Object.values(e.marks).filter((e) => e === "tower").length, i = (e) => Object.values(e.marks).filter((e) => e === "village").length, a = [...e.players].sort((e, n) => J(n, t) - J(e, t) || r(n) - r(e) || i(n) - i(e)), o = J(a[0], t);
	return {
		phase: "done",
		scores: n,
		ranking: a.map((e) => e.rid),
		winner: a.filter((e) => J(e, t) === o).map((e) => e.rid)
	};
}
var et = {
	meta: ae,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ie,
		publicView: C,
		privateView: w,
		config: y
	},
	setup: Ie,
	reduce: Ze,
	viewFor: Qe,
	status: $e
};
function tt(e, t, n) {
	return Ge({
		cur: e.cur,
		config: {
			map: e.map,
			solo: e.solo
		}
	}, t, n);
}
function nt(e, t) {
	let n = D[e.map], r = n.cells.find((e) => e.capital), i = r ? O(r) : null;
	return n.cells.filter((e) => {
		let n = O(e);
		return e.volcano || e.reef || e.capital || t.marks[n] ? !1 : A(e).some((e) => {
			let n = O(e);
			if (n === i) return !0;
			let r = t.marks[n];
			return r === "village" || r === "explorer";
		});
	}).map(O);
}
//#endregion
//#region src/game/copy.ts
var rt = [
	"games.guildofmerchantexplorers.b0",
	"games.guildofmerchantexplorers.b1",
	"games.guildofmerchantexplorers.b2",
	"games.guildofmerchantexplorers.b3",
	"games.guildofmerchantexplorers.b4"
], Y = Array.from({ length: 28 }, (e, t) => `games.guildofmerchantexplorers.i${t}`), it = {
	avenia: "games.guildofmerchantexplorers.mapAvenia",
	aghon: "games.guildofmerchantexplorers.mapAghon",
	kazan: "games.guildofmerchantexplorers.mapKazan",
	cnidaria: "games.guildofmerchantexplorers.mapCnidaria"
}, at = {
	"av-towers": "games.guildofmerchantexplorers.gAvTowers",
	"av-region5": "games.guildofmerchantexplorers.gAvRegion5",
	"av-lands": "games.guildofmerchantexplorers.gAvLands",
	"av-v5": "games.guildofmerchantexplorers.gAvV5",
	"av-borderruins": "games.guildofmerchantexplorers.gAvBorderRuins",
	"av-posts": "games.guildofmerchantexplorers.gAvPosts",
	"ag-mountain2": "games.guildofmerchantexplorers.gAgMountain2",
	"ag-three": "games.guildofmerchantexplorers.gAgThree",
	"ag-ruinterrains": "games.guildofmerchantexplorers.gAgRuinTerrains",
	"ag-route12": "games.guildofmerchantexplorers.gAgRoute12",
	"ag-villagetower": "games.guildofmerchantexplorers.gAgVillageTower",
	"ag-posterrains": "games.guildofmerchantexplorers.gAgPostTerrains",
	"kz-aj": "games.guildofmerchantexplorers.gKzAj",
	"kz-netowerC": "games.guildofmerchantexplorers.gKzNeTowerC",
	"kz-bd": "games.guildofmerchantexplorers.gKzBd",
	"kz-chain": "games.guildofmerchantexplorers.gKzChain",
	"kz-coins3": "games.guildofmerchantexplorers.gKzCoins3",
	"kz-villageruin": "games.guildofmerchantexplorers.gKzVillageRuin",
	"cn-crystalvillages": "games.guildofmerchantexplorers.gCnCrystalVillages",
	"cn-sameregion": "games.guildofmerchantexplorers.gCnSameRegion",
	"cn-shapes": "games.guildofmerchantexplorers.gCnShapes",
	"cn-sameshape3": "games.guildofmerchantexplorers.gCnSameShape3",
	"cn-route16": "games.guildofmerchantexplorers.gCnRoute16",
	"cn-crystal2": "games.guildofmerchantexplorers.gCnCrystal2"
}, ot = {
	grass: "#93A868",
	desert: "#DCC68E",
	mountain: "#B96F55",
	sea: "#8CA6A4"
};
function st(e, t, n) {
	return [
		0,
		60,
		120,
		180,
		240,
		300
	].map((r) => {
		let i = r * Math.PI / 180;
		return `${(e + Math.cos(i) * n).toFixed(2)},${(t + Math.sin(i) * n).toFixed(2)}`;
	}).join(" ");
}
function ct({ size: e = 15 }) {
	return /* @__PURE__ */ p("svg", {
		className: "goe-ico",
		width: e,
		height: e,
		viewBox: "0 0 16 16",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "8",
				cy: "8",
				r: "6.6",
				fill: "#DDB65C",
				stroke: "#77551E",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "8",
				cy: "8",
				r: "4.5",
				fill: "none",
				stroke: "#F8E8B6",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8 5.2l.9 1.9 2 .3-1.45 1.4.35 2-1.8-.95-1.8.95.35-2L5.1 7.4l2-.3z",
				fill: "#8A6423"
			})
		]
	});
}
function lt({ size: e = 16, color: t = "#3F3020" }) {
	return /* @__PURE__ */ p("svg", {
		className: "goe-ico",
		width: e,
		height: e,
		viewBox: "0 0 16 16",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M2.4 7.4L8 2.6l5.6 4.8",
				fill: "none",
				stroke: t,
				strokeWidth: "1.4",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M4 7v6.2h8V7",
				fill: "#EFE0BC",
				stroke: t,
				strokeWidth: "1.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M7 13.2V9.6h2v3.6",
				fill: "none",
				stroke: t,
				strokeWidth: "1.1"
			})
		]
	});
}
function ut({ size: e = 16, color: t = "#3F3020" }) {
	return /* @__PURE__ */ p("svg", {
		className: "goe-ico",
		width: e,
		height: e,
		viewBox: "0 0 16 16",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M5 13.4V5.4h6v8",
				fill: "#EFE0BC",
				stroke: t,
				strokeWidth: "1.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M4.2 5.4h7.6L8 1.8z",
				fill: t
			}),
			/* @__PURE__ */ f("path", {
				d: "M7.2 13.4V10h1.6v3.4",
				fill: t,
				opacity: ".7"
			})
		]
	});
}
function dt({ size: e = 16, color: t = "#3F3020" }) {
	return /* @__PURE__ */ p("svg", {
		className: "goe-ico",
		width: e,
		height: e,
		viewBox: "0 0 16 16",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "8",
				cy: "8",
				r: "6.3",
				fill: "#5B4834",
				stroke: t,
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8 4.3l3.4 5.6H4.6z",
				fill: "#E9D6AE"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "8",
				cy: "8",
				r: "5",
				fill: "none",
				stroke: "#E9D6AE",
				strokeWidth: ".5",
				opacity: ".45"
			})
		]
	});
}
function ft({ className: e }) {
	return /* @__PURE__ */ p("svg", {
		className: e,
		viewBox: "0 0 100 100",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("g", {
				fill: "none",
				stroke: "#6B573A",
				strokeWidth: "1",
				children: [/* @__PURE__ */ f("circle", {
					cx: "50",
					cy: "50",
					r: "30",
					opacity: ".55"
				}), /* @__PURE__ */ f("circle", {
					cx: "50",
					cy: "50",
					r: "23",
					opacity: ".35",
					strokeDasharray: "2 3"
				})]
			}),
			/* @__PURE__ */ p("g", {
				fill: "#6B573A",
				children: [
					/* @__PURE__ */ f("path", { d: "M50 14l5 26-5 8-5-8z" }),
					/* @__PURE__ */ f("path", {
						d: "M50 86l-5-26 5-8 5 8z",
						opacity: ".55"
					}),
					/* @__PURE__ */ f("path", {
						d: "M14 50l26-5 8 5-8 5z",
						opacity: ".55"
					}),
					/* @__PURE__ */ f("path", {
						d: "M86 50l-26 5-8-5 8-5z",
						opacity: ".55"
					})
				]
			}),
			/* @__PURE__ */ f("circle", {
				cx: "50",
				cy: "50",
				r: "3",
				fill: "#8A2E34"
			}),
			/* @__PURE__ */ f("text", {
				x: "50",
				y: "9",
				textAnchor: "middle",
				fontSize: "8",
				fill: "#6B573A",
				fontFamily: "Georgia, serif",
				children: "N"
			})
		]
	});
}
var pt = {
	grass: "#5F7439",
	desert: "#A8873F",
	mountain: "#7C3D2B",
	sea: "#4E7070"
};
function mt(e, t, n, r) {
	let i = pt[e];
	return e === "grass" ? /* @__PURE__ */ f("path", {
		d: `M${t - r * .4} ${n + r * .26}l${r * .12}-${r * .36}M${t - r * .12} ${n + r * .3}l${r * .12}-${r * .42}M${t + r * .18} ${n + r * .24}l${r * .12}-${r * .32}`,
		fill: "none",
		stroke: i,
		strokeWidth: ".85",
		strokeLinecap: "round",
		opacity: ".72"
	}) : e === "desert" ? /* @__PURE__ */ f("path", {
		d: `M${t - r * .52} ${n + r * .1}q${r * .26}-${r * .3} ${r * .52} 0M${t - r * .32} ${n + r * .42}q${r * .24}-${r * .26} ${r * .48} 0`,
		fill: "none",
		stroke: i,
		strokeWidth: ".8",
		strokeLinecap: "round",
		opacity: ".7"
	}) : e === "mountain" ? /* @__PURE__ */ f("path", {
		d: `M${t - r * .58} ${n + r * .34}l${r * .36}-${r * .58} ${r * .36} ${r * .58}M${t - r * .04} ${n + r * .3}l${r * .22}-${r * .34} ${r * .22} ${r * .34}`,
		fill: "none",
		stroke: i,
		strokeWidth: ".85",
		strokeLinejoin: "round",
		opacity: ".8"
	}) : /* @__PURE__ */ f("path", {
		d: `M${t - r * .52} ${n + r * .08}q${r * .13}-${r * .14} ${r * .26} 0t${r * .26} 0M${t - r * .4} ${n + r * .38}q${r * .12}-${r * .12} ${r * .24} 0t${r * .24} 0`,
		fill: "none",
		stroke: i,
		strokeWidth: ".8",
		strokeLinecap: "round",
		opacity: ".7"
	});
}
function ht({ spec: e }) {
	let t = e.allow.length > 0 ? e.allow : ["grass"], n = e.kind === "line" || e.kind === "path" ? 3 : e.max >= 4 ? 4 : e.max >= 2 ? 2 : 1, r = {
		1: [[50, 42]],
		2: [[30, 42], [70, 42]],
		3: [
			[50, 26],
			[30, 56],
			[70, 56]
		],
		4: [
			[50, 22],
			[29, 44],
			[71, 44],
			[50, 66]
		]
	}, i = r[Math.min(4, Math.max(1, n))] ?? r[2], a = n === 1 ? 25 : n === 2 ? 22 : n === 3 ? 17.5 : 15, o = e.kind === "line" || e.kind === "path" || e.kind === "anchorLine";
	return /* @__PURE__ */ p("svg", {
		className: "goe-spec-art",
		viewBox: "0 0 100 84",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("defs", { children: /* @__PURE__ */ p("pattern", {
				id: "goe-art-stipple",
				width: "7",
				height: "7",
				patternUnits: "userSpaceOnUse",
				children: [/* @__PURE__ */ f("circle", {
					cx: "1.1",
					cy: "2",
					r: ".45",
					fill: "#7A5C33",
					opacity: ".55"
				}), /* @__PURE__ */ f("circle", {
					cx: "4.6",
					cy: "5.4",
					r: ".35",
					fill: "#7A5C33",
					opacity: ".38"
				})]
			}) }),
			/* @__PURE__ */ f("rect", {
				width: "100",
				height: "84",
				fill: "url(#goe-art-stipple)",
				opacity: ".33"
			}),
			/* @__PURE__ */ p("g", {
				stroke: "#8A6B3F",
				fill: "none",
				opacity: ".24",
				children: [/* @__PURE__ */ f("path", {
					d: "M4 76q24-8 46-2t46-6",
					strokeWidth: ".45"
				}), /* @__PURE__ */ f("path", {
					d: "M84 8L2 62M84 8L44 82M84 8L99 54M84 8L60 82",
					strokeWidth: ".3",
					opacity: ".7"
				})]
			}),
			o && i.length > 1 && /* @__PURE__ */ p("g", {
				stroke: "#6B573A",
				strokeWidth: "1.1",
				fill: "none",
				opacity: ".7",
				children: [/* @__PURE__ */ f("path", {
					d: `M${i[0][0]} ${i[0][1]} L${i[i.length - 1][0]} ${i[i.length - 1][1]}`,
					strokeDasharray: "2.4 2.2"
				}), /* @__PURE__ */ f("path", {
					d: `M${i[i.length - 1][0] - 3} ${i[i.length - 1][1] - 3.4}l3.4 3.4-4.6.8`,
					strokeLinecap: "round",
					strokeLinejoin: "round"
				})]
			}),
			i.map(([e, n], r) => {
				let i = t[r % t.length];
				return /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("polygon", {
						points: st(e, n, a),
						fill: ot[i],
						stroke: "#54432C",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ f("polygon", {
						points: st(e, n, a),
						fill: "none",
						stroke: "#FFF3D6",
						strokeWidth: ".55",
						opacity: ".4"
					}),
					/* @__PURE__ */ f("polygon", {
						points: st(e, n, a * .79),
						fill: "none",
						stroke: "#FFF3D6",
						strokeWidth: ".4",
						opacity: ".3"
					}),
					mt(i, e, n, a * .78)
				] }, r);
			}),
			e.kind === "anchorAdj" && /* @__PURE__ */ p("g", {
				stroke: "#6B573A",
				strokeWidth: "1.1",
				fill: "none",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ f("path", { d: "M50 3v9M46.4 7.6h7.2" }), /* @__PURE__ */ f("circle", {
					cx: "50",
					cy: "16.5",
					r: "1.5"
				})]
			}),
			e.coinMult && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("circle", {
					cx: "88",
					cy: "11",
					r: "7",
					fill: "#DDB65C",
					stroke: "#77551E",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "88",
					cy: "11",
					r: "5.2",
					fill: "none",
					stroke: "#F8E8B6",
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ p("text", {
					x: "88",
					y: "14",
					textAnchor: "middle",
					fontSize: "7",
					fontWeight: "700",
					fill: "#6B4A12",
					children: ["×", e.coinMult]
				})
			] })
		]
	});
}
function gt() {
	return /* @__PURE__ */ p("svg", {
		className: "goe-spec-art",
		viewBox: "0 0 100 84",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("defs", { children: [/* @__PURE__ */ p("pattern", {
				id: "goe-goal-stipple",
				width: "7",
				height: "7",
				patternUnits: "userSpaceOnUse",
				children: [/* @__PURE__ */ f("circle", {
					cx: "1.1",
					cy: "2",
					r: ".45",
					fill: "#7A5C33",
					opacity: ".5"
				}), /* @__PURE__ */ f("circle", {
					cx: "4.6",
					cy: "5.4",
					r: ".35",
					fill: "#7A5C33",
					opacity: ".32"
				})]
			}), /* @__PURE__ */ p("linearGradient", {
				id: "goe-goal-sky",
				x1: "0",
				y1: "0",
				x2: "0",
				y2: "1",
				children: [/* @__PURE__ */ f("stop", {
					offset: "0",
					stopColor: "#F4E6C0"
				}), /* @__PURE__ */ f("stop", {
					offset: "1",
					stopColor: "#E4CE9F"
				})]
			})] }),
			/* @__PURE__ */ f("rect", {
				width: "100",
				height: "84",
				fill: "url(#goe-goal-sky)"
			}),
			/* @__PURE__ */ f("rect", {
				width: "100",
				height: "84",
				fill: "url(#goe-goal-stipple)",
				opacity: ".4"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "74",
				cy: "18",
				r: "7.5",
				fill: "none",
				stroke: "#B99646",
				strokeWidth: ".7",
				opacity: ".55"
			}),
			/* @__PURE__ */ f("path", {
				d: "M74 12.5v11M68.5 18h11",
				stroke: "#B99646",
				strokeWidth: ".5",
				opacity: ".4"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 58q18-6 34-1t31-2 35 1v28H0z",
				fill: "#9FB4AE",
				opacity: ".55"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 62q18-5 34 0t31-2 35 2M8 70q14-4 27 0t26-1 24 1M14 78q12-3 23 0t22-1 20 1",
				fill: "none",
				stroke: "#5E7C7C",
				strokeWidth: ".7",
				opacity: ".55"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 56q20-9 40-4t28 0 32-7v22q-14 5-30 1t-30 0-24 5-16 1z",
				fill: "#DCC68E",
				opacity: ".85"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 56q20-9 40-4t28 0 32-7",
				fill: "none",
				stroke: "#8A6B3F",
				strokeWidth: ".7",
				opacity: ".6"
			}),
			/* @__PURE__ */ p("g", {
				stroke: "#5A4327",
				strokeWidth: ".6",
				fill: "#EFE0BC",
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ f("path", { d: "M51 55v-9h8v9M49 46l6-5 6 5" }),
					/* @__PURE__ */ f("path", { d: "M60 55V40h4v15M59 40l3-3.5 3 3.5" }),
					/* @__PURE__ */ f("path", {
						d: "M55.5 55v-4.5h2V55",
						fill: "none"
					})
				]
			}),
			/* @__PURE__ */ p("g", {
				fill: "#E2BC64",
				stroke: "#7A571F",
				strokeWidth: ".6",
				children: [
					/* @__PURE__ */ f("circle", {
						cx: "34",
						cy: "60",
						r: "2.4"
					}),
					/* @__PURE__ */ f("circle", {
						cx: "39.5",
						cy: "62",
						r: "2.4"
					}),
					/* @__PURE__ */ f("circle", {
						cx: "36.5",
						cy: "64.6",
						r: "2.4"
					})
				]
			}),
			/* @__PURE__ */ p("g", {
				stroke: "#5F7439",
				strokeWidth: ".8",
				fill: "none",
				strokeLinecap: "round",
				opacity: ".8",
				children: [/* @__PURE__ */ f("path", { d: "M8 46q-2 8 2 16M8 54l-4-3M8 58l-4-2M8 62l-3-1" }), /* @__PURE__ */ f("path", { d: "M92 46q2 8-2 16M92 54l4-3M92 58l4-2M92 62l3-1" })]
			}),
			/* @__PURE__ */ f("rect", {
				x: "2.5",
				y: "2.5",
				width: "95",
				height: "79",
				fill: "none",
				stroke: "#6E7F4A",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ f("path", {
				d: "M2.5 12V2.5h9.5M88 2.5h9.5V12M97.5 72v9.5H88M12 81.5H2.5V72",
				fill: "none",
				stroke: "#6E7F4A",
				strokeWidth: "1.6"
			})
		]
	});
}
function _t({ count: e, label: t }) {
	return /* @__PURE__ */ p("div", {
		className: "goe-deck",
		"aria-label": `${t} ${e}`,
		children: [
			/* @__PURE__ */ p("div", {
				className: "goe-deck-stack",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ f("i", {}),
					/* @__PURE__ */ f("i", {}),
					/* @__PURE__ */ f("i", {}),
					/* @__PURE__ */ f("span", {
						className: "goe-deck-face",
						children: /* @__PURE__ */ p("svg", {
							viewBox: "0 0 40 28",
							children: [
								/* @__PURE__ */ f("rect", {
									x: "2",
									y: "2",
									width: "36",
									height: "24",
									fill: "none",
									stroke: "#8A6B3F",
									strokeWidth: ".7",
									opacity: ".55"
								}),
								/* @__PURE__ */ f("circle", {
									cx: "20",
									cy: "14",
									r: "6.6",
									fill: "none",
									stroke: "#8A6B3F",
									strokeWidth: ".7",
									opacity: ".7"
								}),
								/* @__PURE__ */ f("circle", {
									cx: "20",
									cy: "14",
									r: "5",
									fill: "none",
									stroke: "#8A6B3F",
									strokeWidth: ".4",
									opacity: ".4",
									strokeDasharray: "1 1.4"
								}),
								/* @__PURE__ */ f("path", {
									d: "M20 7.4l1.7 5.9L20 14.9l-1.7-1.6z",
									fill: "#8A6B3F",
									opacity: ".75"
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ f("span", {
				className: "goe-deck-label",
				children: t
			}),
			/* @__PURE__ */ f("b", {
				className: "goe-deck-count",
				children: e
			})
		]
	});
}
function vt({ kind: e, band: t, tag: n, art: r, text: i, foot: a, ariaLabel: o, className: s, children: c }) {
	return /* @__PURE__ */ p("div", {
		className: `goe-cf goe-cf-${e}${s ? ` ${s}` : ""}`,
		role: "group",
		"aria-label": o,
		children: [
			/* @__PURE__ */ p("div", {
				className: "goe-cf-band",
				children: [/* @__PURE__ */ f("span", { children: t }), n && /* @__PURE__ */ f("em", { children: n })]
			}),
			r && /* @__PURE__ */ f("div", {
				className: "goe-cf-art",
				children: r
			}),
			/* @__PURE__ */ f("div", {
				className: "goe-cf-body",
				children: i
			}),
			a && /* @__PURE__ */ f("div", {
				className: "goe-cf-foot",
				children: a
			}),
			c,
			/* @__PURE__ */ f("i", {
				className: "goe-cf-corner tl",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ f("i", {
				className: "goe-cf-corner tr",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ f("i", {
				className: "goe-cf-corner bl",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ f("i", {
				className: "goe-cf-corner br",
				"aria-hidden": "true"
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
var yt = Math.sqrt(3), bt = {
	grass: "#9CAE71",
	desert: "#D9C187",
	mountain: "#BB7359",
	sea: "#93A9A6"
}, xt = {
	grass: "games.guildofmerchantexplorers.grass",
	desert: "games.guildofmerchantexplorers.desert",
	mountain: "games.guildofmerchantexplorers.mountain",
	sea: "games.guildofmerchantexplorers.sea"
}, X = [
	"I",
	"II",
	"III",
	"IV"
], St = [
	(e, t) => [e + 1, e % 2 == 0 ? t : t + 1],
	(e, t) => [e, t + 1],
	(e, t) => [e - 1, e % 2 == 0 ? t : t + 1],
	(e, t) => [e - 1, e % 2 == 0 ? t - 1 : t],
	(e, t) => [e, t - 1],
	(e, t) => [e + 1, e % 2 == 0 ? t - 1 : t]
], Ct = (e) => ({
	x: e.c * 1.5,
	y: e.r * yt + (e.c % 2 ? yt / 2 : 0)
});
function Z(e, t, n) {
	return [
		0,
		60,
		120,
		180,
		240,
		300
	].map((r) => {
		let i = r * Math.PI / 180;
		return `${(e + Math.cos(i) * n).toFixed(3)},${(t + Math.sin(i) * n).toFixed(3)}`;
	}).join(" ");
}
function wt(e, t, n) {
	return [
		0,
		60,
		120,
		180,
		240,
		300
	].map((r) => {
		let i = r * Math.PI / 180;
		return [e + Math.cos(i) * n, t + Math.sin(i) * n];
	});
}
function Tt(e, t) {
	if (e.card >= 0 && e.card <= 4) return t(rt[e.card]);
	if (e.card === 8) return t("games.guildofmerchantexplorers.iWhole");
	if (e.card >= 5 && e.card <= 7) {
		let n = e.players.find((t) => t.rid === e.actor) ?? e.players[0], r = e.card - 5, i = n?.investigate[r];
		return t(i == null ? "games.guildofmerchantexplorers.iWhole" : Y[i]);
	}
	return "";
}
function Et(e) {
	return e.card >= 0 && e.card <= 4 ? Te[e.card] : e.card === 8 ? {
		kind: "pool",
		allow: [
			"grass",
			"desert",
			"mountain"
		],
		max: 3
	} : e.card >= 5 && e.card <= 7 ? R[(e.players.find((t) => t.rid === e.actor) ?? e.players[0])?.investigate[e.card - 5] ?? 1] : Te[0];
}
function Dt(e, t) {
	let n = [t(xt[e.terrain])];
	return e.city && n.push(`${t("games.guildofmerchantexplorers.city")} ${e.city}`), e.crystal && n.push(`${t("games.guildofmerchantexplorers.crystal")} ${e.crystal}`), e.capital && n.push(t("games.guildofmerchantexplorers.capital")), e.volcano && n.push(t("games.guildofmerchantexplorers.volcano")), e.ruin && n.push(t("games.guildofmerchantexplorers.ruin")), e.discovery && n.push(t("games.guildofmerchantexplorers.discovery")), e.coins && n.push(`${t("games.guildofmerchantexplorers.coin")} ${e.coins}`), e.reef && n.push(t("games.guildofmerchantexplorers.reef")), n.join(" · ");
}
function Ot(e) {
	return /* @__PURE__ */ f(kt, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function kt({ pub: e, members: t, myRid: m, send: h }) {
	a();
	let g = s(), _ = o((e) => e.locale), v = D[e.map], y = e.players.find((e) => e.rid === m) ?? e.players[0], b = e.phase === "turn" && e.actor === m && !!e.cur, x = e.pending && e.pending.rid === m ? e.pending : null, [ee, te] = r(m), S = e.players.find((e) => e.rid === ee) ?? y, ne = e.players.findIndex((e) => e.rid === S?.rid), re = (b || !!x) && S?.rid === m, C = (e, n) => u[(t.find((t) => t.rid === e)?.colorIndex ?? n) % u.length], w = (e, n) => {
		let r = t.find((t) => t.rid === e);
		return r ? c(r, _ ?? "zh") : g(u[n % u.length].nameKey);
	}, T = n(() => {
		let t = /* @__PURE__ */ new Set();
		if (!re || !y) return t;
		if (x?.kind === "village") for (let e of x.cells) t.add(e);
		else if (x?.kind === "post") for (let e of x.cities) t.add(e);
		else if (x?.kind === "treasureExplorer") for (let n of nt(e, y)) t.add(n);
		else if (b) for (let n of v.cells) tt(e, y, n) && t.add(O(n));
		return t;
	}, [
		re,
		x,
		b,
		e,
		y,
		v
	]), ie = e.last;
	function ae(e) {
		let t = O(e);
		if (x?.kind === "village" && x.cells.includes(t)) return h({
			type: "decide",
			choice: "village",
			cell: e
		});
		if (x?.kind === "post" && x.cities.includes(t)) return h({
			type: "decide",
			choice: "post",
			cell: e
		});
		if (x?.kind === "treasureExplorer" && T.has(t)) return h({
			type: "decide",
			choice: "treasureExplorer",
			cell: e
		});
		if (b && T.has(t)) return h({
			type: "place",
			cell: e
		});
	}
	let E = n(() => {
		let e = Infinity, t = Infinity, n = -Infinity, r = -Infinity;
		for (let i of v.cells) {
			let { x: a, y: o } = Ct(i);
			e = Math.min(e, a - 1.1), n = Math.max(n, a + 1.1), t = Math.min(t, o - 1.1), r = Math.max(r, o + 1.1);
		}
		return {
			minX: e,
			minY: t,
			w: n - e,
			h: r - t
		};
	}, [v]), k = n(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of v.cells) e.set(O(t), t);
		let t = [];
		for (let n of v.cells) {
			if (n.terrain === "sea") continue;
			let { x: r, y: i } = Ct(n), a = wt(r, i, .985);
			St.forEach((r, i) => {
				let [o, s] = r(n.c, n.r), c = e.get(`${o},${s}`);
				(!c || c.terrain === "sea") && t.push({
					a: a[i],
					b: a[(i + 1) % 6]
				});
			});
		}
		return t;
	}, [v]), A = /* @__PURE__ */ f("div", {
		className: "goe-goalgrid",
		children: e.goals.map((t) => {
			let n = t.completedBy.length > 0, r = t.completedBy.map((t) => w(t, e.players.findIndex((e) => e.rid === t))).join(g("games.guildofmerchantexplorers.listSep"));
			return /* @__PURE__ */ f(vt, {
				kind: "goal",
				className: `goe-goal${n ? " goe-goal-done" : ""}`,
				band: g("games.guildofmerchantexplorers.goalCardLabel"),
				ariaLabel: `${g(at[t.id])} · ${g("games.guildofmerchantexplorers.coinHigh", { n: t.high })} / ${g("games.guildofmerchantexplorers.coinLow", { n: t.low })}${n ? ` · ${g("games.guildofmerchantexplorers.goalDoneBy")}: ${r}` : ""}`,
				art: /* @__PURE__ */ f(gt, {}),
				text: g(at[t.id]),
				foot: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
					className: "goe-cf-high",
					children: [/* @__PURE__ */ f(ct, { size: 13 }), t.high]
				}), /* @__PURE__ */ p("span", {
					className: "goe-cf-low",
					children: [/* @__PURE__ */ f(ct, { size: 12 }), t.low]
				})] }),
				children: n && /* @__PURE__ */ f("span", {
					className: "goe-goal-stamp",
					"aria-hidden": "true",
					children: "✓"
				})
			}, t.id);
		})
	}), oe = /* @__PURE__ */ f("div", {
		className: "goe-scores",
		children: e.players.map((n, r) => {
			let i = t.find((e) => e.rid === n.rid), a = C(n.rid, r), o = w(n.rid, r), s = Object.values(n.marks).filter((e) => e === "village").length, c = Object.values(n.marks).filter((e) => e === "tower").length, u = e.actor === n.rid;
			return /* @__PURE__ */ p("button", {
				className: `goe-score${S?.rid === n.rid ? " goe-score-focus" : ""}${u ? " goe-score-active" : ""}`,
				onClick: () => te(n.rid),
				"aria-label": o,
				children: [
					/* @__PURE__ */ f("span", {
						className: "goe-avatar",
						style: { borderColor: a.hex },
						children: /* @__PURE__ */ f("img", {
							src: l[(i?.avatar ?? r) % l.length],
							alt: "",
							draggable: !1
						})
					}),
					/* @__PURE__ */ p("span", {
						className: "goe-score-name",
						children: [o, u && /* @__PURE__ */ f("i", {
							className: "goe-score-turn",
							"aria-hidden": "true"
						})]
					}),
					/* @__PURE__ */ p("span", {
						className: "goe-score-coins",
						children: [/* @__PURE__ */ f(ct, { size: 14 }), /* @__PURE__ */ f("b", { children: n.coins })]
					}),
					/* @__PURE__ */ p("span", {
						className: "goe-score-mini",
						children: [
							/* @__PURE__ */ f(lt, { size: 14 }),
							s,
							/* @__PURE__ */ f(ut, { size: 14 }),
							c
						]
					})
				]
			}, n.rid);
		})
	}), se = Et(e), ce = /* @__PURE__ */ f(vt, {
		kind: "explore",
		className: "goe-explore-card",
		band: g("games.guildofmerchantexplorers.exploreCardLabel"),
		tag: e.card >= 5 ? X[Math.min(3, Math.max(0, e.card === 8 ? 0 : e.card - 5))] : void 0,
		ariaLabel: `${g("games.guildofmerchantexplorers.cardNow")}: ${Tt(e, g)}`,
		art: /* @__PURE__ */ f(ht, { spec: se }),
		text: Tt(e, g),
		foot: e.card >= 5 ? /* @__PURE__ */ f("span", {
			className: "goe-cf-era",
			children: e.card === 8 ? "I / II / III" : X[e.card - 5]
		}) : void 0
	}), j = /* @__PURE__ */ p("div", {
		className: "goe-era-record",
		children: [/* @__PURE__ */ f("span", {
			className: "goe-rail-label",
			children: g("games.guildofmerchantexplorers.eraCards")
		}), /* @__PURE__ */ f("div", {
			className: "goe-era-slots",
			children: [
				0,
				1,
				2
			].map((e) => {
				let t = y?.investigate?.[e];
				return /* @__PURE__ */ p("span", {
					className: `goe-era-slot${t == null ? " goe-era-empty" : ""}`,
					title: g(t == null ? "games.guildofmerchantexplorers.eraPending" : Y[t]),
					"aria-label": `${g("games.guildofmerchantexplorers.era")} ${X[e]} · ${g(t == null ? "games.guildofmerchantexplorers.eraPending" : Y[t])}`,
					children: [/* @__PURE__ */ f("i", { children: X[e] }), /* @__PURE__ */ f("b", { "aria-hidden": "true" })]
				}, e);
			})
		})]
	}), le = /* @__PURE__ */ p("div", {
		className: "goe-legend",
		children: [
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", {
				className: "goe-lg-city",
				children: "3"
			}), g("games.guildofmerchantexplorers.city")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { className: "goe-lg-coin" }), g("games.guildofmerchantexplorers.coin")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(dt, { size: 11 }), g("games.guildofmerchantexplorers.ruin")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(ut, { size: 11 }), g("games.guildofmerchantexplorers.towers")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { className: "goe-lg-crystal" }), g("games.guildofmerchantexplorers.crystal")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { className: "goe-lg-volcano" }), g("games.guildofmerchantexplorers.volcano")] }),
			/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { className: "goe-lg-reef" }), g("games.guildofmerchantexplorers.reef")] })
		]
	}), M = /* @__PURE__ */ p("div", {
		className: "goe-values",
		children: [
			/* @__PURE__ */ f("span", {
				className: "goe-values-title",
				children: g("games.guildofmerchantexplorers.valuesTitle")
			}),
			/* @__PURE__ */ p("div", {
				className: "goe-values-row",
				"aria-label": g("games.guildofmerchantexplorers.villageValues"),
				children: [
					/* @__PURE__ */ f(lt, { size: 13 }),
					/* @__PURE__ */ f("b", { children: "1 · 2 · 3 · 5" }),
					/* @__PURE__ */ f("em", { children: g("games.guildofmerchantexplorers.villages") })
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "goe-values-row",
				"aria-label": g("games.guildofmerchantexplorers.towerValues"),
				children: [
					/* @__PURE__ */ f(ut, { size: 13 }),
					/* @__PURE__ */ f("b", { children: "6 · 8 · 10 · 14" }),
					/* @__PURE__ */ f("em", { children: g("games.guildofmerchantexplorers.towers") })
				]
			})
		]
	}), N = /* @__PURE__ */ p("div", {
		className: "goe-actions",
		children: [
			/* @__PURE__ */ p("span", {
				className: "goe-bar-meta",
				children: [
					/* @__PURE__ */ f("i", { children: g("games.guildofmerchantexplorers.deck") }),
					/* @__PURE__ */ f("b", { children: e.deckCount }),
					/* @__PURE__ */ f("i", { children: g("games.guildofmerchantexplorers.treasureDeck") }),
					/* @__PURE__ */ f("b", { children: y?.treasures.length ?? 0 })
				]
			}),
			x?.kind === "village" && /* @__PURE__ */ f("p", {
				className: "goe-hint",
				children: g("games.guildofmerchantexplorers.chooseVillage")
			}),
			x?.kind === "post" && /* @__PURE__ */ f("p", {
				className: "goe-hint",
				children: g("games.guildofmerchantexplorers.choosePost")
			}),
			x?.kind === "treasureExplorer" && /* @__PURE__ */ f("p", {
				className: "goe-hint",
				children: g("games.guildofmerchantexplorers.chooseTreasure")
			}),
			!x && b && /* @__PURE__ */ p("div", {
				className: "goe-turnbar",
				children: [
					/* @__PURE__ */ p("span", {
						className: "goe-turn-count",
						children: [/* @__PURE__ */ f("span", { children: g("games.guildofmerchantexplorers.placed") }), /* @__PURE__ */ f("b", { children: e.cur?.placed.length ?? 0 })]
					}),
					/* @__PURE__ */ f("span", {
						className: "goe-turn-hint",
						children: g("games.guildofmerchantexplorers.placeHint")
					}),
					/* @__PURE__ */ f("button", {
						className: "goe-end",
						onClick: () => h({ type: "endExplore" }),
						children: g("games.guildofmerchantexplorers.endExplore")
					})
				]
			}),
			!x && !b && /* @__PURE__ */ f("p", {
				className: "goe-hint",
				children: e.actor ? `${g("games.guildofmerchantexplorers.turnOf", { name: w(e.actor, e.players.findIndex((t) => t.rid === e.actor)) })} · ${g("games.guildofmerchantexplorers.waiting")}` : g("games.guildofmerchantexplorers.waiting")
			})
		]
	}), P = x && (x.kind === "investigate" || x.kind === "useInvestigate") ? /* @__PURE__ */ f("div", {
		className: "goe-chooser pointer-events-auto",
		children: /* @__PURE__ */ p("div", {
			className: "goe-chooser-panel",
			children: [/* @__PURE__ */ f("p", {
				className: "goe-chooser-title",
				children: g(x.kind === "investigate" ? "games.guildofmerchantexplorers.chooseInvestigate" : "games.guildofmerchantexplorers.chooseUseInvestigate")
			}), /* @__PURE__ */ f("div", {
				className: "goe-chooser-cards",
				children: x.options.map((t) => /* @__PURE__ */ f("button", {
					className: "goe-chooser-card",
					onClick: () => h({
						type: "decide",
						choice: x.kind,
						card: t
					}),
					children: /* @__PURE__ */ f(vt, {
						kind: "investigate",
						band: g("games.guildofmerchantexplorers.investigateCardLabel"),
						art: /* @__PURE__ */ f(ht, { spec: R[t] }),
						text: g(Y[t]),
						foot: /* @__PURE__ */ f("span", {
							className: "goe-cf-era",
							children: X[Math.min(3, Math.max(0, t < 28 ? e.era - 1 : 0))]
						})
					})
				}, t))
			})]
		})
	}) : null, ue = /* @__PURE__ */ p("div", {
		className: "goe-charter",
		children: [
			/* @__PURE__ */ f(ft, { className: "goe-charter-emblem" }),
			/* @__PURE__ */ p("div", {
				className: "goe-charter-title",
				children: [/* @__PURE__ */ f("span", { children: g("games.guildofmerchantexplorers.guildCharter") }), /* @__PURE__ */ f("h1", { children: g("games.guildofmerchantexplorers.name") })]
			}),
			/* @__PURE__ */ p("div", {
				className: "goe-charter-meta",
				children: [
					/* @__PURE__ */ p("span", {
						className: "goe-era-chip",
						children: [/* @__PURE__ */ f("i", { children: g("games.guildofmerchantexplorers.era") }), /* @__PURE__ */ f("b", { children: X[e.era - 1] ?? e.era })]
					}),
					/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { children: g("games.guildofmerchantexplorers.round") }), /* @__PURE__ */ f("b", { children: e.round })] }),
					/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("i", { children: g("games.guildofmerchantexplorers.deck") }), /* @__PURE__ */ f("b", { children: e.deckCount })] }),
					/* @__PURE__ */ f("span", {
						className: "goe-charter-turn",
						children: e.actor ? w(e.actor, e.players.findIndex((t) => t.rid === e.actor)) : ""
					})
				]
			})
		]
	});
	return /* @__PURE__ */ f(i, {
		banner: ue,
		actions: N,
		actionsHeight: "h-24",
		overlay: P,
		className: "goe-root",
		children: /* @__PURE__ */ p("div", {
			className: "goe-table",
			children: [
				/* @__PURE__ */ p("aside", {
					className: "goe-rail",
					children: [
						/* @__PURE__ */ f("span", {
							className: "goe-rail-label",
							children: g("games.guildofmerchantexplorers.cardNow")
						}),
						ce,
						/* @__PURE__ */ f(_t, {
							count: e.deckCount,
							label: g("games.guildofmerchantexplorers.deck")
						}),
						/* @__PURE__ */ f(_t, {
							count: y?.treasures.length ?? 0,
							label: g("games.guildofmerchantexplorers.treasureDeck")
						}),
						j,
						le,
						/* @__PURE__ */ f("div", {
							className: "goe-rail-seal",
							"aria-hidden": "true",
							children: /* @__PURE__ */ f(ft, {})
						})
					]
				}),
				/* @__PURE__ */ p("section", {
					className: "goe-sheet",
					"aria-label": g("games.guildofmerchantexplorers.viewBoard"),
					children: [
						/* @__PURE__ */ p("div", {
							className: "goe-sheet-plate",
							children: [/* @__PURE__ */ f("span", { children: g(it[e.map]) }), /* @__PURE__ */ f("em", { children: g("games.guildofmerchantexplorers.mapSurvey") })]
						}),
						/* @__PURE__ */ f(ft, { className: "goe-sheet-rose" }),
						/* @__PURE__ */ p("svg", {
							className: "goe-board",
							viewBox: `${E.minX - .3} ${E.minY - .3} ${E.w + .6} ${E.h + .6}`,
							preserveAspectRatio: "xMidYMid meet",
							role: "group",
							"aria-label": g("games.guildofmerchantexplorers.viewBoard"),
							children: [
								/* @__PURE__ */ p("defs", { children: [
									/* @__PURE__ */ f("pattern", {
										id: "goe-p-grass",
										width: "0.66",
										height: "0.66",
										patternUnits: "userSpaceOnUse",
										children: /* @__PURE__ */ f("path", {
											d: "M0.16 0.44l0.06-0.14 0.06 0.14M0.34 0.5l0.06-0.12 0.06 0.12M0.5 0.3l0.05-0.1 0.05 0.1",
											fill: "none",
											stroke: "#6F8347",
											strokeWidth: "0.035",
											strokeLinecap: "round"
										})
									}),
									/* @__PURE__ */ f("pattern", {
										id: "goe-p-desert",
										width: "0.7",
										height: "0.7",
										patternUnits: "userSpaceOnUse",
										children: /* @__PURE__ */ f("path", {
											d: "M0.12 0.42q0.14-0.16 0.3 0M0.4 0.24q0.14-0.14 0.28 0M0.3 0.58q0.12-0.12 0.24 0",
											fill: "none",
											stroke: "#B79653",
											strokeWidth: "0.035",
											strokeLinecap: "round"
										})
									}),
									/* @__PURE__ */ f("pattern", {
										id: "goe-p-mountain",
										width: "0.8",
										height: "0.8",
										patternUnits: "userSpaceOnUse",
										children: /* @__PURE__ */ f("path", {
											d: "M0.1 0.5l0.16-0.26 0.16 0.26M0.42 0.56l0.14-0.22 0.14 0.22M0.28 0.3l0.08-0.1 0.08 0.1",
											fill: "none",
											stroke: "#8E4B37",
											strokeWidth: "0.04",
											strokeLinejoin: "round"
										})
									}),
									/* @__PURE__ */ f("pattern", {
										id: "goe-p-sea",
										width: "0.9",
										height: "0.9",
										patternUnits: "userSpaceOnUse",
										children: /* @__PURE__ */ f("path", {
											d: "M0.08 0.42q0.1-0.1 0.2 0t0.2 0M0.44 0.66q0.1-0.1 0.2 0t0.2 0M0.28 0.24q0.09-0.09 0.18 0",
											fill: "none",
											stroke: "#5E7C7C",
											strokeWidth: "0.05",
											strokeLinecap: "round"
										})
									}),
									/* @__PURE__ */ p("pattern", {
										id: "goe-p-grain",
										width: "1.3",
										height: "1.3",
										patternUnits: "userSpaceOnUse",
										children: [
											/* @__PURE__ */ f("circle", {
												cx: "0.22",
												cy: "0.3",
												r: "0.028",
												fill: "#5A4327",
												opacity: ".5"
											}),
											/* @__PURE__ */ f("circle", {
												cx: "0.86",
												cy: "0.66",
												r: "0.024",
												fill: "#FFF8E6",
												opacity: ".65"
											}),
											/* @__PURE__ */ f("circle", {
												cx: "0.5",
												cy: "1.02",
												r: "0.02",
												fill: "#5A4327",
												opacity: ".35"
											})
										]
									}),
									/* @__PURE__ */ f("filter", {
										id: "goe-soft",
										x: "-20%",
										y: "-20%",
										width: "140%",
										height: "140%",
										children: /* @__PURE__ */ f("feDropShadow", {
											dx: "0",
											dy: "0.06",
											stdDeviation: "0.08",
											floodColor: "#4B3A24",
											floodOpacity: "0.28"
										})
									})
								] }),
								/* @__PURE__ */ f("g", {
									filter: "url(#goe-soft)",
									children: v.cells.map((e) => {
										let t = O(e), { x: n, y: r } = Ct(e), i = T.has(t), a = ie?.cells.includes(t), o = (e.c * 7 + e.r * 13) % 5 - 2;
										return /* @__PURE__ */ p("g", {
											className: `goe-hex${i ? " goe-lit" : ""}${a ? " goe-fresh" : ""}`,
											onClick: () => ae(e),
											role: "button",
											"aria-disabled": !i && !a,
											"aria-label": `${Dt(e, g)}${i ? ` · ${g("games.guildofmerchantexplorers.placeHere")}` : ""}`,
											children: [
												/* @__PURE__ */ f("polygon", {
													points: Z(n, r, 1),
													fill: bt[e.terrain],
													stroke: "rgba(62,47,31,0.22)",
													strokeWidth: .028
												}),
												/* @__PURE__ */ f("polygon", {
													points: Z(n, r, 1),
													fill: `url(#goe-p-${e.terrain})`,
													stroke: "none",
													className: "goe-pattern"
												}),
												/* @__PURE__ */ f("polygon", {
													points: Z(n, r, 1),
													fill: o > 0 ? "#FFF8E6" : "#4A3A28",
													opacity: Math.abs(o) * .007,
													stroke: "none"
												}),
												/* @__PURE__ */ f("polygon", {
													points: Z(n, r, .965),
													fill: "none",
													stroke: "rgba(255,246,224,0.32)",
													strokeWidth: .022
												}),
												/* @__PURE__ */ f(At, {
													cell: e,
													x: n,
													y: r
												}),
												/* @__PURE__ */ f(jt, {
													mark: S?.marks[t],
													post: S?.posts[t],
													fresh: a,
													color: C(S?.rid ?? m, ne).hex,
													x: n,
													y: r
												}),
												i && /* @__PURE__ */ f("polygon", {
													points: Z(n, r, .93),
													className: "goe-target"
												}),
												a && /* @__PURE__ */ f("circle", {
													cx: n,
													cy: r,
													r: .9,
													className: "goe-ripple"
												})
											]
										}, t);
									})
								}),
								/* @__PURE__ */ f("rect", {
									x: E.minX - .3,
									y: E.minY - .3,
									width: E.w + .6,
									height: E.h + .6,
									fill: "url(#goe-p-grain)",
									opacity: ".55",
									pointerEvents: "none"
								}),
								/* @__PURE__ */ f("g", {
									className: "goe-coast",
									"aria-hidden": "true",
									children: k.map((e, t) => /* @__PURE__ */ f("line", {
										x1: e.a[0],
										y1: e.a[1],
										x2: e.b[0],
										y2: e.b[1]
									}, t))
								})
							]
						}),
						/* @__PURE__ */ f(ft, { className: "goe-compass" }),
						/* @__PURE__ */ p("div", {
							className: "goe-scale",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ f("i", {}),
								/* @__PURE__ */ f("i", {}),
								/* @__PURE__ */ f("i", {}),
								/* @__PURE__ */ f("i", {}),
								/* @__PURE__ */ f("i", {})
							]
						})
					]
				}),
				/* @__PURE__ */ p("aside", {
					className: "goe-ledger",
					children: [
						/* @__PURE__ */ p("header", {
							className: "goe-ledger-head",
							children: [/* @__PURE__ */ f("h2", { children: g("games.guildofmerchantexplorers.guildLedger") }), /* @__PURE__ */ f("span", { children: g("games.guildofmerchantexplorers.guildLedgerSub") })]
						}),
						oe,
						/* @__PURE__ */ p("div", {
							className: "goe-ledger-goals",
							children: [/* @__PURE__ */ f("h3", { children: g("games.guildofmerchantexplorers.goals") }), A]
						}),
						M,
						/* @__PURE__ */ p("div", {
							className: "goe-narrow-cards",
							children: [/* @__PURE__ */ f("span", {
								className: "goe-rail-label",
								children: g("games.guildofmerchantexplorers.cardNow")
							}), /* @__PURE__ */ p("div", {
								className: "goe-narrow-row",
								children: [ce, /* @__PURE__ */ f("div", {
									className: "goe-narrow-goals",
									children: A
								})]
							})]
						})
					]
				})
			]
		})
	});
}
function At({ cell: e, x: t, y: n }) {
	if (e.city) return /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("circle", {
			cx: t,
			cy: n,
			r: .62,
			fill: "#F8EFD9",
			stroke: "#44331F",
			strokeWidth: .05
		}),
		/* @__PURE__ */ f("circle", {
			cx: t,
			cy: n,
			r: .5,
			fill: "none",
			stroke: "#B99646",
			strokeWidth: .028
		}),
		/* @__PURE__ */ f("text", {
			x: t,
			y: n + .22,
			textAnchor: "middle",
			fontSize: .7,
			fontWeight: 700,
			fill: "#3B2C19",
			fontFamily: "Georgia, 'Songti SC', serif",
			children: e.city
		})
	] });
	if (e.crystal) return /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("polygon", {
			points: `${t},${n - .58} ${t + .34},${n - .16} ${t},${n + .58} ${t - .34},${n - .16}`,
			fill: "#C978B8",
			stroke: "#5E3A63",
			strokeWidth: .045
		}),
		/* @__PURE__ */ f("polygon", {
			points: `${t},${n - .58} ${t + .34},${n - .16} ${t},${n + .1}`,
			fill: "#E7A9DA",
			opacity: ".8"
		}),
		/* @__PURE__ */ f("text", {
			x: t,
			y: n + .05,
			textAnchor: "middle",
			fontSize: .5,
			fontWeight: 700,
			fill: "#4B2A50",
			children: e.crystal
		})
	] });
	if (e.capital) return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
		cx: t,
		cy: n,
		r: .54,
		fill: "#F8EFD9",
		stroke: "#7C2B33",
		strokeWidth: .05
	}), /* @__PURE__ */ f("path", {
		d: `M${t - .3} ${n + .12}l0-0.28 0.15 0.12 0.15-0.24 0.15 0.24 0.15-0.12 0 0.28z`,
		fill: "#B99646",
		stroke: "#7C5A1C",
		strokeWidth: .025,
		strokeLinejoin: "round"
	})] });
	if (e.volcano) return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("polygon", {
		points: `${t},${n - .5} ${t + .55},${n + .46} ${t - .55},${n + .46}`,
		fill: "#7E3020",
		stroke: "#4A2418",
		strokeWidth: .045,
		strokeLinejoin: "round"
	}), /* @__PURE__ */ f("path", {
		d: `M${t - .14} ${n - .2}l-0.08 0.34M${t + .12} ${n - .22}l0.1 0.3`,
		stroke: "#F0A648",
		strokeWidth: .05,
		strokeLinecap: "round"
	})] });
	if (e.ruin) {
		let r = e.ruin === "triangle" ? "▲" : e.ruin === "circle" ? "●" : e.ruin === "square" ? "■" : e.ruin === "sea" || e.ruin === "land" ? "⚓" : e.ruin;
		return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
			cx: t,
			cy: n,
			r: .4,
			fill: "#5B4834",
			stroke: "#2F2315",
			strokeWidth: .04
		}), /* @__PURE__ */ f("text", {
			x: t,
			y: n + .16,
			textAnchor: "middle",
			fontSize: .44,
			fontWeight: 700,
			fill: "#F2E2BF",
			children: r
		})] });
	}
	return e.discovery ? /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("path", {
			d: `M${t - .2} ${n + .36}l0-0.62 0.4 0 0 0.62z`,
			fill: "#EFE0BC",
			stroke: "#4A392A",
			strokeWidth: .04
		}),
		/* @__PURE__ */ f("path", {
			d: `M${t - .3} ${n - .24}l0.3-0.32 0.3 0.32z`,
			fill: "#B99646",
			stroke: "#4A392A",
			strokeWidth: .04,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ f("rect", {
			x: t - .06,
			y: n + .06,
			width: .12,
			height: .3,
			fill: "#4A392A"
		})
	] }) : e.coins ? /* @__PURE__ */ f("g", { children: Array.from({ length: e.coins }).map((r, i) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
		cx: t - (e.coins ? (e.coins - 1) * .15 : 0) + i * .3,
		cy: n + .52,
		r: .14,
		fill: "#E2BC64",
		stroke: "#7A571F",
		strokeWidth: .035
	}), /* @__PURE__ */ f("circle", {
		cx: t - (e.coins ? (e.coins - 1) * .15 : 0) + i * .3,
		cy: n + .52,
		r: .085,
		fill: "none",
		stroke: "#FFF0C0",
		strokeWidth: .025
	})] }, i)) }) : e.reef ? /* @__PURE__ */ f("g", { children: /* @__PURE__ */ f("path", {
		d: `M${t - .34} ${n + .1}q0.17-0.18 0.34 0t0.34 0M${t - .26} ${n + .3}q0.13-0.14 0.26 0t0.26 0`,
		fill: "none",
		stroke: "#3D5A58",
		strokeWidth: .05,
		strokeLinecap: "round"
	}) }) : null;
}
function jt({ mark: e, post: t, fresh: n, color: r, x: i, y: a }) {
	return /* @__PURE__ */ p("g", {
		className: n ? "goe-mark-fresh" : void 0,
		children: [
			e === "explorer" && /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
				cx: i,
				cy: a - .14,
				r: .27,
				fill: r,
				stroke: "#FFF6E2",
				strokeWidth: .05
			}), /* @__PURE__ */ f("circle", {
				cx: i - .08,
				cy: a - .22,
				r: .075,
				fill: "#FFF6E2",
				opacity: ".65"
			})] }),
			e === "village" && /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: `M${i - .34} ${a - .14}l0.34-0.34 0.34 0.34`,
					fill: "none",
					stroke: "#FFF6E2",
					strokeWidth: .1,
					strokeLinecap: "round",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ f("path", {
					d: `M${i - .32} ${a - .12}l0.32-0.32 0.32 0.32`,
					fill: "none",
					stroke: r,
					strokeWidth: .07,
					strokeLinecap: "round",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ f("rect", {
					x: i - .25,
					y: a - .14,
					width: .5,
					height: .46,
					rx: .04,
					fill: r,
					stroke: "#FFF6E2",
					strokeWidth: .05
				})
			] }),
			e === "tower" && /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("rect", {
				x: i - .13,
				y: a - .14,
				width: .26,
				height: .54,
				fill: r,
				stroke: "#FFF6E2",
				strokeWidth: .045
			}), /* @__PURE__ */ f("path", {
				d: `M${i - .27} ${a - .14}l0.27-0.3 0.27 0.3z`,
				fill: r,
				stroke: "#FFF6E2",
				strokeWidth: .045,
				strokeLinejoin: "round"
			})] }),
			t && /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("rect", {
				x: i - .17,
				y: a - .5,
				width: .34,
				height: .34,
				fill: bt[t],
				stroke: r,
				strokeWidth: .08,
				transform: `rotate(45 ${i} ${a - .33})`
			}), /* @__PURE__ */ f("circle", {
				cx: i,
				cy: a - .33,
				r: .05,
				fill: "#FFF6E2"
			})] })
		]
	});
}
//#endregion
//#region src/game/bot.ts
var Mt = [
	1,
	2,
	3,
	5
], Nt = [
	6,
	8,
	10,
	14
];
function Q(e) {
	let t = 2166136261;
	for (let n = 0; n < e.length; n++) t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
	return (t >>> 0) / 4294967295;
}
function Pt(e) {
	return Nt[Math.min(e - 1, 3)];
}
function $(e) {
	return e.kind === "anchorAdj" || e.kind === "anchorLine" ? 1 + e.max : e.kind === "seaThenCity" ? e.seaMax ?? 4 : e.perTerrain ? Object.values(e.perTerrain).reduce((e, t) => e + t, 0) : e.max;
}
function Ft(e, t, n, r) {
	let i = D[e.map], a = O(n), o = 0;
	if (n.coins && (o += n.coins * (n.terrain && r > 1 ? r : 1)), n.crystal && !t.crystals.includes(a) && (o += n.crystal + t.crystalSum + 3), n.discovery) {
		let e = Object.values(t.marks).filter((e) => e === "tower").length + 1;
		o += Pt(e) + 1;
	}
	if (n.ruin && (o += t.looted.includes(a) ? 0 : 6), n.city && (o += 1.5), n.terrain && !n.discovery && !n.crystal) {
		let n = F(i), r = n.of.get(a);
		if (r !== void 0) {
			let s = n.list[r], c = s.some((e) => t.marks[e] === "village");
			s.every((e) => e === a || !!t.marks[e]) && !c && s.some((e) => e === a || t.marks[e] === "explorer" && P(i.index.get(e))) ? o += Mt[e.era - 1] + 7 : o += .35;
		}
	}
	let s = 0;
	for (let e of A(n)) {
		let n = i.index.get(O(e));
		n && !t.marks[O(n)] && s++;
	}
	return o += s * .12, o += Q(a + e.round + e.actor) * .5, o;
}
var It = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = D[n.map];
	if (n.phase === "decide") {
		let e = n.pending;
		if (!e || e.rid !== t.rid) return null;
		if (e.kind === "investigate") return { action: {
			type: "decide",
			choice: "investigate",
			card: [...e.options].sort((e, t) => $(R[e]) - $(R[t]) || Q("i" + e) - Q("i" + t))[0]
		} };
		if (e.kind === "useInvestigate") return { action: {
			type: "decide",
			choice: "useInvestigate",
			card: [...e.options].sort((e, t) => $(R[e]) - $(R[t]) || Q("u" + e) - Q("u" + t))[0]
		} };
		if (e.kind === "village") {
			let t = e.cells[0], n = -1;
			for (let a of e.cells) {
				let e = i.index.get(a);
				if (!e) continue;
				let o = 0;
				for (let t of A(e)) {
					let e = i.index.get(O(t));
					e && !r.marks[O(e)] && (o += P(e) ? 1.4 : 1);
				}
				o += Q(a) * .3, o > n && (n = o, t = a);
			}
			return { action: {
				type: "decide",
				choice: "village",
				cell: k(t)
			} };
		}
		if (e.kind === "post") {
			let t = /* @__PURE__ */ new Set();
			if (n.map === "aghon") for (let e of [
				"grass",
				"desert",
				"mountain"
			]) Object.values(r.posts).includes(e) || t.add(e);
			let a = e.cities[0], o = -1;
			for (let n of e.cities) {
				let e = i.index.get(n);
				if (!e) continue;
				let r = (e.city ?? 0) + (t.has(e.terrain) ? 5 : 0);
				r > o && (o = r, a = n);
			}
			return { action: {
				type: "decide",
				choice: "post",
				cell: k(a)
			} };
		}
		if (e.kind === "treasureExplorer") {
			let e = nt(n, r);
			if (!e.length) return null;
			let t = e[0], a = -1e9;
			for (let o of e) {
				let e = i.index.get(o);
				if (!e) continue;
				let s = Ft(n, r, e, 1);
				s > a && (a = s, t = o);
			}
			return { action: {
				type: "decide",
				choice: "treasureExplorer",
				cell: k(t)
			} };
		}
		return null;
	}
	if (n.phase === "turn" && n.actor === t.rid && n.cur) {
		let e = n.cur.spec.coinMult && n.cur.spec.coinTerrains ? n.cur.spec.coinMult : 1, t = i.cells.filter((e) => tt(n, r, e));
		if (!t.length) return { action: { type: "endExplore" } };
		let a = t[0], o = -1e9;
		for (let i of t) {
			let t = Ft(n, r, i, e);
			t > o && (o = t, a = i);
		}
		return { action: {
			type: "place",
			cell: {
				c: a.c,
				r: a.r
			}
		} };
	}
	return null;
};
//#endregion
//#region src/game/game-over.tsx
function Lt(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) return {
		coins: 0,
		villages: 0,
		towers: 0,
		crystals: 0,
		treasures: 0,
		goals: 0,
		bonus: 0,
		total: 0
	};
	let r = Object.values(n.marks).filter((e) => e === "village").length, i = Object.values(n.marks).filter((e) => e === "tower").length, a = J(n, D[e.map]);
	return {
		coins: n.coins,
		villages: r,
		towers: i,
		crystals: n.crystalSum,
		treasures: n.treasures.length,
		goals: e.goals.filter((e) => e.completedBy.includes(t)).length,
		bonus: a - n.coins,
		total: a
	};
}
function Rt({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let d = s(), h = o((e) => e.locale), g = C.safeParse(t), _ = g.success ? g.data : null, v = i ?? a, y = (e, t) => u[(n.find((t) => t.rid === e)?.colorIndex ?? t) % u.length], b = (e, t) => {
		let r = n.find((t) => t.rid === e);
		return r ? c(r, h ?? "zh") : d(u[t % u.length].nameKey);
	}, x = e.winner;
	return /* @__PURE__ */ p("div", {
		className: "goe-over",
		style: { "--goe-card-w": "clamp(112px, 9vw, 168px)" },
		children: [e.winner.length > 0 && /* @__PURE__ */ f(m, {}), /* @__PURE__ */ p("div", {
			className: "goe-report",
			children: [
				/* @__PURE__ */ f("span", {
					className: "goe-seal",
					"aria-hidden": "true",
					children: /* @__PURE__ */ f("b", { children: "✦" })
				}),
				/* @__PURE__ */ p("header", {
					className: "goe-report-head",
					children: [
						/* @__PURE__ */ f("span", {
							className: "goe-report-kicker",
							children: d("games.guildofmerchantexplorers.guildCharter")
						}),
						/* @__PURE__ */ f("h1", { children: d("games.guildofmerchantexplorers.reportTitle") }),
						_ && /* @__PURE__ */ p("p", { children: [
							d(it[_.map]),
							" · ",
							d("games.guildofmerchantexplorers.reportSubtitle")
						] })
					]
				}),
				x.length > 0 && /* @__PURE__ */ p("div", {
					className: "goe-pennant",
					children: [
						/* @__PURE__ */ f("span", {
							className: "goe-pennant-label",
							children: d("games.guildofmerchantexplorers.reportChampion")
						}),
						/* @__PURE__ */ f("div", {
							className: "goe-pennant-who",
							children: x.map((t) => {
								let r = e.ranking.indexOf(t), i = n.find((e) => e.rid === t), a = y(t, r);
								return /* @__PURE__ */ p("span", {
									className: "goe-pennant-player",
									children: [/* @__PURE__ */ f("span", {
										className: "goe-avatar",
										style: { borderColor: a.hex },
										children: /* @__PURE__ */ f("img", {
											src: l[(i?.avatar ?? r) % l.length],
											alt: "",
											draggable: !1
										})
									}), /* @__PURE__ */ f("b", { children: b(t, r) })]
								}, t);
							})
						}),
						/* @__PURE__ */ f("span", {
							className: "goe-pennant-crown",
							"aria-hidden": "true",
							children: "♛"
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: "goe-report-ledger",
					children: [/* @__PURE__ */ f("span", {
						className: "goe-report-ledger-title",
						children: d("games.guildofmerchantexplorers.reportLedger")
					}), /* @__PURE__ */ f("ol", {
						className: "goe-over-list",
						children: e.ranking.map((t, i) => {
							let a = n.find((e) => e.rid === t), o = y(t, i), s = e.winner.includes(t), c = _ ? Lt(_, t) : null;
							return /* @__PURE__ */ p("li", {
								className: `goe-over-row${s ? " goe-over-won" : ""}`,
								children: [
									/* @__PURE__ */ p("div", {
										className: "goe-over-rank",
										"aria-label": d("games.guildofmerchantexplorers.resultRank", { n: i + 1 }),
										children: [/* @__PURE__ */ f("span", { children: s ? "★" : i + 1 }), /* @__PURE__ */ f("em", { children: d("games.guildofmerchantexplorers.resultRank", { n: i + 1 }) })]
									}),
									/* @__PURE__ */ p("div", {
										className: "goe-over-who",
										children: [/* @__PURE__ */ f("span", {
											className: "goe-avatar",
											style: { borderColor: o.hex },
											children: a && /* @__PURE__ */ f("img", {
												src: l[a.avatar % l.length],
												alt: "",
												draggable: !1
											})
										}), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("strong", { children: [b(t, i), t === r && /* @__PURE__ */ f("small", { children: d("lobby.you") })] }), /* @__PURE__ */ p("span", {
											className: "goe-over-total",
											children: [
												d("games.guildofmerchantexplorers.total"),
												" ",
												/* @__PURE__ */ f("b", { children: c?.total ?? e.scores?.[t] ?? 0 })
											]
										})] })]
									}),
									c && /* @__PURE__ */ p("dl", {
										className: "goe-over-breakdown",
										children: [
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.coins") }), /* @__PURE__ */ f("dd", { children: c.coins })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.villages") }), /* @__PURE__ */ f("dd", { children: c.villages })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.towers") }), /* @__PURE__ */ f("dd", { children: c.towers })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.resultTreasureBonus") }), /* @__PURE__ */ p("dd", { children: ["+", c.bonus] })] }),
											/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.resultGoalsDone") }), /* @__PURE__ */ p("dd", { children: [
												c.goals,
												" / ",
												_?.goals.length ?? 3
											] })] }),
											c.crystals > 0 && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("dt", { children: d("games.guildofmerchantexplorers.crystal") }), /* @__PURE__ */ f("dd", { children: c.crystals })] })
										]
									})
								]
							}, t);
						})
					})]
				}),
				/* @__PURE__ */ f("p", {
					className: "goe-over-tie",
					children: d("games.guildofmerchantexplorers.resultTiebreak")
				}),
				v ? /* @__PURE__ */ p("div", {
					className: "goe-over-controls",
					children: [i && /* @__PURE__ */ f("button", {
						type: "button",
						className: "goe-over-primary",
						onClick: i,
						children: d("session.result.playAgain")
					}), a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "goe-over-quiet",
						onClick: a,
						children: d("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ f("p", {
					className: "goe-over-wait",
					children: d("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region src/game/types.ts
var zt = [
	"avenia",
	"aghon",
	"kazan",
	"cnidaria"
];
//#endregion
//#region src/game/options.tsx
function Bt({ value: e, onChange: t }) {
	let n = s(), r = y.safeParse(e), i = r.success ? r.data : y.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: /* @__PURE__ */ f(g, {
			title: n("games.guildofmerchantexplorers.selectMap"),
			children: zt.map((e) => /* @__PURE__ */ f(h, {
				name: "goe-map",
				value: e,
				checked: i.map === e,
				label: n(it[e]),
				accent: ae.accent,
				onChange: () => t({
					...i,
					map: e
				})
			}, e))
		})
	});
}
//#endregion
//#region src/game/guide.tsx
function Vt() {
	let e = s();
	return /* @__PURE__ */ p("div", {
		className: "goe-guide",
		children: [
			/* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: e("games.guildofmerchantexplorers.rulesTitle") }), /* @__PURE__ */ f("p", { children: e("games.guildofmerchantexplorers.rules") })] }),
			/* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: e("games.guildofmerchantexplorers.cardNow") }), /* @__PURE__ */ f("ul", { children: rt.map((t) => /* @__PURE__ */ f("li", { children: e(t) }, t)) })] }),
			/* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: e("games.guildofmerchantexplorers.investigated") }), /* @__PURE__ */ f("ul", { children: Y.map((t) => /* @__PURE__ */ f("li", { children: e(t) }, t)) })] })
		]
	});
}
//#endregion
//#region src/index.tsx
var Ht = {
	definition: et,
	View: Ot,
	bot: It,
	OverView: Rt,
	Options: Bt,
	Guide: Vt,
	locales: {
		zh: {
			name: "提戈梅公会",
			desc: "在提戈梅王国的四方疆域中远航探索，开辟村庄、打通贸易路线、寻访发现塔，四个时代后金币最多者获胜。",
			rules: "目标：\n在四个时代中探索提戈梅王国的疆域，通过发现村庄、打通贸易路线、寻访发现塔与收集宝物赚取金币。四个时代结束后，金币最多的玩家获胜。\n\n回合流程：\n每个时代由若干回合组成，回合数等于探索牌堆的牌数。每回合由一名玩家翻开探索牌堆顶的一张牌，所有玩家同时按照这张牌的指示，在自己的地图上放置探索者。所有玩家完成本次探索并结算地图要素后，再翻开下一张牌。\n\n探索者放置：\n探索者必须放在与你的村庄、首都或已放置的探索者相邻的空格上，并且该格不能已有探索者、村庄或发现塔。你始终逐个放置探索者，可以少放，但不能把未使用的部分保留到之后的回合。首都始终可以作为探索起点，它在探索时视同村庄，但不计入村庄类目标。\n\n黄金探索法则：\n一、每个探索者都必须与你的村庄或探索者相邻，且目标格不能已有探索者、村庄或发现塔。\n二、始终逐个放置探索者。\n三、一旦满足条件就立即结算地图要素，即使本次探索尚未完成；结算之后再继续完成探索。\n四、除非探索牌明确要求相邻或特定排列，否则每个新探索者可以放在地图上任何与村庄或探索者相邻的位置。\n五、你可以少放探索者，但必须遵守探索牌的相邻或连接规则，且不能把未使用的部分留到以后的回合。\n\n地图要素：\n地图有草原、沙漠、山地与海洋四种地形。同一种地形相连的格组成一个区域。每张地图上的首都格是你最初的探索起点，首都格本身不能被探索。\n\n村庄：\n当你在一个时代内完整探索了一个区域，也就是该区域内所有格（包括城市）都放有探索者时，必须立即用一个村庄替换该区域某个空白格上的探索者，并按当前时代在分值区获得金币：第一、二、三、四时代分别获得 1、2、3、5 枚金币。每个区域最多只能有 1 座村庄，且只有空白格可以建村。海洋、遗迹和发现格不属于任何区域。\n\n金币格：\n探索金币格时，立即获得该格所示数量的金币。金币格在之后的时代可以再次探索，并再次获得金币。\n\n遗迹格：\n首次探索遗迹格时，把一个宝物标记放在该格上，并立即从宝物牌堆抽一张宝物卡结算其即时效果。没有即时效果的宝物卡留到终局计分。之后再次探索同一遗迹格，不会再抽宝物卡。终局计分时，按定居点计分的宝物卡把每座村庄视为一个定居点：每凑齐 2 个定居点，可以获得 1 枚金币，不足 2 个的部分不计分；按发现塔计分的宝物卡统计你的每一座发现塔。\n\n城市与贸易路线：\n当两座城市通过由探索者、村庄和／或首都组成的不间断链条相连，并且这两座城市都没有贸易站时，立即完成一条贸易路线，获得两座城市数值的乘积，并在其中一座城市下放置与该城市地形对应的贸易站。带有贸易站的城市不能再计入另一条贸易路线。\n\n发现塔：\n发现格属于任意地形。探索发现格时，把探索者收回，并在该格放置一座发现塔，然后按照你已放置发现塔的数量在分值区获得金币，第 1、2、3、4 座依次为 6、8、10、14 枚金币。放置发现塔之后，该格不能再被探索。\n\n调查卡与时代卡：\n探索牌堆中包含时代卡（I、II、III 与 I/II/III）。某张时代卡首次出现时，每位玩家从调查牌堆抽 2 张调查卡并选择 1 张，放到地图左侧对应当前时代的位置，然后执行这张调查卡的行动，另一张放到调查牌堆底部。之后再次出现同一时代卡时，执行你已经放置的对应调查卡行动。在第四时代，当 I/II/III 时代卡出现时，你可以再次使用你已经拥有的一张调查卡。\n\n目标卡：\n每张地图有 6 张目标卡，开局随机亮出其中的 3 张。当你的一次探索满足了某张目标卡的条件时，立即在该卡上放置一个探索者并结算金币。最先完成某张目标的玩家获得较高分值；若同一回合有多名玩家首次完成同一目标，则这些玩家都获得较高分值；在他人之后完成该目标的玩家获得较低分值。每位玩家对同一目标只能完成一次。\n\n时代与终局：\n探索牌堆抽完后，当前时代结束。进入下一时代时，收回你所有的探索者，但村庄、贸易站、宝物标记与发现塔保留在原位。第四时代结束后游戏结束，金币最多的玩家获胜；若金币相同，则依次比较发现塔数量与村庄数量，仍相同则共享胜利。\n\n特殊地图：\n阿维尼亚中，一块“陆地”是被海洋或地图边界隔开的一片地形区域，部分目标以陆地为条件。阿格洪没有额外规则。卡赞中，火山不能被探索，部分山地因没有空白格而无法建村，遗迹格带有字母，用于完成特定目标。克尼达利亚中，带有尖礁的格不能被探索；每个遗迹格带有三角形、圆形或方形符号；松露水晶格属于任意地形，探索时获得该格数值加上你在本时代及之前已探索的所有水晶格数值之和，水晶格不属于任何区域。",
			grass: "草原",
			desert: "沙漠",
			mountain: "山地",
			sea: "海洋",
			mapAvenia: "阿维尼亚",
			mapAghon: "阿格洪",
			mapKazan: "卡赞",
			mapCnidaria: "克尼达利亚",
			b0: "探索 2 个草原格。",
			b1: "探索 2 个沙漠格。",
			b2: "探索 1 个山地格。",
			b3: "沿直线探索最多 3 个海洋格。",
			b4: "探索任意 2 个相邻格。",
			i0: "以任意顺序探索最多 1 个海洋格和 3 个山地格。",
			i1: "以任意顺序探索最多 1 个沙漠格、1 个草原格、1 个山地格和 2 个海洋格。",
			i2: "探索 1 个山地格，然后探索与该山地格相邻的最多 5 个格。",
			i3: "探索 1 个山地格，然后沿直线探索与该山地格相连的最多 3 个格。",
			i4: "探索 1 个海洋格，然后探索与该海洋格相邻的最多 5 个格。",
			i5: "探索最多 4 个海洋格。本回合每探索 1 个遗迹格，额外抽 1 张宝物卡。",
			i6: "探索最多 4 个沙漠格。这些格为你带来的金币价值翻三倍。",
			i7: "探索最多 4 个海洋格，然后探索与这些海洋格相邻的最多 2 个金币格。",
			i8: "在同一区域内探索最多 4 个格。",
			i9: "探索 1 个草原格，然后沿直线探索与该草原格相连的最多 3 个格。",
			i10: "沿直线探索任意数量相连的草原格、沙漠格和山地格。",
			i11: "以任意顺序探索最多 1 个海洋格和 4 个沙漠格。",
			i12: "探索 1 个海洋格，然后沿直线探索与该海洋格相连的最多 3 个格。",
			i13: "沿直线探索任意数量相连的海洋格。",
			i14: "探索 1 个草原格，然后探索与该草原格相邻的最多 5 个格。",
			i15: "沿直线探索最多 3 个相连的格，且该直线需与 2 个不同的村庄相邻。",
			i16: "探索一条由草原格和／或海洋格组成、最多 5 个格的连续路径。",
			i17: "探索最多 3 个山地格。这些格为你带来的金币价值翻倍。",
			i18: "以任意顺序探索最多 2 个山地格和 3 个草原格。",
			i19: "探索最多 4 个海洋格，然后探索与这些海洋格相邻的任意数量城市格。",
			i20: "以任意顺序探索最多 2 个山地格和 3 个沙漠格。",
			i21: "探索最多 5 个海洋格。",
			i22: "探索最多 4 个草原格。这些格为你带来的金币价值翻三倍。",
			i23: "探索一条由沙漠格和／或海洋格组成、最多 5 个格的连续路径。",
			i24: "以任意顺序探索最多 1 个海洋格和 4 个草原格。",
			i25: "探索 1 个沙漠格，然后探索与该沙漠格相邻的最多 5 个格。",
			i26: "探索一条由山地格和／或海洋格组成、最多 4 个格的连续路径。",
			i27: "探索 1 个沙漠格，然后沿直线探索与该沙漠格相连的最多 3 个格。",
			gAvTowers: "放置 2 座发现塔。",
			gAvRegion5: "在一个面积至少为 5 格的区域发现一座村庄。",
			gAvLands: "在 3 块不同的陆地上发现村庄。",
			gAvV5: "发现 5 座村庄。",
			gAvBorderRuins: "探索 3 个位于地图边缘的遗迹格。",
			gAvPosts: "在价值至少为 3 的城市上放置 2 个贸易站。",
			gAgMountain2: "在 2 个山地格上发现村庄。",
			gAgThree: "在草原、沙漠和山地格上各发现一座村庄。",
			gAgRuinTerrains: "探索分别与草原、沙漠和山地格相邻的遗迹格。",
			gAgRoute12: "完成一条价值至少为 12 的贸易路线。",
			gAgVillageTower: "发现一座与发现塔相邻的村庄；该发现格上必须已有发现塔。",
			gAgPostTerrains: "在草原、沙漠和山地格上放置贸易站。",
			gKzAj: "探索遗迹格 A 和 J。",
			gKzNeTowerC: "探索东北方的发现塔以及遗迹格 C。",
			gKzBd: "探索遗迹格 B 和 D。",
			gKzChain: "用一条不间断的探索者（及村庄）链连接 2 座城市和 2 个遗迹格。",
			gKzCoins3: "探索一个至少有 3 枚金币的格。",
			gKzVillageRuin: "发现一座与遗迹格相邻的村庄。",
			gCnCrystalVillages: "发现 2 座与水晶格相邻的村庄。",
			gCnSameRegion: "在同一类型区域中发现 3 座村庄。",
			gCnShapes: "探索三角形、圆形和方形各一个遗迹格。",
			gCnSameShape3: "探索同一形状的 3 个遗迹格。",
			gCnRoute16: "完成一条价值至少为 16 的贸易路线。",
			gCnCrystal2: "探索 2 个水晶格。",
			map: "地图",
			solo: "单人模式",
			city: "城市",
			era: "时代",
			round: "回合",
			deck: "探索牌堆",
			goals: "目标",
			coins: "金币",
			towers: "发现塔",
			villages: "村庄",
			tradePosts: "贸易站",
			yourTurn: "轮到你探索",
			waiting: "等待其他玩家…",
			endExplore: "结束本次探索",
			placeHint: "在高亮格放置探索者。",
			chooseInvestigate: "选择一张调查卡",
			chooseUseInvestigate: "选择一张已持有的调查卡再次执行",
			chooseVillage: "选择发现村庄的格",
			choosePost: "选择放置贸易站的城市",
			chooseTreasure: "从宝物卡放置 1 个探索者",
			illegal: "该位置不可用。",
			placed: "探索者",
			picked: "已选",
			score: "得分",
			total: "总分",
			treasure: "宝物",
			investigated: "调查",
			capital: "首都",
			ruin: "遗迹",
			discovery: "发现",
			crystal: "水晶",
			volcano: "火山",
			reef: "礁石",
			coin: "金币格",
			eraEnd: "本时代结束",
			done: "游戏结束",
			winner: "胜者",
			cardNow: "当前探索卡",
			iWhole: "从你已持有的调查卡中选择 1 张再次执行。",
			exploreCardLabel: "探索卡",
			investigateCardLabel: "调查卡",
			goalCardLabel: "皇家敕令",
			guildCharter: "皇家特许状",
			guildLedger: "公会账本",
			guildLedgerSub: "提戈梅 · 远征记录",
			mapSurvey: "提戈梅皇家勘测",
			treasureDeck: "宝物牌堆",
			placeHere: "可放置",
			turnOf: "{{name}} 正在探索",
			eraCards: "时代调查",
			valuesTitle: "分值区",
			villageValues: "村庄分值 1、2、3、5",
			towerValues: "发现塔分值 6、8、10、14",
			eraPending: "未抽取",
			coinHigh: "先完成得 {{n}} 金币",
			coinLow: "后完成得 {{n}} 金币",
			goalDoneBy: "已完成",
			listSep: "、",
			placeExplorer: "放置探索者",
			confirm: "确定",
			cancel: "取消",
			close: "关闭",
			yourMap: "你的地图",
			viewBoard: "查看版图",
			selectMap: "选择地图",
			rulesTitle: "玩法说明",
			best: "最佳人数",
			resultTitle: "远征结算",
			resultSubtitle: "四个时代结束，金币最多者胜出。",
			reportTitle: "皇家勘测报告",
			reportSubtitle: "提戈梅公会 · 四时代远征核验",
			reportChampion: "首席探险家",
			reportSeal: "提戈梅公会印记",
			reportLedger: "终局账目",
			resultRank: "第 {{n}} 名",
			resultTreasureBonus: "宝物加分",
			resultGoalsDone: "完成目标",
			resultTiebreak: "金币相同时依次比较发现塔数量与村庄数量，仍相同则共享胜利。"
		},
		en: {
			name: "The Guild of Merchant Explorers",
			desc: "Voyage across the four provinces of Tigomé, founding villages, opening trade routes and visiting discovery towers. After four eras, the most coins wins.",
			rules: "Goal:\nOver four eras, explore the provinces of Tigomé and earn coins by discovering villages, completing trade routes, visiting discovery towers and collecting treasure. After four eras, the player with the most coins wins.\n\nTurn flow:\nEach era has as many turns as there are cards in the exploration deck. On a turn, one player reveals the top card and all players explore their own map at once according to that card. Once everyone has finished the explore action and resolved its features, the next card is revealed.\n\nPlacing explorers:\nEach explorer must be placed on an empty space adjacent to one of your villages, your capital or an explorer you already placed, and that space must not already hold an explorer, village or discovery tower. Explorers are always placed one at a time. You may place fewer than the card allows, but you cannot save an unused part of the action for later. The capital may always be used as an explore origin and counts as a village for exploring, but not for village goals.\n\nGolden rules of exploration:\n1. Every explorer must be adjacent to one of your villages or explorers, and the space must be free of explorers, villages and discovery towers.\n2. Always place explorers one at a time.\n3. Resolve map features as soon as their requirements are met, even if the explore action is not finished, then complete the action.\n4. Unless a card explicitly requires adjacency or a specific arrangement, each new explorer may go anywhere adjacent to one of your villages or explorers.\n5. You may place fewer explorers than shown, as long as you follow the card's adjacency or connection rules, and you cannot save any part for later.\n\nMap features:\nMaps have four terrains: grassland, desert, mountain and sea. A contiguous group of spaces of the same terrain forms a region. The capital space is your starting origin and cannot be explored.\n\nVillages:\nWhen you fully explore a region in a single era, so that every space in it, including cities, has an explorer, you must immediately replace one explorer on a blank space of that region with a village and earn coins from the score area for the current era: 1, 2, 3 and 5 coins in Eras I, II, III and IV. Each region may hold only one village, and villages may only be founded on blank spaces. Sea, ruin and discovery spaces belong to no region.\n\nCoin spaces:\nWhen you explore a coin space, immediately earn the coins shown on it. A coin space may be explored again in later eras to earn more coins.\n\nRuin spaces:\nThe first time you explore a ruin space, place a treasure token on it and immediately draw and resolve a treasure card. Treasure cards without an immediate effect are kept and scored at the end of the game. Exploring the same ruin again never draws another treasure card. When scoring treasure at the end of the game, a card that scores for settlements counts each of your villages as one settlement, and a card that scores for discovery towers counts each of your towers.\n\nCities and trade routes:\nWhen two cities are connected by an unbroken chain of explorers, villages and/or your capital, and neither city has a trading post, you immediately complete a trade route: earn the product of the two cities' values and place a trading post of the matching terrain on one of the two cities. A city with a trading post can never be used for another trade route.\n\nDiscovery towers:\nDiscovery spaces are wild terrain. When you explore a discovery space, return the explorer and place a discovery tower, then earn coins from the score area based on how many towers you have placed: the 1st, 2nd, 3rd and 4th are worth 6, 8, 10 and 14 coins. A space with a tower can never be explored again.\n\nInvestigate cards and era cards:\nThe exploration deck contains era cards (I, II, III and I/II/III). The first time an era card appears, every player draws 2 investigate cards, keeps 1, places it on the matching era slot on the left of their map, and takes its action; the other card goes to the bottom of the investigate deck. When the same era card appears again, take the action of the investigate card you placed for that era. In Era IV, when the I/II/III era card appears, you may use one of your investigate cards again.\n\nGoal cards:\nEach map has 6 goal cards; reveal 3 at random at the start. Whenever one of your explore actions satisfies a goal, immediately place an explorer on that card and score coins. The first player to complete a goal earns the higher value; if several players first complete the same goal in the same turn, all of them earn the higher value; players completing it later earn the lower value. Each player may complete a given goal only once.\n\nEras and game end:\nAn era ends when its exploration deck is empty. When the next era begins, return all of your explorers to your supply, but keep your villages, trading posts, treasure tokens and discovery towers in place. The game ends after Era IV; the most coins wins, then the most discovery towers, then the most villages.\n\nSpecial maps:\nIn Avenia, a \"land\" is an area of terrain cut off by sea or the map border, and some goals use lands. Aghon has no extra rules. In Kazan, volcanoes cannot be explored, some mountain regions have no blank spaces and cannot hold villages, and ruin spaces are lettered for certain goals. In Cnidaria, spaces with jagged reefs cannot be explored; each ruin carries a triangle, circle or square symbol; and sonulux crystal spaces are wild terrain that earn their own value plus the value of every crystal you have already explored, and belong to no region.",
			grass: "Grassland",
			desert: "Desert",
			mountain: "Mountain",
			sea: "Sea",
			mapAvenia: "Avenia",
			mapAghon: "Aghon",
			mapKazan: "Kazan",
			mapCnidaria: "Cnidaria",
			b0: "Explore 2 grassland spaces.",
			b1: "Explore 2 desert spaces.",
			b2: "Explore 1 mountain space.",
			b3: "Explore up to 3 sea spaces in a straight line.",
			b4: "Explore any 2 adjacent spaces.",
			i0: "Explore up to 1 sea and 3 mountain spaces in any order.",
			i1: "Explore up to 1 desert, 1 grassland, 1 mountain, and 2 sea spaces in any order.",
			i2: "Explore 1 mountain space, then explore up to 5 spaces adjacent to this mountain space.",
			i3: "Explore 1 mountain space, then explore up to 3 spaces connected to it in a straight line.",
			i4: "Explore 1 sea space, then explore up to 5 spaces adjacent to this sea space.",
			i5: "Explore up to 4 sea spaces. Draw an additional treasure card for each ruin space you explore this turn.",
			i6: "Explore up to 4 desert spaces. Triple the value of any coins you earn from these spaces.",
			i7: "Explore up to 4 sea spaces, then explore up to 2 coin spaces adjacent to these sea spaces.",
			i8: "Explore up to 4 spaces within a single region.",
			i9: "Explore 1 grassland space, then explore up to 3 spaces connected to it in a straight line.",
			i10: "Explore any number of connected grassland, desert, and mountain spaces in a straight line.",
			i11: "Explore up to 1 sea and 4 desert spaces in any order.",
			i12: "Explore 1 sea space, then explore up to 3 spaces connected to it in a straight line.",
			i13: "Explore any number of connected sea spaces in a straight line.",
			i14: "Explore 1 grassland space, then explore up to 5 spaces adjacent to this grassland space.",
			i15: "Explore up to 3 spaces connected in a straight line adjacent to 2 different villages.",
			i16: "Explore a continuous path of up to 5 grassland and/or sea spaces.",
			i17: "Explore up to 3 mountain spaces. Double the value of any coins you earn from these spaces.",
			i18: "Explore up to 2 mountain and 3 grassland spaces in any order.",
			i19: "Explore up to 4 sea spaces, then explore any number of city spaces adjacent to these sea spaces.",
			i20: "Explore up to 2 mountain and 3 desert spaces in any order.",
			i21: "Explore up to 5 sea spaces.",
			i22: "Explore up to 4 grassland spaces. Triple the value of any coins you earn from these spaces.",
			i23: "Explore a continuous path of up to 5 desert and/or sea spaces.",
			i24: "Explore up to 1 sea and 4 grassland spaces in any order.",
			i25: "Explore 1 desert space, then explore up to 5 spaces adjacent to this desert space.",
			i26: "Explore a continuous path of up to 4 mountain and/or sea spaces.",
			i27: "Explore 1 desert space, then explore up to 3 spaces connected to it in a straight line.",
			gAvTowers: "Place 2 discovery towers.",
			gAvRegion5: "Discover a village on a region of 5 or more spaces.",
			gAvLands: "Discover villages on 3 different lands.",
			gAvV5: "Discover 5 villages.",
			gAvBorderRuins: "Explore 3 ruin spaces along the border of the map.",
			gAvPosts: "Place 2 trading posts on cities valued 3 or greater.",
			gAgMountain2: "Discover 2 villages on mountain spaces.",
			gAgThree: "Discover villages on grassland, desert, and mountain spaces.",
			gAgRuinTerrains: "Explore ruin spaces adjacent to grassland, desert, and mountain spaces.",
			gAgRoute12: "Complete a trade route worth at least 12.",
			gAgVillageTower: "Discover a village adjacent to a discovery tower. The discovery space must have a discovery tower.",
			gAgPostTerrains: "Place trading posts on grassland, desert, and mountain spaces.",
			gKzAj: "Explore ruin spaces A and J.",
			gKzNeTowerC: "Explore the northeastern discovery tower and ruin space C.",
			gKzBd: "Explore ruin spaces B and D.",
			gKzChain: "Connect 2 cities and 2 ruin spaces with an unbroken chain of explorers and villages.",
			gKzCoins3: "Explore a space with at least 3 coins.",
			gKzVillageRuin: "Discover a village adjacent to a ruin space.",
			gCnCrystalVillages: "Discover 2 villages adjacent to crystal spaces.",
			gCnSameRegion: "Discover 3 villages on the same region type.",
			gCnShapes: "Explore a ruin space of each type (triangle, circle, and square).",
			gCnSameShape3: "Explore 3 ruin spaces of the same type.",
			gCnRoute16: "Complete a trade route worth at least 16.",
			gCnCrystal2: "Explore 2 crystal spaces.",
			map: "Map",
			solo: "Solo mode",
			era: "Era",
			round: "Round",
			deck: "Explore deck",
			goals: "Goals",
			coins: "Coins",
			towers: "Discovery towers",
			villages: "Villages",
			tradePosts: "Trading posts",
			yourTurn: "Your turn to explore",
			waiting: "Waiting for other players…",
			endExplore: "End this explore",
			placeHint: "Place an explorer on a highlighted space.",
			chooseInvestigate: "Choose an investigate card",
			chooseUseInvestigate: "Choose one of your investigate cards to use again",
			chooseVillage: "Choose where to found the village",
			choosePost: "Choose which city gets the trading post",
			chooseTreasure: "Place 1 explorer from a treasure card",
			illegal: "That space is not available.",
			placed: "Explorer",
			picked: "Selected",
			score: "Score",
			total: "Total",
			treasure: "Treasure",
			investigated: "Investigate",
			capital: "Capital",
			ruin: "Ruin",
			discovery: "Discovery",
			crystal: "Crystal",
			volcano: "Volcano",
			reef: "Reef",
			coin: "Coin space",
			eraEnd: "Era ends",
			done: "Game over",
			winner: "Winner",
			cardNow: "Current explore card",
			iWhole: "Use one of your investigate cards again.",
			exploreCardLabel: "Explore",
			investigateCardLabel: "Investigate",
			goalCardLabel: "Royal Commission",
			guildCharter: "Royal Charter",
			guildLedger: "Guild Ledger",
			guildLedgerSub: "Tigomé · expedition record",
			mapSurvey: "Royal Survey of Tigomé",
			treasureDeck: "Treasure deck",
			placeHere: "available",
			turnOf: "{{name}} is exploring",
			eraCards: "Era cards",
			valuesTitle: "Score area",
			villageValues: "Villages score 1, 2, 3, 5",
			towerValues: "Discovery towers score 6, 8, 10, 14",
			eraPending: "Not drawn",
			coinHigh: "{{n}} coins if completed first",
			coinLow: "{{n}} coins if completed later",
			goalDoneBy: "Completed",
			listSep: ", ",
			placeExplorer: "Place explorer",
			confirm: "Confirm",
			cancel: "Cancel",
			close: "Close",
			yourMap: "Your map",
			viewBoard: "View board",
			selectMap: "Map",
			rulesTitle: "How to play",
			best: "Best with",
			city: "City",
			resultTitle: "Expedition Results",
			resultSubtitle: "Four eras are over. The most coins wins.",
			reportTitle: "Royal Survey Report",
			reportSubtitle: "The Guild of Merchant Explorers · four eras certified",
			reportChampion: "Foremost Explorer",
			reportSeal: "Guild seal",
			reportLedger: "Final ledger",
			resultRank: "Rank {{n}}",
			resultTreasureBonus: "Treasure bonus",
			resultGoalsDone: "Goals completed",
			resultTiebreak: "Ties are broken by discovery towers, then villages; if still tied, the victory is shared."
		}
	}
};
//#endregion
export { Ht as default };
