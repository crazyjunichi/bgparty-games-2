import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useId as i, useMemo as a, useRef as o, useState as s } from "react";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { ConfirmButton as f } from "@bgparty/sdk/confirm-button";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { seatName as m } from "@bgparty/sdk/ui/player-strip";
import { SheetFxProbe as h, SheetView as g } from "@bgparty/sdk/sheet-view";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as C, OptionSection as w } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var T = [
	"coal",
	"oil",
	"garbage",
	"uranium"
], E = "#485d52", D = {
	3: {
		id: 3,
		kind: "oil",
		need: 2,
		cities: 1
	},
	4: {
		id: 4,
		kind: "coal",
		need: 2,
		cities: 1
	},
	5: {
		id: 5,
		kind: "hybrid",
		need: 2,
		cities: 1
	},
	6: {
		id: 6,
		kind: "garbage",
		need: 1,
		cities: 1
	},
	7: {
		id: 7,
		kind: "oil",
		need: 3,
		cities: 2
	},
	8: {
		id: 8,
		kind: "coal",
		need: 3,
		cities: 2
	},
	9: {
		id: 9,
		kind: "oil",
		need: 1,
		cities: 1
	},
	10: {
		id: 10,
		kind: "coal",
		need: 2,
		cities: 2
	},
	11: {
		id: 11,
		kind: "uranium",
		need: 1,
		cities: 2
	},
	12: {
		id: 12,
		kind: "hybrid",
		need: 2,
		cities: 2
	},
	13: {
		id: 13,
		kind: "wind",
		need: 0,
		cities: 1
	},
	14: {
		id: 14,
		kind: "garbage",
		need: 2,
		cities: 2
	},
	15: {
		id: 15,
		kind: "coal",
		need: 2,
		cities: 3
	},
	16: {
		id: 16,
		kind: "oil",
		need: 2,
		cities: 3
	},
	17: {
		id: 17,
		kind: "uranium",
		need: 1,
		cities: 2
	},
	18: {
		id: 18,
		kind: "wind",
		need: 0,
		cities: 2
	},
	19: {
		id: 19,
		kind: "garbage",
		need: 2,
		cities: 3
	},
	20: {
		id: 20,
		kind: "coal",
		need: 3,
		cities: 5
	},
	21: {
		id: 21,
		kind: "hybrid",
		need: 2,
		cities: 4
	},
	22: {
		id: 22,
		kind: "wind",
		need: 0,
		cities: 2
	},
	23: {
		id: 23,
		kind: "uranium",
		need: 1,
		cities: 3
	},
	24: {
		id: 24,
		kind: "garbage",
		need: 2,
		cities: 4
	},
	25: {
		id: 25,
		kind: "coal",
		need: 2,
		cities: 5
	},
	26: {
		id: 26,
		kind: "oil",
		need: 2,
		cities: 5
	},
	27: {
		id: 27,
		kind: "wind",
		need: 0,
		cities: 3
	},
	28: {
		id: 28,
		kind: "uranium",
		need: 1,
		cities: 4
	},
	29: {
		id: 29,
		kind: "hybrid",
		need: 1,
		cities: 4
	},
	30: {
		id: 30,
		kind: "garbage",
		need: 3,
		cities: 6
	},
	31: {
		id: 31,
		kind: "coal",
		need: 3,
		cities: 6
	},
	32: {
		id: 32,
		kind: "oil",
		need: 3,
		cities: 6
	},
	33: {
		id: 33,
		kind: "wind",
		need: 0,
		cities: 4
	},
	34: {
		id: 34,
		kind: "uranium",
		need: 1,
		cities: 5
	},
	35: {
		id: 35,
		kind: "oil",
		need: 1,
		cities: 5
	},
	36: {
		id: 36,
		kind: "coal",
		need: 3,
		cities: 7
	},
	37: {
		id: 37,
		kind: "wind",
		need: 0,
		cities: 4
	},
	38: {
		id: 38,
		kind: "garbage",
		need: 3,
		cities: 7
	},
	39: {
		id: 39,
		kind: "uranium",
		need: 1,
		cities: 6
	},
	40: {
		id: 40,
		kind: "oil",
		need: 2,
		cities: 6
	},
	42: {
		id: 42,
		kind: "coal",
		need: 2,
		cities: 6
	},
	44: {
		id: 44,
		kind: "wind",
		need: 0,
		cities: 5
	},
	46: {
		id: 46,
		kind: "hybrid",
		need: 3,
		cities: 7
	},
	50: {
		id: 50,
		kind: "wind",
		need: 0,
		cities: 6
	}
}, O = Object.keys(D).map(Number).sort((e, t) => e - t), k = O.filter((e) => e <= 15), A = O.filter((e) => e > 15);
function j(e, t, n, r) {
	let i = Object.entries(r).map(([e, t]) => ({
		id: e,
		region: t.region,
		x: t.x,
		y: t.y
	})), a = /* @__PURE__ */ new Set(), o = [];
	for (let [e, t] of Object.entries(r)) for (let [n, r] of t.n) {
		let t = e < n ? `${e}|${n}` : `${n}|${e}`;
		a.has(t) || (a.add(t), o.push([
			e,
			n,
			r
		]));
	}
	return {
		id: e,
		width: t,
		height: n,
		cities: i,
		links: o
	};
}
var M = {
	germany: j("germany", 580, 760, {
		flensburg: {
			region: "green",
			x: 241,
			y: 26,
			n: [["kiel", 4]]
		},
		kiel: {
			region: "green",
			x: 271,
			y: 75,
			n: [
				["flensburg", 4],
				["lubeck", 4],
				["hamburg", 8]
			]
		},
		hamburg: {
			region: "green",
			x: 267,
			y: 149,
			n: [
				["kiel", 8],
				["lubeck", 6],
				["schwerin", 8],
				["bremen", 11],
				["cuxhaven", 11],
				["hannover", 17]
			]
		},
		bremen: {
			region: "green",
			x: 210,
			y: 197,
			n: [
				["hamburg", 11],
				["cuxhaven", 8],
				["wilhelmshaven", 11],
				["osnabruck", 11],
				["hannover", 10]
			]
		},
		cuxhaven: {
			region: "green",
			x: 200,
			y: 119,
			n: [["hamburg", 11], ["bremen", 8]]
		},
		wilhelmshaven: {
			region: "green",
			x: 161,
			y: 149,
			n: [["osnabruck", 14], ["bremen", 11]]
		},
		hannover: {
			region: "green",
			x: 268,
			y: 268,
			n: [
				["hamburg", 17],
				["bremen", 10],
				["osnabruck", 16],
				["kassel", 15],
				["erfurt", 19],
				["magdeburg", 15],
				["schwerin", 19]
			]
		},
		lubeck: {
			region: "brown",
			x: 314,
			y: 108,
			n: [
				["kiel", 4],
				["hamburg", 6],
				["schwerin", 6]
			]
		},
		schwerin: {
			region: "brown",
			x: 353,
			y: 153,
			n: [
				["lubeck", 6],
				["rostock", 6],
				["hamburg", 8],
				["magdeburg", 16],
				["hannover", 19],
				["torgelow", 19],
				["berlin", 18]
			]
		},
		rostock: {
			region: "brown",
			x: 388,
			y: 90,
			n: [["schwerin", 6], ["torgelow", 19]]
		},
		torgelow: {
			region: "brown",
			x: 498,
			y: 148,
			n: [
				["rostock", 19],
				["schwerin", 19],
				["berlin", 15]
			]
		},
		magdeburg: {
			region: "brown",
			x: 374,
			y: 274,
			n: [
				["hannover", 15],
				["schwerin", 16],
				["berlin", 10],
				["halle", 11]
			]
		},
		berlin: {
			region: "brown",
			x: 460,
			y: 251,
			n: [
				["torgelow", 15],
				["schwerin", 18],
				["magdeburg", 10],
				["halle", 17],
				["frankfurto", 6]
			]
		},
		frankfurto: {
			region: "brown",
			x: 521,
			y: 269,
			n: [
				["berlin", 6],
				["leipzig", 21],
				["dresden", 16]
			]
		},
		osnabruck: {
			region: "red",
			x: 165,
			y: 256,
			n: [
				["bremen", 11],
				["hannover", 16],
				["munster", 7],
				["wilhelmshaven", 14],
				["kassel", 20]
			]
		},
		munster: {
			region: "red",
			x: 133,
			y: 303,
			n: [
				["osnabruck", 7],
				["essen", 6],
				["dortmund", 2]
			]
		},
		essen: {
			region: "red",
			x: 91,
			y: 337,
			n: [
				["munster", 6],
				["dortmund", 4],
				["duisburg", 0],
				["duesseldorf", 2]
			]
		},
		dortmund: {
			region: "red",
			x: 142,
			y: 360,
			n: [
				["munster", 2],
				["essen", 4],
				["koln", 10],
				["kassel", 18],
				["frankfurtm", 20]
			]
		},
		duisburg: {
			region: "red",
			x: 55,
			y: 324,
			n: [["essen", 0]]
		},
		duesseldorf: {
			region: "red",
			x: 64,
			y: 381,
			n: [
				["essen", 2],
				["koln", 4],
				["aachen", 9]
			]
		},
		kassel: {
			region: "red",
			x: 239,
			y: 372,
			n: [
				["hannover", 15],
				["osnabruck", 20],
				["dortmund", 18],
				["frankfurtm", 13],
				["fulda", 8],
				["erfurt", 15]
			]
		},
		koln: {
			region: "blue",
			x: 103,
			y: 420,
			n: [
				["dortmund", 10],
				["duesseldorf", 4],
				["aachen", 7],
				["trier", 20],
				["wiesbaden", 21]
			]
		},
		aachen: {
			region: "blue",
			x: 47,
			y: 436,
			n: [
				["koln", 7],
				["duesseldorf", 9],
				["trier", 19]
			]
		},
		frankfurtm: {
			region: "blue",
			x: 202,
			y: 478,
			n: [
				["kassel", 13],
				["dortmund", 20],
				["wiesbaden", 0],
				["wuerzburg", 13],
				["fulda", 8]
			]
		},
		wiesbaden: {
			region: "blue",
			x: 166,
			y: 494,
			n: [
				["frankfurtm", 0],
				["koln", 21],
				["trier", 18],
				["saarbrucken", 10],
				["mannheim", 11]
			]
		},
		trier: {
			region: "blue",
			x: 70,
			y: 524,
			n: [
				["koln", 20],
				["aachen", 19],
				["wiesbaden", 18],
				["saarbrucken", 11]
			]
		},
		saarbrucken: {
			region: "blue",
			x: 120,
			y: 580,
			n: [
				["trier", 11],
				["wiesbaden", 10],
				["mannheim", 11],
				["stuttgart", 17]
			]
		},
		mannheim: {
			region: "blue",
			x: 197,
			y: 565,
			n: [
				["wiesbaden", 11],
				["saarbrucken", 11],
				["stuttgart", 6],
				["wuerzburg", 10]
			]
		},
		dresden: {
			region: "yellow",
			x: 498,
			y: 405,
			n: [
				["frankfurto", 16],
				["leipzig", 13],
				["erfurt", 19]
			]
		},
		fulda: {
			region: "yellow",
			x: 266,
			y: 445,
			n: [
				["kassel", 8],
				["frankfurtm", 8],
				["wuerzburg", 11],
				["erfurt", 13]
			]
		},
		erfurt: {
			region: "yellow",
			x: 342,
			y: 402,
			n: [
				["hannover", 19],
				["kassel", 15],
				["fulda", 13],
				["nurnberg", 21],
				["dresden", 19],
				["halle", 6]
			]
		},
		halle: {
			region: "yellow",
			x: 384,
			y: 350,
			n: [
				["magdeburg", 11],
				["erfurt", 6],
				["leipzig", 0],
				["berlin", 17]
			]
		},
		leipzig: {
			region: "yellow",
			x: 416,
			y: 373,
			n: [
				["halle", 0],
				["dresden", 13],
				["frankfurto", 21]
			]
		},
		wuerzburg: {
			region: "yellow",
			x: 276,
			y: 521,
			n: [
				["fulda", 11],
				["frankfurtm", 13],
				["mannheim", 10],
				["stuttgart", 12],
				["augsburg", 19],
				["nurnberg", 8]
			]
		},
		nurnberg: {
			region: "yellow",
			x: 341,
			y: 553,
			n: [
				["erfurt", 21],
				["wuerzburg", 8],
				["augsburg", 18],
				["regensburg", 12]
			]
		},
		stuttgart: {
			region: "purple",
			x: 215,
			y: 626,
			n: [
				["mannheim", 6],
				["saarbrucken", 17],
				["freiburg", 16],
				["konstanz", 16],
				["augsburg", 15],
				["wuerzburg", 12]
			]
		},
		freiburg: {
			region: "purple",
			x: 147,
			y: 685,
			n: [["stuttgart", 16], ["konstanz", 14]]
		},
		konstanz: {
			region: "purple",
			x: 214,
			y: 718,
			n: [
				["stuttgart", 16],
				["freiburg", 14],
				["augsburg", 17]
			]
		},
		augsburg: {
			region: "purple",
			x: 311,
			y: 647,
			n: [
				["wuerzburg", 19],
				["stuttgart", 15],
				["konstanz", 17],
				["muenchen", 6],
				["regensburg", 13],
				["nurnberg", 18]
			]
		},
		muenchen: {
			region: "purple",
			x: 368,
			y: 687,
			n: [
				["augsburg", 6],
				["passau", 14],
				["regensburg", 10]
			]
		},
		regensburg: {
			region: "purple",
			x: 387,
			y: 600,
			n: [
				["nurnberg", 12],
				["augsburg", 13],
				["muenchen", 10],
				["passau", 12]
			]
		},
		passau: {
			region: "purple",
			x: 475,
			y: 641,
			n: [["regensburg", 12], ["muenchen", 14]]
		}
	}),
	usa: j("usa", 1040, 730, {
		seattle: {
			region: "purple",
			x: 81,
			y: 99,
			n: [
				["portland", 3],
				["billings", 9],
				["boise", 12]
			]
		},
		portland: {
			region: "purple",
			x: 75,
			y: 153,
			n: [
				["seattle", 3],
				["boise", 13],
				["sanfrancisco", 24]
			]
		},
		boise: {
			region: "purple",
			x: 187,
			y: 202,
			n: [
				["seattle", 12],
				["portland", 13],
				["billings", 12],
				["cheyenne", 24],
				["sanfrancisco", 23],
				["saltlakecity", 8]
			]
		},
		billings: {
			region: "purple",
			x: 320,
			y: 145,
			n: [
				["seattle", 9],
				["boise", 12],
				["cheyenne", 9],
				["fargo", 17],
				["minneapolis", 18]
			]
		},
		cheyenne: {
			region: "purple",
			x: 384,
			y: 266,
			n: [
				["boise", 24],
				["billings", 9],
				["omaha", 14],
				["denver", 0],
				["minneapolis", 18]
			]
		},
		omaha: {
			region: "purple",
			x: 537,
			y: 261,
			n: [
				["cheyenne", 14],
				["minneapolis", 8],
				["chicago", 13],
				["kansascity", 5]
			]
		},
		denver: {
			region: "purple",
			x: 380,
			y: 303,
			n: [
				["cheyenne", 0],
				["saltlakecity", 21],
				["santafe", 13],
				["kansascity", 16]
			]
		},
		sanfrancisco: {
			region: "darkgreen",
			x: 80,
			y: 352,
			n: [
				["portland", 24],
				["boise", 23],
				["saltlakecity", 27],
				["lasvegas", 14],
				["losangeles", 9]
			]
		},
		losangeles: {
			region: "darkgreen",
			x: 152,
			y: 447,
			n: [
				["sanfrancisco", 9],
				["lasvegas", 9],
				["sandiego", 3]
			]
		},
		sandiego: {
			region: "darkgreen",
			x: 169,
			y: 483,
			n: [
				["losangeles", 3],
				["lasvegas", 9],
				["phoenix", 14]
			]
		},
		lasvegas: {
			region: "darkgreen",
			x: 206,
			y: 393,
			n: [
				["sanfrancisco", 14],
				["losangeles", 9],
				["sandiego", 9],
				["phoenix", 15],
				["saltlakecity", 18],
				["santafe", 27]
			]
		},
		phoenix: {
			region: "darkgreen",
			x: 258,
			y: 465,
			n: [
				["sandiego", 14],
				["lasvegas", 15],
				["santafe", 18]
			]
		},
		santafe: {
			region: "darkgreen",
			x: 365,
			y: 406,
			n: [
				["lasvegas", 27],
				["phoenix", 18],
				["saltlakecity", 28],
				["denver", 13],
				["houston", 21],
				["dallas", 16],
				["oklahomacity", 15],
				["kansascity", 16]
			]
		},
		saltlakecity: {
			region: "darkgreen",
			x: 261,
			y: 274,
			n: [
				["boise", 8],
				["denver", 21],
				["sanfrancisco", 27],
				["lasvegas", 18],
				["santafe", 28]
			]
		},
		fargo: {
			region: "yellow",
			x: 522,
			y: 117,
			n: [
				["billings", 17],
				["duluth", 6],
				["minneapolis", 6]
			]
		},
		duluth: {
			region: "yellow",
			x: 603,
			y: 119,
			n: [
				["fargo", 6],
				["minneapolis", 5],
				["chicago", 12],
				["detroit", 15]
			]
		},
		minneapolis: {
			region: "yellow",
			x: 582,
			y: 166,
			n: [
				["billings", 18],
				["cheyenne", 18],
				["omaha", 8],
				["fargo", 6],
				["duluth", 5],
				["chicago", 8]
			]
		},
		chicago: {
			region: "yellow",
			x: 681,
			y: 246,
			n: [
				["omaha", 13],
				["duluth", 12],
				["minneapolis", 8],
				["stlouis", 10],
				["cincinnati", 7],
				["kansascity", 8],
				["detroit", 7]
			]
		},
		stlouis: {
			region: "yellow",
			x: 636,
			y: 331,
			n: [
				["chicago", 10],
				["cincinnati", 12],
				["kansascity", 6],
				["memphis", 7],
				["atlanta", 12]
			]
		},
		cincinnati: {
			region: "yellow",
			x: 734,
			y: 318,
			n: [
				["chicago", 7],
				["stlouis", 12],
				["knoxville", 6],
				["detroit", 4],
				["pittsburgh", 7],
				["raleigh", 15]
			]
		},
		knoxville: {
			region: "yellow",
			x: 744,
			y: 401,
			n: [["cincinnati", 6], ["atlanta", 5]]
		},
		kansascity: {
			region: "red",
			x: 560,
			y: 318,
			n: [
				["santafe", 16],
				["denver", 16],
				["omaha", 5],
				["chicago", 8],
				["stlouis", 6],
				["oklahomacity", 8],
				["memphis", 12]
			]
		},
		oklahomacity: {
			region: "red",
			x: 510,
			y: 411,
			n: [
				["santafe", 15],
				["kansascity", 8],
				["dallas", 3],
				["memphis", 14]
			]
		},
		dallas: {
			region: "red",
			x: 522,
			y: 481,
			n: [
				["santafe", 16],
				["oklahomacity", 3],
				["houston", 5],
				["memphis", 12],
				["neworleans", 12]
			]
		},
		houston: {
			region: "red",
			x: 546,
			y: 558,
			n: [
				["santafe", 21],
				["dallas", 5],
				["neworleans", 8]
			]
		},
		memphis: {
			region: "red",
			x: 639,
			y: 421,
			n: [
				["stlouis", 7],
				["kansascity", 12],
				["oklahomacity", 14],
				["dallas", 12],
				["neworleans", 7],
				["birmingham", 6]
			]
		},
		neworleans: {
			region: "red",
			x: 637,
			y: 554,
			n: [
				["dallas", 12],
				["houston", 8],
				["memphis", 7],
				["birmingham", 11],
				["jacksonville", 16]
			]
		},
		birmingham: {
			region: "red",
			x: 694,
			y: 463,
			n: [
				["memphis", 6],
				["neworleans", 11],
				["jacksonville", 9],
				["atlanta", 3]
			]
		},
		detroit: {
			region: "brown",
			x: 760,
			y: 235,
			n: [
				["duluth", 15],
				["chicago", 7],
				["cincinnati", 4],
				["buffalo", 7],
				["pittsburgh", 6]
			]
		},
		buffalo: {
			region: "brown",
			x: 831,
			y: 220,
			n: [
				["detroit", 7],
				["newyork", 8],
				["pittsburgh", 7]
			]
		},
		pittsburgh: {
			region: "brown",
			x: 812,
			y: 285,
			n: [
				["cincinnati", 7],
				["detroit", 6],
				["buffalo", 7],
				["washingtondc", 6],
				["raleigh", 7]
			]
		},
		boston: {
			region: "brown",
			x: 965,
			y: 233,
			n: [["newyork", 3]]
		},
		newyork: {
			region: "brown",
			x: 915,
			y: 277,
			n: [
				["buffalo", 8],
				["boston", 3],
				["philadelphia", 0]
			]
		},
		philadelphia: {
			region: "brown",
			x: 895,
			y: 296,
			n: [["newyork", 0], ["washingtondc", 3]]
		},
		washingtondc: {
			region: "brown",
			x: 864,
			y: 323,
			n: [
				["pittsburgh", 6],
				["philadelphia", 3],
				["norfolk", 5]
			]
		},
		atlanta: {
			region: "lightgreen",
			x: 736,
			y: 457,
			n: [
				["birmingham", 3],
				["stlouis", 12],
				["knoxville", 5],
				["raleigh", 7],
				["savannah", 7]
			]
		},
		norfolk: {
			region: "lightgreen",
			x: 876,
			y: 375,
			n: [["washingtondc", 5], ["raleigh", 3]]
		},
		raleigh: {
			region: "lightgreen",
			x: 836,
			y: 403,
			n: [
				["cincinnati", 15],
				["pittsburgh", 7],
				["norfolk", 3],
				["atlanta", 7],
				["savannah", 7]
			]
		},
		savannah: {
			region: "lightgreen",
			x: 793,
			y: 499,
			n: [
				["atlanta", 7],
				["raleigh", 7],
				["jacksonville", 0]
			]
		},
		jacksonville: {
			region: "lightgreen",
			x: 782,
			y: 545,
			n: [
				["neworleans", 16],
				["birmingham", 9],
				["savannah", 0],
				["tampa", 4]
			]
		},
		tampa: {
			region: "lightgreen",
			x: 769,
			y: 606,
			n: [["jacksonville", 4], ["miami", 4]]
		},
		miami: {
			region: "lightgreen",
			x: 808,
			y: 661,
			n: [["tampa", 4]]
		}
	})
}, ee = {
	germany: [
		"green",
		"brown",
		"red",
		"blue",
		"yellow",
		"purple"
	],
	usa: [
		"purple",
		"darkgreen",
		"yellow",
		"red",
		"brown",
		"lightgreen"
	]
};
function N(e) {
	let t = new Map(e.cities.map((e) => [e.id, e.region])), n = {};
	for (let t of ee[e.id]) n[t] = /* @__PURE__ */ new Set();
	for (let [r, i] of e.links) {
		let e = t.get(r), a = t.get(i);
		e && a && e !== a && (n[e].add(a), n[a].add(e));
	}
	return Object.fromEntries(Object.entries(n).map(([e, t]) => [e, [...t].sort()]));
}
var te = {
	germany: N(M.germany),
	usa: N(M.usa)
}, ne = {
	flensburg: "games.powergrid.cityFlensburg",
	kiel: "games.powergrid.cityKiel",
	hamburg: "games.powergrid.cityHamburg",
	bremen: "games.powergrid.cityBremen",
	cuxhaven: "games.powergrid.cityCuxhaven",
	wilhelmshaven: "games.powergrid.cityWilhelmshaven",
	hannover: "games.powergrid.cityHannover",
	lubeck: "games.powergrid.cityLubeck",
	schwerin: "games.powergrid.citySchwerin",
	rostock: "games.powergrid.cityRostock",
	torgelow: "games.powergrid.cityTorgelow",
	magdeburg: "games.powergrid.cityMagdeburg",
	berlin: "games.powergrid.cityBerlin",
	frankfurto: "games.powergrid.cityFrankfurtO",
	osnabruck: "games.powergrid.cityOsnabruck",
	munster: "games.powergrid.cityMunster",
	essen: "games.powergrid.cityEssen",
	dortmund: "games.powergrid.cityDortmund",
	duisburg: "games.powergrid.cityDuisburg",
	duesseldorf: "games.powergrid.cityDuesseldorf",
	kassel: "games.powergrid.cityKassel",
	koln: "games.powergrid.cityKoln",
	aachen: "games.powergrid.cityAachen",
	frankfurtm: "games.powergrid.cityFrankfurtM",
	wiesbaden: "games.powergrid.cityWiesbaden",
	trier: "games.powergrid.cityTrier",
	saarbrucken: "games.powergrid.citySaarbrucken",
	mannheim: "games.powergrid.cityMannheim",
	dresden: "games.powergrid.cityDresden",
	fulda: "games.powergrid.cityFulda",
	erfurt: "games.powergrid.cityErfurt",
	halle: "games.powergrid.cityHalle",
	leipzig: "games.powergrid.cityLeipzig",
	wuerzburg: "games.powergrid.cityWuerzburg",
	nurnberg: "games.powergrid.cityNurnberg",
	stuttgart: "games.powergrid.cityStuttgart",
	freiburg: "games.powergrid.cityFreiburg",
	konstanz: "games.powergrid.cityKonstanz",
	augsburg: "games.powergrid.cityAugsburg",
	muenchen: "games.powergrid.cityMuenchen",
	regensburg: "games.powergrid.cityRegensburg",
	passau: "games.powergrid.cityPassau",
	seattle: "games.powergrid.citySeattle",
	portland: "games.powergrid.cityPortland",
	boise: "games.powergrid.cityBoise",
	billings: "games.powergrid.cityBillings",
	cheyenne: "games.powergrid.cityCheyenne",
	omaha: "games.powergrid.cityOmaha",
	denver: "games.powergrid.cityDenver",
	sanfrancisco: "games.powergrid.citySanFrancisco",
	losangeles: "games.powergrid.cityLosAngeles",
	sandiego: "games.powergrid.citySanDiego",
	lasvegas: "games.powergrid.cityLasVegas",
	phoenix: "games.powergrid.cityPhoenix",
	santafe: "games.powergrid.citySantaFe",
	saltlakecity: "games.powergrid.citySaltLakeCity",
	fargo: "games.powergrid.cityFargo",
	duluth: "games.powergrid.cityDuluth",
	minneapolis: "games.powergrid.cityMinneapolis",
	chicago: "games.powergrid.cityChicago",
	stlouis: "games.powergrid.cityStLouis",
	cincinnati: "games.powergrid.cityCincinnati",
	knoxville: "games.powergrid.cityKnoxville",
	kansascity: "games.powergrid.cityKansasCity",
	oklahomacity: "games.powergrid.cityOklahomaCity",
	dallas: "games.powergrid.cityDallas",
	houston: "games.powergrid.cityHouston",
	memphis: "games.powergrid.cityMemphis",
	neworleans: "games.powergrid.cityNewOrleans",
	birmingham: "games.powergrid.cityBirmingham",
	detroit: "games.powergrid.cityDetroit",
	buffalo: "games.powergrid.cityBuffalo",
	pittsburgh: "games.powergrid.cityPittsburgh",
	boston: "games.powergrid.cityBoston",
	newyork: "games.powergrid.cityNewYork",
	philadelphia: "games.powergrid.cityPhiladelphia",
	washingtondc: "games.powergrid.cityWashingtonDC",
	atlanta: "games.powergrid.cityAtlanta",
	norfolk: "games.powergrid.cityNorfolk",
	raleigh: "games.powergrid.cityRaleigh",
	savannah: "games.powergrid.citySavannah",
	jacksonville: "games.powergrid.cityJacksonville",
	tampa: "games.powergrid.cityTampa",
	miami: "games.powergrid.cityMiami"
}, re = {
	green: "games.powergrid.regionGreen",
	brown: "games.powergrid.regionBrown",
	red: "games.powergrid.regionRed",
	blue: "games.powergrid.regionBlue",
	yellow: "games.powergrid.regionYellow",
	purple: "games.powergrid.regionPurple",
	darkgreen: "games.powergrid.regionDarkGreen",
	lightgreen: "games.powergrid.regionLightGreen"
};
function ie(e, t) {
	return e.map((e) => ({
		price: e,
		cap: t
	}));
}
var ae = {
	coal: ie([
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	], 3),
	oil: ie([
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	], 3),
	garbage: ie([
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	], 3),
	uranium: [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		10,
		12,
		14,
		16
	].map((e) => ({
		price: e,
		cap: 1
	}))
}, oe = {
	coal: 24,
	oil: 24,
	garbage: 24,
	uranium: 12
}, se = {
	coal: 24,
	oil: 18,
	garbage: 9,
	uranium: 2
}, ce = [
	10,
	22,
	33,
	44,
	54,
	64,
	73,
	82,
	90,
	98,
	105,
	112,
	118,
	124,
	129,
	134,
	138,
	142,
	145,
	148,
	150
], le = {
	3: {
		regions: 3,
		step2: 7,
		end: 17,
		removePlug: 2,
		removeSocket: 6
	},
	4: {
		regions: 4,
		step2: 7,
		end: 17,
		removePlug: 1,
		removeSocket: 3
	},
	5: {
		regions: 5,
		step2: 7,
		end: 15,
		removePlug: 0,
		removeSocket: 0
	},
	6: {
		regions: 5,
		step2: 6,
		end: 14,
		removePlug: 0,
		removeSocket: 0
	}
}, ue = {
	3: {
		1: {
			coal: 4,
			oil: 2,
			garbage: 1,
			uranium: 1
		},
		2: {
			coal: 5,
			oil: 3,
			garbage: 2,
			uranium: 1
		},
		3: {
			coal: 3,
			oil: 4,
			garbage: 3,
			uranium: 1
		}
	},
	4: {
		1: {
			coal: 5,
			oil: 3,
			garbage: 1,
			uranium: 1
		},
		2: {
			coal: 6,
			oil: 4,
			garbage: 2,
			uranium: 2
		},
		3: {
			coal: 4,
			oil: 5,
			garbage: 3,
			uranium: 2
		}
	},
	5: {
		1: {
			coal: 5,
			oil: 4,
			garbage: 2,
			uranium: 2
		},
		2: {
			coal: 7,
			oil: 5,
			garbage: 3,
			uranium: 3
		},
		3: {
			coal: 5,
			oil: 6,
			garbage: 4,
			uranium: 2
		}
	},
	6: {
		1: {
			coal: 7,
			oil: 5,
			garbage: 3,
			uranium: 2
		},
		2: {
			coal: 9,
			oil: 6,
			garbage: 5,
			uranium: 3
		},
		3: {
			coal: 6,
			oil: 7,
			garbage: 6,
			uranium: 3
		}
	}
}, de = [
	10,
	15,
	20
], fe = {
	1: 1,
	2: 2,
	3: 3
}, pe = () => ({
	coal: 0,
	oil: 0,
	garbage: 0,
	uranium: 0
});
function me(e, t) {
	return e === "wind" ? !1 : e === "hybrid" ? t === "coal" || t === "oil" : e === t;
}
function P(e, t) {
	return e.kind === "wind" ? !0 : e.kind === "hybrid" ? t.coal + t.oil >= e.need : t[e.kind] >= e.need;
}
function he(e, t) {
	if (!P(e, t)) return null;
	let n = { ...t };
	if (e.kind === "wind") return n;
	if (e.kind !== "hybrid") return n[e.kind] -= e.need, n;
	let r = e.need, i = Math.min(n.coal, r);
	return n.coal -= i, r -= i, n.oil -= r, n;
}
function ge(e, t) {
	let n = ae[t];
	for (let t = 0; t < n.length; t += 1) if ((e[t] ?? 0) > 0) return n[t].price;
	return null;
}
function _e(e, t, n, r) {
	return ge(n, t) ?? (e === "usa" && t === "coal" && r > 0 ? 8 : null);
}
function ve(e, t) {
	return e.cities.find((e) => e.id === t);
}
function ye(e, t, n, r) {
	return e === "wind" ? 0 : e === "hybrid" ? Math.max(0, t * 2 - n.coal - n.oil) : e === r ? Math.max(0, t * 2 - n[r]) : 0;
}
function be(e, t, n, r, i) {
	let a = new Set(t), o = e.cities.filter((e) => a.has(e.region)).map((e) => e.id), s = new Set(o);
	if (!s.has(r)) return null;
	let c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map();
	for (let e of o) c.set(e, Infinity);
	for (let e of n) c.has(e) && c.set(e, 0);
	let u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Map();
	for (let e of o) d.set(e, []);
	for (let [t, n, r] of e.links) s.has(t) && s.has(n) && (d.get(t).push([n, r]), d.get(n).push([t, r]));
	for (;;) {
		let e = null;
		for (let t of o) u.has(t) || (e === null || (c.get(t) ?? Infinity) < (c.get(e) ?? Infinity)) && (e = t);
		if (e === null) break;
		let t = c.get(e) ?? Infinity;
		if (t === Infinity) break;
		u.add(e);
		for (let [n, r] of d.get(e) ?? []) {
			let a = t + r;
			a < (c.get(n) ?? Infinity) && (c.set(n, a), i && l.set(n, e));
		}
	}
	let f = c.get(r);
	if (f == null || f === Infinity) return null;
	if (i) for (let e = r; e; e = l.get(e)) i.unshift(e);
	return f;
}
function xe(e, t, n, r, i, a) {
	let o = ve(e, r);
	if (!o || !t.includes(o.region) || i >= fe[a] || n.includes(r)) return null;
	if (n.length === 0) return i === 0 ? de[0] : null;
	let s = be(e, t, n, r);
	return s == null ? null : s + de[i];
}
//#endregion
//#region src/game/meta.ts
var Se = {
	id: "powergrid",
	uuid: "cc1545c1-fdf2-42af-9eab-5fc9c6794c5b",
	tier: "alpha",
	mechanics: [
		"auction",
		"route-building",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.powergrid.name",
	descKey: "games.powergrid.desc",
	rulesKey: "games.powergrid.rules",
	rulesUrl: { de: "https://2f-spiele.de/pdf/funkenschlag-recharged-anleitung_de.pdf" },
	icon: "⚡",
	iconImg: "games/powergrid.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [
		3,
		4,
		5
	],
	accent: "#e8b73a",
	releasedAt: "2026-11-28T11:08:00+08:00",
	search: {
		py: "dian li gong si",
		init: "dlgs"
	},
	hotseat: "open",
	botDelayMs: 900
}, F = t.string(), I = t.int().min(1).max(100), Ce = t.enum(["germany", "usa"]), L = t.enum([
	"green",
	"brown",
	"red",
	"blue",
	"yellow",
	"purple",
	"darkgreen",
	"lightgreen"
]), we = t.enum([
	"coal",
	"oil",
	"garbage",
	"uranium"
]), Te = t.object({
	coal: t.int().nonnegative(),
	oil: t.int().nonnegative(),
	garbage: t.int().nonnegative(),
	uranium: t.int().nonnegative()
}), Ee = t.object({
	coal: t.int().nonnegative(),
	oil: t.int().nonnegative(),
	garbage: t.int().nonnegative(),
	uranium: t.int().nonnegative()
}), R = t.object({ map: Ce.default("germany") }).prefault({}), z = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseArea"),
		region: L
	}),
	t.object({
		type: t.literal("offer"),
		plant: I,
		bid: t.int().nonnegative()
	}),
	t.object({ type: t.literal("declineOffer") }),
	t.object({
		type: t.literal("bid"),
		amount: t.int().nonnegative()
	}),
	t.object({ type: t.literal("passBid") }),
	t.object({
		type: t.literal("scrap"),
		plant: I
	}),
	t.object({
		type: t.literal("buyResource"),
		plant: I,
		resource: we
	}),
	t.object({
		type: t.literal("transferFuel"),
		from: I,
		to: I,
		resource: we
	}),
	t.object({ type: t.literal("endResources") }),
	t.object({
		type: t.literal("build"),
		city: t.string().max(40)
	}),
	t.object({ type: t.literal("endBuild") }),
	t.object({
		type: t.literal("submitPower"),
		runs: t.array(I).max(4)
	})
]), De = t.object({
	map: Ce,
	round: t.int().min(1),
	step: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	phase: t.enum([
		"areas",
		"auction",
		"resources",
		"build",
		"bureaucracy",
		"over"
	]),
	order: t.array(F),
	areas: t.array(L),
	players: t.array(t.object({
		rid: F,
		money: t.int().nonnegative(),
		cities: t.array(t.string()),
		plants: t.array(t.object({
			id: I,
			fuel: Te
		})),
		supplied: t.int().nonnegative()
	})),
	market: t.array(I),
	deckCount: t.int().nonnegative(),
	discount: I.nullable(),
	auction: t.object({
		offerer: F,
		stage: t.enum(["offer", "bidding"]),
		plant: I.nullable(),
		bid: t.int().nonnegative(),
		high: F.nullable(),
		passed: t.array(F)
	}).nullable(),
	pendingScrap: F.nullable(),
	turn: F.nullable(),
	prices: t.object({
		coal: t.array(t.int().nonnegative()),
		oil: t.array(t.int().nonnegative()),
		garbage: t.array(t.int().nonnegative()),
		uranium: t.array(t.int().nonnegative())
	}),
	supply: Ee,
	endTriggered: t.boolean(),
	finalResult: t.object({
		ranking: t.array(F),
		supplied: t.record(t.string(), t.int().nonnegative())
	}).nullable()
}), Oe = t.object({}), B = (e) => ({ code: e });
function ke(e) {
	return e.players.length;
}
function V(e) {
	return le[ke(e)] ?? le[4];
}
function Ae(e) {
	return V(e).regions;
}
function H(t) {
	for (let n = t.deck.length - 1; n > 0; --n) {
		let r = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1;
		let i = t.deck[n];
		t.deck[n] = t.deck[r], t.deck[r] = i;
	}
}
function U(e, t) {
	e.market.push(t), e.market.sort((e, t) => e - t);
}
function je(e) {
	return e.step === 3 ? e.market : e.market.slice(0, 4);
}
function Me(e, t) {
	return e.discount === t ? 1 : t;
}
function Ne(e) {
	return e.plants.reduce((e, t) => Math.max(e, t.id), 0);
}
function Pe(e) {
	return e.players.map((e, t) => t).sort((t, n) => {
		let r = e.players[t], i = e.players[n];
		if (r.cities.length !== i.cities.length) return i.cities.length - r.cities.length;
		let a = Ne(i) - Ne(r);
		return a === 0 ? t - n : a;
	});
}
function Fe(e, t) {
	e.auction = {
		turn: t,
		stage: "offer",
		offerer: t,
		plant: null,
		bid: 0,
		high: null,
		passed: []
	};
}
function W(e) {
	e.phase = "auction", e.bought = [], e.declined = [], e.pendingScrap = null, e.discount = e.market.length > 0 ? e.market[0] : null, Fe(e, e.order[0]);
}
function Ie(e, t) {
	let n = e.order.indexOf(t);
	for (let t = 1; t <= e.order.length; t += 1) {
		let r = e.order[(n + t) % e.order.length];
		if (!(e.bought.includes(r) || e.declined.includes(r))) return r;
	}
	return null;
}
function G(e, t) {
	let n = e.auction;
	if (!n) return null;
	let r = e.order.indexOf(t);
	for (let t = 1; t <= e.order.length; t += 1) {
		let i = e.order[(r + t) % e.order.length];
		if (i !== n.high && !(e.bought.includes(i) || e.declined.includes(i) || n.passed.includes(i))) return i;
	}
	return null;
}
function K(e) {
	e.market.length > 0 && e.market.shift(), H(e);
}
function Le(e) {
	for (let t = 0; t < 30; t += 1) {
		let t = e.deck.shift();
		if (t === void 0) return;
		if (t === 100) {
			e.step3Next = !0, H(e);
			return;
		}
		if (e.discount != null && t < e.discount) {
			e.discount = null;
			continue;
		}
		U(e, t);
		return;
	}
}
function q(e) {
	if (e.step3Next) e.market.length > 0 && e.market.shift(), e.step = 3, e.step3Next = !1;
	else if (e.discount != null) {
		let t = e.discount;
		if (e.discount = null, e.market.includes(t)) {
			e.market = e.market.filter((e) => e !== t);
			let n = e.deck.shift();
			n === 100 ? (K(e), e.step = 3) : n !== void 0 && U(e, n);
		}
	}
	e.discount = null, e.auction = null, e.round === 1 && (e.order = Pe(e)), e.phase = "resources", e.done = [], e.turn = e.order[e.order.length - 1];
}
function Re(e) {
	let t = e.auction;
	if (t) {
		if (t.high === t.offerer) {
			let n = Ie(e, t.offerer);
			n === null ? q(e) : Fe(e, n);
		} else Fe(e, t.offerer);
	}
}
function J(e, t, n) {
	for (let r of T) {
		let i = n[r];
		for (let e of t.plants) {
			if (i <= 0) break;
			let t = D[e.id];
			if (!me(t.kind, r)) continue;
			let n = ye(t.kind, t.need, e.fuel, r), a = Math.min(n, i);
			e.fuel[r] += a, i -= a;
		}
		e.supply[r] += i;
	}
}
function ze(e) {
	let t = e.auction;
	if (!t || t.high == null || t.plant == null) return [];
	let n = t.high, r = t.plant, i = e.players[n], a = [{
		kind: "pg-sale",
		rid: i.rid,
		data: {
			plant: r,
			bid: t.bid,
			slot: e.market.indexOf(r),
			discount: e.discount === r
		}
	}];
	return i.money -= t.bid, i.plants.push({
		id: r,
		fuel: pe()
	}), i.plants.sort((e, t) => e.id - t.id), e.map === "germany" && r === 39 && (e.atomicExit = !0), e.market = e.market.filter((e) => e !== r), e.discount === r && (e.discount = null), e.bought.push(n), Le(e), i.plants.length > 3 ? (e.pendingScrap = n, a) : (Re(e), a);
}
function Be(e) {
	if (e.step2Done = !0, e.step === 1 && (e.step = 2), e.market.length === 0) return;
	e.market.shift();
	let t = e.deck.shift();
	if (t !== void 0) {
		if (t === 100) {
			e.step3Next = !0, K(e);
			return;
		}
		U(e, t);
	}
}
function Ve(e) {
	let t = ue[ke(e)]?.[e.step] ?? ue[4][e.step];
	for (let n of T) {
		if (n === "uranium" && e.atomicExit) continue;
		let r = t[n];
		for (; r > 0 && e.supply[n] > 0;) {
			let t = -1;
			for (let r = ae[n].length - 1; r >= 0; --r) if ((e.prices[n][r] ?? 0) < ae[n][r].cap) {
				t = r;
				break;
			}
			if (t < 0) break;
			e.prices[n][t] += 1, --e.supply[n], --r;
		}
	}
}
function He(e) {
	if (e.step === 3) {
		e.market.length > 0 && e.market.shift();
		let t = e.deck.shift();
		t !== void 0 && t !== 100 && U(e, t);
		return;
	}
	if (e.market.length > 0) {
		let t = e.market[e.market.length - 1];
		e.market.pop(), e.deck.push(t);
	}
	let t = e.deck.shift();
	if (t !== void 0) {
		if (t === 100) {
			e.step3Next = !0, K(e);
			return;
		}
		U(e, t);
	}
}
function Ue(e) {
	let t = e.players.map((e, t) => t).sort((t, n) => {
		let r = e.players[t].supplied, i = e.players[n].supplied;
		return r === i ? e.players[n].money - e.players[t].money : i - r;
	});
	e.finalSupplied = e.players.map((e) => e.supplied), e.finalRanking = t, e.phase = "over", e.turn = null, e.auction = null, e.pendingScrap = null;
}
function We(e) {
	if (e.endTriggered) {
		Ue(e);
		return;
	}
	Ve(e), e.step3Next || He(e), e.order = Pe(e), e.step3Next &&= (e.step = 3, !1), e.round += 1, W(e);
}
function Ge(e, t, n) {
	let r = e.players.filter((e) => e.cities.includes(n)).length;
	return xe(M[e.map], e.areas, e.players[t].cities, n, r, e.step);
}
function Ke(e) {
	if (e.phase === "areas") {
		let t = e.order[e.areaPicks];
		return t == null ? null : e.players[t].rid;
	}
	return e.pendingScrap == null ? e.phase === "auction" ? e.auction ? e.players[e.auction.turn].rid : null : e.turn == null ? null : e.players[e.turn].rid : e.players[e.pendingScrap].rid;
}
function Y(t, n, r) {
	let i = t.map, a = le[Math.max(3, Math.min(6, n.length))] ?? le[4], o = 0, s = (t) => {
		let n = [...t];
		for (let t = n.length - 1; t > 0; --t) {
			let i = e(r, o, t + 1);
			o += 1;
			let a = n[t];
			n[t] = n[i], n[i] = a;
		}
		return n;
	}, c = s(k), l = c.slice(0, 8).sort((e, t) => e - t), u = c[8], d = c.slice(9).slice(a.removePlug), f = s(A).slice(a.removeSocket), p = [
		u,
		...s([...d, ...f]),
		100
	], m = s(n.map((e, t) => t)), h = {};
	for (let e of T) {
		let t = ae[e], n = t.map(() => 0), r = se[e];
		for (let e = t.length - 1; e >= 0 && r > 0; --e) {
			let i = Math.min(t[e].cap, r);
			n[e] = i, r -= i;
		}
		h[e] = n;
	}
	let g = {};
	for (let e of T) g[e] = oe[e] - se[e];
	return { state: {
		seed: r,
		rngCursor: o,
		map: i,
		players: n.map((e) => ({
			rid: e,
			money: 50,
			plants: [],
			cities: [],
			supplied: 0
		})),
		order: m,
		round: 1,
		step: 1,
		phase: "areas",
		areas: [],
		areaPicks: 0,
		market: l,
		deck: p,
		discount: null,
		auction: null,
		pendingScrap: null,
		bought: [],
		declined: [],
		turn: null,
		done: [],
		prices: h,
		supply: g,
		step2Done: !1,
		step3Next: !1,
		endTriggered: !1,
		atomicExit: !1,
		finalSupplied: null,
		finalRanking: null
	} };
}
function qe(e, t, n) {
	let r = structuredClone(e), i = r.players.findIndex((e) => e.rid === n.by);
	if (i < 0) return B("games.powergrid.errTurn");
	if (r.phase === "over") return B("games.powergrid.errAction");
	if (t.type === "transferFuel") {
		let e = r.players[i], n = e.plants.find((e) => e.id === t.from), a = e.plants.find((e) => e.id === t.to);
		if (!n || !a || n === a) return B("games.powergrid.errTransfer");
		let o = D[a.id];
		return n.fuel[t.resource] < 1 || ye(o.kind, o.need, a.fuel, t.resource) < 1 ? B("games.powergrid.errTransfer") : (--n.fuel[t.resource], a.fuel[t.resource] += 1, {
			state: r,
			fx: [{
				kind: "pg-transfer",
				rid: e.rid,
				data: {
					from: n.id,
					to: a.id,
					resource: t.resource
				}
			}]
		});
	}
	if (r.pendingScrap != null) {
		if (t.type !== "scrap" || i !== r.pendingScrap) return B("games.powergrid.errTurn");
		let e = r.players[i], n = e.plants.find((e) => e.id === t.plant);
		return n ? (e.plants = e.plants.filter((e) => e !== n), J(r, e, n.fuel), r.pendingScrap = null, Re(r), { state: r }) : B("games.powergrid.errScrap");
	}
	switch (r.phase) {
		case "areas": return t.type === "chooseArea" ? r.order[r.areaPicks] === i ? !ee[r.map].includes(t.region) || r.areas.includes(t.region) || r.areas.length > 0 && !te[r.map][t.region]?.some((e) => r.areas.includes(e)) ? B("games.powergrid.errArea") : (r.areas.push(t.region), r.areaPicks += 1, r.areaPicks >= Ae(r) && (r.round = 1, W(r)), { state: r }) : B("games.powergrid.errTurn") : B("games.powergrid.errAction");
		case "auction": {
			let e = r.auction;
			if (!e) return B("games.powergrid.errAction");
			if (e.turn !== i) return B("games.powergrid.errTurn");
			if (t.type === "offer") {
				if (e.stage !== "offer") return B("games.powergrid.errAction");
				if (!je(r).includes(t.plant)) return B("games.powergrid.errPlant");
				if (t.bid < Me(r, t.plant) || t.bid > r.players[i].money) return B("games.powergrid.errBid");
				e.stage = "bidding", e.plant = t.plant, e.bid = t.bid, e.high = i, e.passed = [];
				let n = G(r, i);
				return n === null ? {
					state: r,
					fx: ze(r)
				} : (e.turn = n, { state: r });
			}
			if (t.type === "declineOffer") {
				if (e.stage !== "offer" || r.round === 1) return B("games.powergrid.errAction");
				r.declined.push(i);
				let t = Ie(r, i);
				return t === null ? q(r) : Fe(r, t), { state: r };
			}
			if (t.type === "bid") {
				if (e.stage !== "bidding") return B("games.powergrid.errAction");
				if (e.high === i || t.amount <= e.bid || t.amount > r.players[i].money) return B("games.powergrid.errBid");
				e.bid = t.amount, e.high = i;
				let n = G(r, i);
				return n === null ? {
					state: r,
					fx: ze(r)
				} : (e.turn = n, { state: r });
			}
			if (t.type === "passBid") {
				if (e.stage !== "bidding") return B("games.powergrid.errAction");
				e.passed.includes(i) || e.passed.push(i);
				let t = G(r, i);
				return t === null ? {
					state: r,
					fx: ze(r)
				} : (e.turn = t, { state: r });
			}
			return B("games.powergrid.errAction");
		}
		case "resources": {
			if (r.turn !== i) return B("games.powergrid.errTurn");
			if (t.type === "endResources") {
				r.done.push(i);
				let e = [...r.order].reverse().find((e) => !r.done.includes(e));
				return e == null ? (r.phase = "build", r.done = [], r.turn = r.order[r.order.length - 1]) : r.turn = e, { state: r };
			}
			if (t.type !== "buyResource") return B("games.powergrid.errAction");
			let e = r.players[i], n = e.plants.find((e) => e.id === t.plant);
			if (!n) return B("games.powergrid.errResource");
			let a = D[n.id];
			if (!me(a.kind, t.resource)) return B("games.powergrid.errResource");
			if (ye(a.kind, a.need, n.fuel, t.resource) <= 0) return B("games.powergrid.errFuel");
			let o = _e(r.map, t.resource, r.prices[t.resource], r.supply[t.resource]);
			if (o == null) return B("games.powergrid.errResource");
			if (e.money < o) return B("games.powergrid.errMoney");
			let s = r.prices[t.resource].findIndex((e) => e > 0);
			return s < 0 ? --r.supply[t.resource] : --r.prices[t.resource][s], e.money -= o, n.fuel[t.resource] += 1, {
				state: r,
				fx: [{
					kind: "pg-fuel",
					rid: e.rid,
					data: {
						plant: n.id,
						resource: t.resource,
						price: o
					}
				}]
			};
		}
		case "build": {
			if (r.turn !== i) return B("games.powergrid.errTurn");
			if (t.type === "endBuild") {
				r.done.push(i);
				let e = [...r.order].reverse().find((e) => !r.done.includes(e));
				return e == null ? (r.endTriggered = r.players.some((e) => e.cities.length >= V(r).end), r.phase = "bureaucracy", r.done = [], r.turn = r.order[0], !r.endTriggered && !r.step2Done && r.players.some((e) => e.cities.length >= V(r).step2) && Be(r)) : r.turn = e, { state: r };
			}
			if (t.type !== "build") return B("games.powergrid.errAction");
			let e = r.players[i], n = Ge(r, i, t.city);
			return n == null ? B("games.powergrid.errBuild") : e.money < n ? B("games.powergrid.errMoney") : (e.money -= n, e.cities.push(t.city), {
				state: r,
				fx: [{
					kind: "pg-build",
					rid: e.rid,
					data: {
						city: t.city,
						cost: n
					}
				}]
			});
		}
		case "bureaucracy": {
			if (r.turn !== i) return B("games.powergrid.errTurn");
			if (t.type !== "submitPower") return B("games.powergrid.errAction");
			let e = r.players[i], n = [...new Set(t.runs)];
			for (let t of n) {
				let n = e.plants.find((e) => e.id === t);
				if (!n || !P(D[t], n.fuel)) return B("games.powergrid.errFuel");
			}
			let a = pe(), o = 0;
			for (let t of n) {
				let n = e.plants.find((e) => e.id === t), r = D[t], i = he(r, n.fuel);
				for (let e of T) a[e] += n.fuel[e] - i[e];
				n.fuel = i, o += r.cities;
			}
			for (let e of T) r.supply[e] += a[e];
			let s = Math.min(o, e.cities.length);
			e.supplied = s;
			let c = r.endTriggered ? 0 : ce[Math.min(s, ce.length - 1)];
			e.money += c, r.done.push(i);
			let l = r.order.find((e) => !r.done.includes(e));
			return l == null ? We(r) : r.turn = l, {
				state: r,
				fx: [{
					kind: "pg-power",
					rid: e.rid,
					data: {
						runs: n,
						supplied: s,
						income: c,
						lit: s === e.cities.length ? e.cities : []
					}
				}]
			};
		}
		default: return B("games.powergrid.errAction");
	}
}
function X(e) {
	let t = e;
	return {
		public: {
			map: t.map,
			round: t.round,
			step: t.step,
			phase: t.phase,
			order: t.order.map((e) => t.players[e].rid),
			areas: [...t.areas],
			players: t.players.map((e) => ({
				rid: e.rid,
				money: e.money,
				cities: [...e.cities],
				plants: e.plants.map((e) => ({
					id: e.id,
					fuel: { ...e.fuel }
				})),
				supplied: e.supplied
			})),
			market: [...t.market],
			deckCount: t.deck.length,
			discount: t.discount,
			auction: t.auction ? {
				offerer: t.players[t.auction.offerer].rid,
				stage: t.auction.stage,
				plant: t.auction.plant,
				bid: t.auction.bid,
				high: t.auction.high == null ? null : t.players[t.auction.high].rid,
				passed: t.auction.passed.map((e) => t.players[e].rid)
			} : null,
			pendingScrap: t.pendingScrap == null ? null : t.players[t.pendingScrap].rid,
			turn: Ke(t),
			prices: {
				coal: [...t.prices.coal],
				oil: [...t.prices.oil],
				garbage: [...t.prices.garbage],
				uranium: [...t.prices.uranium]
			},
			supply: { ...t.supply },
			endTriggered: t.endTriggered,
			finalResult: t.finalRanking ? {
				ranking: t.finalRanking.map((e) => t.players[e].rid),
				supplied: Object.fromEntries(t.players.map((e) => [e.rid, e.supplied]))
			} : null
		},
		private: {}
	};
}
function Z(e) {
	if (e.phase !== "over" || !e.finalRanking) return { phase: e.phase };
	let t = e.finalRanking.map((t) => e.players[t].rid), n = {};
	for (let t of e.players) n[t.rid] = t.supplied;
	let r = e.finalRanking[0], i = e.players[r].supplied, a = -1;
	for (let t of e.players) t.supplied === i && t.money > a && (a = t.money);
	return {
		phase: "over",
		winner: e.finalRanking.filter((t) => e.players[t].supplied === i && e.players[t].money === a).map((t) => e.players[t].rid),
		ranking: t,
		scores: n
	};
}
var Q = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Se,
	schemas: {
		action: z,
		publicView: De,
		privateView: Oe,
		config: R
	},
	setup: Y,
	reduce: qe,
	viewFor: X,
	status: Z
}, Je = {
	coal: "games.powergrid.resCoal",
	oil: "games.powergrid.resOil",
	garbage: "games.powergrid.resGarbage",
	uranium: "games.powergrid.resUranium"
}, Ye = {
	...Je,
	hybrid: "games.powergrid.kindHybrid",
	wind: "games.powergrid.kindWind"
}, Xe = {
	coal: ["#896147", "#ddc4a4"],
	oil: ["#2d4546", "#b5c9c6"],
	garbage: ["#9c751c", "#f2dfa0"],
	uranium: ["#974441", "#e8b5a8"],
	wind: ["#347176", "#bddbda"],
	hybrid: ["#556752", "#c4d0b9"]
};
function Ze() {
	return /* @__PURE__ */ v("svg", {
		className: "pg-icon",
		viewBox: "0 0 20 22",
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("path", {
			fill: "currentColor",
			d: "M8 1 2 12h6L6 21 18 8h-7l4-7Z"
		})
	});
}
function Qe({ color: e }) {
	return /* @__PURE__ */ y("svg", {
		className: "pg-avatar",
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("circle", {
				cx: "16",
				cy: "16",
				r: "16",
				fill: e
			}),
			/* @__PURE__ */ v("circle", {
				cx: "16",
				cy: "11",
				r: "4.6",
				fill: "#fffaf0"
			}),
			/* @__PURE__ */ v("path", {
				d: "M7 25c0-10 18-10 18 0Z",
				fill: "#fffaf0"
			})
		]
	});
}
function $e({ color: e = "#bc8735" }) {
	return /* @__PURE__ */ y("svg", {
		className: "pg-icon",
		viewBox: "0 0 20 20",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("path", {
			fill: e,
			stroke: "#253e36",
			strokeWidth: ".7",
			d: "M1 9 10 1l9 8h-2v9H3V9Z"
		}), /* @__PURE__ */ v("path", {
			fill: "#253e36",
			d: "M8 18v-6h4v6Z"
		})]
	});
}
function $({ kind: e }) {
	let [t] = Xe[e];
	return /* @__PURE__ */ y("svg", {
		className: "pg-icon",
		viewBox: "-10 -10 20 20",
		"aria-hidden": !0,
		children: [
			e === "coal" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", {
				fill: t,
				d: "m-8 5 1-7 4-2 3-4 5 3 3 5-1 6-10 2Z"
			}), /* @__PURE__ */ v("path", {
				fill: "#fffaf0",
				d: "m-6 1 5-4 4 1-2 4Z"
			})] }),
			e === "oil" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("rect", {
				x: "-6",
				y: "-8",
				width: "12",
				height: "16",
				rx: "2",
				fill: t
			}), /* @__PURE__ */ v("path", {
				d: "M-6-4H6M-6 4H6",
				stroke: "#fffaf0"
			})] }),
			e === "garbage" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", {
				fill: t,
				d: "M-5-4H5v11H-5zM-7-7H7v3H-7zM-2-9h4v3h-4z"
			}), /* @__PURE__ */ v("path", {
				d: "M0-2V5",
				stroke: "#fffaf0"
			})] }),
			e === "uranium" && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("circle", {
					r: "8",
					fill: t
				}),
				/* @__PURE__ */ v("circle", {
					r: "2",
					fill: "#fffaf0"
				}),
				/* @__PURE__ */ v("path", {
					fill: "#fffaf0",
					d: "m-1-3-3-3h7L1-3ZM3 1l4-1-3 6-2-3ZM-3 1l1 2-2 3-3-6Z"
				})
			] }),
			e === "wind" && /* @__PURE__ */ v("path", {
				fill: t,
				d: "M-2-8-7 2h6l-2 7 10-12H1l3-5Z"
			}),
			e === "hybrid" && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					fill: Xe.coal[0],
					d: "m-9 2 2-5 4-2 3 6-3 4Z"
				}),
				/* @__PURE__ */ v("rect", {
					x: "2",
					y: "-6",
					width: "6",
					height: "12",
					rx: "1",
					fill: Xe.oil[0]
				}),
				/* @__PURE__ */ v("path", {
					d: "M2-3H8",
					stroke: "#fffaf0"
				})
			] })
		]
	});
}
function et({ kind: e }) {
	let [t, n] = Xe[e];
	return /* @__PURE__ */ y("svg", {
		className: "pg-plant-art",
		viewBox: "0 0 150 95",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("rect", {
				width: "150",
				height: "95",
				fill: n
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 62Q35 41 65 56T150 50v45H0Z",
				fill: "#617f70"
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 76Q46 63 81 75T150 67v28H0Z",
				fill: "#35594f"
			}),
			e === "wind" && [
				[
					27,
					42,
					.7
				],
				[
					68,
					30,
					1.05
				],
				[
					113,
					47,
					.7
				]
			].map(([e, t, n]) => /* @__PURE__ */ y("g", {
				transform: "translate(" + e + " " + t + ") scale(" + n + ")",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M0 0v44",
						stroke: "#f5e4be",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m0-1-18 5 13 1 5-4 14 12-5-11-8-2 5-17-5 6Z",
						fill: "#f5e4be"
					}),
					/* @__PURE__ */ v("circle", {
						r: "2",
						fill: "#1c302b"
					})
				]
			}, e)),
			e === "uranium" && /* @__PURE__ */ v("path", {
				d: "M20 74q14-23 9-44h26q-6 21 8 44Zm60 0q11-17 7-35h23q-5 19 10 35Z",
				fill: "#ded2ae",
				stroke: "#1c302b",
				strokeWidth: "1.5"
			}),
			e === "oil" && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "m18 73 11-47h14l9 47M24 55h22M27 43h16M29 26l18 47M43 26 23 73",
					fill: "none",
					stroke: "#ead9b0",
					strokeWidth: "2.2"
				}),
				/* @__PURE__ */ v("path", {
					d: "m56 73 11-28h21l13-10 12 3-9 8-27 6-4 21Z",
					fill: "#b47d60",
					stroke: "#1c302b",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("rect", {
					x: "116",
					y: "53",
					width: "21",
					height: "21",
					rx: "2",
					fill: "#cab189",
					stroke: "#1c302b"
				})
			] }),
			(e === "coal" || e === "hybrid" || e === "garbage") && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: e === "garbage" ? "M17 76V51h19V41h32v13h24v22Z" : "M15 76V56l23-10v10l20-13v12l23-7v28Z",
					fill: t,
					stroke: "#1c302b",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("path", {
					d: "M83 52h47v24H83Z",
					fill: "#d5bd8c",
					stroke: "#1c302b",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("path", {
					d: "M95 54V21h10v33m6 0V29h8v25",
					fill: "#af735a",
					stroke: "#1c302b",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ v("path", {
					d: "M96 27h8m8 8h6",
					stroke: "#f5e4be",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "m9 77 9-8 8 7 8-9 13 10Z",
					fill: "#233c35"
				})
			] })
		]
	});
}
function tt({ plant: e, discount: t }) {
	let n = u(), r = D[e];
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ y("span", {
			className: "pg-plant-visual",
			children: [
				/* @__PURE__ */ v(et, { kind: r.kind }),
				/* @__PURE__ */ v("b", {
					className: "pg-plant-id",
					children: e
				}),
				t && /* @__PURE__ */ v("span", {
					className: "pg-plant-tag",
					children: n("games.powergrid.discountTag")
				})
			]
		}),
		/* @__PURE__ */ v("span", {
			className: "pg-plant-name",
			children: n(Ye[r.kind])
		}),
		/* @__PURE__ */ y("span", {
			className: "pg-plant-stats",
			children: [r.need > 0 ? /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v($, { kind: r.kind }), r.need] }) : /* @__PURE__ */ v("span", {
				className: "pg-no-fuel",
				children: n("games.powergrid.noFuel")
			}), /* @__PURE__ */ y("span", {
				"aria-label": n("games.powergrid.plantCities", { n: r.cities }),
				children: [/* @__PURE__ */ v($e, {}), r.cities]
			})]
		})
	] });
}
function nt({ plant: e, fuel: t }) {
	let n = u(), r = D[e], i = T.filter((e) => me(r.kind, e)).flatMap((e) => Array.from({ length: t[e] }, () => e)), a = T.filter((e) => t[e] > 0).map((e) => n("games.powergrid.plantFuel", {
		n: t[e],
		res: n(Je[e])
	})).join(" · ");
	return r.need ? /* @__PURE__ */ v("span", {
		className: "pg-storage",
		role: "img",
		"aria-label": a || n("games.powergrid.emptyStorage"),
		children: Array.from({ length: r.need * 2 }, (e, t) => /* @__PURE__ */ v("span", {
			className: i[t] ? "is-filled" : "",
			children: i[t] && /* @__PURE__ */ v($, { kind: i[t] })
		}, t))
	}) : null;
}
//#endregion
//#region src/game/board.tsx
var rt = {
	green: "M117 100L202 91 210 14 253 3 283 26 288 81 315 119 307 170 321 218 310 286 257 313 222 278 208 239 152 215 126 184Z",
	brown: "M288 81L345 86 359 55 408 55 456 92 523 117 540 170 577 227 553 283 553 322 441 308 376 324 310 286 321 218 307 170 315 119Z",
	red: "M14 303L56 279 116 269 152 215 208 239 222 278 257 313 280 378 254 416 195 422 138 402 95 401 73 406 23 397Z",
	blue: "M23 397L73 406 95 401 138 402 195 422 254 416 244 488 230 532 250 584 214 607 156 609 123 605 81 599 66 561 43 548 52 498 20 465Z",
	yellow: "M254 416L280 378 257 313 310 286 376 324 441 308 553 322 537 365 560 409 523 456 450 504 432 553 381 571 322 587 250 584 230 532 244 488Z",
	purple: "M123 605L156 609 214 607 250 584 322 587 381 571 432 553 454 599 503 608 518 650 480 681 426 666 410 704 370 724 295 710 251 748 189 747 160 726 113 720 105 683Z"
}, it = "M35 65 142 71 235 112 387 104 517 82 616 88 682 135 695 183 725 202 761 187 821 183 906 187 963 182 1000 204 990 251 951 298 922 321 912 372 874 435 832 495 825 591 843 659 817 691 774 664 742 610 728 566 662 597 607 575 559 603 508 591 477 553 402 532 329 522 258 500 176 510 131 457 96 419 62 375 54 308 35 230Z";
function at(e) {
	if (e.id === "germany") return rt;
	let t = {};
	for (let n of e.cities) {
		let r = [
			[0, 0],
			[e.width, 0],
			[e.width, e.height],
			[0, e.height]
		];
		for (let t of e.cities) {
			if (t.id === n.id) continue;
			let e = t.x - n.x, i = t.y - n.y, a = e * (n.x + t.x) / 2 + i * (n.y + t.y) / 2, o = ([t, n]) => e * t + i * n - a, s = [];
			if (r.forEach((e, t) => {
				let n = r[(t + 1) % r.length], i = o(e), a = o(n);
				if (i <= 0 && s.push(e), i <= 0 != a <= 0) {
					let t = i / (i - a);
					s.push([e[0] + (n[0] - e[0]) * t, e[1] + (n[1] - e[1]) * t]);
				}
			}), r = s, !r.length) break;
		}
		r.length && (t[n.region] = (t[n.region] ?? "") + "M" + r.map(([e, t]) => e.toFixed(1) + "," + t.toFixed(1)).join(" ") + "Z");
	}
	return t;
}
var ot = {
	green: "#aabda2",
	brown: "#d3ac75",
	red: "#cb927e",
	blue: "#9ebac8",
	yellow: "#d9c87d",
	purple: "#b6aac1",
	darkgreen: "#8fae9c",
	lightgreen: "#b7c58a"
}, st = [
	"M193 10Q213 67 186 121T200 244T142 401T165 530T130 615",
	"M526 244Q469 280 478 313T414 424T397 518T460 675",
	"M103 704Q145 661 187 682T290 670T418 639T518 642",
	"M323 67Q349 130 330 180T339 269T400 397"
];
function ct({ x: e, y: t, owner: n, city: r, label: i }) {
	let { ref: a, hidden: o } = c("pg:house:" + n.rid + ":" + r);
	return /* @__PURE__ */ y("g", {
		transform: "translate(" + e + " " + t + ")",
		children: [/* @__PURE__ */ v("foreignObject", {
			x: "-9",
			y: "-9",
			width: "18",
			height: "18",
			children: /* @__PURE__ */ v("div", {
				ref: a,
				style: {
					width: "100%",
					height: "100%"
				}
			})
		}), /* @__PURE__ */ y("g", {
			visibility: o ? "hidden" : void 0,
			children: [
				/* @__PURE__ */ y("title", { children: [
					n.name,
					" · ",
					i
				] }),
				/* @__PURE__ */ v("path", {
					d: "M-8-1 0-8l8 7H6v8H-6v-8Z",
					fill: n.color,
					stroke: "#fffaf0",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ v("path", {
					d: "M-2 7V1h4v6Z",
					fill: "#20372f"
				})
			]
		})]
	});
}
function lt(e, t) {
	return e[0] < t[2] && e[2] > t[0] && e[1] < t[3] && e[3] > t[1];
}
function ut({ map: e, areas: t, openAreas: r, occupants: s, affordable: l, selected: d, onCity: f, onArea: p, regionSelection: m }) {
	let _ = u(), b = _(e.id === "germany" ? "games.powergrid.mapGermany" : "games.powergrid.mapUsa"), x = i(), { ref: S } = c("pg:map"), C = o(null), w = n((e) => {
		C.current = e, S(e);
	}, [S]), T = (e) => {
		let t = C.current?.querySelector("svg");
		if (!t) return;
		let n = t.getBoundingClientRect();
		t.dispatchEvent(new WheelEvent("wheel", {
			bubbles: !0,
			cancelable: !0,
			deltaY: e,
			clientX: n.left + n.width / 2,
			clientY: n.top + n.height / 2
		}));
	}, D = a(() => new Set(t), [t]), O = a(() => new Map(e.cities.map((e) => [e.id, e])), [e]), k = (e, t) => d?.route.some((n, r, i) => n === e && i[r + 1] === t || n === t && i[r + 1] === e), A = (e) => _(ne[e.id]), j = d && O.get(d.id), M = a(() => at(e), [e]), ee = e.cities.flatMap((e) => {
		let t = r.includes(e.region);
		return !t && !l.has(e.id) ? [] : [{
			key: t ? "area:" + e.region + ":" + e.id : e.id,
			rect: {
				x: e.x - 3,
				y: e.y - 3,
				w: 6,
				h: 6
			}
		}];
	}), N = e.cities.map((e) => [
		e.x - 10,
		e.y - 10,
		e.x + 10,
		e.y + 11
	]), te = [...e.cities].sort((e, t) => Number(t.id === d?.id) - Number(e.id === d?.id) || Number(s.has(t.id)) - Number(s.has(e.id)) || Number(D.has(t.region)) - Number(D.has(e.region))).flatMap((t) => {
		if (!D.has(t.region) && !m) return [];
		let n = A(t), r = Math.max(25, [...n].reduce((e, t) => e + (t.charCodeAt(0) > 255 ? 14 : 8), 8)), i = [
			[0, 26],
			[0, -15],
			[r / 2 + 14, 4],
			[-r / 2 - 14, 4],
			[r / 2 + 10, 21],
			[-r / 2 - 10, 21]
		];
		for (let [a, o] of i) {
			let i = [
				t.x + a - r / 2,
				t.y + o - 13,
				t.x + a + r / 2,
				t.y + o + 4
			];
			if (!(i[0] < 2 || i[1] < 2 || i[2] > e.width - 2 || i[3] > e.height - 2 || N.some((e) => lt(i, e)))) return N.push(i), [{
				id: t.id,
				x: t.x + a,
				y: t.y + o,
				name: n
			}];
		}
		return [];
	}), ie = e.links.filter(([e, t]) => D.has(O.get(e).region) && D.has(O.get(t).region)).sort(([e, t], [n, r]) => Number(!!k(n, r)) - Number(!!k(e, t))).map(([t, n, r]) => {
		let i = O.get(t), a = O.get(n), o = (i.x + a.x) / 2, s = (i.y + a.y) / 2, c = Math.hypot(a.x - i.x, a.y - i.y) || 1, l = (a.y - i.y) / c, u = (i.x - a.x) / c, { x: d, y: f, bounds: p } = [
			0,
			16,
			-16,
			26,
			-26,
			36,
			-36,
			49,
			-49
		].map((t) => {
			let n = Math.max(12, Math.min(e.width - 12, o + l * t)), r = Math.max(9, Math.min(e.height - 9, s + u * t)), i = [
				n - 11,
				r - 8,
				n + 11,
				r + 8
			];
			return {
				x: n,
				y: r,
				bounds: i,
				overlaps: N.filter((e) => lt(e, i)).length
			};
		}).sort((e, t) => e.overlaps - t.overlaps)[0];
		return N.push(p), {
			a: t,
			b: n,
			cost: r,
			x: d,
			y: f,
			cx: o,
			cy: s,
			marked: k(t, n)
		};
	});
	return /* @__PURE__ */ y("div", {
		className: "pg-map",
		ref: w,
		children: [
			/* @__PURE__ */ y(g, {
				sheetW: e.width,
				sheetH: e.height,
				fitKey: e.id,
				clampToSheet: !0,
				highlight: "off",
				eligible: ee,
				onTapEligible: (e) => e.startsWith("area:") ? p(e.split(":")[1]) : f(e),
				children: [
					/* @__PURE__ */ y("defs", { children: [/* @__PURE__ */ v("pattern", {
						id: x,
						width: "28",
						height: "28",
						patternUnits: "userSpaceOnUse",
						children: /* @__PURE__ */ v("path", {
							d: "M28 0H0V28",
							stroke: "#657967",
							strokeWidth: ".65",
							opacity: ".23",
							fill: "none"
						})
					}), /* @__PURE__ */ v("clipPath", {
						id: x + "-us",
						children: /* @__PURE__ */ v("path", { d: it })
					})] }),
					/* @__PURE__ */ v("rect", {
						x: "-2000",
						y: "-1200",
						width: "5000",
						height: "3300",
						fill: "url(#" + x + ")",
						pointerEvents: "none"
					}),
					/* @__PURE__ */ y("g", {
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ v("g", {
								clipPath: e.id === "usa" ? "url(#" + x + "-us)" : void 0,
								children: Object.entries(M).map(([t, n]) => {
									let i = t;
									return /* @__PURE__ */ v("path", {
										d: n,
										fill: ot[i],
										opacity: D.has(i) || r.includes(i) ? ".87" : ".43",
										stroke: e.id === "germany" ? "#f6efdb" : void 0,
										strokeWidth: "2.2",
										strokeDasharray: r.includes(i) ? "8 5" : void 0,
										className: r.includes(i) ? "pg-eligible" : void 0
									}, i);
								})
							}),
							e.id === "germany" && st.map((e) => /* @__PURE__ */ v("path", {
								d: e,
								stroke: "#779894",
								strokeWidth: "4",
								fill: "none",
								opacity: ".43"
							}, e)),
							e.links.map(([e, t]) => {
								let n = O.get(e), r = O.get(t), i = D.has(n.region) && D.has(r.region);
								return /* @__PURE__ */ v("line", {
									x1: n.x,
									y1: n.y,
									x2: r.x,
									y2: r.y,
									stroke: k(e, t) ? "#cf9b3a" : i ? E : "#829087",
									strokeWidth: k(e, t) ? 5 : i ? 2.4 : 1.25,
									opacity: i ? .93 : .6,
									strokeLinecap: "round"
								}, e + "-" + t);
							}),
							ie.map(({ a: e, b: t, cost: n, x: r, y: i, cx: a, cy: o, marked: s }) => /* @__PURE__ */ y("g", {
								className: "pg-link-price",
								"data-edge": e + "-" + t,
								children: [
									Math.hypot(r - a, i - o) > 10 && /* @__PURE__ */ v("line", {
										x1: a,
										y1: o,
										x2: r,
										y2: i,
										stroke: s ? "#99722d" : "#65786c",
										strokeDasharray: "2 2"
									}),
									/* @__PURE__ */ v("rect", {
										x: r - 10,
										y: i - 7,
										width: "20",
										height: "15",
										rx: "3",
										fill: s ? "#edbf61" : "#f5eed8"
									}),
									/* @__PURE__ */ v("text", {
										x: r,
										y: i + 5,
										textAnchor: "middle",
										children: n
									})
								]
							}, e + "-" + t)),
							e.cities.map((e) => {
								let t = s.get(e.id) ?? [], n = D.has(e.region), i = l.has(e.id) || r.includes(e.region);
								return /* @__PURE__ */ y("g", { children: [
									i && /* @__PURE__ */ v("circle", {
										className: "pg-eligible",
										cx: e.x,
										cy: e.y,
										r: e.id === d?.id ? 16 : 12,
										fill: "none",
										stroke: e.id === d?.id ? "#946220" : "#536746",
										strokeWidth: e.id === d?.id ? 3 : 1.6,
										strokeDasharray: "5 4"
									}),
									/* @__PURE__ */ v("circle", {
										cx: e.x,
										cy: e.y,
										r: t.length ? 10 : 6.1,
										fill: n || i ? "#fff8dc" : "#e7e5d6",
										stroke: t[0]?.color ?? (n || i ? "#485d52" : "#98a096"),
										strokeWidth: t.length ? 2.1 : 1.55
									}),
									t.map((n, r) => {
										let i = e.x + (r - (t.length - 1) / 2) * 9;
										return /* @__PURE__ */ v(ct, {
											x: i,
											y: e.y,
											owner: n,
											city: e.id,
											label: A(e)
										}, n.rid);
									}),
									t.length > 0 && /* @__PURE__ */ v(h, {
										name: "pg:city:" + e.id,
										r: {
											x: e.x - 10,
											y: e.y - 10,
											w: 20,
											h: 20
										}
									})
								] }, e.id);
							}),
							te.map((e) => /* @__PURE__ */ v("text", {
								className: "pg-city-name",
								x: e.x,
								y: e.y,
								textAnchor: "middle",
								opacity: D.has(O.get(e.id).region) ? 1 : .72,
								children: e.name
							}, e.id)),
							m && r.map((t) => {
								let n = e.cities.filter((e) => e.region === t), r = n.reduce((e, t) => e + t.x, 0) / n.length, i = n.reduce((e, t) => e + t.y, 0) / n.length;
								return /* @__PURE__ */ v("text", {
									className: "pg-city-name",
									x: r,
									y: i - 8,
									textAnchor: "middle",
									children: _(re[t])
								}, t);
							}),
							j && d && (() => {
								let t = j.x > e.width - 115, n = j.x + (t ? -55 : 55), r = Math.max(24, j.y - 45);
								return /* @__PURE__ */ y("g", {
									className: "pg-map-quote",
									children: [
										/* @__PURE__ */ v("path", {
											d: "M" + j.x + " " + (j.y - 14) + "L" + n + " " + r,
											stroke: "#896025",
											strokeWidth: "2"
										}),
										/* @__PURE__ */ v("rect", {
											x: n - 29,
											y: r - 13,
											width: "58",
											height: "25",
											rx: "5"
										}),
										/* @__PURE__ */ v("text", {
											x: n,
											y: r + 5,
											textAnchor: "middle",
											children: _("games.powergrid.buildCost", { n: d.cost })
										})
									]
								});
							})()
						]
					})
				]
			}),
			/* @__PURE__ */ v("span", {
				className: "pg-map-label",
				children: b
			}),
			/* @__PURE__ */ y("div", {
				className: "pg-map-key",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("i", { className: "pg-key-ring" }), _("games.powergrid.cityEmpty")] }),
					/* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("i", { className: "pg-key-ring is-legal" }), _("games.powergrid.cityAvailable")] }),
					/* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v($e, {}), _("games.powergrid.cityConnected")] })
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "pg-map-tools",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					className: "pg-btn",
					"aria-label": _("games.powergrid.zoomIn"),
					onClick: () => T(-1),
					children: "+"
				}), /* @__PURE__ */ v("button", {
					type: "button",
					className: "pg-btn",
					"aria-label": _("games.powergrid.zoomOut"),
					onClick: () => T(1),
					children: "−"
				})]
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
function dt(e, t) {
	let n = e.find((e) => e.rid === t)?.colorIndex ?? 0;
	return d[n % d.length];
}
function ft(e, t, n, r) {
	let i = e.find((e) => e.rid === t);
	return i && m(i, n) || r(dt(e, t).nameKey);
}
function pt(e, t) {
	let n = 0;
	return [...e].sort((e, t) => D[t.id].cities - D[e.id].cities).filter((e) => n >= t || !P(D[e.id], e.fuel) ? !1 : (n += D[e.id].cities, !0)).map((e) => e.id);
}
function mt({ player: e, name: t, color: n, acting: r, muted: i }) {
	let a = u(), { ref: o } = c("pg:seat:" + e.rid);
	return /* @__PURE__ */ y("div", {
		ref: o,
		className: "pg-seat" + (r ? " is-acting" : "") + (i ? " is-muted" : ""),
		"data-active": r,
		children: [
			/* @__PURE__ */ v(Qe, { color: n }),
			/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("b", {
				title: t,
				children: t
			}), /* @__PURE__ */ y("small", { children: [
				a("games.powergrid.moneyStat", { n: e.money }),
				" · ",
				a("games.powergrid.citiesStat", { n: e.cities.length })
			] })] }),
			r && /* @__PURE__ */ v("span", {
				className: "pg-turn-mark",
				"aria-label": a("games.powergrid.acting"),
				children: /* @__PURE__ */ v("span", { children: a("games.powergrid.acting") })
			})
		]
	});
}
function ht({ id: e, selected: t, discount: n, fuel: r, launch: i, onClick: a }) {
	let o = u(), { ref: s, hidden: l } = c(i ?? null), d = D[e], f = e + " · " + o(Ye[d.kind]) + " · " + o("games.powergrid.plantCities", { n: d.cities });
	return /* @__PURE__ */ y("div", {
		className: "pg-plant-wrap",
		ref: s,
		style: l ? { visibility: "hidden" } : void 0,
		children: [a ? /* @__PURE__ */ v("button", {
			type: "button",
			className: "pg-plant" + (t ? " is-selected" : ""),
			"aria-label": f,
			"aria-pressed": t,
			onClick: a,
			children: /* @__PURE__ */ v(tt, {
				plant: e,
				discount: n
			})
		}) : /* @__PURE__ */ v("div", {
			className: "pg-plant" + (t ? " is-selected" : ""),
			"aria-label": f,
			children: /* @__PURE__ */ v(tt, {
				plant: e,
				discount: n
			})
		}), r && /* @__PURE__ */ v(nt, {
			plant: e,
			fuel: r
		})]
	});
}
function gt({ resource: e, counts: t, reserve: n = 0 }) {
	let r = u(), { ref: i } = c("pg:resource:" + e), a = ae[e].flatMap((e, n) => Array.from({ length: t[n] ?? 0 }, () => e.price)), o = a.length === 0 && n > 0, s = o ? n : a.length;
	return /* @__PURE__ */ y("li", {
		ref: i,
		className: "pg-price-row",
		children: [
			/* @__PURE__ */ y("b", { children: [/* @__PURE__ */ v($, { kind: e }), r(Je[e])] }),
			/* @__PURE__ */ v("span", {
				className: "pg-prices",
				children: o ? /* @__PURE__ */ v("span", {
					className: "is-next",
					children: r("games.powergrid.reserveCoalQuote", { n: 8 })
				}) : a.length === 0 ? /* @__PURE__ */ v("span", { children: r("games.powergrid.soldOut") }) : a.slice(0, 6).map((e, t) => /* @__PURE__ */ v("span", {
					className: t === 0 ? "is-next" : void 0,
					children: e
				}, t))
			}),
			/* @__PURE__ */ v("strong", {
				"aria-label": r("games.powergrid.supplyLeft", { n: s }),
				children: s
			})
		]
	});
}
function _t({ public: e, members: t, myRid: n, send: r, onResults: i }) {
	let o = e, d = u(), m = l((e) => e.locale), h = M[o.map], g = o.players.find((e) => e.rid === n), b = g?.cities, x = g?.plants ?? [], S = g?.money ?? 0, C = o.pendingScrap ?? o.turn, w = C === n, E = o.auction, O = E?.stage === "offer", k = o.order.length ? o.order : o.players.map((e) => e.rid), A = (e) => ft(t, e, m, d), j = (e) => r(e), [N, re] = s(!1), [ie, ae] = s(!1), [oe, se] = s(null), [ue, fe] = s(null), [pe, he] = s(null), [ge, ve] = s(null), [Se, F] = s(null), [I, Ce] = s(null), L = [
		n,
		o.map,
		o.round,
		o.phase,
		C
	].join(":"), we = L + ":" + (O ? E.offerer : "") + ":" + (o.discount ?? ""), Te = L + ":" + (E?.plant ?? "") + ":" + (E?.bid ?? ""), Ee = w && o.phase === "build", R = w && o.phase === "resources", z = w && o.phase === "bureaucracy", De = o.pendingScrap === n, { ref: Oe } = c("pg:market"), { ref: B } = c("pg:dock"), ke = a(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of o.players) {
			let r = {
				rid: n.rid,
				color: dt(t, n.rid).hex,
				name: ft(t, n.rid, m, d)
			};
			for (let t of n.cities) {
				let n = e.get(t) ?? [];
				n.push(r), e.set(t, n);
			}
		}
		return e;
	}, [
		o.players,
		t,
		m,
		d
	]), V = /* @__PURE__ */ new Map();
	if (Ee) for (let e of h.cities) {
		let t = xe(h, o.areas, b ?? [], e.id, ke.get(e.id)?.length ?? 0, o.step);
		t !== null && t <= S && V.set(e.id, t);
	}
	let Ae = w && o.phase === "areas" ? ee[o.map].filter((e) => !o.areas.includes(e) && (!o.areas.length || te[o.map][e]?.some((e) => o.areas.includes(e)))) : [], H = pe?.scope === L ? pe.id : void 0, U = H ? V.get(H) : void 0, je = [], Me = H && U != null ? de[ke.get(H)?.length ?? 0] : 0;
	H && U != null && b?.length && be(h, o.areas, b, H, je);
	let Ne = o.step === 3 ? o.market.length : 4, Pe = o.market.slice(0, Ne), Fe = o.market.slice(Ne), W = oe?.scope === we && Pe.includes(oe.id) ? oe : null, Ie = (E?.bid ?? 0) + 1, G = ue?.scope === Te ? ue.bid : Ie, K = ge?.scope === L ? x.find((e) => e.id === ge.id) : void 0, Le = x.filter((e) => P(D[e.id], e.fuel)), q = z ? Se?.scope === L ? Se.ids.filter((e) => Le.some((t) => t.id === e)) : pt(Le, b?.length ?? 0) : [], Re = o.phase === "over" ? [] : x.flatMap((e) => x.flatMap((t) => {
		if (e.id === t.id) return [];
		let n = D[t.id];
		return T.filter((r) => e.fuel[r] > 0 && ye(n.kind, n.need, t.fuel, r) > 0).map((n) => ({
			from: e.id,
			to: t.id,
			resource: n
		}));
	})), J = I?.rid === n && o.phase !== "over", ze = J ? I.from : void 0, Be = ze === void 0 ? [] : Re.filter((e) => e.from === ze), Ve = Math.min(b?.length ?? 0, q.reduce((e, t) => e + D[t].cities, 0)), He = ce[Math.min(Ve, ce.length - 1)], Ue = N || R || z || De, We = d({
		areas: "games.powergrid.phaseAreasYou",
		auction: "games.powergrid.auctionTitle",
		resources: "games.powergrid.phaseResourcesYou",
		build: "games.powergrid.phaseBuildYou",
		bureaucracy: "games.powergrid.powerTitle",
		over: "games.powergrid.phaseOver"
	}[o.phase]), Ge = d("games.powergrid.roundChip", { n: o.round }) + " · " + d("games.powergrid.stepChip", { n: o.step }), Ke = (e) => d("games.powergrid.waitFor", { name: A(e) }), Y = (e, t, n = !1, r = !1) => /* @__PURE__ */ v("button", {
		type: "button",
		className: "pg-btn" + (n ? " pg-primary" : ""),
		onClick: t,
		disabled: r,
		children: e
	}), qe = (e, t, n, r) => /* @__PURE__ */ y("span", {
		className: "pg-stepper",
		children: [
			Y("−", () => r(Math.max(t, e - 1)), !1, e <= t),
			/* @__PURE__ */ v("output", {
				"aria-label": d("games.powergrid.bidAmount"),
				children: e
			}),
			Y("+", () => r(Math.min(n, e + 1)), !1, e >= n),
			Y("+5", () => r(Math.min(n, e + 5)), !1, e >= n)
		]
	}), X = null, Z = null, Q = We;
	if (o.phase === "over") i && (Z = Y(d("games.powergrid.showResults"), i, !0));
	else if (!w) Q = C ? Ke(C) : We, o.phase === "auction" && E?.stage === "bidding" && (X = d("games.powergrid.phaseBidSub", {
		bid: E.bid,
		name: E.high ? A(E.high) : ""
	}));
	else if (De) Q = d("games.powergrid.scrapTitle"), X = d("games.powergrid.scrapHint");
	else if (o.phase === "areas") X = d("games.powergrid.areasSub", { n: Math.max(0, (le[o.players.length]?.regions ?? 4) - o.areas.length) });
	else if (o.phase === "auction" && O) {
		if (W) {
			let e = o.discount === W.id ? 1 : W.id;
			Q = d("games.powergrid.plantNumber", { n: W.id }), X = d("games.powergrid.offerMin", { n: e }), Z = /* @__PURE__ */ y(_, { children: [qe(W.bid, e, S, (e) => se({
				...W,
				bid: e
			})), Y(d("games.powergrid.bidConfirm"), () => {
				j({
					type: "offer",
					plant: W.id,
					bid: W.bid
				}), se(null);
			}, !0, W.bid < e || W.bid > S)] });
		} else X = d("games.powergrid.selectPlantHint");
		o.round > 1 && (Z = /* @__PURE__ */ y(_, { children: [Z, Y(d("games.powergrid.declineOffer"), () => j({ type: "declineOffer" }))] }));
	} else o.phase === "auction" && E ? (Q = d("games.powergrid.phaseBid", { plant: E.plant ?? "" }), X = d("games.powergrid.phaseBidSub", {
		bid: E.bid,
		name: E.high ? A(E.high) : ""
	}), Z = /* @__PURE__ */ y(_, { children: [
		qe(G, Math.min(Ie, S), S, (e) => fe({
			scope: Te,
			bid: e
		})),
		Y(d("games.powergrid.bidConfirm"), () => j({
			type: "bid",
			amount: G
		}), !0, G < Ie || G > S),
		Y(d("games.powergrid.bidPass"), () => j({ type: "passBid" }))
	] })) : R ? (Q = K ? d("games.powergrid.plantNumber", { n: K.id }) : We, X = K ? D[K.id].need === 0 ? d("games.powergrid.noFuel") : null : d(x.length ? "games.powergrid.tapPlantHint" : "games.powergrid.noPlants"), Z = /* @__PURE__ */ y(_, { children: [K && T.filter((e) => me(D[K.id].kind, e)).map((e) => {
		let t = D[K.id], n = _e(o.map, e, o.prices[e], o.supply[e]), r = ye(t.kind, t.need, K.fuel, e) <= 0;
		return /* @__PURE__ */ y("button", {
			type: "button",
			className: "pg-btn pg-primary",
			disabled: n === null || S < n || r,
			onClick: () => j({
				type: "buyResource",
				plant: K.id,
				resource: e
			}),
			children: [/* @__PURE__ */ v($, { kind: e }), d(r ? "games.powergrid.storageFull" : n === null ? "games.powergrid.soldOut" : "games.powergrid.buyAt", { n: n ?? 0 })]
		}, e);
	}), Y(d("games.powergrid.buyEnd"), () => j({ type: "endResources" }), !K)] })) : Ee ? (H && U != null ? (Q = d("games.powergrid.buildCity", { city: d(ne[H]) }), X = d("games.powergrid.buildBreakdown", {
		site: Me,
		route: U - Me
	}), Z = Y(d("games.powergrid.buildConfirm", { n: U }), () => {
		j({
			type: "build",
			city: H
		}), he(null);
	}, !0)) : X = d(V.size ? "games.powergrid.buildHint" : "games.powergrid.buildNone"), Z = /* @__PURE__ */ y(_, { children: [Z, Y(d("games.powergrid.buildEnd"), () => j({ type: "endBuild" }), U == null)] })) : z && (Q = d("games.powergrid.powerCities", { n: Ve }), X = o.endTriggered ? d("games.powergrid.powerHint") : d("games.powergrid.powerIncome", { n: He }), Z = Y(d("games.powergrid.powerConfirm"), () => j({
		type: "submitPower",
		runs: q
	}), !0));
	let Ye = /* @__PURE__ */ y("section", {
		className: "pg-command",
		"aria-label": We,
		children: [/* @__PURE__ */ y("div", {
			className: "pg-command-copy",
			children: [/* @__PURE__ */ v("b", { children: Q }), X && /* @__PURE__ */ v("p", { children: X })]
		}), /* @__PURE__ */ v("div", {
			className: "pg-controls",
			children: Z
		})]
	}), Xe = x.map((e) => {
		let t = D[e.id], r = P(t, e.fuel), i = J ? Re.some((t) => t.from === e.id) ? () => Ce({
			rid: n,
			from: e.id
		}) : void 0 : R ? () => ve(K?.id === e.id ? null : {
			scope: L,
			id: e.id
		}) : z && r ? () => F({
			scope: L,
			ids: q.includes(e.id) ? q.filter((t) => t !== e.id) : [...q, e.id]
		}) : void 0;
		return /* @__PURE__ */ y("div", {
			className: "pg-owned-item",
			children: [
				/* @__PURE__ */ v(ht, {
					id: e.id,
					fuel: e.fuel,
					selected: J ? ze === e.id : K?.id === e.id || q.includes(e.id),
					onClick: i,
					launch: "pg:owned:" + e.id
				}),
				z && !r && /* @__PURE__ */ v("small", { children: d("games.powergrid.powerNeedFuel") }),
				De && /* @__PURE__ */ v(f, {
					className: "pg-btn",
					label: d("games.powergrid.scrapAria", { n: e.id }),
					confirmLabel: d("games.powergrid.scrapConfirm"),
					onConfirm: () => j({
						type: "scrap",
						plant: e.id
					})
				})
			]
		}, e.id);
	}), $e = (e, t) => /* @__PURE__ */ y("div", {
		className: "pg-market-group",
		children: [/* @__PURE__ */ v("b", { children: d(t ? "games.powergrid.futureMarket" : "games.powergrid.currentMarket") }), /* @__PURE__ */ v("div", {
			className: "pg-market-cards",
			children: e.map((e, n) => {
				let r = o.discount === e ? 1 : e, i = !t && w && O && !De && o.phase === "auction" && r <= S;
				return /* @__PURE__ */ v(ht, {
					id: e,
					launch: "pg:market-slot:" + (t ? Ne + n : n),
					discount: o.discount === e,
					selected: W?.id === e || E?.plant === e,
					onClick: i ? () => se(W?.id === e ? null : {
						scope: we,
						id: e,
						bid: r
					}) : void 0
				}, e);
			})
		})]
	});
	return /* @__PURE__ */ v(p, {
		adaptive: !0,
		className: "pg-shell",
		scroll: !1,
		actionsHeight: "pg-market-slot",
		banner: /* @__PURE__ */ y("header", {
			className: "pg-header",
			children: [
				/* @__PURE__ */ y("div", {
					className: "pg-identity",
					children: [/* @__PURE__ */ v("span", {
						className: "pg-logo",
						children: /* @__PURE__ */ v(Ze, {})
					}), /* @__PURE__ */ v("b", { children: d("games.powergrid.name") })]
				}),
				/* @__PURE__ */ y("div", {
					className: "pg-phase",
					children: [/* @__PURE__ */ v("small", { children: o.phase === "over" ? We : Ge }), /* @__PURE__ */ v("b", { children: We })]
				}),
				/* @__PURE__ */ v("div", {
					className: "pg-seats",
					children: k.map((e) => {
						let n = o.players.find((t) => t.rid === e);
						return n && /* @__PURE__ */ v(mt, {
							player: n,
							color: dt(t, e).hex,
							name: A(e),
							acting: e === C && o.phase !== "over",
							muted: E?.passed.includes(e) ?? !1
						}, e);
					})
				})
			]
		}),
		actions: /* @__PURE__ */ y("div", {
			className: "pg-bottom",
			children: [/* @__PURE__ */ y("div", {
				className: "pg-market",
				ref: Oe,
				children: [/* @__PURE__ */ y("div", {
					className: "pg-market-title",
					children: [/* @__PURE__ */ v("h2", { children: d("games.powergrid.marketTitle") }), /* @__PURE__ */ v("small", { children: d("games.powergrid.deckLeft", { n: o.deckCount }) })]
				}), /* @__PURE__ */ y("div", {
					className: "pg-market-rail",
					children: [$e(Pe, !1), Fe.length > 0 && $e(Fe, !0)]
				})]
			}), /* @__PURE__ */ v("div", {
				className: "pg-mobile-command",
				children: Ye
			})]
		}),
		children: /* @__PURE__ */ y("div", {
			className: "pg-stage" + (Ue ? " is-dock-open" : ""),
			children: [
				/* @__PURE__ */ y("div", {
					className: "pg-main",
					children: [/* @__PURE__ */ v(ut, {
						map: h,
						areas: o.areas,
						openAreas: Ae,
						occupants: ke,
						affordable: new Set(V.keys()),
						selected: H && U != null ? {
							id: H,
							cost: U,
							route: je
						} : void 0,
						onCity: (e) => he(e === H ? null : {
							scope: L,
							id: e
						}),
						onArea: (e) => j({
							type: "chooseArea",
							region: e
						}),
						regionSelection: o.phase === "areas"
					}), /* @__PURE__ */ v("button", {
						type: "button",
						className: "pg-btn pg-dock-toggle",
						onClick: () => re(!N),
						"aria-expanded": Ue,
						hidden: R || z || De,
						children: d(N ? "games.powergrid.close" : "games.powergrid.myPlants")
					})]
				}),
				/* @__PURE__ */ v("aside", {
					className: "pg-side",
					children: /* @__PURE__ */ y("div", {
						className: "pg-sidebar-scroll",
						children: [/* @__PURE__ */ y("section", {
							className: "pg-owned",
							children: [
								/* @__PURE__ */ y("div", {
									className: "pg-section-heading",
									children: [/* @__PURE__ */ v("h2", { children: d("games.powergrid.myPlants") }), /* @__PURE__ */ y("div", {
										className: "pg-owned-links",
										children: [(Re.length > 0 || J) && /* @__PURE__ */ v("button", {
											type: "button",
											className: "pg-table-link",
											"aria-expanded": J,
											onClick: () => Ce(J ? null : { rid: n }),
											children: d(J ? "games.powergrid.close" : "games.powergrid.transferFuel")
										}), /* @__PURE__ */ v("button", {
											type: "button",
											className: "pg-table-link",
											"aria-expanded": ie,
											onClick: () => ae(!ie),
											children: d("games.powergrid.playersPanel")
										})]
									})]
								}),
								/* @__PURE__ */ v("div", {
									className: "pg-owned-cards",
									ref: B,
									children: Xe.length ? Xe : /* @__PURE__ */ v("span", { children: d("games.powergrid.noPlants") })
								}),
								J && /* @__PURE__ */ y("div", {
									className: "pg-transfer",
									"aria-label": d("games.powergrid.transferFuel"),
									children: [/* @__PURE__ */ v("p", { children: d(Be.length > 0 ? "games.powergrid.transferDestination" : Re.length > 0 ? "games.powergrid.transferSource" : "games.powergrid.transferNone") }), /* @__PURE__ */ v("div", { children: Be.map((e) => /* @__PURE__ */ y("button", {
										type: "button",
										className: "pg-btn",
										onClick: () => j({
											type: "transferFuel",
											...e
										}),
										children: [/* @__PURE__ */ v($, { kind: e.resource }), d("games.powergrid.transferTo", {
											n: e.to,
											resource: d(Je[e.resource])
										})]
									}, e.to + ":" + e.resource)) })]
								}),
								ie && /* @__PURE__ */ v("ul", {
									className: "pg-networks",
									children: k.map((e) => {
										let n = o.players.find((t) => t.rid === e);
										return n && /* @__PURE__ */ y("li", { children: [
											/* @__PURE__ */ v(Qe, { color: dt(t, e).hex }),
											/* @__PURE__ */ v("b", { children: A(e) }),
											/* @__PURE__ */ v("span", { children: n.plants.map((e) => e.id).join(" · ") || "—" }),
											/* @__PURE__ */ v("span", { children: d("games.powergrid.suppliedStat", { n: n.supplied }) })
										] }, e);
									})
								})
							]
						}), /* @__PURE__ */ y("section", {
							className: "pg-resources" + (R && K ? " is-buying" : ""),
							children: [/* @__PURE__ */ y("div", {
								className: "pg-section-heading",
								children: [/* @__PURE__ */ v("h2", { children: d("games.powergrid.supplyPanel") }), /* @__PURE__ */ v("small", { children: d("games.powergrid.marketStock") })]
							}), /* @__PURE__ */ v("ul", { children: T.map((e) => /* @__PURE__ */ v(gt, {
								resource: e,
								counts: o.prices[e],
								reserve: o.map === "usa" && e === "coal" ? o.supply.coal : 0
							}, e)) })]
						})]
					})
				}),
				/* @__PURE__ */ v("div", {
					className: "pg-desktop-command",
					children: Ye
				})
			]
		})
	});
}
//#endregion
//#region src/game/bot.ts
function vt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.players) for (let e of n.cities) t.set(e, (t.get(e) ?? 0) + 1);
	return t;
}
function yt(e, t) {
	return e.players.findIndex((e) => e.rid === t);
}
function bt(e, t) {
	return e.players[yt(e, t)] ?? null;
}
function xt(e, t) {
	let n = bt(e, t);
	if (!n) return [];
	let r = M[e.map], i = vt(e), a = [];
	for (let t of r.cities) {
		let o = xe(r, e.areas, n.cities, t.id, i.get(t.id) ?? 0, e.step);
		o != null && a.push({
			id: t.id,
			cost: o
		});
	}
	return a.sort((e, t) => e.cost - t.cost);
}
function St(e, t, n) {
	let r = D[e], i = r.kind === "wind" ? 6 : r.kind === "hybrid" ? 3 : r.kind === "uranium" ? -2 : 0, a = r.cities <= t ? -7 : 0, o = r.cities * 10 + i - a;
	return n < 20 ? o * .8 : o;
}
function Ct(e, t) {
	let n = bt(e, t);
	if (!n) return [];
	let r = [...n.plants].sort((e, t) => D[t.id].cities - D[e.id].cities), i = [], a = 0;
	for (let e of r) {
		if (a >= n.cities.length) break;
		P(D[e.id], e.fuel) && (i.push(e.id), a += D[e.id].cities);
	}
	return i;
}
function wt(e, t) {
	let n = bt(e, t);
	if (!n || n.cities.length === 0) return null;
	let r = [...n.plants].sort((e, t) => D[t.id].cities - D[e.id].cities), i = 0;
	for (let t of r) {
		if (i >= n.cities.length) return null;
		let r = D[t.id];
		if (P(r, t.fuel)) {
			i += r.cities;
			continue;
		}
		let a = T.filter((e) => me(r.kind, e)), o = null;
		for (let n of a) {
			let i = _e(e.map, n, e.prices[n], e.supply[n]);
			i != null && (ye(r.kind, r.need, t.fuel, n) <= 0 || (!o || i < o.price) && (o = {
				resource: n,
				price: i
			}));
		}
		if (o && n.money - o.price >= 8) return {
			plant: t.id,
			resource: o.resource
		};
	}
	return null;
}
var Tt = (e, t) => {
	let n = e.public, r = t.rid, i = bt(n, r);
	if (!i || n.phase === "over") return null;
	if (n.pendingScrap != null) {
		if (n.pendingScrap !== r) return null;
		let e = [...i.plants].sort((e, t) => D[e.id].cities - D[t.id].cities || e.id - t.id)[0];
		return e ? { action: {
			type: "scrap",
			plant: e.id
		} } : null;
	}
	if (n.phase === "areas") {
		if (n.turn !== r) return null;
		let e = le[n.players.length]?.regions ?? 4;
		if (n.areas.length >= e) return null;
		let t = ee[n.map].filter((e) => n.areas.includes(e) ? !1 : n.areas.length === 0 || (te[n.map][e] ?? []).some((e) => n.areas.includes(e))), i = M[n.map], a = null, o = -Infinity;
		for (let e of t) {
			let t = i.cities.filter((t) => t.region === e).length, r = (te[n.map][e] ?? []).filter((e) => n.areas.includes(e)).length, s = t * 2 + r * 3;
			s > o && (o = s, a = e);
		}
		return a ? { action: {
			type: "chooseArea",
			region: a
		} } : null;
	}
	if (n.phase === "auction") {
		let e = n.auction;
		if (!e || n.turn !== r) return null;
		if (e.stage === "offer") {
			let e = n.step === 3 ? n.market : n.market.slice(0, 4), t = i.plants.reduce((e, t) => Math.max(e, D[t.id].cities), 0), r = e.map((e) => ({
				id: e,
				min: n.discount === e ? 1 : e
			})).filter((e) => e.min <= i.money);
			if (r.length === 0) return n.round > 1 ? { action: { type: "declineOffer" } } : null;
			r.sort((e, n) => St(n.id, t, i.money) - St(e.id, t, i.money));
			let a = r[0], o = D[a.id];
			return n.round > 1 && i.plants.length >= 3 && o.cities <= t ? { action: { type: "declineOffer" } } : { action: {
				type: "offer",
				plant: a.id,
				bid: a.min
			} };
		}
		let t = e.plant;
		if (t == null) return null;
		let a = D[t], o = i.plants.reduce((e, t) => Math.max(e, D[t.id].cities), 0), s = a.cities * 11 + (a.kind === "wind" ? 5 : a.kind === "hybrid" ? 4 : 0) - (a.cities <= o ? 8 : 0), c = i.plants.length === 0 ? 16 : 6, l = Math.max(1, Math.min(i.money - 1, Math.floor(s * .8) + c));
		return e.bid + 1 <= l && e.bid + 1 <= i.money ? { action: {
			type: "bid",
			amount: e.bid + 1
		} } : { action: { type: "passBid" } };
	}
	if (n.phase === "resources") {
		if (n.turn !== r) return null;
		let e = wt(n, r);
		return e ? { action: {
			type: "buyResource",
			plant: e.plant,
			resource: e.resource
		} } : { action: { type: "endResources" } };
	}
	if (n.phase === "build") {
		if (n.turn !== r) return null;
		let e = xt(n, r), t = n.endTriggered ? 0 : 22, a = e.find((e) => e.cost <= i.money);
		return a && (i.money - a.cost >= t || n.endTriggered || i.cities.length < 2) ? { action: {
			type: "build",
			city: a.id
		} } : { action: { type: "endBuild" } };
	}
	return n.phase === "bureaucracy" && n.turn === r ? { action: {
		type: "submitPower",
		runs: Ct(n, r)
	} } : null;
};
//#endregion
//#region src/game/fx.tsx
function Et(e, t, n = t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function Dt(e, t) {
	let n = e.x + e.w / 2, r = e.y + e.h / 2;
	return n >= t.x && n <= t.x + t.w && r >= t.y && r <= t.y + t.h;
}
var Ot = {
	"pg-sale": (e, t) => {
		let { plant: n, bid: r, slot: i, discount: a } = e.data;
		if (!e.rid || !D[n]) return null;
		let o = t.anchor("pg:market"), s = t.anchor("pg:market-slot:" + i), c = t.anchor("pg:seat:" + e.rid), l = "pg:owned:" + n, u = e.rid === t.myRid ? t.anchor(l) : null, d = u && u.w > 0 ? u : null;
		if (!o || !c) return null;
		let f = s && Dt(s, o) ? Math.min(s.w, 145) : Math.min(83, o.w), p = s && Dt(s, o) ? s : Et(o, f, f), m = d ? Et(d, d.w) : Et(c, Math.min(48, c.w)), h = t.queued ? 270 : 490;
		return {
			ms: h + 65,
			hide: d && !t.queued ? [l] : void 0,
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				from: p,
				to: m,
				ms: h,
				children: /* @__PURE__ */ v("div", {
					className: "pg-plant pg-fx-sprite",
					style: {
						width: f,
						height: f * 1.05
					},
					children: /* @__PURE__ */ v(tt, {
						plant: n,
						discount: a
					})
				})
			}), /* @__PURE__ */ v(b, {
				at: c,
				ms: h + 35,
				children: /* @__PURE__ */ y("span", {
					className: "pg-fx-mark",
					children: ["−", r]
				})
			})] })
		};
	},
	"pg-fuel": (e, t) => {
		let { plant: n, resource: r, price: i } = e.data;
		if (!e.rid) return null;
		let a = t.anchor("pg:resource:" + r), o = t.anchor("pg:seat:" + e.rid);
		if (!o) return null;
		let s = e.rid === t.myRid ? t.anchor("pg:owned:" + n) : null, c = s && s.w > 0 ? {
			...s,
			y: s.y + s.h - 16,
			h: 16
		} : o, l = t.queued ? 230 : 410;
		if (!a?.w || !a.h) return {
			ms: l,
			node: /* @__PURE__ */ v(b, {
				at: o,
				ms: l,
				children: /* @__PURE__ */ y("span", {
					className: "pg-fx-mark",
					children: [
						/* @__PURE__ */ v($, { kind: r }),
						" −",
						i
					]
				})
			})
		};
		let u = {
			x: a.x + a.w * .16,
			y: a.y,
			w: 24,
			h: a.h
		};
		return {
			ms: l + 55,
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				from: u,
				to: Et(c, 21),
				ms: l,
				children: /* @__PURE__ */ v("span", {
					className: "pg-fx-token",
					children: /* @__PURE__ */ v($, { kind: r })
				})
			}), /* @__PURE__ */ v(b, {
				at: o,
				ms: l,
				children: /* @__PURE__ */ y("span", {
					className: "pg-fx-mark",
					children: ["−", i]
				})
			})] })
		};
	},
	"pg-transfer": (e, t) => {
		let { from: n, to: r, resource: i } = e.data;
		if (e.rid !== t.myRid) return null;
		let a = t.anchor("pg:owned:" + n), o = t.anchor("pg:owned:" + r);
		if (!a?.w || !o?.w) return null;
		let s = (e) => Et({
			...e,
			y: e.y + e.h - 18,
			h: 18
		}, 22), c = t.queued ? 200 : 375;
		return {
			ms: c,
			node: /* @__PURE__ */ v(x, {
				from: s(a),
				to: s(o),
				ms: c,
				children: /* @__PURE__ */ v("span", {
					className: "pg-fx-token",
					children: /* @__PURE__ */ v($, { kind: i })
				})
			})
		};
	},
	"pg-build": (e, t) => {
		let { city: n, cost: r } = e.data;
		if (!e.rid) return null;
		let i = "pg:house:" + e.rid + ":" + n, a = t.anchor(i), o = t.anchor("pg:seat:" + e.rid), s = t.anchor("pg:map");
		if (!a || !s || !Dt(a, s)) return o ? {
			ms: 370,
			node: /* @__PURE__ */ v(b, {
				at: o,
				ms: 370,
				children: /* @__PURE__ */ y("span", {
					className: "pg-fx-mark",
					children: ["−", r]
				})
			})
		} : null;
		let c = d[(t.member(e.rid)?.colorIndex ?? 0) % d.length].hex, l = t.queued ? 210 : 380, u = {
			...a,
			y: Math.max(s.y, a.y - 30)
		};
		return {
			ms: l,
			hide: t.queued ? void 0 : [i],
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				from: u,
				to: a,
				ms: l,
				children: /* @__PURE__ */ v("span", {
					className: "pg-fx-house",
					style: { fontSize: a.w },
					children: /* @__PURE__ */ v($e, { color: c })
				})
			}), o && /* @__PURE__ */ v(b, {
				at: o,
				ms: l,
				children: /* @__PURE__ */ y("span", {
					className: "pg-fx-mark",
					children: ["−", r]
				})
			})] })
		};
	},
	"pg-power": (e, t) => {
		let { runs: n, supplied: r, income: i, lit: a } = e.data;
		if (!e.rid) return null;
		let o = t.anchor("pg:seat:" + e.rid), s = t.anchor("pg:map"), c = a.flatMap((e) => {
			let n = t.anchor("pg:city:" + e);
			return n && s && Dt(n, s) ? [{
				city: e,
				at: n
			}] : [];
		}), l = e.rid === t.myRid ? n.flatMap((e) => {
			let n = t.anchor("pg:owned:" + e);
			return n?.w ? [{
				id: e,
				at: n
			}] : [];
		}) : [], u = t.queued ? 290 : 620;
		return !o && !c.length && !l.length ? null : {
			ms: u,
			node: /* @__PURE__ */ y(_, { children: [
				l.map(({ id: e, at: t }) => /* @__PURE__ */ v(S, {
					at: t,
					ms: u * .58
				}, e)),
				c.map(({ city: e, at: t }) => /* @__PURE__ */ v(b, {
					at: t,
					ms: u * .78,
					delay: u * .09,
					children: /* @__PURE__ */ v("span", {
						className: "pg-fx-mark",
						children: /* @__PURE__ */ v(Ze, {})
					})
				}, e)),
				o && /* @__PURE__ */ v(b, {
					at: o,
					ms: u * .76,
					delay: u * .2,
					children: /* @__PURE__ */ y("span", {
						className: "pg-fx-mark",
						children: [
							/* @__PURE__ */ v(Ze, {}),
							" ",
							r,
							i > 0 ? " · +" + i : ""
						]
					})
				})
			] })
		};
	}
}, kt = () => {};
function At({ public: e, result: t, members: n, myRid: i, hintCount: a, onPlayAgain: c, onBackToLobby: d }) {
	let p = e, m = u(), h = l((e) => e.locale), [g, _] = s(!0), b = o(null), x = o(null), S = o(!1), C = (e) => {
		S.current = !0, _(e);
	};
	r(() => {
		S.current && (g ? b.current?.focus() : x.current?.querySelector(".pg-command .pg-primary:not([disabled])")?.focus());
	}, [g]);
	let w = (e) => ft(n, e, h, m), T = t.ranking.flatMap((e) => {
		let t = p.players.find((t) => t.rid === e);
		return t ? [{
			...t,
			supplied: p.finalResult?.supplied[e] ?? t.supplied
		}] : [];
	}), E = t.winner.map(w), D = E.length > 0 ? m(E.length === 1 ? "games.powergrid.finalWinner" : "games.powergrid.finalJointWinners", { names: new Intl.ListFormat(h, { type: "conjunction" }).format(E) }) : m("session.result.title");
	return /* @__PURE__ */ y("div", {
		className: "pg-result",
		children: [/* @__PURE__ */ v("div", {
			className: "pg-result-board",
			inert: g,
			ref: x,
			children: /* @__PURE__ */ v(_t, {
				public: p,
				members: n,
				myRid: i,
				send: kt,
				onResults: () => C(!0)
			})
		}), /* @__PURE__ */ v("div", {
			className: "pg-result-curtain",
			hidden: !g,
			children: /* @__PURE__ */ y("section", {
				className: "pg-result-panel",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "pg-result-heading",
				tabIndex: -1,
				ref: b,
				children: [
					/* @__PURE__ */ y("header", {
						className: "pg-result-header",
						children: [/* @__PURE__ */ y("h2", {
							id: "pg-result-heading",
							children: [/* @__PURE__ */ v(Ze, {}), m("games.powergrid.finalTitle")]
						}), /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("p", { children: D }), /* @__PURE__ */ v("button", {
							type: "button",
							className: "pg-btn",
							onClick: () => C(!1),
							children: m("games.powergrid.reviewMap")
						})] })]
					}),
					/* @__PURE__ */ y("div", {
						className: "pg-result-scroll",
						children: [/* @__PURE__ */ y("table", {
							className: "pg-result-table",
							children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [
								/* @__PURE__ */ v("th", {
									scope: "col",
									children: m("games.powergrid.finalPlayer")
								}),
								/* @__PURE__ */ v("th", {
									scope: "col",
									children: m("games.powergrid.finalSupply")
								}),
								/* @__PURE__ */ v("th", {
									scope: "col",
									children: m("games.powergrid.finalMoney")
								})
							] }) }), /* @__PURE__ */ v("tbody", { children: T.map((e) => {
								let r = 1 + T.filter((t) => t.supplied > e.supplied || t.supplied === e.supplied && t.money > e.money).length, i = t.autopilot?.[e.rid] ?? 0;
								return /* @__PURE__ */ y("tr", {
									className: t.winner.includes(e.rid) ? "is-winner" : void 0,
									children: [
										/* @__PURE__ */ y("td", { children: [/* @__PURE__ */ y("span", {
											className: "pg-result-player",
											children: [
												/* @__PURE__ */ v("span", { children: r }),
												/* @__PURE__ */ v(Qe, { color: dt(n, e.rid).hex }),
												/* @__PURE__ */ v("b", { children: w(e.rid) })
											]
										}), i > 0 && /* @__PURE__ */ v("small", { children: m("games.powergrid.autopilotShare", { n: Math.round(i * 100) }) })] }),
										/* @__PURE__ */ v("td", {
											className: "pg-result-supply",
											children: e.supplied
										}),
										/* @__PURE__ */ v("td", { children: m("games.powergrid.moneyStat", { n: e.money }) })
									]
								}, e.rid);
							}) })]
						}), c && a != null && a > 0 && /* @__PURE__ */ v("p", { children: m("games.powergrid.hintCount", { n: a }) })]
					}),
					/* @__PURE__ */ y("footer", {
						className: "pg-result-actions",
						children: [
							c && /* @__PURE__ */ v(f, {
								className: "pg-btn pg-primary",
								label: m("session.result.playAgain"),
								confirmLabel: m("games.powergrid.confirmRestart"),
								onConfirm: c
							}),
							d && /* @__PURE__ */ v(f, {
								className: "pg-btn",
								label: m("session.result.backToLobby"),
								confirmLabel: m("games.powergrid.confirmLeave"),
								onConfirm: d
							}),
							!c && !d && /* @__PURE__ */ v("p", { children: m("session.result.waitHost") })
						]
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function jt({ value: e, onChange: t }) {
	let n = u(), r = R.parse(e);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ v(w, {
			title: n("games.powergrid.optionMap"),
			columns: 2,
			children: [{
				key: "germany",
				label: "games.powergrid.mapGermany"
			}, {
				key: "usa",
				label: "games.powergrid.mapUsa"
			}].map((e) => /* @__PURE__ */ v(C, {
				name: "powergrid-map",
				value: e.key,
				checked: r.map === e.key,
				label: n(e.label),
				accent: Se.accent,
				onChange: () => t({
					...r,
					map: e.key
				})
			}, e.key))
		}), /* @__PURE__ */ v("p", {
			className: "text-xs font-bold opacity-60",
			children: n("games.powergrid.optionMapHint")
		})]
	});
}
//#endregion
//#region src/index.tsx
var Mt = {
	definition: Q,
	View: _t,
	bot: Tt,
	fx: Ot,
	OverView: At,
	Options: jt,
	locales: {
		zh: {
			name: "电力公司",
			desc: "拍卖发电厂、购买燃料、扩建电网，为最多城市供电",
			rules: "目标：\n· 游戏进行若干轮，率先把自家电网扩展到规定城市数的玩家触发终局；终局结算后，能为最多城市供电的玩家获胜，供电数相同时剩余资金多者获胜。\n开局：\n· 每名玩家以 50 元开始，没有发电厂和城市。\n· 首先确定本局使用的地图与经营区域。由起始玩家开始，按座次每人选择一个区域，所选区域必须与已经选择的区域相邻，第一块区域不受此限制。三人局共选择三个区域，四人局选择四个，五人和六人局选择五个；六人局选满五个区域后，最后一名玩家不再选择。\n· 经营区域决定可以建造的城市范围，区域之外的城市不能连接。\n每轮流程：\n· 一轮依次进行五个阶段，所有玩家都完成同一阶段后才进入下一阶段。\n· 一、排列顺序：按已连接城市数从多到少排列行动顺序；城市数相同时，拥有编号最大发电厂的玩家靠前。第一轮的行动顺序在开局时抽签决定。\n· 二、拍卖发电厂：按行动顺序从优到劣，每名玩家依次选择一座当前市场中的发电厂发起拍卖，其余玩家轮流出价或放弃，最后剩下的出价者按自己的出价付款并获得该发电厂。每名玩家每轮最多获得一座发电厂。第一轮每名玩家都必须获得一座发电厂；从第二轮起可以选择跳过，跳过者本轮不再参与拍卖。当前市场中编号最小的发电厂带有折扣标记，其最低出价为 1 元，其余发电厂的最低出价等于其编号。被买走的发电厂由牌库补充。\n· 三、购买燃料：按行动顺序从劣到优，每名玩家为自己的发电厂购买煤、石油、垃圾或铀。每座发电厂只能存放其运行所需的资源，存量上限为运行需求的两倍；混合发电厂可以存放煤和石油，两者合计上限同样为需求的两倍。风力发电厂不需要燃料，也不能存放燃料。\n· 四、建造城市：按行动顺序从劣到优，每名玩家可以建造任意多座城市。第一座城市可以建在经营区域内任意一座无人占用的城市，费用为 10 元，不需要支付连接费用。之后每座城市都要从自己的城市出发，支付最短连接路线上的连接费用，再加上该城市下一个空位的费用：第一位玩家 10 元、第二位 15 元、第三位 20 元。连接路线可以使用区域内任意城市中转，也可以经过已被占满的城市。\n· 五、官僚阶段：按行动顺序从优到劣，每名玩家选择发电厂供电。每座发电厂每轮最多运行一次，并且必须投入完整数量的燃料；可供电城市数等于各运行发电厂标注数量之和。实际供电城市数取该数量与自有城市数中较小者，随后按供电城市数获得收入；没有供电城市时也有 10 元基础收入，供电城市越多收入越高。所有玩家结算完毕后，补充资源市场并按人数和当前阶段补充燃料，再更新发电厂市场。\n阶段与城市容量：\n· 第一阶段每座城市只能容纳一名玩家，第二阶段可以容纳两名，第三阶段可以容纳三名。城市空位的价格在所有阶段都按该城市已有玩家数计算，依次为 10 元、15 元和 20 元。\n· 当任意玩家连接第 7 座城市后（六人局为第 6 座），本轮建造阶段结束时进入第二阶段：从当前市场移除编号最小的发电厂并补充一张新牌。\n· 当抽到第三阶段卡时，第三阶段从下一阶段开始。若在拍卖阶段抽到，拍卖继续进行，拍卖阶段结束时把该卡与当前市场编号最小的发电厂一并移除，第三阶段从购买燃料阶段开始；若在官僚阶段抽到，立即把该卡与当前市场编号最小的发电厂一并移除，本轮仍按第二阶段补充燃料，第三阶段从下一轮开始。第三阶段的市场只保留 6 座发电厂，拍卖时全部可选。\n终局：\n· 建造阶段结束时，如果有玩家达到终局城市数，则本轮结束后游戏结束：三人局与四人局为 17 座，五人局为 15 座，六人局为 14 座。终局只比较供电城市数，不再发放收入；供电城市数相同时比较剩余资金。\n发电厂与燃料：\n· 每名玩家最多同时拥有三座发电厂。购买第四座发电厂时必须立即拆解一座已有发电厂，被拆解发电厂上的燃料会尽量转入其余发电厂，无法存放的部分退回供应堆。\n· 发电厂编号同时用于确定最低出价、市场排序和同城市数时的行动顺序。发电厂分为燃煤、燃油、垃圾、铀、混合与风电六类；混合发电厂投入煤或石油都可以运行，通常优先使用较便宜的一种。\n· 对局中，你可以随时在自己的发电厂之间调拨燃料。接收燃料的电厂必须能使用该燃料，并有剩余仓储空间。\n美国地图的特殊规则：\n· 煤炭市场售罄后，你可在购买燃料阶段从煤炭储备以每份 8 元的价格买煤。储备也用尽时，无法购买更多煤炭。\n德国地图的特殊规则：\n· 德国地图中，39 号核电厂被任意玩家买走后，本局不再补充铀；该发电厂未被买走或未进入本局牌库时，不触发这一效果。",
			mapGermany: "德国",
			mapUsa: "美国",
			optionMap: "地图",
			optionMapHint: "选择本局使用的双面地图之一",
			roundChip: "第 {{n}} 轮",
			stepChip: "第 {{n}} 阶段",
			phaseAreasYou: "请选择经营区域",
			phaseAreas: "{{name}} 选择经营区域",
			areasSub: "点选与已选区域相邻的区域，还需选择 {{n}} 个",
			phaseOfferYou: "轮到你选购发电厂",
			phaseOfferWait: "等待 {{name}} 选购发电厂",
			phaseBid: "{{plant}} 号发电厂竞拍中",
			phaseBidSub: "最高出价 {{bid}} 元，来自 {{name}}",
			phaseBidYou: "最高出价 {{bid}} 元，轮到你加价或放弃",
			phaseResourcesYou: "购买燃料",
			phaseResources: "等待 {{name}} 购买燃料",
			phaseBuildYou: "建造城市",
			phaseBuild: "等待 {{name}} 建造城市",
			phasePowerYou: "选择发电厂供电",
			phasePower: "等待 {{name}} 供电结算",
			phaseScrapYou: "买下了第四座发电厂，请拆解一座",
			phaseScrap: "等待 {{name}} 拆解发电厂",
			phaseOver: "对局结束",
			marketTitle: "发电厂市场",
			deckLeft: "牌库 {{n}} 张",
			discountTag: "折扣",
			selectPlantHint: "点选一座发电厂发起拍卖",
			plantCities: "供 {{n}} 城",
			plantFuel: "{{n}} {{res}}",
			plantFuelHybrid: "{{n}} 煤/油",
			plantWind: "风电",
			offerMin: "起价 {{n}} 元",
			bidAmount: "你的出价",
			bidConfirm: "确认出价",
			bidPass: "放弃",
			declineOffer: "跳过本轮",
			bidNeedHigher: "必须高于 {{n}} 元",
			bidNeedMin: "不能低于 {{n}} 元",
			bidNeedMoney: "资金不足",
			auctionTop: "{{name}} 暂时领先",
			auctionOfferBy: "{{name}} 发起拍卖",
			resCoal: "煤",
			resOil: "石油",
			resGarbage: "垃圾",
			resUranium: "铀",
			kindCoal: "燃煤",
			kindOil: "燃油",
			kindGarbage: "垃圾",
			kindUranium: "铀",
			kindHybrid: "混合",
			kindWind: "风电",
			priceNow: "现价 {{n}} 元",
			soldOut: "售罄",
			supplyPanel: "资源市场",
			supplyLeft: "库存 {{n}}",
			storageFull: "储料已满",
			fuelBuy: "购买",
			fuelStored: "已有 {{n}}",
			fuelCapacity: "可存 {{n}}",
			buyFuelTitle: "{{n}} 号发电厂：购买燃料",
			buyEnd: "结束购买",
			buildEnd: "结束建造",
			buildHint: "点击地图中高亮的城市建造",
			buildCost: "{{n}} 元",
			buildNone: "当前没有可以建造的城市",
			myPlants: "你的发电厂",
			noPlants: "你还没有发电厂",
			playersPanel: "玩家与发电厂",
			tapPlantHint: "点击发电厂购买燃料",
			powerHint: "点击发电厂切换是否供电",
			powerCapacity: "共可供电 {{n}} 座城市",
			powerIncome: "收入 {{n}} 元",
			powerConfirm: "确认供电",
			powerNeedFuel: "燃料不足",
			scrapTitle: "拆解一座发电厂",
			scrapHint: "选择要拆解的一座发电厂，燃料会转入其余发电厂",
			scrapAria: "拆解 {{n}} 号发电厂",
			moneyStat: "{{n}} 元",
			citiesStat: "城 {{n}}",
			suppliedStat: "供电 {{n}}",
			noFuel: "免燃料",
			cityEmpty: "空置",
			cityAvailable: "可接入",
			cityConnected: "已接入",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			emptyStorage: "没有存放燃料",
			acting: "行动中",
			auctionTitle: "发电厂拍卖",
			powerTitle: "供电结算",
			waitFor: "等待 {{name}} 行动",
			plantNumber: "{{n}} 号发电厂",
			buyAt: "购买 · {{n}} 元",
			buildCity: "接入{{city}}",
			buildBreakdown: "城市空位 {{site}} 元 ＋ 线路 {{route}} 元",
			buildConfirm: "确认接入 · {{n}} 元",
			powerCities: "本轮可为 {{n}} 座城市供电",
			scrapConfirm: "确认拆解",
			futureMarket: "未来市场",
			currentMarket: "当前市场",
			marketStock: "市场库存",
			reserveCoalQuote: "储备煤 · {{n}} 元",
			transferFuel: "调拨燃料",
			transferSource: "选择调出燃料的电厂。",
			transferDestination: "选择接收电厂和要调拨的燃料。",
			transferNone: "当前没有可调拨的燃料。",
			transferTo: "将 1 份{{resource}}调至 {{n}} 号电厂",
			errTransfer: "请在自己拥有且有相容仓储的电厂之间调拨燃料",
			showResults: "返回结算",
			reviewMap: "回看地图",
			finalTitle: "最终供电结算",
			finalWinner: "{{names}} 获胜",
			finalJointWinners: "{{names}} 并列获胜",
			finalSupply: "供电城市",
			finalMoney: "余额",
			finalPlayer: "名次／玩家",
			confirmRestart: "确认再来一局",
			confirmLeave: "确认返回大厅",
			hintCount: "使用提示 {{n}} 次",
			autopilotShare: "托管 {{n}}%",
			close: "关闭",
			errTurn: "还没轮到你",
			errAction: "当前阶段不能执行这个操作",
			errArea: "只能选择与已选区域相邻且尚未选择过的区域",
			errPlant: "只能选购当前市场中的发电厂",
			errBid: "出价必须高于当前最高价，且不超过你的资金",
			errResource: "这里不能购买这种燃料",
			errFuel: "燃料不足或储料已满",
			errMoney: "资金不足",
			errBuild: "这座城市不能建造",
			errScrap: "只能拆解你拥有的发电厂",
			regionGreen: "绿色区域",
			regionBrown: "棕色区域",
			regionRed: "红色区域",
			regionBlue: "蓝色区域",
			regionYellow: "黄色区域",
			regionPurple: "紫色区域",
			regionDarkGreen: "深绿区域",
			regionLightGreen: "浅绿区域",
			cityFlensburg: "弗伦斯堡",
			cityKiel: "基尔",
			cityHamburg: "汉堡",
			cityBremen: "不来梅",
			cityCuxhaven: "库克斯港",
			cityWilhelmshaven: "威廉港",
			cityHannover: "汉诺威",
			cityLubeck: "吕贝克",
			citySchwerin: "什未林",
			cityRostock: "罗斯托克",
			cityTorgelow: "托尔格洛",
			cityMagdeburg: "马格德堡",
			cityBerlin: "柏林",
			cityFrankfurtO: "法兰克福（奥得河）",
			cityOsnabruck: "奥斯纳布吕克",
			cityMunster: "明斯特",
			cityEssen: "埃森",
			cityDortmund: "多特蒙德",
			cityDuisburg: "杜伊斯堡",
			cityDuesseldorf: "杜塞尔多夫",
			cityKassel: "卡塞尔",
			cityKoln: "科隆",
			cityAachen: "亚琛",
			cityFrankfurtM: "法兰克福（美因河）",
			cityWiesbaden: "威斯巴登",
			cityTrier: "特里尔",
			citySaarbrucken: "萨尔布吕肯",
			cityMannheim: "曼海姆",
			cityDresden: "德累斯顿",
			cityFulda: "富尔达",
			cityErfurt: "埃尔福特",
			cityHalle: "哈雷",
			cityLeipzig: "莱比锡",
			cityWuerzburg: "维尔茨堡",
			cityNurnberg: "纽伦堡",
			cityStuttgart: "斯图加特",
			cityFreiburg: "弗赖堡",
			cityKonstanz: "康斯坦茨",
			cityAugsburg: "奥格斯堡",
			cityMuenchen: "慕尼黑",
			cityRegensburg: "雷根斯堡",
			cityPassau: "帕绍",
			citySeattle: "西雅图",
			cityPortland: "波特兰",
			cityBoise: "博伊西",
			cityBillings: "比灵斯",
			cityCheyenne: "夏延",
			cityOmaha: "奥马哈",
			cityDenver: "丹佛",
			citySanFrancisco: "旧金山",
			cityLosAngeles: "洛杉矶",
			citySanDiego: "圣迭戈",
			cityLasVegas: "拉斯维加斯",
			cityPhoenix: "凤凰城",
			citySantaFe: "圣菲",
			citySaltLakeCity: "盐湖城",
			cityFargo: "法戈",
			cityDuluth: "德卢斯",
			cityMinneapolis: "明尼阿波利斯",
			cityChicago: "芝加哥",
			cityStLouis: "圣路易斯",
			cityCincinnati: "辛辛那提",
			cityKnoxville: "诺克斯维尔",
			cityKansasCity: "堪萨斯城",
			cityOklahomaCity: "俄克拉何马城",
			cityDallas: "达拉斯",
			cityHouston: "休斯敦",
			cityMemphis: "孟菲斯",
			cityNewOrleans: "新奥尔良",
			cityBirmingham: "伯明翰",
			cityDetroit: "底特律",
			cityBuffalo: "布法罗",
			cityPittsburgh: "匹兹堡",
			cityBoston: "波士顿",
			cityNewYork: "纽约",
			cityPhiladelphia: "费城",
			cityWashingtonDC: "华盛顿",
			cityAtlanta: "亚特兰大",
			cityNorfolk: "诺福克",
			cityRaleigh: "罗利",
			citySavannah: "萨凡纳",
			cityJacksonville: "杰克逊维尔",
			cityTampa: "坦帕",
			cityMiami: "迈阿密"
		},
		en: {
			name: "Power Grid",
			desc: "Auction power plants, buy fuel, and expand your grid to supply the most cities",
			rules: "Goal:\n· The game runs for several rounds. When a player reaches the required number of cities, the endgame is triggered; after the final scoring, the player who supplies the most cities wins. Ties are broken by remaining money.\nSetup:\n· Each player starts with 50 Elektro and no power plants or cities.\n· First choose the map and the regions in play. Starting with the starting player, players take turns choosing one region; each new region must be adjacent to the regions already chosen, except the first one. A three-player game uses three regions, four players use four, and five or six players use five; with six players the last player does not choose after the fifth region is taken.\n· Only cities inside the chosen regions can be connected.\nEach round:\n· A round consists of five phases, and every player finishes one phase before the game moves on.\n· 1. Player order: order players by connected cities, most first; ties favor the player with the largest power plant. The order for the first round is drawn at setup.\n· 2. Auction power plants: in player order from best to worst, each player either puts one plant from the current market up for auction or, from round two onward, passes; the other players then raise or pass in turn, and the last remaining bidder pays the bid and takes the plant. Each player may gain at most one plant per round, and must gain one in the first round. The cheapest plant in the current market is discounted to a minimum bid of 1; every other plant's minimum bid equals its number. Sold plants are replaced from the deck.\n· 3. Buy resources: in player order from worst to best, each player buys coal, oil, garbage, or uranium for their plants. A plant can store only the resources it burns, up to twice its required amount; hybrid plants store coal and oil with the same combined limit. Wind plants need and store no fuel.\n· 4. Build cities: in player order from worst to best, each player may connect any number of cities. The first city may be any empty city inside the chosen regions for 10 Elektro, with no connection cost. Every later city pays the shortest connection cost from the player's own cities plus the next free slot in that city: 10 for the first player, 15 for the second, and 20 for the third. Connection routes may pass through any city in the regions, including fully occupied cities.\n· 5. Bureaucracy: in player order from best to worst, each player chooses which plants to run. Each plant runs at most once per round and must consume its full required fuel; the total capacity is the sum of the cities printed on the plants that run. The player supplies the smaller of that capacity and their number of cities, then earns income based on supplied cities; supplying none still earns 10 Elektro, and more supplied cities earn more. After everyone has been paid, the resource market is refilled, fuel is restocked according to player count and step, and the plant market is updated.\nSteps and city capacity:\n· In step 1 each city holds one player, in step 2 two players, and in step 3 three players. A city slot always costs according to how many players are already there: 10, 15, or 20 Elektro.\n· When any player connects a seventh city (a sixth city with six players), step 2 begins at the end of that round's build phase: the cheapest plant in the current market is removed and replaced.\n· Step 3 begins in the next phase after the Step 3 card is drawn. If it is drawn during the auction, the auction continues; at the end of that phase the card and the cheapest plant in the current market are removed, and step 3 starts with the resource-buying phase. If it is drawn during the bureaucracy, the card and the cheapest plant are removed immediately, resources are refilled one last time using the step 2 column, and step 3 starts in the next round. During step 3 the market holds only six plants, and all of them are available in an auction.\nEndgame:\n· At the end of a build phase, if any player has reached the endgame city count, the game ends after that round: 17 cities for three or four players, 15 for five, and 14 for six. Only supplied cities are compared, and no income is paid; ties are broken by remaining money.\nPower plants and fuel:\n· A player may own at most three plants. Buying a fourth plant requires scrapping one immediately; fuel on the scrapped plant is moved to the remaining plants where possible, and anything that does not fit returns to the supply.\n· A plant's number is its minimum bid, its market order, and the tie-breaker for player order. Plants burn coal, oil, garbage, or uranium, or are hybrid or wind. A hybrid plant runs on coal or oil, normally the cheaper one.\n· During the game, you may move fuel between your own plants at any time. The receiving plant must be able to use the fuel and have space to store it.\nUSA map rule:\n· When the coal market is empty, you may buy coal from the reserve for 8 Elektro per token during the resource-buying phase. You cannot buy any more coal when the reserve is also empty.\nGermany map rule:\n· On the Germany map, once plant 39 is bought by any player, no more uranium is restocked for the rest of the game. This does not trigger if plant 39 is never bought or is not in this game's deck.",
			mapGermany: "Germany",
			mapUsa: "USA",
			optionMap: "Map",
			optionMapHint: "Choose one of the two original maps",
			roundChip: "Round {{n}}",
			stepChip: "Step {{n}}",
			phaseAreasYou: "Choose your regions",
			phaseAreas: "{{name}} is choosing regions",
			areasSub: "Tap a region adjacent to those already chosen; {{n}} left to pick",
			phaseOfferYou: "Your turn to buy a power plant",
			phaseOfferWait: "Waiting for {{name}} to buy a power plant",
			phaseBid: "Plant {{plant}} up for auction",
			phaseBidSub: "Highest bid {{bid}} Elektro by {{name}}",
			phaseBidYou: "Highest bid is {{bid}} Elektro; raise or pass",
			phaseResourcesYou: "Buy fuel",
			phaseResources: "Waiting for {{name}} to buy fuel",
			phaseBuildYou: "Build cities",
			phaseBuild: "Waiting for {{name}} to build cities",
			phasePowerYou: "Choose plants to run",
			phasePower: "Waiting for {{name}} to supply power",
			phaseScrapYou: "You bought a fourth plant; scrap one",
			phaseScrap: "Waiting for {{name}} to scrap a plant",
			phaseOver: "Game over",
			marketTitle: "Plant market",
			deckLeft: "Deck {{n}}",
			discountTag: "Discount",
			selectPlantHint: "Tap a plant to put it up for auction",
			plantCities: "Supplies {{n}}",
			plantFuel: "{{n}} {{res}}",
			plantFuelHybrid: "{{n}} coal/oil",
			plantWind: "Wind",
			offerMin: "Min bid {{n}}",
			bidAmount: "Your bid",
			bidConfirm: "Bid",
			bidPass: "Pass",
			declineOffer: "Skip this round",
			bidNeedHigher: "Must be above {{n}}",
			bidNeedMin: "Must be at least {{n}}",
			bidNeedMoney: "Not enough money",
			auctionTop: "{{name}} leads",
			auctionOfferBy: "{{name}} opened the auction",
			resCoal: "coal",
			resOil: "oil",
			resGarbage: "garbage",
			resUranium: "uranium",
			kindCoal: "Coal",
			kindOil: "Oil",
			kindGarbage: "Garbage",
			kindUranium: "Uranium",
			kindHybrid: "Hybrid",
			kindWind: "Wind",
			priceNow: "Price {{n}}",
			soldOut: "Sold out",
			supplyPanel: "Resource market",
			supplyLeft: "Supply {{n}}",
			storageFull: "Storage full",
			fuelBuy: "Buy",
			fuelStored: "Have {{n}}",
			fuelCapacity: "Room {{n}}",
			buyFuelTitle: "Plant {{n}}: buy fuel",
			buyEnd: "Done buying",
			buildEnd: "Done building",
			buildHint: "Tap a highlighted city to build",
			buildCost: "{{n}} Elektro",
			buildNone: "No city can be built right now",
			myPlants: "Your plants",
			noPlants: "You have no plants yet",
			playersPanel: "Players and plants",
			tapPlantHint: "Tap a plant to buy fuel",
			powerHint: "Tap a plant to toggle whether it runs",
			powerCapacity: "Total capacity {{n}} cities",
			powerIncome: "Income {{n}} Elektro",
			powerConfirm: "Supply power",
			powerNeedFuel: "Not enough fuel",
			scrapTitle: "Scrap a plant",
			scrapHint: "Choose one plant to scrap; its fuel moves to your other plants",
			scrapAria: "Scrap plant {{n}}",
			moneyStat: "{{n}} Elektro",
			citiesStat: "Cities {{n}}",
			suppliedStat: "Supplied {{n}}",
			noFuel: "No fuel",
			cityEmpty: "Unoccupied",
			cityAvailable: "Can connect",
			cityConnected: "Connected",
			zoomIn: "Zoom in on map",
			zoomOut: "Zoom out on map",
			emptyStorage: "Fuel storage is empty",
			acting: "Active",
			auctionTitle: "Plant auction",
			powerTitle: "Power generation",
			waitFor: "Waiting for {{name}}",
			plantNumber: "Plant {{n}}",
			buyAt: "Buy · {{n}} Elektro",
			buildCity: "Connect {{city}}",
			buildBreakdown: "City slot {{site}} + line cost {{route}} Elektro",
			buildConfirm: "Connect · {{n}} Elektro",
			powerCities: "Power up to {{n}} cities this round",
			scrapConfirm: "Confirm scrapping",
			futureMarket: "Future market",
			currentMarket: "Current market",
			marketStock: "In market",
			reserveCoalQuote: "Reserve coal · {{n}} Elektro",
			transferFuel: "Transfer fuel",
			transferSource: "Select the plant supplying the fuel.",
			transferDestination: "Choose the receiving plant and the fuel to move.",
			transferNone: "There is no fuel you can transfer right now.",
			transferTo: "Move 1 {{resource}} to plant {{n}}",
			errTransfer: "Move fuel between your own plants with compatible storage and available space",
			showResults: "Show results",
			reviewMap: "Review map",
			finalTitle: "Final power report",
			finalWinner: "{{names}} wins",
			finalJointWinners: "{{names}} tie for first",
			finalSupply: "Cities powered",
			finalMoney: "Cash left",
			finalPlayer: "Rank / Player",
			confirmRestart: "Confirm rematch",
			confirmLeave: "Confirm return to lobby",
			hintCount: "Hints used: {{n}}",
			autopilotShare: "Autopilot {{n}}%",
			close: "Close",
			errTurn: "Not your turn yet",
			errAction: "That action is not available in this phase",
			errArea: "Choose an unchosen region adjacent to those already chosen",
			errPlant: "That plant is not in the current market",
			errBid: "The bid must beat the current high bid and fit your money",
			errResource: "This plant cannot buy that resource",
			errFuel: "Not enough fuel, or the plant is full",
			errMoney: "Not enough money",
			errBuild: "That city cannot be built",
			errScrap: "You can only scrap one of your own plants",
			regionGreen: "Green region",
			regionBrown: "Brown region",
			regionRed: "Red region",
			regionBlue: "Blue region",
			regionYellow: "Yellow region",
			regionPurple: "Purple region",
			regionDarkGreen: "Dark green region",
			regionLightGreen: "Light green region",
			cityFlensburg: "Flensburg",
			cityKiel: "Kiel",
			cityHamburg: "Hamburg",
			cityBremen: "Bremen",
			cityCuxhaven: "Cuxhaven",
			cityWilhelmshaven: "Wilhelmshaven",
			cityHannover: "Hannover",
			cityLubeck: "Lübeck",
			citySchwerin: "Schwerin",
			cityRostock: "Rostock",
			cityTorgelow: "Torgelow",
			cityMagdeburg: "Magdeburg",
			cityBerlin: "Berlin",
			cityFrankfurtO: "Frankfurt (Oder)",
			cityOsnabruck: "Osnabrück",
			cityMunster: "Münster",
			cityEssen: "Essen",
			cityDortmund: "Dortmund",
			cityDuisburg: "Duisburg",
			cityDuesseldorf: "Düsseldorf",
			cityKassel: "Kassel",
			cityKoln: "Cologne",
			cityAachen: "Aachen",
			cityFrankfurtM: "Frankfurt (Main)",
			cityWiesbaden: "Wiesbaden",
			cityTrier: "Trier",
			citySaarbrucken: "Saarbrücken",
			cityMannheim: "Mannheim",
			cityDresden: "Dresden",
			cityFulda: "Fulda",
			cityErfurt: "Erfurt",
			cityHalle: "Halle",
			cityLeipzig: "Leipzig",
			cityWuerzburg: "Würzburg",
			cityNurnberg: "Nuremberg",
			cityStuttgart: "Stuttgart",
			cityFreiburg: "Freiburg",
			cityKonstanz: "Konstanz",
			cityAugsburg: "Augsburg",
			cityMuenchen: "Munich",
			cityRegensburg: "Regensburg",
			cityPassau: "Passau",
			citySeattle: "Seattle",
			cityPortland: "Portland",
			cityBoise: "Boise",
			cityBillings: "Billings",
			cityCheyenne: "Cheyenne",
			cityOmaha: "Omaha",
			cityDenver: "Denver",
			citySanFrancisco: "San Francisco",
			cityLosAngeles: "Los Angeles",
			citySanDiego: "San Diego",
			cityLasVegas: "Las Vegas",
			cityPhoenix: "Phoenix",
			citySantaFe: "Santa Fe",
			citySaltLakeCity: "Salt Lake City",
			cityFargo: "Fargo",
			cityDuluth: "Duluth",
			cityMinneapolis: "Minneapolis",
			cityChicago: "Chicago",
			cityStLouis: "St. Louis",
			cityCincinnati: "Cincinnati",
			cityKnoxville: "Knoxville",
			cityKansasCity: "Kansas City",
			cityOklahomaCity: "Oklahoma City",
			cityDallas: "Dallas",
			cityHouston: "Houston",
			cityMemphis: "Memphis",
			cityNewOrleans: "New Orleans",
			cityBirmingham: "Birmingham",
			cityDetroit: "Detroit",
			cityBuffalo: "Buffalo",
			cityPittsburgh: "Pittsburgh",
			cityBoston: "Boston",
			cityNewYork: "New York",
			cityPhiladelphia: "Philadelphia",
			cityWashingtonDC: "Washington DC",
			cityAtlanta: "Atlanta",
			cityNorfolk: "Norfolk",
			cityRaleigh: "Raleigh",
			citySavannah: "Savannah",
			cityJacksonville: "Jacksonville",
			cityTampa: "Tampa",
			cityMiami: "Miami"
		}
	}
};
//#endregion
export { Mt as default };
