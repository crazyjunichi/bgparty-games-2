import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as l, rich as u } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f, SeatBadgedAvatar as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { AVATARS as v } from "@bgparty/sdk/avatars";
import { IconBot as y } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as b } from "@bgparty/sdk/player-colors";
import { OptionSwitch as x } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var S = [
	"bread",
	"carrot",
	"cheese",
	"fish",
	"meat",
	"mushroom",
	"wine"
], C = [
	2,
	2,
	2,
	3,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7
], w = [
	"soup",
	"garden",
	"desert",
	"water",
	"air",
	"lantern",
	"midnight",
	"academy"
], T = {
	soup: {
		id: "soup",
		slots: 0
	},
	garden: {
		id: "garden",
		slots: 3
	},
	desert: {
		id: "desert",
		slots: 3
	},
	water: {
		id: "water",
		slots: 3
	},
	air: {
		id: "air",
		slots: 4
	},
	lantern: {
		id: "lantern",
		slots: 5
	},
	midnight: {
		id: "midnight",
		slots: 5
	},
	academy: {
		id: "academy",
		slots: 0
	}
};
function E(e) {
	let t = /* @__PURE__ */ new Set([
		"soup",
		"garden",
		"desert",
		"academy",
		"midnight"
	]);
	return e >= 3 && t.add("water"), e >= 4 && t.add("air"), (e === 5 || e >= 7) && t.add("lantern"), w.filter((e) => t.has(e));
}
var D = [
	[
		"meat",
		"carrot",
		"wine"
	],
	[
		"cheese",
		"meat",
		"mushroom"
	],
	[
		"mushroom",
		"wine",
		"fish"
	],
	[
		"bread",
		"fish",
		"cheese"
	],
	[
		"carrot",
		"mushroom",
		"bread"
	],
	[
		"fish",
		"cheese",
		"carrot"
	],
	[
		"wine",
		"bread",
		"meat"
	]
], O = [
	"games.critterkitchen.challenge0",
	"games.critterkitchen.challenge1",
	"games.critterkitchen.challenge2",
	"games.critterkitchen.challenge3",
	"games.critterkitchen.challenge4",
	"games.critterkitchen.challenge5",
	"games.critterkitchen.challenge6"
], ee = [
	"games.critterkitchen.critic0",
	"games.critterkitchen.critic1",
	"games.critterkitchen.critic2",
	"games.critterkitchen.critic3",
	"games.critterkitchen.critic4",
	"games.critterkitchen.critic5",
	"games.critterkitchen.critic6",
	"games.critterkitchen.critic7",
	"games.critterkitchen.critic8",
	"games.critterkitchen.critic9",
	"games.critterkitchen.critic10",
	"games.critterkitchen.critic11",
	"games.critterkitchen.critic12",
	"games.critterkitchen.critic13",
	"games.critterkitchen.critic14",
	"games.critterkitchen.critic15"
], te = [
	"games.critterkitchen.criticText0",
	"games.critterkitchen.criticText1",
	"games.critterkitchen.criticText2",
	"games.critterkitchen.criticText3",
	"games.critterkitchen.criticText4",
	"games.critterkitchen.criticText5",
	"games.critterkitchen.criticText6",
	"games.critterkitchen.criticText7",
	"games.critterkitchen.criticText8",
	"games.critterkitchen.criticText9",
	"games.critterkitchen.criticText10",
	"games.critterkitchen.criticText11",
	"games.critterkitchen.criticText12",
	"games.critterkitchen.criticText13",
	"games.critterkitchen.criticText14",
	"games.critterkitchen.criticText15"
], k = /* @__PURE__ */ "games.critterkitchen.rumor0,games.critterkitchen.rumor1,games.critterkitchen.rumor2,games.critterkitchen.rumor3,games.critterkitchen.rumor4,games.critterkitchen.rumor5,games.critterkitchen.rumor6,games.critterkitchen.rumor7,games.critterkitchen.rumor8,games.critterkitchen.rumor9,games.critterkitchen.rumor10,games.critterkitchen.rumor11,games.critterkitchen.rumor12,games.critterkitchen.rumor13,games.critterkitchen.rumor14,games.critterkitchen.rumor15,games.critterkitchen.rumor16,games.critterkitchen.rumor17,games.critterkitchen.rumor18,games.critterkitchen.rumor19,games.critterkitchen.rumor20,games.critterkitchen.rumor21,games.critterkitchen.rumor22,games.critterkitchen.rumor23,games.critterkitchen.rumor24,games.critterkitchen.rumor25,games.critterkitchen.rumor26,games.critterkitchen.rumor27".split(","), ne = /* @__PURE__ */ "games.critterkitchen.rumorText0,games.critterkitchen.rumorText1,games.critterkitchen.rumorText2,games.critterkitchen.rumorText3,games.critterkitchen.rumorText4,games.critterkitchen.rumorText5,games.critterkitchen.rumorText6,games.critterkitchen.rumorText7,games.critterkitchen.rumorText8,games.critterkitchen.rumorText9,games.critterkitchen.rumorText10,games.critterkitchen.rumorText11,games.critterkitchen.rumorText12,games.critterkitchen.rumorText13,games.critterkitchen.rumorText14,games.critterkitchen.rumorText15,games.critterkitchen.rumorText16,games.critterkitchen.rumorText17,games.critterkitchen.rumorText18,games.critterkitchen.rumorText19,games.critterkitchen.rumorText20,games.critterkitchen.rumorText21,games.critterkitchen.rumorText22,games.critterkitchen.rumorText23,games.critterkitchen.rumorText24,games.critterkitchen.rumorText25,games.critterkitchen.rumorText26,games.critterkitchen.rumorText27".split(","), A = {
	2: "bread",
	3: "carrot",
	4: "cheese",
	6: "fish",
	8: "meat",
	10: "mushroom",
	27: "wine"
}, re = [
	"games.critterkitchen.rest0",
	"games.critterkitchen.rest1",
	"games.critterkitchen.rest2",
	"games.critterkitchen.rest3",
	"games.critterkitchen.rest4",
	"games.critterkitchen.rest5",
	"games.critterkitchen.rest6",
	"games.critterkitchen.rest7",
	"games.critterkitchen.rest8",
	"games.critterkitchen.rest9",
	"games.critterkitchen.rest10",
	"games.critterkitchen.rest11",
	"games.critterkitchen.rest12",
	"games.critterkitchen.rest13"
], ie = [
	"games.critterkitchen.restText0",
	"games.critterkitchen.restText1",
	"games.critterkitchen.restText2",
	"games.critterkitchen.restText3",
	"games.critterkitchen.restText4",
	"games.critterkitchen.restText5",
	"games.critterkitchen.restText6",
	"games.critterkitchen.restText7",
	"games.critterkitchen.restText8",
	"games.critterkitchen.restText9",
	"games.critterkitchen.restText10",
	"games.critterkitchen.restText11",
	"games.critterkitchen.restText12",
	"games.critterkitchen.restText13"
], ae = [
	{
		id: 100,
		cap: 2,
		timing: "after",
		exp: !1
	},
	{
		id: 101,
		cap: 1,
		timing: "start",
		exp: !1
	},
	{
		id: 102,
		cap: 3,
		timing: "start",
		exp: !1
	},
	{
		id: 103,
		cap: 3,
		timing: "before",
		exp: !1
	},
	{
		id: 104,
		cap: 2,
		timing: "after",
		exp: !1
	},
	{
		id: 105,
		cap: 1,
		timing: "after",
		exp: !1
	},
	{
		id: 106,
		cap: 3,
		timing: "after",
		exp: !1
	},
	{
		id: 107,
		cap: 1,
		timing: "start",
		exp: !1
	},
	{
		id: 108,
		cap: 1,
		timing: "after",
		exp: !1
	},
	{
		id: 109,
		cap: 2,
		timing: "start",
		exp: !1
	},
	{
		id: 110,
		cap: 2,
		timing: "after",
		exp: !1
	},
	{
		id: 111,
		cap: 3,
		timing: "start",
		exp: !1
	},
	{
		id: 200,
		cap: 3,
		timing: "after",
		exp: !0
	},
	{
		id: 201,
		cap: 1,
		timing: "after",
		exp: !0
	},
	{
		id: 202,
		cap: 3,
		timing: "before",
		exp: !0
	},
	{
		id: 203,
		cap: 3,
		timing: "after",
		exp: !0
	},
	{
		id: 204,
		cap: 3,
		timing: "after",
		exp: !0
	},
	{
		id: 205,
		cap: 2,
		timing: "after",
		exp: !0
	},
	{
		id: 206,
		cap: 2,
		timing: "start",
		exp: !0
	},
	{
		id: 207,
		cap: 2,
		timing: "start",
		exp: !0
	},
	{
		id: 208,
		cap: 2,
		timing: "after",
		exp: !0
	},
	{
		id: 209,
		cap: 2,
		timing: "start",
		exp: !0
	},
	{
		id: 210,
		cap: 1,
		timing: "after",
		exp: !0
	},
	{
		id: 211,
		cap: 2,
		timing: "after",
		exp: !0
	},
	{
		id: 212,
		cap: 3,
		timing: "start",
		exp: !0
	},
	{
		id: 213,
		cap: 1,
		timing: "start",
		exp: !0
	},
	{
		id: 214,
		cap: 1,
		timing: "before",
		exp: !0
	},
	{
		id: 215,
		cap: 2,
		timing: "before",
		exp: !0
	},
	{
		id: 216,
		cap: 2,
		timing: "after",
		exp: !0
	},
	{
		id: 217,
		cap: 1,
		timing: "after",
		exp: !0
	},
	{
		id: 218,
		cap: 3,
		timing: "start",
		exp: !0
	},
	{
		id: 219,
		cap: 3,
		timing: "after",
		exp: !0
	},
	{
		id: 220,
		cap: 1,
		timing: "start",
		exp: !0
	},
	{
		id: 221,
		cap: 2,
		timing: "start",
		exp: !0
	},
	{
		id: 222,
		cap: 3,
		timing: "start",
		exp: !0
	},
	{
		id: 223,
		cap: 1,
		timing: "before",
		exp: !0
	}
], oe = Object.fromEntries(ae.map((e) => [e.id, `games.critterkitchen.zous${e.id}`])), j = Object.fromEntries(ae.map((e) => [e.id, `games.critterkitchen.zousText${e.id}`])), se = [
	"coffee",
	"flowers",
	"trophies",
	"gift",
	"coin",
	"mystery",
	"organic",
	"tofu",
	"zoustoo"
], ce = {
	coffee: "games.critterkitchen.cartCoffee",
	flowers: "games.critterkitchen.cartFlowers",
	trophies: "games.critterkitchen.cartTrophies",
	gift: "games.critterkitchen.cartGift",
	coin: "games.critterkitchen.cartCoin",
	mystery: "games.critterkitchen.cartMystery",
	organic: "games.critterkitchen.cartOrganic",
	tofu: "games.critterkitchen.cartTofu",
	zoustoo: "games.critterkitchen.cartZousToo"
}, le = {
	coffee: "games.critterkitchen.cartTextCoffee",
	flowers: "games.critterkitchen.cartTextFlowers",
	trophies: "games.critterkitchen.cartTextTrophies",
	gift: "games.critterkitchen.cartTextGift",
	coin: "games.critterkitchen.cartTextCoin",
	mystery: "games.critterkitchen.cartTextMystery",
	organic: "games.critterkitchen.cartTextOrganic",
	tofu: "games.critterkitchen.cartTextTofu",
	zoustoo: "games.critterkitchen.cartTextZousToo"
}, ue = {
	soup: "games.critterkitchen.locSoup",
	garden: "games.critterkitchen.locGarden",
	desert: "games.critterkitchen.locDesert",
	water: "games.critterkitchen.locWater",
	air: "games.critterkitchen.locAir",
	lantern: "games.critterkitchen.locLantern",
	midnight: "games.critterkitchen.locMidnight",
	academy: "games.critterkitchen.locAcademy"
}, de = {
	bread: "games.critterkitchen.ingBread",
	carrot: "games.critterkitchen.ingCarrot",
	cheese: "games.critterkitchen.ingCheese",
	fish: "games.critterkitchen.ingFish",
	meat: "games.critterkitchen.ingMeat",
	mushroom: "games.critterkitchen.ingMushroom",
	wine: "games.critterkitchen.ingWine"
}, fe = [
	4,
	5,
	6,
	7,
	4,
	5,
	6
], pe = [4, 5], me = {
	0: 2,
	1: 3,
	2: 2,
	3: 2,
	4: 2,
	5: 2,
	6: 3,
	7: 2,
	8: 1,
	9: 2,
	10: 2,
	11: 2,
	12: 2,
	13: 1
}, he = {
	1: "games.critterkitchen.chef1",
	2: "games.critterkitchen.chef2",
	3: "games.critterkitchen.chef3"
};
//#endregion
//#region src/game/state.ts
function M(e, t) {
	return e.locations.find((e) => e.id === t);
}
function ge(e, t) {
	return e.P[t];
}
//#endregion
//#region src/game/engine.ts
function N(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor, n + 1);
		t.cursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function P(t, n) {
	let r = e(t.seed, t.cursor, n) + 1;
	return t.cursor += 1, r;
}
function F(e, t, n = {}) {
	let r = {
		id: e.nextItemId,
		kind: t,
		...n
	};
	return e.nextItemId += 1, r;
}
function I(e) {
	for (;;) {
		let t = e.bag.shift();
		if (!t) return null;
		if (!(t.kind === "rumor" && t.r !== void 0 && t.r >= 0 && e.rumorRevealed[t.r])) return t;
	}
}
function L(e, t, n = 1) {
	for (let r = 0; r < n; r += 1) {
		let n = I(e);
		if (!n) return;
		R(e, t, n);
	}
}
function R(e, t, n) {
	let r = ge(e, t);
	n.kind === "soup" ? r.soup += 1 : n.kind === "bisque" ? r.bisque += 1 : n.kind === "coin" ? r.coins += 1 : n.kind === "coffee" ? r.coffee += 1 : n.kind === "flowers" ? r.flowers += 1 : n.kind === "trophy" ? n.t && r.trophies.push(n.t) : n.kind === "zous" ? n.v !== void 0 && r.zousNext.push(n.v) : n.kind === "rumor" ? z(e, t, n) : r.items.push(n);
}
function z(e, t, n, r) {
	let i = ge(e, t), a = r ?? n.r ?? -1;
	return a < 0 && (a = i.rumorSlots.findIndex((e) => !e)), a < 0 || a > 2 || i.rumorSlots[a] ? !1 : (i.rumorSlots[a] = !0, i.known[a] = !0, e.players.every((t) => ge(e, t).rumorSlots[a]) && (e.rumorRevealed[a] = !0), B(e, {
		k: "rumor",
		rid: t
	}), !0);
}
function _e(e, t) {
	return ge(e, t).rumorSlots.filter(Boolean).length;
}
function B(e, t) {
	e.events.push(t), e.events.length > 40 && e.events.splice(0, e.events.length - 40);
}
function ve(e, t, n) {
	let r = M(e, t);
	for (let t = 0; t < n; t += 1) {
		let t = I(e);
		if (!t) break;
		r.items.push(t);
	}
}
function V(e, t) {
	let n = I(e);
	return n && t.items.push(n), n;
}
function H(e, t) {
	let n = e.priority.indexOf(t);
	return n < 0 ? e.players.length : n;
}
function ye(e, t) {
	e.priority = e.priority.filter((e) => e !== t), e.priority.push(t);
}
function be(e, t) {
	e.priority = e.priority.filter((e) => e !== t), e.priority.unshift(t);
}
function xe(e) {
	for (let t of [
		"garden",
		"desert",
		"water",
		"air",
		"lantern"
	]) {
		let n = e.locations.find((e) => e.id === t);
		if (!n) continue;
		let r = T[t].slots;
		ve(e, t, Math.max(0, r - n.items.length));
	}
	let t = M(e, "soup");
	t.items.some((e) => e.kind === "bisque") || t.items.push(F(e, "bisque")), t.items.some((e) => e.kind === "soup") || t.items.unshift(F(e, "soup"));
}
function Se(e, t) {
	t.kind === "organic" ? e.organicStack.push(t) : t.kind === "tofu" ? e.tofuStack.push(t) : t.kind === "zousing" ? e.zousIngStack.push(t) : (t.kind === "ingredient" || t.kind === "spice") && e.bag.push(t);
}
//#endregion
//#region src/game/schema.ts
var Ce = t.enum(S), we = t.enum([...S, "allspice"]), U = t.enum(w), W = t.object({
	id: t.number().int(),
	kind: t.enum([
		"ingredient",
		"spice",
		"rumor",
		"coffee",
		"flowers",
		"trophy",
		"coin",
		"mystery",
		"organic",
		"tofu",
		"zousing",
		"soup",
		"bisque",
		"zous"
	]),
	t: we.optional(),
	v: t.number().int().optional(),
	r: t.number().int().optional()
}), Te = t.object({
	expansion: t.boolean().default(!1),
	carts: t.boolean().default(!0)
}).default({
	expansion: !1,
	carts: !0
}), Ee = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3)
]), G = t.object({
	id: t.number().int(),
	spice: t.number().int().optional()
}), De = t.object({
	challenge: t.number().int().min(0).max(6),
	items: t.array(G),
	soup: t.number().int().min(0),
	bisque: t.number().int().min(0)
}), Oe = t.object({ items: t.array(G) }), ke = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("restPick"),
		id: t.number().int()
	}),
	t.object({
		type: t.literal("plan"),
		chefs: t.array(t.object({
			chef: Ee,
			loc: U
		})),
		breakChef: Ee.optional(),
		zous: t.array(t.object({
			id: t.number().int(),
			loc: U
		}))
	}),
	t.object({
		type: t.literal("pick"),
		item: t.number().int(),
		slot: t.number().int().min(0).max(2).optional()
	}),
	t.object({ type: t.literal("leave") }),
	t.object({
		type: t.literal("gift"),
		box: t.number().int().min(0).max(1)
	}),
	t.object({
		type: t.literal("extra"),
		item: t.number().int(),
		slot: t.number().int().min(0).max(2).optional()
	}),
	t.object({ type: t.literal("coin") }),
	t.object({
		type: t.literal("coffee"),
		loc: U
	}),
	t.object({
		type: t.literal("meals"),
		meals: t.array(De)
	}),
	t.object({
		type: t.literal("fridge"),
		keep: t.array(t.number().int())
	}),
	t.object({
		type: t.literal("critic"),
		courses: t.record(Ce, Oe),
		extra: De.optional()
	})
]), K = t.string(), Ae = t.object({
	k: t.enum([
		"rest",
		"plan",
		"pick",
		"rumor",
		"soup",
		"leave",
		"gift",
		"coin",
		"coffee",
		"challenge",
		"fridge",
		"critic",
		"round",
		"zous",
		"star",
		"final"
	]),
	rid: K.optional(),
	loc: t.string().optional(),
	n: t.number().optional(),
	t: t.string().optional(),
	q: t.number().optional(),
	s: t.number().optional()
}), je = t.object({
	kind: t.enum([
		"coffee",
		"flowers",
		"trophies",
		"gift",
		"coin",
		"mystery",
		"organic",
		"tofu",
		"zoustoo"
	]),
	items: t.array(W),
	flowers: t.number().int(),
	gifts: t.array(t.array(W)),
	zous: t.number().int().nullable()
}), Me = t.object({
	loc: U,
	activeRid: K,
	activeChef: t.number().int().nullable(),
	activeZous: t.number().int().nullable(),
	picks: t.number().int(),
	cap: t.number().int(),
	pendingCoffee: t.boolean(),
	extraAvailable: t.boolean()
}), Ne = t.object({
	rid: K,
	challenge: t.number().int(),
	quality: t.number().int(),
	stars: t.number().int(),
	items: t.array(W),
	soup: t.number().int(),
	bisque: t.number().int()
}), Pe = t.object({
	rid: K,
	stars: t.number().int(),
	base: t.number().int(),
	bonus: t.number().int(),
	quality: t.number().int(),
	track: t.number().int(),
	courses: t.record(Ce, t.number().int())
}), Fe = t.object({
	phase: t.enum([
		"rest",
		"plan",
		"shop",
		"challenge",
		"fridge",
		"critic",
		"done"
	]),
	round: t.number().int(),
	day: t.number().int(),
	players: t.array(t.object({
		rid: K,
		stars: t.number().int(),
		rumorSlots: t.array(t.boolean()),
		zous: t.array(t.number().int()),
		breakChef: t.number().int().nullable(),
		coffee: t.number().int(),
		coins: t.number().int(),
		flowers: t.number().int(),
		trophies: t.array(Ce),
		restaurateur: t.number().int().nullable(),
		ready: t.boolean()
	})),
	priority: t.array(K),
	locations: t.array(t.object({
		id: U,
		items: t.array(W),
		chefs: t.array(t.object({
			rid: K,
			chef: t.number().int().nullable(),
			cap: t.number().int(),
			zous: t.number().int().nullable()
		})),
		zous: t.number().int().nullable(),
		cart: je.nullable()
	})),
	rumorCards: t.array(t.number().int().nullable()),
	rumorRevealed: t.array(t.boolean()),
	critic: t.number().int(),
	challenges: t.array(t.number().int()),
	held: t.array(t.number().int()),
	extraChallenge: t.number().int().nullable(),
	breakRoll: t.number().int().nullable(),
	shop: Me.nullable(),
	events: t.array(Ae),
	mealResults: t.array(Ne),
	final: t.object({
		entries: t.array(Pe),
		ranking: t.array(K)
	}).nullable()
}), Ie = t.object({
	items: t.array(W),
	soup: t.number().int(),
	bisque: t.number().int(),
	rumorCards: t.array(t.number().int().nullable()),
	known: t.array(t.boolean()),
	hiddenRumor: t.number().int().nullable(),
	zousReady: t.array(t.number().int()),
	restaurateur: t.number().int().nullable(),
	offers: t.array(t.number().int()),
	canAct: t.boolean(),
	planReady: t.boolean(),
	mealReady: t.boolean(),
	fridgeReady: t.boolean(),
	fridgeLimit: t.number().int(),
	criticReady: t.boolean(),
	shop: t.object({
		canPick: t.boolean(),
		canLeave: t.boolean(),
		canGift: t.boolean(),
		canExtra: t.boolean(),
		canCoin: t.boolean(),
		canCoffee: t.boolean(),
		giftCost: t.number().int()
	}).nullable(),
	lastMeals: t.array(Ne),
	lastCritic: t.record(Ce, t.number().int()).nullable()
}), Le = {
	id: "critterkitchen",
	uuid: "883678d2-ad99-46e4-96a9-e40e597659f3",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"set-collection",
		"action-programming"
	],
	interactionTags: [],
	nameKey: "games.critterkitchen.name",
	descKey: "games.critterkitchen.desc",
	rulesKey: "games.critterkitchen.rules",
	icon: "🍲",
	iconImg: "games/critterkitchen.webp",
	minPlayers: 2,
	maxPlayers: 7,
	bestPlayers: [3, 4],
	playerRange: (e) => {
		let t = Te.safeParse(e);
		return {
			min: 2,
			max: t.success && t.data.expansion ? 7 : 5
		};
	},
	accent: "#d4543c",
	releasedAt: "2026-11-26T03:08:44+08:00",
	search: {
		py: "dong wu xing can ting",
		init: "dwxct"
	},
	hotseat: "cover",
	botDelayMs: 900,
	rulesUrl: { en: "https://cardboardalchemy.com/downloads/CritterKitchen_Rulebook.pdf" }
}, Re = (e) => ae.find((t) => t.id === e)?.cap ?? 1;
function ze(e) {
	return (e.kind === "ingredient" || e.kind === "spice" || e.kind === "trophy") && e.t ? `${e.kind}:${e.t}` : e.kind === "zous" && e.v !== void 0 ? `zous:${e.v}` : e.kind;
}
function Be(e) {
	let t = e.nextUid;
	return e.nextUid += 1, t;
}
function Ve(e, t, n, r) {
	return {
		uid: Be(e),
		rid: t,
		chef: n,
		zous: r,
		cap: n || Re(r),
		count: 0,
		bonus: 0,
		picks: [],
		started: !1,
		afterDone: !1,
		done: !1,
		left: !1
	};
}
function He(e, t, n) {
	let r = e.locations[n];
	return !!r && r.entries.some((e) => e.rid === t && !e.done);
}
function Ue(e) {
	let t = e.items.length;
	return e.cart && (t += e.cart.items.length, e.cart.kind === "gift" && (t += e.cart.gifts.reduce((e, t) => e + t.length, 0))), t;
}
function We(e) {
	for (let t of e.locations) t.entries = [];
	e.shop = {
		loc: 0,
		active: null,
		firstPicked: !1,
		pendingCoffee: null,
		coinUsed: [],
		hatSuppressed: !1,
		tieSizes: {},
		firstPickRid: null
	};
	for (let t of e.players) {
		let n = e.P[t], r = n.plan;
		if (r) {
			e.breakRoll !== null && r.breakChef === e.breakRoll && (n.soup += 2, B(e, {
				k: "soup",
				rid: t,
				n: 2
			}));
			for (let n of r.chefs) r.breakChef !== n.chef && M(e, n.loc).entries.push(Ve(e, t, n.chef, null));
			for (let n of r.zous) M(e, n.loc).entries.push(Ve(e, t, null, n.id));
		}
	}
	if (e.critic === 15) for (let t of e.players) {
		let n = 0;
		for (let r of e.locations) {
			let e = new Set(r.entries.map((e) => e.rid));
			e.size === 1 && e.has(t) && (n += 1);
		}
		n > 0 && (e.P[t].stars += n, B(e, {
			k: "star",
			rid: t,
			n
		}));
	}
	Ge(e);
}
function Ge(e) {
	let t = e.shop, n = e.locations[t.loc];
	t.firstPicked = !1, t.active = null, t.pendingCoffee = null, t.coinUsed = [], t.hatSuppressed = !1, t.firstPickRid = null, t.tieSizes = {};
	for (let e of n.entries) t.tieSizes[e.cap] = (t.tieSizes[e.cap] ?? 0) + 1;
	if (n.id === "midnight") {
		let t = T.midnight.slots;
		ve(e, "midnight", Math.max(0, t - n.items.length));
	}
	qe(e, n), $e(e);
}
function Ke(e) {
	return e.items.some((e) => (e.kind === "ingredient" || e.kind === "spice") && e.t === "fish");
}
function qe(e, t) {
	let n = [...t.entries];
	n.sort((t, n) => H(e, t.rid) - H(e, n.rid) || t.uid - n.uid);
	for (let r of n) {
		if (r.done || r.left) continue;
		let n = r.zous;
		if (n === 101) t.entries.filter((e) => !e.done).length === 1 && (r.cap = Math.max(r.cap, 3));
		else if (n === 102) be(e, r.rid);
		else if (n === 107) e.shop.hatSuppressed = !0;
		else if (n === 109) {
			let n = t.entries.find((e) => e !== r && e.cap === 2 && !e.done);
			n && (L(e, r.rid, 1), L(e, n.rid, 1));
		} else if (n === 111) V(e, t), V(e, t);
		else if (n === 212) Ye(e, t, r);
		else if (n === 220) for (let e of t.entries) e.rid !== r.rid && !e.done && (e.cap = 1);
		else if (n === 221) for (let n of t.entries) {
			if (n.rid === r.rid || n.done) continue;
			let t = e.P[n.rid], i = Je(t);
			i && (t.items = t.items.filter((e) => e.id !== i.id), r.picks.push(i));
		}
	}
}
function Je(e) {
	let t = null;
	for (let n of e.items) n.v && (!t || n.v < (t.v ?? 0)) && (t = n);
	return t;
}
function Ye(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of t.entries) if (!(i.rid === n.rid || i.done)) for (let t of e.P[i.rid].items) (t.kind === "ingredient" || t.kind === "spice") && t.t && r.set(t.t, (r.get(t.t) ?? 0) + 1);
	let i = null, a = 0;
	for (let [e, t] of r) t > a && (a = t, i = e);
	if (i) for (let r of t.entries) {
		if (r.rid === n.rid || r.done) continue;
		let t = e.P[r.rid], a = t.items.find((e) => (e.kind === "ingredient" || e.kind === "spice") && e.t === i);
		a ? (t.items = t.items.filter((e) => e.id !== a.id), n.picks.push(a)) : (r.left = !0, r.done = !0, t.soup += 1);
	}
}
function Xe(e, t) {
	let n = t.cap;
	return t.zous === 107 || t.zous === 209 && e.id === "midnight" && Ke(e) ? n = -300 : t.zous === 222 && (n -= .5), t.chef === 1 && e.entries.some((e) => e.zous === 218) && (n = 1e3), n;
}
function Ze(e) {
	return e.entries.filter((e) => !e.done && !e.left);
}
function Qe(e) {
	let t = e.shop;
	if (!t || t.active == null) return null;
	for (let n of e.locations) {
		let e = n.entries.find((e) => e.uid === t.active);
		if (e) return e;
	}
	return null;
}
function $e(e) {
	let t = e.shop;
	if (!t || t.pendingCoffee != null) return;
	let n = e.locations[t.loc];
	for (;;) {
		let r = Ze(n);
		if (r.length === 0) {
			nt(e);
			return;
		}
		let i = r.filter((e) => e.bonus > 0);
		if (i.length > 0) {
			i.sort((t, n) => H(e, t.rid) - H(e, n.rid) || t.uid - n.uid);
			let r = i[0];
			if (et(e, n, r)) {
				t.active = r.uid;
				return;
			}
			at(e, n, r), it(e, r);
			continue;
		}
		if (Ue(n) === 0) {
			tt(e, n);
			return;
		}
		let a = r.map((e) => Xe(n, e)), o = Math.min(...a), s = r.filter((e) => Xe(n, e) === o);
		s.sort((t, n) => t.count - n.count || H(e, t.rid) - H(e, n.rid) || t.uid - n.uid);
		let c = s[0];
		if (et(e, n, c)) {
			t.active = c.uid;
			return;
		}
		at(e, n, c), it(e, c);
	}
}
function et(e, t, n) {
	let r = e.P[n.rid], i = ut(e, n.rid), a = (e) => e.kind === "rumor" ? e.r === void 0 ? !1 : e.r >= 0 ? !r.rumorSlots[e.r] : r.rumorSlots.some((e) => !e) : e.kind !== "coffee" || i.length > 0;
	return !!(t.items.some(a) || t.cart?.items.some(a) || t.cart?.kind === "gift" && r.stars >= 1 && t.cart.gifts.some((e) => e.length > 0) || n.count > 0 && n.bonus === 0 && r.coins >= 1 && !e.shop.coinUsed.includes(n.rid));
}
function tt(e, t) {
	for (let n of [...Ze(t)]) at(e, t, n), it(e, n);
	nt(e);
}
function nt(e) {
	let t = e.shop, n = e.locations[t.loc];
	for (let t of n.entries) t.done || it(e, t);
	if (n.entries = [], n.id === "academy") {
		let t = M(e, "soup");
		for (let e of n.items) (e.kind === "ingredient" || e.kind === "spice") && t.items.push(e);
		n.items = [];
	} else if (n.id !== "soup") {
		let t = M(e, "academy");
		for (let e of n.items) (e.kind === "ingredient" || e.kind === "spice") && t.items.push(e);
		n.items = [];
	}
	if (n.cart && (n.cart.kind === "zoustoo" && (n.cart.zous = null), n.cart.items = []), t.loc += 1, t.loc >= e.locations.length) {
		e.shop = null, yt(e);
		return;
	}
	Ge(e);
}
function rt(e, t) {
	let n = e.P[t.rid];
	for (let n of t.picks) R(e, t.rid, n);
	t.picks = [], t.count === 0 && !t.left && (n.restaurateur === 1 ? L(e, t.rid, 1) : n.soup += 1), t.done = !0;
}
function it(e, t) {
	t.done || rt(e, t);
}
function at(e, t, n) {
	if (n.afterDone || n.left) return;
	n.afterDone = !0;
	let r = e.P[n.rid];
	switch (n.zous) {
		case 100:
			H(e, n.rid) === e.players.length - 1 && (r.stars += 1, B(e, {
				k: "star",
				rid: n.rid,
				n: 1
			}));
			break;
		case 104:
			L(e, n.rid, 1);
			break;
		case 105: {
			let t = M(e, "soup"), n = t.items.find((e) => e.kind === "bisque");
			n ? (t.items = t.items.filter((e) => e.id !== n.id), r.bisque += 1) : r.soup += 1;
			break;
		}
		case 106:
			t.items.length > 0 ? n.bonus += 1 : L(e, n.rid, 1);
			break;
		case 108: {
			let e = [...t.items.filter((e) => e.kind === "ingredient" && e.v), ...n.picks.filter((e) => e.kind === "ingredient" && e.v)];
			if (e.length > 0) {
				let t = Math.min(...e.map((e) => e.v));
				n.picks.some((e) => e.kind === "ingredient" && e.v === t) && (r.soup += 3);
			}
			break;
		}
		case 110: {
			let t = M(e, "soup"), n = t.items.find((e) => e.kind === "bisque");
			n ? (t.items = t.items.filter((e) => e.id !== n.id), r.bisque += 1) : r.soup += 1;
			break;
		}
		case 200:
			n.picks.some((e) => e.kind === "ingredient" && e.t === "bread") && (r.stars += 1, B(e, {
				k: "star",
				rid: n.rid,
				n: 1
			}));
			break;
		case 201:
			ot(e, n, (t, n) => t > e.shop.loc && n !== "academy" && e.locations[t].entries.length === 0);
			break;
		case 203: {
			let t = n.picks.filter((e) => e.kind === "ingredient" && e.t === "meat").length;
			L(e, n.rid, t);
			break;
		}
		case 204:
			r.soup += n.picks.length;
			break;
		case 205: {
			let t = M(e, "academy"), r = 3 - n.count;
			for (; r > 0;) {
				let i = t.items.findIndex((e) => e.kind !== "zous");
				if (i < 0) break;
				let [a] = t.items.splice(i, 1);
				R(e, n.rid, a), --r;
			}
			break;
		}
		case 208: {
			let t = [];
			for (let n = 0; n < 5; n += 1) {
				let n = I(e);
				if (!n) break;
				n.kind === "ingredient" && n.t === "mushroom" ? t.push(n) : e.bag.push(n);
			}
			for (let r of t) R(e, n.rid, r);
			break;
		}
		case 210:
			t.items.length > 0 && (n.bonus += 1, V(e, t), V(e, t));
			break;
		case 211: {
			if (r.rumorSlots.every(Boolean)) break;
			let t = n.picks.find((e) => e.kind === "ingredient" && e.t === "wine");
			if (!t) break;
			n.picks = n.picks.filter((e) => e.id !== t.id);
			let i = r.rumorSlots.findIndex((e) => !e);
			i >= 0 && (r.rumorSlots[i] = !0, r.known[i] = !0, e.players.every((t) => e.P[t].rumorSlots[i]) && (e.rumorRevealed[i] = !0));
			break;
		}
		case 216:
			ot(e, n, (t) => e.locations[t].id === "midnight" && t > e.shop.loc && !He(e, n.rid, t));
			break;
		case 217:
			e.shop.firstPickRid === n.rid && L(e, n.rid, 1);
			break;
		case 219: n.bonus += _e(e, n.rid);
	}
}
function ot(e, t, n) {
	for (let r = 0; r < e.locations.length; r += 1) {
		let i = e.locations[r].id;
		if (!n(r, i)) continue;
		let a = Ve(e, t.rid, t.chef, t.zous);
		e.locations[r].entries.push(a);
		for (let n of t.picks) R(e, t.rid, n);
		t.picks = [], t.done = !0;
		return;
	}
}
function st(e, t, n) {
	if (n.started) return;
	n.started = !0;
	let r = e.P[n.rid];
	switch (n.zous) {
		case 103:
			V(e, t);
			break;
		case 202: {
			let n = t.items.filter((e) => e.kind === "ingredient" || e.kind === "spice").sort((e, t) => (e.v ?? 0) - (t.v ?? 0)).slice(0, 3);
			for (let r of n) t.items = t.items.filter((e) => e.id !== r.id), e.bag.push(r), V(e, t);
			break;
		}
		case 214:
			for (let n of [...t.items]) n.kind !== "rumor" || n.r === void 0 || n.r < 0 || r.rumorSlots[n.r] || r.soup <= 0 || (--r.soup, r.rumorSlots[n.r] = !0, r.known[n.r] = !0, e.players.every((t) => e.P[t].rumorSlots[n.r]) && (e.rumorRevealed[n.r] = !0));
			break;
		case 215:
			t.items.some((e) => e.kind === "spice") && (n.cap += 1);
			break;
		case 223: t.entries.filter((e) => !e.done).length === 1 && L(e, n.rid, 2);
	}
}
function ct(e, t, n, r) {
	let i = e.shop, a = e.locations[i.loc], o = a.cart?.items.some((e) => e.id === n) ?? !1, s = o ? a.cart.items.find((e) => e.id === n) : a.items.find((e) => e.id === n);
	if (!s) return {
		ok: !1,
		err: "noItem"
	};
	let c = e.P[t.rid];
	if (s.kind === "rumor") {
		if (s.r === void 0) return {
			ok: !1,
			err: "noItem"
		};
		if (s.r >= 0) {
			if (c.rumorSlots[s.r]) return {
				ok: !1,
				err: "rumorSlot"
			};
		} else {
			let e = r.slot;
			if (e === void 0 || e < 0 || e > 2 || c.rumorSlots[e]) return {
				ok: !1,
				err: "rumorSlot"
			};
		}
	}
	if (s.kind === "coffee" && !ut(e, t.rid).length) return {
		ok: !1,
		err: "coffeeDest"
	};
	if (s.kind !== "soup" && (o ? a.cart.items = a.cart.items.filter((e) => e.id !== s.id) : a.items = a.items.filter((e) => e.id !== s.id)), st(e, a, t), !i.firstPicked) {
		i.firstPicked = !0, i.firstPickRid = t.rid;
		let n = i.tieSizes[t.cap ?? 0] ?? 0, r = a.entries.some((e) => e.zous === 222 && e.cap === t.cap);
		n >= 2 && !i.hatSuppressed && !r && ye(e, t.rid), a.cart?.kind === "flowers" && a.cart.flowers > 0 && (c.flowers += a.cart.flowers, a.cart.flowers = 0);
	}
	let l = !r.bonus;
	switch (s.kind) {
		case "rumor":
			if (r.slot !== void 0 && s.r === -1) {
				if (!lt(e, t.rid, r.slot)) return {
					ok: !1,
					err: "rumorSlot"
				};
			} else if (!lt(e, t.rid, s.r)) return {
				ok: !1,
				err: "rumorSlot"
			};
			break;
		case "coffee":
			t.picks.push(s), i.pendingCoffee = t.uid;
			break;
		case "mystery": {
			let n = P(e, 6);
			L(e, t.rid, n);
			break;
		}
		case "zous":
			s.v !== void 0 && (c.zousNext.push(s.v), (s.v === 207 || t.zous === 207) && (c.stars += 1, B(e, {
				k: "star",
				rid: t.rid,
				n: 1
			})));
			break;
		default: t.picks.push(s);
	}
	return s.kind === "coffee" ? B(e, {
		k: "coffee",
		rid: t.rid
	}) : s.kind === "zous" ? B(e, {
		k: "zous",
		rid: t.rid,
		n: s.v
	}) : s.kind !== "rumor" && B(e, {
		k: "pick",
		rid: t.rid,
		loc: a.id,
		t: ze(s)
	}), l ? t.count += 1 : t.bonus = Math.max(0, t.bonus - 1), (!l && t.bonus === 0 && t.count >= t.cap || l && t.count >= t.cap) && (at(e, a, t), t.bonus === 0 && !t.done && it(e, t)), $e(e), { ok: !0 };
}
function lt(e, t, n) {
	let r = e.P[t];
	return n < 0 || n > 2 || r.rumorSlots[n] ? !1 : (r.rumorSlots[n] = !0, r.known[n] = !0, e.players.every((t) => e.P[t].rumorSlots[n]) && (e.rumorRevealed[n] = !0), !0);
}
function ut(e, t) {
	let n = e.shop, r = [];
	for (let i = n.loc + 1; i < e.locations.length; i += 1) He(e, t, i) || r.push(i);
	return r;
}
function dt(e, t, n, r) {
	let i = e.shop;
	if (!i || i.pendingCoffee != null) return "turn";
	let a = Qe(e);
	if (!a || a.rid !== t) return "turn";
	let o = ct(e, a, n, {
		bonus: !1,
		slot: r
	});
	return o.ok ? "ok" : o.err;
}
function ft(e, t, n, r) {
	let i = e.shop;
	if (!i || i.pendingCoffee != null) return "turn";
	let a = Qe(e);
	if (!a || a.rid !== t || a.bonus <= 0) return "turn";
	let o = ct(e, a, n, {
		bonus: !0,
		slot: r
	});
	return o.ok ? "ok" : o.err;
}
function pt(e, t) {
	let n = e.shop;
	if (!n) return "turn";
	let r = Qe(e);
	if (!r || r.rid !== t) return "turn";
	if (r.count > 0) return "picked";
	r.left = !0, r.done = !0;
	let i = e.P[t];
	return B(e, {
		k: "leave",
		rid: t,
		loc: e.locations[n.loc].id
	}), i.restaurateur === 1 ? L(e, t, 1) : i.soup += 1, $e(e), "ok";
}
function mt(e, t, n) {
	let r = e.shop;
	if (!r) return "turn";
	let i = Qe(e);
	if (!i || i.rid !== t) return "turn";
	let a = e.locations[r.loc], o = a.cart;
	if (!o || o.kind !== "gift" || !o.gifts[n] || o.gifts[n].length === 0) return "noBox";
	let s = e.P[t];
	return s.stars < 1 ? "noStar" : (--s.stars, i.picks.push(...o.gifts[n]), o.gifts[n] = [], i.count += 1, B(e, {
		k: "gift",
		rid: t
	}), i.count >= i.cap && (at(e, a, i), i.bonus === 0 && !i.done && it(e, i)), $e(e), "ok");
}
function ht(e, t) {
	let n = e.shop;
	if (!n) return "turn";
	let r = Qe(e);
	if (!r || r.rid !== t) return "turn";
	let i = e.P[t];
	return r.count === 0 ? "noPick" : i.coins < 1 ? "noCoin" : n.coinUsed.includes(t) ? "used" : (--i.coins, n.coinUsed.push(t), e.locations[n.loc].items.push({
		id: e.nextItemId,
		kind: "coin"
	}), e.nextItemId += 1, r.bonus += 1, B(e, {
		k: "coin",
		rid: t
	}), $e(e), "ok");
}
function gt(e, t, n) {
	let r = e.shop;
	if (!r || r.pendingCoffee == null) return "turn";
	let i = Qe(e);
	if (!i || i.rid !== t) return "turn";
	if (!ut(e, t).includes(n)) return "dest";
	r.pendingCoffee = null;
	for (let n of i.picks) R(e, t, n);
	i.picks = [], i.done = !0;
	let a = Ve(e, t, i.chef, i.zous);
	return e.locations[n].entries.push(a), $e(e), "ok";
}
function _t(e) {
	if (e.day = e.round <= 3 ? 1 : e.round <= 6 ? 2 : 3, xe(e), e.players.length === 2) {
		let t = M(e, "academy");
		V(e, t), V(e, t);
	}
	if (e.round <= 6) {
		e.challengeRevealed = e.round;
		let t = e.round - 1, n = e.challenges[t];
		n !== void 0 && (e.round === 3 || e.round === 6) && !e.heldChallenges.includes(n) && e.heldChallenges.push(n);
	}
	let t = M(e, "academy");
	if (t.items = t.items.filter((e) => e.kind !== "zous"), e.round === 7) t.items.push({
		id: e.nextItemId,
		kind: "spice",
		t: "allspice"
	}), e.nextItemId += 1;
	else if (e.zousDeck.length > 0) {
		let n = e.zousDeck.shift();
		t.items.push({
			id: e.nextItemId,
			kind: "zous",
			v: n
		}), e.nextItemId += 1;
	}
	vt(e), e.breakRoll = e.players.length >= 6 ? P(e, 3) : null;
	for (let t of e.players) e.P[t].restaurateur === 13 && (e.round === 1 || e.round === 4 || e.round === 7) && e.zousDeck.length > 0 && e.P[t].zousReady.push(e.zousDeck.shift());
	for (let t of e.players) e.P[t].ready = !1, e.P[t].plan = null;
	e.phase = "plan", B(e, {
		k: "round",
		n: e.round
	});
}
function vt(e) {
	for (let t of e.locations) {
		let n = t.cart;
		if (n) switch (n.kind) {
			case "coffee":
				n.items.push({
					id: e.nextItemId,
					kind: "coffee"
				}), e.nextItemId += 1;
				break;
			case "flowers":
				n.flowers += 1;
				break;
			case "trophies":
				e.trophyStack.length > 0 && (n.items.push({
					id: e.nextItemId,
					kind: "trophy",
					t: e.trophyStack.shift()
				}), e.nextItemId += 1);
				break;
			case "gift":
				for (let t of n.gifts) for (let n = 0; n < 2; n += 1) {
					let n = I(e);
					n && t.push(n);
				}
				break;
			case "coin":
				n.items.push({
					id: e.nextItemId,
					kind: "coin"
				}), e.nextItemId += 1;
				break;
			case "mystery":
				n.items.push({
					id: e.nextItemId,
					kind: "mystery"
				}), e.nextItemId += 1;
				break;
			case "organic": {
				let t = e.organicStack.shift();
				t && n.items.push(t);
				break;
			}
			case "tofu": {
				let t = e.tofuStack.shift();
				t && n.items.push(t);
				break;
			}
			case "zoustoo":
				if (n.zous != null && (n.zous = null), e.zousDeck.length > 0) {
					let t = e.zousDeck.shift();
					n.zous = t, n.items = n.items.filter((e) => e.kind !== "zous"), n.items.push({
						id: e.nextItemId,
						kind: "zous",
						v: t
					}), e.nextItemId += 1;
				}
				for (let t = 0; t < 2; t += 1) {
					let t = e.zousIngStack.shift();
					t && n.items.push(t);
				}
		}
	}
}
function yt(e) {
	for (let t of e.players) {
		let n = e.P[t];
		n.zousReady = n.zousNext, n.zousNext = [], n.breakChef = null, n.ready = !1, n.lastMeals = [], n.lastCritic = null;
	}
	for (let t of e.players) if (e.P[t].restaurateur === 9) {
		let n = e.priority.indexOf(t);
		n > 0 ? (e.priority = e.priority.filter((e) => e !== t), e.priority.splice(n - 1, 0, t)) : L(e, t, 1);
	}
	if ((e.round === 3 || e.round === 6 || e.round === 7) && bt(e), e.round === 7) {
		e.phase = "critic";
		for (let t of e.players) e.P[t].criticCourses = null, e.P[t].ready = !1;
		return;
	}
	if (e.round === 3 || e.round === 6) {
		e.phase = "challenge";
		for (let t of e.players) e.P[t].meals = null, e.P[t].ready = !1;
		return;
	}
	e.round += 1, _t(e);
}
function bt(e) {
	let t = Math.max(...e.players.map((t) => e.P[t].flowers));
	if (!(t <= 0)) for (let n of e.players) e.P[n].flowers === t && (e.P[n].stars += 1, B(e, {
		k: "star",
		rid: n,
		n: 1
	}));
}
//#endregion
//#region src/game/scoring.ts
function xt(e, t) {
	return e.items.find((e) => e.id === t);
}
function St(e, t) {
	return t.kind === "ingredient" ? !(e.critic === 9 && t.v === 2 || e.critic === 13 && t.v === 3) : t.kind === "spice" ? e.critic !== 14 : t.kind === "tofu" || t.kind === "zousing" || t.kind === "flowers";
}
function Ct(e) {
	return e <= 1 ? 5 : 10;
}
function wt(e, t) {
	let n = t.v ?? 0;
	return t.kind === "organic" && (n = 8), e.critic === 6 && t.kind === "ingredient" && n === 6 && (n = 9), e.critic === 8 && t.kind === "ingredient" && t.t === "carrot" && (n *= 2), n;
}
function Tt(e, t, n, r) {
	let i = e.P[t], a = r;
	return i.restaurateur === 2 && (n === "meat" || n === "fish") && (a += 3), i.restaurateur === 4 && r === 2 && (a += 2), a;
}
function Et(e) {
	return e.critic === 11 ? 3 : 2;
}
function Dt(e, t, n) {
	if (n === -1) return e.critic !== 5 || !t.rumorSlots.some(Boolean) ? null : {
		type: null,
		allspice: !0
	};
	let r = xt(t, n);
	return r ? r.kind === "spice" ? {
		type: r.t === "allspice" ? null : r.t,
		allspice: r.t === "allspice"
	} : e.critic === 10 && r.kind === "ingredient" && r.t === "wine" ? {
		type: null,
		allspice: !0
	} : null : null;
}
function Ot(e, t, n, r, i) {
	return n.allspice || n.type === null || r.kind === "tofu" || e.critic === 1 && r.t === "mushroom" || t.restaurateur === 8 ? !0 : i === n.type;
}
function kt(e, t, n, r) {
	let i = xt(t, n);
	if (!i) return { err: "badItem" };
	if (i.kind === "spice") return t.restaurateur === 12 ? r === void 0 ? {
		item: i,
		type: i.t === "allspice" ? "any" : i.t ?? "any",
		printed: 5,
		spiced: !1,
		spiceId: null
	} : { err: "badSpice" } : { err: "badItem" };
	if (i.kind !== "ingredient" && i.kind !== "organic" && i.kind !== "tofu" && i.kind !== "zousing") return { err: "badItem" };
	let a = i.kind === "tofu" ? "any" : i.t ?? "any", o = !1, s = null;
	if (r !== void 0) {
		let n = Dt(e, t, r);
		if (!n || !Ot(e, t, n, i, a)) return { err: "badSpice" };
		i.kind === "tofu" && n.type && (a = n.type), o = !0, s = r;
	} else if (i.kind === "tofu") return { err: "tofuSpice" };
	let c = !1;
	return e.critic === 1 && i.kind === "ingredient" && i.t === "mushroom" && (c = !0), t.restaurateur === 11 && (i.v ?? 0) === 3 && i.kind === "ingredient" && (c = !0), c && (a = "any"), {
		item: i,
		type: a,
		printed: wt(e, i),
		spiced: o,
		spiceId: s
	};
}
function At(e, t) {
	e.add(t.item.id), t.spiceId != null && t.spiceId >= 0 && e.add(t.spiceId);
}
function jt(e, t) {
	return !!(e.has(t.item.id) || t.spiceId != null && t.spiceId >= 0 && (e.has(t.spiceId) || t.spiceId === t.item.id));
}
function Mt(e) {
	return e >= 21 ? 4 : e >= 12 ? 2 : +(e >= 6);
}
function Nt(e) {
	return e <= 0 ? 0 : 10 * Math.floor((e - 1) / 70) + Math.ceil(((e - 1) % 70 + 1) / 7);
}
function Pt(e, t, n) {
	let r = e.P[t], i = D[n.challenge];
	if (!i) return { err: "badChallenge" };
	let a = e.heldChallenges.includes(n.challenge) ? i.slice(0, -1) : [...i], o = /* @__PURE__ */ new Set(), s = [];
	for (let t of n.items) {
		let n = kt(e, r, t.id, t.spice);
		if ("err" in n) return { err: n.err };
		if (jt(o, n)) return { err: "dupItem" };
		At(o, n), s.push(n);
	}
	if (s.length === 0) return { err: "noIngredient" };
	if (n.soup < 0 || n.bisque < 0 || n.soup > r.soup || n.bisque > r.bisque) return { err: "badSoup" };
	let c = /* @__PURE__ */ new Set(), l = [];
	for (let e of s) if (e.type === "any") l.push(1);
	else if (a.includes(e.type)) c.add(e.type);
	else return { err: "badType" };
	let u = l.length, d = a.filter((e) => !c.has(e));
	if (n.soup + n.bisque + u < d.length) return { err: "missingReq" };
	let f = /* @__PURE__ */ new Set();
	for (let t of s) {
		if (!t.spiced) continue;
		let n = (t.spiceId == null ? null : t.spiceId === -1 ? {
			type: null,
			allspice: !0
		} : Dt(e, r, t.spiceId))?.type ?? (t.type === "any" ? null : t.type);
		n && f.add(n);
	}
	let p = Et(e), m = 0;
	for (let n of s) {
		let i = Tt(e, t, n.type, n.printed), a = r.restaurateur === 6 && n.type !== "any" && f.has(n.type);
		(n.spiced || a) && (i *= p), m += i;
	}
	if (m += n.soup + n.bisque * 3, r.restaurateur === 10 && (m += Math.min(r.rumorSlots.filter(Boolean).length, 5)), m < 6) return { err: "weakMeal" };
	let h = Mt(m);
	if (e.critic === 2 && h > 0 && (h += 1), r.restaurateur === 5 && m >= 25 && (h += 1), r.restaurateur === 3 && n.soup + n.bisque === 0) {
		let e = /* @__PURE__ */ new Map();
		for (let t of s) t.type !== "any" && e.set(t.type, (e.get(t.type) ?? 0) + 1);
		a.length === s.length && a.every((t) => e.get(t) === 1) && (h += 1);
	}
	return {
		quality: m,
		stars: h,
		servedIds: [...o],
		soup: n.soup,
		bisque: n.bisque
	};
}
function Ft(e, t, n) {
	let r = e.P[t], i = new Set(n.servedIds), a = [];
	for (let t of r.items) i.has(t.id) ? Se(e, t) : a.push(t);
	r.items = a, r.soup = Math.max(0, r.soup - n.soup), r.bisque = Math.max(0, r.bisque - n.bisque);
}
function It(e, t, n) {
	let r = e.P[t], i = Ct(e.day), a = new Set(n);
	for (let t of a) {
		let n = xt(r, t);
		if (!n || !St(e, n)) return "badItem";
	}
	let o = Math.min(r.flowers, i), s = [];
	for (let t of r.items) {
		if (t.kind === "organic") {
			Se(e, t);
			continue;
		}
		if (St(e, t)) {
			a.has(t.id) ? (o += 1, s.push(t)) : Se(e, t);
			continue;
		}
		s.push(t);
	}
	return o > i ? "tooMany" : (r.items = s, "ok");
}
var Lt = () => Object.fromEntries(S.map((e) => [e, 0])), Rt = () => Object.fromEntries(S.map((e) => [e, []]));
function zt(e, t, n) {
	let r = e.P[t], i = Lt(), a = Rt(), o = [], s = /* @__PURE__ */ new Set(), c = 0, l = 0, u = 0, d = !1;
	for (let t of S) {
		let f = n[t];
		if (!f || f.items.length === 0) continue;
		let p = [], m = [];
		for (let n of f.items) {
			let i = kt(e, r, n.id, n.spice);
			if ("err" in i) return { err: i.err };
			if (jt(s, i)) return { err: "dupItem" };
			if (At(s, i), e.critic === 4 && i.item.kind === "ingredient" && i.item.t === "wine" && !i.spiced && i.type !== t) m.push(i);
			else {
				if (i.type !== "any" && i.type !== t) return { err: "badType" };
				p.push(i);
			}
		}
		if (p.length === 0) return { err: "noIngredient" };
		let h = Math.max(...p.map((e) => e.printed)), g = 0;
		if (e.critic === 0 && t === "cheese") g = 99;
		else if (e.critic === 3 && !d) {
			if (p.length <= 4) p.length > 1 && (d = !0), g = 99;
			else return { err: "tooManyItems" };
		} else e.critic === 14 ? g = 1 : e.critic === 9 ? g = p.filter((e) => e.printed === 2).length : e.critic === 13 && t === "fish" && (g = h);
		let _ = (e.critic === 14 ? 2 : 1) + (e.critic === 0 && t === "cheese" ? 99 : 0) + (e.critic === 3 && g > 0 ? 3 : 0) + (e.critic === 9 ? g : 0) + (e.critic === 13 && t === "fish" ? g : 0), v = e.critic === 0 && t === "cheese" ? 99 : e.critic === 3 && g > 0 ? 4 : _;
		if (p.length > v || e.critic === 4 && m.length > 1) return { err: "tooManyItems" };
		for (let e of m) if (e.printed !== h) return { err: "badWinePair" };
		let y = /* @__PURE__ */ new Set();
		for (let t of p) {
			if (!t.spiced) continue;
			let n = (t.spiceId == null ? null : t.spiceId === -1 ? {
				type: null,
				allspice: !0
			} : Dt(e, r, t.spiceId))?.type ?? (t.type === "any" ? null : t.type);
			n && y.add(n);
		}
		let b = Et(e), x = 0;
		for (let e of p) {
			let n = e.spiced || r.restaurateur === 6 && e.type !== "any" && y.has(e.type);
			x += n ? e.printed * b : e.printed, e.spiced && (c += 1), e.printed >= 6 && (u += 1), o.push({
				printed: e.printed,
				type: e.type,
				spiced: e.spiced
			}), a[t].push(e.printed);
		}
		for (let e of m) x += e.printed, l += 1, o.push({
			printed: e.printed,
			type: "wine",
			spiced: !1
		}), a[t].push(e.printed);
		i[t] = x;
	}
	return {
		qualityByCourse: i,
		printedByCourse: a,
		served: o,
		servedIds: [...s],
		spicedCount: c,
		winePairCount: l,
		poodleCount: u
	};
}
function Bt(e, t) {
	let n = 0;
	for (let r of e.served) r.type === t && r.printed > n && (n = r.printed);
	return n;
}
function Vt(e) {
	return S.filter((t) => e.printedByCourse[t].length > 0).length;
}
function Ht(e, t, n, r, i) {
	if (A[r]) return 0;
	let a = e.P[t], o = n.served.map((e) => e.printed), s = S.filter((e) => n.printedByCourse[e].length > 0), c = (e) => {
		let t = n.printedByCourse[e];
		return t.length ? Math.max(...t) : 0;
	};
	switch (r) {
		case 0: return c("cheese") >= s.length ? 3 : 0;
		case 1: return a.soup + a.bisque * 3 >= c("bread") ? 2 : 0;
		case 5: return s.length === 7 && s.every((e) => c(e) >= 5) ? 2 : 0;
		case 7: {
			if (s.length === 0) return 0;
			let e = s[s.length - 1], t = n.qualityByCourse[e];
			return s.every((e) => n.qualityByCourse[e] <= t) ? 2 : 0;
		}
		case 9: return o.length ? Math.max(...o) - Math.min(...o) : 0;
		case 11: {
			if (s.length === 0) return 0;
			let e = -1;
			for (let t of s) {
				let n = c(t);
				if (n < e) return 0;
				e = n;
			}
			return 5;
		}
		case 12: return s.length > 0 && s.every((e) => c(e) % 2 == 1) ? 3 : 0;
		case 13: return s.length === 7 && o.length ? Math.min(...o) : 0;
		case 14: {
			if (!s.includes("mushroom")) return 0;
			let e = n.qualityByCourse.mushroom;
			return s.every((t) => n.qualityByCourse[t] <= e) ? 2 : 0;
		}
		case 15: return Math.max(0, c("carrot") - 2);
		case 16: return i.winners.ru16?.has(t) ? 3 : 0;
		case 17: return (c("wine") > 0 && c("wine") === c("fish") ? 2 : 0) + (c("wine") > 0 && c("wine") === c("meat") ? 2 : 0);
		case 18: return i.winners.ru18?.has(t) ? 2 : 0;
		case 19: return i.winners.ru19?.has(t) ? 3 : 0;
		case 20: return a.rumorSlots.filter(Boolean).length;
		case 21: return s.length === 0 ? 0 : c(s[0]) + c(s[s.length - 1]) === 10 ? 3 : 0;
		case 22: return Math.floor((i.unserved[t]?.count ?? 0) / 2) + +!!i.winners.ru22?.has(t);
		case 23: return (i.singleUnspiced[t] ?? 0) + +!!i.winners.ru23?.has(t);
		case 24: return (i.unserved[t]?.values.size ?? 0) + +!!i.winners.ru24?.has(t);
		case 25: return (i.servedValues[t]?.size ?? 0) + +!!i.winners.ru25?.has(t);
		case 26: return i.unserved[t]?.wine ?? 0;
		default: return 0;
	}
}
function Ut(e) {
	let t = Object.values(e), n = t.length ? Math.max(...t) : 0, r = /* @__PURE__ */ new Set();
	if (n <= 0) return r;
	for (let [t, i] of Object.entries(e)) i === n && r.add(t);
	return r;
}
function Wt(e) {
	let t = [];
	for (let n of e.rumorCards) n != null && t.push(n);
	for (let n of e.players) {
		let r = e.P[n].hiddenRumor;
		r != null && t.push(r);
	}
	return [...new Set(t)];
}
function Gt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.players) {
		let r = e.P[n], i = zt(e, n, r.criticCourses ?? {});
		if ("err" in i) {
			t.set(n, {
				qualityByCourse: Lt(),
				printedByCourse: Rt(),
				served: [],
				servedIds: [],
				spicedCount: 0,
				winePairCount: 0,
				poodleCount: 0
			});
			continue;
		}
		t.set(n, i);
	}
	let n = Wt(e), r = /* @__PURE__ */ new Map();
	for (let e of n) {
		let t = A[e];
		t && r.set(t, (r.get(t) ?? 0) + 1);
	}
	let i = {
		winners: {},
		unserved: {},
		servedValues: {},
		courseMaxes: {},
		singleUnspiced: {}
	}, a = {
		ru16: {},
		ru18: {},
		ru19: {},
		ru22: {},
		ru23: {},
		ru24: {},
		ru25: {}
	};
	for (let n of e.players) {
		let r = e.P[n], o = t.get(n), s = new Set(o.servedIds), c = r.items.filter((e) => !s.has(e.id) && (e.kind === "ingredient" || e.kind === "organic" || e.kind === "tofu" || e.kind === "zousing" || e.kind === "spice")), l = /* @__PURE__ */ new Set(), u = 0;
		for (let t of c) {
			if (t.kind === "spice") continue;
			let n = wt(e, t);
			e.critic === 6 && t.kind === "ingredient" && (t.v ?? 0) === 6 ? l.add(9) : e.critic === 8 && t.kind === "ingredient" && t.t === "carrot" ? l.add((t.v ?? 0) * 2) : l.add(n), t.kind === "ingredient" && t.t === "wine" && (u += 1);
		}
		i.unserved[n] = {
			count: c.length,
			values: l,
			wine: u
		};
		let d = new Set(o.served.map((e) => e.printed));
		i.servedValues[n] = d;
		let f = /* @__PURE__ */ new Map();
		for (let e of o.served) f.set(e.printed, (f.get(e.printed) ?? 0) + 1);
		a.ru16[n] = Math.max(0, ...f.values()), a.ru18[n] = o.served.filter((e) => e.spiced).length;
		let p = Bt(o, "bread");
		a.ru19[n] = p > 0 ? o.served.filter((e) => e.printed === p).length : 0, a.ru22[n] = c.length;
		let m = 0;
		for (let e of S) {
			let t = o.printedByCourse[e];
			t.length === 1 && o.qualityByCourse[e] === t[0] && (m += 1);
		}
		i.singleUnspiced[n] = m, a.ru23[n] = m, a.ru24[n] = l.size, a.ru25[n] = d.size;
	}
	i.winners.ru16 = Ut(a.ru16), i.winners.ru18 = Ut(a.ru18), i.winners.ru19 = Ut(a.ru19), i.winners.ru22 = Ut(a.ru22), i.winners.ru23 = Ut(a.ru23), i.winners.ru24 = Ut(a.ru24), i.winners.ru25 = Ut(a.ru25);
	let o = Object.fromEntries(e.players.map((e) => [e, 0])), s = Object.fromEntries(e.players.map((e) => [e, []]));
	for (let n of S) {
		let r = 0;
		for (let i of e.players) r = Math.max(r, t.get(i).qualityByCourse[n]);
		if (!(r <= 0)) for (let i of e.players) t.get(i).qualityByCourse[n] === r && (s[i].push(n), o[i] += e.critic === 0 && n === "cheese" ? 3 : 1, e.P[i].trophies.includes(n) && (o[i] += 1));
	}
	let c = 0;
	for (let t of e.players) c = Math.max(c, e.P[t].soup + e.P[t].bisque * 3);
	if (c > 0) for (let t of e.players) e.P[t].soup + e.P[t].bisque * 3 === c && (o[t] += 1);
	for (let r of e.players) {
		let a = t.get(r);
		Vt(a) === 7 && (o[r] += 1);
		for (let t of n) o[r] += Ht(e, r, a, t, i);
		let s = e.P[r];
		o[r] += me[s.restaurateur ?? -1] ?? 0, o[r] += Math.floor(s.coins / 2), o[r] += a.winePairCount, o[r] += a.poodleCount;
	}
	let l = 0, u = 0;
	for (let t of e.players) l = Math.max(l, e.P[t].coins), u = Math.max(u, e.P[t].coffee);
	if (l > 0) for (let t of e.players) e.P[t].coins === l && (o[t] += 1);
	if (u > 0) for (let t of e.players) e.P[t].coffee === u && --o[t];
	let d = e.players.map((n) => {
		let i = e.P[n], a = t.get(n), s = {}, c = 0;
		for (let e of S) {
			let t = a.qualityByCourse[e], n = r.get(e) ?? 0;
			for (let e = 0; e < n; e += 1) t *= 2;
			s[e] = t, c += t;
		}
		let l = Nt(c);
		return {
			rid: n,
			stars: Math.max(0, i.stars + o[n] + l),
			base: i.stars,
			bonus: o[n],
			quality: c,
			track: l,
			courses: s
		};
	}), f = (t) => {
		let n = e.priority.indexOf(t);
		return n < 0 ? e.players.length : n;
	};
	d.sort((t, n) => n.stars - t.stars || n.quality - t.quality || f(t.rid) - f(n.rid) || e.players.indexOf(t.rid) - e.players.indexOf(n.rid)), e.final = {
		entries: d,
		ranking: d.map((e) => e.rid)
	}, e.phase = "done";
	for (let t of d) B(e, {
		k: "star",
		rid: t.rid,
		n: t.stars
	});
	B(e, { k: "final" });
	for (let n of e.players) {
		let r = e.P[n], i = t.get(n), a = new Set(i.servedIds), o = [];
		for (let t of r.items) a.has(t.id) ? Se(e, t) : o.push(t);
		r.items = o;
	}
}
function Kt(e) {
	return {
		critic: e.critic,
		heldChallenges: e.held,
		P: { [e.rid]: {
			items: e.items,
			soup: e.soup,
			bisque: e.bisque,
			rumorSlots: e.rumorSlots,
			restaurateur: e.restaurateur
		} }
	};
}
function qt(e, t) {
	return Pt(Kt(e), e.rid, t);
}
function Jt(e, t) {
	return zt(Kt(e), e.rid, t);
}
//#endregion
//#region src/game/rules.ts
var Yt = 28, Xt = 12, Zt = 7, Qt = 12, $t = 15, en = (e) => ({
	expansion: e.expansion === !0,
	carts: e.carts !== !1
});
function tn(e, t) {
	return {
		kind: e,
		items: [],
		flowers: 0,
		gifts: e === "gift" ? t >= 4 ? [[], []] : [[]] : [],
		zous: null
	};
}
function nn(e) {
	let t = e.players.length, n = t === 2 ? ["garden", "desert"] : [
		"garden",
		"desert",
		"water"
	], r = se.filter((e) => e !== "zoustoo"), i = t >= 6 ? ["zoustoo", ...N(e, r).slice(0, n.length - 1)] : N(e, r).slice(0, n.length);
	n.forEach((n, r) => {
		M(e, n).cart = tn(i[r], t);
	});
}
function rn(e) {
	let t = e.cfg.expansion && e.players.length >= 6;
	for (let n of S) {
		for (let t of C) e.bag.push({
			id: e.nextItemId++,
			kind: "ingredient",
			t: n,
			v: t
		});
		t && e.bag.push({
			id: e.nextItemId++,
			kind: "ingredient",
			t: n,
			v: 7
		});
	}
	for (let n of S) {
		for (let t = 0; t < 2; t += 1) e.bag.push({
			id: e.nextItemId++,
			kind: "spice",
			t: n
		});
		t && e.bag.push({
			id: e.nextItemId++,
			kind: "spice",
			t: n
		});
	}
	for (let t = 0; t < 2; t += 1) e.bag.push({
		id: e.nextItemId++,
		kind: "spice",
		t: "allspice"
	});
}
function an(e) {
	let t = e.cfg.expansion ? Yt : Xt;
	e.rumorCards = N(e, Array.from({ length: t }, (e, t) => t)).slice(0, 3);
	for (let t = 0; t < 3; t += 1) for (let n = 0; n < 3; n += 1) e.bag.push({
		id: e.nextItemId++,
		kind: "rumor",
		r: t
	});
	for (let t = 0; t < 3; t += 1) e.bag.push({
		id: e.nextItemId++,
		kind: "rumor",
		r: -1
	});
	if (e.cfg.expansion && e.players.length >= 6) for (let t = 0; t < 4; t += 1) e.bag.push({
		id: e.nextItemId++,
		kind: "rumor",
		r: -1
	});
}
function on(e) {
	let t = Array.from({ length: 12 }, (e, t) => t);
	return e.cfg.expansion && (t = t.concat([
		12,
		13,
		14,
		15
	])), e.players.length < 3 && (t = t.filter((e) => e !== $t)), t[P(e, t.length) - 1];
}
function sn(e, t, n) {
	let r = en(e), i = {
		seed: n,
		cursor: 0,
		cfg: r,
		round: 1,
		day: 1,
		phase: "rest",
		players: [...t],
		P: {},
		priority: [],
		bag: [],
		rumorCards: [],
		rumorRevealed: [
			!1,
			!1,
			!1
		],
		critic: 0,
		challenges: [],
		challengeRevealed: 0,
		heldChallenges: [],
		extraChallenge: null,
		locations: [],
		shop: null,
		organicStack: [],
		tofuStack: [],
		zousIngStack: [],
		zousDeck: [],
		trophyStack: [],
		trophiesOnCarts: 0,
		breakRoll: null,
		events: [],
		mealResults: [],
		final: null,
		nextUid: 1,
		nextItemId: 1
	};
	rn(i), an(i), i.bag = N(i, i.bag), i.critic = on(i);
	let a = N(i, Array.from({ length: 7 }, (e, t) => t));
	i.challenges = a.slice(0, 6), i.extraChallenge = i.critic === Qt ? a[6] : null, i.zousDeck = N(i, ae.filter((e) => r.expansion || !e.exp).map((e) => e.id)), i.trophyStack = N(i, [...S]), i.organicStack = N(i, S.map((e) => ({
		id: i.nextItemId++,
		kind: "organic",
		t: e,
		v: 8
	}))), i.tofuStack = N(i, fe.map((e) => ({
		id: i.nextItemId++,
		kind: "tofu",
		v: e
	}))), i.zousIngStack = N(i, S.flatMap((e) => pe.map((t) => ({
		id: i.nextItemId++,
		kind: "zousing",
		t: e,
		v: t
	})))), i.locations = E(t.length).map((e) => ({
		id: e,
		items: [],
		entries: [],
		cart: null
	}));
	for (let e of t) {
		let t = {
			stars: 0,
			items: [],
			soup: 0,
			bisque: 0,
			rumorSlots: [
				!1,
				!1,
				!1
			],
			known: [
				!1,
				!1,
				!1
			],
			hiddenRumor: null,
			zousReady: [],
			zousNext: [],
			breakChef: null,
			coffee: 0,
			coins: 0,
			flowers: 0,
			trophies: [],
			restaurateur: null,
			offers: [],
			ready: !1,
			plan: null,
			meals: null,
			fridgeKeep: null,
			criticCourses: null,
			lastMeals: [],
			lastCritic: null
		};
		i.P[e] = t;
	}
	if (r.expansion && r.carts && nn(i), i.locations.some((e) => e.cart?.kind === "gift")) for (let e of t) i.P[e].stars += 1;
	i.priority = N(i, [...t]);
	let o = N(i, Array.from({ length: r.expansion ? 14 : 10 }, (e, t) => t));
	return t.forEach((e, t) => {
		i.P[e].offers = o.slice(t * 2, t * 2 + 2);
	}), { state: i };
}
function cn(e) {
	let t = new Set(e.rumorCards);
	for (let n of e.players) {
		let r = e.P[n].hiddenRumor;
		r != null && t.add(r);
	}
	let n = e.cfg.expansion ? Yt : Xt, r = Array.from({ length: n }, (e, t) => t).filter((e) => !t.has(e));
	return r[P(e, r.length) - 1];
}
function ln(e) {
	return e.players.every((t) => e.P[t].ready);
}
var q = { code: "games.critterkitchen.errPhase" }, un = { code: "games.critterkitchen.errReady" };
function dn(e) {
	switch (e) {
		case "turn": return { code: "games.critterkitchen.errTurn" };
		case "noItem": return { code: "games.critterkitchen.errNoItem" };
		case "rumorSlot": return { code: "games.critterkitchen.errRumorSlot" };
		case "coffeeDest": return { code: "games.critterkitchen.errCoffeeDest" };
		case "picked": return { code: "games.critterkitchen.errLeaveAfterPick" };
		case "noBox": return { code: "games.critterkitchen.errGiftEmpty" };
		case "noStar": return { code: "games.critterkitchen.errNoStar" };
		case "noCoin": return { code: "games.critterkitchen.errNoCoin" };
		case "used": return { code: "games.critterkitchen.errCoinUsed" };
		case "noPick": return { code: "games.critterkitchen.errNeedPick" };
		default: return { code: "games.critterkitchen.errPhase" };
	}
}
function fn(e) {
	switch (e) {
		case "tofuSpice": return { code: "games.critterkitchen.errMealTofu" };
		case "badSpice": return { code: "games.critterkitchen.errMealSpice" };
		case "dupItem": return { code: "games.critterkitchen.errMealDup" };
		case "badSoup": return { code: "games.critterkitchen.errMealSoup" };
		case "badType": return { code: "games.critterkitchen.errMealType" };
		case "missingReq": return { code: "games.critterkitchen.errMealMissing" };
		case "badChallenge": return { code: "games.critterkitchen.errMealChallenge" };
		case "tooManyItems": return { code: "games.critterkitchen.errMealTooMany" };
		case "badWinePair": return { code: "games.critterkitchen.errWinePair" };
		case "weakMeal": return { code: "games.critterkitchen.errMealQuality" };
		default: return { code: "games.critterkitchen.errMealItem" };
	}
}
function pn(e) {
	return e.challenges.slice(Math.max(0, e.round - 3), e.round);
}
function mn(e, t) {
	let n = [];
	for (let r of t.items) {
		let t = e.items.find((e) => e.id === r.id);
		t && n.push(t);
	}
	return n;
}
function hn(e, t, n, r) {
	return {
		rid: e,
		challenge: t,
		quality: n.quality,
		stars: n.stars,
		items: r,
		soup: n.soup,
		bisque: n.bisque
	};
}
function gn(e, t, n, r) {
	return e.phase === "rest" ? n.ready ? un : n.offers.includes(r) ? (n.restaurateur = r, n.offers = [], n.ready = !0, B(e, {
		k: "rest",
		rid: t,
		t: String(r)
	}), r === Zt && n.hiddenRumor === null && (n.hiddenRumor = cn(e)), ln(e) && _t(e), { state: e }) : { code: "games.critterkitchen.errOffer" } : q;
}
function _n(e, t, n, r) {
	if (e.phase !== "plan") return q;
	if (n.ready) return un;
	if (r.chefs.length !== 3) return { code: "games.critterkitchen.errPlan" };
	let i = new Set(r.chefs.map((e) => e.chef));
	if (i.size !== 3 || ![
		1,
		2,
		3
	].every((e) => i.has(e))) return { code: "games.critterkitchen.errPlan" };
	let a = e.players.length >= 6;
	if (r.breakChef !== void 0 && !a) return { code: "games.critterkitchen.errPlan" };
	let o = a ? r.breakChef ?? e.breakRoll ?? 1 : null, s = new Set(e.locations.map((e) => e.id)), c = /* @__PURE__ */ new Set();
	for (let e of r.chefs) {
		if (!s.has(e.loc)) return { code: "games.critterkitchen.errPlan" };
		if (e.chef !== o) {
			if (c.has(e.loc)) return { code: "games.critterkitchen.errPlan" };
			c.add(e.loc);
		}
	}
	let l = /* @__PURE__ */ new Set();
	for (let e of r.zous) {
		if (!s.has(e.loc) || !n.zousReady.includes(e.id) || l.has(e.id) || c.has(e.loc)) return { code: "games.critterkitchen.errZous" };
		l.add(e.id), c.add(e.loc);
	}
	if (n.plan = {
		chefs: r.chefs.map((e) => ({
			chef: e.chef,
			loc: e.loc
		})),
		breakChef: o,
		zous: r.zous.map((e) => ({
			id: e.id,
			loc: e.loc
		}))
	}, n.breakChef = o, n.ready = !0, B(e, {
		k: "plan",
		rid: t
	}), ln(e)) {
		for (let t of e.players) e.P[t].ready = !1;
		e.phase = "shop", We(e);
	}
	return { state: e };
}
function vn(e, t, n, r) {
	if (e.phase !== "challenge") return q;
	if (n.ready) return un;
	let i = e.critic === Qt && e.extraChallenge !== null, a = i ? 4 : 3;
	if (r.length > a) return { code: "games.critterkitchen.errMealCount" };
	let o = pn(e), s = /* @__PURE__ */ new Set(), c = !1, l = [];
	for (let a of r) {
		let r = i && a.challenge === e.extraChallenge;
		if (!r && !o.includes(a.challenge)) return { code: "games.critterkitchen.errMealChallenge" };
		if (s.has(a.challenge)) return { code: "games.critterkitchen.errMealCount" };
		if (s.add(a.challenge), r) {
			if (c) return { code: "games.critterkitchen.errMealCount" };
			c = !0;
		}
		let u = Pt(e, t, a);
		if ("err" in u) return fn(u.err);
		let d = mn(n, a);
		Ft(e, t, u), n.stars += u.stars, B(e, {
			k: "challenge",
			rid: t,
			t: String(a.challenge),
			q: u.quality,
			n: u.stars
		}), l.push(hn(t, a.challenge, u, d));
	}
	if (n.meals = r, n.lastMeals = l, e.mealResults.push(...l), n.restaurateur === 0 && r.length >= 3 && (n.stars += 2, B(e, {
		k: "star",
		rid: t,
		n: 2
	})), n.ready = !0, ln(e)) {
		e.phase = "fridge";
		for (let t of e.players) {
			let n = e.P[t];
			n.ready = !1, n.fridgeKeep = null;
		}
	}
	return { state: e };
}
function yn(e, t, n, r) {
	if (e.phase !== "fridge") return q;
	if (n.ready) return un;
	let i = It(e, t, r);
	return i === "badItem" ? { code: "games.critterkitchen.errFridgeItem" } : i === "ok" ? (n.fridgeKeep = r, n.ready = !0, B(e, {
		k: "fridge",
		rid: t
	}), ln(e) && (e.round += 1, _t(e)), { state: e }) : { code: "games.critterkitchen.errFridgeLimit" };
}
function bn(e, t, n, r) {
	if (e.phase !== "critic") return q;
	if (n.ready) return un;
	if (r.extra) {
		if (e.critic !== Qt || r.extra.challenge !== e.extraChallenge) return { code: "games.critterkitchen.errMealChallenge" };
		let i = Pt(e, t, r.extra);
		if ("err" in i) return fn(i.err);
		let a = mn(n, r.extra);
		Ft(e, t, i), n.stars += i.stars;
		let o = hn(t, r.extra.challenge, i, a);
		n.lastMeals = [...n.lastMeals, o], e.mealResults.push(o), B(e, {
			k: "challenge",
			rid: t,
			t: String(r.extra.challenge),
			q: i.quality,
			n: i.stars
		});
	}
	let i = zt(e, t, r.courses);
	return "err" in i ? fn(i.err) : (n.criticCourses = r.courses, n.lastCritic = { ...i.qualityByCourse }, n.ready = !0, B(e, {
		k: "critic",
		rid: t
	}), ln(e) && Gt(e), { state: e });
}
function xn(e, t, n) {
	let r = structuredClone(e), i = r.P[n.by];
	if (!i) return { code: "games.critterkitchen.errNotPlayer" };
	switch (t.type) {
		case "restPick": return gn(r, n.by, i, t.id);
		case "plan": return _n(r, n.by, i, t);
		case "pick": {
			if (r.phase !== "shop") return q;
			let e = dt(r, n.by, t.item, t.slot);
			return e === "ok" ? { state: r } : dn(e);
		}
		case "extra": {
			if (r.phase !== "shop") return q;
			let e = ft(r, n.by, t.item, t.slot);
			return e === "ok" ? { state: r } : dn(e);
		}
		case "leave": {
			if (r.phase !== "shop") return q;
			let e = pt(r, n.by);
			return e === "ok" ? { state: r } : dn(e);
		}
		case "gift": {
			if (r.phase !== "shop") return q;
			let e = mt(r, n.by, t.box);
			return e === "ok" ? { state: r } : dn(e);
		}
		case "coin": {
			if (r.phase !== "shop") return q;
			let e = ht(r, n.by);
			return e === "ok" ? { state: r } : dn(e);
		}
		case "coffee": {
			if (r.phase !== "shop") return q;
			let e = gt(r, n.by, r.locations.findIndex((e) => e.id === t.loc));
			return e === "ok" ? { state: r } : dn(e);
		}
		case "meals": return vn(r, n.by, i, t.meals);
		case "fridge": return yn(r, n.by, i, t.keep);
		case "critic": return bn(r, n.by, i, t);
		default: return q;
	}
}
function Sn(e, t) {
	let n = e.P[t];
	return {
		rid: t,
		stars: n.stars,
		rumorSlots: [...n.rumorSlots],
		zous: [...n.zousReady],
		breakChef: e.phase === "plan" || e.phase === "rest" ? null : n.breakChef,
		coffee: n.coffee,
		coins: n.coins,
		flowers: n.flowers,
		trophies: [...n.trophies],
		restaurateur: n.restaurateur,
		ready: n.ready
	};
}
function Cn(e, t) {
	let n = e, r = n.P[t], i = Qe(n), a = !!i && i.rid === t, o = n.shop?.pendingCoffee != null, s = r.known.map((e, t) => e || n.rumorRevealed[t]), c = {
		phase: n.phase,
		round: n.round,
		day: n.day,
		players: n.players.map((e) => Sn(n, e)),
		priority: [...n.priority],
		locations: n.locations.map((e) => ({
			id: e.id,
			items: e.items.map((e) => ({ ...e })),
			chefs: e.entries.filter((e) => !e.done && !e.left).map((e) => ({
				rid: e.rid,
				chef: e.chef,
				cap: e.cap,
				zous: e.zous
			})),
			zous: null,
			cart: e.cart ? {
				kind: e.cart.kind,
				items: e.cart.items.map((e) => ({ ...e })),
				flowers: e.cart.flowers,
				gifts: e.cart.gifts.map((e) => e.map((e) => ({ ...e }))),
				zous: e.cart.zous
			} : null
		})),
		rumorCards: n.rumorCards.map((e, t) => n.rumorRevealed[t] ? e : null),
		rumorRevealed: [...n.rumorRevealed],
		critic: n.critic,
		challenges: n.challenges.map((e, t) => t < n.challengeRevealed ? e : -1),
		held: [...n.heldChallenges],
		extraChallenge: n.extraChallenge,
		breakRoll: n.breakRoll,
		shop: n.phase === "shop" && n.shop && i ? {
			loc: n.locations[n.shop.loc].id,
			activeRid: i.rid,
			activeChef: i.chef,
			activeZous: i.zous,
			picks: i.count,
			cap: i.cap,
			pendingCoffee: o,
			extraAvailable: i.bonus > 0
		} : null,
		events: n.events.map((e) => ({ ...e })),
		mealResults: n.mealResults.map((e) => ({
			...e,
			items: e.items.map((e) => ({ ...e }))
		})),
		final: n.final
	}, l = n.shop ? n.locations[n.shop.loc] : null, u = l?.cart?.kind === "gift" ? l.cart : null, d = n.phase === "shop" && n.shop && a ? {
		canPick: !o,
		canLeave: !o && i.count === 0,
		canGift: !o && !!u && u.gifts.some((e) => e.length > 0) && r.stars >= 1,
		canExtra: !o && i.bonus > 0,
		canCoin: !o && i.count > 0 && r.coins >= 1 && !n.shop.coinUsed.includes(t),
		canCoffee: o,
		giftCost: 1
	} : null;
	return {
		public: c,
		private: {
			items: r.items.map((e) => ({ ...e })),
			soup: r.soup,
			bisque: r.bisque,
			rumorCards: n.rumorCards.map((e, t) => s[t] ? e : null),
			known: s,
			hiddenRumor: r.hiddenRumor,
			zousReady: [...r.zousReady],
			restaurateur: r.restaurateur,
			offers: [...r.offers],
			canAct: n.phase === "rest" || n.phase === "plan" || n.phase === "challenge" || n.phase === "fridge" || n.phase === "critic" ? !r.ready : n.phase === "shop" && a,
			planReady: n.phase === "plan" && r.ready,
			mealReady: n.phase === "challenge" && r.ready,
			fridgeReady: n.phase === "fridge" && r.ready,
			fridgeLimit: Ct(n.day),
			criticReady: n.phase === "critic" && r.ready,
			shop: d,
			lastMeals: r.lastMeals.map((e) => ({
				...e,
				items: e.items.map((e) => ({ ...e }))
			})),
			lastCritic: r.lastCritic ? { ...r.lastCritic } : null
		}
	};
}
function wn(e) {
	if (e.phase !== "done" || !e.final) return { phase: e.phase };
	let t = e.final.entries[0];
	return {
		phase: "done",
		winner: e.final.entries.filter((e) => e.stars === t.stars && e.quality === t.quality).map((e) => e.rid),
		ranking: [...e.final.ranking],
		scores: Object.fromEntries(e.final.entries.map((e) => [e.rid, e.stars]))
	};
}
var Tn = {
	meta: Le,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ke,
		publicView: Fe,
		privateView: Ie,
		config: Te
	},
	setup: sn,
	reduce: xn,
	viewFor: Cn,
	status: wn
}, En = "games/critterkitchen/", Dn = {
	soup: "soup",
	garden: "garden",
	desert: "desert",
	water: "water",
	air: "air",
	lantern: "lantern",
	midnight: "night",
	academy: "academy"
};
function On({ location: e }) {
	return /* @__PURE__ */ g("img", {
		className: "ck-stall-art",
		src: `${En}stall-${Dn[e]}.webp`,
		width: 720,
		height: 295,
		alt: "",
		draggable: !1
	});
}
function kn({ card: e }) {
	return e < 0 || e > 6 ? null : /* @__PURE__ */ g("img", {
		className: "ck-dish-art",
		src: `${En}dish-${e}.webp`,
		width: 520,
		height: 197,
		alt: "",
		draggable: !1
	});
}
function An({ food: e, className: t }) {
	return /* @__PURE__ */ g("img", {
		className: t ?? "ck-food-art",
		src: `${En}food-${e}.webp`,
		width: 96,
		height: 76,
		alt: "",
		draggable: !1
	});
}
function jn({ item: e }) {
	return e.kind === "ingredient" || e.kind === "organic" || e.kind === "zousing" ? e.t && e.t !== "allspice" ? /* @__PURE__ */ g(An, { food: e.t }) : null : /* @__PURE__ */ g(An, { food: e.kind });
}
var Mn = {
	basket: "M3 10h18l-3 10H6zM8 10l4-7 4 7m-6 4v3m4-3v3",
	hat: "M6 15a4 4 0 1 1 1-8 5 5 0 0 1 10 0 4 4 0 1 1 1 8l-1 5H7zM7 17h10",
	star: "M12 2.4l2.8 5.8 6.4 1-4.6 4.5 1.2 6.3-5.8-3-5.8 3 1.2-6.3L3 9.2l6.2-1z",
	plate: "M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20zm0 4a6 6 0 1 1 0 12 6 6 0 0 1 0-12z",
	cart: "M2 4h3l3 11h10l3-8H6m3 12h.1m8 0h.1"
};
function J({ kind: e }) {
	return /* @__PURE__ */ g("svg", {
		className: `ck-icon ck-icon--${e}`,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ g("path", {
			d: Mn[e],
			fill: e === "star" ? "currentColor" : "none",
			stroke: "currentColor",
			strokeWidth: "1.65",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function Nn() {
	return /* @__PURE__ */ g("svg", {
		className: "ck-target-outline",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ g("rect", {
			pathLength: "100",
			rx: "10"
		})
	});
}
//#endregion
//#region src/game/market-motion.ts
function Pn(e) {
	let t = e?.closest(".ck-screen");
	if (!e || !t || e.ownerDocument.defaultView?.matchMedia("(prefers-reduced-motion: reduce)").matches) return null;
	let n = e.cloneNode(!0);
	return n.inert = !0, n.setAttribute("aria-hidden", "true"), n.classList.remove("is-selected"), n.classList.add("ck-flying-piece"), {
		piece: n,
		from: e.getBoundingClientRect(),
		screen: t
	};
}
function Fn(e, t, n) {
	let { piece: r, from: i, screen: a } = e, o = t.getBoundingClientRect();
	if (!a.isConnected || !i.width || !o.width) return;
	let s = o.x + (o.width - i.width) / 2 - i.x, c = o.y + (o.height - i.height) / 2 - i.y, l = Math.min(1, Math.max(.5, o.width / i.width)), u = Math.min(75, 18 + Math.hypot(s, c) * .13);
	Object.assign(r.style, {
		left: "0",
		top: "0",
		width: `${i.width}px`,
		height: `${i.height}px`
	}), a.append(r);
	let d = r.getBoundingClientRect();
	r.style.left = `${i.x - d.x}px`, r.style.top = `${i.y - d.y}px`, r.animate([
		{
			transform: "translate(0, 0) scale(1)",
			opacity: 1,
			offset: 0
		},
		{
			transform: `translate(${s * .55}px, ${c * .55 - u}px) scale(1.04)`,
			opacity: 1,
			offset: .55
		},
		{
			transform: `translate(${s}px, ${c}px) scale(${l})`,
			opacity: .9,
			offset: .92
		},
		{
			transform: `translate(${s}px, ${c}px) scale(${l})`,
			opacity: 0,
			offset: 1
		}
	], {
		duration: n,
		easing: "cubic-bezier(.22,.63,.34,1)"
	}).finished.then(() => {
		r.remove(), t.isConnected && t.animate([{ filter: "brightness(1.16)" }, { filter: "none" }], { duration: 150 });
	}, () => r.remove());
}
//#endregion
//#region src/game/view-player.tsx
var Y = (e) => e, In = {
	items: [],
	soup: 0,
	bisque: 0,
	rumorCards: [
		null,
		null,
		null
	],
	known: [
		!1,
		!1,
		!1
	],
	hiddenRumor: null,
	zousReady: [],
	restaurateur: null,
	offers: [],
	canAct: !1,
	planReady: !1,
	mealReady: !1,
	fridgeReady: !1,
	fridgeLimit: 5,
	criticReady: !1,
	shop: null,
	lastMeals: [],
	lastCritic: null
};
function Ln(e) {
	let t = e.public;
	return /* @__PURE__ */ g(Rn, {
		pub: t,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Rn({ pub: e, priv: t, members: u, myRid: p, send: h }) {
	let v = s(), y = o((e) => e.locale), b = t ?? In, x = e.players.find((e) => e.rid === p), C = (e) => {
		let t = u.find((t) => t.rid === e);
		return t ? m(t, y) : v("games.critterkitchen.finalUnnamed");
	}, [w, T] = i(null), [E, D] = i(null), [O, ee] = i(null), [te, k] = i(!1), [ne, A] = i(!1), [re, ae] = i(!1), [oe, j] = i(null), [se, ce] = i(null), [le, ue] = i(null), [de, fe] = i(null), [pe, he] = i(p), M = r(null), ge = r(/* @__PURE__ */ new Map());
	pe !== p && (he(p), T(null), D(null), ee(null), k(!1), A(!1), ae(!1), j(null), ce(null), ue(null), fe(null));
	let N = oe && oe.round === e.round ? oe : null, P = se && se.round === e.round ? se.meals : [], F = de && de.round === e.round ? de.courses : {}, I = de && de.round === e.round ? de.extra : null, L = le && le.round === e.round ? le.keep : null, R = e.phase === "shop" && e.shop?.activeRid === p, z = b.canAct, _e = e.critic === 12 && e.extraChallenge !== null, B = e.round <= 3 ? 0 : e.round <= 6 ? 3 : 6, ve = e.round <= 6 ? e.challenges.slice(B, B + 3).filter((e) => e >= 0) : [], V = e.players.filter((e) => !e.ready).map((e) => C(e.rid)).join(", "), H = x?.rumorSlots ?? [
		!1,
		!1,
		!1
	], ye = {
		rid: p,
		critic: e.critic,
		held: e.held,
		items: b.items,
		soup: b.soup,
		bisque: b.bisque,
		rumorSlots: H,
		restaurateur: b.restaurateur
	}, be = (e) => {
		let t = P.filter((t) => t.challenge !== e);
		return {
			...ye,
			soup: Math.max(0, b.soup - t.reduce((e, t) => e + t.soup, 0)),
			bisque: Math.max(0, b.bisque - t.reduce((e, t) => e + t.bisque, 0))
		};
	}, xe = e.critic === 11 ? 3 : 2;
	n(() => {
		let e = ge.current, t = M.current?.closest(".ck-screen");
		return () => {
			e.clear(), t?.querySelectorAll(".ck-flying-piece").forEach((e) => e.remove());
		};
	}, [p]), n(() => {
		let t = ge.current;
		if (!t.size) return;
		let n = e.events.map((e) => JSON.stringify(e)), r = /* @__PURE__ */ new Set();
		for (let [i, a] of t) {
			if (performance.now() - a.time > 2200) {
				t.delete(i);
				continue;
			}
			let o = gr(a.events, n), s = e.events.findIndex((e, t) => t >= o && !r.has(t) && e.k === "pick" && e.rid === p && e.loc === a.loc && e.t === a.tag);
			if (s < 0) {
				t.set(i, {
					...a,
					events: n
				});
				continue;
			}
			r.add(s), t.delete(i);
			let c = Array.from(a.travel.screen.querySelectorAll(".ck-kitchen-target")).find((e) => e.getClientRects().length)?.querySelector(".ck-purchase-basket");
			c && Fn(a.travel, c, 440);
		}
		e.phase !== "shop" && t.clear();
	}, [
		p,
		e.events,
		e.phase
	]);
	function Se(t, n) {
		let r = fr(e, N, t);
		if (r !== N && r.sel === null && N?.sel) {
			let e = n.closest(".ck-loc"), t = e?.closest(".ck-screen")?.querySelector(".ck-figure.is-selected"), r = Pn(t ?? null);
			r && requestAnimationFrame(() => {
				let t = e?.querySelector(".ck-marker");
				t && Fn(r, t, 380);
			});
		}
		j(r);
	}
	let Ce = (e.phase === "rest" || e.phase === "plan" || e.phase === "challenge" || e.phase === "fridge" || e.phase === "critic") && z || R ? "accent" : e.phase === "done" ? "done" : "info", we = Xn(v, e, b, R, C, V), U = b.items.filter((t) => rr(e.critic, t)), W = Math.min(x?.flowers ?? 0, b.fridgeLimit), Te = Math.max(0, b.fridgeLimit - W), Ee = [...U].sort((e, t) => (t.v ?? 0) - (e.v ?? 0)).slice(0, Te).map((e) => e.id), G = L ?? Ee, De = e.shop ? or(e, p) : [], Oe = R && (b.shop?.canPick ?? !1), ke = re && (b.shop?.canExtra ?? !1), K = e.shop ? e.locations.find((t) => t.id === e.shop.loc)?.cart : null, Ae = K?.kind === "gift" ? K.gifts : [], je = P.filter((e) => e.challenge !== E?.challenge), Me = /* @__PURE__ */ new Set();
	if (E) for (let e of je) for (let t of e.items) Me.add(t.id), t.spice !== void 0 && Me.add(t.spice);
	let Ne = /* @__PURE__ */ new Set();
	if (E?.extra) for (let e of Object.values(F)) for (let t of e.items) Ne.add(t.id), t.spice !== void 0 && Ne.add(t.spice);
	let Pe = (t) => {
		let n = P.findIndex((e) => e.challenge === t.challenge), r = n >= 0 ? P.map((e, r) => r === n ? t : e) : [...P, t];
		ce({
			round: e.round,
			meals: r
		}), D(null);
	}, Fe = (t) => {
		ce({
			round: e.round,
			meals: P.filter((e) => e.challenge !== t)
		});
	}, Ie = (t, n) => {
		let r = { ...F };
		n.items.length === 0 ? delete r[t] : r[t] = n, fe({
			round: e.round,
			courses: r,
			extra: I
		}), ee(null);
	}, Re = (t) => {
		fe({
			round: e.round,
			courses: F,
			extra: t
		}), D(null);
	}, ze = /* @__PURE__ */ new Set();
	if (O) {
		for (let [e, t] of Object.entries(F)) if (e !== O) for (let e of t.items) ze.add(e.id), e.spice !== void 0 && ze.add(e.spice);
		if (I) for (let e of I.items) ze.add(e.id), e.spice !== void 0 && ze.add(e.spice);
	}
	let Be = w ? /* @__PURE__ */ g(Jn, {
		t: v,
		detail: w,
		held: w.kind === "challenge" && e.held.includes(w.id),
		onClose: () => T(null)
	}) : null, Ve = (() => {
		if (e.phase === "rest") return /* @__PURE__ */ g(X, { text: z ? v("games.critterkitchen.restHint") : v("games.critterkitchen.restWaiting", { name: V }) });
		if (e.phase === "plan") return z ? /* @__PURE__ */ g(Bn, {
			pub: e,
			priv: b,
			plan: N,
			onPlan: j,
			onClear: () => j(null),
			onSubmit: (t) => h(ur(e, b, t))
		}) : /* @__PURE__ */ g(X, { text: v("games.critterkitchen.planWaiting", { name: V }) });
		if (e.phase === "shop") {
			if (!e.shop) return /* @__PURE__ */ g(X, { text: v("games.critterkitchen.shopWaiting") });
			if (e.shop.pendingCoffee) return R ? /* @__PURE__ */ _("div", {
				className: "ck-actions",
				children: [/* @__PURE__ */ g("span", {
					className: "ck-actions__hint",
					children: v("games.critterkitchen.shopCoffeeHint")
				}), /* @__PURE__ */ g("div", {
					className: "ck-actions__wrap",
					children: De.map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn",
						onClick: () => h({
							type: "coffee",
							loc: e
						}),
						children: Q(v, e)
					}, e))
				})]
			}) : /* @__PURE__ */ g(X, { text: v("games.critterkitchen.shopWaiting") });
			if (!R) return /* @__PURE__ */ g(X, { text: v("games.critterkitchen.shopActiveAt", {
				name: C(e.shop.activeRid),
				loc: Q(v, e.shop.loc)
			}) });
			let t = b.shop;
			return /* @__PURE__ */ _("div", {
				className: "ck-actions",
				children: [/* @__PURE__ */ g("span", {
					className: "ck-actions__hint",
					children: v("games.critterkitchen.shopCap", {
						n: e.shop.picks,
						cap: e.shop.cap
					})
				}), /* @__PURE__ */ _("div", {
					className: "ck-actions__wrap",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							disabled: !t?.canLeave,
							title: v("games.critterkitchen.shopLeaveHint"),
							onClick: () => h({ type: "leave" }),
							children: v("games.critterkitchen.shopLeave")
						}),
						t?.canGift && Ae.length > 0 && /* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							onClick: () => k(!0),
							children: v("games.critterkitchen.shopGiftTitle")
						}),
						t?.canCoin && /* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							onClick: () => h({ type: "coin" }),
							title: v("games.critterkitchen.shopCoinHint"),
							children: v("games.critterkitchen.shopCoinUse")
						}),
						e.shop.extraAvailable && /* @__PURE__ */ g("button", {
							type: "button",
							className: `ck-btn${ke ? " is-on" : ""}`,
							"aria-pressed": ke,
							onClick: () => ae(!ke),
							children: v("games.critterkitchen.shopExtra")
						})
					]
				})]
			});
		}
		return e.phase === "challenge" ? b.mealReady ? /* @__PURE__ */ g(X, { text: v("games.critterkitchen.challengeWaiting", { name: V }) }) : /* @__PURE__ */ _("div", {
			className: "ck-actions",
			children: [/* @__PURE__ */ g("span", {
				className: "ck-actions__hint",
				children: v("games.critterkitchen.challengeHint")
			}), /* @__PURE__ */ g("button", {
				type: "button",
				className: "ck-btn ck-btn--primary",
				disabled: !z,
				onClick: () => h({
					type: "meals",
					meals: P
				}),
				children: v("games.critterkitchen.challengeSubmit")
			})]
		}) : e.phase === "fridge" ? b.fridgeReady ? /* @__PURE__ */ g(X, { text: v("games.critterkitchen.fridgeWaiting", { name: V }) }) : /* @__PURE__ */ _("div", {
			className: "ck-actions",
			children: [/* @__PURE__ */ g("span", {
				className: "ck-actions__hint",
				children: v("games.critterkitchen.fridgeCount", {
					n: G.length + W,
					limit: b.fridgeLimit
				})
			}), /* @__PURE__ */ g("button", {
				type: "button",
				className: "ck-btn ck-btn--primary",
				disabled: !z || G.length + W > b.fridgeLimit,
				onClick: () => h({
					type: "fridge",
					keep: G
				}),
				children: v("games.critterkitchen.fridgeSubmit")
			})]
		}) : e.phase === "critic" ? b.criticReady ? /* @__PURE__ */ g(X, { text: v("games.critterkitchen.criticWaiting", { name: V }) }) : /* @__PURE__ */ _("div", {
			className: "ck-actions",
			children: [/* @__PURE__ */ g("span", {
				className: "ck-actions__hint",
				children: v("games.critterkitchen.criticHint")
			}), /* @__PURE__ */ g("button", {
				type: "button",
				className: "ck-btn ck-btn--primary",
				disabled: !z,
				onClick: () => h({
					type: "critic",
					courses: F,
					extra: I ?? void 0
				}),
				children: v("games.critterkitchen.criticSubmit")
			})]
		}) : /* @__PURE__ */ g(X, { text: we.sub ?? we.text });
	})(), He = () => A(!0), Ue = e.phase === "plan" || e.phase === "shop", We = (e) => /* @__PURE__ */ _("button", {
		type: "button",
		className: `ck-kitchen-target ck-kitchen-target--${e}`,
		onClick: He,
		children: [
			/* @__PURE__ */ g("span", {
				className: "ck-purchase-basket",
				children: /* @__PURE__ */ g(J, { kind: "basket" })
			}),
			/* @__PURE__ */ g("b", { children: v("games.critterkitchen.kitchenTitle") }),
			/* @__PURE__ */ g("span", { children: v("games.critterkitchen.itemCount", { n: b.items.length }) })
		]
	});
	return /* @__PURE__ */ _(c, {
		adaptive: !0,
		className: "ck-screen",
		actionsHeight: "ck-action-slot",
		actions: /* @__PURE__ */ _("div", {
			className: "ck-counter",
			children: [We("rail"), Ve]
		}),
		banner: /* @__PURE__ */ _("div", {
			className: "ck-banner",
			children: [
				/* @__PURE__ */ _("div", {
					className: "ck-masthead",
					children: [/* @__PURE__ */ _("div", {
						className: "ck-brand",
						children: [/* @__PURE__ */ g(J, { kind: "basket" }), /* @__PURE__ */ g("b", { children: v("games.critterkitchen.name") })]
					}), /* @__PURE__ */ g(d, {
						tone: Ce,
						text: we.text,
						chip: we.chip,
						accent: Le.accent
					})]
				}),
				/* @__PURE__ */ g(f, {
					adaptive: !0,
					variant: "plate",
					members: u,
					myRid: p,
					picked: (e) => e === p,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						if (!n) return null;
						let r = e.priority.indexOf(t);
						return /* @__PURE__ */ _("span", {
							className: "ck-pstatus",
							"data-current-seat": t === p || void 0,
							children: [
								/* @__PURE__ */ g("b", { children: v("games.critterkitchen.starsCount", { n: n.stars }) }),
								r >= 0 && /* @__PURE__ */ _("small", { children: ["#", r + 1] }),
								/* @__PURE__ */ g("span", {
									className: "ck-slotdots",
									"aria-hidden": !0,
									children: n.rumorSlots.map((e, t) => /* @__PURE__ */ g("i", { className: e ? "is-on" : "" }, t))
								})
							]
						});
					},
					action: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? e.phase === "shop" ? e.shop?.activeRid === t ? "pending" : null : e.phase === "rest" || e.phase === "plan" || e.phase === "challenge" || e.phase === "fridge" || e.phase === "critic" ? n.ready ? "done" : "pending" : null : null;
					}
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-resbar",
					children: [
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.soupLabel"),
							value: b.soup
						}),
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.bisqueLabel"),
							value: b.bisque
						}),
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.coinLabel"),
							value: x?.coins ?? 0
						}),
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.coffeeLabel"),
							value: x?.coffee ?? 0
						}),
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.flowersLabel"),
							value: x?.flowers ?? 0
						}),
						/* @__PURE__ */ g(zn, {
							label: v("games.critterkitchen.trophyLabel"),
							value: x?.trophies.length ?? 0
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-res ck-res--btn",
							onClick: () => T({
								kind: "rest",
								id: b.restaurateur ?? -1
							}),
							disabled: b.restaurateur === null,
							children: b.restaurateur === null ? v("games.critterkitchen.restaurateurLabel") : Cr(v, b.restaurateur)
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-res ck-res--btn",
							onClick: () => T({
								kind: "critic",
								id: e.critic
							}),
							children: v("games.critterkitchen.criticLabel")
						}),
						!Ue && ve.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-res ck-res--btn",
							onClick: () => T({
								kind: "challenge",
								id: e
							}),
							children: xr(v, e)
						}, e))
					]
				})
			]
		}),
		children: [
			/* @__PURE__ */ _("div", {
				className: "ck-view",
				ref: M,
				children: [
					!Ue && e.events.length > 0 && /* @__PURE__ */ g(l, {
						log: e.events,
						line: (e) => Zn(v, e, C)
					}),
					e.phase === "rest" && /* @__PURE__ */ g("section", {
						className: "ck-phase",
						children: /* @__PURE__ */ _("div", {
							className: "ck-cards2",
							children: [b.offers.map((e) => {
								let t = b.restaurateur === e;
								return /* @__PURE__ */ _("button", {
									type: "button",
									className: `ck-card ck-card--rest${t ? " is-picked" : ""}`,
									disabled: !z,
									onClick: () => h({
										type: "restPick",
										id: e
									}),
									children: [
										/* @__PURE__ */ g("span", {
											className: "ck-card__seal",
											children: /* @__PURE__ */ g(J, { kind: "hat" })
										}),
										/* @__PURE__ */ _("header", {
											className: "ck-card__head",
											children: [/* @__PURE__ */ g("b", { children: Cr(v, e) }), /* @__PURE__ */ g("span", { children: v("games.critterkitchen.restStars", { n: me[e] ?? 0 }) })]
										}),
										/* @__PURE__ */ g("p", {
											className: "ck-card__body",
											children: v(Y(ie[e]))
										})
									]
								}, e);
							}), b.offers.length === 0 && /* @__PURE__ */ g("p", {
								className: "ck-empty",
								children: b.restaurateur === null ? v("games.critterkitchen.waitingFor", { name: V }) : v("games.critterkitchen.restChosen", { name: Cr(v, b.restaurateur) })
							})]
						})
					}),
					Ue && /* @__PURE__ */ _("div", {
						className: "ck-market",
						children: [/* @__PURE__ */ _("aside", {
							className: "ck-market-side",
							children: [
								ve.length > 0 && /* @__PURE__ */ g("div", {
									className: "ck-daily",
									children: ve.map((t) => /* @__PURE__ */ g("button", {
										type: "button",
										className: "ck-daily__card",
										onClick: () => T({
											kind: "challenge",
											id: t
										}),
										children: /* @__PURE__ */ g(Un, {
											t: v,
											cid: t,
											held: e.held.includes(t)
										})
									}, t))
								}),
								/* @__PURE__ */ _("div", {
									className: "ck-market-kitchen",
									children: [We("counter"), /* @__PURE__ */ _("div", {
										className: "ck-kitchen-tray",
										children: [b.items.length === 0 && /* @__PURE__ */ g("span", {
											className: "ck-empty",
											children: v("games.critterkitchen.noItems")
										}), b.items.slice(-5).map((e) => /* @__PURE__ */ g($, {
											t: v,
											it: e,
											spiceMult: xe
										}, e.id))]
									})]
								}),
								/* @__PURE__ */ g("div", {
									className: "ck-market-log",
									children: /* @__PURE__ */ g(l, {
										log: e.events,
										line: (e) => Zn(v, e, C)
									})
								})
							]
						}), /* @__PURE__ */ g("div", {
							className: "ck-board",
							children: e.locations.map((t) => /* @__PURE__ */ g(Hn, {
								loc: t,
								mode: e.phase === "plan" ? "plan" : "shop",
								active: e.phase === "shop" && e.shop?.loc === t.id,
								myRid: p,
								members: u,
								nameOf: C,
								plan: e.phase === "plan" ? N : null,
								onPlanTap: e.phase === "plan" && z && N?.sel ? (e) => Se(t.id, e) : void 0,
								onPlanRemove: e.phase === "plan" && z ? (t) => j(mr(e, N, t)) : void 0,
								pickable: Oe && t.id === e.shop?.loc,
								extraOn: ke,
								actingRid: e.phase === "shop" ? e.shop?.activeRid ?? null : null,
								actingChef: e.phase === "shop" ? e.shop?.activeChef ?? null : null,
								actingZous: e.phase === "shop" ? e.shop?.activeZous ?? null : null,
								spiceMult: xe,
								canTake: (e) => ir(H, De, e),
								onItem: (n, r) => {
									if ([
										"ingredient",
										"organic",
										"zousing",
										"tofu",
										"spice",
										"soup",
										"bisque"
									].includes(n.kind)) {
										let i = Pn(r);
										i && ge.current.set(n.id, {
											travel: i,
											loc: t.id,
											time: performance.now(),
											tag: (n.kind === "ingredient" || n.kind === "spice") && n.t ? `${n.kind}:${n.t}` : n.kind,
											events: e.events.map((e) => JSON.stringify(e))
										});
									}
									let i = ar(n, H);
									ke ? (ae(!1), h({
										type: "extra",
										item: n.id,
										...i === void 0 ? {} : { slot: i }
									})) : h({
										type: "pick",
										item: n.id,
										...i === void 0 ? {} : { slot: i }
									});
								},
								giftBoxes: t.cart?.kind === "gift" ? t.cart.gifts : null,
								canGift: R && (b.shop?.canGift ?? !1),
								onGift: () => k(!0),
								onCart: (e) => T({
									kind: "cart",
									cart: e
								})
							}, t.id))
						})]
					}),
					e.phase === "challenge" && /* @__PURE__ */ _("section", {
						className: "ck-phase",
						children: [/* @__PURE__ */ _("div", {
							className: "ck-cards3",
							children: [ve.map((t) => /* @__PURE__ */ g(Wn, {
								cid: t,
								ctx: be(t),
								held: e.held.includes(t),
								meal: P.find((e) => e.challenge === t) ?? null,
								result: b.lastMeals.find((e) => e.challenge === t) ?? null,
								editable: z && !b.mealReady,
								limitReached: P.length >= (_e ? 4 : 3) && !P.some((e) => e.challenge === t),
								onOpen: () => D({
									challenge: t,
									extra: !1
								}),
								onRemove: () => Fe(t),
								onDetail: () => T({
									kind: "challenge",
									id: t
								})
							}, t)), _e && e.extraChallenge !== null && /* @__PURE__ */ g(Wn, {
								cid: e.extraChallenge,
								extra: !0,
								ctx: be(e.extraChallenge),
								held: !1,
								meal: P.find((t) => t.challenge === e.extraChallenge) ?? null,
								result: b.lastMeals.find((t) => t.challenge === e.extraChallenge) ?? null,
								editable: z && !b.mealReady,
								limitReached: P.length >= 4 && !P.some((t) => t.challenge === e.extraChallenge),
								onOpen: () => D({
									challenge: e.extraChallenge,
									extra: !0
								}),
								onRemove: () => Fe(e.extraChallenge),
								onDetail: () => T({
									kind: "challenge",
									id: e.extraChallenge
								})
							})]
						}), b.lastMeals.length > 0 && /* @__PURE__ */ g("ul", {
							className: "ck-results",
							children: b.lastMeals.map((e, t) => /* @__PURE__ */ _("li", { children: [
								C(e.rid),
								" · ",
								xr(v, e.challenge),
								" · ",
								v("games.critterkitchen.challengeQuality", { n: e.quality }),
								" ·",
								" ",
								v("games.critterkitchen.challengeStars", { n: e.stars })
							] }, t))
						})]
					}),
					e.phase === "fridge" && /* @__PURE__ */ _("section", {
						className: "ck-phase",
						children: [
							/* @__PURE__ */ g("p", {
								className: "ck-note",
								children: v("games.critterkitchen.fridgeHint", { n: b.fridgeLimit })
							}),
							U.length === 0 && !b.items.some((e) => e.kind === "organic") ? /* @__PURE__ */ g("p", {
								className: "ck-empty",
								children: v("games.critterkitchen.fridgeEmpty")
							}) : /* @__PURE__ */ g("div", {
								className: "ck-items ck-items--fridge",
								children: U.map((t) => {
									let n = G.includes(t.id);
									return /* @__PURE__ */ g("button", {
										type: "button",
										className: `ck-token${n ? " is-on" : ""}`,
										disabled: !z,
										"aria-pressed": n,
										onClick: () => {
											let r = n ? G.filter((e) => e !== t.id) : [...G, t.id];
											ue({
												round: e.round,
												keep: r
											});
										},
										children: /* @__PURE__ */ g($, {
											t: v,
											it: t,
											spiceMult: xe
										})
									}, t.id);
								})
							}),
							b.items.some((e) => e.kind === "organic") && /* @__PURE__ */ g("p", {
								className: "ck-note",
								children: v("games.critterkitchen.fridgeOrganic")
							}),
							(x?.flowers ?? 0) > 0 && /* @__PURE__ */ g("p", {
								className: "ck-note",
								children: v("games.critterkitchen.fridgeFlowers")
							})
						]
					}),
					e.phase === "critic" && /* @__PURE__ */ _("section", {
						className: "ck-phase",
						children: [
							/* @__PURE__ */ g("div", {
								className: "ck-courses",
								children: S.map((e) => {
									let t = F[e], n = Jt(ye, F), r = "err" in n ? null : n.qualityByCourse[e];
									return /* @__PURE__ */ _("button", {
										type: "button",
										className: `ck-course${t ? " is-filled" : ""}`,
										disabled: !z || b.criticReady,
										onClick: () => ee(e),
										children: [
											/* @__PURE__ */ _("span", {
												className: "ck-course__type",
												children: [/* @__PURE__ */ g(An, { food: e }), Z(v, e)]
											}),
											/* @__PURE__ */ g("span", {
												className: "ck-course__picks",
												children: t && t.items.length > 0 ? t.items.map((e, t) => {
													let n = b.items.find((t) => t.id === e.id);
													return n ? /* @__PURE__ */ g($, {
														t: v,
														it: n,
														spiceMult: xe
													}, t) : null;
												}) : v("games.critterkitchen.criticEmpty")
											}),
											/* @__PURE__ */ g("span", {
												className: "ck-course__q",
												children: r === null ? v("games.critterkitchen.none") : v("games.critterkitchen.criticQuality", { n: r })
											})
										]
									}, e);
								})
							}),
							_e && e.extraChallenge !== null && /* @__PURE__ */ _("div", {
								className: "ck-extra",
								children: [/* @__PURE__ */ g("b", { children: v("games.critterkitchen.criticExtraTitle") }), /* @__PURE__ */ _("div", {
									className: "ck-extra__acts",
									children: [/* @__PURE__ */ g("button", {
										type: "button",
										className: `ck-btn${I ? " is-on" : ""}`,
										disabled: !z || b.criticReady,
										onClick: () => D({
											challenge: e.extraChallenge,
											extra: !0
										}),
										children: v("games.critterkitchen.criticExtraAdd")
									}), I && /* @__PURE__ */ g("button", {
										type: "button",
										className: "ck-btn",
										disabled: !z || b.criticReady,
										onClick: () => Re(null),
										children: v("games.critterkitchen.criticExtraNone")
									})]
								})]
							}),
							b.lastCritic && /* @__PURE__ */ g("ul", {
								className: "ck-results",
								children: S.map((e) => /* @__PURE__ */ _("li", { children: [
									Z(v, e),
									" · ",
									v("games.critterkitchen.criticQuality", { n: b.lastCritic[e] ?? 0 })
								] }, e))
							})
						]
					})
				]
			}),
			Be,
			E && /* @__PURE__ */ g(Gn, {
				t: v,
				ctx: ye,
				challenge: E.challenge,
				held: e.held.includes(E.challenge),
				initial: E.extra ? I : P.find((e) => e.challenge === E.challenge) ?? null,
				reserved: E.extra ? Ne : Me,
				soupLeft: Math.max(0, b.soup - je.reduce((e, t) => e + t.soup, 0)),
				bisqueLeft: Math.max(0, b.bisque - je.reduce((e, t) => e + t.bisque, 0)),
				onClose: () => D(null),
				onSave: (e) => E.extra ? Re(e) : Pe(e),
				extra: E.extra
			}),
			O && /* @__PURE__ */ g(Kn, {
				t: v,
				ctx: ye,
				type: O,
				courses: F,
				initial: F[O] ?? null,
				reserved: ze,
				onClose: () => ee(null),
				onSave: (e) => Ie(O, e)
			}),
			te && /* @__PURE__ */ g(qn, {
				t: v,
				boxes: Ae,
				cost: b.shop?.giftCost ?? 1,
				enabled: R && (b.shop?.canGift ?? !1),
				spiceMult: xe,
				onClose: () => k(!1),
				onTake: (e) => {
					h({
						type: "gift",
						box: e
					}), k(!1);
				}
			}),
			/* @__PURE__ */ g(a, {
				open: ne,
				onClose: () => A(!1),
				label: v("games.critterkitchen.kitchenTitle"),
				title: v("games.critterkitchen.kitchenTitle"),
				tall: !0,
				children: /* @__PURE__ */ g(Yn, {
					t: v,
					priv: b,
					pub: e
				})
			})
		]
	});
}
function X({ text: e }) {
	return /* @__PURE__ */ g("div", {
		className: "ck-actions ck-actions--single",
		children: /* @__PURE__ */ g("span", {
			className: "ck-actions__wait",
			children: e
		})
	});
}
function zn({ label: e, value: t }) {
	return /* @__PURE__ */ _("span", {
		className: "ck-res",
		children: [/* @__PURE__ */ g("span", { children: e }), /* @__PURE__ */ g("b", { children: t })]
	});
}
function Bn({ pub: e, priv: t, plan: n, onPlan: r, onClear: i, onSubmit: a }) {
	let o = s(), c = n ?? sr(e), l = cr(e, t, c);
	return /* @__PURE__ */ _("div", {
		className: "ck-actions ck-actions--plan",
		children: [
			/* @__PURE__ */ g(Vn, {
				pub: e,
				priv: t,
				draft: c,
				setPlan: r
			}),
			/* @__PURE__ */ g("span", {
				className: "ck-actions__hint",
				children: c.sel ? o("games.critterkitchen.planChooseMarket") : l ? null : lr(o, e, t, c)
			}),
			/* @__PURE__ */ _("div", {
				className: "ck-actions__wrap",
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: "ck-btn",
					onClick: i,
					children: o("games.critterkitchen.planClear")
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "ck-btn ck-btn--primary",
					disabled: !l,
					onClick: () => a(c),
					children: o("games.critterkitchen.planSubmit")
				})]
			})
		]
	});
}
function Vn({ pub: e, priv: t, draft: n, setPlan: r }) {
	let i = s(), a = n.sel, o = n.breakChef, c = [
		1,
		2,
		3
	];
	return /* @__PURE__ */ _("section", {
		className: "ck-plan",
		children: [/* @__PURE__ */ _("div", {
			className: "ck-tray",
			children: [c.map((e) => {
				let s = o === e, c = a?.kind === "chef" && a.chef === e, l = n.assign[e];
				return /* @__PURE__ */ _("button", {
					type: "button",
					className: `ck-figure${c ? " is-selected" : ""}${s ? " is-resting" : ""}`,
					"aria-pressed": c,
					disabled: !t.canAct || s,
					onClick: () => r({
						...n,
						sel: {
							kind: "chef",
							chef: e
						}
					}),
					children: [
						/* @__PURE__ */ g(J, { kind: "hat" }),
						/* @__PURE__ */ g("b", { children: br(i, e) }),
						/* @__PURE__ */ g("span", {
							className: "ck-dots",
							children: _r(e)
						}),
						l && /* @__PURE__ */ g("small", { children: Q(i, l) }),
						s && /* @__PURE__ */ g("small", { children: i("games.critterkitchen.planBreakTitle") })
					]
				}, e);
			}), t.zousReady.map((e) => {
				let o = a?.kind === "zous" && a.id === e, s = n.zous[e];
				return /* @__PURE__ */ _("button", {
					type: "button",
					className: `ck-figure ck-figure--zous${o ? " is-selected" : ""}`,
					"aria-pressed": o,
					disabled: !t.canAct,
					onClick: () => r({
						...n,
						sel: {
							kind: "zous",
							id: e
						}
					}),
					children: [
						/* @__PURE__ */ g(J, { kind: "hat" }),
						/* @__PURE__ */ g("b", { children: Tr(i, e) }),
						s && /* @__PURE__ */ g("small", { children: Q(i, s) })
					]
				}, e);
			})]
		}), e.breakRoll !== null && /* @__PURE__ */ _("div", {
			className: "ck-break",
			children: [/* @__PURE__ */ g("span", { children: i("games.critterkitchen.planBreakHint", { n: e.breakRoll }) }), /* @__PURE__ */ g("div", {
				className: "ck-break__pick",
				children: c.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					className: `ck-btn${o === e ? " is-on" : ""}`,
					disabled: !t.canAct,
					onClick: () => r(dr(n, e)),
					children: br(i, e)
				}, e))
			})]
		})]
	});
}
function Hn({ loc: e, mode: t, active: n, myRid: r, members: i, nameOf: a, plan: o, onPlanTap: c, onPlanRemove: l, pickable: u, extraOn: d, actingRid: f, actingChef: m, actingZous: v, spiceMult: y, canTake: b, onItem: x, giftBoxes: S, canGift: C, onGift: w, onCart: T }) {
	let E = s(), D = e.cart, O = [];
	if (o) {
		for (let t of [
			1,
			2,
			3
		]) o.assign[t] === e.id && O.push({
			kind: "chef",
			chef: t
		});
		for (let [t, n] of Object.entries(o.zous)) n === e.id && O.push({
			kind: "zous",
			id: Number(t)
		});
	}
	return /* @__PURE__ */ _("section", {
		className: `ck-loc${n ? " is-active" : ""}`,
		"data-loc": e.id,
		children: [
			/* @__PURE__ */ _("header", {
				className: "ck-loc__head",
				children: [
					/* @__PURE__ */ g(On, { location: e.id }),
					/* @__PURE__ */ g("h3", { children: Q(E, e.id) }),
					n && /* @__PURE__ */ g("span", {
						className: "ck-loc__active",
						children: E("games.critterkitchen.marketActive")
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "ck-items",
				children: [e.items.map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					className: `ck-token${u && b(e) ? " is-pickable" : ""}${d && u ? " is-extra" : ""}`,
					disabled: !u || !b(e),
					onClick: (t) => x(e, t.currentTarget),
					children: [/* @__PURE__ */ g($, {
						t: E,
						it: e,
						spiceMult: y
					}), u && b(e) && /* @__PURE__ */ g(Nn, {})]
				}, e.id)), e.items.length === 0 && !D && /* @__PURE__ */ g("span", {
					className: "ck-empty",
					children: E("games.critterkitchen.shopEmptyLoc")
				})]
			}),
			D && /* @__PURE__ */ _("div", {
				className: "ck-cart",
				"data-cart": D.kind,
				children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						className: "ck-cart__name",
						onClick: () => T(D.kind),
						children: [/* @__PURE__ */ g(J, { kind: "cart" }), Er(E, D.kind)]
					}),
					D.flowers > 0 && /* @__PURE__ */ _("span", {
						className: "ck-res",
						children: [/* @__PURE__ */ g("span", { children: E("games.critterkitchen.flowersLabel") }), /* @__PURE__ */ g("b", { children: D.flowers })]
					}),
					D.zous !== null && /* @__PURE__ */ g("span", {
						className: "ck-tag",
						children: Tr(E, D.zous)
					}),
					D.items.map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						className: `ck-token${u && b(e) ? " is-pickable" : ""}${d && u ? " is-extra" : ""}`,
						disabled: !u || !b(e),
						onClick: (t) => x(e, t.currentTarget),
						children: [/* @__PURE__ */ g($, {
							t: E,
							it: e,
							spiceMult: y
						}), u && b(e) && /* @__PURE__ */ g(Nn, {})]
					}, e.id)),
					S && S.length > 0 && /* @__PURE__ */ _("button", {
						type: "button",
						className: "ck-gift",
						disabled: !C,
						onClick: w,
						children: [
							E("games.critterkitchen.shopGiftTitle"),
							" · ",
							E("games.critterkitchen.itemCount", { n: S.length })
						]
					})
				]
			}),
			t === "plan" && /* @__PURE__ */ _("div", {
				className: "ck-loc__plan",
				children: [c && /* @__PURE__ */ g("button", {
					type: "button",
					className: "ck-loc__zone",
					"aria-label": Q(E, e.id),
					onClick: (e) => c(e.currentTarget),
					children: /* @__PURE__ */ g(Nn, {})
				}), O.length > 0 && /* @__PURE__ */ g("div", {
					className: "ck-loc__markers",
					children: O.map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						className: "ck-marker",
						disabled: !l,
						onClick: () => l?.(e),
						children: [/* @__PURE__ */ g(J, { kind: "hat" }), e.kind === "chef" ? /* @__PURE__ */ _(h, { children: [br(E, e.chef), /* @__PURE__ */ g("span", {
							className: "ck-dots",
							children: _r(e.chef)
						})] }) : Tr(E, e.id)]
					}, hr(e)))
				})]
			}),
			t === "shop" && e.chefs.length > 0 && /* @__PURE__ */ g("ul", {
				className: "ck-queue",
				children: e.chefs.map((e, t) => {
					let o = i.find((t) => t.rid === e.rid), s = n && e.rid === f && (e.chef === null ? e.zous !== null && e.zous === v : e.chef === m);
					return /* @__PURE__ */ _("li", {
						className: `ck-queue__item${s ? " is-acting" : ""}`,
						title: a(e.rid),
						children: [
							o && /* @__PURE__ */ g(p, {
								m: o,
								myRid: r,
								action: null,
								anchorName: null,
								box: "ck-avatar-box",
								img: "ck-avatar-img"
							}),
							/* @__PURE__ */ g("span", {
								className: "ck-queue__who",
								children: e.chef === null ? e.zous === null ? "" : Tr(E, e.zous) : br(E, e.chef)
							}),
							/* @__PURE__ */ g("span", {
								className: "ck-dots",
								children: _r(e.cap)
							})
						]
					}, t);
				})
			})
		]
	});
}
function Un({ t: e, cid: t, held: n }) {
	let r = D[t] ?? [];
	return /* @__PURE__ */ _("div", {
		className: "ck-challenge-face",
		children: [
			/* @__PURE__ */ g("div", {
				className: "ck-challenge-face__requirements",
				children: r.map((t, i) => /* @__PURE__ */ _("span", {
					className: "ck-requirement",
					"data-held": n && i === r.length - 1 || void 0,
					children: [/* @__PURE__ */ g(An, { food: t }), /* @__PURE__ */ g("span", { children: Z(e, t) })]
				}, t))
			}),
			/* @__PURE__ */ g("strong", {
				className: "ck-challenge-face__title",
				children: xr(e, t)
			}),
			n && /* @__PURE__ */ g("small", {
				className: "ck-challenge-face__held",
				children: e("games.critterkitchen.heldLabel")
			}),
			/* @__PURE__ */ g(kn, { card: t })
		]
	});
}
function Wn({ cid: e, held: t, extra: n, ctx: r, meal: i, result: a, editable: o, limitReached: c, onOpen: l, onRemove: u, onDetail: d }) {
	let f = s(), p = i ? qt(r, i) : null;
	return /* @__PURE__ */ _("article", {
		className: `ck-card ck-card--challenge${a ? " is-done" : ""}`,
		children: [
			/* @__PURE__ */ _("div", {
				className: "ck-card__picture",
				children: [/* @__PURE__ */ g(Un, {
					t: f,
					cid: e,
					held: t
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "ck-info",
					onClick: d,
					"aria-label": f("games.critterkitchen.tapForDetail"),
					children: "ⓘ"
				})]
			}),
			n && /* @__PURE__ */ g("span", {
				className: "ck-tag",
				children: f("games.critterkitchen.challengeExtra")
			}),
			/* @__PURE__ */ _("div", {
				className: "ck-card__foot",
				children: [a ? /* @__PURE__ */ _("span", { children: [
					f("games.critterkitchen.challengeQuality", { n: a.quality }),
					" · ",
					f("games.critterkitchen.challengeStars", { n: a.stars })
				] }) : p ? /* @__PURE__ */ g("span", {
					className: "err" in p ? "ck-muted" : void 0,
					children: "err" in p ? vr(f, p.err) : `${f("games.critterkitchen.challengeQuality", { n: p.quality })} · ${f("games.critterkitchen.challengeStars", { n: p.stars })}`
				}) : /* @__PURE__ */ g("span", {
					className: "ck-muted",
					children: f("games.critterkitchen.challengeMealEmpty")
				}), /* @__PURE__ */ _("span", {
					className: "ck-card__acts",
					children: [o && !a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn ck-btn--sm",
						disabled: c,
						onClick: l,
						children: f("games.critterkitchen.criticAdd")
					}), o && !a && i && /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn ck-btn--sm",
						onClick: u,
						children: f("games.critterkitchen.remove")
					})]
				})]
			})
		]
	});
}
function Gn({ t: e, ctx: t, challenge: n, held: r, initial: o, reserved: s, soupLeft: c, bisqueLeft: l, onClose: u, onSave: d, extra: f }) {
	let [p, m] = i(o?.items.map((e) => ({ ...e })) ?? []), [h, v] = i(o?.soup ?? 0), [y, b] = i(o?.bisque ?? 0), [x, S] = i(null), C = {
		...t,
		items: t.items.filter((e) => !s.has(e.id)),
		soup: c,
		bisque: l
	}, w = qt(C, {
		challenge: n,
		items: p,
		soup: h,
		bisque: y
	}), T = /* @__PURE__ */ new Set();
	for (let e of p) T.add(e.id), e.spice !== void 0 && T.add(e.spice);
	let E = C.items.filter((e) => !T.has(e.id) && $n(e, t.restaurateur)), O = C.items.filter((e) => !T.has(e.id) && er(e, t.critic)), ee = t.critic === 5 && t.rumorSlots.some(Boolean), te = t.critic === 11 ? 3 : 2, k = D[n] ?? [], ne = r ? k.slice(0, -1) : k, A = x === null ? null : p[x], re = A ? C.items.find((e) => e.id === A.id) : null, ie = re ? tr(re, O, ee, t.critic, t.restaurateur) : [];
	return /* @__PURE__ */ g(a, {
		open: !0,
		onClose: u,
		label: e("games.critterkitchen.challengeTitle"),
		title: xr(e, n),
		tall: !0,
		children: /* @__PURE__ */ _("div", {
			className: "ck-sheet",
			children: [
				/* @__PURE__ */ _("p", {
					className: "ck-note",
					children: [
						e("games.critterkitchen.challengeRequired", { types: ne.map((t) => Z(e, t)).join(" · ") }),
						r ? ` · ${e("games.critterkitchen.heldLabel")}` : "",
						f ? ` · ${e("games.critterkitchen.challengeExtra")}` : ""
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-meal",
					children: [p.map((n, r) => {
						let i = C.items.find((e) => e.id === n.id);
						if (!i) return null;
						let a = tr(i, O, ee, t.critic, t.restaurateur);
						return /* @__PURE__ */ _("div", {
							className: "ck-meal__row",
							children: [
								/* @__PURE__ */ g($, {
									t: e,
									it: i,
									spiceMult: te
								}),
								(a.length > 0 || n.spice !== void 0) && /* @__PURE__ */ g("button", {
									type: "button",
									className: "ck-btn ck-btn--sm",
									onClick: () => S(r),
									children: n.spice === void 0 ? e("games.critterkitchen.challengeAddSpice") : e("games.critterkitchen.challengePickSpice")
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "ck-btn ck-btn--sm",
									onClick: () => {
										m(p.filter((e, t) => t !== r)), S(null);
									},
									children: e("games.critterkitchen.remove")
								})
							]
						}, `${n.id}-${r}`);
					}), p.length === 0 && /* @__PURE__ */ g("p", {
						className: "ck-empty",
						children: e("games.critterkitchen.challengeMealEmpty")
					})]
				}),
				x !== null && re && /* @__PURE__ */ _("div", {
					className: "ck-spicepick",
					children: [/* @__PURE__ */ g("p", {
						className: "ck-note",
						children: e("games.critterkitchen.challengePickSpice")
					}), /* @__PURE__ */ _("div", {
						className: "ck-items",
						children: [
							/* @__PURE__ */ g("button", {
								type: "button",
								className: `ck-token${A?.spice === void 0 ? " is-on" : ""}`,
								onClick: () => {
									m(p.map((e, t) => t === x ? { id: e.id } : e)), S(null);
								},
								children: e("games.critterkitchen.challengeSpiceNone")
							}),
							ie.filter((e) => e >= 0).map((t) => {
								let n = C.items.find((e) => e.id === t);
								return n ? /* @__PURE__ */ g("button", {
									type: "button",
									className: `ck-token${A?.spice === t ? " is-on" : ""}`,
									onClick: () => {
										m(p.map((e, n) => n === x ? {
											id: e.id,
											spice: t
										} : e)), S(null);
									},
									children: /* @__PURE__ */ g($, {
										t: e,
										it: n,
										spiceMult: te
									})
								}, t) : null;
							}),
							ie.includes(-1) && /* @__PURE__ */ g("button", {
								type: "button",
								className: `ck-token${A?.spice === -1 ? " is-on" : ""}`,
								onClick: () => {
									m(p.map((e, t) => t === x ? {
										id: e.id,
										spice: -1
									} : e)), S(null);
								},
								children: e("games.critterkitchen.rumorLabel")
							})
						]
					})]
				}),
				/* @__PURE__ */ g("p", {
					className: "ck-note",
					children: e("games.critterkitchen.challengeAddItem")
				}),
				/* @__PURE__ */ g("div", {
					className: "ck-items",
					children: E.map((t) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-token",
						onClick: () => m([...p, { id: t.id }]),
						children: /* @__PURE__ */ g($, {
							t: e,
							it: t,
							spiceMult: te
						})
					}, t.id))
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-soups",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							disabled: h <= 0,
							onClick: () => v(Math.max(0, h - 1)),
							children: "−"
						}),
						/* @__PURE__ */ _("span", { children: [
							e("games.critterkitchen.challengeSoupUsed", { n: h }),
							" / ",
							c
						] }),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							disabled: h >= c,
							onClick: () => v(h + 1),
							children: "+"
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							disabled: y <= 0,
							onClick: () => b(Math.max(0, y - 1)),
							children: "−"
						}),
						/* @__PURE__ */ _("span", { children: [
							e("games.critterkitchen.challengeBisqueUsed", { n: y }),
							" / ",
							l
						] }),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							disabled: y >= l,
							onClick: () => b(y + 1),
							children: "+"
						})
					]
				}),
				/* @__PURE__ */ g("p", {
					className: `ck-preview${"err" in w ? " is-bad" : ""}`,
					children: "err" in w ? vr(e, w.err) : `${e("games.critterkitchen.challengeQuality", { n: w.quality })} · ${e("games.critterkitchen.challengeStars", { n: w.stars })}`
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-sheet__acts",
					children: [/* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn",
						onClick: u,
						children: e("games.critterkitchen.cancel")
					}), /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn ck-btn--primary",
						disabled: "err" in w,
						onClick: () => d({
							challenge: n,
							items: p,
							soup: h,
							bisque: y
						}),
						children: e("games.critterkitchen.confirm")
					})]
				})
			]
		})
	});
}
function Kn({ t: e, ctx: t, type: n, courses: r, initial: o, reserved: s, onClose: c, onSave: l }) {
	let [u, d] = i(o?.items.map((e) => ({ ...e })) ?? []), [f, p] = i(null), m = {
		...t,
		items: t.items.filter((e) => !s.has(e.id))
	}, h = { items: u }, v = Jt(m, {
		...r,
		[n]: h
	}), y = /* @__PURE__ */ new Set();
	for (let e of u) y.add(e.id), e.spice !== void 0 && y.add(e.spice);
	let b = m.items.filter((e) => !y.has(e.id) && nr(e, n, t.critic, t.restaurateur)), x = m.items.filter((e) => !y.has(e.id) && er(e, t.critic)), S = t.critic === 5 && t.rumorSlots.some(Boolean), C = t.critic === 11 ? 3 : 2, w = f === null ? null : u[f], T = w ? m.items.find((e) => e.id === w.id) : null, E = T ? tr(T, x, S, t.critic, t.restaurateur) : [], D = "err" in v ? null : v.qualityByCourse[n];
	return /* @__PURE__ */ g(a, {
		open: !0,
		onClose: c,
		label: e("games.critterkitchen.criticTitle"),
		title: Z(e, n),
		tall: !0,
		children: /* @__PURE__ */ _("div", {
			className: "ck-sheet",
			children: [
				/* @__PURE__ */ g("p", {
					className: "ck-note",
					children: e("games.critterkitchen.criticHint")
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-meal",
					children: [u.map((n, r) => {
						let i = m.items.find((e) => e.id === n.id);
						if (!i) return null;
						let a = tr(i, x, S, t.critic, t.restaurateur);
						return /* @__PURE__ */ _("div", {
							className: "ck-meal__row",
							children: [
								/* @__PURE__ */ g($, {
									t: e,
									it: i,
									spiceMult: C
								}),
								(a.length > 0 || n.spice !== void 0) && /* @__PURE__ */ g("button", {
									type: "button",
									className: "ck-btn ck-btn--sm",
									onClick: () => p(r),
									children: n.spice === void 0 ? e("games.critterkitchen.criticAddSpice") : e("games.critterkitchen.challengePickSpice")
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "ck-btn ck-btn--sm",
									onClick: () => {
										d(u.filter((e, t) => t !== r)), p(null);
									},
									children: e("games.critterkitchen.remove")
								})
							]
						}, `${n.id}-${r}`);
					}), u.length === 0 && /* @__PURE__ */ g("p", {
						className: "ck-empty",
						children: e("games.critterkitchen.criticEmpty")
					})]
				}),
				f !== null && T && /* @__PURE__ */ _("div", {
					className: "ck-spicepick",
					children: [/* @__PURE__ */ g("p", {
						className: "ck-note",
						children: e("games.critterkitchen.challengePickSpice")
					}), /* @__PURE__ */ _("div", {
						className: "ck-items",
						children: [
							/* @__PURE__ */ g("button", {
								type: "button",
								className: `ck-token${w?.spice === void 0 ? " is-on" : ""}`,
								onClick: () => {
									d(u.map((e, t) => t === f ? { id: e.id } : e)), p(null);
								},
								children: e("games.critterkitchen.criticSpiceNone")
							}),
							E.filter((e) => e >= 0).map((t) => {
								let n = m.items.find((e) => e.id === t);
								return n ? /* @__PURE__ */ g("button", {
									type: "button",
									className: `ck-token${w?.spice === t ? " is-on" : ""}`,
									onClick: () => {
										d(u.map((e, n) => n === f ? {
											id: e.id,
											spice: t
										} : e)), p(null);
									},
									children: /* @__PURE__ */ g($, {
										t: e,
										it: n,
										spiceMult: C
									})
								}, t) : null;
							}),
							E.includes(-1) && /* @__PURE__ */ g("button", {
								type: "button",
								className: `ck-token${w?.spice === -1 ? " is-on" : ""}`,
								onClick: () => {
									d(u.map((e, t) => t === f ? {
										id: e.id,
										spice: -1
									} : e)), p(null);
								},
								children: e("games.critterkitchen.rumorLabel")
							})
						]
					})]
				}),
				/* @__PURE__ */ g("p", {
					className: "ck-note",
					children: e("games.critterkitchen.criticAdd")
				}),
				/* @__PURE__ */ g("div", {
					className: "ck-items",
					children: b.map((t) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-token",
						onClick: () => d([...u, { id: t.id }]),
						children: /* @__PURE__ */ g($, {
							t: e,
							it: t,
							spiceMult: C
						})
					}, t.id))
				}),
				/* @__PURE__ */ g("p", {
					className: `ck-preview${"err" in v ? " is-bad" : ""}`,
					children: "err" in v ? vr(e, v.err) : `${e("games.critterkitchen.criticQualityLabel")} ${D ?? 0}`
				}),
				/* @__PURE__ */ _("div", {
					className: "ck-sheet__acts",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							onClick: c,
							children: e("games.critterkitchen.cancel")
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn",
							onClick: () => d([]),
							children: e("games.critterkitchen.criticRemove")
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "ck-btn ck-btn--primary",
							disabled: "err" in v,
							onClick: () => l(h),
							children: e("games.critterkitchen.confirm")
						})
					]
				})
			]
		})
	});
}
function qn({ t: e, boxes: t, cost: n, enabled: r, spiceMult: i, onClose: o, onTake: s }) {
	return /* @__PURE__ */ g(a, {
		open: !0,
		onClose: o,
		label: e("games.critterkitchen.shopGiftTitle"),
		title: e("games.critterkitchen.shopGiftTitle"),
		children: /* @__PURE__ */ _("div", {
			className: "ck-sheet",
			children: [/* @__PURE__ */ g("p", {
				className: "ck-note",
				children: e("games.critterkitchen.shopGiftCost")
			}), t.map((t, a) => /* @__PURE__ */ _("div", {
				className: "ck-meal",
				children: [/* @__PURE__ */ g("div", {
					className: "ck-items",
					children: t.map((t) => /* @__PURE__ */ g($, {
						t: e,
						it: t,
						spiceMult: i
					}, t.id))
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "ck-btn ck-btn--primary",
					disabled: !r || t.length === 0,
					onClick: () => s(a),
					children: e("games.critterkitchen.starsCount", { n })
				})]
			}, a))]
		})
	});
}
function Jn({ t: e, detail: t, held: n, onClose: r }) {
	let i = "", o = null;
	return t.kind === "cart" ? (i = Er(e, t.cart), o = /* @__PURE__ */ g("p", { children: e(Y(le[t.cart])) })) : t.kind === "critic" ? (i = Sr(e, t.id), o = /* @__PURE__ */ g("p", { children: e(Y(te[t.id] ?? te[0])) })) : t.kind === "rest" ? t.id < 0 ? i = e("games.critterkitchen.restaurateurLabel") : (i = Cr(e, t.id), o = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", { children: e(Y(ie[t.id])) }), /* @__PURE__ */ g("p", {
		className: "ck-note",
		children: e("games.critterkitchen.restStars", { n: me[t.id] ?? 0 })
	})] })) : t.kind === "challenge" ? (i = xr(e, t.id), o = /* @__PURE__ */ g(Un, {
		t: e,
		cid: t.id,
		held: n
	})) : t.kind === "rumor" ? (i = wr(e, t.id), o = /* @__PURE__ */ g("p", { children: e(Y(ne[t.id])) })) : t.kind === "zous" && (i = Tr(e, t.id), o = j[t.id] ? /* @__PURE__ */ g("p", { children: e(Y(j[t.id])) }) : null), /* @__PURE__ */ g(a, {
		open: !0,
		onClose: r,
		label: i,
		title: i,
		children: /* @__PURE__ */ g("div", {
			className: "ck-sheet ck-sheet--detail",
			children: o
		})
	});
}
function Yn({ t: e, priv: t, pub: n }) {
	let r = t.rumorCards.map((e, t) => ({
		id: e,
		i: t
	})).filter((e) => e.id !== null), i = n.critic === 11 ? 3 : 2;
	return /* @__PURE__ */ _("div", {
		className: "ck-sheet",
		children: [
			/* @__PURE__ */ _("div", {
				className: "ck-kitchen__grid",
				children: [/* @__PURE__ */ _("div", {
					className: "ck-res",
					children: [/* @__PURE__ */ g("span", { children: e("games.critterkitchen.soupLabel") }), /* @__PURE__ */ g("b", { children: t.soup })]
				}), /* @__PURE__ */ _("div", {
					className: "ck-res",
					children: [/* @__PURE__ */ g("span", { children: e("games.critterkitchen.bisqueLabel") }), /* @__PURE__ */ g("b", { children: t.bisque })]
				})]
			}),
			/* @__PURE__ */ g("p", {
				className: "ck-note",
				children: e("games.critterkitchen.itemCount", { n: t.items.length })
			}),
			/* @__PURE__ */ _("div", {
				className: "ck-items",
				children: [t.items.map((t) => /* @__PURE__ */ g($, {
					t: e,
					it: t,
					spiceMult: i
				}, t.id)), t.items.length === 0 && /* @__PURE__ */ g("span", {
					className: "ck-empty",
					children: e("games.critterkitchen.noItems")
				})]
			}),
			/* @__PURE__ */ g("h4", { children: e("games.critterkitchen.rumorLabel") }),
			r.length === 0 && /* @__PURE__ */ g("p", {
				className: "ck-empty",
				children: e("games.critterkitchen.none")
			}),
			r.map(({ id: t, i: n }) => /* @__PURE__ */ _("div", {
				className: "ck-detail",
				children: [/* @__PURE__ */ _("b", { children: [
					n + 1,
					" · ",
					wr(e, t)
				] }), /* @__PURE__ */ g("p", { children: e(Y(ne[t])) })]
			}, n)),
			t.hiddenRumor !== null && /* @__PURE__ */ _("div", {
				className: "ck-detail",
				children: [/* @__PURE__ */ g("b", { children: wr(e, t.hiddenRumor) }), /* @__PURE__ */ g("p", { children: e(Y(ne[t.hiddenRumor])) })]
			}),
			t.zousReady.length > 0 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("h4", { children: e("games.critterkitchen.zousLabel") }), t.zousReady.map((t) => /* @__PURE__ */ _("div", {
				className: "ck-detail",
				children: [/* @__PURE__ */ g("b", { children: Tr(e, t) }), j[t] && /* @__PURE__ */ g("p", { children: e(Y(j[t])) })]
			}, t))] }),
			n.critic >= 0 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("h4", { children: e("games.critterkitchen.criticLabel") }), /* @__PURE__ */ _("div", {
				className: "ck-detail",
				children: [/* @__PURE__ */ g("b", { children: Sr(e, n.critic) }), /* @__PURE__ */ g("p", { children: e(Y(te[n.critic])) })]
			})] })
		]
	});
}
function Xn(e, t, n, r, i, a) {
	let o = /* @__PURE__ */ _(h, { children: [
		e("games.critterkitchen.round", { n: t.round }),
		" · ",
		e("games.critterkitchen.day", { n: t.day })
	] });
	switch (t.phase) {
		case "rest": return n.canAct ? {
			text: e("games.critterkitchen.phaseRest"),
			chip: o
		} : {
			text: e("games.critterkitchen.restWaiting", { name: a }),
			sub: n.restaurateur === null ? void 0 : e("games.critterkitchen.restChosen", { name: Cr(e, n.restaurateur) }),
			chip: o
		};
		case "plan": return n.planReady ? {
			text: e("games.critterkitchen.planWaiting", { name: a }),
			chip: o
		} : {
			text: e("games.critterkitchen.phasePlan"),
			sub: e("games.critterkitchen.planHint"),
			chip: o
		};
		case "shop": return t.shop ? t.shop.pendingCoffee && r ? {
			text: e("games.critterkitchen.shopPendingCoffee"),
			chip: o
		} : r ? {
			text: e("games.critterkitchen.shopYouTurn"),
			sub: e("games.critterkitchen.shopPickHint"),
			chip: o
		} : {
			text: e("games.critterkitchen.shopActiveAt", {
				name: i(t.shop.activeRid),
				loc: Q(e, t.shop.loc)
			}),
			chip: o
		} : {
			text: e("games.critterkitchen.shopWaiting"),
			chip: o
		};
		case "challenge": return n.mealReady ? {
			text: e("games.critterkitchen.challengeWaiting", { name: a }),
			chip: o
		} : {
			text: e("games.critterkitchen.phaseChallenge"),
			sub: e("games.critterkitchen.challengeHint"),
			chip: o
		};
		case "fridge": return n.fridgeReady ? {
			text: e("games.critterkitchen.fridgeWaiting", { name: a }),
			chip: o
		} : {
			text: e("games.critterkitchen.phaseFridge"),
			sub: e("games.critterkitchen.fridgeHint", { n: n.fridgeLimit }),
			chip: o
		};
		case "critic": return n.criticReady ? {
			text: e("games.critterkitchen.criticWaiting", { name: a }),
			chip: o
		} : {
			text: e("games.critterkitchen.phaseCritic"),
			sub: e("games.critterkitchen.criticHint"),
			chip: o
		};
		default: return {
			text: e("games.critterkitchen.phaseDone"),
			chip: o
		};
	}
}
function Zn(e, t, n) {
	let r = t.rid ? n(t.rid) : "";
	switch (t.k) {
		case "round": return e("games.critterkitchen.logRound", { n: t.n ?? 0 });
		case "rest": return e("games.critterkitchen.logRest", {
			name: r,
			card: Cr(e, Number(t.t ?? 0))
		});
		case "plan": return e("games.critterkitchen.logPlan", { name: r });
		case "pick": return u(e, "games.critterkitchen.logPick", [
			["name", r],
			["loc", t.loc ? Q(e, t.loc) : ""],
			["item", Qn(e, t.t ?? "")]
		]);
		case "rumor": return e("games.critterkitchen.logRumor", { name: r });
		case "soup": return e("games.critterkitchen.logSoup", {
			name: r,
			n: t.n ?? 0
		});
		case "leave": return e("games.critterkitchen.logLeave", {
			name: r,
			loc: t.loc ? Q(e, t.loc) : ""
		});
		case "gift": return e("games.critterkitchen.logGift", { name: r });
		case "coin": return e("games.critterkitchen.logCoin", { name: r });
		case "coffee": return e("games.critterkitchen.logCoffee", { name: r });
		case "zous": return e("games.critterkitchen.logZous", { name: r });
		case "challenge": return e("games.critterkitchen.logChallenge", {
			name: r,
			card: xr(e, Number(t.t ?? 0)),
			q: t.q ?? 0,
			n: t.n ?? 0
		});
		case "fridge": return e("games.critterkitchen.logFridge", { name: r });
		case "critic": return e("games.critterkitchen.logCritic", { name: r });
		case "star": return e("games.critterkitchen.logStar", {
			name: r,
			n: t.n ?? 0
		});
		default: return e("games.critterkitchen.logFinal");
	}
}
function Qn(e, t) {
	let [n, r] = t.split(":");
	if (n === "zous") return Tr(e, Number(r));
	if (n === "ingredient" || n === "trophy") return r ? Z(e, r) : e("games.critterkitchen.ingredientLabel");
	if (n === "spice") return r === "allspice" ? e("games.critterkitchen.allspiceLabel") : r ? e("games.critterkitchen.itemSpice", { type: Z(e, r) }) : e("games.critterkitchen.spiceLabel");
	switch (n) {
		case "soup": return e("games.critterkitchen.soupLabel");
		case "bisque": return e("games.critterkitchen.bisqueLabel");
		case "coffee": return e("games.critterkitchen.coffeeLabel");
		case "flowers": return e("games.critterkitchen.flowersLabel");
		case "coin": return e("games.critterkitchen.coinLabel");
		case "mystery": return e("games.critterkitchen.itemMystery");
		case "organic": return e("games.critterkitchen.itemOrganic");
		case "tofu": return e("games.critterkitchen.itemTofu");
		case "zousing": return e("games.critterkitchen.itemZousIng");
		case "rumor": return e("games.critterkitchen.rumorLabel");
		default: return t;
	}
}
function $n(e, t) {
	return e.kind === "ingredient" || e.kind === "organic" || e.kind === "tofu" || e.kind === "zousing" || e.kind === "spice" && t === 12;
}
function er(e, t) {
	return e.kind === "spice" || t === 10 && e.kind === "ingredient" && e.t === "wine";
}
function tr(e, t, n, r, i) {
	if (e.kind === "spice") return [];
	let a = e.t, o = [];
	for (let n of t) {
		if (n.id === e.id) continue;
		let t;
		if (n.kind === "spice") t = n.t === "allspice" ? null : n.t;
		else if (r === 10 && n.kind === "ingredient" && n.t === "wine") t = null;
		else continue;
		(t === null || e.kind === "tofu" || r === 1 && e.t === "mushroom" || i === 8 || a !== void 0 && a === t) && o.push(n.id);
	}
	return n && o.push(-1), o;
}
function nr(e, t, n, r) {
	return e.kind === "tofu" ? !0 : e.kind === "spice" ? r === 12 && (e.t === t || e.t === "allspice") : e.kind !== "ingredient" && e.kind !== "organic" && e.kind !== "zousing" ? !1 : e.t === t || n === 4 && t !== "wine" && e.t === "wine" || n === 1 && e.t === "mushroom" || r === 11 && e.v === 3;
}
function rr(e, t) {
	return t.kind === "ingredient" ? !(e === 9 && t.v === 2 || e === 13 && t.v === 3) : t.kind === "spice" ? e !== 14 : t.kind === "tofu" || t.kind === "zousing";
}
function ir(e, t, n) {
	return n.kind === "rumor" ? n.r === void 0 ? !1 : n.r >= 0 ? !e[n.r] : e.some((e) => !e) : n.kind !== "coffee" || t.length > 0;
}
function ar(e, t) {
	if (e.kind !== "rumor" || e.r !== -1) return;
	let n = t.findIndex((e) => !e);
	return n >= 0 ? n : void 0;
}
function or(e, t) {
	if (!e.shop) return [];
	let n = e.locations.findIndex((t) => t.id === e.shop.loc), r = [];
	return e.locations.forEach((e, i) => {
		i > n && !e.chefs.some((e) => e.rid === t) && r.push(e.id);
	}), r;
}
function sr(e) {
	return {
		round: e.round,
		assign: {},
		zous: {},
		breakChef: e.breakRoll ?? null,
		sel: null
	};
}
function cr(e, t, n) {
	let r = e.breakRoll === null ? null : n.breakChef ?? e.breakRoll, i = [
		1,
		2,
		3
	].filter((e) => e !== r).map((e) => n.assign[e]);
	if (i.some((e) => !e) || new Set(i).size !== i.length) return !1;
	let a = new Set(i), o = [];
	for (let e of t.zousReady) {
		let t = n.zous[e];
		if (!t || a.has(t)) return !1;
		a.add(t), o.push(t);
	}
	return o.length === t.zousReady.length;
}
function lr(e, t, n, r) {
	let i = t.breakRoll === null ? null : r.breakChef ?? t.breakRoll;
	return [
		1,
		2,
		3
	].filter((e) => e !== i).some((e) => !r.assign[e]) ? e("games.critterkitchen.planNeedChefs") : n.zousReady.some((e) => !r.zous[e]) ? e("games.critterkitchen.planNeedZous") : e("games.critterkitchen.planHint");
}
function ur(e, t, n) {
	let r = e.breakRoll === null ? null : n.breakChef ?? e.breakRoll, i = e.locations[0].id, a = [
		1,
		2,
		3
	].map((e) => ({
		chef: e,
		loc: e === r ? n.assign[e] ?? i : n.assign[e]
	})), o = t.zousReady.map((e) => ({
		id: e,
		loc: n.zous[e]
	}));
	return {
		type: "plan",
		chefs: a,
		breakChef: r ?? void 0,
		zous: o
	};
}
function dr(e, t) {
	let n = { ...e.assign };
	delete n[t];
	let r = e.sel?.kind === "chef" && e.sel.chef === t ? null : e.sel;
	return {
		...e,
		assign: n,
		breakChef: t,
		sel: r
	};
}
function fr(e, t, n) {
	let r = t ?? sr(e), i = r.sel;
	if (!i) return r;
	let a = { ...r.assign }, o = { ...r.zous };
	return i.kind === "chef" ? r.breakChef === i.chef ? r : a[i.chef] === n ? (delete a[i.chef], {
		...r,
		assign: a
	}) : (pr(a, o, n), a[i.chef] = n, {
		...r,
		assign: a,
		zous: o,
		sel: null
	}) : o[i.id] === n ? (delete o[i.id], {
		...r,
		zous: o
	}) : (pr(a, o, n), o[i.id] = n, {
		...r,
		assign: a,
		zous: o,
		sel: null
	});
}
function pr(e, t, n) {
	for (let t of [
		1,
		2,
		3
	]) e[t] === n && delete e[t];
	for (let e of Object.keys(t)) t[Number(e)] === n && delete t[Number(e)];
}
function mr(e, t, n) {
	let r = t ?? sr(e);
	if (n.kind === "chef") {
		let e = { ...r.assign };
		return delete e[n.chef], {
			...r,
			assign: e
		};
	}
	let i = { ...r.zous };
	return delete i[n.id], {
		...r,
		zous: i
	};
}
function hr(e) {
	return e.kind === "chef" ? `chef:${e.chef}` : `zous:${e.id}`;
}
function gr(e, t) {
	for (let n = Math.min(e.length, t.length); n > 0; --n) if (e.slice(-n).every((e, n) => e === t[n])) return n;
	return 0;
}
function _r(e) {
	return Array.from({ length: e }).map((e, t) => /* @__PURE__ */ g("i", { className: "ck-dot" }, t));
}
function vr(e, t) {
	switch (t) {
		case "tofuSpice": return e("games.critterkitchen.errMealTofu");
		case "badSpice": return e("games.critterkitchen.errMealSpice");
		case "dupItem": return e("games.critterkitchen.errMealDup");
		case "badSoup": return e("games.critterkitchen.errMealSoup");
		case "badType": return e("games.critterkitchen.errMealType");
		case "missingReq": return e("games.critterkitchen.errMealMissing");
		case "badChallenge": return e("games.critterkitchen.errMealChallenge");
		case "tooManyItems": return e("games.critterkitchen.errMealTooMany");
		case "badWinePair": return e("games.critterkitchen.errWinePair");
		case "weakMeal": return e("games.critterkitchen.errMealQuality");
		default: return e("games.critterkitchen.errMealItem");
	}
}
var yr = (e, t, n) => t[n] ? e(Y(t[n])) : "";
function Z(e, t) {
	return e(Y(de[t]));
}
function Q(e, t) {
	return e(Y(ue[t]));
}
function br(e, t) {
	return he[t] ? e(Y(he[t])) : "";
}
function xr(e, t) {
	return yr(e, O, t);
}
function Sr(e, t) {
	return yr(e, ee, t);
}
function Cr(e, t) {
	return yr(e, re, t);
}
function wr(e, t) {
	return yr(e, k, t);
}
function Tr(e, t) {
	let n = oe[t];
	return e(n ? Y(n) : "games.critterkitchen.zousLabel");
}
function Er(e, t) {
	return e(Y(ce[t]));
}
function Dr(e, t) {
	switch (t.kind) {
		case "ingredient":
		case "trophy": return t.t ? Z(e, t.t) : "";
		case "spice": return t.t === "allspice" ? e("games.critterkitchen.itemSpiceAll") : t.t ? e("games.critterkitchen.itemSpice", { type: Z(e, t.t) }) : e("games.critterkitchen.spiceLabel");
		case "organic": return e("games.critterkitchen.itemOrganic");
		case "tofu": return e("games.critterkitchen.itemTofu");
		case "zousing": return e("games.critterkitchen.itemZousIng");
		case "rumor": return t.r, e("games.critterkitchen.rumorLabel");
		case "coffee": return e("games.critterkitchen.coffeeLabel");
		case "flowers": return e("games.critterkitchen.flowersLabel");
		case "coin": return e("games.critterkitchen.coinLabel");
		case "mystery": return e("games.critterkitchen.itemMystery");
		case "soup": return e("games.critterkitchen.soupLabel");
		case "bisque": return e("games.critterkitchen.bisqueLabel");
		case "zous": return t.v === void 0 ? e("games.critterkitchen.zousLabel") : Tr(e, t.v);
		default: return "";
	}
}
function $({ t: e, it: t, spiceMult: n = 2 }) {
	let r = t.kind === "ingredient" || t.kind === "spice" || t.kind === "trophy" || t.kind === "organic" || t.kind === "zousing" || t.kind === "tofu" ? t.t : void 0, i = t.kind === "soup" ? 1 : t.kind === "bisque" ? 3 : t.v;
	return /* @__PURE__ */ _("span", {
		className: "ck-token__inner",
		"data-kind": t.kind,
		"data-ing": r,
		children: [
			/* @__PURE__ */ g(jn, { item: t }),
			/* @__PURE__ */ g("span", {
				className: "ck-token__name",
				children: Dr(e, t)
			}),
			i !== void 0 && t.kind !== "zous" && /* @__PURE__ */ g("span", {
				className: "ck-token__val",
				children: i
			}),
			t.kind === "spice" && /* @__PURE__ */ _("span", {
				className: "ck-token__mul",
				children: ["×", n]
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var Or = () => (crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] ?? 0) / 4294967296;
function kr(e) {
	return e[Math.floor(Or() * e.length)];
}
function Ar(e, t) {
	return e.players.find((e) => e.rid === t);
}
function jr(e, t) {
	let n = e.v ?? 0;
	return e.kind === "organic" && (n = 8), t.critic === 6 && e.kind === "ingredient" && n === 6 && (n = 9), t.critic === 8 && e.kind === "ingredient" && e.t === "carrot" && (n *= 2), n;
}
function Mr(e) {
	return e.kind === "ingredient" || e.kind === "organic" || e.kind === "zousing" ? e.t ?? null : null;
}
function Nr(e) {
	return e.kind === "ingredient" || e.kind === "organic" || e.kind === "tofu" || e.kind === "zousing";
}
function Pr(e, t) {
	return e.kind === "ingredient" ? !(t.critic === 9 && e.v === 2 || t.critic === 13 && e.v === 3) : e.kind === "spice" ? t.critic !== 14 : e.kind === "tofu" || e.kind === "zousing";
}
function Fr(e) {
	if (e.day >= 3) return new Set(S);
	let t = e.challenges.slice(e.day === 1 ? 0 : 3, e.day === 1 ? 3 : 6).filter((e) => e >= 0), n = /* @__PURE__ */ new Set();
	for (let r of t) for (let t of Ir(e, r)) n.add(t);
	return n;
}
function Ir(e, t) {
	let n = D[t] ?? [];
	return e.held.includes(t) ? n.slice(0, -1) : [...n];
}
function Lr(e) {
	return [...e.items, ...e.cart?.items ?? []];
}
function Rr(e, t, n) {
	switch (e.kind) {
		case "ingredient":
		case "zousing": {
			let r = e.v ?? 0, i = e.t;
			return i && t.has(i) && (r += 2), n.restaurateur === 2 && (i === "meat" || i === "fish") && (r += 1), n.restaurateur === 4 && e.v === 2 && (r += 1), r;
		}
		case "organic": {
			let n = e.t;
			return n && t.has(n) ? 8 : 2;
		}
		case "spice": {
			if (e.t === "allspice") return 4;
			let n = e.t;
			return n && t.has(n) ? 4 : 2.5;
		}
		case "tofu": return 4;
		case "rumor": return 2.5;
		case "trophy": return 3;
		case "coin": return 1.5;
		case "mystery": return 4;
		case "bisque": return 3;
		case "soup": return 1;
		case "zous": return 3;
		case "flowers": return 1;
		case "coffee": return 0;
		default: return 1;
	}
}
function zr(e, t, n, r) {
	let i = Lr(e).map((e) => Rr(e, n, r)).sort((e, t) => t - e), a = 0;
	for (let e = 0; e < Math.min(t, i.length); e += 1) a += i[e];
	return a;
}
var Br = {
	0: 7,
	1: 4,
	2: 6,
	3: 3,
	4: 4,
	5: 5,
	6: 5,
	7: 4,
	8: 5,
	9: 5,
	10: 5,
	11: 5,
	12: 4,
	13: 5
};
function Vr(e, t, n) {
	if (e.phase !== "rest" || !t.canAct || t.offers.length === 0) return null;
	if (n === "weak" && Or() < .35) return {
		type: "restPick",
		id: kr(t.offers)
	};
	let r = (e) => (me[e] ?? 0) * 2 + (Br[e] ?? 2);
	return {
		type: "restPick",
		id: [...t.offers].sort((e, t) => r(t) - r(e))[0]
	};
}
function Hr(e, t, n, r, i) {
	let a = null, o = -Infinity;
	for (let s of e) {
		if (t.has(s.id)) continue;
		let e = zr(s, n, r, i);
		e > o && (o = e, a = s);
	}
	return a;
}
function Ur(e, t, n) {
	if (e.phase !== "plan" || !t.canAct) return null;
	let r = e.locations, i = Fr(e), a = e.players.length >= 6 ? e.breakRoll ?? 1 : null, o = [], s = /* @__PURE__ */ new Set(), c = [
		1,
		2,
		3
	], l = a ? c.filter((e) => e !== a) : c;
	for (let e of [...l].sort((e, t) => t - e)) {
		let n = Hr(r, s, e, i, t);
		if (!n) break;
		s.add(n.id), o.push({
			chef: e,
			loc: n
		});
	}
	if (o.length < l.length) return null;
	if (n === "weak" && Or() < .3) for (let e = o.length - 1; e > 0; --e) {
		let t = Math.floor(Or() * (e + 1));
		[o[e], o[t]] = [o[t], o[e]];
	}
	let u = o.map((e) => ({
		chef: e.chef,
		loc: e.loc.id
	})), d = new Set(o.map((e) => e.loc.id));
	if (a) {
		let e = Hr(r, d, 1, i, t);
		u.push({
			chef: a,
			loc: (e ?? o[0].loc).id
		});
	}
	let f = new Set(d), p = [], m = [...t.zousReady].sort((e, t) => Wr(t) - Wr(e));
	for (let e of m) {
		let n = Hr(r, f, Wr(e), i, t);
		n && (f.add(n.id), p.push({
			id: e,
			loc: n.id
		}));
	}
	return {
		type: "plan",
		chefs: u,
		zous: p
	};
}
function Wr(e) {
	return ae.find((t) => t.id === e)?.cap ?? 1;
}
function Gr(e, t, n) {
	let r = e.shop;
	if (!r) return null;
	let i = e.locations.findIndex((e) => e.id === r.loc), a = null, o = -Infinity;
	for (let s = i + 1; s < e.locations.length; s += 1) {
		let i = e.locations[s];
		if (i.chefs.some((e) => e.rid === n)) continue;
		let c = zr(i, r.cap, Fr(e), t);
		c > o && (o = c, a = i.id);
	}
	return a;
}
function Kr(e, t, n, r, i = 1) {
	let a = e.shop;
	if (!a) return null;
	let o = Ar(e, n);
	if (!o) return null;
	let s = e.locations.find((e) => e.id === a.loc);
	if (!s) return null;
	let c = [];
	for (let i of Lr(s)) {
		let a;
		if (i.kind === "rumor") {
			if (i.r === void 0) continue;
			if (i.r >= 0) {
				if (o.rumorSlots[i.r]) continue;
			} else {
				let e = o.rumorSlots.findIndex((e) => !e);
				if (e < 0) continue;
				a = e;
			}
		}
		(i.kind !== "coffee" || Gr(e, t, n)) && c.push({
			item: i,
			slot: a,
			value: Rr(i, r, t)
		});
	}
	return c.length === 0 ? null : (c.sort((e, t) => t.value - e.value || e.item.id - t.item.id), i > 1 ? kr(c.slice(0, Math.min(i, c.length))) : c[0]);
}
function qr(e, t, n) {
	let r = e.locations.find((e) => e.id === t.loc);
	if (r?.cart?.kind !== "gift") return -1;
	let i = r.cart.gifts.findIndex((e) => e.length >= n);
	return i === 0 || i === 1 ? i : -1;
}
function Jr(e, t, n, r) {
	let i = e.shop;
	if (e.phase !== "shop" || !i || i.activeRid !== n) return null;
	let a = Ar(e, n), o = t.shop;
	if (!a || !o) return null;
	if (i.pendingCoffee) {
		let r = Gr(e, t, n);
		return r ? {
			type: "coffee",
			loc: r
		} : null;
	}
	let s = Fr(e), c = r === "weak" ? 3 : 1;
	if (o.canExtra) {
		let r = Kr(e, t, n, s, c);
		if (r) return {
			type: "extra",
			item: r.item.id,
			...r.slot === void 0 ? {} : { slot: r.slot }
		};
	}
	if (o.canGift && a.stars >= 2 && i.picks < i.cap) {
		let t = qr(e, i, 2);
		if (t >= 0) return {
			type: "gift",
			box: t
		};
	}
	if (o.canCoin && a.coins >= 2) {
		let r = Kr(e, t, n, s);
		if (r && r.value >= 5) return { type: "coin" };
	}
	let l = Kr(e, t, n, s, c);
	if (l) return {
		type: "pick",
		item: l.item.id,
		...l.slot === void 0 ? {} : { slot: l.slot }
	};
	if (o.canLeave) return { type: "leave" };
	if (o.canGift) {
		let t = qr(e, i, 1);
		if (t >= 0) return {
			type: "gift",
			box: t
		};
	}
	return o.canCoin ? { type: "coin" } : null;
}
function Yr(e, t, n) {
	if (e.kind === "ingredient" || e.kind === "organic" || e.kind === "zousing") {
		let r = Mr(e);
		return r ? {
			it: e,
			realType: r,
			wild: n.restaurateur === 11 && e.kind === "ingredient" && e.v === 3 || t.critic === 1 && e.kind === "ingredient" && e.t === "mushroom",
			needsSpice: !1,
			value: jr(e, t)
		} : null;
	}
	return e.kind === "tofu" ? {
		it: e,
		realType: null,
		wild: !0,
		needsSpice: !0,
		value: jr(e, t)
	} : null;
}
function Xr(e, t) {
	return e.it.kind === "tofu" ? !t || t.kind !== "spice" || !t.t || t.t === "allspice" ? "any" : t.t : e.wild ? "any" : e.realType ?? "any";
}
function Zr(e, t, n, r) {
	return e.kind === "spice" ? e.t ? r.restaurateur === 8 || e.t === "allspice" || e.t === t.realType : !1 : n.critic === 10 && e.kind === "ingredient" && e.t === "wine";
}
function Qr(e, t, n) {
	return e.kind === "spice" ? e.t ? e.t === "allspice" || t.includes(e.t) : !1 : n.critic === 10 && e.kind === "ingredient" && e.t === "wine";
}
function $r(e, t, n) {
	return e.kind === "spice" ? e.t ? e.t === "allspice" || e.t === t : !1 : n.critic === 10 && e.kind === "ingredient" && e.t === "wine";
}
function ei(e, t, n, r) {
	let i = e.filter((e) => !r.has(e.id) && $r(e, t, n));
	if (i.length === 0) return null;
	let a = (e) => e.kind === "spice" && e.t === t ? 0 : e.kind === "spice" && e.t === "allspice" ? 1 : 2;
	return [...i].sort((e, t) => a(e) - a(t))[0];
}
function ti(e, t, n, r, i, a) {
	let o = e.filter((e) => !a.has(e.id) && (t.needsSpice ? Qr(e, i, n) : Zr(e, t, n, r)));
	if (o.length === 0) return null;
	let s = (e) => e.kind === "spice" && e.t !== "allspice" && e.t === t.realType ? 0 : e.kind === "spice" && e.t === "allspice" ? 2 : 1;
	return [...o].sort((e, t) => s(e) - s(t))[0];
}
function ni(e, t, n, r) {
	let i = /* @__PURE__ */ new Set();
	for (let t of e.picks) {
		if (!t.spice) continue;
		let e = Xr(t.cand, t.spice);
		e !== "any" && i.add(e);
	}
	let a = 0;
	for (let r of e.picks) {
		let e = Xr(r.cand, r.spice), o = r.cand.value;
		n.restaurateur === 2 && (e === "meat" || e === "fish") && (o += 3), n.restaurateur === 4 && r.cand.value === 2 && (o += 2);
		let s = n.restaurateur === 6 && e !== "any" && i.has(e);
		(r.spice || s) && (o *= t.critic === 11 ? 3 : 2), a += o;
	}
	return n.restaurateur === 10 && (a += Math.min(r.filter(Boolean).length, 5)), a + e.soup + e.bisque * 3;
}
function ri(e, t, n, r) {
	if (e < 6) return 0;
	let i = e >= 21 ? 4 : e >= 12 ? 2 : 1;
	if (n.critic === 2 && (i += 1), r.restaurateur === 5 && e >= 25 && (i += 1), r.restaurateur === 3 && t.soup + t.bisque === 0) {
		let e = t.picks.length === t.req.length;
		if (e) {
			let n = /* @__PURE__ */ new Map();
			for (let r of t.picks) {
				let t = Xr(r.cand, r.spice);
				if (t === "any") {
					e = !1;
					break;
				}
				n.set(t, (n.get(t) ?? 0) + 1);
			}
			if (e) for (let r of t.req) n.get(r) !== 1 && (e = !1);
		}
		e && (i += 1);
	}
	return i;
}
function ii(e, t, n, r, i, a, o, s) {
	let c = {
		req: e,
		picks: [],
		soup: 0,
		bisque: 0
	}, l = t.map((e) => Yr(e, a, o)).filter((e) => e !== null).sort((e, t) => t.value - e.value), u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set();
	for (let t of e) {
		let e = l.find((e) => !u.has(e.it.id) && !e.wild && e.realType === t) ?? null;
		if (e) u.add(e.it.id), c.picks.push({
			cand: e,
			spice: null
		});
		else {
			let r = l.filter((e) => !u.has(e.it.id) && e.wild);
			for (let i of r) {
				if (i.needsSpice) {
					let r = ei(n, t, a, /* @__PURE__ */ new Set([...d, ...u]));
					if (!r) continue;
					u.add(i.it.id), d.add(r.id), c.picks.push({
						cand: i,
						spice: r
					}), e = i;
					break;
				}
				u.add(i.it.id), c.picks.push({
					cand: i,
					spice: null
				}), e = i;
				break;
			}
		}
		if (!e) {
			if (r > 0) c.soup += 1, --r;
			else if (i > 0) c.bisque += 1, --i;
			else return null;
		}
	}
	let f = c.picks.filter((e) => !e.spice && !e.cand.needsSpice).sort((e, t) => t.cand.value - e.cand.value);
	for (let t of f) {
		let r = ti(n, t.cand, a, o, e, /* @__PURE__ */ new Set([...d, ...u]));
		r && (t.spice = r, d.add(r.id));
	}
	for (let t of l) {
		if (u.has(t.it.id)) continue;
		if (ni(c, a, o, s) >= 21) break;
		if (!t.wild && (!t.realType || !e.includes(t.realType))) continue;
		if (t.needsSpice) {
			let r = ti(n, t, a, o, e, /* @__PURE__ */ new Set([...d, ...u]));
			if (!r) continue;
			u.add(t.it.id), d.add(r.id), c.picks.push({
				cand: t,
				spice: r
			});
			continue;
		}
		u.add(t.it.id);
		let r = ti(n, t, a, o, e, /* @__PURE__ */ new Set([...d, ...u]));
		r && d.add(r.id), c.picks.push({
			cand: t,
			spice: r
		});
	}
	if (c.picks.length === 0) return null;
	for (; !(ni(c, a, o, s) >= 6);) if (r > 0) c.soup += 1, --r;
	else if (i > 0) c.bisque += 1, --i;
	else break;
	for (;;) {
		let e = ni(c, a, o, s), t = e < 12 ? 12 : e < 21 ? 21 : null;
		if (t === null || i <= 0 || t - e > 3) break;
		c.bisque += 1, --i;
	}
	return c;
}
function ai(e) {
	return {
		challenge: -1,
		items: e.picks.map((e) => ({
			id: e.cand.it.id,
			...e.spice ? { spice: e.spice.id } : {}
		})),
		soup: e.soup,
		bisque: e.bisque
	};
}
function oi(e, t, n) {
	let r = Ar(e, n)?.rumorSlots ?? [], i = [];
	for (let t of e.day === 1 ? [
		0,
		1,
		2
	] : [
		3,
		4,
		5
	]) {
		let n = e.challenges[t];
		n !== void 0 && n >= 0 && i.push(n);
	}
	let a = e.critic === 12 && e.extraChallenge !== null;
	a && i.push(e.extraChallenge);
	let o = a ? 4 : 3, s = /* @__PURE__ */ new Set(), c = t.soup, l = t.bisque, u = [];
	for (let n of i) {
		if (u.length >= o) break;
		let i = ii(Ir(e, n), t.items.filter((e) => !s.has(e.id) && Nr(e)), t.items.filter((t) => !s.has(t.id) && (t.kind === "spice" || e.critic === 10 && t.kind === "ingredient" && t.t === "wine")), c, l, e, t, r);
		if (i && !(ri(ni(i, e, t, r), i, e, t) <= 0)) {
			for (let e of i.picks) s.add(e.cand.it.id), e.spice && s.add(e.spice.id);
			c -= i.soup, l -= i.bisque, u.push({
				...ai(i),
				challenge: n
			});
		}
	}
	return {
		type: "meals",
		meals: u
	};
}
function si(e, t, n) {
	if (e.phase !== "fridge" || !t.canAct) return null;
	let r = Ar(e, n)?.flowers ?? 0, i = t.fridgeLimit - Math.min(r, t.fridgeLimit);
	if (i <= 0) return {
		type: "fridge",
		keep: []
	};
	let a = (n) => n.kind === "spice" ? n.t === "allspice" ? 6 : t.items.some((e) => e.kind !== "spice" && Mr(e) === n.t) ? 5 : 3 : n.kind === "tofu" ? 4 : jr(n, e);
	return {
		type: "fridge",
		keep: t.items.filter((t) => Pr(t, e)).sort((e, t) => a(t) - a(e) || e.id - t.id).slice(0, i).map((e) => e.id)
	};
}
function ci(e, t, n, r, i) {
	let a = t.items.filter((e) => !r.has(e.id)).map((n) => Yr(n, e, t)).filter((e) => e !== null), o = a.filter((e) => e.realType === n && !e.wild).sort((e, t) => t.value - e.value);
	if (o[0]) return o[0];
	let s = a.filter((e) => e.wild).sort((e, t) => +!!e.needsSpice - !!t.needsSpice || t.value - e.value);
	for (let a of s) if (!a.needsSpice || ti(i, a, e, t, [n], /* @__PURE__ */ new Set([...r]))) return a;
	return null;
}
function li(e, t, n) {
	if (e.phase !== "critic" || !t.canAct) return null;
	let r = /* @__PURE__ */ new Set(), i = Object.fromEntries(S.map((e) => [e, { items: [] }])), a = () => t.items.filter((t) => !r.has(t.id) && (t.kind === "spice" || e.critic === 10 && t.kind === "ingredient" && t.t === "wine"));
	for (let n of S) {
		let o = e.critic === 14 ? 2 : 1;
		for (let s = 0; s < o; s += 1) {
			let o = ci(e, t, n, r, a());
			if (!o) break;
			let s = ti(a(), o, e, t, [n], /* @__PURE__ */ new Set([...r]));
			r.add(o.it.id);
			let c = { id: o.it.id };
			s && (r.add(s.id), c.spice = s.id), i[n].items.push(c);
		}
	}
	let o;
	if (e.critic === 12 && e.extraChallenge !== null) {
		let i = Ir(e, e.extraChallenge), a = t.items.filter((e) => !r.has(e.id) && Nr(e)), s = t.items.filter((t) => !r.has(t.id) && (t.kind === "spice" || e.critic === 10 && t.kind === "ingredient" && t.t === "wine")), c = Ar(e, n), l = ii(i, a, s, t.soup, t.bisque, e, t, c?.rumorSlots ?? []);
		l && ni(l, e, t, c?.rumorSlots ?? []) >= 6 && (o = {
			...ai(l),
			challenge: e.extraChallenge
		});
	}
	return {
		type: "critic",
		courses: i,
		...o ? { extra: o } : {}
	};
}
var ui = (e, t) => {
	let n = e.public, r = e.private, i = t.rid;
	if (!r) return null;
	switch (n.phase) {
		case "rest": {
			let e = Vr(n, r, t.difficulty);
			return e ? { action: e } : null;
		}
		case "plan": {
			let e = Ur(n, r, t.difficulty);
			return e ? { action: e } : null;
		}
		case "shop": {
			let e = Jr(n, r, i, t.difficulty);
			return e ? { action: e } : null;
		}
		case "challenge": return r.canAct ? { action: oi(n, r, i) } : null;
		case "fridge": {
			let e = si(n, r, i);
			return e ? { action: e } : null;
		}
		case "critic": {
			let e = li(n, r, i);
			return e ? { action: e } : null;
		}
		default: return null;
	}
}, di = (e, t, n) => {
	let r = (e) => n(ue[e]);
	switch (e.type) {
		case "restPick": return n("games.critterkitchen.restTitle");
		case "plan": return e.chefs.map((e) => `${n("games.critterkitchen.planChefLabel", { n: e.chef })} · ${r(e.loc)}`).join(" / ");
		case "pick":
		case "extra": return n("games.critterkitchen.shopPickHint");
		case "leave": return n("games.critterkitchen.shopLeave");
		case "gift": return n("games.critterkitchen.shopGiftTitle");
		case "coin": return n("games.critterkitchen.shopCoinUse");
		case "coffee": return `${n("games.critterkitchen.shopCoffeeTitle")} · ${r(e.loc)}`;
		case "meals": return n("games.critterkitchen.challengeSubmit");
		case "fridge": return n("games.critterkitchen.fridgeSubmit");
		case "critic": return n("games.critterkitchen.criticSubmit");
		default: return n("games.critterkitchen.confirm");
	}
};
//#endregion
//#region src/game/game-over.tsx
function fi({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let c = s(), l = o((e) => e.locale), u = new Map((t?.final?.entries ?? []).map((e) => [e.rid, e])), d = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, l) : c("games.critterkitchen.finalUnnamed");
	}, f = i ?? a, p = e.winner.map(d).join(" · ");
	return /* @__PURE__ */ _("div", {
		className: "ck-result",
		children: [/* @__PURE__ */ _("div", {
			className: "ck-result__masthead",
			children: [/* @__PURE__ */ g(J, { kind: "star" }), /* @__PURE__ */ g("b", { children: c("games.critterkitchen.name") })]
		}), /* @__PURE__ */ _("div", {
			className: "ck-result__layout",
			children: [
				/* @__PURE__ */ _("header", {
					className: "ck-result__head",
					children: [
						/* @__PURE__ */ g("div", {
							className: "ck-result__crest",
							children: /* @__PURE__ */ g(J, { kind: "star" })
						}),
						/* @__PURE__ */ g("h1", {
							className: "ck-result__title",
							children: c("games.critterkitchen.finalTitle")
						}),
						/* @__PURE__ */ g("p", {
							className: "ck-result__win",
							children: e.winner.length > 1 ? `${c("games.critterkitchen.finalDraw")} · ${p}` : c("games.critterkitchen.finalWinner", { name: p })
						})
					]
				}),
				/* @__PURE__ */ g("ol", {
					className: "ck-result__list",
					children: e.ranking.map((t, i) => {
						let a = u.get(t), o = n.find((e) => e.rid === t), s = e.scores?.[t] ?? a?.stars ?? 0, l = e.winner.includes(t), f = e.autopilot?.[t], p = b[(o?.colorIndex ?? 0) % b.length];
						return /* @__PURE__ */ _("li", {
							className: "ck-result__row",
							"data-winner": l || void 0,
							children: [
								/* @__PURE__ */ g("span", {
									className: "ck-result__rank",
									"aria-label": c("games.critterkitchen.finalRank", { n: i + 1 }),
									children: i + 1
								}),
								/* @__PURE__ */ g("span", {
									className: "ck-result__avatar",
									style: { backgroundColor: p.hex },
									children: o && /* @__PURE__ */ g("img", {
										src: v[o.avatar % v.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ g("div", {
									className: "ck-result__person",
									children: /* @__PURE__ */ _("strong", { children: [
										/* @__PURE__ */ g("span", {
											className: "ck-result__name",
											children: d(t)
										}),
										t === r && /* @__PURE__ */ g("small", {
											className: "ck-result__you",
											children: c("lobby.you")
										}),
										f !== void 0 && f > 0 && /* @__PURE__ */ _("small", {
											className: "ck-result__ap",
											children: [/* @__PURE__ */ g(y, { size: 11 }), c("session.autopilot.share", { n: Math.round(f * 100) })]
										})
									] })
								}),
								a && /* @__PURE__ */ _("dl", {
									className: "ck-result__breakdown",
									children: [
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: c("games.critterkitchen.finalBase") }), /* @__PURE__ */ g("dd", { children: a.base })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: c("games.critterkitchen.finalBonus") }), /* @__PURE__ */ g("dd", { children: a.bonus >= 0 ? `+${a.bonus}` : a.bonus })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: c("games.critterkitchen.finalTrack") }), /* @__PURE__ */ g("dd", { children: a.track })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: c("games.critterkitchen.finalQualityLabel") }), /* @__PURE__ */ g("dd", { children: a.quality })] })
									]
								}),
								/* @__PURE__ */ _("div", {
									className: "ck-result__total",
									children: [/* @__PURE__ */ _("b", { children: [
										/* @__PURE__ */ g(J, { kind: "star" }),
										" ",
										s
									] }), /* @__PURE__ */ g("small", { children: c("games.critterkitchen.finalTotal") })]
								})
							]
						}, t);
					})
				}),
				/* @__PURE__ */ g("p", {
					className: "ck-result__hint",
					children: c("games.critterkitchen.finalHint")
				}),
				f ? /* @__PURE__ */ _("div", {
					className: "ck-result__controls safe-b",
					children: [i && /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn ck-btn--primary",
						onClick: i,
						children: c("session.result.playAgain")
					}), a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "ck-btn",
						onClick: a,
						children: c("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ g("p", {
					className: "ck-result__wait safe-b",
					children: c("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function pi({ value: e, onChange: t }) {
	let n = s(), r = Te.parse(e);
	return /* @__PURE__ */ _("div", {
		className: "flex w-full max-w-3xl flex-col gap-1",
		children: [/* @__PURE__ */ g(x, {
			checked: r.expansion,
			label: n("games.critterkitchen.optionExpansion"),
			hint: n("games.critterkitchen.optionExpansionHint"),
			accent: Le.accent,
			onChange: () => t({
				...r,
				expansion: !r.expansion
			})
		}), /* @__PURE__ */ g(x, {
			checked: r.carts,
			disabled: !r.expansion,
			label: n("games.critterkitchen.optionCarts"),
			hint: n("games.critterkitchen.optionCartsHint"),
			accent: Le.accent,
			onChange: () => t({
				...r,
				carts: !r.carts
			})
		})]
	});
}
//#endregion
//#region src/index.tsx
var mi = {
	definition: Tn,
	View: Ln,
	bot: ui,
	describe: di,
	OverView: fi,
	Options: pi,
	locales: {
		zh: {
			name: "动物星餐厅",
			desc: "派遣厨师采购食材，完成挑战餐并征服评论家，比谁获得最多星星",
			optionExpansion: "启用《À La Cart》扩展",
			optionExpansionHint: "加入六至七人模式，以及扩展谣言、评论家与 zous 厨师",
			optionCarts: "启用购物车",
			optionCartsHint: "在花园顶店、沙漠商贩与水产市场放置购物车",
			rules: "目标:\n在七轮采购与烹饪中，用厨师从各处集市挑选食材与香料，完成挑战餐并打动美食评论家。游戏结束时星星最多的玩家获胜。\n准备:\n· 每名玩家拿取自己的三名厨师与厨房板。\n· 把所有食材、香料与谣言标记放入袋中并洗混。食材共有面包、胡萝卜、奶酪、鱼、肉、蘑菇与酒七种类型，数值从 2 到 7。每种香料有两枚，另有万能香料。\n· 洗混七张挑战卡，取出六张按顺序暗放，第七张留在旁边。每轮开始时揭示一张。\n· 随机抽取一名评论家卡放在桌上，它在第三天为所有玩家试吃。\n· 每名玩家获得两张餐厅老板卡，暗选一张保留，另一张放回盒中。\n· 抽取三张谣言卡正面朝上摆放，并从袋中放入对应的谣言标记与狂野标记。\n· 按人数摆放地点板。两人局使用汤车、花园顶店、沙漠商贩、午夜商人与厨师学院。\n· 由系统随机决定优先轨顺序，之后玩家的相对顺序会随采购改变。\n回合与天:\n一局共进行七轮，分为三天。第一至三轮为第一天，第四至六轮为第二天，第七轮为第三天。每轮依次经历安排厨师与采购两个阶段。第一天与第二天结束时结算挑战餐并冷藏，第三天结束时为评论家上菜。\n选择餐厅老板:\n只在第一轮开始前进行一次。每名玩家从两张卡中选择一张，该卡的能力在本局剩余时间里持续生效，卡顶星数在终局直接计入总分。\n安排厨师:\n· 每名玩家同时把三名厨师分别安排到三个不同的地点。\n· 玩家也可以把当轮拥有的 zous 厨师安排到地点。zous 厨师同样不能与其他厨师或另一名 zous 厨师占用同一地点。\n· 六至七人局中，每轮开始时掷出 1 至 3 的休息编号。每名玩家指定一名休息厨师，该厨师本轮不下场。如果休息厨师的编号与掷出的编号相同，该玩家获得两份汤。\n· 所有玩家确认安排后进入采购阶段。\n采购:\n· 采购从第一个地点开始，按地点板的顺序依次解析。每个地点按容量 1、2、3 排队；同一容量有多名厨师时，按优先轨从前往后轮流取货。\n· 轮到某名厨师时，他从该地点取走一件物品。每名厨师按其容量最多取走相应数量的物品，取满后轮到下一名厨师或下一容量。\n· 如果某名厨师是第一个从该地点取货的人，且他的优先轨位置与另一名厨师并列，那么只有他把自己的帽子移到队尾。\n· 玩家尚未取走任何物品时可以选择离开，并获得一份汤。已经取走物品后，必须继续取到容量上限或地点清空。\n· 地点解析后，剩余食材与香料移入厨师学院，剩余谣言标记与购物车物品被移除。\n· 所有玩家完成采购后，结束本轮。第一、二天结束时先结算挑战餐，再进行冷藏。\n挑战餐:\n· 每轮开始时揭示一张新挑战卡。第一、二天结束时，桌面上各有三张当天可用的挑战卡。\n· 每张挑战卡列出三种必需食材类型。一份挑战餐必须包含每种必需食材至少一件；缺少的类型可以用汤代替，每份汤只能代替一种缺失类型，整份餐不能全部由汤组成。\n· 一份挑战餐可以额外加入任意数量的同类食材与汤。\n· 第一天与第二天最后揭示的挑战卡各带一枚保留标记，盖住最右侧的一项要求，被盖住的要求不需要满足。\n· 食材的数值相加得到餐的质量；香料使对应食材的数值翻倍，汤计 1，浓汤计 3。\n· 质量低于 6 的餐不能上菜。质量为 6 至 11 获得 1 颗星，12 至 20 获得 2 颗星，21 及以上获得 4 颗星。\n· 每名玩家每天最多上三份挑战餐，每张挑战卡至多一份。上菜后，汤与浓汤回到供应堆，食材与香料放回袋中。\n冷藏:\n· 第一天结束时最多冷藏五件可冷藏物品，第二天结束时最多冷藏十件；第三天不需要冷藏。\n· 可冷藏的物品包括食材、香料、豆腐与花；汤、浓汤、谣言标记与公开物品不计入。\n· 未冷藏的食材与香料放回袋中；花与有机食材另有规则。\n评论家试餐:\n· 第三天采购结束后，每名玩家为评论家准备七道菜。七道菜按面包、胡萝卜、奶酪、鱼、肉、蘑菇与酒的顺序排列，每道菜选择一件食材，至多再搭配一份香料。\n· 评论家餐不能用汤代替食材。豆腐必须搭配香料才能上菜。\n· 每道菜的数值合计为该道质量；香料使对应食材的数值翻倍。\n· 七道菜全部完成时获得 1 颗星。每道菜质量最高者获得 1 颗星，并列者都获得。\n· 汤与浓汤总量最高者获得 1 颗星，每份汤计 1，每份浓汤计 3。\n· 随后结算所有在场谣言卡、餐厅老板能力、奖杯、金币、咖啡与评论家能力。\n· 七道菜的质量合计决定分数轨上的位置，按停留位置对应的星数取星，第一格至第七格均为 1 颗星；越过七十格时额外获得 10 颗星，并从起点继续。\n· 终局星星最多的玩家获胜。并列时依次比较评论家餐质量合计与优先轨位置。\n餐厅老板:\n· 每名玩家在开局保留一张餐厅老板卡，其能力整局有效，卡顶星数在终局计入总分。\n· 基础盒有十张餐厅老板卡，扩展开启后加入四张。各卡能力印在卡面上，玩家随时可以点开查看。\n谣言:\n· 游戏开始时抽取三张谣言卡正面朝上放在桌上，每张对应三枚同名谣言标记，袋中另有狂野谣言标记。\n· 玩家在采购中取到谣言标记时，把它放到厨房对应的谣言槽，并立刻查看该谣言卡；狂野标记放到任意空槽，并查看该槽的谣言。\n· 已经知道的谣言不能再被同一玩家拾取。当所有玩家都知道某张谣言时，把它翻面公开。\n· 终局结算评论家餐时，所有在场谣言对所有玩家同时生效，不论该玩家是否知道。\n购物车:\n· 开启扩展后，在花园顶店、沙漠商贩与水产市场各放置一辆购物车，每辆购物车提供一种额外物品。两人局只使用两辆购物车。\n· 购物车上的物品可以像普通物品一样取走，每轮开始时按卡面补充；轮末剩余物品弃掉，礼盒除外。\n· 本作包含九种购物车：咖啡、花、奖杯、礼盒、金币、神秘箱、有机食材、豆腐与 zous 补给车。\n· 扩展中的冰淇淋、酱料、报纸、饺子与食物募捐车没有可用卡面资料，本作不包含这些内容。\nzous 厨师:\n· zous 厨师是额外帮手，玩家取到它后，在下一轮安排阶段派往地点。它不占用三名厨师的安排位置，但同样不能与其他厨师或另一名 zous 厨师占用同一地点。\n· 每轮开始时厨师学院出现一名 zous 厨师；取走它的玩家在下一轮使用它。zous 厨师只工作一轮，用过后离队，不能留到更晚的轮次。\n· 六至七人局与 zous 补给车可以让玩家同时拥有多名 zous 厨师。\n· 每名 zous 厨师按卡面写明的时机生效，分为地点开始时、首次取货前与取完最后一件物品后。\n可选内容:\n· 本作包含基础游戏与 À La Cart 扩展：九种购物车、二十四名扩展 zous 厨师、四名扩展评论家、四名扩展餐厅老板与六至七人模式。\n· 单人模式缺少可用卡面资料，本作不包含；其余扩展购物车同样不包含。\n",
			round: "第 {{n}} 轮",
			day: "第 {{n}} 天",
			phaseRest: "选择餐厅老板",
			phasePlan: "安排厨师",
			phaseShop: "采购",
			phaseChallenge: "上菜",
			phaseFridge: "冷藏",
			phaseCritic: "评论家试餐",
			phaseDone: "终局",
			priorityLabel: "优先轨",
			starsCount: "{{n}} 星",
			waitingFor: "等 {{name}}…",
			readyLabel: "已确认",
			you: "你",
			close: "关闭",
			cancel: "取消",
			confirm: "确认",
			submit: "提交",
			pick: "取走",
			remove: "移除",
			none: "无",
			log: "记录",
			logEmpty: "暂无记录",
			kitchenTitle: "你的厨房",
			soupLabel: "汤",
			bisqueLabel: "浓汤",
			rumorLabel: "谣言",
			coinLabel: "金币",
			coffeeLabel: "咖啡",
			flowersLabel: "花",
			trophyLabel: "奖杯",
			zousLabel: "zous 厨师",
			restaurateurLabel: "餐厅老板",
			criticLabel: "评论家",
			heldLabel: "保留",
			itemTofu: "豆腐",
			itemOrganic: "有机食材",
			itemZousIng: "zous 食材",
			itemMystery: "神秘骰",
			planClear: "清空安排",
			spiceLabel: "香料",
			allspiceLabel: "万能香料",
			ingredientLabel: "食材",
			itemCount: "{{n}} 件",
			noItems: "没有物品",
			tapForDetail: "点击查看卡面",
			itemSpice: "{{type}}香料",
			itemSpiceAll: "万能香料",
			starUnit: "星",
			restTitle: "选择餐厅老板",
			restHint: "从两张卡中选择一张；卡顶星数在终局计入总分",
			restWaiting: "等 {{name}} 选择餐厅老板…",
			restChosen: "已选择 {{name}}",
			restStars: "终局加 {{n}} 星",
			planTitle: "安排厨师",
			planHint: "三名厨师要前往不同地点；zous 厨师也不能与他们同地点",
			planChooseMarket: "选择要派往的摊位。",
			marketActive: "当前采购",
			planChefLabel: "厨师 {{n}}",
			planBreakTitle: "休息厨师",
			planBreakHint: "本轮休息编号为 {{n}}；被安排休息的厨师不下场，编号相同时你获得两份汤",
			planBreakPick: "选择休息厨师",
			planLocPlaceholder: "选择地点",
			planZousTitle: "zous 厨师",
			planZousPlaceholder: "为 {{name}} 选择地点",
			planSubmit: "确认安排",
			planWaiting: "已确认，等 {{name}}…",
			planNeedChefs: "三名厨师都要选择地点",
			planNeedZous: "还有 zous 厨师没有安排",
			shopTitle: "采购",
			shopActiveAt: "{{name}} 在{{loc}}取货",
			shopYouTurn: "轮到你取货",
			shopCap: "已取 {{n}} / {{cap}}",
			shopQueueTitle: "取货顺序",
			shopPickHint: "点击物品取走",
			shopLeave: "离开",
			shopLeaveHint: "尚未取货时可以离开，获得一份汤",
			shopGiftTitle: "礼盒",
			shopGiftCost: "支付一颗星取走整盒",
			shopExtra: "额外取一件",
			shopCoinTitle: "金币",
			shopCoinUse: "放金币再取一件",
			shopCoinHint: "每个地点限一次；放下的金币会成为可取的物品",
			shopCoffeeTitle: "咖啡去向",
			shopCoffeeHint: "选择移往的地点",
			shopCoffeeCancel: "取消",
			shopWaiting: "等待其他玩家取货…",
			shopEmptyLoc: "此地点已空",
			shopPendingCoffee: "选择咖啡的去向",
			challengeTitle: "上菜",
			challengeHint: "每张挑战卡至多一份；质量达到 6 才能上菜",
			challengeRequired: "需要 {{types}}",
			challengeAddItem: "加入食材",
			challengeAddSoup: "用汤补缺",
			challengeAddBisque: "用浓汤补缺",
			challengeMealEmpty: "尚未选择",
			challengeQuality: "质量 {{n}}",
			challengeStars: "{{n}} 星",
			challengeTooWeak: "质量不足 6，不能上菜",
			challengeSubmit: "提交上菜",
			challengeWaiting: "已提交，等 {{name}}…",
			challengeExtra: "额外挑战",
			challengeRemove: "移除",
			challengeAddSpice: "加香料",
			challengeSpiceNone: "不加香料",
			challengePickItem: "选择食材",
			challengePickSpice: "选择香料",
			challengeTofuHint: "豆腐需要搭配香料",
			challengeNeedTypes: "缺少 {{types}}",
			challengeSoupUsed: "已用 {{n}} 份汤",
			challengeBisqueUsed: "已用 {{n}} 份浓汤",
			criticTitle: "评论家试餐",
			criticHint: "每道菜选一件食材，至多搭配一份香料；汤不计入，豆腐需要香料",
			criticCourse: "{{name}}道",
			criticEmpty: "未上菜",
			criticAdd: "选择食材",
			criticAddSpice: "搭配香料",
			criticRemove: "移除",
			criticQuality: "质量 {{n}}",
			criticExtraTitle: "额外挑战餐（河马）",
			criticExtraNone: "不上额外挑战餐",
			criticExtraAdd: "准备额外挑战餐",
			criticSubmit: "提交评论家餐",
			criticWaiting: "已提交，等 {{name}}…",
			criticQualityLabel: "质量",
			criticSpiceNone: "不加香料",
			fridgeTitle: "冷藏",
			fridgeHint: "最多冷藏 {{n}} 件食材与香料；未冷藏的食材与香料放回袋中",
			fridgeKeep: "冷藏",
			fridgeDiscard: "不冷藏",
			fridgeCount: "已选 {{n}} / {{limit}}",
			fridgeSubmit: "确认冷藏",
			fridgeWaiting: "已确认，等 {{name}}…",
			fridgeOrganic: "有机食材不能冷藏，今日结束时会丢弃",
			fridgeFlowers: "花必须冷藏，不能丢弃",
			fridgeEmpty: "没有需要处理的物品",
			finalTitle: "餐厅评鉴榜",
			finalUnnamed: "未命名餐厅",
			finalRank: "第 {{n}} 名",
			finalBase: "对局中获得",
			finalBonus: "奖励与修正",
			finalTrack: "质量轨",
			finalQuality: "七道质量合计 {{n}}",
			finalQualityLabel: "七道质量合计",
			finalTotal: "星星总计",
			finalWinner: "{{name}} 获胜",
			finalDraw: "并列获胜",
			finalHint: "星星相同时，比较评论家餐质量合计与优先轨位置",
			logRest: "{{name}} 选择了餐厅老板「{{card}}」",
			logPlan: "{{name}} 完成厨师安排",
			logPick: "{{name}} 在{{loc}}取走{{item}}",
			logRumor: "{{name}} 查看了谣言卡",
			logSoup: "{{name}} 获得 {{n}} 份汤",
			logLeave: "{{name}} 离开{{loc}}",
			logGift: "{{name}} 取走一个礼盒",
			logCoin: "{{name}} 放置金币并额外取货",
			logCoffee: "{{name}} 取走咖啡并移动厨师",
			logZous: "{{name}} 获得 zous 厨师",
			logChallenge: "{{name}} 上菜「{{card}}」，质量 {{q}}，获得 {{n}} 星",
			logFridge: "{{name}} 完成冷藏",
			logCritic: "{{name}} 完成评论家餐",
			logStar: "{{name}} 获得 {{n}} 星",
			logRound: "第 {{n}} 轮开始",
			logFinal: "终局计分完成",
			optExpansion: "À La Cart 扩展",
			optExpansionHint: "加入购物车、扩展卡牌与六至七人模式",
			optCarts: "启用购物车",
			optCartsHint: "在花园顶店、沙漠商贩与水产市场放置购物车",
			challenge0: "街头小吃",
			challenge1: "咸香叠饼",
			challenge2: "美酒佳肴",
			challenge3: "终极熔岩三明治",
			challenge4: "美味塔帕斯",
			challenge5: "海岸融合菜",
			challenge6: "治愈家常菜",
			critic0: "老鼠评论家",
			criticText0: "准备评论家餐时，你的奶酪道可以包含任意数量的奶酪。比较每道菜的最佳质量时，奶酪道额外获得 2 颗星。",
			critic1: "獾评论家",
			criticText1: "全程中，你可以把蘑菇当作任意类型食材使用，也可以把任意香料用于蘑菇。",
			critic2: "水豚评论家",
			criticText2: "你上菜的每份挑战餐额外获得 1 颗星。",
			critic3: "奶牛评论家",
			criticText3: "准备评论家餐时，你可以选择一道菜，该道最多可以包含四件同类型食材。",
			critic4: "果蝠评论家",
			criticText4: "准备评论家餐时，每道菜可以额外加入一瓶不加香料的酒，其数值必须等于该道中最高食材的数值。每这样搭配一道菜，获得 1 颗星。",
			critic5: "跳鼠评论家",
			criticText5: "准备评论家餐时，谣言标记可以当作万能香料使用。",
			critic6: "袋鼠评论家",
			criticText6: "全程中，数值 6 的食材视为数值 9。",
			critic7: "贵宾犬评论家",
			criticText7: "每有一件加香料前数值不低于 6 的食材被端给评论家，获得 1 颗星。",
			critic8: "兔子评论家",
			criticText8: "全程中，所有胡萝卜的数值翻倍。",
			critic9: "浣熊评论家",
			criticText9: "全程中，数值 2 的食材不计入冷藏上限，并保持公开。准备评论家餐时，每道菜可以额外包含任意数量的同类型数值 2 食材。",
			critic10: "圣伯纳犬评论家",
			criticText10: "全程中，酒类食材可以当作万能香料使用。",
			critic11: "树鼩评论家",
			criticText11: "全程中，香料把食材数值乘三，而不是乘二。",
			critic12: "河马评论家",
			criticText12: "把未使用的挑战卡公开放在河马旁边，整局有效。你可以在每天结束时额外上这份挑战餐。",
			critic13: "鬣狗评论家",
			criticText13: "全程中，数值 3 的食材不计入冷藏上限，并保持公开。准备评论家餐时，你的鱼道可以额外包含数值 3 的食材，数量不超过你最高的鱼数值。",
			critic14: "猪评论家",
			criticText14: "全程中，香料不计入冷藏上限，并保持公开。准备评论家餐时，每道菜可以包含两件同类型食材。",
			critic15: "狼獾评论家",
			criticText15: "每轮采购前，每个只有你一名玩家派厨师的地点，你获得 1 颗星。此评论家只在三人及以上对局出现。",
			rest0: "玛莎·鼩华特",
			restText0: "在同一天上满三份挑战餐，获得 2 颗星。",
			rest1: "安东尼·波登",
			restText1: "获得慰藉汤时，可以改为从袋中取一件物品。",
			rest2: "鲍勃猫·弗莱",
			restText2: "你的肉与鱼食材用于挑战餐时，每件数值加 3。",
			rest3: "猎鹰·布朗",
			restText3: "每份挑战餐恰好包含每种要求食材各一件且没有用汤，获得 1 颗星。",
			rest4: "山羊·拉姆齐",
			restText4: "你的数值 2 食材用于挑战餐时，每件数值加 2。",
			rest5: "格雷厄姆·大象",
			restText5: "上菜的挑战餐质量达到 25 或更高时，获得 1 颗星。",
			rest6: "苍鹭·桑切斯",
			restText6: "挑战餐中，一份香料可以作用于任意数量同类型食材。",
			rest7: "杰米·猫头鹰",
			restText7: "游戏开始时额外抽一张只有你能看到的谣言卡，它对所有玩家结算。",
			rest8: "朱莉娅·怀尔德",
			restText8: "全程中，任意香料都可以当作万能香料使用。",
			rest9: "马库斯·鲁斯特森",
			restText9: "每轮结束时，在优先轨上前进一格；如果已经在最前，则改为从袋中取一件物品。",
			rest10: "盖伊·熊里",
			restText10: "游戏开始时获得一枚狂野谣言标记。你每持有一枚谣言标记，你上菜的挑战餐质量加 1，最多加 5。",
			rest11: "亚历克斯·瓜纳谢尔鱼",
			restText11: "全程中，你可以把数值 3 的食材当作任意类型使用。",
			rest12: "埃梅里尔·拉马斯",
			restText12: "你可以把香料当作该类型的数值 5 食材使用，而不是当作香料；万能香料可以当作任意类型的数值 5 食材。",
			rest13: "森本特",
			restText13: "在第 1、4、7 轮开始时，抽一名 zous 厨师供该轮使用。",
			rumor0: "浓香奶酪",
			rumorText0: "如果你上菜的菜品数量不超过奶酪道最高食材数值，获得 3 颗星。",
			rumor1: "大汤勺",
			rumorText1: "如果你的剩汤质量不低于面包道最高食材数值，获得 2 颗星。汤计 1，浓汤计 3。",
			rumor2: "面包狂",
			rumorText2: "终局计分时，面包道的质量翻倍。",
			rumor3: "胡萝卜狂",
			rumorText3: "终局计分时，胡萝卜道的质量翻倍。",
			rumor4: "奶酪狂",
			rumorText4: "终局计分时，奶酪道的质量翻倍。",
			rumor5: "极其娇贵",
			rumorText5: "如果你上满七道菜，且每道都有一件数值不低于 5 的食材，获得 2 颗星。",
			rumor6: "鱼痴",
			rumorText6: "终局计分时，鱼道的质量翻倍。",
			rumor7: "冬眠者",
			rumorText7: "如果最右侧一道是你质量最高的菜，获得 2 颗星。",
			rumor8: "肉食狂",
			rumorText8: "终局计分时，肉道的质量翻倍。",
			rumor9: "善变",
			rumorText9: "获得与你所上食材中最高与最低数值之差相等的星。",
			rumor10: "蘑菇狂",
			rumorText10: "终局计分时，蘑菇道的质量翻倍。",
			rumor11: "夜行",
			rumorText11: "如果每道菜中数值最高的食材按顺序依次不低于左边一道，获得 5 颗星。",
			rumor12: "古怪口味",
			rumorText12: "如果你每道菜中数值最高的食材都是单数，获得 3 颗星。",
			rumor13: "挑剔",
			rumorText13: "如果你上满七道菜，获得与你所上食材中最低数值相等的星。",
			rumor14: "迷幻风味",
			rumorText14: "如果蘑菇道是你质量最高的菜，获得 2 颗星。",
			rumor15: "短视",
			rumorText15: "获得与你所上胡萝卜最高数值减去 2 相等的星。",
			rumor16: "简单口味",
			rumorText16: "上菜中数值相同的食材最多者获得 3 颗星。",
			rumor17: "侍酒师",
			rumorText17: "如果你所上的酒与鱼最高数值相同，获得 2 颗星；如果酒与肉最高数值相同，再获得 2 颗星。",
			rumor18: "香料爱好者",
			rumorText18: "上菜中使用香料最多者获得 2 颗星。",
			rumor19: "微妙风味",
			rumorText19: "上菜中与面包道最高数值相同的食材最多者获得 3 颗星。",
			rumor20: "话痨",
			rumorText20: "你每收集一枚谣言标记，获得 1 颗星。",
			rumor21: "鲜嫩",
			rumorText21: "如果最左与最右一道中数值最高的食材之和恰好为十，获得 3 颗星。",
			rumor22: "打包",
			rumorText22: "每有两件未上菜的食材或香料，获得 1 颗星；未上菜食材与香料最多者额外获得 1 颗星。",
			rumor23: "返璞归真",
			rumorText23: "每有一道只含一件食材且未加香料的菜，获得 1 颗星；这类菜最多者额外获得 1 颗星。",
			rumor24: "丰富剩菜",
			rumorText24: "每有一种不同数值的未上菜食材，获得 1 颗星；种类最多者额外获得 1 颗星。",
			rumor25: "丰富上菜",
			rumorText25: "每有一种不同数值的上菜食材，获得 1 颗星；种类最多者额外获得 1 颗星。",
			rumor26: "酒窖",
			rumorText26: "每有一瓶未上菜的酒，获得 1 颗星。",
			rumor27: "酒痴",
			rumorText27: "终局计分时，酒道的质量翻倍。",
			zous100: "卡罗尔·考拉",
			zousText100: "取完最后一件物品后：如果你在优先轨最后，获得 1 颗星。",
			zous101: "克莉茜·花栗鼠",
			zousText101: "地点开始：如果克莉茜独自在场，一次取三件物品，而不是一件。",
			zous102: "达什·猎豹",
			zousText102: "地点开始：移动到优先轨最前。",
			zous103: "杰弗里·长颈鹿",
			zousText103: "首次取货前：从袋中额外取一件物品，放到杰弗里的地点。",
			zous104: "金杰·狐狸",
			zousText104: "取完最后一件物品后：从袋中取一件物品。",
			zous105: "莉莉·青蛙",
			zousText105: "取完最后一件物品后：从汤车取走浓汤；如果没有浓汤，取一份汤。",
			zous106: "曼迪·熊猫",
			zousText106: "取完最后一件物品后：曼迪从该地点额外取一件物品；如果该地点没有物品，则从袋中取一件。",
			zous107: "明·蜂鸟",
			zousText107: "地点开始：明在其他所有厨师之前取货。该地点无人改变优先轨位置。",
			zous108: "牛顿·约克夏",
			zousText108: "取完最后一件物品后：如果牛顿取走了可选的数值最低食材，获得三份汤。",
			zous109: "奥托·水獭",
			zousText109: "地点开始：如果该地点至少还有另一名容量为 2 的厨师，你们各从袋中取一件物品。",
			zous110: "佩妮·企鹅",
			zousText110: "取完最后一件物品后：从汤车额外取一件物品，可以取汤。",
			zous111: "斯努兹·树懒",
			zousText111: "地点开始：从袋中额外取两件物品，放到该地点。",
			zous200: "亚历克斯·羊驼",
			zousText200: "取完最后一件物品后：如果亚历克斯取走了面包食材，获得 1 颗星。",
			zous201: "阿提库斯·芬奇",
			zousText201: "取完最后一件物品后：阿提库斯可以移动到一处尚未结算且没有厨师的地点，并在那里再行动一次。",
			zous202: "比利·水牛",
			zousText202: "首次取货前：比利可以弃掉并替换最多三件可用食材或香料。",
			zous203: "塞西莉亚·蟒蛇",
			zousText203: "取完最后一件物品后：塞西莉亚每在该地点取走一件肉食材，你额外从袋中取一件物品。",
			zous204: "唐娜·驴",
			zousText204: "取完最后一件物品后：唐娜每取走一件物品，你获得一份汤。",
			zous205: "多蒂·豹",
			zousText205: "取完最后一件物品后：如果多蒂未能取满三件物品，从厨师学院取三件物品，不含 zous 厨师。",
			zous206: "艾玛·鹰",
			zousText206: "地点开始：你可以移动到优先轨最后，让艾玛在该地点所有厨师之前取货；如果这样做，艾玛只取一件物品。",
			zous207: "芬恩·海豚",
			zousText207: "地点开始：如果芬恩被 zous 厨师取走，或用于取走 zous 厨师，获得 1 颗星。",
			zous208: "汉斯·鼹鼠",
			zousText208: "取完最后一件物品后：从袋中抽五件物品，保留其中所有蘑菇食材，其余放回。",
			zous209: "胡特利·猫头鹰",
			zousText209: "地点开始：如果胡特利在午夜商人处，且该处已翻出鱼食材或鱼香料，胡特利在该地点所有厨师之前取货。",
			zous210: "莉诺·渡鸦",
			zousText210: "取完最后一件物品后：莉诺可以额外取一件物品；如果这样做，从袋中额外取两件物品放到该地点。",
			zous211: "露露·狐猴",
			zousText211: "取完最后一件物品后：如果露露取走了酒，你可以把它当作狂野谣言放到你的厨房，而不是留作食材。",
			zous212: "麦克·鲨鱼",
			zousText212: "地点开始：指定一种食材类型。麦克所在地点的每名其他厨师必须给你一件该类型食材或香料，否则带着一份汤离开。",
			zous213: "玛丽·蝴蝶",
			zousText213: "地点开始：如果玛丽不是独自在场，你可以改为获得 1 颗星而不取物品。",
			zous214: "马蒂·苍蝇",
			zousText214: "首次取货前：如果马蒂所在地点有谣言，把一份汤放到你厨房上任意对应的空谣言槽；你从此知晓这些谣言。",
			zous215: "彼得·鹦鹉",
			zousText215: "首次取货前：如果彼得所在地点有香料，彼得额外取一件物品。",
			zous216: "波克特·浣熊",
			zousText216: "取完最后一件物品后：如果午夜商人尚未结算且你没有厨师在那里，把波克特移到午夜商人处，并在那里再行动一次。",
			zous217: "奎妮·蜜蜂",
			zousText217: "取完最后一件物品后：如果奎妮是该地点第一个取货的厨师，从袋中取一件物品。",
			zous218: "理查德·狮子",
			zousText218: "地点开始：理查德所在地点的老鼠厨师排在其他所有厨师之后。",
			zous219: "沙吉·寻回犬",
			zousText219: "取完最后一件物品后：你每在厨房持有一枚谣言标记，就从该地点额外取一件物品。",
			zous220: "斯基特·臭鼬",
			zousText220: "地点开始：斯基特所在地点的其他厨师每次只取一件物品，不论容量。",
			zous221: "斯派克·豪猪",
			zousText221: "地点开始：如果能够支付，斯派克所在地点的每名其他厨师必须给你一件非汤物品，由对方选择。",
			zous222: "斯特莱普斯·斑马",
			zousText222: "地点开始：斯特莱普斯在同容量的其他所有厨师之前取完全部物品。这些厨师包括斯特莱普斯都不改变优先轨位置。",
			zous223: "西德·鸭嘴兽",
			zousText223: "首次取货前：如果西德独自在场，从袋中取两件物品。",
			cartCoffee: "咖啡车",
			cartTextCoffee: "每轮开始时在车上放一枚咖啡。玩家取走咖啡时，立刻把该厨师移动到一处尚未结算且没有自己厨师的地点，并在那里再行动一次；如果无法完整执行，则不能取走咖啡。终局时咖啡最多的玩家失去 1 颗星。咖啡公开摆放，不需要冷藏。",
			cartFlowers: "花车",
			cartTextFlowers: "每轮开始时在车上放一枚花。第一个从该地点取走物品的玩家必须同时收下全部花。花永远不能丢弃。每天结束时花最多的玩家获得 1 颗星。花需要冷藏。",
			cartTrophies: "奖杯车",
			cartTextTrophies: "每轮开始时翻开一枚奖杯放到车上。奖杯可以像其他物品一样取走。终局时，如果玩家在某道菜获得最佳并持有该类型的奖杯，额外获得 1 颗星。奖杯公开摆放，不需要冷藏。",
			cartGift: "礼盒车",
			cartTextGift: "所有玩家在游戏开始时获得 1 颗星。两至三人局只使用一个礼盒，四人以上使用两个。每轮开始时每个礼盒加入两件物品。玩家可以支付 1 颗星取走一个礼盒中的全部物品，这按取走一件物品计算容量。轮末不清空礼盒。得到的食材与香料需要冷藏。",
			cartCoin: "金币车",
			cartTextCoin: "每轮开始时在车上放一枚金币。金币可以像其他物品一样取走。玩家取走物品后，可以放一枚自己的金币在该地点，立刻额外取一件物品，每个地点限一次；放下的金币会成为其他玩家可以取走的物品。终局时每两枚金币折算 1 颗星，金币最多的玩家额外获得 1 颗星。金币公开摆放，不需要冷藏。",
			cartMystery: "神秘箱",
			cartTextMystery: "每轮开始时把神秘骰放到车上。神秘骰可以像其他物品一样取走，但会立刻掷出并从地点移除；掷骰者从袋中取得与点数相同数量的物品。无论点数是多少，取走神秘骰只按取走一件物品计算。得到的食材与香料需要冷藏。",
			cartOrganic: "有机食材车",
			cartTextOrganic: "每轮开始时翻开一枚有机食材放到车上。有机食材可以像其他物品一样取走，但不能冷藏；如果当天结束时没有用于挑战餐或评论家餐，必须丢弃。",
			cartTofu: "豆腐车",
			cartTextTofu: "每轮开始时翻开一枚豆腐放到车上。豆腐可以像其他物品一样取走。豆腐只有搭配香料时才能上菜，此时视为与香料类型相同的食材，数值照常翻倍；如果使用万能香料，豆腐可以当作任意类型食材。豆腐需要冷藏。",
			cartZousToo: "zous 补给车",
			cartTextZousToo: "每轮开始时，除了为厨师学院抽一名 zous 厨师外，也为这辆车抽一名 zous 厨师并放上对应标记，同时抽出两枚 zous 食材。这辆车的作用与厨师学院的 zous 厨师相同，玩家可以像取普通物品一样取走食材或厨师。zous 食材按普通食材处理。通过这辆车，玩家可以在下一轮同时拥有多名 zous 厨师。",
			ingBread: "面包",
			ingCarrot: "胡萝卜",
			ingCheese: "奶酪",
			ingFish: "鱼",
			ingMeat: "肉",
			ingMushroom: "蘑菇",
			ingWine: "酒",
			locSoup: "汤车",
			locGarden: "花园顶店",
			locDesert: "沙漠商贩",
			locWater: "水产市场",
			locAir: "空中码头",
			locLantern: "灯笼巷",
			locMidnight: "午夜商人",
			locAcademy: "厨师学院",
			chef1: "老鼠厨师",
			chef2: "蜥蜴厨师",
			chef3: "野猪厨师",
			errPhase: "现在不能执行这个操作",
			errReady: "已经确认过了",
			errNotPlayer: "你不是本局玩家",
			errOffer: "这张餐厅老板卡不在你的选择中",
			errPlan: "三名厨师必须安排到三个不同的地点",
			errZous: "这名 zous 厨师不能安排到该地点",
			errTurn: "现在轮不到你",
			errNoItem: "这件物品不在可选范围内",
			errRumorSlot: "这个谣言槽不能使用",
			errCoffeeDest: "这个地点不能作为咖啡的去向",
			errLeaveAfterPick: "取走物品后，必须继续取到容量上限或地点清空",
			errGiftEmpty: "这个礼盒没有物品",
			errNoStar: "星数不足",
			errNoCoin: "没有可放置的金币",
			errCoinUsed: "本地点已经使用过金币",
			errNeedPick: "需要先取走一件物品",
			errMealTofu: "豆腐必须搭配香料",
			errMealSpice: "这份香料不能这样使用",
			errMealDup: "同一件物品不能重复使用",
			errMealSoup: "汤只能用来补足缺少的食材类型",
			errMealType: "食材类型与这道菜不符",
			errMealMissing: "还缺少必需的食材",
			errMealChallenge: "这道菜不属于当前可用的挑战",
			errMealTooMany: "这道菜加入了过多食材",
			errMealQuality: "质量不足 6 的餐不能上菜",
			errMealItem: "食材或香料不可用",
			errMealCount: "上菜的份数不符合规则",
			errFridgeItem: "这件物品不能冷藏",
			errFridgeLimit: "超出冷藏上限",
			errWinePair: "这瓶酒不能这样搭配"
		},
		en: {
			name: "Critter Kitchen",
			desc: "Send chefs to gather ingredients, serve challenge meals, and win over the critic for the most stars",
			optionExpansion: "Use the À La Cart expansion",
			optionExpansionHint: "Adds the 6–7 player mode plus expansion rumors, critics and zous chefs",
			optionCarts: "Enable shopping carts",
			optionCartsHint: "Places carts at the Garden Roof Shop, Desert Trader and Fish Market",
			rules: "Goal:\nAcross seven rounds of shopping and cooking, send your chefs to markets around town to gather ingredients and spice, serve challenge meals, and impress the food critic. The player with the most stars at the end of the game wins.\nSetup:\n· Each player takes their three chefs and a kitchen board.\n· Put all ingredient, spice, and rumor tokens into the bag and shuffle it. There are seven ingredient types: bread, carrot, cheese, fish, meat, mushroom, and wine, with values from 2 to 7. Each spice type has two tokens, and there is also allspice.\n· Shuffle the seven Challenge Cards, deal six face down in a row, and set the seventh aside. Reveal one at the start of each round.\n· Draw one Critic Card at random and place it face up; it tastes every restaurant on the third day.\n· Each player is dealt two Restaurateur Cards, keeps one face down, and returns the other to the box.\n· Reveal three Rumor Cards and add their matching Rumor Tokens plus the wild tokens to the bag.\n· Set out the Location Boards for the player count. With two players, use the Soup Truck, Garden Top Shop, Desert Vendor, Midnight Merchant, and Chef Academy.\n· The priority track starts in a random order; shopping changes the relative order as the game goes on.\nRounds and days:\nThe game lasts seven rounds divided into three days. Rounds one to three are day one, rounds four to six are day two, and round seven is day three. Each round has a planning step and a shopping step. Days one and two end with challenge meals and refrigeration; day three ends with the critic meal.\nRestaurateur:\nThis happens once before round one. Each player chooses one of their two Restaurateur Cards. Its ability applies for the rest of the game, and the stars printed at the top count toward the final score.\nPlanning:\n· All players simultaneously assign their three chefs to three different locations.\n· A player may also assign any zous-chefs they have for the round. A zous-chef cannot share a location with another chef or with another zous-chef.\n· In six- and seven-player games, a break number from 1 to 3 is rolled at the start of each round. Each player puts one chef on break; that chef does not visit a location. If the chef on break matches the rolled number, the player gains two soup. If a player does not choose, the chef matching the roll is put on break.\n· Once every player confirms planning, shopping begins.\nShopping:\n· Shopping resolves locations in board order. Each location has queues for carrying capacity 1, 2, and 3. Chefs of the same capacity take turns from the front of the priority track onward.\n· On a chef’s turn, they take one item from the location. Each chef takes up to their carrying capacity, then play passes to the next chef or the next capacity group.\n· If a chef is the first to pick at the location and is tied on the priority track, only that chef moves their hat to the back.\n· A player who has not picked anything may leave and gain one soup. After picking at least once, they must keep picking until they reach capacity or the location is empty.\n· After a location resolves, leftover ingredients and spice move to the Chef Academy, and leftover rumor tokens and cart items are discarded.\n· Once every player finishes shopping, the round ends. Days one and two then resolve challenge meals and refrigeration.\nChallenge meals:\n· A new Challenge Card is revealed at the start of each round. At the end of days one and two, the three challenges revealed over that day are available.\n· Each Challenge Card lists three required ingredient types. A challenge meal must contain at least one of each required type. A missing type may be replaced by one soup, and one soup replaces only one missing type. A meal cannot consist only of soup.\n· A challenge meal may also include any number of matching ingredients and soup.\n· The last challenge revealed on days one and two carries a Hold Token that covers its rightmost requirement; the covered requirement is not needed.\n· Add up ingredient values for the meal’s quality. Spice doubles the value of the ingredient it is paired with, soup counts as 1, and bisque counts as 3.\n· A meal with quality below 6 cannot be presented. Quality 6 to 11 earns 1 star, 12 to 20 earns 2 stars, and 21 or more earns 4 stars.\n· Each player may serve up to three challenge meals per day, at most one per Challenge Card. After serving, soup and bisque return to the supply, and ingredients and spice return to the bag.\nRefrigeration:\n· At the end of day one, a player may refrigerate up to five countable items; at the end of day two, up to ten. Day three has no refrigeration.\n· Ingredients, spice, tofu, and flowers can be refrigerated. Soup, bisque, rumor tokens, and public items do not count.\n· Ingredients and spice that are not refrigerated return to the bag. Flowers and organic ingredients follow their own rules.\nCritic meal:\n· After shopping on day three, each player prepares seven courses for the critic. The courses are bread, carrot, cheese, fish, meat, mushroom, and wine in that order. Each course holds one ingredient and may also include one spice.\n· Soup cannot replace an ingredient in the critic meal. Tofu must be paired with spice to be served.\n· Each course’s ingredient values add up to that course’s quality; spice doubles the value of its ingredient.\n· Serving all seven courses earns 1 star. The highest quality in each course earns 1 star, and ties all earn it.\n· The most soup and bisque earns 1 star, counting soup as 1 and bisque as 3 each.\n· Then score all revealed Rumor Cards, Restaurateur abilities, trophies, gold coins, coffee, and critic abilities.\n· The seven courses’ total quality sets the position on the scoring track; take the stars shown for that position, with spaces one through seven each worth 1 star. Passing space seventy earns 10 stars and continues from the top.\n· The player with the most stars wins. Ties compare total critic-meal quality, then priority-track position.\nRestaurateurs:\n· Each player keeps one Restaurateur Card at setup. Its ability applies for the whole game, and the stars printed at the top count toward the final score.\n· The base game has ten Restaurateur Cards, and the expansion adds four. Each ability is printed on its card and can be viewed at any time.\nRumors:\n· At setup, three Rumor Cards are revealed and placed face up. Each has three matching Rumor Tokens in the bag, along with the wild rumor tokens.\n· When a player picks a rumor token while shopping, they place it in the matching rumor slot on their kitchen and immediately look at that Rumor Card. A wild token goes into any empty slot and looks at that slot’s rumor.\n· A player may not collect the same rumor again. When every player knows a rumor, flip it face up.\n· At final scoring, every revealed rumor applies to every player, whether or not that player knows it.\nCarts:\n· With the expansion enabled, one cart is placed at the Garden Top Shop, Desert Vendor, and Water Market, each offering a special item. Two-player games use only two carts.\n· Cart items are picked like other items and restocked each round as printed on the cart. Leftover cart items are discarded at the end of the round, except for gift boxes.\n· This edition includes nine carts: Coffee, Flowers, Trophies, Gift, Gold Coins, Mystery Box, Organic, Tofu, and Zous Too.\n· The expansion’s Gelato, Sauces, Newspapers, Dumplings, and Food Drive carts have no available card text, so this edition does not include them.\nZous-chefs:\n· A zous-chef is an extra helper. After picking one, a player assigns it during the next round’s planning step. It does not use one of the three chef assignments, but it cannot share a location with another chef or another zous-chef.\n· A new zous-chef appears at the Chef Academy each round; the player who picks it uses it in the next round. A zous-chef works for only one round and then leaves, and cannot be saved for later.\n· Six- and seven-player games and the Zous Too cart let a player have more than one zous-chef at a time.\n· Each zous-chef triggers at the timing printed on its card: Start of Location, Before Your First Pick, or After Your Last Pick.\nOptional content:\n· This edition includes the base game and the À La Cart expansion: nine carts, twenty-four expansion zous-chefs, four expansion critics, four expansion restaurateurs, and the six- and seven-player mode.\n· Solo mode has no available card data and is not included. The remaining expansion carts are also not included.\n",
			round: "Round {{n}}",
			day: "Day {{n}}",
			phaseRest: "Choose Restaurateur",
			phasePlan: "Plan Chefs",
			phaseShop: "Shopping",
			phaseChallenge: "Serve Challenges",
			phaseFridge: "Refrigerate",
			phaseCritic: "Critic Meal",
			phaseDone: "Final Scoring",
			priorityLabel: "Priority",
			starsCount: "{{n}} stars",
			waitingFor: "Waiting for {{name}}…",
			readyLabel: "Confirmed",
			you: "You",
			close: "Close",
			cancel: "Cancel",
			confirm: "Confirm",
			submit: "Submit",
			pick: "Take",
			remove: "Remove",
			none: "None",
			log: "Log",
			logEmpty: "No entries yet",
			kitchenTitle: "Your kitchen",
			soupLabel: "Soup",
			bisqueLabel: "Bisque",
			rumorLabel: "Rumor",
			coinLabel: "Gold coin",
			coffeeLabel: "Coffee",
			flowersLabel: "Flowers",
			trophyLabel: "Trophy",
			zousLabel: "Zous-chef",
			restaurateurLabel: "Restaurateur",
			criticLabel: "Critic",
			heldLabel: "Hold",
			itemTofu: "Tofu",
			itemOrganic: "Organic ingredient",
			itemZousIng: "Zous ingredient",
			itemMystery: "Mystery die",
			planClear: "Clear plan",
			spiceLabel: "Spice",
			allspiceLabel: "Allspice",
			ingredientLabel: "Ingredient",
			itemCount: "{{n}} items",
			noItems: "No items",
			tapForDetail: "Tap to view card",
			itemSpice: "{{type}} spice",
			itemSpiceAll: "Allspice",
			starUnit: "star",
			restTitle: "Choose a Restaurateur",
			restHint: "Keep one of two cards; its printed stars count toward your final score",
			restWaiting: "Waiting for {{name}} to choose a Restaurateur…",
			restChosen: "Chose {{name}}",
			restStars: "{{n}} final stars",
			planTitle: "Plan your chefs",
			planHint: "The three chefs need different locations; zous-chefs cannot share with them either",
			planChooseMarket: "Choose a market stall for this chef.",
			marketActive: "Shopping here",
			planChefLabel: "Chef {{n}}",
			planBreakTitle: "Chef on break",
			planBreakHint: "This round’s break number is {{n}}. The chef on break stays home; if the numbers match, you gain two soup",
			planBreakPick: "Choose the chef on break",
			planLocPlaceholder: "Choose a location",
			planZousTitle: "Zous-chefs",
			planZousPlaceholder: "Choose a location for {{name}}",
			planSubmit: "Confirm planning",
			planWaiting: "Confirmed, waiting for {{name}}…",
			planNeedChefs: "All three chefs need a location",
			planNeedZous: "A zous-chef still needs a location",
			shopTitle: "Shopping",
			shopActiveAt: "{{name}} is picking at {{loc}}",
			shopYouTurn: "Your turn to pick",
			shopCap: "Picked {{n}} / {{cap}}",
			shopQueueTitle: "Pick order",
			shopPickHint: "Tap an item to take it",
			shopLeave: "Leave",
			shopLeaveHint: "You may leave before picking anything and gain one soup",
			shopGiftTitle: "Gift box",
			shopGiftCost: "Pay one star to take the whole box",
			shopExtra: "Take one extra item",
			shopCoinTitle: "Gold coin",
			shopCoinUse: "Place a coin for an extra pick",
			shopCoinHint: "Once per location; the coin becomes an item others can pick",
			shopCoffeeTitle: "Coffee destination",
			shopCoffeeHint: "Choose where the chef moves",
			shopCoffeeCancel: "Cancel",
			shopWaiting: "Waiting for other players to shop…",
			shopEmptyLoc: "This location is empty",
			shopPendingCoffee: "Choose where the chef moves",
			challengeTitle: "Serve challenges",
			challengeHint: "At most one meal per Challenge Card; quality must reach 6",
			challengeRequired: "Requires {{types}}",
			challengeAddItem: "Add an ingredient",
			challengeAddSoup: "Replace with soup",
			challengeAddBisque: "Replace with bisque",
			challengeMealEmpty: "Nothing chosen yet",
			challengeQuality: "Quality {{n}}",
			challengeStars: "{{n}} stars",
			challengeTooWeak: "Quality below 6; cannot be served",
			challengeSubmit: "Submit meals",
			challengeWaiting: "Submitted, waiting for {{name}}…",
			challengeExtra: "Extra challenge",
			challengeRemove: "Remove",
			challengeAddSpice: "Add spice",
			challengeSpiceNone: "No spice",
			challengePickItem: "Choose an ingredient",
			challengePickSpice: "Choose spice",
			challengeTofuHint: "Tofu needs spice",
			challengeNeedTypes: "Missing {{types}}",
			challengeSoupUsed: "{{n}} soup used",
			challengeBisqueUsed: "{{n}} bisque used",
			criticTitle: "Critic meal",
			criticHint: "One ingredient per course and at most one spice; soup does not count, and tofu needs spice",
			criticCourse: "{{name}} course",
			criticEmpty: "Not served",
			criticAdd: "Choose ingredient",
			criticAddSpice: "Add spice",
			criticRemove: "Remove",
			criticQuality: "Quality {{n}}",
			criticExtraTitle: "Extra challenge meal (Hippo)",
			criticExtraNone: "No extra challenge meal",
			criticExtraAdd: "Prepare the extra challenge meal",
			criticSubmit: "Submit critic meal",
			criticWaiting: "Submitted, waiting for {{name}}…",
			criticQualityLabel: "Quality",
			criticSpiceNone: "No spice",
			fridgeTitle: "Refrigeration",
			fridgeHint: "Refrigerate up to {{n}} ingredients and spice; the rest return to the bag",
			fridgeKeep: "Refrigerate",
			fridgeDiscard: "Leave out",
			fridgeCount: "Selected {{n}} / {{limit}}",
			fridgeSubmit: "Confirm refrigeration",
			fridgeWaiting: "Confirmed, waiting for {{name}}…",
			fridgeOrganic: "Organic ingredients cannot be refrigerated and are discarded at the end of today",
			fridgeFlowers: "Flowers must be refrigerated and cannot be discarded",
			fridgeEmpty: "Nothing to handle",
			finalTitle: "Restaurant rankings",
			finalUnnamed: "Unnamed restaurant",
			finalRank: "Place {{n}}",
			finalBase: "Earned during play",
			finalBonus: "Bonuses and modifiers",
			finalTrack: "Quality track",
			finalQuality: "Seven-course quality {{n}}",
			finalQualityLabel: "Seven-course quality",
			finalTotal: "Total stars",
			finalWinner: "{{name}} wins",
			finalDraw: "Shared victory",
			finalHint: "Ties compare total critic-meal quality, then priority-track position",
			logRest: "{{name}} chose {{card}}",
			logPlan: "{{name}} finished planning",
			logPick: "{{name}} took {{item}} at {{loc}}",
			logRumor: "{{name}} viewed a Rumor Card",
			logSoup: "{{name}} gained {{n}} soup",
			logLeave: "{{name}} left {{loc}}",
			logGift: "{{name}} took a gift box",
			logCoin: "{{name}} placed a coin for an extra pick",
			logCoffee: "{{name}} took coffee and moved a chef",
			logZous: "{{name}} gained a zous-chef",
			logChallenge: "{{name}} served {{card}} with quality {{q}} for {{n}} stars",
			logFridge: "{{name}} finished refrigeration",
			logCritic: "{{name}} finished the critic meal",
			logStar: "{{name}} gained {{n}} stars",
			logRound: "Round {{n}} begins",
			logFinal: "Final scoring complete",
			optExpansion: "À La Cart expansion",
			optExpansionHint: "Adds carts, expansion cards, and six- and seven-player mode",
			optCarts: "Enable carts",
			optCartsHint: "Place carts at the Garden Top Shop, Desert Vendor, and Water Market",
			challenge0: "Street Eats",
			challenge1: "Savory Stack",
			challenge2: "Wine & Dine",
			challenge3: "Ultimate Melt",
			challenge4: "Tasty Tapas",
			challenge5: "Coastal Fusion",
			challenge6: "Comfort Food",
			critic0: "Mouse",
			criticText0: "When preparing the critic meal, your cheese course may include any number of cheese. When comparing the best quality of each course, cheese earns 2 extra stars.",
			critic1: "Badger",
			criticText1: "Throughout the game, you may use mushrooms as any ingredient, and use any spice on mushrooms.",
			critic2: "Capybara",
			criticText2: "Each challenge meal you serve earns 1 extra star.",
			critic3: "Cow",
			criticText3: "When preparing the critic meal, one course of your choice may include up to four ingredients of its type.",
			critic4: "Fruit Bat",
			criticText4: "When preparing the critic meal, each course may include one unspiced wine matching that course’s highest ingredient value. Gain 1 star for each course paired this way.",
			critic5: "Jerboa",
			criticText5: "When preparing the critic meal, Rumor Tokens may be used as allspice.",
			critic6: "Kangaroo",
			criticText6: "Throughout the game, treat 6-value ingredients as 9s.",
			critic7: "Poodle",
			criticText7: "Gain 1 star for each ingredient worth 6 or more before spice that is served to the critic.",
			critic8: "Rabbit",
			criticText8: "Throughout the game, the value of all carrots is doubled.",
			critic9: "Raccoon",
			criticText9: "Throughout the game, 2-value ingredients do not count toward your refrigeration limit and stay public. When preparing the critic meal, each course may also include any number of 2-value ingredients of its type.",
			critic10: "Saint Bernard",
			criticText10: "Throughout the game, wine ingredients may be used as allspice.",
			critic11: "Tree Shrew",
			criticText11: "Throughout the game, spice triples an ingredient’s value instead of doubling it.",
			critic12: "Hippo",
			criticText12: "Place the unused Challenge Card face up beside the Hippo for the whole game. At the end of each day, you may serve this extra challenge meal.",
			critic13: "Hyena",
			criticText13: "Throughout the game, 3-value ingredients do not count toward your refrigeration limit and stay public. When preparing the critic meal, your fish course may include 3-value ingredients up to your highest fish value.",
			critic14: "Pig",
			criticText14: "Throughout the game, spice does not count toward your refrigeration limit and stays public. When preparing the critic meal, each course may contain two ingredients of its type.",
			critic15: "Wolverine",
			criticText15: "Before shopping each round, gain 1 star for each location where you are the only player with a chef. This critic appears only in games with three or more players.",
			rest0: "Martha Shrewart",
			restText0: "Gain 2 stars for serving all three challenge meals in the same day.",
			rest1: "Anthony Boardain",
			restText1: "When you would gain a consolation soup, you may take one item from the bag instead.",
			rest2: "Bobcat Flay",
			restText2: "Your meat and fish ingredients are each worth 3 extra value for challenge meals.",
			rest3: "Falcon Brown",
			restText3: "Gain 1 star for each challenge meal containing exactly one of each required ingredient and no soup.",
			rest4: "Goat’n Ramsay",
			restText4: "Your 2-value ingredients are each worth 2 extra value for challenge meals.",
			rest5: "Graham Elephant",
			restText5: "Gain 1 star when you serve a challenge meal of quality 25 or higher.",
			rest6: "Heron Sanchez",
			restText6: "In challenge meals, one spice may apply to any number of ingredients of the same type.",
			rest7: "Jamie Owliver",
			restText7: "At the start of the game, draw an extra Rumor Card only you can see. It applies to every player.",
			rest8: "Julia Wild",
			restText8: "Throughout the game, you may use any spice as allspice.",
			rest9: "Marcus Roostersson",
			restText9: "At the end of each round, move forward once on the priority track. If you are already at the front, take one item from the bag instead.",
			rest10: "Guy Beari",
			restText10: "At the start of the game, gain a wild rumor token. For each Rumor Token you hold, add 1 to the quality of challenge meals you serve, up to 5.",
			rest11: "Alex Guarnashellfish",
			restText11: "Throughout the game, you may use 3-value ingredients as any type of your choice.",
			rest12: "Emeril Llamasse",
			restText12: "You may treat spice as a 5-value ingredient of that type instead of as spice. You may treat allspice as a 5-value ingredient of any type.",
			rest13: "Morimotter",
			restText13: "At the start of rounds 1, 4, and 7, draw a zous-chef to use that round.",
			rumor0: "Big Cheese",
			rumorText0: "Gain 3 stars if your highest cheese value is at least the number of courses you served.",
			rumor1: "Big Dipper",
			rumorText1: "Gain 2 stars if your remaining soup quality is at least your highest bread value. Soup counts as 1 and bisque as 3.",
			rumor2: "Bread Fanatic",
			rumorText2: "During final scoring, double the quality of your bread course.",
			rumor3: "Carrot Fanatic",
			rumorText3: "During final scoring, double the quality of your carrot course.",
			rumor4: "Cheese Fanatic",
			rumorText4: "During final scoring, double the quality of your cheese course.",
			rumor5: "Extremely Pampered",
			rumorText5: "Gain 2 stars if you serve all seven courses and each includes an ingredient worth 5 or more.",
			rumor6: "Fish Fanatic",
			rumorText6: "During final scoring, double the quality of your fish course.",
			rumor7: "Hibernator",
			rumorText7: "Gain 2 stars if your rightmost course is your highest-quality course.",
			rumor8: "Meat Fanatic",
			rumorText8: "During final scoring, double the quality of your meat course.",
			rumor9: "Mercurial",
			rumorText9: "Gain stars equal to the difference between your highest and lowest served ingredient values.",
			rumor10: "Mushroom Fanatic",
			rumorText10: "During final scoring, double the quality of your mushroom course.",
			rumor11: "Nocturnal",
			rumorText11: "Gain 5 stars if the highest-valued ingredient in each course is equal to or greater than the one to its left.",
			rumor12: "Odd Tastes",
			rumorText12: "Gain 3 stars if the highest-valued ingredient in each course is an odd number.",
			rumor13: "Picky",
			rumorText13: "Gain stars equal to your lowest served ingredient value if you serve all seven courses.",
			rumor14: "Psychedelic Flavor",
			rumorText14: "Gain 2 stars if your mushroom course is your highest-quality course.",
			rumor15: "Shortsighted",
			rumorText15: "Gain stars equal to your highest served carrot value minus 2.",
			rumor16: "Simple Palate",
			rumorText16: "The player who serves the most ingredients of the same value gains 3 stars.",
			rumor17: "Sommelier",
			rumorText17: "Gain 2 stars if your highest served wine and fish values match, and 2 more if your highest wine and meat values match.",
			rumor18: "Spice Lover",
			rumorText18: "The player who serves the most spiced items gains 2 stars.",
			rumor19: "Subtle Flavors",
			rumorText19: "The player who serves the most ingredients matching their highest bread value gains 3 stars.",
			rumor20: "Super Chatty",
			rumorText20: "Gain 1 star for each Rumor Token you have collected.",
			rumor21: "Tender",
			rumorText21: "Gain 3 stars if the highest-valued ingredients in your leftmost and rightmost courses add up to exactly 10.",
			rumor22: "To Go",
			rumorText22: "Gain 1 star for every two unserved ingredient or spice tokens, and 1 more for having the most.",
			rumor23: "Unsophisticated",
			rumorText23: "Gain 1 star for each unspiced single-ingredient course served, and 1 more for serving the most.",
			rumor24: "Varied Leftovers",
			rumorText24: "Gain 1 star for each different value among your unserved ingredients, and 1 more for having the most.",
			rumor25: "Varied Servings",
			rumorText25: "Gain 1 star for each different value among your served ingredients, and 1 more for serving the most.",
			rumor26: "Wine Cellar",
			rumorText26: "Gain 1 star for each unserved wine.",
			rumor27: "Wine Fanatic",
			rumorText27: "During final scoring, double the quality of your wine course.",
			zous100: "Carol Koala",
			zousText100: "After your last pick: if you are at the back of the priority track, gain 1 star.",
			zous101: "Chrissy Chipmunk",
			zousText101: "Start of Location: if Chrissy is alone, she picks three items instead of one.",
			zous102: "Dash Cheetah",
			zousText102: "Start of Location: move to the front of the priority track.",
			zous103: "Geoffrey Giraffe",
			zousText103: "Before your first pick: add one extra item from the bag to Geoffrey’s location.",
			zous104: "Ginger Fox",
			zousText104: "After your last pick: gain one item from the bag.",
			zous105: "Lily Frog",
			zousText105: "After your last pick: take the bisque from the Soup Truck; if there is no bisque, take one soup.",
			zous106: "Mandy Panda",
			zousText106: "After your last pick: Mandy picks one extra item from this location; if none is available, gain one from the bag.",
			zous107: "Ming Hummingbird",
			zousText107: "Start of Location: Ming picks before every other chef. Nobody changes priority-track position at this location.",
			zous108: "Newton Yorkie",
			zousText108: "After your last pick: if Newton picked the lowest-valued available ingredient, gain three soup.",
			zous109: "Otto Otter",
			zousText109: "Start of Location: if at least one other chef with capacity 2 is here, each of you gains one item from the bag.",
			zous110: "Penny Penguin",
			zousText110: "After your last pick: pick one extra item from the Soup Truck, including soup.",
			zous111: "Snooze Sloth",
			zousText111: "Start of Location: add two extra items from the bag to this location.",
			zous200: "Alex Alpaca",
			zousText200: "After your last pick: if Alex picked any bread ingredients, gain 1 star.",
			zous201: "Atticus Finch",
			zousText201: "After your last pick: Atticus may move to an unresolved location with no chefs and take another turn there.",
			zous202: "Billy Buffalo",
			zousText202: "Before your first pick: Billy may discard and replace up to three available ingredients or spice.",
			zous203: "Cecilia Python",
			zousText203: "After your last pick: for each meat ingredient Cecilia picked at this location, also gain one item from the bag.",
			zous204: "Donna Donkey",
			zousText204: "After your last pick: for each item Donna picked, gain one soup.",
			zous205: "Dottie Leopard",
			zousText205: "After your last pick: if Dottie could not pick three items, take three items from the Chef Academy, excluding the zous-chef.",
			zous206: "Emma Eagle",
			zousText206: "Start of Location: you may move to the back of the priority track so Emma picks before every chef here. If you do, Emma picks only one item.",
			zous207: "Finn Dolphin",
			zousText207: "Start of Location: if Finn is picked by a zous-chef or used to pick a zous-chef, gain 1 star.",
			zous208: "Hans Mole",
			zousText208: "After your last pick: draw five items from the bag, keep all mushroom ingredients, and return the rest.",
			zous209: "Hootly Owl",
			zousText209: "Start of Location: if Hootly is at the Midnight Merchant and fish ingredients or fish spice are revealed there, Hootly picks before every chef here.",
			zous210: "Lenore Raven",
			zousText210: "After your last pick: Lenore may pick one extra item; if she does, add two extra items from the bag to this location.",
			zous211: "Lulu Lemur",
			zousText211: "After your last pick: if Lulu picked wine, you may place it on your kitchen as a wild rumor instead of keeping it as an ingredient.",
			zous212: "Mack Shark",
			zousText212: "Start of Location: name an ingredient type. Every other chef here must give you an ingredient or spice of that type, or leave with one soup.",
			zous213: "Marie Butterfly",
			zousText213: "Start of Location: if Marie is not alone, you may gain 1 star instead of picking an item.",
			zous214: "Marty Fly",
			zousText214: "Before your first pick: if there are rumors at Marty’s location, place a soup on any matching empty rumor slot on your kitchen; you now know those rumors.",
			zous215: "Peter Parrot",
			zousText215: "Before your first pick: if there is spice at Peter’s location, Peter picks one extra item.",
			zous216: "Pocket Raccoon",
			zousText216: "After your last pick: if the Midnight Merchant is unresolved and you have no chef there, move Pocket there and take another turn.",
			zous217: "Queenie Bee",
			zousText217: "After your last pick: if Queenie was the first to pick at this location, gain one item from the bag.",
			zous218: "Richard Lion",
			zousText218: "Start of Location: mouse chefs at Richard’s location go after all other chefs.",
			zous219: "Shaggy Retriever",
			zousText219: "After your last pick: pick one extra item from this location for each Rumor Token on your kitchen.",
			zous220: "Skeeter Skunk",
			zousText220: "Start of Location: other chefs at Skeeter’s location pick only one item each, regardless of capacity.",
			zous221: "Spike Porcupine",
			zousText221: "Start of Location: if able, each other chef at Spike’s location must give you one non-soup item of their choice.",
			zous222: "Stripes Zebra",
			zousText222: "Start of Location: Stripes picks all his items before all other chefs of the same capacity. None of these chefs, including Stripes, change priority-track position.",
			zous223: "Syd Platypus",
			zousText223: "Before your first pick: if Syd is alone, gain two items from the bag.",
			cartCoffee: "Coffee",
			cartTextCoffee: "Each round, place one coffee on the cart. When a player picks the coffee, they immediately move that chef to an unresolved location where they have no chef and take another turn there; if they cannot do so fully, they cannot take the coffee. At the end of the game, the player with the most coffee loses 1 star. Coffee is public and does not need refrigeration.",
			cartFlowers: "Flowers",
			cartTextFlowers: "Each round, place one flower on the cart. The first player to pick an item from this location must also take all the flowers. Flowers can never be discarded. At the end of each day, the player with the most flowers gains 1 star. Flowers must be refrigerated.",
			cartTrophies: "Trophies",
			cartTextTrophies: "Each round, reveal one trophy on the cart. Trophies are picked like other items. At the end of the game, if a player earns the best in a course and holds the matching trophy, they gain 1 extra star. Trophies are public and do not need refrigeration.",
			cartGift: "Gift",
			cartTextGift: "Every player starts with 1 star. Two- and three-player games use one gift box; four or more players use two. Each round, add two items to each gift box. A player may pay 1 star to take everything in one gift box, counting as one item for carrying capacity. Gift boxes are not cleared at the end of the round. Ingredients and spice gained must be refrigerated.",
			cartCoin: "Gold Coins",
			cartTextCoin: "Each round, place one gold coin on the cart. Gold coins are picked like other items. After picking an item, a player may place one of their own coins at that location to immediately pick one extra item, once per location; the placed coin becomes an item others can pick. At the end of the game, each two coins are worth 1 star, and the player with the most gains 1 more. Gold coins are public and do not need refrigeration.",
			cartMystery: "Mystery Box",
			cartTextMystery: "Each round, place the Mystery Die on the cart. It is picked like any other item but is immediately rolled and removed from the location; the player who rolled it gains items from the bag equal to the result. Taking the die counts as picking one item regardless of the roll. Ingredients and spice gained must be refrigerated.",
			cartOrganic: "Organic",
			cartTextOrganic: "Each round, reveal one organic ingredient on the cart. Organic ingredients are picked like other items but cannot be refrigerated; if unused in a challenge or critic meal by the end of the day, they are discarded.",
			cartTofu: "Tofu",
			cartTextTofu: "Each round, reveal one tofu on the cart. Tofu is picked like other items. It can be served only when paired with spice, and then counts as an ingredient of that spice’s type with its value doubled; with allspice, tofu may be any type. Tofu must be refrigerated.",
			cartZousToo: "Zous Too",
			cartTextZousToo: "Each round, in addition to drawing a zous-chef for the Chef Academy, draw one for this cart with its matching token and two zous ingredient tokens. The cart works like the Chef Academy’s zous-chef: players may pick the ingredient or chef like any other item. Zous ingredients work like standard ingredients. This cart can let a player have more than one zous-chef in the next round.",
			ingBread: "Bread",
			ingCarrot: "Carrot",
			ingCheese: "Cheese",
			ingFish: "Fish",
			ingMeat: "Meat",
			ingMushroom: "Mushroom",
			ingWine: "Wine",
			locSoup: "Soup Truck",
			locGarden: "Garden Top Shop",
			locDesert: "Desert Vendor",
			locWater: "Water Market",
			locAir: "Air Docks",
			locLantern: "Lantern Lane",
			locMidnight: "Midnight Merchant",
			locAcademy: "Chef Academy",
			chef1: "Mouse chef",
			chef2: "Lizard chef",
			chef3: "Boar chef",
			errPhase: "That action is not available now",
			errReady: "You have already confirmed",
			errNotPlayer: "You are not in this game",
			errOffer: "That Restaurateur Card is not one of your choices",
			errPlan: "The three chefs must go to three different locations",
			errZous: "That zous-chef cannot go to that location",
			errTurn: "It is not your turn",
			errNoItem: "That item is not available to pick",
			errRumorSlot: "That rumor slot cannot be used",
			errCoffeeDest: "That location cannot be the coffee destination",
			errLeaveAfterPick: "After picking, you must continue until capacity or the location is empty",
			errGiftEmpty: "That gift box has no items",
			errNoStar: "Not enough stars",
			errNoCoin: "No gold coin to place",
			errCoinUsed: "A coin has already been used at this location",
			errNeedPick: "Pick an item first",
			errMealTofu: "Tofu must be paired with spice",
			errMealSpice: "That spice cannot be used this way",
			errMealDup: "The same item cannot be used twice",
			errMealSoup: "Soup can only replace a missing required ingredient type",
			errMealType: "That ingredient type does not fit this dish",
			errMealMissing: "A required ingredient is still missing",
			errMealChallenge: "That dish is not one of the available challenges",
			errMealTooMany: "That dish has too many ingredients",
			errMealQuality: "A meal with quality below 6 cannot be served",
			errMealItem: "That ingredient or spice is unavailable",
			errMealCount: "The number of meals does not follow the rules",
			errFridgeItem: "That item cannot be refrigerated",
			errFridgeLimit: "That is over the refrigeration limit",
			errWinePair: "That wine cannot be paired this way"
		}
	}
};
//#endregion
export { mi as default };
