import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { useT as u } from "@bgparty/sdk/i18n";
import { IconClose as d, IconLayoutCover as f, IconMove as p, IconPile as m } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as h } from "@bgparty/sdk/player-colors";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as v } from "@bgparty/sdk/assets";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { usePrefersReducedMotion as S } from "@bgparty/sdk/fx/use-reduced-motion";
import { useFrame as C, useThree as ee } from "@react-three/fiber";
import { ACESFilmicToneMapping as w, BackSide as te, BoxGeometry as T, BufferAttribute as E, BufferGeometry as D, CapsuleGeometry as O, Color as k, CylinderGeometry as ne, DirectionalLight as re, DoubleSide as ie, FogExp2 as ae, Group as A, HemisphereLight as oe, IcosahedronGeometry as se, InstancedMesh as ce, Mesh as le, MeshBasicMaterial as ue, MeshStandardMaterial as j, Object3D as de, Plane as fe, PlaneGeometry as pe, Raycaster as me, Scene as he, ShaderMaterial as ge, SphereGeometry as _e, Vector2 as ve, Vector3 as M } from "three";
import { ResilientCanvas as ye } from "@bgparty/sdk/three/resilient-canvas";
import { ConfirmButton as be } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as xe, OptionSection as Se } from "@bgparty/sdk/ui/game-options";
var N = Object.fromEntries([
	{
		id: 0,
		name: "Lake District",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 1,
		name: "Picos de Europa",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 2,
		name: "Vatnajökull",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 3,
		name: "Calanques",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 4,
		name: "Samaria",
		suit: "purple",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 5,
		name: "Rila",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 6,
		name: "Jotunheimen",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 3,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 7,
		name: "Cinque Terre",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 2,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 8,
		name: "Tatra",
		suit: "purple",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 9,
		name: "Swiss National Park",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 10,
		name: "Loch Lomond & The Trossachs",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 11,
		name: "Jostedalsbreen",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 12,
		name: "Connemara",
		suit: "teal",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 13,
		name: "Hardangervidda",
		suit: "teal",
		points: 4,
		cost: {
			forest: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 14,
		name: "Theth",
		suit: "teal",
		points: 5,
		cost: {
			forest: 3,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 15,
		name: "Triglav",
		suit: "teal",
		points: 5,
		cost: {
			forest: 2,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 16,
		name: "Berchtesgaden",
		suit: "teal",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 17,
		name: "Retezat",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 18,
		name: "Abruzzo, Lazio e Molise",
		suit: "purple",
		points: 2,
		cost: {
			mountain: 1,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 19,
		name: "Arcipelago di La Maddalena",
		suit: "purple",
		points: 2,
		cost: {
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 20,
		name: "Göreme",
		suit: "orange",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 21,
		name: "Pyrénées",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 1,
			sun: 2,
			any: 2
		}
	},
	{
		id: 22,
		name: "Sarek",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 3,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 23,
		name: "Timanfaya",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 2,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 24,
		name: "Dolomiti Bellunesi",
		suit: "orange",
		points: 5,
		cost: { mountain: 3 }
	},
	{
		id: 25,
		name: "Hohe Tauern",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 26,
		name: "Thingvellir",
		suit: "teal",
		points: 2,
		cost: {
			forest: 1,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 27,
		name: "Wadden Sea",
		suit: "teal",
		points: 2,
		cost: { water: 4 },
		instant: "mug"
	},
	{
		id: 28,
		name: "Pirin",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 29,
		name: "Oulanka",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 30,
		name: "Killarney",
		suit: "lime",
		points: 5,
		cost: {
			forest: 3,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 31,
		name: "Durmitor",
		suit: "lime",
		points: 5,
		cost: {
			forest: 2,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 32,
		name: "Gauja",
		suit: "lime",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 33,
		name: "Doñana",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 34,
		name: "Écrins",
		suit: "orange",
		points: 2,
		cost: {
			mountain: 1,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 35,
		name: "Vikos-Aoös",
		suit: "orange",
		points: 2,
		cost: { sun: 4 },
		instant: "photo"
	},
	{
		id: 36,
		name: "Olympus",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 37,
		name: "Ordesa y Monte Perdido",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 38,
		name: "Plitvice Lakes",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 2,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 39,
		name: "Teide",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 40,
		name: "Peneda-Gerês",
		suit: "lime",
		points: 2,
		cost: {
			forest: 1,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 41,
		name: "Gesäuse",
		suit: "lime",
		points: 2,
		cost: { sun: 4 },
		instant: "die"
	},
	{
		id: 42,
		name: "Krka",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 43,
		name: "Abisko",
		suit: "lime",
		points: 4,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 44,
		name: "Saxon Switzerland",
		suit: "lime",
		points: 3,
		cost: {
			forest: 2,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 45,
		name: "Butrint",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 46,
		name: "Cairngorms",
		suit: "lime",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 47,
		name: "Peak District",
		suit: "lime",
		points: 4,
		cost: {
			forest: 1,
			sun: 2,
			any: 2
		}
	}
].map((e) => [e.id, e])), P = [
	"lime",
	"orange",
	"teal",
	"purple"
], Ce = {
	lime: "wildlife",
	orange: "photo",
	teal: "mug",
	purple: "wonder"
}, we = [
	"sun",
	"mountain",
	"water",
	"forest"
], Te = {
	sun: { sun: 2 },
	mountain: { mountain: 1 },
	water: { water: 2 },
	forest: { forest: 1 }
}, Ee = [
	{
		name: "Biodiversity Restoration",
		benefit: "die"
	},
	{
		name: "Field Research",
		benefit: "parks"
	},
	{
		name: "Heritage Site Restoration",
		benefit: "mug"
	},
	{
		name: "Light Pollution Reduction",
		benefit: "wonder"
	},
	{
		name: "Nature Photography",
		benefit: "photo"
	},
	{
		name: "Species Protection",
		benefit: "wildlife"
	},
	{
		name: "Trail Maintenance",
		benefit: "carabiner"
	}
], F = (e) => we[Math.floor(e / 7)], I = (e, t = 1) => ({
	t: "res",
	res: e,
	n: t
}), De = (e = 1) => ({
	t: "carabiner",
	n: e
}), Oe = [
	{
		id: "b01",
		no: 1,
		name: "Take a Wild Ride",
		art: "w01",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [De(2)]
		}
	},
	{
		id: "b02",
		no: 2,
		name: "Savor the Sunrise",
		art: "w02",
		top: { grants: [I("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [I("forest"), I("water")]
		}
	},
	{
		id: "b03",
		no: 3,
		name: "Bask in the Light",
		art: "w03",
		top: { grants: [I("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [I("mountain"), I("water")]
		}
	},
	{
		id: "b04",
		no: 4,
		name: "Enjoy the Forests",
		art: "w04",
		top: { grants: [I("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [{
				t: "photo",
				n: 1
			}, I("sun")]
		}
	},
	{
		id: "b05",
		no: 5,
		name: "Walk in the Woods",
		art: "w05",
		top: { grants: [I("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [I("wildlife"), I("sun")]
		}
	},
	{
		id: "b06",
		no: 6,
		name: "Take a Hike Bike",
		art: "w06",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [I("wildlife")] }
	},
	{
		id: "b07",
		no: 7,
		name: "Explore the Backcountry",
		art: "w07",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [I("wildlife", 2)]
		}
	},
	{
		id: "b08",
		no: 8,
		name: "Clear Skies, Full Hearts",
		art: "w08",
		top: { grants: [I("sun", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b09",
		no: 9,
		name: "Protect the Peaks",
		art: "w09",
		top: { grants: [I("mountain")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b10",
		no: 10,
		name: "Reflect on the Journey",
		art: "w10",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "mug" }, { t: "mug" }]
		}
	},
	{
		id: "b11",
		no: 11,
		name: "Trail Magic",
		art: "w11",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{ t: "mug" }] }
	},
	{
		id: "b12",
		no: 12,
		name: "Take a Dip",
		art: "w12",
		top: { grants: [I("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [I("forest"), I("sun")]
		}
	},
	{
		id: "b13",
		no: 13,
		name: "Ford a Mountain Stream",
		art: "w13",
		top: { grants: [I("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [I("mountain"), I("sun")]
		}
	},
	{
		id: "b14",
		no: 14,
		name: "Clip In and Climb",
		art: "w14",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [De()] }
	},
	{
		id: "b16",
		no: 16,
		name: "Capture the Moment",
		art: "w16",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "shutterbug" }, {
				t: "photo",
				n: 1
			}]
		}
	},
	{
		id: "b17",
		no: 17,
		name: "Ramble Along",
		art: "w17",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{
			t: "photo",
			n: 1
		}] }
	},
	{
		id: "b18",
		no: 18,
		name: "Ascend the Mountain",
		art: "w18",
		top: { grants: [I("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [De(), I("water")]
		}
	},
	{
		id: "b19",
		no: 19,
		name: "Scale the Summit",
		art: "w19",
		top: { grants: [I("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [{ t: "mug" }, I("water")]
		}
	},
	{
		id: "b20",
		no: 20,
		name: "Preserve the Trees",
		art: "w20",
		top: { grants: [I("forest")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b21",
		no: 21,
		name: "Clean the Riverbanks",
		art: "w21",
		top: { grants: [I("water", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	}
], ke = [
	{
		id: "c01",
		no: 1,
		art: "w15",
		effect: "consForest"
	},
	{
		id: "c02",
		no: 2,
		art: "w36",
		effect: "consMountain"
	},
	{
		id: "c03",
		no: 3,
		art: "w29",
		effect: "consSun"
	},
	{
		id: "c04",
		no: 4,
		art: "w30",
		effect: "consWater"
	},
	{
		id: "c05",
		no: 5,
		art: "w31",
		effect: "iconForest"
	},
	{
		id: "c06",
		no: 6,
		art: "w32",
		effect: "iconMountain"
	},
	{
		id: "c07",
		no: 7,
		art: "w33",
		effect: "iconSun"
	},
	{
		id: "c08",
		no: 8,
		art: "w34",
		effect: "iconWater"
	},
	{
		id: "c09",
		no: 9,
		art: "w35",
		effect: "anyIcons"
	},
	{
		id: "c10",
		no: 10,
		art: "w22",
		effect: "album"
	},
	{
		id: "c11",
		no: 11,
		art: "w23",
		effect: "wonderHand"
	},
	{
		id: "c12",
		no: 12,
		art: "w24",
		effect: "snow"
	},
	{
		id: "c13",
		no: 13,
		art: "w25",
		effect: "turnWildlife2"
	},
	{
		id: "c14",
		no: 14,
		art: "w26",
		effect: "turnAny2"
	},
	{
		id: "c15",
		no: 15,
		art: "w27",
		effect: "turnCarabiner"
	},
	{
		id: "c16",
		no: 16,
		art: "w28",
		effect: "turnAny3"
	}
], Ae = Object.fromEntries(Oe.map((e) => [e.id, e])), L = Object.fromEntries(ke.map((e) => [e.id, e]));
[...Oe.map((e) => e.id), ...ke.map((e) => e.id)];
var je = [
	{
		id: "cliffs",
		name: "Season of Cliffs",
		pattern: [
			"water",
			"water",
			"sun",
			"sun",
			"sun",
			"water"
		],
		fires: [
			1,
			7,
			5
		],
		display: {
			zone: "cons",
			token: "carabiner"
		}
	},
	{
		id: "swimming",
		name: "Season of Swimming",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"water",
			"water"
		],
		fires: [
			6,
			4,
			3
		],
		display: {
			zone: "parks",
			token: "water"
		}
	},
	{
		id: "memories",
		name: "Season of Memories",
		pattern: [
			"sun",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			2,
			6
		],
		display: {
			zone: "cons",
			token: "photo"
		}
	},
	{
		id: "sun",
		name: "Season of Sun",
		pattern: [
			"sun",
			"sun",
			"water",
			"sun",
			"sun",
			"sun"
		],
		fires: [
			5,
			3,
			2
		],
		display: {
			zone: "parks",
			token: "sun"
		}
	},
	{
		id: "dreams",
		name: "Season of Dreams",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			7,
			1
		],
		display: {
			zone: "parks",
			token: "snow"
		}
	},
	{
		id: "joy",
		name: "Season of Joy",
		pattern: [
			"sun",
			"water",
			"forest",
			"mountain",
			"wildlife",
			"sun"
		],
		fires: [
			7,
			1,
			3
		]
	},
	{
		id: "scouting",
		name: "Season of Scouting",
		pattern: [
			"sun",
			"sun",
			"wildlife",
			"wildlife",
			"wildlife",
			"water"
		],
		fires: [
			7,
			5,
			2
		]
	},
	{
		id: "growth",
		name: "Season of Growth",
		pattern: [
			"sun",
			"water",
			"forest",
			"sun",
			"forest",
			"forest"
		],
		fires: [
			5,
			6,
			7
		]
	},
	{
		id: "climbing",
		name: "Season of Climbing",
		pattern: [
			"sun",
			"water",
			"sun",
			"carabiner",
			"carabiner",
			"carabiner"
		],
		fires: [
			1,
			3,
			6
		]
	},
	{
		id: "caves",
		name: "Season of Caves",
		pattern: [
			"water",
			"sun",
			"mountain",
			"mountain",
			"water",
			"mountain"
		],
		fires: [
			3,
			2,
			1
		]
	},
	{
		id: "meadows",
		name: "Season of Meadows",
		pattern: [
			"sun",
			"photo",
			"sun",
			"photo",
			"sun",
			"photo"
		],
		fires: [
			2,
			4,
			5
		]
	},
	{
		id: "ice",
		name: "Season of Ice",
		pattern: [
			"snow",
			"water",
			"snow",
			"water",
			"snow",
			"water"
		],
		fires: [
			3,
			5,
			6
		]
	}
];
Object.fromEntries(je.map((e, t) => [t, e]));
var Me = [
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water"
], Ne = [
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
], Pe = {
	"core-forest": "forest",
	"core-sun": "sun",
	"core-mountain": "mountain",
	"core-water": "water"
};
function Fe(e) {
	return Pe[e] ?? null;
}
var Ie = [
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
], Le = [
	{
		ranger: "butterfly",
		symbols: 1,
		carabiner: 1
	},
	{
		ranger: "butterfly",
		symbols: 1,
		res: { wildlife: 1 }
	},
	{
		ranger: "butterfly",
		symbols: 2,
		res: {
			mountain: 1,
			water: 1
		}
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "wonder"
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "photo"
	},
	{
		ranger: "flower",
		symbols: 2,
		res: {
			sun: 1,
			forest: 1
		}
	}
], R = [
	{ t: "start" },
	{ t: "snow" },
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: 0,
		solo: 3
	},
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: null,
		solo: 4
	},
	{ t: "snow" },
	{ t: "snow" },
	{
		t: "award",
		stack: 1,
		solo: 5
	},
	{ t: "snow" },
	{ t: "snow" },
	{ t: "end" }
], Re = R.length - 1, ze = [
	"conservation",
	"carabiner",
	"mug",
	"chalet"
], Be = {
	mountain: 16,
	forest: 16,
	sun: 22,
	water: 22,
	wildlife: 14,
	snow: 20
}, Ve = [
	{
		at: 50,
		rank: 5
	},
	{
		at: 45,
		rank: 4
	},
	{
		at: 40,
		rank: 3
	},
	{
		at: 35,
		rank: 2
	},
	{
		at: 30,
		rank: 1
	}
], He = {
	id: "parkseurope",
	uuid: "57ea4f6d-4e67-4904-8ef4-ab6f134dd492",
	tier: "alpha",
	mechanics: [
		"set-collection",
		"hand-management",
		"engine-building",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.parkseurope.name",
	descKey: "games.parkseurope.desc",
	rulesKey: "games.parkseurope.rules",
	icon: "🏞️",
	iconImg: "games/parkseurope.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#3f7a4d",
	releasedAt: "2026-11-24T05:21:41+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, Ue = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
];
function We(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		wildlife: t.wildlife ?? 0
	};
	for (let r of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) {
		let i = t[r] ?? 0;
		n[r] = Math.min(e[r], i), n.wildlife += i - n[r];
	}
	if (n.wildlife > e.wildlife) return null;
	let r = t.any ?? 0;
	for (let t of Ue) {
		if (r === 0) break;
		let i = Math.min(r, e[t] - n[t]);
		n[t] += i, r -= i;
	}
	return r === 0 ? n : null;
}
//#endregion
//#region src/game/schema.ts
var Ge = t.enum([
	"lime",
	"orange",
	"teal",
	"purple",
	"wild"
]), Ke = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow"
]), qe = t.enum([
	"conservation",
	"carabiner",
	"mug",
	"chalet"
]), Je = t.enum([
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water",
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
]), Ye = t.enum([
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
]), Xe = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow",
	"photo",
	"carabiner"
]), Ze = t.partialRecord(Ke, t.int().nonnegative()), Qe = t.partialRecord(t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
]), t.int().nonnegative().max(3)), z = t.union([
	t.object({
		kind: t.literal("top"),
		action: qe
	}),
	t.object({
		kind: t.literal("both"),
		action: qe
	}),
	t.object({ kind: t.literal("parks") })
]), $e = t.union([
	t.object({
		type: t.literal("move"),
		hiker: t.union([t.literal(0), t.literal(1)]),
		to: t.int().min(1).max(8),
		campfire: t.enum(["communal", "card"]).optional(),
		card: t.string().optional(),
		slot: z.optional()
	}),
	t.object({ type: t.literal("siteAction") }),
	t.object({
		type: t.literal("activateCons"),
		card: t.int().nonnegative()
	}),
	t.object({ type: t.literal("endTop") }),
	t.object({ type: t.literal("endParks") }),
	t.object({ type: t.literal("viaFerrata") }),
	t.object({
		type: t.literal("reserve"),
		from: t.enum(["display", "deck"]),
		index: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("visit"),
		parkId: t.int().nonnegative(),
		pay: Ze.optional()
	}),
	t.object({ type: t.literal("parksDone") }),
	t.object({
		type: t.literal("mug"),
		act: t.enum(["fill", "drink"])
	}),
	t.object({
		type: t.literal("mugChoice"),
		choice: t.enum(["chalet", "cons"])
	}),
	t.object({
		type: t.literal("consPick"),
		index: t.int().nonnegative().optional(),
		deck: t.boolean().optional()
	}),
	t.object({
		type: t.literal("assignWild"),
		suit: t.enum([
			"lime",
			"orange",
			"teal",
			"purple"
		])
	}),
	t.object({
		type: t.literal("freePark"),
		parkId: t.int().nonnegative().optional(),
		from: t.enum([
			"display",
			"reserve",
			"deck"
		])
	}),
	t.object({
		type: t.literal("playWonder"),
		card: t.string(),
		side: t.enum(["top", "bottom"]),
		pay: Ze.optional()
	}),
	t.object({
		type: t.literal("discardRes"),
		res: t.enum([
			"mountain",
			"forest",
			"sun",
			"water",
			"wildlife"
		])
	}),
	t.object({
		type: t.literal("discardWonder"),
		card: t.string()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("gretaColor"),
		first: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("campfireEnd"),
		card: t.string(),
		pay: Qe.optional(),
		carabiner: t.boolean().optional()
	}),
	t.object({ type: t.literal("scoringDone") })
]), et = t.object({ greta: t.boolean().default(!1) }).prefault({}), tt = t.object({
	id: t.int().nonnegative(),
	suit: Ge.nullable()
}), nt = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	res: t.record(t.enum([
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]), t.int().nonnegative()),
	snow: t.int().nonnegative(),
	carabiners: t.int().nonnegative(),
	mug: t.int().min(0).max(3),
	photos: t.int().nonnegative(),
	albums: t.int().nonnegative(),
	photosTaken: t.int().nonnegative(),
	visited: t.array(tt),
	reserved: t.array(t.int().nonnegative()),
	cons: t.array(t.int().nonnegative()),
	parkAwards: t.record(t.enum([
		"lime",
		"orange",
		"teal",
		"purple"
	]), t.int().nonnegative()),
	consAwards: t.int().nonnegative(),
	chaletAwards: t.array(t.int().nonnegative()),
	wonderCount: t.int().nonnegative(),
	shutterbug: t.boolean(),
	chaletPos: t.int().nonnegative(),
	chaletOrder: t.int(),
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	endUsed: t.array(t.string()),
	endPoints: t.int().nonnegative()
}), rt = t.object({
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	solo: t.boolean()
}), it = t.object({
	kind: t.enum(["top", "both"]),
	action: qe,
	rid: t.string().nullable()
}), at = t.object({
	phase: t.enum([
		"turn",
		"scoring",
		"ended"
	]),
	season: t.int().min(1).max(3),
	turn: t.string().nullable(),
	moved: t.boolean(),
	pending: t.enum([
		"move",
		"trailEnd",
		"actions",
		"parks",
		"mug",
		"mugChoice",
		"cons",
		"assignWild",
		"freePark",
		"discardRes",
		"discardWonder",
		"gretaColor",
		"scoring",
		"none"
	]),
	freeCons: t.boolean(),
	landingSite: t.int().min(1).max(7).nullable(),
	siteDone: t.boolean(),
	consUsed: t.array(t.int().nonnegative()),
	vfUsed: t.boolean(),
	end: t.object({
		action: qe.nullable(),
		topDone: t.boolean(),
		parksDone: t.boolean()
	}).nullable(),
	seasonCard: t.string(),
	order: t.array(t.string()),
	players: t.array(nt),
	trailSites: t.array(Je),
	trailBonus: t.array(Xe.nullable()),
	campfires: t.array(t.int().nonnegative()),
	vf: t.array(Ye.nullable()),
	parksDisplay: t.array(t.int().nonnegative()),
	parksDeck: t.int().nonnegative(),
	parksBonus: t.array(Xe.nullable()),
	consDisplay: t.array(t.int().nonnegative()),
	consDeck: t.int().nonnegative(),
	consBonus: t.array(Xe.nullable()),
	consAwardsLeft: t.int().nonnegative(),
	chaletStacks: t.array(t.array(t.int().nonnegative())),
	endSlots: t.array(it),
	parksEndOccupied: t.boolean(),
	greta: rt.nullable(),
	soloRanks: t.array(t.object({
		at: t.int().nonnegative(),
		rank: t.int().nonnegative()
	})).nullable(),
	revealedCampfire: t.array(t.object({
		rid: t.string(),
		cards: t.array(t.string())
	})).nullable(),
	campfireUsed: t.array(t.string()),
	finalRows: t.array(t.object({
		rid: t.string(),
		parks: t.int(),
		campfire: t.int(),
		endgame: t.int(),
		photos: t.int(),
		parkAwards: t.int(),
		cons: t.int(),
		chalet: t.int(),
		photoAward: t.int(),
		total: t.int()
	})).nullable()
}), ot = t.object({
	hand: t.array(t.string()),
	isTurn: t.boolean()
}), B = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], V = (e, t) => ({
	code: `games.parkseurope.err.${e}`,
	...t ? { params: t } : {}
});
function H(t, n, r) {
	let i = r;
	for (let r = t.length - 1; r > 0; r--) {
		let a = e(n, i++, r + 1);
		[t[r], t[a]] = [t[a], t[r]];
	}
	return {
		items: t,
		cursor: i
	};
}
function U(e, t, n) {
	return {
		seat: e,
		res: {
			mountain: 0,
			forest: 0,
			sun: 0,
			water: 0,
			wildlife: 0
		},
		snow: 0,
		carabiners: 1,
		mug: 0,
		photos: 0,
		albums: 0,
		photosTaken: 0,
		visited: [],
		reserved: [],
		cons: [],
		parkAwards: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		consAwards: 0,
		consSets: 0,
		chaletAwards: [],
		wonderHand: [t],
		shutterbug: !1,
		chaletPos: 0,
		chaletOrder: n,
		hikers: [0, 0],
		slots: [null, null],
		sets: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		endUsed: [],
		endPoints: 0
	};
}
function W(e, t, n, r) {
	let i = Math.min(r, e.supply[n]);
	i <= 0 || (e.supply[n] -= i, t.res[n] += i);
}
function st(e, t, n) {
	let r = Math.min(n, e.supply.snow);
	r <= 0 || (e.supply.snow -= r, t.snow += r);
}
function ct(e, t, n) {
	let r = Math.min(n, e.supply.carabiner);
	r <= 0 || (e.supply.carabiner -= r, t.carabiners += r);
}
function lt(e, t, n) {
	for (t.photosTaken += n, t.photos += n; t.photos >= 5 && t.albums < 8;) t.photos -= 5, t.albums += 1;
}
function ut(e, t, n) {
	for (let r = 0; r < n; r++) {
		if (e.wonderDeck.length === 0) {
			if (e.wonderDiscard.length === 0) return;
			let t = H(e.wonderDiscard.slice(), e.seed, e.cursor);
			e.wonderDeck = t.items, e.cursor = t.cursor, e.wonderDiscard = [];
		}
		let n = e.wonderDeck.pop();
		n && t.wonderHand.push(n);
	}
}
function dt(e, t) {
	for (let t of e.order) e.players[t].shutterbug = !1;
	t && e.players[t] && (e.players[t].shutterbug = !0);
}
function ft(e) {
	let t = e.snow * 2;
	for (let n of B) t += e.res[n];
	return t;
}
function pt(e, t) {
	if (t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] > 0 && --e.supply[n];
}
function mt(e, t) {
	if (!t || t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] += 1;
}
function ht(e, t, n) {
	n === "photo" ? lt(e, t, 1) : n === "carabiner" ? t.carabiners += 1 : n === "snow" ? t.snow += 1 : t.res[n] += 1;
}
function gt(e, t, n) {
	let r = (e) => e.some((e) => e !== null && e.kind !== "parks" && e.kind === t && e.action === n);
	for (let t of e.order) if (r(e.players[t].slots)) return !0;
	return !!(e.greta && r(e.greta.slots));
}
function _t(e, t, n) {
	let r = We(t.res, n);
	if (!r) return !1;
	for (let n of B) t.res[n] -= r[n], e.supply[n] += r[n];
	return !0;
}
function G(e, t) {
	e.tasks.push(t);
}
function vt(t, n) {
	let r = Le[e(t.seed, t.cursor++, Le.length)];
	if (r.carabiner && ct(t, n, r.carabiner), r.res) for (let e of B) r.res[e] && W(t, n, e, r.res[e]);
	r.grant === "wonder" && ut(t, n, 1), r.grant === "photo" && lt(t, n, 1 + +!!n.shutterbug);
}
function yt(e, t, n) {
	switch (n) {
		case "die":
			vt(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "wonder":
			ut(e, t, 1);
			break;
		case "photo":
			lt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			W(e, t, "wildlife", 1);
			break;
		case "carabiner": ct(e, t, 1);
	}
}
function bt(e, t, n) {
	switch (n.t) {
		case "res":
			W(e, t, n.res, n.n);
			break;
		case "snow":
			st(e, t, n.n);
			break;
		case "carabiner":
			ct(e, t, n.n);
			break;
		case "photo":
			lt(e, t, n.n + +!!t.shutterbug);
			break;
		case "wonder":
			ut(e, t, n.n);
			break;
		case "die":
			for (let r = 0; r < n.n; r++) vt(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "cons":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "chalet":
			Ct(e, t);
			break;
		case "shutterbug": dt(e, e.turn ?? xt(e, t));
	}
}
function xt(e, t) {
	for (let n of e.order) if (e.players[n] === t) return n;
	return null;
}
function St(e, t, n) {
	if (n === "snow") {
		st(e, t, 1);
		return;
	}
	if (n === "chalet") {
		Ct(e, t);
		return;
	}
	yt(e, t, n);
}
function Ct(e, t) {
	let n = t.snow;
	if (n <= 0) return;
	e.supply.snow += n, t.snow = 0;
	let r = t.chaletPos, i = r, a = n;
	for (; a > 0 && i < Re;) i += 1, R[i].t === "snow" && --a;
	for (let n = r + 1; n <= i; n++) {
		let r = R[n];
		r.t === "wonder" ? ut(e, t, 1) : r.t === "award" && Tt(e, t, n, r);
	}
	t.chaletPos = i, t.chaletOrder = wt(e, i) + 1, e.chaletSeq = t.chaletOrder;
}
function wt(e, t) {
	let n = -1;
	for (let r of e.order) {
		let i = e.players[r];
		i.chaletPos === t && (n = Math.max(n, i.chaletOrder));
	}
	return n;
}
function Tt(e, t, n, r) {
	let i = !1;
	if (e.solo) e.chaletClaimed[n] || (e.chaletClaimed[n] = !0, t.chaletAwards.push(r.solo), i = !0);
	else if (r.stack !== null) {
		let n = e.chaletStacks[r.stack].pop();
		n !== void 0 && (t.chaletAwards.push(n), i = !0);
	}
	if (!i) {
		ut(e, t, 1);
		return;
	}
	e.solo && ut(e, t, 1);
}
function Et(e, t) {
	let n = 0;
	for (let r of e.order) for (let i of e.players[r].hikers) i === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function Dt(e, t, n) {
	let r = e.trailBonus[n];
	r && (e.trailBonus[n] = null, ht(e, t, r));
}
function Ot(e, t, n) {
	switch (n) {
		case "core-forest":
			W(e, t, "forest", 1);
			break;
		case "core-sun":
			W(e, t, "sun", 2);
			break;
		case "core-mountain":
			W(e, t, "mountain", 1), st(e, t, 1);
			break;
		case "core-water":
			W(e, t, "water", 2), st(e, t, 1);
			break;
		case "wildlife":
			W(e, t, "wildlife", 1);
			break;
		case "carabiner":
			ct(e, t, 1);
			break;
		case "die":
			vt(e, t);
			break;
		case "photo":
			lt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wonder":
			ut(e, t, 1);
			break;
		case "chalet":
			Ct(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "conservation": G(e, {
			t: "cons",
			free: !1
		});
	}
}
function kt(e, t, n) {
	if (e.landingSite === null) return V("noConsSite");
	let r = Fe(e.trailSites[e.landingSite - 1]);
	if (!r) return V("noConsSite");
	let i = t.cons[n];
	return i === void 0 || F(i) !== r ? V("badCons") : e.consUsed.includes(n) ? V("consUsed") : (e.consUsed.push(n), yt(e, t, Ee[i % 7].benefit), null);
}
function At(e) {
	let t = N[e]?.cost ?? {};
	return {
		forest: t.forest ?? 0,
		mountain: t.mountain ?? 0,
		sun: t.sun ?? 0,
		water: t.water ?? 0,
		any: t.any ?? 0
	};
}
function jt(e, t, n) {
	let r = {
		id: n,
		suit: null
	};
	t.visited.push(r);
	let i = P.filter((e) => t.visited.some((t) => t.id !== n && t.suit === e));
	if (i.length !== 0) {
		if (i.length === 1) {
			r.suit = i[0], Nt(e, t);
			return;
		}
		G(e, {
			t: "assignWild",
			parkId: n,
			suits: i
		});
	}
}
function Mt(e, t, n) {
	let r = N[n].suit;
	if (r === "wild") {
		jt(e, t, n);
		return;
	}
	for (let e of t.visited) e.suit === null && (e.suit = r);
	t.visited.push({
		id: n,
		suit: r
	}), Nt(e, t);
}
function Nt(e, t) {
	for (let n of P) {
		let r = t.visited.filter((e) => e.suit === n).length, i = Math.floor(r / 3);
		for (; t.sets[n] < i;) t.sets[n] += 1, St(e, t, Ce[n]), e.parkAwardPool[n] > 0 && (--e.parkAwardPool[n], t.parkAwards[n] += 1);
	}
}
function Pt(e, t, n) {
	n === "parks" ? (e.parkBonus.splice(t, 1), e.parksDisplay.splice(t, 1)) : (e.consBonus.splice(t, 1), e.consDisplay.splice(t, 1));
}
function Ft(e) {
	for (; e.parksDisplay.length < 3 && e.parksDeck.length > 0;) e.parksDisplay.unshift(e.parksDeck.shift()), e.parkBonus.unshift(null);
	for (; e.consDisplay.length < 3 && e.consDeck.length > 0;) e.consDisplay.unshift(e.consDeck.shift()), e.consBonus.unshift(null);
}
function It(e, t, n) {
	n && ht(e, t, n);
}
function Lt(e, t, n) {
	let r = e.parkBonus[n] ?? null;
	Pt(e, n, "parks"), It(e, t, r);
}
function Rt(e, t, n) {
	let r = N[n];
	if (!r) return !1;
	let i = e.parksDisplay.indexOf(n), a = t.reserved.indexOf(n);
	return i < 0 && a < 0 || !_t(e, t, r.cost) ? !1 : (i >= 0 ? Lt(e, t, i) : t.reserved.splice(a, 1), Mt(e, t, n), r.instant && St(e, t, r.instant), !0);
}
function zt(e, t, n, r, i) {
	let a;
	if (r) {
		if (!i && !_t(e, t, {
			sun: 1,
			water: 1
		})) return V("noRes");
		if (e.consDeck.length === 0) return V("badCons");
		a = e.consDeck.shift();
	} else {
		if (n === void 0 || n < 0 || n >= e.consDisplay.length) return V("badCons");
		if (a = e.consDisplay[n], !i && !_t(e, t, Te[F(a)])) return V("noRes");
		Bt(e, t, n);
	}
	return t.cons.push(a), Vt(e, t), null;
}
function Bt(e, t, n) {
	let r = e.consBonus[n] ?? null;
	Pt(e, n, "cons"), It(e, t, r);
}
function Vt(e, t) {
	let n = Infinity;
	for (let e of we) n = Math.min(n, t.cons.filter((t) => F(t) === e).length);
	for (Number.isFinite(n) || (n = 0); t.consSets < n;) t.consSets += 1, e.consAwardsLeft > 0 && (--e.consAwardsLeft, t.consAwards += 1);
}
function Ht(e) {
	e.moved = !1, e.landingSite = null, e.siteDone = !1, e.consUsed = [], e.vfUsed = !1, e.end = null, e.tasks = [];
}
function Ut(e, t) {
	return e.players[t].hikers.some((e) => e < 8);
}
function Wt(e) {
	return !!e.greta && e.greta.hikers.some((e) => e < 8);
}
function Gt(e, t) {
	for (let n of e.order) if (n !== t && e.players[n].hikers.some((e) => e < 8)) return !1;
	return !Wt(e);
}
function Kt(e, t) {
	return t < e.order.length ? e.order[t] : "$greta";
}
function qt(e) {
	let t = e.order.length + +!!e.greta;
	for (let n = 0; n < t * 4 + 8; n++) {
		let n = (e.turnIdx + 1) % t, r = Kt(e, n);
		if (r === "$greta") {
			if (e.turnIdx = n, !Wt(e)) continue;
			if (e.greta && e.greta.solo) {
				e.turn = e.order[0], e.gretaPending = !0;
				return;
			}
			pn(e, 0), Ft(e);
			continue;
		}
		if (Ut(e, r)) {
			e.turnIdx = n, e.turn = r, e.gretaPending = !1, Ht(e);
			return;
		}
	}
	Qt(e);
}
function Jt(e, t) {
	e.turnIdx = e.order.indexOf(t), e.turn = t, e.gretaPending = !1, Ht(e);
}
function Yt(e) {
	let t = e.order[0];
	for (let n of e.order) {
		let r = e.players[n], i = e.players[t];
		(r.chaletPos > i.chaletPos || r.chaletPos === i.chaletPos && r.chaletOrder > i.chaletOrder) && (t = n);
	}
	return t;
}
function Xt(e) {
	let t = e.seasonAdvanced[e.season - 1], n = H([...Me, ...t], e.seed, e.cursor);
	e.cursor = n.cursor, e.trailSites = n.items.slice(0, 7);
}
function Zt(e) {
	let t = je[e.seasonQueue[e.season - 1]];
	Xt(e);
	for (let t of e.trailBonus) mt(e, t);
	let n = [null];
	for (let r of t.pattern) pt(e, r), n.push(r);
	e.trailBonus = n;
	for (let t of e.parkBonus) mt(e, t);
	for (let t of e.consBonus) mt(e, t);
	if (e.parkBonus = e.parksDisplay.map(() => null), e.consBonus = e.consDisplay.map(() => null), t.display) {
		let n = t.display.token;
		t.display.zone === "parks" ? e.parkBonus = e.parksDisplay.map(() => (pt(e, n), n)) : e.consBonus = e.consDisplay.map(() => (pt(e, n), n));
	}
	let r = e.order.length, i;
	i = r <= 3 ? [t.fires[0]] : r === 4 ? [t.fires[0], t.fires[1]] : [
		t.fires[0],
		t.fires[1],
		t.fires[2]
	], e.campfires = i.filter((e) => e >= 1 && e <= 7);
}
function Qt(e) {
	if (e.season >= 3) {
		an(e);
		return;
	}
	e.season += 1;
	for (let t of e.order) {
		let n = e.players[t];
		n.hikers = n.hikers.map(() => 0), n.slots = n.slots.map(() => null);
	}
	e.greta && (e.greta.hikers = e.greta.hikers.map(() => 0), e.greta.slots = e.greta.slots.map(() => null)), Zt(e), Jt(e, Yt(e));
}
function $t(e) {
	let t = {
		forest: 0,
		mountain: 0,
		sun: 0,
		water: 0,
		any: 0
	};
	for (let n of e.visited) {
		let e = At(n.id);
		t.forest += e.forest, t.mountain += e.mountain, t.sun += e.sun, t.water += e.water, t.any += e.any;
	}
	return t;
}
function en(e) {
	let t = 0;
	for (let n of e.wonderHand) {
		let r = L[n];
		if (r) switch (r.effect) {
			case "consForest":
				t += e.cons.filter((e) => F(e) === "forest").length;
				break;
			case "consMountain":
				t += e.cons.filter((e) => F(e) === "mountain").length;
				break;
			case "consSun":
				t += e.cons.filter((e) => F(e) === "sun").length;
				break;
			case "consWater":
				t += e.cons.filter((e) => F(e) === "water").length;
				break;
			case "iconForest":
				t += Math.floor($t(e).forest / 3);
				break;
			case "iconMountain":
				t += Math.floor($t(e).mountain / 3);
				break;
			case "iconSun":
				t += Math.floor($t(e).sun / 3);
				break;
			case "iconWater":
				t += Math.floor($t(e).water / 3);
				break;
			case "anyIcons":
				t += Math.floor($t(e).any / 2);
				break;
			case "album":
				t += e.albums;
				break;
			case "wonderHand":
				t += e.wonderHand.length;
				break;
			case "snow": t += e.snow;
		}
	}
	return t;
}
function tn(e, t) {
	return e.chaletPos === t.chaletPos ? t.chaletOrder - e.chaletOrder : t.chaletPos - e.chaletPos;
}
function nn(e) {
	let t = 0;
	for (let n of e.visited) t += N[n.id].points;
	return t;
}
function rn(e) {
	let t = 0;
	for (let n of P) {
		let r = e.visited.filter((e) => e.suit === n).length;
		t += e.parkAwards[n] * r;
	}
	return t;
}
function an(e) {
	e.phase = "scoring", e.tasks = [], e.moved = !1, e.landingSite = null, e.siteDone = !0, e.consUsed = [], e.vfUsed = !0, e.end = null, e.gretaPending = !1, e.scoringIdx = 0, e.turnIdx = 0, e.turn = e.order[0] ?? null, e.campfireUsed = [];
	for (let t of e.order) e.players[t].endUsed = [], e.players[t].endPoints = 0;
}
var on = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]);
function sn(e, t, n, r) {
	let i = 0;
	for (let e of B) {
		let r = n[e] ?? 0;
		if (r > t.res[e]) return V("noRes");
		i += r;
	}
	if (i !== r) return V("noRes");
	for (let r of B) {
		let i = n[r] ?? 0;
		i !== 0 && (t.res[r] -= i, e.supply[r] += i);
	}
	return null;
}
function cn(e, t, n) {
	let r = e.players[t], i = L[n.card];
	if (!i || !on.has(i.effect) || !r.wonderHand.includes(n.card) || e.campfireUsed.includes(n.card)) return V("badWonder");
	let a = n.pay ?? {};
	if (i.effect === "turnWildlife2") {
		if ((a.wildlife ?? 0) !== 2) return V("noRes");
		let t = sn(e, r, a, 2);
		if (t) return t;
		r.endPoints += 4;
	} else if (i.effect === "turnCarabiner") {
		if (n.carabiner !== !0 || r.carabiners < 1) return V("noCarabiner");
		--r.carabiners, e.supply.carabiner += 1, r.endPoints += 2;
	} else if (i.effect === "turnAny3") {
		let t = sn(e, r, a, 3);
		if (t) return t;
		r.endPoints += 3;
	} else {
		let n = sn(e, r, a, 2);
		if (n) return n;
		dt(e, t), lt(e, r, 2);
	}
	return e.campfireUsed.push(n.card), r.endUsed.push(n.card), null;
}
function ln(e) {
	let t = {}, n = [];
	for (let t of e.order) {
		let r = e.players[t], i = nn(r), a = en(r), o = r.endPoints, s = r.photos + r.albums * 5, c = rn(r), l = r.consAwards * 5, u = r.chaletAwards.reduce((e, t) => e + t, 0), d = i + a + o + s + c + l + u;
		n.push({
			rid: t,
			parks: i,
			campfire: a,
			endgame: o,
			photos: s,
			parkAwards: c,
			cons: l,
			chalet: u,
			photoAward: 0,
			total: d
		});
	}
	let r = null;
	if (!e.solo) {
		let t = 0;
		for (let n of e.order) t = Math.max(t, e.players[n].photosTaken);
		if (t > 0) {
			let n = e.order.filter((n) => e.players[n].photosTaken === t);
			r = n[0];
			for (let t of n) tn(e.players[t], e.players[r]) < 0 && (r = t);
		}
	}
	for (let e of n) e.photoAward = e.rid === r ? 3 : 0, e.total += e.photoAward, t[e.rid] = e.total;
	let i = [...e.order].sort((n, r) => t[r] - t[n] || tn(e.players[n], e.players[r])), a = null;
	if (e.solo) {
		let n = t[e.order[0]];
		a = 0;
		for (let e of Ve) n >= e.at && (a = Math.max(a, e.rank));
	}
	e.final = {
		scores: t,
		ranking: i,
		winner: e.solo ? [] : [i[0]],
		soloRank: a,
		rows: n
	}, e.phase = "ended", e.tasks = [], e.end = null, e.gretaPending = !1, e.turn = null;
}
function un(t, n, r) {
	let i = r * 2, a = [n.hikers[i], n.hikers[i + 1]].map((e, t) => ({
		pos: e,
		hiker: i + t
	})).filter((e) => e.pos < 8);
	if (a.length === 0) return;
	let o = Le[e(t.seed, t.cursor++, Le.length)];
	a.sort((e, t) => e.pos - t.pos);
	let s = o.ranger === "butterfly" ? a[0] : a[a.length - 1], c = o.symbols, l = s.pos, u = [];
	for (let e = l + 1; e <= 7; e++) {
		let n = Et(t, e), r = t.campfires.includes(e);
		if ((n === 0 || r) && u.push(e), u.length >= c) break;
	}
	if (u.length < c) {
		n.hikers[s.hiker] = 8, dn(t, n, s.hiker), fn(t);
		return;
	}
	let d = u[c - 1];
	if (Et(t, d) > 0) {
		let e = t.campfires.indexOf(d);
		e >= 0 && t.campfires.splice(e, 1);
	}
	n.hikers[s.hiker] = d, t.trailBonus[d - 1] && (mt(t, t.trailBonus[d - 1]), t.trailBonus[d - 1] = null), d === 4 && dt(t, null);
}
function dn(e, t, n) {
	for (let r of ze) if (!gt(e, "both", r)) {
		t.slots[n] = {
			kind: "both",
			action: r
		};
		return;
	}
	for (let r of ze) if (!gt(e, "top", r)) {
		t.slots[n] = {
			kind: "top",
			action: r
		};
		return;
	}
	t.slots[n] = { kind: "parks" };
}
function fn(e) {
	e.parksDisplay.length > 0 && (mt(e, e.parkBonus[e.parkBonus.length - 1] ?? null), Pt(e, e.parksDisplay.length - 1, "parks")), e.consDisplay.length > 0 && (mt(e, e.consBonus[e.consBonus.length - 1] ?? null), Pt(e, e.consDisplay.length - 1, "cons"));
}
function pn(e, t) {
	let n = e.greta;
	if (!n) return;
	let r = +(t === 1), i = n.colors >= 2 ? [r, 1 - r] : [0];
	for (let t of i) (n.hikers[t * 2] < 8 || n.hikers[t * 2 + 1] < 8) && un(e, n, t);
}
function mn(e, t, n, r, i) {
	if (r < 1 || r > 8) return V("badTarget");
	if (t.hikers[n] >= 8) return V("badHiker");
	if (r !== 8 && r <= t.hikers[n]) return V("badTarget");
	if (r === 8) return i.slot ? i.slot.kind !== "parks" && gt(e, i.slot.kind, i.slot.action) ? V("full") : (t.hikers[n] = 8, t.slots[n] = i.slot, e.moved = !0, e.end = i.slot.kind === "parks" ? {
		action: null,
		topDone: !0,
		parksDone: !1
	} : {
		action: i.slot.action,
		topDone: !1,
		parksDone: i.slot.kind === "top"
	}, null) : V("badSlot");
	let a = r - 1;
	if (Et(e, r) > 0) {
		if (i.campfire === "card") {
			let n = i.card ? t.wonderHand.indexOf(i.card) : -1;
			if (n < 0 || !L[i.card]) return V("noCampfire");
			e.wonderDiscard.push(t.wonderHand.splice(n, 1)[0]);
		} else {
			let t = e.campfires.indexOf(r);
			if (t < 0) return V("occupied");
			e.campfires.splice(t, 1);
		}
	}
	return t.hikers[n] = r, e.moved = !0, e.landingSite = r, e.siteDone = !1, e.consUsed = [], Dt(e, t, a), r === 4 && dt(e, e.turn), null;
}
function hn(e, t, n) {
	switch (n) {
		case "conservation":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "carabiner":
			ct(e, t, 1);
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "chalet": Ct(e, t);
	}
}
function gn(e, t, n, r) {
	if (r === "display") {
		let r = e.parksDisplay.indexOf(n);
		if (r < 0) return V("badPark");
		Lt(e, t, r);
	} else if (r === "reserve") {
		let e = t.reserved.indexOf(n);
		if (e < 0) return V("badPark");
		t.reserved.splice(e, 1);
	} else {
		if (e.parksDeck.length === 0) return V("badPark");
		n = e.parksDeck.shift();
	}
	Mt(e, t, n);
	let i = N[n];
	return i.instant && St(e, t, i.instant), null;
}
function _n(e, t) {
	if (e.landingSite === null || e.vfUsed) return V("noVf");
	if (t.carabiners < 1) return V("noCarabiner");
	let n = e.vf[e.landingSite - 1];
	if (!n) return V("noVf");
	switch (--t.carabiners, e.supply.carabiner += 1, e.vfUsed = !0, st(e, t, 1), n) {
		case "wonder":
			ut(e, t, 1);
			break;
		case "sunwater":
			W(e, t, "sun", 1), W(e, t, "water", 1);
			break;
		case "photo":
			lt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			W(e, t, "wildlife", 1);
			break;
		case "conservation":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "mug": G(e, { t: "mug" });
	}
	return null;
}
function vn(e, t) {
	let n = t.mug;
	if (t.mug = 0, n === 1) G(e, { t: "mug1" });
	else if (n === 2) for (let n = 0; n < 3; n++) vt(e, t);
	else n >= 3 && G(e, { t: "freePark" });
}
function yn(e, t, n, r) {
	if (L[n]) return V("badWonder");
	let i = Ae[n];
	if (!i) return V("badWonder");
	let a = t.wonderHand.indexOf(n);
	if (a < 0) return V("badWonder");
	let o = r === "top" ? i.top : i.bottom;
	if (o.pay && !_t(e, t, o.pay)) return V("noRes");
	t.wonderHand.splice(a, 1), e.wonderDiscard.push(n);
	for (let n of o.grants) bt(e, t, n);
	return null;
}
function bn(e, t) {
	if (t.wonderHand.length > 3) for (let n = 0; n < t.wonderHand.length - 3; n++) G(e, { t: "discardWonder" });
	t.carabiners > 3 && (e.supply.carabiner += t.carabiners - 3, t.carabiners = 3);
	let n = ft(t) - 12, r = B.reduce((e, n) => e + t.res[n], 0), i = Math.min(Math.max(0, n), r);
	for (let t = 0; t < i; t++) G(e, { t: "discardRes" });
	return e.tasks.length === 0;
}
function xn(e) {
	if (Ft(e), [...e.order].every((t) => e.players[t].hikers.every((e) => e === 8)) && (!e.greta || e.greta.hikers.every((e) => e === 8))) {
		Qt(e);
		return;
	}
	qt(e);
}
function Sn(e, t, n) {
	let r = e;
	if (r.phase === "ended" || r.turn === null) return V("phase");
	if (n.by !== r.turn) return V("notTurn");
	let i = r.players[n.by];
	if (!i) return V("notPlayer");
	if (r.phase === "scoring") return t.type === "campfireEnd" ? cn(r, n.by, t) ?? { state: r } : t.type === "scoringDone" ? (r.scoringIdx += 1, r.scoringIdx >= r.order.length ? ln(r) : (r.turn = r.order[r.scoringIdx], r.turnIdx = r.scoringIdx), { state: r }) : V("badAction");
	if (r.gretaPending) {
		if (t.type !== "gretaColor") return V("badAction");
		let e = r.greta;
		return !e || !e.solo ? V("badAction") : (r.gretaPending = !1, pn(r, t.first), Ft(r), qt(r), { state: r });
	}
	let a = r.tasks.length > 0 ? r.tasks[r.tasks.length - 1] : null;
	if (t.type === "playWonder") return yn(r, i, t.card, t.side) ?? { state: r };
	if (t.type === "endTurn") return r.moved ? a ? V("badAction") : r.end && (!r.end.topDone || !r.end.parksDone) ? V("endIncomplete") : (bn(r, i) && xn(r), { state: r }) : V("mustMove");
	if (!a) {
		if (t.type === "siteAction") return !r.moved || r.landingSite === null || r.siteDone ? V("badAction") : (r.siteDone = !0, Ot(r, i, r.trailSites[r.landingSite - 1]), { state: r });
		if (t.type === "activateCons") return !r.moved || r.landingSite === null ? V("noConsSite") : kt(r, i, t.card) ?? { state: r };
		if (t.type === "endTop") return !r.end || r.end.topDone || !r.end.action ? V("badAction") : (r.end.topDone = !0, hn(r, i, r.end.action), { state: r });
		if (t.type === "endParks") return !r.end || r.end.parksDone ? V("badAction") : (r.end.parksDone = !0, G(r, {
			t: "parks",
			visited: !1
		}), { state: r });
	}
	if (a) {
		if (a.t === "parks") {
			if (t.type === "reserve") {
				if (a.visited) return V("badAction");
				if (t.from === "display") {
					if (t.index === void 0 || t.index < 0 || t.index >= r.parksDisplay.length) return V("badPark");
					i.reserved.push(r.parksDisplay[t.index]), Lt(r, i, t.index);
				} else {
					if (r.parksDeck.length === 0) return V("badPark");
					i.reserved.push(r.parksDeck.shift());
				}
				return r.tasks.pop(), { state: r };
			}
			return t.type === "visit" ? Rt(r, i, t.parkId) ? (a.visited = !0, { state: r }) : V("badPark") : t.type === "parksDone" ? (r.tasks.pop(), { state: r }) : V("badAction");
		}
		if (a.t === "mug") {
			if (t.type !== "mug") return V("badAction");
			if (t.act === "fill") i.mug = Math.min(3, i.mug + 1);
			else {
				if (i.mug < 1) return V("badAction");
				vn(r, i);
			}
			return r.tasks.pop(), { state: r };
		}
		if (a.t === "mug1") return t.type === "mugChoice" ? (r.tasks.pop(), t.choice === "chalet" ? Ct(r, i) : G(r, {
			t: "cons",
			free: !0
		}), { state: r }) : V("badAction");
		if (a.t === "cons") return t.type === "consPick" ? zt(r, i, t.index, t.deck === !0, a.free) || (r.tasks.pop(), { state: r }) : t.type === "skip" ? (r.tasks.pop(), { state: r }) : V("badAction");
		if (a.t === "assignWild") {
			if (t.type !== "assignWild") return V("badAction");
			if (!a.suits.includes(t.suit)) return V("badSuit");
			let e = i.visited.find((e) => e.id === a.parkId && e.suit === null);
			return e ? (e.suit = t.suit, r.tasks.pop(), Nt(r, i), { state: r }) : V("badPark");
		}
		if (a.t === "freePark") return t.type === "freePark" ? gn(r, i, t.parkId ?? 0, t.from) || (r.tasks.pop(), { state: r }) : V("badAction");
		if (a.t === "discardRes") return t.type !== "discardRes" || i.res[t.res] <= 0 ? V("badAction") : (--i.res[t.res], r.supply[t.res] += 1, r.tasks.pop(), { state: r });
		if (a.t === "discardWonder") {
			if (t.type !== "discardWonder") return V("badAction");
			let e = i.wonderHand.indexOf(t.card);
			return e < 0 ? V("badWonder") : (r.wonderDiscard.push(i.wonderHand.splice(e, 1)[0]), r.tasks.pop(), { state: r });
		}
		return V("badAction");
	}
	return t.type === "viaFerrata" ? r.moved ? _n(r, i) ?? { state: r } : V("mustMove") : t.type === "move" ? r.moved ? V("alreadyMoved") : t.to !== 8 && Gt(r, n.by) ? V("mustEnd") : mn(r, i, t.hiker, t.to, t) || { state: r } : V("badAction");
}
function Cn(e) {
	if (e.phase === "ended") return "none";
	if (e.phase === "scoring") return "scoring";
	if (e.gretaPending) return "gretaColor";
	if (!e.moved) return e.turn !== null && Gt(e, e.turn) ? "trailEnd" : "move";
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t ? t.t === "parks" ? "parks" : t.t === "mug" ? "mug" : t.t === "mug1" ? "mugChoice" : t.t === "cons" ? "cons" : t.t === "assignWild" ? "assignWild" : t.t === "freePark" ? "freePark" : t.t === "discardWonder" ? "discardWonder" : "discardRes" : "actions";
}
function wn(e) {
	let t = (e) => e.some((e) => e !== null && e.kind === "parks");
	for (let n of e.order) if (t(e.players[n].slots)) return !0;
	return !!e.greta && t(e.greta.slots);
}
function Tn(e) {
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t !== null && t.t === "cons" && t.free;
}
function En(e, t) {
	let n = { ...e.res };
	return {
		rid: t,
		seat: e.seat,
		res: n,
		snow: e.snow,
		carabiners: e.carabiners,
		mug: e.mug,
		photos: e.photos,
		albums: e.albums,
		photosTaken: e.photosTaken,
		visited: e.visited.map((e) => ({
			id: e.id,
			suit: e.suit
		})),
		reserved: [...e.reserved],
		cons: [...e.cons],
		parkAwards: { ...e.parkAwards },
		consAwards: e.consAwards,
		chaletAwards: [...e.chaletAwards],
		wonderCount: e.wonderHand.length,
		shutterbug: e.shutterbug,
		chaletPos: e.chaletPos,
		chaletOrder: e.chaletOrder,
		hikers: [...e.hikers],
		atEnd: e.hikers.every((e) => e === 8),
		endUsed: [...e.endUsed],
		endPoints: e.endPoints
	};
}
function Dn(e) {
	let t = (t, n) => {
		for (let r of e.order) if (e.players[r].slots.find((e) => e !== null && e.kind === t && e.action === n)) return r;
		return e.greta && e.greta.slots.some((e) => e !== null && e.kind === t && e.action === n) ? "$greta" : null;
	}, n = [];
	for (let e of ze) n.push({
		kind: "top",
		action: e,
		rid: t("top", e)
	}), n.push({
		kind: "both",
		action: e,
		rid: t("both", e)
	});
	return n;
}
var On = {
	meta: He,
	saveCompatibility: { version: "2" },
	schemas: {
		action: $e,
		publicView: at,
		privateView: ot,
		config: et
	},
	setup(e, t, n) {
		let r = et.parse(e ?? {}), i = t.length === 1, a = i || t.length === 2 && r.greta, o = [...t], s = 0, c = H(Array.from({ length: 48 }, (e, t) => t), n, s);
		s = c.cursor;
		let l = c.items.slice(), u = l.splice(0, 3), d = H(Array.from({ length: 28 }, (e, t) => t), n, s);
		s = d.cursor;
		let f = d.items.slice(), p = f.splice(0, 3), m = H([...Oe.map((e) => e.id), ...ke.map((e) => e.id)], n, s);
		s = m.cursor;
		let h = m.items, g = H(Array.from({ length: je.length }, (e, t) => t), n, s);
		s = g.cursor;
		let _ = g.items.slice(0, 3), v = H(Ne.slice(), n, s);
		s = v.cursor;
		let y = [
			v.items.slice(0, 3),
			v.items.slice(3, 6),
			v.items.slice(6, 9)
		], b = H(Ie.slice(), n, s);
		s = b.cursor;
		let x = [], S = 0;
		for (let e = 0; e < 7; e++) x.push(e === 3 ? null : b.items[S++]);
		let C = H(o.slice(), n, s);
		s = C.cursor;
		let ee = {};
		o.forEach((e, t) => {
			let n = h.pop(), r = C.items.indexOf(e);
			ee[e] = U(t, n, r);
		});
		let w = o.length >= 4 ? 2 : 1, te = {
			phase: "turn",
			season: 1,
			order: o,
			players: ee,
			turnIdx: 0,
			turn: null,
			moved: !1,
			landingSite: null,
			siteDone: !1,
			consUsed: [],
			vfUsed: !1,
			end: null,
			tasks: [],
			gretaPending: !1,
			scoringIdx: 0,
			campfireUsed: [],
			trailSites: [],
			trailBonus: [
				null,
				null,
				null,
				null,
				null,
				null,
				null
			],
			campfires: [],
			vf: x,
			seasonAdvanced: y,
			seasonQueue: _,
			parkBonus: [
				null,
				null,
				null
			],
			consBonus: [
				null,
				null,
				null
			],
			parksDeck: l,
			parksDisplay: u,
			consDeck: f,
			consDisplay: p,
			parkAwardPool: {
				lime: w,
				orange: w,
				teal: w,
				purple: w
			},
			consAwardsLeft: 5,
			chaletStacks: [[
				3,
				4,
				5
			], [
				3,
				4,
				5
			]],
			chaletClaimed: R.map(() => !1),
			supply: {
				...Be,
				carabiner: 15
			},
			wonderDeck: h,
			wonderDiscard: [],
			greta: a ? {
				solo: i,
				colors: i ? 2 : 1,
				hikers: Array(i ? 4 : 2).fill(0),
				slots: Array(i ? 4 : 2).fill(null)
			} : null,
			parkAwardsPerSuit: w,
			solo: i,
			seed: n,
			cursor: s,
			chaletSeq: o.length,
			final: null
		};
		return Zt(te), Jt(te, Yt(te)), { state: te };
	},
	reduce: Sn,
	viewFor(e, t) {
		let n = e, r = n.order.map((e) => En(n.players[e], e)), i = {
			phase: n.phase,
			season: n.season,
			turn: n.turn,
			moved: n.moved,
			pending: Cn(n),
			freeCons: Tn(n),
			landingSite: n.landingSite,
			siteDone: n.siteDone,
			consUsed: [...n.consUsed],
			vfUsed: n.vfUsed,
			end: n.end ? {
				action: n.end.action,
				topDone: n.end.topDone,
				parksDone: n.end.parksDone
			} : null,
			seasonCard: je[n.seasonQueue[n.season - 1]].id,
			order: n.order,
			players: r,
			trailSites: n.trailSites,
			trailBonus: n.trailBonus,
			campfires: n.campfires,
			vf: n.vf,
			parksDisplay: n.parksDisplay,
			parksDeck: n.parksDeck.length,
			parksBonus: n.parkBonus,
			consDisplay: n.consDisplay,
			consDeck: n.consDeck.length,
			consBonus: n.consBonus,
			consAwardsLeft: n.consAwardsLeft,
			chaletStacks: n.chaletStacks.map((e) => [...e]),
			endSlots: Dn(n),
			parksEndOccupied: wn(n),
			greta: n.greta ? {
				hikers: [...n.greta.hikers],
				atEnd: n.greta.hikers.every((e) => e === 8),
				solo: n.greta.solo
			} : null,
			soloRanks: n.solo ? Ve.map((e) => ({
				at: e.at,
				rank: e.rank
			})) : null,
			revealedCampfire: n.phase === "scoring" || n.phase === "ended" ? n.order.map((e) => ({
				rid: e,
				cards: n.players[e].wonderHand.filter((e) => !!L[e])
			})) : null,
			campfireUsed: [...n.campfireUsed],
			finalRows: n.final ? n.final.rows.map((e) => ({ ...e })) : null
		}, a = n.players[t];
		return {
			public: i,
			private: {
				hand: a ? [...a.wonderHand] : [],
				isTurn: n.turn === t
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	}
}, kn = /* @__PURE__ */ "games.parkseurope.parkNames.p0,games.parkseurope.parkNames.p1,games.parkseurope.parkNames.p2,games.parkseurope.parkNames.p3,games.parkseurope.parkNames.p4,games.parkseurope.parkNames.p5,games.parkseurope.parkNames.p6,games.parkseurope.parkNames.p7,games.parkseurope.parkNames.p8,games.parkseurope.parkNames.p9,games.parkseurope.parkNames.p10,games.parkseurope.parkNames.p11,games.parkseurope.parkNames.p12,games.parkseurope.parkNames.p13,games.parkseurope.parkNames.p14,games.parkseurope.parkNames.p15,games.parkseurope.parkNames.p16,games.parkseurope.parkNames.p17,games.parkseurope.parkNames.p18,games.parkseurope.parkNames.p19,games.parkseurope.parkNames.p20,games.parkseurope.parkNames.p21,games.parkseurope.parkNames.p22,games.parkseurope.parkNames.p23,games.parkseurope.parkNames.p24,games.parkseurope.parkNames.p25,games.parkseurope.parkNames.p26,games.parkseurope.parkNames.p27,games.parkseurope.parkNames.p28,games.parkseurope.parkNames.p29,games.parkseurope.parkNames.p30,games.parkseurope.parkNames.p31,games.parkseurope.parkNames.p32,games.parkseurope.parkNames.p33,games.parkseurope.parkNames.p34,games.parkseurope.parkNames.p35,games.parkseurope.parkNames.p36,games.parkseurope.parkNames.p37,games.parkseurope.parkNames.p38,games.parkseurope.parkNames.p39,games.parkseurope.parkNames.p40,games.parkseurope.parkNames.p41,games.parkseurope.parkNames.p42,games.parkseurope.parkNames.p43,games.parkseurope.parkNames.p44,games.parkseurope.parkNames.p45,games.parkseurope.parkNames.p46,games.parkseurope.parkNames.p47".split(","), An = {
	b01: "games.parkseurope.wonderNames.b01",
	b02: "games.parkseurope.wonderNames.b02",
	b03: "games.parkseurope.wonderNames.b03",
	b04: "games.parkseurope.wonderNames.b04",
	b05: "games.parkseurope.wonderNames.b05",
	b06: "games.parkseurope.wonderNames.b06",
	b07: "games.parkseurope.wonderNames.b07",
	b08: "games.parkseurope.wonderNames.b08",
	b09: "games.parkseurope.wonderNames.b09",
	b10: "games.parkseurope.wonderNames.b10",
	b11: "games.parkseurope.wonderNames.b11",
	b12: "games.parkseurope.wonderNames.b12",
	b13: "games.parkseurope.wonderNames.b13",
	b14: "games.parkseurope.wonderNames.b14",
	b16: "games.parkseurope.wonderNames.b16",
	b17: "games.parkseurope.wonderNames.b17",
	b18: "games.parkseurope.wonderNames.b18",
	b19: "games.parkseurope.wonderNames.b19",
	b20: "games.parkseurope.wonderNames.b20",
	b21: "games.parkseurope.wonderNames.b21"
};
function jn(e, t) {
	return e(kn[t]);
}
function Mn(e, t) {
	let n = L[t];
	return n ? e("games.parkseurope.campfireCardName", { n: String(n.no).padStart(2, "0") }) : e(An[t] ?? "games.parkseurope.siteShort.wonder");
}
//#endregion
//#region src/game/field-components.tsx
var Nn = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any",
	carabiner: "games.parkseurope.token.carabiner",
	photo: "games.parkseurope.token.photo",
	mug: "games.parkseurope.siteShort.mug",
	wonder: "games.parkseurope.siteShort.wonder",
	die: "games.parkseurope.siteShort.die",
	chalet: "games.parkseurope.siteShort.chalet",
	parks: "games.parkseurope.siteShort.parks",
	cons: "games.parkseurope.consTitle",
	campfire: "games.parkseurope.campfireLabel",
	award: "games.parkseurope.fieldAward"
};
function K({ kind: e }) {
	return e === "campfire" ? null : /* @__PURE__ */ b("img", {
		className: "pke-mark",
		"data-kind": e,
		src: v("games/parkseurope/marks/" + (e === "cons" ? "conservation" : e) + ".webp"),
		alt: "",
		"aria-hidden": !0
	});
}
function q({ kind: e, count: t }) {
	let n = u()(Nn[e]);
	return /* @__PURE__ */ x("span", {
		className: "pke-piece",
		"data-kind": e,
		role: "img",
		title: n,
		"aria-label": t === void 0 ? n : `${n} ×${t}`,
		children: [e === "campfire" ? n : /* @__PURE__ */ b(K, { kind: e }), t !== void 0 && /* @__PURE__ */ b("b", { children: t })]
	});
}
var Pn = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"any"
];
function Fn({ cost: e, free: t = !1 }) {
	let n = u(), r = Pn.filter((t) => (e[t] ?? 0) > 0);
	return /* @__PURE__ */ b("span", {
		className: "pke-cost-tokens",
		children: t || r.length === 0 ? n("games.parkseurope.free") : r.map((t) => /* @__PURE__ */ b(q, {
			kind: t,
			count: e[t]
		}, t))
	});
}
function In({ park: e, suitLabel: t, effect: n, bonus: r, picked: i, free: a, onPick: o }) {
	let s = u();
	return /* @__PURE__ */ x(o ? "button" : "article", {
		type: o ? "button" : void 0,
		className: "pke-park-face",
		"data-suit": e.suit,
		"aria-pressed": o ? i : void 0,
		onClick: o,
		children: [/* @__PURE__ */ x("span", {
			className: "pke-park-art",
			children: [/* @__PURE__ */ b("img", {
				loading: "lazy",
				decoding: "async",
				src: v(`games/parkseurope/parks/${e.id}.webp`),
				alt: ""
			}), /* @__PURE__ */ b("b", {
				className: "pke-park-score",
				children: s("games.parkseurope.points", { n: e.points })
			})]
		}), /* @__PURE__ */ x("span", {
			className: "pke-park-info",
			children: [
				/* @__PURE__ */ b("strong", {
					className: "pke-park-name",
					children: jn(s, e.id)
				}),
				/* @__PURE__ */ x("span", {
					className: "pke-park-suit",
					children: [/* @__PURE__ */ b("i", { "aria-hidden": !0 }), t]
				}),
				/* @__PURE__ */ b(Fn, {
					cost: e.cost,
					free: a
				}),
				/* @__PURE__ */ x("span", {
					className: "pke-park-effect",
					children: [e.instant && n && /* @__PURE__ */ x("span", {
						className: "pke-effect-line",
						children: [/* @__PURE__ */ b(K, { kind: e.instant }), /* @__PURE__ */ b("span", { children: n })]
					}), r && /* @__PURE__ */ x("span", {
						className: "pke-effect-line",
						children: [
							/* @__PURE__ */ b("b", {
								"aria-hidden": "true",
								children: "+"
							}),
							/* @__PURE__ */ b(q, { kind: r }),
							/* @__PURE__ */ b("span", { children: s("games.parkseurope.displayBonus") })
						]
					})]
				})
			]
		})]
	});
}
function Ln({ player: e }) {
	let t = u(), n = [];
	for (let t = 0; t < e.snow; t++) n.push({
		kind: "snow",
		index: t
	});
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]) for (let r = 0; r < e.res[t]; r++) n.push({
		kind: t,
		index: r
	});
	let r = n.length + e.snow;
	return /* @__PURE__ */ x("div", {
		className: "pke-res-mat",
		children: [
			/* @__PURE__ */ x("div", {
				className: "pke-mat-capacity",
				children: [/* @__PURE__ */ b("b", { children: t("games.parkseurope.packSlots") }), /* @__PURE__ */ b("output", { children: t("games.parkseurope.packUsage", { used: r }) })]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-mat-sockets",
				"aria-label": t("games.parkseurope.packUsage", { used: r }),
				children: [n.map(({ kind: e, index: t }) => /* @__PURE__ */ b("div", {
					className: "pke-mat-socket",
					"data-kind": e,
					children: /* @__PURE__ */ b(q, { kind: e })
				}, `${e}:${t}`)), Array.from({ length: Math.max(0, 12 - r) }, (e, t) => /* @__PURE__ */ b("div", {
					className: "pke-mat-socket",
					"aria-hidden": "true"
				}, `empty:${t}`))]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-gear",
				children: [/* @__PURE__ */ b("span", { children: t("games.parkseurope.token.carabiner") }), /* @__PURE__ */ b(q, {
					kind: "carabiner",
					count: e.carabiners
				})]
			})
		]
	});
}
//#endregion
//#region src/game/field-objects.tsx
var Rn = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
}, zn = (e) => v(`games/parkseurope/objects/${e}.webp`);
function Bn({ award: e, reveal: t = !1 }) {
	let n = u(), r = e.kind, i = r === "parks" ? e.suit : r === "cons" ? "conservation" : "photo", a = r === "chalet" ? e.points : r === "cons" ? 5 : r === "photo" ? 3 : 1, o = r === "parks" ? n("games.parkseurope.fx.parkAward", {
		suit: n(Rn[e.suit]),
		count: e.count
	}) : r === "cons" ? n("games.parkseurope.consAwardsLabel", { n: e.count }) : r === "chalet" ? n("games.parkseurope.fx.chaletAward", { points: a }) : n("games.parkseurope.resultPhotoAward");
	return /* @__PURE__ */ x("span", {
		className: "pke-award-piece",
		"data-kind": r,
		"data-suit": r === "parks" ? e.suit : void 0,
		"data-reveal": t,
		role: "img",
		"aria-label": o,
		title: o,
		children: [
			r !== "chalet" && /* @__PURE__ */ b("img", {
				className: "pke-award-illustration",
				src: zn("award-" + i),
				alt: ""
			}),
			(r === "chalet" || r === "photo" || r === "parks" && t) && /* @__PURE__ */ b("b", {
				className: "pke-award-score",
				children: a
			}),
			"count" in e && e.count > 1 && /* @__PURE__ */ x("b", {
				className: "pke-award-count",
				children: ["×", e.count]
			})
		]
	});
}
function Vn({ player: e }) {
	let t = u(), n = [...P.map((n) => [
		{
			kind: "parks",
			suit: n,
			count: e.parkAwards[n]
		},
		t(Rn[n]),
		t("games.parkseurope.awardParkDetail", { benefit: t(Nn[Ce[n]]) })
	]), [
		{
			kind: "cons",
			count: e.consAwards
		},
		t("games.parkseurope.fieldProjects"),
		t("games.parkseurope.awardFixedDetail", { n: 5 })
	]], r = e.chaletAwards.map((e) => [
		{
			kind: "chalet",
			points: e
		},
		t("games.parkseurope.fieldChalet"),
		t("games.parkseurope.awardFixedDetail", { n: e })
	]);
	return /* @__PURE__ */ x("div", {
		className: "pke-award-tray",
		children: [/* @__PURE__ */ b("h3", { children: t("games.parkseurope.fieldHonors") }), /* @__PURE__ */ b("ul", { children: [...n, ...r].map(([e, t, n], r) => {
			let i = !("count" in e) || e.count > 0;
			return /* @__PURE__ */ x("li", {
				className: "pke-award-well",
				"data-owned": i,
				"data-kind": e.kind,
				"data-suit": e.kind === "parks" ? e.suit : void 0,
				children: [
					/* @__PURE__ */ b("span", {
						className: "pke-award-recess",
						children: i ? /* @__PURE__ */ b(Bn, { award: e }) : /* @__PURE__ */ b("i", { "aria-hidden": !0 })
					}),
					/* @__PURE__ */ b("strong", {
						title: i ? n : void 0,
						children: t
					}),
					i && /* @__PURE__ */ b("span", {
						className: "pke-award-explanation",
						children: n
					})
				]
			}, r);
		}) })]
	});
}
function Hn() {
	return /* @__PURE__ */ b("img", {
		className: "pke-album-art",
		src: zn("award-album"),
		alt: "",
		"aria-hidden": !0
	});
}
var Un = {
	snow: "snow",
	carabiner: "carabiner",
	photo: "photo",
	wonder: "wonder",
	die: "die",
	parks: "parks",
	mug: "mug",
	cons: "cons",
	chalet: "chalet"
};
function Wn({ grants: e }) {
	let t = u();
	return /* @__PURE__ */ b("span", {
		className: "pke-wonder-grants",
		children: e.map((e, n) => {
			if (e.t === "shutterbug") return /* @__PURE__ */ b("img", {
				className: "pke-shutterbug-art",
				src: zn("award-shutterbug"),
				alt: t("games.parkseurope.shutterbug")
			}, n);
			let r = e.t === "res" ? e.res : Un[e.t], i = "n" in e && e.n > 1 ? e.n : void 0;
			return /* @__PURE__ */ b(q, {
				kind: r,
				count: i
			}, n);
		})
	});
}
function Gn({ face: e, side: t, used: n, enabled: r, onPlay: i, titleId: a, waiting: o }) {
	let s = u(), c = i ? "button" : "div", l = e.pay && Object.values(e.pay).some(Boolean), d = s(t === "top" ? "games.parkseurope.wonder.top" : "games.parkseurope.wonder.bottom"), f = a + "-" + t, p = f + "-status";
	return /* @__PURE__ */ x(c, {
		className: "pke-wonder-action",
		"data-side": t,
		"data-used": n,
		"aria-labelledby": i ? a + " " + f : void 0,
		"aria-describedby": i && !r ? p : void 0,
		type: i ? "button" : void 0,
		disabled: i ? !r : void 0,
		onClick: i ? () => i(t) : void 0,
		children: [/* @__PURE__ */ x("span", {
			id: f,
			className: "pke-wonder-command",
			children: [
				/* @__PURE__ */ x("b", {
					className: "sr-only",
					children: [d, " "]
				}),
				l && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Fn, { cost: e.pay ?? {} }), /* @__PURE__ */ b("span", {
					className: "pke-wonder-arrow",
					"aria-hidden": !0,
					children: "›"
				})] }),
				/* @__PURE__ */ b(Wn, { grants: e.grants })
			]
		}), i && /* @__PURE__ */ b("span", {
			id: p,
			className: "pke-wonder-play",
			children: s(o ? "games.parkseurope.wonderWait" : r ? "games.parkseurope.wonderPlay" : "games.parkseurope.cannotAfford")
		})]
	});
}
function Kn({ id: e, used: t, campEffect: n, canUse: i, onPlay: a, waiting: o }) {
	let s = u(), c = r(), l = Ae[e];
	if (!l && !L[e]) return null;
	let d = Mn(s, e);
	if (!l) return /* @__PURE__ */ x("article", {
		className: "pke-wonder pke-wonder-face pke-wonder-campfire",
		children: [
			/* @__PURE__ */ b("img", {
				src: zn("campfire"),
				alt: ""
			}),
			/* @__PURE__ */ b("header", { children: /* @__PURE__ */ b("b", { children: d }) }),
			/* @__PURE__ */ b("span", {
				className: "pke-campfire-use",
				children: s("games.parkseurope.wonderShare")
			}),
			n && /* @__PURE__ */ x("div", {
				className: "pke-campfire-score",
				children: [/* @__PURE__ */ b("strong", { children: s("games.parkseurope.wonderScore") }), /* @__PURE__ */ b("p", { children: n })]
			})
		]
	});
	let f = `url("${zn("wonder-" + String(l.no).padStart(2, "0"))}")`;
	return /* @__PURE__ */ x("article", {
		className: "pke-wonder pke-wonder-face",
		style: { "--pke-wonder-art": f },
		children: [
			/* @__PURE__ */ b(Gn, {
				face: l.top,
				side: "top",
				titleId: c,
				used: t === "top",
				enabled: !o && (i?.("top") ?? !0),
				waiting: o,
				onPlay: a
			}),
			/* @__PURE__ */ b("header", { children: /* @__PURE__ */ b("b", {
				id: c,
				children: d
			}) }),
			/* @__PURE__ */ b(Gn, {
				face: l.bottom,
				side: "bottom",
				titleId: c,
				used: t === "bottom",
				enabled: !o && (i?.("bottom") ?? !0),
				waiting: o,
				onPlay: a
			})
		]
	});
}
var qn = {
	sun: [
		"#f3ca64",
		"#8d5d20",
		"#fff0b8"
	],
	mountain: [
		"#f0a4ab",
		"#8d344f",
		"#ffdde0"
	],
	water: [
		"#a8dded",
		"#20608a",
		"#d5f4fb"
	],
	forest: [
		"#b9d87c",
		"#385e39",
		"#e4f1bd"
	]
};
function Jn({ id: e, name: t, site: n, benefit: r, bonus: i, supported: a, free: o, action: s }) {
	let c = u(), l = F(e), [d, f, p] = qn[l];
	return /* @__PURE__ */ x("article", {
		className: "pke-project-face",
		"data-supported": a,
		style: {
			"--stock": d,
			"--mark-ink": f,
			"--paper": p
		},
		children: [
			/* @__PURE__ */ x("div", {
				className: "pke-project-plate",
				children: [/* @__PURE__ */ b(K, { kind: l }), /* @__PURE__ */ b(K, { kind: "cons" })]
			}),
			/* @__PURE__ */ x("header", { children: [/* @__PURE__ */ b("strong", { children: t }), /* @__PURE__ */ b("span", { children: n })] }),
			/* @__PURE__ */ x("div", {
				className: "pke-project-reward",
				children: [/* @__PURE__ */ b(q, { kind: Ee[e % 7].benefit }), /* @__PURE__ */ b("span", { children: r })]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-project-foot",
				children: [a ? /* @__PURE__ */ b("span", { children: c("games.parkseurope.fieldSupported") }) : /* @__PURE__ */ b(Fn, {
					cost: Te[l],
					free: o
				}), i && /* @__PURE__ */ x("span", {
					"aria-label": c("games.parkseurope.displayBonus"),
					children: ["+ ", /* @__PURE__ */ b(q, { kind: i })]
				})]
			}),
			s && /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: s.disabled,
				onClick: s.onPress,
				children: s.label
			})
		]
	});
}
//#endregion
//#region src/game/field-motion.tsx
var Yn = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
};
function Xn(e, t, n) {
	let r = n && We(e.res, n), i = Ue.map((n) => ({
		kind: n,
		count: t.res[n] - e.res[n] + (r?.[n] ?? 0)
	}));
	return i.push({
		kind: "snow",
		count: t.snow - e.snow
	}, {
		kind: "carabiner",
		count: t.carabiners - e.carabiners
	}), i.filter(({ count: e }) => e > 0);
}
function Zn(e, t) {
	let n = [];
	for (let r of P) {
		let i = t.parkAwards[r] - e.parkAwards[r];
		i > 0 && n.push({
			kind: "parks",
			suit: r,
			count: i
		});
	}
	t.consAwards > e.consAwards && n.push({
		kind: "cons",
		count: t.consAwards - e.consAwards
	});
	for (let r of t.chaletAwards.slice(e.chaletAwards.length)) n.push({
		kind: "chalet",
		points: r
	});
	return n;
}
function Qn(e, t) {
	return t.season < e.season || t.season - e.season > 1 ? !1 : e.players.every((e) => {
		let n = t.players.find(({ rid: t }) => t === e.rid);
		return !!n && n.photosTaken >= e.photosTaken && n.chaletPos >= e.chaletPos && e.visited.every(({ id: e }, t) => n.visited[t]?.id === e) && e.cons.every((e, t) => n.cons[t] === e);
	});
}
function $n(e, t) {
	if (!t) return;
	let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
	if (!(r.width === 0 || r.height === 0 || r.right <= n.left || r.left >= n.right || r.bottom <= n.top || r.top >= n.bottom)) return {
		point: {
			x: r.left - n.left + r.width / 2,
			y: r.top - n.top + r.height / 2
		},
		width: r.width
	};
}
function er(e, t, n, r, i) {
	if (e?.type === "campfireEnd" && !r.campfireUsed.includes(e.card) && i.campfireUsed.includes(e.card)) return { id: e.card };
	if ((e?.type === "playWonder" || e?.type === "move" && e.campfire === "card") && e.card && t.includes(e.card) && !n.includes(e.card) && (e.type !== "move" || i.moved)) return {
		id: e.card,
		side: e.type === "playWonder" ? e.side : void 0
	};
}
function tr(e, t, n, r, i) {
	if (t?.side) return Ae[t.id]?.[t.side].pay;
	if (e?.type === "visit" && r.visited.length > n.visited.length && r.visited.at(-1)?.id === e.parkId) return N[e.parkId]?.cost;
	if (e?.type !== "consPick" || i.freeCons || r.cons.length <= n.cons.length) return;
	if (e.deck) return {
		sun: 1,
		water: 1
	};
	let a = e.index === void 0 ? void 0 : i.consDisplay[e.index];
	return a === void 0 ? void 0 : Te[F(a)];
}
function nr(e, t, n) {
	let r = e?.card ? 390 : 0, i = e?.gains.length ? 760 : 0, a = e?.awards.some(({ rid: e }) => e === t) ? 1400 : e?.awards.length ? 1120 : 0;
	return n ? {
		gainDelay: 0,
		awardDelay: 0,
		duration: 1400
	} : {
		gainDelay: r,
		awardDelay: r + i,
		duration: r + i + a
	};
}
function rr(e, t, r) {
	let i = o(null), a = o(null), c = o(null), l = o(null), u = o(0), [d, f] = s({
		self: r,
		frames: []
	}), p = S(), m = d.self === r ? d.frames[0] : void 0, h = nr(m, r, p);
	function g(e) {
		let t = e.target instanceof Element ? e.target.closest("button") : null;
		if (!t || !i.current) return;
		a.current = {
			origin: $n(i.current, t),
			card: $n(i.current, t.closest(".pke-wonder, .pke-scoring-card"))
		};
		let n = a.current;
		queueMicrotask(() => {
			a.current === n && (a.current = null);
		});
	}
	function _(t) {
		c.current = {
			scope: e,
			action: t,
			origin: a.current?.origin,
			card: a.current?.card
		};
	}
	return n(() => {
		let n = l.current;
		if (l.current = {
			pub: e,
			hand: t,
			self: r
		}, !n || n.self !== r || !Qn(n.pub, e) || e.order.length !== n.pub.order.length || !e.order.every((e) => n.pub.order.includes(e)) || n.pub.phase === "ended" && e.phase !== "ended") {
			c.current = null, queueMicrotask(() => f({
				self: r,
				frames: []
			}));
			return;
		}
		let a = n.pub.players.find(({ rid: e }) => e === r), o = e.players.find(({ rid: e }) => e === r);
		if (!i.current || !a || !o || n.pub === e) return;
		let s = c.current?.scope === n.pub ? c.current : null;
		c.current = null;
		let d = er(s?.action, n.hand, t, n.pub, e);
		d && (d.origin = s?.card ?? s?.origin);
		let p = Xn(a, o, tr(s?.action, d, a, o, n.pub)), m = [];
		for (let t of e.players) {
			let e = n.pub.players.find(({ rid: e }) => e === t.rid);
			if (!e) continue;
			let r = Zn(e, t);
			r.length && m.push({
				rid: t.rid,
				awards: r
			});
		}
		if (!d && p.length === 0 && m.length === 0) return;
		let h = $n(i.current, i.current.querySelector(".pke-field-stage")), g = e.landingSite ?? n.pub.landingSite, _ = g === null ? null : i.current.querySelector(`.pke-valley-pin[data-stop="${g}"]:not([hidden])`), v = d?.origin?.point ?? $n(i.current, _)?.point ?? s?.origin?.point ?? h?.point, y = $n(i.current, i.current.querySelector("[data-panel=\"pack\"]"))?.point, b = {
			id: ++u.current,
			gains: p,
			awards: m,
			card: d,
			origin: v,
			target: y
		};
		queueMicrotask(() => f((e) => ({
			self: r,
			frames: e.self === r ? [...e.frames, b] : [b]
		})));
	}, [
		e,
		t,
		r
	]), n(() => {
		if (!m) return;
		let e = window.setTimeout(() => {
			f((e) => e.frames[0]?.id === m.id ? {
				...e,
				frames: e.frames.slice(1)
			} : e);
		}, h.duration);
		return () => window.clearTimeout(e);
	}, [m, h.duration]), {
		root: i,
		capture: g,
		record: _,
		active: m,
		timing: h
	};
}
function ir(e, t) {
	return e ? {
		[`--pke-fx-${t}-x`]: `${e.x}px`,
		[`--pke-fx-${t}-y`]: `${e.y}px`
	} : {};
}
function ar({ frame: e, self: t, timing: n, nameOf: r }) {
	let i = u();
	if (!e) return /* @__PURE__ */ b("div", { className: "pke-fx" });
	let a = (e) => e.awards.map((e) => e.kind === "parks" ? i("games.parkseurope.fx.parkAward", {
		suit: i(Yn[e.suit]),
		count: e.count
	}) : e.kind === "chalet" ? i("games.parkseurope.fx.chaletAward", { points: e.points }) : e.kind === "cons" ? i("games.parkseurope.consAwardsLabel", { n: e.count }) : i("games.parkseurope.resultPhotoAward")), o = e.awards.find(({ rid: e }) => e === t), s = e.awards.filter(({ rid: e }) => e !== t), c = {
		"--pke-gain-delay": `${n.gainDelay}ms`,
		"--pke-award-delay": `${n.awardDelay}ms`
	};
	return /* @__PURE__ */ x("div", {
		className: "pke-fx",
		style: c,
		children: [
			/* @__PURE__ */ x("span", {
				className: "sr-only",
				role: "status",
				children: [
					e.card && i("games.parkseurope.fx.cardUsed", { card: Mn(i, e.card.id) }),
					" ",
					e.gains.map(({ kind: e, count: t }) => `+${t} ${i(Nn[e])}`).join(" · "),
					" ",
					e.awards.map((e) => `${r(e.rid)} · ${a(e).join(" · ")}`).join(" · ")
				]
			}),
			e.card && /* @__PURE__ */ b("div", {
				className: "pke-fx-card",
				"aria-hidden": "true",
				"data-card": e.card.id,
				style: {
					...ir(e.card.origin?.point, "from"),
					"--pke-fx-card-width": `${e.card.origin?.width ?? 160}px`
				},
				children: /* @__PURE__ */ b(Kn, {
					id: e.card.id,
					used: e.card.side
				})
			}),
			e.gains.length > 0 && /* @__PURE__ */ x("div", {
				className: "pke-fx-gains",
				"aria-hidden": "true",
				style: {
					...ir(e.origin, "from"),
					...ir(e.target, "to")
				},
				children: [e.gains.map(({ kind: e, count: t }, n) => /* @__PURE__ */ b("span", {
					className: "pke-fx-flight",
					style: {
						"--pke-fx-step": n,
						"--pke-fx-rise": `${44 + n * 12}px`
					},
					children: /* @__PURE__ */ b(q, {
						kind: e,
						count: t
					})
				}, e)), /* @__PURE__ */ b("div", {
					className: "pke-fx-pack-receipt",
					children: e.gains.map(({ kind: e, count: t }) => /* @__PURE__ */ x("span", {
						className: "pke-fx-gain",
						children: [/* @__PURE__ */ b(q, { kind: e }), /* @__PURE__ */ x("b", { children: ["+", t] })]
					}, e))
				})]
			}),
			o && /* @__PURE__ */ x("div", {
				className: "pke-fx-honor",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ b("div", { className: "pke-fx-sunburst" }), /* @__PURE__ */ x("div", {
					className: "pke-fx-honor-card",
					children: [
						/* @__PURE__ */ b("div", {
							className: "pke-fx-emblems",
							children: o.awards.map((e, t) => /* @__PURE__ */ b(Bn, {
								award: e,
								reveal: !0
							}, t))
						}),
						/* @__PURE__ */ b("strong", { children: i("games.parkseurope.fx.honorEarned") }),
						a(o).map((e, t) => /* @__PURE__ */ b("span", { children: e }, t))
					]
				})]
			}),
			s.length > 0 && /* @__PURE__ */ b("div", {
				className: "pke-fx-other",
				"aria-hidden": "true",
				children: s.map((e) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("strong", { children: r(e.rid) }), /* @__PURE__ */ b("span", { children: a(e).join(" · ") })] }, e.rid))
			})
		]
	}, e.id);
}
//#endregion
//#region src/game/field-tracks.tsx
function or({ items: e, active: t, onSelect: n, label: r }) {
	return /* @__PURE__ */ b("div", {
		className: "pke-field-tabs",
		role: "group",
		"aria-label": r,
		children: e.map(([e, r]) => /* @__PURE__ */ b("button", {
			type: "button",
			"aria-pressed": e === t,
			onClick: () => n(e),
			children: r
		}, e))
	});
}
var sr = [
	[13, 87],
	[13, 72],
	[13, 57],
	[14, 42],
	[22, 25],
	[39, 14],
	[54, 14],
	[69, 18],
	[83, 27],
	[90, 40],
	[90, 53],
	[90, 66],
	[90, 79],
	[78, 91],
	[62, 91],
	[47, 91]
], cr = {
	start: "games.parkseurope.trailStart",
	end: "games.parkseurope.fieldFinish",
	snow: "games.parkseurope.fieldSnowSpace",
	wonder: "games.parkseurope.siteShort.wonder",
	award: "games.parkseurope.fieldAward"
};
function lr({ pub: e, nameOf: t, marker: n }) {
	let r = u(), [i, a] = s(null), o = R.map((t, n) => {
		let r = e.players.filter((e) => e.chaletPos === n).sort((e, t) => e.chaletOrder - t.chaletOrder), i = [];
		return t.t === "award" && (i = e.greta?.solo ? e.players.some((e) => e.chaletPos >= n) ? [] : [t.solo] : t.stack === null ? [] : e.chaletStacks[t.stack] ?? []), {
			type: t.t,
			occupants: r,
			scores: i,
			top: i.at(-1)
		};
	}), c = i ?? o.reduce((e, t, n) => t.top === void 0 ? e : n, 0), l = o[c], d = l.top === void 0 ? l.type === "award" || l.type === "wonder" ? r("games.parkseurope.fieldDrawPassing") : "" : r("games.parkseurope.fieldAwardNext", { n: l.top }) + (l.scores.length > 1 ? " " + r("games.parkseurope.fieldAwardStack", { scores: l.scores.slice(0, -1).reverse().join(" / ") }) : "");
	return /* @__PURE__ */ x(y, { children: [
		/* @__PURE__ */ b("p", {
			className: "pke-track-note",
			children: r("games.parkseurope.fieldChaletNote")
		}),
		/* @__PURE__ */ x("div", {
			className: "pke-chalet-map",
			role: "group",
			"aria-label": r("games.parkseurope.chaletTrack"),
			children: [
				/* @__PURE__ */ b("svg", {
					viewBox: "0 0 100 100",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: /* @__PURE__ */ b("polyline", {
						points: sr.map((e) => e.join(",")).join(" "),
						fill: "none",
						vectorEffect: "non-scaling-stroke"
					})
				}),
				/* @__PURE__ */ b("div", {
					className: "pke-chalet-heart",
					"aria-hidden": !0,
					children: /* @__PURE__ */ b(K, { kind: "chalet" })
				}),
				o.map(({ type: e, occupants: i, top: o }, s) => {
					let [l, u] = sr[s], d = [
						r("games.parkseurope.fieldTrackSpace", {
							n: s,
							name: r(cr[e])
						}),
						o === void 0 ? "" : r("games.parkseurope.points", { n: o }),
						...i.map((e) => t(e.rid))
					].filter(Boolean).join(" · ");
					return /* @__PURE__ */ x("button", {
						type: "button",
						className: "pke-chalet-node",
						"data-space": s,
						"data-kind": e,
						style: {
							"--x": l + "%",
							"--y": u + "%"
						},
						"aria-label": d,
						"aria-pressed": c === s,
						onClick: () => a(s),
						children: [
							e === "start" || e === "end" ? r(e === "start" ? "games.parkseurope.fieldStartShort" : "games.parkseurope.fieldEndShort") : /* @__PURE__ */ b(K, { kind: e === "award" && o === void 0 ? "wonder" : e }),
							o !== void 0 && /* @__PURE__ */ b("b", { children: o }),
							i.length > 0 && /* @__PURE__ */ b("span", {
								className: "pke-chalet-occupants",
								children: i.map((e) => /* @__PURE__ */ b("span", { children: n(e.rid) }, e.rid))
							})
						]
					}, s);
				})
			]
		}),
		/* @__PURE__ */ x("p", {
			className: "pke-track-detail",
			"aria-live": "polite",
			children: [
				/* @__PURE__ */ b("strong", { children: r("games.parkseurope.fieldTrackSpace", {
					n: c,
					name: r(cr[l.type])
				}) }),
				d && /* @__PURE__ */ b("span", { children: d }),
				l.occupants.length > 0 && /* @__PURE__ */ b("span", { children: l.occupants.map((e) => t(e.rid)).join(" / ") })
			]
		})
	] });
}
var ur = {
	conservation: "cons",
	carabiner: "carabiner",
	mug: "mug",
	chalet: "chalet"
};
function dr({ pub: e, actionName: t, nameOf: n, marker: r, onTake: i }) {
	let a = u();
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("table", {
		className: "pke-end-board",
		"aria-label": a("games.parkseurope.fieldEndActions"),
		children: [/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.fieldAction")
			}),
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.slotTop")
			}),
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.slotBoth")
			})
		] }) }), /* @__PURE__ */ b("tbody", { children: ze.map((o) => /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ x("th", {
			scope: "row",
			children: [
				/* @__PURE__ */ b(K, { kind: ur[o] }),
				" ",
				t(o)
			]
		}), ["top", "both"].map((s) => {
			let c = e.endSlots.find((e) => e.action === o && e.kind === s)?.rid;
			return /* @__PURE__ */ b("td", { children: c ? /* @__PURE__ */ x("span", {
				className: "pke-end-occupant",
				children: [
					r(c),
					" ",
					n(c)
				]
			}) : i ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				"aria-label": t(o) + " · " + a(s === "top" ? "games.parkseurope.slotTop" : "games.parkseurope.slotBoth"),
				onClick: () => i(s, o),
				children: a("games.parkseurope.fieldVacant")
			}) : /* @__PURE__ */ b("span", {
				className: "pke-sub",
				children: a("games.parkseurope.fieldVacant")
			}) }, s);
		})] }, o)) })]
	}), /* @__PURE__ */ x("div", {
		className: "pke-park-only",
		children: [/* @__PURE__ */ x("strong", { children: [
			/* @__PURE__ */ b(K, { kind: "parks" }),
			" ",
			a("games.parkseurope.slotParks")
		] }), i ? /* @__PURE__ */ b("button", {
			type: "button",
			className: "pke-btn pke-btn--main",
			onClick: () => i("parks"),
			children: a("games.parkseurope.fieldChoose")
		}) : /* @__PURE__ */ x("span", { children: [a("games.parkseurope.fieldSharedSlot"), e.parksEndOccupied && " · " + a("games.parkseurope.fieldSharedOccupied")] })]
	})] });
}
function fr({ pub: e, name: t }) {
	let n = u(), r = je.find((t) => t.id === e.seasonCard);
	return r ? /* @__PURE__ */ x("article", {
		className: "pke-season-card",
		children: [
			/* @__PURE__ */ b("h3", { children: t }),
			/* @__PURE__ */ b("p", { children: n("games.parkseurope.fieldSeasonNote") }),
			/* @__PURE__ */ b("ol", { children: r.pattern.map((e, t) => /* @__PURE__ */ x("li", { children: [/* @__PURE__ */ b(q, { kind: e }), /* @__PURE__ */ b("span", { children: n("games.parkseurope.siteNo", { n: t + 2 }) })] }, t)) }),
			r.display && /* @__PURE__ */ x("p", { children: [
				n(r.display.zone === "cons" ? "games.parkseurope.consTitle" : "games.parkseurope.parksTitle"),
				" · ",
				n("games.parkseurope.displayBonus"),
				" ",
				/* @__PURE__ */ b(q, { kind: r.display.token })
			] })
		]
	}) : null;
}
//#endregion
//#region src/game/valley-world.ts
var J = (e, t, n) => e + (t - e) * n, pr = (e, t = 0, n = 1) => Math.max(t, Math.min(n, e)), Y = (e) => pr(e) * pr(e) * (3 - 2 * pr(e)), mr = (e) => e - Math.floor(e), X = (e, t = 1) => mr(Math.sin(e * 127.1 + t * 311.7 + 38.4) * 43758.5453123);
function Z(e, t) {
	let n = Math.floor(e), r = Math.floor(t), i = Y(e - n), a = Y(t - r);
	return J(J(X(n, r), X(n + 1, r), i), J(X(n, r + 1), X(n + 1, r + 1), i), a);
}
var hr = (e, t) => 1 - Math.abs(Z(e, t) * 2 - 1), gr = (e, t) => Math.exp(-((e / t) ** 2)), _r = Array.from({ length: 9 }, (e, t) => 8 - t * 8.75), Q = (e) => 2.25 * Math.sin(e * .128) + .78 * Math.sin(e * .29) - .036 * e, vr = (e) => -14.7 + .115 * e + 1.35 * Math.sin(e * .12), yr = .02, br = 13232623, xr = .0084, Sr = (e) => .35 - .036 * e + .34 * Math.sin(e * .105), Cr = (e, t) => Sr(t) + .79 * (Z(e * .13 + 3, t * .12) - .4) + .27 * (Z(e * .53, t * .53) - .4);
function $(e, t) {
	let n = Math.abs(e - Q(t)), r = (6 + 11 * Z(e * .027, t * .024)) * Y((n - 6) / 29), i = 22 * gr(e + 27, 15) * gr(t + 64, 30), a = 19 * gr(e - 34, 16) * gr(t + 78, 29), o = 38 * gr(t + 113, 25) * (gr(e + 14, 33) + .5 * gr(e - 30, 23)), s = (5 * hr(e * .09, t * .08) + 2.6 * hr(e * .19, t * .14) + .9 * Z(e * .42, t * .35)) * Y((n - 4) / 16) * Y((-t + 13) / 31), c = Y((Math.abs(t - vr(e)) - 1.35) / 1.35), l = J(Cr(e, t) + r + i + a + o + s, Sr(t), 1 - Y((n - .74) / 1.38)), u = J(-.54 + .18 * Z(e * .46, t * .45), l, c), d = Math.abs(t + 15);
	return J(u, 1.14, Y((d - 2.18) / .34) * (1 - Y((d - 2.55) / 1.04)) * (1 - Y((n - 1.02) / .76)));
}
function wr(e) {
	return Math.abs(e + 15) < 2.53 ? 1.14 : $(Q(e), e) + .02;
}
var Tr = "\nfloat valNoise(vec2 p) {\n  vec2 i=floor(p), f=fract(p);\n  f=f*f*(3.0-2.0*f);\n  vec4 a=fract(sin(vec4(dot(i,vec2(127.1,311.7)),dot(i+vec2(1,0),vec2(127.1,311.7)),dot(i+vec2(0,1),vec2(127.1,311.7)),dot(i+vec2(1,1),vec2(127.1,311.7))))*43758.5453);\n  return mix(mix(a.x,a.y,f.x),mix(a.z,a.w,f.x),f.y);\n}";
function Er(e, t, n = {}) {
	let r = new j(e);
	return r.onBeforeCompile = (e) => {
		Object.assign(e.uniforms, n), e.vertexShader = "varying vec3 valleyPosition;\n" + e.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\nvalleyPosition=(modelMatrix*vec4(position,1.0)).xyz;"), e.fragmentShader = `varying vec3 valleyPosition;\n${Object.keys(n).map((e) => `uniform float ${e};`).join("\n")}\n${Tr}\n` + e.fragmentShader.replace("#include <color_fragment>", `#include <color_fragment>\n${t}`);
	}, r.customProgramCacheKey = () => t, r;
}
function Dr() {
	let e = new ge({
		side: te,
		depthWrite: !1,
		fog: !1,
		uniforms: { sun: { value: new M(.56, .68, -.46).normalize() } },
		vertexShader: "varying vec3 direction; void main(){direction=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
		fragmentShader: `varying vec3 direction; uniform vec3 sun;
${Tr}
void main(){
  vec3 d=normalize(direction); float e=max(d.y,0.0); float s=max(dot(d,sun),0.0);
  vec3 sky=mix(vec3(.52,.78,.89),vec3(.06,.36,.70),smoothstep(0.0,.72,e));
  sky+=vec3(.24,.15,.045)*pow(s,12.0)*.45;
  vec2 p=d.xz/max(.15,d.y+.38)*4.2;
  float n=valNoise(p)+.38*valNoise(p*2.15)+.17*valNoise(p*4.35)+.07*valNoise(p*8.6);
  float cloud=smoothstep(.82,1.14,n)*smoothstep(.035,.19,e)*(1.0-smoothstep(.5,.9,e));
  sky=mix(sky,mix(vec3(.82,.91,.96),vec3(1.0,.96,.83),pow(s,4.0)),cloud*.86);
  sky+=vec3(1.0,.89,.60)*(pow(s,220.0)*.22+smoothstep(.9990,.9996,s)*2.0);
  gl_FragColor=vec4(sky,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`
	}), t = new le(new _e(155, 40, 24), e);
	return t.frustumCulled = !1, t.renderOrder = -20, t;
}
function Or(e, t = !1) {
	let n = t ? new pe(350, 370, 91, 97) : new pe(124, 160, e ? 182 : 226, e ? 202 : 252);
	n.rotateX(-Math.PI / 2);
	let r = n.attributes.position, i = new Float32Array(r.count * 3), a = new k("#588758"), o = new k("#b0c175"), s = new k("#8dabbc"), c = new k("#c0cf7a"), l = new k("#958666"), u = new k("#d2ad76"), d = new k("#e6f0ef"), f = new k();
	for (let e = 0; e < r.count; e++) {
		let n = r.getX(e), p = r.getZ(e) - 52, m = $(n, p) - (t ? .86 : 0);
		r.setXYZ(e, n, m, p);
		let h = Math.hypot($(n + .32, p) - $(n - .32, p), $(n, p + .32) - $(n, p - .32)) / .64, g = .62 * Z(n * .18, p * .2) + .38 * Z(n * .64, p * .58);
		f.copy(a).lerp(o, Y(g * 1.15)), f.lerp(c, .35 * Y((g - .27) * 1.5)), f.lerp(s, Y((h - .42) * .89) * Y((m - 3) / 10)), f.lerp(d, Y((m + g * 7 - 31) / 10) * (1 - Y((h - 1.8) * .45)));
		let _ = Math.abs(n - Q(p));
		f.lerp(u, (1 - Y((_ - .55 - Z(n * 2, p * 1.7) * .24) / .56)) * .93), f.lerp(l, 1 - Y((Math.abs(p - vr(n)) - 1.05) / 1.75)), f.toArray(i, e * 3);
	}
	n.setAttribute("color", new E(i, 3)), n.computeVertexNormals();
	let p = Er({
		vertexColors: !0,
		roughness: .96
	}, "\n  vec2 v=valleyPosition.xz;\n  float fine=valNoise(v*20.0)*.45+valNoise(v*8.0)*.35+valNoise(v*3.2)*.20;\n  float grain=smoothstep(.28,.82,fine);\n  float vein=valNoise(vec2(v.x*2.8,valleyPosition.y*8.0+v.y*1.1));\n  diffuseColor.rgb*=.83+grain*.36+vein*.12;\n  "), m = new le(n, p);
	return m.receiveShadow = !0, m;
}
function kr() {
	let e = [], t = [];
	for (let n = 0; n <= 185; n++) {
		let r = J(-60, 60, n / 185), i = vr(r), a = 1.43 + .34 * Z(r * .16, 8);
		if (e.push(r, yr, i - a, r, yr, i + a), n < 185) {
			let e = n * 2;
			t.push(e, e + 1, e + 2, e + 2, e + 1, e + 3);
		}
	}
	let n = new D();
	n.setAttribute("position", new E(new Float32Array(e), 3)), n.setIndex(t), n.computeVertexNormals();
	let r = { value: 0 }, i = Er({
		color: 4103851,
		roughness: .32,
		metalness: .08,
		side: ie
	}, "\n  vec2 p=valleyPosition.xz;\n  float r=valNoise(vec2(p.x*1.75-waterClock*.85,p.y*6.9));\n  float q=valNoise(vec2(p.x*4.4-waterClock*1.2,p.y*13.0));\n  float flashes=pow(max(sin(p.y*19.0+p.x*.41+r*5.0-waterClock*2.2),0.0),8.0);\n  diffuseColor.rgb*=.79+(r+q)*.23;\n  diffuseColor.rgb+=vec3(.23,.43,.47)*flashes*smoothstep(.38,.83,r);\n  ", { waterClock: r }), a = new le(n, i);
	return a.receiveShadow = !0, {
		mesh: a,
		time: r
	};
}
function Ar(e, t, n, r, { shadow: i = !1, tint: a } = {}) {
	if (!r.length) return;
	let o = new ce(t, n, r.length), s = new de(), c = new k();
	return r.forEach((e, t) => {
		s.position.set(e.x, e.y, e.z), s.rotation.set(e.rx || 0, e.angle || 0, e.rz || 0), s.scale.set(e.w, e.h, e.d ?? e.w), s.updateMatrix(), o.setMatrixAt(t, s.matrix), a && o.setColorAt(t, a(c, t));
	}), o.castShadow = i, o.receiveShadow = i, o.computeBoundingSphere(), e.add(o), o;
}
function jr(e) {
	let t = [], n = [], r = [], i = new k("#4c7350"), a = new k("#a4c66b"), o = new k(), s = e ? 12 : 7, c = e ? 15 : 8;
	for (let e = 0; e < s; e++) {
		let l = e / s, u = .22 + l * .68, d = .19 * (1 - l) ** .7 + .009, f = t.length / 3;
		for (let r = 0; r < 3; r++) for (let s = 0; s < c; s++) {
			let f = s / c * Math.PI * 2 + e * .49, p = (.77 + .32 * X(s, e)) * d * (r === 0 ? 1 : r === 1 ? .67 : .14);
			t.push(Math.sin(f) * p, u + r * (.095 - l * .043) + (X(s + 17, e) - .5) * .047, Math.cos(f) * p), o.copy(i).lerp(a, .16 + r * .17 + l * .27 + X(s + 25, e) * .22).toArray(n, n.length);
		}
		for (let e = 0; e < 2; e++) for (let t = 0; t < c; t++) {
			let n = f + e * c + t, i = f + e * c + (t + 1) % c;
			r.push(n, i, n + c, i, i + c, n + c);
		}
	}
	let l = new D();
	return l.setAttribute("position", new E(new Float32Array(t), 3)), l.setAttribute("color", new E(new Float32Array(n), 3)), l.setIndex(r), l.computeVertexNormals(), l;
}
function Mr(e, t) {
	let n = [];
	for (let e = 0; e < (t ? 460 : 640); e++) {
		let t = J(-102, 22, X(e, 51)), r = 4.7 + 36 * X(e, 49) ** 1.65, i = Q(t) + (e % 2 ? 1 : -1) * r;
		if (Math.abs(t - vr(i)) < 3.5 || Math.abs(t + 60) < 6 && r < 9 || r > 9 && Z(i * .15, t * .15) < .33) continue;
		let a = 3.7 + 8.9 * X(e, 57) ** 1.38, o = a * J(.72, 1.21, X(e, 20));
		r < 3.5 + o * .24 || n.push({
			x: i,
			z: t,
			y: $(i, t) - .12,
			w: o,
			h: a,
			angle: X(e, 71) * 6.28
		});
	}
	for (let [e, t, r, i] of [
		[
			-1,
			1,
			10.8,
			8
		],
		[
			1,
			-3,
			10,
			7.2
		],
		[
			-1,
			-19,
			12.5,
			8
		],
		[
			1,
			-31,
			12.2,
			9
		],
		[
			1,
			-45,
			10,
			8
		],
		[
			-1,
			-48,
			9.4,
			6
		]
	]) {
		let a = Q(t) + e * (4.2 + i * .24);
		n.push({
			x: a,
			z: t,
			y: $(a, t) - .16,
			w: i,
			h: r,
			angle: X(a, t) * 6.28
		});
	}
	let r = new ne(.012, .038, .82, 8);
	r.translate(0, .41, 0);
	let i = new j({
		vertexColors: !0,
		roughness: .96,
		side: ie
	}), a = new j({
		color: 7166017,
		roughness: 1
	}), o = n.filter((e) => Math.abs(e.x - Q(e.z)) < 15 && e.z > -83), s = n.filter((e) => !o.includes(e)), c = (e, t) => e.setRGB(.84 + X(t, 3) * .15, .88 + X(t, 4) * .12, .78 + X(t, 5) * .18);
	Ar(e, jr(!0), i, o, {
		shadow: !0,
		tint: c
	}), Ar(e, jr(!1), i, s, { tint: c }), Ar(e, r, a, o, { shadow: !0 }), Ar(e, r, a, s);
}
function Nr(e) {
	let t = new se(1, e), n = t.attributes.position;
	for (let e = 0; e < n.count; e++) {
		let t = n.getX(e), r = n.getY(e), i = n.getZ(e), a = .83 + .22 * Z(t * 2.7 + i * 1.6, r * 2.2 + i * 3.1) + .13 * Z(t * 6.6 + r * 2.7, i * 6.7);
		n.setXYZ(e, t * a, r * a * .72 + .065 * Math.sin(i * 8), i * a);
	}
	let r = new Float32Array(n.count * 3), i = new M();
	for (let e = 0; e < n.count; e++) i.set(n.getX(e), n.getY(e) * 1.65, n.getZ(e)).normalize(), i.toArray(r, e * 3);
	return t.setAttribute("normal", new E(r, 3)), t;
}
function Pr() {
	let e = [], t = [], n = [], r = new k("#65944c"), i = new k("#c8ce76"), a = new k();
	for (let o = 0; o < 8; o++) {
		let s = (X(o, 243) - .5) * .58, c = (X(o, 47) - .5) * .58, l = .23 + X(o, 83) * .43, u = (X(o, 97) - .5) * .55, d = e.length / 3;
		e.push(s - .032, 0, c, s + .032, 0, c, s + u * .4 + .018, l * .58, c - .035, s + u * .4 - .018, l * .58, c - .035, s + u, l, c - .1), t.push(d, d + 1, d + 3, d + 1, d + 2, d + 3, d + 3, d + 2, d + 4);
		for (let e = 0; e < 5; e++) a.copy(r).lerp(i, e * .15 + X(o, 21) * .2).toArray(n, n.length);
	}
	let o = new D();
	return o.setAttribute("position", new E(new Float32Array(e), 3)), o.setAttribute("color", new E(new Float32Array(n), 3)), o.setIndex(t), o.computeVertexNormals(), o;
}
function Fr(e, t) {
	let n = [], r = [], i = [];
	for (let e = 0; e < (t ? 3500 : 6800); e++) {
		let t = J(-78, 16, X(e, 31)), r = 1.18 + 17 * X(e, 15) ** 2.1, a = Q(t) + (e % 2 ? 1 : -1) * r;
		if (Math.abs(t - vr(a)) < 1.83 || Z(a * .26, t * .29) < .25) continue;
		let o = $(a, t), s = .42 + .79 * X(e, 91) * (.8 + Z(a * .4, t * .4));
		n.push({
			x: a,
			z: t,
			y: o,
			w: s,
			h: s,
			angle: X(e, 78) * 6.28
		}), e % 19 == 0 && r < 6 && i.push({
			x: a,
			z: t,
			y: o + .22 * s,
			w: s * .094,
			h: s * .13,
			angle: 0,
			d: s * .094
		});
	}
	for (let e = 0; e < 320; e++) {
		let t = J(-95, 14, X(e, 178)), n = 1.24 + 22 * X(e, 175) ** 1.7, i = Q(t) + (e % 2 ? 1 : -1) * n, a = .09 + 1.18 * X(e, 172) ** 2.5, o = $(i, t);
		Math.abs(t - vr(i)) < .84 || r.push({
			x: i,
			z: t,
			y: o - .12 * a,
			w: a * .89,
			h: a,
			d: a * .62,
			angle: X(e, 8) * 6.28,
			rx: X(e, 186) * .23,
			rz: X(e, 153) * .36
		});
	}
	let a = new j({
		color: 11715783,
		roughness: .91
	}), o = (e, t) => t % 4 == 0 ? e.set("#b3c197") : e.set(t % 2 ? "#c6d4ce" : "#dce1d4"), s = r.filter((e) => Math.abs(e.x - Q(e.z)) < 6);
	Ar(e, Nr(3), a, s, {
		shadow: !0,
		tint: o
	}), Ar(e, Nr(1), a, r.filter((e) => !s.includes(e)), { tint: o }), Ar(e, Pr(), new j({
		vertexColors: !0,
		side: ie,
		roughness: .88
	}), n), Ar(e, new se(1, 0), new j({ roughness: .87 }), i, { tint: (e, t) => e.set(t % 3 == 0 ? "#ffc754" : t % 3 == 1 ? "#fff3c1" : "#ef9779") });
}
function Ir(e) {
	let t = new j({
		color: 8939595,
		roughness: .93
	}), n = new j({
		color: 12160347,
		roughness: .83
	}), r = new j({
		color: 4540476,
		roughness: .62,
		metalness: .29
	});
	function i(e, t, n, r, i, a, o, s) {
		let c = new le(new T(n, r, i), t);
		return c.position.set(a, o, s), c.castShadow = !0, c.receiveShadow = !0, e.add(c), c;
	}
	let a = new A();
	a.position.set(Q(-15), 0, -15), e.add(a);
	for (let e = 0; e < 19; e++) i(a, e % 4 == 0 ? t : n, 2.38, .12, .25, 0, 1.075, (e - 9) * .268);
	for (let e of [-1.12, 1.12]) {
		i(a, t, .15, .13, 5.14, e, 1.96, 0), i(a, t, .1, .1, 5.14, e, 1.61, 0);
		for (let n of [
			-2.46,
			-1.22,
			0,
			1.22,
			2.46
		]) i(a, t, .12, 1.01, .12, e, 1.51, n), i(a, r, .15, .08, .15, e, 1.99, n);
	}
	for (let a of _r) {
		let o = Q(a) + 1.85, s = $(o, a), c = new A();
		c.position.set(o, s, a), c.rotation.y = -.23, e.add(c), i(c, t, .16, 1.87, .18, 0, .85, 0), i(c, n, 1.12, .33, .13, -.28, 1.36, .05), i(c, t, .74, .24, .12, -.1, 1.72, .055);
		for (let e of [-.67, .11]) i(c, r, .049, .048, .035, e, 1.36, .132);
	}
	let o = new le(new ne(.18, .23, 2.6, 11), t);
	o.position.set(Q(-41) - 2.03, $(Q(-41) - 2.03, -41) + .31, -41), o.rotation.z = 1.31, o.rotation.y = .57, o.castShadow = !0, e.add(o);
}
function Lr(e, t = e) {
	let n = new A(), r = new j({
		color: e,
		roughness: .91
	}), i = new j({
		color: 2968398,
		roughness: .94
	}), a = new j({
		color: 4278071,
		roughness: .95
	}), o = new j({
		color: 13144418,
		roughness: .86
	}), s = new j({
		color: t,
		roughness: .79
	}), c = new j({
		color: 7554609,
		roughness: .92
	}), l = new j({
		color: 15253369,
		roughness: .92
	}), u = new j({
		color: 4010795,
		roughness: .97
	});
	function d(e, t, n, r, i, a, o = 1, s = 1, c = 1) {
		let l = new le(t, n);
		return l.position.set(r, i, a), l.scale.set(o, s, c), l.castShadow = !0, l.receiveShadow = !0, e.add(l), l;
	}
	let f = new _e(1, 19, 13), p = new A();
	n.add(p), d(p, new O(.25, .44, 8, 14), r, 0, 1.12, 0, 1.08, 1, .75), d(p, f, a, 0, .8, 0, .24, .2, .17), d(p, f, o, 0, 1.67, -.024, .19, .23, .175), d(p, new ne(.15, .213, .117, 22), l, 0, 1.86, -.015), d(p, new ne(.284, .292, .034, 24), c, 0, 1.813, -.015), d(p, new O(.21, .31, 8, 16), s, 0, 1.23, .235, 1.05, 1, .57), d(p, f, c, 0, 1.18, .36, .216, .162, .054), d(p, f, s, 0, 1.214, .392, .182, .116, .041), d(p, new T(.051, .056, .025), l, 0, 1.242, .432);
	let m = d(p, new ne(.074, .074, .39, 16), l, 0, 1.52, .243);
	m.rotation.z = Math.PI / 2;
	for (let e of [-1, 1]) d(p, new T(.047, .37, .031), i, e * .184, 1.24, -.158).rotation.z = e * .14, d(p, f, c, e * .21, 1.07, .233, .049, .118, .072);
	let h = [], g = [];
	for (let e of [-1, 1]) {
		let t = new A();
		t.position.set(e * .282, 1.37, .005), p.add(t), t.rotation.z = e * .1, d(t, new O(.079, .31, 6, 12), r, 0, -.187, 0), d(t, f, o, 0, -.4, -.004, .061, .096, .064), h.push(t);
		let i = new A();
		i.position.set(e * .124, .82, .008), n.add(i), d(i, new O(.093, .25, 6, 12), a, 0, -.177, 0);
		let s = new A();
		s.position.y = -.34, i.add(s), d(s, new O(.075, .233, 6, 12), a, 0, -.17, .006), d(s, f, u, 0, -.38, -.047, .095, .086, .155), g.push({
			hip: i,
			knee: s
		});
	}
	return {
		root: n,
		pose(e, t) {
			let n = t ? Math.sin(e * 10.7) : 0;
			p.position.y = t ? Math.abs(n) * .042 : 0, p.rotation.z = n * .053, p.rotation.x = t ? -.08 : 0, g.forEach(({ hip: e, knee: t }, r) => {
				let i = n * (r === 0 ? 1 : -1);
				e.rotation.x = i * .48, t.rotation.x = Math.max(0, -i) * .67, h[r].rotation.x = -i * .42;
			});
		}
	};
}
function Rr() {
	let e = [], t = [];
	for (let n = 0; n <= 210; n++) {
		let r = J(_r[0], _r[_r.length - 1], n / 210), i = Q(r), a = wr(r) + .055;
		if (e.push(i - .47, a, r, i + .47, a, r), n < 210) {
			let e = n * 2;
			t.push(e, e + 1, e + 2, e + 1, e + 3, e + 2);
		}
	}
	let n = new D();
	n.setAttribute("position", new E(new Float32Array(e), 3)), n.setIndex(t), n.computeVertexNormals();
	let r = new ue({
		color: 15120237,
		side: ie,
		transparent: !0,
		opacity: .86,
		depthWrite: !1
	}), i = new A();
	i.add(new le(n, r));
	let a = new ne(.75, .89, .12, 24), o = [
		15909745,
		7130314,
		11982181,
		15966846
	];
	return _r.forEach((e, t) => {
		let n = new le(a, new j({
			color: o[t % o.length],
			roughness: .58,
			metalness: .12
		}));
		n.position.set(Q(e), wr(e) + .06, e), i.add(n);
	}), i.visible = !1, i;
}
function zr(e = !1) {
	let t = new he(), n = new ae(br, xr);
	t.fog = n, t.add(new oe(15793151, 11709831, 1.76));
	let r = new re(16772558, 2.6);
	r.castShadow = !0, r.shadow.mapSize.set(e ? 1024 : 2048, e ? 1024 : 2048), Object.assign(r.shadow.camera, {
		left: -18,
		right: 18,
		top: 21,
		bottom: -21,
		near: 1,
		far: 83
	}), r.shadow.normalBias = .048, r.shadow.bias = -36e-5, r.shadow.radius = 2.7, r.shadow.intensity = .58, t.add(r, r.target);
	let i = new re(13955327, .7);
	i.position.set(-12, 13, 9), t.add(i);
	let a = Dr();
	t.add(a), t.add(Or(e, !0), Or(e));
	let o = kr();
	t.add(o.mesh), Mr(t, e), Fr(t, e), Ir(t);
	let s = Rr();
	return t.add(s), {
		scene: t,
		sun: r,
		sky: a,
		stream: o,
		route: s,
		fog: n
	};
}
function Br(e, t, n = 0) {
	let r = Q(e), i = e - 7.2, a = t ? .8 : 1.18, o = e + (t ? 5.34 : 5.25) * Math.cos(n) - a * Math.sin(n) * .33, s = Q(o) + a * Math.cos(n) + 1.55 * Math.sin(n), c = Math.max(wr(e) + 2.31, $(s, o) + 1.47);
	return {
		position: new M(s, c, o),
		look: new M(J(Q(i), r, t ? .61 : .38), wr(e) + (t ? .06 : .3), i),
		fov: t ? 60 : 49
	};
}
function Vr(e) {
	return e < 1.04 ? {
		position: new M(39, 113, 67),
		look: new M(0, -1, -14),
		fov: 55
	} : {
		position: new M(86, 75, 6),
		look: new M(0, 0, -24),
		fov: 46
	};
}
function Hr(e, t, n, r) {
	let { sun: i, stream: a } = e, o = r ? -24 : t;
	i.position.set(Q(o) + 29, 35 + wr(o), o - 16), i.target.position.set(Q(o), wr(o), o - 4);
	let s = e.sun.shadow.camera, c = r ? 39 : 21;
	s.top !== c && (Object.assign(s, {
		top: c,
		bottom: -c,
		left: -c,
		right: c
	}), s.updateProjectionMatrix()), e.route.visible = r, e.fog.density = r ? .0027 : xr, a.time.value = n;
}
//#endregion
//#region src/game/valley-stage.tsx
function Ur(e) {
	let t = /* @__PURE__ */ new Set();
	e.traverse((e) => {
		let n = e;
		if (n.isMesh) {
			n.geometry.dispose();
			for (let e of Array.isArray(n.material) ? n.material : [n.material]) t.add(e);
		}
	}), t.forEach((e) => e.dispose());
}
function Wr() {
	try {
		return typeof WebGL2RenderingContext < "u";
	} catch {
		return !1;
	}
}
function Gr(e, t) {
	let n = e.clone();
	n.updateMatrixWorld();
	let r = new me(), i = new fe(new M(0, 1, 0)), a = new ve();
	return (e, o) => (a.set((e - t.left) / t.width * 2 - 1, 1 - (o - t.top) / t.height * 2), r.setFromCamera(a, n), r.ray.intersectPlane(i, new M()));
}
function Kr({ mode: e, season: t, hikers: r, focused: i, sites: a, onSite: c, fallback: l, resetKey: u = 0 }) {
	let [d] = s(Wr), [f, p] = s(!1), m = o([]), h = o(0), g = o({
		x: 0,
		z: 0
	}), _ = o(null), v = o(null), y = o(null), [S] = s(() => typeof matchMedia < "u" && matchMedia("(max-width: 760px)").matches);
	n(() => {
		g.current = {
			x: 0,
			z: 0
		}, h.current = 0, v.current?.();
	}, [u]);
	function C(t) {
		if (y.current || t.button !== 0 || t.target.closest("button")) return;
		let n = e === "overview" && _.current ? Gr(_.current, t.currentTarget.getBoundingClientRect()) : void 0;
		y.current = {
			id: t.pointerId,
			x: t.clientX,
			angle: h.current,
			panX: g.current.x,
			panZ: g.current.z,
			unproject: n,
			origin: n?.(t.clientX, t.clientY)
		}, t.currentTarget.setPointerCapture(t.pointerId);
	}
	function ee(t) {
		let n = y.current;
		if (n?.id === t.pointerId) {
			if (e === "follow") h.current = Math.max(-.9, Math.min(.9, n.angle - (t.clientX - n.x) * .009));
			else {
				let e = n.unproject?.(t.clientX, t.clientY);
				if (!e || !n.origin) return;
				g.current.x = Math.max(-35, Math.min(35, n.panX + n.origin.x - e.x)), g.current.z = Math.max(-42, Math.min(42, n.panZ + n.origin.z - e.z));
			}
			v.current?.();
		}
	}
	function w(e) {
		y.current?.id === e.pointerId && (y.current = null);
	}
	return /* @__PURE__ */ x("div", {
		className: "pke-valley",
		"data-mode": e,
		onPointerDownCapture: C,
		onPointerMoveCapture: ee,
		onPointerUp: w,
		onPointerCancel: w,
		onLostPointerCapture: w,
		children: [
			d && /* @__PURE__ */ b(qr, {
				low: S,
				mode: e,
				season: t,
				hikers: r,
				focused: i,
				sites: a,
				pins: m,
				angle: h,
				pan: g,
				cameraRef: _,
				wakeRef: v,
				onRecoveryChange: p
			}),
			(!d || f) && /* @__PURE__ */ b("p", {
				className: "pke-valley-fallback",
				children: l
			}),
			/* @__PURE__ */ b("div", {
				className: "pke-valley-pins",
				hidden: !d || f,
				children: a.map((e, t) => /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-valley-pin",
					disabled: !e.legal,
					"data-stop": t,
					"data-current": e.current,
					"data-selected": !!e.selected,
					"data-legal": e.legal,
					ref: (e) => {
						m.current[t] = e;
					},
					style: { "--pke-pin-color": e.color },
					"aria-label": e.selected ? e.label + " · " + e.selected : e.label,
					onClick: () => c(t),
					children: [/* @__PURE__ */ x("b", { children: [e.icon, e.label] }), e.occupants.length > 0 && /* @__PURE__ */ b("span", {
						className: "pke-valley-occupants",
						children: e.occupants
					})]
				}, t))
			})
		]
	});
}
function qr({ low: e, onRecoveryChange: t, ...r }) {
	let i = a(() => zr(e), [e]);
	return n(() => () => Ur(i.scene), [i]), /* @__PURE__ */ b(ye, {
		scene: i.scene,
		camera: {
			fov: 46,
			near: .11,
			far: 264
		},
		frameloop: "demand",
		dpr: [1, e ? 1.2 : 1.45],
		shadows: "soft",
		gl: {
			antialias: !0,
			powerPreference: "high-performance"
		},
		onCreated: ({ gl: e }) => {
			e.toneMapping = w, e.toneMappingExposure = 1.11, e.shadowMap.autoUpdate = !1;
		},
		onRecoveryChange: t,
		children: /* @__PURE__ */ b(Jr, {
			...r,
			low: e,
			world: i
		})
	});
}
function Jr({ world: e, mode: t, season: r, hikers: i, focused: a, sites: s, pins: c, angle: l, pan: u, cameraRef: d, wakeRef: f }) {
	let p = S(), m = ee((e) => e.invalidate), h = ee((e) => e.camera), g = o({
		models: /* @__PURE__ */ new Map(),
		season: r,
		first: !0,
		mode: t,
		aim: new M(),
		projected: new M(),
		elapsed: 0
	});
	return n(() => (d.current = h, () => {
		d.current = null;
	}), [h, d]), n(() => {
		f.current = m;
		let t = g.current.models;
		return () => {
			f.current = null;
			for (let n of t.values()) e.scene.remove(n.body.root), Ur(n.body.root);
			t.clear();
		};
	}, [
		m,
		f,
		e
	]), n(() => {
		m();
	}, [
		m,
		t,
		r,
		i,
		a,
		s
	]), C(({ camera: n, size: o, gl: d }, f) => {
		let h = g.current, _ = Math.min(f, .05), v = h.season !== r, y = h.mode !== t;
		h.season = r, h.mode = t, h.elapsed += _;
		let b = !1, x = new Set(i.map((e) => e.id));
		for (let [t, n] of h.models) x.has(t) || (e.scene.remove(n.body.root), Ur(n.body.root), h.models.delete(t));
		let S = /* @__PURE__ */ new Map();
		for (let t of i) {
			let n = _r[t.site];
			if (n === void 0) continue;
			let r = h.models.get(t.id);
			(!r || r.color !== t.color) && (r && (e.scene.remove(r.body.root), Ur(r.body.root)), r = {
				body: Lr(t.color),
				from: n,
				depth: n,
				target: n,
				elapsed: 0,
				color: t.color
			}, h.models.set(t.id, r), e.scene.add(r.body.root)), r.target !== n && (r.from = v || p || n > r.depth ? n : r.depth, r.target = n, r.elapsed = 0), r.elapsed += _;
			let i = Math.min(2.9, .48 + Math.abs(r.target - r.from) * .038), a = Math.min(1, r.elapsed / i), o = r.from !== r.target && a < 1, s = a * a * (3 - 2 * a);
			r.depth = r.from + (r.target - r.from) * s;
			let c = S.get(t.site) ?? 0;
			S.set(t.site, c + 1);
			let l = c === 0 ? 0 : Math.min(3, Math.ceil(c / 2)) * (c % 2 ? -.83 : .83), u = Q(r.depth) + (o ? 0 : l), d = l && !o ? Math.max($(u, r.depth), wr(r.depth)) : wr(r.depth);
			r.body.root.position.set(u, d + .025, r.depth), r.body.root.rotation.y = -Math.atan2(Q(r.depth - .2) - Q(r.depth + .2), .4), r.body.pose(r.elapsed, o), b ||= o;
		}
		let C = n, ee = h.models.get(a)?.depth ?? _r[0], w = t === "overview", te = o.width <= 610, T = w ? Vr(C.aspect) : Br(ee, te, l.current);
		w && (T.position.x += u.current.x, T.position.z += u.current.z, T.look.x += u.current.x, T.look.z += u.current.z);
		let E = h.first || p ? 1 : 1 - Math.exp(-_ * (b ? 8 : 7)), D = n.position.distanceToSquared(T.position) > 9e-4 || Math.abs(C.fov - T.fov) > .08;
		n.position.lerp(T.position, D ? E : 1), D && (n.position.y = Math.max(n.position.y, $(n.position.x, n.position.z) + 1.4)), h.aim.lerp(T.look, D ? E : 1), C.fov += (T.fov - C.fov) * (D ? E : 1), C.updateProjectionMatrix(), n.lookAt(h.aim), n.updateMatrixWorld(), e.sky.position.copy(n.position), Hr(e, ee, h.elapsed, w), d.shadowMap.needsUpdate = h.first || b || y || !D, h.first = !1;
		let O = [];
		s.map((e, t) => ({
			site: e,
			index: t
		})).sort((e, t) => Number(!!t.site.selected) - Number(!!e.site.selected) || Number(t.site.occupants.length > 0) - Number(e.site.occupants.length > 0) || Number(t.site.current) - Number(e.site.current)).forEach(({ site: e, index: t }) => {
			let r = c.current[t];
			if (!r) return;
			let i = _r[t], a = h.projected.set(Q(i), wr(i) + (w ? 2.2 : 2.1), i).project(n), s = (a.x + 1) * o.width / 2, l = (1 - a.y) * o.height / 2, u = a.z > 0 && a.z < 1 && s > 38 && s < o.width - 38 && l > 42 && l < o.height - 20, d = !O.some((e) => Math.abs(s - e.x) < (w ? 76 : 98) && Math.abs(l - e.y) < 48), f = w || e.legal || e.current || !!e.selected, p = u && d && f;
			r.hidden = !p, p && (O.push({
				x: s,
				y: l
			}), r.style.left = `${s}px`, r.style.top = `${l}px`);
		}), (b || D) && m();
	}), null;
}
//#endregion
//#region src/game/view-player.tsx
var Yr = [
	{
		id: "parks",
		label: "games.parkseurope.fieldParks"
	},
	{
		id: "cons",
		label: "games.parkseurope.fieldProjects"
	},
	{
		id: "hand",
		label: "games.parkseurope.fieldHand"
	},
	{
		id: "pack",
		label: "games.parkseurope.fieldPack"
	},
	{
		id: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		id: "trail",
		label: "games.parkseurope.trail"
	}
], Xr = {
	"core-mountain": "mountain",
	"core-water": "water",
	"core-forest": "forest",
	"core-sun": "sun",
	carabiner: "carabiner",
	die: "die",
	chalet: "chalet",
	parks: "parks",
	wildlife: "wildlife",
	photo: "photo",
	mug: "mug",
	wonder: "wonder",
	conservation: "cons"
}, Zr = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], Qr = {
	mountain: 0,
	forest: 0,
	sun: 0,
	water: 0,
	wildlife: 0
}, $r = "#4f5d4a", ei = ["#4f5d4a", "#a4632f"], ti = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]), ni = {
	cliffs: "games.parkseurope.season.cliffs",
	swimming: "games.parkseurope.season.swimming",
	memories: "games.parkseurope.season.memories",
	sun: "games.parkseurope.season.sun",
	dreams: "games.parkseurope.season.dreams",
	joy: "games.parkseurope.season.joy",
	scouting: "games.parkseurope.season.scouting",
	growth: "games.parkseurope.season.growth",
	climbing: "games.parkseurope.season.climbing",
	caves: "games.parkseurope.season.caves",
	meadows: "games.parkseurope.season.meadows",
	ice: "games.parkseurope.season.ice"
}, ri = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any"
}, ii = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple",
	wild: "games.parkseurope.suit.wild"
}, ai = {
	"core-forest": "games.parkseurope.site.core-forest",
	"core-sun": "games.parkseurope.site.core-sun",
	"core-mountain": "games.parkseurope.site.core-mountain",
	"core-water": "games.parkseurope.site.core-water",
	wildlife: "games.parkseurope.site.wildlife",
	carabiner: "games.parkseurope.site.carabiner",
	parks: "games.parkseurope.site.parks",
	die: "games.parkseurope.site.die",
	photo: "games.parkseurope.site.photo",
	mug: "games.parkseurope.site.mug",
	chalet: "games.parkseurope.site.chalet",
	wonder: "games.parkseurope.site.wonder",
	conservation: "games.parkseurope.site.conservation"
}, oi = {
	"core-forest": "games.parkseurope.siteShort.core-forest",
	"core-sun": "games.parkseurope.siteShort.core-sun",
	"core-mountain": "games.parkseurope.siteShort.core-mountain",
	"core-water": "games.parkseurope.siteShort.core-water",
	wildlife: "games.parkseurope.siteShort.wildlife",
	carabiner: "games.parkseurope.siteShort.carabiner",
	parks: "games.parkseurope.siteShort.parks",
	die: "games.parkseurope.siteShort.die",
	photo: "games.parkseurope.siteShort.photo",
	mug: "games.parkseurope.siteShort.mug",
	chalet: "games.parkseurope.siteShort.chalet",
	wonder: "games.parkseurope.siteShort.wonder",
	conservation: "games.parkseurope.siteShort.conservation"
}, si = {
	wonder: "games.parkseurope.vfShort.wonder",
	sunwater: "games.parkseurope.vfShort.sunwater",
	photo: "games.parkseurope.vfShort.photo",
	conservation: "games.parkseurope.vfShort.conservation",
	mug: "games.parkseurope.vfShort.mug",
	wildlife: "games.parkseurope.vfShort.wildlife"
}, ci = {
	conservation: "games.parkseurope.top.conservation",
	carabiner: "games.parkseurope.top.carabiner",
	mug: "games.parkseurope.top.mug",
	chalet: "games.parkseurope.top.chalet"
}, li = {
	die: "games.parkseurope.benefit.die",
	parks: "games.parkseurope.benefit.parks",
	mug: "games.parkseurope.benefit.mug",
	wonder: "games.parkseurope.benefit.wonder",
	photo: "games.parkseurope.benefit.photo",
	wildlife: "games.parkseurope.benefit.wildlife",
	carabiner: "games.parkseurope.benefit.carabiner"
}, ui = {
	snow: "games.parkseurope.res.snow",
	wonder: "games.parkseurope.site.wonder",
	mug: "games.parkseurope.site.mug",
	photo: "games.parkseurope.site.photo",
	wildlife: "games.parkseurope.res.wildlife",
	carabiner: "games.parkseurope.token.carabiner",
	die: "games.parkseurope.site.die",
	chalet: "games.parkseurope.top.chalet"
}, di = {
	consForest: "games.parkseurope.campfire.consForest",
	consMountain: "games.parkseurope.campfire.consMountain",
	consSun: "games.parkseurope.campfire.consSun",
	consWater: "games.parkseurope.campfire.consWater",
	iconForest: "games.parkseurope.campfire.iconForest",
	iconMountain: "games.parkseurope.campfire.iconMountain",
	iconSun: "games.parkseurope.campfire.iconSun",
	iconWater: "games.parkseurope.campfire.iconWater",
	anyIcons: "games.parkseurope.campfire.anyIcons",
	album: "games.parkseurope.campfire.album",
	wonderHand: "games.parkseurope.campfire.wonderHand",
	snow: "games.parkseurope.campfire.snow",
	turnWildlife2: "games.parkseurope.campfire.turnWildlife2",
	turnAny2: "games.parkseurope.campfire.turnAny2",
	turnCarabiner: "games.parkseurope.campfire.turnCarabiner",
	turnAny3: "games.parkseurope.campfire.turnAny3"
}, fi = [
	"games.parkseurope.consProject.p0",
	"games.parkseurope.consProject.p1",
	"games.parkseurope.consProject.p2",
	"games.parkseurope.consProject.p3",
	"games.parkseurope.consProject.p4",
	"games.parkseurope.consProject.p5",
	"games.parkseurope.consProject.p6"
], pi = {
	move: "games.parkseurope.pending.move",
	trailEnd: "games.parkseurope.pending.trailEnd",
	actions: "games.parkseurope.pending.actions",
	parks: "games.parkseurope.pending.parks",
	mug: "games.parkseurope.pending.mug",
	mugChoice: "games.parkseurope.pending.mugChoice",
	cons: "games.parkseurope.pending.cons",
	assignWild: "games.parkseurope.pending.assignWild",
	freePark: "games.parkseurope.pending.freePark",
	discardRes: "games.parkseurope.pending.discardRes",
	discardWonder: "games.parkseurope.pending.discardWonder",
	gretaColor: "games.parkseurope.pending.gretaColor",
	scoring: "games.parkseurope.pending.scoring",
	none: "games.parkseurope.pending.none"
}, mi = {
	mountain: "#6b7c8f",
	forest: "#3f7a4d",
	sun: "#d9a227",
	water: "#3a7ca5",
	wildlife: "#8a5a44",
	snow: "#cfe3ee",
	any: "#8b8578"
};
function hi(e, t) {
	return We(e.res, t) !== null;
}
function gi({ color: e, label: t, greta: n, avatar: r, selected: i }) {
	return /* @__PURE__ */ b("span", {
		className: "pke-hiker-mark",
		"data-selected": i,
		style: { "--pke-mark": e },
		role: "img",
		"aria-label": t,
		title: t,
		children: n ? /* @__PURE__ */ b("i", {
			className: "pke-greta-glyph",
			"aria-hidden": !0
		}) : /* @__PURE__ */ b("img", {
			src: r,
			alt: "",
			draggable: !1
		})
	});
}
function _i(e) {
	let t = e.public, n = e.private ?? {
		hand: [],
		isTurn: !1
	};
	return /* @__PURE__ */ b(vi, {
		pub: t,
		hand: n.hand,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function vi({ pub: e, hand: t, members: n, myRid: r, send: a }) {
	let v = u();
	g();
	let S = e.players.find((e) => e.rid === r), C = e.phase === "turn" && e.turn === r && !!S, ee = e.phase === "scoring" && e.turn === r && !!S, [w, te] = s(r), [T, E] = s(0), [D, O] = s(null), [k, ne] = s(null), [re, ie] = s(null), [ae, A] = s({ ...Qr }), [oe, se] = s(""), [ce, le] = s(""), [ue, j] = s("overview"), [de, fe] = s(0), [pe, me] = s(null), [he, ge] = s({
		panel: null,
		id: 0
	}), [_e, ve] = s(null), [M, ye] = s(null), [be, xe] = s("display"), [Se, Ce] = s("route"), [we, I] = s(0), De = o(null), Oe = o(!1), { root: ke, capture: je, record: Me, active: Ne, timing: Pe } = rr(e, t, r);
	i(() => {
		let e = De.current;
		e && (e.scrollTop = 0, Oe.current && (Oe.current = !1, e.querySelector("#pke-panel-parks .pke-park-face[aria-pressed=\"true\"]")?.focus()));
	}, [
		pe,
		he,
		be,
		Se
	]);
	let Ie = e.players.find((e) => e.rid === w) ?? e.players.find((e) => e.rid === r) ?? e.players[0], Le = (e) => n.find((t) => t.rid === e), R = (t) => t === "$greta" ? v("games.parkseurope.greta") : Le(t)?.name || v(h[(Le(t)?.colorIndex ?? Math.max(0, e.order.indexOf(t))) % h.length].nameKey), Re = (e) => e === "$greta" ? $r : h[(Le(e)?.colorIndex ?? 0) % h.length].hex, ze = (e) => c[(Le(e)?.avatar ?? 0) % c.length], Be = (t) => e.greta?.solo ? ei[Math.floor(t / 2) % ei.length] : $r, Ve = (e, t) => `${R(e)} · ${v("games.parkseurope.hikerLabel", { n: t + 1 })}`, He = (e, t, n) => {
		let i = e === r && t === V, a = Ve(e, t) + (i ? " · " + v("games.parkseurope.selectedHiker") : "");
		return e === "$greta" ? /* @__PURE__ */ b(gi, {
			greta: !0,
			color: Be(t),
			label: a
		}, n) : /* @__PURE__ */ b(gi, {
			color: Re(e),
			avatar: ze(e),
			label: a,
			selected: i
		}, n);
	}, Ue = (t) => {
		let n = [];
		for (let r of e.players) r.hikers.forEach((e, i) => {
			e === t && n.push({
				rid: r.rid,
				hiker: i
			});
		});
		return e.greta && e.greta.hikers.forEach((e, r) => {
			e === t && n.push({
				rid: "$greta",
				hiker: r
			});
		}), n;
	}, We = (n) => e.campfires.includes(n) || t.some((e) => !!L[e]), Ge = `${e.season}:${e.turn}:${e.moved}:${e.pending}:${S?.hikers.join(",") ?? ""}:${t.length}`;
	if (ce !== Ge && (le(Ge), S)) {
		let e = S.hikers.map((e, t) => e < 8 ? t : -1).filter((e) => e >= 0);
		E(e.includes(T) ? T : e[0] ?? 0);
	}
	let Ke = S ? Zr.reduce((e, t) => e + S.res[t], 0) : 0, qe = e.pending === "discardRes" ? "discardRes" : e.pending === "discardWonder" ? "discardWonder" : e.pending === "assignWild" ? "assignWild" : e.pending === "freePark" ? "freePark" : null, Je = `${e.season}:${e.turn}:${e.pending}:${Ke}:${t.length}:${e.landingSite}`;
	if (Je !== oe && (se(Je), qe && C && O(qe)), !S) return /* @__PURE__ */ b(_, {
		adaptive: !0,
		className: "pke-screen",
		children: /* @__PURE__ */ b("p", {
			className: "pke-empty",
			children: v("games.parkseurope.err.notPlayer")
		})
	});
	let Ye = C && e.pending === "parks" ? "parks" : C && e.pending === "cons" ? "cons" : null, Xe = he.panel === Ye ? he.id : he.id + 1;
	he.panel !== Ye && ge({
		panel: Ye,
		id: Xe
	});
	let Ze = `${r}:${e.season}:${e.turn}:${S.hikers.join(",")}`;
	Ye === "parks" && _e?.turn !== Ze ? ve({
		turn: Ze,
		visits: S.visited.length
	}) : _e && (_e.turn !== Ze || [
		"actions",
		"move",
		"trailEnd",
		"none"
	].includes(e.pending)) && ve(null);
	let Qe = pe?.seat === r ? pe : null, z = Qe && (!Ye || Qe.prompt === Xe) ? Qe.panel : Ye, $e = (e) => {
		let t = e === null && Qe?.prompt === Xe && Qe.returnToParks;
		t && (Oe.current = !0), me({
			seat: r,
			prompt: Xe,
			panel: t ? "parks" : e,
			returnToParks: e !== null && e !== "parks" && (z === "parks" || !!Qe?.returnToParks)
		});
	}, et = M?.seat === r && (M.from === "display" ? e.parksDisplay : S.reserved).includes(M.id) ? M : null, tt = Zr.filter((e) => S.res[e]), nt = S.visited.at(-1), rt = nt && Ye === "parks" && _e?.turn === Ze && S.visited.length > _e.visits ? N[nt.id] : null, it = (e) => e === "$greta" ? /* @__PURE__ */ b(gi, {
		greta: !0,
		color: $r,
		label: R(e)
	}) : /* @__PURE__ */ b(gi, {
		color: Re(e),
		avatar: ze(e),
		label: R(e)
	}), at = e.consDeck > 0 && (e.freeCons || hi(S, {
		sun: 1,
		water: 1
	})), ot = S.hikers[T] < 8 || S.hikers[1 - T] >= 8 ? T : +(T === 0), B = S.hikers[ot], V = C && B < 8 ? ot : null, H = /* @__PURE__ */ new Set();
	if (C && (e.pending === "move" || e.pending === "trailEnd")) {
		if (e.pending === "trailEnd") H.add(8);
		else if (B < 8) {
			for (let e = B + 1; e <= 7; e++) (Ue(e).length === 0 || We(e)) && H.add(e);
			H.add(8);
		}
	}
	let U = (e) => {
		Me(e), a(e);
	}, W = (e) => {
		if (H.has(e)) {
			if (fe(ot), e === 8) {
				O("trailEnd");
				return;
			}
			if (Ue(e).length > 0) {
				ne({
					hiker: ot,
					to: e
				}), O("campfire");
				return;
			}
			U({
				type: "move",
				hiker: ot,
				to: e
			});
		}
	}, st = e.phase === "ended" || e.pending === "none" ? v("games.parkseurope.pending.none") : ee ? v("games.parkseurope.pending.scoring") : C ? v(pi[e.pending]) : v("games.parkseurope.waitingFor", { name: R(e.turn ?? "") }), ct = ni[e.seasonCard] ? v(ni[e.seasonCard]) : e.seasonCard, lt = e.landingSite === null ? null : e.vf[e.landingSite - 1], ut = C && e.pending === "actions" && !e.vfUsed && e.landingSite !== null && lt !== null && S.carabiners > 0, dt = e.landingSite === null ? null : e.trailSites[e.landingSite - 1], ft = dt ? Fe(dt) : null, pt = ft ? S.cons.map((e, t) => ({
		id: e,
		i: t
	})).filter(({ id: t, i: n }) => F(t) === ft && !e.consUsed.includes(n)) : [], mt = !e.end || e.end.topDone && e.end.parksDone, ht = t.filter((t) => !!L[t] && ti.has(L[t].effect) && !e.campfireUsed.includes(t)), gt = Zr.reduce((e, t) => e + ae[t], 0), _t = /* @__PURE__ */ x("div", {
		className: "pke-actions",
		children: [/* @__PURE__ */ b("div", {
			className: "pke-actions-hikers",
			role: "group",
			"aria-label": v("games.parkseurope.chooseHiker"),
			children: [0, 1].map((t) => {
				let n = t, r = S.hikers[n];
				return /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-hiker",
					"data-on": V === n,
					disabled: !C || r >= 8 || e.pending !== "move" && e.pending !== "trailEnd",
					"aria-pressed": V === n,
					onClick: () => {
						E(n), fe(n);
					},
					children: [
						/* @__PURE__ */ b("b", { children: v("games.parkseurope.hikerLabel", { n: t + 1 }) }),
						/* @__PURE__ */ b("span", { children: r >= 8 ? v("games.parkseurope.atEnd") : r === 0 ? v("games.parkseurope.trailStart") : v("games.parkseurope.siteNo", { n: r }) }),
						V === n && /* @__PURE__ */ b("small", {
							className: "pke-hiker-selected",
							"aria-hidden": !0,
							children: v("games.parkseurope.selectedHiker")
						})
					]
				}, n);
			})
		}), /* @__PURE__ */ b("div", {
			className: "pke-actions-main",
			children: e.pending === "gretaColor" && C ? /* @__PURE__ */ b(y, { children: [0, 1].map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({
					type: "gretaColor",
					first: e
				}),
				children: [/* @__PURE__ */ b("i", {
					className: "pke-pair-dot",
					style: { background: ei[e] },
					"aria-hidden": !0
				}), v(e === 0 ? "games.parkseurope.gretaPairA" : "games.parkseurope.gretaPairB")]
			}, e)) }) : e.phase === "scoring" ? ee ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => O("scoring"),
				children: v("games.parkseurope.scoringTitle")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => {
					U({ type: "scoringDone" }), O(null), ie(null), A({ ...Qr });
				},
				children: v("games.parkseurope.scoringDone")
			})] }) : null : !C || e.pending === "move" || e.pending === "trailEnd" ? null : e.pending === "parks" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => $e("parks"),
				children: v("games.parkseurope.fieldChoosePark")
			}) : e.pending === "mug" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: S.mug >= 3,
				onClick: () => U({
					type: "mug",
					act: "fill"
				}),
				children: v("games.parkseurope.mug.fill")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				disabled: S.mug < 1,
				onClick: () => U({
					type: "mug",
					act: "drink"
				}),
				children: v("games.parkseurope.mug.drink")
			})] }) : e.pending === "mugChoice" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => U({
					type: "mugChoice",
					choice: "chalet"
				}),
				children: v("games.parkseurope.mug.chalet")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({
					type: "mugChoice",
					choice: "cons"
				}),
				children: v("games.parkseurope.mug.cons")
			})] }) : e.pending === "cons" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: !at,
				onClick: () => U({
					type: "consPick",
					deck: !0
				}),
				children: [
					v("games.parkseurope.startDeck"),
					" · ",
					e.freeCons ? v("games.parkseurope.free") : v("games.parkseurope.deckCost")
				]
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({ type: "skip" }),
				children: v("games.parkseurope.skip")
			})] }) : e.pending === "assignWild" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("assignWild"),
				children: v("games.parkseurope.assignWildPrompt")
			}) : e.pending === "freePark" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("freePark"),
				children: v("games.parkseurope.freeParkPrompt")
			}) : e.pending === "discardRes" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("discardRes"),
				children: v("games.parkseurope.discardResPrompt")
			}) : e.pending === "discardWonder" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("discardWonder"),
				children: v("games.parkseurope.discardWonderPrompt")
			}) : /* @__PURE__ */ x(y, { children: [
				e.end?.action && !e.end.topDone && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "endTop" }),
					children: [
						v("games.parkseurope.endTop"),
						" · ",
						v(ci[e.end.action])
					]
				}),
				e.end && !e.end.parksDone && /* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "endParks" }),
					children: v("games.parkseurope.endParksTodo")
				}),
				dt && !e.siteDone && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "siteAction" }),
					children: [
						v("games.parkseurope.siteAction"),
						" · ",
						v(oi[dt])
					]
				}),
				pt.length > 0 && /* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => O("activateCons"),
					children: v("games.parkseurope.activateCons")
				}),
				ut && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => U({ type: "viaFerrata" }),
					children: [v("games.parkseurope.viaFerrata"), lt ? ` · ${v(si[lt])}` : ""]
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					disabled: !mt,
					onClick: () => U({ type: "endTurn" }),
					children: v("games.parkseurope.endTurn")
				})
			] })
		})]
	});
	return /* @__PURE__ */ x("div", {
		className: "pke-motion-root",
		ref: ke,
		onClickCapture: je,
		children: [/* @__PURE__ */ x(_, {
			adaptive: !0,
			scroll: !1,
			className: "pke-screen",
			children: [
				/* @__PURE__ */ x("div", {
					className: "pke-layout",
					children: [
						/* @__PURE__ */ x("div", {
							className: "pke-field-stage",
							children: [
								/* @__PURE__ */ b(Kr, {
									mode: ue,
									season: e.season,
									resetKey: we,
									focused: `${r}:${de}`,
									hikers: [...e.players.flatMap((e) => e.hikers.map((t, n) => ({
										id: `${e.rid}:${n}`,
										site: t,
										color: Re(e.rid)
									}))), ...e.greta?.hikers.map((e, t) => ({
										id: `$greta:${t}`,
										site: e,
										color: Be(t)
									})) ?? []],
									sites: Array.from({ length: 9 }, (t, n) => {
										let i = e.trailSites[n - 1];
										return {
											label: n === 0 ? v("games.parkseurope.trailStart") : n === 8 ? v("games.parkseurope.trailEnd") : `${n} ${v(oi[i])}`,
											color: i && Fe(i) ? mi[Fe(i)] : n === 8 ? "#f6b396" : "#efd999",
											current: S.hikers[ue === "follow" ? de : ot] === n,
											legal: H.has(n),
											selected: V !== null && B === n ? Ve(r, V) + " · " + v("games.parkseurope.selectedHiker") : void 0,
											icon: i && /* @__PURE__ */ b(K, { kind: Xr[i] }),
											occupants: Ue(n).map((e) => He(e.rid, e.hiker, `${e.rid}:${e.hiker}`))
										};
									}),
									onSite: W,
									fallback: v("games.parkseurope.valleyUnavailable")
								}),
								/* @__PURE__ */ b("div", {
									className: "pke-field-heading",
									children: /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ x("strong", { children: ["PARKS ", /* @__PURE__ */ b("em", { children: "EUROPE" })] }), /* @__PURE__ */ x("span", { children: [
										v("games.parkseurope.seasonLabel", { n: e.season }),
										" · ",
										ct
									] })] })
								}),
								/* @__PURE__ */ b("div", {
									className: "pke-field-roster",
									children: e.players.map((t) => /* @__PURE__ */ x("button", {
										type: "button",
										"data-turn": e.turn === t.rid,
										"aria-label": R(t.rid) + " · " + v("games.parkseurope.visitedCount", { n: t.visited.length }),
										"aria-expanded": z === "pack" && Ie.rid === t.rid,
										onClick: () => {
											te(t.rid), $e("pack");
										},
										children: [it(t.rid), /* @__PURE__ */ b("b", { children: R(t.rid) })]
									}, t.rid))
								}),
								/* @__PURE__ */ x("button", {
									type: "button",
									className: "pke-field-resources",
									"aria-label": v("games.parkseurope.fieldPack"),
									"data-kinds": tt.length + Number(S.snow > 0),
									"aria-expanded": z === "pack" && Ie.rid === r,
									onClick: () => {
										te(r), $e(z === "pack" && Ie.rid === r ? null : "pack");
									},
									children: [/* @__PURE__ */ x("span", {
										className: "pke-resource-counts",
										children: [
											tt.map((e) => /* @__PURE__ */ b(q, {
												kind: e,
												count: S.res[e]
											}, e)),
											S.snow > 0 && /* @__PURE__ */ b(q, {
												kind: "snow",
												count: S.snow
											}),
											!Ke && !S.snow && /* @__PURE__ */ b(m, {})
										]
									}), /* @__PURE__ */ x("span", {
										className: "pke-resource-load",
										children: [/* @__PURE__ */ b(m, {}), /* @__PURE__ */ x("b", { children: [Ke + S.snow * 2, " / 12"] })]
									})]
								}),
								/* @__PURE__ */ x("div", {
									className: "pke-camera",
									role: "group",
									"aria-label": v("games.parkseurope.camera"),
									children: [
										/* @__PURE__ */ x("button", {
											type: "button",
											"aria-pressed": ue === "overview",
											onClick: () => j("overview"),
											children: [/* @__PURE__ */ b(f, {}), v("games.parkseurope.overview")]
										}),
										/* @__PURE__ */ x("button", {
											type: "button",
											"aria-pressed": ue === "follow",
											onClick: () => j("follow"),
											children: [/* @__PURE__ */ b(p, {}), v("games.parkseurope.follow")]
										}),
										/* @__PURE__ */ b("button", {
											type: "button",
											"aria-label": v("games.parkseurope.fieldResetCamera"),
											onClick: () => {
												j("overview"), I((e) => e + 1);
											},
											children: "⌖"
										})
									]
								})
							]
						}),
						e.phase === "scoring" && e.revealedCampfire && /* @__PURE__ */ x("section", {
							className: "pke-panel pke-scoring",
							children: [/* @__PURE__ */ x("header", {
								className: "pke-section-head",
								children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.scoringTitle") }), /* @__PURE__ */ b("span", {
									className: "pke-sub",
									children: v("games.parkseurope.scoringPrompt")
								})]
							}), /* @__PURE__ */ b("ul", {
								className: "pke-scoring-list",
								children: e.revealedCampfire.map(({ rid: t, cards: n }) => {
									let r = e.players.find((e) => e.rid === t);
									return /* @__PURE__ */ x("li", {
										"data-on": e.turn === t,
										children: [
											/* @__PURE__ */ b("b", { children: R(t) }),
											/* @__PURE__ */ b("span", { children: n.length === 0 ? v("games.parkseurope.scoringEmpty") : n.map((t) => {
												let n = L[t]?.effect, r = e.campfireUsed.includes(t);
												return `${Mn(v, t)}${n ? ` · ${v(di[n])}` : ""}${r ? ` · ${v("games.parkseurope.scoringUsed")}` : ""}`;
											}).join("、") }),
											/* @__PURE__ */ b("span", {
												className: "pke-scoring-points",
												children: v("games.parkseurope.over.endgame", { n: r?.endPoints ?? 0 })
											})
										]
									}, t);
								})
							})]
						}),
						/* @__PURE__ */ x("section", {
							className: "pke-action-hud",
							"aria-label": v("games.parkseurope.fieldAction"),
							children: [/* @__PURE__ */ b("header", {
								className: "pke-action-title",
								"aria-live": "polite",
								children: st
							}), _t]
						}),
						/* @__PURE__ */ b("nav", {
							className: "pke-field-nav",
							"aria-label": v("games.parkseurope.fieldPanels"),
							children: Yr.map(({ id: e, label: n }) => /* @__PURE__ */ x("button", {
								type: "button",
								"data-panel": e,
								"aria-expanded": z === e,
								"aria-controls": `pke-panel-${e}`,
								onClick: () => {
									e === "pack" && z !== e && te(r), $e(z === e ? null : e);
								},
								children: [
									e === "pack" ? /* @__PURE__ */ b(m, {}) : e !== "trail" && /* @__PURE__ */ b(K, { kind: e === "hand" ? "wonder" : e }),
									/* @__PURE__ */ b("span", { children: v(n) }),
									e === "hand" && /* @__PURE__ */ b("b", { children: t.length })
								]
							}, e))
						}),
						/* @__PURE__ */ x("div", {
							"data-panel": z,
							className: "pke-boards pke-field-drawer",
							hidden: z === null,
							onKeyDown: (e) => {
								e.key === "Escape" && (e.stopPropagation(), $e(null));
							},
							children: [/* @__PURE__ */ b("button", {
								type: "button",
								className: "pke-field-close",
								"aria-label": v("games.parkseurope.closePanel"),
								onClick: () => $e(null),
								children: /* @__PURE__ */ b(d, {})
							}), /* @__PURE__ */ x("div", {
								ref: De,
								className: "pke-field-scroll",
								children: [
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-parks",
										hidden: z !== "parks",
										id: "pke-panel-parks",
										children: [
											/* @__PURE__ */ x("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.parksTitle") }), /* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: v("games.parkseurope.deckCount", { n: e.parksDeck })
												})]
											}),
											/* @__PURE__ */ b(or, {
												items: [["display", v("games.parkseurope.fieldDisplay")], ["reserved", v("games.parkseurope.fieldReserved", { n: S.reserved.length })]],
												active: be,
												onSelect: xe,
												label: v("games.parkseurope.parksTitle")
											}),
											/* @__PURE__ */ b("div", {
												className: "pke-card-row",
												children: (be === "display" ? e.parksDisplay : S.reserved).map((t, n) => {
													let i = N[t];
													return i ? /* @__PURE__ */ b(In, {
														park: i,
														suitLabel: v(ii[i.suit]),
														bonus: be === "display" ? e.parksBonus[n] : null,
														effect: i.instant ? v(ui[i.instant]) : void 0,
														picked: et?.id === t && et.from === be,
														onPick: () => ye({
															seat: r,
															id: t,
															from: be
														})
													}, t) : null;
												})
											}),
											be === "reserved" && !S.reserved.length && /* @__PURE__ */ b("p", {
												className: "pke-muted",
												children: v("games.parkseurope.fieldNoReserved")
											}),
											et?.from === be && C && e.pending === "parks" && (() => {
												let t = N[et.id], n = hi(S, t.cost);
												return /* @__PURE__ */ x("div", {
													className: "pke-park-choice",
													"aria-live": "polite",
													children: [/* @__PURE__ */ b("strong", { children: jn(v, t.id) }), /* @__PURE__ */ x("div", {
														className: "pke-card-actions",
														children: [et.from === "display" && !rt && /* @__PURE__ */ b("button", {
															type: "button",
															className: "pke-btn pke-btn--quiet",
															onClick: () => U({
																type: "reserve",
																from: "display",
																index: e.parksDisplay.indexOf(t.id)
															}),
															children: v("games.parkseurope.reserve")
														}), /* @__PURE__ */ b("button", {
															type: "button",
															className: "pke-btn pke-btn--main",
															disabled: !n,
															onClick: () => U({
																type: "visit",
																parkId: t.id
															}),
															children: v(n ? "games.parkseurope.visit" : "games.parkseurope.cannotAfford")
														})]
													})]
												});
											})(),
											C && e.pending === "parks" && /* @__PURE__ */ x("div", {
												className: "pke-park-footer",
												children: [rt ? /* @__PURE__ */ x("output", {
													className: "pke-park-receipt",
													children: [
														/* @__PURE__ */ b(K, { kind: "parks" }),
														" ",
														v("games.parkseurope.fieldVisitedPark", {
															name: jn(v, rt.id),
															n: rt.points
														})
													]
												}) : e.parksDeck > 0 && /* @__PURE__ */ x("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => U({
														type: "reserve",
														from: "deck"
													}),
													children: [
														v("games.parkseurope.reserve"),
														" · ",
														v("games.parkseurope.startDeck")
													]
												}), /* @__PURE__ */ b("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => U({ type: "parksDone" }),
													children: v("games.parkseurope.fieldFinishParks")
												})]
											})
										]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-cons",
										hidden: z !== "cons",
										id: "pke-panel-cons",
										children: [/* @__PURE__ */ x("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.consTitle") }), /* @__PURE__ */ b("span", {
												className: "pke-sub",
												children: v("games.parkseurope.consAwardsLabel", { n: e.consAwardsLeft })
											})]
										}), /* @__PURE__ */ b("div", {
											className: "pke-card-row pke-project-row",
											children: e.consDisplay.map((t, n) => {
												let r = F(t), i = Ee[t % 7], a = C && e.pending === "cons", o = a && e.freeCons, s = o || hi(S, Te[r]);
												return /* @__PURE__ */ b(Jn, {
													id: t,
													name: v(fi[t % 7]),
													site: v("games.parkseurope.projectSite", { resource: v(ri[r]) }),
													benefit: v(li[i.benefit]),
													free: o,
													bonus: e.consBonus[n],
													action: a ? {
														label: v(s ? o ? "games.parkseurope.free" : "games.parkseurope.support" : "games.parkseurope.cannotAfford"),
														disabled: !s,
														onPress: () => U({
															type: "consPick",
															index: n
														})
													} : void 0
												}, t);
											})
										})]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel",
										hidden: z !== "trail",
										id: "pke-panel-trail",
										children: [
											/* @__PURE__ */ b("header", {
												className: "pke-section-head",
												children: /* @__PURE__ */ b("h2", { children: v("games.parkseurope.fieldTrailSeason") })
											}),
											/* @__PURE__ */ b(or, {
												items: [
													["route", v("games.parkseurope.fieldTrailRoute")],
													["end", v("games.parkseurope.fieldEndActions")],
													["season", v("games.parkseurope.fieldSeasonTab")]
												],
												active: Se,
												onSelect: Ce,
												label: v("games.parkseurope.fieldTrailSeason")
											}),
											Se === "route" && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("div", {
												className: "pke-route-head",
												"aria-hidden": !0,
												children: [
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldStop") }),
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldExtras") }),
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldHikers") })
												]
											}), /* @__PURE__ */ b("ol", {
												className: "pke-route",
												children: Array.from({ length: 9 }, (t, n) => {
													let r = e.trailSites[n - 1], i = e.vf[n - 1], a = e.trailBonus[n - 1], o = v(n === 0 ? "games.parkseurope.trailStart" : n === 8 ? "games.parkseurope.trailEnd" : oi[r]), s = H.has(n);
													return /* @__PURE__ */ x("li", {
														className: "pke-route-stop",
														"data-legal": s,
														"aria-current": e.landingSite === n ? "location" : void 0,
														children: [
															/* @__PURE__ */ b("b", {
																className: "pke-route-number",
																children: n === 0 ? v("games.parkseurope.fieldStartShort") : n === 8 ? v("games.parkseurope.fieldEndShort") : n
															}),
															/* @__PURE__ */ x("span", {
																className: "pke-route-name",
																children: [r && /* @__PURE__ */ b(K, { kind: Xr[r] }), s || n === 8 ? /* @__PURE__ */ b("button", {
																	type: "button",
																	"aria-label": s ? v("games.parkseurope.fieldGoTo", { name: o }) : o,
																	onClick: () => {
																		s ? ($e(null), W(n)) : Ce("end");
																	},
																	children: o
																}) : /* @__PURE__ */ b("strong", {
																	title: r ? v(ai[r]) : void 0,
																	children: o
																})]
															}),
															/* @__PURE__ */ x("span", {
																className: "pke-route-extras",
																children: [
																	i && /* @__PURE__ */ x("span", { children: [
																		v("games.parkseurope.viaFerrata"),
																		" · ",
																		v(si[i])
																	] }),
																	a && /* @__PURE__ */ x("span", { children: [
																		v("games.parkseurope.fieldSeasonTab"),
																		" ",
																		/* @__PURE__ */ b(q, { kind: a })
																	] }),
																	e.campfires.includes(n) && /* @__PURE__ */ b("span", { children: v("games.parkseurope.campfireLabel") }),
																	n === 4 && /* @__PURE__ */ b("span", { children: v("games.parkseurope.shutterbug") })
																]
															}),
															/* @__PURE__ */ b("span", {
																className: "pke-route-hikers",
																children: Ue(n).map((e) => He(e.rid, e.hiker, e.rid + ":" + e.hiker))
															})
														]
													}, n);
												})
											})] }),
											Se === "end" && /* @__PURE__ */ b(dr, {
												pub: e,
												nameOf: R,
												marker: it,
												actionName: (e) => v(ci[e])
											}),
											Se === "season" && /* @__PURE__ */ b(fr, {
												pub: e,
												name: ct
											})
										]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-chalet",
										hidden: z !== "chalet",
										id: "pke-panel-chalet",
										children: [/* @__PURE__ */ b("header", {
											className: "pke-section-head",
											children: /* @__PURE__ */ b("h2", { children: v("games.parkseurope.chaletTrack") })
										}), /* @__PURE__ */ b(lr, {
											pub: e,
											nameOf: R,
											marker: it
										})]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-mat",
										hidden: z !== "pack",
										id: "pke-panel-pack",
										children: [/* @__PURE__ */ x("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ b("h2", { children: Ie.rid === r ? v("games.parkseurope.myMat") : v("games.parkseurope.otherMat", { name: R(Ie.rid) }) }), Ie.shutterbug && /* @__PURE__ */ b("span", {
												className: "pke-badge",
												children: v("games.parkseurope.shutterbug")
											})]
										}), /* @__PURE__ */ b(yi, {
											p: Ie,
											t: v,
											name: R(Ie.rid)
										}, Ie.rid)]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-hand",
										hidden: z !== "hand",
										id: "pke-panel-hand",
										children: [
											/* @__PURE__ */ x("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.handTitle") }), /* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: t.length
												})]
											}),
											t.length === 0 ? /* @__PURE__ */ b("p", {
												className: "pke-muted",
												children: v("games.parkseurope.handEmpty")
											}) : /* @__PURE__ */ b("div", {
												className: "pke-hand-row pke-wonder-hand",
												children: t.map((e, t) => {
													let n = Ae[e], r = L[e];
													return /* @__PURE__ */ b(Kn, {
														id: e,
														campEffect: r && v(di[r.effect]),
														waiting: !C,
														canUse: (e) => !n?.[e].pay || hi(S, n[e].pay),
														onPlay: n ? (t) => U({
															type: "playWonder",
															card: e,
															side: t
														}) : void 0
													}, e + ":" + t);
												})
											}),
											e.soloRanks && /* @__PURE__ */ b("p", {
												className: "pke-solo-ranks",
												children: v("games.parkseurope.soloRankTable")
											})
										]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ b(l, {
					open: D === "trailEnd",
					onClose: () => O(null),
					label: v("games.parkseurope.chooseSlot"),
					title: v("games.parkseurope.chooseSlot"),
					children: /* @__PURE__ */ b(dr, {
						pub: e,
						nameOf: R,
						marker: it,
						actionName: (e) => v(ci[e]),
						onTake: (e, t) => {
							e === "parks" ? U({
								type: "move",
								hiker: ot,
								to: 8,
								slot: { kind: e }
							}) : t && U({
								type: "move",
								hiker: ot,
								to: 8,
								slot: {
									kind: e,
									action: t
								}
							}), O(null);
						}
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "campfire",
					onClose: () => {
						O(null), ne(null);
					},
					label: v("games.parkseurope.occupiedPrompt"),
					title: v("games.parkseurope.occupiedPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-choice-list",
						children: [k && e.campfires.includes(k.to) && /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "move",
									hiker: k.hiker,
									to: k.to,
									campfire: "communal"
								}), O(null), ne(null);
							},
							children: v("games.parkseurope.useCommunalCampfire")
						}), k && t.filter((e) => !!L[e]).map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "move",
									hiker: k.hiker,
									to: k.to,
									campfire: "card",
									card: e
								}), O(null), ne(null);
							},
							children: [
								v("games.parkseurope.useCampfireCard"),
								" · ",
								Mn(v, e)
							]
						}, e))]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "assignWild",
					onClose: () => O(null),
					label: v("games.parkseurope.assignWildPrompt"),
					title: v("games.parkseurope.assignWildPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-choice-list",
						children: P.filter((e) => S.visited.some((t) => t.suit === e)).map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "assignWild",
									suit: e
								}), O(null);
							},
							children: v(ii[e])
						}, e))
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "freePark",
					onClose: () => O(null),
					label: v("games.parkseurope.freeParkPrompt"),
					title: v("games.parkseurope.freeParkPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-pick-gallery",
						children: [[{
							from: "display",
							ids: e.parksDisplay,
							title: "fieldDisplay"
						}, {
							from: "reserve",
							ids: S.reserved,
							title: "reservedTitle"
						}].filter(({ ids: e }) => e.length > 0).map(({ from: t, ids: n, title: r }) => /* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("h3", { children: v(`games.parkseurope.${r}`) }), /* @__PURE__ */ b("div", {
							className: "pke-pick-grid",
							children: n.map((n, r) => {
								let i = N[n];
								return /* @__PURE__ */ b(In, {
									park: i,
									suitLabel: v(ii[i.suit]),
									effect: i.instant && v(ui[i.instant]),
									bonus: t === "display" ? e.parksBonus[r] : null,
									picked: !1,
									free: !0,
									onPick: () => {
										U({
											type: "freePark",
											parkId: n,
											from: t
										}), O(null);
									}
								}, n);
							})
						})] }, t)), /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-btn pke-btn--quiet",
							disabled: !e.parksDeck,
							onClick: () => {
								U({
									type: "freePark",
									from: "deck"
								}), O(null);
							},
							children: v("games.parkseurope.startDeck")
						})]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "discardRes",
					onClose: () => O(null),
					label: v("games.parkseurope.discardResPrompt"),
					title: v("games.parkseurope.discardResPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-choice-list",
						children: Zr.filter((e) => S.res[e] > 0).map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "discardRes",
									res: e
								}), O(null);
							},
							children: [
								/* @__PURE__ */ b(q, {
									kind: e,
									count: S.res[e]
								}),
								" ",
								v(ri[e])
							]
						}, e))
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "discardWonder",
					onClose: () => O(null),
					label: v("games.parkseurope.discardWonderPrompt"),
					title: v("games.parkseurope.discardWonderPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-pick-grid pke-wonder-picker",
						children: t.map((e) => {
							let t = L[e];
							return /* @__PURE__ */ x("div", {
								className: "pke-pick-object",
								children: [/* @__PURE__ */ b(Kn, {
									id: e,
									campEffect: t && v(di[t.effect])
								}), /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									"aria-label": v("games.parkseurope.wonderDiscardName", { name: Mn(v, e) }),
									onClick: () => {
										U({
											type: "discardWonder",
											card: e
										}), O(null);
									},
									children: v("games.parkseurope.wonderDiscard")
								})]
							}, e);
						})
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "scoring",
					onClose: () => {
						O(null), ie(null), A({ ...Qr });
					},
					label: v("games.parkseurope.scoringTitle"),
					title: v("games.parkseurope.scoringTitle"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-scoring-sheet",
						children: [ht.length === 0 && /* @__PURE__ */ b("p", {
							className: "pke-muted",
							children: v("games.parkseurope.scoringEmpty")
						}), ht.map((e) => {
							let t = L[e].effect, n = t === "turnAny3" ? 3 : t === "turnAny2" ? 2 : 0, r = re === e;
							return /* @__PURE__ */ x("section", {
								className: "pke-scoring-card",
								"data-on": r,
								children: [/* @__PURE__ */ b(Kn, {
									id: e,
									campEffect: v(di[t])
								}), t === "turnWildlife2" ? /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: S.res.wildlife < 2,
									onClick: () => U({
										type: "campfireEnd",
										card: e,
										pay: { wildlife: 2 }
									}),
									children: S.res.wildlife < 2 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
								}) : t === "turnCarabiner" ? /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: S.carabiners < 1,
									onClick: () => U({
										type: "campfireEnd",
										card: e,
										carabiner: !0
									}),
									children: S.carabiners < 1 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
								}) : r ? /* @__PURE__ */ x(y, { children: [
									/* @__PURE__ */ b("div", {
										className: "pke-pay-row",
										children: Zr.map((e) => /* @__PURE__ */ x("span", {
											className: "pke-pay-res",
											style: { "--pke-res": mi[e] },
											children: [
												/* @__PURE__ */ b(K, { kind: e }),
												/* @__PURE__ */ b("button", {
													type: "button",
													"aria-label": `- ${v(ri[e])}`,
													disabled: ae[e] <= 0,
													onClick: () => A((t) => ({
														...t,
														[e]: t[e] - 1
													})),
													children: "−"
												}),
												/* @__PURE__ */ b("b", {
													className: "font-mono tabular-nums",
													children: ae[e]
												}),
												/* @__PURE__ */ b("button", {
													type: "button",
													"aria-label": `+ ${v(ri[e])}`,
													disabled: ae[e] >= S.res[e] || gt >= n,
													onClick: () => A((t) => ({
														...t,
														[e]: t[e] + 1
													})),
													children: "+"
												}),
												/* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: S.res[e]
												})
											]
										}, e))
									}),
									/* @__PURE__ */ x("p", {
										className: "pke-sub",
										children: [
											v("games.parkseurope.scoringPayPrompt", { n }),
											" · ",
											v("games.parkseurope.scoringPayChosen", { n: gt })
										]
									}),
									/* @__PURE__ */ x("div", {
										className: "pke-scoring-actions",
										children: [/* @__PURE__ */ b("button", {
											type: "button",
											className: "pke-btn pke-btn--main",
											disabled: gt !== n,
											onClick: () => {
												U({
													type: "campfireEnd",
													card: e,
													pay: { ...ae }
												}), ie(null), A({ ...Qr });
											},
											children: v("games.parkseurope.scoringPayConfirm")
										}), /* @__PURE__ */ b("button", {
											type: "button",
											className: "pke-btn pke-btn--quiet",
											onClick: () => {
												ie(null), A({ ...Qr });
											},
											children: v("games.parkseurope.scoringPayReset")
										})]
									})
								] }) : /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => {
										ie(e), A({ ...Qr });
									},
									children: v("games.parkseurope.useEffect")
								})]
							}, e);
						})]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: D === "activateCons",
					onClose: () => O(null),
					label: v("games.parkseurope.activateConsPrompt"),
					title: v("games.parkseurope.activateConsPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-pick-grid",
						children: [pt.length === 0 && /* @__PURE__ */ b("p", {
							className: "pke-muted",
							children: v("games.parkseurope.activateConsEmpty")
						}), pt.map(({ id: e, i: t }) => /* @__PURE__ */ b(Jn, {
							id: e,
							name: v(fi[e % 7]),
							site: v("games.parkseurope.projectSite", { resource: v(ri[F(e)]) }),
							benefit: v(li[Ee[e % 7].benefit]),
							supported: !0,
							action: {
								label: v("games.parkseurope.useEffect"),
								onPress: () => {
									U({
										type: "activateCons",
										card: t
									}), O(null);
								}
							}
						}, t))]
					})
				})
			]
		}), e.phase !== "ended" && /* @__PURE__ */ b(ar, {
			frame: Ne,
			timing: Pe,
			self: r,
			nameOf: R
		})]
	});
}
function yi({ p: e, t, name: n }) {
	let [r, i] = s(null), a = P.reduce((t, n) => t + e.parkAwards[n], 0) + e.consAwards + e.chaletAwards.length, o = P.find((t) => e.parkAwards[t] > 0), c = e.chaletAwards.at(-1), l = [
		[
			"album",
			"photo",
			"fieldAlbum",
			e.photos + e.albums
		],
		[
			"honors",
			"award",
			"fieldHonors",
			a
		],
		[
			"collection",
			"parks",
			"fieldCollection",
			e.visited.length
		],
		[
			"projects",
			"cons",
			"fieldSupported",
			e.cons.length
		]
	];
	return /* @__PURE__ */ x("div", {
		className: "pke-mat-body",
		"aria-label": n,
		children: [
			/* @__PURE__ */ b(Ln, { player: e }),
			/* @__PURE__ */ x("div", {
				className: "pke-mug-row",
				"aria-label": t("games.parkseurope.mug.level", { n: e.mug }),
				children: [
					/* @__PURE__ */ b(K, { kind: "mug" }),
					/* @__PURE__ */ b("span", { children: t("games.parkseurope.mug.track") }),
					[
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ b("i", {
						className: "pke-mug-pip",
						"data-on": e.mug >= t,
						"aria-hidden": !0
					}, t))
				]
			}),
			/* @__PURE__ */ b("div", {
				className: "pke-player-objects",
				role: "group",
				"aria-label": t("games.parkseurope.fieldPlayerItems"),
				children: l.map(([e, n, a, s]) => /* @__PURE__ */ x("button", {
					type: "button",
					"data-object": e,
					"data-empty": !s,
					"aria-expanded": r === e,
					"aria-controls": "pke-player-object",
					onClick: () => i(r === e ? null : e),
					children: [/* @__PURE__ */ b("span", {
						className: "pke-object-pose",
						"aria-hidden": !0,
						children: e === "album" ? /* @__PURE__ */ b(Hn, {}) : e === "honors" ? o ? /* @__PURE__ */ b(Bn, { award: {
							kind: "parks",
							suit: o,
							count: 1
						} }) : c === void 0 ? /* @__PURE__ */ b(Bn, { award: {
							kind: "cons",
							count: 1
						} }) : /* @__PURE__ */ b(Bn, { award: {
							kind: "chalet",
							points: c
						} }) : /* @__PURE__ */ b("span", {
							className: "pke-object-stack",
							children: /* @__PURE__ */ b(K, { kind: n })
						})
					}), /* @__PURE__ */ x("span", {
						className: "pke-object-label",
						children: [t(`games.parkseurope.${a}`), s > 0 && /* @__PURE__ */ b("b", { children: s })]
					})]
				}, e))
			}),
			/* @__PURE__ */ x("div", {
				id: "pke-player-object",
				hidden: r === null,
				children: [
					r === "album" && /* @__PURE__ */ x("div", {
						className: "pke-player-album",
						children: [/* @__PURE__ */ x("div", {
							className: "pke-photo-pieces",
							children: [Array.from({ length: e.photos }, (e, t) => /* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(K, { kind: "photo" }) }, "photo" + t)), Array.from({ length: e.albums }, (e, t) => /* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(Hn, {}) }, "album" + t))]
						}), /* @__PURE__ */ x("p", { children: [
							t("games.parkseurope.photos", { n: e.photos }),
							" · ",
							t("games.parkseurope.albums", { n: e.albums })
						] })]
					}),
					r === "honors" && /* @__PURE__ */ b(Vn, { player: e }),
					r === "collection" && (e.visited.length ? /* @__PURE__ */ b("div", {
						className: "pke-card-row",
						children: e.visited.map(({ id: e, suit: n }) => {
							let r = N[e];
							return /* @__PURE__ */ b(In, {
								park: r,
								suitLabel: t(ii[n ?? r.suit]),
								picked: !1,
								effect: r.instant ? t(ui[r.instant]) : void 0
							}, e);
						})
					}) : /* @__PURE__ */ b("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					})),
					r === "projects" && (e.cons.length ? /* @__PURE__ */ b("div", {
						className: "pke-card-row pke-project-row",
						children: e.cons.map((e, n) => /* @__PURE__ */ b(Jn, {
							id: e,
							name: t(fi[e % 7]),
							site: t("games.parkseurope.projectSite", { resource: t(ri[F(e)]) }),
							benefit: t(li[Ee[e % 7].benefit]),
							supported: !0
						}, e + ":" + n))
					}) : /* @__PURE__ */ b("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					}))
				]
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var bi = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], xi = {
	mountain: 1.1,
	forest: 1,
	sun: .9,
	water: .9,
	wildlife: 1.4
}, Si = {
	parks: 4.2,
	mug: 2.8,
	photo: 1.4,
	die: 1.6,
	wonder: 1.6,
	wildlife: 1.2,
	carabiner: 1.3
}, Ci = {
	conservation: 2.8,
	mug: 2.8,
	chalet: 1.6,
	carabiner: 1.4
}, wi = {
	wonder: 1.6,
	sunwater: 1.7,
	photo: 1.7,
	conservation: 2.2,
	mug: 2.4,
	wildlife: 1.2
}, Ti = {
	album: 3,
	wonderHand: 2,
	turnAny2: 3,
	turnAny3: 3,
	turnWildlife2: 1,
	turnCarabiner: 2,
	anyIcons: 2,
	consForest: 1.5,
	consMountain: 1.5,
	consSun: 1.5,
	consWater: 1.5,
	iconForest: 1.5,
	iconMountain: 1.5,
	iconSun: 1.5,
	iconWater: 1.5,
	snow: 1
};
function Ei() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Di(e, t) {
	return t && e.length > 1 && Ei() < .3 ? e[Math.floor(Ei() * e.length)] : e[0];
}
function Oi(e) {
	return e.sort((e, t) => t.score - e.score);
}
function ki(e, t) {
	return e.players.find((e) => e.rid === t);
}
function Ai(e, t) {
	let n = 0;
	for (let r of e.players) for (let e of r.hikers) e === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function ji(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, r = 0;
	for (let e of Object.keys(t)) {
		let i = t[e] ?? 0;
		e === "wildlife" ? r = i : n[e] = i;
	}
	if (e.res.wildlife < r) return !1;
	let i = e.res.wildlife - r, a = 0;
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a += Math.max(0, n[t] - e.res[t]);
	if (i < a) return !1;
	let o = n.mountain + n.forest + n.sun + n.water + r + a;
	return bi.reduce((t, n) => t + e.res[n], 0) - o >= n.any;
}
function Mi(e) {
	let t = 0;
	for (let n of Object.keys(e)) {
		let r = e[n] ?? 0;
		t += n === "any" ? r * 1 : n === "wildlife" ? r * 1.3 : r * xi[n];
	}
	return t;
}
function Ni(e) {
	return e ? e === "photo" ? 1.2 : e === "carabiner" ? 1.3 : e === "snow" ? .7 : xi[e] : 0;
}
function Pi(e, t) {
	return t === null ? null : e.vf[t - 1] ?? null;
}
function Fi(e, t) {
	let n = e.visited.filter((e) => e.suit === t).length;
	return n % 3 == 2 ? 2.2 : n % 3 == 1 ? .4 : 0;
}
function Ii(e, t) {
	let n = N[t];
	if (!n) return 0;
	let r = n.points;
	if (n.instant) {
		let t = n.instant;
		r += t === "photo" ? e.shutterbug ? 2 : 1 : t === "mug" ? 2.2 : t === "wonder" ? 1.3 : t === "chalet" || t === "die" ? 1.2 : t === "carabiner" ? 1 : t === "wildlife" ? .8 : .6;
	}
	if (n.suit === "wild") {
		let t = P.reduce((t, n) => Math.max(t, Fi(e, n)), 0);
		r += t;
	} else r += Fi(e, n.suit);
	return r;
}
function Li(e, t, n) {
	switch (e) {
		case "core-forest": return xi.forest;
		case "core-sun": return xi.sun * 2;
		case "core-mountain": return xi.mountain + .7;
		case "core-water": return xi.water * 2 + .7;
		case "wildlife": return xi.wildlife;
		case "carabiner": return 1.6;
		case "parks": return 4.2;
		case "die": return 1.7;
		case "photo": return t.shutterbug ? 2.4 : 1.4;
		case "mug": return t.mug >= 3 ? 3.4 : 2.6;
		case "chalet": return .6 + t.snow * 1;
		case "wonder": return 1.6;
		case "conservation": {
			let e = [...new Set(t.cons.map((e) => F(e)))];
			return 2.6 + (n.consAwardsLeft > 0 && e.length < 4 ? .7 : 0);
		}
	}
}
function Ri(e) {
	return e.filter((e) => !!Ae[e]);
}
function zi(e, t, n) {
	let r = Ae[t];
	if (!r) return null;
	let i = r[n];
	if (i.pay && !ji(e, i.pay)) return null;
	let a = 0;
	for (let t of i.grants) switch (t.t) {
		case "res":
			a += xi[t.res] * t.n;
			break;
		case "snow":
			a += .7 * t.n;
			break;
		case "carabiner":
			a += 1.3 * t.n;
			break;
		case "photo":
			a += (e.shutterbug ? 1.8 : 1.1) * t.n;
			break;
		case "wonder":
			a += 1.5 * t.n;
			break;
		case "die":
			a += 1.6 * t.n;
			break;
		case "parks":
			a += 4.2;
			break;
		case "mug":
			a += 2.6;
			break;
		case "cons":
			a += 2.6;
			break;
		case "chalet":
			a += .6 + e.snow;
			break;
		case "shutterbug": a += e.shutterbug ? .8 : 2.4;
	}
	return a - (i.pay ? Mi(i.pay) : 0);
}
function Bi(e, t) {
	let n = Ci[e];
	return t ? n + 4.2 : n;
}
function Vi(e) {
	let t = [];
	for (let n of e.endSlots) n.rid === null && t.push({
		v: {
			kind: n.kind,
			action: n.action
		},
		score: Bi(n.action, n.kind === "both")
	});
	return t.push({
		v: { kind: "parks" },
		score: 4.2
	}), Oi(t), t[0].v;
}
function Hi(e, t, n) {
	let r = [], i = new Set(e.cons.map((e) => F(e)));
	return t.consDisplay.forEach((t, a) => {
		let o = F(t), s = n ? {} : Te[o];
		if (!n && !ji(e, s)) return;
		let c = Si[Ui(t)];
		i.has(o) || (c += 1.6), c -= Mi(s) * .2, r.push({
			v: {
				type: "consPick",
				index: a
			},
			score: c
		});
	}), r.length > 0 ? (Oi(r), r[0].v) : t.consDeck > 0 && (n || ji(e, {
		sun: 1,
		water: 1
	})) ? {
		type: "consPick",
		deck: !0
	} : { type: "skip" };
}
function Ui(e) {
	return [
		"die",
		"parks",
		"mug",
		"wonder",
		"photo",
		"wildlife",
		"carabiner"
	][e % 7];
}
function Wi(e, t) {
	let n = [];
	for (let r of t.parksDisplay) n.push({
		v: {
			type: "freePark",
			parkId: r,
			from: "display"
		},
		score: Ii(e, r)
	});
	for (let t of e.reserved) n.push({
		v: {
			type: "freePark",
			parkId: t,
			from: "reserve"
		},
		score: Ii(e, t)
	});
	return n.length > 0 ? (Oi(n), n[0].v) : {
		type: "freePark",
		from: "deck"
	};
}
function Gi(e, t, n, r) {
	let i = [];
	for (let r of [0, 1]) {
		let a = t.hikers[r];
		if (!(a >= 8)) for (let o = a + 1; o <= 7; o++) {
			let a = Ai(e, o) > 0, s = null, c;
			if (a) {
				if (e.campfires.includes(o)) s = "communal";
				else {
					let e = n.filter((e) => !!L[e]);
					if (e.length === 0) continue;
					s = "card", c = e[0];
				}
			}
			let l = Li(e.trailSites[o - 1], t, e);
			l += Ni(e.trailBonus[o - 1]), o === 4 && (l += 1);
			let u = Pi(e, o);
			u && t.carabiners > 0 && (l += wi[u] + .7 - 1.2), s === "communal" ? l -= 2 : s === "card" && (l -= 2.5);
			let d = {
				type: "move",
				hiker: r,
				to: o
			};
			s && (d.campfire = s), c && (d.card = c), i.push({
				v: d,
				score: l
			});
		}
	}
	return i.length > 0 ? Di(Oi(i).map((e) => e.v), r) : {
		type: "move",
		hiker: [0, 1].find((e) => t.hikers[e] < 8) ?? 0,
		to: 8,
		slot: Vi(e)
	};
}
function Ki(e) {
	return {
		type: "discardRes",
		res: [...bi].sort((t, n) => e.res[n] - e.res[t])[0]
	};
}
function qi(e, t) {
	let n = [
		"sun",
		"water",
		"forest",
		"mountain",
		"wildlife"
	], r = {}, i = t;
	for (let t of n) {
		let n = Math.min(i, e.res[t]);
		if (n > 0 && (r[t] = n, i -= n), i === 0) return r;
	}
	return null;
}
function Ji(e, t, n) {
	let r = new Set(e.campfireUsed), i = n.filter((e) => !!L[e] && !r.has(e)), a = (e) => L[e].effect;
	for (let e of i) if (a(e) === "turnWildlife2" && t.res.wildlife >= 2) return {
		type: "campfireEnd",
		card: e,
		pay: { wildlife: 2 }
	};
	for (let e of i) if (a(e) === "turnCarabiner" && t.carabiners >= 1) return {
		type: "campfireEnd",
		card: e,
		carabiner: !0
	};
	for (let e of i) {
		if (a(e) !== "turnAny3") continue;
		let n = qi(t, 3);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	for (let e of i) {
		if (a(e) !== "turnAny2") continue;
		let n = qi(t, 2);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	return { type: "scoringDone" };
}
function Yi(e, t) {
	let n = t.filter((e) => !!Ae[e]);
	if (n.length > 0) {
		let t = n[0], r = Infinity;
		for (let i of n) {
			let n = zi(e, i, "top") ?? -Infinity, a = zi(e, i, "bottom") ?? -Infinity, o = Math.max(n, a);
			o < r && (r = o, t = i);
		}
		return {
			type: "discardWonder",
			card: t
		};
	}
	return {
		type: "discardWonder",
		card: t.filter((e) => !!L[e]).sort((e, t) => (Ti[L[e].effect] ?? 0) - (Ti[L[t].effect] ?? 0))[0] ?? t[0]
	};
}
var Xi = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.turn !== t.rid) return null;
	let i = ki(n, t.rid);
	if (!i) return null;
	let a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "scoring") return { action: Ji(n, i, o) };
	if (n.phase !== "turn") return null;
	if (n.pending === "gretaColor") return { action: {
		type: "gretaColor",
		first: a && Ei() < .5 ? 1 : 0
	} };
	let s = t.memory ?? {};
	if (n.pending === "move") return {
		action: Gi(n, i, o, a),
		memory: {}
	};
	if (n.pending === "trailEnd") return {
		action: {
			type: "move",
			hiker: [0, 1].find((e) => i.hikers[e] < 8) ?? 0,
			to: 8,
			slot: Vi(n)
		},
		memory: {}
	};
	if (n.pending === "parks") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let r of n.parksDisplay) {
			if (t.has(r)) continue;
			t.add(r);
			let n = N[r];
			n && ji(i, n.cost) && e.push({
				v: r,
				score: Ii(i, r)
			});
		}
		for (let n of i.reserved) {
			if (t.has(n)) continue;
			t.add(n);
			let r = N[n];
			r && ji(i, r.cost) && e.push({
				v: n,
				score: Ii(i, n)
			});
		}
		if (e.length > 0) return Oi(e), {
			action: {
				type: "visit",
				parkId: Di(e, a).v
			},
			memory: { parks: !0 }
		};
		if (s.parks) return {
			action: { type: "parksDone" },
			memory: {}
		};
		let r = [];
		return n.parksDisplay.forEach((e, t) => r.push({
			index: t,
			score: Ii(i, e)
		})), r.length > 0 ? (r.sort((e, t) => t.score - e.score), {
			action: {
				type: "reserve",
				from: "display",
				index: r[0].index
			},
			memory: {}
		}) : n.parksDeck > 0 ? {
			action: {
				type: "reserve",
				from: "deck"
			},
			memory: {}
		} : {
			action: { type: "parksDone" },
			memory: {}
		};
	}
	if (n.pending === "mug") return i.mug >= 3 ? {
		action: {
			type: "mug",
			act: "drink"
		},
		memory: s
	} : {
		action: {
			type: "mug",
			act: "fill"
		},
		memory: s
	};
	if (n.pending === "mugChoice") return {
		action: {
			type: "mugChoice",
			choice: .6 + i.snow + (i.chaletPos < 15 ? .4 : 0) >= 2.6 ? "chalet" : "cons"
		},
		memory: s
	};
	if (n.pending === "cons") return {
		action: Hi(i, n, n.freeCons),
		memory: s
	};
	if (n.pending === "assignWild") {
		let e = [];
		for (let t of P) {
			let n = i.visited.filter((e) => e.suit === t).length;
			n !== 0 && e.push({
				suit: t,
				score: Fi(i, t) * 2 + n * .1
			});
		}
		return e.sort((e, t) => t.score - e.score), {
			action: {
				type: "assignWild",
				suit: e[0].suit
			},
			memory: s
		};
	}
	if (n.pending === "freePark") return {
		action: Wi(i, n),
		memory: s
	};
	if (n.pending === "discardRes") return {
		action: Ki(i),
		memory: s
	};
	if (n.pending === "discardWonder") return {
		action: Yi(i, o),
		memory: s
	};
	if (n.pending === "actions") {
		if (n.end && !n.end.topDone && n.end.action) return {
			action: { type: "endTop" },
			memory: s
		};
		if (n.end && !n.end.parksDone) return {
			action: { type: "endParks" },
			memory: s
		};
		let e = n.landingSite === null ? null : n.trailSites[n.landingSite - 1];
		if (!n.siteDone && e) return {
			action: { type: "siteAction" },
			memory: s
		};
		let t = e ? Fe(e) : null;
		if (t) {
			let e = i.cons.findIndex((e, r) => F(e) === t && !n.consUsed.includes(r));
			if (e >= 0) return {
				action: {
					type: "activateCons",
					card: e
				},
				memory: s
			};
		}
		let r = Pi(n, n.landingSite);
		if (r && !n.vfUsed && i.carabiners > 0 && wi[r] + .7 > 1.2) return {
			action: { type: "viaFerrata" },
			memory: s
		};
		let a = [];
		for (let e of Ri(o)) for (let t of ["top", "bottom"]) {
			let n = zi(i, e, t);
			n !== null && a.push({
				v: {
					type: "playWonder",
					card: e,
					side: t
				},
				score: n
			});
		}
		let c = Oi(a)[0];
		return c && c.score > .8 ? {
			action: c.v,
			memory: s
		} : {
			action: { type: "endTurn" },
			memory: {}
		};
	}
	return null;
}, Zi = [
	{
		key: "parks",
		label: "games.parkseurope.visitedTitle"
	},
	{
		key: "campfire",
		label: "games.parkseurope.wonder.campfireCard"
	},
	{
		key: "endgame",
		label: "games.parkseurope.scoringTitle"
	},
	{
		key: "photos",
		label: "games.parkseurope.token.photo"
	},
	{
		key: "parkAwards",
		label: "games.parkseurope.resultParkAwards"
	},
	{
		key: "cons",
		label: "games.parkseurope.consTitle"
	},
	{
		key: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		key: "photoAward",
		label: "games.parkseurope.resultPhotoAward"
	}
], Qi = [
	"games.parkseurope.rank.none",
	"games.parkseurope.rank.r1",
	"games.parkseurope.rank.r2",
	"games.parkseurope.rank.r3",
	"games.parkseurope.rank.r4",
	"games.parkseurope.rank.r5"
];
function $i({ public: e, result: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o }) {
	let l = u(), d = e, [f, p] = s(!0), m = (e) => d.finalRows?.find((t) => t.rid === e)?.total ?? t.scores?.[e], g = (e) => n.find((t) => t.rid === e), _ = (e) => h[(g(e)?.colorIndex ?? Math.max(0, d.order.indexOf(e))) % h.length], v = (e) => g(e)?.name || l(_(e).nameKey), y = d.soloRanks && m(r) !== void 0 ? d.soloRanks.reduce((e, t) => (m(r) ?? 0) >= t.at ? Math.max(e, t.rank) : e, 0) : null;
	return /* @__PURE__ */ x("div", {
		className: "pke-recap-root pke-screen",
		children: [
			/* @__PURE__ */ b("div", {
				className: "pke-recap-scene",
				inert: f,
				children: /* @__PURE__ */ b(_i, {
					public: d,
					members: n,
					myRid: r,
					send: () => {}
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "pke-recap-overlay",
				hidden: !f,
				children: /* @__PURE__ */ x("section", {
					className: "pke-recap",
					"aria-label": l("games.parkseurope.journeyEnd"),
					children: [
						/* @__PURE__ */ x("header", {
							className: "pke-recap-header",
							children: [
								/* @__PURE__ */ b(K, { kind: "mountain" }),
								/* @__PURE__ */ b("h1", { children: l("games.parkseurope.journeyEnd") }),
								y !== null && /* @__PURE__ */ b("strong", { children: l(Qi[y] ?? Qi[0]) }),
								/* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => p(!1),
									children: l("games.parkseurope.reviewTable")
								})
							]
						}),
						/* @__PURE__ */ x("div", {
							className: "pke-score-scroll",
							children: [
								/* @__PURE__ */ b("div", {
									className: "pke-recap-roster",
									children: t.ranking.map((e) => {
										let n = d.players.find((t) => t.rid === e), r = d.finalRows?.find((t) => t.rid === e);
										return /* @__PURE__ */ x("article", {
											className: "pke-recap-seat",
											"data-winner": t.winner.includes(e),
											style: { "--pke-seat": _(e).hex },
											children: [/* @__PURE__ */ x("div", {
												className: "pke-recap-identity",
												children: [
													/* @__PURE__ */ b("img", {
														src: c[(g(e)?.avatar ?? 0) % c.length],
														alt: ""
													}),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("strong", { children: v(e) }), t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ b("small", { children: l("games.parkseurope.journeyWinner") })] }),
													/* @__PURE__ */ b("b", { children: m(e) ?? "—" })
												]
											}), n && /* @__PURE__ */ x("div", {
												className: "pke-recap-awards",
												children: [
													P.filter((e) => n.parkAwards[e]).map((e) => /* @__PURE__ */ b(Bn, { award: {
														kind: "parks",
														suit: e,
														count: n.parkAwards[e]
													} }, e)),
													n.consAwards > 0 && /* @__PURE__ */ b(Bn, { award: {
														kind: "cons",
														count: n.consAwards
													} }),
													n.chaletAwards.map((e, t) => /* @__PURE__ */ b(Bn, { award: {
														kind: "chalet",
														points: e
													} }, t)),
													(r?.photoAward ?? 0) > 0 && /* @__PURE__ */ b(Bn, { award: { kind: "photo" } })
												]
											})]
										}, e);
									})
								}),
								/* @__PURE__ */ x("table", {
									className: "pke-score-table",
									children: [
										/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "col",
											children: l("games.parkseurope.scoreItem")
										}), t.ranking.map((e) => /* @__PURE__ */ b("th", {
											scope: "col",
											"data-winner": t.winner.includes(e),
											children: /* @__PURE__ */ x("span", {
												className: "pke-score-player",
												style: { "--pke-seat": _(e).hex },
												children: [
													/* @__PURE__ */ b("img", {
														src: c[(g(e)?.avatar ?? 0) % c.length],
														alt: ""
													}),
													/* @__PURE__ */ b("span", { children: v(e) }),
													t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ b("b", { children: l("games.parkseurope.journeyWinner") })
												]
											})
										}, e))] }) }),
										d.finalRows && /* @__PURE__ */ b("tbody", { children: Zi.map(({ key: e, label: n }) => /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: l(n)
										}), t.ranking.map((t) => /* @__PURE__ */ b("td", { children: d.finalRows?.find((e) => e.rid === t)?.[e] ?? "—" }, t))] }, e)) }),
										/* @__PURE__ */ b("tfoot", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: l("games.parkseurope.resultTotal")
										}), t.ranking.map((e) => /* @__PURE__ */ b("td", { children: m(e) ?? "—" }, e))] }) })
									]
								}),
								i !== void 0 && /* @__PURE__ */ b("p", { children: l("session.hint.usedCount", { n: i }) }),
								t.ranking.map((e) => {
									let n = t.autopilot?.[e];
									return n ? /* @__PURE__ */ x("p", { children: [
										v(e),
										" · ",
										l("session.autopilot.share", { n: Math.round(n * 100) })
									] }, e) : null;
								})
							]
						}),
						/* @__PURE__ */ x("footer", {
							className: "pke-recap-actions",
							children: [
								a && /* @__PURE__ */ b(be, {
									compact: !0,
									label: l("session.result.playAgain"),
									confirmLabel: l("games.parkseurope.confirmAgain"),
									onConfirm: a
								}),
								o && /* @__PURE__ */ b(be, {
									compact: !0,
									label: l("session.result.backToLobby"),
									confirmLabel: l("games.parkseurope.confirmLobby"),
									onConfirm: o
								}),
								!a && !o && /* @__PURE__ */ b("span", { children: l("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main pke-recap-restore",
				hidden: f,
				onClick: () => p(!0),
				children: l("games.parkseurope.returnScores")
			})
		]
	});
}
//#endregion
//#region src/game/game-over-row.tsx
var ea = {
	1: "games.parkseurope.rank.r1",
	2: "games.parkseurope.rank.r2",
	3: "games.parkseurope.rank.r3",
	4: "games.parkseurope.rank.r4",
	5: "games.parkseurope.rank.r5"
};
function ta({ public: e, rid: t }) {
	let n = u(), r = e, i = r.finalRows?.find((e) => e.rid === t);
	if (!i) return null;
	let a = [
		{
			key: "games.parkseurope.over.parks",
			n: i.parks
		},
		{
			key: "games.parkseurope.over.campfire",
			n: i.campfire
		},
		{
			key: "games.parkseurope.over.endgame",
			n: i.endgame
		},
		{
			key: "games.parkseurope.over.photos",
			n: i.photos
		},
		{
			key: "games.parkseurope.over.parkAwards",
			n: i.parkAwards
		},
		{
			key: "games.parkseurope.over.cons",
			n: i.cons
		},
		{
			key: "games.parkseurope.over.chalet",
			n: i.chalet
		},
		{
			key: "games.parkseurope.over.photoAward",
			n: i.photoAward
		}
	], o = null;
	if (r.soloRanks) {
		let e = 0;
		for (let t of r.soloRanks) i.total >= t.at && (e = Math.max(e, t.rank));
		o = n(ea[e] ?? "games.parkseurope.rank.none");
	}
	return /* @__PURE__ */ x("div", {
		className: "mt-1.5 flex flex-wrap gap-1",
		children: [
			a.map(({ key: e, n: t }) => /* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-paper px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums",
				children: n(e, { n: t })
			}, e)),
			/* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-done-soft px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-done-ink",
				children: n("games.parkseurope.over.total", { n: i.total })
			}),
			o && /* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-info-soft px-1.5 py-0.5 text-[10px] font-bold text-info-ink",
				children: n("games.parkseurope.over.rank", { name: o })
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function na({ value: e, onChange: t }) {
	let n = u(), r = et.safeParse(e), i = r.success ? r.data : et.parse(void 0);
	return /* @__PURE__ */ b(Se, {
		title: n("games.parkseurope.name"),
		children: /* @__PURE__ */ b(xe, {
			name: "parkseurope-greta",
			value: "greta",
			checked: i.greta,
			label: n("games.parkseurope.opt.greta"),
			hint: n("games.parkseurope.opt.gretaHint"),
			accent: He.accent,
			onChange: () => t({
				...i,
				greta: !i.greta
			})
		})
	});
}
//#endregion
//#region src/index.tsx
var ra = {
	definition: On,
	View: _i,
	bot: Xi,
	OverView: $i,
	RowView: ta,
	Options: na,
	locales: {
		zh: {
			name: "Parks Europe",
			parkNames: {
				p0: "湖区",
				p1: "欧洲之峰",
				p2: "瓦特纳冰川",
				p3: "卡朗克",
				p4: "萨马里亚",
				p5: "里拉",
				p6: "尤通黑门",
				p7: "五渔村",
				p8: "塔特拉",
				p9: "瑞士国家公园",
				p10: "洛蒙德湖与特罗萨克斯",
				p11: "约斯特达尔冰川",
				p12: "康尼马拉",
				p13: "哈当厄尔高原",
				p14: "泰斯",
				p15: "特里格拉夫",
				p16: "贝希特斯加登",
				p17: "雷泰扎特",
				p18: "阿布鲁佐、拉齐奥与莫利塞",
				p19: "拉马达莱娜群岛",
				p20: "格雷梅",
				p21: "比利牛斯",
				p22: "萨雷克",
				p23: "蒂曼法亚",
				p24: "贝卢诺多洛米蒂",
				p25: "高陶恩",
				p26: "辛格韦德利",
				p27: "瓦登海",
				p28: "皮林",
				p29: "奥兰卡",
				p30: "基拉尼",
				p31: "杜米托尔",
				p32: "高亚",
				p33: "多尼亚纳",
				p34: "埃克兰",
				p35: "维科斯—阿奥斯",
				p36: "奥林匹斯山",
				p37: "奥尔德萨与佩尔迪多山",
				p38: "十六湖",
				p39: "泰德",
				p40: "佩内达—热尔",
				p41: "格泽瑟",
				p42: "克尔卡",
				p43: "阿比斯库",
				p44: "萨克森瑞士",
				p45: "布特林特",
				p46: "凯恩戈姆山",
				p47: "峰区"
			},
			wonderNames: {
				b01: "野趣之旅",
				b02: "细品日出",
				b03: "沐浴晨光",
				b04: "尽享森林",
				b05: "林中漫步",
				b06: "骑游山野",
				b07: "探访荒野",
				b08: "晴空畅怀",
				b09: "守护群峰",
				b10: "回望旅途",
				b11: "步道奇遇",
				b12: "畅游清水",
				b13: "涉过山溪",
				b14: "扣紧攀登",
				b16: "定格此刻",
				b17: "随心漫游",
				b18: "登山而上",
				b19: "攀上顶峰",
				b20: "守护林木",
				b21: "清理河岸"
			},
			campfireCardName: "营火卡 {{n}}",
			selectedHiker: "已选",
			desc: "用三个赛季走遍欧洲的国家公园，收集资源、留宿小屋、拍摄照片并支持保护工程，终局比拼得分",
			rules: "目标:\n每名玩家率领两名旅人，在欧洲的国家公园步道上徒步三个赛季。沿途收集资源与照片、访问国家公园、完成保护工程，并在终局结算中获得最高总分的玩家获胜。\n准备:\n· 每名玩家取一块板面，把两枚旅人放在步道起点，把马克杯标记放在马克杯轨道最下方，并取得一枚登山扣。\n· 将所有玩家的小屋标记随机叠放在小屋赛道的起点。\n· 每名玩家从奇迹牌堆抽取一张奇迹卡，作为手牌的开始。\n· 洗混公园卡与保护卡，各翻开三张组成展示区。按人数准备公共营火：三人及以下使用一枚，四人使用两枚，五人使用三枚。\n· 每个赛季开始时翻开一张赛季卡，按卡面把公共营火与赛季奖励资源放到对应站点。小屋标记最靠前的玩家先手，同格时叠在最上面的玩家先手。\n回合:\n每名玩家轮流行动，直到所有旅人都抵达步道终点，该赛季结束。三个赛季结束后进行终局结算。\n· 行动时，选择一名尚未抵达终点的旅人，把它向前移动到任意一个更靠后的站点，并获得该站点的行动与赛季奖励资源。旅人不能后退，也不能跳过自己的回合。\n· 站点上已有其他旅人时不能直接停留，除非使用点上的公共营火，或弃掉手中一张营火奇迹卡。\n· 你可以放弃站点的主要行动，仍可进行铁索攀登、打出奇迹卡或激活保护卡。\n· 抵达站点后，你可以按任意顺序执行站点的主要行动、进行铁索攀登、打出任意张奇迹卡和激活保护卡。\n· 回合结束时，手牌上限为三张奇迹卡，登山扣上限为三枚；资源区容量为十二格，每枚雪占用两格，超出的非雪资源必须弃回供应区。\n营地与营火:\n· 公共营火每个赛季开始时按人数放置，使用后回到供应区，该赛季不再补充。\n· 营火奇迹卡在终局计分时仍留在手中结算，也可以在此之前弃掉用来占据已有旅人的站点。\n步道站点:\n· 四块核心站点分别提供森林、太阳、山峰与水域资源；山峰与水域站点同时提供一枚雪。\n· 进阶站点提供野生动物、登山扣、公园行动、掷步道骰、拍照、马克杯行动、小屋行动、奇迹卡与保护工程。\n· 中央站点固定印有快门虫图标，旅人抵达时立即取得快门虫。\n步道终点:\n· 终点分为区域：第一排是四种单独行动，每个位置只能容纳一名旅人；中间是公园行动，可以容纳任意多旅人；第二排同时提供上方行动与公园行动，每个位置只能容纳一名旅人。\n· 落在第二排时必须完成上方行动与公园行动，两者的先后顺序由你决定。\n· 终点不能使用营火共享位置。两名旅人都抵达终点后，该玩家的徒步到此结束。\n· 若轮到你行动时其他旅人都已离开步道，你必须立即前往终点，并照常选择终点位置。\n铁索攀登\n· 除中央站点外，每个站点上方都有一块铁索攀登板块。抵达站点后，你可以上交一枚登山扣，领取该板块的奖励，并额外获得一枚雪。\n· 你每回合可以进行一次铁索攀登，时机可选在站点主要行动之前或之后。\n国家公园:\n· 公园行动可以选择预留，或访问任意多张公园卡。预留时从展示区取一张，或直接抽取牌堆顶一张，放在自己的预留区。\n· 访问时支付公园卡上标注的资源。野生动物可以代替任意一种普通资源；带有「任意」图标的费用可以用任何资源支付。\n· 公园卡按花色叠放在板面右侧。每叠满三张同花色公园，立即取得该花色的公园奖章与印刷的即时奖励；奖章在终局按该花色公园数量计分。\n· 野性公园不属于四种花色。取得时把它并入任意一个已有花色的公园叠；若尚未拥有任何花色，则并入下一张取得的有色公园。\n· 展示区取走或弃掉卡牌后不会立即补入；到回合结束时再从牌库补满，已有卡牌先向右滑动，新卡从左侧补入，最右侧始终是最老的卡牌。\n步道骰与快门虫:\n· 步道骰的六个面分别提供登山扣、野生动物、山与水、抽奇迹卡、拍照、太阳与森林。\n· 持有快门虫时，你回合中的每次拍照行动额外获得一张照片；快门虫可以由旅人抵达中央站点或由部分卡牌获得。\n照片:\n· 每张照片在终局计一分。集满五张照片时换成一本相册，相册在终局计五分。\n· 终局时拍摄照片总数最多的玩家额外获得照片奖章，价值三分；平局时小屋赛道更靠前的玩家获胜。单人模式不使用照片奖章。\n马克杯:\n· 马克杯行动可以填充或饮用。填充时把标记向上移动一格，最多到达顶端；饮用时结算标记所在档位的奖励，并把标记移回最下方。\n· 第一档可以选择执行一次小屋行动，或免费支持一张保护工程。\n· 第二档掷三次步道骰并获得全部结果。\n· 第三档免费访问一张公园，来源可以是展示区、预留区或牌堆顶。\n保护工程:\n· 保护行动可以选择支持一张展示区中的保护卡，或支付一枚太阳与一枚水，从牌堆顶取得一张。\n· 取得保护卡后，只能在对应颜色的核心站点激活它的效果。每回合每张保护卡可以激活一次，多张保护卡的激活顺序自定，也可以安排在站点主要行动之前或之后。\n· 若在当前站点取得颜色相同的保护卡，可以立即激活这一张。\n· 集齐四种颜色的保护卡时取得一枚保护奖章，价值五分。\n小屋:\n· 小屋行动上交自己板面上的全部雪，沿小屋赛道前进与雪数量相同的雪格。\n· 经过奇迹格时抽取一张奇迹卡；经过奖章格时取得该位置最有价值的一枚奖章，奖章堆为空时改为抽取一张奇迹卡。\n· 小屋令牌停止在已有令牌的格子上时叠放在最上方。赛道走到尽头后仍可上交雪，但不再前进。\n· 小屋赛道在终局计分中用于打破平局，越靠前越优先，同格时叠在上方者优先。\n奇迹卡:\n· 基础奇迹卡有上下两种即时行动，支付卡面左侧的资源后获得右侧的奖励。\n· 营火奇迹卡可以弃掉来占据已有旅人的站点；终局计分时按效果获得分数，部分卡牌还可以上交资源换取分数。\n赛季与终局:\n· 赛季开始时重新铺设步道，把新的三块进阶站点与四块核心站点洗混后放到七个位置，并放置新的公共营火与赛季奖励。\n· 三个赛季结束后先进入终局结算：每名玩家可以自行决定是否用手中的营火奇迹卡上交资源换取分数，也可以放弃。\n· 营火效果与资源结算完成后，依次计算到访公园、营火奇迹卡的固定效果、照片与相册、公园奖章、保护奖章与小屋奖章；照片奖章在全部营火效果之后才计算。\n· 公园奖章每枚按同花色到访公园的数量计分，保护奖章与相册各计五分，照片按张计分，小屋奖章按其面值计分（3、4 或 5 分）。总分最高的玩家获胜。\n护林员格蕾塔:\n· 单人模式与双人挑战中，护林员格蕾塔会加入徒步。她始终最后行动，按步道骰结果移动自己的旅人。\n· 蝴蝶面移动队伍中靠后的旅人，花朵面移动靠前的旅人；点数表示可以前进到的第几个可用站点。\n· 点上有公共营火时格蕾塔视为可以停留，并会消耗该营火；她的旅人抵达终点时，弃掉展示区最右侧的公园卡与保护卡。\n· 单人模式中格蕾塔控制两组旅人；每次她行动前，由你选择先移动哪一组。你取得小屋奖章时可以额外抽取一张奇迹卡；照片奖章不参与结算，终局按得分对照评级表。",
			season: {
				cliffs: "悬崖之季",
				swimming: "游泳之季",
				memories: "回忆之季",
				sun: "阳光之季",
				dreams: "梦想之季",
				joy: "欢乐之季",
				scouting: "探索之季",
				growth: "生长之季",
				climbing: "攀登之季",
				caves: "洞穴之季",
				meadows: "草甸之季",
				ice: "冰雪之季"
			},
			res: {
				mountain: "山峰",
				forest: "森林",
				sun: "太阳",
				water: "水域",
				wildlife: "野生动物",
				snow: "雪",
				any: "任意资源"
			},
			suit: {
				lime: "青柠",
				orange: "橙",
				teal: "青绿",
				purple: "紫",
				wild: "野性"
			},
			site: {
				"core-forest": "森林：获得 1 枚森林",
				"core-sun": "太阳：获得 2 枚太阳",
				"core-mountain": "山峰：获得 1 枚山峰与 1 枚雪",
				"core-water": "水域：获得 2 枚水域与 1 枚雪",
				wildlife: "野生动物：获得 1 枚野生动物",
				carabiner: "登山扣：获得 1 枚登山扣",
				parks: "公园行动",
				die: "掷步道骰",
				photo: "拍一张照片",
				mug: "马克杯行动",
				chalet: "小屋行动",
				wonder: "抽一张奇迹卡",
				conservation: "保护工程"
			},
			siteShort: {
				"core-forest": "森林",
				"core-sun": "太阳",
				"core-mountain": "山峰",
				"core-water": "水域",
				wildlife: "野生动物",
				carabiner: "登山扣",
				parks: "公园",
				die: "掷步道骰",
				photo: "拍照",
				mug: "马克杯",
				chalet: "小屋",
				wonder: "奇迹卡",
				conservation: "保护工程"
			},
			vf: {
				wonder: "抽一张奇迹卡",
				sunwater: "获得 1 枚太阳与 1 枚水域",
				photo: "拍一张照片",
				conservation: "保护工程",
				mug: "马克杯行动",
				wildlife: "获得 1 枚野生动物"
			},
			vfShort: {
				wonder: "奇迹卡",
				sunwater: "太阳与水域",
				photo: "拍照",
				conservation: "保护工程",
				mug: "马克杯",
				wildlife: "野生动物"
			},
			top: {
				conservation: "保护工程",
				carabiner: "获得登山扣",
				mug: "马克杯行动",
				chalet: "小屋行动"
			},
			benefit: {
				die: "掷步道骰",
				parks: "公园行动",
				mug: "马克杯行动",
				wonder: "抽一张奇迹卡",
				photo: "拍一张照片",
				wildlife: "获得野生动物",
				carabiner: "获得登山扣"
			},
			token: {
				photo: "照片",
				carabiner: "登山扣"
			},
			consProject: {
				p0: "生物多样性修复",
				p1: "野外研究",
				p2: "遗产地修复",
				p3: "减少光污染",
				p4: "自然摄影",
				p5: "物种保护",
				p6: "步道维护"
			},
			campfire: {
				consForest: "每张森林色保护卡计 1 分",
				consMountain: "每张山峰色保护卡计 1 分",
				consSun: "每张太阳色保护卡计 1 分",
				consWater: "每张水域色保护卡计 1 分",
				iconForest: "到访公园每 3 个森林图标计 1 分",
				iconMountain: "到访公园每 3 个山峰图标计 1 分",
				iconSun: "到访公园每 3 个太阳图标计 1 分",
				iconWater: "到访公园每 3 个水域图标计 1 分",
				anyIcons: "到访公园每 2 个任意资源图标计 1 分",
				album: "每本相册计 1 分",
				wonderHand: "手牌中每张奇迹卡计 1 分，包含本卡",
				snow: "板面上每枚雪计 1 分",
				turnWildlife2: "上交 2 枚野生动物，获得 4 分",
				turnAny2: "上交任意 2 点资源，获得快门虫并拍摄 2 张照片",
				turnCarabiner: "上交 1 枚登山扣，获得 2 分",
				turnAny3: "上交任意 3 点资源，获得 3 分"
			},
			rank: {
				none: "未达评级",
				r1: "一日徒步者",
				r2: "远行者",
				r3: "探险家",
				r4: "冒险家",
				r5: "开拓者"
			},
			opt: {
				greta: "邀请护林员格蕾塔",
				gretaHint: "仅双人局可用；单人局中格蕾塔自动加入。"
			},
			seasonLabel: "第 {{n}} 季",
			seasonCard: "赛季卡：{{name}}",
			myTurn: "轮到你行动",
			waitingFor: "等 {{name}} 行动…",
			pending: {
				move: "移动一名旅人",
				trailEnd: "其他旅人都已抵达终点，直接前往步道终点",
				actions: "可以继续行动，或结束回合",
				parks: "预留或访问公园",
				mug: "填充或饮用马克杯",
				mugChoice: "选择马克杯奖励",
				cons: "支持一张保护工程",
				consFree: "免费支持一张保护工程",
				assignWild: "为野性公园选择花色",
				freePark: "免费访问一张公园",
				discardRes: "弃掉一张多余资源",
				discardWonder: "弃掉一张多余的奇迹卡",
				gretaColor: "选择格蕾塔先移动哪一组旅人",
				scoring: "终局结算",
				none: "对局结束"
			},
			trail: "步道",
			trailEnd: "步道终点",
			trailStart: "起点",
			parksTitle: "国家公园",
			consTitle: "保护工程",
			chaletTrack: "小屋赛道",
			myMat: "我的板面",
			handTitle: "我的奇迹卡",
			fieldParks: "公园",
			fieldProjects: "工程",
			fieldChalet: "小屋",
			awardParkDetail: "获得时：{{benefit}}。终局：每张同花色公园得 1 分。",
			awardFixedDetail: "终局得 {{n}} 分。",
			wonderDiscard: "弃置",
			wonderDiscardName: "弃置 {{name}}",
			wonderPlay: "使用这一半",
			wonderWait: "等待你的回合",
			wonderShare: "弃置此牌可进入被占用的步道站点。",
			wonderScore: "终局计分",
			fieldAward: "奖章位",
			fieldFinish: "终点",
			fieldSnowSpace: "雪格",
			fieldAwardNext: "先领取 {{n}} 分奖章。",
			fieldAwardStack: "下方依次为 {{scores}} 分。",
			fieldDrawPassing: "经过时抽 1 张奇迹牌。",
			fieldChaletNote: "每交 1 枚雪，前进 1 个雪格。经过奖励格时领取奖励。",
			fieldTrackSpace: "第 {{n}} 格 · {{name}}",
			fieldStartShort: "起",
			fieldEndShort: "终",
			fieldEndActions: "终点行动",
			fieldAction: "行动",
			fieldVacant: "空位",
			fieldChoose: "选择",
			fieldSharedOccupied: "已有旅人",
			fieldSharedSlot: "可共用",
			fieldSeasonNote: "赛季开始时，第 2–7 站各放置 1 枚额外资源。",
			fieldChoosePark: "选公园",
			fieldFinishParks: "结束公园行动",
			fieldVisitedPark: "已到访 {{name}} · +{{n}} 分",
			fieldDisplay: "展示",
			fieldReserved: "预留 {{n}}",
			fieldNoReserved: "暂无预留公园",
			fieldTrailSeason: "步道与赛季",
			fieldTrailRoute: "沿途站点",
			fieldSeasonTab: "赛季卡",
			fieldStop: "站点",
			fieldExtras: "额外机会",
			fieldHikers: "旅人",
			fieldGoTo: "前往{{name}}",
			fieldResetCamera: "重置全谷视角",
			fieldAlbum: "相册",
			fieldHonors: "荣誉",
			fieldCollection: "公园收藏",
			fieldSupported: "已支持工程",
			fieldNone: "暂无",
			fieldPlayerItems: "玩家物件",
			fieldPack: "背包",
			fieldHand: "手牌",
			fieldPanels: "查看物件",
			closePanel: "关闭面板",
			camera: "步道视角",
			overview: "全谷",
			follow: "跟随",
			valleyUnavailable: "打开「步道」选择站点。",
			packSlots: "资源槽",
			packUsage: "{{used}} / 12 格",
			projectSite: "{{resource}}站",
			displayBonus: "展示奖励",
			journeyEnd: "旅程回顾",
			scoreItem: "计分项目",
			reviewTable: "回看步道与公园",
			returnScores: "返回结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			journeyWinner: "获胜",
			resultParkAwards: "公园奖章",
			resultPhotoAward: "照片奖章",
			resultTotal: "总分",
			fx: {
				cardUsed: "使用了{{card}}",
				honorEarned: "荣誉入册",
				parkAward: "{{suit}}公园奖章 ×{{count}}",
				chaletAward: "小屋奖章 · {{points}} 分"
			},
			handEmpty: "暂无奇迹卡",
			playersTitle: "玩家",
			reservedTitle: "预留公园",
			visitedTitle: "到访公园",
			deckCount: "牌库剩 {{n}} 张",
			startDeck: "牌堆",
			visit: "访问",
			reserve: "预留",
			support: "支持",
			free: "免费",
			deckCost: "太阳 1 · 水域 1",
			points: "{{n}} 分",
			cannotAfford: "资源不足",
			slotTop: "单独行动",
			slotBoth: "行动＋访问公园",
			slotParks: "只访问公园",
			slotTaken: "已被占用",
			chooseSlot: "选择终点位置",
			chooseHiker: "选择旅人",
			hikerLabel: "旅人 {{n}}",
			siteNo: "第 {{n}} 站",
			atEnd: "已抵达终点",
			endTurn: "结束回合",
			viaFerrata: "铁索攀登",
			skip: "跳过",
			cancel: "取消",
			campfireLabel: "营火",
			useCommunalCampfire: "使用公共营火",
			useCampfireCard: "使用营火奇迹卡",
			occupiedPrompt: "这个站点已有旅人，选择如何共享",
			discardResPrompt: "选择要弃回供应的资源",
			discardWonderPrompt: "选择要弃掉的奇迹卡",
			mug: {
				track: "马克杯",
				level: "第 {{n}} 档",
				fill: "填充",
				drink: "饮用",
				chalet: "小屋行动",
				cons: "免费保护工程",
				benefit1: "第一档：小屋行动或免费保护工程",
				benefit2: "第二档：掷三次步道骰",
				benefit3: "第三档：免费访问一张公园"
			},
			assignWildPrompt: "这张野性公园归入哪个花色？",
			freeParkPrompt: "免费访问一张公园",
			wonder: {
				top: "上半",
				bottom: "下半",
				play: "打出",
				pay: "需支付 {{cost}}",
				grant: "获得 {{grant}}",
				campfireCard: "营火卡",
				noPlay: "不能直接打出"
			},
			resources: "资源",
			carabiners: "登山扣 {{n}}",
			photos: "照片 {{n}}",
			albums: "相册 {{n}}",
			awards: "奖章 {{n}}",
			parkAwardsLabel: "公园奖章 {{n}}",
			consAwardsLabel: "保护奖章 {{n}}",
			chaletAwardsLabel: "小屋奖章 {{n}}",
			chaletPos: "小屋第 {{n}} 格",
			visitedCount: "到访 {{n}} 张",
			reservedCount: "预留 {{n}} 张",
			shutterbug: "快门虫",
			greta: "护林员格蕾塔",
			gretaHikers: "格蕾塔的旅人",
			soloRank: "单人评级：{{name}}",
			soloRankTable: "评级线：30 一日徒步者，35 远行者，40 探险家，45 冒险家，50 开拓者",
			siteAction: "执行站点行动",
			endTop: "终点行动",
			endParksTodo: "终点公园行动",
			activateCons: "激活保护卡",
			activateConsPrompt: "选择要激活的保护卡",
			activateConsEmpty: "当前站点没有可激活的保护卡",
			gretaPairA: "橄榄色旅人先",
			gretaPairB: "陶土色旅人先",
			scoringTitle: "终局结算",
			scoringPrompt: "你可以用营火奇迹卡上交资源换取分数；也可以放弃",
			scoringDone: "完成结算",
			scoringEmpty: "手中没有可用的营火效果",
			scoringPayPrompt: "选择要上交的资源，共 {{n}} 点",
			scoringPayChosen: "已选 {{n}}",
			scoringPayConfirm: "上交并结算",
			scoringPayReset: "重新选择",
			scoringUsed: "已使用",
			useEffect: "使用",
			endIncomplete: "请先完成步道终点的行动",
			over: {
				parks: "公园 {{n}}",
				campfire: "营火卡 {{n}}",
				endgame: "营火结算 {{n}}",
				photos: "照片 {{n}}",
				parkAwards: "公园奖章 {{n}}",
				cons: "保护奖章 {{n}}",
				chalet: "小屋奖章 {{n}}",
				photoAward: "照片奖章 {{n}}",
				total: "合计 {{n}}",
				rank: "评级：{{name}}"
			},
			noResources: "暂无资源",
			wild: "野性公园",
			ownMat: "我的",
			otherMat: "{{name}} 的板面",
			scoreShort: "{{n}} 分",
			err: {
				notTurn: "现在轮不到你",
				notPlayer: "你不在这局游戏里",
				phase: "当前步骤不能这样操作",
				badAction: "这一步不能这样做",
				mustMove: "请先移动一名旅人",
				alreadyMoved: "本回合已经移动过了",
				mustEnd: "其他旅人都已抵达终点，必须直接前往步道终点",
				badTarget: "这个站点不能去",
				badHiker: "这名旅人已经抵达终点",
				badSlot: "请选择一个可用的终点位置",
				full: "这个终点位置已被占用",
				occupied: "这个站点已有其他旅人，需要先使用营火",
				noCampfire: "没有可用的营火",
				badPark: "没有可拿取的公园卡",
				badCons: "没有可拿取的保护卡",
				noRes: "资源不足",
				noCarabiner: "登山扣不足",
				noVf: "这个站点无法进行铁索攀登",
				badWonder: "这张奇迹卡不能这样使用",
				badSuit: "不能归入这个花色",
				noConsSite: "这里不能激活保护卡",
				consUsed: "这张保护卡本回合已经激活过"
			}
		},
		en: {
			name: "Parks Europe",
			parkNames: {
				p0: "Lake District",
				p1: "Picos de Europa",
				p2: "Vatnajökull",
				p3: "Calanques",
				p4: "Samaria",
				p5: "Rila",
				p6: "Jotunheimen",
				p7: "Cinque Terre",
				p8: "Tatra",
				p9: "Swiss National Park",
				p10: "Loch Lomond & The Trossachs",
				p11: "Jostedalsbreen",
				p12: "Connemara",
				p13: "Hardangervidda",
				p14: "Theth",
				p15: "Triglav",
				p16: "Berchtesgaden",
				p17: "Retezat",
				p18: "Abruzzo, Lazio e Molise",
				p19: "Arcipelago di La Maddalena",
				p20: "Göreme",
				p21: "Pyrénées",
				p22: "Sarek",
				p23: "Timanfaya",
				p24: "Dolomiti Bellunesi",
				p25: "Hohe Tauern",
				p26: "Thingvellir",
				p27: "Wadden Sea",
				p28: "Pirin",
				p29: "Oulanka",
				p30: "Killarney",
				p31: "Durmitor",
				p32: "Gauja",
				p33: "Doñana",
				p34: "Écrins",
				p35: "Vikos-Aoös",
				p36: "Olympus",
				p37: "Ordesa y Monte Perdido",
				p38: "Plitvice Lakes",
				p39: "Teide",
				p40: "Peneda-Gerês",
				p41: "Gesäuse",
				p42: "Krka",
				p43: "Abisko",
				p44: "Saxon Switzerland",
				p45: "Butrint",
				p46: "Cairngorms",
				p47: "Peak District"
			},
			wonderNames: {
				b01: "Take a Wild Ride",
				b02: "Savor the Sunrise",
				b03: "Bask in the Light",
				b04: "Enjoy the Forests",
				b05: "Walk in the Woods",
				b06: "Take a Hike Bike",
				b07: "Explore the Backcountry",
				b08: "Clear Skies, Full Hearts",
				b09: "Protect the Peaks",
				b10: "Reflect on the Journey",
				b11: "Trail Magic",
				b12: "Take a Dip",
				b13: "Ford a Mountain Stream",
				b14: "Clip In and Climb",
				b16: "Capture the Moment",
				b17: "Ramble Along",
				b18: "Ascend the Mountain",
				b19: "Scale the Summit",
				b20: "Preserve the Trees",
				b21: "Clean the Riverbanks"
			},
			campfireCardName: "Campfire #{{n}}",
			selectedHiker: "Selected",
			desc: "Hike through Europe’s national parks over three seasons, gathering resources, resting at chalets, taking photos and supporting conservation projects for the most points",
			rules: "Goal:\nEach player leads two hikers through the national parks of Europe across three seasons. Collect resources and photos, visit national parks, support conservation projects, and earn the most points in the final scoring to win.\nSetup:\n· Each player takes a player mat, places both hikers at the trailhead, puts the mug token on the bottom space of the mug track, and takes one carabiner.\n· Randomly stack all players’ chalet tokens on the starting space of the chalet track.\n· Each player draws one Wonder card from the Wonder deck to start their hand.\n· Shuffle the park cards and the conservation cards, then reveal three of each into their displays. Prepare communal campfires by player count: one for up to three players, two for four players, and three for five players.\n· At the start of each season, reveal a season card and place communal campfires and season bonus resources on the indicated sites. The player whose chalet token is furthest along the track takes the first turn; if tokens share a space, the topmost token goes first.\nTurns:\nPlayers take turns until all hikers reach Trail’s End, which ends the season. After three seasons, final scoring begins.\n· On your turn, choose one hiker that has not reached Trail’s End and move it forward to any later site, taking that site’s action and any season bonus resource there.\n· Hikers never move backward. A hiker cannot stop on a site occupied by another hiker unless you spend the communal campfire on that site or discard a campfire Wonder card from your hand.\n· You may decline the site’s main action; if you do, you may still use the Via Ferrata, play Wonder cards, or activate conservation cards.\n· After landing, the site’s main action, the Via Ferrata, any Wonder cards, and conservation card activations may be taken in any order.\n· At the end of your turn, your hand holds at most three Wonder cards and you keep at most three carabiners. Your mat holds twelve spaces, each snow occupies two spaces, and any excess non-snow resources are returned to the supply.\nCampfires:\n· Communal campfires are placed at the start of each season and return to the supply when spent; they are not replenished during that season.\n· Campfire Wonder cards stay in your hand for final scoring, but you may discard one earlier to share an occupied site.\nTrail Sites:\n· The four core sites provide forest, sun, mountain and water. The mountain and water sites also provide one snow each.\n· Advanced sites provide wildlife, a carabiner, a parks action, a trail die roll, a photo, a mug action, a chalet action, a Wonder card, or a conservation project.\n· The center site always shows the Shutterbug icon; a hiker landing there immediately takes the Shutterbug.\nTrail’s End:\n· Trail’s End has three areas. The top row offers one of the four actions, with room for one hiker per space. The middle area offers a parks action and holds any number of hikers. The bottom row offers both the action above and a parks action, with room for one hiker per space.\n· A hiker on the bottom row must complete both the action and the parks action, in either order.\n· Campfires cannot be used at Trail’s End. Once both of a player’s hikers reach Trail’s End, that player’s hike is over for the season.\n· If all other hikers have already left the trail when your turn begins, you must move directly to Trail’s End and choose a space as usual.\nVia Ferrata:\n· Every site except the center site has a Via Ferrata tile above it. After landing, you may spend one carabiner to gain that tile’s benefit and one snow.\n· You may use the Via Ferrata only once per turn, and you may do so before or after the site action.\nNational Parks:\n· A parks action lets you either reserve one park or visit any number of parks. Reserving takes one card from the display or the top card of the deck and places it in your reserved area.\n· Visiting requires paying the resources shown on the park card. Wildlife may replace any ordinary resource, and an any-resource cost may be paid with any resources.\n· Stack visited parks by suit to the right of your mat. Each third park in a suit immediately earns that suit’s park award and its printed instant benefit. Each park award scores one point per park of that suit at the end of the game.\n· Wild parks belong to no suit. Add a wild park to any existing suit stack; if you have no suit stack yet, it joins the next colored park you visit.\n· Taking or discarding a card does not refill a display immediately. At the end of the turn, cards slide right and new cards enter from the left, so the rightmost card is always the oldest.\nTrail Die and Shutterbug:\n· The six faces of the trail die provide a carabiner, wildlife, mountain and water, a Wonder card, a photo, or sun and forest.\n· While you hold the Shutterbug, each photo action on your turn grants one extra photo. A hiker landing on the center site or certain cards can give you the Shutterbug.\nPhotos:\n· Each photo scores one point at the end of the game. Every five photos become one photo album, and each album scores five points.\n· At the end of the game, the player who took the most photos gains the photo award worth three points; ties go to the player furthest along the chalet track. Solo mode does not use the photo award.\nMug:\n· A mug action either fills or drinks. Filling moves the token up one space, to the top at most. Drinking resolves the benefit of the token’s current space, then returns the token to the bottom.\n· The first space offers a chalet action or a free conservation project.\n· The second space rolls the trail die three times and grants every result.\n· The third space visits one park for free from the display, your reserved area, or the top of the deck.\nConservation Projects:\n· A conservation action supports one displayed project, or pays one sun and one water to take the top card of the deck.\n· A conservation card activates only at the core site matching its color. Each card may activate once per turn, multiple cards may be activated in any order, and activation may come before or after the site’s main action.\n· If you take a card matching the site you are currently on, you may activate it immediately.\n· Collecting one card of each of the four colors earns a conservation award worth five points.\nChalet:\n· A chalet action turns in all snow on your mat and moves your chalet token along the track one snow space per snow token.\n· Passing a Wonder space draws a Wonder card. Passing an award space takes the most valuable award there, or draws a Wonder card if the stack is empty.\n· If your token ends on a space with another token, stack yours on top. At the end of the track you may still turn in snow, but you no longer move.\n· The chalet track breaks ties at the end of the game; further along wins, and the topmost token wins a shared space.\nWonder Cards:\n· Basic Wonder cards offer two instant actions, one on the top half and one on the bottom half; pay the resources on the left to gain the benefit on the right.\n· Campfire Wonder cards can be discarded to share an occupied site. At the end of the game they score according to their effect, and some let you turn in resources for points.\nSeasons and Final Scoring:\n· At the start of a season, rebuild the trail by shuffling the next three advanced sites with the four core sites and placing them on the seven spaces, then place new campfires and season bonuses.\n· After three seasons, final scoring begins. Each player may choose to turn in resources for points with any campfire Wonder cards in hand, or decline each one.\n· Once campfire effects are resolved, score visited parks, fixed campfire card effects, photos and albums, park awards, conservation awards, and chalet awards. The photo award is calculated after all campfire effects.\n· Park awards score one point per visited park of the matching suit, conservation awards and albums score five points each, photos score one point each, and chalet awards score their face value (3, 4, or 5 points). The player with the most points wins.\nRanger Greta:\n· In solo mode and the two-player challenge, Ranger Greta joins the hike. She always acts last and moves her hikers according to the trail die.\n· A butterfly face moves the rearmost hiker of a pair and a flower face moves the frontmost; the number of symbols is the count of available sites she advances to.\n· Greta treats a site with a communal campfire as available and spends that campfire to stop there. When one of her hikers reaches Trail’s End, discard the rightmost park card and conservation card from their displays.\n· In solo mode Greta controls two pairs of hikers, and before each of her turns you choose which pair moves first. You draw an extra Wonder card whenever you gain a chalet award; the photo award is not used, and your final score is compared to the rank table.",
			season: {
				cliffs: "Season of Cliffs",
				swimming: "Season of Swimming",
				memories: "Season of Memories",
				sun: "Season of Sun",
				dreams: "Season of Dreams",
				joy: "Season of Joy",
				scouting: "Season of Scouting",
				growth: "Season of Growth",
				climbing: "Season of Climbing",
				caves: "Season of Caves",
				meadows: "Season of Meadows",
				ice: "Season of Ice"
			},
			res: {
				mountain: "Mountain",
				forest: "Forest",
				sun: "Sun",
				water: "Water",
				wildlife: "Wildlife",
				snow: "Snow",
				any: "Any resource"
			},
			suit: {
				lime: "Lime",
				orange: "Orange",
				teal: "Teal",
				purple: "Purple",
				wild: "Wild"
			},
			site: {
				"core-forest": "Forest: gain one forest",
				"core-sun": "Sun: gain two sun",
				"core-mountain": "Mountain: gain one mountain and one snow",
				"core-water": "Water: gain two water and one snow",
				wildlife: "Wildlife: gain one wildlife",
				carabiner: "Carabiner: gain one carabiner",
				parks: "Parks action",
				die: "Roll the trail die",
				photo: "Take a photo",
				mug: "Mug action",
				chalet: "Chalet action",
				wonder: "Draw a Wonder card",
				conservation: "Conservation project"
			},
			siteShort: {
				"core-forest": "Forest",
				"core-sun": "Sun",
				"core-mountain": "Mountain",
				"core-water": "Water",
				wildlife: "Wildlife",
				carabiner: "Carabiner",
				parks: "Parks",
				die: "Roll die",
				photo: "Photo",
				mug: "Mug",
				chalet: "Chalet",
				wonder: "Wonder",
				conservation: "Conservation"
			},
			vf: {
				wonder: "Draw a Wonder card",
				sunwater: "Gain one sun and one water",
				photo: "Take a photo",
				conservation: "Conservation project",
				mug: "Mug action",
				wildlife: "Gain one wildlife"
			},
			vfShort: {
				wonder: "Wonder",
				sunwater: "Sun and water",
				photo: "Photo",
				conservation: "Conservation",
				mug: "Mug",
				wildlife: "Wildlife"
			},
			top: {
				conservation: "Conservation project",
				carabiner: "Gain a carabiner",
				mug: "Mug action",
				chalet: "Chalet action"
			},
			benefit: {
				die: "Roll the trail die",
				parks: "Parks action",
				mug: "Mug action",
				wonder: "Draw a Wonder card",
				photo: "Take a photo",
				wildlife: "Gain wildlife",
				carabiner: "Gain a carabiner"
			},
			token: {
				photo: "Photo",
				carabiner: "Carabiner"
			},
			consProject: {
				p0: "Biodiversity Restoration",
				p1: "Field Research",
				p2: "Heritage Site Restoration",
				p3: "Light Pollution Reduction",
				p4: "Nature Photography",
				p5: "Species Protection",
				p6: "Trail Maintenance"
			},
			campfire: {
				consForest: "One point per forest conservation card",
				consMountain: "One point per mountain conservation card",
				consSun: "One point per sun conservation card",
				consWater: "One point per water conservation card",
				iconForest: "One point per three forest icons on visited parks",
				iconMountain: "One point per three mountain icons on visited parks",
				iconSun: "One point per three sun icons on visited parks",
				iconWater: "One point per three water icons on visited parks",
				anyIcons: "One point per two any-resource icons on visited parks",
				album: "One point per photo album",
				wonderHand: "One point per Wonder card in hand, including this one",
				snow: "One point per snow on your mat",
				turnWildlife2: "Turn in two wildlife for four points",
				turnAny2: "Turn in any two resources for the Shutterbug and two photos",
				turnCarabiner: "Turn in one carabiner for two points",
				turnAny3: "Turn in any three resources for three points"
			},
			rank: {
				none: "Unranked",
				r1: "Dayhiker",
				r2: "Trekker",
				r3: "Explorer",
				r4: "Adventurer",
				r5: "Trailblazer"
			},
			opt: {
				greta: "Invite Ranger Greta",
				gretaHint: "Available in two-player games only; in solo mode Greta always joins."
			},
			seasonLabel: "Season {{n}}",
			seasonCard: "Season card: {{name}}",
			myTurn: "Your turn",
			waitingFor: "Waiting for {{name}}…",
			pending: {
				move: "Move one of your hikers",
				trailEnd: "Every other hiker has reached Trail’s End, so move directly there",
				actions: "Keep taking actions, or end your turn",
				parks: "Reserve or visit parks",
				mug: "Fill or drink your mug",
				mugChoice: "Choose your mug benefit",
				cons: "Support a conservation project",
				consFree: "Support a conservation project for free",
				assignWild: "Choose a suit for the wild park",
				freePark: "Visit one park for free",
				discardRes: "Discard one excess resource",
				discardWonder: "Discard one excess Wonder card",
				gretaColor: "Choose which pair of Greta’s hikers moves first",
				scoring: "Final scoring",
				none: "Game over"
			},
			trail: "Trail",
			trailEnd: "Trail’s End",
			trailStart: "Trailhead",
			parksTitle: "National Parks",
			consTitle: "Conservation Projects",
			chaletTrack: "Chalet Track",
			myMat: "My Mat",
			handTitle: "My Wonder Cards",
			fieldParks: "Parks",
			fieldProjects: "Projects",
			fieldChalet: "Chalet",
			awardParkDetail: "On arrival: {{benefit}}. At the end of the game, score 1 point per park of this suit.",
			awardFixedDetail: "Score {{n}} points at the end of the game.",
			wonderDiscard: "Discard",
			wonderDiscardName: "Discard {{name}}",
			wonderPlay: "Play this half",
			wonderWait: "Wait for your turn",
			wonderShare: "Discard to enter an occupied trail site.",
			wonderScore: "End-game scoring",
			fieldAward: "Award space",
			fieldFinish: "Finish",
			fieldSnowSpace: "Snow space",
			fieldAwardNext: "Take the {{n}}-point award first.",
			fieldAwardStack: "Below it, in order: {{scores}} points.",
			fieldDrawPassing: "Draw 1 Wonder card when you pass.",
			fieldChaletNote: "Move 1 snow space per snow token spent. Collect rewards as you pass them.",
			fieldTrackSpace: "Space {{n}} · {{name}}",
			fieldStartShort: "Start",
			fieldEndShort: "End",
			fieldEndActions: "End actions",
			fieldAction: "Action",
			fieldVacant: "Open",
			fieldChoose: "Choose",
			fieldSharedOccupied: "Hikers present",
			fieldSharedSlot: "Shared space",
			fieldSeasonNote: "At the start of the season, place 1 bonus token at each site from 2 to 7.",
			fieldChoosePark: "Choose a park",
			fieldFinishParks: "Finish parks action",
			fieldVisitedPark: "Visited {{name}} · +{{n}} points",
			fieldDisplay: "Display",
			fieldReserved: "Reserved {{n}}",
			fieldNoReserved: "No reserved parks",
			fieldTrailSeason: "Trail and season",
			fieldTrailRoute: "Along the trail",
			fieldSeasonTab: "Season card",
			fieldStop: "Site",
			fieldExtras: "Extras",
			fieldHikers: "Hikers",
			fieldGoTo: "Move to {{name}}",
			fieldResetCamera: "Reset valley view",
			fieldAlbum: "Albums",
			fieldHonors: "Awards",
			fieldCollection: "Visited parks",
			fieldSupported: "Supported projects",
			fieldNone: "None yet",
			fieldPlayerItems: "Player materials",
			fieldPack: "Pack",
			fieldHand: "Hand",
			fieldPanels: "Game materials",
			closePanel: "Close panel",
			camera: "Trail view",
			overview: "Valley",
			follow: "Follow",
			valleyUnavailable: "Open Trail to select a destination.",
			packSlots: "Resource slots",
			packUsage: "{{used}} / 12 slots",
			projectSite: "{{resource}} site",
			displayBonus: "Display bonus",
			journeyEnd: "Journey recap",
			scoreItem: "Scoring category",
			reviewTable: "Review trail and parks",
			returnScores: "Return to scores",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			journeyWinner: "Winner",
			resultParkAwards: "Park Awards",
			resultPhotoAward: "Photo Award",
			resultTotal: "Total",
			fx: {
				cardUsed: "Played {{card}}",
				honorEarned: "Honor earned",
				parkAward: "{{suit}} park award ×{{count}}",
				chaletAward: "Chalet award · {{points}} points"
			},
			handEmpty: "No Wonder cards",
			playersTitle: "Players",
			reservedTitle: "Reserved Parks",
			visitedTitle: "Visited Parks",
			deckCount: "{{n}} cards left in the deck",
			startDeck: "Deck",
			visit: "Visit",
			reserve: "Reserve",
			support: "Support",
			free: "Free",
			deckCost: "One sun, one water",
			points: "{{n}} points",
			cannotAfford: "Not enough resources",
			slotTop: "Action only",
			slotBoth: "Action + visit parks",
			slotParks: "Visit parks only",
			slotTaken: "Occupied",
			chooseSlot: "Choose a Trail’s End space",
			chooseHiker: "Choose a hiker",
			hikerLabel: "Hiker {{n}}",
			siteNo: "Site {{n}}",
			atEnd: "At Trail’s End",
			endTurn: "End turn",
			viaFerrata: "Via Ferrata",
			skip: "Skip",
			cancel: "Cancel",
			campfireLabel: "Campfire",
			useCommunalCampfire: "Spend the communal campfire",
			useCampfireCard: "Spend a campfire Wonder card",
			occupiedPrompt: "Another hiker is here; choose how to share the site",
			discardResPrompt: "Choose a resource to return to the supply",
			discardWonderPrompt: "Choose a Wonder card to discard",
			mug: {
				track: "Mug",
				level: "Space {{n}}",
				fill: "Fill",
				drink: "Drink",
				chalet: "Chalet action",
				cons: "Free conservation project",
				benefit1: "First space: chalet action or free conservation",
				benefit2: "Second space: roll the trail die three times",
				benefit3: "Third space: visit one park for free"
			},
			assignWildPrompt: "Which suit does this wild park join?",
			freeParkPrompt: "Visit one park for free",
			wonder: {
				top: "Top",
				bottom: "Bottom",
				play: "Play",
				pay: "Pay {{cost}}",
				grant: "Gain {{grant}}",
				campfireCard: "Campfire card",
				noPlay: "Cannot be played directly"
			},
			resources: "Resources",
			carabiners: "Carabiners {{n}}",
			photos: "Photos {{n}}",
			albums: "Albums {{n}}",
			awards: "Awards {{n}}",
			parkAwardsLabel: "Park awards {{n}}",
			consAwardsLabel: "Conservation awards {{n}}",
			chaletAwardsLabel: "Chalet awards {{n}}",
			chaletPos: "Chalet space {{n}}",
			visitedCount: "{{n}} visited",
			reservedCount: "{{n}} reserved",
			shutterbug: "Shutterbug",
			greta: "Ranger Greta",
			gretaHikers: "Greta’s hikers",
			soloRank: "Solo rank: {{name}}",
			soloRankTable: "Ranks: 30 Dayhiker, 35 Trekker, 40 Explorer, 45 Adventurer, 50 Trailblazer",
			siteAction: "Take the site action",
			endTop: "Trail’s End action",
			endParksTodo: "Trail’s End parks action",
			activateCons: "Activate conservation card",
			activateConsPrompt: "Choose a conservation card to activate",
			activateConsEmpty: "No conservation card can be activated here",
			gretaPairA: "Moss hikers first",
			gretaPairB: "Clay hikers first",
			scoringTitle: "Final Scoring",
			scoringPrompt: "You may turn in resources for points with campfire Wonder cards, or decline each one",
			scoringDone: "Finish scoring",
			scoringEmpty: "No usable campfire effect in hand",
			scoringPayPrompt: "Choose {{n}} resources to turn in",
			scoringPayChosen: "{{n}} chosen",
			scoringPayConfirm: "Turn in and score",
			scoringPayReset: "Choose again",
			scoringUsed: "Used",
			useEffect: "Use",
			endIncomplete: "Complete the Trail’s End actions first",
			over: {
				parks: "Parks {{n}}",
				campfire: "Campfire cards {{n}}",
				endgame: "Campfire scoring {{n}}",
				photos: "Photos {{n}}",
				parkAwards: "Park awards {{n}}",
				cons: "Conservation awards {{n}}",
				chalet: "Chalet awards {{n}}",
				photoAward: "Photo award {{n}}",
				total: "Total {{n}}",
				rank: "Rank: {{name}}"
			},
			noResources: "No resources",
			wild: "Wild park",
			ownMat: "Mine",
			otherMat: "{{name}}’s mat",
			scoreShort: "{{n}} points",
			err: {
				notTurn: "It is not your turn",
				notPlayer: "You are not in this game",
				phase: "You cannot do that right now",
				badAction: "That action is not available here",
				mustMove: "Move a hiker first",
				alreadyMoved: "You already moved this turn",
				mustEnd: "Every other hiker has reached Trail’s End, so you must move there",
				badTarget: "You cannot stop at that site",
				badHiker: "That hiker has already reached Trail’s End",
				badSlot: "Choose an available Trail’s End space",
				full: "That Trail’s End space is occupied",
				occupied: "Another hiker is here; you need a campfire",
				noCampfire: "No campfire is available",
				badPark: "No park card can be taken",
				badCons: "No conservation card can be taken",
				noRes: "Not enough resources",
				noCarabiner: "Not enough carabiners",
				noVf: "The Via Ferrata is not available here",
				badWonder: "That Wonder card cannot be used this way",
				badSuit: "That suit is not available",
				noConsSite: "No conservation card can be activated here",
				consUsed: "That conservation card was already activated this turn"
			}
		}
	}
};
//#endregion
export { ra as default };
