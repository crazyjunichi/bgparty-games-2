import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { useT as l } from "@bgparty/sdk/i18n";
import { IconClose as u, IconPile as d } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as h } from "@bgparty/sdk/assets";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { usePrefersReducedMotion as y } from "@bgparty/sdk/fx/use-reduced-motion";
import { ConfirmButton as b } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as x, OptionSection as ee } from "@bgparty/sdk/ui/game-options";
var S = Object.fromEntries([
	{
		id: 0,
		name: "Lake District",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 1,
		name: "Picos de Europa",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 2,
		name: "Vatnajökull",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 3,
		name: "Calanques",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 4,
		name: "Samaria",
		suit: "purple",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 5,
		name: "Rila",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 6,
		name: "Jotunheimen",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 3,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 7,
		name: "Cinque Terre",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 2,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 8,
		name: "Tatra",
		suit: "purple",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 9,
		name: "Swiss National Park",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 10,
		name: "Loch Lomond & The Trossachs",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 11,
		name: "Jostedalsbreen",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 12,
		name: "Connemara",
		suit: "teal",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 13,
		name: "Hardangervidda",
		suit: "teal",
		points: 4,
		cost: {
			forest: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 14,
		name: "Theth",
		suit: "teal",
		points: 5,
		cost: {
			forest: 3,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 15,
		name: "Triglav",
		suit: "teal",
		points: 5,
		cost: {
			forest: 2,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 16,
		name: "Berchtesgaden",
		suit: "teal",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 17,
		name: "Retezat",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 18,
		name: "Abruzzo, Lazio e Molise",
		suit: "purple",
		points: 2,
		cost: {
			mountain: 1,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 19,
		name: "Arcipelago di La Maddalena",
		suit: "purple",
		points: 2,
		cost: {
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 20,
		name: "Göreme",
		suit: "orange",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 21,
		name: "Pyrénées",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 1,
			sun: 2,
			any: 2
		}
	},
	{
		id: 22,
		name: "Sarek",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 3,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 23,
		name: "Timanfaya",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 2,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 24,
		name: "Dolomiti Bellunesi",
		suit: "orange",
		points: 5,
		cost: { mountain: 3 }
	},
	{
		id: 25,
		name: "Hohe Tauern",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 26,
		name: "Thingvellir",
		suit: "teal",
		points: 2,
		cost: {
			forest: 1,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 27,
		name: "Wadden Sea",
		suit: "teal",
		points: 2,
		cost: { water: 4 },
		instant: "mug"
	},
	{
		id: 28,
		name: "Pirin",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 29,
		name: "Oulanka",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 30,
		name: "Killarney",
		suit: "lime",
		points: 5,
		cost: {
			forest: 3,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 31,
		name: "Durmitor",
		suit: "lime",
		points: 5,
		cost: {
			forest: 2,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 32,
		name: "Gauja",
		suit: "lime",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 33,
		name: "Doñana",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 34,
		name: "Écrins",
		suit: "orange",
		points: 2,
		cost: {
			mountain: 1,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 35,
		name: "Vikos-Aoös",
		suit: "orange",
		points: 2,
		cost: { sun: 4 },
		instant: "photo"
	},
	{
		id: 36,
		name: "Olympus",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 37,
		name: "Ordesa y Monte Perdido",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 38,
		name: "Plitvice Lakes",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 2,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 39,
		name: "Teide",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 40,
		name: "Peneda-Gerês",
		suit: "lime",
		points: 2,
		cost: {
			forest: 1,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 41,
		name: "Gesäuse",
		suit: "lime",
		points: 2,
		cost: { sun: 4 },
		instant: "die"
	},
	{
		id: 42,
		name: "Krka",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 43,
		name: "Abisko",
		suit: "lime",
		points: 4,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 44,
		name: "Saxon Switzerland",
		suit: "lime",
		points: 3,
		cost: {
			forest: 2,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 45,
		name: "Butrint",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 46,
		name: "Cairngorms",
		suit: "lime",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 47,
		name: "Peak District",
		suit: "lime",
		points: 4,
		cost: {
			forest: 1,
			sun: 2,
			any: 2
		}
	}
].map((e) => [e.id, e])), C = [
	"lime",
	"orange",
	"teal",
	"purple"
], te = {
	lime: "wildlife",
	orange: "photo",
	teal: "mug",
	purple: "wonder"
}, w = [
	"sun",
	"mountain",
	"water",
	"forest"
], ne = {
	sun: { sun: 2 },
	mountain: { mountain: 1 },
	water: { water: 2 },
	forest: { forest: 1 }
}, re = [
	{
		name: "Biodiversity Restoration",
		benefit: "die"
	},
	{
		name: "Field Research",
		benefit: "parks"
	},
	{
		name: "Heritage Site Restoration",
		benefit: "mug"
	},
	{
		name: "Light Pollution Reduction",
		benefit: "wonder"
	},
	{
		name: "Nature Photography",
		benefit: "photo"
	},
	{
		name: "Species Protection",
		benefit: "wildlife"
	},
	{
		name: "Trail Maintenance",
		benefit: "carabiner"
	}
], T = (e) => w[Math.floor(e / 7)], E = (e, t = 1) => ({
	t: "res",
	res: e,
	n: t
}), ie = (e = 1) => ({
	t: "carabiner",
	n: e
}), D = [
	{
		id: "b01",
		no: 1,
		name: "Take a Wild Ride",
		art: "w01",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [ie(2)]
		}
	},
	{
		id: "b02",
		no: 2,
		name: "Savor the Sunrise",
		art: "w02",
		top: { grants: [E("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [E("forest"), E("water")]
		}
	},
	{
		id: "b03",
		no: 3,
		name: "Bask in the Light",
		art: "w03",
		top: { grants: [E("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [E("mountain"), E("water")]
		}
	},
	{
		id: "b04",
		no: 4,
		name: "Enjoy the Forests",
		art: "w04",
		top: { grants: [E("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [{
				t: "photo",
				n: 1
			}, E("sun")]
		}
	},
	{
		id: "b05",
		no: 5,
		name: "Walk in the Woods",
		art: "w05",
		top: { grants: [E("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [E("wildlife"), E("sun")]
		}
	},
	{
		id: "b06",
		no: 6,
		name: "Take a Hike Bike",
		art: "w06",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [E("wildlife")] }
	},
	{
		id: "b07",
		no: 7,
		name: "Explore the Backcountry",
		art: "w07",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [E("wildlife", 2)]
		}
	},
	{
		id: "b08",
		no: 8,
		name: "Clear Skies, Full Hearts",
		art: "w08",
		top: { grants: [E("sun", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b09",
		no: 9,
		name: "Protect the Peaks",
		art: "w09",
		top: { grants: [E("mountain")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b10",
		no: 10,
		name: "Reflect on the Journey",
		art: "w10",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "mug" }, { t: "mug" }]
		}
	},
	{
		id: "b11",
		no: 11,
		name: "Trail Magic",
		art: "w11",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{ t: "mug" }] }
	},
	{
		id: "b12",
		no: 12,
		name: "Take a Dip",
		art: "w12",
		top: { grants: [E("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [E("forest"), E("sun")]
		}
	},
	{
		id: "b13",
		no: 13,
		name: "Ford a Mountain Stream",
		art: "w13",
		top: { grants: [E("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [E("mountain"), E("sun")]
		}
	},
	{
		id: "b14",
		no: 14,
		name: "Clip In and Climb",
		art: "w14",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [ie()] }
	},
	{
		id: "b16",
		no: 16,
		name: "Capture the Moment",
		art: "w16",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "shutterbug" }, {
				t: "photo",
				n: 1
			}]
		}
	},
	{
		id: "b17",
		no: 17,
		name: "Ramble Along",
		art: "w17",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{
			t: "photo",
			n: 1
		}] }
	},
	{
		id: "b18",
		no: 18,
		name: "Ascend the Mountain",
		art: "w18",
		top: { grants: [E("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [ie(), E("water")]
		}
	},
	{
		id: "b19",
		no: 19,
		name: "Scale the Summit",
		art: "w19",
		top: { grants: [E("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [{ t: "mug" }, E("water")]
		}
	},
	{
		id: "b20",
		no: 20,
		name: "Preserve the Trees",
		art: "w20",
		top: { grants: [E("forest")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b21",
		no: 21,
		name: "Clean the Riverbanks",
		art: "w21",
		top: { grants: [E("water", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	}
], O = [
	{
		id: "c01",
		no: 1,
		art: "w15",
		effect: "consForest"
	},
	{
		id: "c02",
		no: 2,
		art: "w36",
		effect: "consMountain"
	},
	{
		id: "c03",
		no: 3,
		art: "w29",
		effect: "consSun"
	},
	{
		id: "c04",
		no: 4,
		art: "w30",
		effect: "consWater"
	},
	{
		id: "c05",
		no: 5,
		art: "w31",
		effect: "iconForest"
	},
	{
		id: "c06",
		no: 6,
		art: "w32",
		effect: "iconMountain"
	},
	{
		id: "c07",
		no: 7,
		art: "w33",
		effect: "iconSun"
	},
	{
		id: "c08",
		no: 8,
		art: "w34",
		effect: "iconWater"
	},
	{
		id: "c09",
		no: 9,
		art: "w35",
		effect: "anyIcons"
	},
	{
		id: "c10",
		no: 10,
		art: "w22",
		effect: "album"
	},
	{
		id: "c11",
		no: 11,
		art: "w23",
		effect: "wonderHand"
	},
	{
		id: "c12",
		no: 12,
		art: "w24",
		effect: "snow"
	},
	{
		id: "c13",
		no: 13,
		art: "w25",
		effect: "turnWildlife2"
	},
	{
		id: "c14",
		no: 14,
		art: "w26",
		effect: "turnAny2"
	},
	{
		id: "c15",
		no: 15,
		art: "w27",
		effect: "turnCarabiner"
	},
	{
		id: "c16",
		no: 16,
		art: "w28",
		effect: "turnAny3"
	}
], ae = Object.fromEntries(D.map((e) => [e.id, e])), k = Object.fromEntries(O.map((e) => [e.id, e]));
[...D.map((e) => e.id), ...O.map((e) => e.id)];
var A = [
	{
		id: "cliffs",
		name: "Season of Cliffs",
		pattern: [
			"water",
			"water",
			"sun",
			"sun",
			"sun",
			"water"
		],
		fires: [
			1,
			7,
			5
		],
		display: {
			zone: "cons",
			token: "carabiner"
		}
	},
	{
		id: "swimming",
		name: "Season of Swimming",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"water",
			"water"
		],
		fires: [
			6,
			4,
			3
		],
		display: {
			zone: "parks",
			token: "water"
		}
	},
	{
		id: "memories",
		name: "Season of Memories",
		pattern: [
			"sun",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			2,
			6
		],
		display: {
			zone: "cons",
			token: "photo"
		}
	},
	{
		id: "sun",
		name: "Season of Sun",
		pattern: [
			"sun",
			"sun",
			"water",
			"sun",
			"sun",
			"sun"
		],
		fires: [
			5,
			3,
			2
		],
		display: {
			zone: "parks",
			token: "sun"
		}
	},
	{
		id: "dreams",
		name: "Season of Dreams",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			7,
			1
		],
		display: {
			zone: "parks",
			token: "snow"
		}
	},
	{
		id: "joy",
		name: "Season of Joy",
		pattern: [
			"sun",
			"water",
			"forest",
			"mountain",
			"wildlife",
			"sun"
		],
		fires: [
			7,
			1,
			3
		]
	},
	{
		id: "scouting",
		name: "Season of Scouting",
		pattern: [
			"sun",
			"sun",
			"wildlife",
			"wildlife",
			"wildlife",
			"water"
		],
		fires: [
			7,
			5,
			2
		]
	},
	{
		id: "growth",
		name: "Season of Growth",
		pattern: [
			"sun",
			"water",
			"forest",
			"sun",
			"forest",
			"forest"
		],
		fires: [
			5,
			6,
			7
		]
	},
	{
		id: "climbing",
		name: "Season of Climbing",
		pattern: [
			"sun",
			"water",
			"sun",
			"carabiner",
			"carabiner",
			"carabiner"
		],
		fires: [
			1,
			3,
			6
		]
	},
	{
		id: "caves",
		name: "Season of Caves",
		pattern: [
			"water",
			"sun",
			"mountain",
			"mountain",
			"water",
			"mountain"
		],
		fires: [
			3,
			2,
			1
		]
	},
	{
		id: "meadows",
		name: "Season of Meadows",
		pattern: [
			"sun",
			"photo",
			"sun",
			"photo",
			"sun",
			"photo"
		],
		fires: [
			2,
			4,
			5
		]
	},
	{
		id: "ice",
		name: "Season of Ice",
		pattern: [
			"snow",
			"water",
			"snow",
			"water",
			"snow",
			"water"
		],
		fires: [
			3,
			5,
			6
		]
	}
];
Object.fromEntries(A.map((e, t) => [t, e]));
var oe = [
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water"
], se = [
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
], ce = {
	"core-forest": "forest",
	"core-sun": "sun",
	"core-mountain": "mountain",
	"core-water": "water"
};
function le(e) {
	return ce[e] ?? null;
}
var ue = [
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
], j = [
	{
		ranger: "butterfly",
		symbols: 1,
		carabiner: 1
	},
	{
		ranger: "butterfly",
		symbols: 1,
		res: { wildlife: 1 }
	},
	{
		ranger: "butterfly",
		symbols: 2,
		res: {
			mountain: 1,
			water: 1
		}
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "wonder"
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "photo"
	},
	{
		ranger: "flower",
		symbols: 2,
		res: {
			sun: 1,
			forest: 1
		}
	}
], de = [
	{ t: "start" },
	{ t: "snow" },
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: 0,
		solo: 3
	},
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: null,
		solo: 4
	},
	{ t: "snow" },
	{ t: "snow" },
	{
		t: "award",
		stack: 1,
		solo: 5
	},
	{ t: "snow" },
	{ t: "snow" },
	{ t: "end" }
], fe = de.length - 1, pe = [
	"conservation",
	"carabiner",
	"mug",
	"chalet"
], me = {
	mountain: 16,
	forest: 16,
	sun: 22,
	water: 22,
	wildlife: 14,
	snow: 20
}, he = [
	{
		at: 50,
		rank: 5
	},
	{
		at: 45,
		rank: 4
	},
	{
		at: 40,
		rank: 3
	},
	{
		at: 35,
		rank: 2
	},
	{
		at: 30,
		rank: 1
	}
], ge = {
	id: "parkseurope",
	uuid: "57ea4f6d-4e67-4904-8ef4-ab6f134dd492",
	tier: "alpha",
	mechanics: [
		"set-collection",
		"hand-management",
		"engine-building",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.parkseurope.name",
	descKey: "games.parkseurope.desc",
	rulesKey: "games.parkseurope.rules",
	icon: "🏞️",
	iconImg: "games/parkseurope.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#3f7a4d",
	releasedAt: "2026-11-24T05:21:41+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, _e = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
];
function ve(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		wildlife: t.wildlife ?? 0
	};
	for (let r of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) {
		let i = t[r] ?? 0;
		n[r] = Math.min(e[r], i), n.wildlife += i - n[r];
	}
	if (n.wildlife > e.wildlife) return null;
	let r = t.any ?? 0;
	for (let t of _e) {
		if (r === 0) break;
		let i = Math.min(r, e[t] - n[t]);
		n[t] += i, r -= i;
	}
	return r === 0 ? n : null;
}
//#endregion
//#region src/game/schema.ts
var ye = t.enum([
	"lime",
	"orange",
	"teal",
	"purple",
	"wild"
]), be = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow"
]), M = t.enum([
	"conservation",
	"carabiner",
	"mug",
	"chalet"
]), xe = t.enum([
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water",
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
]), N = t.enum([
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
]), Se = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow",
	"photo",
	"carabiner"
]), Ce = t.partialRecord(be, t.int().nonnegative()), we = t.partialRecord(t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
]), t.int().nonnegative().max(3)), Te = t.union([
	t.object({
		kind: t.literal("top"),
		action: M
	}),
	t.object({
		kind: t.literal("both"),
		action: M
	}),
	t.object({ kind: t.literal("parks") })
]), Ee = t.union([
	t.object({
		type: t.literal("move"),
		hiker: t.union([t.literal(0), t.literal(1)]),
		to: t.int().min(1).max(8),
		campfire: t.enum(["communal", "card"]).optional(),
		card: t.string().optional(),
		slot: Te.optional()
	}),
	t.object({ type: t.literal("siteAction") }),
	t.object({
		type: t.literal("activateCons"),
		card: t.int().nonnegative()
	}),
	t.object({ type: t.literal("endTop") }),
	t.object({ type: t.literal("endParks") }),
	t.object({ type: t.literal("viaFerrata") }),
	t.object({
		type: t.literal("reserve"),
		from: t.enum(["display", "deck"]),
		index: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("visit"),
		parkId: t.int().nonnegative(),
		pay: Ce.optional()
	}),
	t.object({ type: t.literal("parksDone") }),
	t.object({
		type: t.literal("mug"),
		act: t.enum(["fill", "drink"])
	}),
	t.object({
		type: t.literal("mugChoice"),
		choice: t.enum(["chalet", "cons"])
	}),
	t.object({
		type: t.literal("consPick"),
		index: t.int().nonnegative().optional(),
		deck: t.boolean().optional()
	}),
	t.object({
		type: t.literal("assignWild"),
		suit: t.enum([
			"lime",
			"orange",
			"teal",
			"purple"
		])
	}),
	t.object({
		type: t.literal("freePark"),
		parkId: t.int().nonnegative().optional(),
		from: t.enum([
			"display",
			"reserve",
			"deck"
		])
	}),
	t.object({
		type: t.literal("playWonder"),
		card: t.string(),
		side: t.enum(["top", "bottom"]),
		pay: Ce.optional()
	}),
	t.object({
		type: t.literal("discardRes"),
		res: t.enum([
			"mountain",
			"forest",
			"sun",
			"water",
			"wildlife"
		])
	}),
	t.object({
		type: t.literal("discardWonder"),
		card: t.string()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("gretaColor"),
		first: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("campfireEnd"),
		card: t.string(),
		pay: we.optional(),
		carabiner: t.boolean().optional()
	}),
	t.object({ type: t.literal("scoringDone") })
]), De = t.object({ greta: t.boolean().default(!1) }).prefault({}), Oe = t.object({
	id: t.int().nonnegative(),
	suit: ye.nullable()
}), ke = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	res: t.record(t.enum([
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]), t.int().nonnegative()),
	snow: t.int().nonnegative(),
	carabiners: t.int().nonnegative(),
	mug: t.int().min(0).max(3),
	photos: t.int().nonnegative(),
	albums: t.int().nonnegative(),
	photosTaken: t.int().nonnegative(),
	visited: t.array(Oe),
	reserved: t.array(t.int().nonnegative()),
	cons: t.array(t.int().nonnegative()),
	parkAwards: t.record(t.enum([
		"lime",
		"orange",
		"teal",
		"purple"
	]), t.int().nonnegative()),
	consAwards: t.int().nonnegative(),
	chaletAwards: t.array(t.int().nonnegative()),
	wonderCount: t.int().nonnegative(),
	shutterbug: t.boolean(),
	chaletPos: t.int().nonnegative(),
	chaletOrder: t.int(),
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	endUsed: t.array(t.string()),
	endPoints: t.int().nonnegative()
}), Ae = t.object({
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	solo: t.boolean()
}), je = t.object({
	kind: t.enum(["top", "both"]),
	action: M,
	rid: t.string().nullable()
}), Me = t.object({
	phase: t.enum([
		"turn",
		"scoring",
		"ended"
	]),
	season: t.int().min(1).max(3),
	turn: t.string().nullable(),
	moved: t.boolean(),
	pending: t.enum([
		"move",
		"trailEnd",
		"actions",
		"parks",
		"mug",
		"mugChoice",
		"cons",
		"assignWild",
		"freePark",
		"discardRes",
		"discardWonder",
		"gretaColor",
		"scoring",
		"none"
	]),
	freeCons: t.boolean(),
	landingSite: t.int().min(1).max(7).nullable(),
	siteDone: t.boolean(),
	consUsed: t.array(t.int().nonnegative()),
	vfUsed: t.boolean(),
	end: t.object({
		action: M.nullable(),
		topDone: t.boolean(),
		parksDone: t.boolean()
	}).nullable(),
	seasonCard: t.string(),
	order: t.array(t.string()),
	players: t.array(ke),
	trailSites: t.array(xe),
	trailBonus: t.array(Se.nullable()),
	campfires: t.array(t.int().nonnegative()),
	vf: t.array(N.nullable()),
	parksDisplay: t.array(t.int().nonnegative()),
	parksDeck: t.int().nonnegative(),
	parksBonus: t.array(Se.nullable()),
	consDisplay: t.array(t.int().nonnegative()),
	consDeck: t.int().nonnegative(),
	consBonus: t.array(Se.nullable()),
	consAwardsLeft: t.int().nonnegative(),
	chaletStacks: t.array(t.array(t.int().nonnegative())),
	endSlots: t.array(je),
	parksEndOccupied: t.boolean(),
	greta: Ae.nullable(),
	soloRanks: t.array(t.object({
		at: t.int().nonnegative(),
		rank: t.int().nonnegative()
	})).nullable(),
	revealedCampfire: t.array(t.object({
		rid: t.string(),
		cards: t.array(t.string())
	})).nullable(),
	campfireUsed: t.array(t.string()),
	finalRows: t.array(t.object({
		rid: t.string(),
		parks: t.int(),
		campfire: t.int(),
		endgame: t.int(),
		photos: t.int(),
		parkAwards: t.int(),
		cons: t.int(),
		chalet: t.int(),
		photoAward: t.int(),
		total: t.int()
	})).nullable()
}), Ne = t.object({
	hand: t.array(t.string()),
	isTurn: t.boolean()
}), Pe = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], P = (e, t) => ({
	code: `games.parkseurope.err.${e}`,
	...t ? { params: t } : {}
});
function F(t, n, r) {
	let i = r;
	for (let r = t.length - 1; r > 0; r--) {
		let a = e(n, i++, r + 1);
		[t[r], t[a]] = [t[a], t[r]];
	}
	return {
		items: t,
		cursor: i
	};
}
function I(e, t, n) {
	return {
		seat: e,
		res: {
			mountain: 0,
			forest: 0,
			sun: 0,
			water: 0,
			wildlife: 0
		},
		snow: 0,
		carabiners: 1,
		mug: 0,
		photos: 0,
		albums: 0,
		photosTaken: 0,
		visited: [],
		reserved: [],
		cons: [],
		parkAwards: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		consAwards: 0,
		consSets: 0,
		chaletAwards: [],
		wonderHand: [t],
		shutterbug: !1,
		chaletPos: 0,
		chaletOrder: n,
		hikers: [0, 0],
		slots: [null, null],
		sets: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		endUsed: [],
		endPoints: 0
	};
}
function L(e, t, n, r) {
	let i = Math.min(r, e.supply[n]);
	i <= 0 || (e.supply[n] -= i, t.res[n] += i);
}
function Fe(e, t, n) {
	let r = Math.min(n, e.supply.snow);
	r <= 0 || (e.supply.snow -= r, t.snow += r);
}
function Ie(e, t, n) {
	let r = Math.min(n, e.supply.carabiner);
	r <= 0 || (e.supply.carabiner -= r, t.carabiners += r);
}
function R(e, t, n) {
	for (t.photosTaken += n, t.photos += n; t.photos >= 5 && t.albums < 8;) t.photos -= 5, t.albums += 1;
}
function z(e, t, n) {
	for (let r = 0; r < n; r++) {
		if (e.wonderDeck.length === 0) {
			if (e.wonderDiscard.length === 0) return;
			let t = F(e.wonderDiscard.slice(), e.seed, e.cursor);
			e.wonderDeck = t.items, e.cursor = t.cursor, e.wonderDiscard = [];
		}
		let n = e.wonderDeck.pop();
		n && t.wonderHand.push(n);
	}
}
function B(e, t) {
	for (let t of e.order) e.players[t].shutterbug = !1;
	t && e.players[t] && (e.players[t].shutterbug = !0);
}
function Le(e) {
	let t = e.snow * 2;
	for (let n of Pe) t += e.res[n];
	return t;
}
function Re(e, t) {
	if (t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] > 0 && --e.supply[n];
}
function V(e, t) {
	if (!t || t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] += 1;
}
function ze(e, t, n) {
	n === "photo" ? R(e, t, 1) : n === "carabiner" ? t.carabiners += 1 : n === "snow" ? t.snow += 1 : t.res[n] += 1;
}
function Be(e, t, n) {
	let r = (e) => e.some((e) => e !== null && e.kind !== "parks" && e.kind === t && e.action === n);
	for (let t of e.order) if (r(e.players[t].slots)) return !0;
	return !!(e.greta && r(e.greta.slots));
}
function H(e, t, n) {
	let r = ve(t.res, n);
	if (!r) return !1;
	for (let n of Pe) t.res[n] -= r[n], e.supply[n] += r[n];
	return !0;
}
function U(e, t) {
	e.tasks.push(t);
}
function Ve(t, n) {
	let r = j[e(t.seed, t.cursor++, j.length)];
	if (r.carabiner && Ie(t, n, r.carabiner), r.res) for (let e of Pe) r.res[e] && L(t, n, e, r.res[e]);
	r.grant === "wonder" && z(t, n, 1), r.grant === "photo" && R(t, n, 1 + +!!n.shutterbug);
}
function He(e, t, n) {
	switch (n) {
		case "die":
			Ve(e, t);
			break;
		case "parks":
			U(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			U(e, { t: "mug" });
			break;
		case "wonder":
			z(e, t, 1);
			break;
		case "photo":
			R(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			L(e, t, "wildlife", 1);
			break;
		case "carabiner": Ie(e, t, 1);
	}
}
function W(e, t, n) {
	switch (n.t) {
		case "res":
			L(e, t, n.res, n.n);
			break;
		case "snow":
			Fe(e, t, n.n);
			break;
		case "carabiner":
			Ie(e, t, n.n);
			break;
		case "photo":
			R(e, t, n.n + +!!t.shutterbug);
			break;
		case "wonder":
			z(e, t, n.n);
			break;
		case "die":
			for (let r = 0; r < n.n; r++) Ve(e, t);
			break;
		case "parks":
			U(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			U(e, { t: "mug" });
			break;
		case "cons":
			U(e, {
				t: "cons",
				free: !1
			});
			break;
		case "chalet":
			Ue(e, t);
			break;
		case "shutterbug": B(e, e.turn ?? G(e, t));
	}
}
function G(e, t) {
	for (let n of e.order) if (e.players[n] === t) return n;
	return null;
}
function K(e, t, n) {
	if (n === "snow") {
		Fe(e, t, 1);
		return;
	}
	if (n === "chalet") {
		Ue(e, t);
		return;
	}
	He(e, t, n);
}
function Ue(e, t) {
	let n = t.snow;
	if (n <= 0) return;
	e.supply.snow += n, t.snow = 0;
	let r = t.chaletPos, i = r, a = n;
	for (; a > 0 && i < fe;) i += 1, de[i].t === "snow" && --a;
	for (let n = r + 1; n <= i; n++) {
		let r = de[n];
		r.t === "wonder" ? z(e, t, 1) : r.t === "award" && Ge(e, t, n, r);
	}
	t.chaletPos = i, t.chaletOrder = We(e, i) + 1, e.chaletSeq = t.chaletOrder;
}
function We(e, t) {
	let n = -1;
	for (let r of e.order) {
		let i = e.players[r];
		i.chaletPos === t && (n = Math.max(n, i.chaletOrder));
	}
	return n;
}
function Ge(e, t, n, r) {
	let i = !1;
	if (e.solo) e.chaletClaimed[n] || (e.chaletClaimed[n] = !0, t.chaletAwards.push(r.solo), i = !0);
	else if (r.stack !== null) {
		let n = e.chaletStacks[r.stack].pop();
		n !== void 0 && (t.chaletAwards.push(n), i = !0);
	}
	if (!i) {
		z(e, t, 1);
		return;
	}
	e.solo && z(e, t, 1);
}
function Ke(e, t) {
	let n = 0;
	for (let r of e.order) for (let i of e.players[r].hikers) i === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function qe(e, t, n) {
	let r = e.trailBonus[n];
	r && (e.trailBonus[n] = null, ze(e, t, r));
}
function Je(e, t, n) {
	switch (n) {
		case "core-forest":
			L(e, t, "forest", 1);
			break;
		case "core-sun":
			L(e, t, "sun", 2);
			break;
		case "core-mountain":
			L(e, t, "mountain", 1), Fe(e, t, 1);
			break;
		case "core-water":
			L(e, t, "water", 2), Fe(e, t, 1);
			break;
		case "wildlife":
			L(e, t, "wildlife", 1);
			break;
		case "carabiner":
			Ie(e, t, 1);
			break;
		case "die":
			Ve(e, t);
			break;
		case "photo":
			R(e, t, 1 + +!!t.shutterbug);
			break;
		case "wonder":
			z(e, t, 1);
			break;
		case "chalet":
			Ue(e, t);
			break;
		case "parks":
			U(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			U(e, { t: "mug" });
			break;
		case "conservation": U(e, {
			t: "cons",
			free: !1
		});
	}
}
function Ye(e, t, n) {
	if (e.landingSite === null) return P("noConsSite");
	let r = le(e.trailSites[e.landingSite - 1]);
	if (!r) return P("noConsSite");
	let i = t.cons[n];
	return i === void 0 || T(i) !== r ? P("badCons") : e.consUsed.includes(n) ? P("consUsed") : (e.consUsed.push(n), He(e, t, re[i % 7].benefit), null);
}
function Xe(e) {
	let t = S[e]?.cost ?? {};
	return {
		forest: t.forest ?? 0,
		mountain: t.mountain ?? 0,
		sun: t.sun ?? 0,
		water: t.water ?? 0,
		any: t.any ?? 0
	};
}
function q(e, t, n) {
	let r = {
		id: n,
		suit: null
	};
	t.visited.push(r);
	let i = C.filter((e) => t.visited.some((t) => t.id !== n && t.suit === e));
	if (i.length !== 0) {
		if (i.length === 1) {
			r.suit = i[0], Ze(e, t);
			return;
		}
		U(e, {
			t: "assignWild",
			parkId: n,
			suits: i
		});
	}
}
function J(e, t, n) {
	let r = S[n].suit;
	if (r === "wild") {
		q(e, t, n);
		return;
	}
	for (let e of t.visited) e.suit === null && (e.suit = r);
	t.visited.push({
		id: n,
		suit: r
	}), Ze(e, t);
}
function Ze(e, t) {
	for (let n of C) {
		let r = t.visited.filter((e) => e.suit === n).length, i = Math.floor(r / 3);
		for (; t.sets[n] < i;) t.sets[n] += 1, K(e, t, te[n]), e.parkAwardPool[n] > 0 && (--e.parkAwardPool[n], t.parkAwards[n] += 1);
	}
}
function Qe(e, t, n) {
	n === "parks" ? (e.parkBonus.splice(t, 1), e.parksDisplay.splice(t, 1)) : (e.consBonus.splice(t, 1), e.consDisplay.splice(t, 1));
}
function Y(e) {
	for (; e.parksDisplay.length < 3 && e.parksDeck.length > 0;) e.parksDisplay.unshift(e.parksDeck.shift()), e.parkBonus.unshift(null);
	for (; e.consDisplay.length < 3 && e.consDeck.length > 0;) e.consDisplay.unshift(e.consDeck.shift()), e.consBonus.unshift(null);
}
function X(e, t, n) {
	n && ze(e, t, n);
}
function $e(e, t, n) {
	let r = e.parkBonus[n] ?? null;
	Qe(e, n, "parks"), X(e, t, r);
}
function et(e, t, n) {
	let r = S[n];
	if (!r) return !1;
	let i = e.parksDisplay.indexOf(n), a = t.reserved.indexOf(n);
	return i < 0 && a < 0 || !H(e, t, r.cost) ? !1 : (i >= 0 ? $e(e, t, i) : t.reserved.splice(a, 1), J(e, t, n), r.instant && K(e, t, r.instant), !0);
}
function tt(e, t, n, r, i) {
	let a;
	if (r) {
		if (!i && !H(e, t, {
			sun: 1,
			water: 1
		})) return P("noRes");
		if (e.consDeck.length === 0) return P("badCons");
		a = e.consDeck.shift();
	} else {
		if (n === void 0 || n < 0 || n >= e.consDisplay.length) return P("badCons");
		if (a = e.consDisplay[n], !i && !H(e, t, ne[T(a)])) return P("noRes");
		nt(e, t, n);
	}
	return t.cons.push(a), rt(e, t), null;
}
function nt(e, t, n) {
	let r = e.consBonus[n] ?? null;
	Qe(e, n, "cons"), X(e, t, r);
}
function rt(e, t) {
	let n = Infinity;
	for (let e of w) n = Math.min(n, t.cons.filter((t) => T(t) === e).length);
	for (Number.isFinite(n) || (n = 0); t.consSets < n;) t.consSets += 1, e.consAwardsLeft > 0 && (--e.consAwardsLeft, t.consAwards += 1);
}
function it(e) {
	e.moved = !1, e.landingSite = null, e.siteDone = !1, e.consUsed = [], e.vfUsed = !1, e.end = null, e.tasks = [];
}
function at(e, t) {
	return e.players[t].hikers.some((e) => e < 8);
}
function ot(e) {
	return !!e.greta && e.greta.hikers.some((e) => e < 8);
}
function st(e, t) {
	for (let n of e.order) if (n !== t && e.players[n].hikers.some((e) => e < 8)) return !1;
	return !ot(e);
}
function ct(e, t) {
	return t < e.order.length ? e.order[t] : "$greta";
}
function lt(e) {
	let t = e.order.length + +!!e.greta;
	for (let n = 0; n < t * 4 + 8; n++) {
		let n = (e.turnIdx + 1) % t, r = ct(e, n);
		if (r === "$greta") {
			if (e.turnIdx = n, !ot(e)) continue;
			if (e.greta && e.greta.solo) {
				e.turn = e.order[0], e.gretaPending = !0;
				return;
			}
			Ot(e, 0), Y(e);
			continue;
		}
		if (at(e, r)) {
			e.turnIdx = n, e.turn = r, e.gretaPending = !1, it(e);
			return;
		}
	}
	mt(e);
}
function ut(e, t) {
	e.turnIdx = e.order.indexOf(t), e.turn = t, e.gretaPending = !1, it(e);
}
function dt(e) {
	let t = e.order[0];
	for (let n of e.order) {
		let r = e.players[n], i = e.players[t];
		(r.chaletPos > i.chaletPos || r.chaletPos === i.chaletPos && r.chaletOrder > i.chaletOrder) && (t = n);
	}
	return t;
}
function ft(e) {
	let t = e.seasonAdvanced[e.season - 1], n = F([...oe, ...t], e.seed, e.cursor);
	e.cursor = n.cursor, e.trailSites = n.items.slice(0, 7);
}
function pt(e) {
	let t = A[e.seasonQueue[e.season - 1]];
	ft(e);
	for (let t of e.trailBonus) V(e, t);
	let n = [null];
	for (let r of t.pattern) Re(e, r), n.push(r);
	e.trailBonus = n;
	for (let t of e.parkBonus) V(e, t);
	for (let t of e.consBonus) V(e, t);
	if (e.parkBonus = e.parksDisplay.map(() => null), e.consBonus = e.consDisplay.map(() => null), t.display) {
		let n = t.display.token;
		t.display.zone === "parks" ? e.parkBonus = e.parksDisplay.map(() => (Re(e, n), n)) : e.consBonus = e.consDisplay.map(() => (Re(e, n), n));
	}
	let r = e.order.length, i;
	i = r <= 3 ? [t.fires[0]] : r === 4 ? [t.fires[0], t.fires[1]] : [
		t.fires[0],
		t.fires[1],
		t.fires[2]
	], e.campfires = i.filter((e) => e >= 1 && e <= 7);
}
function mt(e) {
	if (e.season >= 3) {
		bt(e);
		return;
	}
	e.season += 1;
	for (let t of e.order) {
		let n = e.players[t];
		n.hikers = n.hikers.map(() => 0), n.slots = n.slots.map(() => null);
	}
	e.greta && (e.greta.hikers = e.greta.hikers.map(() => 0), e.greta.slots = e.greta.slots.map(() => null)), pt(e), ut(e, dt(e));
}
function ht(e) {
	let t = {
		forest: 0,
		mountain: 0,
		sun: 0,
		water: 0,
		any: 0
	};
	for (let n of e.visited) {
		let e = Xe(n.id);
		t.forest += e.forest, t.mountain += e.mountain, t.sun += e.sun, t.water += e.water, t.any += e.any;
	}
	return t;
}
function gt(e) {
	let t = 0;
	for (let n of e.wonderHand) {
		let r = k[n];
		if (r) switch (r.effect) {
			case "consForest":
				t += e.cons.filter((e) => T(e) === "forest").length;
				break;
			case "consMountain":
				t += e.cons.filter((e) => T(e) === "mountain").length;
				break;
			case "consSun":
				t += e.cons.filter((e) => T(e) === "sun").length;
				break;
			case "consWater":
				t += e.cons.filter((e) => T(e) === "water").length;
				break;
			case "iconForest":
				t += Math.floor(ht(e).forest / 3);
				break;
			case "iconMountain":
				t += Math.floor(ht(e).mountain / 3);
				break;
			case "iconSun":
				t += Math.floor(ht(e).sun / 3);
				break;
			case "iconWater":
				t += Math.floor(ht(e).water / 3);
				break;
			case "anyIcons":
				t += Math.floor(ht(e).any / 2);
				break;
			case "album":
				t += e.albums;
				break;
			case "wonderHand":
				t += e.wonderHand.length;
				break;
			case "snow": t += e.snow;
		}
	}
	return t;
}
function _t(e, t) {
	return e.chaletPos === t.chaletPos ? t.chaletOrder - e.chaletOrder : t.chaletPos - e.chaletPos;
}
function vt(e) {
	let t = 0;
	for (let n of e.visited) t += S[n.id].points;
	return t;
}
function yt(e) {
	let t = 0;
	for (let n of C) {
		let r = e.visited.filter((e) => e.suit === n).length;
		t += e.parkAwards[n] * r;
	}
	return t;
}
function bt(e) {
	e.phase = "scoring", e.tasks = [], e.moved = !1, e.landingSite = null, e.siteDone = !0, e.consUsed = [], e.vfUsed = !0, e.end = null, e.gretaPending = !1, e.scoringIdx = 0, e.turnIdx = 0, e.turn = e.order[0] ?? null, e.campfireUsed = [];
	for (let t of e.order) e.players[t].endUsed = [], e.players[t].endPoints = 0;
}
var xt = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]);
function St(e, t, n, r) {
	let i = 0;
	for (let e of Pe) {
		let r = n[e] ?? 0;
		if (r > t.res[e]) return P("noRes");
		i += r;
	}
	if (i !== r) return P("noRes");
	for (let r of Pe) {
		let i = n[r] ?? 0;
		i !== 0 && (t.res[r] -= i, e.supply[r] += i);
	}
	return null;
}
function Ct(e, t, n) {
	let r = e.players[t], i = k[n.card];
	if (!i || !xt.has(i.effect) || !r.wonderHand.includes(n.card) || e.campfireUsed.includes(n.card)) return P("badWonder");
	let a = n.pay ?? {};
	if (i.effect === "turnWildlife2") {
		if ((a.wildlife ?? 0) !== 2) return P("noRes");
		let t = St(e, r, a, 2);
		if (t) return t;
		r.endPoints += 4;
	} else if (i.effect === "turnCarabiner") {
		if (n.carabiner !== !0 || r.carabiners < 1) return P("noCarabiner");
		--r.carabiners, e.supply.carabiner += 1, r.endPoints += 2;
	} else if (i.effect === "turnAny3") {
		let t = St(e, r, a, 3);
		if (t) return t;
		r.endPoints += 3;
	} else {
		let n = St(e, r, a, 2);
		if (n) return n;
		B(e, t), R(e, r, 2);
	}
	return e.campfireUsed.push(n.card), r.endUsed.push(n.card), null;
}
function wt(e) {
	let t = {}, n = [];
	for (let t of e.order) {
		let r = e.players[t], i = vt(r), a = gt(r), o = r.endPoints, s = r.photos + r.albums * 5, c = yt(r), l = r.consAwards * 5, u = r.chaletAwards.reduce((e, t) => e + t, 0), d = i + a + o + s + c + l + u;
		n.push({
			rid: t,
			parks: i,
			campfire: a,
			endgame: o,
			photos: s,
			parkAwards: c,
			cons: l,
			chalet: u,
			photoAward: 0,
			total: d
		});
	}
	let r = null;
	if (!e.solo) {
		let t = 0;
		for (let n of e.order) t = Math.max(t, e.players[n].photosTaken);
		if (t > 0) {
			let n = e.order.filter((n) => e.players[n].photosTaken === t);
			r = n[0];
			for (let t of n) _t(e.players[t], e.players[r]) < 0 && (r = t);
		}
	}
	for (let e of n) e.photoAward = e.rid === r ? 3 : 0, e.total += e.photoAward, t[e.rid] = e.total;
	let i = [...e.order].sort((n, r) => t[r] - t[n] || _t(e.players[n], e.players[r])), a = null;
	if (e.solo) {
		let n = t[e.order[0]];
		a = 0;
		for (let e of he) n >= e.at && (a = Math.max(a, e.rank));
	}
	e.final = {
		scores: t,
		ranking: i,
		winner: e.solo ? [] : [i[0]],
		soloRank: a,
		rows: n
	}, e.phase = "ended", e.tasks = [], e.end = null, e.gretaPending = !1, e.turn = null;
}
function Tt(t, n, r) {
	let i = r * 2, a = [n.hikers[i], n.hikers[i + 1]].map((e, t) => ({
		pos: e,
		hiker: i + t
	})).filter((e) => e.pos < 8);
	if (a.length === 0) return;
	let o = j[e(t.seed, t.cursor++, j.length)];
	a.sort((e, t) => e.pos - t.pos);
	let s = o.ranger === "butterfly" ? a[0] : a[a.length - 1], c = o.symbols, l = s.pos, u = [];
	for (let e = l + 1; e <= 7; e++) {
		let n = Ke(t, e), r = t.campfires.includes(e);
		if ((n === 0 || r) && u.push(e), u.length >= c) break;
	}
	if (u.length < c) {
		n.hikers[s.hiker] = 8, Et(t, n, s.hiker), Dt(t);
		return;
	}
	let d = u[c - 1];
	if (Ke(t, d) > 0) {
		let e = t.campfires.indexOf(d);
		e >= 0 && t.campfires.splice(e, 1);
	}
	n.hikers[s.hiker] = d, t.trailBonus[d - 1] && (V(t, t.trailBonus[d - 1]), t.trailBonus[d - 1] = null), d === 4 && B(t, null);
}
function Et(e, t, n) {
	for (let r of pe) if (!Be(e, "both", r)) {
		t.slots[n] = {
			kind: "both",
			action: r
		};
		return;
	}
	for (let r of pe) if (!Be(e, "top", r)) {
		t.slots[n] = {
			kind: "top",
			action: r
		};
		return;
	}
	t.slots[n] = { kind: "parks" };
}
function Dt(e) {
	e.parksDisplay.length > 0 && (V(e, e.parkBonus[e.parkBonus.length - 1] ?? null), Qe(e, e.parksDisplay.length - 1, "parks")), e.consDisplay.length > 0 && (V(e, e.consBonus[e.consBonus.length - 1] ?? null), Qe(e, e.consDisplay.length - 1, "cons"));
}
function Ot(e, t) {
	let n = e.greta;
	if (!n) return;
	let r = +(t === 1), i = n.colors >= 2 ? [r, 1 - r] : [0];
	for (let t of i) (n.hikers[t * 2] < 8 || n.hikers[t * 2 + 1] < 8) && Tt(e, n, t);
}
function kt(e, t, n, r, i) {
	if (r < 1 || r > 8) return P("badTarget");
	if (t.hikers[n] >= 8) return P("badHiker");
	if (r !== 8 && r <= t.hikers[n]) return P("badTarget");
	if (r === 8) return i.slot ? i.slot.kind !== "parks" && Be(e, i.slot.kind, i.slot.action) ? P("full") : (t.hikers[n] = 8, t.slots[n] = i.slot, e.moved = !0, e.end = i.slot.kind === "parks" ? {
		action: null,
		topDone: !0,
		parksDone: !1
	} : {
		action: i.slot.action,
		topDone: !1,
		parksDone: i.slot.kind === "top"
	}, null) : P("badSlot");
	let a = r - 1;
	if (Ke(e, r) > 0) {
		if (i.campfire === "card") {
			let n = i.card ? t.wonderHand.indexOf(i.card) : -1;
			if (n < 0 || !k[i.card]) return P("noCampfire");
			e.wonderDiscard.push(t.wonderHand.splice(n, 1)[0]);
		} else {
			let t = e.campfires.indexOf(r);
			if (t < 0) return P("occupied");
			e.campfires.splice(t, 1);
		}
	}
	return t.hikers[n] = r, e.moved = !0, e.landingSite = r, e.siteDone = !1, e.consUsed = [], qe(e, t, a), r === 4 && B(e, e.turn), null;
}
function At(e, t, n) {
	switch (n) {
		case "conservation":
			U(e, {
				t: "cons",
				free: !1
			});
			break;
		case "carabiner":
			Ie(e, t, 1);
			break;
		case "mug":
			U(e, { t: "mug" });
			break;
		case "chalet": Ue(e, t);
	}
}
function jt(e, t, n, r) {
	if (r === "display") {
		let r = e.parksDisplay.indexOf(n);
		if (r < 0) return P("badPark");
		$e(e, t, r);
	} else if (r === "reserve") {
		let e = t.reserved.indexOf(n);
		if (e < 0) return P("badPark");
		t.reserved.splice(e, 1);
	} else {
		if (e.parksDeck.length === 0) return P("badPark");
		n = e.parksDeck.shift();
	}
	J(e, t, n);
	let i = S[n];
	return i.instant && K(e, t, i.instant), null;
}
function Mt(e, t) {
	if (e.landingSite === null || e.vfUsed) return P("noVf");
	if (t.carabiners < 1) return P("noCarabiner");
	let n = e.vf[e.landingSite - 1];
	if (!n) return P("noVf");
	switch (--t.carabiners, e.supply.carabiner += 1, e.vfUsed = !0, Fe(e, t, 1), n) {
		case "wonder":
			z(e, t, 1);
			break;
		case "sunwater":
			L(e, t, "sun", 1), L(e, t, "water", 1);
			break;
		case "photo":
			R(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			L(e, t, "wildlife", 1);
			break;
		case "conservation":
			U(e, {
				t: "cons",
				free: !1
			});
			break;
		case "mug": U(e, { t: "mug" });
	}
	return null;
}
function Nt(e, t) {
	let n = t.mug;
	if (t.mug = 0, n === 1) U(e, { t: "mug1" });
	else if (n === 2) for (let n = 0; n < 3; n++) Ve(e, t);
	else n >= 3 && U(e, { t: "freePark" });
}
function Pt(e, t, n, r) {
	if (k[n]) return P("badWonder");
	let i = ae[n];
	if (!i) return P("badWonder");
	let a = t.wonderHand.indexOf(n);
	if (a < 0) return P("badWonder");
	let o = r === "top" ? i.top : i.bottom;
	if (o.pay && !H(e, t, o.pay)) return P("noRes");
	t.wonderHand.splice(a, 1), e.wonderDiscard.push(n);
	for (let n of o.grants) W(e, t, n);
	return null;
}
function Ft(e, t) {
	if (t.wonderHand.length > 3) for (let n = 0; n < t.wonderHand.length - 3; n++) U(e, { t: "discardWonder" });
	t.carabiners > 3 && (e.supply.carabiner += t.carabiners - 3, t.carabiners = 3);
	let n = Le(t) - 12, r = Pe.reduce((e, n) => e + t.res[n], 0), i = Math.min(Math.max(0, n), r);
	for (let t = 0; t < i; t++) U(e, { t: "discardRes" });
	return e.tasks.length === 0;
}
function It(e) {
	if (Y(e), [...e.order].every((t) => e.players[t].hikers.every((e) => e === 8)) && (!e.greta || e.greta.hikers.every((e) => e === 8))) {
		mt(e);
		return;
	}
	lt(e);
}
function Lt(e, t, n) {
	let r = e;
	if (r.phase === "ended" || r.turn === null) return P("phase");
	if (n.by !== r.turn) return P("notTurn");
	let i = r.players[n.by];
	if (!i) return P("notPlayer");
	if (r.phase === "scoring") return t.type === "campfireEnd" ? Ct(r, n.by, t) ?? { state: r } : t.type === "scoringDone" ? (r.scoringIdx += 1, r.scoringIdx >= r.order.length ? wt(r) : (r.turn = r.order[r.scoringIdx], r.turnIdx = r.scoringIdx), { state: r }) : P("badAction");
	if (r.gretaPending) {
		if (t.type !== "gretaColor") return P("badAction");
		let e = r.greta;
		return !e || !e.solo ? P("badAction") : (r.gretaPending = !1, Ot(r, t.first), Y(r), lt(r), { state: r });
	}
	let a = r.tasks.length > 0 ? r.tasks[r.tasks.length - 1] : null;
	if (t.type === "playWonder") return Pt(r, i, t.card, t.side) ?? { state: r };
	if (t.type === "endTurn") return r.moved ? a ? P("badAction") : r.end && (!r.end.topDone || !r.end.parksDone) ? P("endIncomplete") : (Ft(r, i) && It(r), { state: r }) : P("mustMove");
	if (!a) {
		if (t.type === "siteAction") return !r.moved || r.landingSite === null || r.siteDone ? P("badAction") : (r.siteDone = !0, Je(r, i, r.trailSites[r.landingSite - 1]), { state: r });
		if (t.type === "activateCons") return !r.moved || r.landingSite === null ? P("noConsSite") : Ye(r, i, t.card) ?? { state: r };
		if (t.type === "endTop") return !r.end || r.end.topDone || !r.end.action ? P("badAction") : (r.end.topDone = !0, At(r, i, r.end.action), { state: r });
		if (t.type === "endParks") return !r.end || r.end.parksDone ? P("badAction") : (r.end.parksDone = !0, U(r, {
			t: "parks",
			visited: !1
		}), { state: r });
	}
	if (a) {
		if (a.t === "parks") {
			if (t.type === "reserve") {
				if (a.visited) return P("badAction");
				if (t.from === "display") {
					if (t.index === void 0 || t.index < 0 || t.index >= r.parksDisplay.length) return P("badPark");
					i.reserved.push(r.parksDisplay[t.index]), $e(r, i, t.index);
				} else {
					if (r.parksDeck.length === 0) return P("badPark");
					i.reserved.push(r.parksDeck.shift());
				}
				return r.tasks.pop(), { state: r };
			}
			return t.type === "visit" ? et(r, i, t.parkId) ? (a.visited = !0, { state: r }) : P("badPark") : t.type === "parksDone" ? (r.tasks.pop(), { state: r }) : P("badAction");
		}
		if (a.t === "mug") {
			if (t.type !== "mug") return P("badAction");
			if (t.act === "fill") i.mug = Math.min(3, i.mug + 1);
			else {
				if (i.mug < 1) return P("badAction");
				Nt(r, i);
			}
			return r.tasks.pop(), { state: r };
		}
		if (a.t === "mug1") return t.type === "mugChoice" ? (r.tasks.pop(), t.choice === "chalet" ? Ue(r, i) : U(r, {
			t: "cons",
			free: !0
		}), { state: r }) : P("badAction");
		if (a.t === "cons") return t.type === "consPick" ? tt(r, i, t.index, t.deck === !0, a.free) || (r.tasks.pop(), { state: r }) : t.type === "skip" ? (r.tasks.pop(), { state: r }) : P("badAction");
		if (a.t === "assignWild") {
			if (t.type !== "assignWild") return P("badAction");
			if (!a.suits.includes(t.suit)) return P("badSuit");
			let e = i.visited.find((e) => e.id === a.parkId && e.suit === null);
			return e ? (e.suit = t.suit, r.tasks.pop(), Ze(r, i), { state: r }) : P("badPark");
		}
		if (a.t === "freePark") return t.type === "freePark" ? jt(r, i, t.parkId ?? 0, t.from) || (r.tasks.pop(), { state: r }) : P("badAction");
		if (a.t === "discardRes") return t.type !== "discardRes" || i.res[t.res] <= 0 ? P("badAction") : (--i.res[t.res], r.supply[t.res] += 1, r.tasks.pop(), { state: r });
		if (a.t === "discardWonder") {
			if (t.type !== "discardWonder") return P("badAction");
			let e = i.wonderHand.indexOf(t.card);
			return e < 0 ? P("badWonder") : (r.wonderDiscard.push(i.wonderHand.splice(e, 1)[0]), r.tasks.pop(), { state: r });
		}
		return P("badAction");
	}
	return t.type === "viaFerrata" ? r.moved ? Mt(r, i) ?? { state: r } : P("mustMove") : t.type === "move" ? r.moved ? P("alreadyMoved") : t.to !== 8 && st(r, n.by) ? P("mustEnd") : kt(r, i, t.hiker, t.to, t) || { state: r } : P("badAction");
}
function Rt(e) {
	if (e.phase === "ended") return "none";
	if (e.phase === "scoring") return "scoring";
	if (e.gretaPending) return "gretaColor";
	if (!e.moved) return e.turn !== null && st(e, e.turn) ? "trailEnd" : "move";
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t ? t.t === "parks" ? "parks" : t.t === "mug" ? "mug" : t.t === "mug1" ? "mugChoice" : t.t === "cons" ? "cons" : t.t === "assignWild" ? "assignWild" : t.t === "freePark" ? "freePark" : t.t === "discardWonder" ? "discardWonder" : "discardRes" : "actions";
}
function zt(e) {
	let t = (e) => e.some((e) => e !== null && e.kind === "parks");
	for (let n of e.order) if (t(e.players[n].slots)) return !0;
	return !!e.greta && t(e.greta.slots);
}
function Bt(e) {
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t !== null && t.t === "cons" && t.free;
}
function Vt(e, t) {
	let n = { ...e.res };
	return {
		rid: t,
		seat: e.seat,
		res: n,
		snow: e.snow,
		carabiners: e.carabiners,
		mug: e.mug,
		photos: e.photos,
		albums: e.albums,
		photosTaken: e.photosTaken,
		visited: e.visited.map((e) => ({
			id: e.id,
			suit: e.suit
		})),
		reserved: [...e.reserved],
		cons: [...e.cons],
		parkAwards: { ...e.parkAwards },
		consAwards: e.consAwards,
		chaletAwards: [...e.chaletAwards],
		wonderCount: e.wonderHand.length,
		shutterbug: e.shutterbug,
		chaletPos: e.chaletPos,
		chaletOrder: e.chaletOrder,
		hikers: [...e.hikers],
		atEnd: e.hikers.every((e) => e === 8),
		endUsed: [...e.endUsed],
		endPoints: e.endPoints
	};
}
function Ht(e) {
	let t = (t, n) => {
		for (let r of e.order) if (e.players[r].slots.find((e) => e !== null && e.kind === t && e.action === n)) return r;
		return e.greta && e.greta.slots.some((e) => e !== null && e.kind === t && e.action === n) ? "$greta" : null;
	}, n = [];
	for (let e of pe) n.push({
		kind: "top",
		action: e,
		rid: t("top", e)
	}), n.push({
		kind: "both",
		action: e,
		rid: t("both", e)
	});
	return n;
}
var Ut = {
	meta: ge,
	saveCompatibility: { version: "2" },
	schemas: {
		action: Ee,
		publicView: Me,
		privateView: Ne,
		config: De
	},
	setup(e, t, n) {
		let r = De.parse(e ?? {}), i = t.length === 1, a = i || t.length === 2 && r.greta, o = [...t], s = 0, c = F(Array.from({ length: 48 }, (e, t) => t), n, s);
		s = c.cursor;
		let l = c.items.slice(), u = l.splice(0, 3), d = F(Array.from({ length: 28 }, (e, t) => t), n, s);
		s = d.cursor;
		let f = d.items.slice(), p = f.splice(0, 3), m = F([...D.map((e) => e.id), ...O.map((e) => e.id)], n, s);
		s = m.cursor;
		let h = m.items, g = F(Array.from({ length: A.length }, (e, t) => t), n, s);
		s = g.cursor;
		let _ = g.items.slice(0, 3), v = F(se.slice(), n, s);
		s = v.cursor;
		let y = [
			v.items.slice(0, 3),
			v.items.slice(3, 6),
			v.items.slice(6, 9)
		], b = F(ue.slice(), n, s);
		s = b.cursor;
		let x = [], ee = 0;
		for (let e = 0; e < 7; e++) x.push(e === 3 ? null : b.items[ee++]);
		let S = F(o.slice(), n, s);
		s = S.cursor;
		let C = {};
		o.forEach((e, t) => {
			let n = h.pop(), r = S.items.indexOf(e);
			C[e] = I(t, n, r);
		});
		let te = o.length >= 4 ? 2 : 1, w = {
			phase: "turn",
			season: 1,
			order: o,
			players: C,
			turnIdx: 0,
			turn: null,
			moved: !1,
			landingSite: null,
			siteDone: !1,
			consUsed: [],
			vfUsed: !1,
			end: null,
			tasks: [],
			gretaPending: !1,
			scoringIdx: 0,
			campfireUsed: [],
			trailSites: [],
			trailBonus: [
				null,
				null,
				null,
				null,
				null,
				null,
				null
			],
			campfires: [],
			vf: x,
			seasonAdvanced: y,
			seasonQueue: _,
			parkBonus: [
				null,
				null,
				null
			],
			consBonus: [
				null,
				null,
				null
			],
			parksDeck: l,
			parksDisplay: u,
			consDeck: f,
			consDisplay: p,
			parkAwardPool: {
				lime: te,
				orange: te,
				teal: te,
				purple: te
			},
			consAwardsLeft: 5,
			chaletStacks: [[
				3,
				4,
				5
			], [
				3,
				4,
				5
			]],
			chaletClaimed: de.map(() => !1),
			supply: {
				...me,
				carabiner: 15
			},
			wonderDeck: h,
			wonderDiscard: [],
			greta: a ? {
				solo: i,
				colors: i ? 2 : 1,
				hikers: Array(i ? 4 : 2).fill(0),
				slots: Array(i ? 4 : 2).fill(null)
			} : null,
			parkAwardsPerSuit: te,
			solo: i,
			seed: n,
			cursor: s,
			chaletSeq: o.length,
			final: null
		};
		return pt(w), ut(w, dt(w)), { state: w };
	},
	reduce: Lt,
	viewFor(e, t) {
		let n = e, r = n.order.map((e) => Vt(n.players[e], e)), i = {
			phase: n.phase,
			season: n.season,
			turn: n.turn,
			moved: n.moved,
			pending: Rt(n),
			freeCons: Bt(n),
			landingSite: n.landingSite,
			siteDone: n.siteDone,
			consUsed: [...n.consUsed],
			vfUsed: n.vfUsed,
			end: n.end ? {
				action: n.end.action,
				topDone: n.end.topDone,
				parksDone: n.end.parksDone
			} : null,
			seasonCard: A[n.seasonQueue[n.season - 1]].id,
			order: n.order,
			players: r,
			trailSites: n.trailSites,
			trailBonus: n.trailBonus,
			campfires: n.campfires,
			vf: n.vf,
			parksDisplay: n.parksDisplay,
			parksDeck: n.parksDeck.length,
			parksBonus: n.parkBonus,
			consDisplay: n.consDisplay,
			consDeck: n.consDeck.length,
			consBonus: n.consBonus,
			consAwardsLeft: n.consAwardsLeft,
			chaletStacks: n.chaletStacks.map((e) => [...e]),
			endSlots: Ht(n),
			parksEndOccupied: zt(n),
			greta: n.greta ? {
				hikers: [...n.greta.hikers],
				atEnd: n.greta.hikers.every((e) => e === 8),
				solo: n.greta.solo
			} : null,
			soloRanks: n.solo ? he.map((e) => ({
				at: e.at,
				rank: e.rank
			})) : null,
			revealedCampfire: n.phase === "scoring" || n.phase === "ended" ? n.order.map((e) => ({
				rid: e,
				cards: n.players[e].wonderHand.filter((e) => !!k[e])
			})) : null,
			campfireUsed: [...n.campfireUsed],
			finalRows: n.final ? n.final.rows.map((e) => ({ ...e })) : null
		}, a = n.players[t];
		return {
			public: i,
			private: {
				hand: a ? [...a.wonderHand] : [],
				isTurn: n.turn === t
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	}
}, Wt = /* @__PURE__ */ "games.parkseurope.parkNames.p0,games.parkseurope.parkNames.p1,games.parkseurope.parkNames.p2,games.parkseurope.parkNames.p3,games.parkseurope.parkNames.p4,games.parkseurope.parkNames.p5,games.parkseurope.parkNames.p6,games.parkseurope.parkNames.p7,games.parkseurope.parkNames.p8,games.parkseurope.parkNames.p9,games.parkseurope.parkNames.p10,games.parkseurope.parkNames.p11,games.parkseurope.parkNames.p12,games.parkseurope.parkNames.p13,games.parkseurope.parkNames.p14,games.parkseurope.parkNames.p15,games.parkseurope.parkNames.p16,games.parkseurope.parkNames.p17,games.parkseurope.parkNames.p18,games.parkseurope.parkNames.p19,games.parkseurope.parkNames.p20,games.parkseurope.parkNames.p21,games.parkseurope.parkNames.p22,games.parkseurope.parkNames.p23,games.parkseurope.parkNames.p24,games.parkseurope.parkNames.p25,games.parkseurope.parkNames.p26,games.parkseurope.parkNames.p27,games.parkseurope.parkNames.p28,games.parkseurope.parkNames.p29,games.parkseurope.parkNames.p30,games.parkseurope.parkNames.p31,games.parkseurope.parkNames.p32,games.parkseurope.parkNames.p33,games.parkseurope.parkNames.p34,games.parkseurope.parkNames.p35,games.parkseurope.parkNames.p36,games.parkseurope.parkNames.p37,games.parkseurope.parkNames.p38,games.parkseurope.parkNames.p39,games.parkseurope.parkNames.p40,games.parkseurope.parkNames.p41,games.parkseurope.parkNames.p42,games.parkseurope.parkNames.p43,games.parkseurope.parkNames.p44,games.parkseurope.parkNames.p45,games.parkseurope.parkNames.p46,games.parkseurope.parkNames.p47".split(","), Gt = {
	b01: "games.parkseurope.wonderNames.b01",
	b02: "games.parkseurope.wonderNames.b02",
	b03: "games.parkseurope.wonderNames.b03",
	b04: "games.parkseurope.wonderNames.b04",
	b05: "games.parkseurope.wonderNames.b05",
	b06: "games.parkseurope.wonderNames.b06",
	b07: "games.parkseurope.wonderNames.b07",
	b08: "games.parkseurope.wonderNames.b08",
	b09: "games.parkseurope.wonderNames.b09",
	b10: "games.parkseurope.wonderNames.b10",
	b11: "games.parkseurope.wonderNames.b11",
	b12: "games.parkseurope.wonderNames.b12",
	b13: "games.parkseurope.wonderNames.b13",
	b14: "games.parkseurope.wonderNames.b14",
	b16: "games.parkseurope.wonderNames.b16",
	b17: "games.parkseurope.wonderNames.b17",
	b18: "games.parkseurope.wonderNames.b18",
	b19: "games.parkseurope.wonderNames.b19",
	b20: "games.parkseurope.wonderNames.b20",
	b21: "games.parkseurope.wonderNames.b21"
};
function Kt(e, t) {
	return e(Wt[t]);
}
function qt(e, t) {
	let n = k[t];
	return n ? e("games.parkseurope.campfireCardName", { n: String(n.no).padStart(2, "0") }) : e(Gt[t] ?? "games.parkseurope.siteShort.wonder");
}
//#endregion
//#region src/game/field-components.tsx
var Jt = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any",
	carabiner: "games.parkseurope.token.carabiner",
	photo: "games.parkseurope.token.photo",
	mug: "games.parkseurope.siteShort.mug",
	wonder: "games.parkseurope.siteShort.wonder",
	die: "games.parkseurope.siteShort.die",
	chalet: "games.parkseurope.siteShort.chalet",
	parks: "games.parkseurope.siteShort.parks",
	cons: "games.parkseurope.consTitle",
	campfire: "games.parkseurope.campfireLabel",
	award: "games.parkseurope.fieldAward"
};
function Z({ kind: e }) {
	return e === "campfire" ? null : /* @__PURE__ */ _("img", {
		className: "pke-mark",
		"data-kind": e,
		src: h("games/parkseurope/marks/" + (e === "cons" ? "conservation" : e) + ".webp"),
		alt: "",
		"aria-hidden": !0
	});
}
function Q({ kind: e, count: t }) {
	let n = l()(Jt[e]);
	return /* @__PURE__ */ v("span", {
		className: "pke-piece",
		"data-kind": e,
		role: "img",
		title: n,
		"aria-label": t === void 0 ? n : `${n} ×${t}`,
		children: [e === "campfire" ? n : /* @__PURE__ */ _(Z, { kind: e }), t !== void 0 && /* @__PURE__ */ _("b", { children: t })]
	});
}
var Yt = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"any"
];
function Xt({ cost: e, free: t = !1 }) {
	let n = l(), r = Yt.filter((t) => (e[t] ?? 0) > 0);
	return /* @__PURE__ */ _("span", {
		className: "pke-cost-tokens",
		children: t || r.length === 0 ? n("games.parkseurope.free") : r.map((t) => /* @__PURE__ */ _(Q, {
			kind: t,
			count: e[t]
		}, t))
	});
}
function Zt({ park: e, suitLabel: t, effect: n, bonus: r, picked: i, free: a, onPick: o }) {
	let s = l();
	return /* @__PURE__ */ v(o ? "button" : "article", {
		type: o ? "button" : void 0,
		className: "pke-park-face",
		"data-suit": e.suit,
		"aria-pressed": o ? i : void 0,
		onClick: o,
		children: [/* @__PURE__ */ v("span", {
			className: "pke-park-art",
			children: [/* @__PURE__ */ _("img", {
				loading: "lazy",
				decoding: "async",
				src: h(`games/parkseurope/parks/${e.id}.webp`),
				alt: ""
			}), /* @__PURE__ */ _("b", {
				className: "pke-park-score",
				children: s("games.parkseurope.points", { n: e.points })
			})]
		}), /* @__PURE__ */ v("span", {
			className: "pke-park-info",
			children: [
				/* @__PURE__ */ _("strong", {
					className: "pke-park-name",
					children: Kt(s, e.id)
				}),
				/* @__PURE__ */ v("span", {
					className: "pke-park-suit",
					children: [/* @__PURE__ */ _("i", { "aria-hidden": !0 }), t]
				}),
				/* @__PURE__ */ _(Xt, {
					cost: e.cost,
					free: a
				}),
				/* @__PURE__ */ v("span", {
					className: "pke-park-effect",
					children: [e.instant && n && /* @__PURE__ */ v("span", {
						className: "pke-effect-line",
						children: [/* @__PURE__ */ _(Z, { kind: e.instant }), /* @__PURE__ */ _("span", { children: n })]
					}), r && /* @__PURE__ */ v("span", {
						className: "pke-effect-line",
						children: [
							/* @__PURE__ */ _("b", {
								"aria-hidden": "true",
								children: "+"
							}),
							/* @__PURE__ */ _(Q, { kind: r }),
							/* @__PURE__ */ _("span", { children: s("games.parkseurope.displayBonus") })
						]
					})]
				})
			]
		})]
	});
}
function Qt({ player: e }) {
	let t = l(), n = r(), [i, a] = o(null), s = i === "snow" ? e.snow : i === "carabiner" ? e.carabiners : i ? e.res[i] : 0, c = i === "snow" || i === "wildlife" || i === "carabiner" ? i : "regular", u = (e) => a(i === e ? null : e), d = [];
	for (let t = 0; t < e.snow; t++) d.push({
		kind: "snow",
		index: t
	});
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]) for (let n = 0; n < e.res[t]; n++) d.push({
		kind: t,
		index: n
	});
	let f = d.length + e.snow;
	return /* @__PURE__ */ v("div", {
		className: "pke-res-mat",
		children: [
			/* @__PURE__ */ v("div", {
				className: "pke-mat-capacity",
				children: [/* @__PURE__ */ _("b", { children: t("games.parkseurope.packSlots") }), /* @__PURE__ */ _("output", { children: t("games.parkseurope.packUsage", { used: f }) })]
			}),
			/* @__PURE__ */ v("div", {
				className: "pke-mat-sockets",
				"aria-label": t("games.parkseurope.packUsage", { used: f }),
				children: [d.map(({ kind: e, index: r }) => /* @__PURE__ */ _("button", {
					type: "button",
					className: "pke-mat-socket",
					"data-kind": e,
					"aria-label": t(Jt[e]),
					"aria-expanded": i === e && s > 0,
					"aria-controls": n,
					onClick: () => u(e),
					children: /* @__PURE__ */ _(Q, { kind: e })
				}, `${e}:${r}`)), Array.from({ length: Math.max(0, 12 - f) }, (e, t) => /* @__PURE__ */ _("div", {
					className: "pke-mat-socket",
					"aria-hidden": "true"
				}, `empty:${t}`))]
			}),
			/* @__PURE__ */ v("div", {
				className: "pke-gear",
				children: [/* @__PURE__ */ _("span", { children: t("games.parkseurope.token.carabiner") }), /* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": t(Jt.carabiner),
					"aria-expanded": i === "carabiner",
					"aria-controls": n,
					onClick: () => u("carabiner"),
					children: /* @__PURE__ */ _(Q, {
						kind: "carabiner",
						count: e.carabiners
					})
				})]
			}),
			/* @__PURE__ */ _("div", {
				id: n,
				className: "pke-resource-detail",
				hidden: !i || i !== "carabiner" && s === 0,
				children: i && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", { children: [
					/* @__PURE__ */ _(Z, { kind: i }),
					/* @__PURE__ */ _("strong", { children: t(Jt[i]) }),
					/* @__PURE__ */ _("span", { children: t("games.parkseurope.fieldResourceCount", { n: s }) }),
					/* @__PURE__ */ _("span", { children: t("games.parkseurope.fieldResourceSlots", { n: i === "snow" ? 2 : i === "carabiner" ? 0 : 1 }) })
				] }), /* @__PURE__ */ _("p", { children: t(`games.parkseurope.fieldResourceUse.${c}`) })] })
			})
		]
	});
}
//#endregion
//#region src/game/field-objects.tsx
var $t = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
}, en = (e) => h(`games/parkseurope/objects/${e}.webp`);
function $({ award: e, reveal: t = !1 }) {
	let n = l(), r = e.kind, i = r === "parks" ? e.suit : r === "cons" ? "conservation" : "photo", a = r === "chalet" ? e.points : r === "cons" ? 5 : r === "photo" ? 3 : 1, o = r === "parks" ? n("games.parkseurope.fx.parkAward", {
		suit: n($t[e.suit]),
		count: e.count
	}) : r === "cons" ? n("games.parkseurope.consAwardsLabel", { n: e.count }) : r === "chalet" ? n("games.parkseurope.fx.chaletAward", { points: a }) : n("games.parkseurope.resultPhotoAward");
	return /* @__PURE__ */ v("span", {
		className: "pke-award-piece",
		"data-kind": r,
		"data-suit": r === "parks" ? e.suit : void 0,
		"data-reveal": t,
		role: "img",
		"aria-label": o,
		title: o,
		children: [
			r !== "chalet" && /* @__PURE__ */ _("img", {
				className: "pke-award-illustration",
				src: en("award-" + i),
				alt: ""
			}),
			(r === "chalet" || r === "photo" || r === "parks" && t) && /* @__PURE__ */ _("b", {
				className: "pke-award-score",
				children: a
			}),
			"count" in e && e.count > 1 && /* @__PURE__ */ v("b", {
				className: "pke-award-count",
				children: ["×", e.count]
			})
		]
	});
}
function tn({ player: e }) {
	let t = l(), n = [...C.map((n) => [
		{
			kind: "parks",
			suit: n,
			count: e.parkAwards[n]
		},
		t($t[n]),
		t("games.parkseurope.awardParkDetail", { benefit: t(Jt[te[n]]) })
	]), [
		{
			kind: "cons",
			count: e.consAwards
		},
		t("games.parkseurope.fieldProjects"),
		t("games.parkseurope.awardFixedDetail", { n: 5 })
	]], r = e.chaletAwards.map((e) => [
		{
			kind: "chalet",
			points: e
		},
		t("games.parkseurope.fieldChalet"),
		t("games.parkseurope.awardFixedDetail", { n: e })
	]);
	return /* @__PURE__ */ v("div", {
		className: "pke-award-tray",
		children: [/* @__PURE__ */ _("h3", { children: t("games.parkseurope.fieldHonors") }), /* @__PURE__ */ _("ul", { children: [...n, ...r].map(([e, t, n], r) => {
			let i = !("count" in e) || e.count > 0;
			return /* @__PURE__ */ v("li", {
				className: "pke-award-well",
				"data-owned": i,
				"data-kind": e.kind,
				"data-suit": e.kind === "parks" ? e.suit : void 0,
				children: [
					/* @__PURE__ */ _("span", {
						className: "pke-award-recess",
						children: i ? /* @__PURE__ */ _($, { award: e }) : /* @__PURE__ */ _("i", { "aria-hidden": !0 })
					}),
					/* @__PURE__ */ _("strong", {
						title: i ? n : void 0,
						children: t
					}),
					i && /* @__PURE__ */ _("span", {
						className: "pke-award-explanation",
						children: n
					})
				]
			}, r);
		}) })]
	});
}
function nn() {
	return /* @__PURE__ */ _("img", {
		className: "pke-album-art",
		src: en("award-album"),
		alt: "",
		"aria-hidden": !0
	});
}
var rn = {
	snow: "snow",
	carabiner: "carabiner",
	photo: "photo",
	wonder: "wonder",
	die: "die",
	parks: "parks",
	mug: "mug",
	cons: "cons",
	chalet: "chalet"
};
function an({ grants: e }) {
	let t = l();
	return /* @__PURE__ */ _("span", {
		className: "pke-wonder-grants",
		children: e.map((e, n) => {
			if (e.t === "shutterbug") return /* @__PURE__ */ _("img", {
				className: "pke-shutterbug-art",
				src: en("award-shutterbug"),
				alt: t("games.parkseurope.shutterbug")
			}, n);
			let r = e.t === "res" ? e.res : rn[e.t], i = "n" in e && e.n > 1 ? e.n : void 0;
			return /* @__PURE__ */ _(Q, {
				kind: r,
				count: i
			}, n);
		})
	});
}
function on({ face: e, side: t, used: n, enabled: r, onPlay: i, titleId: a, waiting: o }) {
	let s = l(), c = i ? "button" : "div", u = e.pay && Object.values(e.pay).some(Boolean), d = s(t === "top" ? "games.parkseurope.wonder.top" : "games.parkseurope.wonder.bottom"), f = a + "-" + t, p = f + "-status";
	return /* @__PURE__ */ v(c, {
		className: "pke-wonder-action",
		"data-side": t,
		"data-used": n,
		"aria-labelledby": i ? a + " " + f : void 0,
		"aria-describedby": i && !r ? p : void 0,
		type: i ? "button" : void 0,
		disabled: i ? !r : void 0,
		onClick: i ? () => i(t) : void 0,
		children: [/* @__PURE__ */ v("span", {
			id: f,
			className: "pke-wonder-command",
			children: [
				/* @__PURE__ */ v("b", {
					className: "sr-only",
					children: [d, " "]
				}),
				u && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(Xt, { cost: e.pay ?? {} }), /* @__PURE__ */ _("span", {
					className: "pke-wonder-arrow",
					"aria-hidden": !0,
					children: "›"
				})] }),
				/* @__PURE__ */ _(an, { grants: e.grants })
			]
		}), i && /* @__PURE__ */ _("span", {
			id: p,
			className: "pke-wonder-play",
			children: s(o ? "games.parkseurope.wonderWait" : r ? "games.parkseurope.wonderPlay" : "games.parkseurope.cannotAfford")
		})]
	});
}
function sn({ id: e, used: t, campEffect: n, canUse: i, onPlay: a, waiting: o }) {
	let s = l(), c = r(), u = ae[e];
	if (!u && !k[e]) return null;
	let d = qt(s, e);
	if (!u) return /* @__PURE__ */ v("article", {
		className: "pke-wonder pke-wonder-face pke-wonder-campfire",
		children: [
			/* @__PURE__ */ _("img", {
				src: en("campfire"),
				alt: ""
			}),
			/* @__PURE__ */ _("header", { children: /* @__PURE__ */ _("b", { children: d }) }),
			/* @__PURE__ */ _("span", {
				className: "pke-campfire-use",
				children: s("games.parkseurope.wonderShare")
			}),
			n && /* @__PURE__ */ v("div", {
				className: "pke-campfire-score",
				children: [/* @__PURE__ */ _("strong", { children: s("games.parkseurope.wonderScore") }), /* @__PURE__ */ _("p", { children: n })]
			})
		]
	});
	let f = `url("${en("wonder-" + String(u.no).padStart(2, "0"))}")`;
	return /* @__PURE__ */ v("article", {
		className: "pke-wonder pke-wonder-face",
		style: { "--pke-wonder-art": f },
		children: [
			/* @__PURE__ */ _(on, {
				face: u.top,
				side: "top",
				titleId: c,
				used: t === "top",
				enabled: !o && (i?.("top") ?? !0),
				waiting: o,
				onPlay: a
			}),
			/* @__PURE__ */ _("header", { children: /* @__PURE__ */ _("b", {
				id: c,
				children: d
			}) }),
			/* @__PURE__ */ _(on, {
				face: u.bottom,
				side: "bottom",
				titleId: c,
				used: t === "bottom",
				enabled: !o && (i?.("bottom") ?? !0),
				waiting: o,
				onPlay: a
			})
		]
	});
}
var cn = {
	sun: [
		"#f3ca64",
		"#8d5d20",
		"#fff0b8"
	],
	mountain: [
		"#f0a4ab",
		"#8d344f",
		"#ffdde0"
	],
	water: [
		"#a8dded",
		"#20608a",
		"#d5f4fb"
	],
	forest: [
		"#b9d87c",
		"#385e39",
		"#e4f1bd"
	]
};
function ln({ id: e, name: t, site: n, benefit: r, bonus: i, supported: a, free: o, action: s }) {
	let c = l(), u = T(e), [d, f, p] = cn[u];
	return /* @__PURE__ */ v("article", {
		className: "pke-project-face",
		"data-supported": a,
		style: {
			"--stock": d,
			"--mark-ink": f,
			"--paper": p
		},
		children: [
			/* @__PURE__ */ v("div", {
				className: "pke-project-plate",
				children: [/* @__PURE__ */ _(Z, { kind: u }), /* @__PURE__ */ _(Z, { kind: "cons" })]
			}),
			/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("strong", { children: t }), /* @__PURE__ */ _("span", { children: n })] }),
			/* @__PURE__ */ v("div", {
				className: "pke-project-reward",
				children: [/* @__PURE__ */ _(Q, { kind: re[e % 7].benefit }), /* @__PURE__ */ _("span", { children: r })]
			}),
			/* @__PURE__ */ v("div", {
				className: "pke-project-foot",
				children: [a ? /* @__PURE__ */ _("span", { children: c("games.parkseurope.fieldSupported") }) : /* @__PURE__ */ _(Xt, {
					cost: ne[u],
					free: o
				}), i && /* @__PURE__ */ v("span", {
					"aria-label": c("games.parkseurope.displayBonus"),
					children: ["+ ", /* @__PURE__ */ _(Q, { kind: i })]
				})]
			}),
			s && /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: s.disabled,
				onClick: s.onPress,
				children: s.label
			})
		]
	});
}
//#endregion
//#region src/game/field-motion.tsx
var un = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
};
function dn(e, t, n) {
	let r = n && ve(e.res, n), i = _e.map((n) => ({
		kind: n,
		count: t.res[n] - e.res[n] + (r?.[n] ?? 0)
	}));
	return i.push({
		kind: "snow",
		count: t.snow - e.snow
	}, {
		kind: "carabiner",
		count: t.carabiners - e.carabiners
	}), i.filter(({ count: e }) => e > 0);
}
function fn(e, t) {
	let n = [];
	for (let r of C) {
		let i = t.parkAwards[r] - e.parkAwards[r];
		i > 0 && n.push({
			kind: "parks",
			suit: r,
			count: i
		});
	}
	t.consAwards > e.consAwards && n.push({
		kind: "cons",
		count: t.consAwards - e.consAwards
	});
	for (let r of t.chaletAwards.slice(e.chaletAwards.length)) n.push({
		kind: "chalet",
		points: r
	});
	return n;
}
function pn(e, t) {
	return t.season < e.season || t.season - e.season > 1 ? !1 : e.players.every((e) => {
		let n = t.players.find(({ rid: t }) => t === e.rid);
		return !!n && n.photosTaken >= e.photosTaken && n.chaletPos >= e.chaletPos && e.visited.every(({ id: e }, t) => n.visited[t]?.id === e) && e.cons.every((e, t) => n.cons[t] === e);
	});
}
function mn(e, t) {
	if (!t) return;
	let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
	if (!(r.width === 0 || r.height === 0 || r.right <= n.left || r.left >= n.right || r.bottom <= n.top || r.top >= n.bottom)) return {
		point: {
			x: r.left - n.left + r.width / 2,
			y: r.top - n.top + r.height / 2
		},
		width: r.width
	};
}
function hn(e, t, n, r, i) {
	if (e?.type === "campfireEnd" && !r.campfireUsed.includes(e.card) && i.campfireUsed.includes(e.card)) return { id: e.card };
	if ((e?.type === "playWonder" || e?.type === "move" && e.campfire === "card") && e.card && t.includes(e.card) && !n.includes(e.card) && (e.type !== "move" || i.moved)) return {
		id: e.card,
		side: e.type === "playWonder" ? e.side : void 0
	};
}
function gn(e, t, n, r, i) {
	if (t?.side) return ae[t.id]?.[t.side].pay;
	if (e?.type === "visit" && r.visited.length > n.visited.length && r.visited.at(-1)?.id === e.parkId) return S[e.parkId]?.cost;
	if (e?.type !== "consPick" || i.freeCons || r.cons.length <= n.cons.length) return;
	if (e.deck) return {
		sun: 1,
		water: 1
	};
	let a = e.index === void 0 ? void 0 : i.consDisplay[e.index];
	return a === void 0 ? void 0 : ne[T(a)];
}
function _n(e, t, n) {
	let r = e?.card ? 390 : 0, i = e?.gains.length ? 760 : 0, a = e?.awards.some(({ rid: e }) => e === t) ? 1400 : e?.awards.length ? 1120 : 0;
	return n ? {
		gainDelay: 0,
		awardDelay: 0,
		duration: 1400
	} : {
		gainDelay: r,
		awardDelay: r + i,
		duration: r + i + a
	};
}
function vn(e, t, r) {
	let i = a(null), s = a(null), c = a(null), l = a(null), u = a(0), [d, f] = o({
		self: r,
		frames: []
	}), p = y(), m = d.self === r ? d.frames[0] : void 0, h = _n(m, r, p);
	function g(e) {
		let t = e.target instanceof Element ? e.target.closest("button") : null;
		if (!t || !i.current) return;
		s.current = {
			origin: mn(i.current, t),
			card: mn(i.current, t.closest(".pke-wonder, .pke-scoring-card"))
		};
		let n = s.current;
		queueMicrotask(() => {
			s.current === n && (s.current = null);
		});
	}
	function _(t) {
		c.current = {
			scope: e,
			action: t,
			origin: s.current?.origin,
			card: s.current?.card
		};
	}
	return n(() => {
		let n = l.current;
		if (l.current = {
			pub: e,
			hand: t,
			self: r
		}, !n || n.self !== r || !pn(n.pub, e) || e.order.length !== n.pub.order.length || !e.order.every((e) => n.pub.order.includes(e)) || n.pub.phase === "ended" && e.phase !== "ended") {
			c.current = null, queueMicrotask(() => f({
				self: r,
				frames: []
			}));
			return;
		}
		let a = n.pub.players.find(({ rid: e }) => e === r), o = e.players.find(({ rid: e }) => e === r);
		if (!i.current || !a || !o || n.pub === e) return;
		let s = c.current?.scope === n.pub ? c.current : null;
		c.current = null;
		let d = hn(s?.action, n.hand, t, n.pub, e);
		d && (d.origin = s?.card ?? s?.origin);
		let p = dn(a, o, gn(s?.action, d, a, o, n.pub)), m = [];
		for (let t of e.players) {
			let e = n.pub.players.find(({ rid: e }) => e === t.rid);
			if (!e) continue;
			let r = fn(e, t);
			r.length && m.push({
				rid: t.rid,
				awards: r
			});
		}
		if (!d && p.length === 0 && m.length === 0) return;
		let h = mn(i.current, i.current.querySelector(".pke-field-stage")), g = e.landingSite ?? n.pub.landingSite, _ = g === null ? null : i.current.querySelector(`.pke-trail-piece[data-stop="${g}"]`), v = d?.origin?.point ?? mn(i.current, _)?.point ?? s?.origin?.point ?? h?.point, y = mn(i.current, i.current.querySelector("[data-panel=\"pack\"]"))?.point, b = {
			id: ++u.current,
			gains: p,
			awards: m,
			card: d,
			origin: v,
			target: y
		};
		queueMicrotask(() => f((e) => ({
			self: r,
			frames: e.self === r ? [...e.frames, b] : [b]
		})));
	}, [
		e,
		t,
		r
	]), n(() => {
		if (!m) return;
		let e = window.setTimeout(() => {
			f((e) => e.frames[0]?.id === m.id ? {
				...e,
				frames: e.frames.slice(1)
			} : e);
		}, h.duration);
		return () => window.clearTimeout(e);
	}, [m, h.duration]), {
		root: i,
		capture: g,
		record: _,
		active: m,
		timing: h
	};
}
function yn(e, t) {
	return e ? {
		[`--pke-fx-${t}-x`]: `${e.x}px`,
		[`--pke-fx-${t}-y`]: `${e.y}px`
	} : {};
}
function bn({ frame: e, self: t, timing: n, nameOf: r }) {
	let i = l();
	if (!e) return /* @__PURE__ */ _("div", { className: "pke-fx" });
	let a = (e) => e.awards.map((e) => e.kind === "parks" ? i("games.parkseurope.fx.parkAward", {
		suit: i(un[e.suit]),
		count: e.count
	}) : e.kind === "chalet" ? i("games.parkseurope.fx.chaletAward", { points: e.points }) : e.kind === "cons" ? i("games.parkseurope.consAwardsLabel", { n: e.count }) : i("games.parkseurope.resultPhotoAward")), o = e.awards.find(({ rid: e }) => e === t), s = e.awards.filter(({ rid: e }) => e !== t), c = {
		"--pke-gain-delay": `${n.gainDelay}ms`,
		"--pke-award-delay": `${n.awardDelay}ms`
	};
	return /* @__PURE__ */ v("div", {
		className: "pke-fx",
		style: c,
		children: [
			/* @__PURE__ */ v("span", {
				className: "sr-only",
				role: "status",
				children: [
					e.card && i("games.parkseurope.fx.cardUsed", { card: qt(i, e.card.id) }),
					" ",
					e.gains.map(({ kind: e, count: t }) => `+${t} ${i(Jt[e])}`).join(" · "),
					" ",
					e.awards.map((e) => `${r(e.rid)} · ${a(e).join(" · ")}`).join(" · ")
				]
			}),
			e.card && /* @__PURE__ */ _("div", {
				className: "pke-fx-card",
				"aria-hidden": "true",
				"data-card": e.card.id,
				style: {
					...yn(e.card.origin?.point, "from"),
					"--pke-fx-card-width": `${e.card.origin?.width ?? 160}px`
				},
				children: /* @__PURE__ */ _(sn, {
					id: e.card.id,
					used: e.card.side
				})
			}),
			e.gains.length > 0 && /* @__PURE__ */ v("div", {
				className: "pke-fx-gains",
				"aria-hidden": "true",
				style: {
					...yn(e.origin, "from"),
					...yn(e.target, "to")
				},
				children: [e.gains.map(({ kind: e, count: t }, n) => /* @__PURE__ */ _("span", {
					className: "pke-fx-flight",
					style: {
						"--pke-fx-step": n,
						"--pke-fx-rise": `${44 + n * 12}px`
					},
					children: /* @__PURE__ */ _(Q, {
						kind: e,
						count: t
					})
				}, e)), /* @__PURE__ */ _("div", {
					className: "pke-fx-pack-receipt",
					children: e.gains.map(({ kind: e, count: t }) => /* @__PURE__ */ v("span", {
						className: "pke-fx-gain",
						children: [/* @__PURE__ */ _(Q, { kind: e }), /* @__PURE__ */ v("b", { children: ["+", t] })]
					}, e))
				})]
			}),
			o && /* @__PURE__ */ v("div", {
				className: "pke-fx-honor",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ _("div", { className: "pke-fx-sunburst" }), /* @__PURE__ */ v("div", {
					className: "pke-fx-honor-card",
					children: [
						/* @__PURE__ */ _("div", {
							className: "pke-fx-emblems",
							children: o.awards.map((e, t) => /* @__PURE__ */ _($, {
								award: e,
								reveal: !0
							}, t))
						}),
						/* @__PURE__ */ _("strong", { children: i("games.parkseurope.fx.honorEarned") }),
						a(o).map((e, t) => /* @__PURE__ */ _("span", { children: e }, t))
					]
				})]
			}),
			s.length > 0 && /* @__PURE__ */ _("div", {
				className: "pke-fx-other",
				"aria-hidden": "true",
				children: s.map((e) => /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("strong", { children: r(e.rid) }), /* @__PURE__ */ _("span", { children: a(e).join(" · ") })] }, e.rid))
			})
		]
	}, e.id);
}
//#endregion
//#region src/game/field-tracks.tsx
function xn({ items: e, active: t, onSelect: n, label: r }) {
	return /* @__PURE__ */ _("div", {
		className: "pke-field-tabs",
		role: "group",
		"aria-label": r,
		children: e.map(([e, r]) => /* @__PURE__ */ _("button", {
			type: "button",
			"aria-pressed": e === t,
			onClick: () => n(e),
			children: r
		}, e))
	});
}
var Sn = [
	[13, 87],
	[13, 72],
	[13, 57],
	[14, 42],
	[22, 25],
	[39, 14],
	[54, 14],
	[69, 18],
	[83, 27],
	[90, 40],
	[90, 53],
	[90, 66],
	[90, 79],
	[78, 91],
	[62, 91],
	[47, 91]
], Cn = {
	start: "games.parkseurope.trailStart",
	end: "games.parkseurope.fieldFinish",
	snow: "games.parkseurope.fieldSnowSpace",
	wonder: "games.parkseurope.siteShort.wonder",
	award: "games.parkseurope.fieldAward"
};
function wn({ pub: e, nameOf: t, marker: n }) {
	let r = l(), [i, a] = o(null), s = de.map((t, n) => {
		let r = e.players.filter((e) => e.chaletPos === n).sort((e, t) => e.chaletOrder - t.chaletOrder), i = [];
		return t.t === "award" && (i = e.greta?.solo ? e.players.some((e) => e.chaletPos >= n) ? [] : [t.solo] : t.stack === null ? [] : e.chaletStacks[t.stack] ?? []), {
			type: t.t,
			occupants: r,
			scores: i,
			top: i.at(-1)
		};
	}), c = i ?? s.reduce((e, t, n) => t.top === void 0 ? e : n, 0), u = s[c], d = u.top === void 0 ? u.type === "award" || u.type === "wonder" ? r("games.parkseurope.fieldDrawPassing") : "" : r("games.parkseurope.fieldAwardNext", { n: u.top }) + (u.scores.length > 1 ? " " + r("games.parkseurope.fieldAwardStack", { scores: u.scores.slice(0, -1).reverse().join(" / ") }) : "");
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("p", {
			className: "pke-track-note",
			children: r("games.parkseurope.fieldChaletNote")
		}),
		/* @__PURE__ */ v("div", {
			className: "pke-chalet-map",
			role: "group",
			"aria-label": r("games.parkseurope.chaletTrack"),
			children: [
				/* @__PURE__ */ _("svg", {
					viewBox: "0 0 100 100",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: /* @__PURE__ */ _("polyline", {
						points: Sn.map((e) => e.join(",")).join(" "),
						fill: "none",
						vectorEffect: "non-scaling-stroke"
					})
				}),
				/* @__PURE__ */ _("div", {
					className: "pke-chalet-heart",
					"aria-hidden": !0,
					children: /* @__PURE__ */ _(Z, { kind: "chalet" })
				}),
				s.map(({ type: e, occupants: i, top: o }, s) => {
					let [l, u] = Sn[s], d = [
						r("games.parkseurope.fieldTrackSpace", {
							n: s,
							name: r(Cn[e])
						}),
						o === void 0 ? "" : r("games.parkseurope.points", { n: o }),
						...i.map((e) => t(e.rid))
					].filter(Boolean).join(" · ");
					return /* @__PURE__ */ v("button", {
						type: "button",
						className: "pke-chalet-node",
						"data-space": s,
						"data-kind": e,
						style: {
							"--x": l + "%",
							"--y": u + "%"
						},
						"aria-label": d,
						"aria-pressed": c === s,
						onClick: () => a(s),
						children: [
							e === "start" || e === "end" ? r(e === "start" ? "games.parkseurope.fieldStartShort" : "games.parkseurope.fieldEndShort") : /* @__PURE__ */ _(Z, { kind: e === "award" && o === void 0 ? "wonder" : e }),
							o !== void 0 && /* @__PURE__ */ _("b", { children: o }),
							i.length > 0 && /* @__PURE__ */ _("span", {
								className: "pke-chalet-occupants",
								children: i.map((e) => /* @__PURE__ */ _("span", { children: n(e.rid) }, e.rid))
							})
						]
					}, s);
				})
			]
		}),
		/* @__PURE__ */ v("p", {
			className: "pke-track-detail",
			"aria-live": "polite",
			children: [
				/* @__PURE__ */ _("strong", { children: r("games.parkseurope.fieldTrackSpace", {
					n: c,
					name: r(Cn[u.type])
				}) }),
				d && /* @__PURE__ */ _("span", { children: d }),
				u.occupants.length > 0 && /* @__PURE__ */ _("span", { children: u.occupants.map((e) => t(e.rid)).join(" / ") })
			]
		})
	] });
}
var Tn = {
	conservation: "cons",
	carabiner: "carabiner",
	mug: "mug",
	chalet: "chalet"
};
function En({ pub: e, actionName: t, nameOf: n, marker: r, onTake: i }) {
	let a = l();
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("table", {
		className: "pke-end-board",
		"aria-label": a("games.parkseurope.fieldEndActions"),
		children: [/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [
			/* @__PURE__ */ _("th", {
				scope: "col",
				children: a("games.parkseurope.fieldAction")
			}),
			/* @__PURE__ */ _("th", {
				scope: "col",
				children: a("games.parkseurope.slotTop")
			}),
			/* @__PURE__ */ _("th", {
				scope: "col",
				children: a("games.parkseurope.slotBoth")
			})
		] }) }), /* @__PURE__ */ _("tbody", { children: pe.map((o) => /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ v("th", {
			scope: "row",
			children: [
				/* @__PURE__ */ _(Z, { kind: Tn[o] }),
				" ",
				t(o)
			]
		}), ["top", "both"].map((s) => {
			let c = e.endSlots.find((e) => e.action === o && e.kind === s)?.rid;
			return /* @__PURE__ */ _("td", { children: c ? /* @__PURE__ */ v("span", {
				className: "pke-end-occupant",
				children: [
					r(c),
					" ",
					n(c)
				]
			}) : i ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				"aria-label": t(o) + " · " + a(s === "top" ? "games.parkseurope.slotTop" : "games.parkseurope.slotBoth"),
				onClick: () => i(s, o),
				children: a("games.parkseurope.fieldVacant")
			}) : /* @__PURE__ */ _("span", {
				className: "pke-sub",
				children: a("games.parkseurope.fieldVacant")
			}) }, s);
		})] }, o)) })]
	}), /* @__PURE__ */ v("div", {
		className: "pke-park-only",
		children: [/* @__PURE__ */ v("strong", { children: [
			/* @__PURE__ */ _(Z, { kind: "parks" }),
			" ",
			a("games.parkseurope.slotParks")
		] }), i ? /* @__PURE__ */ _("button", {
			type: "button",
			className: "pke-btn pke-btn--main",
			onClick: () => i("parks"),
			children: a("games.parkseurope.fieldChoose")
		}) : /* @__PURE__ */ v("span", { children: [a("games.parkseurope.fieldSharedSlot"), e.parksEndOccupied && " · " + a("games.parkseurope.fieldSharedOccupied")] })]
	})] });
}
function Dn({ pub: e, name: t }) {
	let n = l(), r = A.find((t) => t.id === e.seasonCard);
	return r ? /* @__PURE__ */ v("article", {
		className: "pke-season-card",
		children: [
			/* @__PURE__ */ _("h3", { children: t }),
			/* @__PURE__ */ _("p", { children: n("games.parkseurope.fieldSeasonNote") }),
			/* @__PURE__ */ _("ol", { children: r.pattern.map((e, t) => /* @__PURE__ */ v("li", { children: [/* @__PURE__ */ _(Q, { kind: e }), /* @__PURE__ */ _("span", { children: n("games.parkseurope.siteNo", { n: t + 2 }) })] }, t)) }),
			r.display && /* @__PURE__ */ v("p", { children: [
				n(r.display.zone === "cons" ? "games.parkseurope.consTitle" : "games.parkseurope.parksTitle"),
				" · ",
				n("games.parkseurope.displayBonus"),
				" ",
				/* @__PURE__ */ _(Q, { kind: r.display.token })
			] })
		]
	}) : null;
}
//#endregion
//#region src/game/trail-board.tsx
var On = {
	"core-forest": [["forest", 1]],
	"core-sun": [["sun", 2]],
	"core-water": [["water", 2], ["snow", 1]],
	"core-mountain": [["mountain", 1], ["snow", 1]],
	wildlife: [["wildlife", 1]]
}, kn = {
	"core-forest": "forest",
	"core-sun": "sun",
	"core-water": "water",
	"core-mountain": "mountain",
	wildlife: "wildlife",
	carabiner: "carabiner",
	parks: "parks",
	die: "die",
	photo: "photo",
	mug: "mug",
	chalet: "chalet",
	wonder: "wonder",
	conservation: "cons"
};
function An({ kind: e }) {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 180 72",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		className: "pke-trail-scenery",
		children: [
			/* @__PURE__ */ _("rect", {
				width: "180",
				height: "72",
				fill: "var(--trail-sky)"
			}),
			/* @__PURE__ */ _("circle", {
				cx: "132",
				cy: "24",
				r: "11",
				fill: "var(--trail-light)"
			}),
			/* @__PURE__ */ _("path", {
				d: "M0 56 26 38 42 41 67 24 100 42 118 29 146 43 165 34 180 47V72H0Z",
				fill: "var(--trail-mid)"
			}),
			/* @__PURE__ */ _("path", {
				d: "M0 66 22 52 38 57 58 41 79 45 100 57 122 50 145 60 166 48 180 54V72H0Z",
				fill: "var(--trail-far)"
			}),
			e === "core-water" && /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("path", {
				d: "m10 72 33-10 37-2 35-11 34 4 31 6v13Z",
				fill: "#5baba9"
			}), /* @__PURE__ */ _("path", {
				d: "m43 66 30-2m26 2 31-6m-24-4 17-1",
				fill: "none",
				stroke: "#c3eade",
				strokeWidth: "1.3"
			})] }),
			e === "core-mountain" && /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("path", {
				d: "m21 72 66-60 34 30 18-17 41 47Z",
				fill: "#697f91"
			}), /* @__PURE__ */ _("path", {
				d: "m57 39 30-27 27 25-14-3-8 5-8-6-6 7Z",
				fill: "#f5f1dd"
			})] }),
			(e === "start" || e === "end" || e === "parks") && /* @__PURE__ */ _("path", {
				d: "m80 72 4-11 20-10 11-14 6 1-11 17-18 9-3 8Z",
				fill: "#daba86"
			}),
			(e === "core-forest" || e === "start" || e === "end" || e === "conservation" || e === "wildlife") && /* @__PURE__ */ _("path", {
				d: "M10 72 18 50 27 72M27 72 41 41 55 72M61 72 71 53 79 72M129 72 141 45 152 72M153 72 165 51 176 72",
				fill: "#466c51"
			}),
			e === "core-sun" && /* @__PURE__ */ _("g", {
				fill: "#ffefad",
				children: [
					24,
					46,
					58,
					75,
					96,
					123,
					152,
					176
				].map((e, t) => {
					let n = 56 + t % 3 * 5;
					return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("path", {
						d: `M${e} 72V${n}`,
						stroke: "#adb36d"
					}), /* @__PURE__ */ _("circle", {
						cx: e,
						cy: n,
						r: "2.5"
					})] }, e);
				})
			}),
			e === "chalet" && /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("path", {
					d: "M85 43h40v26H85Z",
					fill: "#d9b17e"
				}),
				/* @__PURE__ */ _("path", {
					d: "m78 45 26-22 30 22Z",
					fill: "#a45344"
				}),
				/* @__PURE__ */ _("path", {
					d: "M100 54h8v15h-8Z",
					fill: "#745745"
				}),
				/* @__PURE__ */ _("path", {
					d: "M115 53h5v6h-5Z",
					fill: "#fff0bf"
				})
			] }),
			e === "mug" && /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("path", {
					d: "M81 59h36m-32 0v12m27-12v12",
					stroke: "#f4dfad",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ _("path", {
					d: "M94 45h11v13H94Z",
					fill: "#467f81"
				}),
				/* @__PURE__ */ _("circle", {
					cx: "105",
					cy: "50",
					r: "4",
					fill: "#467f81"
				})
			] }),
			e === "wonder" && /* @__PURE__ */ v("g", {
				fill: "#dbd0ee",
				children: [/* @__PURE__ */ _("path", { d: "m78 67 6-21 10-15 6 13-4 23Zm20 0 4-31 11-13 8 15-5 29Zm20 0 8-18 9-7 5 9-6 16Z" }), /* @__PURE__ */ _("path", {
					d: "m110 27 2 29m20-11-1 13",
					stroke: "#f1e9f6",
					fill: "none"
				})]
			})
		]
	});
}
function jn({ stops: e, inspected: t, hikers: n, onInspect: r }) {
	let i = l();
	return /* @__PURE__ */ v("section", {
		className: "pke-field-stage pke-route-board",
		"aria-labelledby": "pke-route-title",
		children: [/* @__PURE__ */ v("header", {
			className: "pke-route-board-head",
			children: [/* @__PURE__ */ _("h2", {
				id: "pke-route-title",
				children: i("games.parkseurope.fieldBoardTrail")
			}), n]
		}), /* @__PURE__ */ _("ol", {
			className: "pke-trail-grid",
			children: e.map((e, n) => {
				let a = e.kind, o = a === "start" || a === "end" ? null : a, s = o && On[o], c = o && !s && a !== "carabiner" && a !== "photo" ? kn[o] : null, l = s ? s.map(([e, t]) => /* @__PURE__ */ _(Q, {
					kind: e,
					count: t
				}, e)) : a === "carabiner" ? /* @__PURE__ */ _(Q, {
					kind: "carabiner",
					count: 1
				}) : a === "photo" ? /* @__PURE__ */ _(Q, {
					kind: "photo",
					count: e.photos ?? 1
				}) : i(`games.parkseurope.fieldBoardAction.${a}`), u = e.current ? i("games.parkseurope.fieldBoardCurrent") : e.legal ? i("games.parkseurope.fieldBoardReachable") : n > 0 && n < 8 && e.occupants.length ? i("games.parkseurope.fieldBoardOccupied") : e.passed ? i("games.parkseurope.fieldBoardPassed") : null;
				return /* @__PURE__ */ v("li", {
					className: "pke-trail-step",
					"data-index": n,
					children: [/* @__PURE__ */ v("button", {
						type: "button",
						className: "pke-trail-piece",
						"data-stop": n,
						"data-kind": a,
						"data-current": e.current,
						"data-legal": e.legal,
						"data-occupied": e.occupants.length > 0,
						"aria-pressed": t === n,
						"aria-controls": "pke-panel-site",
						onClick: () => r(n),
						children: [
							/* @__PURE__ */ _(An, { kind: a }),
							/* @__PURE__ */ v("span", {
								className: "pke-trail-heading",
								children: [
									/* @__PURE__ */ _("span", {
										className: "pke-trail-ordinal",
										children: n === 0 ? i("games.parkseurope.fieldStartShort") : n === 8 ? i("games.parkseurope.fieldEndShort") : n
									}),
									/* @__PURE__ */ v("strong", {
										className: "pke-trail-title",
										children: [c && /* @__PURE__ */ _(Z, { kind: c }), /* @__PURE__ */ _("span", { children: e.title })]
									}),
									e.campfire && /* @__PURE__ */ _("span", {
										className: "pke-trail-flag",
										children: /* @__PURE__ */ _(Q, { kind: "campfire" })
									}),
									n === 4 && /* @__PURE__ */ _("span", {
										className: "pke-trail-flag",
										title: i("games.parkseurope.shutterbug"),
										children: /* @__PURE__ */ _(Z, { kind: "photo" })
									})
								]
							}),
							/* @__PURE__ */ v("span", {
								className: "pke-trail-yield",
								children: [/* @__PURE__ */ _("span", {
									className: "pke-trail-gain",
									children: l
								}), e.bonus && /* @__PURE__ */ v("span", {
									className: "pke-trail-bonus",
									role: "group",
									"aria-label": i("games.parkseurope.fieldBoardBonus"),
									title: i("games.parkseurope.fieldBoardBonus"),
									children: [/* @__PURE__ */ _("span", {
										"aria-hidden": "true",
										children: "+"
									}), /* @__PURE__ */ _(Q, {
										kind: e.bonus,
										count: 1
									})]
								})]
							}),
							/* @__PURE__ */ v("span", {
								className: "pke-trail-state",
								children: [e.occupants.length > 0 && /* @__PURE__ */ _("span", {
									className: "pke-trail-trekkers",
									"data-dense": e.occupants.length > 3,
									children: e.occupants
								}), u && /* @__PURE__ */ _("span", {
									className: "pke-trail-status",
									children: u
								})]
							})
						]
					}), n < 8 && /* @__PURE__ */ _("span", {
						className: "pke-trail-link",
						"aria-hidden": "true"
					})]
				}, n);
			})
		})]
	});
}
//#endregion
//#region src/game/view-player.tsx
var Mn = [
	{
		id: "parks",
		label: "games.parkseurope.fieldParks"
	},
	{
		id: "cons",
		label: "games.parkseurope.fieldProjects"
	},
	{
		id: "hand",
		label: "games.parkseurope.fieldHand"
	},
	{
		id: "pack",
		label: "games.parkseurope.fieldPack"
	},
	{
		id: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		id: "trail",
		label: "games.parkseurope.trail"
	}
], Nn = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], Pn = {
	mountain: 0,
	forest: 0,
	sun: 0,
	water: 0,
	wildlife: 0
}, Fn = "#4f5d4a", In = ["#4f5d4a", "#a4632f"], Ln = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]), Rn = {
	cliffs: "games.parkseurope.season.cliffs",
	swimming: "games.parkseurope.season.swimming",
	memories: "games.parkseurope.season.memories",
	sun: "games.parkseurope.season.sun",
	dreams: "games.parkseurope.season.dreams",
	joy: "games.parkseurope.season.joy",
	scouting: "games.parkseurope.season.scouting",
	growth: "games.parkseurope.season.growth",
	climbing: "games.parkseurope.season.climbing",
	caves: "games.parkseurope.season.caves",
	meadows: "games.parkseurope.season.meadows",
	ice: "games.parkseurope.season.ice"
}, zn = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any"
}, Bn = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple",
	wild: "games.parkseurope.suit.wild"
}, Vn = {
	"core-forest": "games.parkseurope.siteShort.core-forest",
	"core-sun": "games.parkseurope.siteShort.core-sun",
	"core-mountain": "games.parkseurope.siteShort.core-mountain",
	"core-water": "games.parkseurope.siteShort.core-water",
	wildlife: "games.parkseurope.siteShort.wildlife",
	carabiner: "games.parkseurope.siteShort.carabiner",
	parks: "games.parkseurope.siteShort.parks",
	die: "games.parkseurope.siteShort.die",
	photo: "games.parkseurope.siteShort.photo",
	mug: "games.parkseurope.siteShort.mug",
	chalet: "games.parkseurope.siteShort.chalet",
	wonder: "games.parkseurope.siteShort.wonder",
	conservation: "games.parkseurope.siteShort.conservation"
}, Hn = {
	wonder: "games.parkseurope.vfShort.wonder",
	sunwater: "games.parkseurope.vfShort.sunwater",
	photo: "games.parkseurope.vfShort.photo",
	conservation: "games.parkseurope.vfShort.conservation",
	mug: "games.parkseurope.vfShort.mug",
	wildlife: "games.parkseurope.vfShort.wildlife"
}, Un = {
	conservation: "games.parkseurope.top.conservation",
	carabiner: "games.parkseurope.top.carabiner",
	mug: "games.parkseurope.top.mug",
	chalet: "games.parkseurope.top.chalet"
}, Wn = {
	die: "games.parkseurope.benefit.die",
	parks: "games.parkseurope.benefit.parks",
	mug: "games.parkseurope.benefit.mug",
	wonder: "games.parkseurope.benefit.wonder",
	photo: "games.parkseurope.benefit.photo",
	wildlife: "games.parkseurope.benefit.wildlife",
	carabiner: "games.parkseurope.benefit.carabiner"
}, Gn = {
	snow: "games.parkseurope.res.snow",
	wonder: "games.parkseurope.site.wonder",
	mug: "games.parkseurope.site.mug",
	photo: "games.parkseurope.site.photo",
	wildlife: "games.parkseurope.res.wildlife",
	carabiner: "games.parkseurope.token.carabiner",
	die: "games.parkseurope.site.die",
	chalet: "games.parkseurope.top.chalet"
}, Kn = {
	consForest: "games.parkseurope.campfire.consForest",
	consMountain: "games.parkseurope.campfire.consMountain",
	consSun: "games.parkseurope.campfire.consSun",
	consWater: "games.parkseurope.campfire.consWater",
	iconForest: "games.parkseurope.campfire.iconForest",
	iconMountain: "games.parkseurope.campfire.iconMountain",
	iconSun: "games.parkseurope.campfire.iconSun",
	iconWater: "games.parkseurope.campfire.iconWater",
	anyIcons: "games.parkseurope.campfire.anyIcons",
	album: "games.parkseurope.campfire.album",
	wonderHand: "games.parkseurope.campfire.wonderHand",
	snow: "games.parkseurope.campfire.snow",
	turnWildlife2: "games.parkseurope.campfire.turnWildlife2",
	turnAny2: "games.parkseurope.campfire.turnAny2",
	turnCarabiner: "games.parkseurope.campfire.turnCarabiner",
	turnAny3: "games.parkseurope.campfire.turnAny3"
}, qn = [
	"games.parkseurope.consProject.p0",
	"games.parkseurope.consProject.p1",
	"games.parkseurope.consProject.p2",
	"games.parkseurope.consProject.p3",
	"games.parkseurope.consProject.p4",
	"games.parkseurope.consProject.p5",
	"games.parkseurope.consProject.p6"
], Jn = {
	move: "games.parkseurope.pending.move",
	trailEnd: "games.parkseurope.pending.trailEnd",
	actions: "games.parkseurope.pending.actions",
	parks: "games.parkseurope.pending.parks",
	mug: "games.parkseurope.pending.mug",
	mugChoice: "games.parkseurope.pending.mugChoice",
	cons: "games.parkseurope.pending.cons",
	assignWild: "games.parkseurope.pending.assignWild",
	freePark: "games.parkseurope.pending.freePark",
	discardRes: "games.parkseurope.pending.discardRes",
	discardWonder: "games.parkseurope.pending.discardWonder",
	gretaColor: "games.parkseurope.pending.gretaColor",
	scoring: "games.parkseurope.pending.scoring",
	none: "games.parkseurope.pending.none"
}, Yn = {
	mountain: "#6b7c8f",
	forest: "#3f7a4d",
	sun: "#d9a227",
	water: "#3a7ca5",
	wildlife: "#8a5a44",
	snow: "#cfe3ee",
	any: "#8b8578"
};
function Xn(e, t) {
	return ve(e.res, t) !== null;
}
function Zn({ color: e, label: t, greta: n, avatar: r, selected: i }) {
	return /* @__PURE__ */ _("span", {
		className: "pke-hiker-mark",
		"data-selected": i,
		style: { "--pke-mark": e },
		role: "img",
		"aria-label": t,
		title: t,
		children: n ? /* @__PURE__ */ _("i", {
			className: "pke-greta-glyph",
			"aria-hidden": !0
		}) : /* @__PURE__ */ _("img", {
			src: r,
			alt: "",
			draggable: !1
		})
	});
}
function Qn(e) {
	let t = e.public, n = e.private ?? {
		hand: [],
		isTurn: !1
	};
	return /* @__PURE__ */ _($n, {
		pub: t,
		hand: n.hand,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function $n({ pub: e, hand: t, members: n, myRid: r, send: h }) {
	let y = l();
	p();
	let b = e.players.find((e) => e.rid === r), x = e.phase === "turn" && e.turn === r && !!b, ee = e.phase === "scoring" && e.turn === r && !!b, [te, w] = o(r), [E, ie] = o(0), [D, O] = o(null), [A, oe] = o(null), [se, ce] = o(null), [ue, j] = o({ ...Pn }), [de, fe] = o(""), [pe, me] = o(""), [he, ge] = o(null), [_e, ve] = o({
		panel: null,
		id: 0
	}), [ye, be] = o(null), [M, xe] = o(null), [N, Se] = o("display"), [Ce, we] = o("route"), [Te, Ee] = o(null), De = a(null), Oe = a(null), ke = a(!1), { root: Ae, capture: je, record: Me, active: Ne, timing: Pe } = vn(e, t, r);
	i(() => {
		let e = De.current;
		e && (e.scrollTop = 0, ke.current && (ke.current = !1, e.querySelector("#pke-panel-parks .pke-park-face[aria-pressed=\"true\"]")?.focus()));
	}, [
		he,
		_e,
		N,
		Ce
	]);
	let P = e.players.find((e) => e.rid === te) ?? e.players.find((e) => e.rid === r) ?? e.players[0], F = (e) => n.find((t) => t.rid === e), I = (t) => t === "$greta" ? y("games.parkseurope.greta") : F(t)?.name || y(f[(F(t)?.colorIndex ?? Math.max(0, e.order.indexOf(t))) % f.length].nameKey), L = (e) => e === "$greta" ? Fn : f[(F(e)?.colorIndex ?? 0) % f.length].hex, Fe = (e) => s[(F(e)?.avatar ?? 0) % s.length], Ie = (t) => e.greta?.solo ? In[Math.floor(t / 2) % In.length] : Fn, R = (e, t) => `${I(e)} · ${y("games.parkseurope.hikerLabel", { n: t + 1 })}`, z = (e, t, n) => {
		let i = e === r && t === Xe, a = R(e, t) + (i ? " · " + y("games.parkseurope.selectedHiker") : "");
		return e === "$greta" ? /* @__PURE__ */ _(Zn, {
			greta: !0,
			color: Ie(t),
			label: a
		}, n) : /* @__PURE__ */ _(Zn, {
			color: L(e),
			avatar: Fe(e),
			label: a,
			selected: i
		}, n);
	}, B = (t) => {
		let n = [];
		for (let r of e.players) r.hikers.forEach((e, i) => {
			e === t && n.push({
				rid: r.rid,
				hiker: i
			});
		});
		return e.greta && e.greta.hikers.forEach((e, r) => {
			e === t && n.push({
				rid: "$greta",
				hiker: r
			});
		}), n;
	}, Le = (n) => e.campfires.includes(n) || t.some((e) => !!k[e]), Re = `${e.season}:${e.turn}:${e.moved}:${e.pending}:${b?.hikers.join(",") ?? ""}:${t.length}`;
	if (pe !== Re && (me(Re), b)) {
		let e = b.hikers.map((e, t) => e < 8 ? t : -1).filter((e) => e >= 0);
		ie(e.includes(E) ? E : e[0] ?? 0);
	}
	let V = b ? Nn.reduce((e, t) => e + b.res[t], 0) : 0, ze = e.pending === "discardRes" ? "discardRes" : e.pending === "discardWonder" ? "discardWonder" : e.pending === "assignWild" ? "assignWild" : e.pending === "freePark" ? "freePark" : null, Be = `${e.season}:${e.turn}:${e.pending}:${V}:${t.length}:${e.landingSite}`;
	if (Be !== de && (fe(Be), ze && x && O(ze)), !b) return /* @__PURE__ */ _(m, {
		adaptive: !0,
		className: "pke-screen",
		children: /* @__PURE__ */ _("p", {
			className: "pke-empty",
			children: y("games.parkseurope.err.notPlayer")
		})
	});
	let H = x && e.pending === "parks" ? "parks" : x && e.pending === "cons" ? "cons" : null, U = _e.panel === H ? _e.id : _e.id + 1;
	_e.panel !== H && ve({
		panel: H,
		id: U
	});
	let Ve = `${r}:${e.season}:${e.turn}:${b.hikers.join(",")}`;
	H === "parks" && ye?.turn !== Ve ? be({
		turn: Ve,
		visits: b.visited.length
	}) : ye && (ye.turn !== Ve || [
		"actions",
		"move",
		"trailEnd",
		"none"
	].includes(e.pending)) && be(null);
	let He = he?.seat === r ? he : null, W = He && (!H || He.prompt === U) ? He.panel : H, G = (e) => {
		let t = e === null && He?.prompt === U && He.returnToParks;
		t && (ke.current = !0), ge({
			seat: r,
			prompt: U,
			panel: t ? "parks" : e,
			returnToParks: e !== null && e !== "parks" && (W === "parks" || !!He?.returnToParks)
		});
	}, K = M?.seat === r && (M.from === "display" ? e.parksDisplay : b.reserved).includes(M.id) ? M : null, Ue = Nn.filter((e) => b.res[e]), We = b.visited.at(-1), Ge = We && H === "parks" && ye?.turn === Ve && b.visited.length > ye.visits ? S[We.id] : null, Ke = (e) => e === "$greta" ? /* @__PURE__ */ _(Zn, {
		greta: !0,
		color: Fn,
		label: I(e)
	}) : /* @__PURE__ */ _(Zn, {
		color: L(e),
		avatar: Fe(e),
		label: I(e)
	}), qe = e.consDeck > 0 && (e.freeCons || Xn(b, {
		sun: 1,
		water: 1
	})), Je = b.hikers[E] < 8 || b.hikers[1 - E] >= 8 ? E : +(E === 0), Ye = b.hikers[Je], Xe = x && Ye < 8 ? Je : null, q = /* @__PURE__ */ new Set();
	if (x && (e.pending === "move" || e.pending === "trailEnd")) {
		if (e.pending === "trailEnd") q.add(8);
		else if (Ye < 8) {
			for (let e = Ye + 1; e <= 7; e++) (B(e).length === 0 || Le(e)) && q.add(e);
			q.add(8);
		}
	}
	let J = (e) => {
		Me(e), h(e);
	}, Ze = (e) => {
		if (q.has(e)) {
			if (e === 8) {
				O("trailEnd");
				return;
			}
			if (B(e).length > 0) {
				oe({
					hiker: Je,
					to: e
				}), O("campfire");
				return;
			}
			J({
				type: "move",
				hiker: Je,
				to: e
			});
		}
	}, Qe = (t) => {
		Ee({
			seat: r,
			season: e.season,
			site: t
		}), Oe.current && (Oe.current.scrollTop = 0), W === "trail" && G(null);
	}, Y = Te?.seat === r && Te.season === e.season ? Te.site : e.landingSite ?? Ye, X = e.trailSites[Y - 1], $e = e.vf[Y - 1], et = e.trailBonus[Y - 1], tt = B(Y), nt = X && On[X], rt = V + b.snow * 2, it = rt + (et === "snow" ? 2 : et && et !== "photo" && et !== "carabiner" ? 1 : 0) + (nt || []).reduce((e, [t, n]) => e + n * (t === "snow" ? 2 : 1), 0), at = (t) => y(t === 0 ? "games.parkseurope.trailStart" : t === 8 ? "games.parkseurope.trailEnd" : Vn[e.trailSites[t - 1]]), ot = e.phase === "ended" || e.pending === "none" ? y("games.parkseurope.pending.none") : ee ? y("games.parkseurope.pending.scoring") : x ? y(Jn[e.pending]) : y("games.parkseurope.waitingFor", { name: I(e.turn ?? "") }), st = Rn[e.seasonCard] ? y(Rn[e.seasonCard]) : e.seasonCard, ct = e.landingSite === null ? null : e.vf[e.landingSite - 1], lt = x && e.pending === "actions" && !e.vfUsed && e.landingSite !== null && ct !== null && b.carabiners > 0, ut = e.landingSite === null ? null : e.trailSites[e.landingSite - 1], dt = ut ? le(ut) : null, ft = dt ? b.cons.map((e, t) => ({
		id: e,
		i: t
	})).filter(({ id: t, i: n }) => T(t) === dt && !e.consUsed.includes(n)) : [], pt = !e.end || e.end.topDone && e.end.parksDone, mt = t.filter((t) => !!k[t] && Ln.has(k[t].effect) && !e.campfireUsed.includes(t)), ht = Nn.reduce((e, t) => e + ue[t], 0), gt = /* @__PURE__ */ _("div", {
		className: "pke-actions-hikers pke-board-hikers",
		role: "group",
		"aria-label": y("games.parkseurope.chooseHiker"),
		children: [0, 1].map((t) => {
			let n = t, r = b.hikers[n];
			return /* @__PURE__ */ v("button", {
				type: "button",
				className: "pke-hiker",
				"data-on": Xe === n,
				disabled: !x || r >= 8 || e.pending !== "move" && e.pending !== "trailEnd",
				"aria-pressed": Xe === n,
				onClick: () => {
					ie(n), Ee(null);
				},
				children: [/* @__PURE__ */ _("b", { children: y("games.parkseurope.hikerLabel", { n: t + 1 }) }), /* @__PURE__ */ _("span", { children: r >= 8 ? y("games.parkseurope.atEnd") : r === 0 ? y("games.parkseurope.trailStart") : y("games.parkseurope.siteNo", { n: r }) })]
			}, n);
		})
	}), _t = /* @__PURE__ */ _("div", {
		className: "pke-actions",
		children: /* @__PURE__ */ _("div", {
			className: "pke-actions-main",
			children: e.pending === "gretaColor" && x ? /* @__PURE__ */ _(g, { children: [0, 1].map((e) => /* @__PURE__ */ v("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => J({
					type: "gretaColor",
					first: e
				}),
				children: [/* @__PURE__ */ _("i", {
					className: "pke-pair-dot",
					style: { background: In[e] },
					"aria-hidden": !0
				}), y(e === 0 ? "games.parkseurope.gretaPairA" : "games.parkseurope.gretaPairB")]
			}, e)) }) : e.phase === "scoring" ? ee ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => O("scoring"),
				children: y("games.parkseurope.scoringTitle")
			}), /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => {
					J({ type: "scoringDone" }), O(null), ce(null), j({ ...Pn });
				},
				children: y("games.parkseurope.scoringDone")
			})] }) : null : !x || e.pending === "move" || e.pending === "trailEnd" ? null : e.pending === "parks" ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => G("parks"),
				children: y("games.parkseurope.fieldChoosePark")
			}) : e.pending === "mug" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: b.mug >= 3,
				onClick: () => J({
					type: "mug",
					act: "fill"
				}),
				children: y("games.parkseurope.mug.fill")
			}), /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				disabled: b.mug < 1,
				onClick: () => J({
					type: "mug",
					act: "drink"
				}),
				children: y("games.parkseurope.mug.drink")
			})] }) : e.pending === "mugChoice" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => J({
					type: "mugChoice",
					choice: "chalet"
				}),
				children: y("games.parkseurope.mug.chalet")
			}), /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => J({
					type: "mugChoice",
					choice: "cons"
				}),
				children: y("games.parkseurope.mug.cons")
			})] }) : e.pending === "cons" ? /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: !qe,
				onClick: () => J({
					type: "consPick",
					deck: !0
				}),
				children: [
					y("games.parkseurope.startDeck"),
					" · ",
					e.freeCons ? y("games.parkseurope.free") : y("games.parkseurope.deckCost")
				]
			}), /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => J({ type: "skip" }),
				children: y("games.parkseurope.skip")
			})] }) : e.pending === "assignWild" ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("assignWild"),
				children: y("games.parkseurope.assignWildPrompt")
			}) : e.pending === "freePark" ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("freePark"),
				children: y("games.parkseurope.freeParkPrompt")
			}) : e.pending === "discardRes" ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("discardRes"),
				children: y("games.parkseurope.discardResPrompt")
			}) : e.pending === "discardWonder" ? /* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => O("discardWonder"),
				children: y("games.parkseurope.discardWonderPrompt")
			}) : /* @__PURE__ */ v(g, { children: [
				e.end?.action && !e.end.topDone && /* @__PURE__ */ v("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => J({ type: "endTop" }),
					children: [
						y("games.parkseurope.endTop"),
						" · ",
						y(Un[e.end.action])
					]
				}),
				e.end && !e.end.parksDone && /* @__PURE__ */ _("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => J({ type: "endParks" }),
					children: y("games.parkseurope.endParksTodo")
				}),
				ut && !e.siteDone && /* @__PURE__ */ v("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => J({ type: "siteAction" }),
					children: [
						y("games.parkseurope.siteAction"),
						" · ",
						y(Vn[ut])
					]
				}),
				ft.length > 0 && /* @__PURE__ */ _("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => O("activateCons"),
					children: y("games.parkseurope.activateCons")
				}),
				lt && /* @__PURE__ */ v("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => J({ type: "viaFerrata" }),
					children: [y("games.parkseurope.viaFerrata"), ct ? ` · ${y(Hn[ct])}` : ""]
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					disabled: !pt,
					onClick: () => J({ type: "endTurn" }),
					children: y("games.parkseurope.endTurn")
				})
			] })
		})
	});
	return /* @__PURE__ */ v("div", {
		className: "pke-motion-root",
		ref: Ae,
		onClickCapture: je,
		children: [/* @__PURE__ */ v(m, {
			adaptive: !0,
			scroll: !1,
			className: "pke-screen",
			children: [
				/* @__PURE__ */ v("div", {
					className: "pke-layout pke-2d-layout",
					children: [
						/* @__PURE__ */ v("header", {
							className: "pke-board-header",
							children: [
								/* @__PURE__ */ _("div", {
									className: "pke-field-heading",
									children: /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ v("strong", { children: ["PARKS ", /* @__PURE__ */ _("em", { children: "EUROPE" })] }), /* @__PURE__ */ v("span", { children: [
										y("games.parkseurope.seasonLabel", { n: e.season }),
										" · ",
										st
									] })] })
								}),
								/* @__PURE__ */ _("div", {
									className: "pke-board-phase",
									"aria-live": "polite",
									children: ot
								}),
								/* @__PURE__ */ _("div", {
									className: "pke-field-roster",
									children: e.players.map((t) => /* @__PURE__ */ v("button", {
										type: "button",
										"data-turn": e.turn === t.rid,
										"aria-label": I(t.rid) + " · " + y("games.parkseurope.visitedCount", { n: t.visited.length }),
										"aria-expanded": W === "pack" && P.rid === t.rid,
										onClick: () => {
											w(t.rid), G("pack");
										},
										children: [Ke(t.rid), /* @__PURE__ */ _("b", { children: I(t.rid) })]
									}, t.rid))
								}),
								/* @__PURE__ */ v("button", {
									type: "button",
									className: "pke-field-resources",
									"aria-label": y("games.parkseurope.fieldPack"),
									"data-kinds": Ue.length + Number(b.snow > 0),
									"aria-expanded": W === "pack" && P.rid === r,
									onClick: () => {
										w(r), G(W === "pack" && P.rid === r ? null : "pack");
									},
									children: [
										/* @__PURE__ */ _("strong", {
											className: "pke-board-pack-title",
											children: y("games.parkseurope.fieldPack")
										}),
										/* @__PURE__ */ v("span", {
											className: "pke-resource-counts",
											children: [
												Ue.map((e) => /* @__PURE__ */ _(Q, {
													kind: e,
													count: b.res[e]
												}, e)),
												b.snow > 0 && /* @__PURE__ */ _(Q, {
													kind: "snow",
													count: b.snow
												}),
												!V && !b.snow && /* @__PURE__ */ _(d, {})
											]
										}),
										/* @__PURE__ */ v("span", {
											className: "pke-board-pack-meter",
											children: [rt, " / 12"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ _(jn, {
							inspected: Y,
							hikers: gt,
							onInspect: Qe,
							stops: Array.from({ length: 9 }, (t, n) => ({
								kind: n === 0 ? "start" : n === 8 ? "end" : e.trailSites[n - 1],
								title: at(n),
								bonus: e.trailBonus[n - 1],
								current: Xe !== null && Ye === n,
								legal: q.has(n),
								passed: n > 0 && n < Ye,
								campfire: e.campfires.includes(n),
								occupants: B(n).map((e) => z(e.rid, e.hiker, `${e.rid}:${e.hiker}`)),
								photos: b.shutterbug || n === 4 ? 2 : 1
							}))
						}),
						e.phase === "scoring" && e.revealedCampfire && /* @__PURE__ */ v("section", {
							className: "pke-panel pke-scoring",
							children: [/* @__PURE__ */ v("header", {
								className: "pke-section-head",
								children: [/* @__PURE__ */ _("h2", { children: y("games.parkseurope.scoringTitle") }), /* @__PURE__ */ _("span", {
									className: "pke-sub",
									children: y("games.parkseurope.scoringPrompt")
								})]
							}), /* @__PURE__ */ _("ul", {
								className: "pke-scoring-list",
								children: e.revealedCampfire.map(({ rid: t, cards: n }) => {
									let r = e.players.find((e) => e.rid === t);
									return /* @__PURE__ */ v("li", {
										"data-on": e.turn === t,
										children: [
											/* @__PURE__ */ _("b", { children: I(t) }),
											/* @__PURE__ */ _("span", { children: n.length === 0 ? y("games.parkseurope.scoringEmpty") : n.map((t) => {
												let n = k[t]?.effect, r = e.campfireUsed.includes(t);
												return `${qt(y, t)}${n ? ` · ${y(Kn[n])}` : ""}${r ? ` · ${y("games.parkseurope.scoringUsed")}` : ""}`;
											}).join("、") }),
											/* @__PURE__ */ _("span", {
												className: "pke-scoring-points",
												children: y("games.parkseurope.over.endgame", { n: r?.endPoints ?? 0 })
											})
										]
									}, t);
								})
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "pke-board-table",
							ref: Oe,
							children: [/* @__PURE__ */ v("section", {
								className: "pke-board-market",
								"aria-labelledby": "pke-board-market-title",
								children: [/* @__PURE__ */ _("h2", {
									id: "pke-board-market-title",
									children: y("games.parkseurope.fieldBoardMarket")
								}), /* @__PURE__ */ _("div", {
									className: "pke-card-row",
									children: e.parksDisplay.map((t, n) => {
										let i = S[t];
										return /* @__PURE__ */ _(Zt, {
											park: i,
											suitLabel: y(Bn[i.suit]),
											bonus: e.parksBonus[n],
											effect: i.instant ? y(Gn[i.instant]) : void 0,
											picked: K?.id === t && K.from === "display",
											onPick: () => {
												Se("display"), xe({
													seat: r,
													id: t,
													from: "display"
												}), G("parks");
											}
										}, t);
									})
								})]
							}), /* @__PURE__ */ v("section", {
								className: "pke-panel pke-site-peek pke-board-inspector",
								id: "pke-panel-site",
								"aria-labelledby": "pke-inspector-title",
								children: [
									/* @__PURE__ */ v("header", {
										className: "pke-section-head",
										children: [/* @__PURE__ */ v("h2", {
											id: "pke-inspector-title",
											children: [
												X && /* @__PURE__ */ _(Z, { kind: kn[X] }),
												X && `${Y} `,
												at(Y)
											]
										}), Xe !== null && /* @__PURE__ */ _("span", { children: y("games.parkseurope.hikerLabel", { n: Je + 1 }) })]
									}),
									/* @__PURE__ */ v("dl", {
										className: "pke-site-extras",
										children: [
											/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: y("games.parkseurope.siteAction") }), /* @__PURE__ */ _("dd", { children: nt ? /* @__PURE__ */ _("span", {
												className: "pke-board-gain-list",
												children: nt.map(([e, t]) => /* @__PURE__ */ _(Q, {
													kind: e,
													count: t
												}, e))
											}) : y(X ? `games.parkseurope.fieldSiteDetail.${X}` : Y === 0 ? "games.parkseurope.fieldTrailheadInfo" : "games.parkseurope.fieldTrailEndInfo") })] }),
											et && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: y("games.parkseurope.fieldBoardArrival") }), /* @__PURE__ */ _("dd", { children: /* @__PURE__ */ _(Q, {
												kind: et,
												count: 1
											}) })] }),
											$e && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: y("games.parkseurope.viaFerrata") }), /* @__PURE__ */ v("dd", { children: [
												/* @__PURE__ */ _("b", { children: y(Hn[$e]) }),
												" · ",
												y("games.parkseurope.fieldFerrataInfo")
											] })] }),
											e.campfires.includes(Y) && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: y("games.parkseurope.campfireLabel") }), /* @__PURE__ */ _("dd", { children: y("games.parkseurope.fieldShareInfo") })] }),
											Y === 4 && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: y("games.parkseurope.fieldStop") }), /* @__PURE__ */ _("dd", { children: y("games.parkseurope.shutterbug") })] })
										]
									}),
									tt.length > 0 && /* @__PURE__ */ _("ul", {
										className: "pke-board-occupant-list",
										children: tt.map(({ rid: e, hiker: t }) => /* @__PURE__ */ v("li", { children: [z(e, t), /* @__PURE__ */ _("span", { children: R(e, t) })] }, e + ":" + t))
									}),
									/* @__PURE__ */ _("div", {
										className: "pke-board-next",
										children: q.has(Y) ? /* @__PURE__ */ v(g, { children: [it > 12 && it > rt && /* @__PURE__ */ _("p", { children: y("games.parkseurope.fieldBoardFullPack", { used: it }) }), /* @__PURE__ */ _("button", {
											type: "button",
											className: "pke-btn pke-btn--main pke-site-go",
											onClick: () => Ze(Y),
											children: y("games.parkseurope.fieldGoTo", { name: at(Y) })
										})] }) : Y === 8 && /* @__PURE__ */ _("button", {
											type: "button",
											className: "pke-btn pke-site-go",
											onClick: () => {
												we("end"), G("trail");
											},
											children: y("games.parkseurope.fieldEndSpaces")
										})
									}),
									!q.size && /* @__PURE__ */ _("div", {
										className: "pke-board-actions",
										children: x && e.landingSite !== null && e.landingSite !== Y ? /* @__PURE__ */ _("button", {
											type: "button",
											className: "pke-btn pke-btn--main",
											onClick: () => Qe(e.landingSite ?? Ye),
											children: y("games.parkseurope.fieldBackToStop", { name: at(e.landingSite) })
										}) : _t
									})
								]
							})]
						}),
						/* @__PURE__ */ _("nav", {
							className: "pke-field-nav",
							"aria-label": y("games.parkseurope.fieldPanels"),
							children: Mn.map(({ id: e, label: n }) => /* @__PURE__ */ v("button", {
								type: "button",
								"data-panel": e,
								"aria-expanded": W === e,
								"aria-controls": `pke-panel-${e}`,
								onClick: () => {
									e === "pack" && W !== e && w(r), G(W === e ? null : e);
								},
								children: [e === "pack" ? /* @__PURE__ */ _(d, {}) : e !== "trail" && /* @__PURE__ */ _(Z, { kind: e === "hand" ? "wonder" : e }), /* @__PURE__ */ v("span", { children: [y(n), e === "hand" && t.length > 0 && /* @__PURE__ */ _("b", { children: t.length })] })]
							}, e))
						}),
						/* @__PURE__ */ v("div", {
							"data-panel": W,
							className: "pke-boards pke-field-drawer",
							hidden: W === null,
							onKeyDown: (e) => {
								e.key === "Escape" && (e.stopPropagation(), G(null));
							},
							children: [/* @__PURE__ */ _("button", {
								type: "button",
								className: "pke-field-close",
								"aria-label": y("games.parkseurope.closePanel"),
								onClick: () => G(null),
								children: /* @__PURE__ */ _(u, {})
							}), /* @__PURE__ */ v("div", {
								ref: De,
								className: "pke-field-scroll",
								children: [
									/* @__PURE__ */ v("section", {
										className: "pke-panel pke-parks",
										hidden: W !== "parks",
										id: "pke-panel-parks",
										children: [
											/* @__PURE__ */ v("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ _("h2", { children: y("games.parkseurope.parksTitle") }), /* @__PURE__ */ _("span", {
													className: "pke-sub",
													children: y("games.parkseurope.deckCount", { n: e.parksDeck })
												})]
											}),
											/* @__PURE__ */ _(xn, {
												items: [["display", y("games.parkseurope.fieldDisplay")], ["reserved", y("games.parkseurope.fieldReserved", { n: b.reserved.length })]],
												active: N,
												onSelect: Se,
												label: y("games.parkseurope.parksTitle")
											}),
											/* @__PURE__ */ _("div", {
												className: "pke-card-row",
												children: (N === "display" ? e.parksDisplay : b.reserved).map((t, n) => {
													let i = S[t];
													return i ? /* @__PURE__ */ _(Zt, {
														park: i,
														suitLabel: y(Bn[i.suit]),
														bonus: N === "display" ? e.parksBonus[n] : null,
														effect: i.instant ? y(Gn[i.instant]) : void 0,
														picked: K?.id === t && K.from === N,
														onPick: () => xe({
															seat: r,
															id: t,
															from: N
														})
													}, t) : null;
												})
											}),
											N === "reserved" && !b.reserved.length && /* @__PURE__ */ _("p", {
												className: "pke-muted",
												children: y("games.parkseurope.fieldNoReserved")
											}),
											K?.from === N && x && e.pending === "parks" && (() => {
												let t = S[K.id], n = Xn(b, t.cost);
												return /* @__PURE__ */ v("div", {
													className: "pke-park-choice",
													"aria-live": "polite",
													children: [/* @__PURE__ */ _("strong", { children: Kt(y, t.id) }), /* @__PURE__ */ v("div", {
														className: "pke-card-actions",
														children: [K.from === "display" && !Ge && /* @__PURE__ */ _("button", {
															type: "button",
															className: "pke-btn pke-btn--quiet",
															onClick: () => J({
																type: "reserve",
																from: "display",
																index: e.parksDisplay.indexOf(t.id)
															}),
															children: y("games.parkseurope.reserve")
														}), /* @__PURE__ */ _("button", {
															type: "button",
															className: "pke-btn pke-btn--main",
															disabled: !n,
															onClick: () => J({
																type: "visit",
																parkId: t.id
															}),
															children: y(n ? "games.parkseurope.visit" : "games.parkseurope.cannotAfford")
														})]
													})]
												});
											})(),
											x && e.pending === "parks" && /* @__PURE__ */ v("div", {
												className: "pke-park-footer",
												children: [Ge ? /* @__PURE__ */ v("output", {
													className: "pke-park-receipt",
													children: [
														/* @__PURE__ */ _(Z, { kind: "parks" }),
														" ",
														y("games.parkseurope.fieldVisitedPark", {
															name: Kt(y, Ge.id),
															n: Ge.points
														})
													]
												}) : e.parksDeck > 0 && /* @__PURE__ */ v("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => J({
														type: "reserve",
														from: "deck"
													}),
													children: [
														y("games.parkseurope.reserve"),
														" · ",
														y("games.parkseurope.startDeck")
													]
												}), /* @__PURE__ */ _("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => J({ type: "parksDone" }),
													children: y("games.parkseurope.fieldFinishParks")
												})]
											})
										]
									}),
									/* @__PURE__ */ v("section", {
										className: "pke-panel pke-cons",
										hidden: W !== "cons",
										id: "pke-panel-cons",
										children: [/* @__PURE__ */ v("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ _("h2", { children: y("games.parkseurope.consTitle") }), /* @__PURE__ */ _("span", {
												className: "pke-sub",
												children: y("games.parkseurope.consAwardsLabel", { n: e.consAwardsLeft })
											})]
										}), /* @__PURE__ */ _("div", {
											className: "pke-card-row pke-project-row",
											children: e.consDisplay.map((t, n) => {
												let r = T(t), i = re[t % 7], a = x && e.pending === "cons", o = a && e.freeCons, s = o || Xn(b, ne[r]);
												return /* @__PURE__ */ _(ln, {
													id: t,
													name: y(qn[t % 7]),
													site: y("games.parkseurope.projectSite", { resource: y(zn[r]) }),
													benefit: y(Wn[i.benefit]),
													free: o,
													bonus: e.consBonus[n],
													action: a ? {
														label: y(s ? o ? "games.parkseurope.free" : "games.parkseurope.support" : "games.parkseurope.cannotAfford"),
														disabled: !s,
														onPress: () => J({
															type: "consPick",
															index: n
														})
													} : void 0
												}, t);
											})
										})]
									}),
									/* @__PURE__ */ v("section", {
										className: "pke-panel",
										hidden: W !== "trail",
										id: "pke-panel-trail",
										children: [
											/* @__PURE__ */ _("header", {
												className: "pke-section-head",
												children: /* @__PURE__ */ _("h2", { children: y("games.parkseurope.fieldTrailSeason") })
											}),
											/* @__PURE__ */ _(xn, {
												items: [
													["route", y("games.parkseurope.fieldTrailRoute")],
													["end", y("games.parkseurope.fieldEndActions")],
													["season", y("games.parkseurope.fieldSeasonTab")]
												],
												active: Ce,
												onSelect: we,
												label: y("games.parkseurope.fieldTrailSeason")
											}),
											Ce === "route" && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("div", {
												className: "pke-route-head",
												"aria-hidden": !0,
												children: [
													/* @__PURE__ */ _("span", { children: y("games.parkseurope.fieldStop") }),
													/* @__PURE__ */ _("span", { children: y("games.parkseurope.fieldExtras") }),
													/* @__PURE__ */ _("span", { children: y("games.parkseurope.fieldHikers") })
												]
											}), /* @__PURE__ */ _("ol", {
												className: "pke-route",
												children: Array.from({ length: 9 }, (t, n) => {
													let r = e.trailSites[n - 1], i = e.vf[n - 1], a = e.trailBonus[n - 1], o = at(n), s = q.has(n);
													return /* @__PURE__ */ v("li", {
														className: "pke-route-stop",
														"data-legal": s,
														"aria-current": e.landingSite === n ? "location" : void 0,
														children: [
															/* @__PURE__ */ _("b", {
																className: "pke-route-number",
																children: n === 0 ? y("games.parkseurope.fieldStartShort") : n === 8 ? y("games.parkseurope.fieldEndShort") : n
															}),
															/* @__PURE__ */ v("span", {
																className: "pke-route-name",
																children: [r && /* @__PURE__ */ _(Z, { kind: kn[r] }), /* @__PURE__ */ _("button", {
																	type: "button",
																	onClick: () => Qe(n),
																	children: o
																})]
															}),
															/* @__PURE__ */ v("span", {
																className: "pke-route-extras",
																children: [
																	i && /* @__PURE__ */ v("span", { children: [
																		y("games.parkseurope.viaFerrata"),
																		" · ",
																		y(Hn[i])
																	] }),
																	a && /* @__PURE__ */ v("span", { children: [
																		y("games.parkseurope.fieldSeasonTab"),
																		" ",
																		/* @__PURE__ */ _(Q, { kind: a })
																	] }),
																	e.campfires.includes(n) && /* @__PURE__ */ _("span", { children: y("games.parkseurope.campfireLabel") }),
																	n === 4 && /* @__PURE__ */ _("span", { children: y("games.parkseurope.shutterbug") })
																]
															}),
															/* @__PURE__ */ _("span", {
																className: "pke-route-hikers",
																children: B(n).map((e) => z(e.rid, e.hiker, e.rid + ":" + e.hiker))
															})
														]
													}, n);
												})
											})] }),
											Ce === "end" && /* @__PURE__ */ _(En, {
												pub: e,
												nameOf: I,
												marker: Ke,
												actionName: (e) => y(Un[e])
											}),
											Ce === "season" && /* @__PURE__ */ _(Dn, {
												pub: e,
												name: st
											})
										]
									}),
									/* @__PURE__ */ v("section", {
										className: "pke-panel pke-chalet",
										hidden: W !== "chalet",
										id: "pke-panel-chalet",
										children: [/* @__PURE__ */ _("header", {
											className: "pke-section-head",
											children: /* @__PURE__ */ _("h2", { children: y("games.parkseurope.chaletTrack") })
										}), /* @__PURE__ */ _(wn, {
											pub: e,
											nameOf: I,
											marker: Ke
										})]
									}),
									/* @__PURE__ */ v("section", {
										className: "pke-panel pke-mat",
										hidden: W !== "pack",
										id: "pke-panel-pack",
										children: [/* @__PURE__ */ v("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ _("h2", { children: P.rid === r ? y("games.parkseurope.myMat") : y("games.parkseurope.otherMat", { name: I(P.rid) }) }), P.shutterbug && /* @__PURE__ */ _("span", {
												className: "pke-badge",
												children: y("games.parkseurope.shutterbug")
											})]
										}), /* @__PURE__ */ _(er, {
											p: P,
											t: y,
											name: I(P.rid)
										}, P.rid)]
									}),
									/* @__PURE__ */ v("section", {
										className: "pke-panel pke-hand",
										hidden: W !== "hand",
										id: "pke-panel-hand",
										children: [
											/* @__PURE__ */ v("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ _("h2", { children: y("games.parkseurope.handTitle") }), /* @__PURE__ */ _("span", {
													className: "pke-sub",
													children: t.length
												})]
											}),
											t.length === 0 ? /* @__PURE__ */ _("p", {
												className: "pke-muted",
												children: y("games.parkseurope.handEmpty")
											}) : /* @__PURE__ */ _("div", {
												className: "pke-hand-row pke-wonder-hand",
												children: t.map((e, t) => {
													let n = ae[e], r = k[e];
													return /* @__PURE__ */ _(sn, {
														id: e,
														campEffect: r && y(Kn[r.effect]),
														waiting: !x,
														canUse: (e) => !n?.[e].pay || Xn(b, n[e].pay),
														onPlay: n ? (t) => J({
															type: "playWonder",
															card: e,
															side: t
														}) : void 0
													}, e + ":" + t);
												})
											}),
											e.soloRanks && /* @__PURE__ */ _("p", {
												className: "pke-solo-ranks",
												children: y("games.parkseurope.soloRankTable")
											})
										]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ _(c, {
					open: D === "trailEnd",
					onClose: () => O(null),
					label: y("games.parkseurope.chooseSlot"),
					title: y("games.parkseurope.chooseSlot"),
					children: /* @__PURE__ */ _(En, {
						pub: e,
						nameOf: I,
						marker: Ke,
						actionName: (e) => y(Un[e]),
						onTake: (e, t) => {
							e === "parks" ? J({
								type: "move",
								hiker: Je,
								to: 8,
								slot: { kind: e }
							}) : t && J({
								type: "move",
								hiker: Je,
								to: 8,
								slot: {
									kind: e,
									action: t
								}
							}), O(null);
						}
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "campfire",
					onClose: () => {
						O(null), oe(null);
					},
					label: y("games.parkseurope.occupiedPrompt"),
					title: y("games.parkseurope.occupiedPrompt"),
					children: /* @__PURE__ */ v("div", {
						className: "pke-choice-list",
						children: [A && e.campfires.includes(A.to) && /* @__PURE__ */ _("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								J({
									type: "move",
									hiker: A.hiker,
									to: A.to,
									campfire: "communal"
								}), O(null), oe(null);
							},
							children: y("games.parkseurope.useCommunalCampfire")
						}), A && t.filter((e) => !!k[e]).map((e) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								J({
									type: "move",
									hiker: A.hiker,
									to: A.to,
									campfire: "card",
									card: e
								}), O(null), oe(null);
							},
							children: [
								y("games.parkseurope.useCampfireCard"),
								" · ",
								qt(y, e)
							]
						}, e))]
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "assignWild",
					onClose: () => O(null),
					label: y("games.parkseurope.assignWildPrompt"),
					title: y("games.parkseurope.assignWildPrompt"),
					children: /* @__PURE__ */ _("div", {
						className: "pke-choice-list",
						children: C.filter((e) => b.visited.some((t) => t.suit === e)).map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								J({
									type: "assignWild",
									suit: e
								}), O(null);
							},
							children: y(Bn[e])
						}, e))
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "freePark",
					onClose: () => O(null),
					label: y("games.parkseurope.freeParkPrompt"),
					title: y("games.parkseurope.freeParkPrompt"),
					children: /* @__PURE__ */ v("div", {
						className: "pke-pick-gallery",
						children: [[{
							from: "display",
							ids: e.parksDisplay,
							title: "fieldDisplay"
						}, {
							from: "reserve",
							ids: b.reserved,
							title: "reservedTitle"
						}].filter(({ ids: e }) => e.length > 0).map(({ from: t, ids: n, title: r }) => /* @__PURE__ */ v("section", { children: [/* @__PURE__ */ _("h3", { children: y(`games.parkseurope.${r}`) }), /* @__PURE__ */ _("div", {
							className: "pke-pick-grid",
							children: n.map((n, r) => {
								let i = S[n];
								return /* @__PURE__ */ _(Zt, {
									park: i,
									suitLabel: y(Bn[i.suit]),
									effect: i.instant && y(Gn[i.instant]),
									bonus: t === "display" ? e.parksBonus[r] : null,
									picked: !1,
									free: !0,
									onPick: () => {
										J({
											type: "freePark",
											parkId: n,
											from: t
										}), O(null);
									}
								}, n);
							})
						})] }, t)), /* @__PURE__ */ _("button", {
							type: "button",
							className: "pke-btn pke-btn--quiet",
							disabled: !e.parksDeck,
							onClick: () => {
								J({
									type: "freePark",
									from: "deck"
								}), O(null);
							},
							children: y("games.parkseurope.startDeck")
						})]
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "discardRes",
					onClose: () => O(null),
					label: y("games.parkseurope.discardResPrompt"),
					title: y("games.parkseurope.discardResPrompt"),
					children: /* @__PURE__ */ _("div", {
						className: "pke-choice-list",
						children: Nn.filter((e) => b.res[e] > 0).map((e) => /* @__PURE__ */ v("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								J({
									type: "discardRes",
									res: e
								}), O(null);
							},
							children: [
								/* @__PURE__ */ _(Q, {
									kind: e,
									count: b.res[e]
								}),
								" ",
								y(zn[e])
							]
						}, e))
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "discardWonder",
					onClose: () => O(null),
					label: y("games.parkseurope.discardWonderPrompt"),
					title: y("games.parkseurope.discardWonderPrompt"),
					children: /* @__PURE__ */ _("div", {
						className: "pke-pick-grid pke-wonder-picker",
						children: t.map((e) => {
							let t = k[e];
							return /* @__PURE__ */ v("div", {
								className: "pke-pick-object",
								children: [/* @__PURE__ */ _(sn, {
									id: e,
									campEffect: t && y(Kn[t.effect])
								}), /* @__PURE__ */ _("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									"aria-label": y("games.parkseurope.wonderDiscardName", { name: qt(y, e) }),
									onClick: () => {
										J({
											type: "discardWonder",
											card: e
										}), O(null);
									},
									children: y("games.parkseurope.wonderDiscard")
								})]
							}, e);
						})
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "scoring",
					onClose: () => {
						O(null), ce(null), j({ ...Pn });
					},
					label: y("games.parkseurope.scoringTitle"),
					title: y("games.parkseurope.scoringTitle"),
					children: /* @__PURE__ */ v("div", {
						className: "pke-scoring-sheet",
						children: [mt.length === 0 && /* @__PURE__ */ _("p", {
							className: "pke-muted",
							children: y("games.parkseurope.scoringEmpty")
						}), mt.map((e) => {
							let t = k[e].effect, n = t === "turnAny3" ? 3 : t === "turnAny2" ? 2 : 0, r = se === e;
							return /* @__PURE__ */ v("section", {
								className: "pke-scoring-card",
								"data-on": r,
								children: [/* @__PURE__ */ _(sn, {
									id: e,
									campEffect: y(Kn[t])
								}), t === "turnWildlife2" ? /* @__PURE__ */ _("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: b.res.wildlife < 2,
									onClick: () => J({
										type: "campfireEnd",
										card: e,
										pay: { wildlife: 2 }
									}),
									children: b.res.wildlife < 2 ? y("games.parkseurope.cannotAfford") : y("games.parkseurope.useEffect")
								}) : t === "turnCarabiner" ? /* @__PURE__ */ _("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: b.carabiners < 1,
									onClick: () => J({
										type: "campfireEnd",
										card: e,
										carabiner: !0
									}),
									children: b.carabiners < 1 ? y("games.parkseurope.cannotAfford") : y("games.parkseurope.useEffect")
								}) : r ? /* @__PURE__ */ v(g, { children: [
									/* @__PURE__ */ _("div", {
										className: "pke-pay-row",
										children: Nn.map((e) => /* @__PURE__ */ v("span", {
											className: "pke-pay-res",
											style: { "--pke-res": Yn[e] },
											children: [
												/* @__PURE__ */ _(Z, { kind: e }),
												/* @__PURE__ */ _("button", {
													type: "button",
													"aria-label": `- ${y(zn[e])}`,
													disabled: ue[e] <= 0,
													onClick: () => j((t) => ({
														...t,
														[e]: t[e] - 1
													})),
													children: "−"
												}),
												/* @__PURE__ */ _("b", {
													className: "font-mono tabular-nums",
													children: ue[e]
												}),
												/* @__PURE__ */ _("button", {
													type: "button",
													"aria-label": `+ ${y(zn[e])}`,
													disabled: ue[e] >= b.res[e] || ht >= n,
													onClick: () => j((t) => ({
														...t,
														[e]: t[e] + 1
													})),
													children: "+"
												}),
												/* @__PURE__ */ _("span", {
													className: "pke-sub",
													children: b.res[e]
												})
											]
										}, e))
									}),
									/* @__PURE__ */ v("p", {
										className: "pke-sub",
										children: [
											y("games.parkseurope.scoringPayPrompt", { n }),
											" · ",
											y("games.parkseurope.scoringPayChosen", { n: ht })
										]
									}),
									/* @__PURE__ */ v("div", {
										className: "pke-scoring-actions",
										children: [/* @__PURE__ */ _("button", {
											type: "button",
											className: "pke-btn pke-btn--main",
											disabled: ht !== n,
											onClick: () => {
												J({
													type: "campfireEnd",
													card: e,
													pay: { ...ue }
												}), ce(null), j({ ...Pn });
											},
											children: y("games.parkseurope.scoringPayConfirm")
										}), /* @__PURE__ */ _("button", {
											type: "button",
											className: "pke-btn pke-btn--quiet",
											onClick: () => {
												ce(null), j({ ...Pn });
											},
											children: y("games.parkseurope.scoringPayReset")
										})]
									})
								] }) : /* @__PURE__ */ _("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => {
										ce(e), j({ ...Pn });
									},
									children: y("games.parkseurope.useEffect")
								})]
							}, e);
						})]
					})
				}),
				/* @__PURE__ */ _(c, {
					open: D === "activateCons",
					onClose: () => O(null),
					label: y("games.parkseurope.activateConsPrompt"),
					title: y("games.parkseurope.activateConsPrompt"),
					children: /* @__PURE__ */ v("div", {
						className: "pke-pick-grid",
						children: [ft.length === 0 && /* @__PURE__ */ _("p", {
							className: "pke-muted",
							children: y("games.parkseurope.activateConsEmpty")
						}), ft.map(({ id: e, i: t }) => /* @__PURE__ */ _(ln, {
							id: e,
							name: y(qn[e % 7]),
							site: y("games.parkseurope.projectSite", { resource: y(zn[T(e)]) }),
							benefit: y(Wn[re[e % 7].benefit]),
							supported: !0,
							action: {
								label: y("games.parkseurope.useEffect"),
								onPress: () => {
									J({
										type: "activateCons",
										card: t
									}), O(null);
								}
							}
						}, t))]
					})
				})
			]
		}), e.phase !== "ended" && /* @__PURE__ */ _(bn, {
			frame: Ne,
			timing: Pe,
			self: r,
			nameOf: I
		})]
	});
}
function er({ p: e, t, name: n }) {
	let [r, i] = o(null), a = C.reduce((t, n) => t + e.parkAwards[n], 0) + e.consAwards + e.chaletAwards.length, s = C.find((t) => e.parkAwards[t] > 0), c = e.chaletAwards.at(-1), l = [
		[
			"album",
			"photo",
			"fieldAlbum",
			e.photos + e.albums
		],
		[
			"honors",
			"award",
			"fieldHonors",
			a
		],
		[
			"collection",
			"parks",
			"fieldCollection",
			e.visited.length
		],
		[
			"projects",
			"cons",
			"fieldSupported",
			e.cons.length
		]
	];
	return /* @__PURE__ */ v("div", {
		className: "pke-mat-body",
		"aria-label": n,
		children: [
			/* @__PURE__ */ _(Qt, { player: e }),
			/* @__PURE__ */ v("div", {
				className: "pke-mug-row",
				"aria-label": t("games.parkseurope.mug.level", { n: e.mug }),
				children: [
					/* @__PURE__ */ _(Z, { kind: "mug" }),
					/* @__PURE__ */ _("span", { children: t("games.parkseurope.mug.track") }),
					[
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ _("i", {
						className: "pke-mug-pip",
						"data-on": e.mug >= t,
						"aria-hidden": !0
					}, t))
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "pke-player-objects",
				role: "group",
				"aria-label": t("games.parkseurope.fieldPlayerItems"),
				children: l.map(([e, n, a, o]) => /* @__PURE__ */ v("button", {
					type: "button",
					"data-object": e,
					"data-empty": !o,
					"aria-expanded": r === e,
					"aria-controls": "pke-player-object",
					onClick: () => i(r === e ? null : e),
					children: [/* @__PURE__ */ _("span", {
						className: "pke-object-pose",
						"aria-hidden": !0,
						children: e === "album" ? /* @__PURE__ */ _(nn, {}) : e === "honors" ? s ? /* @__PURE__ */ _($, { award: {
							kind: "parks",
							suit: s,
							count: 1
						} }) : c === void 0 ? /* @__PURE__ */ _($, { award: {
							kind: "cons",
							count: 1
						} }) : /* @__PURE__ */ _($, { award: {
							kind: "chalet",
							points: c
						} }) : /* @__PURE__ */ _("span", {
							className: "pke-object-stack",
							children: /* @__PURE__ */ _(Z, { kind: n })
						})
					}), /* @__PURE__ */ v("span", {
						className: "pke-object-label",
						children: [t(`games.parkseurope.${a}`), o > 0 && /* @__PURE__ */ _("b", { children: o })]
					})]
				}, e))
			}),
			/* @__PURE__ */ v("div", {
				id: "pke-player-object",
				hidden: r === null,
				children: [
					r === "album" && /* @__PURE__ */ v("div", {
						className: "pke-player-album",
						children: [/* @__PURE__ */ v("div", {
							className: "pke-photo-pieces",
							children: [Array.from({ length: e.photos }, (e, t) => /* @__PURE__ */ _("span", { children: /* @__PURE__ */ _(Z, { kind: "photo" }) }, "photo" + t)), Array.from({ length: e.albums }, (e, t) => /* @__PURE__ */ _("span", { children: /* @__PURE__ */ _(nn, {}) }, "album" + t))]
						}), /* @__PURE__ */ v("p", { children: [
							t("games.parkseurope.photos", { n: e.photos }),
							" · ",
							t("games.parkseurope.albums", { n: e.albums })
						] })]
					}),
					r === "honors" && /* @__PURE__ */ _(tn, { player: e }),
					r === "collection" && (e.visited.length ? /* @__PURE__ */ _("div", {
						className: "pke-card-row",
						children: e.visited.map(({ id: e, suit: n }) => {
							let r = S[e];
							return /* @__PURE__ */ _(Zt, {
								park: r,
								suitLabel: t(Bn[n ?? r.suit]),
								picked: !1,
								effect: r.instant ? t(Gn[r.instant]) : void 0
							}, e);
						})
					}) : /* @__PURE__ */ _("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					})),
					r === "projects" && (e.cons.length ? /* @__PURE__ */ _("div", {
						className: "pke-card-row pke-project-row",
						children: e.cons.map((e, n) => /* @__PURE__ */ _(ln, {
							id: e,
							name: t(qn[e % 7]),
							site: t("games.parkseurope.projectSite", { resource: t(zn[T(e)]) }),
							benefit: t(Wn[re[e % 7].benefit]),
							supported: !0
						}, e + ":" + n))
					}) : /* @__PURE__ */ _("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					}))
				]
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var tr = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], nr = {
	mountain: 1.1,
	forest: 1,
	sun: .9,
	water: .9,
	wildlife: 1.4
}, rr = {
	parks: 4.2,
	mug: 2.8,
	photo: 1.4,
	die: 1.6,
	wonder: 1.6,
	wildlife: 1.2,
	carabiner: 1.3
}, ir = {
	conservation: 2.8,
	mug: 2.8,
	chalet: 1.6,
	carabiner: 1.4
}, ar = {
	wonder: 1.6,
	sunwater: 1.7,
	photo: 1.7,
	conservation: 2.2,
	mug: 2.4,
	wildlife: 1.2
}, or = {
	album: 3,
	wonderHand: 2,
	turnAny2: 3,
	turnAny3: 3,
	turnWildlife2: 1,
	turnCarabiner: 2,
	anyIcons: 2,
	consForest: 1.5,
	consMountain: 1.5,
	consSun: 1.5,
	consWater: 1.5,
	iconForest: 1.5,
	iconMountain: 1.5,
	iconSun: 1.5,
	iconWater: 1.5,
	snow: 1
};
function sr() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function cr(e, t) {
	return t && e.length > 1 && sr() < .3 ? e[Math.floor(sr() * e.length)] : e[0];
}
function lr(e) {
	return e.sort((e, t) => t.score - e.score);
}
function ur(e, t) {
	return e.players.find((e) => e.rid === t);
}
function dr(e, t) {
	let n = 0;
	for (let r of e.players) for (let e of r.hikers) e === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function fr(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, r = 0;
	for (let e of Object.keys(t)) {
		let i = t[e] ?? 0;
		e === "wildlife" ? r = i : n[e] = i;
	}
	if (e.res.wildlife < r) return !1;
	let i = e.res.wildlife - r, a = 0;
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a += Math.max(0, n[t] - e.res[t]);
	if (i < a) return !1;
	let o = n.mountain + n.forest + n.sun + n.water + r + a;
	return tr.reduce((t, n) => t + e.res[n], 0) - o >= n.any;
}
function pr(e) {
	let t = 0;
	for (let n of Object.keys(e)) {
		let r = e[n] ?? 0;
		t += n === "any" ? r * 1 : n === "wildlife" ? r * 1.3 : r * nr[n];
	}
	return t;
}
function mr(e) {
	return e ? e === "photo" ? 1.2 : e === "carabiner" ? 1.3 : e === "snow" ? .7 : nr[e] : 0;
}
function hr(e, t) {
	return t === null ? null : e.vf[t - 1] ?? null;
}
function gr(e, t) {
	let n = e.visited.filter((e) => e.suit === t).length;
	return n % 3 == 2 ? 2.2 : n % 3 == 1 ? .4 : 0;
}
function _r(e, t) {
	let n = S[t];
	if (!n) return 0;
	let r = n.points;
	if (n.instant) {
		let t = n.instant;
		r += t === "photo" ? e.shutterbug ? 2 : 1 : t === "mug" ? 2.2 : t === "wonder" ? 1.3 : t === "chalet" || t === "die" ? 1.2 : t === "carabiner" ? 1 : t === "wildlife" ? .8 : .6;
	}
	if (n.suit === "wild") {
		let t = C.reduce((t, n) => Math.max(t, gr(e, n)), 0);
		r += t;
	} else r += gr(e, n.suit);
	return r;
}
function vr(e, t, n) {
	switch (e) {
		case "core-forest": return nr.forest;
		case "core-sun": return nr.sun * 2;
		case "core-mountain": return nr.mountain + .7;
		case "core-water": return nr.water * 2 + .7;
		case "wildlife": return nr.wildlife;
		case "carabiner": return 1.6;
		case "parks": return 4.2;
		case "die": return 1.7;
		case "photo": return t.shutterbug ? 2.4 : 1.4;
		case "mug": return t.mug >= 3 ? 3.4 : 2.6;
		case "chalet": return .6 + t.snow * 1;
		case "wonder": return 1.6;
		case "conservation": {
			let e = [...new Set(t.cons.map((e) => T(e)))];
			return 2.6 + (n.consAwardsLeft > 0 && e.length < 4 ? .7 : 0);
		}
	}
}
function yr(e) {
	return e.filter((e) => !!ae[e]);
}
function br(e, t, n) {
	let r = ae[t];
	if (!r) return null;
	let i = r[n];
	if (i.pay && !fr(e, i.pay)) return null;
	let a = 0;
	for (let t of i.grants) switch (t.t) {
		case "res":
			a += nr[t.res] * t.n;
			break;
		case "snow":
			a += .7 * t.n;
			break;
		case "carabiner":
			a += 1.3 * t.n;
			break;
		case "photo":
			a += (e.shutterbug ? 1.8 : 1.1) * t.n;
			break;
		case "wonder":
			a += 1.5 * t.n;
			break;
		case "die":
			a += 1.6 * t.n;
			break;
		case "parks":
			a += 4.2;
			break;
		case "mug":
			a += 2.6;
			break;
		case "cons":
			a += 2.6;
			break;
		case "chalet":
			a += .6 + e.snow;
			break;
		case "shutterbug": a += e.shutterbug ? .8 : 2.4;
	}
	return a - (i.pay ? pr(i.pay) : 0);
}
function xr(e, t) {
	let n = ir[e];
	return t ? n + 4.2 : n;
}
function Sr(e) {
	let t = [];
	for (let n of e.endSlots) n.rid === null && t.push({
		v: {
			kind: n.kind,
			action: n.action
		},
		score: xr(n.action, n.kind === "both")
	});
	return t.push({
		v: { kind: "parks" },
		score: 4.2
	}), lr(t), t[0].v;
}
function Cr(e, t, n) {
	let r = [], i = new Set(e.cons.map((e) => T(e)));
	return t.consDisplay.forEach((t, a) => {
		let o = T(t), s = n ? {} : ne[o];
		if (!n && !fr(e, s)) return;
		let c = rr[wr(t)];
		i.has(o) || (c += 1.6), c -= pr(s) * .2, r.push({
			v: {
				type: "consPick",
				index: a
			},
			score: c
		});
	}), r.length > 0 ? (lr(r), r[0].v) : t.consDeck > 0 && (n || fr(e, {
		sun: 1,
		water: 1
	})) ? {
		type: "consPick",
		deck: !0
	} : { type: "skip" };
}
function wr(e) {
	return [
		"die",
		"parks",
		"mug",
		"wonder",
		"photo",
		"wildlife",
		"carabiner"
	][e % 7];
}
function Tr(e, t) {
	let n = [];
	for (let r of t.parksDisplay) n.push({
		v: {
			type: "freePark",
			parkId: r,
			from: "display"
		},
		score: _r(e, r)
	});
	for (let t of e.reserved) n.push({
		v: {
			type: "freePark",
			parkId: t,
			from: "reserve"
		},
		score: _r(e, t)
	});
	return n.length > 0 ? (lr(n), n[0].v) : {
		type: "freePark",
		from: "deck"
	};
}
function Er(e, t, n, r) {
	let i = [];
	for (let r of [0, 1]) {
		let a = t.hikers[r];
		if (!(a >= 8)) for (let o = a + 1; o <= 7; o++) {
			let a = dr(e, o) > 0, s = null, c;
			if (a) {
				if (e.campfires.includes(o)) s = "communal";
				else {
					let e = n.filter((e) => !!k[e]);
					if (e.length === 0) continue;
					s = "card", c = e[0];
				}
			}
			let l = vr(e.trailSites[o - 1], t, e);
			l += mr(e.trailBonus[o - 1]), o === 4 && (l += 1);
			let u = hr(e, o);
			u && t.carabiners > 0 && (l += ar[u] + .7 - 1.2), s === "communal" ? l -= 2 : s === "card" && (l -= 2.5);
			let d = {
				type: "move",
				hiker: r,
				to: o
			};
			s && (d.campfire = s), c && (d.card = c), i.push({
				v: d,
				score: l
			});
		}
	}
	return i.length > 0 ? cr(lr(i).map((e) => e.v), r) : {
		type: "move",
		hiker: [0, 1].find((e) => t.hikers[e] < 8) ?? 0,
		to: 8,
		slot: Sr(e)
	};
}
function Dr(e) {
	return {
		type: "discardRes",
		res: [...tr].sort((t, n) => e.res[n] - e.res[t])[0]
	};
}
function Or(e, t) {
	let n = [
		"sun",
		"water",
		"forest",
		"mountain",
		"wildlife"
	], r = {}, i = t;
	for (let t of n) {
		let n = Math.min(i, e.res[t]);
		if (n > 0 && (r[t] = n, i -= n), i === 0) return r;
	}
	return null;
}
function kr(e, t, n) {
	let r = new Set(e.campfireUsed), i = n.filter((e) => !!k[e] && !r.has(e)), a = (e) => k[e].effect;
	for (let e of i) if (a(e) === "turnWildlife2" && t.res.wildlife >= 2) return {
		type: "campfireEnd",
		card: e,
		pay: { wildlife: 2 }
	};
	for (let e of i) if (a(e) === "turnCarabiner" && t.carabiners >= 1) return {
		type: "campfireEnd",
		card: e,
		carabiner: !0
	};
	for (let e of i) {
		if (a(e) !== "turnAny3") continue;
		let n = Or(t, 3);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	for (let e of i) {
		if (a(e) !== "turnAny2") continue;
		let n = Or(t, 2);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	return { type: "scoringDone" };
}
function Ar(e, t) {
	let n = t.filter((e) => !!ae[e]);
	if (n.length > 0) {
		let t = n[0], r = Infinity;
		for (let i of n) {
			let n = br(e, i, "top") ?? -Infinity, a = br(e, i, "bottom") ?? -Infinity, o = Math.max(n, a);
			o < r && (r = o, t = i);
		}
		return {
			type: "discardWonder",
			card: t
		};
	}
	return {
		type: "discardWonder",
		card: t.filter((e) => !!k[e]).sort((e, t) => (or[k[e].effect] ?? 0) - (or[k[t].effect] ?? 0))[0] ?? t[0]
	};
}
var jr = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.turn !== t.rid) return null;
	let i = ur(n, t.rid);
	if (!i) return null;
	let a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "scoring") return { action: kr(n, i, o) };
	if (n.phase !== "turn") return null;
	if (n.pending === "gretaColor") return { action: {
		type: "gretaColor",
		first: a && sr() < .5 ? 1 : 0
	} };
	let s = t.memory ?? {};
	if (n.pending === "move") return {
		action: Er(n, i, o, a),
		memory: {}
	};
	if (n.pending === "trailEnd") return {
		action: {
			type: "move",
			hiker: [0, 1].find((e) => i.hikers[e] < 8) ?? 0,
			to: 8,
			slot: Sr(n)
		},
		memory: {}
	};
	if (n.pending === "parks") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let r of n.parksDisplay) {
			if (t.has(r)) continue;
			t.add(r);
			let n = S[r];
			n && fr(i, n.cost) && e.push({
				v: r,
				score: _r(i, r)
			});
		}
		for (let n of i.reserved) {
			if (t.has(n)) continue;
			t.add(n);
			let r = S[n];
			r && fr(i, r.cost) && e.push({
				v: n,
				score: _r(i, n)
			});
		}
		if (e.length > 0) return lr(e), {
			action: {
				type: "visit",
				parkId: cr(e, a).v
			},
			memory: { parks: !0 }
		};
		if (s.parks) return {
			action: { type: "parksDone" },
			memory: {}
		};
		let r = [];
		return n.parksDisplay.forEach((e, t) => r.push({
			index: t,
			score: _r(i, e)
		})), r.length > 0 ? (r.sort((e, t) => t.score - e.score), {
			action: {
				type: "reserve",
				from: "display",
				index: r[0].index
			},
			memory: {}
		}) : n.parksDeck > 0 ? {
			action: {
				type: "reserve",
				from: "deck"
			},
			memory: {}
		} : {
			action: { type: "parksDone" },
			memory: {}
		};
	}
	if (n.pending === "mug") return i.mug >= 3 ? {
		action: {
			type: "mug",
			act: "drink"
		},
		memory: s
	} : {
		action: {
			type: "mug",
			act: "fill"
		},
		memory: s
	};
	if (n.pending === "mugChoice") return {
		action: {
			type: "mugChoice",
			choice: .6 + i.snow + (i.chaletPos < 15 ? .4 : 0) >= 2.6 ? "chalet" : "cons"
		},
		memory: s
	};
	if (n.pending === "cons") return {
		action: Cr(i, n, n.freeCons),
		memory: s
	};
	if (n.pending === "assignWild") {
		let e = [];
		for (let t of C) {
			let n = i.visited.filter((e) => e.suit === t).length;
			n !== 0 && e.push({
				suit: t,
				score: gr(i, t) * 2 + n * .1
			});
		}
		return e.sort((e, t) => t.score - e.score), {
			action: {
				type: "assignWild",
				suit: e[0].suit
			},
			memory: s
		};
	}
	if (n.pending === "freePark") return {
		action: Tr(i, n),
		memory: s
	};
	if (n.pending === "discardRes") return {
		action: Dr(i),
		memory: s
	};
	if (n.pending === "discardWonder") return {
		action: Ar(i, o),
		memory: s
	};
	if (n.pending === "actions") {
		if (n.end && !n.end.topDone && n.end.action) return {
			action: { type: "endTop" },
			memory: s
		};
		if (n.end && !n.end.parksDone) return {
			action: { type: "endParks" },
			memory: s
		};
		let e = n.landingSite === null ? null : n.trailSites[n.landingSite - 1];
		if (!n.siteDone && e) return {
			action: { type: "siteAction" },
			memory: s
		};
		let t = e ? le(e) : null;
		if (t) {
			let e = i.cons.findIndex((e, r) => T(e) === t && !n.consUsed.includes(r));
			if (e >= 0) return {
				action: {
					type: "activateCons",
					card: e
				},
				memory: s
			};
		}
		let r = hr(n, n.landingSite);
		if (r && !n.vfUsed && i.carabiners > 0 && ar[r] + .7 > 1.2) return {
			action: { type: "viaFerrata" },
			memory: s
		};
		let a = [];
		for (let e of yr(o)) for (let t of ["top", "bottom"]) {
			let n = br(i, e, t);
			n !== null && a.push({
				v: {
					type: "playWonder",
					card: e,
					side: t
				},
				score: n
			});
		}
		let c = lr(a)[0];
		return c && c.score > .8 ? {
			action: c.v,
			memory: s
		} : {
			action: { type: "endTurn" },
			memory: {}
		};
	}
	return null;
}, Mr = [
	{
		key: "parks",
		label: "games.parkseurope.visitedTitle"
	},
	{
		key: "campfire",
		label: "games.parkseurope.wonder.campfireCard"
	},
	{
		key: "endgame",
		label: "games.parkseurope.scoringTitle"
	},
	{
		key: "photos",
		label: "games.parkseurope.token.photo"
	},
	{
		key: "parkAwards",
		label: "games.parkseurope.resultParkAwards"
	},
	{
		key: "cons",
		label: "games.parkseurope.consTitle"
	},
	{
		key: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		key: "photoAward",
		label: "games.parkseurope.resultPhotoAward"
	}
], Nr = [
	"games.parkseurope.rank.none",
	"games.parkseurope.rank.r1",
	"games.parkseurope.rank.r2",
	"games.parkseurope.rank.r3",
	"games.parkseurope.rank.r4",
	"games.parkseurope.rank.r5"
];
function Pr({ public: e, result: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: c }) {
	let u = l(), d = e, [p, m] = o(!0), h = (e) => d.finalRows?.find((t) => t.rid === e)?.total ?? t.scores?.[e], g = (e) => n.find((t) => t.rid === e), y = (e) => f[(g(e)?.colorIndex ?? Math.max(0, d.order.indexOf(e))) % f.length], x = (e) => g(e)?.name || u(y(e).nameKey), ee = d.soloRanks && h(r) !== void 0 ? d.soloRanks.reduce((e, t) => (h(r) ?? 0) >= t.at ? Math.max(e, t.rank) : e, 0) : null;
	return /* @__PURE__ */ v("div", {
		className: "pke-recap-root pke-screen",
		children: [
			/* @__PURE__ */ _("div", {
				className: "pke-recap-scene",
				inert: p,
				children: /* @__PURE__ */ _(Qn, {
					public: d,
					members: n,
					myRid: r,
					send: () => {}
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "pke-recap-overlay",
				hidden: !p,
				children: /* @__PURE__ */ v("section", {
					className: "pke-recap",
					"aria-label": u("games.parkseurope.journeyEnd"),
					children: [
						/* @__PURE__ */ v("header", {
							className: "pke-recap-header",
							children: [
								/* @__PURE__ */ _(Z, { kind: "mountain" }),
								/* @__PURE__ */ _("h1", { children: u("games.parkseurope.journeyEnd") }),
								ee !== null && /* @__PURE__ */ _("strong", { children: u(Nr[ee] ?? Nr[0]) }),
								/* @__PURE__ */ _("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => m(!1),
									children: u("games.parkseurope.reviewTable")
								})
							]
						}),
						/* @__PURE__ */ v("div", {
							className: "pke-score-scroll",
							children: [
								/* @__PURE__ */ _("div", {
									className: "pke-recap-roster",
									children: t.ranking.map((e) => {
										let n = d.players.find((t) => t.rid === e), r = d.finalRows?.find((t) => t.rid === e);
										return /* @__PURE__ */ v("article", {
											className: "pke-recap-seat",
											"data-winner": t.winner.includes(e),
											style: { "--pke-seat": y(e).hex },
											children: [/* @__PURE__ */ v("div", {
												className: "pke-recap-identity",
												children: [
													/* @__PURE__ */ _("img", {
														src: s[(g(e)?.avatar ?? 0) % s.length],
														alt: ""
													}),
													/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("strong", { children: x(e) }), t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ _("small", { children: u("games.parkseurope.journeyWinner") })] }),
													/* @__PURE__ */ _("b", { children: h(e) ?? "—" })
												]
											}), n && /* @__PURE__ */ v("div", {
												className: "pke-recap-awards",
												children: [
													C.filter((e) => n.parkAwards[e]).map((e) => /* @__PURE__ */ _($, { award: {
														kind: "parks",
														suit: e,
														count: n.parkAwards[e]
													} }, e)),
													n.consAwards > 0 && /* @__PURE__ */ _($, { award: {
														kind: "cons",
														count: n.consAwards
													} }),
													n.chaletAwards.map((e, t) => /* @__PURE__ */ _($, { award: {
														kind: "chalet",
														points: e
													} }, t)),
													(r?.photoAward ?? 0) > 0 && /* @__PURE__ */ _($, { award: { kind: "photo" } })
												]
											})]
										}, e);
									})
								}),
								/* @__PURE__ */ v("table", {
									className: "pke-score-table",
									children: [
										/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "col",
											children: u("games.parkseurope.scoreItem")
										}), t.ranking.map((e) => /* @__PURE__ */ _("th", {
											scope: "col",
											"data-winner": t.winner.includes(e),
											children: /* @__PURE__ */ v("span", {
												className: "pke-score-player",
												style: { "--pke-seat": y(e).hex },
												children: [
													/* @__PURE__ */ _("img", {
														src: s[(g(e)?.avatar ?? 0) % s.length],
														alt: ""
													}),
													/* @__PURE__ */ _("span", { children: x(e) }),
													t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ _("b", { children: u("games.parkseurope.journeyWinner") })
												]
											})
										}, e))] }) }),
										d.finalRows && /* @__PURE__ */ _("tbody", { children: Mr.map(({ key: e, label: n }) => /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "row",
											children: u(n)
										}), t.ranking.map((t) => /* @__PURE__ */ _("td", { children: d.finalRows?.find((e) => e.rid === t)?.[e] ?? "—" }, t))] }, e)) }),
										/* @__PURE__ */ _("tfoot", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "row",
											children: u("games.parkseurope.resultTotal")
										}), t.ranking.map((e) => /* @__PURE__ */ _("td", { children: h(e) ?? "—" }, e))] }) })
									]
								}),
								i !== void 0 && /* @__PURE__ */ _("p", { children: u("session.hint.usedCount", { n: i }) }),
								t.ranking.map((e) => {
									let n = t.autopilot?.[e];
									return n ? /* @__PURE__ */ v("p", { children: [
										x(e),
										" · ",
										u("session.autopilot.share", { n: Math.round(n * 100) })
									] }, e) : null;
								})
							]
						}),
						/* @__PURE__ */ v("footer", {
							className: "pke-recap-actions",
							children: [
								a && /* @__PURE__ */ _(b, {
									compact: !0,
									label: u("session.result.playAgain"),
									confirmLabel: u("games.parkseurope.confirmAgain"),
									onConfirm: a
								}),
								c && /* @__PURE__ */ _(b, {
									compact: !0,
									label: u("session.result.backToLobby"),
									confirmLabel: u("games.parkseurope.confirmLobby"),
									onConfirm: c
								}),
								!a && !c && /* @__PURE__ */ _("span", { children: u("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "pke-btn pke-btn--main pke-recap-restore",
				hidden: p,
				onClick: () => m(!0),
				children: u("games.parkseurope.returnScores")
			})
		]
	});
}
//#endregion
//#region src/game/game-over-row.tsx
var Fr = {
	1: "games.parkseurope.rank.r1",
	2: "games.parkseurope.rank.r2",
	3: "games.parkseurope.rank.r3",
	4: "games.parkseurope.rank.r4",
	5: "games.parkseurope.rank.r5"
};
function Ir({ public: e, rid: t }) {
	let n = l(), r = e, i = r.finalRows?.find((e) => e.rid === t);
	if (!i) return null;
	let a = [
		{
			key: "games.parkseurope.over.parks",
			n: i.parks
		},
		{
			key: "games.parkseurope.over.campfire",
			n: i.campfire
		},
		{
			key: "games.parkseurope.over.endgame",
			n: i.endgame
		},
		{
			key: "games.parkseurope.over.photos",
			n: i.photos
		},
		{
			key: "games.parkseurope.over.parkAwards",
			n: i.parkAwards
		},
		{
			key: "games.parkseurope.over.cons",
			n: i.cons
		},
		{
			key: "games.parkseurope.over.chalet",
			n: i.chalet
		},
		{
			key: "games.parkseurope.over.photoAward",
			n: i.photoAward
		}
	], o = null;
	if (r.soloRanks) {
		let e = 0;
		for (let t of r.soloRanks) i.total >= t.at && (e = Math.max(e, t.rank));
		o = n(Fr[e] ?? "games.parkseurope.rank.none");
	}
	return /* @__PURE__ */ v("div", {
		className: "mt-1.5 flex flex-wrap gap-1",
		children: [
			a.map(({ key: e, n: t }) => /* @__PURE__ */ _("span", {
				className: "rounded border border-ink/30 bg-paper px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums",
				children: n(e, { n: t })
			}, e)),
			/* @__PURE__ */ _("span", {
				className: "rounded border border-ink/30 bg-done-soft px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-done-ink",
				children: n("games.parkseurope.over.total", { n: i.total })
			}),
			o && /* @__PURE__ */ _("span", {
				className: "rounded border border-ink/30 bg-info-soft px-1.5 py-0.5 text-[10px] font-bold text-info-ink",
				children: n("games.parkseurope.over.rank", { name: o })
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Lr({ value: e, onChange: t }) {
	let n = l(), r = De.safeParse(e), i = r.success ? r.data : De.parse(void 0);
	return /* @__PURE__ */ _(ee, {
		title: n("games.parkseurope.name"),
		children: /* @__PURE__ */ _(x, {
			name: "parkseurope-greta",
			value: "greta",
			checked: i.greta,
			label: n("games.parkseurope.opt.greta"),
			hint: n("games.parkseurope.opt.gretaHint"),
			accent: ge.accent,
			onChange: () => t({
				...i,
				greta: !i.greta
			})
		})
	});
}
//#endregion
//#region src/index.tsx
var Rr = {
	definition: Ut,
	View: Qn,
	bot: jr,
	OverView: Pr,
	RowView: Ir,
	Options: Lr,
	locales: {
		zh: {
			name: "Parks Europe",
			parkNames: {
				p0: "湖区",
				p1: "欧洲之峰",
				p2: "瓦特纳冰川",
				p3: "卡朗克",
				p4: "萨马里亚",
				p5: "里拉",
				p6: "尤通黑门",
				p7: "五渔村",
				p8: "塔特拉",
				p9: "瑞士国家公园",
				p10: "洛蒙德湖与特罗萨克斯",
				p11: "约斯特达尔冰川",
				p12: "康尼马拉",
				p13: "哈当厄尔高原",
				p14: "泰斯",
				p15: "特里格拉夫",
				p16: "贝希特斯加登",
				p17: "雷泰扎特",
				p18: "阿布鲁佐、拉齐奥与莫利塞",
				p19: "拉马达莱娜群岛",
				p20: "格雷梅",
				p21: "比利牛斯",
				p22: "萨雷克",
				p23: "蒂曼法亚",
				p24: "贝卢诺多洛米蒂",
				p25: "高陶恩",
				p26: "辛格韦德利",
				p27: "瓦登海",
				p28: "皮林",
				p29: "奥兰卡",
				p30: "基拉尼",
				p31: "杜米托尔",
				p32: "高亚",
				p33: "多尼亚纳",
				p34: "埃克兰",
				p35: "维科斯—阿奥斯",
				p36: "奥林匹斯山",
				p37: "奥尔德萨与佩尔迪多山",
				p38: "十六湖",
				p39: "泰德",
				p40: "佩内达—热尔",
				p41: "格泽瑟",
				p42: "克尔卡",
				p43: "阿比斯库",
				p44: "萨克森瑞士",
				p45: "布特林特",
				p46: "凯恩戈姆山",
				p47: "峰区"
			},
			wonderNames: {
				b01: "野趣之旅",
				b02: "细品日出",
				b03: "沐浴晨光",
				b04: "尽享森林",
				b05: "林中漫步",
				b06: "骑游山野",
				b07: "探访荒野",
				b08: "晴空畅怀",
				b09: "守护群峰",
				b10: "回望旅途",
				b11: "步道奇遇",
				b12: "畅游清水",
				b13: "涉过山溪",
				b14: "扣紧攀登",
				b16: "定格此刻",
				b17: "随心漫游",
				b18: "登山而上",
				b19: "攀上顶峰",
				b20: "守护林木",
				b21: "清理河岸"
			},
			campfireCardName: "营火卡 {{n}}",
			selectedHiker: "已选",
			desc: "用三个赛季走遍欧洲的国家公园，收集资源、留宿小屋、拍摄照片并支持保护工程，终局比拼得分",
			rules: "目标:\n每名玩家率领两名旅人，在欧洲的国家公园步道上徒步三个赛季。沿途收集资源与照片、访问国家公园、完成保护工程，并在终局结算中获得最高总分的玩家获胜。\n准备:\n· 每名玩家取一块板面，把两枚旅人放在步道起点，把马克杯标记放在马克杯轨道最下方，并取得一枚登山扣。\n· 将所有玩家的小屋标记随机叠放在小屋赛道的起点。\n· 每名玩家从奇迹牌堆抽取一张奇迹卡，作为手牌的开始。\n· 洗混公园卡与保护卡，各翻开三张组成展示区。按人数准备公共营火：三人及以下使用一枚，四人使用两枚，五人使用三枚。\n· 每个赛季开始时翻开一张赛季卡，按卡面把公共营火与赛季奖励资源放到对应站点。小屋标记最靠前的玩家先手，同格时叠在最上面的玩家先手。\n回合:\n每名玩家轮流行动，直到所有旅人都抵达步道终点，该赛季结束。三个赛季结束后进行终局结算。\n· 行动时，选择一名尚未抵达终点的旅人，把它向前移动到任意一个更靠后的站点，并获得该站点的行动与赛季奖励资源。旅人不能后退，也不能跳过自己的回合。\n· 站点上已有其他旅人时不能直接停留，除非使用点上的公共营火，或弃掉手中一张营火奇迹卡。\n· 你可以放弃站点的主要行动，仍可进行铁索攀登、打出奇迹卡或激活保护卡。\n· 抵达站点后，你可以按任意顺序执行站点的主要行动、进行铁索攀登、打出任意张奇迹卡和激活保护卡。\n· 回合结束时，手牌上限为三张奇迹卡，登山扣上限为三枚；资源区容量为十二格，每枚雪占用两格，超出的非雪资源必须弃回供应区。\n营地与营火:\n· 公共营火每个赛季开始时按人数放置，使用后回到供应区，该赛季不再补充。\n· 营火奇迹卡在终局计分时仍留在手中结算，也可以在此之前弃掉用来占据已有旅人的站点。\n步道站点:\n· 四块核心站点分别提供森林、太阳、山峰与水域资源；山峰与水域站点同时提供一枚雪。\n· 进阶站点提供野生动物、登山扣、公园行动、掷步道骰、拍照、马克杯行动、小屋行动、奇迹卡与保护工程。\n· 中央站点固定印有快门虫图标，旅人抵达时立即取得快门虫。\n步道终点:\n· 终点分为区域：第一排是四种单独行动，每个位置只能容纳一名旅人；中间是公园行动，可以容纳任意多旅人；第二排同时提供上方行动与公园行动，每个位置只能容纳一名旅人。\n· 落在第二排时必须完成上方行动与公园行动，两者的先后顺序由你决定。\n· 终点不能使用营火共享位置。两名旅人都抵达终点后，该玩家的徒步到此结束。\n· 若轮到你行动时其他旅人都已离开步道，你必须立即前往终点，并照常选择终点位置。\n铁索攀登\n· 除中央站点外，每个站点上方都有一块铁索攀登板块。抵达站点后，你可以上交一枚登山扣，领取该板块的奖励，并额外获得一枚雪。\n· 你每回合可以进行一次铁索攀登，时机可选在站点主要行动之前或之后。\n国家公园:\n· 公园行动可以选择预留，或访问任意多张公园卡。预留时从展示区取一张，或直接抽取牌堆顶一张，放在自己的预留区。\n· 访问时支付公园卡上标注的资源。野生动物可以代替任意一种普通资源；带有「任意」图标的费用可以用任何资源支付。\n· 公园卡按花色叠放在板面右侧。每叠满三张同花色公园，立即取得该花色的公园奖章与印刷的即时奖励；奖章在终局按该花色公园数量计分。\n· 野性公园不属于四种花色。取得时把它并入任意一个已有花色的公园叠；若尚未拥有任何花色，则并入下一张取得的有色公园。\n· 展示区取走或弃掉卡牌后不会立即补入；到回合结束时再从牌库补满，已有卡牌先向右滑动，新卡从左侧补入，最右侧始终是最老的卡牌。\n步道骰与快门虫:\n· 步道骰的六个面分别提供登山扣、野生动物、山与水、抽奇迹卡、拍照、太阳与森林。\n· 持有快门虫时，你回合中的每次拍照行动额外获得一张照片；快门虫可以由旅人抵达中央站点或由部分卡牌获得。\n照片:\n· 每张照片在终局计一分。集满五张照片时换成一本相册，相册在终局计五分。\n· 终局时拍摄照片总数最多的玩家额外获得照片奖章，价值三分；平局时小屋赛道更靠前的玩家获胜。单人模式不使用照片奖章。\n马克杯:\n· 马克杯行动可以填充或饮用。填充时把标记向上移动一格，最多到达顶端；饮用时结算标记所在档位的奖励，并把标记移回最下方。\n· 第一档可以选择执行一次小屋行动，或免费支持一张保护工程。\n· 第二档掷三次步道骰并获得全部结果。\n· 第三档免费访问一张公园，来源可以是展示区、预留区或牌堆顶。\n保护工程:\n· 保护行动可以选择支持一张展示区中的保护卡，或支付一枚太阳与一枚水，从牌堆顶取得一张。\n· 取得保护卡后，只能在对应颜色的核心站点激活它的效果。每回合每张保护卡可以激活一次，多张保护卡的激活顺序自定，也可以安排在站点主要行动之前或之后。\n· 若在当前站点取得颜色相同的保护卡，可以立即激活这一张。\n· 集齐四种颜色的保护卡时取得一枚保护奖章，价值五分。\n小屋:\n· 小屋行动上交自己板面上的全部雪，沿小屋赛道前进与雪数量相同的雪格。\n· 经过奇迹格时抽取一张奇迹卡；经过奖章格时取得该位置最有价值的一枚奖章，奖章堆为空时改为抽取一张奇迹卡。\n· 小屋令牌停止在已有令牌的格子上时叠放在最上方。赛道走到尽头后仍可上交雪，但不再前进。\n· 小屋赛道在终局计分中用于打破平局，越靠前越优先，同格时叠在上方者优先。\n奇迹卡:\n· 基础奇迹卡有上下两种即时行动，支付卡面左侧的资源后获得右侧的奖励。\n· 营火奇迹卡可以弃掉来占据已有旅人的站点；终局计分时按效果获得分数，部分卡牌还可以上交资源换取分数。\n赛季与终局:\n· 赛季开始时重新铺设步道，把新的三块进阶站点与四块核心站点洗混后放到七个位置，并放置新的公共营火与赛季奖励。\n· 三个赛季结束后先进入终局结算：每名玩家可以自行决定是否用手中的营火奇迹卡上交资源换取分数，也可以放弃。\n· 营火效果与资源结算完成后，依次计算到访公园、营火奇迹卡的固定效果、照片与相册、公园奖章、保护奖章与小屋奖章；照片奖章在全部营火效果之后才计算。\n· 公园奖章每枚按同花色到访公园的数量计分，保护奖章与相册各计五分，照片按张计分，小屋奖章按其面值计分（3、4 或 5 分）。总分最高的玩家获胜。\n护林员格蕾塔:\n· 单人模式与双人挑战中，护林员格蕾塔会加入徒步。她始终最后行动，按步道骰结果移动自己的旅人。\n· 蝴蝶面移动队伍中靠后的旅人，花朵面移动靠前的旅人；点数表示可以前进到的第几个可用站点。\n· 点上有公共营火时格蕾塔视为可以停留，并会消耗该营火；她的旅人抵达终点时，弃掉展示区最右侧的公园卡与保护卡。\n· 单人模式中格蕾塔控制两组旅人；每次她行动前，由你选择先移动哪一组。你取得小屋奖章时可以额外抽取一张奇迹卡；照片奖章不参与结算，终局按得分对照评级表。",
			season: {
				cliffs: "悬崖之季",
				swimming: "游泳之季",
				memories: "回忆之季",
				sun: "阳光之季",
				dreams: "梦想之季",
				joy: "欢乐之季",
				scouting: "探索之季",
				growth: "生长之季",
				climbing: "攀登之季",
				caves: "洞穴之季",
				meadows: "草甸之季",
				ice: "冰雪之季"
			},
			res: {
				mountain: "山峰",
				forest: "森林",
				sun: "太阳",
				water: "水域",
				wildlife: "野生动物",
				snow: "雪",
				any: "任意资源"
			},
			suit: {
				lime: "青柠",
				orange: "橙",
				teal: "青绿",
				purple: "紫",
				wild: "野性"
			},
			site: {
				"core-forest": "森林：获得 1 枚森林",
				"core-sun": "太阳：获得 2 枚太阳",
				"core-mountain": "山峰：获得 1 枚山峰与 1 枚雪",
				"core-water": "水域：获得 2 枚水域与 1 枚雪",
				wildlife: "野生动物：获得 1 枚野生动物",
				carabiner: "登山扣：获得 1 枚登山扣",
				parks: "公园行动",
				die: "掷步道骰",
				photo: "拍一张照片",
				mug: "马克杯行动",
				chalet: "小屋行动",
				wonder: "抽一张奇迹卡",
				conservation: "保护工程"
			},
			siteShort: {
				"core-forest": "森林",
				"core-sun": "太阳",
				"core-mountain": "山峰",
				"core-water": "水域",
				wildlife: "野生动物",
				carabiner: "登山扣",
				parks: "公园",
				die: "掷步道骰",
				photo: "拍照",
				mug: "马克杯",
				chalet: "小屋",
				wonder: "奇迹卡",
				conservation: "保护工程"
			},
			vf: {
				wonder: "抽一张奇迹卡",
				sunwater: "获得 1 枚太阳与 1 枚水域",
				photo: "拍一张照片",
				conservation: "保护工程",
				mug: "马克杯行动",
				wildlife: "获得 1 枚野生动物"
			},
			vfShort: {
				wonder: "奇迹卡",
				sunwater: "太阳与水域",
				photo: "拍照",
				conservation: "保护工程",
				mug: "马克杯",
				wildlife: "野生动物"
			},
			top: {
				conservation: "保护工程",
				carabiner: "获得登山扣",
				mug: "马克杯行动",
				chalet: "小屋行动"
			},
			benefit: {
				die: "掷步道骰",
				parks: "公园行动",
				mug: "马克杯行动",
				wonder: "抽一张奇迹卡",
				photo: "拍一张照片",
				wildlife: "获得野生动物",
				carabiner: "获得登山扣"
			},
			token: {
				photo: "照片",
				carabiner: "登山扣"
			},
			consProject: {
				p0: "生物多样性修复",
				p1: "野外研究",
				p2: "遗产地修复",
				p3: "减少光污染",
				p4: "自然摄影",
				p5: "物种保护",
				p6: "步道维护"
			},
			campfire: {
				consForest: "每张森林色保护卡计 1 分",
				consMountain: "每张山峰色保护卡计 1 分",
				consSun: "每张太阳色保护卡计 1 分",
				consWater: "每张水域色保护卡计 1 分",
				iconForest: "到访公园每 3 个森林图标计 1 分",
				iconMountain: "到访公园每 3 个山峰图标计 1 分",
				iconSun: "到访公园每 3 个太阳图标计 1 分",
				iconWater: "到访公园每 3 个水域图标计 1 分",
				anyIcons: "到访公园每 2 个任意资源图标计 1 分",
				album: "每本相册计 1 分",
				wonderHand: "手牌中每张奇迹卡计 1 分，包含本卡",
				snow: "板面上每枚雪计 1 分",
				turnWildlife2: "上交 2 枚野生动物，获得 4 分",
				turnAny2: "上交任意 2 点资源，获得快门虫并拍摄 2 张照片",
				turnCarabiner: "上交 1 枚登山扣，获得 2 分",
				turnAny3: "上交任意 3 点资源，获得 3 分"
			},
			rank: {
				none: "未达评级",
				r1: "一日徒步者",
				r2: "远行者",
				r3: "探险家",
				r4: "冒险家",
				r5: "开拓者"
			},
			opt: {
				greta: "邀请护林员格蕾塔",
				gretaHint: "仅双人局可用；单人局中格蕾塔自动加入。"
			},
			seasonLabel: "第 {{n}} 季",
			seasonCard: "赛季卡：{{name}}",
			myTurn: "轮到你行动",
			waitingFor: "等 {{name}} 行动…",
			pending: {
				move: "移动一名旅人",
				trailEnd: "其他旅人都已抵达终点，直接前往步道终点",
				actions: "可以继续行动，或结束回合",
				parks: "预留或访问公园",
				mug: "填充或饮用马克杯",
				mugChoice: "选择马克杯奖励",
				cons: "支持一张保护工程",
				consFree: "免费支持一张保护工程",
				assignWild: "为野性公园选择花色",
				freePark: "免费访问一张公园",
				discardRes: "弃掉一张多余资源",
				discardWonder: "弃掉一张多余的奇迹卡",
				gretaColor: "选择格蕾塔先移动哪一组旅人",
				scoring: "终局结算",
				none: "对局结束"
			},
			trail: "步道",
			trailEnd: "步道终点",
			trailStart: "起点",
			parksTitle: "国家公园",
			consTitle: "保护工程",
			chaletTrack: "小屋赛道",
			myMat: "我的板面",
			handTitle: "我的奇迹卡",
			fieldParks: "公园",
			fieldProjects: "工程",
			fieldChalet: "小屋",
			awardParkDetail: "获得时：{{benefit}}。终局：每张同花色公园得 1 分。",
			awardFixedDetail: "终局得 {{n}} 分。",
			wonderDiscard: "弃置",
			wonderDiscardName: "弃置 {{name}}",
			wonderPlay: "使用这一半",
			wonderWait: "等待你的回合",
			wonderShare: "弃置此牌可进入被占用的步道站点。",
			wonderScore: "终局计分",
			fieldAward: "奖章位",
			fieldFinish: "终点",
			fieldSnowSpace: "雪格",
			fieldAwardNext: "先领取 {{n}} 分奖章。",
			fieldAwardStack: "下方依次为 {{scores}} 分。",
			fieldDrawPassing: "经过时抽 1 张奇迹牌。",
			fieldChaletNote: "每交 1 枚雪，前进 1 个雪格。经过奖励格时领取奖励。",
			fieldTrackSpace: "第 {{n}} 格 · {{name}}",
			fieldStartShort: "起",
			fieldEndShort: "终",
			fieldEndActions: "终点行动",
			fieldAction: "行动",
			fieldVacant: "空位",
			fieldChoose: "选择",
			fieldSharedOccupied: "已有旅人",
			fieldSharedSlot: "可共用",
			fieldSeasonNote: "赛季开始时，第 2–7 站各放置 1 枚额外资源。",
			fieldChoosePark: "选公园",
			fieldFinishParks: "结束公园行动",
			fieldVisitedPark: "已到访 {{name}} · +{{n}} 分",
			fieldDisplay: "展示",
			fieldReserved: "预留 {{n}}",
			fieldNoReserved: "暂无预留公园",
			fieldTrailSeason: "步道与赛季",
			fieldTrailRoute: "沿途站点",
			fieldSeasonTab: "赛季卡",
			fieldStop: "站点",
			fieldBoardTrail: "山谷步道",
			fieldBoardCurrent: "当前位置",
			fieldBoardReachable: "可前往",
			fieldBoardOccupied: "已占位",
			fieldBoardPassed: "已走过",
			fieldBoardBonus: "赛季",
			fieldBoardArrival: "抵达奖励",
			fieldBoardMarket: "公园展示",
			fieldBoardFullPack: "若领取全部收益，背包将达 {{used}} / 12 格。",
			fieldBoardAction: {
				start: "从这里出发",
				end: "选择终点行动",
				parks: "预留或访问公园",
				die: "掷一次步道骰",
				mug: "续杯或饮用",
				chalet: "用雪推进小屋",
				wonder: "抽 1 张奇迹卡",
				conservation: "支持保护工程"
			},
			fieldExtras: "额外机会",
			fieldHikers: "旅人",
			fieldGoTo: "前往{{name}}",
			fieldBackToStop: "返回{{name}}",
			fieldMoveHere: "前往",
			fieldTrailheadInfo: "每个赛季，两名旅人都从这里出发。",
			fieldTrailEndInfo: "旅人到达后结束本季徒步。选择一个终点行动位，也可以只访问公园。",
			fieldSiteEmpty: "暂无旅人",
			fieldFerrataInfo: "花费 1 枚登山扣，另得 1 枚雪。",
			fieldSeasonReward: "赛季奖励",
			fieldShareInfo: "可用营火与其他旅人共占本站。",
			fieldEndSpaces: "查看终点行动位",
			fieldSiteDetail: {
				"core-forest": "获得 1 枚森林。",
				"core-sun": "获得 2 枚太阳。",
				"core-mountain": "获得 1 枚山峰和 1 枚雪。",
				"core-water": "获得 2 枚水域和 1 枚雪。",
				wildlife: "获得 1 枚野生动物。",
				carabiner: "获得 1 枚登山扣。",
				parks: "预留 1 张公园卡，或支付资源访问公园。",
				die: "掷一次步道骰并领取结果。",
				photo: "拍摄 1 张照片。持有快门虫时额外获得 1 张。",
				mug: "填满一格马克杯，或饮用并领取当前格奖励。",
				chalet: "交出全部雪，每枚雪前进 1 个雪格。经过奖励格时领取奖励。",
				wonder: "抽取 1 张奇迹卡。",
				conservation: "支持展示区的保护工程，或支付 1 枚太阳和 1 枚水域，从牌堆取得一张。"
			},
			fieldResetCamera: "重置全谷视角",
			fieldAlbum: "相册",
			fieldHonors: "荣誉",
			fieldCollection: "公园收藏",
			fieldSupported: "已支持工程",
			fieldNone: "暂无",
			fieldPlayerItems: "玩家物件",
			fieldPack: "背包",
			fieldHand: "手牌",
			fieldPanels: "查看物件",
			closePanel: "关闭面板",
			camera: "步道视角",
			overview: "全谷",
			follow: "跟随",
			valleyUnavailable: "打开「步道」选择站点。",
			packSlots: "资源槽",
			packUsage: "{{used}} / 12 格",
			fieldResourceCount: "持有 {{n}} 枚",
			fieldResourceSlots: "每枚占 {{n}} 格",
			fieldResourceUse: {
				regular: "可支付卡牌上对应的费用，也可支付任意资源费用。",
				wildlife: "支付费用时，一枚野生动物可以代替一枚山峰、森林、太阳或水域。",
				snow: "执行小屋行动时交出全部雪。每枚雪前进 1 个雪格，经过奖励格时领取奖励。",
				carabiner: "交出一枚登山扣即可进行铁索攀登，领取对应奖励并获得一枚雪。"
			},
			projectSite: "{{resource}}站",
			displayBonus: "展示奖励",
			journeyEnd: "旅程回顾",
			scoreItem: "计分项目",
			reviewTable: "回看步道与公园",
			returnScores: "返回结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			journeyWinner: "获胜",
			resultParkAwards: "公园奖章",
			resultPhotoAward: "照片奖章",
			resultTotal: "总分",
			fx: {
				cardUsed: "使用了{{card}}",
				honorEarned: "荣誉入册",
				parkAward: "{{suit}}公园奖章 ×{{count}}",
				chaletAward: "小屋奖章 · {{points}} 分"
			},
			handEmpty: "暂无奇迹卡",
			playersTitle: "玩家",
			reservedTitle: "预留公园",
			visitedTitle: "到访公园",
			deckCount: "牌库剩 {{n}} 张",
			startDeck: "牌堆",
			visit: "访问",
			reserve: "预留",
			support: "支持",
			free: "免费",
			deckCost: "太阳 1 · 水域 1",
			points: "{{n}} 分",
			cannotAfford: "资源不足",
			slotTop: "单独行动",
			slotBoth: "行动＋访问公园",
			slotParks: "只访问公园",
			slotTaken: "已被占用",
			chooseSlot: "选择终点位置",
			chooseHiker: "选择旅人",
			hikerLabel: "旅人 {{n}}",
			siteNo: "第 {{n}} 站",
			atEnd: "已抵达终点",
			endTurn: "结束回合",
			viaFerrata: "铁索攀登",
			skip: "跳过",
			cancel: "取消",
			campfireLabel: "营火",
			useCommunalCampfire: "使用公共营火",
			useCampfireCard: "使用营火奇迹卡",
			occupiedPrompt: "这个站点已有旅人，选择如何共享",
			discardResPrompt: "选择要弃回供应的资源",
			discardWonderPrompt: "选择要弃掉的奇迹卡",
			mug: {
				track: "马克杯",
				level: "第 {{n}} 档",
				fill: "填充",
				drink: "饮用",
				chalet: "小屋行动",
				cons: "免费保护工程",
				benefit1: "第一档：小屋行动或免费保护工程",
				benefit2: "第二档：掷三次步道骰",
				benefit3: "第三档：免费访问一张公园"
			},
			assignWildPrompt: "这张野性公园归入哪个花色？",
			freeParkPrompt: "免费访问一张公园",
			wonder: {
				top: "上半",
				bottom: "下半",
				play: "打出",
				pay: "需支付 {{cost}}",
				grant: "获得 {{grant}}",
				campfireCard: "营火卡",
				noPlay: "不能直接打出"
			},
			resources: "资源",
			carabiners: "登山扣 {{n}}",
			photos: "照片 {{n}}",
			albums: "相册 {{n}}",
			awards: "奖章 {{n}}",
			parkAwardsLabel: "公园奖章 {{n}}",
			consAwardsLabel: "保护奖章 {{n}}",
			chaletAwardsLabel: "小屋奖章 {{n}}",
			chaletPos: "小屋第 {{n}} 格",
			visitedCount: "到访 {{n}} 张",
			reservedCount: "预留 {{n}} 张",
			shutterbug: "快门虫",
			greta: "护林员格蕾塔",
			gretaHikers: "格蕾塔的旅人",
			soloRank: "单人评级：{{name}}",
			soloRankTable: "评级线：30 一日徒步者，35 远行者，40 探险家，45 冒险家，50 开拓者",
			siteAction: "执行站点行动",
			endTop: "终点行动",
			endParksTodo: "终点公园行动",
			activateCons: "激活保护卡",
			activateConsPrompt: "选择要激活的保护卡",
			activateConsEmpty: "当前站点没有可激活的保护卡",
			gretaPairA: "橄榄色旅人先",
			gretaPairB: "陶土色旅人先",
			scoringTitle: "终局结算",
			scoringPrompt: "你可以用营火奇迹卡上交资源换取分数；也可以放弃",
			scoringDone: "完成结算",
			scoringEmpty: "手中没有可用的营火效果",
			scoringPayPrompt: "选择要上交的资源，共 {{n}} 点",
			scoringPayChosen: "已选 {{n}}",
			scoringPayConfirm: "上交并结算",
			scoringPayReset: "重新选择",
			scoringUsed: "已使用",
			useEffect: "使用",
			endIncomplete: "请先完成步道终点的行动",
			over: {
				parks: "公园 {{n}}",
				campfire: "营火卡 {{n}}",
				endgame: "营火结算 {{n}}",
				photos: "照片 {{n}}",
				parkAwards: "公园奖章 {{n}}",
				cons: "保护奖章 {{n}}",
				chalet: "小屋奖章 {{n}}",
				photoAward: "照片奖章 {{n}}",
				total: "合计 {{n}}",
				rank: "评级：{{name}}"
			},
			noResources: "暂无资源",
			wild: "野性公园",
			ownMat: "我的",
			otherMat: "{{name}} 的板面",
			scoreShort: "{{n}} 分",
			err: {
				notTurn: "现在轮不到你",
				notPlayer: "你不在这局游戏里",
				phase: "当前步骤不能这样操作",
				badAction: "这一步不能这样做",
				mustMove: "请先移动一名旅人",
				alreadyMoved: "本回合已经移动过了",
				mustEnd: "其他旅人都已抵达终点，必须直接前往步道终点",
				badTarget: "这个站点不能去",
				badHiker: "这名旅人已经抵达终点",
				badSlot: "请选择一个可用的终点位置",
				full: "这个终点位置已被占用",
				occupied: "这个站点已有其他旅人，需要先使用营火",
				noCampfire: "没有可用的营火",
				badPark: "没有可拿取的公园卡",
				badCons: "没有可拿取的保护卡",
				noRes: "资源不足",
				noCarabiner: "登山扣不足",
				noVf: "这个站点无法进行铁索攀登",
				badWonder: "这张奇迹卡不能这样使用",
				badSuit: "不能归入这个花色",
				noConsSite: "这里不能激活保护卡",
				consUsed: "这张保护卡本回合已经激活过"
			}
		},
		en: {
			name: "Parks Europe",
			parkNames: {
				p0: "Lake District",
				p1: "Picos de Europa",
				p2: "Vatnajökull",
				p3: "Calanques",
				p4: "Samaria",
				p5: "Rila",
				p6: "Jotunheimen",
				p7: "Cinque Terre",
				p8: "Tatra",
				p9: "Swiss National Park",
				p10: "Loch Lomond & The Trossachs",
				p11: "Jostedalsbreen",
				p12: "Connemara",
				p13: "Hardangervidda",
				p14: "Theth",
				p15: "Triglav",
				p16: "Berchtesgaden",
				p17: "Retezat",
				p18: "Abruzzo, Lazio e Molise",
				p19: "Arcipelago di La Maddalena",
				p20: "Göreme",
				p21: "Pyrénées",
				p22: "Sarek",
				p23: "Timanfaya",
				p24: "Dolomiti Bellunesi",
				p25: "Hohe Tauern",
				p26: "Thingvellir",
				p27: "Wadden Sea",
				p28: "Pirin",
				p29: "Oulanka",
				p30: "Killarney",
				p31: "Durmitor",
				p32: "Gauja",
				p33: "Doñana",
				p34: "Écrins",
				p35: "Vikos-Aoös",
				p36: "Olympus",
				p37: "Ordesa y Monte Perdido",
				p38: "Plitvice Lakes",
				p39: "Teide",
				p40: "Peneda-Gerês",
				p41: "Gesäuse",
				p42: "Krka",
				p43: "Abisko",
				p44: "Saxon Switzerland",
				p45: "Butrint",
				p46: "Cairngorms",
				p47: "Peak District"
			},
			wonderNames: {
				b01: "Take a Wild Ride",
				b02: "Savor the Sunrise",
				b03: "Bask in the Light",
				b04: "Enjoy the Forests",
				b05: "Walk in the Woods",
				b06: "Take a Hike Bike",
				b07: "Explore the Backcountry",
				b08: "Clear Skies, Full Hearts",
				b09: "Protect the Peaks",
				b10: "Reflect on the Journey",
				b11: "Trail Magic",
				b12: "Take a Dip",
				b13: "Ford a Mountain Stream",
				b14: "Clip In and Climb",
				b16: "Capture the Moment",
				b17: "Ramble Along",
				b18: "Ascend the Mountain",
				b19: "Scale the Summit",
				b20: "Preserve the Trees",
				b21: "Clean the Riverbanks"
			},
			campfireCardName: "Campfire #{{n}}",
			selectedHiker: "Selected",
			desc: "Hike through Europe’s national parks over three seasons, gathering resources, resting at chalets, taking photos and supporting conservation projects for the most points",
			rules: "Goal:\nEach player leads two hikers through the national parks of Europe across three seasons. Collect resources and photos, visit national parks, support conservation projects, and earn the most points in the final scoring to win.\nSetup:\n· Each player takes a player mat, places both hikers at the trailhead, puts the mug token on the bottom space of the mug track, and takes one carabiner.\n· Randomly stack all players’ chalet tokens on the starting space of the chalet track.\n· Each player draws one Wonder card from the Wonder deck to start their hand.\n· Shuffle the park cards and the conservation cards, then reveal three of each into their displays. Prepare communal campfires by player count: one for up to three players, two for four players, and three for five players.\n· At the start of each season, reveal a season card and place communal campfires and season bonus resources on the indicated sites. The player whose chalet token is furthest along the track takes the first turn; if tokens share a space, the topmost token goes first.\nTurns:\nPlayers take turns until all hikers reach Trail’s End, which ends the season. After three seasons, final scoring begins.\n· On your turn, choose one hiker that has not reached Trail’s End and move it forward to any later site, taking that site’s action and any season bonus resource there.\n· Hikers never move backward. A hiker cannot stop on a site occupied by another hiker unless you spend the communal campfire on that site or discard a campfire Wonder card from your hand.\n· You may decline the site’s main action; if you do, you may still use the Via Ferrata, play Wonder cards, or activate conservation cards.\n· After landing, the site’s main action, the Via Ferrata, any Wonder cards, and conservation card activations may be taken in any order.\n· At the end of your turn, your hand holds at most three Wonder cards and you keep at most three carabiners. Your mat holds twelve spaces, each snow occupies two spaces, and any excess non-snow resources are returned to the supply.\nCampfires:\n· Communal campfires are placed at the start of each season and return to the supply when spent; they are not replenished during that season.\n· Campfire Wonder cards stay in your hand for final scoring, but you may discard one earlier to share an occupied site.\nTrail Sites:\n· The four core sites provide forest, sun, mountain and water. The mountain and water sites also provide one snow each.\n· Advanced sites provide wildlife, a carabiner, a parks action, a trail die roll, a photo, a mug action, a chalet action, a Wonder card, or a conservation project.\n· The center site always shows the Shutterbug icon; a hiker landing there immediately takes the Shutterbug.\nTrail’s End:\n· Trail’s End has three areas. The top row offers one of the four actions, with room for one hiker per space. The middle area offers a parks action and holds any number of hikers. The bottom row offers both the action above and a parks action, with room for one hiker per space.\n· A hiker on the bottom row must complete both the action and the parks action, in either order.\n· Campfires cannot be used at Trail’s End. Once both of a player’s hikers reach Trail’s End, that player’s hike is over for the season.\n· If all other hikers have already left the trail when your turn begins, you must move directly to Trail’s End and choose a space as usual.\nVia Ferrata:\n· Every site except the center site has a Via Ferrata tile above it. After landing, you may spend one carabiner to gain that tile’s benefit and one snow.\n· You may use the Via Ferrata only once per turn, and you may do so before or after the site action.\nNational Parks:\n· A parks action lets you either reserve one park or visit any number of parks. Reserving takes one card from the display or the top card of the deck and places it in your reserved area.\n· Visiting requires paying the resources shown on the park card. Wildlife may replace any ordinary resource, and an any-resource cost may be paid with any resources.\n· Stack visited parks by suit to the right of your mat. Each third park in a suit immediately earns that suit’s park award and its printed instant benefit. Each park award scores one point per park of that suit at the end of the game.\n· Wild parks belong to no suit. Add a wild park to any existing suit stack; if you have no suit stack yet, it joins the next colored park you visit.\n· Taking or discarding a card does not refill a display immediately. At the end of the turn, cards slide right and new cards enter from the left, so the rightmost card is always the oldest.\nTrail Die and Shutterbug:\n· The six faces of the trail die provide a carabiner, wildlife, mountain and water, a Wonder card, a photo, or sun and forest.\n· While you hold the Shutterbug, each photo action on your turn grants one extra photo. A hiker landing on the center site or certain cards can give you the Shutterbug.\nPhotos:\n· Each photo scores one point at the end of the game. Every five photos become one photo album, and each album scores five points.\n· At the end of the game, the player who took the most photos gains the photo award worth three points; ties go to the player furthest along the chalet track. Solo mode does not use the photo award.\nMug:\n· A mug action either fills or drinks. Filling moves the token up one space, to the top at most. Drinking resolves the benefit of the token’s current space, then returns the token to the bottom.\n· The first space offers a chalet action or a free conservation project.\n· The second space rolls the trail die three times and grants every result.\n· The third space visits one park for free from the display, your reserved area, or the top of the deck.\nConservation Projects:\n· A conservation action supports one displayed project, or pays one sun and one water to take the top card of the deck.\n· A conservation card activates only at the core site matching its color. Each card may activate once per turn, multiple cards may be activated in any order, and activation may come before or after the site’s main action.\n· If you take a card matching the site you are currently on, you may activate it immediately.\n· Collecting one card of each of the four colors earns a conservation award worth five points.\nChalet:\n· A chalet action turns in all snow on your mat and moves your chalet token along the track one snow space per snow token.\n· Passing a Wonder space draws a Wonder card. Passing an award space takes the most valuable award there, or draws a Wonder card if the stack is empty.\n· If your token ends on a space with another token, stack yours on top. At the end of the track you may still turn in snow, but you no longer move.\n· The chalet track breaks ties at the end of the game; further along wins, and the topmost token wins a shared space.\nWonder Cards:\n· Basic Wonder cards offer two instant actions, one on the top half and one on the bottom half; pay the resources on the left to gain the benefit on the right.\n· Campfire Wonder cards can be discarded to share an occupied site. At the end of the game they score according to their effect, and some let you turn in resources for points.\nSeasons and Final Scoring:\n· At the start of a season, rebuild the trail by shuffling the next three advanced sites with the four core sites and placing them on the seven spaces, then place new campfires and season bonuses.\n· After three seasons, final scoring begins. Each player may choose to turn in resources for points with any campfire Wonder cards in hand, or decline each one.\n· Once campfire effects are resolved, score visited parks, fixed campfire card effects, photos and albums, park awards, conservation awards, and chalet awards. The photo award is calculated after all campfire effects.\n· Park awards score one point per visited park of the matching suit, conservation awards and albums score five points each, photos score one point each, and chalet awards score their face value (3, 4, or 5 points). The player with the most points wins.\nRanger Greta:\n· In solo mode and the two-player challenge, Ranger Greta joins the hike. She always acts last and moves her hikers according to the trail die.\n· A butterfly face moves the rearmost hiker of a pair and a flower face moves the frontmost; the number of symbols is the count of available sites she advances to.\n· Greta treats a site with a communal campfire as available and spends that campfire to stop there. When one of her hikers reaches Trail’s End, discard the rightmost park card and conservation card from their displays.\n· In solo mode Greta controls two pairs of hikers, and before each of her turns you choose which pair moves first. You draw an extra Wonder card whenever you gain a chalet award; the photo award is not used, and your final score is compared to the rank table.",
			season: {
				cliffs: "Season of Cliffs",
				swimming: "Season of Swimming",
				memories: "Season of Memories",
				sun: "Season of Sun",
				dreams: "Season of Dreams",
				joy: "Season of Joy",
				scouting: "Season of Scouting",
				growth: "Season of Growth",
				climbing: "Season of Climbing",
				caves: "Season of Caves",
				meadows: "Season of Meadows",
				ice: "Season of Ice"
			},
			res: {
				mountain: "Mountain",
				forest: "Forest",
				sun: "Sun",
				water: "Water",
				wildlife: "Wildlife",
				snow: "Snow",
				any: "Any resource"
			},
			suit: {
				lime: "Lime",
				orange: "Orange",
				teal: "Teal",
				purple: "Purple",
				wild: "Wild"
			},
			site: {
				"core-forest": "Forest: gain one forest",
				"core-sun": "Sun: gain two sun",
				"core-mountain": "Mountain: gain one mountain and one snow",
				"core-water": "Water: gain two water and one snow",
				wildlife: "Wildlife: gain one wildlife",
				carabiner: "Carabiner: gain one carabiner",
				parks: "Parks action",
				die: "Roll the trail die",
				photo: "Take a photo",
				mug: "Mug action",
				chalet: "Chalet action",
				wonder: "Draw a Wonder card",
				conservation: "Conservation project"
			},
			siteShort: {
				"core-forest": "Forest",
				"core-sun": "Sun",
				"core-mountain": "Mountain",
				"core-water": "Water",
				wildlife: "Wildlife",
				carabiner: "Carabiner",
				parks: "Parks",
				die: "Roll die",
				photo: "Photo",
				mug: "Mug",
				chalet: "Chalet",
				wonder: "Wonder",
				conservation: "Conservation"
			},
			vf: {
				wonder: "Draw a Wonder card",
				sunwater: "Gain one sun and one water",
				photo: "Take a photo",
				conservation: "Conservation project",
				mug: "Mug action",
				wildlife: "Gain one wildlife"
			},
			vfShort: {
				wonder: "Wonder",
				sunwater: "Sun and water",
				photo: "Photo",
				conservation: "Conservation",
				mug: "Mug",
				wildlife: "Wildlife"
			},
			top: {
				conservation: "Conservation project",
				carabiner: "Gain a carabiner",
				mug: "Mug action",
				chalet: "Chalet action"
			},
			benefit: {
				die: "Roll the trail die",
				parks: "Parks action",
				mug: "Mug action",
				wonder: "Draw a Wonder card",
				photo: "Take a photo",
				wildlife: "Gain wildlife",
				carabiner: "Gain a carabiner"
			},
			token: {
				photo: "Photo",
				carabiner: "Carabiner"
			},
			consProject: {
				p0: "Biodiversity Restoration",
				p1: "Field Research",
				p2: "Heritage Site Restoration",
				p3: "Light Pollution Reduction",
				p4: "Nature Photography",
				p5: "Species Protection",
				p6: "Trail Maintenance"
			},
			campfire: {
				consForest: "One point per forest conservation card",
				consMountain: "One point per mountain conservation card",
				consSun: "One point per sun conservation card",
				consWater: "One point per water conservation card",
				iconForest: "One point per three forest icons on visited parks",
				iconMountain: "One point per three mountain icons on visited parks",
				iconSun: "One point per three sun icons on visited parks",
				iconWater: "One point per three water icons on visited parks",
				anyIcons: "One point per two any-resource icons on visited parks",
				album: "One point per photo album",
				wonderHand: "One point per Wonder card in hand, including this one",
				snow: "One point per snow on your mat",
				turnWildlife2: "Turn in two wildlife for four points",
				turnAny2: "Turn in any two resources for the Shutterbug and two photos",
				turnCarabiner: "Turn in one carabiner for two points",
				turnAny3: "Turn in any three resources for three points"
			},
			rank: {
				none: "Unranked",
				r1: "Dayhiker",
				r2: "Trekker",
				r3: "Explorer",
				r4: "Adventurer",
				r5: "Trailblazer"
			},
			opt: {
				greta: "Invite Ranger Greta",
				gretaHint: "Available in two-player games only; in solo mode Greta always joins."
			},
			seasonLabel: "Season {{n}}",
			seasonCard: "Season card: {{name}}",
			myTurn: "Your turn",
			waitingFor: "Waiting for {{name}}…",
			pending: {
				move: "Move one of your hikers",
				trailEnd: "Every other hiker has reached Trail’s End, so move directly there",
				actions: "Keep taking actions, or end your turn",
				parks: "Reserve or visit parks",
				mug: "Fill or drink your mug",
				mugChoice: "Choose your mug benefit",
				cons: "Support a conservation project",
				consFree: "Support a conservation project for free",
				assignWild: "Choose a suit for the wild park",
				freePark: "Visit one park for free",
				discardRes: "Discard one excess resource",
				discardWonder: "Discard one excess Wonder card",
				gretaColor: "Choose which pair of Greta’s hikers moves first",
				scoring: "Final scoring",
				none: "Game over"
			},
			trail: "Trail",
			trailEnd: "Trail’s End",
			trailStart: "Trailhead",
			parksTitle: "National Parks",
			consTitle: "Conservation Projects",
			chaletTrack: "Chalet Track",
			myMat: "My Mat",
			handTitle: "My Wonder Cards",
			fieldParks: "Parks",
			fieldProjects: "Projects",
			fieldChalet: "Chalet",
			awardParkDetail: "On arrival: {{benefit}}. At the end of the game, score 1 point per park of this suit.",
			awardFixedDetail: "Score {{n}} points at the end of the game.",
			wonderDiscard: "Discard",
			wonderDiscardName: "Discard {{name}}",
			wonderPlay: "Play this half",
			wonderWait: "Wait for your turn",
			wonderShare: "Discard to enter an occupied trail site.",
			wonderScore: "End-game scoring",
			fieldAward: "Award space",
			fieldFinish: "Finish",
			fieldSnowSpace: "Snow space",
			fieldAwardNext: "Take the {{n}}-point award first.",
			fieldAwardStack: "Below it, in order: {{scores}} points.",
			fieldDrawPassing: "Draw 1 Wonder card when you pass.",
			fieldChaletNote: "Move 1 snow space per snow token spent. Collect rewards as you pass them.",
			fieldTrackSpace: "Space {{n}} · {{name}}",
			fieldStartShort: "Start",
			fieldEndShort: "End",
			fieldEndActions: "End actions",
			fieldAction: "Action",
			fieldVacant: "Open",
			fieldChoose: "Choose",
			fieldSharedOccupied: "Hikers present",
			fieldSharedSlot: "Shared space",
			fieldSeasonNote: "At the start of the season, place 1 bonus token at each site from 2 to 7.",
			fieldChoosePark: "Choose a park",
			fieldFinishParks: "Finish parks action",
			fieldVisitedPark: "Visited {{name}} · +{{n}} points",
			fieldDisplay: "Display",
			fieldReserved: "Reserved {{n}}",
			fieldNoReserved: "No reserved parks",
			fieldTrailSeason: "Trail and season",
			fieldTrailRoute: "Along the trail",
			fieldSeasonTab: "Season card",
			fieldStop: "Site",
			fieldBoardTrail: "Valley trail",
			fieldBoardCurrent: "Here",
			fieldBoardReachable: "Reachable",
			fieldBoardOccupied: "Occupied",
			fieldBoardPassed: "Passed",
			fieldBoardBonus: "Season",
			fieldBoardArrival: "On arrival",
			fieldBoardMarket: "Park display",
			fieldBoardFullPack: "With all rewards, your pack would hold {{used}} / 12 slots.",
			fieldBoardAction: {
				start: "Start here",
				end: "Choose an end space",
				parks: "Reserve or visit a park",
				die: "Roll the trail die",
				mug: "Fill or drink",
				chalet: "Spend snow at the chalet",
				wonder: "Draw one Wonder card",
				conservation: "Support a project"
			},
			fieldExtras: "Extras",
			fieldHikers: "Hikers",
			fieldGoTo: "Move to {{name}}",
			fieldBackToStop: "Back to {{name}}",
			fieldMoveHere: "Move here",
			fieldTrailheadInfo: "Both hikers set out from here at the start of each season.",
			fieldTrailEndInfo: "A hiker finishes the trail for the season here. Choose an end space or visit parks only.",
			fieldSiteEmpty: "No hikers here",
			fieldFerrataInfo: "Spend one carabiner and gain one snow in addition to the reward.",
			fieldSeasonReward: "Season reward",
			fieldShareInfo: "Use the campfire to share this site with another hiker.",
			fieldEndSpaces: "View Trail’s End spaces",
			fieldSiteDetail: {
				"core-forest": "Gain one forest.",
				"core-sun": "Gain two sun.",
				"core-mountain": "Gain one mountain and one snow.",
				"core-water": "Gain two water and one snow.",
				wildlife: "Gain one wildlife.",
				carabiner: "Gain one carabiner.",
				parks: "Reserve one park or spend resources to visit parks.",
				die: "Roll the trail die once and gain the result.",
				photo: "Take one photo. Take one more if you have the Shutterbug.",
				mug: "Fill your mug by one level, or drink to gain the reward at its current level.",
				chalet: "Turn in all your snow. Move one snow space per token and collect rewards as you pass them.",
				wonder: "Draw one Wonder card.",
				conservation: "Support a displayed conservation project, or spend one sun and one water to take the top card."
			},
			fieldResetCamera: "Reset valley view",
			fieldAlbum: "Albums",
			fieldHonors: "Awards",
			fieldCollection: "Visited parks",
			fieldSupported: "Supported projects",
			fieldNone: "None yet",
			fieldPlayerItems: "Player materials",
			fieldPack: "Pack",
			fieldHand: "Hand",
			fieldPanels: "Game materials",
			closePanel: "Close panel",
			camera: "Trail view",
			overview: "Valley",
			follow: "Follow",
			valleyUnavailable: "Open Trail to select a destination.",
			packSlots: "Resource slots",
			packUsage: "{{used}} / 12 slots",
			fieldResourceCount: "{{n}} held",
			fieldResourceSlots: "{{n}} slots per token",
			fieldResourceUse: {
				regular: "Use this to pay costs showing this resource or any resource.",
				wildlife: "When paying a cost, each wildlife can replace one mountain, forest, sun or water.",
				snow: "Turn in all your snow at a chalet. Move one snow space per token and collect rewards as you pass them.",
				carabiner: "Spend one carabiner on a Via Ferrata to gain its reward and one snow."
			},
			projectSite: "{{resource}} site",
			displayBonus: "Display bonus",
			journeyEnd: "Journey recap",
			scoreItem: "Scoring category",
			reviewTable: "Review trail and parks",
			returnScores: "Return to scores",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			journeyWinner: "Winner",
			resultParkAwards: "Park Awards",
			resultPhotoAward: "Photo Award",
			resultTotal: "Total",
			fx: {
				cardUsed: "Played {{card}}",
				honorEarned: "Honor earned",
				parkAward: "{{suit}} park award ×{{count}}",
				chaletAward: "Chalet award · {{points}} points"
			},
			handEmpty: "No Wonder cards",
			playersTitle: "Players",
			reservedTitle: "Reserved Parks",
			visitedTitle: "Visited Parks",
			deckCount: "{{n}} cards left in the deck",
			startDeck: "Deck",
			visit: "Visit",
			reserve: "Reserve",
			support: "Support",
			free: "Free",
			deckCost: "One sun, one water",
			points: "{{n}} points",
			cannotAfford: "Not enough resources",
			slotTop: "Action only",
			slotBoth: "Action + visit parks",
			slotParks: "Visit parks only",
			slotTaken: "Occupied",
			chooseSlot: "Choose a Trail’s End space",
			chooseHiker: "Choose a hiker",
			hikerLabel: "Hiker {{n}}",
			siteNo: "Site {{n}}",
			atEnd: "At Trail’s End",
			endTurn: "End turn",
			viaFerrata: "Via Ferrata",
			skip: "Skip",
			cancel: "Cancel",
			campfireLabel: "Campfire",
			useCommunalCampfire: "Spend the communal campfire",
			useCampfireCard: "Spend a campfire Wonder card",
			occupiedPrompt: "Another hiker is here; choose how to share the site",
			discardResPrompt: "Choose a resource to return to the supply",
			discardWonderPrompt: "Choose a Wonder card to discard",
			mug: {
				track: "Mug",
				level: "Space {{n}}",
				fill: "Fill",
				drink: "Drink",
				chalet: "Chalet action",
				cons: "Free conservation project",
				benefit1: "First space: chalet action or free conservation",
				benefit2: "Second space: roll the trail die three times",
				benefit3: "Third space: visit one park for free"
			},
			assignWildPrompt: "Which suit does this wild park join?",
			freeParkPrompt: "Visit one park for free",
			wonder: {
				top: "Top",
				bottom: "Bottom",
				play: "Play",
				pay: "Pay {{cost}}",
				grant: "Gain {{grant}}",
				campfireCard: "Campfire card",
				noPlay: "Cannot be played directly"
			},
			resources: "Resources",
			carabiners: "Carabiners {{n}}",
			photos: "Photos {{n}}",
			albums: "Albums {{n}}",
			awards: "Awards {{n}}",
			parkAwardsLabel: "Park awards {{n}}",
			consAwardsLabel: "Conservation awards {{n}}",
			chaletAwardsLabel: "Chalet awards {{n}}",
			chaletPos: "Chalet space {{n}}",
			visitedCount: "{{n}} visited",
			reservedCount: "{{n}} reserved",
			shutterbug: "Shutterbug",
			greta: "Ranger Greta",
			gretaHikers: "Greta’s hikers",
			soloRank: "Solo rank: {{name}}",
			soloRankTable: "Ranks: 30 Dayhiker, 35 Trekker, 40 Explorer, 45 Adventurer, 50 Trailblazer",
			siteAction: "Take the site action",
			endTop: "Trail’s End action",
			endParksTodo: "Trail’s End parks action",
			activateCons: "Activate conservation card",
			activateConsPrompt: "Choose a conservation card to activate",
			activateConsEmpty: "No conservation card can be activated here",
			gretaPairA: "Moss hikers first",
			gretaPairB: "Clay hikers first",
			scoringTitle: "Final Scoring",
			scoringPrompt: "You may turn in resources for points with campfire Wonder cards, or decline each one",
			scoringDone: "Finish scoring",
			scoringEmpty: "No usable campfire effect in hand",
			scoringPayPrompt: "Choose {{n}} resources to turn in",
			scoringPayChosen: "{{n}} chosen",
			scoringPayConfirm: "Turn in and score",
			scoringPayReset: "Choose again",
			scoringUsed: "Used",
			useEffect: "Use",
			endIncomplete: "Complete the Trail’s End actions first",
			over: {
				parks: "Parks {{n}}",
				campfire: "Campfire cards {{n}}",
				endgame: "Campfire scoring {{n}}",
				photos: "Photos {{n}}",
				parkAwards: "Park awards {{n}}",
				cons: "Conservation awards {{n}}",
				chalet: "Chalet awards {{n}}",
				photoAward: "Photo award {{n}}",
				total: "Total {{n}}",
				rank: "Rank: {{name}}"
			},
			noResources: "No resources",
			wild: "Wild park",
			ownMat: "Mine",
			otherMat: "{{name}}’s mat",
			scoreShort: "{{n}} points",
			err: {
				notTurn: "It is not your turn",
				notPlayer: "You are not in this game",
				phase: "You cannot do that right now",
				badAction: "That action is not available here",
				mustMove: "Move a hiker first",
				alreadyMoved: "You already moved this turn",
				mustEnd: "Every other hiker has reached Trail’s End, so you must move there",
				badTarget: "You cannot stop at that site",
				badHiker: "That hiker has already reached Trail’s End",
				badSlot: "Choose an available Trail’s End space",
				full: "That Trail’s End space is occupied",
				occupied: "Another hiker is here; you need a campfire",
				noCampfire: "No campfire is available",
				badPark: "No park card can be taken",
				badCons: "No conservation card can be taken",
				noRes: "Not enough resources",
				noCarabiner: "Not enough carabiners",
				noVf: "The Via Ferrata is not available here",
				badWonder: "That Wonder card cannot be used this way",
				badSuit: "That suit is not available",
				noConsSite: "No conservation card can be activated here",
				consUsed: "That conservation card was already activated this turn"
			}
		}
	}
};
//#endregion
export { Rr as default };
