import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { useT as u } from "@bgparty/sdk/i18n";
import { IconClose as d, IconLayoutCover as f, IconMove as p, IconPile as m } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as h } from "@bgparty/sdk/player-colors";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as v } from "@bgparty/sdk/assets";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { usePrefersReducedMotion as S } from "@bgparty/sdk/fx/use-reduced-motion";
import { useFrame as C, useThree as ee } from "@react-three/fiber";
import { ACESFilmicToneMapping as w, BackSide as te, Box3 as ne, BoxGeometry as re, BufferAttribute as T, BufferGeometry as E, CapsuleGeometry as D, Color as O, CylinderGeometry as k, DirectionalLight as ie, DoubleSide as A, FogExp2 as ae, Group as j, HemisphereLight as oe, IcosahedronGeometry as se, InstancedMesh as ce, Mesh as M, MeshBasicMaterial as le, MeshStandardMaterial as N, Object3D as ue, Plane as de, PlaneGeometry as fe, Raycaster as pe, Scene as me, ShaderMaterial as he, SphereGeometry as ge, TorusGeometry as _e, Vector2 as ve, Vector3 as P } from "three";
import { ResilientCanvas as ye } from "@bgparty/sdk/three/resilient-canvas";
import { ConfirmButton as be } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as xe, OptionSection as Se } from "@bgparty/sdk/ui/game-options";
var F = Object.fromEntries([
	{
		id: 0,
		name: "Lake District",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 1,
		name: "Picos de Europa",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 2,
		name: "Vatnajökull",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 3,
		name: "Calanques",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 4,
		name: "Samaria",
		suit: "purple",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 5,
		name: "Rila",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 6,
		name: "Jotunheimen",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 3,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 7,
		name: "Cinque Terre",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 2,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 8,
		name: "Tatra",
		suit: "purple",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 9,
		name: "Swiss National Park",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 10,
		name: "Loch Lomond & The Trossachs",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 11,
		name: "Jostedalsbreen",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 12,
		name: "Connemara",
		suit: "teal",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 13,
		name: "Hardangervidda",
		suit: "teal",
		points: 4,
		cost: {
			forest: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 14,
		name: "Theth",
		suit: "teal",
		points: 5,
		cost: {
			forest: 3,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 15,
		name: "Triglav",
		suit: "teal",
		points: 5,
		cost: {
			forest: 2,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 16,
		name: "Berchtesgaden",
		suit: "teal",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 17,
		name: "Retezat",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 18,
		name: "Abruzzo, Lazio e Molise",
		suit: "purple",
		points: 2,
		cost: {
			mountain: 1,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 19,
		name: "Arcipelago di La Maddalena",
		suit: "purple",
		points: 2,
		cost: {
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 20,
		name: "Göreme",
		suit: "orange",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 21,
		name: "Pyrénées",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 1,
			sun: 2,
			any: 2
		}
	},
	{
		id: 22,
		name: "Sarek",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 3,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 23,
		name: "Timanfaya",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 2,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 24,
		name: "Dolomiti Bellunesi",
		suit: "orange",
		points: 5,
		cost: { mountain: 3 }
	},
	{
		id: 25,
		name: "Hohe Tauern",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 26,
		name: "Thingvellir",
		suit: "teal",
		points: 2,
		cost: {
			forest: 1,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 27,
		name: "Wadden Sea",
		suit: "teal",
		points: 2,
		cost: { water: 4 },
		instant: "mug"
	},
	{
		id: 28,
		name: "Pirin",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 29,
		name: "Oulanka",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 30,
		name: "Killarney",
		suit: "lime",
		points: 5,
		cost: {
			forest: 3,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 31,
		name: "Durmitor",
		suit: "lime",
		points: 5,
		cost: {
			forest: 2,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 32,
		name: "Gauja",
		suit: "lime",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 33,
		name: "Doñana",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 34,
		name: "Écrins",
		suit: "orange",
		points: 2,
		cost: {
			mountain: 1,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 35,
		name: "Vikos-Aoös",
		suit: "orange",
		points: 2,
		cost: { sun: 4 },
		instant: "photo"
	},
	{
		id: 36,
		name: "Olympus",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 37,
		name: "Ordesa y Monte Perdido",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 38,
		name: "Plitvice Lakes",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 2,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 39,
		name: "Teide",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 40,
		name: "Peneda-Gerês",
		suit: "lime",
		points: 2,
		cost: {
			forest: 1,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 41,
		name: "Gesäuse",
		suit: "lime",
		points: 2,
		cost: { sun: 4 },
		instant: "die"
	},
	{
		id: 42,
		name: "Krka",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 43,
		name: "Abisko",
		suit: "lime",
		points: 4,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 44,
		name: "Saxon Switzerland",
		suit: "lime",
		points: 3,
		cost: {
			forest: 2,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 45,
		name: "Butrint",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 46,
		name: "Cairngorms",
		suit: "lime",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 47,
		name: "Peak District",
		suit: "lime",
		points: 4,
		cost: {
			forest: 1,
			sun: 2,
			any: 2
		}
	}
].map((e) => [e.id, e])), Ce = [
	"lime",
	"orange",
	"teal",
	"purple"
], we = {
	lime: "wildlife",
	orange: "photo",
	teal: "mug",
	purple: "wonder"
}, Te = [
	"sun",
	"mountain",
	"water",
	"forest"
], Ee = {
	sun: { sun: 2 },
	mountain: { mountain: 1 },
	water: { water: 2 },
	forest: { forest: 1 }
}, De = [
	{
		name: "Biodiversity Restoration",
		benefit: "die"
	},
	{
		name: "Field Research",
		benefit: "parks"
	},
	{
		name: "Heritage Site Restoration",
		benefit: "mug"
	},
	{
		name: "Light Pollution Reduction",
		benefit: "wonder"
	},
	{
		name: "Nature Photography",
		benefit: "photo"
	},
	{
		name: "Species Protection",
		benefit: "wildlife"
	},
	{
		name: "Trail Maintenance",
		benefit: "carabiner"
	}
], I = (e) => Te[Math.floor(e / 7)], L = (e, t = 1) => ({
	t: "res",
	res: e,
	n: t
}), Oe = (e = 1) => ({
	t: "carabiner",
	n: e
}), ke = [
	{
		id: "b01",
		no: 1,
		name: "Take a Wild Ride",
		art: "w01",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [Oe(2)]
		}
	},
	{
		id: "b02",
		no: 2,
		name: "Savor the Sunrise",
		art: "w02",
		top: { grants: [L("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [L("forest"), L("water")]
		}
	},
	{
		id: "b03",
		no: 3,
		name: "Bask in the Light",
		art: "w03",
		top: { grants: [L("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [L("mountain"), L("water")]
		}
	},
	{
		id: "b04",
		no: 4,
		name: "Enjoy the Forests",
		art: "w04",
		top: { grants: [L("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [{
				t: "photo",
				n: 1
			}, L("sun")]
		}
	},
	{
		id: "b05",
		no: 5,
		name: "Walk in the Woods",
		art: "w05",
		top: { grants: [L("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [L("wildlife"), L("sun")]
		}
	},
	{
		id: "b06",
		no: 6,
		name: "Take a Hike Bike",
		art: "w06",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [L("wildlife")] }
	},
	{
		id: "b07",
		no: 7,
		name: "Explore the Backcountry",
		art: "w07",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [L("wildlife", 2)]
		}
	},
	{
		id: "b08",
		no: 8,
		name: "Clear Skies, Full Hearts",
		art: "w08",
		top: { grants: [L("sun", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b09",
		no: 9,
		name: "Protect the Peaks",
		art: "w09",
		top: { grants: [L("mountain")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b10",
		no: 10,
		name: "Reflect on the Journey",
		art: "w10",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "mug" }, { t: "mug" }]
		}
	},
	{
		id: "b11",
		no: 11,
		name: "Trail Magic",
		art: "w11",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{ t: "mug" }] }
	},
	{
		id: "b12",
		no: 12,
		name: "Take a Dip",
		art: "w12",
		top: { grants: [L("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [L("forest"), L("sun")]
		}
	},
	{
		id: "b13",
		no: 13,
		name: "Ford a Mountain Stream",
		art: "w13",
		top: { grants: [L("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [L("mountain"), L("sun")]
		}
	},
	{
		id: "b14",
		no: 14,
		name: "Clip In and Climb",
		art: "w14",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [Oe()] }
	},
	{
		id: "b16",
		no: 16,
		name: "Capture the Moment",
		art: "w16",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "shutterbug" }, {
				t: "photo",
				n: 1
			}]
		}
	},
	{
		id: "b17",
		no: 17,
		name: "Ramble Along",
		art: "w17",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{
			t: "photo",
			n: 1
		}] }
	},
	{
		id: "b18",
		no: 18,
		name: "Ascend the Mountain",
		art: "w18",
		top: { grants: [L("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [Oe(), L("water")]
		}
	},
	{
		id: "b19",
		no: 19,
		name: "Scale the Summit",
		art: "w19",
		top: { grants: [L("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [{ t: "mug" }, L("water")]
		}
	},
	{
		id: "b20",
		no: 20,
		name: "Preserve the Trees",
		art: "w20",
		top: { grants: [L("forest")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b21",
		no: 21,
		name: "Clean the Riverbanks",
		art: "w21",
		top: { grants: [L("water", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	}
], Ae = [
	{
		id: "c01",
		no: 1,
		art: "w15",
		effect: "consForest"
	},
	{
		id: "c02",
		no: 2,
		art: "w36",
		effect: "consMountain"
	},
	{
		id: "c03",
		no: 3,
		art: "w29",
		effect: "consSun"
	},
	{
		id: "c04",
		no: 4,
		art: "w30",
		effect: "consWater"
	},
	{
		id: "c05",
		no: 5,
		art: "w31",
		effect: "iconForest"
	},
	{
		id: "c06",
		no: 6,
		art: "w32",
		effect: "iconMountain"
	},
	{
		id: "c07",
		no: 7,
		art: "w33",
		effect: "iconSun"
	},
	{
		id: "c08",
		no: 8,
		art: "w34",
		effect: "iconWater"
	},
	{
		id: "c09",
		no: 9,
		art: "w35",
		effect: "anyIcons"
	},
	{
		id: "c10",
		no: 10,
		art: "w22",
		effect: "album"
	},
	{
		id: "c11",
		no: 11,
		art: "w23",
		effect: "wonderHand"
	},
	{
		id: "c12",
		no: 12,
		art: "w24",
		effect: "snow"
	},
	{
		id: "c13",
		no: 13,
		art: "w25",
		effect: "turnWildlife2"
	},
	{
		id: "c14",
		no: 14,
		art: "w26",
		effect: "turnAny2"
	},
	{
		id: "c15",
		no: 15,
		art: "w27",
		effect: "turnCarabiner"
	},
	{
		id: "c16",
		no: 16,
		art: "w28",
		effect: "turnAny3"
	}
], je = Object.fromEntries(ke.map((e) => [e.id, e])), R = Object.fromEntries(Ae.map((e) => [e.id, e]));
[...ke.map((e) => e.id), ...Ae.map((e) => e.id)];
var Me = [
	{
		id: "cliffs",
		name: "Season of Cliffs",
		pattern: [
			"water",
			"water",
			"sun",
			"sun",
			"sun",
			"water"
		],
		fires: [
			1,
			7,
			5
		],
		display: {
			zone: "cons",
			token: "carabiner"
		}
	},
	{
		id: "swimming",
		name: "Season of Swimming",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"water",
			"water"
		],
		fires: [
			6,
			4,
			3
		],
		display: {
			zone: "parks",
			token: "water"
		}
	},
	{
		id: "memories",
		name: "Season of Memories",
		pattern: [
			"sun",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			2,
			6
		],
		display: {
			zone: "cons",
			token: "photo"
		}
	},
	{
		id: "sun",
		name: "Season of Sun",
		pattern: [
			"sun",
			"sun",
			"water",
			"sun",
			"sun",
			"sun"
		],
		fires: [
			5,
			3,
			2
		],
		display: {
			zone: "parks",
			token: "sun"
		}
	},
	{
		id: "dreams",
		name: "Season of Dreams",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			7,
			1
		],
		display: {
			zone: "parks",
			token: "snow"
		}
	},
	{
		id: "joy",
		name: "Season of Joy",
		pattern: [
			"sun",
			"water",
			"forest",
			"mountain",
			"wildlife",
			"sun"
		],
		fires: [
			7,
			1,
			3
		]
	},
	{
		id: "scouting",
		name: "Season of Scouting",
		pattern: [
			"sun",
			"sun",
			"wildlife",
			"wildlife",
			"wildlife",
			"water"
		],
		fires: [
			7,
			5,
			2
		]
	},
	{
		id: "growth",
		name: "Season of Growth",
		pattern: [
			"sun",
			"water",
			"forest",
			"sun",
			"forest",
			"forest"
		],
		fires: [
			5,
			6,
			7
		]
	},
	{
		id: "climbing",
		name: "Season of Climbing",
		pattern: [
			"sun",
			"water",
			"sun",
			"carabiner",
			"carabiner",
			"carabiner"
		],
		fires: [
			1,
			3,
			6
		]
	},
	{
		id: "caves",
		name: "Season of Caves",
		pattern: [
			"water",
			"sun",
			"mountain",
			"mountain",
			"water",
			"mountain"
		],
		fires: [
			3,
			2,
			1
		]
	},
	{
		id: "meadows",
		name: "Season of Meadows",
		pattern: [
			"sun",
			"photo",
			"sun",
			"photo",
			"sun",
			"photo"
		],
		fires: [
			2,
			4,
			5
		]
	},
	{
		id: "ice",
		name: "Season of Ice",
		pattern: [
			"snow",
			"water",
			"snow",
			"water",
			"snow",
			"water"
		],
		fires: [
			3,
			5,
			6
		]
	}
];
Object.fromEntries(Me.map((e, t) => [t, e]));
var Ne = [
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water"
], Pe = [
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
], Fe = {
	"core-forest": "forest",
	"core-sun": "sun",
	"core-mountain": "mountain",
	"core-water": "water"
};
function Ie(e) {
	return Fe[e] ?? null;
}
var Le = [
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
], Re = [
	{
		ranger: "butterfly",
		symbols: 1,
		carabiner: 1
	},
	{
		ranger: "butterfly",
		symbols: 1,
		res: { wildlife: 1 }
	},
	{
		ranger: "butterfly",
		symbols: 2,
		res: {
			mountain: 1,
			water: 1
		}
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "wonder"
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "photo"
	},
	{
		ranger: "flower",
		symbols: 2,
		res: {
			sun: 1,
			forest: 1
		}
	}
], z = [
	{ t: "start" },
	{ t: "snow" },
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: 0,
		solo: 3
	},
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: null,
		solo: 4
	},
	{ t: "snow" },
	{ t: "snow" },
	{
		t: "award",
		stack: 1,
		solo: 5
	},
	{ t: "snow" },
	{ t: "snow" },
	{ t: "end" }
], ze = z.length - 1, Be = [
	"conservation",
	"carabiner",
	"mug",
	"chalet"
], Ve = {
	mountain: 16,
	forest: 16,
	sun: 22,
	water: 22,
	wildlife: 14,
	snow: 20
}, He = [
	{
		at: 50,
		rank: 5
	},
	{
		at: 45,
		rank: 4
	},
	{
		at: 40,
		rank: 3
	},
	{
		at: 35,
		rank: 2
	},
	{
		at: 30,
		rank: 1
	}
], Ue = {
	id: "parkseurope",
	uuid: "57ea4f6d-4e67-4904-8ef4-ab6f134dd492",
	tier: "alpha",
	mechanics: [
		"set-collection",
		"hand-management",
		"engine-building",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.parkseurope.name",
	descKey: "games.parkseurope.desc",
	rulesKey: "games.parkseurope.rules",
	icon: "🏞️",
	iconImg: "games/parkseurope.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#3f7a4d",
	releasedAt: "2026-11-24T05:21:41+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, We = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
];
function Ge(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		wildlife: t.wildlife ?? 0
	};
	for (let r of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) {
		let i = t[r] ?? 0;
		n[r] = Math.min(e[r], i), n.wildlife += i - n[r];
	}
	if (n.wildlife > e.wildlife) return null;
	let r = t.any ?? 0;
	for (let t of We) {
		if (r === 0) break;
		let i = Math.min(r, e[t] - n[t]);
		n[t] += i, r -= i;
	}
	return r === 0 ? n : null;
}
//#endregion
//#region src/game/schema.ts
var Ke = t.enum([
	"lime",
	"orange",
	"teal",
	"purple",
	"wild"
]), qe = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow"
]), Je = t.enum([
	"conservation",
	"carabiner",
	"mug",
	"chalet"
]), Ye = t.enum([
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water",
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
]), Xe = t.enum([
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
]), Ze = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow",
	"photo",
	"carabiner"
]), Qe = t.partialRecord(qe, t.int().nonnegative()), $e = t.partialRecord(t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
]), t.int().nonnegative().max(3)), B = t.union([
	t.object({
		kind: t.literal("top"),
		action: Je
	}),
	t.object({
		kind: t.literal("both"),
		action: Je
	}),
	t.object({ kind: t.literal("parks") })
]), et = t.union([
	t.object({
		type: t.literal("move"),
		hiker: t.union([t.literal(0), t.literal(1)]),
		to: t.int().min(1).max(8),
		campfire: t.enum(["communal", "card"]).optional(),
		card: t.string().optional(),
		slot: B.optional()
	}),
	t.object({ type: t.literal("siteAction") }),
	t.object({
		type: t.literal("activateCons"),
		card: t.int().nonnegative()
	}),
	t.object({ type: t.literal("endTop") }),
	t.object({ type: t.literal("endParks") }),
	t.object({ type: t.literal("viaFerrata") }),
	t.object({
		type: t.literal("reserve"),
		from: t.enum(["display", "deck"]),
		index: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("visit"),
		parkId: t.int().nonnegative(),
		pay: Qe.optional()
	}),
	t.object({ type: t.literal("parksDone") }),
	t.object({
		type: t.literal("mug"),
		act: t.enum(["fill", "drink"])
	}),
	t.object({
		type: t.literal("mugChoice"),
		choice: t.enum(["chalet", "cons"])
	}),
	t.object({
		type: t.literal("consPick"),
		index: t.int().nonnegative().optional(),
		deck: t.boolean().optional()
	}),
	t.object({
		type: t.literal("assignWild"),
		suit: t.enum([
			"lime",
			"orange",
			"teal",
			"purple"
		])
	}),
	t.object({
		type: t.literal("freePark"),
		parkId: t.int().nonnegative().optional(),
		from: t.enum([
			"display",
			"reserve",
			"deck"
		])
	}),
	t.object({
		type: t.literal("playWonder"),
		card: t.string(),
		side: t.enum(["top", "bottom"]),
		pay: Qe.optional()
	}),
	t.object({
		type: t.literal("discardRes"),
		res: t.enum([
			"mountain",
			"forest",
			"sun",
			"water",
			"wildlife"
		])
	}),
	t.object({
		type: t.literal("discardWonder"),
		card: t.string()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("gretaColor"),
		first: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("campfireEnd"),
		card: t.string(),
		pay: $e.optional(),
		carabiner: t.boolean().optional()
	}),
	t.object({ type: t.literal("scoringDone") })
]), tt = t.object({ greta: t.boolean().default(!1) }).prefault({}), nt = t.object({
	id: t.int().nonnegative(),
	suit: Ke.nullable()
}), rt = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	res: t.record(t.enum([
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]), t.int().nonnegative()),
	snow: t.int().nonnegative(),
	carabiners: t.int().nonnegative(),
	mug: t.int().min(0).max(3),
	photos: t.int().nonnegative(),
	albums: t.int().nonnegative(),
	photosTaken: t.int().nonnegative(),
	visited: t.array(nt),
	reserved: t.array(t.int().nonnegative()),
	cons: t.array(t.int().nonnegative()),
	parkAwards: t.record(t.enum([
		"lime",
		"orange",
		"teal",
		"purple"
	]), t.int().nonnegative()),
	consAwards: t.int().nonnegative(),
	chaletAwards: t.array(t.int().nonnegative()),
	wonderCount: t.int().nonnegative(),
	shutterbug: t.boolean(),
	chaletPos: t.int().nonnegative(),
	chaletOrder: t.int(),
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	endUsed: t.array(t.string()),
	endPoints: t.int().nonnegative()
}), it = t.object({
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	solo: t.boolean()
}), at = t.object({
	kind: t.enum(["top", "both"]),
	action: Je,
	rid: t.string().nullable()
}), ot = t.object({
	phase: t.enum([
		"turn",
		"scoring",
		"ended"
	]),
	season: t.int().min(1).max(3),
	turn: t.string().nullable(),
	moved: t.boolean(),
	pending: t.enum([
		"move",
		"trailEnd",
		"actions",
		"parks",
		"mug",
		"mugChoice",
		"cons",
		"assignWild",
		"freePark",
		"discardRes",
		"discardWonder",
		"gretaColor",
		"scoring",
		"none"
	]),
	freeCons: t.boolean(),
	landingSite: t.int().min(1).max(7).nullable(),
	siteDone: t.boolean(),
	consUsed: t.array(t.int().nonnegative()),
	vfUsed: t.boolean(),
	end: t.object({
		action: Je.nullable(),
		topDone: t.boolean(),
		parksDone: t.boolean()
	}).nullable(),
	seasonCard: t.string(),
	order: t.array(t.string()),
	players: t.array(rt),
	trailSites: t.array(Ye),
	trailBonus: t.array(Ze.nullable()),
	campfires: t.array(t.int().nonnegative()),
	vf: t.array(Xe.nullable()),
	parksDisplay: t.array(t.int().nonnegative()),
	parksDeck: t.int().nonnegative(),
	parksBonus: t.array(Ze.nullable()),
	consDisplay: t.array(t.int().nonnegative()),
	consDeck: t.int().nonnegative(),
	consBonus: t.array(Ze.nullable()),
	consAwardsLeft: t.int().nonnegative(),
	chaletStacks: t.array(t.array(t.int().nonnegative())),
	endSlots: t.array(at),
	parksEndOccupied: t.boolean(),
	greta: it.nullable(),
	soloRanks: t.array(t.object({
		at: t.int().nonnegative(),
		rank: t.int().nonnegative()
	})).nullable(),
	revealedCampfire: t.array(t.object({
		rid: t.string(),
		cards: t.array(t.string())
	})).nullable(),
	campfireUsed: t.array(t.string()),
	finalRows: t.array(t.object({
		rid: t.string(),
		parks: t.int(),
		campfire: t.int(),
		endgame: t.int(),
		photos: t.int(),
		parkAwards: t.int(),
		cons: t.int(),
		chalet: t.int(),
		photoAward: t.int(),
		total: t.int()
	})).nullable()
}), st = t.object({
	hand: t.array(t.string()),
	isTurn: t.boolean()
}), ct = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], V = (e, t) => ({
	code: `games.parkseurope.err.${e}`,
	...t ? { params: t } : {}
});
function H(t, n, r) {
	let i = r;
	for (let r = t.length - 1; r > 0; r--) {
		let a = e(n, i++, r + 1);
		[t[r], t[a]] = [t[a], t[r]];
	}
	return {
		items: t,
		cursor: i
	};
}
function U(e, t, n) {
	return {
		seat: e,
		res: {
			mountain: 0,
			forest: 0,
			sun: 0,
			water: 0,
			wildlife: 0
		},
		snow: 0,
		carabiners: 1,
		mug: 0,
		photos: 0,
		albums: 0,
		photosTaken: 0,
		visited: [],
		reserved: [],
		cons: [],
		parkAwards: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		consAwards: 0,
		consSets: 0,
		chaletAwards: [],
		wonderHand: [t],
		shutterbug: !1,
		chaletPos: 0,
		chaletOrder: n,
		hikers: [0, 0],
		slots: [null, null],
		sets: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		endUsed: [],
		endPoints: 0
	};
}
function lt(e, t, n, r) {
	let i = Math.min(r, e.supply[n]);
	i <= 0 || (e.supply[n] -= i, t.res[n] += i);
}
function ut(e, t, n) {
	let r = Math.min(n, e.supply.snow);
	r <= 0 || (e.supply.snow -= r, t.snow += r);
}
function W(e, t, n) {
	let r = Math.min(n, e.supply.carabiner);
	r <= 0 || (e.supply.carabiner -= r, t.carabiners += r);
}
function dt(e, t, n) {
	for (t.photosTaken += n, t.photos += n; t.photos >= 5 && t.albums < 8;) t.photos -= 5, t.albums += 1;
}
function ft(e, t, n) {
	for (let r = 0; r < n; r++) {
		if (e.wonderDeck.length === 0) {
			if (e.wonderDiscard.length === 0) return;
			let t = H(e.wonderDiscard.slice(), e.seed, e.cursor);
			e.wonderDeck = t.items, e.cursor = t.cursor, e.wonderDiscard = [];
		}
		let n = e.wonderDeck.pop();
		n && t.wonderHand.push(n);
	}
}
function pt(e, t) {
	for (let t of e.order) e.players[t].shutterbug = !1;
	t && e.players[t] && (e.players[t].shutterbug = !0);
}
function mt(e) {
	let t = e.snow * 2;
	for (let n of ct) t += e.res[n];
	return t;
}
function ht(e, t) {
	if (t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] > 0 && --e.supply[n];
}
function gt(e, t) {
	if (!t || t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] += 1;
}
function _t(e, t, n) {
	n === "photo" ? dt(e, t, 1) : n === "carabiner" ? t.carabiners += 1 : n === "snow" ? t.snow += 1 : t.res[n] += 1;
}
function vt(e, t, n) {
	let r = (e) => e.some((e) => e !== null && e.kind !== "parks" && e.kind === t && e.action === n);
	for (let t of e.order) if (r(e.players[t].slots)) return !0;
	return !!(e.greta && r(e.greta.slots));
}
function yt(e, t, n) {
	let r = Ge(t.res, n);
	if (!r) return !1;
	for (let n of ct) t.res[n] -= r[n], e.supply[n] += r[n];
	return !0;
}
function G(e, t) {
	e.tasks.push(t);
}
function bt(t, n) {
	let r = Re[e(t.seed, t.cursor++, Re.length)];
	if (r.carabiner && W(t, n, r.carabiner), r.res) for (let e of ct) r.res[e] && lt(t, n, e, r.res[e]);
	r.grant === "wonder" && ft(t, n, 1), r.grant === "photo" && dt(t, n, 1 + +!!n.shutterbug);
}
function xt(e, t, n) {
	switch (n) {
		case "die":
			bt(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "wonder":
			ft(e, t, 1);
			break;
		case "photo":
			dt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			lt(e, t, "wildlife", 1);
			break;
		case "carabiner": W(e, t, 1);
	}
}
function St(e, t, n) {
	switch (n.t) {
		case "res":
			lt(e, t, n.res, n.n);
			break;
		case "snow":
			ut(e, t, n.n);
			break;
		case "carabiner":
			W(e, t, n.n);
			break;
		case "photo":
			dt(e, t, n.n + +!!t.shutterbug);
			break;
		case "wonder":
			ft(e, t, n.n);
			break;
		case "die":
			for (let r = 0; r < n.n; r++) bt(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "cons":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "chalet":
			Tt(e, t);
			break;
		case "shutterbug": pt(e, e.turn ?? Ct(e, t));
	}
}
function Ct(e, t) {
	for (let n of e.order) if (e.players[n] === t) return n;
	return null;
}
function wt(e, t, n) {
	if (n === "snow") {
		ut(e, t, 1);
		return;
	}
	if (n === "chalet") {
		Tt(e, t);
		return;
	}
	xt(e, t, n);
}
function Tt(e, t) {
	let n = t.snow;
	if (n <= 0) return;
	e.supply.snow += n, t.snow = 0;
	let r = t.chaletPos, i = r, a = n;
	for (; a > 0 && i < ze;) i += 1, z[i].t === "snow" && --a;
	for (let n = r + 1; n <= i; n++) {
		let r = z[n];
		r.t === "wonder" ? ft(e, t, 1) : r.t === "award" && Dt(e, t, n, r);
	}
	t.chaletPos = i, t.chaletOrder = Et(e, i) + 1, e.chaletSeq = t.chaletOrder;
}
function Et(e, t) {
	let n = -1;
	for (let r of e.order) {
		let i = e.players[r];
		i.chaletPos === t && (n = Math.max(n, i.chaletOrder));
	}
	return n;
}
function Dt(e, t, n, r) {
	let i = !1;
	if (e.solo) e.chaletClaimed[n] || (e.chaletClaimed[n] = !0, t.chaletAwards.push(r.solo), i = !0);
	else if (r.stack !== null) {
		let n = e.chaletStacks[r.stack].pop();
		n !== void 0 && (t.chaletAwards.push(n), i = !0);
	}
	if (!i) {
		ft(e, t, 1);
		return;
	}
	e.solo && ft(e, t, 1);
}
function Ot(e, t) {
	let n = 0;
	for (let r of e.order) for (let i of e.players[r].hikers) i === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function kt(e, t, n) {
	let r = e.trailBonus[n];
	r && (e.trailBonus[n] = null, _t(e, t, r));
}
function At(e, t, n) {
	switch (n) {
		case "core-forest":
			lt(e, t, "forest", 1);
			break;
		case "core-sun":
			lt(e, t, "sun", 2);
			break;
		case "core-mountain":
			lt(e, t, "mountain", 1), ut(e, t, 1);
			break;
		case "core-water":
			lt(e, t, "water", 2), ut(e, t, 1);
			break;
		case "wildlife":
			lt(e, t, "wildlife", 1);
			break;
		case "carabiner":
			W(e, t, 1);
			break;
		case "die":
			bt(e, t);
			break;
		case "photo":
			dt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wonder":
			ft(e, t, 1);
			break;
		case "chalet":
			Tt(e, t);
			break;
		case "parks":
			G(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "conservation": G(e, {
			t: "cons",
			free: !1
		});
	}
}
function jt(e, t, n) {
	if (e.landingSite === null) return V("noConsSite");
	let r = Ie(e.trailSites[e.landingSite - 1]);
	if (!r) return V("noConsSite");
	let i = t.cons[n];
	return i === void 0 || I(i) !== r ? V("badCons") : e.consUsed.includes(n) ? V("consUsed") : (e.consUsed.push(n), xt(e, t, De[i % 7].benefit), null);
}
function Mt(e) {
	let t = F[e]?.cost ?? {};
	return {
		forest: t.forest ?? 0,
		mountain: t.mountain ?? 0,
		sun: t.sun ?? 0,
		water: t.water ?? 0,
		any: t.any ?? 0
	};
}
function Nt(e, t, n) {
	let r = {
		id: n,
		suit: null
	};
	t.visited.push(r);
	let i = Ce.filter((e) => t.visited.some((t) => t.id !== n && t.suit === e));
	if (i.length !== 0) {
		if (i.length === 1) {
			r.suit = i[0], Ft(e, t);
			return;
		}
		G(e, {
			t: "assignWild",
			parkId: n,
			suits: i
		});
	}
}
function Pt(e, t, n) {
	let r = F[n].suit;
	if (r === "wild") {
		Nt(e, t, n);
		return;
	}
	for (let e of t.visited) e.suit === null && (e.suit = r);
	t.visited.push({
		id: n,
		suit: r
	}), Ft(e, t);
}
function Ft(e, t) {
	for (let n of Ce) {
		let r = t.visited.filter((e) => e.suit === n).length, i = Math.floor(r / 3);
		for (; t.sets[n] < i;) t.sets[n] += 1, wt(e, t, we[n]), e.parkAwardPool[n] > 0 && (--e.parkAwardPool[n], t.parkAwards[n] += 1);
	}
}
function It(e, t, n) {
	n === "parks" ? (e.parkBonus.splice(t, 1), e.parksDisplay.splice(t, 1)) : (e.consBonus.splice(t, 1), e.consDisplay.splice(t, 1));
}
function Lt(e) {
	for (; e.parksDisplay.length < 3 && e.parksDeck.length > 0;) e.parksDisplay.unshift(e.parksDeck.shift()), e.parkBonus.unshift(null);
	for (; e.consDisplay.length < 3 && e.consDeck.length > 0;) e.consDisplay.unshift(e.consDeck.shift()), e.consBonus.unshift(null);
}
function Rt(e, t, n) {
	n && _t(e, t, n);
}
function zt(e, t, n) {
	let r = e.parkBonus[n] ?? null;
	It(e, n, "parks"), Rt(e, t, r);
}
function Bt(e, t, n) {
	let r = F[n];
	if (!r) return !1;
	let i = e.parksDisplay.indexOf(n), a = t.reserved.indexOf(n);
	return i < 0 && a < 0 || !yt(e, t, r.cost) ? !1 : (i >= 0 ? zt(e, t, i) : t.reserved.splice(a, 1), Pt(e, t, n), r.instant && wt(e, t, r.instant), !0);
}
function Vt(e, t, n, r, i) {
	let a;
	if (r) {
		if (!i && !yt(e, t, {
			sun: 1,
			water: 1
		})) return V("noRes");
		if (e.consDeck.length === 0) return V("badCons");
		a = e.consDeck.shift();
	} else {
		if (n === void 0 || n < 0 || n >= e.consDisplay.length) return V("badCons");
		if (a = e.consDisplay[n], !i && !yt(e, t, Ee[I(a)])) return V("noRes");
		Ht(e, t, n);
	}
	return t.cons.push(a), Ut(e, t), null;
}
function Ht(e, t, n) {
	let r = e.consBonus[n] ?? null;
	It(e, n, "cons"), Rt(e, t, r);
}
function Ut(e, t) {
	let n = Infinity;
	for (let e of Te) n = Math.min(n, t.cons.filter((t) => I(t) === e).length);
	for (Number.isFinite(n) || (n = 0); t.consSets < n;) t.consSets += 1, e.consAwardsLeft > 0 && (--e.consAwardsLeft, t.consAwards += 1);
}
function Wt(e) {
	e.moved = !1, e.landingSite = null, e.siteDone = !1, e.consUsed = [], e.vfUsed = !1, e.end = null, e.tasks = [];
}
function Gt(e, t) {
	return e.players[t].hikers.some((e) => e < 8);
}
function Kt(e) {
	return !!e.greta && e.greta.hikers.some((e) => e < 8);
}
function qt(e, t) {
	for (let n of e.order) if (n !== t && e.players[n].hikers.some((e) => e < 8)) return !1;
	return !Kt(e);
}
function Jt(e, t) {
	return t < e.order.length ? e.order[t] : "$greta";
}
function Yt(e) {
	let t = e.order.length + +!!e.greta;
	for (let n = 0; n < t * 4 + 8; n++) {
		let n = (e.turnIdx + 1) % t, r = Jt(e, n);
		if (r === "$greta") {
			if (e.turnIdx = n, !Kt(e)) continue;
			if (e.greta && e.greta.solo) {
				e.turn = e.order[0], e.gretaPending = !0;
				return;
			}
			hn(e, 0), Lt(e);
			continue;
		}
		if (Gt(e, r)) {
			e.turnIdx = n, e.turn = r, e.gretaPending = !1, Wt(e);
			return;
		}
	}
	en(e);
}
function Xt(e, t) {
	e.turnIdx = e.order.indexOf(t), e.turn = t, e.gretaPending = !1, Wt(e);
}
function Zt(e) {
	let t = e.order[0];
	for (let n of e.order) {
		let r = e.players[n], i = e.players[t];
		(r.chaletPos > i.chaletPos || r.chaletPos === i.chaletPos && r.chaletOrder > i.chaletOrder) && (t = n);
	}
	return t;
}
function Qt(e) {
	let t = e.seasonAdvanced[e.season - 1], n = H([...Ne, ...t], e.seed, e.cursor);
	e.cursor = n.cursor, e.trailSites = n.items.slice(0, 7);
}
function $t(e) {
	let t = Me[e.seasonQueue[e.season - 1]];
	Qt(e);
	for (let t of e.trailBonus) gt(e, t);
	let n = [null];
	for (let r of t.pattern) ht(e, r), n.push(r);
	e.trailBonus = n;
	for (let t of e.parkBonus) gt(e, t);
	for (let t of e.consBonus) gt(e, t);
	if (e.parkBonus = e.parksDisplay.map(() => null), e.consBonus = e.consDisplay.map(() => null), t.display) {
		let n = t.display.token;
		t.display.zone === "parks" ? e.parkBonus = e.parksDisplay.map(() => (ht(e, n), n)) : e.consBonus = e.consDisplay.map(() => (ht(e, n), n));
	}
	let r = e.order.length, i;
	i = r <= 3 ? [t.fires[0]] : r === 4 ? [t.fires[0], t.fires[1]] : [
		t.fires[0],
		t.fires[1],
		t.fires[2]
	], e.campfires = i.filter((e) => e >= 1 && e <= 7);
}
function en(e) {
	if (e.season >= 3) {
		sn(e);
		return;
	}
	e.season += 1;
	for (let t of e.order) {
		let n = e.players[t];
		n.hikers = n.hikers.map(() => 0), n.slots = n.slots.map(() => null);
	}
	e.greta && (e.greta.hikers = e.greta.hikers.map(() => 0), e.greta.slots = e.greta.slots.map(() => null)), $t(e), Xt(e, Zt(e));
}
function tn(e) {
	let t = {
		forest: 0,
		mountain: 0,
		sun: 0,
		water: 0,
		any: 0
	};
	for (let n of e.visited) {
		let e = Mt(n.id);
		t.forest += e.forest, t.mountain += e.mountain, t.sun += e.sun, t.water += e.water, t.any += e.any;
	}
	return t;
}
function nn(e) {
	let t = 0;
	for (let n of e.wonderHand) {
		let r = R[n];
		if (r) switch (r.effect) {
			case "consForest":
				t += e.cons.filter((e) => I(e) === "forest").length;
				break;
			case "consMountain":
				t += e.cons.filter((e) => I(e) === "mountain").length;
				break;
			case "consSun":
				t += e.cons.filter((e) => I(e) === "sun").length;
				break;
			case "consWater":
				t += e.cons.filter((e) => I(e) === "water").length;
				break;
			case "iconForest":
				t += Math.floor(tn(e).forest / 3);
				break;
			case "iconMountain":
				t += Math.floor(tn(e).mountain / 3);
				break;
			case "iconSun":
				t += Math.floor(tn(e).sun / 3);
				break;
			case "iconWater":
				t += Math.floor(tn(e).water / 3);
				break;
			case "anyIcons":
				t += Math.floor(tn(e).any / 2);
				break;
			case "album":
				t += e.albums;
				break;
			case "wonderHand":
				t += e.wonderHand.length;
				break;
			case "snow": t += e.snow;
		}
	}
	return t;
}
function rn(e, t) {
	return e.chaletPos === t.chaletPos ? t.chaletOrder - e.chaletOrder : t.chaletPos - e.chaletPos;
}
function an(e) {
	let t = 0;
	for (let n of e.visited) t += F[n.id].points;
	return t;
}
function on(e) {
	let t = 0;
	for (let n of Ce) {
		let r = e.visited.filter((e) => e.suit === n).length;
		t += e.parkAwards[n] * r;
	}
	return t;
}
function sn(e) {
	e.phase = "scoring", e.tasks = [], e.moved = !1, e.landingSite = null, e.siteDone = !0, e.consUsed = [], e.vfUsed = !0, e.end = null, e.gretaPending = !1, e.scoringIdx = 0, e.turnIdx = 0, e.turn = e.order[0] ?? null, e.campfireUsed = [];
	for (let t of e.order) e.players[t].endUsed = [], e.players[t].endPoints = 0;
}
var cn = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]);
function ln(e, t, n, r) {
	let i = 0;
	for (let e of ct) {
		let r = n[e] ?? 0;
		if (r > t.res[e]) return V("noRes");
		i += r;
	}
	if (i !== r) return V("noRes");
	for (let r of ct) {
		let i = n[r] ?? 0;
		i !== 0 && (t.res[r] -= i, e.supply[r] += i);
	}
	return null;
}
function un(e, t, n) {
	let r = e.players[t], i = R[n.card];
	if (!i || !cn.has(i.effect) || !r.wonderHand.includes(n.card) || e.campfireUsed.includes(n.card)) return V("badWonder");
	let a = n.pay ?? {};
	if (i.effect === "turnWildlife2") {
		if ((a.wildlife ?? 0) !== 2) return V("noRes");
		let t = ln(e, r, a, 2);
		if (t) return t;
		r.endPoints += 4;
	} else if (i.effect === "turnCarabiner") {
		if (n.carabiner !== !0 || r.carabiners < 1) return V("noCarabiner");
		--r.carabiners, e.supply.carabiner += 1, r.endPoints += 2;
	} else if (i.effect === "turnAny3") {
		let t = ln(e, r, a, 3);
		if (t) return t;
		r.endPoints += 3;
	} else {
		let n = ln(e, r, a, 2);
		if (n) return n;
		pt(e, t), dt(e, r, 2);
	}
	return e.campfireUsed.push(n.card), r.endUsed.push(n.card), null;
}
function dn(e) {
	let t = {}, n = [];
	for (let t of e.order) {
		let r = e.players[t], i = an(r), a = nn(r), o = r.endPoints, s = r.photos + r.albums * 5, c = on(r), l = r.consAwards * 5, u = r.chaletAwards.reduce((e, t) => e + t, 0), d = i + a + o + s + c + l + u;
		n.push({
			rid: t,
			parks: i,
			campfire: a,
			endgame: o,
			photos: s,
			parkAwards: c,
			cons: l,
			chalet: u,
			photoAward: 0,
			total: d
		});
	}
	let r = null;
	if (!e.solo) {
		let t = 0;
		for (let n of e.order) t = Math.max(t, e.players[n].photosTaken);
		if (t > 0) {
			let n = e.order.filter((n) => e.players[n].photosTaken === t);
			r = n[0];
			for (let t of n) rn(e.players[t], e.players[r]) < 0 && (r = t);
		}
	}
	for (let e of n) e.photoAward = e.rid === r ? 3 : 0, e.total += e.photoAward, t[e.rid] = e.total;
	let i = [...e.order].sort((n, r) => t[r] - t[n] || rn(e.players[n], e.players[r])), a = null;
	if (e.solo) {
		let n = t[e.order[0]];
		a = 0;
		for (let e of He) n >= e.at && (a = Math.max(a, e.rank));
	}
	e.final = {
		scores: t,
		ranking: i,
		winner: e.solo ? [] : [i[0]],
		soloRank: a,
		rows: n
	}, e.phase = "ended", e.tasks = [], e.end = null, e.gretaPending = !1, e.turn = null;
}
function fn(t, n, r) {
	let i = r * 2, a = [n.hikers[i], n.hikers[i + 1]].map((e, t) => ({
		pos: e,
		hiker: i + t
	})).filter((e) => e.pos < 8);
	if (a.length === 0) return;
	let o = Re[e(t.seed, t.cursor++, Re.length)];
	a.sort((e, t) => e.pos - t.pos);
	let s = o.ranger === "butterfly" ? a[0] : a[a.length - 1], c = o.symbols, l = s.pos, u = [];
	for (let e = l + 1; e <= 7; e++) {
		let n = Ot(t, e), r = t.campfires.includes(e);
		if ((n === 0 || r) && u.push(e), u.length >= c) break;
	}
	if (u.length < c) {
		n.hikers[s.hiker] = 8, pn(t, n, s.hiker), mn(t);
		return;
	}
	let d = u[c - 1];
	if (Ot(t, d) > 0) {
		let e = t.campfires.indexOf(d);
		e >= 0 && t.campfires.splice(e, 1);
	}
	n.hikers[s.hiker] = d, t.trailBonus[d - 1] && (gt(t, t.trailBonus[d - 1]), t.trailBonus[d - 1] = null), d === 4 && pt(t, null);
}
function pn(e, t, n) {
	for (let r of Be) if (!vt(e, "both", r)) {
		t.slots[n] = {
			kind: "both",
			action: r
		};
		return;
	}
	for (let r of Be) if (!vt(e, "top", r)) {
		t.slots[n] = {
			kind: "top",
			action: r
		};
		return;
	}
	t.slots[n] = { kind: "parks" };
}
function mn(e) {
	e.parksDisplay.length > 0 && (gt(e, e.parkBonus[e.parkBonus.length - 1] ?? null), It(e, e.parksDisplay.length - 1, "parks")), e.consDisplay.length > 0 && (gt(e, e.consBonus[e.consBonus.length - 1] ?? null), It(e, e.consDisplay.length - 1, "cons"));
}
function hn(e, t) {
	let n = e.greta;
	if (!n) return;
	let r = +(t === 1), i = n.colors >= 2 ? [r, 1 - r] : [0];
	for (let t of i) (n.hikers[t * 2] < 8 || n.hikers[t * 2 + 1] < 8) && fn(e, n, t);
}
function gn(e, t, n, r, i) {
	if (r < 1 || r > 8) return V("badTarget");
	if (t.hikers[n] >= 8) return V("badHiker");
	if (r !== 8 && r <= t.hikers[n]) return V("badTarget");
	if (r === 8) return i.slot ? i.slot.kind !== "parks" && vt(e, i.slot.kind, i.slot.action) ? V("full") : (t.hikers[n] = 8, t.slots[n] = i.slot, e.moved = !0, e.end = i.slot.kind === "parks" ? {
		action: null,
		topDone: !0,
		parksDone: !1
	} : {
		action: i.slot.action,
		topDone: !1,
		parksDone: i.slot.kind === "top"
	}, null) : V("badSlot");
	let a = r - 1;
	if (Ot(e, r) > 0) {
		if (i.campfire === "card") {
			let n = i.card ? t.wonderHand.indexOf(i.card) : -1;
			if (n < 0 || !R[i.card]) return V("noCampfire");
			e.wonderDiscard.push(t.wonderHand.splice(n, 1)[0]);
		} else {
			let t = e.campfires.indexOf(r);
			if (t < 0) return V("occupied");
			e.campfires.splice(t, 1);
		}
	}
	return t.hikers[n] = r, e.moved = !0, e.landingSite = r, e.siteDone = !1, e.consUsed = [], kt(e, t, a), r === 4 && pt(e, e.turn), null;
}
function _n(e, t, n) {
	switch (n) {
		case "conservation":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "carabiner":
			W(e, t, 1);
			break;
		case "mug":
			G(e, { t: "mug" });
			break;
		case "chalet": Tt(e, t);
	}
}
function vn(e, t, n, r) {
	if (r === "display") {
		let r = e.parksDisplay.indexOf(n);
		if (r < 0) return V("badPark");
		zt(e, t, r);
	} else if (r === "reserve") {
		let e = t.reserved.indexOf(n);
		if (e < 0) return V("badPark");
		t.reserved.splice(e, 1);
	} else {
		if (e.parksDeck.length === 0) return V("badPark");
		n = e.parksDeck.shift();
	}
	Pt(e, t, n);
	let i = F[n];
	return i.instant && wt(e, t, i.instant), null;
}
function yn(e, t) {
	if (e.landingSite === null || e.vfUsed) return V("noVf");
	if (t.carabiners < 1) return V("noCarabiner");
	let n = e.vf[e.landingSite - 1];
	if (!n) return V("noVf");
	switch (--t.carabiners, e.supply.carabiner += 1, e.vfUsed = !0, ut(e, t, 1), n) {
		case "wonder":
			ft(e, t, 1);
			break;
		case "sunwater":
			lt(e, t, "sun", 1), lt(e, t, "water", 1);
			break;
		case "photo":
			dt(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			lt(e, t, "wildlife", 1);
			break;
		case "conservation":
			G(e, {
				t: "cons",
				free: !1
			});
			break;
		case "mug": G(e, { t: "mug" });
	}
	return null;
}
function bn(e, t) {
	let n = t.mug;
	if (t.mug = 0, n === 1) G(e, { t: "mug1" });
	else if (n === 2) for (let n = 0; n < 3; n++) bt(e, t);
	else n >= 3 && G(e, { t: "freePark" });
}
function xn(e, t, n, r) {
	if (R[n]) return V("badWonder");
	let i = je[n];
	if (!i) return V("badWonder");
	let a = t.wonderHand.indexOf(n);
	if (a < 0) return V("badWonder");
	let o = r === "top" ? i.top : i.bottom;
	if (o.pay && !yt(e, t, o.pay)) return V("noRes");
	t.wonderHand.splice(a, 1), e.wonderDiscard.push(n);
	for (let n of o.grants) St(e, t, n);
	return null;
}
function Sn(e, t) {
	if (t.wonderHand.length > 3) for (let n = 0; n < t.wonderHand.length - 3; n++) G(e, { t: "discardWonder" });
	t.carabiners > 3 && (e.supply.carabiner += t.carabiners - 3, t.carabiners = 3);
	let n = mt(t) - 12, r = ct.reduce((e, n) => e + t.res[n], 0), i = Math.min(Math.max(0, n), r);
	for (let t = 0; t < i; t++) G(e, { t: "discardRes" });
	return e.tasks.length === 0;
}
function Cn(e) {
	if (Lt(e), [...e.order].every((t) => e.players[t].hikers.every((e) => e === 8)) && (!e.greta || e.greta.hikers.every((e) => e === 8))) {
		en(e);
		return;
	}
	Yt(e);
}
function wn(e, t, n) {
	let r = e;
	if (r.phase === "ended" || r.turn === null) return V("phase");
	if (n.by !== r.turn) return V("notTurn");
	let i = r.players[n.by];
	if (!i) return V("notPlayer");
	if (r.phase === "scoring") return t.type === "campfireEnd" ? un(r, n.by, t) ?? { state: r } : t.type === "scoringDone" ? (r.scoringIdx += 1, r.scoringIdx >= r.order.length ? dn(r) : (r.turn = r.order[r.scoringIdx], r.turnIdx = r.scoringIdx), { state: r }) : V("badAction");
	if (r.gretaPending) {
		if (t.type !== "gretaColor") return V("badAction");
		let e = r.greta;
		return !e || !e.solo ? V("badAction") : (r.gretaPending = !1, hn(r, t.first), Lt(r), Yt(r), { state: r });
	}
	let a = r.tasks.length > 0 ? r.tasks[r.tasks.length - 1] : null;
	if (t.type === "playWonder") return xn(r, i, t.card, t.side) ?? { state: r };
	if (t.type === "endTurn") return r.moved ? a ? V("badAction") : r.end && (!r.end.topDone || !r.end.parksDone) ? V("endIncomplete") : (Sn(r, i) && Cn(r), { state: r }) : V("mustMove");
	if (!a) {
		if (t.type === "siteAction") return !r.moved || r.landingSite === null || r.siteDone ? V("badAction") : (r.siteDone = !0, At(r, i, r.trailSites[r.landingSite - 1]), { state: r });
		if (t.type === "activateCons") return !r.moved || r.landingSite === null ? V("noConsSite") : jt(r, i, t.card) ?? { state: r };
		if (t.type === "endTop") return !r.end || r.end.topDone || !r.end.action ? V("badAction") : (r.end.topDone = !0, _n(r, i, r.end.action), { state: r });
		if (t.type === "endParks") return !r.end || r.end.parksDone ? V("badAction") : (r.end.parksDone = !0, G(r, {
			t: "parks",
			visited: !1
		}), { state: r });
	}
	if (a) {
		if (a.t === "parks") {
			if (t.type === "reserve") {
				if (a.visited) return V("badAction");
				if (t.from === "display") {
					if (t.index === void 0 || t.index < 0 || t.index >= r.parksDisplay.length) return V("badPark");
					i.reserved.push(r.parksDisplay[t.index]), zt(r, i, t.index);
				} else {
					if (r.parksDeck.length === 0) return V("badPark");
					i.reserved.push(r.parksDeck.shift());
				}
				return r.tasks.pop(), { state: r };
			}
			return t.type === "visit" ? Bt(r, i, t.parkId) ? (a.visited = !0, { state: r }) : V("badPark") : t.type === "parksDone" ? (r.tasks.pop(), { state: r }) : V("badAction");
		}
		if (a.t === "mug") {
			if (t.type !== "mug") return V("badAction");
			if (t.act === "fill") i.mug = Math.min(3, i.mug + 1);
			else {
				if (i.mug < 1) return V("badAction");
				bn(r, i);
			}
			return r.tasks.pop(), { state: r };
		}
		if (a.t === "mug1") return t.type === "mugChoice" ? (r.tasks.pop(), t.choice === "chalet" ? Tt(r, i) : G(r, {
			t: "cons",
			free: !0
		}), { state: r }) : V("badAction");
		if (a.t === "cons") return t.type === "consPick" ? Vt(r, i, t.index, t.deck === !0, a.free) || (r.tasks.pop(), { state: r }) : t.type === "skip" ? (r.tasks.pop(), { state: r }) : V("badAction");
		if (a.t === "assignWild") {
			if (t.type !== "assignWild") return V("badAction");
			if (!a.suits.includes(t.suit)) return V("badSuit");
			let e = i.visited.find((e) => e.id === a.parkId && e.suit === null);
			return e ? (e.suit = t.suit, r.tasks.pop(), Ft(r, i), { state: r }) : V("badPark");
		}
		if (a.t === "freePark") return t.type === "freePark" ? vn(r, i, t.parkId ?? 0, t.from) || (r.tasks.pop(), { state: r }) : V("badAction");
		if (a.t === "discardRes") return t.type !== "discardRes" || i.res[t.res] <= 0 ? V("badAction") : (--i.res[t.res], r.supply[t.res] += 1, r.tasks.pop(), { state: r });
		if (a.t === "discardWonder") {
			if (t.type !== "discardWonder") return V("badAction");
			let e = i.wonderHand.indexOf(t.card);
			return e < 0 ? V("badWonder") : (r.wonderDiscard.push(i.wonderHand.splice(e, 1)[0]), r.tasks.pop(), { state: r });
		}
		return V("badAction");
	}
	return t.type === "viaFerrata" ? r.moved ? yn(r, i) ?? { state: r } : V("mustMove") : t.type === "move" ? r.moved ? V("alreadyMoved") : t.to !== 8 && qt(r, n.by) ? V("mustEnd") : gn(r, i, t.hiker, t.to, t) || { state: r } : V("badAction");
}
function Tn(e) {
	if (e.phase === "ended") return "none";
	if (e.phase === "scoring") return "scoring";
	if (e.gretaPending) return "gretaColor";
	if (!e.moved) return e.turn !== null && qt(e, e.turn) ? "trailEnd" : "move";
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t ? t.t === "parks" ? "parks" : t.t === "mug" ? "mug" : t.t === "mug1" ? "mugChoice" : t.t === "cons" ? "cons" : t.t === "assignWild" ? "assignWild" : t.t === "freePark" ? "freePark" : t.t === "discardWonder" ? "discardWonder" : "discardRes" : "actions";
}
function En(e) {
	let t = (e) => e.some((e) => e !== null && e.kind === "parks");
	for (let n of e.order) if (t(e.players[n].slots)) return !0;
	return !!e.greta && t(e.greta.slots);
}
function Dn(e) {
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t !== null && t.t === "cons" && t.free;
}
function On(e, t) {
	let n = { ...e.res };
	return {
		rid: t,
		seat: e.seat,
		res: n,
		snow: e.snow,
		carabiners: e.carabiners,
		mug: e.mug,
		photos: e.photos,
		albums: e.albums,
		photosTaken: e.photosTaken,
		visited: e.visited.map((e) => ({
			id: e.id,
			suit: e.suit
		})),
		reserved: [...e.reserved],
		cons: [...e.cons],
		parkAwards: { ...e.parkAwards },
		consAwards: e.consAwards,
		chaletAwards: [...e.chaletAwards],
		wonderCount: e.wonderHand.length,
		shutterbug: e.shutterbug,
		chaletPos: e.chaletPos,
		chaletOrder: e.chaletOrder,
		hikers: [...e.hikers],
		atEnd: e.hikers.every((e) => e === 8),
		endUsed: [...e.endUsed],
		endPoints: e.endPoints
	};
}
function kn(e) {
	let t = (t, n) => {
		for (let r of e.order) if (e.players[r].slots.find((e) => e !== null && e.kind === t && e.action === n)) return r;
		return e.greta && e.greta.slots.some((e) => e !== null && e.kind === t && e.action === n) ? "$greta" : null;
	}, n = [];
	for (let e of Be) n.push({
		kind: "top",
		action: e,
		rid: t("top", e)
	}), n.push({
		kind: "both",
		action: e,
		rid: t("both", e)
	});
	return n;
}
var An = {
	meta: Ue,
	saveCompatibility: { version: "2" },
	schemas: {
		action: et,
		publicView: ot,
		privateView: st,
		config: tt
	},
	setup(e, t, n) {
		let r = tt.parse(e ?? {}), i = t.length === 1, a = i || t.length === 2 && r.greta, o = [...t], s = 0, c = H(Array.from({ length: 48 }, (e, t) => t), n, s);
		s = c.cursor;
		let l = c.items.slice(), u = l.splice(0, 3), d = H(Array.from({ length: 28 }, (e, t) => t), n, s);
		s = d.cursor;
		let f = d.items.slice(), p = f.splice(0, 3), m = H([...ke.map((e) => e.id), ...Ae.map((e) => e.id)], n, s);
		s = m.cursor;
		let h = m.items, g = H(Array.from({ length: Me.length }, (e, t) => t), n, s);
		s = g.cursor;
		let _ = g.items.slice(0, 3), v = H(Pe.slice(), n, s);
		s = v.cursor;
		let y = [
			v.items.slice(0, 3),
			v.items.slice(3, 6),
			v.items.slice(6, 9)
		], b = H(Le.slice(), n, s);
		s = b.cursor;
		let x = [], S = 0;
		for (let e = 0; e < 7; e++) x.push(e === 3 ? null : b.items[S++]);
		let C = H(o.slice(), n, s);
		s = C.cursor;
		let ee = {};
		o.forEach((e, t) => {
			let n = h.pop(), r = C.items.indexOf(e);
			ee[e] = U(t, n, r);
		});
		let w = o.length >= 4 ? 2 : 1, te = {
			phase: "turn",
			season: 1,
			order: o,
			players: ee,
			turnIdx: 0,
			turn: null,
			moved: !1,
			landingSite: null,
			siteDone: !1,
			consUsed: [],
			vfUsed: !1,
			end: null,
			tasks: [],
			gretaPending: !1,
			scoringIdx: 0,
			campfireUsed: [],
			trailSites: [],
			trailBonus: [
				null,
				null,
				null,
				null,
				null,
				null,
				null
			],
			campfires: [],
			vf: x,
			seasonAdvanced: y,
			seasonQueue: _,
			parkBonus: [
				null,
				null,
				null
			],
			consBonus: [
				null,
				null,
				null
			],
			parksDeck: l,
			parksDisplay: u,
			consDeck: f,
			consDisplay: p,
			parkAwardPool: {
				lime: w,
				orange: w,
				teal: w,
				purple: w
			},
			consAwardsLeft: 5,
			chaletStacks: [[
				3,
				4,
				5
			], [
				3,
				4,
				5
			]],
			chaletClaimed: z.map(() => !1),
			supply: {
				...Ve,
				carabiner: 15
			},
			wonderDeck: h,
			wonderDiscard: [],
			greta: a ? {
				solo: i,
				colors: i ? 2 : 1,
				hikers: Array(i ? 4 : 2).fill(0),
				slots: Array(i ? 4 : 2).fill(null)
			} : null,
			parkAwardsPerSuit: w,
			solo: i,
			seed: n,
			cursor: s,
			chaletSeq: o.length,
			final: null
		};
		return $t(te), Xt(te, Zt(te)), { state: te };
	},
	reduce: wn,
	viewFor(e, t) {
		let n = e, r = n.order.map((e) => On(n.players[e], e)), i = {
			phase: n.phase,
			season: n.season,
			turn: n.turn,
			moved: n.moved,
			pending: Tn(n),
			freeCons: Dn(n),
			landingSite: n.landingSite,
			siteDone: n.siteDone,
			consUsed: [...n.consUsed],
			vfUsed: n.vfUsed,
			end: n.end ? {
				action: n.end.action,
				topDone: n.end.topDone,
				parksDone: n.end.parksDone
			} : null,
			seasonCard: Me[n.seasonQueue[n.season - 1]].id,
			order: n.order,
			players: r,
			trailSites: n.trailSites,
			trailBonus: n.trailBonus,
			campfires: n.campfires,
			vf: n.vf,
			parksDisplay: n.parksDisplay,
			parksDeck: n.parksDeck.length,
			parksBonus: n.parkBonus,
			consDisplay: n.consDisplay,
			consDeck: n.consDeck.length,
			consBonus: n.consBonus,
			consAwardsLeft: n.consAwardsLeft,
			chaletStacks: n.chaletStacks.map((e) => [...e]),
			endSlots: kn(n),
			parksEndOccupied: En(n),
			greta: n.greta ? {
				hikers: [...n.greta.hikers],
				atEnd: n.greta.hikers.every((e) => e === 8),
				solo: n.greta.solo
			} : null,
			soloRanks: n.solo ? He.map((e) => ({
				at: e.at,
				rank: e.rank
			})) : null,
			revealedCampfire: n.phase === "scoring" || n.phase === "ended" ? n.order.map((e) => ({
				rid: e,
				cards: n.players[e].wonderHand.filter((e) => !!R[e])
			})) : null,
			campfireUsed: [...n.campfireUsed],
			finalRows: n.final ? n.final.rows.map((e) => ({ ...e })) : null
		}, a = n.players[t];
		return {
			public: i,
			private: {
				hand: a ? [...a.wonderHand] : [],
				isTurn: n.turn === t
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	}
}, jn = /* @__PURE__ */ "games.parkseurope.parkNames.p0,games.parkseurope.parkNames.p1,games.parkseurope.parkNames.p2,games.parkseurope.parkNames.p3,games.parkseurope.parkNames.p4,games.parkseurope.parkNames.p5,games.parkseurope.parkNames.p6,games.parkseurope.parkNames.p7,games.parkseurope.parkNames.p8,games.parkseurope.parkNames.p9,games.parkseurope.parkNames.p10,games.parkseurope.parkNames.p11,games.parkseurope.parkNames.p12,games.parkseurope.parkNames.p13,games.parkseurope.parkNames.p14,games.parkseurope.parkNames.p15,games.parkseurope.parkNames.p16,games.parkseurope.parkNames.p17,games.parkseurope.parkNames.p18,games.parkseurope.parkNames.p19,games.parkseurope.parkNames.p20,games.parkseurope.parkNames.p21,games.parkseurope.parkNames.p22,games.parkseurope.parkNames.p23,games.parkseurope.parkNames.p24,games.parkseurope.parkNames.p25,games.parkseurope.parkNames.p26,games.parkseurope.parkNames.p27,games.parkseurope.parkNames.p28,games.parkseurope.parkNames.p29,games.parkseurope.parkNames.p30,games.parkseurope.parkNames.p31,games.parkseurope.parkNames.p32,games.parkseurope.parkNames.p33,games.parkseurope.parkNames.p34,games.parkseurope.parkNames.p35,games.parkseurope.parkNames.p36,games.parkseurope.parkNames.p37,games.parkseurope.parkNames.p38,games.parkseurope.parkNames.p39,games.parkseurope.parkNames.p40,games.parkseurope.parkNames.p41,games.parkseurope.parkNames.p42,games.parkseurope.parkNames.p43,games.parkseurope.parkNames.p44,games.parkseurope.parkNames.p45,games.parkseurope.parkNames.p46,games.parkseurope.parkNames.p47".split(","), Mn = {
	b01: "games.parkseurope.wonderNames.b01",
	b02: "games.parkseurope.wonderNames.b02",
	b03: "games.parkseurope.wonderNames.b03",
	b04: "games.parkseurope.wonderNames.b04",
	b05: "games.parkseurope.wonderNames.b05",
	b06: "games.parkseurope.wonderNames.b06",
	b07: "games.parkseurope.wonderNames.b07",
	b08: "games.parkseurope.wonderNames.b08",
	b09: "games.parkseurope.wonderNames.b09",
	b10: "games.parkseurope.wonderNames.b10",
	b11: "games.parkseurope.wonderNames.b11",
	b12: "games.parkseurope.wonderNames.b12",
	b13: "games.parkseurope.wonderNames.b13",
	b14: "games.parkseurope.wonderNames.b14",
	b16: "games.parkseurope.wonderNames.b16",
	b17: "games.parkseurope.wonderNames.b17",
	b18: "games.parkseurope.wonderNames.b18",
	b19: "games.parkseurope.wonderNames.b19",
	b20: "games.parkseurope.wonderNames.b20",
	b21: "games.parkseurope.wonderNames.b21"
};
function Nn(e, t) {
	return e(jn[t]);
}
function Pn(e, t) {
	let n = R[t];
	return n ? e("games.parkseurope.campfireCardName", { n: String(n.no).padStart(2, "0") }) : e(Mn[t] ?? "games.parkseurope.siteShort.wonder");
}
//#endregion
//#region src/game/field-components.tsx
var Fn = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any",
	carabiner: "games.parkseurope.token.carabiner",
	photo: "games.parkseurope.token.photo",
	mug: "games.parkseurope.siteShort.mug",
	wonder: "games.parkseurope.siteShort.wonder",
	die: "games.parkseurope.siteShort.die",
	chalet: "games.parkseurope.siteShort.chalet",
	parks: "games.parkseurope.siteShort.parks",
	cons: "games.parkseurope.consTitle",
	campfire: "games.parkseurope.campfireLabel",
	award: "games.parkseurope.fieldAward"
};
function K({ kind: e }) {
	return e === "campfire" ? null : /* @__PURE__ */ b("img", {
		className: "pke-mark",
		"data-kind": e,
		src: v("games/parkseurope/marks/" + (e === "cons" ? "conservation" : e) + ".webp"),
		alt: "",
		"aria-hidden": !0
	});
}
function q({ kind: e, count: t }) {
	let n = u()(Fn[e]);
	return /* @__PURE__ */ x("span", {
		className: "pke-piece",
		"data-kind": e,
		role: "img",
		title: n,
		"aria-label": t === void 0 ? n : `${n} ×${t}`,
		children: [e === "campfire" ? n : /* @__PURE__ */ b(K, { kind: e }), t !== void 0 && /* @__PURE__ */ b("b", { children: t })]
	});
}
var In = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"any"
];
function Ln({ cost: e, free: t = !1 }) {
	let n = u(), r = In.filter((t) => (e[t] ?? 0) > 0);
	return /* @__PURE__ */ b("span", {
		className: "pke-cost-tokens",
		children: t || r.length === 0 ? n("games.parkseurope.free") : r.map((t) => /* @__PURE__ */ b(q, {
			kind: t,
			count: e[t]
		}, t))
	});
}
function Rn({ park: e, suitLabel: t, effect: n, bonus: r, picked: i, free: a, onPick: o }) {
	let s = u();
	return /* @__PURE__ */ x(o ? "button" : "article", {
		type: o ? "button" : void 0,
		className: "pke-park-face",
		"data-suit": e.suit,
		"aria-pressed": o ? i : void 0,
		onClick: o,
		children: [/* @__PURE__ */ x("span", {
			className: "pke-park-art",
			children: [/* @__PURE__ */ b("img", {
				loading: "lazy",
				decoding: "async",
				src: v(`games/parkseurope/parks/${e.id}.webp`),
				alt: ""
			}), /* @__PURE__ */ b("b", {
				className: "pke-park-score",
				children: s("games.parkseurope.points", { n: e.points })
			})]
		}), /* @__PURE__ */ x("span", {
			className: "pke-park-info",
			children: [
				/* @__PURE__ */ b("strong", {
					className: "pke-park-name",
					children: Nn(s, e.id)
				}),
				/* @__PURE__ */ x("span", {
					className: "pke-park-suit",
					children: [/* @__PURE__ */ b("i", { "aria-hidden": !0 }), t]
				}),
				/* @__PURE__ */ b(Ln, {
					cost: e.cost,
					free: a
				}),
				/* @__PURE__ */ x("span", {
					className: "pke-park-effect",
					children: [e.instant && n && /* @__PURE__ */ x("span", {
						className: "pke-effect-line",
						children: [/* @__PURE__ */ b(K, { kind: e.instant }), /* @__PURE__ */ b("span", { children: n })]
					}), r && /* @__PURE__ */ x("span", {
						className: "pke-effect-line",
						children: [
							/* @__PURE__ */ b("b", {
								"aria-hidden": "true",
								children: "+"
							}),
							/* @__PURE__ */ b(q, { kind: r }),
							/* @__PURE__ */ b("span", { children: s("games.parkseurope.displayBonus") })
						]
					})]
				})
			]
		})]
	});
}
function zn({ player: e }) {
	let t = u(), n = r(), [i, a] = s(null), o = i === "snow" ? e.snow : i === "carabiner" ? e.carabiners : i ? e.res[i] : 0, c = i === "snow" || i === "wildlife" || i === "carabiner" ? i : "regular", l = (e) => a(i === e ? null : e), d = [];
	for (let t = 0; t < e.snow; t++) d.push({
		kind: "snow",
		index: t
	});
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]) for (let n = 0; n < e.res[t]; n++) d.push({
		kind: t,
		index: n
	});
	let f = d.length + e.snow;
	return /* @__PURE__ */ x("div", {
		className: "pke-res-mat",
		children: [
			/* @__PURE__ */ x("div", {
				className: "pke-mat-capacity",
				children: [/* @__PURE__ */ b("b", { children: t("games.parkseurope.packSlots") }), /* @__PURE__ */ b("output", { children: t("games.parkseurope.packUsage", { used: f }) })]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-mat-sockets",
				"aria-label": t("games.parkseurope.packUsage", { used: f }),
				children: [d.map(({ kind: e, index: r }) => /* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-mat-socket",
					"data-kind": e,
					"aria-label": t(Fn[e]),
					"aria-expanded": i === e && o > 0,
					"aria-controls": n,
					onClick: () => l(e),
					children: /* @__PURE__ */ b(q, { kind: e })
				}, `${e}:${r}`)), Array.from({ length: Math.max(0, 12 - f) }, (e, t) => /* @__PURE__ */ b("div", {
					className: "pke-mat-socket",
					"aria-hidden": "true"
				}, `empty:${t}`))]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-gear",
				children: [/* @__PURE__ */ b("span", { children: t("games.parkseurope.token.carabiner") }), /* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": t(Fn.carabiner),
					"aria-expanded": i === "carabiner",
					"aria-controls": n,
					onClick: () => l("carabiner"),
					children: /* @__PURE__ */ b(q, {
						kind: "carabiner",
						count: e.carabiners
					})
				})]
			}),
			/* @__PURE__ */ b("div", {
				id: n,
				className: "pke-resource-detail",
				hidden: !i || i !== "carabiner" && o === 0,
				children: i && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("div", { children: [
					/* @__PURE__ */ b(K, { kind: i }),
					/* @__PURE__ */ b("strong", { children: t(Fn[i]) }),
					/* @__PURE__ */ b("span", { children: t("games.parkseurope.fieldResourceCount", { n: o }) }),
					/* @__PURE__ */ b("span", { children: t("games.parkseurope.fieldResourceSlots", { n: i === "snow" ? 2 : i === "carabiner" ? 0 : 1 }) })
				] }), /* @__PURE__ */ b("p", { children: t(`games.parkseurope.fieldResourceUse.${c}`) })] })
			})
		]
	});
}
//#endregion
//#region src/game/field-objects.tsx
var Bn = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
}, Vn = (e) => v(`games/parkseurope/objects/${e}.webp`);
function Hn({ award: e, reveal: t = !1 }) {
	let n = u(), r = e.kind, i = r === "parks" ? e.suit : r === "cons" ? "conservation" : "photo", a = r === "chalet" ? e.points : r === "cons" ? 5 : r === "photo" ? 3 : 1, o = r === "parks" ? n("games.parkseurope.fx.parkAward", {
		suit: n(Bn[e.suit]),
		count: e.count
	}) : r === "cons" ? n("games.parkseurope.consAwardsLabel", { n: e.count }) : r === "chalet" ? n("games.parkseurope.fx.chaletAward", { points: a }) : n("games.parkseurope.resultPhotoAward");
	return /* @__PURE__ */ x("span", {
		className: "pke-award-piece",
		"data-kind": r,
		"data-suit": r === "parks" ? e.suit : void 0,
		"data-reveal": t,
		role: "img",
		"aria-label": o,
		title: o,
		children: [
			r !== "chalet" && /* @__PURE__ */ b("img", {
				className: "pke-award-illustration",
				src: Vn("award-" + i),
				alt: ""
			}),
			(r === "chalet" || r === "photo" || r === "parks" && t) && /* @__PURE__ */ b("b", {
				className: "pke-award-score",
				children: a
			}),
			"count" in e && e.count > 1 && /* @__PURE__ */ x("b", {
				className: "pke-award-count",
				children: ["×", e.count]
			})
		]
	});
}
function Un({ player: e }) {
	let t = u(), n = [...Ce.map((n) => [
		{
			kind: "parks",
			suit: n,
			count: e.parkAwards[n]
		},
		t(Bn[n]),
		t("games.parkseurope.awardParkDetail", { benefit: t(Fn[we[n]]) })
	]), [
		{
			kind: "cons",
			count: e.consAwards
		},
		t("games.parkseurope.fieldProjects"),
		t("games.parkseurope.awardFixedDetail", { n: 5 })
	]], r = e.chaletAwards.map((e) => [
		{
			kind: "chalet",
			points: e
		},
		t("games.parkseurope.fieldChalet"),
		t("games.parkseurope.awardFixedDetail", { n: e })
	]);
	return /* @__PURE__ */ x("div", {
		className: "pke-award-tray",
		children: [/* @__PURE__ */ b("h3", { children: t("games.parkseurope.fieldHonors") }), /* @__PURE__ */ b("ul", { children: [...n, ...r].map(([e, t, n], r) => {
			let i = !("count" in e) || e.count > 0;
			return /* @__PURE__ */ x("li", {
				className: "pke-award-well",
				"data-owned": i,
				"data-kind": e.kind,
				"data-suit": e.kind === "parks" ? e.suit : void 0,
				children: [
					/* @__PURE__ */ b("span", {
						className: "pke-award-recess",
						children: i ? /* @__PURE__ */ b(Hn, { award: e }) : /* @__PURE__ */ b("i", { "aria-hidden": !0 })
					}),
					/* @__PURE__ */ b("strong", {
						title: i ? n : void 0,
						children: t
					}),
					i && /* @__PURE__ */ b("span", {
						className: "pke-award-explanation",
						children: n
					})
				]
			}, r);
		}) })]
	});
}
function Wn() {
	return /* @__PURE__ */ b("img", {
		className: "pke-album-art",
		src: Vn("award-album"),
		alt: "",
		"aria-hidden": !0
	});
}
var Gn = {
	snow: "snow",
	carabiner: "carabiner",
	photo: "photo",
	wonder: "wonder",
	die: "die",
	parks: "parks",
	mug: "mug",
	cons: "cons",
	chalet: "chalet"
};
function Kn({ grants: e }) {
	let t = u();
	return /* @__PURE__ */ b("span", {
		className: "pke-wonder-grants",
		children: e.map((e, n) => {
			if (e.t === "shutterbug") return /* @__PURE__ */ b("img", {
				className: "pke-shutterbug-art",
				src: Vn("award-shutterbug"),
				alt: t("games.parkseurope.shutterbug")
			}, n);
			let r = e.t === "res" ? e.res : Gn[e.t], i = "n" in e && e.n > 1 ? e.n : void 0;
			return /* @__PURE__ */ b(q, {
				kind: r,
				count: i
			}, n);
		})
	});
}
function qn({ face: e, side: t, used: n, enabled: r, onPlay: i, titleId: a, waiting: o }) {
	let s = u(), c = i ? "button" : "div", l = e.pay && Object.values(e.pay).some(Boolean), d = s(t === "top" ? "games.parkseurope.wonder.top" : "games.parkseurope.wonder.bottom"), f = a + "-" + t, p = f + "-status";
	return /* @__PURE__ */ x(c, {
		className: "pke-wonder-action",
		"data-side": t,
		"data-used": n,
		"aria-labelledby": i ? a + " " + f : void 0,
		"aria-describedby": i && !r ? p : void 0,
		type: i ? "button" : void 0,
		disabled: i ? !r : void 0,
		onClick: i ? () => i(t) : void 0,
		children: [/* @__PURE__ */ x("span", {
			id: f,
			className: "pke-wonder-command",
			children: [
				/* @__PURE__ */ x("b", {
					className: "sr-only",
					children: [d, " "]
				}),
				l && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Ln, { cost: e.pay ?? {} }), /* @__PURE__ */ b("span", {
					className: "pke-wonder-arrow",
					"aria-hidden": !0,
					children: "›"
				})] }),
				/* @__PURE__ */ b(Kn, { grants: e.grants })
			]
		}), i && /* @__PURE__ */ b("span", {
			id: p,
			className: "pke-wonder-play",
			children: s(o ? "games.parkseurope.wonderWait" : r ? "games.parkseurope.wonderPlay" : "games.parkseurope.cannotAfford")
		})]
	});
}
function Jn({ id: e, used: t, campEffect: n, canUse: i, onPlay: a, waiting: o }) {
	let s = u(), c = r(), l = je[e];
	if (!l && !R[e]) return null;
	let d = Pn(s, e);
	if (!l) return /* @__PURE__ */ x("article", {
		className: "pke-wonder pke-wonder-face pke-wonder-campfire",
		children: [
			/* @__PURE__ */ b("img", {
				src: Vn("campfire"),
				alt: ""
			}),
			/* @__PURE__ */ b("header", { children: /* @__PURE__ */ b("b", { children: d }) }),
			/* @__PURE__ */ b("span", {
				className: "pke-campfire-use",
				children: s("games.parkseurope.wonderShare")
			}),
			n && /* @__PURE__ */ x("div", {
				className: "pke-campfire-score",
				children: [/* @__PURE__ */ b("strong", { children: s("games.parkseurope.wonderScore") }), /* @__PURE__ */ b("p", { children: n })]
			})
		]
	});
	let f = `url("${Vn("wonder-" + String(l.no).padStart(2, "0"))}")`;
	return /* @__PURE__ */ x("article", {
		className: "pke-wonder pke-wonder-face",
		style: { "--pke-wonder-art": f },
		children: [
			/* @__PURE__ */ b(qn, {
				face: l.top,
				side: "top",
				titleId: c,
				used: t === "top",
				enabled: !o && (i?.("top") ?? !0),
				waiting: o,
				onPlay: a
			}),
			/* @__PURE__ */ b("header", { children: /* @__PURE__ */ b("b", {
				id: c,
				children: d
			}) }),
			/* @__PURE__ */ b(qn, {
				face: l.bottom,
				side: "bottom",
				titleId: c,
				used: t === "bottom",
				enabled: !o && (i?.("bottom") ?? !0),
				waiting: o,
				onPlay: a
			})
		]
	});
}
var Yn = {
	sun: [
		"#f3ca64",
		"#8d5d20",
		"#fff0b8"
	],
	mountain: [
		"#f0a4ab",
		"#8d344f",
		"#ffdde0"
	],
	water: [
		"#a8dded",
		"#20608a",
		"#d5f4fb"
	],
	forest: [
		"#b9d87c",
		"#385e39",
		"#e4f1bd"
	]
};
function Xn({ id: e, name: t, site: n, benefit: r, bonus: i, supported: a, free: o, action: s }) {
	let c = u(), l = I(e), [d, f, p] = Yn[l];
	return /* @__PURE__ */ x("article", {
		className: "pke-project-face",
		"data-supported": a,
		style: {
			"--stock": d,
			"--mark-ink": f,
			"--paper": p
		},
		children: [
			/* @__PURE__ */ x("div", {
				className: "pke-project-plate",
				children: [/* @__PURE__ */ b(K, { kind: l }), /* @__PURE__ */ b(K, { kind: "cons" })]
			}),
			/* @__PURE__ */ x("header", { children: [/* @__PURE__ */ b("strong", { children: t }), /* @__PURE__ */ b("span", { children: n })] }),
			/* @__PURE__ */ x("div", {
				className: "pke-project-reward",
				children: [/* @__PURE__ */ b(q, { kind: De[e % 7].benefit }), /* @__PURE__ */ b("span", { children: r })]
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-project-foot",
				children: [a ? /* @__PURE__ */ b("span", { children: c("games.parkseurope.fieldSupported") }) : /* @__PURE__ */ b(Ln, {
					cost: Ee[l],
					free: o
				}), i && /* @__PURE__ */ x("span", {
					"aria-label": c("games.parkseurope.displayBonus"),
					children: ["+ ", /* @__PURE__ */ b(q, { kind: i })]
				})]
			}),
			s && /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: s.disabled,
				onClick: s.onPress,
				children: s.label
			})
		]
	});
}
//#endregion
//#region src/game/field-motion.tsx
var Zn = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple"
};
function Qn(e, t, n) {
	let r = n && Ge(e.res, n), i = We.map((n) => ({
		kind: n,
		count: t.res[n] - e.res[n] + (r?.[n] ?? 0)
	}));
	return i.push({
		kind: "snow",
		count: t.snow - e.snow
	}, {
		kind: "carabiner",
		count: t.carabiners - e.carabiners
	}), i.filter(({ count: e }) => e > 0);
}
function $n(e, t) {
	let n = [];
	for (let r of Ce) {
		let i = t.parkAwards[r] - e.parkAwards[r];
		i > 0 && n.push({
			kind: "parks",
			suit: r,
			count: i
		});
	}
	t.consAwards > e.consAwards && n.push({
		kind: "cons",
		count: t.consAwards - e.consAwards
	});
	for (let r of t.chaletAwards.slice(e.chaletAwards.length)) n.push({
		kind: "chalet",
		points: r
	});
	return n;
}
function er(e, t) {
	return t.season < e.season || t.season - e.season > 1 ? !1 : e.players.every((e) => {
		let n = t.players.find(({ rid: t }) => t === e.rid);
		return !!n && n.photosTaken >= e.photosTaken && n.chaletPos >= e.chaletPos && e.visited.every(({ id: e }, t) => n.visited[t]?.id === e) && e.cons.every((e, t) => n.cons[t] === e);
	});
}
function tr(e, t) {
	if (!t) return;
	let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
	if (!(r.width === 0 || r.height === 0 || r.right <= n.left || r.left >= n.right || r.bottom <= n.top || r.top >= n.bottom)) return {
		point: {
			x: r.left - n.left + r.width / 2,
			y: r.top - n.top + r.height / 2
		},
		width: r.width
	};
}
function nr(e, t, n, r, i) {
	if (e?.type === "campfireEnd" && !r.campfireUsed.includes(e.card) && i.campfireUsed.includes(e.card)) return { id: e.card };
	if ((e?.type === "playWonder" || e?.type === "move" && e.campfire === "card") && e.card && t.includes(e.card) && !n.includes(e.card) && (e.type !== "move" || i.moved)) return {
		id: e.card,
		side: e.type === "playWonder" ? e.side : void 0
	};
}
function rr(e, t, n, r, i) {
	if (t?.side) return je[t.id]?.[t.side].pay;
	if (e?.type === "visit" && r.visited.length > n.visited.length && r.visited.at(-1)?.id === e.parkId) return F[e.parkId]?.cost;
	if (e?.type !== "consPick" || i.freeCons || r.cons.length <= n.cons.length) return;
	if (e.deck) return {
		sun: 1,
		water: 1
	};
	let a = e.index === void 0 ? void 0 : i.consDisplay[e.index];
	return a === void 0 ? void 0 : Ee[I(a)];
}
function ir(e, t, n) {
	let r = e?.card ? 390 : 0, i = e?.gains.length ? 760 : 0, a = e?.awards.some(({ rid: e }) => e === t) ? 1400 : e?.awards.length ? 1120 : 0;
	return n ? {
		gainDelay: 0,
		awardDelay: 0,
		duration: 1400
	} : {
		gainDelay: r,
		awardDelay: r + i,
		duration: r + i + a
	};
}
function ar(e, t, r) {
	let i = o(null), a = o(null), c = o(null), l = o(null), u = o(0), [d, f] = s({
		self: r,
		frames: []
	}), p = S(), m = d.self === r ? d.frames[0] : void 0, h = ir(m, r, p);
	function g(e) {
		let t = e.target instanceof Element ? e.target.closest("button") : null;
		if (!t || !i.current) return;
		a.current = {
			origin: tr(i.current, t),
			card: tr(i.current, t.closest(".pke-wonder, .pke-scoring-card"))
		};
		let n = a.current;
		queueMicrotask(() => {
			a.current === n && (a.current = null);
		});
	}
	function _(t) {
		c.current = {
			scope: e,
			action: t,
			origin: a.current?.origin,
			card: a.current?.card
		};
	}
	return n(() => {
		let n = l.current;
		if (l.current = {
			pub: e,
			hand: t,
			self: r
		}, !n || n.self !== r || !er(n.pub, e) || e.order.length !== n.pub.order.length || !e.order.every((e) => n.pub.order.includes(e)) || n.pub.phase === "ended" && e.phase !== "ended") {
			c.current = null, queueMicrotask(() => f({
				self: r,
				frames: []
			}));
			return;
		}
		let a = n.pub.players.find(({ rid: e }) => e === r), o = e.players.find(({ rid: e }) => e === r);
		if (!i.current || !a || !o || n.pub === e) return;
		let s = c.current?.scope === n.pub ? c.current : null;
		c.current = null;
		let d = nr(s?.action, n.hand, t, n.pub, e);
		d && (d.origin = s?.card ?? s?.origin);
		let p = Qn(a, o, rr(s?.action, d, a, o, n.pub)), m = [];
		for (let t of e.players) {
			let e = n.pub.players.find(({ rid: e }) => e === t.rid);
			if (!e) continue;
			let r = $n(e, t);
			r.length && m.push({
				rid: t.rid,
				awards: r
			});
		}
		if (!d && p.length === 0 && m.length === 0) return;
		let h = tr(i.current, i.current.querySelector(".pke-field-stage")), g = e.landingSite ?? n.pub.landingSite, _ = g === null ? null : i.current.querySelector(`.pke-valley-pin[data-stop="${g}"]:not([hidden])`), v = d?.origin?.point ?? tr(i.current, _)?.point ?? s?.origin?.point ?? h?.point, y = tr(i.current, i.current.querySelector("[data-panel=\"pack\"]"))?.point, b = {
			id: ++u.current,
			gains: p,
			awards: m,
			card: d,
			origin: v,
			target: y
		};
		queueMicrotask(() => f((e) => ({
			self: r,
			frames: e.self === r ? [...e.frames, b] : [b]
		})));
	}, [
		e,
		t,
		r
	]), n(() => {
		if (!m) return;
		let e = window.setTimeout(() => {
			f((e) => e.frames[0]?.id === m.id ? {
				...e,
				frames: e.frames.slice(1)
			} : e);
		}, h.duration);
		return () => window.clearTimeout(e);
	}, [m, h.duration]), {
		root: i,
		capture: g,
		record: _,
		active: m,
		timing: h
	};
}
function or(e, t) {
	return e ? {
		[`--pke-fx-${t}-x`]: `${e.x}px`,
		[`--pke-fx-${t}-y`]: `${e.y}px`
	} : {};
}
function sr({ frame: e, self: t, timing: n, nameOf: r }) {
	let i = u();
	if (!e) return /* @__PURE__ */ b("div", { className: "pke-fx" });
	let a = (e) => e.awards.map((e) => e.kind === "parks" ? i("games.parkseurope.fx.parkAward", {
		suit: i(Zn[e.suit]),
		count: e.count
	}) : e.kind === "chalet" ? i("games.parkseurope.fx.chaletAward", { points: e.points }) : e.kind === "cons" ? i("games.parkseurope.consAwardsLabel", { n: e.count }) : i("games.parkseurope.resultPhotoAward")), o = e.awards.find(({ rid: e }) => e === t), s = e.awards.filter(({ rid: e }) => e !== t), c = {
		"--pke-gain-delay": `${n.gainDelay}ms`,
		"--pke-award-delay": `${n.awardDelay}ms`
	};
	return /* @__PURE__ */ x("div", {
		className: "pke-fx",
		style: c,
		children: [
			/* @__PURE__ */ x("span", {
				className: "sr-only",
				role: "status",
				children: [
					e.card && i("games.parkseurope.fx.cardUsed", { card: Pn(i, e.card.id) }),
					" ",
					e.gains.map(({ kind: e, count: t }) => `+${t} ${i(Fn[e])}`).join(" · "),
					" ",
					e.awards.map((e) => `${r(e.rid)} · ${a(e).join(" · ")}`).join(" · ")
				]
			}),
			e.card && /* @__PURE__ */ b("div", {
				className: "pke-fx-card",
				"aria-hidden": "true",
				"data-card": e.card.id,
				style: {
					...or(e.card.origin?.point, "from"),
					"--pke-fx-card-width": `${e.card.origin?.width ?? 160}px`
				},
				children: /* @__PURE__ */ b(Jn, {
					id: e.card.id,
					used: e.card.side
				})
			}),
			e.gains.length > 0 && /* @__PURE__ */ x("div", {
				className: "pke-fx-gains",
				"aria-hidden": "true",
				style: {
					...or(e.origin, "from"),
					...or(e.target, "to")
				},
				children: [e.gains.map(({ kind: e, count: t }, n) => /* @__PURE__ */ b("span", {
					className: "pke-fx-flight",
					style: {
						"--pke-fx-step": n,
						"--pke-fx-rise": `${44 + n * 12}px`
					},
					children: /* @__PURE__ */ b(q, {
						kind: e,
						count: t
					})
				}, e)), /* @__PURE__ */ b("div", {
					className: "pke-fx-pack-receipt",
					children: e.gains.map(({ kind: e, count: t }) => /* @__PURE__ */ x("span", {
						className: "pke-fx-gain",
						children: [/* @__PURE__ */ b(q, { kind: e }), /* @__PURE__ */ x("b", { children: ["+", t] })]
					}, e))
				})]
			}),
			o && /* @__PURE__ */ x("div", {
				className: "pke-fx-honor",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ b("div", { className: "pke-fx-sunburst" }), /* @__PURE__ */ x("div", {
					className: "pke-fx-honor-card",
					children: [
						/* @__PURE__ */ b("div", {
							className: "pke-fx-emblems",
							children: o.awards.map((e, t) => /* @__PURE__ */ b(Hn, {
								award: e,
								reveal: !0
							}, t))
						}),
						/* @__PURE__ */ b("strong", { children: i("games.parkseurope.fx.honorEarned") }),
						a(o).map((e, t) => /* @__PURE__ */ b("span", { children: e }, t))
					]
				})]
			}),
			s.length > 0 && /* @__PURE__ */ b("div", {
				className: "pke-fx-other",
				"aria-hidden": "true",
				children: s.map((e) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("strong", { children: r(e.rid) }), /* @__PURE__ */ b("span", { children: a(e).join(" · ") })] }, e.rid))
			})
		]
	}, e.id);
}
//#endregion
//#region src/game/field-tracks.tsx
function cr({ items: e, active: t, onSelect: n, label: r }) {
	return /* @__PURE__ */ b("div", {
		className: "pke-field-tabs",
		role: "group",
		"aria-label": r,
		children: e.map(([e, r]) => /* @__PURE__ */ b("button", {
			type: "button",
			"aria-pressed": e === t,
			onClick: () => n(e),
			children: r
		}, e))
	});
}
var lr = [
	[13, 87],
	[13, 72],
	[13, 57],
	[14, 42],
	[22, 25],
	[39, 14],
	[54, 14],
	[69, 18],
	[83, 27],
	[90, 40],
	[90, 53],
	[90, 66],
	[90, 79],
	[78, 91],
	[62, 91],
	[47, 91]
], ur = {
	start: "games.parkseurope.trailStart",
	end: "games.parkseurope.fieldFinish",
	snow: "games.parkseurope.fieldSnowSpace",
	wonder: "games.parkseurope.siteShort.wonder",
	award: "games.parkseurope.fieldAward"
};
function dr({ pub: e, nameOf: t, marker: n }) {
	let r = u(), [i, a] = s(null), o = z.map((t, n) => {
		let r = e.players.filter((e) => e.chaletPos === n).sort((e, t) => e.chaletOrder - t.chaletOrder), i = [];
		return t.t === "award" && (i = e.greta?.solo ? e.players.some((e) => e.chaletPos >= n) ? [] : [t.solo] : t.stack === null ? [] : e.chaletStacks[t.stack] ?? []), {
			type: t.t,
			occupants: r,
			scores: i,
			top: i.at(-1)
		};
	}), c = i ?? o.reduce((e, t, n) => t.top === void 0 ? e : n, 0), l = o[c], d = l.top === void 0 ? l.type === "award" || l.type === "wonder" ? r("games.parkseurope.fieldDrawPassing") : "" : r("games.parkseurope.fieldAwardNext", { n: l.top }) + (l.scores.length > 1 ? " " + r("games.parkseurope.fieldAwardStack", { scores: l.scores.slice(0, -1).reverse().join(" / ") }) : "");
	return /* @__PURE__ */ x(y, { children: [
		/* @__PURE__ */ b("p", {
			className: "pke-track-note",
			children: r("games.parkseurope.fieldChaletNote")
		}),
		/* @__PURE__ */ x("div", {
			className: "pke-chalet-map",
			role: "group",
			"aria-label": r("games.parkseurope.chaletTrack"),
			children: [
				/* @__PURE__ */ b("svg", {
					viewBox: "0 0 100 100",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: /* @__PURE__ */ b("polyline", {
						points: lr.map((e) => e.join(",")).join(" "),
						fill: "none",
						vectorEffect: "non-scaling-stroke"
					})
				}),
				/* @__PURE__ */ b("div", {
					className: "pke-chalet-heart",
					"aria-hidden": !0,
					children: /* @__PURE__ */ b(K, { kind: "chalet" })
				}),
				o.map(({ type: e, occupants: i, top: o }, s) => {
					let [l, u] = lr[s], d = [
						r("games.parkseurope.fieldTrackSpace", {
							n: s,
							name: r(ur[e])
						}),
						o === void 0 ? "" : r("games.parkseurope.points", { n: o }),
						...i.map((e) => t(e.rid))
					].filter(Boolean).join(" · ");
					return /* @__PURE__ */ x("button", {
						type: "button",
						className: "pke-chalet-node",
						"data-space": s,
						"data-kind": e,
						style: {
							"--x": l + "%",
							"--y": u + "%"
						},
						"aria-label": d,
						"aria-pressed": c === s,
						onClick: () => a(s),
						children: [
							e === "start" || e === "end" ? r(e === "start" ? "games.parkseurope.fieldStartShort" : "games.parkseurope.fieldEndShort") : /* @__PURE__ */ b(K, { kind: e === "award" && o === void 0 ? "wonder" : e }),
							o !== void 0 && /* @__PURE__ */ b("b", { children: o }),
							i.length > 0 && /* @__PURE__ */ b("span", {
								className: "pke-chalet-occupants",
								children: i.map((e) => /* @__PURE__ */ b("span", { children: n(e.rid) }, e.rid))
							})
						]
					}, s);
				})
			]
		}),
		/* @__PURE__ */ x("p", {
			className: "pke-track-detail",
			"aria-live": "polite",
			children: [
				/* @__PURE__ */ b("strong", { children: r("games.parkseurope.fieldTrackSpace", {
					n: c,
					name: r(ur[l.type])
				}) }),
				d && /* @__PURE__ */ b("span", { children: d }),
				l.occupants.length > 0 && /* @__PURE__ */ b("span", { children: l.occupants.map((e) => t(e.rid)).join(" / ") })
			]
		})
	] });
}
var fr = {
	conservation: "cons",
	carabiner: "carabiner",
	mug: "mug",
	chalet: "chalet"
};
function pr({ pub: e, actionName: t, nameOf: n, marker: r, onTake: i }) {
	let a = u();
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("table", {
		className: "pke-end-board",
		"aria-label": a("games.parkseurope.fieldEndActions"),
		children: [/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.fieldAction")
			}),
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.slotTop")
			}),
			/* @__PURE__ */ b("th", {
				scope: "col",
				children: a("games.parkseurope.slotBoth")
			})
		] }) }), /* @__PURE__ */ b("tbody", { children: Be.map((o) => /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ x("th", {
			scope: "row",
			children: [
				/* @__PURE__ */ b(K, { kind: fr[o] }),
				" ",
				t(o)
			]
		}), ["top", "both"].map((s) => {
			let c = e.endSlots.find((e) => e.action === o && e.kind === s)?.rid;
			return /* @__PURE__ */ b("td", { children: c ? /* @__PURE__ */ x("span", {
				className: "pke-end-occupant",
				children: [
					r(c),
					" ",
					n(c)
				]
			}) : i ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				"aria-label": t(o) + " · " + a(s === "top" ? "games.parkseurope.slotTop" : "games.parkseurope.slotBoth"),
				onClick: () => i(s, o),
				children: a("games.parkseurope.fieldVacant")
			}) : /* @__PURE__ */ b("span", {
				className: "pke-sub",
				children: a("games.parkseurope.fieldVacant")
			}) }, s);
		})] }, o)) })]
	}), /* @__PURE__ */ x("div", {
		className: "pke-park-only",
		children: [/* @__PURE__ */ x("strong", { children: [
			/* @__PURE__ */ b(K, { kind: "parks" }),
			" ",
			a("games.parkseurope.slotParks")
		] }), i ? /* @__PURE__ */ b("button", {
			type: "button",
			className: "pke-btn pke-btn--main",
			onClick: () => i("parks"),
			children: a("games.parkseurope.fieldChoose")
		}) : /* @__PURE__ */ x("span", { children: [a("games.parkseurope.fieldSharedSlot"), e.parksEndOccupied && " · " + a("games.parkseurope.fieldSharedOccupied")] })]
	})] });
}
function mr({ pub: e, name: t }) {
	let n = u(), r = Me.find((t) => t.id === e.seasonCard);
	return r ? /* @__PURE__ */ x("article", {
		className: "pke-season-card",
		children: [
			/* @__PURE__ */ b("h3", { children: t }),
			/* @__PURE__ */ b("p", { children: n("games.parkseurope.fieldSeasonNote") }),
			/* @__PURE__ */ b("ol", { children: r.pattern.map((e, t) => /* @__PURE__ */ x("li", { children: [/* @__PURE__ */ b(q, { kind: e }), /* @__PURE__ */ b("span", { children: n("games.parkseurope.siteNo", { n: t + 2 }) })] }, t)) }),
			r.display && /* @__PURE__ */ x("p", { children: [
				n(r.display.zone === "cons" ? "games.parkseurope.consTitle" : "games.parkseurope.parksTitle"),
				" · ",
				n("games.parkseurope.displayBonus"),
				" ",
				/* @__PURE__ */ b(q, { kind: r.display.token })
			] })
		]
	}) : null;
}
//#endregion
//#region src/game/valley-world.ts
var hr = (e, t, n) => e + (t - e) * n, gr = (e, t = 0, n = 1) => Math.max(t, Math.min(n, e)), J = (e) => gr(e) * gr(e) * (3 - 2 * gr(e)), _r = (e) => e - Math.floor(e), Y = (e, t = 1) => _r(Math.sin(e * 127.1 + t * 311.7 + 38.4) * 43758.5453123);
function X(e, t) {
	let n = Math.floor(e), r = Math.floor(t), i = J(e - n), a = J(t - r);
	return hr(hr(Y(n, r), Y(n + 1, r), i), hr(Y(n, r + 1), Y(n + 1, r + 1), i), a);
}
var vr = (e, t) => 1 - Math.abs(X(e, t) * 2 - 1), yr = (e, t) => Math.exp(-((e / t) ** 2)), br = Array.from({ length: 9 }, (e, t) => 8 - t * 8.75), Z = (e) => 2.25 * Math.sin(e * .128) + .78 * Math.sin(e * .29) - .036 * e;
function xr(e) {
	let t = br[e] - .35;
	return {
		x: Z(t) + (e % 2 ? 3.85 : -3.85),
		z: t
	};
}
var Sr = br.slice(1, -1).map((e, t) => xr(t + 1)), Cr = (e, t, n) => Sr.some((r) => Math.hypot(e - r.x, t - r.z) < n), wr = (e) => -14.7 + .115 * e + 1.35 * Math.sin(e * .12), Tr = .02, Er = 13232623, Dr = .0084, Or = (e) => .35 - .036 * e + .34 * Math.sin(e * .105), kr = (e, t) => Or(t) + .79 * (X(e * .13 + 3, t * .12) - .4) + .27 * (X(e * .53, t * .53) - .4);
function Q(e, t) {
	let n = Math.abs(e - Z(t)), r = (6 + 11 * X(e * .027, t * .024)) * J((n - 6) / 29), i = 22 * yr(e + 27, 15) * yr(t + 64, 30), a = 19 * yr(e - 34, 16) * yr(t + 78, 29), o = 38 * yr(t + 113, 25) * (yr(e + 14, 33) + .5 * yr(e - 30, 23)), s = (5 * vr(e * .09, t * .08) + 2.6 * vr(e * .19, t * .14) + .9 * X(e * .42, t * .35)) * J((n - 4) / 16) * J((-t + 13) / 31), c = J((Math.abs(t - wr(e)) - 1.35) / 1.35), l = hr(kr(e, t) + r + i + a + o + s, Or(t), 1 - J((n - .74) / 1.38)), u = hr(-.54 + .18 * X(e * .46, t * .45), l, c), d = Math.abs(t + 15);
	return hr(u, 1.14, J((d - 2.18) / .34) * (1 - J((d - 2.55) / 1.04)) * (1 - J((n - 1.02) / .76)));
}
function Ar(e) {
	return Math.abs(e + 15) < 2.53 ? 1.14 : Q(Z(e), e) + .02;
}
var jr = "\nfloat valNoise(vec2 p) {\n  vec2 i=floor(p), f=fract(p);\n  f=f*f*(3.0-2.0*f);\n  vec4 a=fract(sin(vec4(dot(i,vec2(127.1,311.7)),dot(i+vec2(1,0),vec2(127.1,311.7)),dot(i+vec2(0,1),vec2(127.1,311.7)),dot(i+vec2(1,1),vec2(127.1,311.7))))*43758.5453);\n  return mix(mix(a.x,a.y,f.x),mix(a.z,a.w,f.x),f.y);\n}";
function Mr(e, t, n = {}) {
	let r = new N(e);
	return r.onBeforeCompile = (e) => {
		Object.assign(e.uniforms, n), e.vertexShader = "varying vec3 valleyPosition;\n" + e.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\nvalleyPosition=(modelMatrix*vec4(position,1.0)).xyz;"), e.fragmentShader = `varying vec3 valleyPosition;\n${Object.keys(n).map((e) => `uniform float ${e};`).join("\n")}\n${jr}\n` + e.fragmentShader.replace("#include <color_fragment>", `#include <color_fragment>\n${t}`);
	}, r.customProgramCacheKey = () => t, r;
}
function Nr() {
	let e = new he({
		side: te,
		depthWrite: !1,
		fog: !1,
		uniforms: { sun: { value: new P(.56, .68, -.46).normalize() } },
		vertexShader: "varying vec3 direction; void main(){direction=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
		fragmentShader: `varying vec3 direction; uniform vec3 sun;
${jr}
void main(){
  vec3 d=normalize(direction); float e=max(d.y,0.0); float s=max(dot(d,sun),0.0);
  vec3 sky=mix(vec3(.52,.78,.89),vec3(.06,.36,.70),smoothstep(0.0,.72,e));
  sky+=vec3(.24,.15,.045)*pow(s,12.0)*.45;
  vec2 p=d.xz/max(.15,d.y+.38)*4.2;
  float n=valNoise(p)+.38*valNoise(p*2.15)+.17*valNoise(p*4.35)+.07*valNoise(p*8.6);
  float cloud=smoothstep(.82,1.14,n)*smoothstep(.035,.19,e)*(1.0-smoothstep(.5,.9,e));
  sky=mix(sky,mix(vec3(.82,.91,.96),vec3(1.0,.96,.83),pow(s,4.0)),cloud*.86);
  sky+=vec3(1.0,.89,.60)*(pow(s,220.0)*.22+smoothstep(.9990,.9996,s)*2.0);
  gl_FragColor=vec4(sky,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`
	}), t = new M(new ge(155, 40, 24), e);
	return t.frustumCulled = !1, t.renderOrder = -20, t;
}
function Pr(e, t = !1) {
	let n = t ? new fe(350, 370, 91, 97) : new fe(124, 160, e ? 182 : 226, e ? 202 : 252);
	n.rotateX(-Math.PI / 2);
	let r = n.attributes.position, i = new Float32Array(r.count * 3), a = new O("#588758"), o = new O("#b0c175"), s = new O("#8dabbc"), c = new O("#c0cf7a"), l = new O("#958666"), u = new O("#d2ad76"), d = new O("#e6f0ef"), f = new O();
	for (let e = 0; e < r.count; e++) {
		let n = r.getX(e), p = r.getZ(e) - 52, m = Q(n, p) - (t ? .86 : 0);
		r.setXYZ(e, n, m, p);
		let h = Math.hypot(Q(n + .32, p) - Q(n - .32, p), Q(n, p + .32) - Q(n, p - .32)) / .64, g = .62 * X(n * .18, p * .2) + .38 * X(n * .64, p * .58);
		f.copy(a).lerp(o, J(g * 1.15)), f.lerp(c, .35 * J((g - .27) * 1.5)), f.lerp(s, J((h - .42) * .89) * J((m - 3) / 10)), f.lerp(d, J((m + g * 7 - 31) / 10) * (1 - J((h - 1.8) * .45)));
		let _ = Math.abs(n - Z(p));
		f.lerp(u, (1 - J((_ - .55 - X(n * 2, p * 1.7) * .24) / .56)) * .93), f.lerp(l, 1 - J((Math.abs(p - wr(n)) - 1.05) / 1.75)), f.toArray(i, e * 3);
	}
	n.setAttribute("color", new T(i, 3)), n.computeVertexNormals();
	let p = Mr({
		vertexColors: !0,
		roughness: .96
	}, "\n  vec2 v=valleyPosition.xz;\n  float fine=valNoise(v*20.0)*.45+valNoise(v*8.0)*.35+valNoise(v*3.2)*.20;\n  float grain=smoothstep(.28,.82,fine);\n  float vein=valNoise(vec2(v.x*2.8,valleyPosition.y*8.0+v.y*1.1));\n  diffuseColor.rgb*=.83+grain*.36+vein*.12;\n  "), m = new M(n, p);
	return m.receiveShadow = !0, m;
}
function Fr() {
	let e = [], t = [];
	for (let n = 0; n <= 185; n++) {
		let r = hr(-60, 60, n / 185), i = wr(r), a = 1.43 + .34 * X(r * .16, 8);
		if (e.push(r, Tr, i - a, r, Tr, i + a), n < 185) {
			let e = n * 2;
			t.push(e, e + 1, e + 2, e + 2, e + 1, e + 3);
		}
	}
	let n = new E();
	n.setAttribute("position", new T(new Float32Array(e), 3)), n.setIndex(t), n.computeVertexNormals();
	let r = { value: 0 }, i = Mr({
		color: 4103851,
		roughness: .32,
		metalness: .08,
		side: A
	}, "\n  vec2 p=valleyPosition.xz;\n  float r=valNoise(vec2(p.x*1.75-waterClock*.85,p.y*6.9));\n  float q=valNoise(vec2(p.x*4.4-waterClock*1.2,p.y*13.0));\n  float flashes=pow(max(sin(p.y*19.0+p.x*.41+r*5.0-waterClock*2.2),0.0),8.0);\n  diffuseColor.rgb*=.79+(r+q)*.23;\n  diffuseColor.rgb+=vec3(.23,.43,.47)*flashes*smoothstep(.38,.83,r);\n  ", { waterClock: r }), a = new M(n, i);
	return a.receiveShadow = !0, {
		mesh: a,
		time: r
	};
}
function Ir(e, t, n, r, { shadow: i = !1, tint: a } = {}) {
	if (!r.length) return;
	let o = new ce(t, n, r.length), s = new ue(), c = new O();
	return r.forEach((e, t) => {
		s.position.set(e.x, e.y, e.z), s.rotation.set(e.rx || 0, e.angle || 0, e.rz || 0), s.scale.set(e.w, e.h, e.d ?? e.w), s.updateMatrix(), o.setMatrixAt(t, s.matrix), a && o.setColorAt(t, a(c, t));
	}), o.castShadow = i, o.receiveShadow = i, o.computeBoundingSphere(), e.add(o), o;
}
function Lr(e) {
	let t = [], n = [], r = [], i = new O("#4c7350"), a = new O("#a4c66b"), o = new O(), s = e ? 12 : 7, c = e ? 15 : 8;
	for (let e = 0; e < s; e++) {
		let l = e / s, u = .22 + l * .68, d = .19 * (1 - l) ** .7 + .009, f = t.length / 3;
		for (let r = 0; r < 3; r++) for (let s = 0; s < c; s++) {
			let f = s / c * Math.PI * 2 + e * .49, p = (.77 + .32 * Y(s, e)) * d * (r === 0 ? 1 : r === 1 ? .67 : .14);
			t.push(Math.sin(f) * p, u + r * (.095 - l * .043) + (Y(s + 17, e) - .5) * .047, Math.cos(f) * p), o.copy(i).lerp(a, .16 + r * .17 + l * .27 + Y(s + 25, e) * .22).toArray(n, n.length);
		}
		for (let e = 0; e < 2; e++) for (let t = 0; t < c; t++) {
			let n = f + e * c + t, i = f + e * c + (t + 1) % c;
			r.push(n, i, n + c, i, i + c, n + c);
		}
	}
	let l = new E();
	return l.setAttribute("position", new T(new Float32Array(t), 3)), l.setAttribute("color", new T(new Float32Array(n), 3)), l.setIndex(r), l.computeVertexNormals(), l;
}
function Rr(e, t) {
	let n = [];
	for (let e = 0; e < (t ? 460 : 640); e++) {
		let t = hr(-102, 22, Y(e, 51)), r = 4.7 + 36 * Y(e, 49) ** 1.65, i = Z(t) + (e % 2 ? 1 : -1) * r;
		if (Math.abs(t - wr(i)) < 3.5 || Math.abs(t + 60) < 6 && r < 9 || Cr(i, t, 5.4) || r > 9 && X(i * .15, t * .15) < .33) continue;
		let a = 3.7 + 8.9 * Y(e, 57) ** 1.38, o = a * hr(.72, 1.21, Y(e, 20));
		r < 3.5 + o * .24 || n.push({
			x: i,
			z: t,
			y: Q(i, t) - .12,
			w: o,
			h: a,
			angle: Y(e, 71) * 6.28
		});
	}
	for (let [e, t, r, i] of [
		[
			-1,
			1,
			10.8,
			8
		],
		[
			1,
			-3,
			10,
			7.2
		],
		[
			-1,
			-19,
			12.5,
			8
		],
		[
			1,
			-31,
			12.2,
			9
		],
		[
			1,
			-45,
			10,
			8
		],
		[
			-1,
			-48,
			9.4,
			6
		]
	]) {
		let a = Z(t) + e * (4.2 + i * .24);
		Cr(a, t, 5.4) || n.push({
			x: a,
			z: t,
			y: Q(a, t) - .16,
			w: i,
			h: r,
			angle: Y(a, t) * 6.28
		});
	}
	let r = new k(.012, .038, .82, 8);
	r.translate(0, .41, 0);
	let i = new N({
		vertexColors: !0,
		roughness: .96,
		side: A
	}), a = new N({
		color: 7166017,
		roughness: 1
	}), o = n.filter((e) => Math.abs(e.x - Z(e.z)) < 15 && e.z > -83), s = n.filter((e) => !o.includes(e)), c = (e, t) => e.setRGB(.84 + Y(t, 3) * .15, .88 + Y(t, 4) * .12, .78 + Y(t, 5) * .18);
	Ir(e, Lr(!0), i, o, {
		shadow: !0,
		tint: c
	}), Ir(e, Lr(!1), i, s, { tint: c }), Ir(e, r, a, o, { shadow: !0 }), Ir(e, r, a, s);
}
function zr(e) {
	let t = new se(1, e), n = t.attributes.position;
	for (let e = 0; e < n.count; e++) {
		let t = n.getX(e), r = n.getY(e), i = n.getZ(e), a = .83 + .22 * X(t * 2.7 + i * 1.6, r * 2.2 + i * 3.1) + .13 * X(t * 6.6 + r * 2.7, i * 6.7);
		n.setXYZ(e, t * a, r * a * .72 + .065 * Math.sin(i * 8), i * a);
	}
	let r = new Float32Array(n.count * 3), i = new P();
	for (let e = 0; e < n.count; e++) i.set(n.getX(e), n.getY(e) * 1.65, n.getZ(e)).normalize(), i.toArray(r, e * 3);
	return t.setAttribute("normal", new T(r, 3)), t;
}
function Br() {
	let e = [], t = [], n = [], r = new O("#65944c"), i = new O("#c8ce76"), a = new O();
	for (let o = 0; o < 8; o++) {
		let s = (Y(o, 243) - .5) * .58, c = (Y(o, 47) - .5) * .58, l = .23 + Y(o, 83) * .43, u = (Y(o, 97) - .5) * .55, d = e.length / 3;
		e.push(s - .032, 0, c, s + .032, 0, c, s + u * .4 + .018, l * .58, c - .035, s + u * .4 - .018, l * .58, c - .035, s + u, l, c - .1), t.push(d, d + 1, d + 3, d + 1, d + 2, d + 3, d + 3, d + 2, d + 4);
		for (let e = 0; e < 5; e++) a.copy(r).lerp(i, e * .15 + Y(o, 21) * .2).toArray(n, n.length);
	}
	let o = new E();
	return o.setAttribute("position", new T(new Float32Array(e), 3)), o.setAttribute("color", new T(new Float32Array(n), 3)), o.setIndex(t), o.computeVertexNormals(), o;
}
function Vr(e, t) {
	let n = [], r = [], i = [];
	for (let e = 0; e < (t ? 3500 : 6800); e++) {
		let t = hr(-78, 16, Y(e, 31)), r = 1.18 + 17 * Y(e, 15) ** 2.1, a = Z(t) + (e % 2 ? 1 : -1) * r;
		if (Math.abs(t - wr(a)) < 1.83 || X(a * .26, t * .29) < .25 || Cr(a, t, 2.45)) continue;
		let o = Q(a, t), s = .42 + .79 * Y(e, 91) * (.8 + X(a * .4, t * .4));
		n.push({
			x: a,
			z: t,
			y: o,
			w: s,
			h: s,
			angle: Y(e, 78) * 6.28
		}), e % 19 == 0 && r < 6 && i.push({
			x: a,
			z: t,
			y: o + .22 * s,
			w: s * .094,
			h: s * .13,
			angle: 0,
			d: s * .094
		});
	}
	for (let e = 0; e < 320; e++) {
		let t = hr(-95, 14, Y(e, 178)), n = 1.24 + 22 * Y(e, 175) ** 1.7, i = Z(t) + (e % 2 ? 1 : -1) * n, a = .09 + 1.18 * Y(e, 172) ** 2.5, o = Q(i, t);
		Math.abs(t - wr(i)) < .84 || Cr(i, t, 2.45) || r.push({
			x: i,
			z: t,
			y: o - .12 * a,
			w: a * .89,
			h: a,
			d: a * .62,
			angle: Y(e, 8) * 6.28,
			rx: Y(e, 186) * .23,
			rz: Y(e, 153) * .36
		});
	}
	let a = new N({
		color: 11715783,
		roughness: .91
	}), o = (e, t) => t % 4 == 0 ? e.set("#b3c197") : e.set(t % 2 ? "#c6d4ce" : "#dce1d4"), s = r.filter((e) => Math.abs(e.x - Z(e.z)) < 6);
	Ir(e, zr(3), a, s, {
		shadow: !0,
		tint: o
	}), Ir(e, zr(1), a, r.filter((e) => !s.includes(e)), { tint: o }), Ir(e, Br(), new N({
		vertexColors: !0,
		side: A,
		roughness: .88
	}), n), Ir(e, new se(1, 0), new N({ roughness: .87 }), i, { tint: (e, t) => e.set(t % 3 == 0 ? "#ffc754" : t % 3 == 1 ? "#fff3c1" : "#ef9779") });
}
function Hr(e) {
	let t = new N({
		color: 8939595,
		roughness: .93
	}), n = new N({
		color: 12160347,
		roughness: .83
	}), r = new N({
		color: 4540476,
		roughness: .62,
		metalness: .29
	});
	function i(e, t, n, r, i, a, o, s) {
		let c = new M(new re(n, r, i), t);
		return c.position.set(a, o, s), c.castShadow = !0, c.receiveShadow = !0, e.add(c), c;
	}
	let a = new j();
	a.position.set(Z(-15), 0, -15), e.add(a);
	for (let e = 0; e < 19; e++) i(a, e % 4 == 0 ? t : n, 2.38, .12, .25, 0, 1.075, (e - 9) * .268);
	for (let e of [-1.12, 1.12]) {
		i(a, t, .15, .13, 5.14, e, 1.96, 0), i(a, t, .1, .1, 5.14, e, 1.61, 0);
		for (let n of [
			-2.46,
			-1.22,
			0,
			1.22,
			2.46
		]) i(a, t, .12, 1.01, .12, e, 1.51, n), i(a, r, .15, .08, .15, e, 1.99, n);
	}
	for (let a of br) {
		let o = Z(a) + 1.85, s = Q(o, a), c = new j();
		c.position.set(o, s, a), c.rotation.y = -.23, e.add(c), i(c, t, .16, 1.87, .18, 0, .85, 0), i(c, n, 1.12, .33, .13, -.28, 1.36, .05), i(c, t, .74, .24, .12, -.1, 1.72, .055);
		for (let e of [-.67, .11]) i(c, r, .049, .048, .035, e, 1.36, .132);
	}
	let o = new M(new k(.18, .23, 2.6, 11), t);
	o.position.set(Z(-41) - 2.03, Q(Z(-41) - 2.03, -41) + .31, -41), o.rotation.z = 1.31, o.rotation.y = .57, o.castShadow = !0, e.add(o);
}
function Ur(e, t = e) {
	let n = new j(), r = new N({
		color: e,
		roughness: .91
	}), i = new N({
		color: 2968398,
		roughness: .94
	}), a = new N({
		color: 4278071,
		roughness: .95
	}), o = new N({
		color: 13144418,
		roughness: .86
	}), s = new N({
		color: t,
		roughness: .79
	}), c = new N({
		color: 7554609,
		roughness: .92
	}), l = new N({
		color: 15253369,
		roughness: .92
	}), u = new N({
		color: 4010795,
		roughness: .97
	});
	function d(e, t, n, r, i, a, o = 1, s = 1, c = 1) {
		let l = new M(t, n);
		return l.position.set(r, i, a), l.scale.set(o, s, c), l.castShadow = !0, l.receiveShadow = !0, e.add(l), l;
	}
	let f = new ge(1, 19, 13), p = new j();
	n.add(p), d(p, new D(.25, .44, 8, 14), r, 0, 1.12, 0, 1.08, 1, .75), d(p, f, a, 0, .8, 0, .24, .2, .17), d(p, f, o, 0, 1.67, -.024, .19, .23, .175), d(p, new k(.15, .213, .117, 22), l, 0, 1.86, -.015), d(p, new k(.284, .292, .034, 24), c, 0, 1.813, -.015), d(p, new D(.21, .31, 8, 16), s, 0, 1.23, .235, 1.05, 1, .57), d(p, f, c, 0, 1.18, .36, .216, .162, .054), d(p, f, s, 0, 1.214, .392, .182, .116, .041), d(p, new re(.051, .056, .025), l, 0, 1.242, .432);
	let m = d(p, new k(.074, .074, .39, 16), l, 0, 1.52, .243);
	m.rotation.z = Math.PI / 2;
	for (let e of [-1, 1]) d(p, new re(.047, .37, .031), i, e * .184, 1.24, -.158).rotation.z = e * .14, d(p, f, c, e * .21, 1.07, .233, .049, .118, .072);
	let h = [], g = [];
	for (let e of [-1, 1]) {
		let t = new j();
		t.position.set(e * .282, 1.37, .005), p.add(t), t.rotation.z = e * .1, d(t, new D(.079, .31, 6, 12), r, 0, -.187, 0), d(t, f, o, 0, -.4, -.004, .061, .096, .064), h.push(t);
		let i = new j();
		i.position.set(e * .124, .82, .008), n.add(i), d(i, new D(.093, .25, 6, 12), a, 0, -.177, 0);
		let s = new j();
		s.position.y = -.34, i.add(s), d(s, new D(.075, .233, 6, 12), a, 0, -.17, .006), d(s, f, u, 0, -.38, -.047, .095, .086, .155), g.push({
			hip: i,
			knee: s
		});
	}
	return {
		root: n,
		pose(e, t) {
			let n = t ? Math.sin(e * 10.7) : 0;
			p.position.y = t ? Math.abs(n) * .042 : 0, p.rotation.z = n * .053, p.rotation.x = t ? -.08 : 0, g.forEach(({ hip: e, knee: t }, r) => {
				let i = n * (r === 0 ? 1 : -1);
				e.rotation.x = i * .48, t.rotation.x = Math.max(0, -i) * .67, h[r].rotation.x = -i * .42;
			});
		}
	};
}
function Wr() {
	let e = [], t = [];
	for (let n = 0; n <= 210; n++) {
		let r = hr(br[0], br[br.length - 1], n / 210), i = Z(r), a = Ar(r) + .055;
		if (e.push(i - .47, a, r, i + .47, a, r), n < 210) {
			let e = n * 2;
			t.push(e, e + 1, e + 2, e + 1, e + 3, e + 2);
		}
	}
	let n = new E();
	n.setAttribute("position", new T(new Float32Array(e), 3)), n.setIndex(t), n.computeVertexNormals();
	let r = new le({
		color: 15120237,
		side: A,
		transparent: !0,
		opacity: .86,
		depthWrite: !1
	}), i = new j();
	i.add(new M(n, r));
	let a = new k(.75, .89, .12, 24), o = [
		15909745,
		7130314,
		11982181,
		15966846
	];
	return br.forEach((e, t) => {
		let n = new M(a, new N({
			color: o[t % o.length],
			roughness: .58,
			metalness: .12
		}));
		n.position.set(Z(e), Ar(e) + .06, e), i.add(n);
	}), i.visible = !1, i;
}
function Gr(e = !1) {
	let t = new me(), n = new ae(Er, Dr);
	t.fog = n, t.add(new oe(15793151, 11709831, 1.76));
	let r = new ie(16772558, 2.6);
	r.castShadow = !0, r.shadow.mapSize.set(e ? 1024 : 2048, e ? 1024 : 2048), Object.assign(r.shadow.camera, {
		left: -18,
		right: 18,
		top: 21,
		bottom: -21,
		near: 1,
		far: 83
	}), r.shadow.normalBias = .048, r.shadow.bias = -36e-5, r.shadow.radius = 2.7, r.shadow.intensity = .58, t.add(r, r.target);
	let i = new ie(13955327, .7);
	i.position.set(-12, 13, 9), t.add(i);
	let a = Nr();
	t.add(a), t.add(Pr(e, !0), Pr(e));
	let o = Fr();
	t.add(o.mesh), Rr(t, e), Vr(t, e), Hr(t);
	let s = Wr();
	return t.add(s), {
		scene: t,
		sun: r,
		sky: a,
		stream: o,
		route: s,
		fog: n
	};
}
function Kr(e, t, n = 0) {
	let r = Z(e), i = e - 7.2, a = t ? .8 : 1.18, o = e + (t ? 5.34 : 5.25) * Math.cos(n) - a * Math.sin(n) * .33, s = Z(o) + a * Math.cos(n) + 1.55 * Math.sin(n), c = Math.max(Ar(e) + 2.31, Q(s, o) + 1.47);
	return {
		position: new P(s, c, o),
		look: new P(hr(Z(i), r, t ? .61 : .38), Ar(e) + (t ? .06 : .3), i),
		fov: t ? 60 : 49
	};
}
function qr(e) {
	return e < 1.04 ? {
		position: new P(39, 113, 67),
		look: new P(0, -1, -14),
		fov: 55
	} : {
		position: new P(86, 75, 6),
		look: new P(0, 0, -24),
		fov: 46
	};
}
function Jr(e, t, n, r) {
	let { sun: i, stream: a } = e, o = r ? -24 : t;
	i.position.set(Z(o) + 29, 35 + Ar(o), o - 16), i.target.position.set(Z(o), Ar(o), o - 4);
	let s = e.sun.shadow.camera, c = r ? 39 : 21;
	s.top !== c && (Object.assign(s, {
		top: c,
		bottom: -c,
		left: -c,
		right: c
	}), s.updateProjectionMatrix()), e.route.visible = r, e.fog.density = r ? .0027 : Dr, a.time.value = n;
}
//#endregion
//#region src/game/valley-landmarks.ts
function Yr() {
	let e = (e) => new N({
		color: e,
		roughness: .86
	}), t = zr(2), n = t.attributes.position, r = new Float32Array(n.count * 3), i = new O("#6b899d"), a = new O("#f6fcfa");
	for (let e = 0; e < n.count; e++) {
		let t = .29 + Math.sin(n.getX(e) * 11 + n.getZ(e) * 8) * .07;
		i.clone().lerp(a, Math.max(0, Math.min(1, (n.getY(e) - t) * 10))).toArray(r, e * 3);
	}
	return t.setAttribute("color", new T(r, 3)), {
		box: new re(1, 1, 1),
		cylinder: new k(1, 1, 1, 16),
		tapered: new k(.34, .51, 1, 13),
		sphere: new ge(1, 14, 9),
		wreath: new _e(1, .12, 10, 26),
		flower: new se(1, 0),
		rock: zr(2),
		snowRock: t,
		foliage: Lr(!0),
		snowy: new N({
			vertexColors: !0,
			roughness: .89
		}),
		pine: new N({
			vertexColors: !0,
			side: A,
			roughness: .94
		}),
		bark: e(6902587),
		timber: e(10907202),
		cut: e(14461291),
		roof: e(11161916),
		shade: e(3554875),
		limestone: e(10923682),
		blue: e(3051429),
		cream: e(16773050),
		brass: e(14001742),
		ibex: e(10778964),
		prism: e(7957165)
	};
}
function $(e, t, n, r, i, a, o, s, c) {
	let l = new M(t, n);
	return l.position.set(r, i, a), l.scale.set(o, s, c), l.castShadow = !0, l.receiveShadow = !0, e.add(l), l;
}
function Xr(e, t, n) {
	return Q(e.position.x + t, e.position.z + n) - e.position.y;
}
function Zr(e, t) {
	let n = [
		0,
		.39,
		.82,
		1
	], r = t ? 2.35 : 2.55, i = t ? 2.45 : 3.08, a = [], o = [], s = [], c = new O(t ? "#208f9d" : "#d8bf65"), l = new O(t ? "#88d0b7" : "#9ba653"), u = new O("#a9ac83"), d = Math.max(0, ...Array.from({ length: 40 }, (t, n) => {
		let a = n * Math.PI * 2 / 40;
		return Xr(e, Math.cos(a) * r * .88, Math.sin(a) * i * .88);
	})) + .13;
	n.forEach((n, f) => {
		for (let p = 0; p < 40; p++) {
			let m = p * Math.PI * 2 / 40, h = n * (1 + .08 * Math.sin(m * 3) + .047 * Math.cos(m * 7)), g = Math.cos(m) * r * h, _ = Math.sin(m) * i * h, v = Xr(e, g, _);
			if (a.push(g, t && f < 3 ? d : v + .055, _), (t && f === 3 ? u.clone() : c.clone().lerp(l, n ** 2)).multiplyScalar(1 + Math.sin(p * 12 + f * 4) * .09).toArray(o, o.length), !f) continue;
			let y = (f - 1) * 40 + p, b = (f - 1) * 40 + (p + 1) % 40;
			s.push(y, y + 40, b, b, y + 40, b + 40);
		}
	});
	let f = new E();
	f.setAttribute("position", new T(new Float32Array(a), 3)), f.setAttribute("color", new T(new Float32Array(o), 3)), f.setIndex(s), f.computeVertexNormals();
	let p = new N({
		vertexColors: !0,
		roughness: t ? .29 : 1,
		side: A
	}), m = new M(f, p);
	return m.receiveShadow = !0, e.add(m), d;
}
function Qr(e, t) {
	let n = Zr(e, !0);
	for (let r = 0; r < 21; r++) {
		let i = r * Math.PI * 2 / 21, a = Math.cos(i) * 2.15, o = Math.sin(i) * 2.24, s = .27 + r * 7 % 11 * .031;
		$(e, t.rock, t.limestone, a, Math.max(Xr(e, a, o), n - .13), o, s * 1.42, s, s);
	}
	for (let [r, i, a] of [
		[
			-.75,
			-.43,
			.71
		],
		[
			.25,
			.62,
			.94
		],
		[
			.54,
			-.94,
			.45
		]
	]) $(e, t.sphere, t.cream, r, n + .012, i, a, .011, .024);
}
function $r(e, t) {
	[
		[
			-1.22,
			-.07,
			4
		],
		[
			-1.67,
			1.15,
			3.05
		],
		[
			.38,
			1.34,
			4.75
		],
		[
			.14,
			-1.14,
			5.5
		],
		[
			1.29,
			-.26,
			4.4
		],
		[
			1.13,
			-2,
			3.58
		],
		[
			-.74,
			-2.31,
			4.3
		]
	].forEach(([n, r, i], a) => {
		let o = Xr(e, n, r);
		$(e, t.cylinder, t.bark, n, o + i * .28, r, .09, i * .56, .09);
		let s = $(e, t.foliage, t.pine, n, o - .14, r, i * 1.3, i, i * 1.22);
		s.rotation.y = a * 2.1;
	});
}
function ei(e, t) {
	for (let [n, r, i, a, o, s] of [
		[
			.25,
			-.37,
			1.57,
			5.7,
			1.46,
			-.17
		],
		[
			-1.15,
			.48,
			.92,
			3.45,
			1.19,
			.22
		],
		[
			1.28,
			.45,
			.97,
			3.04,
			.98,
			-.29
		],
		[
			.7,
			-1.52,
			1.02,
			3.66,
			1.08,
			.18
		]
	]) $(e, t.snowRock, t.snowy, n, Xr(e, n, r) + a * .45, r, i, a, o).rotation.set(.14, r, s);
}
function ti(e, t) {
	Zr(e, !1);
	let n = new ce(t.flower, t.cream, 72), r = new ue(), i = [
		new O("#ffc857"),
		new O("#ffdb78"),
		new O("#f9e9ac")
	];
	for (let t = 0; t < n.count; t++) {
		let a = t * 2.39996, o = Math.sqrt((t + .5) / n.count), s = Math.cos(a) * o * 2.34, c = Math.sin(a) * o * 2.72;
		r.position.set(s, Xr(e, s, c) + .16 + t % 4 * .04, c), r.scale.set(.09, .059, .089), r.updateMatrix(), n.setMatrixAt(t, r.matrix), n.setColorAt(t, i[t % i.length]);
	}
	n.instanceMatrix.needsUpdate = !0, n.instanceColor && (n.instanceColor.needsUpdate = !0), n.computeBoundingSphere(), e.add(n);
}
function ni(e, t) {
	let n = new j();
	n.rotation.y = e.position.x < 0 ? -.32 : .38, e.add(n), $(n, t.box, t.limestone, 0, .03, 0, 3.28, .55, 2.7), $(n, t.box, t.bark, 0, 1.19, 0, 3.03, 2.12, 2.43);
	for (let e = 0; e < 7; e++) {
		let r = .3 + e * .277;
		for (let i of [-1, 1]) $(n, t.box, e % 3 ? t.timber : t.cut, 0, r, i * 1.24, 3.18, .25, .1), $(n, t.box, t.timber, i * 1.54, r, 0, .09, .25, 2.5);
	}
	for (let e of [-1, 1]) {
		let r = $(n, t.box, t.roof, e * .91, 2.68, 0, 2.16, .18, 3.14);
		r.rotation.z = -e * .57;
		let i = $(n, t.box, t.cut, e * .91, 2.63, 1.57, 2.15, .11, .13);
		i.rotation.z = -e * .57;
	}
	$(n, t.box, t.bark, 0, 2.49, 0, 1.25, 1.01, 2.41), $(n, t.box, t.limestone, .79, 3.12, -.61, .39, 1.26, .42), $(n, t.box, t.shade, -.66, 1.05, 1.31, .79, 1.52, .09), $(n, t.box, t.cream, .65, 1.49, 1.32, .68, .59, .1), $(n, t.box, t.bark, .65, 1.49, 1.39, .08, .6, .08), $(n, t.box, t.bark, .65, 1.49, 1.39, .68, .07, .08), $(n, t.box, t.cut, -.66, .18, 1.58, 1.03, .23, .52);
}
function ri(e, t) {
	$(e, t.sphere, t.ibex, 0, 1.28, 0, .42, .46, .96), $(e, t.sphere, t.ibex, 0, 1.62, .66, .31, .52, .36).rotation.x = -.46, $(e, t.sphere, t.ibex, 0, 1.99, .96, .29, .28, .41);
	for (let n of [-1, 1]) {
		for (let r of [-.51, .55]) $(e, t.cylinder, t.ibex, n * .24, .58, r, .09, 1.14, .09);
		let r = $(e, t.wreath, t.bark, n * .19, 2.3, .75, .14, .39, .29);
		r.rotation.y = Math.PI / 2;
	}
	e.rotation.y = .75;
}
function ii(e, t, n) {
	switch (n) {
		case "carabiner":
			$(e, t.rock, t.limestone, 0, .72, -.35, 1.02, 1.6, .69), $(e, t.wreath, t.brass, .05, 1.57, .28, .36, .64, .45).rotation.z = -.48;
			break;
		case "parks":
			for (let n of [-1.14, 1.14]) $(e, t.cylinder, t.bark, n, 1.22, 0, .14, 2.44, .14), $(e, t.rock, t.limestone, n, .12, 0, .44, .41, .58);
			$(e, t.box, t.timber, 0, 2.17, 0, 2.78, .54, .25), $(e, t.box, t.cut, 0, 1.91, .17, 1.8, .08, .07);
			break;
		case "die": {
			$(e, t.rock, t.limestone, 0, .28, 0, 1.57, .63, 1.48);
			let n = new j();
			n.position.y = 1.15, n.rotation.y = -.39, e.add(n), $(n, t.box, t.blue, 0, 0, 0, 1.22, 1.22, 1.22);
			for (let [e, r] of [
				[-.31, .31],
				[0, 0],
				[.31, -.31]
			]) $(n, t.sphere, t.cream, e, r, .613, .085, .085, .023), $(n, t.sphere, t.cream, e, .613, r, .085, .023, .085);
			break;
		}
		case "photo":
			for (let n = 0; n < 3; n++) {
				let r = n * Math.PI * 2 / 3;
				$(e, t.cylinder, t.bark, Math.sin(r) * .34, .74, Math.cos(r) * .34, .07, 1.65, .07).rotation.set(-Math.cos(r) * .4, 0, Math.sin(r) * .4);
			}
			$(e, t.box, t.shade, 0, 1.63, 0, .92, .57, .51), $(e, t.cylinder, t.limestone, 0, 1.65, .31, .22, .28, .22).rotation.x = Math.PI / 2, $(e, t.sphere, t.blue, 0, 1.65, .46, .15, .15, .055);
			break;
		case "mug":
			for (let n of [-.85, .85]) $(e, t.box, t.bark, n, .42, 0, .21, .84, .66);
			$(e, t.box, t.cut, 0, .86, 0, 2.23, .13, .83), $(e, t.cylinder, t.blue, 0, 1.18, 0, .29, .53, .29), $(e, t.cylinder, t.shade, 0, 1.45, 0, .22, .03, .22), $(e, t.wreath, t.blue, .33, 1.19, 0, .14, .17, .2);
			break;
		case "wonder":
			$(e, t.rock, t.limestone, 0, .4, 0, 1.27, .75, 1.07);
			for (let [n, r, i, a] of [
				[
					0,
					.02,
					1.24,
					-.12
				],
				[
					-.44,
					.17,
					.75,
					.42
				],
				[
					.54,
					-.34,
					.85,
					-.45
				]
			]) $(e, t.flower, t.prism, n, .56 + i * .61, r, .32, i, .27).rotation.z = a;
			break;
		case "conservation":
			for (let n of [-.95, .95]) $(e, t.box, t.bark, n, .61, .69, .16, 1.2, .16);
			for (let n of [.46, .91]) $(e, t.box, t.cut, 0, n, .69, 2.19, .15, .13);
			for (let [n, r, i] of [
				[
					-.9,
					-.19,
					1.84
				],
				[
					.12,
					-.69,
					2.28
				],
				[
					.91,
					-.11,
					1.57
				]
			]) $(e, t.cylinder, t.bark, n, .46, r, .06, .99, .06), $(e, t.foliage, t.pine, n, -.01, r, i, i, i);
	}
}
function ai(e) {
	let t = new j(), n = Yr();
	return e.forEach((e, r) => {
		let { x: i, z: a } = xr(r + 1), o = new j();
		switch (o.name = e, o.position.set(i, Q(i, a), a), e) {
			case "core-water":
				Qr(o, n);
				break;
			case "core-forest":
				$r(o, n);
				break;
			case "core-mountain":
				ei(o, n);
				break;
			case "core-sun":
				ti(o, n);
				break;
			case "chalet":
				ni(o, n);
				break;
			case "wildlife":
				ri(o, n);
				break;
			default: ii(o, n, e);
		}
		t.add(o);
	}), t;
}
//#endregion
//#region src/game/valley-pins.ts
var oi = {
	width: 44,
	height: 36
}, si = 8, ci = 6;
function li(e, t, n, r, i, a) {
	let o = t.height - e.height - si;
	if (r > i || o < si) return;
	let s = a ? i : Math.max(r, Math.min(i, e.x)), c = Math.max(si, Math.min(o, e.y)), l = (t, r) => n.every((n) => t >= n.x + n.width + ci || t + e.width + ci <= n.x || r >= n.y + n.height + ci || r + e.height + ci <= n.y);
	if (l(s, c)) return {
		...e,
		x: s,
		y: c
	};
	let u = [
		s,
		r,
		i
	], d = [
		c,
		si,
		o
	];
	for (let t of n) u.push(t.x - e.width - ci, t.x + t.width + ci), d.push(t.y - e.height - ci, t.y + t.height + ci);
	let f, p = Infinity;
	for (let t of u) if (!(t < r || t > i || a && f && t < f.x)) for (let n of d) {
		if (n < si || n > o || !l(t, n)) continue;
		let r = (t - s) ** 2 + (n - c) ** 2;
		(a && f && t > f.x || r < p) && (f = {
			...e,
			x: t,
			y: n
		}, p = r);
	}
	return f;
}
function ui(e, t, n, r, i, a = !1) {
	let o = r === "up", s = o ? {
		width: t.height,
		height: t.width
	} : t, c = (e) => o ? {
		x: t.height - e.y - e.height,
		y: e.x,
		width: e.height,
		height: e.width
	} : e, l = (e) => o ? {
		x: e.y,
		y: t.height - e.x - e.width,
		width: e.height,
		height: e.width
	} : e, u = n.map(c), d = e.map((e) => {
		let t = i || e.outside || e.compact, { width: n, height: r } = t ? oi : e;
		return {
			index: e.index,
			compact: t,
			rect: c({
				x: e.x - n / 2,
				y: e.y - r,
				width: n,
				height: r
			})
		};
	}), f = [];
	if (a) {
		let e = si;
		for (let [t, n] of d.entries()) {
			let { width: r } = n.rect, i = Math.max(si, e - r / 2), a = s.width - si - r - (d.length - t - 1) * 13, o = li(n.rect, s, u, i, a, !1);
			if (!o) return;
			f.push({
				...l(o),
				index: n.index,
				compact: n.compact
			}), u.push(o), e = o.x + r / 2 + 13;
		}
		return f;
	}
	let p = Array(d.length), m = s.width - si;
	for (let e = d.length - 1; e >= 0; e--) {
		let t = d[e].rect, n = li(t, s, u, si, m - t.width, !0);
		if (!n) return;
		p[e] = n.x, m = n.x - ci;
	}
	let h = si;
	for (let [e, t] of d.entries()) {
		let n = li(t.rect, s, u, h, p[e], !1);
		if (!n) return;
		f.push({
			...l(n),
			index: t.index,
			compact: t.compact
		}), h = n.x + n.width + ci;
	}
	return f;
}
function di(e, t, n, r, i) {
	let a = [...n, ...r], o = i === "up" ? "across" : "up";
	return ui(e, t, a, i, !1) ?? ui(e, t, a, i, !0) ?? ui(e, t, n, i, !0) ?? ui(e, t, n, i, !0, !0) ?? ui(e, t, n, o, !0) ?? ui(e, t, n, o, !0, !0) ?? [];
}
//#endregion
//#region src/game/valley-stage.tsx
function fi(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
	e.traverse((e) => {
		let r = e;
		if (r.isMesh) {
			t.add(r.geometry);
			for (let e of Array.isArray(r.material) ? r.material : [r.material]) n.add(e);
		}
	}), t.forEach((e) => e.dispose()), n.forEach((e) => e.dispose());
}
function pi() {
	try {
		return typeof WebGL2RenderingContext < "u";
	} catch {
		return !1;
	}
}
function mi(e, t) {
	let n = e.clone();
	n.updateMatrixWorld();
	let r = new pe(), i = new de(new P(0, 1, 0)), a = new ve();
	return (e, o) => (a.set((e - t.left) / t.width * 2 - 1, 1 - (o - t.top) / t.height * 2), r.setFromCamera(a, n), r.ray.intersectPlane(i, new P()));
}
function hi(e, t, n, r) {
	let i = Infinity, a = -Infinity, o = Infinity, s = -Infinity;
	for (let c of [e.min.x, e.max.x]) for (let l of [e.min.y, e.max.y]) for (let u of [e.min.z, e.max.z]) {
		if (r.set(c, l, u).project(t), r.z < -1 || r.z > 1) return null;
		let e = (r.x + 1) * n.width / 2, d = (1 - r.y) * n.height / 2;
		i = Math.min(e, i), a = Math.max(e, a), o = Math.min(d, o), s = Math.max(d, s);
	}
	let c = a - i, l = s - o;
	return {
		x: i + c * .16,
		y: o + l * .18,
		width: c * .68,
		height: l * .64
	};
}
function gi({ mode: e, season: t, trailSites: r, hikers: i, focused: a, sites: c, inspectedSite: l, onSite: u, fallback: d, resetKey: f = 0 }) {
	let [p] = s(pi), [m, h] = s(!1), g = o([]), _ = o([]), v = o(null), y = o(0), S = o({
		x: 0,
		z: 0
	}), C = o(null), ee = o(null), w = o(null), [te] = s(() => typeof matchMedia < "u" && matchMedia("(max-width: 760px)").matches);
	n(() => {
		S.current = {
			x: 0,
			z: 0
		}, y.current = 0, ee.current?.();
	}, [f]);
	function ne(t) {
		if (w.current || t.button !== 0 || t.target.closest("button")) return;
		let n = e === "overview" && C.current ? mi(C.current, t.currentTarget.getBoundingClientRect()) : void 0;
		w.current = {
			id: t.pointerId,
			x: t.clientX,
			angle: y.current,
			panX: S.current.x,
			panZ: S.current.z,
			unproject: n,
			origin: n?.(t.clientX, t.clientY)
		}, t.currentTarget.setPointerCapture(t.pointerId);
	}
	function re(t) {
		let n = w.current;
		if (n?.id === t.pointerId) {
			if (e === "follow") y.current = Math.max(-.9, Math.min(.9, n.angle - (t.clientX - n.x) * .009));
			else {
				let e = n.unproject?.(t.clientX, t.clientY);
				if (!e || !n.origin) return;
				S.current.x = Math.max(-35, Math.min(35, n.panX + n.origin.x - e.x)), S.current.z = Math.max(-42, Math.min(42, n.panZ + n.origin.z - e.z));
			}
			ee.current?.();
		}
	}
	function T(e) {
		w.current?.id === e.pointerId && (w.current = null);
	}
	return /* @__PURE__ */ x("div", {
		className: "pke-valley",
		"data-mode": e,
		onPointerDownCapture: ne,
		onPointerMoveCapture: re,
		onPointerUp: T,
		onPointerCancel: T,
		onLostPointerCapture: T,
		children: [
			p && /* @__PURE__ */ b(_i, {
				low: te,
				mode: e,
				season: t,
				trailSites: r,
				hikers: i,
				focused: a,
				sites: c,
				pins: g,
				leaders: _,
				pinLayer: v,
				angle: y,
				pan: S,
				cameraRef: C,
				wakeRef: ee,
				onRecoveryChange: h
			}),
			(!p || m) && /* @__PURE__ */ b("p", {
				className: "pke-valley-fallback",
				children: d
			}),
			/* @__PURE__ */ x("div", {
				className: "pke-valley-pins",
				ref: v,
				hidden: !p || m,
				children: [/* @__PURE__ */ b("svg", {
					className: "pke-valley-leaders",
					"aria-hidden": "true",
					children: c.map((e, t) => /* @__PURE__ */ b("line", { ref: (e) => {
						_.current[t] = e;
					} }, t))
				}), c.map((e, t) => /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-valley-pin",
					"data-stop": t,
					"data-current": e.current,
					"data-selected": !!e.selected,
					"data-legal": e.legal,
					ref: (e) => {
						g.current[t] = e;
					},
					style: { "--pke-pin-color": e.color },
					"aria-expanded": l === t,
					"aria-controls": l === t ? "pke-panel-site" : void 0,
					"aria-label": e.selected ? e.label + " · " + e.selected : e.label,
					onClick: () => u(t),
					children: [/* @__PURE__ */ x("span", {
						className: "pke-valley-pin-detail",
						children: [/* @__PURE__ */ x("b", { children: [e.icon, e.label] }), e.occupants.length > 0 && /* @__PURE__ */ b("span", {
							className: "pke-valley-occupants",
							children: e.occupants
						})]
					}), /* @__PURE__ */ x("b", {
						className: "pke-valley-pin-compact",
						"aria-hidden": "true",
						children: [e.icon, e.shortLabel ?? t]
					})]
				}, t))]
			})
		]
	});
}
function _i({ low: e, onRecoveryChange: t, ...r }) {
	let i = a(() => Gr(e), [e]);
	return n(() => () => fi(i.scene), [i]), /* @__PURE__ */ b(ye, {
		scene: i.scene,
		camera: {
			fov: 46,
			near: .11,
			far: 264
		},
		frameloop: "demand",
		dpr: [1, e ? 1.2 : 1.45],
		shadows: "soft",
		gl: {
			antialias: !0,
			powerPreference: "high-performance"
		},
		onCreated: ({ gl: e }) => {
			e.toneMapping = w, e.toneMappingExposure = 1.11, e.shadowMap.autoUpdate = !1;
		},
		onRecoveryChange: t,
		children: /* @__PURE__ */ b(vi, {
			...r,
			low: e,
			world: i
		})
	});
}
function vi({ world: e, mode: t, season: r, trailSites: i, hikers: a, focused: s, sites: c, pins: l, leaders: u, pinLayer: d, angle: f, pan: p, cameraRef: m, wakeRef: h }) {
	let g = S(), _ = ee((e) => e.invalidate), v = ee((e) => e.camera), y = o({
		models: /* @__PURE__ */ new Map(),
		season: r,
		first: !0,
		mode: t,
		aim: new P(),
		projected: new P(),
		elapsed: 0,
		landmarks: null,
		landmarkOrder: "",
		landmarkPositions: []
	});
	return n(() => (m.current = v, () => {
		m.current = null;
	}), [v, m]), n(() => {
		h.current = _;
		let t = y.current;
		return () => {
			h.current = null;
			for (let n of t.models.values()) e.scene.remove(n.body.root), fi(n.body.root);
			t.models.clear();
			let { landmarks: n } = t;
			n && (e.scene.remove(n), fi(n), t.landmarks = null, t.landmarkOrder = "");
		};
	}, [
		_,
		h,
		e
	]), n(() => {
		_();
	}, [
		_,
		t,
		r,
		i,
		a,
		s,
		c
	]), C(({ camera: n, size: o, gl: m }, h) => {
		let v = y.current, b = Math.min(h, .05), x = v.season !== r, S = v.mode !== t, C = i.join(","), ee = v.landmarkOrder !== C;
		ee && (v.landmarks && (e.scene.remove(v.landmarks), fi(v.landmarks)), v.landmarks = ai(i), v.landmarkOrder = C, e.scene.add(v.landmarks), v.landmarkPositions = v.landmarks.children.map((e) => {
			let t = new ne().setFromObject(e);
			return {
				bounds: t,
				anchor: new P(e.position.x, t.max.y + .72, e.position.z)
			};
		})), v.season = r, v.mode = t, v.elapsed += b;
		let w = !1, te = new Set(a.map((e) => e.id));
		for (let [t, n] of v.models) te.has(t) || (e.scene.remove(n.body.root), fi(n.body.root), v.models.delete(t));
		let re = /* @__PURE__ */ new Map();
		for (let t of a) {
			let n = br[t.site];
			if (n === void 0) continue;
			let r = v.models.get(t.id);
			(!r || r.color !== t.color) && (r && (e.scene.remove(r.body.root), fi(r.body.root)), r = {
				body: Ur(t.color),
				from: n,
				depth: n,
				target: n,
				elapsed: 0,
				color: t.color
			}, v.models.set(t.id, r), e.scene.add(r.body.root)), r.target !== n && (r.from = x || g || n > r.depth ? n : r.depth, r.target = n, r.elapsed = 0), r.elapsed += b;
			let i = Math.min(2.9, .48 + Math.abs(r.target - r.from) * .038), a = Math.min(1, r.elapsed / i), o = r.from !== r.target && a < 1, s = a * a * (3 - 2 * a);
			r.depth = r.from + (r.target - r.from) * s;
			let c = re.get(t.site) ?? 0;
			re.set(t.site, c + 1);
			let l = c === 0 ? 0 : Math.min(3, Math.ceil(c / 2)) * (c % 2 ? -.83 : .83), u = Z(r.depth) + (o ? 0 : l), d = l && !o ? Math.max(Q(u, r.depth), Ar(r.depth)) : Ar(r.depth);
			r.body.root.position.set(u, d + .025, r.depth), r.body.root.rotation.y = -Math.atan2(Z(r.depth - .2) - Z(r.depth + .2), .4), r.body.pose(r.elapsed, o), w ||= o;
		}
		let T = n, E = v.models.get(s)?.depth ?? br[0], D = t === "overview", O = o.width <= 610, k = D ? qr(T.aspect) : Kr(E, O, f.current);
		D && (k.position.x += p.current.x, k.position.z += p.current.z, k.look.x += p.current.x, k.look.z += p.current.z);
		let ie = v.first || g ? 1 : 1 - Math.exp(-b * (w ? 8 : 7)), A = n.position.distanceToSquared(k.position) > 9e-4 || Math.abs(T.fov - k.fov) > .08;
		n.position.lerp(k.position, A ? ie : 1), A && (n.position.y = Math.max(n.position.y, Q(n.position.x, n.position.z) + 1.4)), v.aim.lerp(k.look, A ? ie : 1), T.fov += (k.fov - T.fov) * (A ? ie : 1), T.updateProjectionMatrix(), n.lookAt(v.aim), n.updateMatrixWorld(), e.sky.position.copy(n.position), Jr(e, E, v.elapsed, D), m.shadowMap.needsUpdate = v.first || w || S || ee || !A, v.first = !1;
		let ae = d.current;
		if (!ae || ae.hidden) {
			(w || A) && _();
			return;
		}
		let j = ae.getBoundingClientRect(), oe = ae.closest(".pke-layout")?.querySelectorAll(".pke-field-heading, .pke-field-roster, .pke-field-resources, .pke-camera, .pke-action-hud, .pke-field-nav") ?? [], se = Array.from(oe, (e) => {
			let t = e.getBoundingClientRect();
			return {
				x: t.left - j.left,
				y: t.top - j.top,
				width: t.width,
				height: t.height
			};
		}).filter(({ width: e, height: t }) => e > 0 && t > 0), ce = [];
		if (D) for (let { bounds: e } of v.landmarkPositions) {
			let t = hi(e, T, o, v.projected);
			t && ce.push(t);
		}
		let M = [];
		c.forEach((e, t) => {
			let r = l.current[t]?.firstElementChild;
			if (!r) return;
			let i = br[t], a = D ? v.landmarkPositions[t - 1]?.anchor : void 0;
			a ? v.projected.copy(a) : v.projected.set(Z(i), Ar(i) + 2.1, i);
			let s = v.projected.project(n), c = (s.x + 1) * o.width / 2, u = (1 - s.y) * o.height / 2, d = s.z <= -1 || s.z >= 1 || c < 0 || c > o.width || u < 0 || u > o.height, f = !D && !e.current && E - i > 19;
			(D || !d) && M.push({
				index: t,
				x: c,
				y: u,
				outside: d,
				compact: f,
				width: r.offsetWidth + 2,
				height: r.offsetHeight + 2
			});
		});
		let le = di(M, o, se, ce, D && o.width > o.height * 1.04 ? "across" : "up");
		l.current.forEach((e, t) => {
			if (!e) return;
			let n = le.find((e) => e.index === t), r = M.find((e) => e.index === t), i = u.current[t];
			if (e.toggleAttribute("data-placed", !!n), i && (i.style.visibility = "hidden"), !n || !r) return;
			e.toggleAttribute("data-compact", n.compact), e.style.left = `${n.x}px`, e.style.top = `${n.y}px`;
			let a = n.x + n.width / 2, o = n.y + n.height, s = Math.hypot(a - r.x, o - r.y);
			!i || r.outside || s < 12 || s > 76 || (i.setAttribute("x1", String(a)), i.setAttribute("y1", String(o)), i.setAttribute("x2", String(r.x)), i.setAttribute("y2", String(r.y)), i.style.visibility = "visible");
		}), (w || A) && _();
	}), null;
}
//#endregion
//#region src/game/view-player.tsx
var yi = [
	{
		id: "parks",
		label: "games.parkseurope.fieldParks"
	},
	{
		id: "cons",
		label: "games.parkseurope.fieldProjects"
	},
	{
		id: "hand",
		label: "games.parkseurope.fieldHand"
	},
	{
		id: "pack",
		label: "games.parkseurope.fieldPack"
	},
	{
		id: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		id: "trail",
		label: "games.parkseurope.trail"
	}
], bi = {
	"core-mountain": "mountain",
	"core-water": "water",
	"core-forest": "forest",
	"core-sun": "sun",
	carabiner: "carabiner",
	die: "die",
	chalet: "chalet",
	parks: "parks",
	wildlife: "wildlife",
	photo: "photo",
	mug: "mug",
	wonder: "wonder",
	conservation: "cons"
}, xi = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], Si = {
	mountain: 0,
	forest: 0,
	sun: 0,
	water: 0,
	wildlife: 0
}, Ci = "#4f5d4a", wi = ["#4f5d4a", "#a4632f"], Ti = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]), Ei = {
	cliffs: "games.parkseurope.season.cliffs",
	swimming: "games.parkseurope.season.swimming",
	memories: "games.parkseurope.season.memories",
	sun: "games.parkseurope.season.sun",
	dreams: "games.parkseurope.season.dreams",
	joy: "games.parkseurope.season.joy",
	scouting: "games.parkseurope.season.scouting",
	growth: "games.parkseurope.season.growth",
	climbing: "games.parkseurope.season.climbing",
	caves: "games.parkseurope.season.caves",
	meadows: "games.parkseurope.season.meadows",
	ice: "games.parkseurope.season.ice"
}, Di = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any"
}, Oi = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple",
	wild: "games.parkseurope.suit.wild"
}, ki = {
	"core-forest": "games.parkseurope.siteShort.core-forest",
	"core-sun": "games.parkseurope.siteShort.core-sun",
	"core-mountain": "games.parkseurope.siteShort.core-mountain",
	"core-water": "games.parkseurope.siteShort.core-water",
	wildlife: "games.parkseurope.siteShort.wildlife",
	carabiner: "games.parkseurope.siteShort.carabiner",
	parks: "games.parkseurope.siteShort.parks",
	die: "games.parkseurope.siteShort.die",
	photo: "games.parkseurope.siteShort.photo",
	mug: "games.parkseurope.siteShort.mug",
	chalet: "games.parkseurope.siteShort.chalet",
	wonder: "games.parkseurope.siteShort.wonder",
	conservation: "games.parkseurope.siteShort.conservation"
}, Ai = {
	wonder: "games.parkseurope.vfShort.wonder",
	sunwater: "games.parkseurope.vfShort.sunwater",
	photo: "games.parkseurope.vfShort.photo",
	conservation: "games.parkseurope.vfShort.conservation",
	mug: "games.parkseurope.vfShort.mug",
	wildlife: "games.parkseurope.vfShort.wildlife"
}, ji = {
	conservation: "games.parkseurope.top.conservation",
	carabiner: "games.parkseurope.top.carabiner",
	mug: "games.parkseurope.top.mug",
	chalet: "games.parkseurope.top.chalet"
}, Mi = {
	die: "games.parkseurope.benefit.die",
	parks: "games.parkseurope.benefit.parks",
	mug: "games.parkseurope.benefit.mug",
	wonder: "games.parkseurope.benefit.wonder",
	photo: "games.parkseurope.benefit.photo",
	wildlife: "games.parkseurope.benefit.wildlife",
	carabiner: "games.parkseurope.benefit.carabiner"
}, Ni = {
	snow: "games.parkseurope.res.snow",
	wonder: "games.parkseurope.site.wonder",
	mug: "games.parkseurope.site.mug",
	photo: "games.parkseurope.site.photo",
	wildlife: "games.parkseurope.res.wildlife",
	carabiner: "games.parkseurope.token.carabiner",
	die: "games.parkseurope.site.die",
	chalet: "games.parkseurope.top.chalet"
}, Pi = {
	consForest: "games.parkseurope.campfire.consForest",
	consMountain: "games.parkseurope.campfire.consMountain",
	consSun: "games.parkseurope.campfire.consSun",
	consWater: "games.parkseurope.campfire.consWater",
	iconForest: "games.parkseurope.campfire.iconForest",
	iconMountain: "games.parkseurope.campfire.iconMountain",
	iconSun: "games.parkseurope.campfire.iconSun",
	iconWater: "games.parkseurope.campfire.iconWater",
	anyIcons: "games.parkseurope.campfire.anyIcons",
	album: "games.parkseurope.campfire.album",
	wonderHand: "games.parkseurope.campfire.wonderHand",
	snow: "games.parkseurope.campfire.snow",
	turnWildlife2: "games.parkseurope.campfire.turnWildlife2",
	turnAny2: "games.parkseurope.campfire.turnAny2",
	turnCarabiner: "games.parkseurope.campfire.turnCarabiner",
	turnAny3: "games.parkseurope.campfire.turnAny3"
}, Fi = [
	"games.parkseurope.consProject.p0",
	"games.parkseurope.consProject.p1",
	"games.parkseurope.consProject.p2",
	"games.parkseurope.consProject.p3",
	"games.parkseurope.consProject.p4",
	"games.parkseurope.consProject.p5",
	"games.parkseurope.consProject.p6"
], Ii = {
	move: "games.parkseurope.pending.move",
	trailEnd: "games.parkseurope.pending.trailEnd",
	actions: "games.parkseurope.pending.actions",
	parks: "games.parkseurope.pending.parks",
	mug: "games.parkseurope.pending.mug",
	mugChoice: "games.parkseurope.pending.mugChoice",
	cons: "games.parkseurope.pending.cons",
	assignWild: "games.parkseurope.pending.assignWild",
	freePark: "games.parkseurope.pending.freePark",
	discardRes: "games.parkseurope.pending.discardRes",
	discardWonder: "games.parkseurope.pending.discardWonder",
	gretaColor: "games.parkseurope.pending.gretaColor",
	scoring: "games.parkseurope.pending.scoring",
	none: "games.parkseurope.pending.none"
}, Li = {
	mountain: "#6b7c8f",
	forest: "#3f7a4d",
	sun: "#d9a227",
	water: "#3a7ca5",
	wildlife: "#8a5a44",
	snow: "#cfe3ee",
	any: "#8b8578"
};
function Ri(e, t) {
	return Ge(e.res, t) !== null;
}
function zi({ color: e, label: t, greta: n, avatar: r, selected: i }) {
	return /* @__PURE__ */ b("span", {
		className: "pke-hiker-mark",
		"data-selected": i,
		style: { "--pke-mark": e },
		role: "img",
		"aria-label": t,
		title: t,
		children: n ? /* @__PURE__ */ b("i", {
			className: "pke-greta-glyph",
			"aria-hidden": !0
		}) : /* @__PURE__ */ b("img", {
			src: r,
			alt: "",
			draggable: !1
		})
	});
}
function Bi(e) {
	let t = e.public, n = e.private ?? {
		hand: [],
		isTurn: !1
	};
	return /* @__PURE__ */ b(Vi, {
		pub: t,
		hand: n.hand,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Vi({ pub: e, hand: t, members: n, myRid: r, send: a }) {
	let v = u();
	g();
	let S = e.players.find((e) => e.rid === r), C = e.phase === "turn" && e.turn === r && !!S, ee = e.phase === "scoring" && e.turn === r && !!S, [w, te] = s(r), [ne, re] = s(0), [T, E] = s(null), [D, O] = s(null), [k, ie] = s(null), [A, ae] = s({ ...Si }), [j, oe] = s(""), [se, ce] = s(""), [M, le] = s("overview"), [N, ue] = s(0), [de, fe] = s(null), [pe, me] = s({
		panel: null,
		id: 0
	}), [he, ge] = s(null), [_e, ve] = s(null), [P, ye] = s("display"), [be, xe] = s("route"), [Se, we] = s(null), [Te, L] = s(0), Oe = o(null), ke = o(!1), { root: Ae, capture: Me, record: Ne, active: Pe, timing: Fe } = ar(e, t, r);
	i(() => {
		let e = Oe.current;
		e && (e.scrollTop = 0, ke.current && (ke.current = !1, e.querySelector("#pke-panel-parks .pke-park-face[aria-pressed=\"true\"]")?.focus()));
	}, [
		de,
		pe,
		P,
		be
	]);
	let Le = e.players.find((e) => e.rid === w) ?? e.players.find((e) => e.rid === r) ?? e.players[0], Re = (e) => n.find((t) => t.rid === e), z = (t) => t === "$greta" ? v("games.parkseurope.greta") : Re(t)?.name || v(h[(Re(t)?.colorIndex ?? Math.max(0, e.order.indexOf(t))) % h.length].nameKey), ze = (e) => e === "$greta" ? Ci : h[(Re(e)?.colorIndex ?? 0) % h.length].hex, Be = (e) => c[(Re(e)?.avatar ?? 0) % c.length], Ve = (t) => e.greta?.solo ? wi[Math.floor(t / 2) % wi.length] : Ci, He = (e, t) => `${z(e)} · ${v("games.parkseurope.hikerLabel", { n: t + 1 })}`, Ue = (e, t, n) => {
		let i = e === r && t === V, a = He(e, t) + (i ? " · " + v("games.parkseurope.selectedHiker") : "");
		return e === "$greta" ? /* @__PURE__ */ b(zi, {
			greta: !0,
			color: Ve(t),
			label: a
		}, n) : /* @__PURE__ */ b(zi, {
			color: ze(e),
			avatar: Be(e),
			label: a,
			selected: i
		}, n);
	}, We = (t) => {
		let n = [];
		for (let r of e.players) r.hikers.forEach((e, i) => {
			e === t && n.push({
				rid: r.rid,
				hiker: i
			});
		});
		return e.greta && e.greta.hikers.forEach((e, r) => {
			e === t && n.push({
				rid: "$greta",
				hiker: r
			});
		}), n;
	}, Ge = (n) => e.campfires.includes(n) || t.some((e) => !!R[e]), Ke = `${e.season}:${e.turn}:${e.moved}:${e.pending}:${S?.hikers.join(",") ?? ""}:${t.length}`;
	if (se !== Ke && (ce(Ke), S)) {
		let e = S.hikers.map((e, t) => e < 8 ? t : -1).filter((e) => e >= 0);
		re(e.includes(ne) ? ne : e[0] ?? 0);
	}
	let qe = S ? xi.reduce((e, t) => e + S.res[t], 0) : 0, Je = e.pending === "discardRes" ? "discardRes" : e.pending === "discardWonder" ? "discardWonder" : e.pending === "assignWild" ? "assignWild" : e.pending === "freePark" ? "freePark" : null, Ye = `${e.season}:${e.turn}:${e.pending}:${qe}:${t.length}:${e.landingSite}`;
	if (Ye !== j && (oe(Ye), Je && C && E(Je)), !S) return /* @__PURE__ */ b(_, {
		adaptive: !0,
		className: "pke-screen",
		children: /* @__PURE__ */ b("p", {
			className: "pke-empty",
			children: v("games.parkseurope.err.notPlayer")
		})
	});
	let Xe = C && e.pending === "parks" ? "parks" : C && e.pending === "cons" ? "cons" : null, Ze = pe.panel === Xe ? pe.id : pe.id + 1;
	pe.panel !== Xe && me({
		panel: Xe,
		id: Ze
	});
	let Qe = `${r}:${e.season}:${e.turn}:${S.hikers.join(",")}`;
	Xe === "parks" && he?.turn !== Qe ? ge({
		turn: Qe,
		visits: S.visited.length
	}) : he && (he.turn !== Qe || [
		"actions",
		"move",
		"trailEnd",
		"none"
	].includes(e.pending)) && ge(null);
	let $e = de?.seat === r ? de : null, B = $e && (!Xe || $e.prompt === Ze) ? $e.panel : Xe, et = (e) => {
		let t = e === null && $e?.prompt === Ze && $e.returnToParks;
		t && (ke.current = !0), fe({
			seat: r,
			prompt: Ze,
			panel: t ? "parks" : e,
			returnToParks: e !== null && e !== "parks" && (B === "parks" || !!$e?.returnToParks)
		});
	}, tt = _e?.seat === r && (_e.from === "display" ? e.parksDisplay : S.reserved).includes(_e.id) ? _e : null, nt = xi.filter((e) => S.res[e]), rt = S.visited.at(-1), it = rt && Xe === "parks" && he?.turn === Qe && S.visited.length > he.visits ? F[rt.id] : null, at = (e) => e === "$greta" ? /* @__PURE__ */ b(zi, {
		greta: !0,
		color: Ci,
		label: z(e)
	}) : /* @__PURE__ */ b(zi, {
		color: ze(e),
		avatar: Be(e),
		label: z(e)
	}), ot = e.consDeck > 0 && (e.freeCons || Ri(S, {
		sun: 1,
		water: 1
	})), st = S.hikers[ne] < 8 || S.hikers[1 - ne] >= 8 ? ne : +(ne === 0), ct = S.hikers[st], V = C && ct < 8 ? st : null, H = /* @__PURE__ */ new Set();
	if (C && (e.pending === "move" || e.pending === "trailEnd")) {
		if (e.pending === "trailEnd") H.add(8);
		else if (ct < 8) {
			for (let e = ct + 1; e <= 7; e++) (We(e).length === 0 || Ge(e)) && H.add(e);
			H.add(8);
		}
	}
	let U = (e) => {
		Ne(e), a(e);
	}, lt = (e) => {
		if (H.has(e)) {
			if (ue(st), e === 8) {
				E("trailEnd");
				return;
			}
			if (We(e).length > 0) {
				O({
					hiker: st,
					to: e
				}), E("campfire");
				return;
			}
			U({
				type: "move",
				hiker: st,
				to: e
			});
		}
	}, ut = (t) => {
		we({
			seat: r,
			season: e.season,
			site: t
		}), et("site");
	}, W = Se?.seat === r && Se.season === e.season ? Se.site : null, dt = W === null ? null : e.trailSites[W - 1], ft = W === null ? null : e.vf[W - 1], pt = W === null ? null : e.trailBonus[W - 1], mt = W === null ? [] : We(W), ht = (t) => v(t === 0 ? "games.parkseurope.trailStart" : t === 8 ? "games.parkseurope.trailEnd" : ki[e.trailSites[t - 1]]), gt = e.phase === "ended" || e.pending === "none" ? v("games.parkseurope.pending.none") : ee ? v("games.parkseurope.pending.scoring") : C ? v(Ii[e.pending]) : v("games.parkseurope.waitingFor", { name: z(e.turn ?? "") }), _t = Ei[e.seasonCard] ? v(Ei[e.seasonCard]) : e.seasonCard, vt = e.landingSite === null ? null : e.vf[e.landingSite - 1], yt = C && e.pending === "actions" && !e.vfUsed && e.landingSite !== null && vt !== null && S.carabiners > 0, G = e.landingSite === null ? null : e.trailSites[e.landingSite - 1], bt = G ? Ie(G) : null, xt = bt ? S.cons.map((e, t) => ({
		id: e,
		i: t
	})).filter(({ id: t, i: n }) => I(t) === bt && !e.consUsed.includes(n)) : [], St = !e.end || e.end.topDone && e.end.parksDone, Ct = t.filter((t) => !!R[t] && Ti.has(R[t].effect) && !e.campfireUsed.includes(t)), wt = xi.reduce((e, t) => e + A[t], 0), Tt = /* @__PURE__ */ x("div", {
		className: "pke-actions",
		children: [/* @__PURE__ */ b("div", {
			className: "pke-actions-hikers",
			role: "group",
			"aria-label": v("games.parkseurope.chooseHiker"),
			children: [0, 1].map((t) => {
				let n = t, r = S.hikers[n];
				return /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-hiker",
					"data-on": V === n,
					disabled: !C || r >= 8 || e.pending !== "move" && e.pending !== "trailEnd",
					"aria-pressed": V === n,
					onClick: () => {
						re(n), ue(n);
					},
					children: [
						/* @__PURE__ */ b("b", { children: v("games.parkseurope.hikerLabel", { n: t + 1 }) }),
						/* @__PURE__ */ b("span", { children: r >= 8 ? v("games.parkseurope.atEnd") : r === 0 ? v("games.parkseurope.trailStart") : v("games.parkseurope.siteNo", { n: r }) }),
						V === n && /* @__PURE__ */ b("small", {
							className: "pke-hiker-selected",
							"aria-hidden": !0,
							children: v("games.parkseurope.selectedHiker")
						})
					]
				}, n);
			})
		}), /* @__PURE__ */ b("div", {
			className: "pke-actions-main",
			children: e.pending === "gretaColor" && C ? /* @__PURE__ */ b(y, { children: [0, 1].map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({
					type: "gretaColor",
					first: e
				}),
				children: [/* @__PURE__ */ b("i", {
					className: "pke-pair-dot",
					style: { background: wi[e] },
					"aria-hidden": !0
				}), v(e === 0 ? "games.parkseurope.gretaPairA" : "games.parkseurope.gretaPairB")]
			}, e)) }) : e.phase === "scoring" ? ee ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => E("scoring"),
				children: v("games.parkseurope.scoringTitle")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => {
					U({ type: "scoringDone" }), E(null), ie(null), ae({ ...Si });
				},
				children: v("games.parkseurope.scoringDone")
			})] }) : null : !C || e.pending === "move" || e.pending === "trailEnd" ? null : e.pending === "parks" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => et("parks"),
				children: v("games.parkseurope.fieldChoosePark")
			}) : e.pending === "mug" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: S.mug >= 3,
				onClick: () => U({
					type: "mug",
					act: "fill"
				}),
				children: v("games.parkseurope.mug.fill")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				disabled: S.mug < 1,
				onClick: () => U({
					type: "mug",
					act: "drink"
				}),
				children: v("games.parkseurope.mug.drink")
			})] }) : e.pending === "mugChoice" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => U({
					type: "mugChoice",
					choice: "chalet"
				}),
				children: v("games.parkseurope.mug.chalet")
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({
					type: "mugChoice",
					choice: "cons"
				}),
				children: v("games.parkseurope.mug.cons")
			})] }) : e.pending === "cons" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: !ot,
				onClick: () => U({
					type: "consPick",
					deck: !0
				}),
				children: [
					v("games.parkseurope.startDeck"),
					" · ",
					e.freeCons ? v("games.parkseurope.free") : v("games.parkseurope.deckCost")
				]
			}), /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => U({ type: "skip" }),
				children: v("games.parkseurope.skip")
			})] }) : e.pending === "assignWild" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("assignWild"),
				children: v("games.parkseurope.assignWildPrompt")
			}) : e.pending === "freePark" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("freePark"),
				children: v("games.parkseurope.freeParkPrompt")
			}) : e.pending === "discardRes" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("discardRes"),
				children: v("games.parkseurope.discardResPrompt")
			}) : e.pending === "discardWonder" ? /* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("discardWonder"),
				children: v("games.parkseurope.discardWonderPrompt")
			}) : /* @__PURE__ */ x(y, { children: [
				e.end?.action && !e.end.topDone && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "endTop" }),
					children: [
						v("games.parkseurope.endTop"),
						" · ",
						v(ji[e.end.action])
					]
				}),
				e.end && !e.end.parksDone && /* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "endParks" }),
					children: v("games.parkseurope.endParksTodo")
				}),
				G && !e.siteDone && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => U({ type: "siteAction" }),
					children: [
						v("games.parkseurope.siteAction"),
						" · ",
						v(ki[G])
					]
				}),
				xt.length > 0 && /* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => E("activateCons"),
					children: v("games.parkseurope.activateCons")
				}),
				yt && /* @__PURE__ */ x("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => U({ type: "viaFerrata" }),
					children: [v("games.parkseurope.viaFerrata"), vt ? ` · ${v(Ai[vt])}` : ""]
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					disabled: !St,
					onClick: () => U({ type: "endTurn" }),
					children: v("games.parkseurope.endTurn")
				})
			] })
		})]
	});
	return /* @__PURE__ */ x("div", {
		className: "pke-motion-root",
		ref: Ae,
		onClickCapture: Me,
		children: [/* @__PURE__ */ x(_, {
			adaptive: !0,
			scroll: !1,
			className: "pke-screen",
			children: [
				/* @__PURE__ */ x("div", {
					className: "pke-layout",
					children: [
						/* @__PURE__ */ x("div", {
							className: "pke-field-stage",
							children: [
								/* @__PURE__ */ b(gi, {
									mode: M,
									season: e.season,
									trailSites: e.trailSites,
									resetKey: Te,
									focused: `${r}:${N}`,
									hikers: [...e.players.flatMap((e) => e.hikers.map((t, n) => ({
										id: `${e.rid}:${n}`,
										site: t,
										color: ze(e.rid)
									}))), ...e.greta?.hikers.map((e, t) => ({
										id: `$greta:${t}`,
										site: e,
										color: Ve(t)
									})) ?? []],
									sites: Array.from({ length: 9 }, (t, n) => {
										let i = e.trailSites[n - 1];
										return {
											label: n === 0 ? v("games.parkseurope.trailStart") : n === 8 ? v("games.parkseurope.trailEnd") : `${n} ${v(ki[i])}`,
											shortLabel: n === 0 ? v("games.parkseurope.fieldStartShort") : n === 8 ? v("games.parkseurope.fieldEndShort") : void 0,
											color: i && Ie(i) ? Li[Ie(i)] : n === 8 ? "#f6b396" : "#efd999",
											current: S.hikers[M === "follow" ? N : st] === n,
											legal: H.has(n),
											selected: V !== null && ct === n ? He(r, V) + " · " + v("games.parkseurope.selectedHiker") : void 0,
											icon: i && /* @__PURE__ */ b(K, { kind: bi[i] }),
											occupants: We(n).map((e) => Ue(e.rid, e.hiker, `${e.rid}:${e.hiker}`))
										};
									}),
									inspectedSite: B === "site" ? W : null,
									onSite: ut,
									fallback: v("games.parkseurope.valleyUnavailable")
								}),
								/* @__PURE__ */ b("div", {
									className: "pke-field-heading",
									children: /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ x("strong", { children: ["PARKS ", /* @__PURE__ */ b("em", { children: "EUROPE" })] }), /* @__PURE__ */ x("span", { children: [
										v("games.parkseurope.seasonLabel", { n: e.season }),
										" · ",
										_t
									] })] })
								}),
								/* @__PURE__ */ b("div", {
									className: "pke-field-roster",
									children: e.players.map((t) => /* @__PURE__ */ x("button", {
										type: "button",
										"data-turn": e.turn === t.rid,
										"aria-label": z(t.rid) + " · " + v("games.parkseurope.visitedCount", { n: t.visited.length }),
										"aria-expanded": B === "pack" && Le.rid === t.rid,
										onClick: () => {
											te(t.rid), et("pack");
										},
										children: [at(t.rid), /* @__PURE__ */ b("b", { children: z(t.rid) })]
									}, t.rid))
								}),
								/* @__PURE__ */ x("button", {
									type: "button",
									className: "pke-field-resources",
									"aria-label": v("games.parkseurope.fieldPack"),
									"data-kinds": nt.length + Number(S.snow > 0),
									"aria-expanded": B === "pack" && Le.rid === r,
									onClick: () => {
										te(r), et(B === "pack" && Le.rid === r ? null : "pack");
									},
									children: [/* @__PURE__ */ x("span", {
										className: "pke-resource-counts",
										children: [
											nt.map((e) => /* @__PURE__ */ b(q, {
												kind: e,
												count: S.res[e]
											}, e)),
											S.snow > 0 && /* @__PURE__ */ b(q, {
												kind: "snow",
												count: S.snow
											}),
											!qe && !S.snow && /* @__PURE__ */ b(m, {})
										]
									}), /* @__PURE__ */ x("span", {
										className: "pke-resource-load",
										children: [/* @__PURE__ */ b(m, {}), /* @__PURE__ */ x("b", { children: [qe + S.snow * 2, " / 12"] })]
									})]
								}),
								/* @__PURE__ */ x("div", {
									className: "pke-camera",
									role: "group",
									"aria-label": v("games.parkseurope.camera"),
									children: [
										/* @__PURE__ */ x("button", {
											type: "button",
											"aria-pressed": M === "overview",
											onClick: () => le("overview"),
											children: [/* @__PURE__ */ b(f, {}), v("games.parkseurope.overview")]
										}),
										/* @__PURE__ */ x("button", {
											type: "button",
											"aria-pressed": M === "follow",
											onClick: () => le("follow"),
											children: [/* @__PURE__ */ b(p, {}), v("games.parkseurope.follow")]
										}),
										/* @__PURE__ */ b("button", {
											type: "button",
											"aria-label": v("games.parkseurope.fieldResetCamera"),
											onClick: () => {
												le("overview"), L((e) => e + 1);
											},
											children: "⌖"
										})
									]
								})
							]
						}),
						e.phase === "scoring" && e.revealedCampfire && /* @__PURE__ */ x("section", {
							className: "pke-panel pke-scoring",
							children: [/* @__PURE__ */ x("header", {
								className: "pke-section-head",
								children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.scoringTitle") }), /* @__PURE__ */ b("span", {
									className: "pke-sub",
									children: v("games.parkseurope.scoringPrompt")
								})]
							}), /* @__PURE__ */ b("ul", {
								className: "pke-scoring-list",
								children: e.revealedCampfire.map(({ rid: t, cards: n }) => {
									let r = e.players.find((e) => e.rid === t);
									return /* @__PURE__ */ x("li", {
										"data-on": e.turn === t,
										children: [
											/* @__PURE__ */ b("b", { children: z(t) }),
											/* @__PURE__ */ b("span", { children: n.length === 0 ? v("games.parkseurope.scoringEmpty") : n.map((t) => {
												let n = R[t]?.effect, r = e.campfireUsed.includes(t);
												return `${Pn(v, t)}${n ? ` · ${v(Pi[n])}` : ""}${r ? ` · ${v("games.parkseurope.scoringUsed")}` : ""}`;
											}).join("、") }),
											/* @__PURE__ */ b("span", {
												className: "pke-scoring-points",
												children: v("games.parkseurope.over.endgame", { n: r?.endPoints ?? 0 })
											})
										]
									}, t);
								})
							})]
						}),
						/* @__PURE__ */ x("section", {
							className: "pke-action-hud",
							"aria-label": v("games.parkseurope.fieldAction"),
							children: [/* @__PURE__ */ b("header", {
								className: "pke-action-title",
								"aria-live": "polite",
								children: gt
							}), Tt]
						}),
						/* @__PURE__ */ b("nav", {
							className: "pke-field-nav",
							"aria-label": v("games.parkseurope.fieldPanels"),
							children: yi.map(({ id: e, label: n }) => /* @__PURE__ */ x("button", {
								type: "button",
								"data-panel": e,
								"aria-expanded": B === e,
								"aria-controls": `pke-panel-${e}`,
								onClick: () => {
									e === "pack" && B !== e && te(r), et(B === e ? null : e);
								},
								children: [
									e === "pack" ? /* @__PURE__ */ b(m, {}) : e !== "trail" && /* @__PURE__ */ b(K, { kind: e === "hand" ? "wonder" : e }),
									/* @__PURE__ */ b("span", { children: v(n) }),
									e === "hand" && /* @__PURE__ */ b("b", { children: t.length })
								]
							}, e))
						}),
						/* @__PURE__ */ x("div", {
							"data-panel": B,
							className: "pke-boards pke-field-drawer",
							hidden: B === null || B === "site" && W === null,
							onKeyDown: (e) => {
								e.key === "Escape" && (e.stopPropagation(), et(null));
							},
							children: [/* @__PURE__ */ b("button", {
								type: "button",
								className: "pke-field-close",
								"aria-label": v("games.parkseurope.closePanel"),
								onClick: () => et(null),
								children: /* @__PURE__ */ b(d, {})
							}), /* @__PURE__ */ x("div", {
								ref: Oe,
								className: "pke-field-scroll",
								children: [
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-parks",
										hidden: B !== "parks",
										id: "pke-panel-parks",
										children: [
											/* @__PURE__ */ x("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.parksTitle") }), /* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: v("games.parkseurope.deckCount", { n: e.parksDeck })
												})]
											}),
											/* @__PURE__ */ b(cr, {
												items: [["display", v("games.parkseurope.fieldDisplay")], ["reserved", v("games.parkseurope.fieldReserved", { n: S.reserved.length })]],
												active: P,
												onSelect: ye,
												label: v("games.parkseurope.parksTitle")
											}),
											/* @__PURE__ */ b("div", {
												className: "pke-card-row",
												children: (P === "display" ? e.parksDisplay : S.reserved).map((t, n) => {
													let i = F[t];
													return i ? /* @__PURE__ */ b(Rn, {
														park: i,
														suitLabel: v(Oi[i.suit]),
														bonus: P === "display" ? e.parksBonus[n] : null,
														effect: i.instant ? v(Ni[i.instant]) : void 0,
														picked: tt?.id === t && tt.from === P,
														onPick: () => ve({
															seat: r,
															id: t,
															from: P
														})
													}, t) : null;
												})
											}),
											P === "reserved" && !S.reserved.length && /* @__PURE__ */ b("p", {
												className: "pke-muted",
												children: v("games.parkseurope.fieldNoReserved")
											}),
											tt?.from === P && C && e.pending === "parks" && (() => {
												let t = F[tt.id], n = Ri(S, t.cost);
												return /* @__PURE__ */ x("div", {
													className: "pke-park-choice",
													"aria-live": "polite",
													children: [/* @__PURE__ */ b("strong", { children: Nn(v, t.id) }), /* @__PURE__ */ x("div", {
														className: "pke-card-actions",
														children: [tt.from === "display" && !it && /* @__PURE__ */ b("button", {
															type: "button",
															className: "pke-btn pke-btn--quiet",
															onClick: () => U({
																type: "reserve",
																from: "display",
																index: e.parksDisplay.indexOf(t.id)
															}),
															children: v("games.parkseurope.reserve")
														}), /* @__PURE__ */ b("button", {
															type: "button",
															className: "pke-btn pke-btn--main",
															disabled: !n,
															onClick: () => U({
																type: "visit",
																parkId: t.id
															}),
															children: v(n ? "games.parkseurope.visit" : "games.parkseurope.cannotAfford")
														})]
													})]
												});
											})(),
											C && e.pending === "parks" && /* @__PURE__ */ x("div", {
												className: "pke-park-footer",
												children: [it ? /* @__PURE__ */ x("output", {
													className: "pke-park-receipt",
													children: [
														/* @__PURE__ */ b(K, { kind: "parks" }),
														" ",
														v("games.parkseurope.fieldVisitedPark", {
															name: Nn(v, it.id),
															n: it.points
														})
													]
												}) : e.parksDeck > 0 && /* @__PURE__ */ x("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => U({
														type: "reserve",
														from: "deck"
													}),
													children: [
														v("games.parkseurope.reserve"),
														" · ",
														v("games.parkseurope.startDeck")
													]
												}), /* @__PURE__ */ b("button", {
													type: "button",
													className: "pke-btn pke-btn--quiet",
													onClick: () => U({ type: "parksDone" }),
													children: v("games.parkseurope.fieldFinishParks")
												})]
											})
										]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-cons",
										hidden: B !== "cons",
										id: "pke-panel-cons",
										children: [/* @__PURE__ */ x("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.consTitle") }), /* @__PURE__ */ b("span", {
												className: "pke-sub",
												children: v("games.parkseurope.consAwardsLabel", { n: e.consAwardsLeft })
											})]
										}), /* @__PURE__ */ b("div", {
											className: "pke-card-row pke-project-row",
											children: e.consDisplay.map((t, n) => {
												let r = I(t), i = De[t % 7], a = C && e.pending === "cons", o = a && e.freeCons, s = o || Ri(S, Ee[r]);
												return /* @__PURE__ */ b(Xn, {
													id: t,
													name: v(Fi[t % 7]),
													site: v("games.parkseurope.projectSite", { resource: v(Di[r]) }),
													benefit: v(Mi[i.benefit]),
													free: o,
													bonus: e.consBonus[n],
													action: a ? {
														label: v(s ? o ? "games.parkseurope.free" : "games.parkseurope.support" : "games.parkseurope.cannotAfford"),
														disabled: !s,
														onPress: () => U({
															type: "consPick",
															index: n
														})
													} : void 0
												}, t);
											})
										})]
									}),
									W !== null && /* @__PURE__ */ x("section", {
										className: "pke-panel pke-site-peek",
										hidden: B !== "site",
										id: "pke-panel-site",
										children: [
											/* @__PURE__ */ x("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ x("h2", { children: [dt && /* @__PURE__ */ b(K, { kind: bi[dt] }), ht(W)] }), dt && /* @__PURE__ */ b("b", {
													className: "pke-route-number",
													children: W
												})]
											}),
											/* @__PURE__ */ b("p", {
												className: "pke-site-description",
												children: v(dt ? `games.parkseurope.fieldSiteDetail.${dt}` : W === 0 ? "games.parkseurope.fieldTrailheadInfo" : "games.parkseurope.fieldTrailEndInfo")
											}),
											(pt || ft || e.campfires.includes(W) || W === 4) && /* @__PURE__ */ x("dl", {
												className: "pke-site-extras",
												children: [
													pt && /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: v("games.parkseurope.fieldSeasonReward") }), /* @__PURE__ */ b("dd", { children: /* @__PURE__ */ b(q, {
														kind: pt,
														count: 1
													}) })] }),
													ft && /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: v("games.parkseurope.viaFerrata") }), /* @__PURE__ */ x("dd", { children: [
														/* @__PURE__ */ b("b", { children: v(Ai[ft]) }),
														" · ",
														v("games.parkseurope.fieldFerrataInfo")
													] })] }),
													e.campfires.includes(W) && /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: v("games.parkseurope.campfireLabel") }), /* @__PURE__ */ b("dd", { children: v("games.parkseurope.fieldShareInfo") })] }),
													W === 4 && /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: v("games.parkseurope.fieldStop") }), /* @__PURE__ */ b("dd", { children: v("games.parkseurope.shutterbug") })] })
												]
											}),
											/* @__PURE__ */ x("div", {
												className: "pke-site-occupants",
												children: [/* @__PURE__ */ b("strong", { children: v("games.parkseurope.fieldHikers") }), mt.length ? /* @__PURE__ */ b("ul", { children: mt.map(({ rid: e, hiker: t }) => /* @__PURE__ */ x("li", { children: [Ue(e, t), /* @__PURE__ */ b("span", { children: He(e, t) })] }, e + ":" + t)) }) : /* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldSiteEmpty") })]
											}),
											H.has(W) ? /* @__PURE__ */ b("button", {
												type: "button",
												className: "pke-btn pke-btn--main pke-site-go",
												"aria-label": v("games.parkseurope.fieldGoTo", { name: ht(W) }),
												onClick: () => {
													et(null), lt(W);
												},
												children: v("games.parkseurope.fieldMoveHere")
											}) : W === 8 && /* @__PURE__ */ b("button", {
												type: "button",
												className: "pke-btn pke-site-go",
												onClick: () => {
													xe("end"), et("trail");
												},
												children: v("games.parkseurope.fieldEndSpaces")
											})
										]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel",
										hidden: B !== "trail",
										id: "pke-panel-trail",
										children: [
											/* @__PURE__ */ b("header", {
												className: "pke-section-head",
												children: /* @__PURE__ */ b("h2", { children: v("games.parkseurope.fieldTrailSeason") })
											}),
											/* @__PURE__ */ b(cr, {
												items: [
													["route", v("games.parkseurope.fieldTrailRoute")],
													["end", v("games.parkseurope.fieldEndActions")],
													["season", v("games.parkseurope.fieldSeasonTab")]
												],
												active: be,
												onSelect: xe,
												label: v("games.parkseurope.fieldTrailSeason")
											}),
											be === "route" && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("div", {
												className: "pke-route-head",
												"aria-hidden": !0,
												children: [
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldStop") }),
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldExtras") }),
													/* @__PURE__ */ b("span", { children: v("games.parkseurope.fieldHikers") })
												]
											}), /* @__PURE__ */ b("ol", {
												className: "pke-route",
												children: Array.from({ length: 9 }, (t, n) => {
													let r = e.trailSites[n - 1], i = e.vf[n - 1], a = e.trailBonus[n - 1], o = ht(n), s = H.has(n);
													return /* @__PURE__ */ x("li", {
														className: "pke-route-stop",
														"data-legal": s,
														"aria-current": e.landingSite === n ? "location" : void 0,
														children: [
															/* @__PURE__ */ b("b", {
																className: "pke-route-number",
																children: n === 0 ? v("games.parkseurope.fieldStartShort") : n === 8 ? v("games.parkseurope.fieldEndShort") : n
															}),
															/* @__PURE__ */ x("span", {
																className: "pke-route-name",
																children: [r && /* @__PURE__ */ b(K, { kind: bi[r] }), /* @__PURE__ */ b("button", {
																	type: "button",
																	onClick: () => ut(n),
																	children: o
																})]
															}),
															/* @__PURE__ */ x("span", {
																className: "pke-route-extras",
																children: [
																	i && /* @__PURE__ */ x("span", { children: [
																		v("games.parkseurope.viaFerrata"),
																		" · ",
																		v(Ai[i])
																	] }),
																	a && /* @__PURE__ */ x("span", { children: [
																		v("games.parkseurope.fieldSeasonTab"),
																		" ",
																		/* @__PURE__ */ b(q, { kind: a })
																	] }),
																	e.campfires.includes(n) && /* @__PURE__ */ b("span", { children: v("games.parkseurope.campfireLabel") }),
																	n === 4 && /* @__PURE__ */ b("span", { children: v("games.parkseurope.shutterbug") })
																]
															}),
															/* @__PURE__ */ b("span", {
																className: "pke-route-hikers",
																children: We(n).map((e) => Ue(e.rid, e.hiker, e.rid + ":" + e.hiker))
															})
														]
													}, n);
												})
											})] }),
											be === "end" && /* @__PURE__ */ b(pr, {
												pub: e,
												nameOf: z,
												marker: at,
												actionName: (e) => v(ji[e])
											}),
											be === "season" && /* @__PURE__ */ b(mr, {
												pub: e,
												name: _t
											})
										]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-chalet",
										hidden: B !== "chalet",
										id: "pke-panel-chalet",
										children: [/* @__PURE__ */ b("header", {
											className: "pke-section-head",
											children: /* @__PURE__ */ b("h2", { children: v("games.parkseurope.chaletTrack") })
										}), /* @__PURE__ */ b(dr, {
											pub: e,
											nameOf: z,
											marker: at
										})]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-mat",
										hidden: B !== "pack",
										id: "pke-panel-pack",
										children: [/* @__PURE__ */ x("header", {
											className: "pke-section-head",
											children: [/* @__PURE__ */ b("h2", { children: Le.rid === r ? v("games.parkseurope.myMat") : v("games.parkseurope.otherMat", { name: z(Le.rid) }) }), Le.shutterbug && /* @__PURE__ */ b("span", {
												className: "pke-badge",
												children: v("games.parkseurope.shutterbug")
											})]
										}), /* @__PURE__ */ b(Hi, {
											p: Le,
											t: v,
											name: z(Le.rid)
										}, Le.rid)]
									}),
									/* @__PURE__ */ x("section", {
										className: "pke-panel pke-hand",
										hidden: B !== "hand",
										id: "pke-panel-hand",
										children: [
											/* @__PURE__ */ x("header", {
												className: "pke-section-head",
												children: [/* @__PURE__ */ b("h2", { children: v("games.parkseurope.handTitle") }), /* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: t.length
												})]
											}),
											t.length === 0 ? /* @__PURE__ */ b("p", {
												className: "pke-muted",
												children: v("games.parkseurope.handEmpty")
											}) : /* @__PURE__ */ b("div", {
												className: "pke-hand-row pke-wonder-hand",
												children: t.map((e, t) => {
													let n = je[e], r = R[e];
													return /* @__PURE__ */ b(Jn, {
														id: e,
														campEffect: r && v(Pi[r.effect]),
														waiting: !C,
														canUse: (e) => !n?.[e].pay || Ri(S, n[e].pay),
														onPlay: n ? (t) => U({
															type: "playWonder",
															card: e,
															side: t
														}) : void 0
													}, e + ":" + t);
												})
											}),
											e.soloRanks && /* @__PURE__ */ b("p", {
												className: "pke-solo-ranks",
												children: v("games.parkseurope.soloRankTable")
											})
										]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ b(l, {
					open: T === "trailEnd",
					onClose: () => E(null),
					label: v("games.parkseurope.chooseSlot"),
					title: v("games.parkseurope.chooseSlot"),
					children: /* @__PURE__ */ b(pr, {
						pub: e,
						nameOf: z,
						marker: at,
						actionName: (e) => v(ji[e]),
						onTake: (e, t) => {
							e === "parks" ? U({
								type: "move",
								hiker: st,
								to: 8,
								slot: { kind: e }
							}) : t && U({
								type: "move",
								hiker: st,
								to: 8,
								slot: {
									kind: e,
									action: t
								}
							}), E(null);
						}
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "campfire",
					onClose: () => {
						E(null), O(null);
					},
					label: v("games.parkseurope.occupiedPrompt"),
					title: v("games.parkseurope.occupiedPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-choice-list",
						children: [D && e.campfires.includes(D.to) && /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "move",
									hiker: D.hiker,
									to: D.to,
									campfire: "communal"
								}), E(null), O(null);
							},
							children: v("games.parkseurope.useCommunalCampfire")
						}), D && t.filter((e) => !!R[e]).map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "move",
									hiker: D.hiker,
									to: D.to,
									campfire: "card",
									card: e
								}), E(null), O(null);
							},
							children: [
								v("games.parkseurope.useCampfireCard"),
								" · ",
								Pn(v, e)
							]
						}, e))]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "assignWild",
					onClose: () => E(null),
					label: v("games.parkseurope.assignWildPrompt"),
					title: v("games.parkseurope.assignWildPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-choice-list",
						children: Ce.filter((e) => S.visited.some((t) => t.suit === e)).map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "assignWild",
									suit: e
								}), E(null);
							},
							children: v(Oi[e])
						}, e))
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "freePark",
					onClose: () => E(null),
					label: v("games.parkseurope.freeParkPrompt"),
					title: v("games.parkseurope.freeParkPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-pick-gallery",
						children: [[{
							from: "display",
							ids: e.parksDisplay,
							title: "fieldDisplay"
						}, {
							from: "reserve",
							ids: S.reserved,
							title: "reservedTitle"
						}].filter(({ ids: e }) => e.length > 0).map(({ from: t, ids: n, title: r }) => /* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("h3", { children: v(`games.parkseurope.${r}`) }), /* @__PURE__ */ b("div", {
							className: "pke-pick-grid",
							children: n.map((n, r) => {
								let i = F[n];
								return /* @__PURE__ */ b(Rn, {
									park: i,
									suitLabel: v(Oi[i.suit]),
									effect: i.instant && v(Ni[i.instant]),
									bonus: t === "display" ? e.parksBonus[r] : null,
									picked: !1,
									free: !0,
									onPick: () => {
										U({
											type: "freePark",
											parkId: n,
											from: t
										}), E(null);
									}
								}, n);
							})
						})] }, t)), /* @__PURE__ */ b("button", {
							type: "button",
							className: "pke-btn pke-btn--quiet",
							disabled: !e.parksDeck,
							onClick: () => {
								U({
									type: "freePark",
									from: "deck"
								}), E(null);
							},
							children: v("games.parkseurope.startDeck")
						})]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "discardRes",
					onClose: () => E(null),
					label: v("games.parkseurope.discardResPrompt"),
					title: v("games.parkseurope.discardResPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-choice-list",
						children: xi.filter((e) => S.res[e] > 0).map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								U({
									type: "discardRes",
									res: e
								}), E(null);
							},
							children: [
								/* @__PURE__ */ b(q, {
									kind: e,
									count: S.res[e]
								}),
								" ",
								v(Di[e])
							]
						}, e))
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "discardWonder",
					onClose: () => E(null),
					label: v("games.parkseurope.discardWonderPrompt"),
					title: v("games.parkseurope.discardWonderPrompt"),
					children: /* @__PURE__ */ b("div", {
						className: "pke-pick-grid pke-wonder-picker",
						children: t.map((e) => {
							let t = R[e];
							return /* @__PURE__ */ x("div", {
								className: "pke-pick-object",
								children: [/* @__PURE__ */ b(Jn, {
									id: e,
									campEffect: t && v(Pi[t.effect])
								}), /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									"aria-label": v("games.parkseurope.wonderDiscardName", { name: Pn(v, e) }),
									onClick: () => {
										U({
											type: "discardWonder",
											card: e
										}), E(null);
									},
									children: v("games.parkseurope.wonderDiscard")
								})]
							}, e);
						})
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "scoring",
					onClose: () => {
						E(null), ie(null), ae({ ...Si });
					},
					label: v("games.parkseurope.scoringTitle"),
					title: v("games.parkseurope.scoringTitle"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-scoring-sheet",
						children: [Ct.length === 0 && /* @__PURE__ */ b("p", {
							className: "pke-muted",
							children: v("games.parkseurope.scoringEmpty")
						}), Ct.map((e) => {
							let t = R[e].effect, n = t === "turnAny3" ? 3 : t === "turnAny2" ? 2 : 0, r = k === e;
							return /* @__PURE__ */ x("section", {
								className: "pke-scoring-card",
								"data-on": r,
								children: [/* @__PURE__ */ b(Jn, {
									id: e,
									campEffect: v(Pi[t])
								}), t === "turnWildlife2" ? /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: S.res.wildlife < 2,
									onClick: () => U({
										type: "campfireEnd",
										card: e,
										pay: { wildlife: 2 }
									}),
									children: S.res.wildlife < 2 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
								}) : t === "turnCarabiner" ? /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--main",
									disabled: S.carabiners < 1,
									onClick: () => U({
										type: "campfireEnd",
										card: e,
										carabiner: !0
									}),
									children: S.carabiners < 1 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
								}) : r ? /* @__PURE__ */ x(y, { children: [
									/* @__PURE__ */ b("div", {
										className: "pke-pay-row",
										children: xi.map((e) => /* @__PURE__ */ x("span", {
											className: "pke-pay-res",
											style: { "--pke-res": Li[e] },
											children: [
												/* @__PURE__ */ b(K, { kind: e }),
												/* @__PURE__ */ b("button", {
													type: "button",
													"aria-label": `- ${v(Di[e])}`,
													disabled: A[e] <= 0,
													onClick: () => ae((t) => ({
														...t,
														[e]: t[e] - 1
													})),
													children: "−"
												}),
												/* @__PURE__ */ b("b", {
													className: "font-mono tabular-nums",
													children: A[e]
												}),
												/* @__PURE__ */ b("button", {
													type: "button",
													"aria-label": `+ ${v(Di[e])}`,
													disabled: A[e] >= S.res[e] || wt >= n,
													onClick: () => ae((t) => ({
														...t,
														[e]: t[e] + 1
													})),
													children: "+"
												}),
												/* @__PURE__ */ b("span", {
													className: "pke-sub",
													children: S.res[e]
												})
											]
										}, e))
									}),
									/* @__PURE__ */ x("p", {
										className: "pke-sub",
										children: [
											v("games.parkseurope.scoringPayPrompt", { n }),
											" · ",
											v("games.parkseurope.scoringPayChosen", { n: wt })
										]
									}),
									/* @__PURE__ */ x("div", {
										className: "pke-scoring-actions",
										children: [/* @__PURE__ */ b("button", {
											type: "button",
											className: "pke-btn pke-btn--main",
											disabled: wt !== n,
											onClick: () => {
												U({
													type: "campfireEnd",
													card: e,
													pay: { ...A }
												}), ie(null), ae({ ...Si });
											},
											children: v("games.parkseurope.scoringPayConfirm")
										}), /* @__PURE__ */ b("button", {
											type: "button",
											className: "pke-btn pke-btn--quiet",
											onClick: () => {
												ie(null), ae({ ...Si });
											},
											children: v("games.parkseurope.scoringPayReset")
										})]
									})
								] }) : /* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => {
										ie(e), ae({ ...Si });
									},
									children: v("games.parkseurope.useEffect")
								})]
							}, e);
						})]
					})
				}),
				/* @__PURE__ */ b(l, {
					open: T === "activateCons",
					onClose: () => E(null),
					label: v("games.parkseurope.activateConsPrompt"),
					title: v("games.parkseurope.activateConsPrompt"),
					children: /* @__PURE__ */ x("div", {
						className: "pke-pick-grid",
						children: [xt.length === 0 && /* @__PURE__ */ b("p", {
							className: "pke-muted",
							children: v("games.parkseurope.activateConsEmpty")
						}), xt.map(({ id: e, i: t }) => /* @__PURE__ */ b(Xn, {
							id: e,
							name: v(Fi[e % 7]),
							site: v("games.parkseurope.projectSite", { resource: v(Di[I(e)]) }),
							benefit: v(Mi[De[e % 7].benefit]),
							supported: !0,
							action: {
								label: v("games.parkseurope.useEffect"),
								onPress: () => {
									U({
										type: "activateCons",
										card: t
									}), E(null);
								}
							}
						}, t))]
					})
				})
			]
		}), e.phase !== "ended" && /* @__PURE__ */ b(sr, {
			frame: Pe,
			timing: Fe,
			self: r,
			nameOf: z
		})]
	});
}
function Hi({ p: e, t, name: n }) {
	let [r, i] = s(null), a = Ce.reduce((t, n) => t + e.parkAwards[n], 0) + e.consAwards + e.chaletAwards.length, o = Ce.find((t) => e.parkAwards[t] > 0), c = e.chaletAwards.at(-1), l = [
		[
			"album",
			"photo",
			"fieldAlbum",
			e.photos + e.albums
		],
		[
			"honors",
			"award",
			"fieldHonors",
			a
		],
		[
			"collection",
			"parks",
			"fieldCollection",
			e.visited.length
		],
		[
			"projects",
			"cons",
			"fieldSupported",
			e.cons.length
		]
	];
	return /* @__PURE__ */ x("div", {
		className: "pke-mat-body",
		"aria-label": n,
		children: [
			/* @__PURE__ */ b(zn, { player: e }),
			/* @__PURE__ */ x("div", {
				className: "pke-mug-row",
				"aria-label": t("games.parkseurope.mug.level", { n: e.mug }),
				children: [
					/* @__PURE__ */ b(K, { kind: "mug" }),
					/* @__PURE__ */ b("span", { children: t("games.parkseurope.mug.track") }),
					[
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ b("i", {
						className: "pke-mug-pip",
						"data-on": e.mug >= t,
						"aria-hidden": !0
					}, t))
				]
			}),
			/* @__PURE__ */ b("div", {
				className: "pke-player-objects",
				role: "group",
				"aria-label": t("games.parkseurope.fieldPlayerItems"),
				children: l.map(([e, n, a, s]) => /* @__PURE__ */ x("button", {
					type: "button",
					"data-object": e,
					"data-empty": !s,
					"aria-expanded": r === e,
					"aria-controls": "pke-player-object",
					onClick: () => i(r === e ? null : e),
					children: [/* @__PURE__ */ b("span", {
						className: "pke-object-pose",
						"aria-hidden": !0,
						children: e === "album" ? /* @__PURE__ */ b(Wn, {}) : e === "honors" ? o ? /* @__PURE__ */ b(Hn, { award: {
							kind: "parks",
							suit: o,
							count: 1
						} }) : c === void 0 ? /* @__PURE__ */ b(Hn, { award: {
							kind: "cons",
							count: 1
						} }) : /* @__PURE__ */ b(Hn, { award: {
							kind: "chalet",
							points: c
						} }) : /* @__PURE__ */ b("span", {
							className: "pke-object-stack",
							children: /* @__PURE__ */ b(K, { kind: n })
						})
					}), /* @__PURE__ */ x("span", {
						className: "pke-object-label",
						children: [t(`games.parkseurope.${a}`), s > 0 && /* @__PURE__ */ b("b", { children: s })]
					})]
				}, e))
			}),
			/* @__PURE__ */ x("div", {
				id: "pke-player-object",
				hidden: r === null,
				children: [
					r === "album" && /* @__PURE__ */ x("div", {
						className: "pke-player-album",
						children: [/* @__PURE__ */ x("div", {
							className: "pke-photo-pieces",
							children: [Array.from({ length: e.photos }, (e, t) => /* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(K, { kind: "photo" }) }, "photo" + t)), Array.from({ length: e.albums }, (e, t) => /* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(Wn, {}) }, "album" + t))]
						}), /* @__PURE__ */ x("p", { children: [
							t("games.parkseurope.photos", { n: e.photos }),
							" · ",
							t("games.parkseurope.albums", { n: e.albums })
						] })]
					}),
					r === "honors" && /* @__PURE__ */ b(Un, { player: e }),
					r === "collection" && (e.visited.length ? /* @__PURE__ */ b("div", {
						className: "pke-card-row",
						children: e.visited.map(({ id: e, suit: n }) => {
							let r = F[e];
							return /* @__PURE__ */ b(Rn, {
								park: r,
								suitLabel: t(Oi[n ?? r.suit]),
								picked: !1,
								effect: r.instant ? t(Ni[r.instant]) : void 0
							}, e);
						})
					}) : /* @__PURE__ */ b("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					})),
					r === "projects" && (e.cons.length ? /* @__PURE__ */ b("div", {
						className: "pke-card-row pke-project-row",
						children: e.cons.map((e, n) => /* @__PURE__ */ b(Xn, {
							id: e,
							name: t(Fi[e % 7]),
							site: t("games.parkseurope.projectSite", { resource: t(Di[I(e)]) }),
							benefit: t(Mi[De[e % 7].benefit]),
							supported: !0
						}, e + ":" + n))
					}) : /* @__PURE__ */ b("p", {
						className: "pke-muted",
						children: t("games.parkseurope.fieldNone")
					}))
				]
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var Ui = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], Wi = {
	mountain: 1.1,
	forest: 1,
	sun: .9,
	water: .9,
	wildlife: 1.4
}, Gi = {
	parks: 4.2,
	mug: 2.8,
	photo: 1.4,
	die: 1.6,
	wonder: 1.6,
	wildlife: 1.2,
	carabiner: 1.3
}, Ki = {
	conservation: 2.8,
	mug: 2.8,
	chalet: 1.6,
	carabiner: 1.4
}, qi = {
	wonder: 1.6,
	sunwater: 1.7,
	photo: 1.7,
	conservation: 2.2,
	mug: 2.4,
	wildlife: 1.2
}, Ji = {
	album: 3,
	wonderHand: 2,
	turnAny2: 3,
	turnAny3: 3,
	turnWildlife2: 1,
	turnCarabiner: 2,
	anyIcons: 2,
	consForest: 1.5,
	consMountain: 1.5,
	consSun: 1.5,
	consWater: 1.5,
	iconForest: 1.5,
	iconMountain: 1.5,
	iconSun: 1.5,
	iconWater: 1.5,
	snow: 1
};
function Yi() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Xi(e, t) {
	return t && e.length > 1 && Yi() < .3 ? e[Math.floor(Yi() * e.length)] : e[0];
}
function Zi(e) {
	return e.sort((e, t) => t.score - e.score);
}
function Qi(e, t) {
	return e.players.find((e) => e.rid === t);
}
function $i(e, t) {
	let n = 0;
	for (let r of e.players) for (let e of r.hikers) e === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function ea(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, r = 0;
	for (let e of Object.keys(t)) {
		let i = t[e] ?? 0;
		e === "wildlife" ? r = i : n[e] = i;
	}
	if (e.res.wildlife < r) return !1;
	let i = e.res.wildlife - r, a = 0;
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a += Math.max(0, n[t] - e.res[t]);
	if (i < a) return !1;
	let o = n.mountain + n.forest + n.sun + n.water + r + a;
	return Ui.reduce((t, n) => t + e.res[n], 0) - o >= n.any;
}
function ta(e) {
	let t = 0;
	for (let n of Object.keys(e)) {
		let r = e[n] ?? 0;
		t += n === "any" ? r * 1 : n === "wildlife" ? r * 1.3 : r * Wi[n];
	}
	return t;
}
function na(e) {
	return e ? e === "photo" ? 1.2 : e === "carabiner" ? 1.3 : e === "snow" ? .7 : Wi[e] : 0;
}
function ra(e, t) {
	return t === null ? null : e.vf[t - 1] ?? null;
}
function ia(e, t) {
	let n = e.visited.filter((e) => e.suit === t).length;
	return n % 3 == 2 ? 2.2 : n % 3 == 1 ? .4 : 0;
}
function aa(e, t) {
	let n = F[t];
	if (!n) return 0;
	let r = n.points;
	if (n.instant) {
		let t = n.instant;
		r += t === "photo" ? e.shutterbug ? 2 : 1 : t === "mug" ? 2.2 : t === "wonder" ? 1.3 : t === "chalet" || t === "die" ? 1.2 : t === "carabiner" ? 1 : t === "wildlife" ? .8 : .6;
	}
	if (n.suit === "wild") {
		let t = Ce.reduce((t, n) => Math.max(t, ia(e, n)), 0);
		r += t;
	} else r += ia(e, n.suit);
	return r;
}
function oa(e, t, n) {
	switch (e) {
		case "core-forest": return Wi.forest;
		case "core-sun": return Wi.sun * 2;
		case "core-mountain": return Wi.mountain + .7;
		case "core-water": return Wi.water * 2 + .7;
		case "wildlife": return Wi.wildlife;
		case "carabiner": return 1.6;
		case "parks": return 4.2;
		case "die": return 1.7;
		case "photo": return t.shutterbug ? 2.4 : 1.4;
		case "mug": return t.mug >= 3 ? 3.4 : 2.6;
		case "chalet": return .6 + t.snow * 1;
		case "wonder": return 1.6;
		case "conservation": {
			let e = [...new Set(t.cons.map((e) => I(e)))];
			return 2.6 + (n.consAwardsLeft > 0 && e.length < 4 ? .7 : 0);
		}
	}
}
function sa(e) {
	return e.filter((e) => !!je[e]);
}
function ca(e, t, n) {
	let r = je[t];
	if (!r) return null;
	let i = r[n];
	if (i.pay && !ea(e, i.pay)) return null;
	let a = 0;
	for (let t of i.grants) switch (t.t) {
		case "res":
			a += Wi[t.res] * t.n;
			break;
		case "snow":
			a += .7 * t.n;
			break;
		case "carabiner":
			a += 1.3 * t.n;
			break;
		case "photo":
			a += (e.shutterbug ? 1.8 : 1.1) * t.n;
			break;
		case "wonder":
			a += 1.5 * t.n;
			break;
		case "die":
			a += 1.6 * t.n;
			break;
		case "parks":
			a += 4.2;
			break;
		case "mug":
			a += 2.6;
			break;
		case "cons":
			a += 2.6;
			break;
		case "chalet":
			a += .6 + e.snow;
			break;
		case "shutterbug": a += e.shutterbug ? .8 : 2.4;
	}
	return a - (i.pay ? ta(i.pay) : 0);
}
function la(e, t) {
	let n = Ki[e];
	return t ? n + 4.2 : n;
}
function ua(e) {
	let t = [];
	for (let n of e.endSlots) n.rid === null && t.push({
		v: {
			kind: n.kind,
			action: n.action
		},
		score: la(n.action, n.kind === "both")
	});
	return t.push({
		v: { kind: "parks" },
		score: 4.2
	}), Zi(t), t[0].v;
}
function da(e, t, n) {
	let r = [], i = new Set(e.cons.map((e) => I(e)));
	return t.consDisplay.forEach((t, a) => {
		let o = I(t), s = n ? {} : Ee[o];
		if (!n && !ea(e, s)) return;
		let c = Gi[fa(t)];
		i.has(o) || (c += 1.6), c -= ta(s) * .2, r.push({
			v: {
				type: "consPick",
				index: a
			},
			score: c
		});
	}), r.length > 0 ? (Zi(r), r[0].v) : t.consDeck > 0 && (n || ea(e, {
		sun: 1,
		water: 1
	})) ? {
		type: "consPick",
		deck: !0
	} : { type: "skip" };
}
function fa(e) {
	return [
		"die",
		"parks",
		"mug",
		"wonder",
		"photo",
		"wildlife",
		"carabiner"
	][e % 7];
}
function pa(e, t) {
	let n = [];
	for (let r of t.parksDisplay) n.push({
		v: {
			type: "freePark",
			parkId: r,
			from: "display"
		},
		score: aa(e, r)
	});
	for (let t of e.reserved) n.push({
		v: {
			type: "freePark",
			parkId: t,
			from: "reserve"
		},
		score: aa(e, t)
	});
	return n.length > 0 ? (Zi(n), n[0].v) : {
		type: "freePark",
		from: "deck"
	};
}
function ma(e, t, n, r) {
	let i = [];
	for (let r of [0, 1]) {
		let a = t.hikers[r];
		if (!(a >= 8)) for (let o = a + 1; o <= 7; o++) {
			let a = $i(e, o) > 0, s = null, c;
			if (a) {
				if (e.campfires.includes(o)) s = "communal";
				else {
					let e = n.filter((e) => !!R[e]);
					if (e.length === 0) continue;
					s = "card", c = e[0];
				}
			}
			let l = oa(e.trailSites[o - 1], t, e);
			l += na(e.trailBonus[o - 1]), o === 4 && (l += 1);
			let u = ra(e, o);
			u && t.carabiners > 0 && (l += qi[u] + .7 - 1.2), s === "communal" ? l -= 2 : s === "card" && (l -= 2.5);
			let d = {
				type: "move",
				hiker: r,
				to: o
			};
			s && (d.campfire = s), c && (d.card = c), i.push({
				v: d,
				score: l
			});
		}
	}
	return i.length > 0 ? Xi(Zi(i).map((e) => e.v), r) : {
		type: "move",
		hiker: [0, 1].find((e) => t.hikers[e] < 8) ?? 0,
		to: 8,
		slot: ua(e)
	};
}
function ha(e) {
	return {
		type: "discardRes",
		res: [...Ui].sort((t, n) => e.res[n] - e.res[t])[0]
	};
}
function ga(e, t) {
	let n = [
		"sun",
		"water",
		"forest",
		"mountain",
		"wildlife"
	], r = {}, i = t;
	for (let t of n) {
		let n = Math.min(i, e.res[t]);
		if (n > 0 && (r[t] = n, i -= n), i === 0) return r;
	}
	return null;
}
function _a(e, t, n) {
	let r = new Set(e.campfireUsed), i = n.filter((e) => !!R[e] && !r.has(e)), a = (e) => R[e].effect;
	for (let e of i) if (a(e) === "turnWildlife2" && t.res.wildlife >= 2) return {
		type: "campfireEnd",
		card: e,
		pay: { wildlife: 2 }
	};
	for (let e of i) if (a(e) === "turnCarabiner" && t.carabiners >= 1) return {
		type: "campfireEnd",
		card: e,
		carabiner: !0
	};
	for (let e of i) {
		if (a(e) !== "turnAny3") continue;
		let n = ga(t, 3);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	for (let e of i) {
		if (a(e) !== "turnAny2") continue;
		let n = ga(t, 2);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	return { type: "scoringDone" };
}
function va(e, t) {
	let n = t.filter((e) => !!je[e]);
	if (n.length > 0) {
		let t = n[0], r = Infinity;
		for (let i of n) {
			let n = ca(e, i, "top") ?? -Infinity, a = ca(e, i, "bottom") ?? -Infinity, o = Math.max(n, a);
			o < r && (r = o, t = i);
		}
		return {
			type: "discardWonder",
			card: t
		};
	}
	return {
		type: "discardWonder",
		card: t.filter((e) => !!R[e]).sort((e, t) => (Ji[R[e].effect] ?? 0) - (Ji[R[t].effect] ?? 0))[0] ?? t[0]
	};
}
var ya = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.turn !== t.rid) return null;
	let i = Qi(n, t.rid);
	if (!i) return null;
	let a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "scoring") return { action: _a(n, i, o) };
	if (n.phase !== "turn") return null;
	if (n.pending === "gretaColor") return { action: {
		type: "gretaColor",
		first: a && Yi() < .5 ? 1 : 0
	} };
	let s = t.memory ?? {};
	if (n.pending === "move") return {
		action: ma(n, i, o, a),
		memory: {}
	};
	if (n.pending === "trailEnd") return {
		action: {
			type: "move",
			hiker: [0, 1].find((e) => i.hikers[e] < 8) ?? 0,
			to: 8,
			slot: ua(n)
		},
		memory: {}
	};
	if (n.pending === "parks") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let r of n.parksDisplay) {
			if (t.has(r)) continue;
			t.add(r);
			let n = F[r];
			n && ea(i, n.cost) && e.push({
				v: r,
				score: aa(i, r)
			});
		}
		for (let n of i.reserved) {
			if (t.has(n)) continue;
			t.add(n);
			let r = F[n];
			r && ea(i, r.cost) && e.push({
				v: n,
				score: aa(i, n)
			});
		}
		if (e.length > 0) return Zi(e), {
			action: {
				type: "visit",
				parkId: Xi(e, a).v
			},
			memory: { parks: !0 }
		};
		if (s.parks) return {
			action: { type: "parksDone" },
			memory: {}
		};
		let r = [];
		return n.parksDisplay.forEach((e, t) => r.push({
			index: t,
			score: aa(i, e)
		})), r.length > 0 ? (r.sort((e, t) => t.score - e.score), {
			action: {
				type: "reserve",
				from: "display",
				index: r[0].index
			},
			memory: {}
		}) : n.parksDeck > 0 ? {
			action: {
				type: "reserve",
				from: "deck"
			},
			memory: {}
		} : {
			action: { type: "parksDone" },
			memory: {}
		};
	}
	if (n.pending === "mug") return i.mug >= 3 ? {
		action: {
			type: "mug",
			act: "drink"
		},
		memory: s
	} : {
		action: {
			type: "mug",
			act: "fill"
		},
		memory: s
	};
	if (n.pending === "mugChoice") return {
		action: {
			type: "mugChoice",
			choice: .6 + i.snow + (i.chaletPos < 15 ? .4 : 0) >= 2.6 ? "chalet" : "cons"
		},
		memory: s
	};
	if (n.pending === "cons") return {
		action: da(i, n, n.freeCons),
		memory: s
	};
	if (n.pending === "assignWild") {
		let e = [];
		for (let t of Ce) {
			let n = i.visited.filter((e) => e.suit === t).length;
			n !== 0 && e.push({
				suit: t,
				score: ia(i, t) * 2 + n * .1
			});
		}
		return e.sort((e, t) => t.score - e.score), {
			action: {
				type: "assignWild",
				suit: e[0].suit
			},
			memory: s
		};
	}
	if (n.pending === "freePark") return {
		action: pa(i, n),
		memory: s
	};
	if (n.pending === "discardRes") return {
		action: ha(i),
		memory: s
	};
	if (n.pending === "discardWonder") return {
		action: va(i, o),
		memory: s
	};
	if (n.pending === "actions") {
		if (n.end && !n.end.topDone && n.end.action) return {
			action: { type: "endTop" },
			memory: s
		};
		if (n.end && !n.end.parksDone) return {
			action: { type: "endParks" },
			memory: s
		};
		let e = n.landingSite === null ? null : n.trailSites[n.landingSite - 1];
		if (!n.siteDone && e) return {
			action: { type: "siteAction" },
			memory: s
		};
		let t = e ? Ie(e) : null;
		if (t) {
			let e = i.cons.findIndex((e, r) => I(e) === t && !n.consUsed.includes(r));
			if (e >= 0) return {
				action: {
					type: "activateCons",
					card: e
				},
				memory: s
			};
		}
		let r = ra(n, n.landingSite);
		if (r && !n.vfUsed && i.carabiners > 0 && qi[r] + .7 > 1.2) return {
			action: { type: "viaFerrata" },
			memory: s
		};
		let a = [];
		for (let e of sa(o)) for (let t of ["top", "bottom"]) {
			let n = ca(i, e, t);
			n !== null && a.push({
				v: {
					type: "playWonder",
					card: e,
					side: t
				},
				score: n
			});
		}
		let c = Zi(a)[0];
		return c && c.score > .8 ? {
			action: c.v,
			memory: s
		} : {
			action: { type: "endTurn" },
			memory: {}
		};
	}
	return null;
}, ba = [
	{
		key: "parks",
		label: "games.parkseurope.visitedTitle"
	},
	{
		key: "campfire",
		label: "games.parkseurope.wonder.campfireCard"
	},
	{
		key: "endgame",
		label: "games.parkseurope.scoringTitle"
	},
	{
		key: "photos",
		label: "games.parkseurope.token.photo"
	},
	{
		key: "parkAwards",
		label: "games.parkseurope.resultParkAwards"
	},
	{
		key: "cons",
		label: "games.parkseurope.consTitle"
	},
	{
		key: "chalet",
		label: "games.parkseurope.fieldChalet"
	},
	{
		key: "photoAward",
		label: "games.parkseurope.resultPhotoAward"
	}
], xa = [
	"games.parkseurope.rank.none",
	"games.parkseurope.rank.r1",
	"games.parkseurope.rank.r2",
	"games.parkseurope.rank.r3",
	"games.parkseurope.rank.r4",
	"games.parkseurope.rank.r5"
];
function Sa({ public: e, result: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o }) {
	let l = u(), d = e, [f, p] = s(!0), m = (e) => d.finalRows?.find((t) => t.rid === e)?.total ?? t.scores?.[e], g = (e) => n.find((t) => t.rid === e), _ = (e) => h[(g(e)?.colorIndex ?? Math.max(0, d.order.indexOf(e))) % h.length], v = (e) => g(e)?.name || l(_(e).nameKey), y = d.soloRanks && m(r) !== void 0 ? d.soloRanks.reduce((e, t) => (m(r) ?? 0) >= t.at ? Math.max(e, t.rank) : e, 0) : null;
	return /* @__PURE__ */ x("div", {
		className: "pke-recap-root pke-screen",
		children: [
			/* @__PURE__ */ b("div", {
				className: "pke-recap-scene",
				inert: f,
				children: /* @__PURE__ */ b(Bi, {
					public: d,
					members: n,
					myRid: r,
					send: () => {}
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "pke-recap-overlay",
				hidden: !f,
				children: /* @__PURE__ */ x("section", {
					className: "pke-recap",
					"aria-label": l("games.parkseurope.journeyEnd"),
					children: [
						/* @__PURE__ */ x("header", {
							className: "pke-recap-header",
							children: [
								/* @__PURE__ */ b(K, { kind: "mountain" }),
								/* @__PURE__ */ b("h1", { children: l("games.parkseurope.journeyEnd") }),
								y !== null && /* @__PURE__ */ b("strong", { children: l(xa[y] ?? xa[0]) }),
								/* @__PURE__ */ b("button", {
									type: "button",
									className: "pke-btn pke-btn--quiet",
									onClick: () => p(!1),
									children: l("games.parkseurope.reviewTable")
								})
							]
						}),
						/* @__PURE__ */ x("div", {
							className: "pke-score-scroll",
							children: [
								/* @__PURE__ */ b("div", {
									className: "pke-recap-roster",
									children: t.ranking.map((e) => {
										let n = d.players.find((t) => t.rid === e), r = d.finalRows?.find((t) => t.rid === e);
										return /* @__PURE__ */ x("article", {
											className: "pke-recap-seat",
											"data-winner": t.winner.includes(e),
											style: { "--pke-seat": _(e).hex },
											children: [/* @__PURE__ */ x("div", {
												className: "pke-recap-identity",
												children: [
													/* @__PURE__ */ b("img", {
														src: c[(g(e)?.avatar ?? 0) % c.length],
														alt: ""
													}),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("strong", { children: v(e) }), t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ b("small", { children: l("games.parkseurope.journeyWinner") })] }),
													/* @__PURE__ */ b("b", { children: m(e) ?? "—" })
												]
											}), n && /* @__PURE__ */ x("div", {
												className: "pke-recap-awards",
												children: [
													Ce.filter((e) => n.parkAwards[e]).map((e) => /* @__PURE__ */ b(Hn, { award: {
														kind: "parks",
														suit: e,
														count: n.parkAwards[e]
													} }, e)),
													n.consAwards > 0 && /* @__PURE__ */ b(Hn, { award: {
														kind: "cons",
														count: n.consAwards
													} }),
													n.chaletAwards.map((e, t) => /* @__PURE__ */ b(Hn, { award: {
														kind: "chalet",
														points: e
													} }, t)),
													(r?.photoAward ?? 0) > 0 && /* @__PURE__ */ b(Hn, { award: { kind: "photo" } })
												]
											})]
										}, e);
									})
								}),
								/* @__PURE__ */ x("table", {
									className: "pke-score-table",
									children: [
										/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "col",
											children: l("games.parkseurope.scoreItem")
										}), t.ranking.map((e) => /* @__PURE__ */ b("th", {
											scope: "col",
											"data-winner": t.winner.includes(e),
											children: /* @__PURE__ */ x("span", {
												className: "pke-score-player",
												style: { "--pke-seat": _(e).hex },
												children: [
													/* @__PURE__ */ b("img", {
														src: c[(g(e)?.avatar ?? 0) % c.length],
														alt: ""
													}),
													/* @__PURE__ */ b("span", { children: v(e) }),
													t.winner.includes(e) && t.ranking.length > 1 && /* @__PURE__ */ b("b", { children: l("games.parkseurope.journeyWinner") })
												]
											})
										}, e))] }) }),
										d.finalRows && /* @__PURE__ */ b("tbody", { children: ba.map(({ key: e, label: n }) => /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: l(n)
										}), t.ranking.map((t) => /* @__PURE__ */ b("td", { children: d.finalRows?.find((e) => e.rid === t)?.[e] ?? "—" }, t))] }, e)) }),
										/* @__PURE__ */ b("tfoot", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: l("games.parkseurope.resultTotal")
										}), t.ranking.map((e) => /* @__PURE__ */ b("td", { children: m(e) ?? "—" }, e))] }) })
									]
								}),
								i !== void 0 && /* @__PURE__ */ b("p", { children: l("session.hint.usedCount", { n: i }) }),
								t.ranking.map((e) => {
									let n = t.autopilot?.[e];
									return n ? /* @__PURE__ */ x("p", { children: [
										v(e),
										" · ",
										l("session.autopilot.share", { n: Math.round(n * 100) })
									] }, e) : null;
								})
							]
						}),
						/* @__PURE__ */ x("footer", {
							className: "pke-recap-actions",
							children: [
								a && /* @__PURE__ */ b(be, {
									compact: !0,
									label: l("session.result.playAgain"),
									confirmLabel: l("games.parkseurope.confirmAgain"),
									onConfirm: a
								}),
								o && /* @__PURE__ */ b(be, {
									compact: !0,
									label: l("session.result.backToLobby"),
									confirmLabel: l("games.parkseurope.confirmLobby"),
									onConfirm: o
								}),
								!a && !o && /* @__PURE__ */ b("span", { children: l("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ b("button", {
				type: "button",
				className: "pke-btn pke-btn--main pke-recap-restore",
				hidden: f,
				onClick: () => p(!0),
				children: l("games.parkseurope.returnScores")
			})
		]
	});
}
//#endregion
//#region src/game/game-over-row.tsx
var Ca = {
	1: "games.parkseurope.rank.r1",
	2: "games.parkseurope.rank.r2",
	3: "games.parkseurope.rank.r3",
	4: "games.parkseurope.rank.r4",
	5: "games.parkseurope.rank.r5"
};
function wa({ public: e, rid: t }) {
	let n = u(), r = e, i = r.finalRows?.find((e) => e.rid === t);
	if (!i) return null;
	let a = [
		{
			key: "games.parkseurope.over.parks",
			n: i.parks
		},
		{
			key: "games.parkseurope.over.campfire",
			n: i.campfire
		},
		{
			key: "games.parkseurope.over.endgame",
			n: i.endgame
		},
		{
			key: "games.parkseurope.over.photos",
			n: i.photos
		},
		{
			key: "games.parkseurope.over.parkAwards",
			n: i.parkAwards
		},
		{
			key: "games.parkseurope.over.cons",
			n: i.cons
		},
		{
			key: "games.parkseurope.over.chalet",
			n: i.chalet
		},
		{
			key: "games.parkseurope.over.photoAward",
			n: i.photoAward
		}
	], o = null;
	if (r.soloRanks) {
		let e = 0;
		for (let t of r.soloRanks) i.total >= t.at && (e = Math.max(e, t.rank));
		o = n(Ca[e] ?? "games.parkseurope.rank.none");
	}
	return /* @__PURE__ */ x("div", {
		className: "mt-1.5 flex flex-wrap gap-1",
		children: [
			a.map(({ key: e, n: t }) => /* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-paper px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums",
				children: n(e, { n: t })
			}, e)),
			/* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-done-soft px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-done-ink",
				children: n("games.parkseurope.over.total", { n: i.total })
			}),
			o && /* @__PURE__ */ b("span", {
				className: "rounded border border-ink/30 bg-info-soft px-1.5 py-0.5 text-[10px] font-bold text-info-ink",
				children: n("games.parkseurope.over.rank", { name: o })
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Ta({ value: e, onChange: t }) {
	let n = u(), r = tt.safeParse(e), i = r.success ? r.data : tt.parse(void 0);
	return /* @__PURE__ */ b(Se, {
		title: n("games.parkseurope.name"),
		children: /* @__PURE__ */ b(xe, {
			name: "parkseurope-greta",
			value: "greta",
			checked: i.greta,
			label: n("games.parkseurope.opt.greta"),
			hint: n("games.parkseurope.opt.gretaHint"),
			accent: Ue.accent,
			onChange: () => t({
				...i,
				greta: !i.greta
			})
		})
	});
}
//#endregion
//#region src/index.tsx
var Ea = {
	definition: An,
	View: Bi,
	bot: ya,
	OverView: Sa,
	RowView: wa,
	Options: Ta,
	locales: {
		zh: {
			name: "Parks Europe",
			parkNames: {
				p0: "湖区",
				p1: "欧洲之峰",
				p2: "瓦特纳冰川",
				p3: "卡朗克",
				p4: "萨马里亚",
				p5: "里拉",
				p6: "尤通黑门",
				p7: "五渔村",
				p8: "塔特拉",
				p9: "瑞士国家公园",
				p10: "洛蒙德湖与特罗萨克斯",
				p11: "约斯特达尔冰川",
				p12: "康尼马拉",
				p13: "哈当厄尔高原",
				p14: "泰斯",
				p15: "特里格拉夫",
				p16: "贝希特斯加登",
				p17: "雷泰扎特",
				p18: "阿布鲁佐、拉齐奥与莫利塞",
				p19: "拉马达莱娜群岛",
				p20: "格雷梅",
				p21: "比利牛斯",
				p22: "萨雷克",
				p23: "蒂曼法亚",
				p24: "贝卢诺多洛米蒂",
				p25: "高陶恩",
				p26: "辛格韦德利",
				p27: "瓦登海",
				p28: "皮林",
				p29: "奥兰卡",
				p30: "基拉尼",
				p31: "杜米托尔",
				p32: "高亚",
				p33: "多尼亚纳",
				p34: "埃克兰",
				p35: "维科斯—阿奥斯",
				p36: "奥林匹斯山",
				p37: "奥尔德萨与佩尔迪多山",
				p38: "十六湖",
				p39: "泰德",
				p40: "佩内达—热尔",
				p41: "格泽瑟",
				p42: "克尔卡",
				p43: "阿比斯库",
				p44: "萨克森瑞士",
				p45: "布特林特",
				p46: "凯恩戈姆山",
				p47: "峰区"
			},
			wonderNames: {
				b01: "野趣之旅",
				b02: "细品日出",
				b03: "沐浴晨光",
				b04: "尽享森林",
				b05: "林中漫步",
				b06: "骑游山野",
				b07: "探访荒野",
				b08: "晴空畅怀",
				b09: "守护群峰",
				b10: "回望旅途",
				b11: "步道奇遇",
				b12: "畅游清水",
				b13: "涉过山溪",
				b14: "扣紧攀登",
				b16: "定格此刻",
				b17: "随心漫游",
				b18: "登山而上",
				b19: "攀上顶峰",
				b20: "守护林木",
				b21: "清理河岸"
			},
			campfireCardName: "营火卡 {{n}}",
			selectedHiker: "已选",
			desc: "用三个赛季走遍欧洲的国家公园，收集资源、留宿小屋、拍摄照片并支持保护工程，终局比拼得分",
			rules: "目标:\n每名玩家率领两名旅人，在欧洲的国家公园步道上徒步三个赛季。沿途收集资源与照片、访问国家公园、完成保护工程，并在终局结算中获得最高总分的玩家获胜。\n准备:\n· 每名玩家取一块板面，把两枚旅人放在步道起点，把马克杯标记放在马克杯轨道最下方，并取得一枚登山扣。\n· 将所有玩家的小屋标记随机叠放在小屋赛道的起点。\n· 每名玩家从奇迹牌堆抽取一张奇迹卡，作为手牌的开始。\n· 洗混公园卡与保护卡，各翻开三张组成展示区。按人数准备公共营火：三人及以下使用一枚，四人使用两枚，五人使用三枚。\n· 每个赛季开始时翻开一张赛季卡，按卡面把公共营火与赛季奖励资源放到对应站点。小屋标记最靠前的玩家先手，同格时叠在最上面的玩家先手。\n回合:\n每名玩家轮流行动，直到所有旅人都抵达步道终点，该赛季结束。三个赛季结束后进行终局结算。\n· 行动时，选择一名尚未抵达终点的旅人，把它向前移动到任意一个更靠后的站点，并获得该站点的行动与赛季奖励资源。旅人不能后退，也不能跳过自己的回合。\n· 站点上已有其他旅人时不能直接停留，除非使用点上的公共营火，或弃掉手中一张营火奇迹卡。\n· 你可以放弃站点的主要行动，仍可进行铁索攀登、打出奇迹卡或激活保护卡。\n· 抵达站点后，你可以按任意顺序执行站点的主要行动、进行铁索攀登、打出任意张奇迹卡和激活保护卡。\n· 回合结束时，手牌上限为三张奇迹卡，登山扣上限为三枚；资源区容量为十二格，每枚雪占用两格，超出的非雪资源必须弃回供应区。\n营地与营火:\n· 公共营火每个赛季开始时按人数放置，使用后回到供应区，该赛季不再补充。\n· 营火奇迹卡在终局计分时仍留在手中结算，也可以在此之前弃掉用来占据已有旅人的站点。\n步道站点:\n· 四块核心站点分别提供森林、太阳、山峰与水域资源；山峰与水域站点同时提供一枚雪。\n· 进阶站点提供野生动物、登山扣、公园行动、掷步道骰、拍照、马克杯行动、小屋行动、奇迹卡与保护工程。\n· 中央站点固定印有快门虫图标，旅人抵达时立即取得快门虫。\n步道终点:\n· 终点分为区域：第一排是四种单独行动，每个位置只能容纳一名旅人；中间是公园行动，可以容纳任意多旅人；第二排同时提供上方行动与公园行动，每个位置只能容纳一名旅人。\n· 落在第二排时必须完成上方行动与公园行动，两者的先后顺序由你决定。\n· 终点不能使用营火共享位置。两名旅人都抵达终点后，该玩家的徒步到此结束。\n· 若轮到你行动时其他旅人都已离开步道，你必须立即前往终点，并照常选择终点位置。\n铁索攀登\n· 除中央站点外，每个站点上方都有一块铁索攀登板块。抵达站点后，你可以上交一枚登山扣，领取该板块的奖励，并额外获得一枚雪。\n· 你每回合可以进行一次铁索攀登，时机可选在站点主要行动之前或之后。\n国家公园:\n· 公园行动可以选择预留，或访问任意多张公园卡。预留时从展示区取一张，或直接抽取牌堆顶一张，放在自己的预留区。\n· 访问时支付公园卡上标注的资源。野生动物可以代替任意一种普通资源；带有「任意」图标的费用可以用任何资源支付。\n· 公园卡按花色叠放在板面右侧。每叠满三张同花色公园，立即取得该花色的公园奖章与印刷的即时奖励；奖章在终局按该花色公园数量计分。\n· 野性公园不属于四种花色。取得时把它并入任意一个已有花色的公园叠；若尚未拥有任何花色，则并入下一张取得的有色公园。\n· 展示区取走或弃掉卡牌后不会立即补入；到回合结束时再从牌库补满，已有卡牌先向右滑动，新卡从左侧补入，最右侧始终是最老的卡牌。\n步道骰与快门虫:\n· 步道骰的六个面分别提供登山扣、野生动物、山与水、抽奇迹卡、拍照、太阳与森林。\n· 持有快门虫时，你回合中的每次拍照行动额外获得一张照片；快门虫可以由旅人抵达中央站点或由部分卡牌获得。\n照片:\n· 每张照片在终局计一分。集满五张照片时换成一本相册，相册在终局计五分。\n· 终局时拍摄照片总数最多的玩家额外获得照片奖章，价值三分；平局时小屋赛道更靠前的玩家获胜。单人模式不使用照片奖章。\n马克杯:\n· 马克杯行动可以填充或饮用。填充时把标记向上移动一格，最多到达顶端；饮用时结算标记所在档位的奖励，并把标记移回最下方。\n· 第一档可以选择执行一次小屋行动，或免费支持一张保护工程。\n· 第二档掷三次步道骰并获得全部结果。\n· 第三档免费访问一张公园，来源可以是展示区、预留区或牌堆顶。\n保护工程:\n· 保护行动可以选择支持一张展示区中的保护卡，或支付一枚太阳与一枚水，从牌堆顶取得一张。\n· 取得保护卡后，只能在对应颜色的核心站点激活它的效果。每回合每张保护卡可以激活一次，多张保护卡的激活顺序自定，也可以安排在站点主要行动之前或之后。\n· 若在当前站点取得颜色相同的保护卡，可以立即激活这一张。\n· 集齐四种颜色的保护卡时取得一枚保护奖章，价值五分。\n小屋:\n· 小屋行动上交自己板面上的全部雪，沿小屋赛道前进与雪数量相同的雪格。\n· 经过奇迹格时抽取一张奇迹卡；经过奖章格时取得该位置最有价值的一枚奖章，奖章堆为空时改为抽取一张奇迹卡。\n· 小屋令牌停止在已有令牌的格子上时叠放在最上方。赛道走到尽头后仍可上交雪，但不再前进。\n· 小屋赛道在终局计分中用于打破平局，越靠前越优先，同格时叠在上方者优先。\n奇迹卡:\n· 基础奇迹卡有上下两种即时行动，支付卡面左侧的资源后获得右侧的奖励。\n· 营火奇迹卡可以弃掉来占据已有旅人的站点；终局计分时按效果获得分数，部分卡牌还可以上交资源换取分数。\n赛季与终局:\n· 赛季开始时重新铺设步道，把新的三块进阶站点与四块核心站点洗混后放到七个位置，并放置新的公共营火与赛季奖励。\n· 三个赛季结束后先进入终局结算：每名玩家可以自行决定是否用手中的营火奇迹卡上交资源换取分数，也可以放弃。\n· 营火效果与资源结算完成后，依次计算到访公园、营火奇迹卡的固定效果、照片与相册、公园奖章、保护奖章与小屋奖章；照片奖章在全部营火效果之后才计算。\n· 公园奖章每枚按同花色到访公园的数量计分，保护奖章与相册各计五分，照片按张计分，小屋奖章按其面值计分（3、4 或 5 分）。总分最高的玩家获胜。\n护林员格蕾塔:\n· 单人模式与双人挑战中，护林员格蕾塔会加入徒步。她始终最后行动，按步道骰结果移动自己的旅人。\n· 蝴蝶面移动队伍中靠后的旅人，花朵面移动靠前的旅人；点数表示可以前进到的第几个可用站点。\n· 点上有公共营火时格蕾塔视为可以停留，并会消耗该营火；她的旅人抵达终点时，弃掉展示区最右侧的公园卡与保护卡。\n· 单人模式中格蕾塔控制两组旅人；每次她行动前，由你选择先移动哪一组。你取得小屋奖章时可以额外抽取一张奇迹卡；照片奖章不参与结算，终局按得分对照评级表。",
			season: {
				cliffs: "悬崖之季",
				swimming: "游泳之季",
				memories: "回忆之季",
				sun: "阳光之季",
				dreams: "梦想之季",
				joy: "欢乐之季",
				scouting: "探索之季",
				growth: "生长之季",
				climbing: "攀登之季",
				caves: "洞穴之季",
				meadows: "草甸之季",
				ice: "冰雪之季"
			},
			res: {
				mountain: "山峰",
				forest: "森林",
				sun: "太阳",
				water: "水域",
				wildlife: "野生动物",
				snow: "雪",
				any: "任意资源"
			},
			suit: {
				lime: "青柠",
				orange: "橙",
				teal: "青绿",
				purple: "紫",
				wild: "野性"
			},
			site: {
				"core-forest": "森林：获得 1 枚森林",
				"core-sun": "太阳：获得 2 枚太阳",
				"core-mountain": "山峰：获得 1 枚山峰与 1 枚雪",
				"core-water": "水域：获得 2 枚水域与 1 枚雪",
				wildlife: "野生动物：获得 1 枚野生动物",
				carabiner: "登山扣：获得 1 枚登山扣",
				parks: "公园行动",
				die: "掷步道骰",
				photo: "拍一张照片",
				mug: "马克杯行动",
				chalet: "小屋行动",
				wonder: "抽一张奇迹卡",
				conservation: "保护工程"
			},
			siteShort: {
				"core-forest": "森林",
				"core-sun": "太阳",
				"core-mountain": "山峰",
				"core-water": "水域",
				wildlife: "野生动物",
				carabiner: "登山扣",
				parks: "公园",
				die: "掷步道骰",
				photo: "拍照",
				mug: "马克杯",
				chalet: "小屋",
				wonder: "奇迹卡",
				conservation: "保护工程"
			},
			vf: {
				wonder: "抽一张奇迹卡",
				sunwater: "获得 1 枚太阳与 1 枚水域",
				photo: "拍一张照片",
				conservation: "保护工程",
				mug: "马克杯行动",
				wildlife: "获得 1 枚野生动物"
			},
			vfShort: {
				wonder: "奇迹卡",
				sunwater: "太阳与水域",
				photo: "拍照",
				conservation: "保护工程",
				mug: "马克杯",
				wildlife: "野生动物"
			},
			top: {
				conservation: "保护工程",
				carabiner: "获得登山扣",
				mug: "马克杯行动",
				chalet: "小屋行动"
			},
			benefit: {
				die: "掷步道骰",
				parks: "公园行动",
				mug: "马克杯行动",
				wonder: "抽一张奇迹卡",
				photo: "拍一张照片",
				wildlife: "获得野生动物",
				carabiner: "获得登山扣"
			},
			token: {
				photo: "照片",
				carabiner: "登山扣"
			},
			consProject: {
				p0: "生物多样性修复",
				p1: "野外研究",
				p2: "遗产地修复",
				p3: "减少光污染",
				p4: "自然摄影",
				p5: "物种保护",
				p6: "步道维护"
			},
			campfire: {
				consForest: "每张森林色保护卡计 1 分",
				consMountain: "每张山峰色保护卡计 1 分",
				consSun: "每张太阳色保护卡计 1 分",
				consWater: "每张水域色保护卡计 1 分",
				iconForest: "到访公园每 3 个森林图标计 1 分",
				iconMountain: "到访公园每 3 个山峰图标计 1 分",
				iconSun: "到访公园每 3 个太阳图标计 1 分",
				iconWater: "到访公园每 3 个水域图标计 1 分",
				anyIcons: "到访公园每 2 个任意资源图标计 1 分",
				album: "每本相册计 1 分",
				wonderHand: "手牌中每张奇迹卡计 1 分，包含本卡",
				snow: "板面上每枚雪计 1 分",
				turnWildlife2: "上交 2 枚野生动物，获得 4 分",
				turnAny2: "上交任意 2 点资源，获得快门虫并拍摄 2 张照片",
				turnCarabiner: "上交 1 枚登山扣，获得 2 分",
				turnAny3: "上交任意 3 点资源，获得 3 分"
			},
			rank: {
				none: "未达评级",
				r1: "一日徒步者",
				r2: "远行者",
				r3: "探险家",
				r4: "冒险家",
				r5: "开拓者"
			},
			opt: {
				greta: "邀请护林员格蕾塔",
				gretaHint: "仅双人局可用；单人局中格蕾塔自动加入。"
			},
			seasonLabel: "第 {{n}} 季",
			seasonCard: "赛季卡：{{name}}",
			myTurn: "轮到你行动",
			waitingFor: "等 {{name}} 行动…",
			pending: {
				move: "移动一名旅人",
				trailEnd: "其他旅人都已抵达终点，直接前往步道终点",
				actions: "可以继续行动，或结束回合",
				parks: "预留或访问公园",
				mug: "填充或饮用马克杯",
				mugChoice: "选择马克杯奖励",
				cons: "支持一张保护工程",
				consFree: "免费支持一张保护工程",
				assignWild: "为野性公园选择花色",
				freePark: "免费访问一张公园",
				discardRes: "弃掉一张多余资源",
				discardWonder: "弃掉一张多余的奇迹卡",
				gretaColor: "选择格蕾塔先移动哪一组旅人",
				scoring: "终局结算",
				none: "对局结束"
			},
			trail: "步道",
			trailEnd: "步道终点",
			trailStart: "起点",
			parksTitle: "国家公园",
			consTitle: "保护工程",
			chaletTrack: "小屋赛道",
			myMat: "我的板面",
			handTitle: "我的奇迹卡",
			fieldParks: "公园",
			fieldProjects: "工程",
			fieldChalet: "小屋",
			awardParkDetail: "获得时：{{benefit}}。终局：每张同花色公园得 1 分。",
			awardFixedDetail: "终局得 {{n}} 分。",
			wonderDiscard: "弃置",
			wonderDiscardName: "弃置 {{name}}",
			wonderPlay: "使用这一半",
			wonderWait: "等待你的回合",
			wonderShare: "弃置此牌可进入被占用的步道站点。",
			wonderScore: "终局计分",
			fieldAward: "奖章位",
			fieldFinish: "终点",
			fieldSnowSpace: "雪格",
			fieldAwardNext: "先领取 {{n}} 分奖章。",
			fieldAwardStack: "下方依次为 {{scores}} 分。",
			fieldDrawPassing: "经过时抽 1 张奇迹牌。",
			fieldChaletNote: "每交 1 枚雪，前进 1 个雪格。经过奖励格时领取奖励。",
			fieldTrackSpace: "第 {{n}} 格 · {{name}}",
			fieldStartShort: "起",
			fieldEndShort: "终",
			fieldEndActions: "终点行动",
			fieldAction: "行动",
			fieldVacant: "空位",
			fieldChoose: "选择",
			fieldSharedOccupied: "已有旅人",
			fieldSharedSlot: "可共用",
			fieldSeasonNote: "赛季开始时，第 2–7 站各放置 1 枚额外资源。",
			fieldChoosePark: "选公园",
			fieldFinishParks: "结束公园行动",
			fieldVisitedPark: "已到访 {{name}} · +{{n}} 分",
			fieldDisplay: "展示",
			fieldReserved: "预留 {{n}}",
			fieldNoReserved: "暂无预留公园",
			fieldTrailSeason: "步道与赛季",
			fieldTrailRoute: "沿途站点",
			fieldSeasonTab: "赛季卡",
			fieldStop: "站点",
			fieldExtras: "额外机会",
			fieldHikers: "旅人",
			fieldGoTo: "前往{{name}}",
			fieldMoveHere: "前往",
			fieldTrailheadInfo: "每个赛季，两名旅人都从这里出发。",
			fieldTrailEndInfo: "旅人到达后结束本季徒步。选择一个终点行动位，也可以只访问公园。",
			fieldSiteEmpty: "暂无旅人",
			fieldFerrataInfo: "花费 1 枚登山扣，另得 1 枚雪。",
			fieldSeasonReward: "赛季奖励",
			fieldShareInfo: "可用营火与其他旅人共占本站。",
			fieldEndSpaces: "查看终点行动位",
			fieldSiteDetail: {
				"core-forest": "获得 1 枚森林。",
				"core-sun": "获得 2 枚太阳。",
				"core-mountain": "获得 1 枚山峰和 1 枚雪。",
				"core-water": "获得 2 枚水域和 1 枚雪。",
				wildlife: "获得 1 枚野生动物。",
				carabiner: "获得 1 枚登山扣。",
				parks: "预留 1 张公园卡，或支付资源访问公园。",
				die: "掷一次步道骰并领取结果。",
				photo: "拍摄 1 张照片。持有快门虫时额外获得 1 张。",
				mug: "填满一格马克杯，或饮用并领取当前格奖励。",
				chalet: "交出全部雪，每枚雪前进 1 个雪格。经过奖励格时领取奖励。",
				wonder: "抽取 1 张奇迹卡。",
				conservation: "支持展示区的保护工程，或支付 1 枚太阳和 1 枚水域，从牌堆取得一张。"
			},
			fieldResetCamera: "重置全谷视角",
			fieldAlbum: "相册",
			fieldHonors: "荣誉",
			fieldCollection: "公园收藏",
			fieldSupported: "已支持工程",
			fieldNone: "暂无",
			fieldPlayerItems: "玩家物件",
			fieldPack: "背包",
			fieldHand: "手牌",
			fieldPanels: "查看物件",
			closePanel: "关闭面板",
			camera: "步道视角",
			overview: "全谷",
			follow: "跟随",
			valleyUnavailable: "打开「步道」选择站点。",
			packSlots: "资源槽",
			packUsage: "{{used}} / 12 格",
			fieldResourceCount: "持有 {{n}} 枚",
			fieldResourceSlots: "每枚占 {{n}} 格",
			fieldResourceUse: {
				regular: "可支付卡牌上对应的费用，也可支付任意资源费用。",
				wildlife: "支付费用时，一枚野生动物可以代替一枚山峰、森林、太阳或水域。",
				snow: "执行小屋行动时交出全部雪。每枚雪前进 1 个雪格，经过奖励格时领取奖励。",
				carabiner: "交出一枚登山扣即可进行铁索攀登，领取对应奖励并获得一枚雪。"
			},
			projectSite: "{{resource}}站",
			displayBonus: "展示奖励",
			journeyEnd: "旅程回顾",
			scoreItem: "计分项目",
			reviewTable: "回看步道与公园",
			returnScores: "返回结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			journeyWinner: "获胜",
			resultParkAwards: "公园奖章",
			resultPhotoAward: "照片奖章",
			resultTotal: "总分",
			fx: {
				cardUsed: "使用了{{card}}",
				honorEarned: "荣誉入册",
				parkAward: "{{suit}}公园奖章 ×{{count}}",
				chaletAward: "小屋奖章 · {{points}} 分"
			},
			handEmpty: "暂无奇迹卡",
			playersTitle: "玩家",
			reservedTitle: "预留公园",
			visitedTitle: "到访公园",
			deckCount: "牌库剩 {{n}} 张",
			startDeck: "牌堆",
			visit: "访问",
			reserve: "预留",
			support: "支持",
			free: "免费",
			deckCost: "太阳 1 · 水域 1",
			points: "{{n}} 分",
			cannotAfford: "资源不足",
			slotTop: "单独行动",
			slotBoth: "行动＋访问公园",
			slotParks: "只访问公园",
			slotTaken: "已被占用",
			chooseSlot: "选择终点位置",
			chooseHiker: "选择旅人",
			hikerLabel: "旅人 {{n}}",
			siteNo: "第 {{n}} 站",
			atEnd: "已抵达终点",
			endTurn: "结束回合",
			viaFerrata: "铁索攀登",
			skip: "跳过",
			cancel: "取消",
			campfireLabel: "营火",
			useCommunalCampfire: "使用公共营火",
			useCampfireCard: "使用营火奇迹卡",
			occupiedPrompt: "这个站点已有旅人，选择如何共享",
			discardResPrompt: "选择要弃回供应的资源",
			discardWonderPrompt: "选择要弃掉的奇迹卡",
			mug: {
				track: "马克杯",
				level: "第 {{n}} 档",
				fill: "填充",
				drink: "饮用",
				chalet: "小屋行动",
				cons: "免费保护工程",
				benefit1: "第一档：小屋行动或免费保护工程",
				benefit2: "第二档：掷三次步道骰",
				benefit3: "第三档：免费访问一张公园"
			},
			assignWildPrompt: "这张野性公园归入哪个花色？",
			freeParkPrompt: "免费访问一张公园",
			wonder: {
				top: "上半",
				bottom: "下半",
				play: "打出",
				pay: "需支付 {{cost}}",
				grant: "获得 {{grant}}",
				campfireCard: "营火卡",
				noPlay: "不能直接打出"
			},
			resources: "资源",
			carabiners: "登山扣 {{n}}",
			photos: "照片 {{n}}",
			albums: "相册 {{n}}",
			awards: "奖章 {{n}}",
			parkAwardsLabel: "公园奖章 {{n}}",
			consAwardsLabel: "保护奖章 {{n}}",
			chaletAwardsLabel: "小屋奖章 {{n}}",
			chaletPos: "小屋第 {{n}} 格",
			visitedCount: "到访 {{n}} 张",
			reservedCount: "预留 {{n}} 张",
			shutterbug: "快门虫",
			greta: "护林员格蕾塔",
			gretaHikers: "格蕾塔的旅人",
			soloRank: "单人评级：{{name}}",
			soloRankTable: "评级线：30 一日徒步者，35 远行者，40 探险家，45 冒险家，50 开拓者",
			siteAction: "执行站点行动",
			endTop: "终点行动",
			endParksTodo: "终点公园行动",
			activateCons: "激活保护卡",
			activateConsPrompt: "选择要激活的保护卡",
			activateConsEmpty: "当前站点没有可激活的保护卡",
			gretaPairA: "橄榄色旅人先",
			gretaPairB: "陶土色旅人先",
			scoringTitle: "终局结算",
			scoringPrompt: "你可以用营火奇迹卡上交资源换取分数；也可以放弃",
			scoringDone: "完成结算",
			scoringEmpty: "手中没有可用的营火效果",
			scoringPayPrompt: "选择要上交的资源，共 {{n}} 点",
			scoringPayChosen: "已选 {{n}}",
			scoringPayConfirm: "上交并结算",
			scoringPayReset: "重新选择",
			scoringUsed: "已使用",
			useEffect: "使用",
			endIncomplete: "请先完成步道终点的行动",
			over: {
				parks: "公园 {{n}}",
				campfire: "营火卡 {{n}}",
				endgame: "营火结算 {{n}}",
				photos: "照片 {{n}}",
				parkAwards: "公园奖章 {{n}}",
				cons: "保护奖章 {{n}}",
				chalet: "小屋奖章 {{n}}",
				photoAward: "照片奖章 {{n}}",
				total: "合计 {{n}}",
				rank: "评级：{{name}}"
			},
			noResources: "暂无资源",
			wild: "野性公园",
			ownMat: "我的",
			otherMat: "{{name}} 的板面",
			scoreShort: "{{n}} 分",
			err: {
				notTurn: "现在轮不到你",
				notPlayer: "你不在这局游戏里",
				phase: "当前步骤不能这样操作",
				badAction: "这一步不能这样做",
				mustMove: "请先移动一名旅人",
				alreadyMoved: "本回合已经移动过了",
				mustEnd: "其他旅人都已抵达终点，必须直接前往步道终点",
				badTarget: "这个站点不能去",
				badHiker: "这名旅人已经抵达终点",
				badSlot: "请选择一个可用的终点位置",
				full: "这个终点位置已被占用",
				occupied: "这个站点已有其他旅人，需要先使用营火",
				noCampfire: "没有可用的营火",
				badPark: "没有可拿取的公园卡",
				badCons: "没有可拿取的保护卡",
				noRes: "资源不足",
				noCarabiner: "登山扣不足",
				noVf: "这个站点无法进行铁索攀登",
				badWonder: "这张奇迹卡不能这样使用",
				badSuit: "不能归入这个花色",
				noConsSite: "这里不能激活保护卡",
				consUsed: "这张保护卡本回合已经激活过"
			}
		},
		en: {
			name: "Parks Europe",
			parkNames: {
				p0: "Lake District",
				p1: "Picos de Europa",
				p2: "Vatnajökull",
				p3: "Calanques",
				p4: "Samaria",
				p5: "Rila",
				p6: "Jotunheimen",
				p7: "Cinque Terre",
				p8: "Tatra",
				p9: "Swiss National Park",
				p10: "Loch Lomond & The Trossachs",
				p11: "Jostedalsbreen",
				p12: "Connemara",
				p13: "Hardangervidda",
				p14: "Theth",
				p15: "Triglav",
				p16: "Berchtesgaden",
				p17: "Retezat",
				p18: "Abruzzo, Lazio e Molise",
				p19: "Arcipelago di La Maddalena",
				p20: "Göreme",
				p21: "Pyrénées",
				p22: "Sarek",
				p23: "Timanfaya",
				p24: "Dolomiti Bellunesi",
				p25: "Hohe Tauern",
				p26: "Thingvellir",
				p27: "Wadden Sea",
				p28: "Pirin",
				p29: "Oulanka",
				p30: "Killarney",
				p31: "Durmitor",
				p32: "Gauja",
				p33: "Doñana",
				p34: "Écrins",
				p35: "Vikos-Aoös",
				p36: "Olympus",
				p37: "Ordesa y Monte Perdido",
				p38: "Plitvice Lakes",
				p39: "Teide",
				p40: "Peneda-Gerês",
				p41: "Gesäuse",
				p42: "Krka",
				p43: "Abisko",
				p44: "Saxon Switzerland",
				p45: "Butrint",
				p46: "Cairngorms",
				p47: "Peak District"
			},
			wonderNames: {
				b01: "Take a Wild Ride",
				b02: "Savor the Sunrise",
				b03: "Bask in the Light",
				b04: "Enjoy the Forests",
				b05: "Walk in the Woods",
				b06: "Take a Hike Bike",
				b07: "Explore the Backcountry",
				b08: "Clear Skies, Full Hearts",
				b09: "Protect the Peaks",
				b10: "Reflect on the Journey",
				b11: "Trail Magic",
				b12: "Take a Dip",
				b13: "Ford a Mountain Stream",
				b14: "Clip In and Climb",
				b16: "Capture the Moment",
				b17: "Ramble Along",
				b18: "Ascend the Mountain",
				b19: "Scale the Summit",
				b20: "Preserve the Trees",
				b21: "Clean the Riverbanks"
			},
			campfireCardName: "Campfire #{{n}}",
			selectedHiker: "Selected",
			desc: "Hike through Europe’s national parks over three seasons, gathering resources, resting at chalets, taking photos and supporting conservation projects for the most points",
			rules: "Goal:\nEach player leads two hikers through the national parks of Europe across three seasons. Collect resources and photos, visit national parks, support conservation projects, and earn the most points in the final scoring to win.\nSetup:\n· Each player takes a player mat, places both hikers at the trailhead, puts the mug token on the bottom space of the mug track, and takes one carabiner.\n· Randomly stack all players’ chalet tokens on the starting space of the chalet track.\n· Each player draws one Wonder card from the Wonder deck to start their hand.\n· Shuffle the park cards and the conservation cards, then reveal three of each into their displays. Prepare communal campfires by player count: one for up to three players, two for four players, and three for five players.\n· At the start of each season, reveal a season card and place communal campfires and season bonus resources on the indicated sites. The player whose chalet token is furthest along the track takes the first turn; if tokens share a space, the topmost token goes first.\nTurns:\nPlayers take turns until all hikers reach Trail’s End, which ends the season. After three seasons, final scoring begins.\n· On your turn, choose one hiker that has not reached Trail’s End and move it forward to any later site, taking that site’s action and any season bonus resource there.\n· Hikers never move backward. A hiker cannot stop on a site occupied by another hiker unless you spend the communal campfire on that site or discard a campfire Wonder card from your hand.\n· You may decline the site’s main action; if you do, you may still use the Via Ferrata, play Wonder cards, or activate conservation cards.\n· After landing, the site’s main action, the Via Ferrata, any Wonder cards, and conservation card activations may be taken in any order.\n· At the end of your turn, your hand holds at most three Wonder cards and you keep at most three carabiners. Your mat holds twelve spaces, each snow occupies two spaces, and any excess non-snow resources are returned to the supply.\nCampfires:\n· Communal campfires are placed at the start of each season and return to the supply when spent; they are not replenished during that season.\n· Campfire Wonder cards stay in your hand for final scoring, but you may discard one earlier to share an occupied site.\nTrail Sites:\n· The four core sites provide forest, sun, mountain and water. The mountain and water sites also provide one snow each.\n· Advanced sites provide wildlife, a carabiner, a parks action, a trail die roll, a photo, a mug action, a chalet action, a Wonder card, or a conservation project.\n· The center site always shows the Shutterbug icon; a hiker landing there immediately takes the Shutterbug.\nTrail’s End:\n· Trail’s End has three areas. The top row offers one of the four actions, with room for one hiker per space. The middle area offers a parks action and holds any number of hikers. The bottom row offers both the action above and a parks action, with room for one hiker per space.\n· A hiker on the bottom row must complete both the action and the parks action, in either order.\n· Campfires cannot be used at Trail’s End. Once both of a player’s hikers reach Trail’s End, that player’s hike is over for the season.\n· If all other hikers have already left the trail when your turn begins, you must move directly to Trail’s End and choose a space as usual.\nVia Ferrata:\n· Every site except the center site has a Via Ferrata tile above it. After landing, you may spend one carabiner to gain that tile’s benefit and one snow.\n· You may use the Via Ferrata only once per turn, and you may do so before or after the site action.\nNational Parks:\n· A parks action lets you either reserve one park or visit any number of parks. Reserving takes one card from the display or the top card of the deck and places it in your reserved area.\n· Visiting requires paying the resources shown on the park card. Wildlife may replace any ordinary resource, and an any-resource cost may be paid with any resources.\n· Stack visited parks by suit to the right of your mat. Each third park in a suit immediately earns that suit’s park award and its printed instant benefit. Each park award scores one point per park of that suit at the end of the game.\n· Wild parks belong to no suit. Add a wild park to any existing suit stack; if you have no suit stack yet, it joins the next colored park you visit.\n· Taking or discarding a card does not refill a display immediately. At the end of the turn, cards slide right and new cards enter from the left, so the rightmost card is always the oldest.\nTrail Die and Shutterbug:\n· The six faces of the trail die provide a carabiner, wildlife, mountain and water, a Wonder card, a photo, or sun and forest.\n· While you hold the Shutterbug, each photo action on your turn grants one extra photo. A hiker landing on the center site or certain cards can give you the Shutterbug.\nPhotos:\n· Each photo scores one point at the end of the game. Every five photos become one photo album, and each album scores five points.\n· At the end of the game, the player who took the most photos gains the photo award worth three points; ties go to the player furthest along the chalet track. Solo mode does not use the photo award.\nMug:\n· A mug action either fills or drinks. Filling moves the token up one space, to the top at most. Drinking resolves the benefit of the token’s current space, then returns the token to the bottom.\n· The first space offers a chalet action or a free conservation project.\n· The second space rolls the trail die three times and grants every result.\n· The third space visits one park for free from the display, your reserved area, or the top of the deck.\nConservation Projects:\n· A conservation action supports one displayed project, or pays one sun and one water to take the top card of the deck.\n· A conservation card activates only at the core site matching its color. Each card may activate once per turn, multiple cards may be activated in any order, and activation may come before or after the site’s main action.\n· If you take a card matching the site you are currently on, you may activate it immediately.\n· Collecting one card of each of the four colors earns a conservation award worth five points.\nChalet:\n· A chalet action turns in all snow on your mat and moves your chalet token along the track one snow space per snow token.\n· Passing a Wonder space draws a Wonder card. Passing an award space takes the most valuable award there, or draws a Wonder card if the stack is empty.\n· If your token ends on a space with another token, stack yours on top. At the end of the track you may still turn in snow, but you no longer move.\n· The chalet track breaks ties at the end of the game; further along wins, and the topmost token wins a shared space.\nWonder Cards:\n· Basic Wonder cards offer two instant actions, one on the top half and one on the bottom half; pay the resources on the left to gain the benefit on the right.\n· Campfire Wonder cards can be discarded to share an occupied site. At the end of the game they score according to their effect, and some let you turn in resources for points.\nSeasons and Final Scoring:\n· At the start of a season, rebuild the trail by shuffling the next three advanced sites with the four core sites and placing them on the seven spaces, then place new campfires and season bonuses.\n· After three seasons, final scoring begins. Each player may choose to turn in resources for points with any campfire Wonder cards in hand, or decline each one.\n· Once campfire effects are resolved, score visited parks, fixed campfire card effects, photos and albums, park awards, conservation awards, and chalet awards. The photo award is calculated after all campfire effects.\n· Park awards score one point per visited park of the matching suit, conservation awards and albums score five points each, photos score one point each, and chalet awards score their face value (3, 4, or 5 points). The player with the most points wins.\nRanger Greta:\n· In solo mode and the two-player challenge, Ranger Greta joins the hike. She always acts last and moves her hikers according to the trail die.\n· A butterfly face moves the rearmost hiker of a pair and a flower face moves the frontmost; the number of symbols is the count of available sites she advances to.\n· Greta treats a site with a communal campfire as available and spends that campfire to stop there. When one of her hikers reaches Trail’s End, discard the rightmost park card and conservation card from their displays.\n· In solo mode Greta controls two pairs of hikers, and before each of her turns you choose which pair moves first. You draw an extra Wonder card whenever you gain a chalet award; the photo award is not used, and your final score is compared to the rank table.",
			season: {
				cliffs: "Season of Cliffs",
				swimming: "Season of Swimming",
				memories: "Season of Memories",
				sun: "Season of Sun",
				dreams: "Season of Dreams",
				joy: "Season of Joy",
				scouting: "Season of Scouting",
				growth: "Season of Growth",
				climbing: "Season of Climbing",
				caves: "Season of Caves",
				meadows: "Season of Meadows",
				ice: "Season of Ice"
			},
			res: {
				mountain: "Mountain",
				forest: "Forest",
				sun: "Sun",
				water: "Water",
				wildlife: "Wildlife",
				snow: "Snow",
				any: "Any resource"
			},
			suit: {
				lime: "Lime",
				orange: "Orange",
				teal: "Teal",
				purple: "Purple",
				wild: "Wild"
			},
			site: {
				"core-forest": "Forest: gain one forest",
				"core-sun": "Sun: gain two sun",
				"core-mountain": "Mountain: gain one mountain and one snow",
				"core-water": "Water: gain two water and one snow",
				wildlife: "Wildlife: gain one wildlife",
				carabiner: "Carabiner: gain one carabiner",
				parks: "Parks action",
				die: "Roll the trail die",
				photo: "Take a photo",
				mug: "Mug action",
				chalet: "Chalet action",
				wonder: "Draw a Wonder card",
				conservation: "Conservation project"
			},
			siteShort: {
				"core-forest": "Forest",
				"core-sun": "Sun",
				"core-mountain": "Mountain",
				"core-water": "Water",
				wildlife: "Wildlife",
				carabiner: "Carabiner",
				parks: "Parks",
				die: "Roll die",
				photo: "Photo",
				mug: "Mug",
				chalet: "Chalet",
				wonder: "Wonder",
				conservation: "Conservation"
			},
			vf: {
				wonder: "Draw a Wonder card",
				sunwater: "Gain one sun and one water",
				photo: "Take a photo",
				conservation: "Conservation project",
				mug: "Mug action",
				wildlife: "Gain one wildlife"
			},
			vfShort: {
				wonder: "Wonder",
				sunwater: "Sun and water",
				photo: "Photo",
				conservation: "Conservation",
				mug: "Mug",
				wildlife: "Wildlife"
			},
			top: {
				conservation: "Conservation project",
				carabiner: "Gain a carabiner",
				mug: "Mug action",
				chalet: "Chalet action"
			},
			benefit: {
				die: "Roll the trail die",
				parks: "Parks action",
				mug: "Mug action",
				wonder: "Draw a Wonder card",
				photo: "Take a photo",
				wildlife: "Gain wildlife",
				carabiner: "Gain a carabiner"
			},
			token: {
				photo: "Photo",
				carabiner: "Carabiner"
			},
			consProject: {
				p0: "Biodiversity Restoration",
				p1: "Field Research",
				p2: "Heritage Site Restoration",
				p3: "Light Pollution Reduction",
				p4: "Nature Photography",
				p5: "Species Protection",
				p6: "Trail Maintenance"
			},
			campfire: {
				consForest: "One point per forest conservation card",
				consMountain: "One point per mountain conservation card",
				consSun: "One point per sun conservation card",
				consWater: "One point per water conservation card",
				iconForest: "One point per three forest icons on visited parks",
				iconMountain: "One point per three mountain icons on visited parks",
				iconSun: "One point per three sun icons on visited parks",
				iconWater: "One point per three water icons on visited parks",
				anyIcons: "One point per two any-resource icons on visited parks",
				album: "One point per photo album",
				wonderHand: "One point per Wonder card in hand, including this one",
				snow: "One point per snow on your mat",
				turnWildlife2: "Turn in two wildlife for four points",
				turnAny2: "Turn in any two resources for the Shutterbug and two photos",
				turnCarabiner: "Turn in one carabiner for two points",
				turnAny3: "Turn in any three resources for three points"
			},
			rank: {
				none: "Unranked",
				r1: "Dayhiker",
				r2: "Trekker",
				r3: "Explorer",
				r4: "Adventurer",
				r5: "Trailblazer"
			},
			opt: {
				greta: "Invite Ranger Greta",
				gretaHint: "Available in two-player games only; in solo mode Greta always joins."
			},
			seasonLabel: "Season {{n}}",
			seasonCard: "Season card: {{name}}",
			myTurn: "Your turn",
			waitingFor: "Waiting for {{name}}…",
			pending: {
				move: "Move one of your hikers",
				trailEnd: "Every other hiker has reached Trail’s End, so move directly there",
				actions: "Keep taking actions, or end your turn",
				parks: "Reserve or visit parks",
				mug: "Fill or drink your mug",
				mugChoice: "Choose your mug benefit",
				cons: "Support a conservation project",
				consFree: "Support a conservation project for free",
				assignWild: "Choose a suit for the wild park",
				freePark: "Visit one park for free",
				discardRes: "Discard one excess resource",
				discardWonder: "Discard one excess Wonder card",
				gretaColor: "Choose which pair of Greta’s hikers moves first",
				scoring: "Final scoring",
				none: "Game over"
			},
			trail: "Trail",
			trailEnd: "Trail’s End",
			trailStart: "Trailhead",
			parksTitle: "National Parks",
			consTitle: "Conservation Projects",
			chaletTrack: "Chalet Track",
			myMat: "My Mat",
			handTitle: "My Wonder Cards",
			fieldParks: "Parks",
			fieldProjects: "Projects",
			fieldChalet: "Chalet",
			awardParkDetail: "On arrival: {{benefit}}. At the end of the game, score 1 point per park of this suit.",
			awardFixedDetail: "Score {{n}} points at the end of the game.",
			wonderDiscard: "Discard",
			wonderDiscardName: "Discard {{name}}",
			wonderPlay: "Play this half",
			wonderWait: "Wait for your turn",
			wonderShare: "Discard to enter an occupied trail site.",
			wonderScore: "End-game scoring",
			fieldAward: "Award space",
			fieldFinish: "Finish",
			fieldSnowSpace: "Snow space",
			fieldAwardNext: "Take the {{n}}-point award first.",
			fieldAwardStack: "Below it, in order: {{scores}} points.",
			fieldDrawPassing: "Draw 1 Wonder card when you pass.",
			fieldChaletNote: "Move 1 snow space per snow token spent. Collect rewards as you pass them.",
			fieldTrackSpace: "Space {{n}} · {{name}}",
			fieldStartShort: "Start",
			fieldEndShort: "End",
			fieldEndActions: "End actions",
			fieldAction: "Action",
			fieldVacant: "Open",
			fieldChoose: "Choose",
			fieldSharedOccupied: "Hikers present",
			fieldSharedSlot: "Shared space",
			fieldSeasonNote: "At the start of the season, place 1 bonus token at each site from 2 to 7.",
			fieldChoosePark: "Choose a park",
			fieldFinishParks: "Finish parks action",
			fieldVisitedPark: "Visited {{name}} · +{{n}} points",
			fieldDisplay: "Display",
			fieldReserved: "Reserved {{n}}",
			fieldNoReserved: "No reserved parks",
			fieldTrailSeason: "Trail and season",
			fieldTrailRoute: "Along the trail",
			fieldSeasonTab: "Season card",
			fieldStop: "Site",
			fieldExtras: "Extras",
			fieldHikers: "Hikers",
			fieldGoTo: "Move to {{name}}",
			fieldMoveHere: "Move here",
			fieldTrailheadInfo: "Both hikers set out from here at the start of each season.",
			fieldTrailEndInfo: "A hiker finishes the trail for the season here. Choose an end space or visit parks only.",
			fieldSiteEmpty: "No hikers here",
			fieldFerrataInfo: "Spend one carabiner and gain one snow in addition to the reward.",
			fieldSeasonReward: "Season reward",
			fieldShareInfo: "Use the campfire to share this site with another hiker.",
			fieldEndSpaces: "View Trail’s End spaces",
			fieldSiteDetail: {
				"core-forest": "Gain one forest.",
				"core-sun": "Gain two sun.",
				"core-mountain": "Gain one mountain and one snow.",
				"core-water": "Gain two water and one snow.",
				wildlife: "Gain one wildlife.",
				carabiner: "Gain one carabiner.",
				parks: "Reserve one park or spend resources to visit parks.",
				die: "Roll the trail die once and gain the result.",
				photo: "Take one photo. Take one more if you have the Shutterbug.",
				mug: "Fill your mug by one level, or drink to gain the reward at its current level.",
				chalet: "Turn in all your snow. Move one snow space per token and collect rewards as you pass them.",
				wonder: "Draw one Wonder card.",
				conservation: "Support a displayed conservation project, or spend one sun and one water to take the top card."
			},
			fieldResetCamera: "Reset valley view",
			fieldAlbum: "Albums",
			fieldHonors: "Awards",
			fieldCollection: "Visited parks",
			fieldSupported: "Supported projects",
			fieldNone: "None yet",
			fieldPlayerItems: "Player materials",
			fieldPack: "Pack",
			fieldHand: "Hand",
			fieldPanels: "Game materials",
			closePanel: "Close panel",
			camera: "Trail view",
			overview: "Valley",
			follow: "Follow",
			valleyUnavailable: "Open Trail to select a destination.",
			packSlots: "Resource slots",
			packUsage: "{{used}} / 12 slots",
			fieldResourceCount: "{{n}} held",
			fieldResourceSlots: "{{n}} slots per token",
			fieldResourceUse: {
				regular: "Use this to pay costs showing this resource or any resource.",
				wildlife: "When paying a cost, each wildlife can replace one mountain, forest, sun or water.",
				snow: "Turn in all your snow at a chalet. Move one snow space per token and collect rewards as you pass them.",
				carabiner: "Spend one carabiner on a Via Ferrata to gain its reward and one snow."
			},
			projectSite: "{{resource}} site",
			displayBonus: "Display bonus",
			journeyEnd: "Journey recap",
			scoreItem: "Scoring category",
			reviewTable: "Review trail and parks",
			returnScores: "Return to scores",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			journeyWinner: "Winner",
			resultParkAwards: "Park Awards",
			resultPhotoAward: "Photo Award",
			resultTotal: "Total",
			fx: {
				cardUsed: "Played {{card}}",
				honorEarned: "Honor earned",
				parkAward: "{{suit}} park award ×{{count}}",
				chaletAward: "Chalet award · {{points}} points"
			},
			handEmpty: "No Wonder cards",
			playersTitle: "Players",
			reservedTitle: "Reserved Parks",
			visitedTitle: "Visited Parks",
			deckCount: "{{n}} cards left in the deck",
			startDeck: "Deck",
			visit: "Visit",
			reserve: "Reserve",
			support: "Support",
			free: "Free",
			deckCost: "One sun, one water",
			points: "{{n}} points",
			cannotAfford: "Not enough resources",
			slotTop: "Action only",
			slotBoth: "Action + visit parks",
			slotParks: "Visit parks only",
			slotTaken: "Occupied",
			chooseSlot: "Choose a Trail’s End space",
			chooseHiker: "Choose a hiker",
			hikerLabel: "Hiker {{n}}",
			siteNo: "Site {{n}}",
			atEnd: "At Trail’s End",
			endTurn: "End turn",
			viaFerrata: "Via Ferrata",
			skip: "Skip",
			cancel: "Cancel",
			campfireLabel: "Campfire",
			useCommunalCampfire: "Spend the communal campfire",
			useCampfireCard: "Spend a campfire Wonder card",
			occupiedPrompt: "Another hiker is here; choose how to share the site",
			discardResPrompt: "Choose a resource to return to the supply",
			discardWonderPrompt: "Choose a Wonder card to discard",
			mug: {
				track: "Mug",
				level: "Space {{n}}",
				fill: "Fill",
				drink: "Drink",
				chalet: "Chalet action",
				cons: "Free conservation project",
				benefit1: "First space: chalet action or free conservation",
				benefit2: "Second space: roll the trail die three times",
				benefit3: "Third space: visit one park for free"
			},
			assignWildPrompt: "Which suit does this wild park join?",
			freeParkPrompt: "Visit one park for free",
			wonder: {
				top: "Top",
				bottom: "Bottom",
				play: "Play",
				pay: "Pay {{cost}}",
				grant: "Gain {{grant}}",
				campfireCard: "Campfire card",
				noPlay: "Cannot be played directly"
			},
			resources: "Resources",
			carabiners: "Carabiners {{n}}",
			photos: "Photos {{n}}",
			albums: "Albums {{n}}",
			awards: "Awards {{n}}",
			parkAwardsLabel: "Park awards {{n}}",
			consAwardsLabel: "Conservation awards {{n}}",
			chaletAwardsLabel: "Chalet awards {{n}}",
			chaletPos: "Chalet space {{n}}",
			visitedCount: "{{n}} visited",
			reservedCount: "{{n}} reserved",
			shutterbug: "Shutterbug",
			greta: "Ranger Greta",
			gretaHikers: "Greta’s hikers",
			soloRank: "Solo rank: {{name}}",
			soloRankTable: "Ranks: 30 Dayhiker, 35 Trekker, 40 Explorer, 45 Adventurer, 50 Trailblazer",
			siteAction: "Take the site action",
			endTop: "Trail’s End action",
			endParksTodo: "Trail’s End parks action",
			activateCons: "Activate conservation card",
			activateConsPrompt: "Choose a conservation card to activate",
			activateConsEmpty: "No conservation card can be activated here",
			gretaPairA: "Moss hikers first",
			gretaPairB: "Clay hikers first",
			scoringTitle: "Final Scoring",
			scoringPrompt: "You may turn in resources for points with campfire Wonder cards, or decline each one",
			scoringDone: "Finish scoring",
			scoringEmpty: "No usable campfire effect in hand",
			scoringPayPrompt: "Choose {{n}} resources to turn in",
			scoringPayChosen: "{{n}} chosen",
			scoringPayConfirm: "Turn in and score",
			scoringPayReset: "Choose again",
			scoringUsed: "Used",
			useEffect: "Use",
			endIncomplete: "Complete the Trail’s End actions first",
			over: {
				parks: "Parks {{n}}",
				campfire: "Campfire cards {{n}}",
				endgame: "Campfire scoring {{n}}",
				photos: "Photos {{n}}",
				parkAwards: "Park awards {{n}}",
				cons: "Conservation awards {{n}}",
				chalet: "Chalet awards {{n}}",
				photoAward: "Photo award {{n}}",
				total: "Total {{n}}",
				rank: "Rank: {{name}}"
			},
			noResources: "No resources",
			wild: "Wild park",
			ownMat: "Mine",
			otherMat: "{{name}}’s mat",
			scoreShort: "{{n}} points",
			err: {
				notTurn: "It is not your turn",
				notPlayer: "You are not in this game",
				phase: "You cannot do that right now",
				badAction: "That action is not available here",
				mustMove: "Move a hiker first",
				alreadyMoved: "You already moved this turn",
				mustEnd: "Every other hiker has reached Trail’s End, so you must move there",
				badTarget: "You cannot stop at that site",
				badHiker: "That hiker has already reached Trail’s End",
				badSlot: "Choose an available Trail’s End space",
				full: "That Trail’s End space is occupied",
				occupied: "Another hiker is here; you need a campfire",
				noCampfire: "No campfire is available",
				badPark: "No park card can be taken",
				badCons: "No conservation card can be taken",
				noRes: "Not enough resources",
				noCarabiner: "Not enough carabiners",
				noVf: "The Via Ferrata is not available here",
				badWonder: "That Wonder card cannot be used this way",
				badSuit: "That suit is not available",
				noConsSite: "No conservation card can be activated here",
				consUsed: "That conservation card was already activated this turn"
			}
		}
	}
};
//#endregion
export { Ea as default };
