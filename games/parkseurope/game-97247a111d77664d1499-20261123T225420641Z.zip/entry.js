import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { OptionCheckbox as ee, OptionSection as m } from "@bgparty/sdk/ui/game-options";
var h = Object.fromEntries([
	{
		id: 0,
		name: "Lake District",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 1,
		name: "Picos de Europa",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 2,
		name: "Vatnajökull",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 2,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 3,
		name: "Calanques",
		suit: "purple",
		points: 3,
		cost: {
			mountain: 1,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 4,
		name: "Samaria",
		suit: "purple",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 5,
		name: "Rila",
		suit: "purple",
		points: 4,
		cost: {
			mountain: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 6,
		name: "Jotunheimen",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 3,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 7,
		name: "Cinque Terre",
		suit: "purple",
		points: 5,
		cost: {
			mountain: 2,
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 8,
		name: "Tatra",
		suit: "purple",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 9,
		name: "Swiss National Park",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 10,
		name: "Loch Lomond & The Trossachs",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 11,
		name: "Jostedalsbreen",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 12,
		name: "Connemara",
		suit: "teal",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 13,
		name: "Hardangervidda",
		suit: "teal",
		points: 4,
		cost: {
			forest: 1,
			water: 2,
			any: 2
		}
	},
	{
		id: 14,
		name: "Theth",
		suit: "teal",
		points: 5,
		cost: {
			forest: 3,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 15,
		name: "Triglav",
		suit: "teal",
		points: 5,
		cost: {
			forest: 2,
			water: 4
		},
		instant: "mug"
	},
	{
		id: 16,
		name: "Berchtesgaden",
		suit: "teal",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 17,
		name: "Retezat",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			water: 1,
			wildlife: 1
		}
	},
	{
		id: 18,
		name: "Abruzzo, Lazio e Molise",
		suit: "purple",
		points: 2,
		cost: {
			mountain: 1,
			water: 2
		},
		instant: "snow"
	},
	{
		id: 19,
		name: "Arcipelago di La Maddalena",
		suit: "purple",
		points: 2,
		cost: {
			sun: 1,
			water: 3
		},
		instant: "wonder"
	},
	{
		id: 20,
		name: "Göreme",
		suit: "orange",
		points: 3,
		cost: { mountain: 2 }
	},
	{
		id: 21,
		name: "Pyrénées",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 1,
			sun: 2,
			any: 2
		}
	},
	{
		id: 22,
		name: "Sarek",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 3,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 23,
		name: "Timanfaya",
		suit: "orange",
		points: 5,
		cost: {
			mountain: 2,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 24,
		name: "Dolomiti Bellunesi",
		suit: "orange",
		points: 5,
		cost: { mountain: 3 }
	},
	{
		id: 25,
		name: "Hohe Tauern",
		suit: "wild",
		points: 4,
		cost: {
			mountain: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 26,
		name: "Thingvellir",
		suit: "teal",
		points: 2,
		cost: {
			forest: 1,
			sun: 1,
			water: 1
		},
		instant: "chalet"
	},
	{
		id: 27,
		name: "Wadden Sea",
		suit: "teal",
		points: 2,
		cost: { water: 4 },
		instant: "mug"
	},
	{
		id: 28,
		name: "Pirin",
		suit: "teal",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 29,
		name: "Oulanka",
		suit: "teal",
		points: 3,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 30,
		name: "Killarney",
		suit: "lime",
		points: 5,
		cost: {
			forest: 3,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 31,
		name: "Durmitor",
		suit: "lime",
		points: 5,
		cost: {
			forest: 2,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 32,
		name: "Gauja",
		suit: "lime",
		points: 5,
		cost: { forest: 3 }
	},
	{
		id: 33,
		name: "Doñana",
		suit: "wild",
		points: 4,
		cost: {
			forest: 1,
			sun: 1,
			wildlife: 1
		}
	},
	{
		id: 34,
		name: "Écrins",
		suit: "orange",
		points: 2,
		cost: {
			mountain: 1,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 35,
		name: "Vikos-Aoös",
		suit: "orange",
		points: 2,
		cost: { sun: 4 },
		instant: "photo"
	},
	{
		id: 36,
		name: "Olympus",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			any: 2
		}
	},
	{
		id: 37,
		name: "Ordesa y Monte Perdido",
		suit: "orange",
		points: 4,
		cost: {
			mountain: 2,
			any: 2
		}
	},
	{
		id: 38,
		name: "Plitvice Lakes",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 2,
			sun: 1,
			water: 1
		},
		instant: "carabiner"
	},
	{
		id: 39,
		name: "Teide",
		suit: "orange",
		points: 3,
		cost: {
			mountain: 1,
			sun: 4
		},
		instant: "photo"
	},
	{
		id: 40,
		name: "Peneda-Gerês",
		suit: "lime",
		points: 2,
		cost: {
			forest: 1,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 41,
		name: "Gesäuse",
		suit: "lime",
		points: 2,
		cost: { sun: 4 },
		instant: "die"
	},
	{
		id: 42,
		name: "Krka",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			any: 2
		}
	},
	{
		id: 43,
		name: "Abisko",
		suit: "lime",
		points: 4,
		cost: {
			forest: 2,
			any: 2
		}
	},
	{
		id: 44,
		name: "Saxon Switzerland",
		suit: "lime",
		points: 3,
		cost: {
			forest: 2,
			sun: 2
		},
		instant: "wildlife"
	},
	{
		id: 45,
		name: "Butrint",
		suit: "lime",
		points: 3,
		cost: {
			forest: 1,
			sun: 3,
			water: 1
		},
		instant: "die"
	},
	{
		id: 46,
		name: "Cairngorms",
		suit: "lime",
		points: 3,
		cost: { forest: 2 }
	},
	{
		id: 47,
		name: "Peak District",
		suit: "lime",
		points: 4,
		cost: {
			forest: 1,
			sun: 2,
			any: 2
		}
	}
].map((e) => [e.id, e])), g = [
	"lime",
	"orange",
	"teal",
	"purple"
], _ = {
	lime: "wildlife",
	orange: "photo",
	teal: "mug",
	purple: "wonder"
}, v = [
	"sun",
	"mountain",
	"water",
	"forest"
], te = {
	sun: { sun: 2 },
	mountain: { mountain: 1 },
	water: { water: 2 },
	forest: { forest: 1 }
}, ne = [
	{
		name: "Biodiversity Restoration",
		benefit: "die"
	},
	{
		name: "Field Research",
		benefit: "parks"
	},
	{
		name: "Heritage Site Restoration",
		benefit: "mug"
	},
	{
		name: "Light Pollution Reduction",
		benefit: "wonder"
	},
	{
		name: "Nature Photography",
		benefit: "photo"
	},
	{
		name: "Species Protection",
		benefit: "wildlife"
	},
	{
		name: "Trail Maintenance",
		benefit: "carabiner"
	}
], y = (e) => v[Math.floor(e / 7)], b = (e, t = 1) => ({
	t: "res",
	res: e,
	n: t
}), x = (e = 1) => ({
	t: "carabiner",
	n: e
}), re = [
	{
		id: "b01",
		no: 1,
		name: "Take a Wild Ride",
		art: "w01",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [x(2)]
		}
	},
	{
		id: "b02",
		no: 2,
		name: "Savor the Sunrise",
		art: "w02",
		top: { grants: [b("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [b("forest"), b("water")]
		}
	},
	{
		id: "b03",
		no: 3,
		name: "Bask in the Light",
		art: "w03",
		top: { grants: [b("sun", 2)] },
		bottom: {
			pay: { sun: 1 },
			grants: [b("mountain"), b("water")]
		}
	},
	{
		id: "b04",
		no: 4,
		name: "Enjoy the Forests",
		art: "w04",
		top: { grants: [b("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [{
				t: "photo",
				n: 1
			}, b("sun")]
		}
	},
	{
		id: "b05",
		no: 5,
		name: "Walk in the Woods",
		art: "w05",
		top: { grants: [b("forest")] },
		bottom: {
			pay: { forest: 1 },
			grants: [b("wildlife"), b("sun")]
		}
	},
	{
		id: "b06",
		no: 6,
		name: "Take a Hike Bike",
		art: "w06",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [b("wildlife")] }
	},
	{
		id: "b07",
		no: 7,
		name: "Explore the Backcountry",
		art: "w07",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [b("wildlife", 2)]
		}
	},
	{
		id: "b08",
		no: 8,
		name: "Clear Skies, Full Hearts",
		art: "w08",
		top: { grants: [b("sun", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b09",
		no: 9,
		name: "Protect the Peaks",
		art: "w09",
		top: { grants: [b("mountain")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b10",
		no: 10,
		name: "Reflect on the Journey",
		art: "w10",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "mug" }, { t: "mug" }]
		}
	},
	{
		id: "b11",
		no: 11,
		name: "Trail Magic",
		art: "w11",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{ t: "mug" }] }
	},
	{
		id: "b12",
		no: 12,
		name: "Take a Dip",
		art: "w12",
		top: { grants: [b("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [b("forest"), b("sun")]
		}
	},
	{
		id: "b13",
		no: 13,
		name: "Ford a Mountain Stream",
		art: "w13",
		top: { grants: [b("water", 2)] },
		bottom: {
			pay: { water: 1 },
			grants: [b("mountain"), b("sun")]
		}
	},
	{
		id: "b14",
		no: 14,
		name: "Clip In and Climb",
		art: "w14",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [x()] }
	},
	{
		id: "b16",
		no: 16,
		name: "Capture the Moment",
		art: "w16",
		top: { grants: [{ t: "parks" }] },
		bottom: {
			pay: { any: 2 },
			grants: [{ t: "shutterbug" }, {
				t: "photo",
				n: 1
			}]
		}
	},
	{
		id: "b17",
		no: 17,
		name: "Ramble Along",
		art: "w17",
		top: { grants: [{ t: "parks" }] },
		bottom: { grants: [{
			t: "photo",
			n: 1
		}] }
	},
	{
		id: "b18",
		no: 18,
		name: "Ascend the Mountain",
		art: "w18",
		top: { grants: [b("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [x(), b("water")]
		}
	},
	{
		id: "b19",
		no: 19,
		name: "Scale the Summit",
		art: "w19",
		top: { grants: [b("mountain")] },
		bottom: {
			pay: { mountain: 1 },
			grants: [{ t: "mug" }, b("water")]
		}
	},
	{
		id: "b20",
		no: 20,
		name: "Preserve the Trees",
		art: "w20",
		top: { grants: [b("forest")] },
		bottom: { grants: [{ t: "cons" }] }
	},
	{
		id: "b21",
		no: 21,
		name: "Clean the Riverbanks",
		art: "w21",
		top: { grants: [b("water", 2)] },
		bottom: { grants: [{ t: "cons" }] }
	}
], ie = [
	{
		id: "c01",
		no: 1,
		art: "w15",
		effect: "consForest"
	},
	{
		id: "c02",
		no: 2,
		art: "w36",
		effect: "consMountain"
	},
	{
		id: "c03",
		no: 3,
		art: "w29",
		effect: "consSun"
	},
	{
		id: "c04",
		no: 4,
		art: "w30",
		effect: "consWater"
	},
	{
		id: "c05",
		no: 5,
		art: "w31",
		effect: "iconForest"
	},
	{
		id: "c06",
		no: 6,
		art: "w32",
		effect: "iconMountain"
	},
	{
		id: "c07",
		no: 7,
		art: "w33",
		effect: "iconSun"
	},
	{
		id: "c08",
		no: 8,
		art: "w34",
		effect: "iconWater"
	},
	{
		id: "c09",
		no: 9,
		art: "w35",
		effect: "anyIcons"
	},
	{
		id: "c10",
		no: 10,
		art: "w22",
		effect: "album"
	},
	{
		id: "c11",
		no: 11,
		art: "w23",
		effect: "wonderHand"
	},
	{
		id: "c12",
		no: 12,
		art: "w24",
		effect: "snow"
	},
	{
		id: "c13",
		no: 13,
		art: "w25",
		effect: "turnWildlife2"
	},
	{
		id: "c14",
		no: 14,
		art: "w26",
		effect: "turnAny2"
	},
	{
		id: "c15",
		no: 15,
		art: "w27",
		effect: "turnCarabiner"
	},
	{
		id: "c16",
		no: 16,
		art: "w28",
		effect: "turnAny3"
	}
], S = Object.fromEntries(re.map((e) => [e.id, e])), C = Object.fromEntries(ie.map((e) => [e.id, e]));
[...re.map((e) => e.id), ...ie.map((e) => e.id)];
var ae = [
	{
		id: "cliffs",
		name: "Season of Cliffs",
		pattern: [
			"water",
			"water",
			"sun",
			"sun",
			"sun",
			"water"
		],
		fires: [
			1,
			7,
			5
		],
		display: {
			zone: "cons",
			token: "carabiner"
		}
	},
	{
		id: "swimming",
		name: "Season of Swimming",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"water",
			"water"
		],
		fires: [
			6,
			4,
			3
		],
		display: {
			zone: "parks",
			token: "water"
		}
	},
	{
		id: "memories",
		name: "Season of Memories",
		pattern: [
			"sun",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			2,
			6
		],
		display: {
			zone: "cons",
			token: "photo"
		}
	},
	{
		id: "sun",
		name: "Season of Sun",
		pattern: [
			"sun",
			"sun",
			"water",
			"sun",
			"sun",
			"sun"
		],
		fires: [
			5,
			3,
			2
		],
		display: {
			zone: "parks",
			token: "sun"
		}
	},
	{
		id: "dreams",
		name: "Season of Dreams",
		pattern: [
			"water",
			"water",
			"sun",
			"water",
			"sun",
			"water"
		],
		fires: [
			4,
			7,
			1
		],
		display: {
			zone: "parks",
			token: "snow"
		}
	},
	{
		id: "joy",
		name: "Season of Joy",
		pattern: [
			"sun",
			"water",
			"forest",
			"mountain",
			"wildlife",
			"sun"
		],
		fires: [
			7,
			1,
			3
		]
	},
	{
		id: "scouting",
		name: "Season of Scouting",
		pattern: [
			"sun",
			"sun",
			"wildlife",
			"wildlife",
			"wildlife",
			"water"
		],
		fires: [
			7,
			5,
			2
		]
	},
	{
		id: "growth",
		name: "Season of Growth",
		pattern: [
			"sun",
			"water",
			"forest",
			"sun",
			"forest",
			"forest"
		],
		fires: [
			5,
			6,
			7
		]
	},
	{
		id: "climbing",
		name: "Season of Climbing",
		pattern: [
			"sun",
			"water",
			"sun",
			"carabiner",
			"carabiner",
			"carabiner"
		],
		fires: [
			1,
			3,
			6
		]
	},
	{
		id: "caves",
		name: "Season of Caves",
		pattern: [
			"water",
			"sun",
			"mountain",
			"mountain",
			"water",
			"mountain"
		],
		fires: [
			3,
			2,
			1
		]
	},
	{
		id: "meadows",
		name: "Season of Meadows",
		pattern: [
			"sun",
			"photo",
			"sun",
			"photo",
			"sun",
			"photo"
		],
		fires: [
			2,
			4,
			5
		]
	},
	{
		id: "ice",
		name: "Season of Ice",
		pattern: [
			"snow",
			"water",
			"snow",
			"water",
			"snow",
			"water"
		],
		fires: [
			3,
			5,
			6
		]
	}
];
Object.fromEntries(ae.map((e, t) => [t, e]));
var w = [
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water"
], oe = [
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
], T = {
	"core-forest": "forest",
	"core-sun": "sun",
	"core-mountain": "mountain",
	"core-water": "water"
};
function se(e) {
	return T[e] ?? null;
}
var E = [
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
], D = [
	{
		ranger: "butterfly",
		symbols: 1,
		carabiner: 1
	},
	{
		ranger: "butterfly",
		symbols: 1,
		res: { wildlife: 1 }
	},
	{
		ranger: "butterfly",
		symbols: 2,
		res: {
			mountain: 1,
			water: 1
		}
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "wonder"
	},
	{
		ranger: "flower",
		symbols: 1,
		grant: "photo"
	},
	{
		ranger: "flower",
		symbols: 2,
		res: {
			sun: 1,
			forest: 1
		}
	}
], ce = [
	{ t: "start" },
	{ t: "snow" },
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: 0,
		solo: 3
	},
	{ t: "snow" },
	{ t: "wonder" },
	{ t: "snow" },
	{
		t: "award",
		stack: null,
		solo: 4
	},
	{ t: "snow" },
	{ t: "snow" },
	{
		t: "award",
		stack: 1,
		solo: 5
	},
	{ t: "snow" },
	{ t: "snow" },
	{ t: "end" }
], le = ce.length - 1, ue = [
	"conservation",
	"carabiner",
	"mug",
	"chalet"
], O = {
	mountain: 16,
	forest: 16,
	sun: 22,
	water: 22,
	wildlife: 14,
	snow: 20
}, k = [
	{
		at: 50,
		rank: 5
	},
	{
		at: 45,
		rank: 4
	},
	{
		at: 40,
		rank: 3
	},
	{
		at: 35,
		rank: 2
	},
	{
		at: 30,
		rank: 1
	}
], de = {
	id: "parkseurope",
	uuid: "57ea4f6d-4e67-4904-8ef4-ab6f134dd492",
	tier: "alpha",
	mechanics: [
		"set-collection",
		"hand-management",
		"engine-building",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.parkseurope.name",
	descKey: "games.parkseurope.desc",
	rulesKey: "games.parkseurope.rules",
	icon: "🏞️",
	iconImg: "games/parkseurope.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#3f7a4d",
	releasedAt: "2026-11-24T05:21:41+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, A = t.enum([
	"lime",
	"orange",
	"teal",
	"purple",
	"wild"
]), fe = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow"
]), pe = t.enum([
	"conservation",
	"carabiner",
	"mug",
	"chalet"
]), me = t.enum([
	"core-forest",
	"core-sun",
	"core-mountain",
	"core-water",
	"wildlife",
	"carabiner",
	"parks",
	"die",
	"photo",
	"mug",
	"chalet",
	"wonder",
	"conservation"
]), he = t.enum([
	"wonder",
	"sunwater",
	"photo",
	"conservation",
	"mug",
	"wildlife"
]), j = t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife",
	"snow",
	"photo",
	"carabiner"
]), ge = t.partialRecord(fe, t.int().nonnegative()), M = t.partialRecord(t.enum([
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
]), t.int().nonnegative().max(3)), _e = t.union([
	t.object({
		kind: t.literal("top"),
		action: pe
	}),
	t.object({
		kind: t.literal("both"),
		action: pe
	}),
	t.object({ kind: t.literal("parks") })
]), ve = t.union([
	t.object({
		type: t.literal("move"),
		hiker: t.union([t.literal(0), t.literal(1)]),
		to: t.int().min(1).max(8),
		campfire: t.enum(["communal", "card"]).optional(),
		card: t.string().optional(),
		slot: _e.optional()
	}),
	t.object({ type: t.literal("siteAction") }),
	t.object({
		type: t.literal("activateCons"),
		card: t.int().nonnegative()
	}),
	t.object({ type: t.literal("endTop") }),
	t.object({ type: t.literal("endParks") }),
	t.object({ type: t.literal("viaFerrata") }),
	t.object({
		type: t.literal("reserve"),
		from: t.enum(["display", "deck"]),
		index: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("visit"),
		parkId: t.int().nonnegative(),
		pay: ge.optional()
	}),
	t.object({ type: t.literal("parksDone") }),
	t.object({
		type: t.literal("mug"),
		act: t.enum(["fill", "drink"])
	}),
	t.object({
		type: t.literal("mugChoice"),
		choice: t.enum(["chalet", "cons"])
	}),
	t.object({
		type: t.literal("consPick"),
		index: t.int().nonnegative().optional(),
		deck: t.boolean().optional()
	}),
	t.object({
		type: t.literal("assignWild"),
		suit: t.enum([
			"lime",
			"orange",
			"teal",
			"purple"
		])
	}),
	t.object({
		type: t.literal("freePark"),
		parkId: t.int().nonnegative().optional(),
		from: t.enum([
			"display",
			"reserve",
			"deck"
		])
	}),
	t.object({
		type: t.literal("playWonder"),
		card: t.string(),
		side: t.enum(["top", "bottom"]),
		pay: ge.optional()
	}),
	t.object({
		type: t.literal("discardRes"),
		res: t.enum([
			"mountain",
			"forest",
			"sun",
			"water",
			"wildlife"
		])
	}),
	t.object({
		type: t.literal("discardWonder"),
		card: t.string()
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("gretaColor"),
		first: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("campfireEnd"),
		card: t.string(),
		pay: M.optional(),
		carabiner: t.boolean().optional()
	}),
	t.object({ type: t.literal("scoringDone") })
]), N = t.object({ greta: t.boolean().default(!1) }).prefault({}), ye = t.object({
	id: t.int().nonnegative(),
	suit: A.nullable()
}), be = t.object({
	rid: t.string(),
	seat: t.int().nonnegative(),
	res: t.record(t.enum([
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife"
	]), t.int().nonnegative()),
	snow: t.int().nonnegative(),
	carabiners: t.int().nonnegative(),
	mug: t.int().min(0).max(3),
	photos: t.int().nonnegative(),
	albums: t.int().nonnegative(),
	photosTaken: t.int().nonnegative(),
	visited: t.array(ye),
	reserved: t.array(t.int().nonnegative()),
	cons: t.array(t.int().nonnegative()),
	parkAwards: t.record(t.enum([
		"lime",
		"orange",
		"teal",
		"purple"
	]), t.int().nonnegative()),
	consAwards: t.int().nonnegative(),
	chaletAwards: t.array(t.int().nonnegative()),
	wonderCount: t.int().nonnegative(),
	shutterbug: t.boolean(),
	chaletPos: t.int().nonnegative(),
	chaletOrder: t.int(),
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	endUsed: t.array(t.string()),
	endPoints: t.int().nonnegative()
}), xe = t.object({
	hikers: t.array(t.int().min(-1).max(8)),
	atEnd: t.boolean(),
	solo: t.boolean()
}), Se = t.object({
	kind: t.enum(["top", "both"]),
	action: pe,
	rid: t.string().nullable()
}), Ce = t.object({
	phase: t.enum([
		"turn",
		"scoring",
		"ended"
	]),
	season: t.int().min(1).max(3),
	turn: t.string().nullable(),
	moved: t.boolean(),
	pending: t.enum([
		"move",
		"trailEnd",
		"actions",
		"parks",
		"mug",
		"mugChoice",
		"cons",
		"assignWild",
		"freePark",
		"discardRes",
		"discardWonder",
		"gretaColor",
		"scoring",
		"none"
	]),
	freeCons: t.boolean(),
	landingSite: t.int().min(1).max(7).nullable(),
	siteDone: t.boolean(),
	consUsed: t.array(t.int().nonnegative()),
	vfUsed: t.boolean(),
	end: t.object({
		action: pe.nullable(),
		topDone: t.boolean(),
		parksDone: t.boolean()
	}).nullable(),
	seasonCard: t.string(),
	order: t.array(t.string()),
	players: t.array(be),
	trailSites: t.array(me),
	trailBonus: t.array(j.nullable()),
	campfires: t.array(t.int().nonnegative()),
	vf: t.array(he.nullable()),
	parksDisplay: t.array(t.int().nonnegative()),
	parksDeck: t.int().nonnegative(),
	parksBonus: t.array(j.nullable()),
	consDisplay: t.array(t.int().nonnegative()),
	consDeck: t.int().nonnegative(),
	consBonus: t.array(j.nullable()),
	consAwardsLeft: t.int().nonnegative(),
	chaletStacks: t.array(t.array(t.int().nonnegative())),
	endSlots: t.array(Se),
	parksEndOccupied: t.boolean(),
	greta: xe.nullable(),
	soloRanks: t.array(t.object({
		at: t.int().nonnegative(),
		rank: t.int().nonnegative()
	})).nullable(),
	revealedCampfire: t.array(t.object({
		rid: t.string(),
		cards: t.array(t.string())
	})).nullable(),
	campfireUsed: t.array(t.string()),
	finalRows: t.array(t.object({
		rid: t.string(),
		parks: t.int(),
		campfire: t.int(),
		endgame: t.int(),
		photos: t.int(),
		parkAwards: t.int(),
		cons: t.int(),
		chalet: t.int(),
		photoAward: t.int(),
		total: t.int()
	})).nullable()
}), we = t.object({
	hand: t.array(t.string()),
	isTurn: t.boolean()
}), P = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], F = (e, t) => ({
	code: `games.parkseurope.err.${e}`,
	...t ? { params: t } : {}
});
function I(t, n, r) {
	let i = r;
	for (let r = t.length - 1; r > 0; r--) {
		let a = e(n, i++, r + 1);
		[t[r], t[a]] = [t[a], t[r]];
	}
	return {
		items: t,
		cursor: i
	};
}
function L(e, t, n) {
	return {
		seat: e,
		res: {
			mountain: 0,
			forest: 0,
			sun: 0,
			water: 0,
			wildlife: 0
		},
		snow: 0,
		carabiners: 1,
		mug: 0,
		photos: 0,
		albums: 0,
		photosTaken: 0,
		visited: [],
		reserved: [],
		cons: [],
		parkAwards: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		consAwards: 0,
		consSets: 0,
		chaletAwards: [],
		wonderHand: [t],
		shutterbug: !1,
		chaletPos: 0,
		chaletOrder: n,
		hikers: [0, 0],
		slots: [null, null],
		sets: {
			lime: 0,
			orange: 0,
			teal: 0,
			purple: 0
		},
		endUsed: [],
		endPoints: 0
	};
}
function R(e, t, n, r) {
	let i = Math.min(r, e.supply[n]);
	i <= 0 || (e.supply[n] -= i, t.res[n] += i);
}
function z(e, t, n) {
	let r = Math.min(n, e.supply.snow);
	r <= 0 || (e.supply.snow -= r, t.snow += r);
}
function B(e, t, n) {
	let r = Math.min(n, e.supply.carabiner);
	r <= 0 || (e.supply.carabiner -= r, t.carabiners += r);
}
function V(e, t, n) {
	for (t.photosTaken += n, t.photos += n; t.photos >= 5 && t.albums < 8;) t.photos -= 5, t.albums += 1;
}
function H(e, t, n) {
	for (let r = 0; r < n; r++) {
		if (e.wonderDeck.length === 0) {
			if (e.wonderDiscard.length === 0) return;
			let t = I(e.wonderDiscard.slice(), e.seed, e.cursor);
			e.wonderDeck = t.items, e.cursor = t.cursor, e.wonderDiscard = [];
		}
		let n = e.wonderDeck.pop();
		n && t.wonderHand.push(n);
	}
}
function U(e, t) {
	for (let t of e.order) e.players[t].shutterbug = !1;
	t && e.players[t] && (e.players[t].shutterbug = !0);
}
function Te(e) {
	let t = e.snow * 2;
	for (let n of P) t += e.res[n];
	return t;
}
function W(e, t) {
	if (t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] > 0 && --e.supply[n];
}
function G(e, t) {
	if (!t || t === "photo") return;
	let n = t === "carabiner" ? "carabiner" : t;
	e.supply[n] += 1;
}
function Ee(e, t, n) {
	n === "photo" ? V(e, t, 1) : n === "carabiner" ? t.carabiners += 1 : n === "snow" ? t.snow += 1 : t.res[n] += 1;
}
function De(e, t, n) {
	let r = (e) => e.some((e) => e !== null && e.kind !== "parks" && e.kind === t && e.action === n);
	for (let t of e.order) if (r(e.players[t].slots)) return !0;
	return !!(e.greta && r(e.greta.slots));
}
function K(e, t, n) {
	let r = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, i = 0;
	for (let e of Object.keys(n)) {
		let t = n[e] ?? 0;
		e === "wildlife" ? i = t : r[e] = t;
	}
	let a = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		wildlife: 0
	};
	if (t.res.wildlife < i) return !1;
	a.wildlife = i;
	for (let e of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a[e] = Math.min(t.res[e], r[e]);
	let o = 0;
	for (let e of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) o += r[e] - a[e];
	if (t.res.wildlife - a.wildlife < o || (a.wildlife += o, P.reduce((e, n) => e + t.res[n] - a[n], 0) < r.any)) return !1;
	let s = r.any;
	for (let e of P) {
		if (s <= 0) break;
		let n = t.res[e] - a[e], r = Math.min(n, s);
		a[e] += r, s -= r;
	}
	for (let n of P) t.res[n] -= a[n], e.supply[n] += a[n];
	return !0;
}
function q(e, t) {
	e.tasks.push(t);
}
function J(t, n) {
	let r = D[e(t.seed, t.cursor++, D.length)];
	if (r.carabiner && B(t, n, r.carabiner), r.res) for (let e of P) r.res[e] && R(t, n, e, r.res[e]);
	r.grant === "wonder" && H(t, n, 1), r.grant === "photo" && V(t, n, 1 + +!!n.shutterbug);
}
function Oe(e, t, n) {
	switch (n) {
		case "die":
			J(e, t);
			break;
		case "parks":
			q(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			q(e, { t: "mug" });
			break;
		case "wonder":
			H(e, t, 1);
			break;
		case "photo":
			V(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			R(e, t, "wildlife", 1);
			break;
		case "carabiner": B(e, t, 1);
	}
}
function ke(e, t, n) {
	switch (n.t) {
		case "res":
			R(e, t, n.res, n.n);
			break;
		case "snow":
			z(e, t, n.n);
			break;
		case "carabiner":
			B(e, t, n.n);
			break;
		case "photo":
			V(e, t, n.n + +!!t.shutterbug);
			break;
		case "wonder":
			H(e, t, n.n);
			break;
		case "die":
			for (let r = 0; r < n.n; r++) J(e, t);
			break;
		case "parks":
			q(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			q(e, { t: "mug" });
			break;
		case "cons":
			q(e, {
				t: "cons",
				free: !1
			});
			break;
		case "chalet":
			Me(e, t);
			break;
		case "shutterbug": U(e, e.turn ?? Ae(e, t));
	}
}
function Ae(e, t) {
	for (let n of e.order) if (e.players[n] === t) return n;
	return null;
}
function je(e, t, n) {
	if (n === "snow") {
		z(e, t, 1);
		return;
	}
	if (n === "chalet") {
		Me(e, t);
		return;
	}
	Oe(e, t, n);
}
function Me(e, t) {
	let n = t.snow;
	if (n <= 0) return;
	e.supply.snow += n, t.snow = 0;
	let r = t.chaletPos, i = r, a = n;
	for (; a > 0 && i < le;) i += 1, ce[i].t === "snow" && --a;
	for (let n = r + 1; n <= i; n++) {
		let r = ce[n];
		r.t === "wonder" ? H(e, t, 1) : r.t === "award" && Pe(e, t, n, r);
	}
	t.chaletPos = i, t.chaletOrder = Ne(e, i) + 1, e.chaletSeq = t.chaletOrder;
}
function Ne(e, t) {
	let n = -1;
	for (let r of e.order) {
		let i = e.players[r];
		i.chaletPos === t && (n = Math.max(n, i.chaletOrder));
	}
	return n;
}
function Pe(e, t, n, r) {
	let i = !1;
	if (e.solo) e.chaletClaimed[n] || (e.chaletClaimed[n] = !0, t.chaletAwards.push(r.solo), i = !0);
	else if (r.stack !== null) {
		let n = e.chaletStacks[r.stack].pop();
		n !== void 0 && (t.chaletAwards.push(n), i = !0);
	}
	if (!i) {
		H(e, t, 1);
		return;
	}
	e.solo && H(e, t, 1);
}
function Fe(e, t) {
	let n = 0;
	for (let r of e.order) for (let i of e.players[r].hikers) i === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function Ie(e, t, n) {
	let r = e.trailBonus[n];
	r && (e.trailBonus[n] = null, Ee(e, t, r));
}
function Le(e, t, n) {
	switch (n) {
		case "core-forest":
			R(e, t, "forest", 1);
			break;
		case "core-sun":
			R(e, t, "sun", 2);
			break;
		case "core-mountain":
			R(e, t, "mountain", 1), z(e, t, 1);
			break;
		case "core-water":
			R(e, t, "water", 2), z(e, t, 1);
			break;
		case "wildlife":
			R(e, t, "wildlife", 1);
			break;
		case "carabiner":
			B(e, t, 1);
			break;
		case "die":
			J(e, t);
			break;
		case "photo":
			V(e, t, 1 + +!!t.shutterbug);
			break;
		case "wonder":
			H(e, t, 1);
			break;
		case "chalet":
			Me(e, t);
			break;
		case "parks":
			q(e, {
				t: "parks",
				visited: !1
			});
			break;
		case "mug":
			q(e, { t: "mug" });
			break;
		case "conservation": q(e, {
			t: "cons",
			free: !1
		});
	}
}
function Re(e, t, n) {
	if (e.landingSite === null) return F("noConsSite");
	let r = se(e.trailSites[e.landingSite - 1]);
	if (!r) return F("noConsSite");
	let i = t.cons[n];
	return i === void 0 || y(i) !== r ? F("badCons") : e.consUsed.includes(n) ? F("consUsed") : (e.consUsed.push(n), Oe(e, t, ne[i % 7].benefit), null);
}
function ze(e) {
	let t = h[e]?.cost ?? {};
	return {
		forest: t.forest ?? 0,
		mountain: t.mountain ?? 0,
		sun: t.sun ?? 0,
		water: t.water ?? 0,
		any: t.any ?? 0
	};
}
function Be(e, t, n) {
	let r = {
		id: n,
		suit: null
	};
	t.visited.push(r);
	let i = g.filter((e) => t.visited.some((t) => t.id !== n && t.suit === e));
	if (i.length !== 0) {
		if (i.length === 1) {
			r.suit = i[0], He(e, t);
			return;
		}
		q(e, {
			t: "assignWild",
			parkId: n,
			suits: i
		});
	}
}
function Ve(e, t, n) {
	let r = h[n].suit;
	if (r === "wild") {
		Be(e, t, n);
		return;
	}
	for (let e of t.visited) e.suit === null && (e.suit = r);
	t.visited.push({
		id: n,
		suit: r
	}), He(e, t);
}
function He(e, t) {
	for (let n of g) {
		let r = t.visited.filter((e) => e.suit === n).length, i = Math.floor(r / 3);
		for (; t.sets[n] < i;) t.sets[n] += 1, je(e, t, _[n]), e.parkAwardPool[n] > 0 && (--e.parkAwardPool[n], t.parkAwards[n] += 1);
	}
}
function Ue(e, t, n) {
	n === "parks" ? (e.parkBonus.splice(t, 1), e.parksDisplay.splice(t, 1)) : (e.consBonus.splice(t, 1), e.consDisplay.splice(t, 1));
}
function We(e) {
	for (; e.parksDisplay.length < 3 && e.parksDeck.length > 0;) e.parksDisplay.unshift(e.parksDeck.shift()), e.parkBonus.unshift(null);
	for (; e.consDisplay.length < 3 && e.consDeck.length > 0;) e.consDisplay.unshift(e.consDeck.shift()), e.consBonus.unshift(null);
}
function Ge(e, t, n) {
	n && Ee(e, t, n);
}
function Ke(e, t, n) {
	let r = e.parkBonus[n] ?? null;
	Ue(e, n, "parks"), Ge(e, t, r);
}
function qe(e, t, n) {
	let r = h[n];
	if (!r) return !1;
	let i = e.parksDisplay.indexOf(n), a = t.reserved.indexOf(n);
	return i < 0 && a < 0 || !K(e, t, r.cost) ? !1 : (i >= 0 ? Ke(e, t, i) : t.reserved.splice(a, 1), Ve(e, t, n), r.instant && je(e, t, r.instant), !0);
}
function Je(e, t, n, r, i) {
	let a;
	if (r) {
		if (!i && !K(e, t, {
			sun: 1,
			water: 1
		})) return F("noRes");
		if (e.consDeck.length === 0) return F("badCons");
		a = e.consDeck.shift();
	} else {
		if (n === void 0 || n < 0 || n >= e.consDisplay.length) return F("badCons");
		if (a = e.consDisplay[n], !i && !K(e, t, te[y(a)])) return F("noRes");
		Ye(e, t, n);
	}
	return t.cons.push(a), Xe(e, t), null;
}
function Ye(e, t, n) {
	let r = e.consBonus[n] ?? null;
	Ue(e, n, "cons"), Ge(e, t, r);
}
function Xe(e, t) {
	let n = Infinity;
	for (let e of v) n = Math.min(n, t.cons.filter((t) => y(t) === e).length);
	for (Number.isFinite(n) || (n = 0); t.consSets < n;) t.consSets += 1, e.consAwardsLeft > 0 && (--e.consAwardsLeft, t.consAwards += 1);
}
function Ze(e) {
	e.moved = !1, e.landingSite = null, e.siteDone = !1, e.consUsed = [], e.vfUsed = !1, e.end = null, e.tasks = [];
}
function Qe(e, t) {
	return e.players[t].hikers.some((e) => e < 8);
}
function $e(e) {
	return !!e.greta && e.greta.hikers.some((e) => e < 8);
}
function et(e, t) {
	for (let n of e.order) if (n !== t && e.players[n].hikers.some((e) => e < 8)) return !1;
	return !$e(e);
}
function tt(e, t) {
	return t < e.order.length ? e.order[t] : "$greta";
}
function nt(e) {
	let t = e.order.length + +!!e.greta;
	for (let n = 0; n < t * 4 + 8; n++) {
		let n = (e.turnIdx + 1) % t, r = tt(e, n);
		if (r === "$greta") {
			if (e.turnIdx = n, !$e(e)) continue;
			if (e.greta && e.greta.solo) {
				e.turn = e.order[0], e.gretaPending = !0;
				return;
			}
			xt(e, 0), We(e);
			continue;
		}
		if (Qe(e, r)) {
			e.turnIdx = n, e.turn = r, e.gretaPending = !1, Ze(e);
			return;
		}
	}
	st(e);
}
function rt(e, t) {
	e.turnIdx = e.order.indexOf(t), e.turn = t, e.gretaPending = !1, Ze(e);
}
function it(e) {
	let t = e.order[0];
	for (let n of e.order) {
		let r = e.players[n], i = e.players[t];
		(r.chaletPos > i.chaletPos || r.chaletPos === i.chaletPos && r.chaletOrder > i.chaletOrder) && (t = n);
	}
	return t;
}
function at(e) {
	let t = e.seasonAdvanced[e.season - 1], n = I([...w, ...t], e.seed, e.cursor);
	e.cursor = n.cursor, e.trailSites = n.items.slice(0, 7);
}
function ot(e) {
	let t = ae[e.seasonQueue[e.season - 1]];
	at(e);
	for (let t of e.trailBonus) G(e, t);
	let n = [null];
	for (let r of t.pattern) W(e, r), n.push(r);
	e.trailBonus = n;
	for (let t of e.parkBonus) G(e, t);
	for (let t of e.consBonus) G(e, t);
	if (e.parkBonus = e.parksDisplay.map(() => null), e.consBonus = e.consDisplay.map(() => null), t.display) {
		let n = t.display.token;
		t.display.zone === "parks" ? e.parkBonus = e.parksDisplay.map(() => (W(e, n), n)) : e.consBonus = e.consDisplay.map(() => (W(e, n), n));
	}
	let r = e.order.length, i;
	i = r <= 3 ? [t.fires[0]] : r === 4 ? [t.fires[0], t.fires[1]] : [
		t.fires[0],
		t.fires[1],
		t.fires[2]
	], e.campfires = i.filter((e) => e >= 1 && e <= 7);
}
function st(e) {
	if (e.season >= 3) {
		pt(e);
		return;
	}
	e.season += 1;
	for (let t of e.order) {
		let n = e.players[t];
		n.hikers = n.hikers.map(() => 0), n.slots = n.slots.map(() => null);
	}
	e.greta && (e.greta.hikers = e.greta.hikers.map(() => 0), e.greta.slots = e.greta.slots.map(() => null)), ot(e), rt(e, it(e));
}
function ct(e) {
	let t = {
		forest: 0,
		mountain: 0,
		sun: 0,
		water: 0,
		any: 0
	};
	for (let n of e.visited) {
		let e = ze(n.id);
		t.forest += e.forest, t.mountain += e.mountain, t.sun += e.sun, t.water += e.water, t.any += e.any;
	}
	return t;
}
function lt(e) {
	let t = 0;
	for (let n of e.wonderHand) {
		let r = C[n];
		if (r) switch (r.effect) {
			case "consForest":
				t += e.cons.filter((e) => y(e) === "forest").length;
				break;
			case "consMountain":
				t += e.cons.filter((e) => y(e) === "mountain").length;
				break;
			case "consSun":
				t += e.cons.filter((e) => y(e) === "sun").length;
				break;
			case "consWater":
				t += e.cons.filter((e) => y(e) === "water").length;
				break;
			case "iconForest":
				t += Math.floor(ct(e).forest / 3);
				break;
			case "iconMountain":
				t += Math.floor(ct(e).mountain / 3);
				break;
			case "iconSun":
				t += Math.floor(ct(e).sun / 3);
				break;
			case "iconWater":
				t += Math.floor(ct(e).water / 3);
				break;
			case "anyIcons":
				t += Math.floor(ct(e).any / 2);
				break;
			case "album":
				t += e.albums;
				break;
			case "wonderHand":
				t += e.wonderHand.length;
				break;
			case "snow": t += e.snow;
		}
	}
	return t;
}
function ut(e, t) {
	return e.chaletPos === t.chaletPos ? t.chaletOrder - e.chaletOrder : t.chaletPos - e.chaletPos;
}
function dt(e) {
	let t = 0;
	for (let n of e.visited) t += h[n.id].points;
	return t;
}
function ft(e) {
	let t = 0;
	for (let n of g) {
		let r = e.visited.filter((e) => e.suit === n).length;
		t += e.parkAwards[n] * r;
	}
	return t;
}
function pt(e) {
	e.phase = "scoring", e.tasks = [], e.moved = !1, e.landingSite = null, e.siteDone = !0, e.consUsed = [], e.vfUsed = !0, e.end = null, e.gretaPending = !1, e.scoringIdx = 0, e.turnIdx = 0, e.turn = e.order[0] ?? null, e.campfireUsed = [];
	for (let t of e.order) e.players[t].endUsed = [], e.players[t].endPoints = 0;
}
var mt = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]);
function ht(e, t, n, r) {
	let i = 0;
	for (let e of P) {
		let r = n[e] ?? 0;
		if (r > t.res[e]) return F("noRes");
		i += r;
	}
	if (i !== r) return F("noRes");
	for (let r of P) {
		let i = n[r] ?? 0;
		i !== 0 && (t.res[r] -= i, e.supply[r] += i);
	}
	return null;
}
function gt(e, t, n) {
	let r = e.players[t], i = C[n.card];
	if (!i || !mt.has(i.effect) || !r.wonderHand.includes(n.card) || e.campfireUsed.includes(n.card)) return F("badWonder");
	let a = n.pay ?? {};
	if (i.effect === "turnWildlife2") {
		if ((a.wildlife ?? 0) !== 2) return F("noRes");
		let t = ht(e, r, a, 2);
		if (t) return t;
		r.endPoints += 4;
	} else if (i.effect === "turnCarabiner") {
		if (n.carabiner !== !0 || r.carabiners < 1) return F("noCarabiner");
		--r.carabiners, e.supply.carabiner += 1, r.endPoints += 2;
	} else if (i.effect === "turnAny3") {
		let t = ht(e, r, a, 3);
		if (t) return t;
		r.endPoints += 3;
	} else {
		let n = ht(e, r, a, 2);
		if (n) return n;
		U(e, t), V(e, r, 2);
	}
	return e.campfireUsed.push(n.card), r.endUsed.push(n.card), null;
}
function _t(e) {
	let t = {}, n = [];
	for (let t of e.order) {
		let r = e.players[t], i = dt(r), a = lt(r), o = r.endPoints, s = r.photos + r.albums * 5, c = ft(r), l = r.consAwards * 5, u = r.chaletAwards.reduce((e, t) => e + t, 0), d = i + a + o + s + c + l + u;
		n.push({
			rid: t,
			parks: i,
			campfire: a,
			endgame: o,
			photos: s,
			parkAwards: c,
			cons: l,
			chalet: u,
			photoAward: 0,
			total: d
		});
	}
	let r = null;
	if (!e.solo) {
		let t = 0;
		for (let n of e.order) t = Math.max(t, e.players[n].photosTaken);
		if (t > 0) {
			let n = e.order.filter((n) => e.players[n].photosTaken === t);
			r = n[0];
			for (let t of n) ut(e.players[t], e.players[r]) < 0 && (r = t);
		}
	}
	for (let e of n) e.photoAward = e.rid === r ? 3 : 0, e.total += e.photoAward, t[e.rid] = e.total;
	let i = [...e.order].sort((n, r) => t[r] - t[n] || ut(e.players[n], e.players[r])), a = null;
	if (e.solo) {
		let n = t[e.order[0]];
		a = 0;
		for (let e of k) n >= e.at && (a = Math.max(a, e.rank));
	}
	e.final = {
		scores: t,
		ranking: i,
		winner: e.solo ? [] : [i[0]],
		soloRank: a,
		rows: n
	}, e.phase = "ended", e.tasks = [], e.end = null, e.gretaPending = !1, e.turn = null;
}
function vt(t, n, r) {
	let i = r * 2, a = [n.hikers[i], n.hikers[i + 1]].map((e, t) => ({
		pos: e,
		hiker: i + t
	})).filter((e) => e.pos < 8);
	if (a.length === 0) return;
	let o = D[e(t.seed, t.cursor++, D.length)];
	a.sort((e, t) => e.pos - t.pos);
	let s = o.ranger === "butterfly" ? a[0] : a[a.length - 1], c = o.symbols, l = s.pos, u = [];
	for (let e = l + 1; e <= 7; e++) {
		let n = Fe(t, e), r = t.campfires.includes(e);
		if ((n === 0 || r) && u.push(e), u.length >= c) break;
	}
	if (u.length < c) {
		n.hikers[s.hiker] = 8, yt(t, n, s.hiker), bt(t);
		return;
	}
	let d = u[c - 1];
	if (Fe(t, d) > 0) {
		let e = t.campfires.indexOf(d);
		e >= 0 && t.campfires.splice(e, 1);
	}
	n.hikers[s.hiker] = d, t.trailBonus[d - 1] && (G(t, t.trailBonus[d - 1]), t.trailBonus[d - 1] = null), d === 4 && U(t, null);
}
function yt(e, t, n) {
	for (let r of ue) if (!De(e, "both", r)) {
		t.slots[n] = {
			kind: "both",
			action: r
		};
		return;
	}
	for (let r of ue) if (!De(e, "top", r)) {
		t.slots[n] = {
			kind: "top",
			action: r
		};
		return;
	}
	t.slots[n] = { kind: "parks" };
}
function bt(e) {
	e.parksDisplay.length > 0 && (G(e, e.parkBonus[e.parkBonus.length - 1] ?? null), Ue(e, e.parksDisplay.length - 1, "parks")), e.consDisplay.length > 0 && (G(e, e.consBonus[e.consBonus.length - 1] ?? null), Ue(e, e.consDisplay.length - 1, "cons"));
}
function xt(e, t) {
	let n = e.greta;
	if (!n) return;
	let r = +(t === 1), i = n.colors >= 2 ? [r, 1 - r] : [0];
	for (let t of i) (n.hikers[t * 2] < 8 || n.hikers[t * 2 + 1] < 8) && vt(e, n, t);
}
function St(e, t, n, r, i) {
	if (r < 1 || r > 8) return F("badTarget");
	if (t.hikers[n] >= 8) return F("badHiker");
	if (r !== 8 && r <= t.hikers[n]) return F("badTarget");
	if (r === 8) return i.slot ? i.slot.kind !== "parks" && De(e, i.slot.kind, i.slot.action) ? F("full") : (t.hikers[n] = 8, t.slots[n] = i.slot, e.moved = !0, e.end = i.slot.kind === "parks" ? {
		action: null,
		topDone: !0,
		parksDone: !1
	} : {
		action: i.slot.action,
		topDone: !1,
		parksDone: i.slot.kind === "top"
	}, null) : F("badSlot");
	let a = r - 1;
	if (Fe(e, r) > 0) {
		if (i.campfire === "card") {
			let n = i.card ? t.wonderHand.indexOf(i.card) : -1;
			if (n < 0 || !C[i.card]) return F("noCampfire");
			e.wonderDiscard.push(t.wonderHand.splice(n, 1)[0]);
		} else {
			let t = e.campfires.indexOf(r);
			if (t < 0) return F("occupied");
			e.campfires.splice(t, 1);
		}
	}
	return t.hikers[n] = r, e.moved = !0, e.landingSite = r, e.siteDone = !1, e.consUsed = [], Ie(e, t, a), r === 4 && U(e, e.turn), null;
}
function Ct(e, t, n) {
	switch (n) {
		case "conservation":
			q(e, {
				t: "cons",
				free: !1
			});
			break;
		case "carabiner":
			B(e, t, 1);
			break;
		case "mug":
			q(e, { t: "mug" });
			break;
		case "chalet": Me(e, t);
	}
}
function wt(e, t, n, r) {
	if (r === "display") {
		let r = e.parksDisplay.indexOf(n);
		if (r < 0) return F("badPark");
		Ke(e, t, r);
	} else if (r === "reserve") {
		let e = t.reserved.indexOf(n);
		if (e < 0) return F("badPark");
		t.reserved.splice(e, 1);
	} else {
		if (e.parksDeck.length === 0) return F("badPark");
		n = e.parksDeck.shift();
	}
	Ve(e, t, n);
	let i = h[n];
	return i.instant && je(e, t, i.instant), null;
}
function Tt(e, t) {
	if (e.landingSite === null || e.vfUsed) return F("noVf");
	if (t.carabiners < 1) return F("noCarabiner");
	let n = e.vf[e.landingSite - 1];
	if (!n) return F("noVf");
	switch (--t.carabiners, e.supply.carabiner += 1, e.vfUsed = !0, z(e, t, 1), n) {
		case "wonder":
			H(e, t, 1);
			break;
		case "sunwater":
			R(e, t, "sun", 1), R(e, t, "water", 1);
			break;
		case "photo":
			V(e, t, 1 + +!!t.shutterbug);
			break;
		case "wildlife":
			R(e, t, "wildlife", 1);
			break;
		case "conservation":
			q(e, {
				t: "cons",
				free: !1
			});
			break;
		case "mug": q(e, { t: "mug" });
	}
	return null;
}
function Et(e, t) {
	let n = t.mug;
	if (t.mug = 0, n === 1) q(e, { t: "mug1" });
	else if (n === 2) for (let n = 0; n < 3; n++) J(e, t);
	else n >= 3 && q(e, { t: "freePark" });
}
function Dt(e, t, n, r) {
	if (C[n]) return F("badWonder");
	let i = S[n];
	if (!i) return F("badWonder");
	let a = t.wonderHand.indexOf(n);
	if (a < 0) return F("badWonder");
	let o = r === "top" ? i.top : i.bottom;
	if (o.pay && !K(e, t, o.pay)) return F("noRes");
	t.wonderHand.splice(a, 1), e.wonderDiscard.push(n);
	for (let n of o.grants) ke(e, t, n);
	return null;
}
function Ot(e, t) {
	if (t.wonderHand.length > 3) for (let n = 0; n < t.wonderHand.length - 3; n++) q(e, { t: "discardWonder" });
	t.carabiners > 3 && (e.supply.carabiner += t.carabiners - 3, t.carabiners = 3);
	let n = Te(t) - 12, r = P.reduce((e, n) => e + t.res[n], 0), i = Math.min(Math.max(0, n), r);
	for (let t = 0; t < i; t++) q(e, { t: "discardRes" });
	return e.tasks.length === 0;
}
function kt(e) {
	if (We(e), [...e.order].every((t) => e.players[t].hikers.every((e) => e === 8)) && (!e.greta || e.greta.hikers.every((e) => e === 8))) {
		st(e);
		return;
	}
	nt(e);
}
function At(e, t, n) {
	let r = e;
	if (r.phase === "ended" || r.turn === null) return F("phase");
	if (n.by !== r.turn) return F("notTurn");
	let i = r.players[n.by];
	if (!i) return F("notPlayer");
	if (r.phase === "scoring") return t.type === "campfireEnd" ? gt(r, n.by, t) ?? { state: r } : t.type === "scoringDone" ? (r.scoringIdx += 1, r.scoringIdx >= r.order.length ? _t(r) : (r.turn = r.order[r.scoringIdx], r.turnIdx = r.scoringIdx), { state: r }) : F("badAction");
	if (r.gretaPending) {
		if (t.type !== "gretaColor") return F("badAction");
		let e = r.greta;
		return !e || !e.solo ? F("badAction") : (r.gretaPending = !1, xt(r, t.first), We(r), nt(r), { state: r });
	}
	let a = r.tasks.length > 0 ? r.tasks[r.tasks.length - 1] : null;
	if (t.type === "playWonder") return Dt(r, i, t.card, t.side) ?? { state: r };
	if (t.type === "endTurn") return r.moved ? a ? F("badAction") : r.end && (!r.end.topDone || !r.end.parksDone) ? F("endIncomplete") : (Ot(r, i) && kt(r), { state: r }) : F("mustMove");
	if (!a) {
		if (t.type === "siteAction") return !r.moved || r.landingSite === null || r.siteDone ? F("badAction") : (r.siteDone = !0, Le(r, i, r.trailSites[r.landingSite - 1]), { state: r });
		if (t.type === "activateCons") return !r.moved || r.landingSite === null ? F("noConsSite") : Re(r, i, t.card) ?? { state: r };
		if (t.type === "endTop") return !r.end || r.end.topDone || !r.end.action ? F("badAction") : (r.end.topDone = !0, Ct(r, i, r.end.action), { state: r });
		if (t.type === "endParks") return !r.end || r.end.parksDone ? F("badAction") : (r.end.parksDone = !0, q(r, {
			t: "parks",
			visited: !1
		}), { state: r });
	}
	if (a) {
		if (a.t === "parks") {
			if (t.type === "reserve") {
				if (a.visited) return F("badAction");
				if (t.from === "display") {
					if (t.index === void 0 || t.index < 0 || t.index >= r.parksDisplay.length) return F("badPark");
					i.reserved.push(r.parksDisplay[t.index]), Ke(r, i, t.index);
				} else {
					if (r.parksDeck.length === 0) return F("badPark");
					i.reserved.push(r.parksDeck.shift());
				}
				return r.tasks.pop(), { state: r };
			}
			return t.type === "visit" ? qe(r, i, t.parkId) ? (a.visited = !0, { state: r }) : F("badPark") : t.type === "parksDone" ? (r.tasks.pop(), { state: r }) : F("badAction");
		}
		if (a.t === "mug") {
			if (t.type !== "mug") return F("badAction");
			if (t.act === "fill") i.mug = Math.min(3, i.mug + 1);
			else {
				if (i.mug < 1) return F("badAction");
				Et(r, i);
			}
			return r.tasks.pop(), { state: r };
		}
		if (a.t === "mug1") return t.type === "mugChoice" ? (r.tasks.pop(), t.choice === "chalet" ? Me(r, i) : q(r, {
			t: "cons",
			free: !0
		}), { state: r }) : F("badAction");
		if (a.t === "cons") return t.type === "consPick" ? Je(r, i, t.index, t.deck === !0, a.free) || (r.tasks.pop(), { state: r }) : t.type === "skip" ? (r.tasks.pop(), { state: r }) : F("badAction");
		if (a.t === "assignWild") {
			if (t.type !== "assignWild") return F("badAction");
			if (!a.suits.includes(t.suit)) return F("badSuit");
			let e = i.visited.find((e) => e.id === a.parkId && e.suit === null);
			return e ? (e.suit = t.suit, r.tasks.pop(), He(r, i), { state: r }) : F("badPark");
		}
		if (a.t === "freePark") return t.type === "freePark" ? wt(r, i, t.parkId ?? 0, t.from) || (r.tasks.pop(), { state: r }) : F("badAction");
		if (a.t === "discardRes") return t.type !== "discardRes" || i.res[t.res] <= 0 ? F("badAction") : (--i.res[t.res], r.supply[t.res] += 1, r.tasks.pop(), { state: r });
		if (a.t === "discardWonder") {
			if (t.type !== "discardWonder") return F("badAction");
			let e = i.wonderHand.indexOf(t.card);
			return e < 0 ? F("badWonder") : (r.wonderDiscard.push(i.wonderHand.splice(e, 1)[0]), r.tasks.pop(), { state: r });
		}
		return F("badAction");
	}
	return t.type === "viaFerrata" ? r.moved ? Tt(r, i) ?? { state: r } : F("mustMove") : t.type === "move" ? r.moved ? F("alreadyMoved") : t.to !== 8 && et(r, n.by) ? F("mustEnd") : St(r, i, t.hiker, t.to, t) || { state: r } : F("badAction");
}
function jt(e) {
	if (e.phase === "ended") return "none";
	if (e.phase === "scoring") return "scoring";
	if (e.gretaPending) return "gretaColor";
	if (!e.moved) return e.turn !== null && et(e, e.turn) ? "trailEnd" : "move";
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t ? t.t === "parks" ? "parks" : t.t === "mug" ? "mug" : t.t === "mug1" ? "mugChoice" : t.t === "cons" ? "cons" : t.t === "assignWild" ? "assignWild" : t.t === "freePark" ? "freePark" : t.t === "discardWonder" ? "discardWonder" : "discardRes" : "actions";
}
function Mt(e) {
	let t = (e) => e.some((e) => e !== null && e.kind === "parks");
	for (let n of e.order) if (t(e.players[n].slots)) return !0;
	return !!e.greta && t(e.greta.slots);
}
function Nt(e) {
	let t = e.tasks.length > 0 ? e.tasks[e.tasks.length - 1] : null;
	return t !== null && t.t === "cons" && t.free;
}
function Pt(e, t) {
	let n = { ...e.res };
	return {
		rid: t,
		seat: e.seat,
		res: n,
		snow: e.snow,
		carabiners: e.carabiners,
		mug: e.mug,
		photos: e.photos,
		albums: e.albums,
		photosTaken: e.photosTaken,
		visited: e.visited.map((e) => ({
			id: e.id,
			suit: e.suit
		})),
		reserved: [...e.reserved],
		cons: [...e.cons],
		parkAwards: { ...e.parkAwards },
		consAwards: e.consAwards,
		chaletAwards: [...e.chaletAwards],
		wonderCount: e.wonderHand.length,
		shutterbug: e.shutterbug,
		chaletPos: e.chaletPos,
		chaletOrder: e.chaletOrder,
		hikers: [...e.hikers],
		atEnd: e.hikers.every((e) => e === 8),
		endUsed: [...e.endUsed],
		endPoints: e.endPoints
	};
}
function Ft(e) {
	let t = (t, n) => {
		for (let r of e.order) if (e.players[r].slots.find((e) => e !== null && e.kind === t && e.action === n)) return r;
		return e.greta && e.greta.slots.some((e) => e !== null && e.kind === t && e.action === n) ? "$greta" : null;
	}, n = [];
	for (let e of ue) n.push({
		kind: "top",
		action: e,
		rid: t("top", e)
	}), n.push({
		kind: "both",
		action: e,
		rid: t("both", e)
	});
	return n;
}
var It = {
	meta: de,
	saveCompatibility: { version: "2" },
	schemas: {
		action: ve,
		publicView: Ce,
		privateView: we,
		config: N
	},
	setup(e, t, n) {
		let r = N.parse(e ?? {}), i = t.length === 1, a = i || t.length === 2 && r.greta, o = [...t], s = 0, c = I(Array.from({ length: 48 }, (e, t) => t), n, s);
		s = c.cursor;
		let l = c.items.slice(), u = l.splice(0, 3), d = I(Array.from({ length: 28 }, (e, t) => t), n, s);
		s = d.cursor;
		let f = d.items.slice(), p = f.splice(0, 3), ee = I([...re.map((e) => e.id), ...ie.map((e) => e.id)], n, s);
		s = ee.cursor;
		let m = ee.items, h = I(Array.from({ length: ae.length }, (e, t) => t), n, s);
		s = h.cursor;
		let g = h.items.slice(0, 3), _ = I(oe.slice(), n, s);
		s = _.cursor;
		let v = [
			_.items.slice(0, 3),
			_.items.slice(3, 6),
			_.items.slice(6, 9)
		], te = I(E.slice(), n, s);
		s = te.cursor;
		let ne = [], y = 0;
		for (let e = 0; e < 7; e++) ne.push(e === 3 ? null : te.items[y++]);
		let b = I(o.slice(), n, s);
		s = b.cursor;
		let x = {};
		o.forEach((e, t) => {
			let n = m.pop(), r = b.items.indexOf(e);
			x[e] = L(t, n, r);
		});
		let S = o.length >= 4 ? 2 : 1, C = {
			phase: "turn",
			season: 1,
			order: o,
			players: x,
			turnIdx: 0,
			turn: null,
			moved: !1,
			landingSite: null,
			siteDone: !1,
			consUsed: [],
			vfUsed: !1,
			end: null,
			tasks: [],
			gretaPending: !1,
			scoringIdx: 0,
			campfireUsed: [],
			trailSites: [],
			trailBonus: [
				null,
				null,
				null,
				null,
				null,
				null,
				null
			],
			campfires: [],
			vf: ne,
			seasonAdvanced: v,
			seasonQueue: g,
			parkBonus: [
				null,
				null,
				null
			],
			consBonus: [
				null,
				null,
				null
			],
			parksDeck: l,
			parksDisplay: u,
			consDeck: f,
			consDisplay: p,
			parkAwardPool: {
				lime: S,
				orange: S,
				teal: S,
				purple: S
			},
			consAwardsLeft: 5,
			chaletStacks: [[
				3,
				4,
				5
			], [
				3,
				4,
				5
			]],
			chaletClaimed: ce.map(() => !1),
			supply: {
				...O,
				carabiner: 15
			},
			wonderDeck: m,
			wonderDiscard: [],
			greta: a ? {
				solo: i,
				colors: i ? 2 : 1,
				hikers: Array(i ? 4 : 2).fill(0),
				slots: Array(i ? 4 : 2).fill(null)
			} : null,
			parkAwardsPerSuit: S,
			solo: i,
			seed: n,
			cursor: s,
			chaletSeq: o.length,
			final: null
		};
		return ot(C), rt(C, it(C)), { state: C };
	},
	reduce: At,
	viewFor(e, t) {
		let n = e, r = n.order.map((e) => Pt(n.players[e], e)), i = {
			phase: n.phase,
			season: n.season,
			turn: n.turn,
			moved: n.moved,
			pending: jt(n),
			freeCons: Nt(n),
			landingSite: n.landingSite,
			siteDone: n.siteDone,
			consUsed: [...n.consUsed],
			vfUsed: n.vfUsed,
			end: n.end ? {
				action: n.end.action,
				topDone: n.end.topDone,
				parksDone: n.end.parksDone
			} : null,
			seasonCard: ae[n.seasonQueue[n.season - 1]].id,
			order: n.order,
			players: r,
			trailSites: n.trailSites,
			trailBonus: n.trailBonus,
			campfires: n.campfires,
			vf: n.vf,
			parksDisplay: n.parksDisplay,
			parksDeck: n.parksDeck.length,
			parksBonus: n.parkBonus,
			consDisplay: n.consDisplay,
			consDeck: n.consDeck.length,
			consBonus: n.consBonus,
			consAwardsLeft: n.consAwardsLeft,
			chaletStacks: n.chaletStacks.map((e) => [...e]),
			endSlots: Ft(n),
			parksEndOccupied: Mt(n),
			greta: n.greta ? {
				hikers: [...n.greta.hikers],
				atEnd: n.greta.hikers.every((e) => e === 8),
				solo: n.greta.solo
			} : null,
			soloRanks: n.solo ? k.map((e) => ({
				at: e.at,
				rank: e.rank
			})) : null,
			revealedCampfire: n.phase === "scoring" || n.phase === "ended" ? n.order.map((e) => ({
				rid: e,
				cards: n.players[e].wonderHand.filter((e) => !!C[e])
			})) : null,
			campfireUsed: [...n.campfireUsed],
			finalRows: n.final ? n.final.rows.map((e) => ({ ...e })) : null
		}, a = n.players[t];
		return {
			public: i,
			private: {
				hand: a ? [...a.wonderHand] : [],
				isTurn: n.turn === t
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	}
}, Y = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], X = {
	mountain: 0,
	forest: 0,
	sun: 0,
	water: 0,
	wildlife: 0
}, Lt = "#4f5d4a", Rt = ["#4f5d4a", "#a4632f"], zt = /* @__PURE__ */ new Set([
	"turnWildlife2",
	"turnAny2",
	"turnCarabiner",
	"turnAny3"
]), Bt = {
	cliffs: "games.parkseurope.season.cliffs",
	swimming: "games.parkseurope.season.swimming",
	memories: "games.parkseurope.season.memories",
	sun: "games.parkseurope.season.sun",
	dreams: "games.parkseurope.season.dreams",
	joy: "games.parkseurope.season.joy",
	scouting: "games.parkseurope.season.scouting",
	growth: "games.parkseurope.season.growth",
	climbing: "games.parkseurope.season.climbing",
	caves: "games.parkseurope.season.caves",
	meadows: "games.parkseurope.season.meadows",
	ice: "games.parkseurope.season.ice"
}, Z = {
	mountain: "games.parkseurope.res.mountain",
	forest: "games.parkseurope.res.forest",
	sun: "games.parkseurope.res.sun",
	water: "games.parkseurope.res.water",
	wildlife: "games.parkseurope.res.wildlife",
	snow: "games.parkseurope.res.snow",
	any: "games.parkseurope.res.any"
}, Vt = {
	lime: "games.parkseurope.suit.lime",
	orange: "games.parkseurope.suit.orange",
	teal: "games.parkseurope.suit.teal",
	purple: "games.parkseurope.suit.purple",
	wild: "games.parkseurope.suit.wild"
}, Ht = {
	"core-forest": "games.parkseurope.site.core-forest",
	"core-sun": "games.parkseurope.site.core-sun",
	"core-mountain": "games.parkseurope.site.core-mountain",
	"core-water": "games.parkseurope.site.core-water",
	wildlife: "games.parkseurope.site.wildlife",
	carabiner: "games.parkseurope.site.carabiner",
	parks: "games.parkseurope.site.parks",
	die: "games.parkseurope.site.die",
	photo: "games.parkseurope.site.photo",
	mug: "games.parkseurope.site.mug",
	chalet: "games.parkseurope.site.chalet",
	wonder: "games.parkseurope.site.wonder",
	conservation: "games.parkseurope.site.conservation"
}, Ut = {
	"core-forest": "games.parkseurope.siteShort.core-forest",
	"core-sun": "games.parkseurope.siteShort.core-sun",
	"core-mountain": "games.parkseurope.siteShort.core-mountain",
	"core-water": "games.parkseurope.siteShort.core-water",
	wildlife: "games.parkseurope.siteShort.wildlife",
	carabiner: "games.parkseurope.siteShort.carabiner",
	parks: "games.parkseurope.siteShort.parks",
	die: "games.parkseurope.siteShort.die",
	photo: "games.parkseurope.siteShort.photo",
	mug: "games.parkseurope.siteShort.mug",
	chalet: "games.parkseurope.siteShort.chalet",
	wonder: "games.parkseurope.siteShort.wonder",
	conservation: "games.parkseurope.siteShort.conservation"
}, Wt = {
	wonder: "games.parkseurope.vfShort.wonder",
	sunwater: "games.parkseurope.vfShort.sunwater",
	photo: "games.parkseurope.vfShort.photo",
	conservation: "games.parkseurope.vfShort.conservation",
	mug: "games.parkseurope.vfShort.mug",
	wildlife: "games.parkseurope.vfShort.wildlife"
}, Gt = {
	conservation: "games.parkseurope.top.conservation",
	carabiner: "games.parkseurope.top.carabiner",
	mug: "games.parkseurope.top.mug",
	chalet: "games.parkseurope.top.chalet"
}, Kt = {
	die: "games.parkseurope.benefit.die",
	parks: "games.parkseurope.benefit.parks",
	mug: "games.parkseurope.benefit.mug",
	wonder: "games.parkseurope.benefit.wonder",
	photo: "games.parkseurope.benefit.photo",
	wildlife: "games.parkseurope.benefit.wildlife",
	carabiner: "games.parkseurope.benefit.carabiner"
}, qt = {
	snow: "games.parkseurope.res.snow",
	wonder: "games.parkseurope.site.wonder",
	mug: "games.parkseurope.site.mug",
	photo: "games.parkseurope.site.photo",
	wildlife: "games.parkseurope.res.wildlife",
	carabiner: "games.parkseurope.token.carabiner",
	die: "games.parkseurope.site.die",
	chalet: "games.parkseurope.top.chalet"
}, Jt = {
	consForest: "games.parkseurope.campfire.consForest",
	consMountain: "games.parkseurope.campfire.consMountain",
	consSun: "games.parkseurope.campfire.consSun",
	consWater: "games.parkseurope.campfire.consWater",
	iconForest: "games.parkseurope.campfire.iconForest",
	iconMountain: "games.parkseurope.campfire.iconMountain",
	iconSun: "games.parkseurope.campfire.iconSun",
	iconWater: "games.parkseurope.campfire.iconWater",
	anyIcons: "games.parkseurope.campfire.anyIcons",
	album: "games.parkseurope.campfire.album",
	wonderHand: "games.parkseurope.campfire.wonderHand",
	snow: "games.parkseurope.campfire.snow",
	turnWildlife2: "games.parkseurope.campfire.turnWildlife2",
	turnAny2: "games.parkseurope.campfire.turnAny2",
	turnCarabiner: "games.parkseurope.campfire.turnCarabiner",
	turnAny3: "games.parkseurope.campfire.turnAny3"
}, Yt = [
	"games.parkseurope.consProject.p0",
	"games.parkseurope.consProject.p1",
	"games.parkseurope.consProject.p2",
	"games.parkseurope.consProject.p3",
	"games.parkseurope.consProject.p4",
	"games.parkseurope.consProject.p5",
	"games.parkseurope.consProject.p6"
], Xt = {
	move: "games.parkseurope.pending.move",
	trailEnd: "games.parkseurope.pending.trailEnd",
	actions: "games.parkseurope.pending.actions",
	parks: "games.parkseurope.pending.parks",
	mug: "games.parkseurope.pending.mug",
	mugChoice: "games.parkseurope.pending.mugChoice",
	cons: "games.parkseurope.pending.cons",
	assignWild: "games.parkseurope.pending.assignWild",
	freePark: "games.parkseurope.pending.freePark",
	discardRes: "games.parkseurope.pending.discardRes",
	discardWonder: "games.parkseurope.pending.discardWonder",
	gretaColor: "games.parkseurope.pending.gretaColor",
	scoring: "games.parkseurope.pending.scoring",
	none: "games.parkseurope.pending.none"
}, Q = {
	mountain: "#6b7c8f",
	forest: "#3f7a4d",
	sun: "#d9a227",
	water: "#3a7ca5",
	wildlife: "#8a5a44",
	snow: "#cfe3ee",
	any: "#8b8578"
}, Zt = {
	lime: "#8fae2f",
	orange: "#d07a2e",
	teal: "#2f7d78",
	purple: "#6d5a9c",
	wild: "#7d7468"
}, Qt = {
	mountain: Q.mountain,
	forest: Q.forest,
	sun: Q.sun,
	water: Q.water,
	wildlife: Q.wildlife,
	snow: "#a9c9da",
	photo: "#b0674a",
	carabiner: "#8a7a63"
};
function $t(e, t) {
	let n = [];
	for (let r of [
		"mountain",
		"forest",
		"sun",
		"water",
		"wildlife",
		"any"
	]) {
		let i = t[r] ?? 0;
		i > 0 && n.push(`${e(Z[r])} ${i}`);
	}
	return n.join(" · ");
}
function en(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, r = 0;
	for (let e of Object.keys(t)) {
		let i = t[e] ?? 0;
		e === "wildlife" ? r = i : n[e] = i;
	}
	let i = e.res.wildlife;
	if (i < r) return !1;
	i -= r;
	let a = 0;
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a += Math.max(0, n[t] - e.res[t]);
	if (i < a) return !1;
	let o = r + a + n.mountain + n.forest + n.sun + n.water;
	return Y.reduce((t, n) => t + e.res[n], 0) - o >= n.any;
}
function tn(e, t) {
	return e(t === "photo" ? "games.parkseurope.token.photo" : t === "carabiner" ? "games.parkseurope.token.carabiner" : Z[t]);
}
function nn(e, t) {
	return t.map((t) => {
		let n = "n" in t && t.n !== void 0 ? t.n : 1;
		return t.t === "res" && t.res ? n > 1 ? `${e(Z[t.res])} ${n}` : e(Z[t.res]) : t.t === "snow" ? n > 1 ? `${e("games.parkseurope.res.snow")} ${n}` : e("games.parkseurope.res.snow") : t.t === "carabiner" ? n > 1 ? `${e("games.parkseurope.token.carabiner")} ${n}` : e("games.parkseurope.token.carabiner") : t.t === "photo" ? n > 1 ? `${e("games.parkseurope.token.photo")} ${n}` : e("games.parkseurope.token.photo") : t.t === "wonder" ? n > 1 ? `${e("games.parkseurope.site.wonder")} ${n}` : e("games.parkseurope.site.wonder") : t.t === "die" ? n > 1 ? `${e("games.parkseurope.site.die")} ${n}` : e("games.parkseurope.site.die") : t.t === "parks" ? e("games.parkseurope.benefit.parks") : t.t === "mug" ? e("games.parkseurope.benefit.mug") : t.t === "cons" ? e("games.parkseurope.top.conservation") : t.t === "chalet" ? e("games.parkseurope.top.chalet") : e("games.parkseurope.shutterbug");
	}).join("、");
}
function rn({ color: e, label: t, greta: n, avatar: r }) {
	return /* @__PURE__ */ f("span", {
		className: "pke-hiker-mark",
		style: { "--pke-mark": e },
		role: "img",
		"aria-label": t,
		title: t,
		children: n ? /* @__PURE__ */ f("i", {
			className: "pke-greta-glyph",
			"aria-hidden": !0
		}) : /* @__PURE__ */ f("img", {
			src: r,
			alt: "",
			draggable: !1
		})
	});
}
function an(e) {
	let t = e.public, n = e.private ?? {
		hand: [],
		isTurn: !1
	};
	return /* @__PURE__ */ f(on, {
		pub: t,
		hand: n.hand,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function on({ pub: e, hand: t, members: ee, myRid: m, send: _ }) {
	let v = a();
	s();
	let b = e.players.find((e) => e.rid === m), x = e.phase === "turn" && e.turn === m && !!b, re = e.phase === "scoring" && e.turn === m && !!b, [ie, ae] = n(m), [w, oe] = n(0), [T, E] = n(null), [D, le] = n(null), [ue, O] = n(null), [k, A] = n({ ...X }), [fe, pe] = n(""), [me, he] = n(""), j = e.players.find((e) => e.rid === ie) ?? e.players.find((e) => e.rid === m) ?? e.players[0], ge = (e) => ee.find((t) => t.rid === e), M = (e) => e === "$greta" ? v("games.parkseurope.greta") : ge(e)?.name ?? e, _e = (e) => e === "$greta" ? Lt : o[(ge(e)?.colorIndex ?? 0) % o.length].hex, ve = (e) => r[(ge(e)?.avatar ?? 0) % r.length], N = (t) => e.greta?.solo ? Rt[Math.floor(t / 2) % Rt.length] : Lt, ye = (e, t) => `${M(e)} · ${v("games.parkseurope.hikerLabel", { n: t + 1 })}`, be = (e, t, n) => {
		let r = ye(e, t);
		return e === "$greta" ? /* @__PURE__ */ f(rn, {
			greta: !0,
			color: N(t),
			label: r
		}, n) : /* @__PURE__ */ f(rn, {
			color: _e(e),
			avatar: ve(e),
			label: r
		}, n);
	}, xe = (t) => {
		let n = [];
		for (let r of e.players) r.hikers.forEach((e, i) => {
			e === t && n.push({
				rid: r.rid,
				hiker: i
			});
		});
		return e.greta && e.greta.hikers.forEach((e, r) => {
			e === t && n.push({
				rid: "$greta",
				hiker: r
			});
		}), n;
	}, Se = (n) => e.campfires.includes(n) || t.some((e) => !!C[e]), Ce = `${e.season}:${e.turn}:${e.moved}:${e.pending}:${b?.hikers.join(",") ?? ""}:${t.length}`;
	if (me !== Ce && (he(Ce), b)) {
		let e = b.hikers.map((e, t) => e < 8 ? t : -1).filter((e) => e >= 0);
		oe(e.includes(w) ? w : e[0] ?? 0);
	}
	let we = b ? Y.reduce((e, t) => e + b.res[t], 0) : 0, P = e.pending === "discardRes" ? "discardRes" : e.pending === "discardWonder" ? "discardWonder" : e.pending === "assignWild" ? "assignWild" : e.pending === "freePark" ? "freePark" : null, F = `${e.season}:${e.turn}:${e.pending}:${we}:${t.length}:${e.landingSite}`;
	if (F !== fe && (pe(F), P && x && E(P)), !b) return /* @__PURE__ */ f(c, {
		adaptive: !0,
		className: "pke-screen",
		children: /* @__PURE__ */ f("p", {
			className: "pke-empty",
			children: v("games.parkseurope.err.notPlayer")
		})
	});
	let I = b.hikers[w] ?? 0, L = /* @__PURE__ */ new Set();
	if (x && (e.pending === "move" || e.pending === "trailEnd")) {
		if (e.pending === "trailEnd") L.add(8);
		else if (I < 8) {
			for (let e = I + 1; e <= 7; e++) (xe(e).length === 0 || Se(e)) && L.add(e);
			L.add(8);
		}
	}
	let R = (e) => _(e), z = (e) => {
		if (L.has(e)) {
			if (e === 8) {
				E("trailEnd");
				return;
			}
			if (xe(e).length > 0) {
				le({
					hiker: w,
					to: e
				}), E("campfire");
				return;
			}
			R({
				type: "move",
				hiker: w,
				to: e
			});
		}
	}, B = "info", V;
	e.phase === "ended" || e.pending === "none" ? (B = "done", V = v("games.parkseurope.pending.none")) : re ? (B = "accent", V = v("games.parkseurope.pending.scoring")) : x ? (B = "accent", V = v(Xt[e.pending])) : V = v("games.parkseurope.waitingFor", { name: M(e.turn ?? "") });
	let H = Bt[e.seasonCard] ? v(Bt[e.seasonCard]) : e.seasonCard, U = e.landingSite === null ? null : e.vf[e.landingSite - 1], Te = x && e.pending === "actions" && !e.vfUsed && e.landingSite !== null && U !== null && b.carabiners > 0, W = e.landingSite === null ? null : e.trailSites[e.landingSite - 1], G = W ? se(W) : null, Ee = G ? b.cons.map((e, t) => ({
		id: e,
		i: t
	})).filter(({ id: t, i: n }) => y(t) === G && !e.consUsed.includes(n)) : [], De = !e.end || e.end.topDone && e.end.parksDone, K = t.filter((t) => !!C[t] && zt.has(C[t].effect) && !e.campfireUsed.includes(t)), q = Y.reduce((e, t) => e + k[t], 0), J = (e) => b.hikers[e] < 8, Oe = J(w) ? w : +!J(0), ke = /* @__PURE__ */ p("div", {
		className: "pke-actions",
		children: [/* @__PURE__ */ f("div", {
			className: "pke-actions-hikers",
			role: "group",
			"aria-label": v("games.parkseurope.chooseHiker"),
			children: [0, 1].map((t) => {
				let n = t, r = b.hikers[n];
				return /* @__PURE__ */ p("button", {
					type: "button",
					className: "pke-hiker",
					"data-on": Oe === n && x,
					disabled: !x || r >= 8 || e.pending !== "move" && e.pending !== "trailEnd",
					"aria-pressed": Oe === n,
					onClick: () => oe(n),
					children: [/* @__PURE__ */ f("b", { children: v("games.parkseurope.hikerLabel", { n: t + 1 }) }), /* @__PURE__ */ f("span", { children: r >= 8 ? v("games.parkseurope.atEnd") : r === 0 ? v("games.parkseurope.trailStart") : v("games.parkseurope.siteNo", { n: r }) })]
				}, n);
			})
		}), /* @__PURE__ */ f("div", {
			className: "pke-actions-main",
			children: e.pending === "gretaColor" ? /* @__PURE__ */ f(d, { children: [0, 1].map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => R({
					type: "gretaColor",
					first: e
				}),
				children: [/* @__PURE__ */ f("i", {
					className: "pke-pair-dot",
					style: { background: Rt[e] },
					"aria-hidden": !0
				}), v(e === 0 ? "games.parkseurope.gretaPairA" : "games.parkseurope.gretaPairB")]
			}, e)) }) : e.phase === "scoring" ? re ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => E("scoring"),
				children: v("games.parkseurope.scoringTitle")
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => {
					R({ type: "scoringDone" }), E(null), O(null), A({ ...X });
				},
				children: v("games.parkseurope.scoringDone")
			})] }) : /* @__PURE__ */ f("p", {
				className: "pke-actions-wait",
				children: v("games.parkseurope.waitingFor", { name: M(e.turn ?? "") })
			}) : x ? e.pending === "move" || e.pending === "trailEnd" ? /* @__PURE__ */ f("p", {
				className: "pke-actions-wait",
				children: v(e.pending === "trailEnd" ? "games.parkseurope.pending.trailEnd" : "games.parkseurope.pending.move")
			}) : e.pending === "parks" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => R({
					type: "reserve",
					from: "deck"
				}),
				children: [
					v("games.parkseurope.reserve"),
					" · ",
					v("games.parkseurope.startDeck")
				]
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => R({ type: "parksDone" }),
				children: [
					v("games.parkseurope.pending.parks"),
					" · ",
					v("games.parkseurope.skip")
				]
			})] }) : e.pending === "mug" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				disabled: b.mug >= 3,
				onClick: () => R({
					type: "mug",
					act: "fill"
				}),
				children: v("games.parkseurope.mug.fill")
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				disabled: b.mug < 1,
				onClick: () => R({
					type: "mug",
					act: "drink"
				}),
				children: v("games.parkseurope.mug.drink")
			})] }) : e.pending === "mugChoice" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => R({
					type: "mugChoice",
					choice: "chalet"
				}),
				children: v("games.parkseurope.mug.chalet")
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => R({
					type: "mugChoice",
					choice: "cons"
				}),
				children: v("games.parkseurope.mug.cons")
			})] }) : e.pending === "cons" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => R({
					type: "consPick",
					deck: !0
				}),
				children: [
					v("games.parkseurope.startDeck"),
					" · ",
					e.freeCons ? v("games.parkseurope.free") : v("games.parkseurope.deckCost")
				]
			}), /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--quiet",
				onClick: () => R({ type: "skip" }),
				children: v("games.parkseurope.skip")
			})] }) : e.pending === "assignWild" ? /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("assignWild"),
				children: v("games.parkseurope.assignWildPrompt")
			}) : e.pending === "freePark" ? /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("freePark"),
				children: v("games.parkseurope.freeParkPrompt")
			}) : e.pending === "discardRes" ? /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("discardRes"),
				children: v("games.parkseurope.discardResPrompt")
			}) : e.pending === "discardWonder" ? /* @__PURE__ */ f("button", {
				type: "button",
				className: "pke-btn pke-btn--main",
				onClick: () => E("discardWonder"),
				children: v("games.parkseurope.discardWonderPrompt")
			}) : /* @__PURE__ */ p(d, { children: [
				e.end?.action && !e.end.topDone && /* @__PURE__ */ p("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => R({ type: "endTop" }),
					children: [
						v("games.parkseurope.endTop"),
						" · ",
						v(Gt[e.end.action])
					]
				}),
				e.end && !e.end.parksDone && /* @__PURE__ */ f("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => R({ type: "endParks" }),
					children: v("games.parkseurope.endParksTodo")
				}),
				W && !e.siteDone && /* @__PURE__ */ p("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					onClick: () => R({ type: "siteAction" }),
					children: [
						v("games.parkseurope.siteAction"),
						" · ",
						v(Ut[W])
					]
				}),
				Ee.length > 0 && /* @__PURE__ */ f("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					onClick: () => E("activateCons"),
					children: v("games.parkseurope.activateCons")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "pke-btn pke-btn--quiet",
					disabled: !Te,
					onClick: () => R({ type: "viaFerrata" }),
					children: [v("games.parkseurope.viaFerrata"), U ? ` · ${v(Wt[U])}` : ""]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "pke-btn pke-btn--main",
					disabled: !De,
					onClick: () => R({ type: "endTurn" }),
					children: v("games.parkseurope.endTurn")
				})
			] }) : /* @__PURE__ */ f("p", {
				className: "pke-actions-wait",
				children: v("games.parkseurope.waitingFor", { name: M(e.turn ?? "") })
			})
		})]
	});
	return /* @__PURE__ */ p(c, {
		adaptive: !0,
		className: "pke-screen",
		actionsHeight: "pke-actions-slot",
		actions: ke,
		banner: /* @__PURE__ */ p("div", {
			className: "pke-banner",
			children: [/* @__PURE__ */ f(l, {
				tone: B,
				text: V,
				sub: v("games.parkseurope.seasonCard", { name: H }),
				chip: v("games.parkseurope.seasonLabel", { n: e.season }),
				accent: de.accent
			}), /* @__PURE__ */ f(u, {
				members: ee.filter((t) => e.players.some((e) => e.rid === t.rid)),
				myRid: m,
				variant: "medal",
				picked: (e) => e === ie,
				onPick: (e) => ae(e),
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ f("span", {
						className: "pke-seat-status",
						children: v("games.parkseurope.visitedCount", { n: n.visited.length })
					}) : null;
				},
				action: (t) => e.turn === t && e.phase === "turn" ? "pending" : null
			})]
		}),
		children: [
			/* @__PURE__ */ p("div", {
				className: "pke-layout",
				children: [
					/* @__PURE__ */ p("section", {
						className: "pke-trail-section",
						children: [
							/* @__PURE__ */ p("header", {
								className: "pke-section-head",
								children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.trail") }), /* @__PURE__ */ f("span", {
									className: "pke-sub",
									children: H
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "pke-trail",
								children: [
									/* @__PURE__ */ f("div", {
										className: "pke-trail-start",
										children: v("games.parkseurope.trailStart")
									}),
									e.trailSites.map((t, n) => {
										let r = n + 1, i = L.has(r), a = xe(r), o = e.trailBonus[n];
										return /* @__PURE__ */ p("button", {
											type: "button",
											className: "pke-site",
											"data-kind": t,
											"data-legal": i,
											"data-core": t.startsWith("core-"),
											"aria-disabled": !i,
											"aria-label": `${v("games.parkseurope.siteNo", { n: r })} ${v(Ht[t])}`,
											onClick: () => z(r),
											children: [
												e.vf[n] && /* @__PURE__ */ f("span", {
													className: "pke-vf",
													"data-kind": e.vf[n],
													children: v(Wt[e.vf[n]])
												}),
												/* @__PURE__ */ p("span", {
													className: "pke-site-head",
													children: [/* @__PURE__ */ f("b", {
														className: "pke-site-no",
														children: r
													}), /* @__PURE__ */ f("span", {
														className: "pke-site-name",
														children: v(Ut[t])
													})]
												}),
												r === 4 && /* @__PURE__ */ f("span", {
													className: "pke-shutterbug-badge",
													children: v("games.parkseurope.shutterbug")
												}),
												/* @__PURE__ */ p("span", {
													className: "pke-site-extras",
													children: [o && /* @__PURE__ */ f("i", {
														className: "pke-token",
														"data-token": o,
														style: { background: Qt[o] },
														title: tn(v, o)
													}), e.campfires.includes(r) && /* @__PURE__ */ f("span", {
														className: "pke-campfire",
														children: v("games.parkseurope.campfireLabel")
													})]
												}),
												/* @__PURE__ */ f("span", {
													className: "pke-site-hikers",
													children: a.map((e) => be(e.rid, e.hiker, `${e.rid}:${e.hiker}`))
												})
											]
										}, r);
									}),
									/* @__PURE__ */ p("button", {
										type: "button",
										className: "pke-trail-end",
										"data-legal": L.has(8),
										"aria-disabled": !L.has(8),
										onClick: () => L.has(8) ? E("trailEnd") : void 0,
										children: [
											/* @__PURE__ */ f("b", { children: v("games.parkseurope.trailEnd") }),
											/* @__PURE__ */ f("span", {
												className: "pke-end-slots",
												children: e.endSlots.map((e, t) => /* @__PURE__ */ f("span", {
													className: "pke-end-slot",
													"data-kind": e.kind,
													"aria-label": `${v(e.kind === "both" ? "games.parkseurope.slotBoth" : "games.parkseurope.slotTop")} · ${v(Gt[e.action])}${e.rid ? ` · ${M(e.rid)}` : ""}`,
													title: e.rid ? M(e.rid) : v(Gt[e.action]),
													children: e.rid && (e.rid === "$greta" ? /* @__PURE__ */ f(rn, {
														greta: !0,
														color: Lt,
														label: M(e.rid)
													}) : /* @__PURE__ */ f(rn, {
														color: _e(e.rid),
														avatar: ve(e.rid),
														label: M(e.rid)
													}))
												}, t))
											}),
											/* @__PURE__ */ f("span", {
												className: "pke-sub",
												children: e.players.reduce((e, t) => e + t.hikers.filter((e) => e === 8).length, 0) + (e.greta?.hikers.filter((e) => e === 8).length ?? 0)
											})
										]
									})
								]
							}),
							e.greta && /* @__PURE__ */ p("div", {
								className: "pke-greta",
								children: [/* @__PURE__ */ f("span", {
									className: "pke-greta-name",
									children: v("games.parkseurope.greta")
								}), e.greta.hikers.map((e, t) => /* @__PURE__ */ p("span", {
									className: "pke-greta-hiker",
									style: { borderColor: N(t) },
									title: ye("$greta", t),
									children: [/* @__PURE__ */ f("i", {
										className: "pke-pair-dot",
										style: { background: N(t) },
										"aria-hidden": !0
									}), e === 8 ? v("games.parkseurope.atEnd") : e === 0 ? v("games.parkseurope.trailStart") : v("games.parkseurope.siteNo", { n: e })]
								}, t))]
							})
						]
					}),
					e.phase === "scoring" && e.revealedCampfire && /* @__PURE__ */ p("section", {
						className: "pke-panel pke-scoring",
						children: [/* @__PURE__ */ p("header", {
							className: "pke-section-head",
							children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.scoringTitle") }), /* @__PURE__ */ f("span", {
								className: "pke-sub",
								children: v("games.parkseurope.scoringPrompt")
							})]
						}), /* @__PURE__ */ f("ul", {
							className: "pke-scoring-list",
							children: e.revealedCampfire.map(({ rid: t, cards: n }) => {
								let r = e.players.find((e) => e.rid === t);
								return /* @__PURE__ */ p("li", {
									"data-on": e.turn === t,
									children: [
										/* @__PURE__ */ f("b", { children: M(t) }),
										/* @__PURE__ */ f("span", { children: n.length === 0 ? v("games.parkseurope.scoringEmpty") : n.map((t) => {
											let n = C[t]?.effect, r = e.campfireUsed.includes(t);
											return `${n ? v(Jt[n]) : t}${r ? ` · ${v("games.parkseurope.scoringUsed")}` : ""}`;
										}).join("、") }),
										/* @__PURE__ */ f("span", {
											className: "pke-scoring-points",
											children: v("games.parkseurope.over.endgame", { n: r?.endPoints ?? 0 })
										})
									]
								}, t);
							})
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "pke-boards",
						children: [
							/* @__PURE__ */ p("section", {
								className: "pke-panel pke-parks",
								children: [
									/* @__PURE__ */ p("header", {
										className: "pke-section-head",
										children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.parksTitle") }), /* @__PURE__ */ f("span", {
											className: "pke-sub",
											children: v("games.parkseurope.deckCount", { n: e.parksDeck })
										})]
									}),
									/* @__PURE__ */ f("div", {
										className: "pke-card-row",
										children: e.parksDisplay.map((t, n) => {
											let r = h[t];
											if (!r) return null;
											let i = e.parksBonus[n] ?? null, a = en(b, r.cost), o = x && e.pending === "parks" && a;
											return /* @__PURE__ */ p("article", {
												className: "pke-park",
												"data-suit": r.suit,
												style: { "--pke-suit": Zt[r.suit] },
												children: [
													/* @__PURE__ */ p("header", {
														className: "pke-park-head",
														children: [/* @__PURE__ */ f("span", {
															className: "pke-park-name",
															title: r.name,
															children: r.name
														}), /* @__PURE__ */ f("span", {
															className: "pke-points",
															children: v("games.parkseurope.points", { n: r.points })
														})]
													}),
													/* @__PURE__ */ f("p", {
														className: "pke-cost",
														children: $t(v, r.cost)
													}),
													/* @__PURE__ */ f("p", {
														className: "pke-instant",
														children: r.instant ? v(qt[r.instant]) : v(Vt[r.suit])
													}),
													i && /* @__PURE__ */ f("i", {
														className: "pke-token",
														"data-token": i,
														style: { background: Qt[i] },
														title: tn(v, i)
													}),
													x && e.pending === "parks" && /* @__PURE__ */ p("span", {
														className: "pke-card-actions",
														children: [/* @__PURE__ */ f("button", {
															type: "button",
															className: "pke-btn pke-btn--main",
															disabled: !o,
															onClick: () => R({
																type: "visit",
																parkId: t
															}),
															children: v(o ? "games.parkseurope.visit" : "games.parkseurope.cannotAfford")
														}), /* @__PURE__ */ f("button", {
															type: "button",
															className: "pke-btn pke-btn--quiet",
															onClick: () => R({
																type: "reserve",
																from: "display",
																index: n
															}),
															children: v("games.parkseurope.reserve")
														})]
													})
												]
											}, `${t}:${n}`);
										})
									}),
									/* @__PURE__ */ p("div", {
										className: "pke-reserved",
										children: [/* @__PURE__ */ f("h3", { children: v("games.parkseurope.reservedTitle") }), /* @__PURE__ */ p("div", {
											className: "pke-chip-list",
											children: [b.reserved.length === 0 && /* @__PURE__ */ f("span", {
												className: "pke-muted",
												children: v("games.parkseurope.noResources")
											}), b.reserved.map((t, n) => {
												let r = h[t];
												if (!r) return null;
												let i = en(b, r.cost), a = x && e.pending === "parks" && i;
												return /* @__PURE__ */ p("button", {
													type: "button",
													className: "pke-chip pke-chip--park",
													"data-suit": r.suit,
													disabled: !a,
													title: `${r.name} · ${$t(v, r.cost)}`,
													onClick: () => R({
														type: "visit",
														parkId: t
													}),
													children: [/* @__PURE__ */ f("i", { style: { background: Zt[r.suit] } }), r.name]
												}, `${t}:${n}`);
											})]
										})]
									})
								]
							}),
							/* @__PURE__ */ p("section", {
								className: "pke-panel pke-cons",
								children: [/* @__PURE__ */ p("header", {
									className: "pke-section-head",
									children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.consTitle") }), /* @__PURE__ */ f("span", {
										className: "pke-sub",
										children: v("games.parkseurope.consAwardsLabel", { n: e.consAwardsLeft })
									})]
								}), /* @__PURE__ */ f("div", {
									className: "pke-card-row",
									children: e.consDisplay.map((t, n) => {
										let r = y(t), i = ne[t % 7], a = e.consBonus[n] ?? null, o = te[r], s = e.freeCons || en(b, o), c = x && e.pending === "cons" && s;
										return /* @__PURE__ */ p("article", {
											className: "pke-cons-card",
											"data-color": r,
											style: { "--pke-res": Q[r] },
											children: [
												/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("span", { children: v(Z[r]) }), /* @__PURE__ */ f("b", { children: v(Yt[t % 7]) })] }),
												/* @__PURE__ */ f("p", { children: v(Kt[i.benefit]) }),
												/* @__PURE__ */ f("p", {
													className: "pke-cost",
													children: e.freeCons ? v("games.parkseurope.free") : $t(v, o)
												}),
												a && /* @__PURE__ */ f("i", {
													className: "pke-token",
													"data-token": a,
													style: { background: Qt[a] },
													title: tn(v, a)
												}),
												x && e.pending === "cons" && /* @__PURE__ */ f("button", {
													type: "button",
													className: "pke-btn pke-btn--main",
													disabled: !c,
													onClick: () => R({
														type: "consPick",
														index: n
													}),
													children: c ? e.freeCons ? v("games.parkseurope.free") : v("games.parkseurope.support") : v("games.parkseurope.cannotAfford")
												})
											]
										}, `${t}:${n}`);
									})
								})]
							}),
							/* @__PURE__ */ p("section", {
								className: "pke-panel pke-chalet",
								children: [/* @__PURE__ */ p("header", {
									className: "pke-section-head",
									children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.chaletTrack") }), /* @__PURE__ */ f("span", {
										className: "pke-sub",
										children: e.chaletStacks.map((e, t) => /* @__PURE__ */ p("span", {
											className: "pke-stack",
											children: [
												"[",
												e.join(" "),
												"]"
											]
										}, t))
									})]
								}), /* @__PURE__ */ f("div", {
									className: "pke-track",
									children: ce.map((t, n) => {
										let r = e.players.filter((e) => e.chaletPos === n).sort((e, t) => e.chaletOrder - t.chaletOrder), i = "";
										return t.t === "start" ? i = v("games.parkseurope.trailStart") : t.t === "wonder" ? i = v("games.parkseurope.siteShort.wonder") : t.t === "end" ? i = v("games.parkseurope.trailEnd") : t.t === "award" && (i = t.stack === null ? e.greta?.solo ? String(t.solo) : "✦" : String(e.chaletStacks[t.stack][e.chaletStacks[t.stack].length - 1] ?? "·")), /* @__PURE__ */ p("div", {
											className: "pke-track-space",
											"data-t": t.t,
											children: [/* @__PURE__ */ f("span", {
												className: "pke-track-label",
												children: i
											}), /* @__PURE__ */ f("span", {
												className: "pke-track-tokens",
												children: r.map((e) => /* @__PURE__ */ f(rn, {
													color: _e(e.rid),
													avatar: ve(e.rid),
													label: M(e.rid)
												}, e.rid))
											})]
										}, n);
									})
								})]
							}),
							/* @__PURE__ */ p("section", {
								className: "pke-panel pke-mat",
								children: [/* @__PURE__ */ p("header", {
									className: "pke-section-head",
									children: [/* @__PURE__ */ f("h2", { children: j.rid === m ? v("games.parkseurope.myMat") : v("games.parkseurope.otherMat", { name: M(j.rid) }) }), j.shutterbug && /* @__PURE__ */ f("span", {
										className: "pke-badge",
										children: v("games.parkseurope.shutterbug")
									})]
								}), /* @__PURE__ */ f(sn, {
									p: j,
									t: v,
									name: M(j.rid)
								})]
							}),
							/* @__PURE__ */ p("section", {
								className: "pke-panel pke-hand",
								children: [
									/* @__PURE__ */ p("header", {
										className: "pke-section-head",
										children: [/* @__PURE__ */ f("h2", { children: v("games.parkseurope.handTitle") }), /* @__PURE__ */ f("span", {
											className: "pke-sub",
											children: t.length
										})]
									}),
									t.length === 0 ? /* @__PURE__ */ f("p", {
										className: "pke-muted",
										children: v("games.parkseurope.handEmpty")
									}) : /* @__PURE__ */ f("div", {
										className: "pke-hand-row",
										children: t.map((e, t) => {
											let n = S[e], r = C[e];
											return r ? /* @__PURE__ */ p("article", {
												className: "pke-wonder pke-wonder--camp",
												children: [
													/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("b", { children: v("games.parkseurope.wonder.campfireCard") }), /* @__PURE__ */ p("span", { children: ["#", r.no] })] }),
													/* @__PURE__ */ f("p", { children: v(Jt[r.effect]) }),
													/* @__PURE__ */ f("span", {
														className: "pke-muted",
														children: v("games.parkseurope.wonder.noPlay")
													})
												]
											}, `${e}:${t}`) : n ? /* @__PURE__ */ p("article", {
												className: "pke-wonder",
												children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("b", {
													title: n.name,
													children: n.name
												}), /* @__PURE__ */ p("span", { children: ["#", n.no] })] }), /* @__PURE__ */ f("div", {
													className: "pke-wonder-sides",
													children: ["top", "bottom"].map((t) => {
														let r = n[t], i = !r.pay || en(b, r.pay);
														return /* @__PURE__ */ p("button", {
															type: "button",
															className: "pke-wonder-side",
															disabled: !x || !i,
															onClick: () => R({
																type: "playWonder",
																card: e,
																side: t
															}),
															children: [
																/* @__PURE__ */ f("span", {
																	className: "pke-wonder-side-label",
																	children: v(t === "top" ? "games.parkseurope.wonder.top" : "games.parkseurope.wonder.bottom")
																}),
																r.pay && /* @__PURE__ */ f("span", {
																	className: "pke-cost",
																	children: v("games.parkseurope.wonder.pay", { cost: $t(v, r.pay) })
																}),
																/* @__PURE__ */ f("span", { children: v("games.parkseurope.wonder.grant", { grant: nn(v, r.grants) }) })
															]
														}, t);
													})
												})]
											}, `${e}:${t}`) : null;
										})
									}),
									e.soloRanks && /* @__PURE__ */ f("p", {
										className: "pke-solo-ranks",
										children: v("games.parkseurope.soloRankTable")
									})
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ f(i, {
				open: T === "trailEnd",
				onClose: () => E(null),
				label: v("games.parkseurope.chooseSlot"),
				title: v("games.parkseurope.chooseSlot"),
				children: /* @__PURE__ */ p("div", {
					className: "pke-slot-sheet",
					children: [["top", "both"].map((t) => /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: v(t === "top" ? "games.parkseurope.slotTop" : "games.parkseurope.slotBoth") }), /* @__PURE__ */ f("div", {
						className: "pke-slot-row",
						children: e.endSlots.filter((e) => e.kind === t).map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							className: "pke-slot",
							disabled: e.rid !== null,
							onClick: () => {
								R({
									type: "move",
									hiker: w,
									to: 8,
									slot: {
										kind: t,
										action: e.action
									}
								}), E(null);
							},
							children: [/* @__PURE__ */ f("span", { children: v(Gt[e.action]) }), /* @__PURE__ */ f("i", { children: e.rid ? M(e.rid) : v("games.parkseurope.free") })]
						}, `${e.kind}:${e.action}`))
					})] }, t)), /* @__PURE__ */ p("section", { children: [/* @__PURE__ */ f("h3", { children: v("games.parkseurope.slotParks") }), /* @__PURE__ */ f("button", {
						type: "button",
						className: "pke-slot pke-slot--parks",
						onClick: () => {
							R({
								type: "move",
								hiker: w,
								to: 8,
								slot: { kind: "parks" }
							}), E(null);
						},
						children: /* @__PURE__ */ f("span", { children: v("games.parkseurope.site.parks") })
					})] })]
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "campfire",
				onClose: () => {
					E(null), le(null);
				},
				label: v("games.parkseurope.occupiedPrompt"),
				title: v("games.parkseurope.occupiedPrompt"),
				children: /* @__PURE__ */ p("div", {
					className: "pke-choice-list",
					children: [D && e.campfires.includes(D.to) && /* @__PURE__ */ f("button", {
						type: "button",
						className: "pke-choice",
						onClick: () => {
							R({
								type: "move",
								hiker: D.hiker,
								to: D.to,
								campfire: "communal"
							}), E(null), le(null);
						},
						children: v("games.parkseurope.useCommunalCampfire")
					}), D && t.filter((e) => !!C[e]).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "pke-choice",
						onClick: () => {
							R({
								type: "move",
								hiker: D.hiker,
								to: D.to,
								campfire: "card",
								card: e
							}), E(null), le(null);
						},
						children: [
							v("games.parkseurope.useCampfireCard"),
							" · #",
							C[e]?.no
						]
					}, e))]
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "assignWild",
				onClose: () => E(null),
				label: v("games.parkseurope.assignWildPrompt"),
				title: v("games.parkseurope.assignWildPrompt"),
				children: /* @__PURE__ */ f("div", {
					className: "pke-choice-list",
					children: g.filter((e) => b.visited.some((t) => t.suit === e)).map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						className: "pke-choice",
						onClick: () => {
							R({
								type: "assignWild",
								suit: e
							}), E(null);
						},
						children: v(Vt[e])
					}, e))
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "freePark",
				onClose: () => E(null),
				label: v("games.parkseurope.freeParkPrompt"),
				title: v("games.parkseurope.freeParkPrompt"),
				children: /* @__PURE__ */ p("div", {
					className: "pke-choice-list",
					children: [
						e.parksDisplay.map((e) => {
							let t = h[e];
							return t ? /* @__PURE__ */ p("button", {
								type: "button",
								className: "pke-choice",
								onClick: () => {
									R({
										type: "freePark",
										parkId: e,
										from: "display"
									}), E(null);
								},
								children: [
									/* @__PURE__ */ f("i", { style: { background: Zt[t.suit] } }),
									" ",
									t.name
								]
							}, `d:${e}`) : null;
						}),
						b.reserved.map((e) => {
							let t = h[e];
							return t ? /* @__PURE__ */ p("button", {
								type: "button",
								className: "pke-choice",
								onClick: () => {
									R({
										type: "freePark",
										parkId: e,
										from: "reserve"
									}), E(null);
								},
								children: [
									/* @__PURE__ */ f("i", { style: { background: Zt[t.suit] } }),
									" ",
									t.name
								]
							}, `r:${e}`) : null;
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								R({
									type: "freePark",
									from: "deck"
								}), E(null);
							},
							children: v("games.parkseurope.startDeck")
						})
					]
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "discardRes",
				onClose: () => E(null),
				label: v("games.parkseurope.discardResPrompt"),
				title: v("games.parkseurope.discardResPrompt"),
				children: /* @__PURE__ */ f("div", {
					className: "pke-choice-list",
					children: Y.filter((e) => b.res[e] > 0).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "pke-choice",
						onClick: () => {
							R({
								type: "discardRes",
								res: e
							}), E(null);
						},
						children: [
							/* @__PURE__ */ f("i", { style: { background: Q[e] } }),
							" ",
							v(Z[e]),
							" · ",
							b.res[e]
						]
					}, e))
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "discardWonder",
				onClose: () => E(null),
				label: v("games.parkseurope.discardWonderPrompt"),
				title: v("games.parkseurope.discardWonderPrompt"),
				children: /* @__PURE__ */ f("div", {
					className: "pke-choice-list",
					children: t.map((e) => {
						let t = S[e], n = C[e];
						return /* @__PURE__ */ f("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								R({
									type: "discardWonder",
									card: e
								}), E(null);
							},
							children: t ? t.name : `${v("games.parkseurope.wonder.campfireCard")} #${n?.no}`
						}, e);
					})
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "scoring",
				onClose: () => {
					E(null), O(null), A({ ...X });
				},
				label: v("games.parkseurope.scoringTitle"),
				title: v("games.parkseurope.scoringTitle"),
				children: /* @__PURE__ */ p("div", {
					className: "pke-scoring-sheet",
					children: [K.length === 0 && /* @__PURE__ */ f("p", {
						className: "pke-muted",
						children: v("games.parkseurope.scoringEmpty")
					}), K.map((e) => {
						let t = C[e].effect, n = t === "turnAny3" ? 3 : t === "turnAny2" ? 2 : 0, r = ue === e;
						return /* @__PURE__ */ p("section", {
							className: "pke-scoring-card",
							"data-on": r,
							children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ p("b", { children: [
								v("games.parkseurope.wonder.campfireCard"),
								" #",
								C[e].no
							] }), /* @__PURE__ */ f("span", { children: v(Jt[t]) })] }), t === "turnWildlife2" ? /* @__PURE__ */ f("button", {
								type: "button",
								className: "pke-btn pke-btn--main",
								disabled: b.res.wildlife < 2,
								onClick: () => R({
									type: "campfireEnd",
									card: e,
									pay: { wildlife: 2 }
								}),
								children: b.res.wildlife < 2 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
							}) : t === "turnCarabiner" ? /* @__PURE__ */ f("button", {
								type: "button",
								className: "pke-btn pke-btn--main",
								disabled: b.carabiners < 1,
								onClick: () => R({
									type: "campfireEnd",
									card: e,
									carabiner: !0
								}),
								children: b.carabiners < 1 ? v("games.parkseurope.cannotAfford") : v("games.parkseurope.useEffect")
							}) : r ? /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f("div", {
									className: "pke-pay-row",
									children: Y.map((e) => /* @__PURE__ */ p("span", {
										className: "pke-pay-res",
										style: { "--pke-res": Q[e] },
										children: [
											/* @__PURE__ */ f("i", { "aria-hidden": !0 }),
											/* @__PURE__ */ f("button", {
												type: "button",
												"aria-label": `- ${v(Z[e])}`,
												disabled: k[e] <= 0,
												onClick: () => A((t) => ({
													...t,
													[e]: t[e] - 1
												})),
												children: "−"
											}),
											/* @__PURE__ */ f("b", {
												className: "font-mono tabular-nums",
												children: k[e]
											}),
											/* @__PURE__ */ f("button", {
												type: "button",
												"aria-label": `+ ${v(Z[e])}`,
												disabled: k[e] >= b.res[e] || q >= n,
												onClick: () => A((t) => ({
													...t,
													[e]: t[e] + 1
												})),
												children: "+"
											}),
											/* @__PURE__ */ f("span", {
												className: "pke-sub",
												children: b.res[e]
											})
										]
									}, e))
								}),
								/* @__PURE__ */ p("p", {
									className: "pke-sub",
									children: [
										v("games.parkseurope.scoringPayPrompt", { n }),
										" · ",
										v("games.parkseurope.scoringPayChosen", { n: q })
									]
								}),
								/* @__PURE__ */ p("div", {
									className: "pke-scoring-actions",
									children: [/* @__PURE__ */ f("button", {
										type: "button",
										className: "pke-btn pke-btn--main",
										disabled: q !== n,
										onClick: () => {
											R({
												type: "campfireEnd",
												card: e,
												pay: { ...k }
											}), O(null), A({ ...X });
										},
										children: v("games.parkseurope.scoringPayConfirm")
									}), /* @__PURE__ */ f("button", {
										type: "button",
										className: "pke-btn pke-btn--quiet",
										onClick: () => {
											O(null), A({ ...X });
										},
										children: v("games.parkseurope.scoringPayReset")
									})]
								})
							] }) : /* @__PURE__ */ f("button", {
								type: "button",
								className: "pke-btn pke-btn--quiet",
								onClick: () => {
									O(e), A({ ...X });
								},
								children: v("games.parkseurope.useEffect")
							})]
						}, e);
					})]
				})
			}),
			/* @__PURE__ */ f(i, {
				open: T === "activateCons",
				onClose: () => E(null),
				label: v("games.parkseurope.activateConsPrompt"),
				title: v("games.parkseurope.activateConsPrompt"),
				children: /* @__PURE__ */ p("div", {
					className: "pke-choice-list",
					children: [Ee.length === 0 && /* @__PURE__ */ f("p", {
						className: "pke-muted",
						children: v("games.parkseurope.activateConsEmpty")
					}), Ee.map(({ id: e, i: t }) => {
						let n = y(e);
						return /* @__PURE__ */ p("button", {
							type: "button",
							className: "pke-choice",
							onClick: () => {
								R({
									type: "activateCons",
									card: t
								}), E(null);
							},
							children: [
								/* @__PURE__ */ f("i", {
									style: { background: Q[n] },
									"aria-hidden": !0
								}),
								" ",
								v(Kt[ne[e % 7].benefit])
							]
						}, t);
					})]
				})
			})
		]
	});
}
function sn({ p: e, t, name: n }) {
	let r = [...g, "wild"].map((t) => ({
		suit: t,
		ids: e.visited.filter((e) => (e.suit ?? "wild") === t).map((e) => e.id)
	})), i = g.reduce((t, n) => t + e.parkAwards[n], 0) + e.consAwards + e.chaletAwards.length, a = e.mug === 0 ? t("games.parkseurope.noResources") : t("games.parkseurope.mug.level", { n: e.mug });
	return /* @__PURE__ */ p("div", {
		className: "pke-mat-body",
		"aria-label": n,
		children: [
			/* @__PURE__ */ p("div", {
				className: "pke-res-row",
				children: [
					Y.map((n) => /* @__PURE__ */ p("span", {
						className: "pke-res",
						style: { "--pke-res": Q[n] },
						title: t(Z[n]),
						children: [/* @__PURE__ */ f("i", {}), /* @__PURE__ */ f("b", {
							className: "font-mono tabular-nums",
							children: e.res[n]
						})]
					}, n)),
					/* @__PURE__ */ p("span", {
						className: "pke-res",
						style: { "--pke-res": Q.snow },
						title: t("games.parkseurope.res.snow"),
						children: [/* @__PURE__ */ f("i", {}), /* @__PURE__ */ f("b", {
							className: "font-mono tabular-nums",
							children: e.snow
						})]
					}),
					/* @__PURE__ */ p("span", {
						className: "pke-res",
						style: { "--pke-res": Qt.carabiner },
						title: t("games.parkseurope.token.carabiner"),
						children: [/* @__PURE__ */ f("i", {}), /* @__PURE__ */ f("b", {
							className: "font-mono tabular-nums",
							children: e.carabiners
						})]
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "pke-stat-row",
				children: [
					/* @__PURE__ */ f("span", { children: t("games.parkseurope.photos", { n: e.photos }) }),
					/* @__PURE__ */ f("span", { children: t("games.parkseurope.albums", { n: e.albums }) }),
					/* @__PURE__ */ f("span", { children: t("games.parkseurope.awards", { n: i }) }),
					/* @__PURE__ */ f("span", { children: t("games.parkseurope.chaletPos", { n: e.chaletPos }) })
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "pke-award-row",
				children: [
					g.map((n) => /* @__PURE__ */ p("span", {
						className: "pke-award",
						"data-on": e.parkAwards[n] > 0,
						style: { "--pke-suit": Zt[n] },
						children: [
							t(Vt[n]),
							" ",
							/* @__PURE__ */ f("b", {
								className: "font-mono tabular-nums",
								children: e.parkAwards[n]
							})
						]
					}, n)),
					/* @__PURE__ */ f("span", {
						className: "pke-award",
						"data-on": e.consAwards > 0,
						children: t("games.parkseurope.consAwardsLabel", { n: e.consAwards })
					}),
					e.chaletAwards.map((e, t) => /* @__PURE__ */ f("span", {
						className: "pke-award",
						"data-on": !0,
						children: e
					}, t))
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "pke-mug-row",
				children: [
					/* @__PURE__ */ f("span", { children: t("games.parkseurope.mug.track") }),
					[
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ f("i", {
						className: "pke-mug-pip",
						"data-on": e.mug >= t
					}, t)),
					/* @__PURE__ */ f("span", {
						className: "pke-sub",
						children: a
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "pke-mat-groups",
				children: [r.map((e) => e.ids.length > 0 && /* @__PURE__ */ p("div", {
					className: "pke-mat-group",
					children: [/* @__PURE__ */ p("h3", {
						style: { color: Zt[e.suit] },
						children: [
							t(Vt[e.suit]),
							" · ",
							e.ids.length
						]
					}), /* @__PURE__ */ f("p", { children: e.ids.map((e) => h[e]?.name).filter(Boolean).join("、") })]
				}, e.suit)), e.visited.length === 0 && /* @__PURE__ */ f("p", {
					className: "pke-muted",
					children: t("games.parkseurope.noResources")
				})]
			}),
			e.cons.length > 0 && /* @__PURE__ */ p("div", {
				className: "pke-mat-group",
				children: [/* @__PURE__ */ p("h3", { children: [
					t("games.parkseurope.consTitle"),
					" · ",
					e.cons.length
				] }), /* @__PURE__ */ f("p", { children: e.cons.map((e) => `${t(Z[y(e)])} ${t(Yt[e % 7])}`).join("、") })]
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var cn = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], $ = {
	mountain: 1.1,
	forest: 1,
	sun: .9,
	water: .9,
	wildlife: 1.4
}, ln = {
	parks: 4.2,
	mug: 2.8,
	photo: 1.4,
	die: 1.6,
	wonder: 1.6,
	wildlife: 1.2,
	carabiner: 1.3
}, un = {
	conservation: 2.8,
	mug: 2.8,
	chalet: 1.6,
	carabiner: 1.4
}, dn = {
	wonder: 1.6,
	sunwater: 1.7,
	photo: 1.7,
	conservation: 2.2,
	mug: 2.4,
	wildlife: 1.2
}, fn = {
	album: 3,
	wonderHand: 2,
	turnAny2: 3,
	turnAny3: 3,
	turnWildlife2: 1,
	turnCarabiner: 2,
	anyIcons: 2,
	consForest: 1.5,
	consMountain: 1.5,
	consSun: 1.5,
	consWater: 1.5,
	iconForest: 1.5,
	iconMountain: 1.5,
	iconSun: 1.5,
	iconWater: 1.5,
	snow: 1
};
function pn() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function mn(e, t) {
	return t && e.length > 1 && pn() < .3 ? e[Math.floor(pn() * e.length)] : e[0];
}
function hn(e) {
	return e.sort((e, t) => t.score - e.score);
}
function gn(e, t) {
	return e.players.find((e) => e.rid === t);
}
function _n(e, t) {
	let n = 0;
	for (let r of e.players) for (let e of r.hikers) e === t && (n += 1);
	if (e.greta) for (let r of e.greta.hikers) r === t && (n += 1);
	return n;
}
function vn(e, t) {
	let n = {
		mountain: 0,
		forest: 0,
		sun: 0,
		water: 0,
		any: 0
	}, r = 0;
	for (let e of Object.keys(t)) {
		let i = t[e] ?? 0;
		e === "wildlife" ? r = i : n[e] = i;
	}
	if (e.res.wildlife < r) return !1;
	let i = e.res.wildlife - r, a = 0;
	for (let t of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) a += Math.max(0, n[t] - e.res[t]);
	if (i < a) return !1;
	let o = n.mountain + n.forest + n.sun + n.water + r + a;
	return cn.reduce((t, n) => t + e.res[n], 0) - o >= n.any;
}
function yn(e) {
	let t = 0;
	for (let n of Object.keys(e)) {
		let r = e[n] ?? 0;
		t += n === "any" ? r * 1 : n === "wildlife" ? r * 1.3 : r * $[n];
	}
	return t;
}
function bn(e) {
	return e ? e === "photo" ? 1.2 : e === "carabiner" ? 1.3 : e === "snow" ? .7 : $[e] : 0;
}
function xn(e, t) {
	return t === null ? null : e.vf[t - 1] ?? null;
}
function Sn(e, t) {
	let n = e.visited.filter((e) => e.suit === t).length;
	return n % 3 == 2 ? 2.2 : n % 3 == 1 ? .4 : 0;
}
function Cn(e, t) {
	let n = h[t];
	if (!n) return 0;
	let r = n.points;
	if (n.instant) {
		let t = n.instant;
		r += t === "photo" ? e.shutterbug ? 2 : 1 : t === "mug" ? 2.2 : t === "wonder" ? 1.3 : t === "chalet" || t === "die" ? 1.2 : t === "carabiner" ? 1 : t === "wildlife" ? .8 : .6;
	}
	if (n.suit === "wild") {
		let t = g.reduce((t, n) => Math.max(t, Sn(e, n)), 0);
		r += t;
	} else r += Sn(e, n.suit);
	return r;
}
function wn(e, t, n) {
	switch (e) {
		case "core-forest": return $.forest;
		case "core-sun": return $.sun * 2;
		case "core-mountain": return $.mountain + .7;
		case "core-water": return $.water * 2 + .7;
		case "wildlife": return $.wildlife;
		case "carabiner": return 1.6;
		case "parks": return 4.2;
		case "die": return 1.7;
		case "photo": return t.shutterbug ? 2.4 : 1.4;
		case "mug": return t.mug >= 3 ? 3.4 : 2.6;
		case "chalet": return .6 + t.snow * 1;
		case "wonder": return 1.6;
		case "conservation": {
			let e = [...new Set(t.cons.map((e) => y(e)))];
			return 2.6 + (n.consAwardsLeft > 0 && e.length < 4 ? .7 : 0);
		}
	}
}
function Tn(e) {
	return e.filter((e) => !!S[e]);
}
function En(e, t, n) {
	let r = S[t];
	if (!r) return null;
	let i = r[n];
	if (i.pay && !vn(e, i.pay)) return null;
	let a = 0;
	for (let t of i.grants) switch (t.t) {
		case "res":
			a += $[t.res] * t.n;
			break;
		case "snow":
			a += .7 * t.n;
			break;
		case "carabiner":
			a += 1.3 * t.n;
			break;
		case "photo":
			a += (e.shutterbug ? 1.8 : 1.1) * t.n;
			break;
		case "wonder":
			a += 1.5 * t.n;
			break;
		case "die":
			a += 1.6 * t.n;
			break;
		case "parks":
			a += 4.2;
			break;
		case "mug":
			a += 2.6;
			break;
		case "cons":
			a += 2.6;
			break;
		case "chalet":
			a += .6 + e.snow;
			break;
		case "shutterbug": a += e.shutterbug ? .8 : 2.4;
	}
	return a - (i.pay ? yn(i.pay) : 0);
}
function Dn(e, t) {
	let n = un[e];
	return t ? n + 4.2 : n;
}
function On(e) {
	let t = [];
	for (let n of e.endSlots) n.rid === null && t.push({
		v: {
			kind: n.kind,
			action: n.action
		},
		score: Dn(n.action, n.kind === "both")
	});
	return t.push({
		v: { kind: "parks" },
		score: 4.2
	}), hn(t), t[0].v;
}
function kn(e, t, n) {
	let r = [], i = new Set(e.cons.map((e) => y(e)));
	return t.consDisplay.forEach((t, a) => {
		let o = y(t), s = n ? {} : te[o];
		if (!n && !vn(e, s)) return;
		let c = ln[An(t)];
		i.has(o) || (c += 1.6), c -= yn(s) * .2, r.push({
			v: {
				type: "consPick",
				index: a
			},
			score: c
		});
	}), r.length > 0 ? (hn(r), r[0].v) : t.consDeck > 0 && (n || vn(e, {
		sun: 1,
		water: 1
	})) ? {
		type: "consPick",
		deck: !0
	} : { type: "skip" };
}
function An(e) {
	return [
		"die",
		"parks",
		"mug",
		"wonder",
		"photo",
		"wildlife",
		"carabiner"
	][e % 7];
}
function jn(e, t) {
	let n = [];
	for (let r of t.parksDisplay) n.push({
		v: {
			type: "freePark",
			parkId: r,
			from: "display"
		},
		score: Cn(e, r)
	});
	for (let t of e.reserved) n.push({
		v: {
			type: "freePark",
			parkId: t,
			from: "reserve"
		},
		score: Cn(e, t)
	});
	return n.length > 0 ? (hn(n), n[0].v) : {
		type: "freePark",
		from: "deck"
	};
}
function Mn(e, t, n, r) {
	let i = [];
	for (let r of [0, 1]) {
		let a = t.hikers[r];
		if (!(a >= 8)) for (let o = a + 1; o <= 7; o++) {
			let a = _n(e, o) > 0, s = null, c;
			if (a) {
				if (e.campfires.includes(o)) s = "communal";
				else {
					let e = n.filter((e) => !!C[e]);
					if (e.length === 0) continue;
					s = "card", c = e[0];
				}
			}
			let l = wn(e.trailSites[o - 1], t, e);
			l += bn(e.trailBonus[o - 1]), o === 4 && (l += 1);
			let u = xn(e, o);
			u && t.carabiners > 0 && (l += dn[u] + .7 - 1.2), s === "communal" ? l -= 2 : s === "card" && (l -= 2.5);
			let d = {
				type: "move",
				hiker: r,
				to: o
			};
			s && (d.campfire = s), c && (d.card = c), i.push({
				v: d,
				score: l
			});
		}
	}
	return i.length > 0 ? mn(hn(i).map((e) => e.v), r) : {
		type: "move",
		hiker: [0, 1].find((e) => t.hikers[e] < 8) ?? 0,
		to: 8,
		slot: On(e)
	};
}
function Nn(e) {
	return {
		type: "discardRes",
		res: [...cn].sort((t, n) => e.res[n] - e.res[t])[0]
	};
}
function Pn(e, t) {
	let n = [
		"sun",
		"water",
		"forest",
		"mountain",
		"wildlife"
	], r = {}, i = t;
	for (let t of n) {
		let n = Math.min(i, e.res[t]);
		if (n > 0 && (r[t] = n, i -= n), i === 0) return r;
	}
	return null;
}
function Fn(e, t, n) {
	let r = new Set(e.campfireUsed), i = n.filter((e) => !!C[e] && !r.has(e)), a = (e) => C[e].effect;
	for (let e of i) if (a(e) === "turnWildlife2" && t.res.wildlife >= 2) return {
		type: "campfireEnd",
		card: e,
		pay: { wildlife: 2 }
	};
	for (let e of i) if (a(e) === "turnCarabiner" && t.carabiners >= 1) return {
		type: "campfireEnd",
		card: e,
		carabiner: !0
	};
	for (let e of i) {
		if (a(e) !== "turnAny3") continue;
		let n = Pn(t, 3);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	for (let e of i) {
		if (a(e) !== "turnAny2") continue;
		let n = Pn(t, 2);
		if (n) return {
			type: "campfireEnd",
			card: e,
			pay: n
		};
	}
	return { type: "scoringDone" };
}
function In(e, t) {
	let n = t.filter((e) => !!S[e]);
	if (n.length > 0) {
		let t = n[0], r = Infinity;
		for (let i of n) {
			let n = En(e, i, "top") ?? -Infinity, a = En(e, i, "bottom") ?? -Infinity, o = Math.max(n, a);
			o < r && (r = o, t = i);
		}
		return {
			type: "discardWonder",
			card: t
		};
	}
	return {
		type: "discardWonder",
		card: t.filter((e) => !!C[e]).sort((e, t) => (fn[C[e].effect] ?? 0) - (fn[C[t].effect] ?? 0))[0] ?? t[0]
	};
}
var Ln = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.turn !== t.rid) return null;
	let i = gn(n, t.rid);
	if (!i) return null;
	let a = t.difficulty === "weak", o = r.hand;
	if (n.phase === "scoring") return { action: Fn(n, i, o) };
	if (n.phase !== "turn") return null;
	if (n.pending === "gretaColor") return { action: {
		type: "gretaColor",
		first: a && pn() < .5 ? 1 : 0
	} };
	let s = t.memory ?? {};
	if (n.pending === "move") return {
		action: Mn(n, i, o, a),
		memory: {}
	};
	if (n.pending === "trailEnd") return {
		action: {
			type: "move",
			hiker: [0, 1].find((e) => i.hikers[e] < 8) ?? 0,
			to: 8,
			slot: On(n)
		},
		memory: {}
	};
	if (n.pending === "parks") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let r of n.parksDisplay) {
			if (t.has(r)) continue;
			t.add(r);
			let n = h[r];
			n && vn(i, n.cost) && e.push({
				v: r,
				score: Cn(i, r)
			});
		}
		for (let n of i.reserved) {
			if (t.has(n)) continue;
			t.add(n);
			let r = h[n];
			r && vn(i, r.cost) && e.push({
				v: n,
				score: Cn(i, n)
			});
		}
		if (e.length > 0) return hn(e), {
			action: {
				type: "visit",
				parkId: mn(e, a).v
			},
			memory: { parks: !0 }
		};
		if (s.parks) return {
			action: { type: "parksDone" },
			memory: {}
		};
		let r = [];
		return n.parksDisplay.forEach((e, t) => r.push({
			index: t,
			score: Cn(i, e)
		})), r.length > 0 ? (r.sort((e, t) => t.score - e.score), {
			action: {
				type: "reserve",
				from: "display",
				index: r[0].index
			},
			memory: {}
		}) : n.parksDeck > 0 ? {
			action: {
				type: "reserve",
				from: "deck"
			},
			memory: {}
		} : {
			action: { type: "parksDone" },
			memory: {}
		};
	}
	if (n.pending === "mug") return i.mug >= 3 ? {
		action: {
			type: "mug",
			act: "drink"
		},
		memory: s
	} : {
		action: {
			type: "mug",
			act: "fill"
		},
		memory: s
	};
	if (n.pending === "mugChoice") return {
		action: {
			type: "mugChoice",
			choice: .6 + i.snow + (i.chaletPos < 15 ? .4 : 0) >= 2.6 ? "chalet" : "cons"
		},
		memory: s
	};
	if (n.pending === "cons") return {
		action: kn(i, n, n.freeCons),
		memory: s
	};
	if (n.pending === "assignWild") {
		let e = [];
		for (let t of g) {
			let n = i.visited.filter((e) => e.suit === t).length;
			n !== 0 && e.push({
				suit: t,
				score: Sn(i, t) * 2 + n * .1
			});
		}
		return e.sort((e, t) => t.score - e.score), {
			action: {
				type: "assignWild",
				suit: e[0].suit
			},
			memory: s
		};
	}
	if (n.pending === "freePark") return {
		action: jn(i, n),
		memory: s
	};
	if (n.pending === "discardRes") return {
		action: Nn(i),
		memory: s
	};
	if (n.pending === "discardWonder") return {
		action: In(i, o),
		memory: s
	};
	if (n.pending === "actions") {
		if (n.end && !n.end.topDone && n.end.action) return {
			action: { type: "endTop" },
			memory: s
		};
		if (n.end && !n.end.parksDone) return {
			action: { type: "endParks" },
			memory: s
		};
		let e = n.landingSite === null ? null : n.trailSites[n.landingSite - 1];
		if (!n.siteDone && e) return {
			action: { type: "siteAction" },
			memory: s
		};
		let t = e ? se(e) : null;
		if (t) {
			let e = i.cons.findIndex((e, r) => y(e) === t && !n.consUsed.includes(r));
			if (e >= 0) return {
				action: {
					type: "activateCons",
					card: e
				},
				memory: s
			};
		}
		let r = xn(n, n.landingSite);
		if (r && !n.vfUsed && i.carabiners > 0 && dn[r] + .7 > 1.2) return {
			action: { type: "viaFerrata" },
			memory: s
		};
		let a = [];
		for (let e of Tn(o)) for (let t of ["top", "bottom"]) {
			let n = En(i, e, t);
			n !== null && a.push({
				v: {
					type: "playWonder",
					card: e,
					side: t
				},
				score: n
			});
		}
		let c = hn(a)[0];
		return c && c.score > .8 ? {
			action: c.v,
			memory: s
		} : {
			action: { type: "endTurn" },
			memory: {}
		};
	}
	return null;
}, Rn = {
	1: "games.parkseurope.rank.r1",
	2: "games.parkseurope.rank.r2",
	3: "games.parkseurope.rank.r3",
	4: "games.parkseurope.rank.r4",
	5: "games.parkseurope.rank.r5"
};
function zn({ public: e, rid: t }) {
	let n = a(), r = e, i = r.finalRows?.find((e) => e.rid === t);
	if (!i) return null;
	let o = [
		{
			key: "games.parkseurope.over.parks",
			n: i.parks
		},
		{
			key: "games.parkseurope.over.campfire",
			n: i.campfire
		},
		{
			key: "games.parkseurope.over.endgame",
			n: i.endgame
		},
		{
			key: "games.parkseurope.over.photos",
			n: i.photos
		},
		{
			key: "games.parkseurope.over.parkAwards",
			n: i.parkAwards
		},
		{
			key: "games.parkseurope.over.cons",
			n: i.cons
		},
		{
			key: "games.parkseurope.over.chalet",
			n: i.chalet
		},
		{
			key: "games.parkseurope.over.photoAward",
			n: i.photoAward
		}
	], s = null;
	if (r.soloRanks) {
		let e = 0;
		for (let t of r.soloRanks) i.total >= t.at && (e = Math.max(e, t.rank));
		s = n(Rn[e] ?? "games.parkseurope.rank.none");
	}
	return /* @__PURE__ */ p("div", {
		className: "mt-1.5 flex flex-wrap gap-1",
		children: [
			o.map(({ key: e, n: t }) => /* @__PURE__ */ f("span", {
				className: "rounded border border-ink/30 bg-paper px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums",
				children: n(e, { n: t })
			}, e)),
			/* @__PURE__ */ f("span", {
				className: "rounded border border-ink/30 bg-done-soft px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-done-ink",
				children: n("games.parkseurope.over.total", { n: i.total })
			}),
			s && /* @__PURE__ */ f("span", {
				className: "rounded border border-ink/30 bg-info-soft px-1.5 py-0.5 text-[10px] font-bold text-info-ink",
				children: n("games.parkseurope.over.rank", { name: s })
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Bn({ value: e, onChange: t }) {
	let n = a(), r = N.safeParse(e), i = r.success ? r.data : N.parse(void 0);
	return /* @__PURE__ */ f(m, {
		title: n("games.parkseurope.name"),
		children: /* @__PURE__ */ f(ee, {
			name: "parkseurope-greta",
			value: "greta",
			checked: i.greta,
			label: n("games.parkseurope.opt.greta"),
			hint: n("games.parkseurope.opt.gretaHint"),
			accent: de.accent,
			onChange: () => t({
				...i,
				greta: !i.greta
			})
		})
	});
}
//#endregion
//#region src/index.tsx
var Vn = {
	definition: It,
	View: an,
	bot: Ln,
	RowView: zn,
	Options: Bn,
	locales: {
		zh: {
			name: "Parks Europe",
			desc: "用三个赛季走遍欧洲的国家公园，收集资源、留宿小屋、拍摄照片并支持保护工程，终局比拼得分",
			rules: "目标:\n每名玩家率领两名旅人，在欧洲的国家公园步道上徒步三个赛季。沿途收集资源与照片、访问国家公园、完成保护工程，并在终局结算中获得最高总分的玩家获胜。\n准备:\n· 每名玩家取一块板面，把两枚旅人放在步道起点，把马克杯标记放在马克杯轨道最下方，并取得一枚登山扣。\n· 将所有玩家的小屋标记随机叠放在小屋赛道的起点。\n· 每名玩家从奇迹牌堆抽取一张奇迹卡，作为手牌的开始。\n· 洗混公园卡与保护卡，各翻开三张组成展示区。按人数准备公共营火：三人及以下使用一枚，四人使用两枚，五人使用三枚。\n· 每个赛季开始时翻开一张赛季卡，按卡面把公共营火与赛季奖励资源放到对应站点。小屋标记最靠前的玩家先手，同格时叠在最上面的玩家先手。\n回合:\n每名玩家轮流行动，直到所有旅人都抵达步道终点，该赛季结束。三个赛季结束后进行终局结算。\n· 行动时，选择一名尚未抵达终点的旅人，把它向前移动到任意一个更靠后的站点，并获得该站点的行动与赛季奖励资源。旅人不能后退，也不能跳过自己的回合。\n· 站点上已有其他旅人时不能直接停留，除非使用点上的公共营火，或弃掉手中一张营火奇迹卡。\n· 站点的主要行动可以放弃；放弃后，你仍可以继续使用 Via Ferrata、打出奇迹卡或激活保护卡。\n· 落地后，站点主要行动、Via Ferrata、打出任意张奇迹卡与激活保护卡可以按任意顺序进行。\n· 回合结束时，手牌上限为三张奇迹卡，登山扣上限为三枚；资源区容量为十二格，每枚雪占用两格，超出的非雪资源必须弃回供应区。\n营地与营火:\n· 公共营火每个赛季开始时按人数放置，使用后回到供应区，该赛季不再补充。\n· 营火奇迹卡在终局计分时仍留在手中结算，也可以在此之前弃掉用来占据已有旅人的站点。\n步道站点:\n· 四块核心站点分别提供森林、太阳、山峰与水域资源；山峰与水域站点同时提供一枚雪。\n· 进阶站点提供野生动物、登山扣、公园行动、掷步道骰、拍照、马克杯行动、小屋行动、奇迹卡与保护工程。\n· 中央站点固定印有快门虫图标，旅人抵达时立即取得快门虫。\n步道终点:\n· 终点分为区域：第一排是四种单独行动，每个位置只能容纳一名旅人；中间是公园行动，可以容纳任意多旅人；第二排同时提供上方行动与公园行动，每个位置只能容纳一名旅人。\n· 落在第二排时必须完成上方行动与公园行动，两者的先后顺序由你决定。\n· 终点不能使用营火共享位置。两名旅人都抵达终点后，该玩家的徒步到此结束。\n· 若轮到你行动时其他旅人都已离开步道，你必须立即前往终点，并照常选择终点位置。\nVia Ferrata:\n· 除中央站点外，每个站点上方都有一块 Via Ferrata 板块。落地后，你可以上交一枚登山扣，获得该板块的奖励，并额外获得一枚雪。\n· 每回合只能使用一次 Via Ferrata，且可以在站点主要行动之前或之后使用。\n国家公园:\n· 公园行动可以选择预留，或访问任意多张公园卡。预留时从展示区取一张，或直接抽取牌堆顶一张，放在自己的预留区。\n· 访问时支付公园卡上标注的资源。野生动物可以代替任意一种普通资源；带有「任意」图标的费用可以用任何资源支付。\n· 公园卡按花色叠放在板面右侧。每叠满三张同花色公园，立即取得该花色的公园奖章与印刷的即时奖励；奖章在终局按该花色公园数量计分。\n· 野性公园不属于四种花色。取得时把它并入任意一个已有花色的公园叠；若尚未拥有任何花色，则并入下一张取得的有色公园。\n· 展示区取走或弃掉卡牌后不会立即补入；到回合结束时再从牌库补满，已有卡牌先向右滑动，新卡从左侧补入，最右侧始终是最老的卡牌。\n步道骰与快门虫:\n· 步道骰的六个面分别提供登山扣、野生动物、山与水、抽奇迹卡、拍照、太阳与森林。\n· 持有快门虫时，你回合中的每次拍照行动额外获得一张照片；快门虫可以由旅人抵达中央站点或由部分卡牌获得。\n照片:\n· 每张照片在终局计一分。集满五张照片时换成一本相册，相册在终局计五分。\n· 终局时拍摄照片总数最多的玩家额外获得照片奖章，价值三分；平局时小屋赛道更靠前的玩家获胜。单人模式不使用照片奖章。\n马克杯:\n· 马克杯行动可以填充或饮用。填充时把标记向上移动一格，最多到达顶端；饮用时结算标记所在档位的奖励，并把标记移回最下方。\n· 第一档可以选择执行一次小屋行动，或免费支持一张保护工程。\n· 第二档掷三次步道骰并获得全部结果。\n· 第三档免费访问一张公园，来源可以是展示区、预留区或牌堆顶。\n保护工程:\n· 保护行动可以选择支持一张展示区中的保护卡，或支付一枚太阳与一枚水，从牌堆顶取得一张。\n· 取得保护卡后，只能在对应颜色的核心站点激活它的效果。每回合每张保护卡可以激活一次，多张保护卡的激活顺序自定，也可以安排在站点主要行动之前或之后。\n· 若在当前站点取得颜色相同的保护卡，可以立即激活这一张。\n· 集齐四种颜色的保护卡时取得一枚保护奖章，价值五分。\n小屋:\n· 小屋行动上交自己板面上的全部雪，沿小屋赛道前进与雪数量相同的雪格。\n· 经过奇迹格时抽取一张奇迹卡；经过奖章格时取得该位置最有价值的一枚奖章，奖章堆为空时改为抽取一张奇迹卡。\n· 小屋令牌停止在已有令牌的格子上时叠放在最上方。赛道走到尽头后仍可上交雪，但不再前进。\n· 小屋赛道在终局计分中用于打破平局，越靠前越优先，同格时叠在上方者优先。\n奇迹卡:\n· 基础奇迹卡有上下两种即时行动，支付卡面左侧的资源后获得右侧的奖励。\n· 营火奇迹卡可以弃掉来占据已有旅人的站点；终局计分时按效果获得分数，部分卡牌还可以上交资源换取分数。\n赛季与终局:\n· 赛季开始时重新铺设步道，把新的三块进阶站点与四块核心站点洗混后放到七个位置，并放置新的公共营火与赛季奖励。\n· 三个赛季结束后先进入终局结算：每名玩家可以自行决定是否用手中的营火奇迹卡上交资源换取分数，也可以放弃。\n· 营火效果与资源结算完成后，依次计算到访公园、营火奇迹卡的固定效果、照片与相册、公园奖章、保护奖章与小屋奖章；照片奖章在全部营火效果之后才计算。\n· 公园奖章每枚按同花色到访公园的数量计分，保护奖章与相册各计五分，照片按张计分，小屋奖章按其面值计分（3、4 或 5 分）。总分最高的玩家获胜。\n护林员格蕾塔:\n· 单人模式与双人挑战中，护林员格蕾塔会加入徒步。她始终最后行动，按步道骰结果移动自己的旅人。\n· 蝴蝶面移动队伍中靠后的旅人，花朵面移动靠前的旅人；点数表示可以前进到的第几个可用站点。\n· 点上有公共营火时格蕾塔视为可以停留，并会消耗该营火；她的旅人抵达终点时，弃掉展示区最右侧的公园卡与保护卡。\n· 单人模式中格蕾塔控制两组旅人；每次她行动前，由你选择先移动哪一组。你取得小屋奖章时可以额外抽取一张奇迹卡；照片奖章不参与结算，终局按得分对照评级表。",
			season: {
				cliffs: "悬崖之季",
				swimming: "游泳之季",
				memories: "回忆之季",
				sun: "阳光之季",
				dreams: "梦想之季",
				joy: "欢乐之季",
				scouting: "探索之季",
				growth: "生长之季",
				climbing: "攀登之季",
				caves: "洞穴之季",
				meadows: "草甸之季",
				ice: "冰雪之季"
			},
			res: {
				mountain: "山峰",
				forest: "森林",
				sun: "太阳",
				water: "水域",
				wildlife: "野生动物",
				snow: "雪",
				any: "任意资源"
			},
			suit: {
				lime: "青柠",
				orange: "橙",
				teal: "青绿",
				purple: "紫",
				wild: "野性"
			},
			site: {
				"core-forest": "森林：获得 1 枚森林",
				"core-sun": "太阳：获得 2 枚太阳",
				"core-mountain": "山峰：获得 1 枚山峰与 1 枚雪",
				"core-water": "水域：获得 2 枚水域与 1 枚雪",
				wildlife: "野生动物：获得 1 枚野生动物",
				carabiner: "登山扣：获得 1 枚登山扣",
				parks: "公园行动",
				die: "掷步道骰",
				photo: "拍一张照片",
				mug: "马克杯行动",
				chalet: "小屋行动",
				wonder: "抽一张奇迹卡",
				conservation: "保护工程"
			},
			siteShort: {
				"core-forest": "森林",
				"core-sun": "太阳",
				"core-mountain": "山峰",
				"core-water": "水域",
				wildlife: "野生动物",
				carabiner: "登山扣",
				parks: "公园",
				die: "掷步道骰",
				photo: "拍照",
				mug: "马克杯",
				chalet: "小屋",
				wonder: "奇迹卡",
				conservation: "保护工程"
			},
			vf: {
				wonder: "抽一张奇迹卡",
				sunwater: "获得 1 枚太阳与 1 枚水域",
				photo: "拍一张照片",
				conservation: "保护工程",
				mug: "马克杯行动",
				wildlife: "获得 1 枚野生动物"
			},
			vfShort: {
				wonder: "奇迹卡",
				sunwater: "太阳与水域",
				photo: "拍照",
				conservation: "保护工程",
				mug: "马克杯",
				wildlife: "野生动物"
			},
			top: {
				conservation: "保护工程",
				carabiner: "获得登山扣",
				mug: "马克杯行动",
				chalet: "小屋行动"
			},
			benefit: {
				die: "掷步道骰",
				parks: "公园行动",
				mug: "马克杯行动",
				wonder: "抽一张奇迹卡",
				photo: "拍一张照片",
				wildlife: "获得野生动物",
				carabiner: "获得登山扣"
			},
			token: {
				photo: "照片",
				carabiner: "登山扣"
			},
			consProject: {
				p0: "生物多样性修复",
				p1: "野外研究",
				p2: "遗产地修复",
				p3: "减少光污染",
				p4: "自然摄影",
				p5: "物种保护",
				p6: "步道维护"
			},
			campfire: {
				consForest: "每张森林色保护卡计 1 分",
				consMountain: "每张山峰色保护卡计 1 分",
				consSun: "每张太阳色保护卡计 1 分",
				consWater: "每张水域色保护卡计 1 分",
				iconForest: "到访公园每 3 个森林图标计 1 分",
				iconMountain: "到访公园每 3 个山峰图标计 1 分",
				iconSun: "到访公园每 3 个太阳图标计 1 分",
				iconWater: "到访公园每 3 个水域图标计 1 分",
				anyIcons: "到访公园每 2 个任意资源图标计 1 分",
				album: "每本相册计 1 分",
				wonderHand: "手牌中每张奇迹卡计 1 分，包含本卡",
				snow: "板面上每枚雪计 1 分",
				turnWildlife2: "上交 2 枚野生动物，获得 4 分",
				turnAny2: "上交任意 2 点资源，获得快门虫并拍摄 2 张照片",
				turnCarabiner: "上交 1 枚登山扣，获得 2 分",
				turnAny3: "上交任意 3 点资源，获得 3 分"
			},
			rank: {
				none: "未达评级",
				r1: "一日徒步者",
				r2: "远行者",
				r3: "探险家",
				r4: "冒险家",
				r5: "开拓者"
			},
			opt: {
				greta: "邀请护林员格蕾塔",
				gretaHint: "仅双人局可用；单人局中格蕾塔自动加入。"
			},
			seasonLabel: "第 {{n}} 季",
			seasonCard: "赛季卡：{{name}}",
			myTurn: "轮到你行动",
			waitingFor: "等 {{name}} 行动…",
			pending: {
				move: "移动一名旅人",
				trailEnd: "其他旅人都已抵达终点，直接前往步道终点",
				actions: "可以继续行动，或结束回合",
				parks: "预留或访问公园",
				mug: "填充或饮用马克杯",
				mugChoice: "选择马克杯奖励",
				cons: "支持一张保护工程",
				consFree: "免费支持一张保护工程",
				assignWild: "为野性公园选择花色",
				freePark: "免费访问一张公园",
				discardRes: "弃掉一张多余资源",
				discardWonder: "弃掉一张多余的奇迹卡",
				gretaColor: "选择格蕾塔先移动哪一组旅人",
				scoring: "终局结算",
				none: "对局结束"
			},
			trail: "步道",
			trailEnd: "步道终点",
			trailStart: "起点",
			parksTitle: "国家公园",
			consTitle: "保护工程",
			chaletTrack: "小屋赛道",
			myMat: "我的板面",
			handTitle: "我的奇迹卡",
			handEmpty: "暂无奇迹卡",
			playersTitle: "玩家",
			reservedTitle: "预留公园",
			visitedTitle: "到访公园",
			deckCount: "牌库剩 {{n}} 张",
			startDeck: "牌堆",
			visit: "访问",
			reserve: "预留",
			support: "支持",
			free: "免费",
			deckCost: "太阳 1 · 水域 1",
			points: "{{n}} 分",
			cannotAfford: "资源不足",
			slotTop: "单独行动",
			slotBoth: "行动与公园",
			slotParks: "公园行动",
			slotTaken: "已被占用",
			chooseSlot: "选择终点位置",
			chooseHiker: "选择旅人",
			hikerLabel: "旅人 {{n}}",
			siteNo: "第 {{n}} 站",
			atEnd: "已抵达终点",
			endTurn: "结束回合",
			viaFerrata: "Via Ferrata",
			skip: "跳过",
			cancel: "取消",
			campfireLabel: "营火",
			useCommunalCampfire: "使用公共营火",
			useCampfireCard: "使用营火奇迹卡",
			occupiedPrompt: "这个站点已有旅人，选择如何共享",
			discardResPrompt: "选择要弃回供应的资源",
			discardWonderPrompt: "选择要弃掉的奇迹卡",
			mug: {
				track: "马克杯",
				level: "第 {{n}} 档",
				fill: "填充",
				drink: "饮用",
				chalet: "小屋行动",
				cons: "免费保护工程",
				benefit1: "第一档：小屋行动或免费保护工程",
				benefit2: "第二档：掷三次步道骰",
				benefit3: "第三档：免费访问一张公园"
			},
			assignWildPrompt: "这张野性公园归入哪个花色？",
			freeParkPrompt: "免费访问一张公园",
			wonder: {
				top: "上半",
				bottom: "下半",
				play: "打出",
				pay: "需支付 {{cost}}",
				grant: "获得 {{grant}}",
				campfireCard: "营火卡",
				noPlay: "不能直接打出"
			},
			resources: "资源",
			carabiners: "登山扣 {{n}}",
			photos: "照片 {{n}}",
			albums: "相册 {{n}}",
			awards: "奖章 {{n}}",
			parkAwardsLabel: "公园奖章 {{n}}",
			consAwardsLabel: "保护奖章 {{n}}",
			chaletAwardsLabel: "小屋奖章 {{n}}",
			chaletPos: "小屋第 {{n}} 格",
			visitedCount: "到访 {{n}} 张",
			reservedCount: "预留 {{n}} 张",
			shutterbug: "快门虫",
			greta: "护林员格蕾塔",
			gretaHikers: "格蕾塔的旅人",
			soloRank: "单人评级：{{name}}",
			soloRankTable: "评级线：30 一日徒步者，35 远行者，40 探险家，45 冒险家，50 开拓者",
			siteAction: "执行站点行动",
			endTop: "终点行动",
			endParksTodo: "终点公园行动",
			activateCons: "激活保护卡",
			activateConsPrompt: "选择要激活的保护卡",
			activateConsEmpty: "当前站点没有可激活的保护卡",
			gretaPairA: "橄榄色旅人先",
			gretaPairB: "陶土色旅人先",
			scoringTitle: "终局结算",
			scoringPrompt: "你可以用营火奇迹卡上交资源换取分数；也可以放弃",
			scoringDone: "完成结算",
			scoringEmpty: "手中没有可用的营火效果",
			scoringPayPrompt: "选择要上交的资源，共 {{n}} 点",
			scoringPayChosen: "已选 {{n}}",
			scoringPayConfirm: "上交并结算",
			scoringPayReset: "重新选择",
			scoringUsed: "已使用",
			useEffect: "使用",
			endIncomplete: "请先完成步道终点的行动",
			over: {
				parks: "公园 {{n}}",
				campfire: "营火卡 {{n}}",
				endgame: "营火结算 {{n}}",
				photos: "照片 {{n}}",
				parkAwards: "公园奖章 {{n}}",
				cons: "保护奖章 {{n}}",
				chalet: "小屋奖章 {{n}}",
				photoAward: "照片奖章 {{n}}",
				total: "合计 {{n}}",
				rank: "评级：{{name}}"
			},
			noResources: "暂无资源",
			wild: "野性公园",
			ownMat: "我的",
			otherMat: "{{name}} 的板面",
			scoreShort: "{{n}} 分",
			err: {
				notTurn: "现在轮不到你",
				notPlayer: "你不在这局游戏里",
				phase: "当前步骤不能这样操作",
				badAction: "这一步不能这样做",
				mustMove: "请先移动一名旅人",
				alreadyMoved: "本回合已经移动过了",
				mustEnd: "其他旅人都已抵达终点，必须直接前往步道终点",
				badTarget: "这个站点不能去",
				badHiker: "这名旅人已经抵达终点",
				badSlot: "请选择一个可用的终点位置",
				full: "这个终点位置已被占用",
				occupied: "这个站点已有其他旅人，需要先使用营火",
				noCampfire: "没有可用的营火",
				badPark: "没有可拿取的公园卡",
				badCons: "没有可拿取的保护卡",
				noRes: "资源不足",
				noCarabiner: "登山扣不足",
				noVf: "这里不能使用 Via Ferrata",
				badWonder: "这张奇迹卡不能这样使用",
				badSuit: "不能归入这个花色",
				noConsSite: "这里不能激活保护卡",
				consUsed: "这张保护卡本回合已经激活过"
			}
		},
		en: {
			name: "Parks Europe",
			desc: "Hike through Europe’s national parks over three seasons, gathering resources, resting at chalets, taking photos and supporting conservation projects for the most points",
			rules: "Goal:\nEach player leads two hikers through the national parks of Europe across three seasons. Collect resources and photos, visit national parks, support conservation projects, and earn the most points in the final scoring to win.\nSetup:\n· Each player takes a player mat, places both hikers at the trailhead, puts the mug token on the bottom space of the mug track, and takes one carabiner.\n· Randomly stack all players’ chalet tokens on the starting space of the chalet track.\n· Each player draws one Wonder card from the Wonder deck to start their hand.\n· Shuffle the park cards and the conservation cards, then reveal three of each into their displays. Prepare communal campfires by player count: one for up to three players, two for four players, and three for five players.\n· At the start of each season, reveal a season card and place communal campfires and season bonus resources on the indicated sites. The player whose chalet token is furthest along the track takes the first turn; if tokens share a space, the topmost token goes first.\nTurns:\nPlayers take turns until all hikers reach Trail’s End, which ends the season. After three seasons, final scoring begins.\n· On your turn, choose one hiker that has not reached Trail’s End and move it forward to any later site, taking that site’s action and any season bonus resource there.\n· Hikers never move backward. A hiker cannot stop on a site occupied by another hiker unless you spend the communal campfire on that site or discard a campfire Wonder card from your hand.\n· You may decline the site’s main action; if you do, you may still use the Via Ferrata, play Wonder cards, or activate conservation cards.\n· After landing, the site’s main action, the Via Ferrata, any Wonder cards, and conservation card activations may be taken in any order.\n· At the end of your turn, your hand holds at most three Wonder cards and you keep at most three carabiners. Your mat holds twelve spaces, each snow occupies two spaces, and any excess non-snow resources are returned to the supply.\nCampfires:\n· Communal campfires are placed at the start of each season and return to the supply when spent; they are not replenished during that season.\n· Campfire Wonder cards stay in your hand for final scoring, but you may discard one earlier to share an occupied site.\nTrail Sites:\n· The four core sites provide forest, sun, mountain and water. The mountain and water sites also provide one snow each.\n· Advanced sites provide wildlife, a carabiner, a parks action, a trail die roll, a photo, a mug action, a chalet action, a Wonder card, or a conservation project.\n· The center site always shows the Shutterbug icon; a hiker landing there immediately takes the Shutterbug.\nTrail’s End:\n· Trail’s End has three areas. The top row offers one of the four actions, with room for one hiker per space. The middle area offers a parks action and holds any number of hikers. The bottom row offers both the action above and a parks action, with room for one hiker per space.\n· A hiker on the bottom row must complete both the action and the parks action, in either order.\n· Campfires cannot be used at Trail’s End. Once both of a player’s hikers reach Trail’s End, that player’s hike is over for the season.\n· If all other hikers have already left the trail when your turn begins, you must move directly to Trail’s End and choose a space as usual.\nVia Ferrata:\n· Every site except the center site has a Via Ferrata tile above it. After landing, you may spend one carabiner to gain that tile’s benefit and one snow.\n· You may use the Via Ferrata only once per turn, and you may do so before or after the site action.\nNational Parks:\n· A parks action lets you either reserve one park or visit any number of parks. Reserving takes one card from the display or the top card of the deck and places it in your reserved area.\n· Visiting requires paying the resources shown on the park card. Wildlife may replace any ordinary resource, and an any-resource cost may be paid with any resources.\n· Stack visited parks by suit to the right of your mat. Each third park in a suit immediately earns that suit’s park award and its printed instant benefit. Each park award scores one point per park of that suit at the end of the game.\n· Wild parks belong to no suit. Add a wild park to any existing suit stack; if you have no suit stack yet, it joins the next colored park you visit.\n· Taking or discarding a card does not refill a display immediately. At the end of the turn, cards slide right and new cards enter from the left, so the rightmost card is always the oldest.\nTrail Die and Shutterbug:\n· The six faces of the trail die provide a carabiner, wildlife, mountain and water, a Wonder card, a photo, or sun and forest.\n· While you hold the Shutterbug, each photo action on your turn grants one extra photo. A hiker landing on the center site or certain cards can give you the Shutterbug.\nPhotos:\n· Each photo scores one point at the end of the game. Every five photos become one photo album, and each album scores five points.\n· At the end of the game, the player who took the most photos gains the photo award worth three points; ties go to the player furthest along the chalet track. Solo mode does not use the photo award.\nMug:\n· A mug action either fills or drinks. Filling moves the token up one space, to the top at most. Drinking resolves the benefit of the token’s current space, then returns the token to the bottom.\n· The first space offers a chalet action or a free conservation project.\n· The second space rolls the trail die three times and grants every result.\n· The third space visits one park for free from the display, your reserved area, or the top of the deck.\nConservation Projects:\n· A conservation action supports one displayed project, or pays one sun and one water to take the top card of the deck.\n· A conservation card activates only at the core site matching its color. Each card may activate once per turn, multiple cards may be activated in any order, and activation may come before or after the site’s main action.\n· If you take a card matching the site you are currently on, you may activate it immediately.\n· Collecting one card of each of the four colors earns a conservation award worth five points.\nChalet:\n· A chalet action turns in all snow on your mat and moves your chalet token along the track one snow space per snow token.\n· Passing a Wonder space draws a Wonder card. Passing an award space takes the most valuable award there, or draws a Wonder card if the stack is empty.\n· If your token ends on a space with another token, stack yours on top. At the end of the track you may still turn in snow, but you no longer move.\n· The chalet track breaks ties at the end of the game; further along wins, and the topmost token wins a shared space.\nWonder Cards:\n· Basic Wonder cards offer two instant actions, one on the top half and one on the bottom half; pay the resources on the left to gain the benefit on the right.\n· Campfire Wonder cards can be discarded to share an occupied site. At the end of the game they score according to their effect, and some let you turn in resources for points.\nSeasons and Final Scoring:\n· At the start of a season, rebuild the trail by shuffling the next three advanced sites with the four core sites and placing them on the seven spaces, then place new campfires and season bonuses.\n· After three seasons, final scoring begins. Each player may choose to turn in resources for points with any campfire Wonder cards in hand, or decline each one.\n· Once campfire effects are resolved, score visited parks, fixed campfire card effects, photos and albums, park awards, conservation awards, and chalet awards. The photo award is calculated after all campfire effects.\n· Park awards score one point per visited park of the matching suit, conservation awards and albums score five points each, photos score one point each, and chalet awards score their face value (3, 4, or 5 points). The player with the most points wins.\nRanger Greta:\n· In solo mode and the two-player challenge, Ranger Greta joins the hike. She always acts last and moves her hikers according to the trail die.\n· A butterfly face moves the rearmost hiker of a pair and a flower face moves the frontmost; the number of symbols is the count of available sites she advances to.\n· Greta treats a site with a communal campfire as available and spends that campfire to stop there. When one of her hikers reaches Trail’s End, discard the rightmost park card and conservation card from their displays.\n· In solo mode Greta controls two pairs of hikers, and before each of her turns you choose which pair moves first. You draw an extra Wonder card whenever you gain a chalet award; the photo award is not used, and your final score is compared to the rank table.",
			season: {
				cliffs: "Season of Cliffs",
				swimming: "Season of Swimming",
				memories: "Season of Memories",
				sun: "Season of Sun",
				dreams: "Season of Dreams",
				joy: "Season of Joy",
				scouting: "Season of Scouting",
				growth: "Season of Growth",
				climbing: "Season of Climbing",
				caves: "Season of Caves",
				meadows: "Season of Meadows",
				ice: "Season of Ice"
			},
			res: {
				mountain: "Mountain",
				forest: "Forest",
				sun: "Sun",
				water: "Water",
				wildlife: "Wildlife",
				snow: "Snow",
				any: "Any resource"
			},
			suit: {
				lime: "Lime",
				orange: "Orange",
				teal: "Teal",
				purple: "Purple",
				wild: "Wild"
			},
			site: {
				"core-forest": "Forest: gain one forest",
				"core-sun": "Sun: gain two sun",
				"core-mountain": "Mountain: gain one mountain and one snow",
				"core-water": "Water: gain two water and one snow",
				wildlife: "Wildlife: gain one wildlife",
				carabiner: "Carabiner: gain one carabiner",
				parks: "Parks action",
				die: "Roll the trail die",
				photo: "Take a photo",
				mug: "Mug action",
				chalet: "Chalet action",
				wonder: "Draw a Wonder card",
				conservation: "Conservation project"
			},
			siteShort: {
				"core-forest": "Forest",
				"core-sun": "Sun",
				"core-mountain": "Mountain",
				"core-water": "Water",
				wildlife: "Wildlife",
				carabiner: "Carabiner",
				parks: "Parks",
				die: "Roll die",
				photo: "Photo",
				mug: "Mug",
				chalet: "Chalet",
				wonder: "Wonder",
				conservation: "Conservation"
			},
			vf: {
				wonder: "Draw a Wonder card",
				sunwater: "Gain one sun and one water",
				photo: "Take a photo",
				conservation: "Conservation project",
				mug: "Mug action",
				wildlife: "Gain one wildlife"
			},
			vfShort: {
				wonder: "Wonder",
				sunwater: "Sun and water",
				photo: "Photo",
				conservation: "Conservation",
				mug: "Mug",
				wildlife: "Wildlife"
			},
			top: {
				conservation: "Conservation project",
				carabiner: "Gain a carabiner",
				mug: "Mug action",
				chalet: "Chalet action"
			},
			benefit: {
				die: "Roll the trail die",
				parks: "Parks action",
				mug: "Mug action",
				wonder: "Draw a Wonder card",
				photo: "Take a photo",
				wildlife: "Gain wildlife",
				carabiner: "Gain a carabiner"
			},
			token: {
				photo: "Photo",
				carabiner: "Carabiner"
			},
			consProject: {
				p0: "Biodiversity Restoration",
				p1: "Field Research",
				p2: "Heritage Site Restoration",
				p3: "Light Pollution Reduction",
				p4: "Nature Photography",
				p5: "Species Protection",
				p6: "Trail Maintenance"
			},
			campfire: {
				consForest: "One point per forest conservation card",
				consMountain: "One point per mountain conservation card",
				consSun: "One point per sun conservation card",
				consWater: "One point per water conservation card",
				iconForest: "One point per three forest icons on visited parks",
				iconMountain: "One point per three mountain icons on visited parks",
				iconSun: "One point per three sun icons on visited parks",
				iconWater: "One point per three water icons on visited parks",
				anyIcons: "One point per two any-resource icons on visited parks",
				album: "One point per photo album",
				wonderHand: "One point per Wonder card in hand, including this one",
				snow: "One point per snow on your mat",
				turnWildlife2: "Turn in two wildlife for four points",
				turnAny2: "Turn in any two resources for the Shutterbug and two photos",
				turnCarabiner: "Turn in one carabiner for two points",
				turnAny3: "Turn in any three resources for three points"
			},
			rank: {
				none: "Unranked",
				r1: "Dayhiker",
				r2: "Trekker",
				r3: "Explorer",
				r4: "Adventurer",
				r5: "Trailblazer"
			},
			opt: {
				greta: "Invite Ranger Greta",
				gretaHint: "Available in two-player games only; in solo mode Greta always joins."
			},
			seasonLabel: "Season {{n}}",
			seasonCard: "Season card: {{name}}",
			myTurn: "Your turn",
			waitingFor: "Waiting for {{name}}…",
			pending: {
				move: "Move one of your hikers",
				trailEnd: "Every other hiker has reached Trail’s End, so move directly there",
				actions: "Keep taking actions, or end your turn",
				parks: "Reserve or visit parks",
				mug: "Fill or drink your mug",
				mugChoice: "Choose your mug benefit",
				cons: "Support a conservation project",
				consFree: "Support a conservation project for free",
				assignWild: "Choose a suit for the wild park",
				freePark: "Visit one park for free",
				discardRes: "Discard one excess resource",
				discardWonder: "Discard one excess Wonder card",
				gretaColor: "Choose which pair of Greta’s hikers moves first",
				scoring: "Final scoring",
				none: "Game over"
			},
			trail: "Trail",
			trailEnd: "Trail’s End",
			trailStart: "Trailhead",
			parksTitle: "National Parks",
			consTitle: "Conservation Projects",
			chaletTrack: "Chalet Track",
			myMat: "My Mat",
			handTitle: "My Wonder Cards",
			handEmpty: "No Wonder cards",
			playersTitle: "Players",
			reservedTitle: "Reserved Parks",
			visitedTitle: "Visited Parks",
			deckCount: "{{n}} cards left in the deck",
			startDeck: "Deck",
			visit: "Visit",
			reserve: "Reserve",
			support: "Support",
			free: "Free",
			deckCost: "One sun, one water",
			points: "{{n}} points",
			cannotAfford: "Not enough resources",
			slotTop: "Action only",
			slotBoth: "Action and parks",
			slotParks: "Parks action",
			slotTaken: "Occupied",
			chooseSlot: "Choose a Trail’s End space",
			chooseHiker: "Choose a hiker",
			hikerLabel: "Hiker {{n}}",
			siteNo: "Site {{n}}",
			atEnd: "At Trail’s End",
			endTurn: "End turn",
			viaFerrata: "Via Ferrata",
			skip: "Skip",
			cancel: "Cancel",
			campfireLabel: "Campfire",
			useCommunalCampfire: "Spend the communal campfire",
			useCampfireCard: "Spend a campfire Wonder card",
			occupiedPrompt: "Another hiker is here; choose how to share the site",
			discardResPrompt: "Choose a resource to return to the supply",
			discardWonderPrompt: "Choose a Wonder card to discard",
			mug: {
				track: "Mug",
				level: "Space {{n}}",
				fill: "Fill",
				drink: "Drink",
				chalet: "Chalet action",
				cons: "Free conservation project",
				benefit1: "First space: chalet action or free conservation",
				benefit2: "Second space: roll the trail die three times",
				benefit3: "Third space: visit one park for free"
			},
			assignWildPrompt: "Which suit does this wild park join?",
			freeParkPrompt: "Visit one park for free",
			wonder: {
				top: "Top",
				bottom: "Bottom",
				play: "Play",
				pay: "Pay {{cost}}",
				grant: "Gain {{grant}}",
				campfireCard: "Campfire card",
				noPlay: "Cannot be played directly"
			},
			resources: "Resources",
			carabiners: "Carabiners {{n}}",
			photos: "Photos {{n}}",
			albums: "Albums {{n}}",
			awards: "Awards {{n}}",
			parkAwardsLabel: "Park awards {{n}}",
			consAwardsLabel: "Conservation awards {{n}}",
			chaletAwardsLabel: "Chalet awards {{n}}",
			chaletPos: "Chalet space {{n}}",
			visitedCount: "{{n}} visited",
			reservedCount: "{{n}} reserved",
			shutterbug: "Shutterbug",
			greta: "Ranger Greta",
			gretaHikers: "Greta’s hikers",
			soloRank: "Solo rank: {{name}}",
			soloRankTable: "Ranks: 30 Dayhiker, 35 Trekker, 40 Explorer, 45 Adventurer, 50 Trailblazer",
			siteAction: "Take the site action",
			endTop: "Trail’s End action",
			endParksTodo: "Trail’s End parks action",
			activateCons: "Activate conservation card",
			activateConsPrompt: "Choose a conservation card to activate",
			activateConsEmpty: "No conservation card can be activated here",
			gretaPairA: "Moss hikers first",
			gretaPairB: "Clay hikers first",
			scoringTitle: "Final Scoring",
			scoringPrompt: "You may turn in resources for points with campfire Wonder cards, or decline each one",
			scoringDone: "Finish scoring",
			scoringEmpty: "No usable campfire effect in hand",
			scoringPayPrompt: "Choose {{n}} resources to turn in",
			scoringPayChosen: "{{n}} chosen",
			scoringPayConfirm: "Turn in and score",
			scoringPayReset: "Choose again",
			scoringUsed: "Used",
			useEffect: "Use",
			endIncomplete: "Complete the Trail’s End actions first",
			over: {
				parks: "Parks {{n}}",
				campfire: "Campfire cards {{n}}",
				endgame: "Campfire scoring {{n}}",
				photos: "Photos {{n}}",
				parkAwards: "Park awards {{n}}",
				cons: "Conservation awards {{n}}",
				chalet: "Chalet awards {{n}}",
				photoAward: "Photo award {{n}}",
				total: "Total {{n}}",
				rank: "Rank: {{name}}"
			},
			noResources: "No resources",
			wild: "Wild park",
			ownMat: "Mine",
			otherMat: "{{name}}’s mat",
			scoreShort: "{{n}} points",
			err: {
				notTurn: "It is not your turn",
				notPlayer: "You are not in this game",
				phase: "You cannot do that right now",
				badAction: "That action is not available here",
				mustMove: "Move a hiker first",
				alreadyMoved: "You already moved this turn",
				mustEnd: "Every other hiker has reached Trail’s End, so you must move there",
				badTarget: "You cannot stop at that site",
				badHiker: "That hiker has already reached Trail’s End",
				badSlot: "Choose an available Trail’s End space",
				full: "That Trail’s End space is occupied",
				occupied: "Another hiker is here; you need a campfire",
				noCampfire: "No campfire is available",
				badPark: "No park card can be taken",
				badCons: "No conservation card can be taken",
				noRes: "Not enough resources",
				noCarabiner: "Not enough carabiners",
				noVf: "The Via Ferrata is not available here",
				badWonder: "That Wonder card cannot be used this way",
				badSuit: "That suit is not available",
				noConsSite: "No conservation card can be activated here",
				consUsed: "That conservation card was already activated this turn"
			}
		}
	}
};
//#endregion
export { Vn as default };
