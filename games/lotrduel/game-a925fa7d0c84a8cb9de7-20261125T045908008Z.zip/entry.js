import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { gameAssetUrl as r } from "@bgparty/sdk/assets";
import { AVATARS as i } from "@bgparty/sdk/avatars";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { seatName as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
//#region src/game/data.ts
var m = [
	"lindon",
	"arnor",
	"enedwaith",
	"rhovanion",
	"rohan",
	"gondor",
	"mordor"
], h = [
	"elves",
	"ents",
	"hobbits",
	"humans",
	"dwarves",
	"wizards"
], g = [
	["lindon", "arnor"],
	["lindon", "enedwaith"],
	["arnor", "enedwaith"],
	["arnor", "rhovanion"],
	["arnor", "rohan"],
	["enedwaith", "rhovanion"],
	["enedwaith", "rohan"],
	["enedwaith", "gondor"],
	["rhovanion", "rohan"],
	["rhovanion", "mordor"],
	["rohan", "gondor"],
	["rohan", "mordor"],
	["gondor", "mordor"]
];
function _(e) {
	let t = [];
	for (let [n, r] of g) n === e && t.push(r), r === e && t.push(n);
	return t;
}
var v = (e, t, n, r, i = [], a = 0, o = {}) => ({
	id: e,
	chapter: t,
	color: n,
	effect: r,
	skills: i,
	coins: a,
	...o
}), y = [
	v("c1-coin2", 1, "yellow", {
		kind: "coins",
		n: 2
	}, [], 0, { copies: 4 }),
	v("c1-ring1-horse", 1, "blue", {
		kind: "quest",
		n: 1
	}, ["strength"], 0, { grant: "horse" }),
	v("c1-ring1-teapot", 1, "blue", {
		kind: "quest",
		n: 1
	}, ["courage"], 0, { grant: "teapot" }),
	v("c1-ring1-fish", 1, "blue", {
		kind: "quest",
		n: 1
	}, [], 1, { grant: "fish" }),
	v("c1-ring1-plain", 1, "blue", {
		kind: "quest",
		n: 1
	}),
	v("c1-elves", 1, "green", {
		kind: "race",
		race: "elves"
	}, ["knowledge"], 0, { grant: "harp" }),
	v("c1-dwarves", 1, "green", {
		kind: "race",
		race: "dwarves"
	}, ["leadership"], 0, { grant: "anvil" }),
	v("c1-skill-courage", 1, "grey", {
		kind: "skills",
		groups: [["courage"]]
	}, [], 0, { copies: 2 }),
	v("c1-skill-knowledge", 1, "grey", {
		kind: "skills",
		groups: [["knowledge"]]
	}),
	v("c1-hobbits", 1, "green", {
		kind: "race",
		race: "hobbits"
	}, ["leadership"], 0, { grant: "pot" }),
	v("c1-humans", 1, "green", {
		kind: "race",
		race: "humans"
	}, ["knowledge"], 0, { grant: "horseshoe" }),
	v("c1-red1-gondor-rohan", 1, "red", {
		kind: "units",
		n: 1,
		regions: ["gondor", "rohan"]
	}, ["ruse"], 0, { grant: "crossedSwords" }),
	v("c1-skill-strength", 1, "grey", {
		kind: "skills",
		groups: [["strength"]]
	}, [], 0, { copies: 2 }),
	v("c1-skill-ruse", 1, "grey", {
		kind: "skills",
		groups: [["ruse"]]
	}, [], 0, { copies: 2 }),
	v("c1-skill-leadership", 1, "grey", {
		kind: "skills",
		groups: [["leadership"]]
	}),
	v("c1-red1-lindon-arnor", 1, "red", {
		kind: "units",
		n: 1,
		regions: ["lindon", "arnor"]
	}, [], 0, { grant: "sword" }),
	v("c1-red1-enedwaith-rhovanion", 1, "red", {
		kind: "units",
		n: 1,
		regions: ["enedwaith", "rhovanion"]
	}, [], 0, { grant: "helmet" }),
	v("c2-coin3", 2, "yellow", {
		kind: "coins",
		n: 3
	}, [], 0, { grant: "chest" }),
	v("c2-coin4", 2, "yellow", {
		kind: "coins",
		n: 4
	}),
	v("c2-ring1-ruse-strength", 2, "blue", {
		kind: "quest",
		n: 1
	}, ["ruse", "strength"]),
	v("c2-ring2-scroll", 2, "blue", {
		kind: "quest",
		n: 2
	}, [
		"strength",
		"strength",
		"knowledge"
	], 0, { grant: "scroll" }),
	v("c2-ring2-campfire", 2, "blue", {
		kind: "quest",
		n: 2
	}, [
		"strength",
		"courage",
		"courage"
	], 0, { grant: "campfire" }),
	v("c2-ring1-horse", 2, "blue", {
		kind: "quest",
		n: 1
	}, ["courage", "strength"], 0, { require: "horse" }),
	v("c2-ring1-teapot", 2, "blue", {
		kind: "quest",
		n: 1
	}, [], 1, { require: "teapot" }),
	v("c2-red2-gondor-mordor", 2, "red", {
		kind: "units",
		n: 2,
		regions: ["gondor", "mordor"]
	}, [
		"ruse",
		"ruse",
		"ruse"
	], 0, {
		require: "crossedSwords",
		grant: "sword"
	}),
	v("c2-skill-multi3", 2, "grey", {
		kind: "skills",
		groups: [[
			"ruse",
			"strength",
			"courage"
		]]
	}, ["leadership", "knowledge"], 1),
	v("c2-red2-arnor-rhovanion", 2, "red", {
		kind: "units",
		n: 2,
		regions: ["arnor", "rhovanion"]
	}, [
		"courage",
		"courage",
		"leadership"
	]),
	v("c2-humans", 2, "green", {
		kind: "race",
		race: "humans"
	}, [
		"courage",
		"courage",
		"knowledge"
	], 0, {
		require: "horseshoe",
		grant: "flag"
	}),
	v("c2-dwarves", 2, "green", {
		kind: "race",
		race: "dwarves"
	}, [
		"strength",
		"strength",
		"leadership"
	], 0, { require: "anvil" }),
	v("c2-hobbits", 2, "green", {
		kind: "race",
		race: "hobbits"
	}, [
		"ruse",
		"ruse",
		"leadership"
	], 0, {
		require: "pot",
		grant: "teapot"
	}),
	v("c2-elves", 2, "green", {
		kind: "race",
		race: "elves"
	}, [
		"courage",
		"leadership",
		"knowledge"
	], 0, { require: "harp" }),
	v("c2-red2-mordor-rohan", 2, "red", {
		kind: "units",
		n: 2,
		regions: ["mordor", "rohan"]
	}, [
		"ruse",
		"ruse",
		"knowledge"
	], 0, {
		require: "sword",
		grant: "axe"
	}),
	v("c2-red2-lindon-enedwaith", 2, "red", {
		kind: "units",
		n: 2,
		regions: ["lindon", "enedwaith"]
	}, [
		"strength",
		"strength",
		"courage"
	], 0, {
		require: "helmet",
		grant: "chest"
	}),
	v("c2-skill-courage2", 2, "grey", {
		kind: "skills",
		groups: [["courage"], ["courage"]]
	}, [], 1),
	v("c2-skill-strength2", 2, "grey", {
		kind: "skills",
		groups: [["strength"], ["strength"]]
	}, [], 1),
	v("c2-skill-ruse2", 2, "grey", {
		kind: "skills",
		groups: [["ruse"], ["ruse"]]
	}, [], 1),
	v("c2-red2-lindon-rohan", 2, "red", {
		kind: "units",
		n: 2,
		regions: ["lindon", "rohan"]
	}, [
		"ruse",
		"strength",
		"courage"
	]),
	v("c2-skill-leadership-knowledge", 2, "grey", {
		kind: "skills",
		groups: [["leadership", "knowledge"]]
	}, ["ruse"], 1),
	v("c2-skill-knowledge", 2, "grey", {
		kind: "skills",
		groups: [["knowledge"]]
	}),
	v("c2-skill-leadership", 2, "grey", {
		kind: "skills",
		groups: [["leadership"]]
	}),
	v("c3-coin5-a", 3, "yellow", {
		kind: "coins",
		n: 5
	}, [
		"ruse",
		"leadership",
		"knowledge"
	]),
	v("c3-coin5-scroll", 3, "yellow", {
		kind: "coins",
		n: 5
	}, [
		"ruse",
		"ruse",
		"courage"
	], 0, { require: "scroll" }),
	v("c3-ring3", 3, "blue", {
		kind: "quest",
		n: 3
	}, [], 3),
	v("c3-ring2-str", 3, "blue", {
		kind: "quest",
		n: 2
	}, [
		"strength",
		"strength",
		"leadership"
	]),
	v("c3-ring2-scroll", 3, "blue", {
		kind: "quest",
		n: 2
	}, [
		"ruse",
		"ruse",
		"ruse",
		"courage"
	], 0, { require: "scroll" }),
	v("c3-ring2-fish", 3, "blue", {
		kind: "quest",
		n: 2
	}, [
		"ruse",
		"ruse",
		"courage",
		"courage"
	], 0, { require: "fish" }),
	v("c3-ring2-campfire", 3, "blue", {
		kind: "quest",
		n: 2
	}, [
		"ruse",
		"strength",
		"strength",
		"strength"
	], 0, { require: "campfire" }),
	v("c3-wizards-flag", 3, "green", {
		kind: "race",
		race: "wizards"
	}, [
		"ruse",
		"ruse",
		"leadership",
		"leadership"
	], 0, { require: "flag" }),
	v("c3-wizards", 3, "green", {
		kind: "race",
		race: "wizards"
	}, [
		"strength",
		"strength",
		"leadership",
		"knowledge"
	]),
	v("c3-ents-teapot", 3, "green", {
		kind: "race",
		race: "ents"
	}, [
		"strength",
		"strength",
		"knowledge",
		"knowledge"
	], 0, { require: "teapot" }),
	v("c3-ents", 3, "green", {
		kind: "race",
		race: "ents"
	}, [
		"courage",
		"courage",
		"leadership",
		"knowledge"
	]),
	v("c3-red3-enedwaith-arnor", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["enedwaith", "arnor"]
	}, [
		"ruse",
		"ruse",
		"courage",
		"courage"
	]),
	v("c3-red3-rhovanion-gondor", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["rhovanion", "gondor"]
	}, [
		"ruse",
		"ruse",
		"ruse",
		"leadership",
		"leadership"
	]),
	v("c3-red3-lindon-mordor", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["lindon", "mordor"]
	}, [
		"ruse",
		"ruse",
		"courage",
		"knowledge",
		"knowledge"
	]),
	v("c3-red3-rhovanion-mordor", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["rhovanion", "mordor"]
	}, [
		"ruse",
		"strength",
		"strength",
		"courage",
		"courage"
	]),
	v("c3-red3-gondor-arnor", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["gondor", "arnor"]
	}, [
		"ruse",
		"strength",
		"leadership",
		"leadership",
		"knowledge"
	], 0, { require: "axe" }),
	v("c3-red3-enedwaith-rohan", 3, "red", {
		kind: "units",
		n: 3,
		regions: ["enedwaith", "rohan"]
	}, [
		"strength",
		"strength",
		"courage",
		"courage"
	], 0, { require: "chest" }),
	v("c3-purple-move3", 3, "purple", {
		kind: "purple",
		moves: 3,
		removeUnits: 0,
		coinLoss: 0
	}, [
		"courage",
		"courage",
		"leadership",
		"knowledge"
	]),
	v("c3-purple-rm-coin-move", 3, "purple", {
		kind: "purple",
		moves: 1,
		removeUnits: 1,
		coinLoss: 1
	}, [
		"strength",
		"strength",
		"leadership"
	]),
	v("c3-purple-rm2-coin", 3, "purple", {
		kind: "purple",
		moves: 0,
		removeUnits: 2,
		coinLoss: 1
	}, [
		"strength",
		"courage",
		"knowledge",
		"knowledge"
	]),
	v("c3-purple-rm-move2", 3, "purple", {
		kind: "purple",
		moves: 2,
		removeUnits: 1,
		coinLoss: 0
	}, [
		"strength",
		"strength",
		"strength",
		"knowledge"
	]),
	v("c3-purple-rm-coin2", 3, "purple", {
		kind: "purple",
		moves: 0,
		removeUnits: 1,
		coinLoss: 2
	}, [
		"courage",
		"courage",
		"courage",
		"leadership"
	]),
	v("c3-purple-coin-move2", 3, "purple", {
		kind: "purple",
		moves: 2,
		removeUnits: 0,
		coinLoss: 1
	}, [
		"ruse",
		"strength",
		"courage",
		"knowledge"
	])
], b = new Map(y.map((e) => [e.id, e])), x = (e) => {
	let t = b.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
};
function S(e) {
	let t = [];
	for (let n of y) if (n.chapter === e) for (let e = 0; e < (n.copies ?? 1); e += 1) t.push(n.id);
	return t;
}
var C = {
	1: [
		[-4, -16],
		[4, -16],
		[-8, -20],
		[0, -20],
		[8, -20],
		[-12, -24],
		[-4, -24],
		[4, -24],
		[12, -24],
		[-16, -28],
		[-8, -28],
		[0, -28],
		[8, -28],
		[16, -28],
		[-20, -32],
		[-12, -32],
		[-4, -32],
		[4, -32],
		[12, -32],
		[20, -32]
	].map(([e, t], n) => ({
		x: e,
		z: t,
		faceDown: [
			3,
			4,
			5,
			10,
			11,
			12,
			13,
			14
		].includes(n + 1)
	})),
	2: [
		[-20, -16],
		[-12, -16],
		[-4, -16],
		[4, -16],
		[12, -16],
		[20, -16],
		[-16, -20],
		[-8, -20],
		[0, -20],
		[8, -20],
		[16, -20],
		[-12, -24],
		[-4, -24],
		[4, -24],
		[12, -24],
		[-8, -28],
		[0, -28],
		[8, -28],
		[-4, -32],
		[4, -32]
	].map(([e, t], n) => ({
		x: e,
		z: t,
		faceDown: [
			7,
			8,
			9,
			10,
			11,
			16,
			17,
			18
		].includes(n + 1)
	})),
	3: [
		[-4, -16],
		[4, -16],
		[-8, -20],
		[0, -20],
		[8, -20],
		[-12, -24],
		[-4, -24],
		[4, -24],
		[12, -24],
		[-8, -28],
		[8, -28],
		[-12, -32],
		[-4, -32],
		[4, -32],
		[12, -32],
		[-8, -36],
		[0, -36],
		[8, -36],
		[-4, -40],
		[4, -40]
	].map(([e, t], n) => ({
		x: e,
		z: t,
		faceDown: [
			3,
			4,
			5,
			10,
			11,
			16,
			17,
			18
		].includes(n + 1)
	}))
};
function w(e, t) {
	return e.z > t.z && Math.abs(e.x - t.x) < 8.1;
}
var T = [
	{
		id: "baradDur",
		region: "mordor",
		units: 0,
		skills: [
			"courage",
			"courage",
			"courage",
			"leadership",
			"leadership",
			"knowledge"
		],
		coins: 1
	},
	{
		id: "bree",
		region: "arnor",
		units: 2,
		skills: [
			"strength",
			"strength",
			"strength",
			"courage",
			"courage",
			"leadership"
		],
		coins: 1
	},
	{
		id: "erebor",
		region: "rhovanion",
		units: 0,
		skills: [
			"ruse",
			"strength",
			"strength",
			"courage",
			"leadership",
			"knowledge"
		],
		coins: 1
	},
	{
		id: "greyHavens",
		region: "lindon",
		units: 0,
		skills: [
			"strength",
			"strength",
			"strength",
			"courage",
			"leadership",
			"knowledge"
		],
		coins: 1
	},
	{
		id: "helmsDeep",
		region: "rohan",
		units: 3,
		skills: [
			"ruse",
			"ruse",
			"ruse",
			"leadership",
			"leadership",
			"knowledge"
		],
		coins: 1
	},
	{
		id: "isengard",
		region: "enedwaith",
		units: 0,
		skills: [
			"ruse",
			"ruse",
			"courage",
			"courage",
			"courage",
			"knowledge"
		],
		coins: 1
	},
	{
		id: "minasTirith",
		region: "gondor",
		units: 1,
		skills: [
			"ruse",
			"ruse",
			"ruse",
			"strength",
			"knowledge",
			"knowledge"
		],
		coins: 1
	}
], E = (e) => {
	let t = T.find((t) => t.id === e);
	if (!t) throw Error(`unknown landmark ${e}`);
	return t;
}, ee = [
	{
		id: "elves-1",
		race: "elves",
		effect: "elvesYellowTurn",
		immediate: !1
	},
	{
		id: "elves-2",
		race: "elves",
		effect: "elvesRedAny",
		immediate: !1
	},
	{
		id: "elves-3",
		race: "elves",
		effect: "elvesAnySkill",
		immediate: !1
	},
	{
		id: "dwarves-1",
		race: "dwarves",
		effect: "dwarvesNoExtra",
		immediate: !1
	},
	{
		id: "dwarves-2",
		race: "dwarves",
		effect: "dwarvesTurn",
		immediate: !1
	},
	{
		id: "dwarves-3",
		race: "dwarves",
		effect: "dwarvesGreenMoves",
		immediate: !1
	},
	{
		id: "hobbits-1",
		race: "hobbits",
		effect: "hobbitsEagle",
		immediate: !1
	},
	{
		id: "hobbits-2",
		race: "hobbits",
		effect: "hobbitsBlueUnit",
		immediate: !1
	},
	{
		id: "hobbits-3",
		race: "hobbits",
		effect: "hobbitsChainCoins",
		immediate: !1
	},
	{
		id: "humans-1",
		race: "humans",
		effect: "humansYellowQuest",
		immediate: !1
	},
	{
		id: "humans-2",
		race: "humans",
		effect: "humansRedExtra",
		immediate: !1
	},
	{
		id: "humans-3",
		race: "humans",
		effect: "humansDiscardDouble",
		immediate: !1
	},
	{
		id: "ents-1",
		race: "ents",
		effect: "entsTurn",
		immediate: !0
	},
	{
		id: "ents-2",
		race: "ents",
		effect: "entsFortress",
		immediate: !0
	},
	{
		id: "ents-3",
		race: "ents",
		effect: "entsChoice",
		immediate: !0
	},
	{
		id: "wizards-1",
		race: "wizards",
		effect: "wizardsQuest2",
		immediate: !0
	},
	{
		id: "wizards-2",
		race: "wizards",
		effect: "wizardsUnits",
		immediate: !0
	},
	{
		id: "wizards-3",
		race: "wizards",
		effect: "wizardsDiscardFree",
		immediate: !0
	}
], D = (e) => {
	let t = ee.find((t) => t.id === e);
	if (!t) throw Error(`unknown token ${e}`);
	return t;
}, te = {
	coin: "games.lotrduel.track.coin",
	unit: "games.lotrduel.track.unit",
	extraTurn: "games.lotrduel.track.extraTurn",
	fortress: "games.lotrduel.track.fortress"
}, O = {
	4: "coin",
	7: "unit",
	10: "extraTurn",
	13: "fortress",
	18: "coin",
	21: "unit",
	24: "extraTurn",
	27: "fortress"
}, k = {
	lindon: "games.lotrduel.region.lindon",
	arnor: "games.lotrduel.region.arnor",
	enedwaith: "games.lotrduel.region.enedwaith",
	rhovanion: "games.lotrduel.region.rhovanion",
	rohan: "games.lotrduel.region.rohan",
	gondor: "games.lotrduel.region.gondor",
	mordor: "games.lotrduel.region.mordor"
}, ne = {
	elves: "games.lotrduel.race.elves",
	ents: "games.lotrduel.race.ents",
	hobbits: "games.lotrduel.race.hobbits",
	humans: "games.lotrduel.race.humans",
	dwarves: "games.lotrduel.race.dwarves",
	wizards: "games.lotrduel.race.wizards"
}, re = {
	ruse: "games.lotrduel.skill.ruse",
	strength: "games.lotrduel.skill.strength",
	courage: "games.lotrduel.skill.courage",
	knowledge: "games.lotrduel.skill.knowledge",
	leadership: "games.lotrduel.skill.leadership"
}, ie = {
	baradDur: "games.lotrduel.landmark.baradDur",
	bree: "games.lotrduel.landmark.bree",
	erebor: "games.lotrduel.landmark.erebor",
	greyHavens: "games.lotrduel.landmark.greyHavens",
	helmsDeep: "games.lotrduel.landmark.helmsDeep",
	isengard: "games.lotrduel.landmark.isengard",
	minasTirith: "games.lotrduel.landmark.minasTirith"
}, A = {
	yellow: "games.lotrduel.color.yellow",
	blue: "games.lotrduel.color.blue",
	red: "games.lotrduel.color.red",
	green: "games.lotrduel.color.green",
	grey: "games.lotrduel.color.grey",
	purple: "games.lotrduel.color.purple"
}, j = {
	horse: "games.lotrduel.chain.horse",
	teapot: "games.lotrduel.chain.teapot",
	fish: "games.lotrduel.chain.fish",
	harp: "games.lotrduel.chain.harp",
	anvil: "games.lotrduel.chain.anvil",
	pot: "games.lotrduel.chain.pot",
	horseshoe: "games.lotrduel.chain.horseshoe",
	crossedSwords: "games.lotrduel.chain.crossedSwords",
	sword: "games.lotrduel.chain.sword",
	helmet: "games.lotrduel.chain.helmet",
	chest: "games.lotrduel.chain.chest",
	scroll: "games.lotrduel.chain.scroll",
	campfire: "games.lotrduel.chain.campfire",
	axe: "games.lotrduel.chain.axe",
	flag: "games.lotrduel.chain.flag"
}, ae = {
	id: "lotrduel",
	uuid: "3f0c9f2e-6f5a-4d70-9f52-2a0d6b7c41e9",
	tier: "alpha",
	mechanics: [
		"drafting",
		"area-control",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.lotrduel.name",
	descKey: "games.lotrduel.desc",
	rulesKey: "games.lotrduel.rules",
	icon: "💍",
	iconImg: "games/lotrduel.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#7a1f1a",
	releasedAt: "2026-11-23T17:38:36+08:00",
	search: {
		py: "mo jie zhong zhou dui jue",
		init: "mjzzdj"
	},
	hotseat: "open"
}, M = t.union([
	t.object({
		type: t.literal("takeCard"),
		slot: t.int().nonnegative(),
		mode: t.enum(["play", "discard"])
	}),
	t.object({
		type: t.literal("takeLandmark"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("choose"),
		value: t.string(),
		value2: t.string().optional()
	})
]), N = t.string(), P = t.object({
	phase: t.enum([
		"turn",
		"choice",
		"done"
	]),
	chapter: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	turn: N,
	pending: t.object({
		kind: t.enum([
			"redRegion",
			"tokenPick",
			"racePick",
			"greyDiscard",
			"discardPick",
			"move",
			"removeUnit",
			"unitAny",
			"wizardsUnits",
			"entChoice",
			"fortressPick"
		]),
		who: N,
		options: t.array(t.string()),
		remaining: t.int().nonnegative()
	}).nullable(),
	central: t.array(t.object({
		slot: t.int().nonnegative(),
		cardId: t.string().nullable(),
		faceUp: t.boolean(),
		taken: t.boolean(),
		accessible: t.boolean(),
		x: t.number(),
		z: t.number(),
		cost: t.object({
			coins: t.number(),
			missing: t.number(),
			chainFree: t.boolean()
		}).nullable()
	})),
	landmarks: t.array(t.object({
		id: t.string(),
		taken: t.boolean()
	})),
	landmarkDeck: t.int().nonnegative(),
	players: t.array(t.object({
		rid: N,
		coins: t.int().nonnegative(),
		cards: t.array(t.string()),
		units: t.record(t.string(), t.int().nonnegative()),
		fortresses: t.record(t.string(), t.int().nonnegative()),
		tokens: t.array(t.string()),
		quest: t.int().nonnegative(),
		races: t.array(t.string()),
		regions: t.int().nonnegative(),
		faction: t.enum(["fellowship", "sauron"])
	})),
	frodo: t.int().nonnegative(),
	nazgul: t.int().nonnegative(),
	discard: t.array(t.string()),
	winner: t.array(N).nullable(),
	winReason: t.enum([
		"fellowship",
		"sauron",
		"races",
		"conquest",
		"regions",
		"tie"
	]).nullable()
}), F = t.object({}), I = (e) => ({ code: e }), oe = () => Object.fromEntries(m.map((e) => [e, 0])), se = () => Object.fromEntries(h.map((e) => [e, 0]));
function L() {
	return {
		coins: 0,
		cards: [],
		units: oe(),
		forts: oe(),
		tokens: [],
		quest: 15,
		pairs: se(),
		thirdUsed: !1
	};
}
function R(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; --t) {
		let i = e(n.seed, n.cursor, t + 1);
		n.cursor += 1;
		let a = r[t];
		r[t] = r[i], r[i] = a;
	}
	return r;
}
function ce(e, t) {
	let n = C[e.chapter], r = n[t];
	for (let i = 0; i < e.central.length; i += 1) if (!(i === t || e.central[i].taken) && w(n[i], r)) return !0;
	return !1;
}
var le = (e, t) => !e.central[t].taken && !ce(e, t);
function z(e) {
	for (let t = 0; t < e.central.length; t += 1) !e.central[t].taken && le(e, t) && (e.central[t].faceUp = !0);
}
function ue(e, t) {
	e.chapter = t;
	let n = R(S(t), e), r = C[t];
	e.central = r.map((e, t) => ({
		cardId: n[t],
		faceUp: !e.faceDown,
		taken: !1
	}));
	for (let t of n.slice(r.length)) e.discards.push(t);
	z(e);
}
function de(e, t, n) {
	let r = {
		players: [t[0], t[1]],
		turn: 1,
		chapter: 1,
		central: [],
		landmarks: [],
		landmarkDeck: [],
		discards: [],
		piles: Object.fromEntries(h.map((e) => [e, []])),
		ps: [L(), L()],
		frodo: 15,
		nazgul: 1,
		pending: [],
		extraTurn: !1,
		winner: null,
		winReason: null,
		seed: n,
		cursor: 0
	};
	r.ps[0].coins = 3, r.ps[1].coins = 2, r.ps[0].units.arnor = 2, r.ps[1].units.mordor = 2, r.ps[0].quest = 15, r.ps[1].quest = 1, ue(r, 1), r.landmarkDeck = R(T.map((e) => e.id), r);
	for (let e = 0; e < 3; e += 1) r.landmarks.push(r.landmarkDeck.pop());
	for (let e of h) r.piles[e] = R(ee.filter((t) => t.race === e).map((e) => e.id), r);
	return { state: r };
}
function fe(e) {
	let t = [];
	for (let n of e.cards) {
		let e = x(n).effect;
		if (e.kind === "skills") for (let n of e.groups) t.push(n);
	}
	return t;
}
function B(e, t) {
	return e.tokens.some((e) => D(e).effect === t);
}
function pe(e, t) {
	let n = fe(e), r = n.map(() => !1), i = 0;
	for (let e of t) {
		let t = !1;
		for (let i = 0; i < n.length; i += 1) if (!r[i] && n[i].includes(e)) {
			r[i] = !0, t = !0;
			break;
		}
		t || (i += 1);
	}
	return i > 0 && B(e, "elvesAnySkill") && --i, i;
}
function me(e, t) {
	let n = x(t);
	if (n.require && e.cards.some((e) => x(e).grant === n.require)) return {
		coins: 0,
		missing: 0,
		chainFree: !0
	};
	let r = pe(e, n.skills);
	return {
		coins: n.coins + r,
		missing: r,
		chainFree: !1
	};
}
function he(e, t) {
	let n = E(t), r = m.reduce((t, n) => t + e.forts[n], 0), i = B(e, "dwarvesNoExtra") ? 0 : r, a = pe(e, n.skills);
	return {
		coins: n.coins + i + a,
		missing: a
	};
}
function V(e, t, n, r) {
	let i = e.ps[t], a = e.ps[1 - t], o = i.units[n] + r, s = a.units[n];
	i.units[n] = Math.max(0, o - s), a.units[n] = Math.max(0, s - o);
}
function ge(e, t, n, r) {
	let i = e.ps[t];
	i.units[n] <= 0 || (--i.units[n], V(e, t, r, 1));
}
function _e(e, t) {
	return e.units[t] > 0 || e.forts[t] > 0;
}
function H(e) {
	return m.filter((t) => _e(e, t)).length;
}
function ve(e, t) {
	let n = e.ps[t], r = /* @__PURE__ */ new Set();
	for (let e of n.cards) {
		let t = x(e).effect;
		t.kind === "race" && r.add(t.race);
	}
	return B(n, "hobbitsEagle") && r.add("eagle"), [...r];
}
function ye(e) {
	if (!(e.winner !== null || e.winReason)) {
		if (e.frodo >= 29) {
			e.winner = 0, e.winReason = "fellowship";
			return;
		}
		if (e.nazgul >= e.frodo) {
			e.winner = 1, e.winReason = "sauron";
			return;
		}
		for (let t of [0, 1]) {
			if (ve(e, t).length >= 6) {
				e.winner = t, e.winReason = "races";
				return;
			}
			if (H(e.ps[t]) >= 7) {
				e.winner = t, e.winReason = "conquest";
				return;
			}
		}
	}
}
function be(e, t, n, r) {
	let i = O[n];
	if (!i) return;
	let a = e.ps[t];
	if (i === "coin") a.coins += 1;
	else if (i === "unit") e.pending.push({
		kind: "unitAny",
		who: t,
		remaining: 1
	});
	else if (i === "extraTurn") e.extraTurn = !0;
	else if (i === "fortress") {
		let n = m.filter((n) => e.ps[1 - t].forts[n] > 0);
		n.length > 0 && e.pending.push({
			kind: "fortressPick",
			who: t,
			options: n
		});
	}
}
function U(e, t, n, r) {
	let i = e.ps[t];
	if (n <= 0) return;
	let a = i.quest;
	i.quest = Math.min(29, i.quest + n);
	let o = i.quest - a;
	t === 0 ? (e.frodo = i.quest, e.nazgul += o, e.ps[1].quest = e.nazgul) : e.nazgul = i.quest;
	for (let n = a + 1; n <= i.quest; n += 1) be(e, t, n, r);
	ye(e);
}
function xe(e, t) {
	let n = e.ps[t], r = {};
	for (let e of n.cards) {
		let t = x(e).effect;
		t.kind === "race" && (r[t.race] = (r[t.race] ?? 0) + 1);
	}
	for (let i of h) {
		let a = Math.floor((r[i] ?? 0) / 2);
		for (; n.pairs[i] < a;) {
			n.pairs[i] += 1;
			let r = e.piles[i].splice(0, 2);
			r.length > 0 && e.pending.push({
				kind: "tokenPick",
				who: t,
				options: r
			});
		}
	}
	let i = h.filter((e) => (r[e] ?? 0) > 0);
	if (!n.thirdUsed && i.length >= 3) {
		n.thirdUsed = !0;
		let r = [];
		for (let t of i) {
			let n = e.piles[t].shift();
			n && r.push(n);
		}
		r.length > 0 && e.pending.push({
			kind: "tokenPick",
			who: t,
			options: r
		});
	}
}
function Se(e, t, n, r) {
	let i = e.ps[t], a = D(n);
	i.tokens.push(n), a.immediate && Ce(e, t, a.effect, r);
}
function Ce(e, t, n, r) {
	if (n === "entsTurn") e.extraTurn = !0;
	else if (n === "entsFortress") {
		let n = m.filter((n) => e.ps[1 - t].forts[n] > 0);
		n.length > 0 && e.pending.push({
			kind: "fortressPick",
			who: t,
			options: n
		});
	} else n === "entsChoice" ? e.pending.push({
		kind: "entChoice",
		who: t,
		remaining: 3
	}) : n === "wizardsQuest2" ? U(e, t, 2, r) : n === "wizardsUnits" ? e.pending.push({
		kind: "wizardsUnits",
		who: t
	}) : n === "wizardsDiscardFree" && e.discards.length > 0 && e.pending.push({
		kind: "discardPick",
		who: t,
		options: [...e.discards]
	});
}
function we(e, t, n, r) {
	let i = x(n), a = e.ps[t], o = i.effect;
	if (o.kind === "coins") a.coins += o.n, B(a, "elvesYellowTurn") && (e.extraTurn = !0), B(a, "humansYellowQuest") && U(e, t, 1, r);
	else if (o.kind === "quest") U(e, t, o.n, r), B(a, "hobbitsBlueUnit") && e.pending.push({
		kind: "unitAny",
		who: t,
		remaining: 1
	});
	else if (o.kind === "units") {
		let n = B(a, "elvesRedAny") ? [...m] : [...o.regions], r = o.n + +!!B(a, "humansRedExtra");
		e.pending.push({
			kind: "redRegion",
			who: t,
			options: n,
			n: r
		});
	} else o.kind === "race" ? (xe(e, t), B(a, "dwarvesGreenMoves") && e.pending.push({
		kind: "move",
		who: t,
		remaining: 2
	})) : o.kind === "purple" && (o.coinLoss > 0 && (e.ps[1 - t].coins = Math.max(0, e.ps[1 - t].coins - o.coinLoss)), o.removeUnits > 0 && e.pending.push({
		kind: "removeUnit",
		who: t,
		remaining: o.removeUnits
	}), o.moves > 0 && e.pending.push({
		kind: "move",
		who: t,
		remaining: o.moves
	}));
}
function Te(e, t, n, r) {
	let i = e.ps[t], a = E(n);
	if (i.forts[a.region] += 1, a.units > 0 && V(e, t, a.region, a.units), n === "bree") e.pending.push({
		kind: "move",
		who: t,
		remaining: 2
	});
	else if (n === "erebor") i.coins += 5, e.pending.push({
		kind: "move",
		who: t,
		remaining: 1
	});
	else if (n === "greyHavens") e.pending.push({
		kind: "racePick",
		who: t,
		options: [...h]
	});
	else if (n === "isengard") {
		let n = e.ps[1 - t].cards.filter((e) => x(e).color === "grey");
		n.length > 0 && e.pending.push({
			kind: "greyDiscard",
			who: t,
			options: n
		}), U(e, t, 1, r);
	} else n === "minasTirith" ? U(e, t, 2, r) : n === "baradDur" && e.discards.length > 0 && e.pending.push({
		kind: "discardPick",
		who: t,
		options: [...e.discards]
	});
	B(i, "dwarvesTurn") && (e.extraTurn = !0), ye(e);
}
function Ee(e, t) {
	for (; e.pending.length > 0 && ke(e, e.pending[0]).length === 0;) e.pending.shift();
	if (ye(e), !(e.winner !== null || e.winReason) && !(e.pending.length > 0)) {
		if (z(e), e.ps[e.turn], e.central.every((e) => e.taken)) {
			if (e.chapter === 3) {
				De(e);
				return;
			}
			for (ue(e, e.chapter + 1); e.landmarks.length < 3 && e.landmarkDeck.length > 0;) e.landmarks.push(e.landmarkDeck.pop());
		}
		e.extraTurn ? e.extraTurn = !1 : e.turn = 1 - e.turn, z(e);
	}
}
function De(e) {
	let t = H(e.ps[0]), n = H(e.ps[1]);
	t === n ? (e.winner = null, e.winReason = "tie") : t > n ? (e.winner = 0, e.winReason = "regions") : (e.winner = 1, e.winReason = "regions");
}
function Oe(e, t, n) {
	let r = e.players.indexOf(n.by);
	if (r < 0) return I("games.lotrduel.errNotPlayer");
	let i = r, a = structuredClone(e), o = [];
	if (a.winReason) return I("games.lotrduel.errDone");
	if (t.type === "takeCard" || t.type === "takeLandmark") {
		if (a.pending.length > 0) return I("games.lotrduel.errPending");
		if (a.turn !== i) return I("games.lotrduel.errNotYourTurn");
	}
	if (t.type === "takeCard") {
		let e = a.central[t.slot];
		if (!e || e.taken || !e.faceUp || !le(a, t.slot)) return I("games.lotrduel.errBadSlot");
		let n = x(e.cardId), r = a.ps[i];
		if (t.mode === "play") {
			let t = me(r, n.id);
			if (t.coins > r.coins) return I("games.lotrduel.errCantAfford");
			r.coins -= t.coins, r.cards.push(n.id), t.chainFree && B(r, "hobbitsChainCoins") && (r.coins += 3), e.taken = !0, we(a, i, n.id, o);
		} else {
			let t = a.chapter * (B(r, "humansDiscardDouble") ? 2 : 1);
			r.coins += t, a.discards.push(n.id), e.taken = !0;
		}
		return Ee(a, o), { state: a };
	}
	if (t.type === "takeLandmark") {
		let e = a.landmarks[t.index];
		if (!e) return I("games.lotrduel.errBadSlot");
		let n = a.ps[i], r = he(n, e);
		return r.coins > n.coins ? I("games.lotrduel.errCantAfford") : (n.coins -= r.coins, a.landmarks.splice(t.index, 1), Te(a, i, e, o), Ee(a, o), { state: a });
	}
	let s = a.pending[0];
	if (!s) return I("games.lotrduel.errNoPending");
	if (s.who !== i) return I("games.lotrduel.errNotYourChoice");
	let c = a.ps[i];
	switch (s.kind) {
		case "redRegion":
			if (!s.options.includes(t.value)) return I("games.lotrduel.errBadChoice");
			V(a, i, t.value, s.n), a.pending.shift();
			break;
		case "tokenPick": {
			if (!s.options.includes(t.value)) return I("games.lotrduel.errBadChoice");
			Se(a, i, t.value, o);
			let e = s.options.filter((e) => e !== t.value);
			for (let t of e) {
				let e = D(t).race;
				a.piles[e].unshift(t);
			}
			a.pending.shift();
			break;
		}
		case "racePick": {
			let e = t.value;
			if (!s.options.includes(e)) return I("games.lotrduel.errBadChoice");
			let n = a.piles[e].splice(0, 2);
			a.pending.shift(), n.length > 0 && a.pending.unshift({
				kind: "tokenPick",
				who: i,
				options: n
			});
			break;
		}
		case "greyDiscard": {
			if (!s.options.includes(t.value)) return I("games.lotrduel.errBadChoice");
			let e = a.ps[1 - i], n = e.cards.indexOf(t.value);
			n >= 0 && e.cards.splice(n, 1), a.discards.push(t.value), a.pending.shift();
			break;
		}
		case "discardPick": {
			if (!s.options.includes(t.value)) return I("games.lotrduel.errBadChoice");
			let e = a.discards.indexOf(t.value);
			e >= 0 && a.discards.splice(e, 1), c.cards.push(t.value), a.pending.shift(), we(a, i, t.value, o);
			break;
		}
		case "move": {
			let [e, n] = t.value.split(">");
			if (!e || !n || c.units[e] <= 0 || !_(e).includes(n)) return I("games.lotrduel.errBadChoice");
			ge(a, i, e, n), --s.remaining, s.remaining <= 0 && a.pending.shift();
			break;
		}
		case "removeUnit": {
			let e = a.ps[1 - i], n = t.value;
			if (!m.includes(n) || e.units[n] <= 0) return I("games.lotrduel.errBadChoice");
			--e.units[n], --s.remaining, s.remaining <= 0 && a.pending.shift();
			break;
		}
		case "unitAny":
			if (!m.includes(t.value)) return I("games.lotrduel.errBadChoice");
			V(a, i, t.value, 1), --s.remaining, s.remaining <= 0 && a.pending.shift();
			break;
		case "wizardsUnits":
			if (t.value.startsWith("2:")) {
				let e = t.value.slice(2);
				if (!m.includes(e)) return I("games.lotrduel.errBadChoice");
				V(a, i, e, 2), a.pending.shift();
			} else if (t.value.startsWith("1:")) {
				let e = t.value.slice(2);
				if (!m.includes(e)) return I("games.lotrduel.errBadChoice");
				V(a, i, e, 1), a.pending.shift(), a.pending.unshift({
					kind: "unitAny",
					who: i,
					remaining: 1
				});
			} else return I("games.lotrduel.errBadChoice");
			break;
		case "fortressPick": {
			let e = t.value;
			if (!s.options.includes(e)) return I("games.lotrduel.errBadChoice");
			--a.ps[1 - i].forts[e], a.pending.shift();
			break;
		}
		case "entChoice": {
			let e = t.value;
			if (e === "coin") a.ps[1 - i].coins = Math.max(0, a.ps[1 - i].coins - 1);
			else if (e.startsWith("remove:")) {
				let t = e.slice(7);
				if (!m.includes(t) || a.ps[1 - i].units[t] <= 0) return I("games.lotrduel.errBadChoice");
				--a.ps[1 - i].units[t];
			} else if (e.startsWith("move:")) {
				let [t, n] = e.slice(5).split(">");
				if (!t || !n || c.units[t] <= 0 || !_(t).includes(n)) return I("games.lotrduel.errBadChoice");
				ge(a, i, t, n);
			} else return I("games.lotrduel.errBadChoice");
			--s.remaining, s.remaining <= 0 && a.pending.shift();
			break;
		}
	}
	return Ee(a, o), { state: a };
}
function ke(e, t) {
	let n = t.who, r = e.ps[n];
	switch (t.kind) {
		case "redRegion": return [...t.options];
		case "tokenPick": return [...t.options];
		case "racePick": return [...t.options];
		case "greyDiscard": return [...t.options];
		case "discardPick": return [...t.options];
		case "move": {
			let e = [];
			for (let t of m) if (!(r.units[t] <= 0)) for (let n of _(t)) e.push(`${t}>${n}`);
			return e;
		}
		case "removeUnit": return m.filter((t) => e.ps[1 - n].units[t] > 0);
		case "unitAny": return [...m];
		case "wizardsUnits": return m.flatMap((e) => [`2:${e}`, `1:${e}`]);
		case "fortressPick": return m.filter((t) => e.ps[1 - n].forts[t] > 0);
		case "entChoice": {
			let t = ["coin"];
			for (let r of m) e.ps[1 - n].units[r] > 0 && t.push(`remove:${r}`);
			for (let e of m) if (!(r.units[e] <= 0)) for (let n of _(e)) t.push(`move:${e}>${n}`);
			return t;
		}
	}
}
function Ae(e, t) {
	let n = e.players.indexOf(t), r = n >= 0 ? e.ps[n] : null, i = e.pending[0] ?? null;
	return {
		public: {
			phase: e.winReason ? "done" : e.pending.length > 0 ? "choice" : "turn",
			chapter: e.chapter,
			turn: e.players[e.turn],
			pending: i ? {
				kind: i.kind,
				who: e.players[i.who],
				options: ke(e, i),
				remaining: "remaining" in i ? i.remaining : 0
			} : null,
			central: e.central.map((t, n) => ({
				slot: n,
				cardId: t.faceUp ? t.cardId : null,
				faceUp: t.faceUp,
				taken: t.taken,
				accessible: le(e, n),
				x: C[e.chapter][n].x,
				z: C[e.chapter][n].z,
				cost: t.faceUp && !t.taken && r ? me(r, t.cardId) : null
			})),
			landmarks: e.landmarks.map((e) => ({
				id: e,
				taken: !1
			})),
			landmarkDeck: e.landmarkDeck.length,
			players: e.players.map((t, n) => ({
				rid: t,
				coins: e.ps[n].coins,
				cards: [...e.ps[n].cards],
				units: { ...e.ps[n].units },
				fortresses: { ...e.ps[n].forts },
				tokens: [...e.ps[n].tokens],
				quest: e.ps[n].quest,
				races: ve(e, n),
				regions: H(e.ps[n]),
				faction: n === 0 ? "fellowship" : "sauron"
			})),
			frodo: e.frodo,
			nazgul: e.nazgul,
			discard: [...e.discards],
			winner: e.winner === null && !e.winReason ? null : e.winner === null ? [...e.players] : [e.players[e.winner]],
			winReason: e.winReason
		},
		private: {}
	};
}
function je(e) {
	if (!e.winReason) return { phase: "play" };
	let t = e.winner === null ? [...e.players] : [e.players[e.winner], e.players[1 - e.winner]], n = Object.fromEntries(e.players.map((t, n) => [t, H(e.ps[n])]));
	return {
		phase: "done",
		winner: e.winner === null ? [...e.players] : [e.players[e.winner]],
		ranking: t,
		scores: n
	};
}
var Me = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ae,
	schemas: {
		action: M,
		publicView: P,
		privateView: F
	},
	setup: de,
	reduce: Oe,
	viewFor: Ae,
	status: je
};
//#endregion
//#region src/game/icons.tsx
function W({ size: e = 20, className: t, children: n, strokeWidth: r = 1.8, fill: i = "none" }) {
	return /* @__PURE__ */ f("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		fill: i,
		stroke: "currentColor",
		strokeWidth: r,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className: t,
		"aria-hidden": "true",
		children: n
	});
}
var Ne = {
	ruse: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M5 19l1-4 9-9 3-1 1 1-1 3-9 9-4 1z" }), /* @__PURE__ */ f("path", { d: "M8 14l2 2" })] }),
	strength: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M7 13V9.5a1.5 1.5 0 0 1 3 0V13" }),
		/* @__PURE__ */ f("path", { d: "M10 13V8a1.5 1.5 0 0 1 3 0v5" }),
		/* @__PURE__ */ f("path", { d: "M13 13V9a1.5 1.5 0 0 1 3 0v4" }),
		/* @__PURE__ */ f("path", { d: "M16 13v-1.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-1a5 5 0 0 1-5-5v-3.5a1.5 1.5 0 0 1 3 0V14" })
	] }),
	courage: /* @__PURE__ */ f("path", { d: "M12 20s-7.5-4.6-9.5-9A5 5 0 0 1 12 7a5 5 0 0 1 9.5 4C19.5 15.4 12 20 12 20z" }),
	knowledge: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M12 6.5C10 5 8 4.4 5 4.5V19c3-.1 5 .5 7 2 2-1.5 4-2.1 7-2V4.5c-3-.1-5 .5-7 2z" }), /* @__PURE__ */ f("path", { d: "M12 6.5V21" })] }),
	leadership: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M6.5 18.5h11" }), /* @__PURE__ */ f("path", { d: "M5.5 18L4 7.5l5 4L12 4l3 7.5 5-4L18.5 18" })] })
};
function G({ s: e, size: t = 18 }) {
	return /* @__PURE__ */ f(W, {
		size: t,
		children: Ne[e]
	});
}
var Pe = {
	elves: /* @__PURE__ */ f("path", { d: "M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z" }),
	ents: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M12 22v-8" }),
		/* @__PURE__ */ f("path", { d: "M12 15l-4-3M12 15l4-3" }),
		/* @__PURE__ */ f("path", { d: "M12 4a4.5 4.5 0 0 1 4.5 4.5c0 2.2-1.8 3.9-4.5 4.5-2.7-.6-4.5-2.3-4.5-4.5A4.5 4.5 0 0 1 12 4z" })
	] }),
	hobbits: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4 12.5h6V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z" }),
		/* @__PURE__ */ f("path", { d: "M10 15h4l6-6" }),
		/* @__PURE__ */ f("path", { d: "M18 7c1 1.2 2.2 1.2 3 0" })
	] }),
	humans: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M14.5 17.5L3 6V3h3l11.5 11.5" }),
		/* @__PURE__ */ f("path", { d: "M13 19l6-6" }),
		/* @__PURE__ */ f("path", { d: "M16 16l4 4" }),
		/* @__PURE__ */ f("path", { d: "M19 21l2-2" })
	] }),
	dwarves: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M3.5 9.5h7.5c2.1 0 3.3 1.2 3.3 3.2h5.2c0 2-2 3.3-4.2 3.3h-1.5l-2 3.5H7.5L4.6 16.8H3.5z" }), /* @__PURE__ */ f("path", { d: "M8 19.5V22h7v-2.5" })] }),
	wizards: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M7 21L15 7.5" }), /* @__PURE__ */ f("circle", {
		cx: "16.5",
		cy: "4.5",
		r: "2.4"
	})] })
};
function Fe({ race: e, size: t = 18 }) {
	return /* @__PURE__ */ f(W, {
		size: t,
		children: Pe[e]
	});
}
var Ie = {
	horse: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M4.5 20.5V14l4-6 3 1 3.5-3 2.5 3-2 4v2.5c0 3-2.5 5-6 5h-5z" }), /* @__PURE__ */ f("circle", {
		cx: "16",
		cy: "7.5",
		r: ".5",
		fill: "currentColor"
	})] }),
	teapot: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4 11.5h9a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z" }),
		/* @__PURE__ */ f("path", { d: "M13 12l5-2v4l-5 1" }),
		/* @__PURE__ */ f("path", { d: "M6.5 11.5V9h4v2.5" }),
		/* @__PURE__ */ f("path", { d: "M8.5 7c0-1 .8-1.2.8-2" })
	] }),
	fish: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M3.5 12c3-3.6 7.5-3.6 10.5 0-3 3.6-7.5 3.6-10.5 0z" }),
		/* @__PURE__ */ f("path", { d: "M14 12l5-3v6z" }),
		/* @__PURE__ */ f("circle", {
			cx: "7",
			cy: "11.4",
			r: ".5",
			fill: "currentColor"
		})
	] }),
	harp: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M6.5 4c0 7.5 3.5 11 9.5 13" }),
		/* @__PURE__ */ f("path", { d: "M6.5 4h10v13" }),
		/* @__PURE__ */ f("path", { d: "M9 7v8M12 9.5v7M15 12v6" })
	] }),
	anvil: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M3.5 9.5h7.5c2.1 0 3.3 1.2 3.3 3.2h5.2c0 2-2 3.3-4.2 3.3h-1.5l-2 3.5H7.5L4.6 16.8H3.5z" }), /* @__PURE__ */ f("path", { d: "M8 19.5V22h7v-2.5" })] }),
	pot: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4 11.5h14v2.5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z" }),
		/* @__PURE__ */ f("path", { d: "M7.5 8.5h7" }),
		/* @__PURE__ */ f("path", { d: "M2.5 11.5H4M18 11.5h1.5" })
	] }),
	horseshoe: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M6 20.5V12a6 6 0 0 1 12 0v8.5" }), /* @__PURE__ */ f("path", { d: "M9 20.5V12M15 20.5V12" })] }),
	crossedSwords: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4.5 4.5l13 13" }),
		/* @__PURE__ */ f("path", { d: "M19.5 4.5l-13 13" }),
		/* @__PURE__ */ f("path", { d: "M4.5 20.5l3-3M19.5 20.5l-3-3" })
	] }),
	sword: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M14.5 17.5L3 6V3h3l11.5 11.5" }),
		/* @__PURE__ */ f("path", { d: "M13 19l6-6" }),
		/* @__PURE__ */ f("path", { d: "M16 16l4 4" }),
		/* @__PURE__ */ f("path", { d: "M19 21l2-2" })
	] }),
	helmet: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M5.5 15h13v3.5h-13z" }),
		/* @__PURE__ */ f("path", { d: "M6.5 15V9a5.5 5.5 0 0 1 11 0v6" }),
		/* @__PURE__ */ f("path", { d: "M12 3v12" })
	] }),
	chest: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4 10h16v9.5H4z" }),
		/* @__PURE__ */ f("path", { d: "M4 10V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2" }),
		/* @__PURE__ */ f("path", { d: "M10 10v4h4v-4" })
	] }),
	scroll: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M6.5 3.5h11v14.5a2.5 2.5 0 0 0 2.5 2.5H8a2 2 0 0 1-2-2z" }),
		/* @__PURE__ */ f("path", { d: "M6.5 3.5a2 2 0 0 0-2 2v3h3" }),
		/* @__PURE__ */ f("path", { d: "M9.5 8h5M9.5 12h5M9.5 16h5" })
	] }),
	campfire: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M12 3.5c2 2.8 4 4.2 4 7a4 4 0 0 1-8 0c0-2.8 2-4.2 4-7z" }), /* @__PURE__ */ f("path", { d: "M4.5 20.5l15-2.5M19.5 20.5l-15-2.5" })] }),
	axe: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M5 20l11-11" }), /* @__PURE__ */ f("path", { d: "M13.5 4.5l6 1-1 6-4-1-2.5-4z" })] }),
	flag: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M6 3v18" }), /* @__PURE__ */ f("path", { d: "M6 4h12l-3 4 3 4H6" })] })
}, Le = /* @__PURE__ */ p(d, { children: [
	/* @__PURE__ */ f("path", { d: "M9.5 14.5l5-5" }),
	/* @__PURE__ */ f("path", { d: "M7.2 17.8a3.6 3.6 0 0 1 0-5.1l2.3-2.3" }),
	/* @__PURE__ */ f("path", { d: "M16.8 6.2a3.6 3.6 0 0 1 0 5.1l-2.3 2.3" })
] });
function K({ c: e, size: t = 12 }) {
	return /* @__PURE__ */ f(W, {
		size: t,
		strokeWidth: 2,
		children: e ? Ie[e] : Le
	});
}
var Re = {
	lindon: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M4 16.5h16l-2.2-4H6.2z" }),
		/* @__PURE__ */ f("path", { d: "M12 12.5V5" }),
		/* @__PURE__ */ f("path", { d: "M12 5l5 3.2h-5" })
	] }),
	arnor: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M6.5 18.5h11" }), /* @__PURE__ */ f("path", { d: "M5.5 18L4 7.5l5 4L12 4l3 7.5 5-4L18.5 18" })] }),
	enedwaith: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M2.5 19.5l6-10 4 6 3-4.5 6 8.5z" }), /* @__PURE__ */ f("path", { d: "M7 11.5l2 2 1.8-2.4" })] }),
	rhovanion: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M4.5 19.5C4.5 9.5 12 3.5 20 3.5c0 9.5-6.5 16-15.5 16z" }), /* @__PURE__ */ f("path", { d: "M4.5 19.5L14 10" })] }),
	rohan: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M4.5 20.5V14l4-6 3 1 3.5-3 2.5 3-2 4v2.5c0 3-2.5 5-6 5h-5z" }), /* @__PURE__ */ f("path", { d: "M9 10.5l3 1.5" })] }),
	gondor: /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M12 21.5v-6" }),
		/* @__PURE__ */ f("path", { d: "M12 15.5l-3-2M12 15.5l3-2" }),
		/* @__PURE__ */ f("path", { d: "M12 5a4.6 4.6 0 0 1 4.6 4.6c0 2.2-1.9 4-4.6 4.9-2.7-.9-4.6-2.7-4.6-4.9A4.6 4.6 0 0 1 12 5z" }),
		/* @__PURE__ */ f("path", { d: "M12 1.8v1.4" })
	] }),
	mordor: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M3 12s3.8-5.5 9-5.5S21 12 21 12s-3.8 5.5-9 5.5S3 12 3 12z" }), /* @__PURE__ */ f("circle", {
		cx: "12",
		cy: "12",
		r: "2.6"
	})] })
};
function q({ r: e, size: t = 16 }) {
	return /* @__PURE__ */ f(W, {
		size: t,
		children: Re[e]
	});
}
function J({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "8"
		}), /* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "3"
		})]
	});
}
function Y({ size: e = 14 }) {
	return /* @__PURE__ */ f(W, {
		size: e,
		children: /* @__PURE__ */ f("path", { d: "M12 3l7 2.2V12c0 5-3 8.2-7 10-4-1.8-7-5-7-10V5.2z" })
	});
}
function ze({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [
			/* @__PURE__ */ f("path", { d: "M5 21V9.5h3V6.5h2.5v3h3v-3H16v3h3V21z" }),
			/* @__PURE__ */ f("path", { d: "M10 21v-5h4v5" }),
			/* @__PURE__ */ f("path", { d: "M3 21h18" })
		]
	});
}
function Be({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M4 12a8 8 0 1 0 2.7-6" }), /* @__PURE__ */ f("path", { d: "M4 3.5V8h4.5" })]
	});
}
function X({ size: e = 16 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "7.2"
		}), /* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "4.6"
		})]
	});
}
function Ve({ size: e = 16 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M3 12s3.8-5.5 9-5.5S21 12 21 12s-3.8 5.5-9 5.5S3 12 3 12z" }), /* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "2.6"
		})]
	});
}
function He({ size: e = 16 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M2.5 20.5l7-14 4 8 2.5-4 5.5 10z" }), /* @__PURE__ */ f("path", { d: "M8.5 9.5l1.2-1.2 1.6 2.4" })]
	});
}
function Ue({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [
			/* @__PURE__ */ f("path", { d: "M12 3l6.5 2v6c0 4.4-2.7 7.3-6.5 9-3.8-1.7-6.5-4.6-6.5-9V5z" }),
			/* @__PURE__ */ f("path", { d: "M8.8 12h5.4" }),
			/* @__PURE__ */ f("path", { d: "M12.2 9.8l2.2 2.2-2.2 2.2" })
		]
	});
}
function We({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M12 3l6.5 2v6c0 4.4-2.7 7.3-6.5 9-3.8-1.7-6.5-4.6-6.5-9V5z" }), /* @__PURE__ */ f("path", { d: "M9.4 9.4l5.2 5.2M14.6 9.4l-5.2 5.2" })]
	});
}
function Ge({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "8"
		}), /* @__PURE__ */ f("path", { d: "M8 12h8" })]
	});
}
function Ke({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M12 3l1.6 3.9 4.2.4-3.2 2.8 1 4.1L12 12l-3.6 2.2 1-4.1-3.2-2.8 4.2-.4z" }), /* @__PURE__ */ f("path", { d: "M5.5 20.5h13" })]
	});
}
function qe({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M3 6.5l6-2.5 6 2.5 6-2.5v13l-6 2.5-6-2.5-6 2.5z" }), /* @__PURE__ */ f("path", { d: "M9 4v13M15 6.5v13" })]
	});
}
function Z({ size: e = 14 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [
			/* @__PURE__ */ f("rect", {
				x: "7.5",
				y: "4",
				width: "11",
				height: "15",
				rx: "1.5"
			}),
			/* @__PURE__ */ f("path", { d: "M10.5 7.5h5M10.5 10.5h5M10.5 13.5h3" }),
			/* @__PURE__ */ f("path", { d: "M5.5 6.5v13.5h10" })
		]
	});
}
function Q({ size: e = 28 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "11",
				r: "5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 6.2c2.7 0 5 2.2 5 4.8s-2.3 4.8-5 4.8",
				opacity: ".55"
			}),
			/* @__PURE__ */ f("path", { d: "M7.5 19.5c-3-1.4-4.5-4-4.2-7.2" }),
			/* @__PURE__ */ f("path", { d: "M4.5 13.6l-2.2.3M5.5 16.2l-2.2.6M7.8 18.2l-1.6 1.4" }),
			/* @__PURE__ */ f("path", { d: "M16.5 19.5c3-1.4 4.5-4 4.2-7.2" }),
			/* @__PURE__ */ f("path", { d: "M19.5 13.6l2.2.3M18.5 16.2l2.2.6M16.2 18.2l1.6 1.4" })
		]
	});
}
function $({ size: e = 28 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [
			/* @__PURE__ */ f("path", { d: "M5 9.5l2.2-5 2.2 4L12 2.5l2.6 6 2.2-4 2.2 5v2.7H5z" }),
			/* @__PURE__ */ f("path", { d: "M7 16s2-3 5-3 5 3 5 3-2 3-5 3-5-3-5-3z" }),
			/* @__PURE__ */ f("circle", {
				cx: "12",
				cy: "16",
				r: "1.5"
			})
		]
	});
}
function Je({ size: e = 30 }) {
	return /* @__PURE__ */ p(W, {
		size: e,
		children: [/* @__PURE__ */ f("path", { d: "M12 3l2.6 5.4 5.9.8-4.3 4.1 1.1 5.8L12 16.3l-5.3 2.8 1.1-5.8-4.3-4.1 5.9-.8z" }), /* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "2.2"
		})]
	});
}
//#endregion
//#region src/game/card.tsx
var Ye = {
	yellow: "#b8912f",
	blue: "#27477c",
	red: "#8a2a22",
	green: "#33642f",
	grey: "#8c8c86",
	purple: "#553469"
};
function Xe({ def: e }) {
	let t = o(), n = e.effect;
	return n.kind === "coins" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(J, {}), /* @__PURE__ */ f("b", {
		className: "ld-card-num",
		children: n.n
	})] }) : n.kind === "quest" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(X, {}), /* @__PURE__ */ f("b", {
		className: "ld-card-num",
		children: n.n
	})] }) : n.kind === "units" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
		className: "ld-card-line",
		children: [/* @__PURE__ */ f(Y, {}), /* @__PURE__ */ f("b", {
			className: "ld-card-num",
			children: n.n
		})]
	}), /* @__PURE__ */ f("span", {
		className: "ld-card-regions",
		children: n.regions.map((e) => /* @__PURE__ */ f(q, { r: e }, e))
	})] }) : n.kind === "race" ? /* @__PURE__ */ f(Fe, { race: n.race }) : n.kind === "skills" ? /* @__PURE__ */ f("span", {
		className: "ld-card-groups",
		children: n.groups.map((e, t) => /* @__PURE__ */ f("span", {
			className: "ld-card-group",
			children: e.map((e) => /* @__PURE__ */ f(G, { s: e }, e))
		}, t))
	}) : /* @__PURE__ */ p("span", {
		className: "ld-card-purple",
		children: [
			n.moves > 0 && /* @__PURE__ */ p("span", {
				title: t("games.lotrduel.purpleMove", { n: n.moves }),
				children: [/* @__PURE__ */ f(Ue, {}), /* @__PURE__ */ f("b", { children: n.moves })]
			}),
			n.removeUnits > 0 && /* @__PURE__ */ p("span", {
				title: t("games.lotrduel.purpleRemove", { n: n.removeUnits }),
				children: [/* @__PURE__ */ f(We, {}), /* @__PURE__ */ f("b", { children: n.removeUnits })]
			}),
			n.coinLoss > 0 && /* @__PURE__ */ p("span", {
				title: t("games.lotrduel.purpleCoin", { n: n.coinLoss }),
				children: [/* @__PURE__ */ f(Ge, {}), /* @__PURE__ */ f("b", { children: n.coinLoss })]
			})
		]
	});
}
function Ze(e) {
	let t = o(), n = e.effect;
	if (n.kind === "coins") return t("games.lotrduel.effectCoins", { n: n.n });
	if (n.kind === "quest") return t("games.lotrduel.effectQuest", { n: n.n });
	if (n.kind === "units") {
		let e = t(k[n.regions[0]]), r = t(k[n.regions[1]]);
		return `${t("games.lotrduel.effectUnits", { n: n.n })}\n${t("games.lotrduel.needRegion", {
			a: e,
			b: r
		})}`;
	}
	if (n.kind === "race") return t("games.lotrduel.effectRace", { race: t(ne[n.race]) });
	if (n.kind === "skills") return t("games.lotrduel.effectSkills", { list: n.groups.map((e) => e.map((e) => t(re[e])).join("/")).join(" · ") });
	let r = [];
	return n.moves > 0 && r.push(t("games.lotrduel.purpleMove", { n: n.moves })), n.removeUnits > 0 && r.push(t("games.lotrduel.purpleRemove", { n: n.removeUnits })), n.coinLoss > 0 && r.push(t("games.lotrduel.purpleCoin", { n: n.coinLoss })), r.join("\n");
}
function Qe({ id: e, faceUp: t, dim: n, selected: r, live: i, onClick: a, cost: s }) {
	let c = o(), l = x(e), u = Ze(l);
	if (!t) return /* @__PURE__ */ p("button", {
		type: "button",
		onClick: a,
		disabled: !a,
		className: `ld-card ld-card-back${r ? " is-sel" : ""}`,
		"aria-label": c("games.lotrduel.cardFaceDown"),
		children: [/* @__PURE__ */ f("span", {
			className: "ld-card-frame",
			"aria-hidden": !0
		}), /* @__PURE__ */ f("span", {
			className: "ld-card-backmark",
			"aria-hidden": !0,
			children: /* @__PURE__ */ f(X, {})
		})]
	});
	let m = s?.chainFree ?? !1, h = s ? m ? 0 : s.coins : l.coins;
	return /* @__PURE__ */ p("button", {
		type: "button",
		onClick: a,
		disabled: !a,
		className: `ld-card${n ? " is-dim" : ""}${r ? " is-sel" : ""}${i ? " is-live" : ""}`,
		style: { "--ld-tint": Ye[l.color] },
		"aria-label": `${c(A[l.color])} · ${u.replaceAll("\n", " · ")}`,
		"aria-pressed": r || void 0,
		children: [
			/* @__PURE__ */ f("span", {
				className: "ld-card-frame",
				"aria-hidden": !0
			}),
			(h > 0 || m) && /* @__PURE__ */ f("span", {
				className: "ld-card-cost",
				children: m ? /* @__PURE__ */ f(K, {}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(J, {}), /* @__PURE__ */ f("b", { children: h })] })
			}),
			l.grant && /* @__PURE__ */ f("span", {
				className: "ld-card-grant",
				title: c(j[l.grant]),
				children: /* @__PURE__ */ f(K, { c: l.grant })
			}),
			l.require && /* @__PURE__ */ f("span", {
				className: "ld-card-req",
				title: c("games.lotrduel.requirement", { chain: c(j[l.require]) }),
				children: /* @__PURE__ */ f(K, { c: l.require })
			}),
			/* @__PURE__ */ f("span", {
				className: "ld-card-effect",
				children: /* @__PURE__ */ f(Xe, { def: l })
			}),
			l.skills.length > 0 && /* @__PURE__ */ f("span", {
				className: "ld-card-skills",
				children: l.skills.map((e, t) => /* @__PURE__ */ f("span", {
					className: "ld-card-skill",
					title: c(re[e]),
					children: /* @__PURE__ */ f(G, { s: e })
				}, t))
			})
		]
	});
}
function $e({ id: e }) {
	let t = o(), n = x(e), r = Ze(n);
	return /* @__PURE__ */ p("span", {
		className: "ld-chip",
		title: `${t(A[n.color])} · ${r.replaceAll("\n", " · ")}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "ld-chip-band",
				style: { background: Ye[n.color] },
				"aria-hidden": !0
			}),
			/* @__PURE__ */ f(et, { def: n }),
			n.grant && /* @__PURE__ */ f("span", {
				className: "ld-chip-chain",
				"aria-hidden": !0,
				children: /* @__PURE__ */ f(K, {
					c: n.grant,
					size: 10
				})
			})
		]
	});
}
function et({ def: e }) {
	let t = e.effect;
	if (t.kind === "coins") return /* @__PURE__ */ p("span", {
		className: "ld-chip-g",
		children: [/* @__PURE__ */ f(J, { size: 12 }), /* @__PURE__ */ f("b", { children: t.n })]
	});
	if (t.kind === "quest") return /* @__PURE__ */ p("span", {
		className: "ld-chip-g",
		children: [/* @__PURE__ */ f(X, { size: 12 }), /* @__PURE__ */ f("b", { children: t.n })]
	});
	if (t.kind === "units") return /* @__PURE__ */ p("span", {
		className: "ld-chip-g",
		children: [/* @__PURE__ */ f(Y, { size: 12 }), /* @__PURE__ */ f("b", { children: t.n })]
	});
	if (t.kind === "race") return /* @__PURE__ */ f(Fe, {
		race: t.race,
		size: 13
	});
	if (t.kind === "skills") {
		let e = t.groups[0] ?? [];
		return /* @__PURE__ */ f("span", {
			className: "ld-chip-g ld-chip-skills",
			children: e.map((e) => /* @__PURE__ */ f(G, {
				s: e,
				size: 11
			}, e))
		});
	}
	return /* @__PURE__ */ p("span", {
		className: "ld-chip-g",
		children: [
			t.moves > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Ue, { size: 11 }), /* @__PURE__ */ f("b", { children: t.moves })] }),
			t.removeUnits > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(We, { size: 11 }), /* @__PURE__ */ f("b", { children: t.removeUnits })] }),
			t.coinLoss > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Ge, { size: 11 }), /* @__PURE__ */ f("b", { children: t.coinLoss })] })
		]
	});
}
function tt({ id: e, selected: t, onClick: n }) {
	let i = o(), a = E(e);
	return /* @__PURE__ */ p("button", {
		type: "button",
		onClick: n,
		"aria-pressed": t || void 0,
		title: `${i(ie[a.id])} · ${i(k[a.region])}`,
		className: `ld-lmtile${t ? " is-sel" : ""}`,
		children: [
			/* @__PURE__ */ f("img", {
				src: r(`games/lotrduel/lm/${a.id}.webp`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ p("span", {
				className: "ld-lmname",
				children: [/* @__PURE__ */ f(q, {
					r: a.region,
					size: 12
				}), i(ie[a.id])]
			}),
			/* @__PURE__ */ p("span", {
				className: "ld-lmfoot",
				children: [/* @__PURE__ */ f("span", {
					className: "ld-lmregion",
					children: i(k[a.region])
				}), /* @__PURE__ */ p("span", {
					className: "ld-lmreq",
					children: [a.skills.map((e, t) => /* @__PURE__ */ f(G, {
						s: e,
						size: 9
					}, t)), /* @__PURE__ */ p("span", {
						className: "ld-lmcoin",
						children: [/* @__PURE__ */ f(J, { size: 9 }), a.coins]
					})]
				})]
			})
		]
	});
}
function nt({ id: e }) {
	let t = o(), n = D(e);
	return /* @__PURE__ */ p("span", {
		className: "ld-token",
		title: t(ne[n.race]),
		children: [/* @__PURE__ */ f(Fe, {
			race: n.race,
			size: 12
		}), /* @__PURE__ */ f("span", { children: t(ne[n.race]) })]
	});
}
//#endregion
//#region src/game/ending.tsx
function rt(e, t, n) {
	let r = t.winner?.[0] ?? "";
	return t.winReason === "fellowship" ? e("games.lotrduel.winFellowship") : t.winReason === "sauron" ? e("games.lotrduel.winSauron") : t.winReason === "races" ? e("games.lotrduel.winRaces", { name: n(r) }) : t.winReason === "conquest" ? e("games.lotrduel.winConquest", { name: n(r) }) : t.winReason === "regions" ? e("games.lotrduel.winRegions", { name: n(r) }) : t.winReason === "tie" ? e("games.lotrduel.winTie") : "";
}
function it(e) {
	return e.winReason === "fellowship" ? "fel" : e.winReason === "sauron" ? "sau" : e.winReason === "tie" ? "tie" : "banner";
}
function at({ theme: e }) {
	return e === "sau" ? /* @__PURE__ */ f("span", {
		className: "ld-end-emblem",
		children: /* @__PURE__ */ f($, { size: 104 })
	}) : e === "fel" ? /* @__PURE__ */ p("svg", {
		className: "ld-end-emblem",
		viewBox: "0 0 120 120",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "60",
				cy: "48",
				r: "27",
				opacity: ".22"
			}),
			/* @__PURE__ */ f("path", { d: "M38 60a27 27 0 0 1 44-20" }),
			/* @__PURE__ */ f("path", {
				d: "M82 37a27 27 0 0 1-2 34",
				opacity: ".75"
			}),
			/* @__PURE__ */ f("path", { d: "M60 21l-5 11 7 7-5 11" }),
			/* @__PURE__ */ f("path", {
				d: "M60 21v-9M84 26l6-6M92 48h9M36 26l-6-6M28 48h-9M47 24l2-8M73 24l-2-8",
				opacity: ".6"
			}),
			/* @__PURE__ */ f("path", {
				d: "M22 102l13-20 6 9 7-13 8 24z",
				fill: "currentColor",
				fillOpacity: ".14"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 106h92",
				opacity: ".7"
			}),
			/* @__PURE__ */ f("path", {
				d: "M44 102l5-8 4 5 3-6 5 9",
				opacity: ".9"
			})
		]
	}) : e === "tie" ? /* @__PURE__ */ p("svg", {
		className: "ld-end-emblem",
		viewBox: "0 0 120 120",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", { d: "M42 24v76M78 24v76" }),
			/* @__PURE__ */ f("path", { d: "M42 30l-20 8 20 8z" }),
			/* @__PURE__ */ f("path", { d: "M78 30l20 8-20 8z" }),
			/* @__PURE__ */ f("path", {
				d: "M60 18v84",
				opacity: ".35",
				strokeDasharray: "4 5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M30 100h60",
				opacity: ".7"
			})
		]
	}) : /* @__PURE__ */ p("svg", {
		className: "ld-end-emblem",
		viewBox: "0 0 120 120",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", { d: "M34 30v78M86 30v78" }),
			/* @__PURE__ */ f("path", { d: "M34 34l-24 9 24 9z" }),
			/* @__PURE__ */ f("path", { d: "M86 34l24 9-24 9z" }),
			/* @__PURE__ */ f("path", {
				d: "M60 30v78",
				opacity: ".4"
			}),
			/* @__PURE__ */ f("path", {
				d: "M26 100c8-16 16-24 24-24 7 0 11 5 16 5s10-8 18-8 12 10 18 27z",
				fill: "currentColor",
				fillOpacity: ".14"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 104h92",
				opacity: ".7"
			}),
			/* @__PURE__ */ f("path", {
				d: "M46 70l14-18 14 18M54 52l6-8 6 8",
				opacity: ".85"
			})
		]
	});
}
function ot({ pub: e, members: t, myRid: n, mode: r, ranking: c, onInspect: l, onPlayAgain: d, onBackToLobby: m }) {
	let h = o(), g = a((e) => e.locale), _ = it(e), v = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? u(n, g) : e;
	}, y = c && c.length === e.players.length ? c : [...e.players].sort((t, n) => Number(e.winner?.includes(n.rid) ?? !1) - Number(e.winner?.includes(t.rid) ?? !1)).map((e) => e.rid), b = !!(d || m);
	return /* @__PURE__ */ p("div", {
		className: `ld-ending is-${r} ld-end-${_}`,
		role: r === "overlay" ? "dialog" : void 0,
		"aria-label": rt(h, e, v),
		children: [/* @__PURE__ */ f("div", {
			className: "ld-end-art",
			"aria-hidden": !0
		}), /* @__PURE__ */ p("div", {
			className: "ld-end-inner",
			children: [
				/* @__PURE__ */ f("p", {
					className: "ld-end-kicker",
					children: h("games.lotrduel.endingKicker", { n: e.chapter })
				}),
				/* @__PURE__ */ f(at, { theme: _ }),
				/* @__PURE__ */ f("h1", {
					className: "ld-end-title",
					children: rt(h, e, v)
				}),
				/* @__PURE__ */ f("div", {
					className: "ld-end-standings",
					children: y.map((r) => {
						let a = e.players.find((e) => e.rid === r);
						if (!a) return null;
						let o = t.find((e) => e.rid === r), c = e.winner?.includes(r) ?? !1, l = s[(o?.colorIndex ?? 0) % s.length], u = a.faction === "fellowship";
						return /* @__PURE__ */ p("div", {
							className: "ld-end-player",
							"data-won": c,
							children: [
								/* @__PURE__ */ f("span", {
									className: "ld-end-avatar",
									style: { background: l.hex },
									children: o && /* @__PURE__ */ f("img", {
										src: i[o.avatar % i.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ p("div", {
									className: "ld-end-who",
									children: [/* @__PURE__ */ p("b", { children: [v(r), r === n && /* @__PURE__ */ f("small", { children: h("lobby.you") })] }), /* @__PURE__ */ p("span", {
										className: `ld-end-faction ${u ? "is-fel" : "is-sau"}`,
										children: [f(u ? Q : $, { size: 15 }), h(u ? "games.lotrduel.faction.fellowship" : "games.lotrduel.faction.sauron")]
									})]
								}),
								/* @__PURE__ */ p("div", {
									className: "ld-end-stats",
									children: [
										/* @__PURE__ */ p("span", {
											title: h("games.lotrduel.regionsCount", { n: a.regions }),
											children: [
												/* @__PURE__ */ f(qe, { size: 14 }),
												a.regions,
												"/7"
											]
										}),
										/* @__PURE__ */ p("span", {
											title: h("games.lotrduel.racesCount", { n: a.races.length }),
											children: [
												/* @__PURE__ */ f(Ke, { size: 14 }),
												a.races.length,
												"/6"
											]
										}),
										/* @__PURE__ */ p("span", {
											title: h("games.lotrduel.coins"),
											children: [/* @__PURE__ */ f(J, { size: 14 }), a.coins]
										}),
										/* @__PURE__ */ p("span", {
											title: h("games.lotrduel.cardsCount", { n: a.cards.length }),
											children: [/* @__PURE__ */ f(Z, { size: 14 }), a.cards.length]
										})
									]
								}),
								c && /* @__PURE__ */ f("span", {
									className: "ld-end-win",
									children: h("games.lotrduel.winnerMark")
								})
							]
						}, r);
					})
				}),
				r === "overlay" ? /* @__PURE__ */ f("button", {
					type: "button",
					className: "ld-primary",
					onClick: l,
					children: h("games.lotrduel.inspect")
				}) : b ? /* @__PURE__ */ p("div", {
					className: "ld-end-controls",
					children: [d && /* @__PURE__ */ f("button", {
						type: "button",
						className: "ld-primary",
						onClick: d,
						children: h("session.result.playAgain")
					}), m && /* @__PURE__ */ f("button", {
						type: "button",
						className: "ld-quiet",
						onClick: m,
						children: h("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ f("p", {
					className: "ld-end-wait",
					children: h("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region src/game/view-player.tsx
var st = {
	lindon: {
		x: 16.5,
		y: 27.5
	},
	arnor: {
		x: 44,
		y: 23
	},
	rhovanion: {
		x: 83.5,
		y: 27.8
	},
	enedwaith: {
		x: 42,
		y: 51
	},
	rohan: {
		x: 68.5,
		y: 51.5
	},
	gondor: {
		x: 57.5,
		y: 76
	},
	mordor: {
		x: 84.5,
		y: 72.5
	}
}, ct = [
	"yellow",
	"blue",
	"red",
	"green",
	"grey",
	"purple"
];
function lt(e) {
	let t = e.public;
	return /* @__PURE__ */ f(ut, {
		pub: t,
		myRid: e.myRid,
		members: e.members,
		send: e.send
	});
}
function ut({ pub: e, myRid: t, members: r, send: i }) {
	let s = o(), d = a((e) => e.locale), h = e.players.find((e) => e.rid === t) ?? e.players[0], g = e.players.find((e) => e.rid !== h.rid) ?? e.players[1], _ = e.phase === "turn" && e.turn === t, v = e.phase === "choice" && e.pending?.who === t, y = (e) => r.find((t) => t.rid === e), b = (e) => {
		let t = y(e);
		return t ? u(t, d) : e;
	}, [S, w] = n(null), [T, E] = n(null), [ee, te] = n(!0), O = `${e.chapter}|${e.turn}|${e.phase}|${e.pending?.kind ?? ""}|${e.pending?.options.join(",") ?? ""}`, [re, j] = n(O);
	re !== O && (j(O), w(null), E(null), te(!0));
	let M = S === null ? null : e.central[S], N = M && M.faceUp && !M.taken && M.cardId ? x(M.cardId) : null, P = "info", F, I = s("games.lotrduel.chapter", { n: e.chapter });
	e.phase === "done" ? (F = rt(s, e, b), P = "warn") : v && e.pending ? (P = "accent", F = oe(e.pending.kind, e.pending.remaining)) : e.phase === "choice" && e.pending ? F = s("games.lotrduel.choiceWait", { name: b(e.pending.who) }) : _ ? (P = "accent", F = s("games.lotrduel.turnYou")) : F = s("games.lotrduel.turnWait", { name: b(e.turn) });
	function oe(e, t) {
		return e === "redRegion" ? s("games.lotrduel.pickRedRegion") : e === "tokenPick" ? s("games.lotrduel.pickToken") : e === "racePick" ? s("games.lotrduel.pickRace") : e === "greyDiscard" ? s("games.lotrduel.pickGrey") : e === "discardPick" ? s("games.lotrduel.pickDiscard") : e === "move" ? s("games.lotrduel.movePrompt", { n: t }) : e === "removeUnit" ? s("games.lotrduel.removePrompt", { n: t }) : e === "unitAny" ? s("games.lotrduel.unitPrompt", { n: t }) : e === "wizardsUnits" ? s("games.lotrduel.wizardsPrompt") : e === "entChoice" ? s("games.lotrduel.entPrompt", { n: t }) : e === "fortressPick" ? s("games.lotrduel.pickFortress") : "";
	}
	function se(e) {
		if (e.startsWith("remove:")) return s("games.lotrduel.entRemove", { region: s(k[e.slice(7)]) });
		if (e.startsWith("2:")) return s("games.lotrduel.placeTwo", { region: s(k[e.slice(2)]) });
		if (e.startsWith("1:")) return s("games.lotrduel.placeOne", { region: s(k[e.slice(2)]) });
		if (e === "coin") return s("games.lotrduel.entCoin");
		if (e.includes(">")) {
			let [t, n] = e.replace("move:", "").split(">");
			return s("games.lotrduel.moveOpt", {
				from: s(k[t]),
				to: s(k[n])
			});
		}
		return m.includes(e) ? s(k[e]) : /^(elves|ents|hobbits|humans|dwarves|wizards)-/.test(e) ? s(ne[D(e).race]) : e.startsWith("c") ? s(A[x(e).color]) : e;
	}
	let L = /* @__PURE__ */ new Map();
	if (v && e.pending) {
		let t = e.pending.kind;
		for (let n of e.pending.options) t === "redRegion" || t === "unitAny" || t === "fortressPick" || t === "removeUnit" ? L.set(n, n) : t === "entChoice" && n.startsWith("remove:") && L.set(n.slice(7), n);
	}
	let R = e.pending?.options ?? [], ce = /* @__PURE__ */ f("div", {
		className: "ld-actionwrap",
		children: v && e.pending ? /* @__PURE__ */ p("div", {
			className: "ld-options",
			children: [R.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				className: `ld-opt${L.size > 0 && m.includes(e) ? " is-target" : ""}`,
				onClick: () => i({
					type: "choose",
					value: e
				}),
				children: [m.includes(e) && /* @__PURE__ */ f(q, {
					r: e,
					size: 14
				}), se(e)]
			}, e)), R.length === 0 && /* @__PURE__ */ f("span", {
				className: "ld-hint",
				children: "—"
			})]
		}) : _ && N ? /* @__PURE__ */ f("span", {
			className: "ld-actionhint",
			children: s("games.lotrduel.cardConfirmHint")
		}) : _ && T !== null ? /* @__PURE__ */ f("span", {
			className: "ld-actionhint",
			children: s("games.lotrduel.landmarkConfirmHint")
		}) : _ ? /* @__PURE__ */ f("span", {
			className: "ld-actionhint",
			children: s("games.lotrduel.selectCard")
		}) : /* @__PURE__ */ f("span", {
			className: "ld-actionhint",
			children: s("games.lotrduel.turnWait", { name: b(e.turn) })
		})
	}), le = e.phase === "done", z = new Set(C[e.chapter].map((e) => e.z)).size, ue = [...new Set(C[e.chapter].map((e) => e.z))].sort((e, t) => e - t), de = .55 / (1 + (z - 1) * .55), fe = M ? ue.indexOf(M.z) : 0, B = fe >= z / 2, pe = { "--ld-ci-top": `${fe * de * 100}%` };
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		banner: /* @__PURE__ */ f(l, {
			tone: P,
			text: F,
			chip: I,
			accent: ae.accent
		}),
		actions: ce,
		actionsHeight: "h-24",
		className: "ld-root",
		children: /* @__PURE__ */ p("div", {
			className: "ld-scroll",
			children: [
				/* @__PURE__ */ p("div", {
					className: "ld-top",
					children: [
						/* @__PURE__ */ f(ft, {
							p: h,
							member: y(h.rid),
							mine: !0,
							active: e.phase === "turn" && e.turn === h.rid,
							name: b(h.rid)
						}),
						/* @__PURE__ */ f("div", {
							className: "ld-vs",
							"aria-hidden": !0,
							children: /* @__PURE__ */ f(Je, { size: 26 })
						}),
						/* @__PURE__ */ f(ft, {
							p: g,
							member: y(g.rid),
							active: e.phase === "turn" && e.turn === g.rid,
							name: b(g.rid)
						})
					]
				}),
				/* @__PURE__ */ f(pt, { pub: e }),
				/* @__PURE__ */ p("div", {
					className: "ld-main",
					children: [
						/* @__PURE__ */ p("section", {
							className: "ld-boardwrap",
							children: [/* @__PURE__ */ p("div", {
								className: "ld-sechead",
								children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(qe, { size: 14 }), s("games.lotrduel.board")] }), /* @__PURE__ */ p("span", {
									className: "ld-boardlegend",
									"aria-hidden": !0,
									children: [/* @__PURE__ */ f("i", {
										className: "is-fel",
										children: /* @__PURE__ */ f(Q, { size: 13 })
									}), /* @__PURE__ */ f("i", {
										className: "is-sau",
										children: /* @__PURE__ */ f($, { size: 13 })
									})]
								})]
							}), /* @__PURE__ */ f(ht, {
								pub: e,
								regionTargets: v ? L : null,
								onPick: (e) => i({
									type: "choose",
									value: e
								})
							})]
						}),
						/* @__PURE__ */ p("section", {
							className: "ld-rack-panel",
							children: [/* @__PURE__ */ f("div", {
								className: "ld-sechead",
								children: /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { size: 14 }), s("games.lotrduel.central")] })
							}), /* @__PURE__ */ f("div", {
								className: "ld-layout",
								"data-rows": z,
								children: /* @__PURE__ */ p("div", {
									className: "ld-rack",
									children: [e.central.map((e) => {
										let t = ue.indexOf(e.z);
										return /* @__PURE__ */ f("div", {
											className: "ld-slot",
											style: {
												left: `${(e.x + 20) / 48 * 100}%`,
												top: `${t * de * 100}%`,
												zIndex: 10 + t
											},
											children: e.taken ? /* @__PURE__ */ f("span", {
												className: "ld-slot-empty",
												"aria-hidden": !0
											}) : /* @__PURE__ */ f(Qe, {
												id: e.cardId ?? "c1-coin2",
												faceUp: e.faceUp,
												dim: !e.accessible,
												live: _ && e.accessible,
												cost: e.cost,
												selected: S === e.slot,
												onClick: _ && e.accessible ? () => {
													w(S === e.slot ? null : e.slot), E(null);
												} : void 0
											})
										}, e.slot);
									}), N && M && _ && /* @__PURE__ */ f(dt, {
										def: N,
										cost: M.cost ?? null,
										chapter: e.chapter,
										coins: h.coins,
										vertical: B ? "above" : "below",
										style: pe,
										onPlay: () => {
											i({
												type: "takeCard",
												slot: M.slot,
												mode: "play"
											}), w(null);
										},
										onDiscard: () => {
											i({
												type: "takeCard",
												slot: M.slot,
												mode: "discard"
											}), w(null);
										},
										onCancel: () => w(null)
									})]
								})
							})]
						}),
						/* @__PURE__ */ p("aside", {
							className: "ld-side",
							children: [
								/* @__PURE__ */ p("section", {
									className: "ld-landmarks",
									children: [/* @__PURE__ */ p("div", {
										className: "ld-sechead",
										children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(ze, { size: 14 }), s("games.lotrduel.landmarksTitle")] }), /* @__PURE__ */ f("span", {
											className: "ld-dim",
											children: s("games.lotrduel.landmarkDeck", { n: e.landmarkDeck })
										})]
									}), /* @__PURE__ */ p("div", {
										className: "ld-lmrow",
										children: [e.landmarks.map((e, t) => /* @__PURE__ */ p("div", {
											className: "ld-lmslot",
											children: [/* @__PURE__ */ f(tt, {
												id: e.id,
												selected: T === t,
												onClick: _ ? () => {
													E(T === t ? null : t), w(null);
												} : void 0
											}), _ && T === t && /* @__PURE__ */ p("div", {
												className: "ld-lmconfirm",
												role: "group",
												"aria-label": s(ie[e.id]),
												children: [/* @__PURE__ */ f("span", {
													className: "ld-lmconfirm-name",
													children: s(ie[e.id])
												}), /* @__PURE__ */ p("div", {
													className: "ld-lmconfirm-btns",
													children: [/* @__PURE__ */ f("button", {
														type: "button",
														className: "ld-quiet",
														onClick: () => E(null),
														children: s("games.lotrduel.cancel")
													}), /* @__PURE__ */ f("button", {
														type: "button",
														className: "ld-primary",
														onClick: () => {
															i({
																type: "takeLandmark",
																index: t
															}), E(null);
														},
														children: s("games.lotrduel.take")
													})]
												})]
											})]
										}, e.id)), e.landmarks.length === 0 && /* @__PURE__ */ f("span", {
											className: "ld-hint",
											children: "—"
										})]
									})]
								}),
								/* @__PURE__ */ p("div", {
									className: "ld-tableaus",
									children: [/* @__PURE__ */ f(gt, {
										title: s("games.lotrduel.myTableau"),
										p: h,
										name: b(h.rid),
										mine: !0
									}), /* @__PURE__ */ f(gt, {
										title: s("games.lotrduel.oppTableau"),
										p: g,
										name: b(g.rid)
									})]
								}),
								/* @__PURE__ */ p("section", {
									className: "ld-discard-panel",
									children: [/* @__PURE__ */ p("div", {
										className: "ld-sechead",
										children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { size: 14 }), s("games.lotrduel.discardPile")] }), /* @__PURE__ */ f("span", {
											className: "ld-dim",
											children: e.discard.length
										})]
									}), /* @__PURE__ */ p("div", {
										className: "ld-discards",
										children: [e.discard.slice(-10).map((e, t) => /* @__PURE__ */ f($e, { id: e }, `${e}-${t}`)), e.discard.length === 0 && /* @__PURE__ */ f("span", {
											className: "ld-hint",
											children: s("games.lotrduel.emptyDiscard")
										})]
									})]
								})
							]
						})
					]
				}),
				le && ee && /* @__PURE__ */ f(ot, {
					pub: e,
					members: r,
					myRid: t,
					mode: "overlay",
					onInspect: () => te(!1)
				})
			]
		})
	});
}
function dt({ def: e, cost: t, chapter: n, coins: r, vertical: i, style: a, onPlay: s, onDiscard: c, onCancel: l }) {
	let u = o(), m = Ze(e).split("\n"), h = t?.chainFree ?? !1, g = h ? 0 : t?.coins ?? e.coins, _ = h ? 0 : t?.missing ?? 0, v = g <= r, y = e.skills.reduce((e, t) => {
		let n = e.find((e) => e.s === t);
		return n ? n.n += 1 : e.push({
			s: t,
			n: 1
		}), e;
	}, []);
	return /* @__PURE__ */ p("div", {
		className: "ld-cardinfo",
		role: "group",
		"aria-label": u("games.lotrduel.cardInfo"),
		"data-vertical": i,
		style: a,
		children: [
			/* @__PURE__ */ p("div", {
				className: "ld-ci-head",
				children: [/* @__PURE__ */ f("span", {
					className: "ld-ci-swatch",
					style: { background: Ye[e.color] },
					"aria-hidden": !0
				}), /* @__PURE__ */ f("b", { children: u(A[e.color]) })]
			}),
			/* @__PURE__ */ f("div", {
				className: "ld-ci-effect",
				children: m.map((e, t) => /* @__PURE__ */ f("span", { children: e }, t))
			}),
			y.length > 0 && /* @__PURE__ */ p("div", {
				className: "ld-ci-row",
				children: [/* @__PURE__ */ f("span", {
					className: "ld-ci-label",
					children: u("games.lotrduel.ciSkills")
				}), /* @__PURE__ */ f("span", {
					className: "ld-ci-skills",
					children: y.map(({ s: e, n: t }) => /* @__PURE__ */ p("span", {
						className: "ld-ci-skill",
						children: [
							/* @__PURE__ */ f(G, {
								s: e,
								size: 12
							}),
							u(re[e]),
							t > 1 ? /* @__PURE__ */ p("b", { children: ["×", t] }) : null
						]
					}, e))
				})]
			}),
			_ > 0 && /* @__PURE__ */ f("div", {
				className: "ld-ci-miss",
				children: u("games.lotrduel.ciMissing", { n: _ })
			}),
			/* @__PURE__ */ p("div", {
				className: "ld-ci-row",
				children: [/* @__PURE__ */ f("span", {
					className: "ld-ci-label",
					children: u("games.lotrduel.ciCost")
				}), /* @__PURE__ */ f("span", {
					className: "ld-ci-cost",
					children: h ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(K, { size: 12 }), u("games.lotrduel.chainFree")] }) : g > 0 ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(J, { size: 12 }), /* @__PURE__ */ f("b", { children: g })] }) : u("games.lotrduel.noCost")
				})]
			}),
			e.require && /* @__PURE__ */ p("div", {
				className: "ld-ci-chain",
				children: [
					/* @__PURE__ */ f("span", {
						className: "ld-ci-label",
						children: u("games.lotrduel.ciChainRequire")
					}),
					/* @__PURE__ */ p("span", {
						className: "ld-ci-chainname",
						children: [/* @__PURE__ */ f(K, {
							c: e.require,
							size: 12
						}), u(j[e.require])]
					}),
					/* @__PURE__ */ f("small", { children: u("games.lotrduel.ciRequireHow", { chain: u(j[e.require]) }) })
				]
			}),
			e.grant && /* @__PURE__ */ p("div", {
				className: "ld-ci-chain",
				children: [
					/* @__PURE__ */ f("span", {
						className: "ld-ci-label",
						children: u("games.lotrduel.ciChainGrant")
					}),
					/* @__PURE__ */ p("span", {
						className: "ld-ci-chainname",
						children: [/* @__PURE__ */ f(K, {
							c: e.grant,
							size: 12
						}), u(j[e.grant])]
					}),
					/* @__PURE__ */ f("small", { children: u("games.lotrduel.ciGrantHow", { chain: u(j[e.grant]) }) })
				]
			}),
			e.effect.kind === "skills" && /* @__PURE__ */ f("p", {
				className: "ld-ci-note",
				children: u("games.lotrduel.ciGreyNote")
			}),
			!v && /* @__PURE__ */ f("div", {
				className: "ld-ci-miss",
				children: u("games.lotrduel.cantAfford")
			}),
			/* @__PURE__ */ p("div", {
				className: "ld-ci-actions",
				children: [
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "ld-quiet",
						onClick: l,
						children: u("games.lotrduel.cancel")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "ld-quiet",
						onClick: c,
						children: [
							u("games.lotrduel.discard"),
							" ",
							/* @__PURE__ */ f(J, { size: 12 }),
							"+",
							n
						]
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "ld-primary",
						disabled: !v,
						onClick: s,
						children: u("games.lotrduel.play")
					})
				]
			})
		]
	});
}
function ft({ p: e, member: t, mine: n, active: r, name: a }) {
	let c = o(), l = e.faction === "fellowship", u = s[(t?.colorIndex ?? 0) % s.length];
	return /* @__PURE__ */ p("div", {
		className: `ld-plate ${l ? "is-fel" : "is-sau"}${n ? " is-mine" : ""}${r ? " is-active" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "ld-crest",
				"aria-hidden": !0,
				children: f(l ? Q : $, { size: 30 })
			}),
			/* @__PURE__ */ p("div", {
				className: "ld-plate-id",
				children: [/* @__PURE__ */ p("div", {
					className: "ld-plate-name",
					children: [
						/* @__PURE__ */ f("span", {
							className: "ld-avatar",
							style: { background: u.hex },
							children: t && /* @__PURE__ */ f("img", {
								src: i[t.avatar % i.length],
								alt: "",
								draggable: !1
							})
						}),
						/* @__PURE__ */ f("b", { children: a }),
						n && /* @__PURE__ */ f("small", { children: c("lobby.you") })
					]
				}), /* @__PURE__ */ p("div", {
					className: "ld-plate-faction",
					children: [f(l ? Q : $, { size: 13 }), c(l ? "games.lotrduel.faction.fellowship" : "games.lotrduel.faction.sauron")]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "ld-plate-stats",
				children: [
					/* @__PURE__ */ p("span", {
						className: "ld-stat-coin",
						title: c("games.lotrduel.coins"),
						children: [
							/* @__PURE__ */ f(J, { size: 15 }),
							/* @__PURE__ */ f("b", { children: e.coins }),
							/* @__PURE__ */ f("small", { children: c("games.lotrduel.coins") })
						]
					}),
					/* @__PURE__ */ p("span", {
						title: c("games.lotrduel.tokens"),
						children: [/* @__PURE__ */ f(Je, { size: 13 }), e.tokens.length]
					}),
					/* @__PURE__ */ p("span", {
						title: c("games.lotrduel.racesCount", { n: e.races.length }),
						children: [
							/* @__PURE__ */ f(Ke, { size: 13 }),
							e.races.length,
							"/6"
						]
					}),
					/* @__PURE__ */ p("span", {
						title: c("games.lotrduel.regionsCount", { n: e.regions }),
						children: [
							/* @__PURE__ */ f(qe, { size: 13 }),
							e.regions,
							"/7"
						]
					}),
					/* @__PURE__ */ p("span", {
						title: c("games.lotrduel.cardsCount", { n: e.cards.length }),
						children: [/* @__PURE__ */ f(Z, { size: 13 }), e.cards.length]
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "ld-plate-tokens",
				children: e.tokens.map((e) => /* @__PURE__ */ f(nt, { id: e }, e))
			}),
			r && /* @__PURE__ */ f("span", {
				className: "ld-turnflag",
				children: c("games.lotrduel.turnActive")
			})
		]
	});
}
function pt({ pub: e }) {
	let t = o();
	return /* @__PURE__ */ p("section", {
		className: "ld-quest",
		"aria-label": t("games.lotrduel.quest"),
		children: [/* @__PURE__ */ p("div", {
			className: "ld-qhead",
			children: [
				/* @__PURE__ */ p("span", {
					className: "ld-qtitle",
					children: [/* @__PURE__ */ f(X, { size: 14 }), t("games.lotrduel.quest")]
				}),
				/* @__PURE__ */ p("span", {
					className: "ld-qlegend",
					children: [
						/* @__PURE__ */ f("i", {
							className: "ld-mk is-frodo",
							children: /* @__PURE__ */ f(X, { size: 10 })
						}),
						t("games.lotrduel.frodo"),
						/* @__PURE__ */ f("i", {
							className: "ld-mk is-naz",
							children: /* @__PURE__ */ f(Ve, { size: 10 })
						}),
						t("games.lotrduel.nazgul")
					]
				}),
				/* @__PURE__ */ p("span", {
					className: "ld-qends",
					children: [
						t("games.lotrduel.trackStart"),
						" → ",
						t("games.lotrduel.trackEnd")
					]
				})
			]
		}), /* @__PURE__ */ f("div", {
			className: "ld-track",
			children: Array.from({ length: 29 }, (n, r) => {
				let i = r + 1, a = O[i], o = i === 15 ? "is-ring" : i === 29 ? "is-doom" : a ? "is-bonus" : "", s = e.frodo === i, c = e.nazgul === i, l = [s ? t("games.lotrduel.frodo") : "", c ? t("games.lotrduel.nazgul") : ""].filter(Boolean).join(" · ");
				return /* @__PURE__ */ p("div", {
					className: `ld-trackcell ${o}`,
					title: a ? t(te[a]) : void 0,
					"aria-label": `${i}${a ? ` · ${t(te[a])}` : ""}${l ? ` · ${l}` : ""}`,
					children: [/* @__PURE__ */ f("span", {
						className: "ld-cellicon",
						children: mt(a, i)
					}), (s || c) && /* @__PURE__ */ p("span", {
						className: "ld-cellmarkers",
						children: [s && /* @__PURE__ */ f("i", {
							className: "ld-mk is-frodo",
							children: /* @__PURE__ */ f(X, { size: 9 })
						}), c && /* @__PURE__ */ f("i", {
							className: "ld-mk is-naz",
							children: /* @__PURE__ */ f(Ve, { size: 9 })
						})]
					})]
				}, i);
			})
		})]
	});
}
function mt(e, t) {
	return e === "coin" ? /* @__PURE__ */ f(J, { size: 12 }) : e === "unit" ? /* @__PURE__ */ f(Y, { size: 12 }) : e === "extraTurn" ? /* @__PURE__ */ f(Be, { size: 12 }) : e === "fortress" ? /* @__PURE__ */ f(ze, { size: 12 }) : t === 15 ? /* @__PURE__ */ f(X, { size: 13 }) : t === 29 ? /* @__PURE__ */ f(He, { size: 13 }) : null;
}
function ht({ pub: e, regionTargets: t, onPick: n }) {
	let i = o(), a = e.players.find((e) => e.faction === "fellowship") ?? e.players[0], s = e.players.find((e) => e.faction === "sauron") ?? e.players[1];
	return /* @__PURE__ */ f("div", {
		className: "ld-map",
		style: { backgroundImage: `url(${r("games/lotrduel/board.webp")})` },
		role: "group",
		"aria-label": i("games.lotrduel.board"),
		children: m.map((e) => {
			let r = t?.get(e), o = r !== void 0;
			return /* @__PURE__ */ p("div", {
				role: o ? "button" : void 0,
				tabIndex: o ? 0 : void 0,
				className: `ld-region${o ? " is-legal" : ""}`,
				style: {
					left: `${st[e].x}%`,
					top: `${st[e].y}%`
				},
				"aria-label": i("games.lotrduel.regionAria", {
					region: i(k[e]),
					fu: a.units[e] ?? 0,
					ff: a.fortresses[e] ?? 0,
					su: s.units[e] ?? 0,
					sf: s.fortresses[e] ?? 0
				}),
				onClick: o ? () => n(r) : void 0,
				onKeyDown: o ? (e) => {
					(e.key === "Enter" || e.key === " ") && (e.preventDefault(), n(r));
				} : void 0,
				children: [
					o && /* @__PURE__ */ f("svg", {
						className: "ld-ants",
						viewBox: "0 0 100 100",
						preserveAspectRatio: "none",
						"aria-hidden": !0,
						children: /* @__PURE__ */ f("rect", {
							x: "2",
							y: "2",
							width: "96",
							height: "96",
							rx: "12"
						})
					}),
					/* @__PURE__ */ p("div", {
						className: "ld-rname",
						children: [/* @__PURE__ */ f(q, {
							r: e,
							size: 12
						}), i(k[e])]
					}),
					/* @__PURE__ */ p("div", {
						className: "ld-rrows",
						children: [/* @__PURE__ */ p("span", {
							className: "ld-rrow is-fel",
							title: i("games.lotrduel.faction.fellowship"),
							children: [
								/* @__PURE__ */ f(Q, { size: 11 }),
								/* @__PURE__ */ p("span", {
									className: "ld-rq",
									children: [/* @__PURE__ */ f(Y, { size: 11 }), /* @__PURE__ */ f("b", { children: a.units[e] ?? 0 })]
								}),
								(a.fortresses[e] ?? 0) > 0 && /* @__PURE__ */ p("span", {
									className: "ld-rq is-fort",
									children: [/* @__PURE__ */ f(ze, { size: 11 }), /* @__PURE__ */ f("b", { children: a.fortresses[e] })]
								})
							]
						}), /* @__PURE__ */ p("span", {
							className: "ld-rrow is-sau",
							title: i("games.lotrduel.faction.sauron"),
							children: [
								/* @__PURE__ */ f($, { size: 11 }),
								/* @__PURE__ */ p("span", {
									className: "ld-rq",
									children: [/* @__PURE__ */ f(Y, { size: 11 }), /* @__PURE__ */ f("b", { children: s.units[e] ?? 0 })]
								}),
								(s.fortresses[e] ?? 0) > 0 && /* @__PURE__ */ p("span", {
									className: "ld-rq is-fort",
									children: [/* @__PURE__ */ f(ze, { size: 11 }), /* @__PURE__ */ f("b", { children: s.fortresses[e] })]
								})
							]
						})]
					})
				]
			}, e);
		})
	});
}
function gt({ title: e, p: t, name: n, mine: r }) {
	let i = o(), a = t.faction === "fellowship", s = ct.map((e) => ({
		color: e,
		cards: t.cards.map((e, t) => ({
			id: e,
			i: t
		})).filter((t) => x(t.id).color === e)
	})).filter((e) => e.cards.length > 0);
	return /* @__PURE__ */ p("section", {
		className: `ld-tableau${r ? " is-mine" : ""}${t.cards.length === 0 ? " is-empty" : ""}`,
		children: [/* @__PURE__ */ p("div", {
			className: "ld-tableau-head",
			children: [
				/* @__PURE__ */ f("span", {
					className: "ld-tableau-title",
					children: e
				}),
				/* @__PURE__ */ p("span", {
					className: "ld-tableau-owner",
					children: [f(a ? Q : $, { size: 12 }), n]
				}),
				/* @__PURE__ */ p("span", {
					className: "ld-dim",
					children: [/* @__PURE__ */ f(Z, { size: 12 }), t.cards.length]
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "ld-chips",
			children: [t.cards.length === 0 && /* @__PURE__ */ f("span", {
				className: "ld-hint",
				children: i("games.lotrduel.emptyTableau")
			}), s.map((e) => /* @__PURE__ */ p("span", {
				className: "ld-chipgroup",
				role: "group",
				"aria-label": i(A[e.color]),
				children: [/* @__PURE__ */ p("span", {
					className: "ld-chipgroup-label",
					children: [/* @__PURE__ */ f("i", {
						style: { background: Ye[e.color] },
						"aria-hidden": !0
					}), i(A[e.color])]
				}), /* @__PURE__ */ f("span", {
					className: "ld-chipgroup-items",
					children: e.cards.map(({ id: e, i: t }) => /* @__PURE__ */ f($e, { id: e }, `${e}-${t}`))
				})]
			}, e.color))]
		})]
	});
}
//#endregion
//#region src/game/bot.ts
var _t = {
	baradDur: 8.2,
	erebor: 7.4,
	minasTirith: 6.8,
	isengard: 6.2,
	helmsDeep: 5.8,
	bree: 5.4,
	greyHavens: 5.1
}, vt = {
	wizardsQuest2: 5.6,
	entsChoice: 5,
	entsTurn: 4.6,
	entsFortress: 4.2,
	elvesYellowTurn: 4,
	humansYellowQuest: 3.9,
	hobbitsBlueUnit: 3.6,
	elvesAnySkill: 3.4,
	humansRedExtra: 3.3,
	dwarvesNoExtra: 3.2,
	hobbitsChainCoins: 3,
	elvesRedAny: 3.3,
	humansDiscardDouble: 2.6,
	hobbitsEagle: 3.6,
	dwarvesTurn: 4.6,
	wizardsUnits: 4,
	wizardsDiscardFree: 3.4
};
function yt(e, t) {
	let n = e.public.players.findIndex((e) => e.rid === t);
	return n < 0 ? null : {
		idx: n,
		me: e.public.players[n],
		opp: e.public.players[1 - n],
		pub: e.public
	};
}
function bt(e, t, n) {
	let r = e[0], i = -Infinity;
	for (let a of e) {
		let e = t.units[a] ?? 0, o = n.units[a] ?? 0, s = ((t.units[a] ?? 0) + (t.fortresses[a] ?? 0) > 0 ? 0 : 1.4) + Math.min(e, o) * .9 - e * .1 + (n.fortresses[a] ?? 0) * .3;
		s > i && (i = s, r = a);
	}
	return r;
}
function xt(e, t, n) {
	let r = t.public;
	if (n === 0) return r.frodo + e >= 29 ? 100 : e * 2.6 + (r.frodo + e >= 26 ? 3 : 0);
	let i = r.frodo - r.nazgul;
	return e >= i ? 100 : e * 2.6 + (i - e <= 2 ? 3 : 0);
}
function St(e, t, n, r) {
	let i = x(e), a = i.effect, o = 0;
	if (a.kind === "coins") o = a.n * .5 + .4;
	else if (a.kind === "quest") o = xt(a.n, t, n);
	else if (a.kind === "units") {
		let e = bt(a.regions, r, t.public.players[1 - n]), i = (r.units[e] ?? 0) + (r.fortresses[e] ?? 0) > 0 ? 0 : 1.4;
		o = a.n * 1.1 + i * .5;
	} else if (a.kind === "race") {
		let e = r.races.includes(a.race), t = e ? r.races.length : r.races.length + 1;
		o = e ? 2 : 2.6, t >= 6 && (o = 100), r.tokens.some((e) => D(e).effect === "dwarvesGreenMoves") && (o += 1.6);
	} else a.kind === "skills" ? o = 1 + a.groups.length * .7 : a.kind === "purple" && (o = a.moves * 1 + a.removeUnits * 1.5 + a.coinLoss * .5);
	return i.require && r.cards.some((e) => x(e).grant === i.require) && (o += 1.2), o;
}
function Ct(e, t) {
	return (vt[D(e).effect] ?? 2.5) + (t.tokens.includes(e) ? -.8 : 0);
}
function wt(e, t, n, r, i, a) {
	if (a === "redRegion" || a === "unitAny") {
		let t = e;
		if (!m.includes(t)) return -Infinity;
		let n = i.units[t] ?? 0, a = r.units[t] ?? 0;
		return (a + (r.fortresses[t] ?? 0) > 0 ? 0 : 1.6) + Math.min(n, 2) * .8 - a * .05 - (i.fortresses[t] ?? 0) * .2;
	}
	if (a === "tokenPick") return Ct(e, r);
	if (a === "racePick") {
		let t = {};
		for (let e of r.cards) {
			let n = x(e).effect;
			n.kind === "race" && (t[n.race] = (t[n.race] ?? 0) + 1);
		}
		return (t[e] ?? 0) * 1.5 + (r.races.includes(e) ? .4 : 1);
	}
	if (a === "greyDiscard" || a === "discardPick") return St(e, t, n, a === "discardPick" ? r : i);
	if (a === "removeUnit") {
		let t = e;
		return (i.units[t] ?? 0) * .9 + (i.fortresses[t] ?? 0) * .5;
	}
	if (a === "fortressPick") {
		let t = e;
		return (i.fortresses[t] ?? 0) * 2 + (i.units[t] ?? 0) * .4;
	}
	if (a === "move" || e.startsWith("move:") || e.includes(">")) {
		let [t, n] = e.replace("move:", "").split(">");
		if (!t || !n) return 0;
		let a = i.units[n] ?? 0, o = Math.min(r.units[t] ?? 0, a) * .9, s = (r.units[n] ?? 0) + (r.fortresses[n] ?? 0) > 0 ? 0 : 1.2, c = (r.units[t] ?? 0) <= 1 ? -.6 : 0;
		return o + s + c;
	}
	if (e === "coin") return .6;
	if (e.startsWith("remove:")) {
		let t = e.slice(7);
		return (i.units[t] ?? 0) * .9 + (i.fortresses[t] ?? 0) * .4;
	}
	if (e.startsWith("2:")) {
		let t = e.slice(2);
		return 2.2 + (i.units[t] ?? 0) * .7 + ((r.units[t] ?? 0) + (r.fortresses[t] ?? 0) > 0 ? 0 : 1.2);
	}
	if (e.startsWith("1:")) {
		let t = e.slice(2);
		return 1.1 + ((r.units[t] ?? 0) + (r.fortresses[t] ?? 0) > 0 ? 0 : 1.2);
	}
	return 0;
}
var Tt = (e, t) => {
	let n = yt(e, t.rid);
	if (!n) return null;
	let { idx: r, me: i, opp: a, pub: o } = n;
	if (o.phase === "choice" && o.pending) {
		if (o.pending.who !== t.rid) return null;
		let n = o.pending.kind, s = o.pending.options[0], c = -Infinity;
		for (let t of o.pending.options) {
			let o = wt(t, e, r, i, a, n);
			o > c && (c = o, s = t);
		}
		return s === void 0 ? null : { action: {
			type: "choose",
			value: s
		} };
	}
	if (o.phase !== "turn" || o.turn !== t.rid) return null;
	let s = [], c = o.chapter;
	for (let t of o.central) {
		if (t.taken || !t.faceUp || !t.accessible || !t.cardId) continue;
		let n = x(t.cardId), a = St(n.id, e, r, i), l = t.cost ?? me({
			cards: i.cards,
			tokens: i.tokens
		}, n.id);
		if (l.coins <= i.coins) {
			let e = +!!l.chainFree;
			s.push({
				action: {
					type: "takeCard",
					slot: t.slot,
					mode: "play"
				},
				score: a + e - l.coins * .5
			});
		}
		let u = o.players[1 - r].races.length <= 4 ? .15 * a : 0;
		s.push({
			action: {
				type: "takeCard",
				slot: t.slot,
				mode: "discard"
			},
			score: c * .5 + u - .4
		});
	}
	for (let e = 0; e < o.landmarks.length; e += 1) {
		let t = o.landmarks[e].id;
		if (!E(t)) continue;
		let n = he({
			cards: i.cards,
			tokens: i.tokens,
			forts: i.fortresses
		}, t);
		n.coins > i.coins || s.push({
			action: {
				type: "takeLandmark",
				index: e
			},
			score: (_t[t] ?? 4.5) - n.coins * .5 + .2
		});
	}
	return s.length === 0 ? null : (s.sort((e, t) => t.score - e.score), { action: s[0].action });
};
//#endregion
//#region src/game/game-over.tsx
function Et({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ f(ot, {
		pub: t,
		members: n,
		myRid: r,
		mode: "full",
		ranking: e.ranking,
		onPlayAgain: i,
		onBackToLobby: a
	});
}
//#endregion
//#region src/index.tsx
var Dt = {
	definition: Me,
	View: lt,
	bot: Tt,
	OverView: Et,
	locales: {
		zh: {
			name: "魔戒:中洲对决",
			desc: "两人对决:护戒小队与索伦争夺中洲,推进魔戒之旅、结盟六族或在七地立足,抢先达成胜利条件",
			rules: "游戏目标：\n本游戏由护戒小队与索伦两方对决,共进行三个章节。任意一方达成以下任一条件时立即获胜:\n· 护戒小队:佛罗多与山姆抵达末日火山。\n· 索伦:戒灵追上佛罗多与山姆。\n· 任一方:集齐六个不同种族的符号。\n· 任一方:在全部七个地区都至少有一个单位或一座要塞。\n三个章节结束后若仍无人获胜,则在七个地区中立足更多的玩家获胜;若双方相同,则共享胜利。\n\n准备：\n· 随机决定或自行选择一方扮演护戒小队,另一方扮演索伦。索伦先手。\n· 护戒小队将两个单位放在阿尔诺,索伦将两个单位放在魔多。\n· 护戒小队获得三枚金币,索伦获得两枚金币,其余金币作为公共储备。\n· 将六个种族的同盟标记分别洗混,背面朝上叠放在版图上方对应的位置。\n· 将七块地标板块洗混,随机翻开三块;其余板块背面朝上作为牌堆。\n· 将章节牌按背面符文分成三副并分别洗混。第一章的牌阵按盒侧图示摆放,其中部分牌背面朝上;每章剩余的牌背面朝上放入弃牌堆。\n\n回合流程：\n轮到你时,你从以下两种行动中选择一种执行:\n· 拿取一张章节牌:从中央牌阵选择一张没有被其他牌压住的牌。你可以支付费用将其打到自己面前,也可以将其背面朝上弃掉,并按当前章节获得金币:第一章一枚、第二章两枚、第三章三枚。\n· 拿取一块地标板块:从翻开的板块中选择一块,支付费用后放到自己面前,立即在对应地区放置一座要塞并结算其他效果;此行动结束时不再翻开新的板块。\n行动结束后,将因移除卡牌而新暴露出来的牌翻到正面,然后轮到对方行动。\n\n费用：\n· 技能:多数卡牌和地标板块要求你拥有指定技能。你在自己面前每有一张灰色卡牌,就按其所示符号获得相应的技能;每缺一个所需符号,你可以改为向储备支付一枚金币。\n· 金币:部分卡牌在卡面标注金币费用,必须支付给储备。\n· 地标板块除了卡面费用外,还需额外支付等同于你版图上已有要塞数量的金币;你的第一块地标无需支付这笔额外费用。\n· 连锁:从第二章开始,部分卡牌带有连锁符号。若你面前的某张牌右上角印有相同符号,你可以不支付技能与金币费用,直接免费打出该牌。\n\n卡牌效果：\n· 黄色卡牌:立即从储备获得卡面所示数量的金币。\n· 蓝色卡牌:你的角色沿魔戒之旅轨道前进,每有一个魔戒符号前进一格。\n· 红色卡牌:在卡面所示两面旗帜对应的两个地区中选择一个,将卡面所示数量的单位全部放入该地区。\n· 绿色卡牌:代表一个种族。你拥有两个相同种族符号时,抽取该种族牌堆顶的两枚同盟标记,选择一枚保留;你拥有三个不同种族符号时(每局一次),各抽取这三个种族牌堆顶的一枚标记,选择一枚保留。\n· 灰色卡牌:提供技能符号。每个符号每回合可以使用一次;若一张灰色卡牌上有多个以斜线分隔的技能,你每回合只能使用其中一个。\n· 紫色卡牌(仅第三章):执行卡面所示数量的单位移动、移除敌方单位或令对手失去金币。\n\n冲突：\n当你在有敌方单位的地区放置或移动单位时,双方各移除一个单位,重复此过程直到至少一方没有单位为止。敌方要塞不会引发冲突,也不会阻止你进入该地区。\n\n魔戒之旅：\n· 佛罗多与山姆从印有至尊戒的格子出发,戒灵从轨道最左端出发。佛罗多与山姆每前进一格,戒灵也随之前进一格,因此两者之间的距离只会缩短,不会拉大。\n· 角色前进时,由前进的一方结算其到达或经过的奖励格:获得金币、在任意地区放置单位、本回合结束后再进行一个回合,或移除任意地区的一座敌方要塞。戒灵因佛罗多与山姆前进而随之移动时,不结算奖励格。\n· 佛罗多与山姆抵达末日火山时,护戒小队立即获胜;戒灵到达或超过佛罗多与山姆所在的格子时,索伦立即获胜。\n\n地标与同盟标记：\n· 地标板块立即在对应地区放置要塞,并结算其独特效果;具体效果见玩家提示卡。\n· 同盟标记的效果在获得时立即适用;其中恩特与巫师的标记为一次性立即效果,其余标记为持续能力。\n\n章节结束：\n当本章最后一张章节牌被拿走后,本章结束。按下一章的图示布置新的牌阵,并将地标板块翻开至三块(若牌堆允许),然后由未结束本章的一方继续行动,除非有玩家获得了额外行动。",
			chapter: "第 {{n}} 章",
			turnYou: "轮到你:拿一张章节牌或一块地标",
			turnWait: "等待 {{name}} 行动…",
			choiceYou: "请完成当前选择",
			choiceWait: "等待 {{name}} 选择…",
			faction: {
				fellowship: "护戒小队",
				sauron: "索伦"
			},
			region: {
				lindon: "林顿",
				arnor: "阿尔诺",
				enedwaith: "埃奈德",
				rhovanion: "罗瓦尼安",
				rohan: "洛汗",
				gondor: "刚铎",
				mordor: "魔多"
			},
			race: {
				elves: "精灵",
				ents: "恩特",
				hobbits: "霍比特人",
				humans: "人类",
				dwarves: "矮人",
				wizards: "巫师"
			},
			raceEagle: "鹰",
			skill: {
				ruse: "谋略",
				strength: "力量",
				courage: "勇气",
				knowledge: "知识",
				leadership: "统御"
			},
			color: {
				yellow: "黄色",
				blue: "蓝色",
				red: "红色",
				green: "绿色",
				grey: "灰色",
				purple: "紫色"
			},
			chain: {
				horse: "骏马",
				teapot: "茶壶",
				fish: "鱼",
				harp: "竖琴",
				anvil: "铁砧",
				pot: "炊锅",
				horseshoe: "马蹄铁",
				crossedSwords: "交叉剑",
				sword: "剑",
				helmet: "头盔",
				chest: "宝箱",
				scroll: "卷轴",
				campfire: "营火",
				axe: "战斧",
				flag: "旗帜"
			},
			landmark: {
				baradDur: "巴拉多",
				bree: "布理",
				erebor: "孤山",
				greyHavens: "灰港",
				helmsDeep: "圣盔谷",
				isengard: "艾辛格",
				minasTirith: "米那斯提力斯"
			},
			coins: "金币",
			quest: "魔戒之旅",
			myTableau: "我的牌区",
			oppTableau: "对方牌区",
			central: "中央牌阵",
			landmarksTitle: "地标",
			landmarkDeck: "牌堆 {{n}}",
			board: "中洲版图",
			units: "单位",
			fortress: "要塞",
			tokens: "同盟标记",
			racesCount: "种族 {{n}}/6",
			regionsCount: "地区 {{n}}/7",
			frodo: "佛罗多与山姆",
			cardsCount: "卡牌 {{n}}",
			track: {
				coin: "奖励:获得 1 枚金币",
				unit: "奖励:在任意地区放置 1 个单位",
				extraTurn: "奖励:本回合结束后再进行一个回合",
				fortress: "奖励:移除任意地区的 1 座敌方要塞"
			},
			nazgul: "戒灵",
			play: "打出",
			discard: "弃掉",
			take: "拿取",
			cancel: "返回",
			confirm: "确定",
			noCost: "无需费用",
			costCoins: "支付 {{n}} 枚金币",
			missing: "缺 {{n}} 个技能",
			chainFree: "连锁免费",
			cantAfford: "金币不足",
			pickRedRegion: "选择放置单位的地区",
			pickToken: "选择保留的同盟标记",
			pickRace: "选择要抽取的种族",
			pickGrey: "选择对手要弃掉的灰色卡牌",
			pickDiscard: "从弃牌堆选择一张免费打出",
			movePrompt: "移动 1 个单位(剩余 {{n}} 次):选择起点与终点",
			removePrompt: "移除 1 个敌方单位(剩余 {{n}} 次)",
			unitPrompt: "在任意地区放置 1 个单位(剩余 {{n}} 次)",
			entPrompt: "恩特:选择一项效果(剩余 {{n}} 次)",
			wizardsPrompt: "巫师的智慧:在一个地区放 2 个单位,或在两个地区各放 1 个",
			placeTwo: "{{region}} 放 2 个",
			placeOne: "{{region}} 放 1 个",
			entCoin: "对手失去 1 枚金币",
			entRemove: "移除 {{region}} 的 1 个敌方单位",
			entMove: "{{from}} → {{to}} 移动 1 个单位",
			moveOpt: "{{from}} → {{to}}",
			useSkill: "使用技能",
			emptyTableau: "尚无卡牌",
			emptyDiscard: "尚无弃牌",
			discardPile: "弃牌堆",
			pickFortress: "选择要移除的敌方要塞",
			winFellowship: "护戒小队胜利:魔戒已被摧毁!",
			winSauron: "索伦胜利:戒灵夺回了至尊戒!",
			winRaces: "{{name}}胜利:集齐六族支持!",
			winConquest: "{{name}}胜利:征服了整个中洲!",
			winRegions: "{{name}}以更多地区获胜",
			winTie: "双方立足地区相同,共享胜利",
			selectCard: "点选一张可拿的卡牌",
			selectLandmark: "点选一块地标板块",
			cardConfirmHint: "在所选卡牌旁选择打出或弃掉",
			landmarkConfirmHint: "在所选地标旁确认拿取",
			cardInfo: "卡牌说明",
			ciEffect: "效果",
			ciSkills: "所需技能",
			ciMissing: "缺 {{n}} 个,可用金币代替",
			ciCost: "费用",
			ciChainRequire: "连锁要求",
			ciChainGrant: "连锁符号",
			ciRequireHow: "牌区已有「{{chain}}」符号时,本牌可免费打出",
			ciGrantHow: "拥有此符号后,可免费打出要求「{{chain}}」的牌",
			ciGreyNote: "每个技能符号每回合各可使用一次;同一张牌上以斜线分隔的技能每回合只能使用一个。",
			inspect: "查看",
			close: "关闭",
			cardFaceDown: "卡牌背面",
			requirement: "需要连锁「{{chain}}」",
			turnActive: "行动中",
			endingKicker: "第 {{n}} 章终局",
			winnerMark: "胜利",
			trackStart: "佛罗多起点",
			trackEnd: "末日火山",
			regionAria: "{{region}}:护戒小队单位 {{fu}}、要塞 {{ff}};索伦单位 {{su}}、要塞 {{sf}}",
			errNotPlayer: "你不在本局中",
			errDone: "对局已经结束",
			errPending: "请先完成当前选择",
			errNotYourTurn: "还没有轮到你行动",
			errBadSlot: "这张牌当前不能拿取",
			errCantAfford: "金币不足,无法支付这张牌的费用",
			errNoPending: "当前没有待处理的选择",
			errNotYourChoice: "这项选择不属于你",
			errBadChoice: "这个选择无效",
			effectCoins: "获得 {{n}} 枚金币",
			effectQuest: "前进 {{n}} 格",
			effectUnits: "放置 {{n}} 个单位",
			effectRace: "获得{{race}}符号",
			effectSkills: "提供技能:{{list}}",
			effectPurple: "{{parts}}",
			purpleMove: "移动 {{n}} 次",
			purpleRemove: "移除 {{n}} 个敌方单位",
			purpleCoin: "对手失去 {{n}} 枚金币",
			needRegion: "{{a}} 或 {{b}}",
			logTake: "{{name}} 打出 {{card}}",
			logDiscard: "{{name}} 弃掉一张牌",
			logLandmark: "{{name}} 拿取地标「{{landmark}}」",
			logToken: "{{name}} 获得同盟标记「{{race}}」"
		},
		en: {
			name: "The Lord of the Rings: Duel for Middle-earth",
			desc: "Two-player duel: the Fellowship and Sauron race across Middle-earth, advancing the Quest of the Ring, rallying six races, or claiming all seven regions",
			rules: "Goal of the game:\nThe Fellowship of the Ring and Sauron play against each other over three chapters. A player wins immediately by fulfilling one of the following victory conditions:\n· The Fellowship: Frodo and Sam reach Mount Doom.\n· Sauron: the Nazgûl catch Frodo and Sam.\n· Either player: gather six different Race symbols.\n· Either player: be present in all seven regions with a Fortress and/or at least one Unit.\nIf neither player has won by the end of chapter 3, the player present in more regions wins; if both are present in the same number of regions, they share the victory.\n\nSetup:\n· Randomly determine, or choose, who plays the Fellowship and who plays Sauron. The Sauron player begins the game.\n· Place 2 Fellowship Units on Arnor and 2 Sauron Units on Mordor.\n· The Fellowship takes 3 Coins and Sauron takes 2 Coins; the remaining Coins form the reserve.\n· Shuffle each Race stack of Alliance tokens separately and place the stacks face down above the central board.\n· Shuffle the 7 Landmark tiles, reveal 3 of them, and keep the rest face down as a stack.\n· Sort the Chapter cards into three decks by the runes on their backs and shuffle each deck. Lay out the Chapter 1 cards as shown on the side of the box, with some cards face down; place the 3 remaining cards of each chapter face down in the discard.\n\nTurn:\nOn your turn, choose one of two actions:\n· Take a Chapter card: choose an available card in the central play area, meaning one that is not partially covered by another card. Either pay its cost and play it in front of you, or discard it face down and take Coins equal to the current chapter: 1 Coin in chapter 1, 2 Coins in chapter 2 and 3 Coins in chapter 3.\n· Take a Landmark tile: choose one of the face-up tiles, pay its cost, place it in front of you, immediately place a Fortress in the corresponding region and resolve its other effects. You do not reveal a new tile at the end of this turn.\nAt the end of your turn, reveal any cards that are now available, then your opponent takes a turn.\n\nCosts:\n· Skills: most cards and Landmark tiles require Skills. Each Grey card in front of you provides the Skill symbols shown on it. For each required symbol you do not have, you may pay 1 Coin to the reserve instead.\n· Coins: some cards show a Coin cost that must be paid to the reserve.\n· A Landmark tile also costs additional Coins equal to the number of your Fortresses already on the board. Your first Landmark therefore has no additional cost.\n· Chaining: starting in chapter 2, some cards bear a chaining symbol. If one of the cards in front of you shows the same symbol in its top-right corner, you may play the card for free without paying Skills or Coins.\n\nCard effects:\n· Yellow cards: take the number of Coins shown from the reserve.\n· Blue cards: advance your character on the Quest of the Ring track one space per Ring symbol.\n· Red cards: choose one of the two regions shown by the banners and place all the Units shown in that region.\n· Green cards: represent a Race. When you have two matching Race symbols, draw the top two Alliance tokens of that Race and keep one. Once per game, when you have three different Race symbols, draw the top token of each of those three Races and keep one.\n· Grey cards: provide Skill symbols. Each symbol may be used once per turn; when several Skills are separated by a slash, you may use only one of them per turn.\n· Purple cards (chapter 3 only): perform the number of Unit movements, enemy Unit removals or Coin losses shown.\n\nConflicts:\nWhen you place or move Units into a region containing enemy Units, each player removes one of their Units, repeating until at least one player has no Units there. An enemy Fortress neither triggers a conflict nor prevents you from entering the region.\n\nQuest of the Ring:\n· Frodo and Sam start on the space marked with the One Ring, while the Nazgûl start at the far left of the track. Each time Frodo and Sam advance one space, the Nazgûl advance one space as well, so the distance between them only decreases and never increases.\n· When a character advances, the player whose character advances resolves the Bonus spaces it reaches or passes: take a Coin, place a Unit in any region, take another turn after this one, or remove an enemy Fortress from any region. The Nazgûl do not resolve Bonus spaces when they move because Frodo and Sam advanced.\n· If Frodo and Sam reach Mount Doom, the Fellowship wins immediately; if the Nazgûl reach or pass the space of Frodo and Sam, Sauron wins immediately.\n\nLandmarks & tokens:\n· A Landmark tile immediately places a Fortress in its region and resolves its unique effect; see the Player Aid for the details.\n· Alliance token effects apply as soon as you gain them. Ent and Wizard tokens are one-time immediate effects; the other tokens provide persistent abilities.\n\nEnd of a chapter:\nA chapter ends once the final card of that chapter has been taken. Lay out the next chapter as shown in its diagram and reveal Landmark tiles until there are three face up, if possible. The player who did not end the chapter then takes the next turn, unless a player has gained another turn.",
			chapter: "Chapter {{n}}",
			turnYou: "Your turn: take a Chapter card or a Landmark tile",
			turnWait: "Waiting for {{name}}…",
			choiceYou: "Complete the current choice",
			choiceWait: "Waiting for {{name}} to choose…",
			faction: {
				fellowship: "Fellowship",
				sauron: "Sauron"
			},
			region: {
				lindon: "Lindon",
				arnor: "Arnor",
				enedwaith: "Enedwaith",
				rhovanion: "Rhovanion",
				rohan: "Rohan",
				gondor: "Gondor",
				mordor: "Mordor"
			},
			race: {
				elves: "Elves",
				ents: "Ents",
				hobbits: "Hobbits",
				humans: "Humans",
				dwarves: "Dwarves",
				wizards: "Wizards"
			},
			raceEagle: "Eagle",
			skill: {
				ruse: "Ruse",
				strength: "Strength",
				courage: "Courage",
				knowledge: "Knowledge",
				leadership: "Leadership"
			},
			color: {
				yellow: "Yellow",
				blue: "Blue",
				red: "Red",
				green: "Green",
				grey: "Grey",
				purple: "Purple"
			},
			chain: {
				horse: "Horse",
				teapot: "Tea pot",
				fish: "Fish",
				harp: "Harp",
				anvil: "Anvil",
				pot: "Cooking pot",
				horseshoe: "Horseshoe",
				crossedSwords: "Crossed swords",
				sword: "Sword",
				helmet: "Helmet",
				chest: "Chest",
				scroll: "Scroll",
				campfire: "Campfire",
				axe: "Axe",
				flag: "Banner"
			},
			landmark: {
				baradDur: "Barad-Dûr",
				bree: "Bree",
				erebor: "Erebor",
				greyHavens: "Grey Havens",
				helmsDeep: "Helm's Deep",
				isengard: "Isengard",
				minasTirith: "Minas Tirith"
			},
			coins: "Coins",
			quest: "Quest of the Ring",
			myTableau: "Your cards",
			oppTableau: "Opponent's cards",
			central: "Central play area",
			landmarksTitle: "Landmarks",
			landmarkDeck: "Deck {{n}}",
			board: "Middle-earth",
			units: "Units",
			fortress: "Fortress",
			tokens: "Alliance tokens",
			racesCount: "Races {{n}}/6",
			regionsCount: "Regions {{n}}/7",
			frodo: "Frodo & Sam",
			cardsCount: "Cards {{n}}",
			track: {
				coin: "Bonus: take 1 Coin",
				unit: "Bonus: place 1 Unit in any region",
				extraTurn: "Bonus: take another turn after this one",
				fortress: "Bonus: remove 1 enemy Fortress from any region"
			},
			nazgul: "Nazgûl",
			play: "Play",
			discard: "Discard",
			take: "Take",
			cancel: "Back",
			confirm: "Confirm",
			noCost: "No cost",
			costCoins: "Pay {{n}} Coins",
			missing: "{{n}} missing Skills",
			chainFree: "Free by chaining",
			cantAfford: "Not enough Coins",
			pickRedRegion: "Choose a region for the Units",
			pickToken: "Choose an Alliance token to keep",
			pickRace: "Choose a Race to draw from",
			pickGrey: "Choose a Grey card for your opponent to discard",
			pickDiscard: "Choose a card from the discard to play for free",
			movePrompt: "Move 1 Unit ({{n}} left): choose origin and destination",
			removePrompt: "Remove 1 enemy Unit ({{n}} left)",
			unitPrompt: "Place 1 Unit in any region ({{n}} left)",
			entPrompt: "Ents: choose an effect ({{n}} left)",
			wizardsPrompt: "Wizard's counsel: place 2 Units in one region, or 1 Unit in each of two regions",
			placeTwo: "2 Units in {{region}}",
			placeOne: "1 Unit in {{region}}",
			entCoin: "Opponent loses 1 Coin",
			entRemove: "Remove 1 enemy Unit from {{region}}",
			entMove: "Move 1 Unit {{from}} → {{to}}",
			moveOpt: "{{from}} → {{to}}",
			useSkill: "Use a Skill",
			emptyTableau: "No cards yet",
			emptyDiscard: "No discards yet",
			discardPile: "Discard pile",
			pickFortress: "Choose an enemy Fortress to remove",
			winFellowship: "The Fellowship wins: the One Ring is destroyed!",
			winSauron: "Sauron wins: the Nazgûl seized the One Ring!",
			winRaces: "{{name}} wins: six Races rally to the cause!",
			winConquest: "{{name}} wins: all Middle-earth is conquered!",
			winRegions: "{{name}} wins with more regions",
			winTie: "Both players hold the same number of regions and share the victory",
			selectCard: "Select an available card",
			selectLandmark: "Select a Landmark tile",
			cardConfirmHint: "Choose Play or Discard beside the selected card",
			landmarkConfirmHint: "Take the selected Landmark beside its tile",
			cardInfo: "Card details",
			ciEffect: "Effect",
			ciSkills: "Skills needed",
			ciMissing: "{{n}} missing, may pay Coins instead",
			ciCost: "Cost",
			ciChainRequire: "Chain required",
			ciChainGrant: "Chain symbol",
			ciRequireHow: "Free to play if a card in your play area already shows the {{chain}} symbol",
			ciGrantHow: "Once you have this symbol, cards requiring {{chain}} are free to play",
			ciGreyNote: "Each Skill symbol may be used once per turn; on a card with Skills separated by a slash, you may use only one of them per turn.",
			inspect: "Inspect",
			close: "Close",
			cardFaceDown: "Card face down",
			requirement: "Requires the {{chain}} chain",
			turnActive: "Acting",
			endingKicker: "Finale of chapter {{n}}",
			winnerMark: "Victory",
			trackStart: "Frodo’s start",
			trackEnd: "Mount Doom",
			regionAria: "{{region}}: Fellowship {{fu}} Units, {{ff}} Fortresses; Sauron {{su}} Units, {{sf}} Fortresses",
			errNotPlayer: "You are not in this game",
			errDone: "The game is already over",
			errPending: "Complete the current choice first",
			errNotYourTurn: "It is not your turn yet",
			errBadSlot: "That card cannot be taken right now",
			errCantAfford: "You do not have enough Coins to pay for that card",
			errNoPending: "There is no choice to resolve",
			errNotYourChoice: "That choice is not yours",
			errBadChoice: "That choice is not valid",
			effectCoins: "Take {{n}} Coins",
			effectQuest: "Advance {{n}} spaces",
			effectUnits: "Place {{n}} Units",
			effectRace: "Gain the {{race}} symbol",
			effectSkills: "Provides Skills: {{list}}",
			effectPurple: "{{parts}}",
			purpleMove: "Move {{n}} times",
			purpleRemove: "Remove {{n}} enemy Units",
			purpleCoin: "Opponent loses {{n}} Coins",
			needRegion: "{{a}} or {{b}}",
			logTake: "{{name}} played {{card}}",
			logDiscard: "{{name}} discarded a card",
			logLandmark: "{{name}} took the {{landmark}} Landmark",
			logToken: "{{name}} gained a {{race}} Alliance token"
		}
	}
};
//#endregion
export { Dt as default };
