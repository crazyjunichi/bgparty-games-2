import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { avatarNameAt as s, useGameT as c, useI18nSettings as l } from "@bgparty/sdk/i18n";
import { IconHistory as u, IconRecenter as d, IconZoomIn as ee, IconZoomOut as te } from "@bgparty/sdk/icons";
import { Texture as ne } from "@bgparty/sdk/texture";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { PLAYER_COLORS as _ } from "@bgparty/sdk/player-colors";
import { Fragment as re, jsx as v, jsxs as y } from "react/jsx-runtime";
import { botAvatarOf as b } from "@bgparty/sdk/lobby";
import { AVATARS as x } from "@bgparty/sdk/avatars";
//#region src/game/data.ts
var S = [
	"machete",
	"paddle",
	"coin"
], C = {
	traveler: {
		cost: 1,
		sym: "coin",
		power: 1,
		start: 4
	},
	explorer: {
		cost: 2,
		powers: {
			machete: 1,
			paddle: 1
		},
		start: 3
	},
	sailor: {
		cost: 2,
		sym: "paddle",
		power: 1,
		start: 1
	},
	scout: {
		cost: 1,
		sym: "machete",
		power: 2,
		market: !0
	},
	captain: {
		cost: 2,
		sym: "paddle",
		power: 3,
		market: !0
	},
	trailblazer: {
		cost: 3,
		sym: "machete",
		power: 3,
		market: !0
	},
	pioneer: {
		cost: 5,
		sym: "machete",
		power: 5,
		market: !0
	},
	"giant-machete": {
		cost: 3,
		sym: "machete",
		power: 6,
		item: !0,
		market: !0
	},
	photographer: {
		cost: 2,
		sym: "coin",
		power: 2,
		market: !0
	},
	journalist: {
		cost: 3,
		sym: "coin",
		power: 3,
		market: !0
	},
	millionaire: {
		cost: 5,
		sym: "coin",
		power: 4,
		market: !0
	},
	"treasure-chest": {
		cost: 3,
		sym: "coin",
		power: 4,
		item: !0,
		market: !0
	},
	jack: {
		cost: 2,
		joker: 1,
		market: !0
	},
	adventurer: {
		cost: 4,
		joker: 2,
		market: !0
	},
	"prop-plane": {
		cost: 4,
		joker: 4,
		item: !0,
		market: !0
	},
	cartographer: {
		cost: 4,
		action: "cartographer",
		market: !0
	},
	compass: {
		cost: 2,
		action: "compass",
		item: !0,
		market: !0
	},
	scientist: {
		cost: 4,
		action: "scientist",
		market: !0
	},
	transmitter: {
		cost: 4,
		action: "transmitter",
		item: !0,
		market: !0
	},
	"travel-log": {
		cost: 3,
		action: "travel-log",
		item: !0,
		market: !0
	},
	native: {
		cost: 5,
		action: "native",
		market: !0
	}
}, w = Object.keys(C).filter((e) => C[e].market), T = [
	"scout",
	"trailblazer",
	"jack",
	"photographer",
	"treasure-chest",
	"transmitter"
], E = w.filter((e) => !T.includes(e)), D = T.length, O = Object.keys(C).filter((e) => (C[e].start ?? 0) > 0).flatMap((e) => Array.from({ length: C[e].start ?? 0 }, () => e));
function k(e, t) {
	let n = C[e];
	return n.joker ? n.joker : n.powers?.[t] ?? (n.sym === t ? n.power ?? 0 : 0);
}
function ie(e) {
	let t = C[e];
	return t.joker ? [...S] : t.powers ? S.filter((e) => (t.powers?.[e] ?? 0) > 0) : t.sym ? [t.sym] : [];
}
var ae = [
	{
		q: 0,
		r0: 0,
		cells: [
			"s",
			"s",
			"s",
			"s"
		]
	},
	{
		q: 1,
		r0: 0,
		cells: [
			"j1",
			"j1",
			"j1",
			"j2"
		]
	},
	{
		q: 2,
		r0: 0,
		cells: [
			"j1",
			"j2",
			"c2",
			"j1"
		]
	},
	{
		q: 3,
		r0: -1,
		cells: [
			"j1",
			"j2",
			"j1",
			"j2",
			"j1"
		]
	},
	{
		q: 4,
		r0: -1,
		cells: [
			"j2",
			"j1",
			"j2"
		]
	},
	{
		q: 5,
		r0: 0,
		cells: ["b3m:1"]
	},
	{
		q: 6,
		r0: -1,
		cells: [
			"~2",
			"~3",
			"~2",
			"~1"
		]
	},
	{
		q: 7,
		r0: -1,
		cells: [
			"~1",
			"~2",
			"~3",
			"~2",
			"~1"
		]
	},
	{
		q: 8,
		r0: -1,
		cells: [
			"~3",
			"~2",
			"~3",
			"~1"
		]
	},
	{
		q: 9,
		r0: -1,
		cells: [
			"j1",
			"r1",
			"~2",
			"j2"
		]
	},
	{
		q: 10,
		r0: -1,
		cells: [
			"j1",
			"r2",
			"v2",
			"r1"
		]
	},
	{
		q: 11,
		r0: 0,
		cells: ["b4c:2"]
	},
	{
		q: 12,
		r0: -2,
		cells: [
			"v2",
			"v3",
			"v1",
			"v3",
			"v2"
		]
	},
	{
		q: 13,
		r0: -2,
		cells: [
			"v1",
			"j2",
			"v2",
			"j1",
			"v2",
			"j1"
		]
	},
	{
		q: 14,
		r0: -1,
		cells: [
			"c2",
			"j2",
			"j3",
			"j2"
		]
	},
	{
		q: 15,
		r0: -1,
		cells: [
			"j2",
			"j3",
			"j4",
			"j3",
			"j2"
		]
	},
	{
		q: 16,
		r0: 0,
		cells: ["b4m:3"]
	},
	{
		q: 17,
		r0: -1,
		cells: [
			"j2",
			"j3",
			"j4",
			"j3"
		]
	},
	{
		q: 18,
		r0: -1,
		cells: [
			"j3",
			"j2",
			"j1",
			"j2"
		]
	},
	{
		q: 19,
		r0: -1,
		cells: [
			"v2",
			"v3",
			"v2",
			"v1"
		]
	},
	{
		q: 20,
		r0: -1,
		cells: [
			"~2",
			"~3",
			"~2",
			"~1"
		]
	},
	{
		q: 21,
		r0: 0,
		cells: ["b3p:4"]
	},
	{
		q: 22,
		r0: -1,
		cells: [
			"~2",
			"~3",
			"~2"
		]
	},
	{
		q: 23,
		r0: -1,
		cells: [
			"v2",
			"v3",
			"v2"
		]
	},
	{
		q: 24,
		r0: 0,
		cells: ["t"]
	}
];
function oe(e, t, n, r) {
	if (e === "s") return {
		id: t,
		q: n,
		r,
		t: "start",
		s: 0
	};
	if (e === "t") return {
		id: t,
		q: n,
		r,
		t: "temple",
		s: 0
	};
	let i = e[0], [a, o] = e.slice(1).split(":"), s = Number(a.replace(/[a-z]$/, "")), c = a.match(/[a-z]$/)?.[0];
	if (i === "j") return {
		id: t,
		q: n,
		r,
		t: "jungle",
		s
	};
	if (i === "~") return {
		id: t,
		q: n,
		r,
		t: "river",
		s
	};
	if (i === "v") return {
		id: t,
		q: n,
		r,
		t: "village",
		s
	};
	if (i === "r") return {
		id: t,
		q: n,
		r,
		t: "rubble",
		s
	};
	if (i === "c") return {
		id: t,
		q: n,
		r,
		t: "camp",
		s
	};
	if (i === "b") return {
		id: t,
		q: n,
		r,
		t: "blockade",
		s,
		sym: c === "p" ? "paddle" : c === "c" ? "coin" : "machete",
		num: Number(o)
	};
	throw Error(`bad map cell ${e}`);
}
var A = ae.flatMap((e) => e.cells.map((t, n) => oe(t, `${e.q},${e.r0 + n}`, e.q, e.r0 + n))), j = new Map(A.map((e) => [e.id, e])), se = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1],
	[1, -1],
	[-1, 1]
];
function M(e) {
	let t = j.get(e);
	return t ? se.map(([e, n]) => j.get(`${t.q + e},${t.r + n}`)).filter((e) => !!e) : [];
}
var N = A.find((e) => e.t === "temple").id, P = A.filter((e) => e.t === "start").map((e) => e.id);
function ce(e) {
	return e === "jungle" ? "machete" : e === "river" ? "paddle" : e === "village" ? "coin" : null;
}
//#endregion
//#region src/game/meta.ts
var le = {
	id: "eldorado",
	uuid: "7a9d74ed-9aa5-4daf-aa76-dcbc9840f0cb",
	tier: "alpha",
	mechanics: [
		"deck-bag-building",
		"grid-movement",
		"race",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.eldorado.name",
	descKey: "games.eldorado.desc",
	rulesKey: "games.eldorado.rules",
	icon: "🗺️",
	iconImg: "games/eldorado.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#2f6b45",
	releasedAt: "2026-11-21T00:00:00+08:00",
	search: {
		py: "chong xiang huang jin cheng",
		init: "cxhjc"
	},
	hotseat: "cover"
}, F = t.enum([
	"machete",
	"paddle",
	"coin"
]), ue = t.object({
	uid: t.int().nonnegative(),
	id: t.string()
}), I = t.object({
	card: t.string(),
	stock: t.int().nonnegative()
}), de = t.object({}).default({}), fe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		pawn: t.int().min(0).max(1),
		uid: t.int().nonnegative(),
		sym: F,
		to: t.string()
	}),
	t.object({
		type: t.literal("step"),
		to: t.string()
	}),
	t.object({
		type: t.literal("cross"),
		pawn: t.int().min(0).max(1),
		uids: t.array(t.int().nonnegative()).min(1).max(6),
		to: t.string()
	}),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("buy"),
		card: t.string(),
		uids: t.array(t.int().nonnegative()).min(1).max(8)
	}),
	t.object({
		type: t.literal("act"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("chooseCard"),
		card: t.string()
	}),
	t.object({
		type: t.literal("chooseHex"),
		to: t.string(),
		pawn: t.int().min(0).max(1).optional()
	}),
	t.object({
		type: t.literal("remove"),
		uids: t.array(t.int().nonnegative()).max(2)
	}),
	t.object({
		type: t.literal("discardHand"),
		uids: t.array(t.int().nonnegative()).min(1).max(10)
	}),
	t.object({ type: t.literal("endTurn") })
]), pe = t.object({
	seq: t.int(),
	kind: t.string(),
	rid: t.string(),
	card: t.string().optional(),
	hex: t.string().optional(),
	n: t.int().optional()
}), me = t.object({
	phase: t.enum(["play", "done"]),
	turn: t.string(),
	turnNo: t.int(),
	finalRound: t.boolean(),
	active: t.object({
		rid: t.string(),
		pawn: t.int(),
		left: t.int(),
		sym: t.string()
	}).nullable(),
	played: t.array(ue),
	market: t.array(I.nullable()).length(6),
	reserve: t.array(I),
	bought: t.boolean(),
	cleared: t.array(t.string()),
	players: t.array(t.object({
		rid: t.string(),
		pawns: t.array(t.string()),
		hand: t.int(),
		deck: t.int(),
		discard: t.int(),
		blockades: t.array(t.int()),
		done: t.boolean(),
		arrival: t.int()
	})),
	events: t.array(pe)
}), L = t.object({
	hand: t.array(ue),
	prompt: t.object({
		kind: t.enum([
			"remove1",
			"remove2",
			"transmitter",
			"native"
		]),
		max: t.int()
	}).nullable()
}), R = (e) => ({ code: `games.eldorado.${e}` });
function z(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor, n + 1);
		t.cursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function B(e, t) {
	return {
		uid: e.uid++,
		id: t
	};
}
function V(e, t, n) {
	let r = e.p[t], i = [];
	for (let t = 0; t < n; t += 1) {
		if (!r.deck.length) {
			if (!r.discard.length) break;
			r.deck = z(e, r.discard), r.discard = [];
		}
		let t = r.deck.pop();
		if (!t) break;
		i.push(t);
	}
	return r.hand.push(...i), i;
}
function H(e, t, n, r = {}) {
	e.events.push({
		seq: e.seq++,
		kind: t,
		rid: n,
		...r
	}), e.events.length > 80 && e.events.splice(0, e.events.length - 80);
}
function U(e, t, n) {
	let r = e.p[t], i = r.hand.findIndex((e) => e.uid === n);
	return i < 0 ? null : r.hand.splice(i, 1)[0] ?? null;
}
function W(e, t) {
	return t !== N && e.players.some((n) => e.p[n].pawns.includes(t));
}
function he(e, t, n, r) {
	if (e.t === "blockade") return r.has(e.id) ? {
		cost: 0,
		blockade: !1
	} : e.sym !== t || n < e.s ? null : {
		cost: e.s,
		blockade: !0
	};
	let i = ce(e.t);
	return i ? i !== t || n < e.s ? null : {
		cost: e.s,
		blockade: !1
	} : e.t === "start" || e.t === "temple" ? {
		cost: 0,
		blockade: !1
	} : null;
}
function ge(e, t, n, r) {
	let i = e.p[t];
	n >= i.pawns.length || (i.pawns[n] = r, r === N && i.pawns.every((e) => e === N) && !i.finished && (i.finished = !0, i.arrival = e.finishOrder.length, e.finishOrder.push(t), H(e, "arrive", t), e.finalRound || (e.finalRound = !0, e.finalTurnsLeft = e.players.length - 1 - e.turnIdx)));
}
function _e(e, t, n, r) {
	r === "remove" ? H(e, "removeCard", t, { card: n.id }) : e.played.push(n);
}
function G(e) {
	e.active = null;
}
function ve(e, t, n, r) {
	return he(e, t, n, new Set(r))?.cost ?? null;
}
function ye(e, t, n) {
	let r = e.market.findIndex((e) => e === null);
	r >= 0 && (e.market[r] = {
		card: t,
		stock: n
	});
}
function be(e, t, n, r) {
	if (e.bought) return R("errOneBuy");
	if (!C[n]?.market) return R("errNoStock");
	let i = e.market.findIndex((e) => e?.card === n && e.stock > 0), a = i < 0 && (e.reserve[n] ?? 0) > 0, o = e.market.some((e) => e === null);
	if (i < 0 && !(a && o)) return R("errNoStock");
	let s = e.p[t], c = /* @__PURE__ */ new Set(), l = 0;
	for (let e of r) {
		if (c.has(e)) return R("errBadCard");
		c.add(e);
		let t = s.hand.find((t) => t.uid === e);
		if (!t) return R("errBadCard");
		let n = k(t.id, "coin");
		l += n > 0 ? n : .5;
	}
	if (l < C[n].cost) return R("errNotEnoughCoins");
	for (let n of r) {
		let r = U(e, t, n);
		if (!r) return R("errBadCard");
		_e(e, t, r, C[r.id].item && k(r.id, "coin") > 0 ? "remove" : "play");
	}
	if (i >= 0) {
		let t = e.market[i];
		--t.stock, t.stock <= 0 && (e.market[i] = null);
	} else {
		let t = (e.reserve[n] ?? 0) - 1;
		delete e.reserve[n], t > 0 && ye(e, n, t);
	}
	return s.discard.push(B(e, n)), G(e), e.bought = !0, H(e, "buy", t, { card: n }), null;
}
function xe(e, t, n) {
	let r = C[n.id];
	switch (_e(e, t, n, r.item ? "remove" : "play"), r.action) {
		case "cartographer":
			V(e, t, 2), H(e, "draw", t, { n: 2 });
			break;
		case "compass":
			V(e, t, 3), H(e, "draw", t, { n: 3 });
			break;
		case "scientist":
			V(e, t, 1), H(e, "draw", t, { n: 1 }), e.prompt = {
				kind: "remove1",
				rid: t
			};
			break;
		case "travel-log":
			V(e, t, 2), H(e, "draw", t, { n: 2 }), e.prompt = {
				kind: "remove2",
				rid: t
			};
			break;
		case "transmitter":
			e.prompt = {
				kind: "transmitter",
				rid: t
			};
			break;
		case "native": e.prompt = {
			kind: "native",
			rid: t
		};
	}
	H(e, "action", t, { card: n.id });
}
function Se(t, n, r) {
	de.parse(t);
	let i = {
		seed: r,
		cursor: 0,
		uid: 0,
		players: [...n],
		p: {},
		turnIdx: 0,
		turnNo: 1,
		phase: "play",
		market: Array.from({ length: D }, (e, t) => ({
			card: T[t],
			stock: 3
		})),
		reserve: Object.fromEntries(E.map((e) => [e, 3])),
		played: [],
		active: null,
		bought: !1,
		prompt: null,
		cleared: [],
		finalRound: !1,
		finalTurnsLeft: null,
		finishOrder: [],
		events: [],
		seq: 0
	};
	for (let e of n) i.p[e] = {
		hand: [],
		deck: [],
		discard: [],
		pawns: [],
		blockades: [],
		finished: !1,
		arrival: -1
	}, i.p[e].deck = z(i, O.map((e) => B(i, e)));
	n.length === 2 ? (i.p[n[0]].pawns = [P[0], P[2]], i.p[n[1]].pawns = [P[1], P[3]]) : n.forEach((e, t) => {
		i.p[e].pawns = [P[t % P.length]];
	}), i.turnIdx = e(r, i.cursor, n.length), i.cursor += 1;
	for (let e of n) V(i, e, 4);
	return H(i, "turn", n[i.turnIdx]), {
		state: i,
		fx: []
	};
}
function Ce(e) {
	let t = e.players[e.turnIdx], n = e.p[t];
	if (G(e), n.discard.push(...e.played), e.played = [], e.bought = !1, e.prompt = null, V(e, t, Math.max(0, 4 - n.hand.length)), e.players.every((t) => e.p[t].finished)) {
		e.phase = "done", H(e, "end", t);
		return;
	}
	if (e.finalTurnsLeft !== null && (t !== e.finishOrder[0] && --e.finalTurnsLeft, e.finalTurnsLeft <= 0)) {
		e.phase = "done", H(e, "end", t);
		return;
	}
	e.turnIdx = (e.turnIdx + 1) % e.players.length, e.turnNo += 1, H(e, "turn", e.players[e.turnIdx]);
}
function we(e, t, n) {
	if (e.phase === "done") return R("errGameOver");
	let r = e.players[e.turnIdx];
	if (n.by !== r) return R("errNotYourTurn");
	let i = structuredClone(e), a = r, o = i.p[a], s = new Set(i.cleared);
	if (t.type === "endTurn") return i.prompt ? R("errResolveFirst") : (Ce(i), {
		state: i,
		fx: []
	});
	if (i.prompt) {
		let e = i.prompt;
		if (t.type === "chooseCard" && e.kind === "transmitter") {
			let e = t.card;
			if (!C[e]?.market) return R("errNoStock");
			let n = i.market.findIndex((t) => t?.card === e && t.stock > 0);
			if (n >= 0) {
				let e = i.market[n];
				--e.stock, e.stock <= 0 && (i.market[n] = null);
			} else if ((i.reserve[e] ?? 0) > 0) i.reserve[e] = (i.reserve[e] ?? 0) - 1, (i.reserve[e] ?? 0) <= 0 && delete i.reserve[e];
			else return R("errNoStock");
			return o.discard.push(B(i, e)), i.prompt = null, H(i, "transmit", a, { card: e }), {
				state: i,
				fx: []
			};
		}
		if (t.type === "chooseHex" && e.kind === "native") {
			let e = j.get(t.to);
			if (!e) return R("errBadMove");
			let n = t.pawn, r = o.pawns.map((e, t) => ({
				pos: e,
				index: t
			})).filter(({ pos: e }) => M(e).some((e) => e.id === t.to)), c = n === void 0 ? r[0] : r.find((e) => e.index === n);
			return c ? W(i, t.to) ? R("errOccupied") : (e.t === "blockade" && !s.has(e.id) && (i.cleared.push(e.id), o.blockades.push(e.num ?? 0), H(i, "break", a, {
				hex: e.id,
				n: e.num
			})), ge(i, a, c.index, t.to), i.prompt = null, G(i), H(i, "native", a, { hex: t.to }), {
				state: i,
				fx: []
			}) : R("errBadMove");
		}
		if (t.type === "remove" && (e.kind === "remove1" || e.kind === "remove2")) {
			let n = e.kind === "remove1" ? 1 : 2;
			if (t.uids.length > n) return R("errBadPrompt");
			for (let e of t.uids) if (!U(i, a, e)) return R("errBadCard");
			return i.prompt = null, {
				state: i,
				fx: []
			};
		}
		return R("errBadPrompt");
	}
	switch (t.type) {
		case "move": {
			let e = o.hand.find((e) => e.uid === t.uid);
			if (!e) return R("errBadCard");
			if (k(e.id, t.sym) <= 0) return R("errBadSymbol");
			if (t.pawn >= o.pawns.length) return R("errBadMove");
			let n = o.pawns[t.pawn];
			if (!M(n).some((e) => e.id === t.to)) return R("errBadMove");
			let r = j.get(t.to);
			if (r.t === "rubble" || r.t === "camp") return R("errNeedCards");
			if (W(i, t.to)) return R("errOccupied");
			let c = he(r, t.sym, k(e.id, t.sym), s);
			if (!c) return R("errBadSymbol");
			U(i, a, t.uid), _e(i, a, e, C[e.id].item ? "remove" : "play"), c.blockade && (i.cleared.push(r.id), o.blockades.push(r.num ?? 0), H(i, "break", a, {
				hex: r.id,
				n: r.num
			})), ge(i, a, t.pawn, t.to);
			let l = k(e.id, t.sym) - c.cost;
			return i.active = t.to !== N && l > 0 ? {
				pawn: t.pawn,
				uid: e.uid,
				sym: t.sym,
				left: l
			} : null, H(i, "move", a, { hex: t.to }), {
				state: i,
				fx: []
			};
		}
		case "step": {
			if (!i.active) return R("errNoActive");
			let e = o.pawns[i.active.pawn];
			if (!e || !M(e).some((e) => e.id === t.to)) return R("errBadMove");
			let n = j.get(t.to);
			if (n.t === "rubble" || n.t === "camp") return R("errNeedCards");
			if (W(i, t.to)) return R("errOccupied");
			let r = he(n, i.active.sym, i.active.left, s);
			return r ? (r.blockade && (i.cleared.push(n.id), o.blockades.push(n.num ?? 0), H(i, "break", a, {
				hex: n.id,
				n: n.num
			})), ge(i, a, i.active.pawn, t.to), i.active.left -= r.cost, (i.active.left <= 0 || t.to === N) && G(i), H(i, "move", a, { hex: t.to }), {
				state: i,
				fx: []
			}) : R("errBadSymbol");
		}
		case "cross": {
			if (G(i), t.pawn >= o.pawns.length) return R("errBadMove");
			let e = o.pawns[t.pawn];
			if (!M(e).some((e) => e.id === t.to)) return R("errBadMove");
			let n = j.get(t.to);
			if (n.t !== "rubble" && n.t !== "camp") return R("errBadMove");
			if (W(i, t.to)) return R("errOccupied");
			if (t.uids.length !== n.s) return R("errNeedCards");
			if (new Set(t.uids).size !== t.uids.length) return R("errBadCard");
			let r = [];
			for (let e of t.uids) {
				let t = U(i, a, e);
				if (!t) return R("errBadCard");
				r.push(t);
			}
			for (let e of r) _e(i, a, e, n.t === "camp" ? "remove" : "play");
			return ge(i, a, t.pawn, t.to), H(i, n.t === "camp" ? "camp" : "rubble", a, {
				hex: n.id,
				n: r.length
			}), {
				state: i,
				fx: []
			};
		}
		case "stop": return i.active ? (G(i), {
			state: i,
			fx: []
		}) : R("errNoActive");
		case "buy": return be(i, a, t.card, t.uids) ?? {
			state: i,
			fx: []
		};
		case "act": {
			let e = o.hand.find((e) => e.uid === t.uid);
			return !e || !C[e.id].action ? R("errBadCard") : C[e.id].action === "native" && !o.pawns.some((e) => M(e).some((e) => !W(i, e.id))) ? R("errBadMove") : (U(i, a, t.uid), xe(i, a, e), {
				state: i,
				fx: []
			});
		}
		case "discardHand":
			if (G(i), !t.uids.length) return R("errBadAction");
			for (let e of t.uids) {
				let t = U(i, a, e);
				if (!t) return R("errBadCard");
				o.discard.push(t);
			}
			return H(i, "discardHand", a, { n: t.uids.length }), {
				state: i,
				fx: []
			};
		default: return R("errBadAction");
	}
}
function Te(e, t) {
	let n = {
		phase: e.phase,
		turn: e.players[e.turnIdx],
		turnNo: e.turnNo,
		finalRound: e.finalRound,
		active: e.active ? {
			rid: e.players[e.turnIdx],
			pawn: e.active.pawn,
			left: e.active.left,
			sym: e.active.sym
		} : null,
		played: e.played.map((e) => ({
			uid: e.uid,
			id: e.id
		})),
		market: e.market.map((e) => e ? {
			card: e.card,
			stock: e.stock
		} : null),
		reserve: E.filter((t) => (e.reserve[t] ?? 0) > 0).map((t) => ({
			card: t,
			stock: e.reserve[t] ?? 0
		})),
		bought: e.bought,
		cleared: [...e.cleared],
		players: e.players.map((t) => {
			let n = e.p[t];
			return {
				rid: t,
				pawns: [...n.pawns],
				hand: n.hand.length,
				deck: n.deck.length,
				discard: n.discard.length,
				blockades: [...n.blockades],
				done: n.finished,
				arrival: n.arrival
			};
		}),
		events: e.events.slice(-40)
	}, r = e.p[t];
	return {
		public: n,
		private: {
			hand: r ? r.hand.map((e) => ({
				uid: e.uid,
				id: e.id
			})) : [],
			prompt: e.prompt && e.prompt.rid === t ? {
				kind: e.prompt.kind,
				max: e.prompt.kind === "remove2" ? 2 : 1
			} : null
		}
	};
}
function Ee(e) {
	let t = /* @__PURE__ */ new Set([e]), n = [e], r = 0;
	for (; n.length;) {
		if (n.includes(N)) return r;
		let e = [];
		for (let r of n) for (let n of M(r)) t.has(n.id) || (t.add(n.id), e.push(n.id));
		n = e, r += 1;
	}
	return 999;
}
function De(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.filter((t) => e.p[t].finished), n = e.players.filter((t) => !e.p[t].finished), r = [...t].sort((t, n) => {
		let r = e.p[t], i = e.p[n];
		if (r.blockades.length !== i.blockades.length) return i.blockades.length - r.blockades.length;
		let a = Math.max(0, ...r.blockades), o = Math.max(0, ...i.blockades);
		return a === o ? r.arrival - i.arrival : o - a;
	}), i = [...n].sort((t, n) => Math.min(...e.p[t].pawns.map(Ee)) - Math.min(...e.p[n].pawns.map(Ee))), a = [...r, ...i];
	return {
		phase: "done",
		winner: [a[0]],
		ranking: a
	};
}
var Oe = {
	meta: le,
	saveCompatibility: {
		version: "2",
		migrate: ({ version: e, log: t }) => {
			if (e !== void 0 && e !== "1") return null;
			let n = /* @__PURE__ */ new Set([
				"5,-1",
				"11,-1",
				"11,1",
				"16,-1",
				"21,-1"
			]);
			return t.some((e) => {
				let t = e.to;
				return typeof t == "string" && n.has(t);
			}) ? null : t;
		}
	},
	schemas: {
		action: fe,
		config: de,
		publicView: me,
		privateView: L
	},
	setup: Se,
	reduce: we,
	viewFor: Te,
	status: De
};
function ke(e) {
	return {
		x: Math.sqrt(3) * 34 * (e.q + e.r / 2),
		y: 51 * e.r
	};
}
var K = new Map(A.map((e) => [e.id, ke(e)])), q = Math.max(...A.map((e) => K.get(e.id).x)) - Math.min(...A.map((e) => K.get(e.id).x)) + 68 + 52, J = Math.max(...A.map((e) => K.get(e.id).y)) - Math.min(...A.map((e) => K.get(e.id).y)) + 68 + 52, Ae = 60 - Math.min(...A.map((e) => K.get(e.id).x)), je = 60 - Math.min(...A.map((e) => K.get(e.id).y));
function Me(e) {
	let t = K.get(e) ?? {
		x: 0,
		y: 0
	};
	return {
		x: t.x + Ae,
		y: t.y + je
	};
}
var Y = Array.from({ length: 6 }, (e, t) => {
	let n = Math.PI / 180 * (60 * t + 90);
	return `${(32.98 * Math.cos(n)).toFixed(1)},${(32.98 * Math.sin(n)).toFixed(1)}`;
}).join(" "), Ne = {
	start: "url(#el-g-start)",
	jungle: "url(#el-g-jungle)",
	river: "url(#el-g-river)",
	village: "url(#el-g-village)",
	rubble: "url(#el-g-rubble)",
	camp: "url(#el-g-camp)",
	blockade: "url(#el-g-blockade)",
	temple: "url(#el-g-temple)"
}, Pe = (e) => {
	let t = 2166136261;
	for (let n = 0; n < e.length; n += 1) t = Math.imul(t ^ e.charCodeAt(n), 16777619);
	return (t >>> 0) % 997;
}, X = (e, t, n) => (e * (t * 37 + 11) % 101 / 50 - 1) * n;
function Fe() {
	let e = q * 6, t = J * 8, n = -e / 2 + q / 2, r = -t / 2 + J / 2, i = new Set(A.map((e) => `${e.q},${e.r}`));
	return /* @__PURE__ */ y("g", {
		className: "el-map-backdrop",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("rect", {
				x: n,
				y: r,
				width: e,
				height: t,
				fill: "url(#el-g-paper)"
			}),
			/* @__PURE__ */ v("g", {
				opacity: ".55",
				children: Array.from({ length: 19 }, (e, t) => t - 9).map((e) => Array.from({ length: 13 }, (e, t) => t - 6).map((t) => {
					if (i.has(`${e},${t}`)) return null;
					let n = Math.hypot(e * .85, t);
					if (n < 4.6) return null;
					let r = ke({
						q: e,
						r: t
					});
					return /* @__PURE__ */ v("polygon", {
						points: Y,
						transform: `translate(${r.x + Ae} ${r.y + je})`,
						fill: "none",
						stroke: "#a8c394",
						strokeOpacity: Math.min(.11, .022 + n * .006),
						strokeWidth: "1.1"
					}, `ghost-${e}-${t}`);
				}))
			}),
			Array.from({ length: 34 }, (i, a) => {
				let o = r + a * t / 26;
				return /* @__PURE__ */ v("path", {
					d: `M${n} ${o}c${e * .07} ${-J * .06} ${e * .13} ${J * .07} ${e * .2} ${-J * .012}s${e * .12} ${J * .055} ${e * .21} ${-J * .02}s${e * .12} ${J * .05} ${e * .2} ${-J * .005}`,
					fill: "none",
					stroke: "#8fae7c",
					strokeOpacity: a % 5 == 0 ? .16 : .09,
					strokeWidth: a % 5 == 0 ? 2 : 1.3
				}, `contour-${a}`);
			}),
			/* @__PURE__ */ y("g", {
				transform: `translate(${q * .66} ${J * .5})`,
				opacity: ".2",
				children: [
					/* @__PURE__ */ v("circle", {
						r: "96",
						fill: "none",
						stroke: "#e7cf98",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("circle", {
						r: "78",
						fill: "none",
						stroke: "#e7cf98",
						strokeWidth: "2.4"
					}),
					/* @__PURE__ */ v("circle", {
						r: "58",
						fill: "none",
						stroke: "#e7cf98",
						strokeWidth: "1",
						strokeDasharray: "2 7"
					}),
					Array.from({ length: 24 }, (e, t) => /* @__PURE__ */ v("rect", {
						x: "-1",
						y: "-88",
						width: "2",
						height: t % 6 == 0 ? 12 : 6,
						fill: "#e7cf98",
						transform: `rotate(${t * 15})`
					}, `tick-${t}`)),
					/* @__PURE__ */ v("path", {
						d: "M0 -74L13 0 0 74-13 0z",
						fill: "#e7cf98",
						fillOpacity: ".55"
					}),
					/* @__PURE__ */ v("path", {
						d: "M0 -74L0 0 13 0z",
						fill: "#0b1a11",
						fillOpacity: ".7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M0 74L0 0-13 0z",
						fill: "#0b1a11",
						fillOpacity: ".35"
					}),
					/* @__PURE__ */ v("text", {
						y: "-104",
						textAnchor: "middle",
						fontSize: "15",
						fontWeight: "700",
						letterSpacing: "4",
						fill: "#e7cf98",
						children: "N"
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				className: "el-cartouche",
				transform: "translate(26 22)",
				children: [
					/* @__PURE__ */ v("rect", {
						width: "268",
						height: "70",
						rx: "7",
						fill: "#0d1b12",
						fillOpacity: ".62",
						stroke: "#c9a227",
						strokeOpacity: ".55",
						strokeWidth: "1.6"
					}),
					/* @__PURE__ */ v("rect", {
						x: "5",
						y: "5",
						width: "258",
						height: "60",
						rx: "4",
						fill: "none",
						stroke: "#c9a227",
						strokeOpacity: ".3",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("text", {
						x: "134",
						y: "34",
						textAnchor: "middle",
						fontSize: "23",
						fontWeight: "800",
						letterSpacing: "7.5",
						fill: "#f2dfb2",
						children: "EL DORADO"
					}),
					/* @__PURE__ */ v("text", {
						x: "134",
						y: "54",
						textAnchor: "middle",
						fontSize: "9",
						letterSpacing: "4.2",
						fill: "#d8c290",
						fillOpacity: ".8",
						children: "THE QUEST FOR"
					})
				]
			}),
			/* @__PURE__ */ v("rect", {
				x: n,
				y: r,
				width: e,
				height: t,
				fill: "url(#el-g-vignette)"
			}),
			/* @__PURE__ */ v("rect", {
				x: n,
				y: r,
				width: e,
				height: t,
				fill: "url(#el-grain)",
				opacity: ".55"
			})
		]
	});
}
function Ie() {
	return /* @__PURE__ */ y("defs", { children: [
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-paper",
			x1: "0",
			y1: "0",
			x2: "0.35",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#1e3a27"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.5",
					stopColor: "#142a1b"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#091510"
				})
			]
		}),
		/* @__PURE__ */ y("radialGradient", {
			id: "el-g-vignette",
			cx: "0.5",
			cy: "0.5",
			r: "0.62",
			children: [/* @__PURE__ */ v("stop", {
				offset: "0.55",
				stopColor: "#000000",
				stopOpacity: "0"
			}), /* @__PURE__ */ v("stop", {
				offset: "1",
				stopColor: "#000000",
				stopOpacity: "0.55"
			})]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-jungle",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#43905a"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#2b6c45"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#16402a"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-river",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#4793b8"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#27708c"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#143f57"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-village",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#e3bd6f"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#c39745"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#8d6526"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-rubble",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#b0a690"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#8d8576"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#5f584b"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-camp",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#a8502f"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#81361f"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#552015"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-blockade",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#8a6039"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#654428"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#412c19"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-cleared",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#6f7d4c"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#556a3d"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#33482b"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-temple",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#f7d071"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#dcaa2e"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#a1750f"
				})
			]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-g-start",
			x1: "0",
			y1: "0",
			x2: "0.25",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#8fa877"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#6f8d62"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#4d6a48"
				})
			]
		}),
		/* @__PURE__ */ y("radialGradient", {
			id: "el-g-glow",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#ffe9a8",
					stopOpacity: ".9"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.4",
					stopColor: "#ffd873",
					stopOpacity: ".38"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#ffd873",
					stopOpacity: "0"
				})
			]
		}),
		/* @__PURE__ */ y("radialGradient", {
			id: "el-hex-vig",
			cx: "0.5",
			cy: "0.46",
			r: "0.62",
			children: [/* @__PURE__ */ v("stop", {
				offset: "0.5",
				stopColor: "#000000",
				stopOpacity: "0"
			}), /* @__PURE__ */ v("stop", {
				offset: "1",
				stopColor: "#000000",
				stopOpacity: "0.34"
			})]
		}),
		/* @__PURE__ */ y("linearGradient", {
			id: "el-hex-sheen",
			x1: "0.1",
			y1: "0",
			x2: "0.7",
			y2: "1",
			children: [
				/* @__PURE__ */ v("stop", {
					offset: "0",
					stopColor: "#ffffff",
					stopOpacity: ".22"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "0.45",
					stopColor: "#ffffff",
					stopOpacity: ".05"
				}),
				/* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#ffffff",
					stopOpacity: "0"
				})
			]
		}),
		/* @__PURE__ */ v("pattern", {
			id: "el-grain",
			width: "16",
			height: "16",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ v("path", {
				d: "M0 16L16 0",
				stroke: "#ffffff",
				strokeOpacity: ".035",
				strokeWidth: "1.4"
			})
		}),
		/* @__PURE__ */ v("clipPath", {
			id: "el-hex-clip",
			children: /* @__PURE__ */ v("polygon", { points: Y })
		})
	] });
}
var Le = (e, t) => t[e % t.length];
function Re({ x: e, y: t, s: n, tone: r }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: "1",
				cy: "7",
				rx: "10",
				ry: "4.2",
				fill: "#0b2417",
				opacity: ".42"
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 7V-5",
				stroke: "#4a3520",
				strokeWidth: "2.6",
				strokeLinecap: "round"
			}),
			Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ v("path", {
				d: "M0 -5C2.6 -8 4.8 -12.4 4.4 -17C1.8 -14 -0.6 -9.6 0 -5Z",
				fill: r,
				transform: `rotate(${t * 60 + 12})`
			}, t)),
			/* @__PURE__ */ v("circle", {
				cx: "0",
				cy: "-5",
				r: "2.7",
				fill: "#57a173"
			})
		]
	});
}
function ze({ seed: e }) {
	return /* @__PURE__ */ v("g", {
		opacity: ".5",
		children: Array.from({ length: 7 }, (t, n) => {
			let r = X(e, n + 11, 26), i = X(e, n + 21, 24), a = 1.6 + (e + n * 7) % 4 * .9;
			return /* @__PURE__ */ v("circle", {
				cx: r,
				cy: i,
				r: a,
				fill: n % 2 ? "#17442b" : "#3c8b5c",
				opacity: n % 2 ? .55 : .35
			}, n);
		})
	});
}
function Be({ t: e, seed: t }) {
	let n = X(t, 4, 8);
	if (e === "jungle") {
		let e = Le(t, [
			[
				{
					x: -14,
					y: 9,
					s: 1.05
				},
				{
					x: 9,
					y: -6,
					s: .92
				},
				{
					x: 2,
					y: 20,
					s: .78
				}
			],
			[
				{
					x: -6,
					y: -4,
					s: 1.12
				},
				{
					x: -20,
					y: 14,
					s: .86
				},
				{
					x: 14,
					y: 10,
					s: .95
				}
			],
			[
				{
					x: 12,
					y: -10,
					s: 1
				},
				{
					x: -12,
					y: -2,
					s: .9
				},
				{
					x: -4,
					y: 18,
					s: .84
				},
				{
					x: 18,
					y: 18,
					s: .7
				}
			]
		]);
		return /* @__PURE__ */ y("g", {
			transform: `rotate(${n})`,
			children: [
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: "6",
					rx: "32",
					ry: "28",
					fill: "#123020",
					opacity: ".28"
				}),
				/* @__PURE__ */ v(ze, { seed: t }),
				e.map((e, t) => /* @__PURE__ */ v(Re, {
					x: e.x,
					y: e.y,
					s: e.s,
					tone: t % 2 ? "#2f7a4c" : "#378552"
				}, t))
			]
		});
	}
	if (e === "river") {
		let e = [
			0,
			58,
			-58
		][t % 3], n = X(t, 7, 6);
		return /* @__PURE__ */ y("g", {
			transform: `rotate(${e})`,
			children: [
				/* @__PURE__ */ v("rect", {
					x: "-40",
					y: -7 + n,
					width: "80",
					height: "16",
					fill: "#8fbfd6",
					opacity: ".28"
				}),
				/* @__PURE__ */ v("rect", {
					x: "-40",
					y: -5.6 + n,
					width: "80",
					height: "13",
					fill: "#2f7ba2"
				}),
				/* @__PURE__ */ v("rect", {
					x: "-40",
					y: -4.2 + n,
					width: "80",
					height: "10",
					fill: "#357fa8",
					opacity: ".75"
				}),
				/* @__PURE__ */ v("path", {
					d: `M-40 ${-5.6 + n}h80`,
					stroke: "#b8e2f2",
					strokeWidth: "1.6",
					opacity: ".55"
				}),
				/* @__PURE__ */ v("path", {
					d: `M-40 ${7.4 + n}h80`,
					stroke: "#164054",
					strokeWidth: "1.6",
					opacity: ".45"
				}),
				Array.from({ length: 4 }, (e, t) => /* @__PURE__ */ v("path", {
					d: `M${-30 + t * 17} ${-1 + n}c2 2.6 5 2.6 7 0`,
					fill: "none",
					stroke: "#eaf6fb",
					strokeWidth: "1.7",
					strokeLinecap: "round",
					opacity: .34
				}, t)),
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: -11 + n,
					rx: "30",
					ry: "3",
					fill: "#2c5c3a",
					opacity: ".3"
				}),
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: 12 + n,
					rx: "30",
					ry: "3",
					fill: "#2c5c3a",
					opacity: ".24"
				})
			]
		});
	}
	if (e === "village") {
		let e = [
			{
				x: -13,
				y: 3,
				s: 1.3,
				roof: "#8f5c2e"
			},
			{
				x: 12,
				y: 8,
				s: 1.08,
				roof: "#a4703a"
			},
			...t % 2 ? [{
				x: 15,
				y: -11,
				s: .9,
				roof: "#96622f"
			}] : []
		];
		return /* @__PURE__ */ y("g", {
			transform: `rotate(${n * .5})`,
			children: [
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: "4",
					rx: "30",
					ry: "24",
					fill: "#a97e3a",
					opacity: ".18"
				}),
				/* @__PURE__ */ v("path", {
					d: "M-30 18c8-4 12-2 17-6s9-4 15-2 9 1 14 0",
					fill: "none",
					stroke: "#7a5a22",
					strokeWidth: "2.6",
					opacity: ".5",
					strokeLinecap: "round"
				}),
				e.map((e, t) => /* @__PURE__ */ y("g", {
					transform: `translate(${e.x} ${e.y}) scale(${e.s})`,
					children: [
						/* @__PURE__ */ v("ellipse", {
							cx: "0",
							cy: "13",
							rx: "9",
							ry: "2.6",
							fill: "#4a3016",
							opacity: ".3"
						}),
						/* @__PURE__ */ v("path", {
							d: "M-10 2L0 -10 10 2z",
							fill: e.roof,
							stroke: "#3b2614",
							strokeWidth: "1.4"
						}),
						/* @__PURE__ */ v("rect", {
							x: "-7.6",
							y: "2",
							width: "15.2",
							height: "11.4",
							fill: "#f5e4bb",
							stroke: "#634322",
							strokeWidth: "1.2"
						}),
						/* @__PURE__ */ v("rect", {
							x: "-2.4",
							y: "6",
							width: "4.8",
							height: "7.4",
							fill: "#5e3d1e",
							opacity: ".85"
						}),
						/* @__PURE__ */ v("rect", {
							x: "-6.4",
							y: "5.6",
							width: "2.4",
							height: "3.2",
							fill: "#7a5a2c",
							opacity: ".5"
						})
					]
				}, t)),
				/* @__PURE__ */ y("g", {
					transform: `translate(${-24 + X(t, 3, 3)} ${12 + X(t, 5, 3)})`,
					children: [/* @__PURE__ */ v("circle", {
						r: "3.4",
						fill: "#8a7c5c",
						stroke: "#4a3016",
						strokeWidth: "1"
					}), /* @__PURE__ */ v("circle", {
						r: "1.4",
						fill: "#2f2416",
						opacity: ".6"
					})]
				})
			]
		});
	}
	if (e === "rubble") {
		let e = Array.from({ length: 5 }, (e, n) => ({
			px: X(t, n + 2, 20),
			py: X(t, n + 9, 18),
			size: 4.6 + (t + n * 13) % 5 * 1.5,
			rot: (t + n * 37) % 90
		}));
		return /* @__PURE__ */ y("g", {
			transform: `rotate(${n * .5})`,
			children: [
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: "4",
					rx: "29",
					ry: "23",
					fill: "#6d6353",
					opacity: ".22"
				}),
				e.map((e, t) => /* @__PURE__ */ y("g", {
					transform: `translate(${e.px} ${e.py}) rotate(${e.rot})`,
					children: [/* @__PURE__ */ v("polygon", {
						points: `${-e.size},${e.size * .5} ${-e.size * .3},${-e.size * .75} ${e.size * .8},${-e.size * .35} ${e.size * .6},${e.size * .6}`,
						fill: t % 2 ? "#cec4ae" : "#b5ab95",
						stroke: "#4f4738",
						strokeWidth: "1.3"
					}), /* @__PURE__ */ v("path", {
						d: `M${-e.size * .6},${e.size * .1}l${e.size * .8},${-e.size * .2}`,
						stroke: "#7b7263",
						strokeWidth: "1.1",
						opacity: ".7"
					})]
				}, t)),
				/* @__PURE__ */ v("path", {
					d: "M-20 -16l6 7M16 -14l-5 6",
					stroke: "#57503f",
					strokeWidth: "1.6",
					opacity: ".5"
				})
			]
		});
	}
	return e === "camp" ? /* @__PURE__ */ y("g", {
		transform: `rotate(${n * .4})`,
		children: [
			/* @__PURE__ */ v(Re, {
				x: -20,
				y: -12,
				s: .62,
				tone: "#2b6f46"
			}),
			/* @__PURE__ */ v(Re, {
				x: 19,
				y: -14,
				s: .55,
				tone: "#245f3e"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-24 17L-8 -15 8 17z",
				fill: "#f4e2bc",
				stroke: "#4e3220",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-8 -15L2 17",
				stroke: "#4e3220",
				strokeWidth: "1.5",
				opacity: ".7"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-19 16h28",
				stroke: "#33210f",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ y("g", {
				transform: `translate(${16 + X(t, 2, 2)} ${8 - X(t, 5, 1.5)})`,
				children: [
					/* @__PURE__ */ v("circle", {
						r: "8",
						fill: "#ffb347",
						opacity: ".42"
					}),
					/* @__PURE__ */ v("path", {
						d: "M0 -7c3.4 3.4 4.6 5.6 4.6 7.8a4.6 4.6 0 0 1-9.2 0c0-2.2 1.2-4.4 4.6-7.8z",
						fill: "#ffd580",
						stroke: "#8a4a1a",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M0 -2v4",
						stroke: "#c05a18",
						strokeWidth: "1.4",
						strokeLinecap: "round",
						opacity: ".7"
					})
				]
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 -3c3-4 1-7-1-9",
				stroke: "#e7dcc4",
				strokeWidth: "1.6",
				fill: "none",
				opacity: ".3",
				strokeLinecap: "round"
			})
		]
	}) : e === "blockade" ? /* @__PURE__ */ y("g", {
		transform: "translate(0 -2)",
		children: [
			/* @__PURE__ */ v("rect", {
				x: "-31",
				y: "-16",
				width: "62",
				height: "9.5",
				rx: "3.4",
				fill: "#8f6539",
				stroke: "#37240f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("rect", {
				x: "-31",
				y: "6",
				width: "62",
				height: "9.5",
				rx: "3.4",
				fill: "#8f6539",
				stroke: "#37240f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-25 -11.6h10M-7 -11.6h10M11 -11.6h10M-25 10.4h10M-7 10.4h10M11 10.4h10",
				stroke: "#5c4022",
				strokeWidth: "1.3",
				opacity: ".75"
			}),
			/* @__PURE__ */ v("rect", {
				x: "-31",
				y: "-1",
				width: "62",
				height: "4",
				fill: "#5f4122",
				opacity: ".45"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "-23",
				cy: "-11.2",
				r: "1.6",
				fill: "#39260f"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "23",
				cy: "-11.2",
				r: "1.6",
				fill: "#39260f"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "-23",
				cy: "10.8",
				r: "1.6",
				fill: "#39260f"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "23",
				cy: "10.8",
				r: "1.6",
				fill: "#39260f"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-35 -25L-27 27M35 -25L27 27",
				stroke: "#2f1f0d",
				strokeWidth: "3.4",
				opacity: ".5"
			})
		]
	}) : e === "start" ? /* @__PURE__ */ y("g", { children: [
		/* @__PURE__ */ v("circle", {
			cx: "0",
			cy: "5",
			r: "23",
			fill: "#d3e3b3",
			opacity: ".2"
		}),
		/* @__PURE__ */ v("circle", {
			cx: "0",
			cy: "5",
			r: "23",
			fill: "none",
			stroke: "#e8f0cf",
			strokeOpacity: ".22",
			strokeWidth: "1.4",
			strokeDasharray: "4 5"
		}),
		/* @__PURE__ */ v(Re, {
			x: -18,
			y: 12,
			s: .6,
			tone: "#2b6f46"
		}),
		/* @__PURE__ */ v(Re, {
			x: 18,
			y: 14,
			s: .52,
			tone: "#245f3e"
		}),
		/* @__PURE__ */ y("g", {
			transform: "translate(5 -3)",
			children: [
				/* @__PURE__ */ v("rect", {
					x: "-1.9",
					y: "-18",
					width: "3.8",
					height: "32",
					rx: "1.8",
					fill: "#5a4022"
				}),
				/* @__PURE__ */ v("path", {
					d: "M1.9 -18l15 5.6-15 5.6z",
					fill: "#eec84a",
					stroke: "#3d2a17",
					strokeWidth: "1.3"
				}),
				/* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: "14",
					rx: "6",
					ry: "2.2",
					fill: "#3f2c17",
					opacity: ".5"
				})
			]
		})
	] }) : e === "temple" ? /* @__PURE__ */ y("g", { children: [
		/* @__PURE__ */ v("circle", {
			r: "40",
			fill: "url(#el-g-glow)"
		}),
		Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ v("rect", {
			x: "-1.1",
			y: "-40",
			width: "2.2",
			height: "9",
			rx: "1.1",
			fill: "#ffe9a8",
			opacity: ".34",
			transform: `rotate(${t * 22.5})`
		}, t)),
		/* @__PURE__ */ v("path", {
			d: "M-25 19L-18.5 4 -9.5 4 -5 -8 5 -8 9.5 4 18.5 4 25 19z",
			fill: "#f9e6ad",
			stroke: "#7d5a10",
			strokeWidth: "1.8"
		}),
		/* @__PURE__ */ v("path", {
			d: "M-5 -8V19M5 -8V19",
			stroke: "#a67f22",
			strokeWidth: "1.2",
			opacity: ".6"
		}),
		/* @__PURE__ */ v("path", {
			d: "M-3.4 19v-5.2a3.4 3.4 0 0 1 6.8 0V19z",
			fill: "#6b4a11"
		}),
		/* @__PURE__ */ v("rect", {
			x: "-26",
			y: "19",
			width: "52",
			height: "6",
			rx: "2.2",
			fill: "#e9c877",
			stroke: "#7d5a10",
			strokeWidth: "1.4"
		})
	] }) : null;
}
function Ve({ seed: e }) {
	let t = X(e, 3, 5);
	return /* @__PURE__ */ y("g", {
		transform: `rotate(${t})`,
		children: [
			/* @__PURE__ */ v("ellipse", {
				cx: "0",
				cy: "6",
				rx: "31",
				ry: "25",
				fill: "#123020",
				opacity: ".22"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-33 9C-18 2 -8 4 0 0s14-5 33 1",
				fill: "none",
				stroke: "#b79a63",
				strokeWidth: "9",
				strokeLinecap: "round",
				opacity: ".5"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-33 9C-18 2 -8 4 0 0s14-5 33 1",
				fill: "none",
				stroke: "#7a5f34",
				strokeWidth: "1.3",
				strokeDasharray: "3 4",
				opacity: ".5"
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(-31 1) rotate(-20)",
				children: /* @__PURE__ */ v("rect", {
					x: "-4",
					y: "-7",
					width: "8",
					height: "14",
					rx: "1.6",
					fill: "#8f6539",
					stroke: "#37240f",
					strokeWidth: "1.4"
				})
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(31 3) rotate(24)",
				children: /* @__PURE__ */ v("rect", {
					x: "-4",
					y: "-7",
					width: "8",
					height: "14",
					rx: "1.6",
					fill: "#8f6539",
					stroke: "#37240f",
					strokeWidth: "1.4"
				})
			})
		]
	});
}
function He({ sym: e, n: t }) {
	let n = t > 2 ? 28 : 25;
	return /* @__PURE__ */ y("g", {
		transform: "translate(0 17.5)",
		children: [
			/* @__PURE__ */ v("rect", {
				x: -n / 2,
				y: "-8",
				width: n,
				height: "16",
				rx: "8",
				fill: "#0d0a05",
				fillOpacity: ".66",
				stroke: "#f0dcaa",
				strokeOpacity: ".4",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(-5.5 0)",
				children: /* @__PURE__ */ v(Ye, {
					sym: e,
					size: 10,
					color: "#fff6e0"
				})
			}),
			/* @__PURE__ */ v("text", {
				x: "5",
				y: "3.8",
				textAnchor: "middle",
				fontSize: "10.5",
				fontWeight: "800",
				fill: "#fff6e0",
				children: t
			})
		]
	});
}
function Ue({ kind: e, n: t }) {
	let n = t > 2 ? 30 : 27;
	return /* @__PURE__ */ y("g", {
		transform: "translate(0 17.5)",
		children: [
			/* @__PURE__ */ v("rect", {
				x: -n / 2,
				y: "-8",
				width: n,
				height: "16",
				rx: "8",
				fill: "#0d0a05",
				fillOpacity: ".66",
				stroke: "#f0dcaa",
				strokeOpacity: ".4",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(-5 0)",
				children: /* @__PURE__ */ v(Xe, {
					size: 10,
					tone: e === "camp" ? "dark" : "light"
				})
			}),
			/* @__PURE__ */ v("text", {
				x: "5",
				y: "3.8",
				textAnchor: "middle",
				fontSize: "10.5",
				fontWeight: "800",
				fill: "#fff6e0",
				children: t
			}),
			e === "camp" && /* @__PURE__ */ v("path", {
				d: "M-13 -8L13 8M13 -8L-13 8",
				stroke: "#d9443a",
				strokeWidth: "2.4",
				strokeLinecap: "round",
				opacity: ".9"
			})
		]
	});
}
function We({ hex: e }) {
	return /* @__PURE__ */ y("g", {
		transform: "translate(0 17)",
		children: [
			/* @__PURE__ */ v("rect", {
				x: "-23",
				y: "-8.5",
				width: "46",
				height: "17",
				rx: "8.5",
				fill: "#0d0a05",
				fillOpacity: ".68",
				stroke: "#f0dcaa",
				strokeOpacity: ".4",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ v("g", {
				transform: "translate(-10 0)",
				children: /* @__PURE__ */ v(Ye, {
					sym: e.sym ?? "machete",
					size: 11,
					color: "#fff6e0"
				})
			}),
			/* @__PURE__ */ v("text", {
				x: "6",
				y: "3.8",
				textAnchor: "middle",
				fontSize: "10.5",
				fontWeight: "800",
				fill: "#fff6e0",
				children: e.s
			}),
			(e.num ?? 0) > 0 && /* @__PURE__ */ y("g", {
				transform: "translate(17 -15)",
				children: [/* @__PURE__ */ v("path", {
					d: "M-7.5 -6.4h15v9l-7.5 5.6-7.5-5.6z",
					fill: "#f9ecd0",
					stroke: "#2d1f0c",
					strokeWidth: "1.2"
				}), /* @__PURE__ */ v("text", {
					y: "2.8",
					textAnchor: "middle",
					fontSize: "9",
					fontWeight: "800",
					fill: "#2d1f0c",
					children: e.num
				})]
			})
		]
	});
}
function Ge({ hex: e, cleared: t = !1 }) {
	let { x: n, y: r } = Me(e.id), i = Pe(e.id), a = e.t === "blockade" && t, o = e.t === "jungle" || e.t === "river" || e.t === "village" ? e.s : 0, s = e.t === "rubble" || e.t === "camp", c = e.t === "jungle" ? "machete" : e.t === "river" ? "paddle" : "coin";
	return /* @__PURE__ */ y("g", {
		transform: `translate(${n} ${r})`,
		className: `el-hex is-${e.t}${a ? " is-cleared" : ""}`,
		children: [
			/* @__PURE__ */ v("polygon", {
				points: Y,
				transform: "translate(0 5)",
				fill: "#020604",
				opacity: ".55"
			}),
			/* @__PURE__ */ v("polygon", {
				points: Y,
				fill: a ? "url(#el-g-cleared)" : Ne[e.t],
				stroke: "#0c0906",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ y("g", {
				clipPath: "url(#el-hex-clip)",
				children: [
					a ? /* @__PURE__ */ v(Ve, { seed: i }) : /* @__PURE__ */ v(Be, {
						t: e.t,
						seed: i
					}),
					/* @__PURE__ */ v("polygon", {
						points: Y,
						fill: "url(#el-hex-vig)"
					}),
					/* @__PURE__ */ v("polygon", {
						points: Y,
						fill: "url(#el-hex-sheen)"
					})
				]
			}),
			/* @__PURE__ */ v("polygon", {
				points: Y,
				fill: "none",
				stroke: "#f0e2bb",
				strokeOpacity: ".17",
				strokeWidth: "1.2",
				transform: "scale(.955)"
			}),
			o > 0 && /* @__PURE__ */ v(He, {
				sym: c,
				n: o
			}),
			s && /* @__PURE__ */ v(Ue, {
				kind: e.t === "camp" ? "camp" : "rubble",
				n: e.s
			}),
			e.t === "blockade" && !a && /* @__PURE__ */ v(We, { hex: e })
		]
	});
}
function Ke({ size: e = 16, color: t = "#f7f0dc" }) {
	return /* @__PURE__ */ y("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("path", {
			d: "M3.4 18.6c4.6-.2 8.2-1.9 11-5.4l4.3-5.4-1.1-2-2.1 1.2-4.4 5c-1.6 1.8-4 2.8-6.4 2.9z",
			fill: t
		}), /* @__PURE__ */ v("path", {
			d: "M3.4 18.6L2 22l3.3-1.1z",
			fill: t,
			opacity: ".75"
		})]
	});
}
function qe({ size: e = 16, color: t = "#f7f0dc" }) {
	return /* @__PURE__ */ y("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			x: "11",
			y: "2.4",
			width: "2.1",
			height: "13",
			rx: "1",
			fill: t,
			opacity: ".9"
		}), /* @__PURE__ */ v("path", {
			d: "M12 13.6c-3 0-5.1 2-5.1 4.1 0 2.2 2.1 3.2 5.1 3.2s5.1-1 5.1-3.2c0-2.1-2.1-4.1-5.1-4.1z",
			fill: t
		})]
	});
}
function Je({ size: e = 16, color: t = "#f7dc8a" }) {
	return /* @__PURE__ */ y("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("circle", {
			cx: "12",
			cy: "12",
			r: "8.4",
			fill: "none",
			stroke: t,
			strokeWidth: "2.2"
		}), /* @__PURE__ */ v("circle", {
			cx: "12",
			cy: "12",
			r: "3.1",
			fill: t
		})]
	});
}
function Ye({ sym: e, size: t = 16, color: n }) {
	return v(e === "machete" ? Ke : e === "paddle" ? qe : Je, {
		size: t,
		color: n
	});
}
function Xe({ size: e = 14, tone: t = "light" }) {
	let n = t === "light" ? "#f2ead7" : "#3a2a1c", r = t === "light" ? "#7a6a52" : "#f2ead7";
	return /* @__PURE__ */ y("svg", {
		width: e * .78,
		height: e,
		viewBox: "0 0 20 26",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			x: "1.4",
			y: "1.4",
			width: "17.2",
			height: "23.2",
			rx: "2.6",
			fill: n,
			stroke: r,
			strokeWidth: "1.4"
		}), /* @__PURE__ */ v("path", {
			d: "M10 6v9m0 0l-3-3m3 3l3-3",
			stroke: r,
			strokeWidth: "1.6",
			fill: "none",
			strokeLinecap: "round"
		})]
	});
}
function Ze({ focus: e, eligible: t, onTap: o, children: s, fullLabel: c, zoomInLabel: l, zoomOutLabel: u, fitLabel: ne }) {
	let f = i(null), p = i(/* @__PURE__ */ new Map()), m = i(0), h = i(0), g = i({
		cx: q / 2,
		cy: J / 2,
		scale: 1
	}), [_, re] = a({
		width: 0,
		height: 0
	}), [b, x] = a(null);
	n(() => {
		let e = f.current;
		if (!e) return;
		let t = new ResizeObserver(() => re({
			width: e.clientWidth,
			height: e.clientHeight
		}));
		return t.observe(e), re({
			width: e.clientWidth,
			height: e.clientHeight
		}), () => t.disconnect();
	}, []);
	let S = r(() => _.width && _.height ? Math.min(_.width / q, _.height / J) : 1, [_]), C = Math.max(S * 6, .9), w = r(() => Qe({
		cx: q / 2,
		cy: J / 2,
		scale: S
	}, _.width, _.height), [
		S,
		_.width,
		_.height
	]), T = _.width < 720 || _.height < 470, E = r(() => Qe({
		cx: e.x,
		cy: e.y,
		scale: Math.min(C, Math.max(T ? Math.min(S * 2.4, .62) : S, .3))
	}, _.width, _.height), [
		_.width,
		_.height,
		e.x,
		e.y,
		S,
		C,
		T
	]), D = b ? Qe({
		...b,
		scale: Math.min(Math.max(b.scale, S), C)
	}, _.width, _.height) : E;
	n(() => {
		g.current = D;
	}, [D]);
	let O = (e) => {
		let t = Qe(e, _.width, _.height);
		g.current = t, x(t);
	};
	n(() => {
		let e = f.current;
		if (!e) return;
		let t = (t) => {
			t.preventDefault();
			let n = t.deltaY < 0 ? 1.16 : 1 / 1.16, r = g.current, i = Math.min(Math.max(r.scale * n, S), C), a = e.getBoundingClientRect(), o = t.clientX - a.left - a.width / 2, s = t.clientY - a.top - a.height / 2;
			O({
				cx: r.cx + o / r.scale - o / i,
				cy: r.cy + s / r.scale - s / i,
				scale: i
			});
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [
		S,
		C,
		_.width,
		_.height
	]);
	let k = (e) => {
		let t = g.current;
		O({
			...t,
			scale: Math.min(Math.max(t.scale * e, S), C)
		});
	};
	return /* @__PURE__ */ y("div", {
		ref: f,
		className: "el-board",
		children: [
			/* @__PURE__ */ y("svg", {
				className: "el-board-svg",
				onPointerDown: (e) => {
					if (e.currentTarget.setPointerCapture(e.pointerId), p.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), p.current.size === 1 && (m.current = 0), p.current.size === 2) {
						let [e, t] = [...p.current.values()];
						h.current = Math.hypot(e.x - t.x, e.y - t.y);
					}
				},
				onPointerMove: (e) => {
					let t = p.current.get(e.pointerId);
					if (!t) return;
					let n = g.current;
					if (p.current.size === 1) {
						let r = e.clientX - t.x, i = e.clientY - t.y;
						m.current += Math.abs(r) + Math.abs(i), O({
							...n,
							cx: n.cx - r / n.scale,
							cy: n.cy - i / n.scale
						});
					} else if (p.current.size === 2) {
						p.current.set(e.pointerId, {
							x: e.clientX,
							y: e.clientY
						});
						let [t, r] = [...p.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
						if (h.current && i) {
							let e = Math.min(Math.max(n.scale * i / h.current, S), C), a = f.current.getBoundingClientRect(), o = (t.x + r.x) / 2 - a.left - a.width / 2, s = (t.y + r.y) / 2 - a.top - a.height / 2;
							O({
								cx: n.cx + o / n.scale - o / e,
								cy: n.cy + s / n.scale - s / e,
								scale: e
							});
						}
						h.current = i, m.current = 99;
						return;
					}
					p.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					});
				},
				onPointerUp: (e) => {
					let n = p.current.size === 1 && m.current < 10;
					if (p.current.delete(e.pointerId), h.current = 0, !n || !t.length) return;
					let r = f.current.getBoundingClientRect(), i = g.current, a = i.cx + (e.clientX - r.left - r.width / 2) / i.scale, s = i.cy + (e.clientY - r.top - r.height / 2) / i.scale, c, l = (34 * 1.15) ** 2;
					for (let e of t) {
						let t = (e.x - a) ** 2 + (e.y - s) ** 2;
						t < l && (c = e, l = t);
					}
					c && o(c.key);
				},
				onPointerCancel: (e) => {
					p.current.delete(e.pointerId), h.current = 0;
				},
				children: [/* @__PURE__ */ v(Ie, {}), /* @__PURE__ */ y("g", {
					transform: `translate(${_.width / 2 - D.cx * D.scale} ${_.height / 2 - D.cy * D.scale}) scale(${D.scale})`,
					children: [/* @__PURE__ */ v(Fe, {}), s]
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "el-map-controls",
				children: [
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "el-map-control",
						"aria-label": u,
						disabled: D.scale <= S + .001,
						onClick: () => k(1 / 1.45),
						children: /* @__PURE__ */ v(te, { size: 18 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "el-map-control",
						"aria-label": l,
						disabled: D.scale >= C - .001,
						onClick: () => k(1.45),
						children: /* @__PURE__ */ v(ee, { size: 18 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "el-map-control",
						"aria-label": c,
						onClick: () => O(w),
						children: /* @__PURE__ */ v(d, { size: 18 })
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "el-map-control el-map-fit",
						onClick: () => O(w),
						children: ne
					})
				]
			}),
			t.length > 0 && /* @__PURE__ */ v("svg", {
				className: "el-board-hints",
				"aria-hidden": !0,
				children: /* @__PURE__ */ v("g", {
					transform: `translate(${_.width / 2 - D.cx * D.scale} ${_.height / 2 - D.cy * D.scale}) scale(${D.scale})`,
					children: t.map((e) => /* @__PURE__ */ v("circle", {
						cx: e.x,
						cy: e.y,
						r: 29.24,
						fill: "none",
						stroke: "#ffe9a8",
						strokeWidth: "5",
						strokeDasharray: "10 7",
						opacity: ".9"
					}, e.key))
				})
			})
		]
	});
}
function Qe(e, t, n) {
	if (!t || !n) return e;
	let r = t / (2 * e.scale), i = n / (2 * e.scale);
	return {
		...e,
		cx: r >= q / 2 ? q / 2 : Math.min(Math.max(e.cx, r), q - r),
		cy: i >= J / 2 ? J / 2 : Math.min(Math.max(e.cy, i), J - i)
	};
}
function $e(e) {
	return e ? Me(e) : {
		x: q / 2,
		y: J / 2
	};
}
//#endregion
//#region src/game/card.tsx
var et = {
	traveler: ["#c8a24a", "#f6e6bb"],
	explorer: ["#3f7a46", "#cfe4bd"],
	sailor: ["#2f6f8f", "#c3e2ef"],
	scout: ["#3f7a46", "#bcd9a8"],
	captain: ["#2f6f8f", "#bfdbe9"],
	trailblazer: ["#3f7a46", "#bcd9a8"],
	pioneer: ["#3f7a46", "#bcd9a8"],
	"giant-machete": ["#3f7a46", "#bcd9a8"],
	photographer: ["#b8860b", "#f3dda2"],
	journalist: ["#b8860b", "#f3dda2"],
	millionaire: ["#b8860b", "#f3dda2"],
	"treasure-chest": ["#b8860b", "#f3dda2"],
	jack: ["#3f7a46", "#d9e6c4"],
	adventurer: ["#b8860b", "#f0dca6"],
	"prop-plane": ["#7a6a3a", "#e8e0c2"],
	cartographer: ["#7b4d8f", "#e6d3ee"],
	compass: ["#7b4d8f", "#e6d3ee"],
	scientist: ["#7b4d8f", "#e6d3ee"],
	transmitter: ["#7b4d8f", "#e6d3ee"],
	"travel-log": ["#7b4d8f", "#e6d3ee"],
	native: ["#7b4d8f", "#e6d3ee"]
};
function tt({ kind: e }) {
	let t = "#3a2438", n = t;
	return e === "cartographer" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 48 40",
		width: "46",
		height: "38",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			width: "60",
			height: "46",
			fill: n,
			opacity: ".07"
		}), /* @__PURE__ */ y("g", {
			transform: "translate(30 23) scale(1.22) translate(-30 -23)",
			children: [
				/* @__PURE__ */ v("path", {
					d: "M6 10l12-4 12 4 12-4v24l-12 4-12-4-12 4z",
					fill: "#f4e9d2",
					stroke: t,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "M18 6v28M30 10v28",
					stroke: t,
					strokeWidth: "1.6",
					opacity: ".6"
				}),
				/* @__PURE__ */ v("path", {
					d: "M10 26c5-6 8-2 12-7s7 0 11-5",
					fill: "none",
					stroke: "#8a4a2f",
					strokeWidth: "2.2",
					strokeDasharray: "3 3"
				})
			]
		})]
	}) : e === "compass" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 44 44",
		width: "42",
		height: "42",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			width: "60",
			height: "46",
			fill: n,
			opacity: ".07"
		}), /* @__PURE__ */ y("g", {
			transform: "translate(30 23) scale(1.22) translate(-30 -23)",
			children: [/* @__PURE__ */ v("circle", {
				cx: "22",
				cy: "22",
				r: "16",
				fill: "#f4e9d2",
				stroke: t,
				strokeWidth: "2"
			}), /* @__PURE__ */ v("path", {
				d: "M22 8l4 11 11 3-11 4-4 11-4-11-11-4 11-3z",
				fill: "#c9a227",
				stroke: t,
				strokeWidth: "1.4"
			})]
		})]
	}) : e === "scientist" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 44 44",
		width: "40",
		height: "40",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			width: "60",
			height: "46",
			fill: n,
			opacity: ".07"
		}), /* @__PURE__ */ y("g", {
			transform: "translate(30 23) scale(1.22) translate(-30 -23)",
			children: [
				/* @__PURE__ */ v("path", {
					d: "M18 6h8v10l9 18a4 4 0 0 1-3.6 6H12.6A4 4 0 0 1 9 34l9-18z",
					fill: "#e9dcf0",
					stroke: t,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "M13 30h18",
					stroke: "#6d3f85",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "19",
					cy: "35",
					r: "2",
					fill: "#6d3f85"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "26",
					cy: "33",
					r: "1.6",
					fill: "#6d3f85"
				})
			]
		})]
	}) : e === "transmitter" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 46 40",
		width: "44",
		height: "38",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			width: "60",
			height: "46",
			fill: n,
			opacity: ".07"
		}), /* @__PURE__ */ y("g", {
			transform: "translate(30 23) scale(1.22) translate(-30 -23)",
			children: [
				/* @__PURE__ */ v("rect", {
					x: "10",
					y: "16",
					width: "26",
					height: "18",
					rx: "3",
					fill: "#e6c9a8",
					stroke: t,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "M23 16V6",
					stroke: t,
					strokeWidth: "2.4"
				}),
				/* @__PURE__ */ v("path", {
					d: "M23 6c-6 0-9 3-9 6M23 6c6 0 9 3 9 6",
					stroke: t,
					strokeWidth: "2",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "M16 22h14M16 27h14",
					stroke: t,
					strokeWidth: "1.6",
					opacity: ".55"
				})
			]
		})]
	}) : e === "travel-log" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 46 40",
		width: "44",
		height: "38",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			width: "60",
			height: "46",
			fill: n,
			opacity: ".07"
		}), /* @__PURE__ */ y("g", {
			transform: "translate(30 23) scale(1.22) translate(-30 -23)",
			children: [
				/* @__PURE__ */ v("path", {
					d: "M8 10c6-3 11-3 15 0 4-3 9-3 15 0v22c-6-3-11-3-15 0-4-3-9-3-15 0z",
					fill: "#f4e9d2",
					stroke: t,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "M23 10v22",
					stroke: t,
					strokeWidth: "1.8",
					opacity: ".6"
				}),
				/* @__PURE__ */ v("path", {
					d: "M12 16h7M12 21h7M27 16h7M27 21h7",
					stroke: "#8a6a3a",
					strokeWidth: "1.6"
				})
			]
		})]
	}) : /* @__PURE__ */ y("svg", {
		viewBox: "0 0 44 44",
		width: "42",
		height: "42",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("path", {
				d: "M14 4l8 10-4 6-8-10z",
				fill: "#8a5a2f",
				stroke: t,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ v("path", {
				d: "M22 18c4 2 6 6 6 10 0 6-5 10-11 10S6 34 6 28c0-5 4-9 9-9 3 0 5 1 7 3z",
				fill: "#7b4d8f",
				opacity: ".28"
			}),
			/* @__PURE__ */ v("path", {
				d: "M25 28c3-1 5-4 5-7",
				stroke: "#7b4d8f",
				strokeWidth: "2.4",
				fill: "none",
				strokeLinecap: "round"
			})
		]
	});
}
function nt({ sym: e, deep: t }) {
	return e === "machete" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 60 46",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("path", {
				d: "M0 30c10-7 18-7 27 0 9-7 18-7 33 0v16H0z",
				fill: t,
				opacity: ".16"
			}),
			/* @__PURE__ */ y("g", {
				fill: t,
				opacity: ".5",
				children: [
					/* @__PURE__ */ v("ellipse", {
						cx: "10",
						cy: "26",
						rx: "8.5",
						ry: "7"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "20",
						cy: "20",
						rx: "7",
						ry: "6"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "47",
						cy: "24",
						rx: "8",
						ry: "6.5"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "39",
						cy: "28",
						rx: "6",
						ry: "5"
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				fill: t,
				opacity: ".34",
				children: [
					/* @__PURE__ */ v("ellipse", {
						cx: "10",
						cy: "23",
						rx: "5",
						ry: "4"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "20",
						cy: "17",
						rx: "4.2",
						ry: "3.6"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "47",
						cy: "21",
						rx: "4.6",
						ry: "4"
					})
				]
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 36h60",
				stroke: t,
				strokeOpacity: ".28",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ y("g", {
				transform: "translate(30 34) rotate(-38)",
				children: [
					/* @__PURE__ */ v("rect", {
						x: "-2",
						y: "-2",
						width: "9",
						height: "4.6",
						rx: "1.4",
						fill: "#7b4a22",
						stroke: t,
						strokeOpacity: ".55",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M6 -3.4h16l4 3.4-4 3.4H6z",
						fill: "#d8dde2",
						stroke: t,
						strokeOpacity: ".6",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M8 -1.6h14",
						stroke: t,
						strokeOpacity: ".35",
						strokeWidth: "1"
					})
				]
			})
		]
	}) : e === "paddle" ? /* @__PURE__ */ y("svg", {
		viewBox: "0 0 60 46",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("path", {
				d: "M0 26c9 7 15 7 24 0s15-7 24 0 12 6 12 6",
				fill: "none",
				stroke: t,
				strokeOpacity: ".45",
				strokeWidth: "2.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 36c9 7 15 7 24 0s15-7 24 0 12 6 12 6",
				fill: "none",
				stroke: t,
				strokeOpacity: ".28",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ v("path", {
				d: "M10 24c4 6 16 6 21 0z",
				fill: "#8a5a2f",
				stroke: t,
				strokeOpacity: ".5",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M14 24l3-9M27 24l-3-9",
				stroke: t,
				strokeOpacity: ".5",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ y("g", {
				transform: "translate(42 16) rotate(28)",
				children: [/* @__PURE__ */ v("rect", {
					x: "-1.6",
					y: "-9",
					width: "3.2",
					height: "15",
					rx: "1.4",
					fill: "#8a5a2f",
					stroke: t,
					strokeOpacity: ".45",
					strokeWidth: "0.9"
				}), /* @__PURE__ */ v("ellipse", {
					cx: "0",
					cy: "8",
					rx: "4.2",
					ry: "6.4",
					fill: "#c9a227",
					stroke: t,
					strokeOpacity: ".5",
					strokeWidth: "1"
				})]
			})
		]
	}) : /* @__PURE__ */ y("svg", {
		viewBox: "0 0 60 46",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("path", {
				d: "M0 34h60",
				stroke: t,
				strokeOpacity: ".24",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ v("path", {
				d: "M0 30c8 3 12-2 20 0s12 3 20 0 12-3 20 0v16H0z",
				fill: t,
				opacity: ".12"
			}),
			/* @__PURE__ */ y("g", {
				transform: "translate(30 30)",
				children: [
					/* @__PURE__ */ v("ellipse", {
						cx: "0",
						cy: "5",
						rx: "17",
						ry: "4.4",
						fill: t,
						opacity: ".2"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "-7",
						cy: "1",
						rx: "11",
						ry: "4.2",
						fill: "#e3bd63",
						stroke: t,
						strokeOpacity: ".55",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "6",
						cy: "-3",
						rx: "11",
						ry: "4.2",
						fill: "#f0d489",
						stroke: t,
						strokeOpacity: ".55",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "0",
						cy: "-8",
						rx: "11",
						ry: "4.2",
						fill: "#f8e6ae",
						stroke: t,
						strokeOpacity: ".6",
						strokeWidth: "1.1"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "0",
						cy: "-9",
						rx: "6",
						ry: "2.2",
						fill: "none",
						stroke: t,
						strokeOpacity: ".35",
						strokeWidth: "0.9"
					}),
					/* @__PURE__ */ v("path", {
						d: "M-7 5.6V1M6 13.4v-4.6",
						stroke: t,
						strokeOpacity: ".28",
						strokeWidth: "1"
					})
				]
			})
		]
	});
}
function rt({ id: e, name: t, selected: n = !1, disabled: r = !1, compact: i = !1, text: a, badges: o, onClick: s, ariaLabel: c, footer: l }) {
	let u = C[e], [d, ee] = et[e], te = ie(e), ne = te.length === 3 && u.joker ? [
		"machete",
		"paddle",
		"coin"
	].map((e) => ({
		sym: e,
		power: u.joker ?? 0
	})) : te.map((t) => ({
		sym: t,
		power: k(e, t)
	})), f = ne[0]?.sym ?? "coin", p = /* @__PURE__ */ y(re, { children: [
		/* @__PURE__ */ v("span", {
			className: "el-card-band",
			style: { background: `linear-gradient(115deg, ${d}, ${ee})` },
			"aria-hidden": !0
		}),
		/* @__PURE__ */ v("span", {
			className: "el-card-edge",
			"aria-hidden": !0
		}),
		/* @__PURE__ */ y("div", {
			className: "el-card-head",
			children: [o ?? /* @__PURE__ */ v("div", {
				className: `el-card-badges${ne.length > 2 ? " is-triple" : ""}`,
				children: ne.map((e, t) => /* @__PURE__ */ y("span", {
					className: "el-card-badge",
					children: [/* @__PURE__ */ v(Ye, {
						sym: e.sym,
						size: i ? 10 : 12,
						color: "#fdf6e3"
					}), /* @__PURE__ */ v("b", { children: e.power })]
				}, `${e.sym}${t}`))
			}), u.item && /* @__PURE__ */ v("span", {
				className: "el-card-item",
				"aria-hidden": !0,
				children: "✕"
			})]
		}),
		/* @__PURE__ */ v("div", {
			className: "el-card-name",
			children: t
		}),
		/* @__PURE__ */ v("div", {
			className: `el-card-art is-${f}`,
			children: u.action ? /* @__PURE__ */ v(tt, { kind: e }) : /* @__PURE__ */ v(nt, {
				sym: f,
				deep: d
			})
		}),
		a && /* @__PURE__ */ v("div", {
			className: "el-card-text",
			children: a
		}),
		/* @__PURE__ */ y("div", {
			className: "el-card-foot",
			children: [/* @__PURE__ */ y("span", {
				className: "el-card-cost",
				children: [/* @__PURE__ */ v(Je, {
					size: i ? 12 : 14,
					color: "#5a3c08"
				}), u.cost]
			}), l]
		})
	] }), m = `el-card${i ? " is-compact" : ""}${n ? " is-selected" : ""}${r ? " is-disabled" : ""}`;
	return s ? /* @__PURE__ */ v("button", {
		type: "button",
		className: m,
		"aria-pressed": n,
		"aria-label": c,
		disabled: r,
		onClick: s,
		children: p
	}) : /* @__PURE__ */ v("div", {
		className: m,
		"aria-label": c,
		children: p
	});
}
//#endregion
//#region src/game/view-player.tsx
function it(e, t) {
	return t !== N && e.players.some((e) => e.pawns.includes(t));
}
function at(e, t, n, r) {
	if (e.t === "blockade") return r.includes(e.id) ? 0 : e.sym === t && n >= e.s ? e.s : null;
	let i = ce(e.t);
	return i ? i === t && n >= e.s ? e.s : null : e.t === "start" || e.t === "temple" ? 0 : null;
}
function ot(e) {
	f();
	let t = e.public, n = e.private ?? {
		hand: [],
		prompt: null
	};
	return /* @__PURE__ */ v(st, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function st({ pub: e, priv: t, members: r, myRid: i, send: s }) {
	let d = c("eldorado"), ee = l((e) => e.locale), te = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? h(t, ee) : e;
	}, f = (e) => {
		let t = r.find((t) => t.rid === e)?.colorIndex ?? 0;
		return _[t % _.length].hex;
	}, b = (e) => d(`cardNames.${e}`), x = (e) => d(`cardText.${e}`), w = e.players.find((e) => e.rid === i), T = e.phase === "play" && e.turn === i, E = T && e.active && e.active.rid === i ? e.active : null, D = t.prompt, [O, ae] = a([]), [oe, se] = a(null), [N, P] = a(0), [ce, F] = a(null), [ue, I] = a(null), de = `${e.turn}|${e.turnNo}|${D?.kind ?? ""}`, [fe, pe] = a(de);
	fe !== de && (pe(de), ae([]), se(null), I(null)), n(() => {
		if (!ue) return;
		let e = window.setTimeout(() => I(null), 2400);
		return () => window.clearTimeout(e);
	}, [ue]);
	let me = w?.pawns.length ?? 1, L = Math.min(N, Math.max(0, me - 1)), R = t.hand.filter((e) => O.includes(e.uid)), z = R.length === 1 ? R[0] : void 0, B = z ? ie(z.id) : [], V = B.length > 0 ? oe && B.includes(oe) ? oe : B[0] : null, H = R.reduce((e, t) => e + (k(t.id, "coin") || .5), 0), U = (() => {
		if (!T || !w) return [];
		let t = [];
		if (D?.kind === "native") return w.pawns.forEach((n, r) => {
			for (let i of M(n)) it(e, i.id) || t.push({
				to: i.id,
				kind: "native",
				pawn: r
			});
		}), t;
		if (D) return [];
		if (E) {
			let n = w.pawns[E.pawn];
			if (n) for (let r of M(n)) it(e, r.id) || r.t !== "rubble" && r.t !== "camp" && at(r, E.sym, E.left, e.cleared) !== null && t.push({
				to: r.id,
				kind: "step",
				pawn: E.pawn
			});
			return t;
		}
		let n = w.pawns[L];
		if (!n) return t;
		for (let r of M(n)) it(e, r.id) || (r.t === "rubble" || r.t === "camp") && r.s === R.length && t.push({
			to: r.id,
			kind: "cross",
			pawn: L
		});
		if (z && V) for (let r of M(n)) it(e, r.id) || r.t === "rubble" || r.t === "camp" || at(r, V, k(z.id, V), e.cleared) !== null && t.push({
			to: r.id,
			kind: "move",
			pawn: L
		});
		return t;
	})(), W = (e) => {
		s(e), ae([]), se(null), I(null);
	}, he = (e) => {
		if (D?.kind === "remove1" || D?.kind === "remove2") {
			ae((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length >= D.max ? [...t.slice(1), e] : [...t, e]);
			return;
		}
		T && (ae((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), se(null));
	}, ge = (e) => {
		if (!T) return;
		let t = U.find((t) => t.to === e);
		if (!t) {
			let t = j.get(e);
			t && (t.t === "rubble" || t.t === "camp") && O.length > 0 && t.s !== O.length && I(d("needCards", { n: t.s }));
			return;
		}
		t.kind === "step" ? W({
			type: "step",
			to: e
		}) : t.kind === "native" ? W({
			type: "chooseHex",
			to: e,
			pawn: t.pawn
		}) : t.kind === "cross" ? W({
			type: "cross",
			pawn: t.pawn,
			uids: O,
			to: e
		}) : z && V && W({
			type: "move",
			pawn: t.pawn,
			uid: z.uid,
			sym: V,
			to: e
		});
	}, _e = (t) => {
		let n = t;
		if (D?.kind === "transmitter") {
			s({
				type: "chooseCard",
				card: t
			}), F(null);
			return;
		}
		if (T) {
			if (e.bought) {
				I(d("bought"));
				return;
			}
			if (!e.market.some((e) => e?.card === t) && !e.market.some((e) => e === null)) {
				I(d("errNoStock"));
				return;
			}
			if (H < C[n].cost) {
				I(d("errNotEnoughCoins"));
				return;
			}
			W({
				type: "buy",
				card: t,
				uids: O
			}), F(null);
		}
	}, G = ue ? /* @__PURE__ */ v("div", {
		className: "el-toast",
		children: ue
	}) : void 0, ve = e.phase === "done" ? "done" : T ? "accent" : "info", ye = D ? D.kind === "remove1" ? d("promptRemove1") : D.kind === "remove2" ? d("promptRemove2") : D.kind === "transmitter" ? d("promptTransmitter") : d("promptNative") : null, be = E ? d("leftPower", { n: E.left }) : ye ?? (T ? O.length ? `${d("selectedCards", { n: O.length })} · ${d("totalValue", { n: H })}` : d("roundHint") : d("waiting", { name: te(e.turn) })), xe = e.phase === "done" ? d("finalRound") : T ? ye ?? d("you") : d("waiting", { name: te(e.turn) }), Se = (() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e.players) n.pawns.forEach((e, r) => {
			let i = t.get(e) ?? [];
			i.push({
				rid: n.rid,
				index: r
			}), t.set(e, i);
		});
		return t;
	})(), Ce = w?.pawns[E?.pawn ?? L] ?? w?.pawns[0];
	return /* @__PURE__ */ y("div", {
		className: "el-view",
		children: [
			/* @__PURE__ */ v(p, {
				adaptive: !0,
				className: "el-screen",
				scroll: !1,
				banner: /* @__PURE__ */ y("div", {
					className: "el-banner",
					children: [/* @__PURE__ */ v(g, {
						tone: ve,
						text: xe,
						chip: `${d("turnNo", { n: e.turnNo })}${e.finalRound ? ` · ${d("finalRound")}` : ""}`,
						accent: le.accent
					}), /* @__PURE__ */ v(m, {
						variant: "plate",
						members: r,
						myRid: i,
						action: (t) => e.phase === "play" && e.turn === t ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ y("span", {
								className: "el-seat-status",
								children: [
									/* @__PURE__ */ v("span", {
										className: "el-seat-chip",
										children: d("stripHand", { n: n.hand })
									}),
									/* @__PURE__ */ v("span", {
										className: "el-seat-chip",
										children: d("stripDeck", { n: n.deck })
									}),
									/* @__PURE__ */ v("span", {
										className: "el-seat-chip",
										children: d("stripBlockade", { n: n.blockades.length })
									}),
									n.done && /* @__PURE__ */ v("span", {
										className: "el-seat-done",
										children: d("finished")
									})
								]
							}) : null;
						}
					})]
				}),
				actionsHeight: "el-actions-slot",
				actions: /* @__PURE__ */ y("div", {
					className: "el-actions",
					children: [/* @__PURE__ */ y("div", {
						className: "el-actions-main",
						children: [/* @__PURE__ */ y("div", {
							className: "el-status-row",
							children: [
								/* @__PURE__ */ v("span", {
									className: `el-status-text${E ? " is-active" : ""}`,
									children: be
								}),
								/* @__PURE__ */ v("span", {
									className: "el-deck-info",
									children: d("stripDeck", { n: w?.deck ?? 0 })
								}),
								/* @__PURE__ */ y("button", {
									type: "button",
									className: "el-text-btn",
									onClick: () => F("log"),
									"aria-label": d("history"),
									children: [/* @__PURE__ */ v(u, { size: 17 }), d("history")]
								})
							]
						}), /* @__PURE__ */ y("div", {
							className: "el-hand-scroll",
							"aria-label": d("hand"),
							children: [t.hand.map((e) => /* @__PURE__ */ v(rt, {
								id: e.id,
								name: b(e.id),
								text: C[e.id].action ? x(e.id) : void 0,
								compact: !0,
								selected: O.includes(e.uid),
								disabled: !T && !D,
								onClick: () => he(e.uid),
								ariaLabel: `${b(e.id)}，${x(e.id)}`
							}, e.uid)), t.hand.length === 0 && /* @__PURE__ */ v("span", {
								className: "el-empty",
								children: d("empty")
							})]
						})]
					}), /* @__PURE__ */ v("div", {
						className: "el-actions-side",
						children: /* @__PURE__ */ y("div", {
							className: "el-buttons",
							children: [
								me > 1 && !E && !D && /* @__PURE__ */ v("div", {
									className: "el-pawn-toggle",
									role: "group",
									"aria-label": d("choosePawn"),
									children: w?.pawns.map((e, t) => /* @__PURE__ */ y("button", {
										type: "button",
										className: L === t ? "is-on" : "",
										onClick: () => P(t),
										"aria-pressed": L === t,
										"aria-label": d(t === 0 ? "pawnOne" : "pawnTwo"),
										children: [/* @__PURE__ */ v("span", {
											className: "el-pawn-dot",
											style: { background: f(i) }
										}), d(t === 0 ? "pawnOne" : "pawnTwo")]
									}, `${e}${t}`))
								}),
								!E && !D && B.length > 1 && /* @__PURE__ */ v("div", {
									className: "el-sym-toggle",
									role: "group",
									"aria-label": d("chooseSymbol"),
									children: B.map((e) => /* @__PURE__ */ y("button", {
										type: "button",
										className: V === e ? "is-on" : "",
										onClick: () => se(e),
										"aria-pressed": V === e,
										"aria-label": `${d(e)} ${k(z.id, e)}`,
										children: [/* @__PURE__ */ v(Ye, {
											sym: e,
											size: 14,
											color: "#2b2015"
										}), k(z.id, e)]
									}, e))
								}),
								E && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn",
									onClick: () => W({ type: "stop" }),
									children: d("stop")
								}),
								!E && !D && z && C[z.id].action && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn el-primary",
									onClick: () => W({
										type: "act",
										uid: z.uid
									}),
									children: d("use")
								}),
								T && !D && O.length > 0 && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn",
									onClick: () => W({
										type: "discardHand",
										uids: O
									}),
									children: d("discardSelected")
								}),
								T && !D && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn",
									onClick: () => F("market"),
									children: d("market")
								}),
								D && (D.kind === "remove1" || D.kind === "remove2") && /* @__PURE__ */ y(re, { children: [/* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn el-primary",
									onClick: () => W({
										type: "remove",
										uids: O
									}),
									children: d("confirm")
								}), /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn",
									onClick: () => W({
										type: "remove",
										uids: []
									}),
									children: d("skipRemove")
								})] }),
								T && !D && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn el-primary",
									onClick: () => W({ type: "endTurn" }),
									children: d("endTurn")
								}),
								!T && !D && /* @__PURE__ */ v("button", {
									type: "button",
									className: "el-btn",
									onClick: () => F("legend"),
									children: d("legend")
								})
							]
						})
					})]
				}),
				overlay: G,
				children: /* @__PURE__ */ y("div", {
					className: "el-table",
					children: [/* @__PURE__ */ v(ne, {
						kind: "sheen",
						base: "#172a20"
					}), /* @__PURE__ */ y(Ze, {
						focus: $e(Ce),
						eligible: U.map((e) => ({
							key: e.to,
							...Me(e.to)
						})),
						onTap: ge,
						fullLabel: d("recenter"),
						zoomInLabel: d("zoomIn"),
						zoomOutLabel: d("zoomOut"),
						fitLabel: d("fitMap"),
						children: [
							A.map((t) => /* @__PURE__ */ v(Ge, {
								hex: t,
								cleared: e.cleared.includes(t.id)
							}, t.id)),
							[...Se.entries()].flatMap(([e, t]) => {
								let n = Me(e);
								return t.map((r, a) => {
									let o = t.length === 1 ? 0 : (a - (t.length - 1) / 2) * 13, s = r.rid === i, c = E !== null && s && r.index === E.pawn;
									return /* @__PURE__ */ y("g", {
										transform: `translate(${n.x + o} ${n.y + 8})`,
										children: [
											c && /* @__PURE__ */ v("circle", {
												r: "14.5",
												fill: "none",
												stroke: "#ffe9a8",
												strokeWidth: "3",
												className: "el-pawn-ring"
											}),
											/* @__PURE__ */ v("circle", {
												r: "10.5",
												fill: f(r.rid),
												stroke: s ? "#fff8e6" : "#241a10",
												strokeWidth: s ? 3 : 2
											}),
											/* @__PURE__ */ v("circle", {
												r: "4.6",
												fill: "#fff8e6",
												opacity: ".85"
											})
										]
									}, `${e}-${r.rid}-${r.index}`);
								});
							}),
							e.cleared.map((e) => {
								let t = Me(e);
								return /* @__PURE__ */ y("g", {
									transform: `translate(${t.x} ${t.y + 20})`,
									children: [/* @__PURE__ */ v("circle", {
										r: "7",
										fill: "#2f6b45",
										stroke: "#ffe9a8",
										strokeWidth: "1.6"
									}), /* @__PURE__ */ v("path", {
										d: "M-3 0l2.2 2.4 4-4.6",
										stroke: "#ffe9a8",
										strokeWidth: "1.6",
										fill: "none"
									})]
								}, `clear-${e}`);
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ y(o, {
				open: ce === "market" || D?.kind === "transmitter",
				onClose: () => F(null),
				title: d("market"),
				label: d("market"),
				tall: !0,
				children: [
					/* @__PURE__ */ y("div", {
						className: "el-market-head",
						children: [
							/* @__PURE__ */ v("span", { children: d("selectedCards", { n: O.length }) }),
							/* @__PURE__ */ v("b", { children: d("totalValue", { n: H }) }),
							e.bought && /* @__PURE__ */ v("span", {
								className: "el-flag",
								children: d("bought")
							})
						]
					}),
					/* @__PURE__ */ v("h4", {
						className: "el-market-title",
						children: d("marketBoard")
					}),
					/* @__PURE__ */ v("div", {
						className: "el-market-row",
						children: e.market.map((t, n) => t ? /* @__PURE__ */ v(ct, {
							id: t.card,
							stock: t.stock,
							name: b(t.card),
							text: C[t.card].action ? x(t.card) : void 0,
							cost: C[t.card].cost,
							affordable: H >= C[t.card].cost,
							dim: e.bought && D?.kind !== "transmitter",
							onClick: () => _e(t.card)
						}, `${t.card}-${n}`) : /* @__PURE__ */ v("div", {
							className: "el-market-empty",
							children: d("vacant")
						}, `vacant-${n}`))
					}),
					/* @__PURE__ */ v("h4", {
						className: "el-market-title",
						children: d("marketAbove")
					}),
					/* @__PURE__ */ v("div", {
						className: "el-market-row",
						children: e.reserve.map((t) => /* @__PURE__ */ v(ct, {
							id: t.card,
							stock: t.stock,
							name: b(t.card),
							text: C[t.card].action ? x(t.card) : void 0,
							cost: C[t.card].cost,
							affordable: H >= C[t.card].cost,
							dim: e.bought && D?.kind !== "transmitter",
							onClick: () => _e(t.card)
						}, `r-${t.card}`))
					}),
					/* @__PURE__ */ v("p", {
						className: "el-market-note",
						children: ye ?? d("targetHints")
					})
				]
			}),
			/* @__PURE__ */ v(o, {
				open: ce === "log",
				onClose: () => F(null),
				title: d("history"),
				label: d("history"),
				children: /* @__PURE__ */ v("ol", {
					className: "el-log",
					children: e.events.slice().reverse().map((e) => /* @__PURE__ */ v("li", { children: d(`event.${e.kind}`, {
						name: te(e.rid),
						hex: e.hex ?? "",
						card: e.card ? b(e.card) : "",
						n: e.n ?? 0
					}) }, e.seq))
				})
			}),
			/* @__PURE__ */ v(o, {
				open: ce === "legend",
				onClose: () => F(null),
				title: d("legend"),
				label: d("legend"),
				children: /* @__PURE__ */ y("div", {
					className: "el-legend",
					children: [[
						"jungle",
						"river",
						"village",
						"rubble",
						"camp",
						"blockade",
						"temple",
						"start"
					].map((e) => /* @__PURE__ */ v("div", {
						className: `el-legend-row el-swatch-${e}`,
						children: /* @__PURE__ */ v("b", { children: d(e) })
					}, e)), S.map((e) => /* @__PURE__ */ y("div", {
						className: "el-legend-row el-legend-sym",
						children: [/* @__PURE__ */ v(Ye, {
							sym: e,
							size: 18
						}), /* @__PURE__ */ v("b", { children: d(e) })]
					}, e))]
				})
			})
		]
	});
}
function ct({ id: e, stock: t, name: n, text: r, cost: i, affordable: a, dim: o, onClick: s }) {
	return /* @__PURE__ */ v("div", {
		className: `el-market-card${a ? " is-affordable" : ""}${o ? " is-dim" : ""}`,
		children: /* @__PURE__ */ v(rt, {
			id: e,
			name: n,
			text: r,
			compact: !0,
			onClick: s,
			ariaLabel: `${n} ${i}`,
			footer: /* @__PURE__ */ v("span", {
				className: "el-stock",
				children: t
			})
		})
	});
}
//#endregion
//#region src/game/bot.ts
var lt = (() => {
	let e = /* @__PURE__ */ new Map([[N, 0]]), t = [[0, N]], n = (e) => e.t === "camp" ? 6 : e.t === "rubble" ? 3 : e.t === "blockade" ? 2 : 1;
	for (; t.length;) {
		t.sort((e, t) => e[0] - t[0]);
		let [r, i] = t.shift();
		if (!(r > (e.get(i) ?? Infinity))) for (let a of M(i)) {
			let i = r + n(a);
			i < (e.get(a.id) ?? Infinity) && (e.set(a.id, i), t.push([i, a.id]));
		}
	}
	return e;
})(), Z = (e) => lt.get(e) ?? 999, ut = (e, t) => Z(e) - Z(t);
function dt(e, t, n) {
	let r = t[n];
	if (!r) return null;
	let i = /* @__PURE__ */ new Set([r]);
	for (let t = 0; t < 8; t += 1) {
		let t = Z(r), n = null;
		for (let a of M(r)) i.has(a.id) || ht(e, a.id) || a.t === "camp" || Z(a.id) >= t || (!n || Z(a.id) < Z(n.id)) && (n = a);
		if (!n) return null;
		let a = ce(n.t) ?? (n.t === "blockade" && !e.cleared.includes(n.id) ? n.sym ?? null : null);
		if (a) return {
			sym: a,
			power: n.s
		};
		if (n.t === "rubble") return null;
		i.add(n.id), r = n.id;
	}
	return null;
}
var Q = {
	traveler: .2,
	explorer: .45,
	sailor: .35,
	scout: 1.1,
	captain: 1.9,
	trailblazer: 1.5,
	pioneer: 3.2,
	"giant-machete": 3.6,
	photographer: 1.3,
	journalist: 1.9,
	millionaire: 2.8,
	"treasure-chest": 2.6,
	jack: 1.3,
	adventurer: 2.1,
	"prop-plane": 3.2,
	cartographer: 2.5,
	compass: 2.2,
	scientist: 2.4,
	transmitter: 2.7,
	"travel-log": 2.1,
	native: 3
};
function ft(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function pt(e) {
	return k(e, "coin") || .5;
}
function mt(e, t) {
	let n = [...e].sort((e, t) => Q[e.id] - Q[t.id]), r = [], i = 0;
	for (let e of n) {
		if (i >= t) break;
		r.push(e.uid), i += pt(e.id);
	}
	return i >= t ? r : null;
}
function ht(e, t) {
	return t !== N && e.players.some((e) => e.pawns.includes(t));
}
function gt(e, t) {
	let n = C[e], r = (n.joker ?? n.power ?? Math.max(0, ...Object.values(n.powers ?? {}))) * .9 - n.cost * .55;
	n.action && (r += 2.1), n.item && (r += .5), e === "transmitter" && (r += 1.2), e === "cartographer" && (r += .6), (e === "scientist" || e === "travel-log") && (r += .4);
	for (let n of ie(e)) t.some((e) => ie(e.id).includes(n)) || (r += 1.1);
	return r;
}
function _t(e, t, n) {
	let r = t.prompt;
	if (!r) return null;
	let i = e.players.find((e) => e.rid === n);
	if (!i) return null;
	if (r.kind === "remove1" || r.kind === "remove2") {
		let e = r.kind === "remove1" ? 1 : 2;
		return {
			type: "remove",
			uids: [...t.hand].sort((e, t) => Q[e.id] - Q[t.id]).slice(0, e).map((e) => e.uid)
		};
	}
	if (r.kind === "transmitter") {
		let n = e.market.flatMap((e) => e ? [e.card] : []), r = e.reserve.map((e) => e.card), i = [...n, ...r];
		return i.length ? (i.sort((e, n) => gt(n, t.hand) - gt(e, t.hand)), {
			type: "chooseCard",
			card: i[0]
		}) : null;
	}
	let a = null, o = null;
	for (let t = 0; t < i.pawns.length; t += 1) for (let n of M(i.pawns[t])) {
		if (ht(e, n.id)) continue;
		let r = i.pawns[t];
		o ??= {
			to: n.id,
			pawn: t
		};
		let s = ut(r, n.id);
		if (s <= 0) continue;
		let c = s * 2 + Z(r) * .05;
		n.t === "blockade" && !e.cleared.includes(n.id) && (c += 2), (!a || c > a.score) && (a = {
			to: n.id,
			pawn: t,
			score: c
		});
	}
	let s = a ?? o;
	return s ? {
		type: "chooseHex",
		to: s.to,
		pawn: s.pawn
	} : null;
}
var vt = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.phase !== "play" || n.turn !== t.rid) return null;
	let i = n.players.find((e) => e.rid === t.rid);
	if (!i) return null;
	let a = t.difficulty === "weak", o = _t(n, r, t.rid);
	if (o) return { action: o };
	let s = [], c = r.hand;
	if (n.active) {
		let e = i.pawns[n.active.pawn];
		if (e) for (let t of M(e)) {
			if (ht(n, t.id) || t.t === "rubble" || t.t === "camp" || ve(t, n.active.sym, n.active.left, n.cleared) === null) continue;
			let r = ut(e, t.id);
			if (r <= 0) continue;
			let i = r * 2 + Z(e) * .05 + 2;
			t.t === "blockade" && !n.cleared.includes(t.id) && (i += 1.4), s.push({
				action: {
					type: "step",
					to: t.id
				},
				score: i
			});
		}
		if (!s.length) return { action: { type: "stop" } };
	} else {
		for (let e of c) {
			let t = e.id, r = C[t];
			if (r.action) {
				if (r.action === "native") {
					let r = -99;
					for (let e of i.pawns) for (let t of M(e)) {
						if (ht(n, t.id)) continue;
						let i = ut(e, t.id);
						if (i <= 0) continue;
						let a = i * 2 + Z(e) * .05;
						t.t === "blockade" && !n.cleared.includes(t.id) && (a += 2), a > r && (r = a);
					}
					s.push({
						action: {
							type: "act",
							uid: e.uid
						},
						score: r - Q[t] * .1
					});
				} else {
					let n = r.action === "transmitter" ? 8 : 6;
					s.push({
						action: {
							type: "act",
							uid: e.uid
						},
						score: n - Q[t] * .05
					});
				}
			}
			for (let r of ie(t)) {
				let a = k(t, r);
				i.pawns.forEach((i, o) => {
					for (let l of M(i)) {
						if (ht(n, l.id)) continue;
						if (l.t === "rubble" || l.t === "camp") {
							if (l.t === "camp") continue;
							if (c.length >= l.s) {
								let e = [...c].sort((e, t) => Q[e.id] - Q[t.id]).slice(0, l.s).map((e) => e.uid), t = ut(i, l.id);
								if (t <= 0) continue;
								let n = t * 2 - l.s * .35;
								s.push({
									action: {
										type: "cross",
										pawn: o,
										uids: e,
										to: l.id
									},
									score: n
								});
							}
							continue;
						}
						if (ve(l, r, a, n.cleared) === null) continue;
						let u = ut(i, l.id);
						if (u <= 0) continue;
						let d = u * 2 + a * .06 - Q[t] * .25 + Z(i) * .05;
						l.t === "blockade" && !n.cleared.includes(l.id) && (d += 1.5), s.push({
							action: {
								type: "move",
								pawn: o,
								uid: e.uid,
								sym: r,
								to: l.id
							},
							score: d
						});
					}
				});
			}
		}
		if (!n.bought) {
			let e = n.market.flatMap((e) => e ? [e.card] : []), t = n.market.some((e) => e === null) ? n.reserve.map((e) => e.card) : [], r = i.pawns.reduce((e, t, n) => Z(t) > Z(i.pawns[e] ?? N) ? n : e, 0), a = dt(n, i.pawns, r);
			for (let n of [...e, ...t]) {
				let e = n, t = mt(c, C[e].cost);
				if (!t) continue;
				let r = t.reduce((e, t) => {
					let n = c.find((e) => e.uid === t);
					return e + (n ? Q[n.id] * .16 : 0);
				}, 0), i = gt(e, c);
				a && ie(e).includes(a.sym) && (i += k(e, a.sym) >= a.power ? 1.8 : .5), s.push({
					action: {
						type: "buy",
						card: n,
						uids: t
					},
					score: i - r
				});
			}
		}
	}
	let l = s.filter((e) => e.score > .4);
	if (!l.length) {
		let e = s.filter((e) => e.action.type === "buy");
		return e.length ? { action: e.reduce((e, t) => t.score > e.score ? t : e).action } : c.length ? { action: {
			type: "discardHand",
			uids: c.map((e) => e.uid)
		} } : { action: { type: "endTurn" } };
	}
	let u = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
	return a && u < .35 ? { action: { type: "endTurn" } } : { action: a ? ft(l).action : l.reduce((e, t) => t.score > e.score ? t : e).action };
}, yt = (e) => `games.eldorado.cardNames.${e}`, $ = (e, t, n) => e(t, n), bt = (e, t, n) => {
	let r = (e) => {
		let r = t.private?.hand.find((t) => t.uid === e);
		return r ? n(yt(r.id), {}) : "";
	};
	switch (e.type) {
		case "move": return $(n, "games.eldorado.hintMove", {
			card: r(e.uid),
			hex: e.to
		});
		case "step": return $(n, "games.eldorado.hintMove", {
			card: "",
			hex: e.to
		});
		case "cross": return $(n, "games.eldorado.hintCross", {
			n: e.uids.length,
			terrain: ""
		});
		case "buy": return $(n, "games.eldorado.hintBuy", { card: n(yt(e.card), {}) });
		case "act": return $(n, "games.eldorado.hintAction", { card: r(e.uid) });
		case "stop": return $(n, "games.eldorado.hintStop");
		case "endTurn": return $(n, "games.eldorado.hintEnd");
		case "chooseHex": return $(n, "games.eldorado.hintMove", {
			card: n("games.eldorado.cardNames.native", {}),
			hex: e.to
		});
		case "chooseCard": return $(n, "games.eldorado.hintBuy", { card: n(yt(e.card), {}) });
		default: return $(n, "games.eldorado.hintEnd");
	}
}, xt = [
	"🥇",
	"🥈",
	"🥉"
];
function St(e) {
	let t = c("eldorado"), n = l((e) => e.locale), r = e.public, i = (e) => r.players.find((t) => t.rid === e), a = (t) => e.members.find((e) => e.rid === t), o = (e) => {
		let t = a(e);
		return t ? b(t.rid) === null ? t.name : s(n, t.avatar) : e;
	}, u = (e) => _[(a(e)?.colorIndex ?? 0) % _.length].hex, d = !!(e.onPlayAgain ?? e.onBackToLobby), ee = Math.max(1, e.result.ranking.length);
	return /* @__PURE__ */ v("div", {
		className: "el-result",
		children: /* @__PURE__ */ y("div", {
			className: "el-fin",
			children: [
				/* @__PURE__ */ y("header", {
					className: "el-fin-head",
					children: [
						/* @__PURE__ */ v("span", {
							className: "el-fin-kicker",
							children: "EL DORADO"
						}),
						/* @__PURE__ */ v("h1", {
							className: "font-display",
							children: t("resultTitle")
						}),
						/* @__PURE__ */ v("p", { children: t("resultSubtitle") })
					]
				}),
				/* @__PURE__ */ y("section", {
					className: "el-fin-trail",
					"aria-label": t("resultTrail"),
					children: [
						/* @__PURE__ */ v("span", {
							className: "el-fin-track",
							"aria-hidden": !0
						}),
						/* @__PURE__ */ v("span", {
							className: "el-fin-start",
							"aria-hidden": !0,
							children: t("start")
						}),
						/* @__PURE__ */ v("span", {
							className: "el-fin-temple",
							"aria-hidden": !0,
							children: /* @__PURE__ */ y("svg", {
								viewBox: "0 0 48 40",
								width: "44",
								height: "38",
								children: [
									/* @__PURE__ */ v("path", {
										d: "M4 36h40l-5-5H9z",
										fill: "#8a5c16",
										stroke: "#3a2407",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ v("path", {
										d: "M11 31h26l-4-6H15z",
										fill: "#c99a2d",
										stroke: "#3a2407",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ v("path", {
										d: "M17 25h14l-3-6h-8z",
										fill: "#e5bd55",
										stroke: "#3a2407",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ v("path", {
										d: "M19 19h10V9H19z",
										fill: "#f0d489",
										stroke: "#3a2407",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ v("circle", {
										cx: "24",
										cy: "5",
										r: "3.4",
										fill: "#ffe08a",
										stroke: "#8a5c16",
										strokeWidth: "1.2"
									}),
									/* @__PURE__ */ v("path", {
										d: "M14 38v-7M24 38v-9M34 38v-7",
										stroke: "#3a2407",
										strokeWidth: "1.4"
									})
								]
							})
						}),
						e.result.ranking.map((t, n) => {
							let r = ee === 1 ? 50 : 80 - 60 * n / (ee - 1), i = n % 2 == 0 ? 22 : 54, s = e.result.winner.includes(t), c = a(t);
							return /* @__PURE__ */ y("span", {
								className: `el-fin-token${s ? " is-winner" : ""}`,
								style: {
									left: `${r}%`,
									top: `${i}px`,
									"--seat": u(t)
								},
								children: [/* @__PURE__ */ y("span", {
									className: "el-fin-avatar",
									children: [c && /* @__PURE__ */ v("img", {
										src: x[c.avatar % x.length],
										alt: "",
										draggable: !1
									}), s && /* @__PURE__ */ v("b", {
										"aria-hidden": !0,
										children: "♛"
									})]
								}), /* @__PURE__ */ v("span", {
									className: "el-fin-token-name",
									children: o(t)
								})]
							}, t);
						})
					]
				}),
				/* @__PURE__ */ v("ol", {
					className: "el-fin-list",
					children: e.result.ranking.map((n, r) => {
						let s = i(n), c = a(n), l = e.result.winner.includes(n);
						return /* @__PURE__ */ y("li", {
							className: l ? "is-winner" : "",
							style: { "--seat": u(n) },
							children: [
								/* @__PURE__ */ v("span", {
									className: "el-fin-place",
									"aria-hidden": !0,
									children: xt[r] ?? r + 1
								}),
								/* @__PURE__ */ v("span", {
									className: "el-fin-avatar",
									children: c && /* @__PURE__ */ v("img", {
										src: x[c.avatar % x.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ y("span", {
									className: "el-fin-name",
									children: [o(n), n === e.myRid && /* @__PURE__ */ v("em", { children: t("resultYou") })]
								}),
								/* @__PURE__ */ y("span", {
									className: "el-fin-detail",
									children: [
										/* @__PURE__ */ v("span", {
											className: s?.done ? "is-arrived" : "",
											children: s?.done ? t("arrived") : t("resultNotArrived")
										}),
										s && /* @__PURE__ */ v("span", { children: t("stripBlockade", { n: s.blockades.length }) }),
										s && s.blockades.length > 0 && /* @__PURE__ */ v("span", { children: t("highestBlockade", { n: Math.max(...s.blockades) }) })
									]
								})
							]
						}, n);
					})
				}),
				e.hintCount !== void 0 && /* @__PURE__ */ v("p", {
					className: "el-fin-hint",
					children: t("resultHint", { n: e.hintCount })
				}),
				/* @__PURE__ */ v("div", {
					className: "el-fin-actions",
					children: d ? /* @__PURE__ */ y(re, { children: [e.onPlayAgain && /* @__PURE__ */ v("button", {
						type: "button",
						className: "el-fin-primary",
						onClick: e.onPlayAgain,
						children: t("resultPlayAgain")
					}), e.onBackToLobby && /* @__PURE__ */ v("button", {
						type: "button",
						className: "el-fin-secondary",
						onClick: e.onBackToLobby,
						children: t("resultBack")
					})] }) : /* @__PURE__ */ v("p", {
						className: "el-fin-wait",
						children: t("resultWaitHost")
					})
				})
			]
		})
	});
}
//#endregion
//#region src/index.tsx
var Ct = {
	definition: Oe,
	View: ot,
	bot: vt,
	describe: bt,
	OverView: St,
	locales: {
		zh: {
			name: "冲向黄金城",
			desc: "组建探险队穿越丛林与河流，抢先抵达黄金城",
			rules: (/* @__PURE__ */ "目标：,率先让全部棋子抵达黄金城的玩家赢得本局。第一位把棋子走到黄金城的玩家触发最后一轮：本轮中排在其后的每名玩家各再进行一个回合，随后本局结束。,开局准备：,每名玩家拿取一块远征板、一副起始牌组与对应颜色的棋子。起始牌组由 4 张旅行者、3 张探险家与 1 张水手组成。把它洗匀后作为抽牌堆，再抽取 4 张作为手牌。,市场板放置 6 堆牌：侦察兵、开路者、多面手、摄影师、宝箱与发报机。其余 12 堆牌放在市场板上方。,每回合的流程：,1. 出牌：从手牌打出任意数量的牌，用来移动棋子，和／或购买一张新牌。,2. 弃牌：把你这一回合打出的牌正面朝上放入弃牌堆。用于支付营地的牌改为移出游戏，不进入弃牌堆。你还可以选择保留或弃掉尚未使用的手牌，并针对每张牌分别决定；弃掉的手牌放入弃牌堆。,3. 补牌：从抽牌堆补牌，直到手牌达到 4 张。若你已经持有 4 张或更多手牌，则不补牌。抽牌堆用尽时，先把弃牌堆洗匀作为新的抽牌堆，再继续抽取。,移动：,每张地貌牌都带有砍刀、船桨或金币符号，以及对应的力量值。选择一张牌打在自己面前，然后让一个棋子走到相邻的六角格。,目标格的颜色必须与牌的符号一致：绿色丛林使用砍刀，蓝色水域使用船桨，黄色村庄使用金币。牌的力量必须不低于目标格标示的力量。,进入目标格后，如果这张牌还有剩余力量，你可以继续走向相邻的六角格。每次进入新格都必须单独满足符号与力量要求，并且要先扣除这张牌已经用掉的力量。,你不能把多张牌的力量合并起来走进同一个地貌格。你随时可以停止移动，剩余力量随即作废。,有些牌同时带有多种符号，例如探险家印有砍刀 1 与船桨 1。每次使用这种牌时，你只能选择其中一种符号，不能把两种符号的力量相加。,地形与特殊格：,丛林显示若干把砍刀，水域显示若干支船桨，村庄显示若干枚金币。格上符号的数量就是该格的力量。,废墟显示若干张卡牌符号。进入废墟不需要匹配符号，但你必须交出与符号数量相同的任意手牌。这些牌在回合结束时进入弃牌堆。,营地同样要求交出与符号数量相同的任意手牌，但这些牌直接从游戏中移除。营地是精简牌组的主要途径。,任何被其他棋子占据的六角格都无法进入。黄金城可以容纳多名玩家。,封锁：,封锁横在隘口上，格面标有符号、力量与编号。第一个想要通过的玩家必须打出一张符号匹配且力量足够的牌。通过后，该玩家收走这枚封锁标记，此后所有玩家都可以自由通过该格。,封锁的编号用于终局平手判定。玩家收走的封锁越多，平手时越占优势；数量相同时比较各自最高的封锁编号。,购买：,每回合最多购买一张牌，无论你是否已经移动。,带金币符号的牌按牌面力量计值，其他牌每张计半枚金币。你可以打出任意数量的手牌来凑钱，合计达到价格时便可以买下这张牌，且不找零。,买到的牌放入弃牌堆，不能直接加入手牌。,某种牌堆的 3 张牌全部售出后，市场板上会留下一个空位。此时你可以购买市场板上方的任意牌堆：把那堆牌放到空位上，并取走其中一张。市场板存在空位时，你仍然可以购买板上剩余的牌堆。,行动牌与物品牌：,紫色行动牌可以在自己回合的任意时点打出，执行效果后继续原来的行动流程。,制图师让你抽两张牌。罗盘让你抽三张牌，然后把它移出游戏。科学家让你抽一张牌，然后你可以从手牌移出一张。旅行日志让你抽两张牌，然后你可以从手牌移出至多两张，最后把它自己移出游戏。发报机让你从市场板或市场板上方免费取走一张牌，放入弃牌堆，然后把它自己移出游戏。土著让你把一个棋子走到相邻格，无视该格的符号与力量要求，也可以用来拆除封锁。,带划掉卡牌符号的牌是物品牌，每局只能使用一次。使用它本身的符号或功能后，把它移出游戏。,如果你只把它当作半枚金币，或者用它支付废墟的费用，则把它放入弃牌堆，而不是移出游戏。用它支付营地的费用时，仍然要按营地的规则把它移出游戏。,终局：,当一名玩家的全部棋子抵达黄金城时，本局进入最后一轮。本轮中排在其后的每名玩家各再进行一个回合，随后本局结束。如果最后一轮的最后一名玩家率先抵达，本局立即结束。,如果只有一名玩家抵达黄金城，该玩家获胜。如果有多名玩家抵达，收走封锁最多者获胜；封锁数量相同则比较各自最高的封锁编号；仍然相同则由最先抵达者获胜。,二人规则：,每名玩家控制两个棋子，分别从一号与三号、二号与四号起点出发。每当你打出一张移动牌时，先选择要把这张牌用于哪一个棋子。你不能把一张牌的力量拆分给两个棋子。,只有两个棋子都抵达黄金城，该玩家才算完成旅程。如果双方都在最后一轮用第二个棋子抵达，按通常的平手规则决定胜负。".split(",")).join("\n"),
			you: "你的回合",
			waiting: "等待 {{name}}",
			finalRound: "最后一轮",
			turnNo: "第 {{n}} 回合",
			hand: "手牌",
			deck: "牌库",
			discard: "弃牌堆",
			played: "已打出",
			market: "市场",
			marketBoard: "市场板",
			marketAbove: "市场板上方",
			vacant: "空位",
			stock: "余 {{n}}",
			buy: "购买",
			buyFor: "花 {{n}} 枚金币购买",
			bought: "本回合已购买一张牌",
			noStock: "已售罄",
			coins: "金币",
			cost: "价格",
			value: "价值",
			selectedCards: "已选 {{n}} 张",
			totalValue: "合计 {{n}} 枚金币",
			play: "出牌移动",
			stop: "停止移动",
			endTurn: "结束回合",
			use: "使用",
			discardSelected: "弃掉所选",
			cancel: "取消",
			confirm: "确认",
			close: "关闭",
			pass: "跳过",
			skipRemove: "不移出",
			empty: "空",
			chooseSymbol: "选择符号",
			chooseHex: "点选相邻的一格",
			chooseCard: "点选要取走的牌",
			choosePawn: "选择棋子",
			myPawns: "我的棋子",
			pawnOne: "第一枚",
			pawnTwo: "第二枚",
			targetHints: "可走的格已高亮",
			needCards: "这里需要 {{n}} 张手牌",
			leftPower: "剩余力量 {{n}}",
			roundHint: "移动和／或购买一张牌，然后结束回合",
			zoomIn: "放大",
			zoomOut: "缩小",
			recenter: "回到自己的棋子",
			fitMap: "全图",
			legend: "图例",
			log: "记录",
			history: "行动记录",
			rulesTitle: "玩法说明",
			jungle: "丛林",
			river: "水域",
			village: "村庄",
			rubble: "废墟",
			camp: "营地",
			blockade: "封锁",
			temple: "黄金城",
			start: "起点",
			machete: "砍刀",
			paddle: "船桨",
			coin: "金币",
			cards: "卡牌",
			item: "物品",
			action: "行动",
			blockades: "封锁",
			finished: "已抵达",
			arrived: "已抵达黄金城",
			resultTitle: "探险结束",
			resultSubtitle: "远征名次与沿途收获已经结算",
			resultTrail: "远征名次",
			resultYou: "你",
			resultNotArrived: "尚未抵达",
			resultPlayAgain: "再次出发",
			resultBack: "返回大厅",
			resultWaitHost: "等待房主决定是否再次出发",
			resultHint: "本局使用提示 {{n}} 次",
			players: "探险队",
			route: "路线",
			stripHand: "手牌 {{n}}",
			stripDeck: "牌库 {{n}}",
			stripBlockade: "封锁 {{n}}",
			highestBlockade: "最高封锁 {{n}}",
			promptRemove1: "科学家：可从手牌移出一张",
			promptRemove2: "旅行日志：可从手牌移出至多两张",
			promptTransmitter: "发报机：从市场板或上方取走一张牌",
			promptNative: "土著：无视要求走入相邻的一格",
			hintMove: "用 {{card}} 走向 {{hex}}",
			hintCross: "交出 {{n}} 张手牌进入{{terrain}}",
			hintBuy: "购买 {{card}}",
			hintEnd: "结束回合",
			hintStop: "停止移动",
			hintAction: "打出 {{card}}",
			errNotYourTurn: "还没有轮到你",
			errBadCard: "这张牌不在你的手牌中",
			errBadSymbol: "这张牌的符号或力量不足以走到那里",
			errBadMove: "不能走到那里",
			errOccupied: "该格已被其他棋子占据",
			errNeedCards: "需要交出与格上符号数量相同的手牌",
			errNotEnoughCoins: "金币不足",
			errNoStock: "该牌堆已经售罄",
			errOneBuy: "本回合已经购买过一张牌",
			errNoActive: "当前没有正在移动的牌",
			errBadPrompt: "请先处理当前的选择",
			errResolveFirst: "请先完成当前的选择",
			errGameOver: "本局已经结束",
			errBadAction: "无法执行这个动作",
			event: {
				turn: "{{name}} 开始回合",
				move: "{{name}} 移动到 {{hex}}",
				buy: "{{name}} 购买了{{card}}",
				arrive: "{{name}} 抵达黄金城",
				break: "{{name}} 通过了 {{n}} 号封锁",
				action: "{{name}} 打出{{card}}",
				rubble: "{{name}} 交出 {{n}} 张牌进入废墟",
				camp: "{{name}} 移除 {{n}} 张牌进入营地",
				draw: "{{name}} 抽了 {{n}} 张牌",
				removeCard: "{{name}} 移出了{{card}}",
				transmit: "{{name}} 用发报机取走了{{card}}",
				native: "{{name}} 借助土著移动",
				discardHand: "{{name}} 弃掉 {{n}} 张手牌",
				end: "本局结束"
			},
			cardNames: {
				traveler: "旅行者",
				explorer: "探险家",
				sailor: "水手",
				scout: "侦察兵",
				captain: "船长",
				trailblazer: "开路者",
				pioneer: "拓荒者",
				"giant-machete": "巨型砍刀",
				photographer: "摄影师",
				journalist: "记者",
				millionaire: "百万富翁",
				"treasure-chest": "宝箱",
				jack: "多面手",
				adventurer: "冒险家",
				"prop-plane": "螺旋桨飞机",
				cartographer: "制图师",
				compass: "罗盘",
				scientist: "科学家",
				transmitter: "发报机",
				"travel-log": "旅行日志",
				native: "土著"
			},
			cardText: {
				traveler: "金币 1",
				explorer: "砍刀 1 或船桨 1",
				sailor: "船桨 1",
				scout: "砍刀 2",
				captain: "船桨 3",
				trailblazer: "砍刀 3",
				pioneer: "砍刀 5",
				"giant-machete": "砍刀 6",
				photographer: "金币 2",
				journalist: "金币 3",
				millionaire: "金币 4",
				"treasure-chest": "金币 4",
				jack: "任意符号 1",
				adventurer: "任意符号 2",
				"prop-plane": "任意符号 4",
				cartographer: "抽两张牌",
				compass: "抽三张牌",
				scientist: "抽一张牌，可移出一张手牌",
				transmitter: "免费取一张市场牌",
				"travel-log": "抽两张牌，移出至多两张手牌",
				native: "无视要求走一格"
			}
		},
		en: {
			name: "The Quest for El Dorado",
			desc: "Build an expedition, cross jungle and river, and reach El Dorado first",
			rules: (/* @__PURE__ */ "Goal:(Win the expedition by bringing all of your pieces to El Dorado first. The first player to reach it triggers the final round; each player after them in that round takes one more turn, and then the game ends.(Setup:(Each player takes an expedition board, a starting deck and a set of pieces. The starting deck contains 4 Travelers, 3 Explorers and 1 Sailor. Shuffle it as your draw pile, then draw 4 cards as your hand.(Place 6 card piles on the market board: Scout, Trailblazer, Jack-of-All-Trades, Photographer, Treasure Chest and Transmitter. Place the other 12 piles above the market board.(Each turn:(1. Play cards: play any number of cards from your hand to move your pieces and/or to buy one new card.(2. Discard: put the cards you played this turn face up on your discard pile. Cards paid for a base camp are removed from the game instead. You may also keep or discard each unused card in your hand; discard any you do not want, one card at a time.(3. Draw: draw cards until you have 4 cards in hand. If you already hold 4 or more cards, draw nothing. If your draw pile runs out, shuffle your discard pile to form a new draw pile, then continue drawing.(Movement:(Each terrain card shows a machete, paddle or coin symbol together with its power value. Play one card in front of you, then move one piece onto an adjacent hex.(The color of the destination must match the symbol on the card: green jungle uses machetes, blue water uses paddles, and yellow villages use coins. The card’s power must be at least the power shown on the destination.(After entering a space, you may use any remaining power to continue to an adjacent hex. Each new space must meet its own symbol and power requirement, after subtracting the power already spent from the same card.(You cannot combine the power of several cards to enter one terrain space. You may stop moving at any time; any unused power is lost immediately.(Some cards show more than one symbol, such as the Explorer with machete 1 and paddle 1. Each time you use such a card, choose exactly one of its symbols; you cannot add the symbols together.(Terrain and special spaces:(Jungle shows machetes, water shows paddles, and villages show coins. The number of symbols equals the power of the space.(Rubble shows card symbols. Entering rubble does not require a matching symbol, but you must pay one card from your hand for each symbol on the space. Those cards go to your discard pile at the end of the turn.(A base camp also requires one card per symbol, but those cards are removed from the game. Base camps are the main way to keep your deck lean.(You can never enter a space occupied by another piece. El Dorado can hold several players at once.(Blockades:(A blockade lies across a pass and shows a symbol, a power and a number. The first player who wants to pass must play a card whose symbol matches and whose power is sufficient. That player keeps the blockade, and from then on everyone may pass freely.(Blockade numbers break ties at the end of the game. The player with more blockades wins a tie; if the count is equal, compare the highest numbered blockade.(Buying:(You may buy at most one card per turn, whether or not you have moved.(Cards with a coin symbol are worth their power; every other card is worth half a coin. You may play any number of cards from your hand to pay the price. If the total reaches the price, you buy the card; no change is given.(The purchased card goes face up on your discard pile, not directly into your hand.(Once all 3 cards of a pile have been sold, the market board has a vacant spot. You may then buy from any pile above the market board: place that pile on the vacant spot and take one card from it. While a vacancy exists, you may still buy from the piles remaining on the board.(Action and item cards:(Purple action cards may be played at any time during your own turn; resolve the effect, then continue your turn.(The Cartographer draws 2 cards. The Compass draws 3 cards, then is removed from the game. The Scientist draws 1 card; you may then remove one card from your hand. The Travel Log draws 2 cards; you may then remove up to 2 cards from your hand, and the Travel Log itself is removed from the game. The Transmitter lets you take any one card from the market board or from above it for free and put it on your discard pile, then the Transmitter is removed from the game. The Native moves one of your pieces onto an adjacent space, ignoring that space’s requirements; it can also tear down a blockade.(Cards marked with a crossed-out card are item cards and may be used only once per game. When you use an item card for its own symbol or effect, remove it from the game.(If you use an item card only as half a coin, or to pay for rubble, put it on your discard pile instead of removing it. An item card spent to enter a base camp is still removed from the game.(End of the game:(When one player’s pieces have all reached El Dorado, the final round begins. The players after them in that round each take one more turn, and then the game ends. If the last player of the round reaches El Dorado first, the game ends immediately.(If only one player has reached El Dorado, that player wins. If several players have reached it, the player with the most blockades wins. If the blockade count is tied, the tied player with the highest numbered blockade wins. If they still tie, the player who arrived first wins.(Two-player rules:(Each player controls two pieces, starting on spaces #1 and #3 or on spaces #2 and #4. Whenever you play a movement card, first choose which of your pieces it applies to. You cannot split one card’s power between your two pieces.(A player completes the journey only when both pieces have reached El Dorado. If both players bring their second piece to El Dorado during the final round, use the usual tie-breaker rules.".split("(")).join("\n"),
			you: "Your turn",
			waiting: "Waiting for {{name}}",
			finalRound: "Final round",
			turnNo: "Turn {{n}}",
			hand: "Hand",
			deck: "Draw pile",
			discard: "Discard pile",
			played: "Played",
			market: "Market",
			marketBoard: "Market board",
			marketAbove: "Above the market",
			vacant: "Vacant",
			stock: "{{n}} left",
			buy: "Buy",
			buyFor: "Buy for {{n}} coins",
			bought: "You already bought a card this turn",
			noStock: "Sold out",
			coins: "coins",
			cost: "Price",
			value: "Value",
			selectedCards: "{{n}} selected",
			totalValue: "Total {{n}} coins",
			play: "Play to move",
			stop: "Stop moving",
			endTurn: "End turn",
			use: "Use",
			discardSelected: "Discard selected",
			cancel: "Cancel",
			confirm: "Confirm",
			close: "Close",
			pass: "Pass",
			skipRemove: "Remove nothing",
			empty: "Empty",
			chooseSymbol: "Choose a symbol",
			chooseHex: "Tap an adjacent space",
			chooseCard: "Tap the card to take",
			choosePawn: "Choose a piece",
			myPawns: "My pieces",
			pawnOne: "First piece",
			pawnTwo: "Second piece",
			targetHints: "Legal spaces are highlighted",
			needCards: "This space needs {{n}} cards",
			leftPower: "{{n}} power left",
			roundHint: "Move and/or buy a card, then end turn",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			recenter: "Recenter on my pieces",
			fitMap: "Full map",
			legend: "Legend",
			log: "Log",
			history: "Action log",
			rulesTitle: "How to play",
			jungle: "Jungle",
			river: "Water",
			village: "Village",
			rubble: "Rubble",
			camp: "Base camp",
			blockade: "Blockade",
			temple: "El Dorado",
			start: "Start",
			machete: "Machete",
			paddle: "Paddle",
			coin: "Coin",
			cards: "Cards",
			item: "Item",
			action: "Action",
			blockades: "Blockades",
			finished: "Arrived",
			arrived: "Reached El Dorado",
			resultTitle: "Expedition Complete",
			resultSubtitle: "The standings and the spoils of the journey are settled",
			resultTrail: "Expedition standings",
			resultYou: "You",
			resultNotArrived: "Did not arrive",
			resultPlayAgain: "Set Off Again",
			resultBack: "Back to Lobby",
			resultWaitHost: "Waiting for the host to decide whether to set off again",
			resultHint: "Hints used this game: {{n}}",
			players: "Expedition",
			route: "Route",
			stripHand: "Hand {{n}}",
			stripDeck: "Deck {{n}}",
			stripBlockade: "Blockades {{n}}",
			highestBlockade: "Highest blockade {{n}}",
			promptRemove1: "Scientist: you may remove one card from your hand",
			promptRemove2: "Travel Log: you may remove up to two cards from your hand",
			promptTransmitter: "Transmitter: take a card from the market or above it",
			promptNative: "Native: move onto an adjacent space, ignoring its requirements",
			hintMove: "Move to {{hex}} with {{card}}",
			hintCross: "Pay {{n}} cards to enter the {{terrain}}",
			hintBuy: "Buy {{card}}",
			hintEnd: "End turn",
			hintStop: "Stop moving",
			hintAction: "Play {{card}}",
			errNotYourTurn: "It is not your turn yet",
			errBadCard: "That card is not in your hand",
			errBadSymbol: "That card’s symbol or power cannot reach there",
			errBadMove: "You cannot move there",
			errOccupied: "That space is occupied by another piece",
			errNeedCards: "Pay the number of cards shown on the space",
			errNotEnoughCoins: "Not enough coins",
			errNoStock: "That pile is sold out",
			errOneBuy: "You already bought a card this turn",
			errNoActive: "No card is currently being used to move",
			errBadPrompt: "Resolve the current choice first",
			errResolveFirst: "Finish the current choice first",
			errGameOver: "The game is over",
			errBadAction: "That action is not available",
			event: {
				turn: "{{name}} starts a turn",
				move: "{{name}} moves to {{hex}}",
				buy: "{{name}} buys {{card}}",
				arrive: "{{name}} reaches El Dorado",
				break: "{{name}} passes blockade {{n}}",
				action: "{{name}} plays {{card}}",
				rubble: "{{name}} pays {{n}} cards to enter rubble",
				camp: "{{name}} removes {{n}} cards to enter a base camp",
				draw: "{{name}} draws {{n}} cards",
				removeCard: "{{name}} removes {{card}} from the game",
				transmit: "{{name}} takes {{card}} with the Transmitter",
				native: "{{name}} moves with the Native",
				discardHand: "{{name}} discards {{n}} cards",
				end: "The game ends"
			},
			cardNames: {
				traveler: "Traveler",
				explorer: "Explorer",
				sailor: "Sailor",
				scout: "Scout",
				captain: "Captain",
				trailblazer: "Trailblazer",
				pioneer: "Pioneer",
				"giant-machete": "Giant Machete",
				photographer: "Photographer",
				journalist: "Journalist",
				millionaire: "Millionaire",
				"treasure-chest": "Treasure Chest",
				jack: "Jack-of-All-Trades",
				adventurer: "Adventurer",
				"prop-plane": "Prop Plane",
				cartographer: "Cartographer",
				compass: "Compass",
				scientist: "Scientist",
				transmitter: "Transmitter",
				"travel-log": "Travel Log",
				native: "Native"
			},
			cardText: {
				traveler: "Coin 1",
				explorer: "Machete 1 or paddle 1",
				sailor: "Paddle 1",
				scout: "Machete 2",
				captain: "Paddle 3",
				trailblazer: "Machete 3",
				pioneer: "Machete 5",
				"giant-machete": "Machete 6",
				photographer: "Coin 2",
				journalist: "Coin 3",
				millionaire: "Coin 4",
				"treasure-chest": "Coin 4",
				jack: "Any symbol 1",
				adventurer: "Any symbol 2",
				"prop-plane": "Any symbol 4",
				cartographer: "Draw 2 cards",
				compass: "Draw 3 cards",
				scientist: "Draw 1, may remove 1 from hand",
				transmitter: "Take 1 market card for free",
				"travel-log": "Draw 2, remove up to 2 from hand",
				native: "Move 1 space, ignoring requirements"
			}
		}
	}
};
//#endregion
export { Ct as default };
