import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { usePrefersReducedMotion as u } from "@bgparty/sdk/fx/use-reduced-motion";
import { LogSheet as d } from "@bgparty/sdk/ui/log-sheet";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ee, seatName as te } from "@bgparty/sdk/ui/player-strip";
import { SheetView as m } from "@bgparty/sdk/sheet-view";
import { gameAssetUrl as ne } from "@bgparty/sdk/assets";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
import { BottomSheet as _ } from "@bgparty/sdk/bottom-sheet";
import { OptionCheckbox as re, OptionSection as ie } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var v = /* @__PURE__ */ "cave.camp.precinct.inn.barn.dungeon.lagoon.bridgeWest.fountain.lamp.mansion.abbey.crypt.museum.church.hospital.graveyard.laboratory.institute.waterfront.docks.tower.theatre.river.bridgeEast.shop".split("."), y = {
	cave: {
		x: 88,
		y: 245,
		water: !1
	},
	camp: {
		x: 212,
		y: 200,
		water: !1
	},
	precinct: {
		x: 420,
		y: 182,
		water: !1
	},
	inn: {
		x: 570,
		y: 160,
		water: !1
	},
	barn: {
		x: 742,
		y: 166,
		water: !1
	},
	dungeon: {
		x: 915,
		y: 195,
		water: !1
	},
	lagoon: {
		x: 175,
		y: 370,
		water: !0
	},
	bridgeWest: {
		x: 338,
		y: 372,
		water: !1
	},
	fountain: {
		x: 478,
		y: 322,
		water: !1
	},
	lamp: {
		x: 358,
		y: 655,
		water: !1
	},
	mansion: {
		x: 275,
		y: 535,
		water: !1
	},
	abbey: {
		x: 90,
		y: 600,
		water: !1
	},
	crypt: {
		x: 80,
		y: 790,
		water: !1
	},
	museum: {
		x: 225,
		y: 755,
		water: !1
	},
	church: {
		x: 450,
		y: 800,
		water: !1
	},
	hospital: {
		x: 360,
		y: 915,
		water: !1
	},
	graveyard: {
		x: 610,
		y: 895,
		water: !1
	},
	laboratory: {
		x: 700,
		y: 745,
		water: !1
	},
	institute: {
		x: 820,
		y: 890,
		water: !1
	},
	waterfront: {
		x: 900,
		y: 700,
		water: !0
	},
	docks: {
		x: 880,
		y: 525,
		water: !1
	},
	tower: {
		x: 845,
		y: 350,
		water: !1
	},
	theatre: {
		x: 615,
		y: 345,
		water: !1
	},
	river: {
		x: 470,
		y: 460,
		water: !0
	},
	bridgeEast: {
		x: 690,
		y: 527,
		water: !1
	},
	shop: {
		x: 555,
		y: 640,
		water: !1
	}
}, b = {
	cave: ["lagoon", "camp"],
	camp: ["cave", "bridgeWest"],
	precinct: ["fountain"],
	inn: ["fountain"],
	barn: ["theatre"],
	dungeon: ["tower"],
	lagoon: [
		"cave",
		"abbey",
		"bridgeWest"
	],
	bridgeWest: [
		"lagoon",
		"mansion",
		"river",
		"fountain",
		"camp"
	],
	fountain: [
		"bridgeWest",
		"precinct",
		"inn",
		"theatre"
	],
	lamp: [
		"museum",
		"church",
		"shop",
		"mansion"
	],
	mansion: [
		"abbey",
		"lamp",
		"bridgeWest"
	],
	abbey: [
		"crypt",
		"mansion",
		"lagoon"
	],
	crypt: ["abbey"],
	museum: ["lamp"],
	church: [
		"hospital",
		"graveyard",
		"lamp"
	],
	hospital: ["church"],
	graveyard: ["church"],
	laboratory: ["institute", "shop"],
	institute: ["laboratory", "waterfront"],
	waterfront: [
		"institute",
		"bridgeEast",
		"docks"
	],
	docks: ["tower", "waterfront"],
	tower: [
		"theatre",
		"docks",
		"dungeon"
	],
	theatre: [
		"fountain",
		"bridgeEast",
		"tower",
		"barn"
	],
	river: ["bridgeWest", "bridgeEast"],
	bridgeEast: [
		"river",
		"shop",
		"waterfront",
		"theatre"
	],
	shop: [
		"lamp",
		"laboratory",
		"bridgeEast"
	]
}, x = /* @__PURE__ */ "beartrap.rapier.pistol.silvercane.shovel.pitchfork.dart.knife.firepoker.torch.speargun.rifle.research.anatomy.kite.rotenone.centrifuge.fossil.analysis.telescope.experiment.searchlight.camera.cosmicray.monocane.nebularium.tablet.flower.wine.garlic.charm.tarot.mirroredbox.crucifix.wolfsbane.violin.stake.scroll.canopic".split("."), S = {
	beartrap: {
		color: "red",
		strength: 4,
		space: "shop",
		count: 1
	},
	rapier: {
		color: "red",
		strength: 5,
		space: "theatre",
		count: 2
	},
	pistol: {
		color: "red",
		strength: 6,
		space: "precinct",
		count: 2
	},
	silvercane: {
		color: "red",
		strength: 6,
		space: "shop",
		count: 1
	},
	shovel: {
		color: "red",
		strength: 2,
		space: "graveyard",
		count: 2
	},
	pitchfork: {
		color: "red",
		strength: 4,
		space: "barn",
		count: 2
	},
	dart: {
		color: "red",
		strength: 2,
		space: "inn",
		count: 2
	},
	knife: {
		color: "red",
		strength: 3,
		space: "docks",
		count: 2
	},
	firepoker: {
		color: "red",
		strength: 3,
		space: "mansion",
		count: 2
	},
	torch: {
		color: "red",
		strength: 5,
		space: "barn",
		count: 2
	},
	speargun: {
		color: "red",
		strength: 4,
		space: "institute",
		count: 1
	},
	rifle: {
		color: "red",
		strength: 6,
		space: "barn",
		count: 1
	},
	research: {
		color: "blue",
		strength: 2,
		space: "tower",
		count: 2
	},
	anatomy: {
		color: "blue",
		strength: 1,
		space: "institute",
		count: 2
	},
	kite: {
		color: "blue",
		strength: 1,
		space: "tower",
		count: 2
	},
	rotenone: {
		color: "blue",
		strength: 3,
		space: "institute",
		count: 1
	},
	centrifuge: {
		color: "blue",
		strength: 1,
		space: "laboratory",
		count: 2
	},
	fossil: {
		color: "blue",
		strength: 3,
		space: "camp",
		count: 1
	},
	analysis: {
		color: "blue",
		strength: 2,
		space: "institute",
		count: 2
	},
	telescope: {
		color: "blue",
		strength: 2,
		space: "mansion",
		count: 1
	},
	experiment: {
		color: "blue",
		strength: 2,
		space: "laboratory",
		count: 2
	},
	searchlight: {
		color: "blue",
		strength: 2,
		space: "precinct",
		count: 1
	},
	camera: {
		color: "blue",
		strength: 3,
		space: "laboratory",
		count: 1
	},
	cosmicray: {
		color: "blue",
		strength: 3,
		space: "tower",
		count: 1
	},
	monocane: {
		color: "blue",
		strength: 3,
		space: "inn",
		count: 1
	},
	nebularium: {
		color: "blue",
		strength: 3,
		space: "tower",
		count: 1
	},
	tablet: {
		color: "yellow",
		strength: 3,
		space: "museum",
		count: 1
	},
	flower: {
		color: "yellow",
		strength: 2,
		space: "docks",
		count: 2
	},
	wine: {
		color: "yellow",
		strength: 2,
		space: "church",
		count: 2
	},
	garlic: {
		color: "yellow",
		strength: 2,
		space: "inn",
		count: 2
	},
	charm: {
		color: "yellow",
		strength: 4,
		space: "camp",
		count: 1
	},
	tarot: {
		color: "yellow",
		strength: 3,
		space: "camp",
		count: 1
	},
	mirroredbox: {
		color: "yellow",
		strength: 3,
		space: "mansion",
		count: 2
	},
	crucifix: {
		color: "yellow",
		strength: 4,
		space: "church",
		count: 2
	},
	wolfsbane: {
		color: "yellow",
		strength: 4,
		space: "camp",
		count: 2
	},
	violin: {
		color: "yellow",
		strength: 3,
		space: "camp",
		count: 1
	},
	stake: {
		color: "yellow",
		strength: 3,
		space: "abbey",
		count: 2
	},
	scroll: {
		color: "yellow",
		strength: 4,
		space: "museum",
		count: 1
	},
	canopic: {
		color: "yellow",
		strength: 3,
		space: "museum",
		count: 1
	}
}, ae = x.flatMap((e) => Array(S[e].count).fill(e)), C = [
	"archaeologist",
	"courier",
	"explorer",
	"inspector",
	"mayor",
	"professor",
	"scientist"
], oe = {
	archaeologist: {
		actions: 4,
		start: "docks",
		special: "archaeologist"
	},
	courier: {
		actions: 4,
		start: "shop",
		special: "courier"
	},
	explorer: {
		actions: 3,
		start: "camp",
		special: "explorer"
	},
	inspector: {
		actions: 4,
		start: "precinct",
		special: "inspector"
	},
	mayor: {
		actions: 5,
		start: "theatre",
		special: null
	},
	professor: {
		actions: 4,
		start: "hospital",
		special: "professor"
	},
	scientist: {
		actions: 4,
		start: "institute",
		special: "scientist"
	}
}, se = [
	"fritz",
	"maria",
	"maleva",
	"pearson",
	"wilbur",
	"renfield",
	"reed",
	"cranley",
	"lucy",
	"elizabeth"
], w = {
	fritz: {
		safe: "institute",
		spawn: "tower"
	},
	maria: {
		safe: "camp",
		spawn: "barn"
	},
	maleva: {
		safe: "shop",
		spawn: "camp"
	},
	pearson: {
		safe: "museum",
		spawn: "cave"
	},
	wilbur: {
		safe: "dungeon",
		spawn: "shop"
	},
	renfield: {
		safe: "hospital",
		spawn: "docks"
	},
	reed: {
		safe: "camp",
		spawn: "institute"
	},
	cranley: {
		safe: "precinct",
		spawn: "laboratory"
	},
	lucy: {
		safe: "mansion",
		spawn: "theatre"
	},
	elizabeth: {
		safe: "tower",
		spawn: "mansion"
	}
}, T = [
	"dracula",
	"mummy",
	"frankenstein",
	"creature",
	"wolfman",
	"invisibleman"
], E = {
	dracula: 1,
	mummy: 2,
	frankenstein: 3,
	creature: 4,
	wolfman: 5,
	invisibleman: 6
}, ce = [
	"crypt",
	"dungeon",
	"graveyard",
	"cave"
], le = [
	"inn",
	"barn",
	"mansion",
	"laboratory",
	"institute"
], D = [
	1,
	1,
	2,
	2,
	3,
	3
], O = {
	frank: 11,
	bride: 8
}, k = [
	"red",
	"yellow",
	"blue",
	"yellow",
	"blue",
	"red",
	"yellow",
	"blue",
	"yellow",
	"blue",
	"red",
	"yellow",
	"blue",
	"red",
	"red",
	"yellow",
	"blue",
	"red",
	"blue"
], A = k.length, j = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"D"
], M = {
	6: ["1", "5"],
	1: ["6", "2"],
	2: [
		"1",
		"3",
		"D"
	],
	3: ["2", "4"],
	4: ["3", "5"],
	5: [
		"4",
		"6",
		"D"
	],
	D: ["2", "5"]
}, ue = {
	6: {
		x: 33,
		y: 26
	},
	1: {
		x: 67,
		y: 26
	},
	5: {
		x: 18,
		y: 50
	},
	2: {
		x: 82,
		y: 50
	},
	D: {
		x: 50,
		y: 50
	},
	4: {
		x: 33,
		y: 74
	},
	3: {
		x: 67,
		y: 74
	}
}, N = (e, t, n) => ({
	monster: e,
	move: t,
	dice: n
}), de = [
	{
		items: 3,
		event: "onTheMove",
		strikes: [N("frenzy", 3, 2)]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			N("creature", 2, 1),
			N("wolfman", 2, 1),
			N("invisibleman", 2, 1)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			N("creature", 1, 2),
			N("dracula", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "retreatLagoon",
		strikes: [
			N("mummy", 1, 3),
			N("bride", 1, 3),
			N("frenzy", 1, 3)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			N("creature", 1, 2),
			N("dracula", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 3,
		event: "onTheMove",
		strikes: [N("frenzy", 3, 2)]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			N("creature", 2, 1),
			N("wolfman", 2, 1),
			N("invisibleman", 2, 1)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			N("mummy", 1, 3),
			N("creature", 1, 3),
			N("frankenstein", 1, 3)
		]
	},
	{
		items: 3,
		event: "innocent",
		strikes: [
			N("frankenstein", 1, 3),
			N("bride", 1, 3),
			N("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "insaneSurvivor",
		strikes: [N("dracula", 2, 2), N("frenzy", 2, 2)]
	},
	{
		items: 3,
		event: "worriedFiancee",
		strikes: [
			N("frankenstein", 1, 2),
			N("bride", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 3,
		event: "enthralled",
		strikes: [N("dracula", 2, 1), N("frenzy", 2, 1)]
	},
	{
		items: 3,
		event: "delivery",
		strikes: [
			N("frankenstein", 1, 3),
			N("bride", 1, 3),
			N("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "fortuneTeller",
		strikes: [N("wolfman", 1, 2), N("frenzy", 1, 2)]
	},
	{
		items: 3,
		event: "hurriedAssistant",
		strikes: [
			N("frankenstein", 1, 2),
			N("bride", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			N("wolfman", 1, 2),
			N("dracula", 1, 2),
			N("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "hypnoticGaze",
		strikes: [
			N("mummy", 1, 2),
			N("invisibleman", 1, 2),
			N("creature", 1, 2)
		]
	},
	{
		items: 0,
		event: "sunrise",
		strikes: [
			N("invisibleman", 1, 2),
			N("frankenstein", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			N("mummy", 1, 3),
			N("creature", 1, 3),
			N("frankenstein", 1, 3)
		]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			N("wolfman", 1, 2),
			N("dracula", 1, 2),
			N("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			N("mummy", 1, 3),
			N("creature", 1, 3),
			N("frankenstein", 1, 3)
		]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			N("creature", 2, 1),
			N("wolfman", 2, 1),
			N("invisibleman", 2, 1)
		]
	},
	{
		items: 3,
		event: "egyptianExpert",
		strikes: [N("mummy", 2, 2), N("frenzy", 2, 2)]
	},
	{
		items: 3,
		event: "formerEmployer",
		strikes: [N("invisibleman", 1, 2), N("frenzy", 1, 2)]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			N("wolfman", 1, 2),
			N("dracula", 1, 2),
			N("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "formOfTheBat",
		strikes: [
			N("wolfman", 1, 2),
			N("creature", 1, 2),
			N("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			N("creature", 1, 2),
			N("dracula", 1, 2),
			N("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "retreatRiver",
		strikes: [
			N("wolfman", 1, 3),
			N("bride", 1, 3),
			N("frenzy", 1, 3)
		]
	},
	{
		items: 0,
		event: "retreatWaterfront",
		strikes: [
			N("wolfman", 1, 3),
			N("bride", 1, 3),
			N("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "ichthyologist",
		strikes: [N("creature", 1, 2), N("frenzy", 1, 2)]
	}
], fe = [
	"breakOfDawn",
	"lateNight",
	"detective",
	"taxiRide",
	"crucifix",
	"rush",
	"mobJustice",
	"overstock",
	"specialDelivery",
	"hurry",
	"investigation",
	"huntedPrey",
	"ancients",
	"showForce",
	"repel"
], pe = [
	"breakOfDawn",
	"lateNight",
	"detective",
	"taxiRide",
	"crucifix",
	"rush",
	"taxiRide",
	"mobJustice",
	"overstock",
	"specialDelivery",
	"hurry",
	"investigation",
	"overstock",
	"breakOfDawn",
	"lateNight",
	"huntedPrey",
	"ancients",
	"showForce",
	"repel",
	"rush"
];
function me(e, t) {
	let n = /* @__PURE__ */ new Map([[e, {
		to: e,
		prev: null,
		dist: 0
	}]]), r = [e];
	for (; r.length;) {
		let e = r.shift(), i = n.get(e);
		for (let a of b[e]) !n.has(a) && t(a) && (n.set(a, {
			to: a,
			prev: e,
			dist: i.dist + 1
		}), r.push(a));
	}
	return n;
}
function P(e, t) {
	let n = [], r = t;
	for (; r !== null;) n.push(r), r = e.get(r)?.prev ?? null;
	return n.reverse();
}
function he(e) {
	return !y[e].water;
}
//#endregion
//#region src/game/meta.ts
var ge = {
	id: "horrified",
	uuid: "acbff95d-4892-457b-bf84-0a3dfd3e8caa",
	tier: "alpha",
	mechanics: [
		"action-points",
		"dice-rolling",
		"grid-movement",
		"set-collection"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.horrified.name",
	descKey: "games.horrified.desc",
	rulesKey: "games.horrified.rules",
	icon: "🦇",
	iconImg: "games/horrified.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#7b3fb5",
	releasedAt: "2026-11-28T15:53:00+08:00",
	search: {
		py: "duo ming jing hun",
		init: "dmjh"
	},
	hotseat: "open"
}, _e = [
	"dracula",
	"mummy",
	"frank",
	"bride",
	"creature",
	"wolfman",
	"invisibleman"
];
function ve(e) {
	return e === "frank" || e === "bride" ? "frankenstein" : e;
}
function ye(e, t) {
	return `${e}#${t}`;
}
function F(e) {
	return e.slice(0, e.indexOf("#"));
}
function be(e, t) {
	return `${e}#${t}`;
}
function xe(e) {
	return e.slice(0, e.indexOf("#"));
}
//#endregion
//#region src/game/logic.ts
function I(e, ...t) {
	e.queue.unshift(...t);
}
function L(e, t) {
	e.log.push(t), e.log.length > 80 && e.log.splice(0, e.log.length - 80);
}
function R(e) {
	return e.heroes[e.turn];
}
function z(e, t) {
	return e.heroes.find((e) => e.id === t) ?? null;
}
function Se(e, t) {
	return z(e, t)?.owner ?? null;
}
function Ce(e) {
	return e === "scientist";
}
function we(e, t) {
	return S[F(t)].strength + +!!Ce(e);
}
function B(e, t) {
	return t.reduce((t, n) => t + we(e, n), 0);
}
function V(e) {
	return S[F(e)].color;
}
function Te(e, t) {
	return e.config.monsters.includes(t) && !e.defeated.includes(t);
}
function H(e, t) {
	return Te(e, ve(t)) ? U(e, t) !== null : !1;
}
function U(e, t) {
	switch (t) {
		case "dracula": return e.monsters.dracula.space;
		case "creature": return e.monsters.creature.space;
		case "frank": return e.monsters.fb.frank;
		case "bride": return e.monsters.fb.bride;
		case "mummy": return e.monsters.mummy.space;
		case "wolfman": return e.monsters.wolfman.space;
		case "invisibleman": return e.monsters.invisibleman.space;
	}
}
function Ee(e, t, n) {
	switch (t) {
		case "dracula":
			e.monsters.dracula.space = n;
			break;
		case "creature":
			e.monsters.creature.space = n;
			break;
		case "frank":
			e.monsters.fb.frank = n;
			break;
		case "bride":
			e.monsters.fb.bride = n;
			break;
		case "mummy":
			e.monsters.mummy.space = n;
			break;
		case "wolfman":
			e.monsters.wolfman.space = n;
			break;
		case "invisibleman": e.monsters.invisibleman.space = n;
	}
}
function De(e, t) {
	if (t === "frenzy") {
		let t = e.frenzy;
		return t === "frankenstein" ? "frank" : t;
	}
	return t === "frankenstein" ? "frank" : t;
}
function Oe(e) {
	let t = [];
	return Te(e, "creature") && t.push("creature"), Te(e, "dracula") && t.push("dracula"), Te(e, "frankenstein") && t.push("frank", "bride"), Te(e, "mummy") && t.push("mummy"), Te(e, "wolfman") && t.push("wolfman"), Te(e, "invisibleman") && t.push("invisibleman"), t;
}
function ke(e) {
	return me(e, (e) => !y[e].water);
}
function Ae(e, t) {
	return me(t, (t) => e === "creature" || !y[t].water);
}
function je(e, t, n) {
	return [...me(e, (e) => n || !y[e].water).values()].filter((e) => e.dist > 0 && e.dist <= t).map((e) => e.to);
}
function Me(e, t) {
	return b[e].includes(t) && !y[t].water;
}
function Ne(e, t, n, r) {
	let i = U(e, t);
	if (!i) return null;
	if (i === n || r <= 0) return i;
	let a = Ae(t, i);
	if (!a.has(n)) return null;
	let o = P(a, n), s = o[Math.min(r, o.length - 1)];
	return Ee(e, t, s), L(e, {
		k: "monsterMoved",
		figure: t,
		space: s
	}), s;
}
function Pe(e, t, n, r) {
	let i = Le(e, t);
	if (!i || i === n || r <= 0) return;
	let a = ke(i);
	if (!a.has(n)) return;
	let o = P(a, n), s = o[Math.min(r, o.length - 1)];
	if (t.kind === "hero") {
		let n = z(e, t.id);
		if (!n || n.defeated) return;
		n.space = s, L(e, {
			k: "heroMoved",
			hero: n.id,
			space: s
		});
	} else Fe(e, t.id, s);
}
function Fe(e, t, n) {
	let r = e.villagers[t];
	r.status === "board" && (r.space = n, L(e, {
		k: "villagerMoved",
		villager: t,
		space: n
	}), Ze(e));
}
function Ie(e, t, n) {
	let r = e.villagers[t];
	if (r.status !== "board" || !r.space) return;
	let i = ke(r.space), a = w[t].safe;
	if (!i.has(a)) return;
	let o = P(i, a);
	Fe(e, t, o[Math.min(n, o.length - 1)]);
}
function Le(e, t) {
	return t.kind === "hero" ? z(e, t.id)?.space ?? null : e.villagers[t.id]?.space ?? null;
}
function Re(e, t) {
	return e.heroes.filter((e) => !e.defeated && e.space === t).map((e) => e.id);
}
function ze(e, t) {
	return Object.keys(e.villagers).filter((n) => e.villagers[n].status === "board" && e.villagers[n].space === t);
}
function Be(e, t) {
	return [...Re(e, t).map((e) => ({
		kind: "hero",
		id: e
	})), ...ze(e, t).map((e) => ({
		kind: "villager",
		id: e
	}))];
}
function Ve(e, t) {
	let n = e.villagers[t];
	return n.status === "none" && (n.status = "board", n.space = w[t].spawn, L(e, {
		k: "villagerPlaced",
		villager: t,
		space: n.space
	}), !0);
}
function He(e, t) {
	let n = U(e, t);
	if (!n) return null;
	let r = Ae(t, n), i = Infinity, a = [];
	for (let t of e.heroes) {
		if (t.defeated || !t.space) continue;
		let e = r.get(t.space);
		e && (e.dist < i ? (i = e.dist, a = [{
			kind: "hero",
			id: t.id
		}]) : e.dist === i && a.push({
			kind: "hero",
			id: t.id
		}));
	}
	for (let t of Object.keys(e.villagers)) {
		let n = e.villagers[t];
		if (n.status !== "board" || !n.space) continue;
		let o = r.get(n.space);
		o && (o.dist < i ? (i = o.dist, a = [{
			kind: "villager",
			id: t
		}]) : o.dist === i && a.push({
			kind: "villager",
			id: t
		}));
	}
	return a.length ? {
		dist: i,
		list: a
	} : null;
}
function Ue(e, t) {
	let n = U(e, t);
	if (!n) return null;
	let r = Ae(t, n), i = Infinity, a = null;
	for (let t of Object.keys(e.villagers)) {
		let n = e.villagers[t];
		if (n.status !== "board" || !n.space) continue;
		let o = r.get(n.space);
		o && o.dist < i && (i = o.dist, a = t);
	}
	return a;
}
function We(e) {
	return e.heroes.filter((e) => !e.defeated).map((e) => e.id);
}
function Ge(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1), a = r[n];
		r[n] = r[i], r[i] = a;
	}
	return r;
}
function Ke(t) {
	return e(t.seed, t.cursor++, 6);
}
function qe(e) {
	if (!e.bag.length) {
		if (!e.itemDiscard.length) return null;
		e.bag = Ge(e, e.itemDiscard), e.itemDiscard = [];
	}
	let t = e.bag.pop(), n = S[F(t)].space;
	return e.spaceItems[n].push(t), L(e, {
		k: "itemPlaced",
		item: t,
		space: n
	}), t;
}
function Je(e, t) {
	e.itemDiscard.push(t);
}
function Ye(e, t) {
	if (!e.perkDeck.length) {
		if (!e.perkDiscard.length) return null;
		e.perkDeck = Ge(e, e.perkDiscard), e.perkDiscard = [];
	}
	let n = e.perkDeck.pop(), r = z(e, t);
	return r ? (r.perks.push(n), L(e, {
		k: "perkGain",
		hero: t,
		perk: xe(n)
	}), n) : null;
}
function Xe(e) {
	let t = R(e);
	for (let n of Object.keys(e.villagers)) {
		let r = e.villagers[n];
		r.status === "board" && r.space === w[n].safe && (r.status = "safe", r.space = null, L(e, {
			k: "rescued",
			villager: n,
			hero: t?.id
		}), t && Ye(e, t.id));
	}
}
function Ze(e) {
	Xe(e);
}
function Qe(e, t = 1) {
	e.terror = Math.min(7, e.terror + t), L(e, {
		k: "terror",
		n: t
	});
}
function $e(e, t) {
	let n = z(e, t);
	n && !n.defeated && (n.defeated = !0, n.space = null, Qe(e), L(e, {
		k: "heroDefeated",
		hero: t
	}));
}
function et(e, t) {
	let n = e.villagers[t];
	n.status === "board" && (n.status = "defeated", n.space = null, Qe(e), L(e, {
		k: "villagerDefeated",
		villager: t
	}));
}
function tt(e) {
	let t = e.config.monsters.filter((t) => !e.defeated.includes(t)).sort((e, t) => E[e] - E[t]);
	if (!t.length) return;
	let n = t.indexOf(e.frenzy), r = n < 0 ? t[0] : t[(n + 1) % t.length];
	r !== e.frenzy && (e.frenzy = r, L(e, {
		k: "frenzyMoved",
		monster: r
	}));
}
function nt(e, t) {
	if (!e.defeated.includes(t)) {
		switch (e.defeated.push(t), L(e, {
			k: "monsterDefeated",
			monster: t
		}), t) {
			case "dracula":
				e.monsters.dracula.space = null;
				break;
			case "creature":
				e.monsters.creature.space = null;
				break;
			case "frankenstein":
				e.monsters.fb.frank = null, e.monsters.fb.bride = null;
				break;
			case "mummy":
				e.monsters.mummy.space = null, e.soul = null;
				break;
			case "wolfman":
				e.monsters.wolfman.space = null;
				for (let t of e.monsters.wolfman.bottles) t && Je(e, t);
				e.monsters.wolfman.bottles = e.monsters.wolfman.bottles.map(() => null), e.monsters.wolfman.cure = null, e.hunted = null;
				break;
			case "invisibleman":
				e.monsters.invisibleman.space = null;
				for (let t of e.monsters.invisibleman.spots) t && Je(e, t);
				e.monsters.invisibleman.spots = e.monsters.invisibleman.spots.map(() => null);
		}
		e.frenzy === t && tt(e);
	}
}
function rt(e) {
	let t = e.monsters.mummy.slots;
	for (let e of [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6"
	]) {
		let n = t[e];
		if (n.num !== Number(e) || !n.faceUp) return !1;
	}
	return t.D.num === 0;
}
function it(e) {
	if (e.ending || e.defeated.includes("frankenstein")) return;
	let t = e.monsters.fb;
	if (t.frank && t.bride && t.frank === t.bride) {
		if (t.flipped.frank && t.flipped.bride) {
			e.queue.some((e) => e.kind === "fbCombine") || I(e, { kind: "fbCombine" });
			return;
		}
		e.terror = Math.min(7, e.terror + 1), L(e, {
			k: "fbMeet",
			space: t.frank
		}), t.frank = "graveyard", t.bride = "dungeon", e.fbMoves = null;
	}
}
function at(e, t, n) {
	e.ending || (e.ending = {
		win: t,
		reason: n
	}, e.phase = "done", e.prompt = null, e.queue = [], L(e, {
		k: t ? "win" : "lose",
		ok: t,
		n: n === "terror" ? 2 : n === "time" ? 3 : 1
	}));
}
function ot(e) {
	if (!e.ending) {
		if (e.terror >= 7) {
			at(e, !1, "terror");
			return;
		}
		e.config.monsters.every((t) => e.defeated.includes(t)) && at(e, !0, "triumph");
	}
}
function st(e) {
	it(e), ot(e);
}
function W(e, t, n = {}) {
	return {
		id: "",
		kind: e,
		ops: t,
		...n
	};
}
function G(e, t, n, r) {
	if (e.ending || !r.length) return;
	e.decision += 1;
	let i = e.decision;
	e.prompt = {
		decision: i,
		kind: n,
		owners: [...new Set(t.filter(Boolean))],
		options: r.map((e, t) => ({
			...e,
			id: `${i}:${t}`
		}))
	};
}
function ct(e) {
	let t = R(e);
	return t ? [t.owner] : [];
}
function lt(e, t) {
	return [.../* @__PURE__ */ new Set([...ct(e), Se(e, t) ?? ""])];
}
function ut(e) {
	e.turn = (e.turn + 1) % e.players.length;
	let t = R(e);
	e.phase = "hero", e.cardIndex = null, e.mummyMoves = 0, e.fbMoves = null, t.defeated && (t.defeated = !1, t.space = "hospital", L(e, {
		k: "revived",
		hero: t.id,
		space: "hospital"
	})), e.actionsLeft = dt[t.id], L(e, {
		k: "turnStart",
		hero: t.id
	});
}
var dt = Object.fromEntries(Object.entries(oe).map(([e, t]) => [e, t.actions]));
function ft(e) {
	return dt[e];
}
//#endregion
//#region src/game/ops.ts
function K(e) {
	return e.phase === "hero" ? [...e.players] : ct(e);
}
function pt(e) {
	return e.kind === "hero" ? { hero: e.id } : { villager: e.id };
}
var mt = {
	meeting: "frankenstein",
	hunt: "wolfman",
	thief: "invisibleman",
	retreatLagoon: "creature",
	retreatRiver: "creature",
	retreatWaterfront: "creature",
	reincarnatedSoul: "mummy",
	hypnoticGaze: "dracula",
	sunrise: "dracula",
	formOfTheBat: "dracula"
};
function ht(e, t) {
	switch (t.kind) {
		case "monsterBegin": {
			if (e.ending) return;
			if (e.skipMonster) {
				e.skipMonster = !1, L(e, { k: "monsterSkipped" }), I(e, { kind: "cardEnd" });
				return;
			}
			if (!e.monsterDeck.length) {
				at(e, !1, "time");
				return;
			}
			let t = e.monsterDeck.pop(), n = de[t];
			e.cardIndex = t, e.monsterDiscard.push(t), L(e, {
				k: "monsterCard",
				n: t
			}), I(e, {
				kind: "drawItems",
				n: n.items
			}, {
				kind: "event",
				event: n.event
			}, ...n.strikes.map((e) => ({
				kind: "strike",
				symbol: e.monster,
				move: e.move,
				dice: e.dice
			})), { kind: "cardEnd" });
			return;
		}
		case "drawItems":
			for (let n = 0; n < t.n; n++) qe(e);
			return;
		case "drawItemsEach":
			e.players.forEach(() => qe(e));
			return;
		case "addActions":
			e.actionsLeft += t.n, L(e, {
				k: "actions",
				n: t.n
			});
			return;
		case "event": {
			let n = mt[t.event];
			if (n && !Te(e, n)) {
				L(e, {
					k: "eventIgnored",
					monster: n
				});
				return;
			}
			vt(e, t.event);
			return;
		}
		case "askThief": {
			let t = v.map((t) => ({
				space: t,
				n: e.spaceItems[t].length
			})), n = Math.max(0, ...t.map((e) => e.n));
			if (!n) return;
			let r = t.filter((e) => e.n === n).map((e) => e.space);
			if (r.length === 1) {
				I(e, {
					kind: "thief",
					space: r[0]
				});
				return;
			}
			G(e, K(e), "thief", r.map((e) => W("thief", [{
				kind: "thief",
				space: e
			}], { space: e })));
			return;
		}
		case "thief":
			e.monsters.invisibleman.space = t.space;
			for (let n of e.spaceItems[t.space]) e.itemDiscard.push(n);
			e.spaceItems[t.space] = [], L(e, {
				k: "thief",
				space: t.space
			});
			return;
		case "strike": {
			let n = De(e, t.symbol);
			if (!n || !H(e, n) || !U(e, n)) return;
			let r = He(e, n);
			if (!r) return;
			let i = r.list;
			if (i.some((e) => e.kind === "hero") && (i = i.filter((e) => e.kind === "hero")), new Set(i.map((t) => gt(e, t))).size === 1) {
				I(e, {
					kind: "strikeGo",
					figure: n,
					target: i[0],
					move: t.move,
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", i.map((e) => W("attack", [{
				kind: "strikeGo",
				figure: n,
				target: e,
				move: t.move,
				dice: t.dice
			}], pt(e))));
			return;
		}
		case "strikeGo": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = gt(e, t.target);
			if (!r) return;
			if (n !== r) {
				let i = Ae(t.figure, n);
				if (i.has(r)) {
					let n = P(i, r), a = n[Math.min(t.move, n.length - 1)];
					Ee(e, t.figure, a), L(e, {
						k: "monsterMoved",
						figure: t.figure,
						space: a
					});
				}
			}
			let i = U(e, t.figure);
			if (!i) return;
			let a = Be(e, i);
			if (a.some((e) => e.kind === "hero") && (a = a.filter((e) => e.kind === "hero")), !a.length) return;
			if (a.length === 1) {
				I(e, {
					kind: "strikeRoll",
					figure: t.figure,
					target: a[0],
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", a.map((e) => W("attack", [{
				kind: "strikeRoll",
				figure: t.figure,
				target: e,
				dice: t.dice
			}], pt(e))));
			return;
		}
		case "strikeRoll": {
			let n = [];
			for (let r = 0; r < t.dice; r++) n.push(Ke(e));
			let r = n.filter((e) => e < 3).length, i = n.filter((e) => e === 5).length;
			e.lastRoll = {
				figure: t.figure,
				dice: n,
				hits: r,
				powers: i
			}, L(e, {
				k: "roll",
				figure: t.figure,
				n: r,
				n2: i
			});
			let a = [];
			for (let e = 0; e < r; e++) a.push(t.target.kind === "hero" ? {
				kind: "hitHero",
				hero: t.target.id
			} : {
				kind: "hitVillager",
				villager: t.target.id
			});
			for (let e = 0; e < i; e++) a.push({
				kind: "power",
				figure: t.figure
			});
			a.length && I(e, ...a);
			return;
		}
		case "hitHero": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			if (!n.items.length) {
				$e(e, t.hero), L(e, {
					k: "hit",
					hero: t.hero
				});
				return;
			}
			G(e, [.../* @__PURE__ */ new Set([...lt(e, t.hero), ...K(e)])], "defend", [...n.items.map((e) => W("defend", [{
				kind: "defend",
				hero: t.hero,
				uid: e
			}], {
				hero: t.hero,
				item: e
			})), W("takeHit", [{
				kind: "takeHit",
				hero: t.hero
			}], { hero: t.hero })]);
			return;
		}
		case "hitVillager":
			if (e.villagers[t.villager].status !== "board") return;
			et(e, t.villager), L(e, {
				k: "hit",
				villager: t.villager
			});
			return;
		case "defend": {
			let n = z(e, t.hero);
			if (!n) return;
			let r = n.items.indexOf(t.uid);
			if (r < 0) return;
			n.items.splice(r, 1), e.itemDiscard.push(t.uid), L(e, {
				k: "defended",
				hero: t.hero,
				item: t.uid
			});
			return;
		}
		case "takeHit": {
			let n = z(e, t.hero);
			if (!n || n.defeated) return;
			$e(e, t.hero), L(e, {
				k: "hit",
				hero: t.hero
			});
			return;
		}
		case "power":
			_t(e, t.figure);
			return;
		case "cardEnd":
			if (e.ending) return;
			ut(e);
			return;
		case "endGame":
			at(e, t.win, t.reason);
			return;
		case "gainPerk":
			Ye(e, t.hero);
			return;
		case "skipMonster":
			e.skipMonster = !0, L(e, { k: "monsterWillSkip" });
			return;
		case "moveFigure":
			Ee(e, t.figure, t.to), L(e, {
				k: "monsterMoved",
				figure: t.figure,
				space: t.to
			});
			return;
		case "moveHero": {
			let n = z(e, t.hero);
			if (!n || n.defeated) return;
			n.space = t.to, L(e, {
				k: "heroMoved",
				hero: t.hero,
				space: t.to
			});
			return;
		}
		case "moveVillager":
			Fe(e, t.villager, t.to);
			return;
		case "transferItem": {
			let n = z(e, t.from), r = z(e, t.to);
			if (!n || !r) return;
			let i = n.items.indexOf(t.uid);
			if (i < 0) return;
			n.items.splice(i, 1), r.items.push(t.uid), L(e, {
				k: "itemGiven",
				hero: t.from,
				hero2: t.to,
				item: t.uid
			});
			return;
		}
		case "transferCure":
			if (e.monsters.wolfman.cure !== t.from) return;
			e.monsters.wolfman.cure = t.to, L(e, {
				k: "cureGiven",
				hero: t.from,
				hero2: t.to
			});
			return;
		case "fbReset":
			e.monsters.fb.frank = "graveyard", e.monsters.fb.bride = "dungeon";
			return;
		case "fbCombine":
			nt(e, "frankenstein"), L(e, { k: "fbDefeated" });
			return;
		case "askPlaceNamed": {
			let n = t.figures.filter((t) => H(e, t));
			if (!n.length) return;
			if (n.length > 1) {
				G(e, K(e), "placeFigure", n.map((e) => W("figure", [{
					kind: "askPlaceNamed",
					figures: [e]
				}], { figure: e })));
				return;
			}
			let r = n[0], i = v.filter((e) => r === "creature" || !y[e].water);
			G(e, K(e), "placeFigure", i.map((e) => W("place", [{
				kind: "moveFigure",
				figure: r,
				to: e
			}], {
				figure: r,
				space: e
			})));
			return;
		}
		case "askFigureDest": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = [...Ae(t.figure, n).values()].filter((e) => e.dist > 0 && e.dist <= t.steps).map((e) => e.to), i = [W("stay", [], { figure: t.figure }), ...r.map((e) => W("space", [{
				kind: "moveFigure",
				figure: t.figure,
				to: e
			}], {
				figure: t.figure,
				space: e
			}))];
			G(e, K(e), "figureDest", i);
			return;
		}
		case "askMoveAny": {
			let n = Oe(e).filter((t) => U(e, t));
			if (!n.length) return;
			G(e, K(e), "moveFigure", n.map((e) => W("figure", [{
				kind: "askFigureDest",
				figure: e,
				steps: t.steps
			}], { figure: e })));
			return;
		}
		case "askHeroMove":
			if (!t.heroes.length) return;
			G(e, K(e), "moveHero", t.heroes.map((e) => W("hero", [{
				kind: "askHeroDest",
				hero: e,
				steps: t.steps,
				anyLand: !0,
				carry: t.carry
			}], { hero: e })));
			return;
		case "askHeroDest": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			let r = je(n.space, t.steps, !1), i = t.carry && ze(e, n.space).length > 0, a = [W("stay", [], { hero: t.hero }), ...r.map((e) => W("space", [i ? {
				kind: "askHeroCarry",
				hero: t.hero,
				to: e,
				chosen: [],
				remaining: []
			} : {
				kind: "moveHero",
				hero: t.hero,
				to: e
			}], {
				hero: t.hero,
				space: e
			}))];
			G(e, K(e), "heroDest", a);
			return;
		}
		case "askHeroCarry": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			let r = ze(e, n.space);
			if (!r.length) {
				I(e, {
					kind: "moveHero",
					hero: t.hero,
					to: t.to
				}), t.remaining.length && I(e, {
					kind: "askHurry",
					remaining: t.remaining
				});
				return;
			}
			let i = t.chosen.filter((e) => r.includes(e)), a = (e) => i.includes(e) ? i.filter((t) => t !== e) : [...i, e], o = [...r.map((e) => W(i.includes(e) ? "villagerOn" : "villagerOff", [{
				kind: "askHeroCarry",
				hero: t.hero,
				to: t.to,
				chosen: a(e),
				remaining: t.remaining
			}], { villager: e })), W("carryConfirm", [
				{
					kind: "moveHero",
					hero: t.hero,
					to: t.to
				},
				...i.map((e) => ({
					kind: "moveVillager",
					villager: e,
					to: t.to
				})),
				...t.remaining.length ? [{
					kind: "askHurry",
					remaining: t.remaining
				}] : []
			])];
			G(e, K(e), "carry", o);
			return;
		}
		case "askHurry": {
			let [n, ...r] = t.remaining;
			if (!n) return;
			let i = z(e, n);
			if (!i || i.defeated || !i.space) {
				I(e, {
					kind: "askHurry",
					remaining: r
				});
				return;
			}
			let a = je(i.space, 2, !1), o = ze(e, i.space).length > 0, s = [W("stay", [{
				kind: "askHurry",
				remaining: r
			}], { hero: n }), ...a.map((e) => W("space", o ? [{
				kind: "askHeroCarry",
				hero: n,
				to: e,
				chosen: [],
				remaining: r
			}] : [{
				kind: "moveHero",
				hero: n,
				to: e
			}, {
				kind: "askHurry",
				remaining: r
			}], {
				hero: n,
				space: e
			}))];
			G(e, K(e), "hurry", s);
			return;
		}
		case "askInvestigate": {
			let t = [...new Set(e.heroes.filter((e) => !e.defeated && e.space).map((e) => e.space))];
			if (!t.length) return;
			G(e, K(e), "investigate", t.map((t) => W("space", [{
				kind: "askInvestigateHero",
				space: t,
				remaining: We(e).filter((n) => z(e, n)?.space !== t)
			}], { space: t })));
			return;
		}
		case "askInvestigateHero": {
			let n = t.remaining.filter((n) => {
				let r = z(e, n);
				return !!r && !r.defeated && r.space !== t.space;
			}).map((e) => W("hero", [{
				kind: "moveHero",
				hero: e,
				to: t.space
			}, {
				kind: "askInvestigateHero",
				space: t.space,
				remaining: t.remaining.filter((t) => t !== e)
			}], { hero: e }));
			n.push(W("done", [], {})), G(e, K(e), "investigateHero", n);
			return;
		}
		case "askRepel": {
			let [n, ...r] = t.remaining;
			if (!n) return;
			if (!H(e, n) || !U(e, n)) {
				I(e, {
					kind: "askRepel",
					remaining: r
				});
				return;
			}
			let i = [...Ae(n, U(e, n)).values()].filter((e) => e.dist > 0 && e.dist <= 2).map((e) => e.to), a = [W("stay", [{
				kind: "askRepel",
				remaining: r
			}], { figure: n }), ...i.map((e) => W("space", [{
				kind: "moveFigure",
				figure: n,
				to: e
			}, {
				kind: "askRepel",
				remaining: r
			}], {
				figure: n,
				space: e
			}))];
			G(e, K(e), "repel", a);
			return;
		}
		case "askDeliveryFrom": {
			let t = e.heroes.filter((e) => e.items.length > 0);
			if (!t.length) return;
			G(e, K(e), "deliveryFrom", t.map((e) => W("hero", [{
				kind: "askDeliveryTo",
				from: e.id
			}], { hero: e.id })));
			return;
		}
		case "askDeliveryTo": {
			if (!z(e, t.from)) return;
			let n = e.heroes.filter((e) => e.id !== t.from);
			if (!n.length) return;
			G(e, K(e), "deliveryTo", n.map((e) => W("hero", [{
				kind: "askDeliveryItem",
				from: t.from,
				to: e.id
			}], {
				hero: e.id,
				hero2: t.from
			})));
			return;
		}
		case "askDeliveryItem": {
			let n = z(e, t.from);
			if (!n) return;
			let r = n.items.map((e) => W("item", [{
				kind: "transferItem",
				from: t.from,
				to: t.to,
				uid: e
			}, {
				kind: "askDeliveryItem",
				from: t.from,
				to: t.to
			}], {
				item: e,
				hero: t.to
			}));
			r.push(W("done", [], {})), G(e, K(e), "deliveryItem", r);
			return;
		}
		case "askAttackTarget": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = Be(e, n);
			if (r.some((e) => e.kind === "hero") && (r = r.filter((e) => e.kind === "hero")), !r.length) return;
			if (r.length === 1) {
				I(e, {
					kind: "strikeRoll",
					figure: t.figure,
					target: r[0],
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", r.map((e) => W("attack", [{
				kind: "strikeRoll",
				figure: t.figure,
				target: e,
				dice: t.dice
			}], pt(e))));
			return;
		}
		case "askGaze": {
			let t = He(e, "dracula");
			if (!t) return;
			G(e, K(e), "gaze", t.list.map((e) => W("gaze", [{
				kind: "gazeMove",
				person: e
			}], pt(e))));
			return;
		}
		case "gazeMove": {
			let n = e.monsters.dracula.space;
			if (!n) return;
			Pe(e, t.person, n, 3);
			return;
		}
	}
}
function gt(e, t) {
	return t.kind === "hero" ? z(e, t.id)?.space ?? null : e.villagers[t.id]?.space ?? null;
}
function _t(e, t) {
	switch (t) {
		case "dracula": {
			let t = R(e), n = e.monsters.dracula.space;
			if (!t || t.defeated || !n || t.space === n) return;
			t.space = n, L(e, {
				k: "charmed",
				hero: t.id,
				space: n
			});
			return;
		}
		case "creature":
			if (e.monsters.creature.boat <= 0) return;
			--e.monsters.creature.boat, L(e, {
				k: "boatBack",
				n: e.monsters.creature.boat
			});
			return;
		case "frank":
		case "bride": {
			let { frank: t, bride: n } = e.monsters.fb;
			if (!t || !n) return;
			Ne(e, "bride", t, 1);
			return;
		}
		case "mummy": {
			let t = null, n = Infinity;
			for (let r of j) {
				let i = e.monsters.mummy.slots[r];
				i.faceUp && i.num > 0 && i.num < n && (n = i.num, t = r);
			}
			if (!t) return;
			e.monsters.mummy.slots[t].faceUp = !1, L(e, {
				k: "scarabFlipped",
				slot: t
			});
			return;
		}
		case "wolfman": {
			let t = e.monsters.wolfman.space;
			if (!t) return;
			for (let n of Re(e, t)) I(e, {
				kind: "hitHero",
				hero: n
			});
			for (let n of ze(e, t)) I(e, {
				kind: "hitVillager",
				villager: n
			});
			return;
		}
		case "invisibleman": {
			let t = Ue(e, "invisibleman");
			if (!t) return;
			let n = e.villagers[t].space;
			if (!n) return;
			Ne(e, "invisibleman", n, 2);
			return;
		}
	}
}
function vt(e, t) {
	switch (t) {
		case "onTheMove":
			tt(e);
			for (let t of Object.keys(e.villagers)) e.villagers[t].status === "board" && Ie(e, t, 1);
			return;
		case "meeting": {
			let { frank: t, bride: n } = e.monsters.fb;
			t && n && Ne(e, "bride", t, 2);
			return;
		}
		case "hunt": {
			if (e.hunted === null) {
				let t = R(e);
				t && (e.hunted = t.id, L(e, {
					k: "hunted",
					hero: t.id
				}));
			}
			let t = e.hunted ? z(e, e.hunted) : null;
			if (!t || t.defeated || !t.space) return;
			Ne(e, "wolfman", t.space, 3);
			return;
		}
		case "thief":
			I(e, { kind: "askThief" });
			return;
		case "retreatLagoon":
		case "retreatRiver":
		case "retreatWaterfront": {
			let n = t === "retreatLagoon" ? "lagoon" : t === "retreatRiver" ? "river" : "waterfront";
			e.monsters.creature.space = n, L(e, {
				k: "monsterMoved",
				figure: "creature",
				space: n
			});
			return;
		}
		case "innocent":
			Ve(e, "maria");
			return;
		case "insaneSurvivor":
			Ve(e, "renfield");
			return;
		case "worriedFiancee":
			Ve(e, "elizabeth");
			return;
		case "enthralled":
			Ve(e, "lucy");
			return;
		case "delivery":
			Ve(e, "wilbur");
			return;
		case "fortuneTeller":
			Ve(e, "maleva");
			return;
		case "hurriedAssistant":
			Ve(e, "fritz");
			return;
		case "egyptianExpert":
			Ve(e, "pearson");
			return;
		case "formerEmployer":
			Ve(e, "cranley");
			return;
		case "ichthyologist":
			Ve(e, "reed");
			return;
		case "reincarnatedSoul": {
			if (e.soul === null) {
				let t = R(e);
				t && (e.soul = t.id, L(e, {
					k: "soul",
					hero: t.id
				}));
			}
			let t = e.soul ? z(e, e.soul) : null, n = e.monsters.mummy.space;
			if (!t || t.defeated || !t.space || !n) return;
			Pe(e, {
				kind: "hero",
				id: t.id
			}, n, 3);
			return;
		}
		case "hypnoticGaze":
			I(e, { kind: "askGaze" });
			return;
		case "sunrise":
			e.monsters.dracula.space = "crypt", L(e, {
				k: "monsterMoved",
				figure: "dracula",
				space: "crypt"
			});
			return;
		case "formOfTheBat": {
			let t = R(e);
			if (!t || t.defeated || !t.space) return;
			e.monsters.dracula.space = t.space, L(e, {
				k: "monsterMoved",
				figure: "dracula",
				space: t.space
			});
			return;
		}
	}
}
function yt(e, t) {
	let n = xe(t);
	switch (L(e, {
		k: "perkPlayed",
		perk: n
	}), n) {
		case "breakOfDawn":
			e.skipMonster = !0, I(e, {
				kind: "drawItems",
				n: 2
			});
			return;
		case "lateNight":
			e.actionsLeft += 2, L(e, {
				k: "actions",
				n: 2
			});
			return;
		case "overstock":
			I(e, {
				kind: "drawItems",
				n: e.players.length
			});
			return;
		case "taxiRide":
			I(e, {
				kind: "askHeroMove",
				heroes: We(e),
				steps: 99,
				carry: !1
			});
			return;
		case "rush":
			I(e, {
				kind: "askHeroMove",
				heroes: We(e),
				steps: 4,
				carry: !0
			});
			return;
		case "hurry":
			I(e, {
				kind: "askHurry",
				remaining: We(e)
			});
			return;
		case "investigation":
			I(e, { kind: "askInvestigate" });
			return;
		case "repel":
			I(e, {
				kind: "askRepel",
				remaining: Oe(e)
			});
			return;
		case "specialDelivery":
			I(e, { kind: "askDeliveryFrom" });
			return;
		case "detective":
			bt(e, ["invisibleman"]);
			return;
		case "crucifix":
			bt(e, ["dracula"]);
			return;
		case "huntedPrey":
			bt(e, ["wolfman"]);
			return;
		case "ancients":
			bt(e, ["mummy"]);
			return;
		case "showForce":
			bt(e, ["creature"]);
			return;
		case "mobJustice":
			bt(e, ["frank", "bride"]);
			return;
	}
}
function bt(e, t) {
	let n = t.filter((t) => H(e, t)), r = [];
	n.length && r.push(W("modePlace", [{
		kind: "askPlaceNamed",
		figures: n
	}])), r.push(W("modeMove", [{
		kind: "askMoveAny",
		steps: 3
	}])), G(e, K(e), "perkMode", r);
}
//#endregion
//#region src/game/actions.ts
var q = { code: "games.horrified.invalidAction" };
function xt(e, t, n) {
	if (t.type === "choose" || t.type === "tick" || e.ending) return q;
	if (t.type === "playPerk") {
		if (e.phase !== "hero" || e.prompt || e.queue.length || !e.players.includes(n)) return q;
		let r = e.heroes.find((e) => e.perks.includes(t.uid));
		return r ? (r.perks.splice(r.perks.indexOf(t.uid), 1), e.perkDiscard.push(t.uid), yt(e, t.uid), null) : q;
	}
	let r = R(e);
	if (!r || r.owner !== n || r.defeated || e.phase !== "hero" || e.prompt || e.queue.length) return q;
	if (e.mummyMoves > 0 || e.fbMoves) return t.type === "mummySlide" || t.type === "mummyFlip" || t.type === "mummyDone" ? e.mummyMoves > 0 ? St(e, t) : q : (t.type === "fbMove" || t.type === "fbDone") && e.fbMoves ? Ct(e, t) : q;
	if (t.type === "mummySlide" || t.type === "mummyFlip" || t.type === "mummyDone" || t.type === "fbMove" || t.type === "fbDone") return q;
	if (t.type === "endTurn") return e.phase = "monster", e.actionsLeft = 0, e.mummyMoves = 0, e.fbMoves = null, L(e, {
		k: "heroEnd",
		hero: r.id
	}), I(e, { kind: "monsterBegin" }), null;
	if (e.actionsLeft <= 0) return q;
	let i = r.space;
	if (!i) return q;
	switch (t.type) {
		case "move": {
			if (!Me(i, t.to)) return q;
			let n = [...new Set(t.villagers)];
			for (let t of n) {
				let n = e.villagers[t];
				if (n.status !== "board" || n.space !== i) return q;
			}
			r.space = t.to, L(e, {
				k: "heroMoved",
				hero: r.id,
				space: t.to
			});
			for (let r of n) {
				let n = e.villagers[r];
				n.space = t.to, L(e, {
					k: "villagerMoved",
					villager: r,
					space: t.to
				});
			}
			return --e.actionsLeft, Ze(e), null;
		}
		case "guide": {
			let n = e.villagers[t.villager];
			if (n.status !== "board" || !n.space) return q;
			let r = n.space === i && Me(i, t.to), a = t.to === i && Me(i, n.space);
			return !r && !a ? q : (Fe(e, t.villager, t.to), --e.actionsLeft, null);
		}
		case "pickup": {
			let n = [...new Set(t.uids)], a = e.spaceItems[i];
			if (n.some((e) => !a.includes(e))) return q;
			for (let e of n) a.splice(a.indexOf(e), 1);
			return r.items.push(...n), L(e, {
				k: "pickup",
				hero: r.id,
				n: n.length
			}), --e.actionsLeft, null;
		}
		case "share": {
			let n = z(e, t.from), r = z(e, t.to);
			if (!n || !r || n.defeated || r.defeated || n.id === r.id || n.space !== i || r.space !== i) return q;
			let a = [...new Set(t.uids)];
			if (a.some((e) => !n.items.includes(e)) || t.cure && e.monsters.wolfman.cure !== n.id || !a.length && !t.cure) return q;
			for (let t of a) n.items.splice(n.items.indexOf(t), 1), r.items.push(t), L(e, {
				k: "itemGiven",
				hero: n.id,
				hero2: r.id,
				item: t
			});
			return t.cure && (e.monsters.wolfman.cure = r.id, L(e, {
				k: "cureGiven",
				hero: n.id,
				hero2: r.id
			})), --e.actionsLeft, null;
		}
		case "advance": return wt(e, r.id, i, t.monster, t.uids);
		case "defeat": return Et(e, r.id, i, t.monster, t.uids);
		case "specialArchaeologist": {
			if (r.id !== "archaeologist" || !Me(i, t.space)) return q;
			let n = [...new Set(t.uids)];
			if (!n.length) return q;
			let a = e.spaceItems[t.space];
			if (n.some((e) => !a.includes(e))) return q;
			for (let e of n) a.splice(a.indexOf(e), 1);
			return r.items.push(...n), L(e, {
				k: "pickup",
				hero: r.id,
				n: n.length,
				space: t.space
			}), --e.actionsLeft, null;
		}
		case "specialCourier": return r.id !== "courier" || !e.heroes.some((e) => e.id !== r.id && !e.defeated && e.space === t.to) ? q : (r.space = t.to, L(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Ze(e), null);
		case "specialExplorer": return r.id !== "explorer" || y[t.to].water ? q : (r.space = t.to, L(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Ze(e), null);
		case "specialInspector": return r.id !== "inspector" || y[t.to].water || !(H(e, "dracula") && U(e, "dracula") === t.to || H(e, "creature") && U(e, "creature") === t.to || H(e, "mummy") && U(e, "mummy") === t.to || H(e, "wolfman") && U(e, "wolfman") === t.to || H(e, "invisibleman") && U(e, "invisibleman") === t.to || H(e, "frank") && U(e, "frank") === t.to || H(e, "bride") && U(e, "bride") === t.to) ? q : (r.space = t.to, L(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Ze(e), null);
		case "specialProfessor": {
			if (r.id !== "professor" || !!t.hero == !!t.villager) return q;
			let n = t.hero ? z(e, t.hero)?.space ?? null : e.villagers[t.villager].space;
			if (!n || !Me(n, t.to)) return q;
			if (t.hero) {
				let n = z(e, t.hero);
				if (!n || n.defeated) return q;
				let r = [...new Set(t.villagers)], i = n.space;
				if (r.some((t) => e.villagers[t].status !== "board" || e.villagers[t].space !== i)) return q;
				n.space = t.to, L(e, {
					k: "heroMoved",
					hero: n.id,
					space: t.to
				});
				for (let n of r) e.villagers[n].space = t.to, L(e, {
					k: "villagerMoved",
					villager: n,
					space: t.to
				});
				Ze(e);
			} else {
				if (t.villagers.length || e.villagers[t.villager].status !== "board") return q;
				Fe(e, t.villager, t.to);
			}
			return --e.actionsLeft, null;
		}
		default: return q;
	}
}
function St(e, t) {
	if (t.type === "mummyDone") return e.mummyMoves = 0, L(e, { k: "mummyDone" }), null;
	if (t.type === "mummyFlip") {
		let n = e.monsters.mummy.slots[t.slot];
		return n.num <= 0 || n.faceUp ? q : (n.faceUp = !0, --e.mummyMoves, L(e, {
			k: "scarabFlip",
			slot: t.slot
		}), null);
	}
	let n = e.monsters.mummy.slots[t.from], r = e.monsters.mummy.slots[t.to];
	return n.num <= 0 || !n.faceUp || r.num !== 0 || !M[t.from].includes(t.to) ? q : (r.num = n.num, r.faceUp = !0, n.num = 0, n.faceUp = !1, --e.mummyMoves, L(e, {
		k: "scarabSlide",
		slot: t.from
	}), null);
}
function Ct(e, t) {
	let n = e.fbMoves;
	if (!n) return q;
	if (t.type === "fbDone") return e.fbMoves = null, null;
	let r = n.figure;
	if (!H(e, r)) return q;
	let i = U(e, r);
	if (!i || i === t.to) return q;
	let a = Ae(r, i).get(t.to);
	if (!a || a.dist > n.remaining) return q;
	Ee(e, r, t.to), L(e, {
		k: "monsterMoved",
		figure: r,
		space: t.to
	});
	let o = n.remaining - a.dist;
	return e.fbMoves = o > 0 ? {
		figure: r,
		remaining: o
	} : null, null;
}
function wt(e, t, n, r, i) {
	let a = z(e, t);
	if (!H(e, r)) return q;
	let o = [...new Set(i)];
	switch (r) {
		case "dracula":
			if (!e.monsters.dracula.coffins.includes(n) || !o.length || o.some((e) => !a.items.includes(e) || V(e) !== "red") || B(t, o) < 6) return q;
			for (let t of o) a.items.splice(a.items.indexOf(t), 1), Je(e, t);
			return e.monsters.dracula.coffins = e.monsters.dracula.coffins.filter((e) => e !== n), L(e, {
				k: "coffinBroken",
				hero: t,
				space: n
			}), --e.actionsLeft, null;
		case "creature": {
			if (n !== "camp" || o.length !== 1 || !a.items.includes(o[0])) return q;
			let r = e.monsters.creature.boat;
			if (r >= A) return q;
			let i = V(o[0]), s = -1;
			for (let e = r + 1; e <= A; e++) if (k[e - 1] === i) {
				s = e;
				break;
			}
			return s < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), Je(e, o[0]), e.monsters.creature.boat = s, L(e, {
				k: "boatAdvance",
				hero: t,
				n: s
			}), --e.actionsLeft, null);
		}
		case "frank":
		case "bride": {
			if (U(e, r) !== n) return q;
			let i = r === "frank" ? "yellow" : "blue";
			if (o.length !== 1 || !a.items.includes(o[0]) || V(o[0]) !== i) return q;
			let s = we(t, o[0]);
			a.items.splice(a.items.indexOf(o[0]), 1), Je(e, o[0]);
			let c = e.monsters.fb;
			c.score[r] += s;
			let l = O[r];
			return !c.flipped[r] && c.score[r] >= l && (c.flipped[r] = !0, L(e, {
				k: "fbFlipped",
				figure: r,
				n: c.score[r]
			})), e.fbMoves = {
				figure: r,
				remaining: s
			}, L(e, {
				k: "advance",
				hero: t,
				figure: r,
				n: s
			}), --e.actionsLeft, null;
		}
		case "mummy": {
			if (n !== "museum" || o.length !== 1 || !a.items.includes(o[0]) || V(o[0]) !== "yellow") return q;
			let r = we(t, o[0]);
			return a.items.splice(a.items.indexOf(o[0]), 1), Je(e, o[0]), e.mummyMoves = r, L(e, {
				k: "mummyAdvance",
				hero: t,
				n: r
			}), --e.actionsLeft, null;
		}
		case "wolfman": {
			if (n !== "laboratory" || o.length !== 1 || !a.items.includes(o[0]) || V(o[0]) !== "blue") return q;
			let r = S[F(o[0])].strength, i = Ce(t) ? [r, r + 1] : [r], s = e.monsters.wolfman.bottles.findIndex((e, t) => e === null && i.includes(D[t]));
			return s < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), e.monsters.wolfman.bottles[s] = o[0], L(e, {
				k: "bottleFilled",
				hero: t,
				n: D[s]
			}), e.monsters.wolfman.bottles.every((e) => e !== null) && (e.monsters.wolfman.cure = t, L(e, {
				k: "cureTaken",
				hero: t
			})), --e.actionsLeft, null);
		}
		case "invisibleman": {
			if (n !== "precinct" || o.length !== 1 || !a.items.includes(o[0])) return q;
			let r = S[F(o[0])].space, i = e.monsters.invisibleman.spots.findIndex((e, t) => e === null && le[t] === r);
			return i < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), e.monsters.invisibleman.spots[i] = o[0], L(e, {
				k: "spotFilled",
				hero: t,
				space: r
			}), --e.actionsLeft, null);
		}
	}
}
function Tt(e, t, n, r) {
	let i = z(e, t);
	return !i || !n.length || n.some((e) => !i.items.includes(e) || V(e) !== "red") ? !1 : B(t, n) >= r;
}
function Et(e, t, n, r, i) {
	let a = z(e, t);
	if (!H(e, r)) return q;
	let o = [...new Set(i)];
	if (o.length !== i.length) return q;
	let s = (t, n) => {
		for (let r of t) a.items.splice(a.items.indexOf(r), 1), n && Je(e, r);
	};
	switch (r) {
		case "dracula": return U(e, "dracula") !== n || e.monsters.dracula.coffins.length || !o.length || o.some((e) => !a.items.includes(e) || V(e) !== "yellow") || B(t, o) < 6 ? q : (s(o, !0), nt(e, "dracula"), L(e, {
			k: "defeat",
			hero: t,
			monster: "dracula"
		}), --e.actionsLeft, null);
		case "creature": {
			if (U(e, "creature") !== n || e.monsters.creature.boat !== A || o.length !== 3 || o.some((e) => !a.items.includes(e))) return q;
			let r = o.map(V);
			return [
				"red",
				"blue",
				"yellow"
			].every((e) => r.includes(e)) ? (s(o, !0), nt(e, "creature"), L(e, {
				k: "defeat",
				hero: t,
				monster: "creature"
			}), --e.actionsLeft, null) : q;
		}
		case "mummy": return U(e, "mummy") !== n || !rt(e) || !Tt(e, t, o, 9) ? q : (s(o, !0), nt(e, "mummy"), L(e, {
			k: "defeat",
			hero: t,
			monster: "mummy"
		}), --e.actionsLeft, null);
		case "wolfman": return U(e, "wolfman") !== n || e.monsters.wolfman.cure !== t || !Tt(e, t, o, 6) ? q : (s(o, !0), e.monsters.wolfman.cure = null, nt(e, "wolfman"), L(e, {
			k: "defeat",
			hero: t,
			monster: "wolfman"
		}), --e.actionsLeft, null);
		case "invisibleman": return U(e, "invisibleman") !== n || e.monsters.invisibleman.spots.some((e) => e === null) || !Tt(e, t, o, 9) ? q : (s(o, !0), nt(e, "invisibleman"), L(e, {
			k: "defeat",
			hero: t,
			monster: "invisibleman"
		}), --e.actionsLeft, null);
		case "frank":
		case "bride": return q;
	}
}
//#endregion
//#region src/game/schema.ts
var Dt = t.object({ monsters: t.array(t.enum(T)).min(1).max(4).refine((e) => new Set(e).size === e.length).default(["creature", "dracula"]) }).prefault({}), J = t.enum(C), Y = t.enum(v), Ot = t.enum(se), kt = t.enum(_e), X = t.string().min(1).max(40), At = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		to: Y,
		villagers: t.array(Ot).max(10).default([])
	}),
	t.object({
		type: t.literal("guide"),
		villager: Ot,
		to: Y
	}),
	t.object({
		type: t.literal("pickup"),
		uids: t.array(X).min(1).max(12)
	}),
	t.object({
		type: t.literal("share"),
		from: J,
		to: J,
		uids: t.array(X).max(12).default([]),
		cure: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("advance"),
		monster: kt,
		uids: t.array(X).max(12)
	}),
	t.object({
		type: t.literal("defeat"),
		monster: kt,
		uids: t.array(X).max(12)
	}),
	t.object({
		type: t.literal("mummySlide"),
		from: t.enum(j),
		to: t.enum(j)
	}),
	t.object({
		type: t.literal("mummyFlip"),
		slot: t.enum(j)
	}),
	t.object({ type: t.literal("mummyDone") }),
	t.object({
		type: t.literal("fbMove"),
		to: Y
	}),
	t.object({ type: t.literal("fbDone") }),
	t.object({
		type: t.literal("specialArchaeologist"),
		space: Y,
		uids: t.array(X).min(1).max(12)
	}),
	t.object({
		type: t.literal("specialCourier"),
		to: Y
	}),
	t.object({
		type: t.literal("specialExplorer"),
		to: Y
	}),
	t.object({
		type: t.literal("specialInspector"),
		to: Y
	}),
	t.object({
		type: t.literal("specialProfessor"),
		hero: J.optional(),
		villager: Ot.optional(),
		to: Y,
		villagers: t.array(Ot).max(10).default([])
	}),
	t.object({
		type: t.literal("playPerk"),
		uid: X
	}),
	t.object({
		type: t.literal("choose"),
		decision: t.int().nonnegative(),
		choice: t.string().min(1).max(80)
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), jt = t.object({
	id: t.string(),
	kind: t.string(),
	hero: J.optional(),
	hero2: J.optional(),
	figure: kt.optional(),
	villager: Ot.optional(),
	space: Y.optional(),
	slot: t.enum(j).optional(),
	item: X.optional()
}), Mt = t.object({
	decision: t.int().nonnegative(),
	kind: t.string(),
	owners: t.array(t.string()),
	options: t.array(jt)
}), Nt = t.object({
	uid: X,
	type: t.enum(x)
}), Pt = t.object({
	id: Ot,
	status: t.enum([
		"none",
		"board",
		"safe",
		"defeated"
	]),
	space: Y.nullable()
}), Ft = t.object({
	id: J,
	owner: t.string(),
	space: Y.nullable(),
	items: t.array(Nt),
	perks: t.array(t.object({
		uid: X,
		id: t.string()
	})),
	defeated: t.boolean()
}), It = t.object({
	k: t.string(),
	hero: J.optional(),
	hero2: J.optional(),
	figure: kt.optional(),
	monster: t.enum(T).optional(),
	villager: Ot.optional(),
	space: Y.optional(),
	perk: t.enum(fe).optional(),
	item: X.optional(),
	slot: t.enum(j).optional(),
	n: t.int().optional(),
	n2: t.int().optional(),
	ok: t.boolean().optional()
}), Lt = t.object({
	num: t.int().min(0).max(6),
	faceUp: t.boolean()
}), Rt = t.record(t.enum(j), Lt), zt = t.object({
	chosen: t.array(t.enum(T)),
	phase: t.enum([
		"hero",
		"monster",
		"done"
	]),
	terror: t.int().min(0).max(7),
	turn: t.object({
		owner: t.string(),
		hero: J,
		actionsLeft: t.int().nonnegative(),
		actionsMax: t.int().nonnegative()
	}),
	heroes: t.array(Ft),
	villagers: t.record(Ot, Pt),
	monsters: t.object({
		dracula: t.object({
			space: Y.nullable(),
			coffins: t.array(Y)
		}).nullable(),
		creature: t.object({
			space: Y.nullable(),
			boat: t.int().min(0).max(19)
		}).nullable(),
		fb: t.object({
			frank: Y.nullable(),
			bride: Y.nullable(),
			score: t.object({
				frank: t.int().nonnegative(),
				bride: t.int().nonnegative()
			}),
			flipped: t.object({
				frank: t.boolean(),
				bride: t.boolean()
			})
		}).nullable(),
		mummy: t.object({
			space: Y.nullable(),
			slots: Rt
		}).nullable(),
		wolfman: t.object({
			space: Y.nullable(),
			bottles: t.array(X.nullable()),
			cure: J.nullable()
		}).nullable(),
		invisibleman: t.object({
			space: Y.nullable(),
			spots: t.array(X.nullable())
		}).nullable()
	}),
	defeated: t.array(t.enum(T)),
	frenzy: t.enum(T),
	hunted: J.nullable(),
	soul: J.nullable(),
	spaceItems: t.array(t.object({
		space: Y,
		items: t.array(Nt)
	})),
	bagCount: t.int().nonnegative(),
	itemDiscardCount: t.int().nonnegative(),
	perkDeckCount: t.int().nonnegative(),
	perkDiscardCount: t.int().nonnegative(),
	monsterDeckCount: t.int().nonnegative(),
	monsterDiscardCount: t.int().nonnegative(),
	cardIndex: t.int().nonnegative().nullable(),
	lastRoll: t.object({
		figure: kt,
		dice: t.array(t.int().min(0).max(5)),
		hits: t.int().nonnegative(),
		powers: t.int().nonnegative()
	}).nullable(),
	mummyMoves: t.int().nonnegative(),
	fbMoves: t.object({
		figure: t.enum(["frank", "bride"]),
		remaining: t.int().nonnegative()
	}).nullable(),
	skipMonster: t.boolean(),
	prompt: Mt.nullable(),
	ending: t.object({
		win: t.boolean(),
		reason: t.enum([
			"triumph",
			"terror",
			"time"
		])
	}).nullable(),
	log: t.array(It)
}), Bt = t.object({});
//#endregion
//#region src/game/rules.ts
function Vt(e, t, n) {
	let r = e.monsters, i = {
		config: { monsters: r },
		players: [...t],
		heroes: [],
		villagers: Object.fromEntries(se.map((e) => [e, {
			id: e,
			status: "none",
			space: null
		}])),
		monsters: {
			dracula: {
				space: null,
				coffins: [...ce]
			},
			creature: {
				space: null,
				boat: 0
			},
			fb: {
				frank: null,
				bride: null,
				score: {
					frank: 0,
					bride: 0
				},
				flipped: {
					frank: !1,
					bride: !1
				}
			},
			mummy: {
				space: null,
				slots: {}
			},
			wolfman: {
				space: null,
				bottles: Array.from({ length: 6 }, () => null),
				cure: null
			},
			invisibleman: {
				space: null,
				spots: Array.from({ length: 5 }, () => null)
			}
		},
		defeated: [],
		frenzy: r.reduce((e, t) => E[e] <= E[t] ? e : t),
		hunted: null,
		soul: null,
		spaceItems: Object.fromEntries(v.map((e) => [e, []])),
		bag: [],
		itemDiscard: [],
		perkDeck: [],
		perkDiscard: [],
		monsterDeck: [],
		monsterDiscard: [],
		cardIndex: null,
		lastRoll: null,
		terror: t.length === 1 ? 3 : 0,
		turn: 0,
		phase: "hero",
		actionsLeft: 0,
		mummyMoves: 0,
		fbMoves: null,
		skipMonster: !1,
		queue: [],
		prompt: null,
		decision: 0,
		seed: n,
		cursor: 0,
		ending: null,
		log: []
	}, a = /* @__PURE__ */ new Map();
	i.bag = Ge(i, ae.map((e) => {
		let t = a.get(e) ?? 0;
		return a.set(e, t + 1), ye(e, t);
	})), i.monsterDeck = Ge(i, Array.from({ length: 30 }, (e, t) => t));
	let o = /* @__PURE__ */ new Map();
	if (i.perkDeck = Ge(i, pe.filter((e) => t.length !== 1 || e !== "specialDelivery" && e !== "investigation").map((e) => {
		let t = o.get(e) ?? 0;
		return o.set(e, t + 1), be(e, t);
	})), r.includes("dracula") && (i.monsters.dracula.space = "crypt"), r.includes("creature") && (i.monsters.creature.space = "lagoon"), r.includes("frankenstein") && (i.monsters.fb.frank = "graveyard", i.monsters.fb.bride = "dungeon"), r.includes("mummy")) {
		i.monsters.mummy.space = "museum";
		let e = Ge(i, [
			1,
			2,
			3
		]), t = Ge(i, [
			4,
			5,
			6
		]), n = i.monsters.mummy.slots;
		n[1] = {
			num: t[0],
			faceUp: !0
		}, n[2] = {
			num: t[1],
			faceUp: !0
		}, n[3] = {
			num: t[2],
			faceUp: !0
		}, n[4] = {
			num: e[0],
			faceUp: !0
		}, n[5] = {
			num: e[1],
			faceUp: !0
		}, n[6] = {
			num: e[2],
			faceUp: !0
		}, n.D = {
			num: 0,
			faceUp: !1
		};
	}
	r.includes("wolfman") && (i.monsters.wolfman.space = "mansion"), r.includes("invisibleman") && (i.monsters.invisibleman.space = "inn");
	let s = Ge(i, C.filter((e) => t.length !== 1 || e !== "courier"));
	i.heroes = t.map((e, t) => {
		let n = s[t % s.length];
		return {
			id: n,
			owner: e,
			space: oe[n].start,
			items: [],
			perks: [],
			defeated: !1
		};
	});
	for (let e of i.heroes) Ye(i, e.id);
	for (let e = 0; e < 12 && i.bag.length; e += 1) {
		let e = i.bag.pop();
		i.spaceItems[S[F(e)].space].push(e);
	}
	return i.actionsLeft = ft(i.heroes[0].id), i.heroes[0] && L(i, {
		k: "turnStart",
		hero: i.heroes[0].id
	}), { state: i };
}
function Ht(e, t, n) {
	if (e.ending) return { code: "games.horrified.invalidAction" };
	if (t.type === "choose") {
		let r = e.prompt;
		if (!r || !r.owners.includes(n.by) || t.decision !== r.decision) return { code: "games.horrified.invalidAction" };
		let i = r.options.find((e) => e.id === t.choice);
		if (!i) return { code: "games.horrified.invalidAction" };
		let a = structuredClone(e);
		return a.prompt = null, I(a, ...i.ops), st(a), { state: a };
	}
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.prompt || !e.queue.length) return { code: "games.horrified.invalidAction" };
		let t = structuredClone(e);
		return ht(t, t.queue.shift()), st(t), { state: t };
	}
	let r = structuredClone(e);
	return xt(r, t, n.by) || (st(r), { state: r });
}
function Ut(e) {
	return e ? {
		decision: e.decision,
		kind: e.kind,
		owners: [...e.owners],
		options: e.options.map((e) => ({
			id: e.id,
			kind: e.kind,
			hero: e.hero,
			hero2: e.hero2,
			figure: e.figure,
			villager: e.villager,
			space: e.space,
			slot: e.slot,
			item: e.item
		}))
	} : null;
}
function Wt(e) {
	return Object.fromEntries(j.map((t) => [t, { ...e.monsters.mummy.slots[t] }]));
}
function Gt(e) {
	let t = R(e), n = (t) => e.config.monsters.includes(t) && !e.defeated.includes(t);
	return { public: {
		chosen: [...e.config.monsters],
		phase: e.phase,
		terror: e.terror,
		turn: {
			owner: t?.owner ?? "",
			hero: t?.id ?? e.heroes[0].id,
			actionsLeft: e.actionsLeft,
			actionsMax: t ? ft(t.id) : 0
		},
		heroes: e.heroes.map((e) => ({
			id: e.id,
			owner: e.owner,
			space: e.space,
			items: e.items.map((e) => ({
				uid: e,
				type: F(e)
			})),
			perks: e.perks.map((e) => ({
				uid: e,
				id: xe(e)
			})),
			defeated: e.defeated
		})),
		villagers: Object.fromEntries(se.map((t) => [t, { ...e.villagers[t] }])),
		monsters: {
			dracula: n("dracula") ? {
				space: e.monsters.dracula.space,
				coffins: [...e.monsters.dracula.coffins]
			} : null,
			creature: n("creature") ? {
				space: e.monsters.creature.space,
				boat: e.monsters.creature.boat
			} : null,
			fb: n("frankenstein") ? {
				frank: e.monsters.fb.frank,
				bride: e.monsters.fb.bride,
				score: { ...e.monsters.fb.score },
				flipped: { ...e.monsters.fb.flipped }
			} : null,
			mummy: n("mummy") ? {
				space: e.monsters.mummy.space,
				slots: Wt(e)
			} : null,
			wolfman: n("wolfman") ? {
				space: e.monsters.wolfman.space,
				bottles: [...e.monsters.wolfman.bottles],
				cure: e.monsters.wolfman.cure
			} : null,
			invisibleman: n("invisibleman") ? {
				space: e.monsters.invisibleman.space,
				spots: [...e.monsters.invisibleman.spots]
			} : null
		},
		defeated: [...e.defeated],
		frenzy: e.frenzy,
		hunted: e.hunted,
		soul: e.soul,
		spaceItems: v.map((t) => ({
			space: t,
			items: e.spaceItems[t].map((e) => ({
				uid: e,
				type: F(e)
			}))
		})),
		bagCount: e.bag.length,
		itemDiscardCount: e.itemDiscard.length,
		perkDeckCount: e.perkDeck.length,
		perkDiscardCount: e.perkDiscard.length,
		monsterDeckCount: e.monsterDeck.length,
		monsterDiscardCount: e.monsterDiscard.length,
		cardIndex: e.cardIndex,
		lastRoll: e.lastRoll ? {
			...e.lastRoll,
			dice: [...e.lastRoll.dice]
		} : null,
		mummyMoves: e.mummyMoves,
		fbMoves: e.fbMoves ? { ...e.fbMoves } : null,
		skipMonster: e.skipMonster,
		prompt: Ut(e.prompt),
		ending: e.ending ? { ...e.ending } : null,
		log: e.log.map((e) => ({ ...e }))
	} };
}
var Kt = {
	meta: ge,
	saveCompatibility: { version: "1" },
	schemas: {
		action: At,
		config: Dt,
		publicView: zt,
		privateView: Bt
	},
	setup: Vt,
	reduce: Ht,
	viewFor: Gt,
	status(e) {
		if (!e.ending) return { phase: e.phase };
		let t = [...e.players];
		return {
			phase: "done",
			winner: e.ending.win ? [...t] : [],
			ranking: t
		};
	},
	nextTickIn: (e) => !e.ending && !e.prompt && e.queue.length ? 420 : null
}, qt = {
	red: "games.horrified.colorRed",
	blue: "games.horrified.colorBlue",
	yellow: "games.horrified.colorYellow"
}, Jt = {
	cave: "games.horrified.spaceCave",
	camp: "games.horrified.spaceCamp",
	precinct: "games.horrified.spacePrecinct",
	inn: "games.horrified.spaceInn",
	barn: "games.horrified.spaceBarn",
	dungeon: "games.horrified.spaceDungeon",
	lagoon: "games.horrified.spaceLagoon",
	bridgeWest: "games.horrified.spaceBridgeWest",
	fountain: "games.horrified.spaceFountain",
	lamp: "games.horrified.spaceLamp",
	mansion: "games.horrified.spaceMansion",
	abbey: "games.horrified.spaceAbbey",
	crypt: "games.horrified.spaceCrypt",
	museum: "games.horrified.spaceMuseum",
	church: "games.horrified.spaceChurch",
	hospital: "games.horrified.spaceHospital",
	graveyard: "games.horrified.spaceGraveyard",
	laboratory: "games.horrified.spaceLaboratory",
	institute: "games.horrified.spaceInstitute",
	waterfront: "games.horrified.spaceWaterfront",
	docks: "games.horrified.spaceDocks",
	tower: "games.horrified.spaceTower",
	theatre: "games.horrified.spaceTheatre",
	river: "games.horrified.spaceRiver",
	bridgeEast: "games.horrified.spaceBridgeEast",
	shop: "games.horrified.spaceShop"
}, Yt = {
	beartrap: "games.horrified.itemBeartrap",
	rapier: "games.horrified.itemRapier",
	pistol: "games.horrified.itemPistol",
	silvercane: "games.horrified.itemSilvercane",
	shovel: "games.horrified.itemShovel",
	pitchfork: "games.horrified.itemPitchfork",
	dart: "games.horrified.itemDart",
	knife: "games.horrified.itemKnife",
	firepoker: "games.horrified.itemFirepoker",
	torch: "games.horrified.itemTorch",
	speargun: "games.horrified.itemSpeargun",
	rifle: "games.horrified.itemRifle",
	research: "games.horrified.itemResearch",
	anatomy: "games.horrified.itemAnatomy",
	kite: "games.horrified.itemKite",
	rotenone: "games.horrified.itemRotenone",
	centrifuge: "games.horrified.itemCentrifuge",
	fossil: "games.horrified.itemFossil",
	analysis: "games.horrified.itemAnalysis",
	telescope: "games.horrified.itemTelescope",
	experiment: "games.horrified.itemExperiment",
	searchlight: "games.horrified.itemSearchlight",
	camera: "games.horrified.itemCamera",
	cosmicray: "games.horrified.itemCosmicray",
	monocane: "games.horrified.itemMonocane",
	nebularium: "games.horrified.itemNebularium",
	tablet: "games.horrified.itemTablet",
	flower: "games.horrified.itemFlower",
	wine: "games.horrified.itemWine",
	garlic: "games.horrified.itemGarlic",
	charm: "games.horrified.itemCharm",
	tarot: "games.horrified.itemTarot",
	mirroredbox: "games.horrified.itemMirroredbox",
	crucifix: "games.horrified.itemCrucifix",
	wolfsbane: "games.horrified.itemWolfsbane",
	violin: "games.horrified.itemViolin",
	stake: "games.horrified.itemStake",
	scroll: "games.horrified.itemScroll",
	canopic: "games.horrified.itemCanopic"
}, Xt = {
	archaeologist: "games.horrified.heroArchaeologist",
	courier: "games.horrified.heroCourier",
	explorer: "games.horrified.heroExplorer",
	inspector: "games.horrified.heroInspector",
	mayor: "games.horrified.heroMayor",
	professor: "games.horrified.heroProfessor",
	scientist: "games.horrified.heroScientist"
}, Zt = {
	archaeologist: "games.horrified.heroArchaeologistShort",
	courier: "games.horrified.heroCourierShort",
	explorer: "games.horrified.heroExplorerShort",
	inspector: "games.horrified.heroInspectorShort",
	mayor: "games.horrified.heroMayorShort",
	professor: "games.horrified.heroProfessorShort",
	scientist: "games.horrified.heroScientistShort"
}, Qt = {
	fritz: "games.horrified.villagerFritz",
	maria: "games.horrified.villagerMaria",
	maleva: "games.horrified.villagerMaleva",
	pearson: "games.horrified.villagerPearson",
	wilbur: "games.horrified.villagerWilbur",
	renfield: "games.horrified.villagerRenfield",
	reed: "games.horrified.villagerReed",
	cranley: "games.horrified.villagerCranley",
	lucy: "games.horrified.villagerLucy",
	elizabeth: "games.horrified.villagerElizabeth"
}, $t = {
	fritz: "games.horrified.villagerFritzShort",
	maria: "games.horrified.villagerMariaShort",
	maleva: "games.horrified.villagerMalevaShort",
	pearson: "games.horrified.villagerPearsonShort",
	wilbur: "games.horrified.villagerWilburShort",
	renfield: "games.horrified.villagerRenfieldShort",
	reed: "games.horrified.villagerReedShort",
	cranley: "games.horrified.villagerCranleyShort",
	lucy: "games.horrified.villagerLucyShort",
	elizabeth: "games.horrified.villagerElizabethShort"
}, en = {
	dracula: "games.horrified.monsterDracula",
	mummy: "games.horrified.monsterMummy",
	frankenstein: "games.horrified.monsterFrankenstein",
	creature: "games.horrified.monsterCreature",
	wolfman: "games.horrified.monsterWolfman",
	invisibleman: "games.horrified.monsterInvisibleman"
}, tn = {
	dracula: "games.horrified.monsterDracula",
	mummy: "games.horrified.monsterMummy",
	frank: "games.horrified.monsterFrankenstein",
	bride: "games.horrified.monsterBride",
	creature: "games.horrified.monsterCreature",
	wolfman: "games.horrified.monsterWolfman",
	invisibleman: "games.horrified.monsterInvisibleman"
}, nn = {
	dracula: "games.horrified.monsterDraculaShort",
	mummy: "games.horrified.monsterMummyShort",
	frank: "games.horrified.monsterFrankShort",
	bride: "games.horrified.monsterBrideShort",
	creature: "games.horrified.monsterCreatureShort",
	wolfman: "games.horrified.monsterWolfmanShort",
	invisibleman: "games.horrified.monsterInvisiblemanShort"
}, rn = {
	dracula: {
		advance: "games.horrified.monsterDraculaAdvance",
		defeat: "games.horrified.monsterDraculaDefeat",
		power: "games.horrified.monsterDraculaPower"
	},
	mummy: {
		advance: "games.horrified.monsterMummyAdvance",
		defeat: "games.horrified.monsterMummyDefeat",
		power: "games.horrified.monsterMummyPower"
	},
	frankenstein: {
		advance: "games.horrified.monsterFrankensteinAdvance",
		defeat: "games.horrified.monsterFrankensteinDefeat",
		power: "games.horrified.monsterFrankensteinPower"
	},
	creature: {
		advance: "games.horrified.monsterCreatureAdvance",
		defeat: "games.horrified.monsterCreatureDefeat",
		power: "games.horrified.monsterCreaturePower"
	},
	wolfman: {
		advance: "games.horrified.monsterWolfmanAdvance",
		defeat: "games.horrified.monsterWolfmanDefeat",
		power: "games.horrified.monsterWolfmanPower"
	},
	invisibleman: {
		advance: "games.horrified.monsterInvisiblemanAdvance",
		defeat: "games.horrified.monsterInvisiblemanDefeat",
		power: "games.horrified.monsterInvisiblemanPower"
	}
}, an = {
	breakOfDawn: "games.horrified.perkBreakOfDawn",
	lateNight: "games.horrified.perkLateNight",
	detective: "games.horrified.perkDetective",
	taxiRide: "games.horrified.perkTaxiRide",
	crucifix: "games.horrified.perkCrucifix",
	rush: "games.horrified.perkRush",
	mobJustice: "games.horrified.perkMobJustice",
	overstock: "games.horrified.perkOverstock",
	specialDelivery: "games.horrified.perkSpecialDelivery",
	hurry: "games.horrified.perkHurry",
	investigation: "games.horrified.perkInvestigation",
	huntedPrey: "games.horrified.perkHuntedPrey",
	ancients: "games.horrified.perkAncients",
	showForce: "games.horrified.perkShowForce",
	repel: "games.horrified.perkRepel"
}, on = {
	turnStart: "games.horrified.logTurnStart",
	heroEnd: "games.horrified.logHeroEnd",
	heroMoved: "games.horrified.logHeroMoved",
	villagerMoved: "games.horrified.logVillagerMoved",
	pickup: "games.horrified.logPickup",
	itemGiven: "games.horrified.logItemGiven",
	cureGiven: "games.horrified.logCureGiven",
	advance: "games.horrified.logAdvance",
	defeat: "games.horrified.logDefeat",
	monsterDefeated: "games.horrified.logMonsterDefeated",
	coffinBroken: "games.horrified.logCoffinBroken",
	boatAdvance: "games.horrified.logBoatAdvance",
	boatBack: "games.horrified.logBoatBack",
	bottleFilled: "games.horrified.logBottleFilled",
	cureTaken: "games.horrified.logCureTaken",
	spotFilled: "games.horrified.logSpotFilled",
	mummyAdvance: "games.horrified.logMummyAdvance",
	scarabSlide: "games.horrified.logScarabSlide",
	scarabFlip: "games.horrified.logScarabFlip",
	scarabFlipped: "games.horrified.logScarabFlipped",
	mummyDone: "games.horrified.logMummyDone",
	fbFlipped: "games.horrified.logFbFlipped",
	fbMeet: "games.horrified.logFbMeet",
	fbDefeated: "games.horrified.logFbDefeated",
	itemPlaced: "games.horrified.logItemPlaced",
	terror: "games.horrified.logTerror",
	heroDefeated: "games.horrified.logHeroDefeated",
	villagerDefeated: "games.horrified.logVillagerDefeated",
	villagerPlaced: "games.horrified.logVillagerPlaced",
	rescued: "games.horrified.logRescued",
	revived: "games.horrified.logRevived",
	monsterCard: "games.horrified.logMonsterCard",
	monsterMoved: "games.horrified.logMonsterMoved",
	monsterSkipped: "games.horrified.logMonsterSkipped",
	monsterWillSkip: "games.horrified.logMonsterWillSkip",
	roll: "games.horrified.logRoll",
	hitHero: "games.horrified.logHitHero",
	hitVillager: "games.horrified.logHitVillager",
	defended: "games.horrified.logDefended",
	charmed: "games.horrified.logCharmed",
	hunted: "games.horrified.logHunted",
	soul: "games.horrified.logSoul",
	frenzyMoved: "games.horrified.logFrenzyMoved",
	perkGain: "games.horrified.logPerkGain",
	perkPlayed: "games.horrified.logPerkPlayed",
	actions: "games.horrified.logActions",
	thief: "games.horrified.logThief",
	eventIgnored: "games.horrified.logEventIgnored",
	win: "games.horrified.logWin",
	lose: "games.horrified.logLose",
	frenzy: "games.horrified.logFrenzy",
	moved: "games.horrified.logMoved",
	attack: "games.horrified.logAttack"
}, sn = {
	attack: "games.horrified.promptAttack",
	defend: "games.horrified.promptDefend",
	thief: "games.horrified.promptThief",
	placeFigure: "games.horrified.promptPlaceFigure",
	figureDest: "games.horrified.promptFigureDest",
	moveFigure: "games.horrified.promptMoveFigure",
	heroDest: "games.horrified.promptHeroDest",
	moveHero: "games.horrified.promptMoveHero",
	carry: "games.horrified.promptCarry",
	hurry: "games.horrified.promptHurry",
	investigate: "games.horrified.promptInvestigate",
	investigateHero: "games.horrified.promptInvestigateHero",
	repel: "games.horrified.promptRepel",
	deliveryFrom: "games.horrified.promptDeliveryFrom",
	deliveryTo: "games.horrified.promptDeliveryTo",
	deliveryItem: "games.horrified.promptDeliveryItem",
	gaze: "games.horrified.promptGaze",
	perkMode: "games.horrified.promptPerkMode"
}, cn = {
	dracula: "#7b3fb5",
	mummy: "#b58b3f",
	frankenstein: "#4f7d4a",
	creature: "#2f7d8f",
	wolfman: "#8c5a2f",
	invisibleman: "#6b6f8a"
}, Z = (e, t) => t(Jt[e]), Q = (e, t) => t(Xt[e]), ln = (e, t) => t(Zt[e]), $ = (e, t) => t(Qt[e]), un = (e, t) => t($t[e]), dn = (e, t) => t(en[e]), fn = (e, t) => t(tn[e]), pn = (e, t) => t(nn[e]), mn = (e, t) => t(Yt[F(e)]), hn = (e, t) => t(an[xe(e)]), gn = (e, t) => t(qt[e]), _n = (e) => S[e].color, vn = (e, t) => S[e].strength + +(t === "scientist"), yn = (e, t) => vn(F(e), t), bn = (e, t) => e.items.filter((e) => _n(e.type) === t), xn = (e, t) => t.reduce((t, n) => t + yn(n, e.id), 0);
function Sn(e, t) {
	let n = [], r = e.monsters;
	return r.dracula?.space === t && n.push({
		figure: "dracula",
		monster: "dracula"
	}), r.creature?.space === t && n.push({
		figure: "creature",
		monster: "creature"
	}), r.fb?.frank === t && n.push({
		figure: "frank",
		monster: "frankenstein"
	}), r.fb?.bride === t && n.push({
		figure: "bride",
		monster: "frankenstein"
	}), r.mummy?.space === t && n.push({
		figure: "mummy",
		monster: "mummy"
	}), r.wolfman?.space === t && n.push({
		figure: "wolfman",
		monster: "wolfman"
	}), r.invisibleman?.space === t && n.push({
		figure: "invisibleman",
		monster: "invisibleman"
	}), n;
}
function Cn(e, t) {
	return e.heroes.filter((e) => !e.defeated && e.space === t);
}
function wn(e, t) {
	return Object.values(e.villagers).filter((e) => e.status === "board" && e.space === t).map((e) => e.id);
}
function Tn(e, t) {
	return e.spaceItems.find((e) => e.space === t)?.items.map((e) => e.uid) ?? [];
}
var En = (e) => e.D.num === 0 && [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6"
].every((t) => e[t].faceUp && e[t].num === Number(t)), Dn = (e) => k[e] ?? k[A - 1];
function On(e, t) {
	let n = t.space;
	if (!n) return [];
	let r = e.monsters, i = [], a = bn(t, "red").map((e) => e.uid), o = bn(t, "blue").map((e) => e.uid), s = bn(t, "yellow").map((e) => e.uid), c = (e) => e.reduce((e, n) => e + yn(n, t.id), 0);
	if (r.dracula && (r.dracula.coffins.includes(n) && c(a) >= 6 ? i.push({
		mode: "advance",
		monster: "dracula",
		figure: "dracula",
		uids: a,
		single: !1,
		need: 6
	}) : r.dracula.space === n && r.dracula.coffins.length === 0 && c(s) >= 6 && i.push({
		mode: "defeat",
		monster: "dracula",
		figure: "dracula",
		uids: s,
		single: !1,
		need: 6
	})), r.creature && r.creature.boat < A && n === "camp") {
		let e = Dn(r.creature.boat), n = t.items.filter((t) => _n(t.type) === e).map((e) => e.uid);
		n.length && i.push({
			mode: "advance",
			monster: "creature",
			figure: "creature",
			uids: n,
			single: !0,
			need: 1
		});
	}
	if (r.creature && r.creature.space === n && r.creature.boat === A) {
		let e = bn(t, "red")[0], n = bn(t, "blue")[0], r = bn(t, "yellow")[0];
		e && n && r && i.push({
			mode: "defeat",
			monster: "creature",
			figure: "creature",
			uids: [
				e.uid,
				n.uid,
				r.uid
			],
			single: !1,
			need: 3
		});
	}
	if (r.fb && (n === r.fb.frank && s.length && i.push({
		mode: "advance",
		monster: "frankenstein",
		figure: "frank",
		uids: s,
		single: !0,
		need: 1
	}), n === r.fb.bride && o.length && i.push({
		mode: "advance",
		monster: "frankenstein",
		figure: "bride",
		uids: o,
		single: !0,
		need: 1
	})), r.mummy && (n === "museum" && s.length && i.push({
		mode: "advance",
		monster: "mummy",
		figure: "mummy",
		uids: s,
		single: !0,
		need: 1
	}), n === r.mummy.space && En(r.mummy.slots) && c(a) >= 9 && i.push({
		mode: "defeat",
		monster: "mummy",
		figure: "mummy",
		uids: a,
		single: !1,
		need: 9
	})), r.wolfman) {
		if (n === "laboratory") {
			let e = o.filter((e) => {
				let n = S[F(e)].strength;
				return r.wolfman.bottles.some((e, r) => e === null && (D[r] === n || D[r] === n + +(t.id === "scientist")));
			});
			e.length && i.push({
				mode: "advance",
				monster: "wolfman",
				figure: "wolfman",
				uids: e,
				single: !0,
				need: 1
			});
		}
		n === r.wolfman.space && r.wolfman.cure === t.id && c(a) >= 6 && i.push({
			mode: "defeat",
			monster: "wolfman",
			figure: "wolfman",
			uids: a,
			single: !1,
			need: 6
		});
	}
	if (r.invisibleman) {
		if (n === "precinct") {
			let e = t.items.filter((e) => le.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t)).map((e) => e.uid);
			e.length && i.push({
				mode: "advance",
				monster: "invisibleman",
				figure: "invisibleman",
				uids: e,
				single: !0,
				need: 1
			});
		}
		n === r.invisibleman.space && r.invisibleman.spots.every((e) => e !== null) && c(a) >= 9 && i.push({
			mode: "defeat",
			monster: "invisibleman",
			figure: "invisibleman",
			uids: a,
			single: !1,
			need: 9
		});
	}
	return i;
}
function kn(e, t) {
	if (t.single) return t.uids.slice(0, 1);
	if (t.monster === "creature") return t.uids.slice(0, 3);
	let n = [...t.uids].sort((t, n) => yn(t, e.id) - yn(n, e.id)), r = [], i = 0;
	for (let a of n) {
		if (i >= t.need) break;
		r.push(a), i += yn(a, e.id);
	}
	return r;
}
function An(e, t, n) {
	if (t.single) return n.length === 1;
	if (t.monster === "creature") {
		let e = new Set(n.map((e) => _n(F(e))));
		return n.length === 3 && e.has("red") && e.has("blue") && e.has("yellow");
	}
	return xn(e, n) >= t.need;
}
function jn(e, t) {
	return !t || t.defeated || !t.space ? null : t.id === "explorer" ? Object.keys(y).filter((e) => !y[e].water) : t.id === "courier" ? e.heroes.filter((e) => !e.defeated && e.id !== t.id && e.space && e.space !== t.space).map((e) => e.space) : t.id === "inspector" ? Object.keys(y).filter((t) => !y[t].water && Sn(e, t).length > 0) : null;
}
function Mn(e) {
	return b[e].filter((e) => !y[e].water);
}
function Nn(e, t) {
	return [...me(e, he).values()].filter((e) => e.dist > 0 && e.dist <= t).map((e) => e.to);
}
function Pn(e, t) {
	let n = e.hero ? Q(e.hero, t) : "", r = e.hero2 ? Q(e.hero2, t) : "";
	if (e.k === "hit") return e.villager ? t("games.horrified.logHitVillager", { villager: $(e.villager, t) }) : t("games.horrified.logHitHero", { hero: n });
	if (e.k === "win") return t("games.horrified.logWin");
	if (e.k === "lose") return t("games.horrified.logLose");
	let i = on[e.k];
	if (!i) return "";
	let a = {
		hero: n,
		hero2: r,
		n: e.n ?? 0,
		n2: e.n2 ?? 0
	};
	return e.figure && (a.figure = fn(e.figure, t)), e.monster && (a.monster = dn(e.monster, t)), e.villager && (a.villager = $(e.villager, t)), e.space && (a.space = Z(e.space, t)), e.perk && (a.perk = hn(e.perk, t)), e.item && (a.item = mn(e.item, t)), t(i, a);
}
//#endregion
//#region src/game/board.tsx
var Fn = {
	w: 1e3,
	h: 1003
}, In = 112, Ln = Object.keys(y), Rn = (e) => ({
	x: y[e].x - In / 2,
	y: y[e].y - In / 2,
	w: In,
	h: In
});
function zn({ pub: e, members: t, eligible: n, onSpace: r }) {
	let i = s(), a = (n ?? Ln).map((e) => ({
		key: e,
		rect: Rn(e)
	}));
	return /* @__PURE__ */ h("div", {
		className: "hf-board",
		role: "group",
		"aria-label": i("games.horrified.boardLabel"),
		children: /* @__PURE__ */ h(m, {
			image: ne("games/horrified/board.webp"),
			sheetW: Fn.w,
			sheetH: Fn.h,
			fitKey: "horrified-town",
			clampToSheet: !0,
			eligible: a,
			highlight: n ? "outer" : "off",
			onTapEligible: (e) => r(e),
			children: /* @__PURE__ */ h(Bn, {
				pub: e,
				members: t
			})
		})
	});
}
function Bn({ pub: e, members: t }) {
	let n = s(), r = e.heroes.find((t) => t.id === e.turn.hero);
	return /* @__PURE__ */ h("g", {
		"aria-hidden": "true",
		children: Ln.map((i) => {
			let { x: o, y: s } = y[i], l = Sn(e, i), u = Cn(e, i), d = wn(e, i), f = Tn(e, i).length;
			return /* @__PURE__ */ g("g", { children: [
				/* @__PURE__ */ h("title", { children: Z(i, n) }),
				i === r?.space && !r.defeated && /* @__PURE__ */ h("circle", {
					cx: o,
					cy: s,
					r: 46,
					fill: "none",
					stroke: "#fff",
					strokeWidth: 2.4,
					strokeDasharray: "7 6",
					opacity: .85,
					className: "hf-turn-ring"
				}),
				l.map(({ figure: t, monster: r }, i) => {
					let a = o + (i - (l.length - 1) / 2) * 40, c = s - 34, u = e.frenzy === r;
					return /* @__PURE__ */ g("g", {
						transform: `translate(${a} ${c})`,
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ h("circle", {
								r: 17,
								fill: cn[r],
								stroke: "#fff",
								strokeWidth: 2.4
							}),
							/* @__PURE__ */ h("text", {
								y: 1,
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: 11,
								fontWeight: 800,
								fill: "#fff",
								children: pn(t, n)
							}),
							u && /* @__PURE__ */ g("g", {
								transform: "translate(13 -13)",
								children: [/* @__PURE__ */ h("circle", {
									r: 8,
									fill: "#c026d3",
									stroke: "#fff",
									strokeWidth: 1.6
								}), /* @__PURE__ */ h("text", {
									y: 1,
									textAnchor: "middle",
									dominantBaseline: "central",
									fontSize: 9,
									fontWeight: 900,
									fill: "#fff",
									children: "!"
								})]
							}),
							/* @__PURE__ */ h("title", { children: fn(t, n) })
						]
					}, t);
				}),
				u.map((e, r) => {
					let i = t.find((t) => t.rid === e.owner), l = c[(i?.colorIndex ?? 0) % c.length].hex, d = o + (r - (u.length - 1) / 2) * 36, f = s + 16, p = `hf-av-${e.id}`;
					return /* @__PURE__ */ g("g", {
						transform: `translate(${d} ${f})`,
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ h("circle", {
								r: 15,
								fill: l,
								stroke: "#fff",
								strokeWidth: 2.6
							}),
							/* @__PURE__ */ h("clipPath", {
								id: p,
								children: /* @__PURE__ */ h("circle", { r: 12 })
							}),
							/* @__PURE__ */ h("image", {
								href: a[(i?.avatar ?? 0) % a.length],
								x: -12,
								y: -12,
								width: 24,
								height: 24,
								clipPath: `url(#${p})`,
								preserveAspectRatio: "xMidYMid slice"
							}),
							/* @__PURE__ */ h("text", {
								y: 27,
								textAnchor: "middle",
								fontSize: 10,
								fontWeight: 700,
								fill: "#fff",
								stroke: "#1c2230",
								strokeWidth: 2.6,
								paintOrder: "stroke",
								children: ln(e.id, n)
							}),
							/* @__PURE__ */ h("title", { children: ln(e.id, n) })
						]
					}, e.id);
				}),
				d.slice(0, 4).map((e, t) => {
					let r = o + (t - (Math.min(d.length, 4) - 1) / 2) * 39, i = s + 42;
					return /* @__PURE__ */ g("g", {
						transform: `translate(${r} ${i})`,
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ h("rect", {
								x: -18,
								y: -8,
								width: 36,
								height: 16,
								rx: 5,
								fill: "#f6ebc7",
								stroke: "#6d5a2f",
								strokeWidth: 1.4
							}),
							/* @__PURE__ */ h("text", {
								y: 1,
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: 9,
								fontWeight: 700,
								fill: "#3c3116",
								children: un(e, n)
							}),
							/* @__PURE__ */ h("title", { children: un(e, n) })
						]
					}, e);
				}),
				d.length > 4 && /* @__PURE__ */ g("g", {
					transform: `translate(${o + 78} ${s + 42})`,
					pointerEvents: "none",
					children: [/* @__PURE__ */ h("rect", {
						x: -12,
						y: -8,
						width: 24,
						height: 16,
						rx: 5,
						fill: "#6d5a2f"
					}), /* @__PURE__ */ g("text", {
						y: 1,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 9,
						fontWeight: 800,
						fill: "#fff",
						children: ["+", d.length - 4]
					})]
				}),
				f > 0 && /* @__PURE__ */ g("g", {
					transform: `translate(${o + 40} ${s - 18})`,
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ h("circle", {
							r: 10,
							fill: "#f5c542",
							stroke: "#5c4712",
							strokeWidth: 1.6
						}),
						/* @__PURE__ */ h("text", {
							y: 1,
							textAnchor: "middle",
							dominantBaseline: "central",
							fontSize: 11,
							fontWeight: 900,
							fill: "#2a2109",
							children: f
						}),
						/* @__PURE__ */ h("title", { children: n("games.horrified.boardItems") })
					]
				})
			] }, i);
		})
	});
}
//#endregion
//#region src/game/panels.tsx
function Vn(e) {
	let t = o((e) => e.locale);
	return (n) => {
		let r = e.find((e) => e.rid === n);
		return r ? te(r, t) : "";
	};
}
function Hn({ uid: e, hero: t, selected: n, onToggle: r }) {
	let i = s(), a = _n(F(e)), o = `${mn(e, i)} ${i("games.horrified.itemStrength", { n: yn(e, t.id) })}`;
	return /* @__PURE__ */ g("button", {
		type: "button",
		className: `hf-chip hf-item is-${a}`,
		"data-selected": !!n,
		disabled: !r,
		"aria-pressed": !!n,
		"aria-label": o,
		title: o,
		onClick: r,
		children: [
			/* @__PURE__ */ h("i", {
				className: `hf-dot is-${a}`,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ h("span", { children: mn(e, i) }),
			/* @__PURE__ */ h("b", { children: yn(e, t.id) })
		]
	});
}
function Un({ title: e, children: t, hint: n }) {
	return /* @__PURE__ */ g("section", {
		className: "hf-sheet-section",
		children: [/* @__PURE__ */ g("h3", { children: [e, n && /* @__PURE__ */ h("small", { children: n })] }), t]
	});
}
function Wn({ pub: e, space: t, open: n, onClose: r, myRid: a, members: o, send: c, busy: l }) {
	let u = s(), d = Vn(o), f = e.heroes.find((e) => e.owner === a), [p, ee] = i([]), [te, m] = i([]), [ne, re] = i(f?.id ?? null), [ie, v] = i(null), [b, x] = i([]), [S, ae] = i(null), C = `${t}:${e.turn.hero}:${e.phase}:${e.turn.owner}:${e.log.length}`, [oe, se] = i(C);
	oe !== C && (se(C), ee([]), m([]), re(f?.id ?? null), v(null), x([]), ae(null));
	let w = e.phase === "hero" && e.turn.owner === a && !e.prompt && e.mummyMoves <= 0 && !e.fbMoves && !e.ending && !l, T = !!f && !f.defeated && f.space === t, E = t ? Tn(e, t) : [], ce = t ? Cn(e, t) : [], le = t ? wn(e, t) : [], D = t ? Sn(e, t) : [], O = ne ? ce.find((e) => e.id === ne) : void 0, k = O && ie ? ce.find((e) => e.id === ie && e.id !== O.id) : void 0, A = (e, t, n = 12) => e.includes(t) ? e.filter((e) => e !== t) : e.length >= n ? e : [...e, t];
	if (!t) return null;
	let j = w && !!f && !f.defeated && f.space !== t && !!f.space && Mn(f.space).includes(t), M = f && f.space && !f.defeated ? wn(e, f.space) : [], ue = f && T ? On(e, f) : [], N = T ? Mn(t).flatMap((t) => wn(e, t)) : [];
	return /* @__PURE__ */ h(_, {
		open: n,
		onClose: r,
		label: Z(t, u),
		title: `${Z(t, u)}${y[t].water ? ` · ${u("games.horrified.waterTag")}` : ""}`,
		tall: !0,
		children: /* @__PURE__ */ g("div", {
			className: "hf-sheet",
			children: [
				E.length > 0 && /* @__PURE__ */ g(Un, {
					title: u("games.horrified.boardItems"),
					hint: w && T ? u("games.horrified.selectItemsHint") : void 0,
					children: [/* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: E.map((t) => /* @__PURE__ */ h(Hn, {
							uid: t,
							hero: f ?? e.heroes[0],
							selected: p.includes(t),
							onToggle: w && T ? () => ee((e) => A(e, t)) : void 0
						}, t))
					}), w && T && /* @__PURE__ */ h("button", {
						type: "button",
						className: "hf-btn hf-primary",
						disabled: !p.length,
						onClick: () => {
							c({
								type: "pickup",
								uids: p
							}), ee([]);
						},
						children: u("games.horrified.pickupN", { n: p.length })
					})]
				}),
				/* @__PURE__ */ h(Un, {
					title: u("games.horrified.personsHere"),
					children: ce.length + le.length === 0 ? /* @__PURE__ */ h("p", {
						className: "hf-muted",
						children: u("games.horrified.noPersons")
					}) : /* @__PURE__ */ g("ul", {
						className: "hf-people",
						children: [ce.map((e) => /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ g("span", {
							className: "hf-hero-tag",
							children: [Q(e.id, u), /* @__PURE__ */ h("small", { children: d(e.owner) })]
						}), e.perks.length > 0 && /* @__PURE__ */ g("small", {
							className: "hf-muted",
							children: [
								u("games.horrified.perksTitle"),
								" ",
								e.perks.length
							]
						})] }, e.id)), le.map((e) => /* @__PURE__ */ h("li", { children: /* @__PURE__ */ h("span", {
							className: "hf-villager-tag",
							children: $(e, u)
						}) }, e))]
					})
				}),
				/* @__PURE__ */ h(Un, {
					title: u("games.horrified.monstersHere"),
					children: D.length === 0 ? /* @__PURE__ */ h("p", {
						className: "hf-muted",
						children: u("games.horrified.noMonsters")
					}) : /* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: D.map(({ figure: e, monster: t }) => /* @__PURE__ */ h("span", {
							className: "hf-monster-tag",
							style: { backgroundColor: cn[t] },
							children: fn(e, u)
						}, e))
					})
				}),
				w && T && (le.length > 0 || N.length > 0) && /* @__PURE__ */ g(Un, {
					title: u("games.horrified.guideTitle"),
					children: [le.map((e) => Mn(t).length === 0 ? null : /* @__PURE__ */ g("div", {
						className: "hf-guide-row",
						children: [/* @__PURE__ */ h("span", { children: $(e, u) }), /* @__PURE__ */ h("div", {
							className: "hf-chips",
							children: Mn(t).map((t) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "hf-btn hf-small",
								onClick: () => c({
									type: "guide",
									villager: e,
									to: t
								}),
								children: u("games.horrified.guideTo", {
									villager: $(e, u),
									space: Z(t, u)
								})
							}, t))
						})]
					}, e)), N.map((e) => /* @__PURE__ */ g("div", {
						className: "hf-guide-row",
						children: [/* @__PURE__ */ h("span", { children: $(e, u) }), /* @__PURE__ */ h("div", {
							className: "hf-chips",
							children: /* @__PURE__ */ h("button", {
								type: "button",
								className: "hf-btn hf-small",
								onClick: () => c({
									type: "guide",
									villager: e,
									to: t
								}),
								children: u("games.horrified.guideTo", {
									villager: $(e, u),
									space: Z(t, u)
								})
							})
						})]
					}, e))]
				}),
				w && T && ce.length > 1 && /* @__PURE__ */ g(Un, {
					title: u("games.horrified.shareTitle"),
					children: [
						/* @__PURE__ */ h("div", {
							className: "hf-chips",
							children: ce.map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "hf-btn hf-small",
								"data-selected": ne === e.id,
								onClick: () => {
									re(e.id), v(null), x([]);
								},
								children: u("games.horrified.shareFrom", { hero: Q(e.id, u) })
							}, e.id))
						}),
						O && /* @__PURE__ */ h("div", {
							className: "hf-chips",
							children: ce.filter((e) => e.id !== O.id).map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "hf-btn hf-small",
								"data-selected": ie === e.id,
								onClick: () => {
									v(ie === e.id ? null : e.id), x([]);
								},
								children: u("games.horrified.shareTo", { hero: Q(e.id, u) })
							}, e.id))
						}),
						O && k && /* @__PURE__ */ g("div", {
							className: "hf-share",
							children: [/* @__PURE__ */ h("div", {
								className: "hf-chips",
								children: O.items.map((e) => /* @__PURE__ */ h(Hn, {
									uid: e.uid,
									hero: O,
									selected: b.includes(e.uid),
									onToggle: () => x((t) => A(t, e.uid))
								}, e.uid))
							}), /* @__PURE__ */ g("div", {
								className: "hf-row",
								children: [/* @__PURE__ */ h("button", {
									type: "button",
									className: "hf-btn hf-primary",
									disabled: !b.length,
									onClick: () => {
										c({
											type: "share",
											from: O.id,
											to: k.id,
											uids: b,
											cure: !1
										}), x([]);
									},
									children: u("games.horrified.shareTitle")
								}), e.monsters.wolfman?.cure === O.id && /* @__PURE__ */ h("button", {
									type: "button",
									className: "hf-btn",
									onClick: () => c({
										type: "share",
										from: O.id,
										to: k.id,
										uids: [],
										cure: !0
									}),
									children: u("games.horrified.giveCure")
								})]
							})]
						})
					]
				}),
				ue.length > 0 && f && /* @__PURE__ */ g(Un, {
					title: u("games.horrified.spaceActions"),
					children: [/* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: ue.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: `hf-btn ${e.mode === "defeat" ? "hf-danger" : "hf-primary"}`,
							onClick: () => ae({
								option: e,
								uids: kn(f, e)
							}),
							children: u(e.mode === "advance" ? "games.horrified.advanceButton" : "games.horrified.defeatButton", { monster: dn(e.monster, u) })
						}, `${e.mode}-${e.figure}`))
					}), S && /* @__PURE__ */ g("div", {
						className: "hf-task-pick",
						children: [
							/* @__PURE__ */ h("p", {
								className: "hf-muted",
								children: S.option.single ? u("games.horrified.selectItemsHint") : u("games.horrified.strengthSum", { n: xn(f, S.uids) })
							}),
							/* @__PURE__ */ h("div", {
								className: "hf-chips",
								children: S.option.uids.map((e) => /* @__PURE__ */ h(Hn, {
									uid: e,
									hero: f,
									selected: S.uids.includes(e),
									onToggle: () => ae((t) => t && {
										...t,
										uids: t.option.single ? t.uids.includes(e) ? [] : [e] : A(t.uids, e)
									})
								}, e))
							}),
							!S.option.single && /* @__PURE__ */ h("p", {
								className: `hf-strength${An(f, S.option, S.uids) ? "" : " is-short"}`,
								children: u("games.horrified.strengthNeed", { n: S.option.need })
							}),
							/* @__PURE__ */ g("div", {
								className: "hf-row",
								children: [/* @__PURE__ */ h("button", {
									type: "button",
									className: "hf-btn",
									onClick: () => ae(null),
									children: u("games.horrified.cancel")
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "hf-btn hf-primary",
									disabled: !An(f, S.option, S.uids),
									onClick: () => {
										c({
											type: S.option.mode,
											monster: S.option.figure,
											uids: S.uids
										}), ae(null);
									},
									children: u("games.horrified.done")
								})]
							})
						]
					})]
				}),
				j && /* @__PURE__ */ g(Un, {
					title: u("games.horrified.moveTo", { space: Z(t, u) }),
					children: [M.length > 0 && /* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: M.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": te.includes(e),
							onClick: () => m((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
							children: $(e, u)
						}, e))
					}), /* @__PURE__ */ h("button", {
						type: "button",
						className: "hf-btn hf-primary",
						onClick: () => {
							c({
								type: "move",
								to: t,
								villagers: te
							}), m([]);
						},
						children: u("games.horrified.moveTo", { space: Z(t, u) })
					})]
				}),
				!w && /* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: u("games.horrified.waitingOther")
				})
			]
		})
	});
}
function Gn(e, t) {
	return e.kind === "defend" && e.item ? t("games.horrified.defendWith", { item: mn(e.item, t) }) : e.kind === "takeHit" ? t("games.horrified.takeHit") : e.kind === "stay" ? t("games.horrified.stay") : e.kind === "done" ? t("games.horrified.done") : e.kind === "carryConfirm" ? t("games.horrified.carryConfirm") : e.kind === "villagerOn" && e.villager ? `✓ ${$(e.villager, t)}` : e.kind === "villagerOff" && e.villager ? $(e.villager, t) : e.kind === "modePlace" ? t("games.horrified.modePlace") : e.kind === "modeMove" ? t("games.horrified.modeMove") : e.space ? Z(e.space, t) : e.hero ? Q(e.hero, t) : e.villager ? $(e.villager, t) : e.figure ? fn(e.figure, t) : e.item ? mn(e.item, t) : t("games.horrified.done");
}
function Kn({ pub: e, send: t, busy: n }) {
	let r = s(), i = e.prompt;
	if (!i) return null;
	let a = sn[i.kind] ?? "games.horrified.promptTitle";
	return /* @__PURE__ */ h(_, {
		open: !0,
		label: r("games.horrified.promptTitle"),
		title: r(a),
		children: /* @__PURE__ */ h("div", {
			className: "hf-prompt",
			children: /* @__PURE__ */ h("div", {
				className: "hf-chips",
				children: i.options.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "hf-btn hf-option",
					disabled: n,
					onClick: () => t({
						type: "choose",
						decision: i.decision,
						choice: e.id
					}),
					children: Gn(e, r)
				}, e.id))
			})
		})
	});
}
function qn({ pub: e, send: t, busy: n }) {
	let r = s(), [a, o] = i(null), c = e.monsters.mummy, l = e.mummyMoves, [u, d] = i(l);
	if (u !== l && (d(l), o(null)), !c || l <= 0) return null;
	let f = c.slots, p = (e) => {
		if (n) return;
		let r = f[e];
		if (a && r.num === 0 && M[a].includes(e)) {
			t({
				type: "mummySlide",
				from: a,
				to: e
			}), o(null);
			return;
		}
		if (r.num > 0 && !r.faceUp) {
			t({
				type: "mummyFlip",
				slot: e
			}), o(null);
			return;
		}
		r.num > 0 && r.faceUp && o(a === e ? null : e);
	};
	return /* @__PURE__ */ h(_, {
		open: !0,
		label: r("games.horrified.mummyPuzzle"),
		title: r("games.horrified.mummyPuzzle"),
		children: /* @__PURE__ */ g("div", {
			className: "hf-mummy",
			children: [
				/* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: r("games.horrified.mummyPending", { n: l })
				}),
				/* @__PURE__ */ g("svg", {
					viewBox: "0 0 100 100",
					className: "hf-mummy-board",
					role: "group",
					"aria-label": r("games.horrified.mummyPuzzle"),
					children: [j.flatMap((e) => M[e].map((t) => /* @__PURE__ */ h("line", {
						x1: ue[e].x,
						y1: ue[e].y,
						x2: ue[t].x,
						y2: ue[t].y,
						className: "hf-mummy-link"
					}, `${e}-${t}`))), j.map((e) => {
						let t = f[e], n = ue[e], i = t.num === 0, o = !!a && i && M[a].includes(e);
						return /* @__PURE__ */ g("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": i ? r("games.horrified.mummyInvalidTarget") : String(e),
							className: `hf-mummy-cell${a === e ? " is-picked" : ""}${o ? " is-target" : ""}${!t.faceUp && !i ? " is-back" : ""}`,
							onClick: () => p(e),
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), p(e));
							},
							children: [/* @__PURE__ */ h("rect", {
								x: n.x - 9,
								y: n.y - 9,
								width: 18,
								height: 18,
								rx: 3.5
							}), !i && /* @__PURE__ */ h("text", {
								x: n.x,
								y: n.y + 4,
								textAnchor: "middle",
								children: t.faceUp ? t.num : "?"
							})]
						}, e);
					})]
				}),
				/* @__PURE__ */ h("p", {
					className: "hf-hint",
					children: r("games.horrified.mummySlideHint")
				}),
				/* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: r("games.horrified.mummyFlipHint")
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "hf-btn hf-primary",
					disabled: n,
					onClick: () => t({ type: "mummyDone" }),
					children: r("games.horrified.mummyDoneButton")
				})
			]
		})
	});
}
function Jn({ pub: e, send: t, busy: n }) {
	let r = s(), i = e.fbMoves, a = e.monsters.fb;
	if (!i || !a) return null;
	let o = i.figure === "frank" ? a.frank : a.bride;
	if (!o) return null;
	let c = Nn(o, i.remaining);
	return /* @__PURE__ */ h(_, {
		open: !0,
		label: r("games.horrified.fbPending", {
			figure: fn(i.figure, r),
			n: i.remaining
		}),
		title: r("games.horrified.fbPending", {
			figure: fn(i.figure, r),
			n: i.remaining
		}),
		children: /* @__PURE__ */ g("div", {
			className: "hf-sheet",
			children: [
				/* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: r("games.horrified.fbPendingHint")
				}),
				/* @__PURE__ */ h("div", {
					className: "hf-chips",
					children: c.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: "hf-btn",
						disabled: n,
						onClick: () => t({
							type: "fbMove",
							to: e
						}),
						children: Z(e, r)
					}, e))
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "hf-btn hf-primary",
					disabled: n,
					onClick: () => t({ type: "fbDone" }),
					children: r("games.horrified.done")
				})
			]
		})
	});
}
function Yn(e, t, n) {
	let r = e.monsters;
	return t === "dracula" && r.dracula ? n("games.horrified.coffins", { n: 4 - r.dracula.coffins.length }) : t === "creature" && r.creature ? n(r.creature.boat === A ? "games.horrified.boatLair" : "games.horrified.boat", { n: r.creature.boat }) : t === "frankenstein" && r.fb ? `${n("games.horrified.frankProgress", {
		n: r.fb.score.frank,
		target: O.frank
	})} · ${n("games.horrified.brideProgress", {
		n: r.fb.score.bride,
		target: O.bride
	})}` : t === "mummy" && r.mummy ? n(En(r.mummy.slots) ? "games.horrified.mummySolved" : "games.horrified.mummyUnsolved") : t === "wolfman" && r.wolfman ? n("games.horrified.bottles", { n: r.wolfman.bottles.filter(Boolean).length }) : t === "invisibleman" && r.invisibleman ? n("games.horrified.spots", { n: r.invisibleman.spots.filter(Boolean).length }) : "";
}
function Xn({ pub: e, open: t, onClose: n }) {
	let r = s();
	return /* @__PURE__ */ h(_, {
		open: t,
		onClose: n,
		label: r("games.horrified.tasksTitle"),
		title: r("games.horrified.tasksTitle"),
		tall: !0,
		children: /* @__PURE__ */ h("div", {
			className: "hf-tasks",
			children: e.chosen.map((t) => {
				let n = rn[t], i = e.defeated.includes(t);
				return /* @__PURE__ */ g("article", {
					className: `hf-task${i ? " is-done" : ""}`,
					style: { borderColor: cn[t] },
					children: [
						/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", {
							style: { color: cn[t] },
							children: dn(t, r)
						}), /* @__PURE__ */ g("div", {
							className: "hf-tags",
							children: [i && /* @__PURE__ */ h("span", {
								className: "hf-tag is-done",
								children: r("games.horrified.defeatedTag")
							}), e.frenzy === t && !i && /* @__PURE__ */ h("span", {
								className: "hf-tag is-frenzy",
								children: r("games.horrified.frenzyTag")
							})]
						})] }),
						/* @__PURE__ */ h("p", {
							className: "hf-task-progress",
							children: Yn(e, t, r)
						}),
						/* @__PURE__ */ g("dl", { children: [
							/* @__PURE__ */ h("dt", { children: r("games.horrified.taskAdvance") }),
							/* @__PURE__ */ h("dd", { children: r(n.advance) }),
							/* @__PURE__ */ h("dt", { children: r("games.horrified.taskDefeat") }),
							/* @__PURE__ */ h("dd", { children: r(n.defeat) }),
							/* @__PURE__ */ h("dt", { children: r("games.horrified.taskPower") }),
							/* @__PURE__ */ h("dd", { children: r(n.power) })
						] })
					]
				}, t);
			})
		})
	});
}
function Zn({ pub: e, open: t, onClose: n }) {
	let r = s(), i = Object.values(e.villagers), a = i.filter((e) => e.status === "safe").length;
	return /* @__PURE__ */ h(_, {
		open: t,
		onClose: n,
		label: r("games.horrified.villagersTitle"),
		title: r("games.horrified.villagersTitle"),
		tall: !0,
		children: /* @__PURE__ */ g("div", {
			className: "hf-sheet",
			children: [/* @__PURE__ */ h("p", {
				className: "hf-muted",
				children: r("games.horrified.rescuedCount", { n: a })
			}), /* @__PURE__ */ h("ul", {
				className: "hf-villagers",
				children: i.map((e) => /* @__PURE__ */ g("li", {
					"data-status": e.status,
					children: [
						/* @__PURE__ */ h("strong", { children: $(e.id, r) }),
						/* @__PURE__ */ h("span", { children: e.status === "board" && e.space ? r("games.horrified.villagerAt", { space: Z(e.space, r) }) : e.status === "safe" ? r("games.horrified.villagerSafeStatus") : e.status === "defeated" ? r("games.horrified.villagerDefeatedStatus") : r("games.horrified.villagerNone") }),
						/* @__PURE__ */ h("small", { children: r("games.horrified.villagerSafe", { space: Z(w[e.id].safe, r) }) })
					]
				}, e.id))
			})]
		})
	});
}
function Qn({ pub: e, myRid: t, canPlay: n, send: r, open: i, onClose: a }) {
	let o = s();
	return /* @__PURE__ */ h(_, {
		open: i,
		onClose: a,
		label: o("games.horrified.perksTitle"),
		title: o("games.horrified.perksTitle"),
		tall: !0,
		children: /* @__PURE__ */ h("div", {
			className: "hf-sheet",
			children: e.heroes.map((e) => /* @__PURE__ */ h(Un, {
				title: `${Q(e.id, o)}${e.owner === t ? ` · ${o("games.horrified.youTag")}` : ""}`,
				children: e.perks.length === 0 ? /* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: o("games.horrified.perksEmpty")
				}) : /* @__PURE__ */ h("div", {
					className: "hf-chips",
					children: e.perks.map((i) => /* @__PURE__ */ g("div", {
						className: "hf-perk",
						children: [/* @__PURE__ */ h("span", { children: hn(i.uid, o) }), e.owner === t && n && /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-small hf-primary",
							onClick: () => r({
								type: "playPerk",
								uid: i.uid
							}),
							children: o("games.horrified.playPerk")
						})]
					}, i.uid))
				})
			}, e.id))
		})
	});
}
function $n({ pub: e, hero: t, send: n, open: r, onClose: a, onPickOnMap: o, canPick: c = !0 }) {
	let l = s(), [u, d] = i(null), [f, p] = i([]), ee = `${t?.id ?? ""}:${r}`, [te, m] = i(ee);
	if (te !== ee && (m(ee), d(null), p([])), !t || t.defeated) return null;
	let ne = l("games.horrified.specialButton", { hero: Q(t.id, l) });
	if (t.id === "archaeologist") {
		let i = t.space ? b[t.space].filter((t) => Tn(e, t).length > 0) : [];
		return /* @__PURE__ */ h(_, {
			open: r,
			onClose: a,
			label: l("games.horrified.specialTitle"),
			title: ne,
			children: /* @__PURE__ */ g("div", {
				className: "hf-sheet",
				children: [/* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: l("games.horrified.heroArchaeologistSpecial")
				}), i.length === 0 ? /* @__PURE__ */ h("p", {
					className: "hf-muted",
					children: l("games.horrified.noItems")
				}) : /* @__PURE__ */ h("div", {
					className: "hf-chips",
					children: i.map((t) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "hf-btn",
						onClick: () => {
							n({
								type: "specialArchaeologist",
								space: t,
								uids: Tn(e, t).slice(0, 12)
							}), a();
						},
						children: [
							Z(t, l),
							" · ",
							Tn(e, t).length
						]
					}, t))
				})]
			})
		});
	}
	if (t.id === "professor") {
		let t = e.heroes.filter((e) => !e.defeated && e.space), i = Object.values(e.villagers).filter((e) => e.status === "board" && e.space), o = u ? u.kind === "hero" ? e.heroes.find((e) => e.id === u.id)?.space : e.villagers[u.id]?.space : null, s = o ? Mn(o) : [], c = u?.kind === "hero" && o ? wn(e, o) : [];
		return /* @__PURE__ */ h(_, {
			open: r,
			onClose: a,
			label: l("games.horrified.specialTitle"),
			title: ne,
			children: /* @__PURE__ */ g("div", {
				className: "hf-sheet",
				children: [
					/* @__PURE__ */ h("p", {
						className: "hf-muted",
						children: l("games.horrified.heroProfessorSpecial")
					}),
					/* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: [t.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": u?.kind === "hero" && u.id === e.id,
							onClick: () => {
								d({
									kind: "hero",
									id: e.id
								}), p([]);
							},
							children: ln(e.id, l)
						}, e.id)), i.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": u?.kind === "villager" && u.id === e.id,
							onClick: () => {
								d({
									kind: "villager",
									id: e.id
								}), p([]);
							},
							children: $(e.id, l)
						}, e.id))]
					}),
					c.length > 0 && /* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: c.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": f.includes(e),
							onClick: () => p((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
							children: $(e, l)
						}, e))
					}),
					u && /* @__PURE__ */ h("div", {
						className: "hf-chips",
						children: s.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-btn hf-primary hf-small",
							onClick: () => {
								n(u.kind === "hero" ? {
									type: "specialProfessor",
									hero: u.id,
									to: e,
									villagers: f
								} : {
									type: "specialProfessor",
									villager: u.id,
									to: e,
									villagers: []
								}), d(null), p([]);
							},
							children: Z(e, l)
						}, e))
					})
				]
			})
		});
	}
	return /* @__PURE__ */ h(_, {
		open: r,
		onClose: a,
		label: l("games.horrified.specialTitle"),
		title: ne,
		children: /* @__PURE__ */ g("div", {
			className: "hf-sheet",
			children: [/* @__PURE__ */ h("p", {
				className: "hf-muted",
				children: l(t.id === "courier" ? "games.horrified.heroCourierSpecial" : t.id === "explorer" ? "games.horrified.heroExplorerSpecial" : "games.horrified.heroInspectorSpecial")
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "hf-btn hf-primary",
				disabled: !c,
				onClick: () => {
					o(), a();
				},
				children: l("games.horrified.chooseTargetSpace")
			})]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
var er = {
	triumph: "games.horrified.endingWin",
	terror: "games.horrified.endingTerror",
	time: "games.horrified.endingTime"
};
function tr(e) {
	return /* @__PURE__ */ h(nr, { ...e });
}
function nr({ public: e, members: t, myRid: m, send: ne }) {
	l();
	let _ = s(), re = o((e) => e.locale), ie = u(), v = e, [y, b] = i(null), [x, S] = i(null), [ae, C] = i(null), [oe, se] = i(!1), [w, T] = i(!1), E = r(null), [ce, le] = i(m);
	ce !== m && (le(m), b(null), S(null), C(null), se(!1), T(!1));
	let D = t.find((e) => e.rid === m), O = v.heroes.find((e) => e.owner === m), k = v.heroes.find((e) => e.id === v.turn.hero), A = v.phase === "hero" && v.turn.owner === m && !v.prompt && v.mummyMoves <= 0 && !v.fbMoves && !v.ending && !w, j = v.prompt && v.prompt.owners.includes(m) ? v.prompt : null, M = v.turn.owner === m && !v.ending, ue = O ? jn(v, O) : null, N = ue ? [...new Set(ue)] : [], de = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? te(n, re) : "";
	}, fe = c[(D?.colorIndex ?? 0) % c.length], pe = Object.values(v.villagers).filter((e) => e.status === "board" && e.space), me = Object.values(v.villagers).filter((e) => e.status === "safe").length;
	function P(e) {
		w || (T(!0), ne(e), E.current && window.clearTimeout(E.current), E.current = window.setTimeout(() => T(!1), 1200));
	}
	let he = r(v.log.length);
	n(() => {
		v.log.length !== he.current && (he.current = v.log.length, T(!1), E.current && window.clearTimeout(E.current));
	}, [v.log.length]), n(() => () => {
		E.current && window.clearTimeout(E.current);
	}, []);
	let _e = v.prompt ? `prompt:${v.prompt.decision}` : v.mummyMoves > 0 ? `mummy:${v.mummyMoves}` : v.fbMoves ? `fb:${v.fbMoves.figure}:${v.fbMoves.remaining}` : "", [ve, ye] = i(_e);
	ve !== _e && (ye(_e), _e && (b(null), S(null), C(null)));
	let F = `${v.turn.owner}:${v.turn.hero}`, [be, xe] = i(F);
	be !== F && (xe(F), C(null));
	let I = v.log.reduce((e, t, n) => t.k === "roll" ? n : e, -1), L = r(I), [R, z] = i(0);
	n(() => {
		I <= L.current || (L.current = I, z((e) => e + 1));
	}, [I]), n(() => {
		if (!R) return;
		let e = window.setTimeout(() => z(0), 3600);
		return () => window.clearTimeout(e);
	}, [R]);
	function Se(e) {
		O && ae === O.id && (O.id === "explorer" ? P({
			type: "specialExplorer",
			to: e
		}) : O.id === "courier" ? P({
			type: "specialCourier",
			to: e
		}) : O.id === "inspector" && P({
			type: "specialInspector",
			to: e
		}), C(null));
	}
	let Ce = v.ending, we = "info", B, V;
	Ce ? (we = "done", B = _(er[Ce.reason]), V = _("games.horrified.endingTitle")) : v.prompt ? (B = _(sn[v.prompt.kind] ?? "games.horrified.promptTitle"), j ? (we = "accent", V = _("games.horrified.yourTurn")) : V = _("games.horrified.promptWaiting", { name: de(v.prompt.owners[0] ?? v.turn.owner) })) : M && v.mummyMoves > 0 ? (we = "accent", B = _("games.horrified.mummyPending", { n: v.mummyMoves }), V = O ? Q(O.id, _) : void 0) : M && v.fbMoves ? (we = "accent", B = _("games.horrified.fbPending", {
		figure: fn(v.fbMoves.figure, _),
		n: v.fbMoves.remaining
	}), V = O ? Q(O.id, _) : void 0) : v.phase === "monster" ? (we = "warn", B = _("games.horrified.phaseMonster"), V = _("games.horrified.monsterDeck", { n: v.monsterDeckCount })) : v.turn.owner === m ? (we = "accent", B = _("games.horrified.yourTurn"), V = `${k ? Q(k.id, _) : ""} · ${_("games.horrified.actionsLeft", {
		left: v.turn.actionsLeft,
		max: v.turn.actionsMax
	})}`) : (B = _("games.horrified.waitingTurn", { name: de(v.turn.owner) }), V = _("games.horrified.phaseHero"));
	let Te = /* @__PURE__ */ g("div", {
		className: "hf-tools",
		children: [
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "hf-tool",
				disabled: !A || !O || O.defeated,
				onClick: () => S("special"),
				children: _("games.horrified.specialTitle")
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("tasks"),
				children: [_("games.horrified.openTasks"), v.frenzy && !v.defeated.includes(v.frenzy) && /* @__PURE__ */ h("b", {
					className: "hf-tool-mark",
					"aria-label": _("games.horrified.frenzyTag"),
					children: "!"
				})]
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("villagers"),
				children: _("games.horrified.villagersTitle")
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("perks"),
				children: [_("games.horrified.perksTitle"), !!O?.perks.length && /* @__PURE__ */ h("b", {
					className: "hf-tool-mark",
					children: O.perks.length
				})]
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => se(!0),
				children: _("games.horrified.openLog")
			})
		]
	});
	return /* @__PURE__ */ g("div", {
		className: "hf-shell",
		children: [
			/* @__PURE__ */ h(f, {
				adaptive: !0,
				scroll: !1,
				className: `hf-game${ie ? " hf-reduced" : ""}`,
				actionsHeight: "hf-dock-slot",
				banner: /* @__PURE__ */ g("div", {
					className: "hf-top",
					children: [/* @__PURE__ */ h(p, {
						tone: we,
						text: B,
						sub: V,
						accent: ge.accent,
						chip: _("games.horrified.terror", { n: v.terror })
					}), /* @__PURE__ */ h(ee, {
						members: t,
						myRid: m,
						variant: "mini",
						adaptive: !0,
						scroll: !0,
						dimmed: (e) => v.heroes.find((t) => t.owner === e)?.defeated ?? !1,
						status: (e) => {
							let t = v.heroes.find((t) => t.owner === e);
							return t ? /* @__PURE__ */ g("span", {
								className: "hf-seat-status",
								children: [ln(t.id, _), t.defeated ? ` · ${_("games.horrified.heroDefeated")}` : ""]
							}) : null;
						}
					})]
				}),
				overlay: R > 0 && v.lastRoll ? /* @__PURE__ */ g("div", {
					className: "hf-float",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ g("div", {
							className: "hf-float-head",
							children: [/* @__PURE__ */ h("span", { children: _("games.horrified.lastRollTitle") }), /* @__PURE__ */ h("span", { children: fn(v.lastRoll.figure, _) })]
						}),
						/* @__PURE__ */ h("div", {
							className: "hf-dice",
							"aria-hidden": "true",
							children: v.lastRoll.dice.map((e, t) => /* @__PURE__ */ h("i", {
								className: `hf-die is-${e < 3 ? "hit" : e === 5 ? "power" : "blank"}`,
								children: e < 3 ? "✕" : e === 5 ? "★" : "·"
							}, t))
						}),
						/* @__PURE__ */ g("div", {
							className: "hf-float-sum",
							children: [/* @__PURE__ */ h("span", { children: _("games.horrified.rollHits", { n: v.lastRoll.hits }) }), /* @__PURE__ */ h("span", { children: _("games.horrified.rollPowers", { n: v.lastRoll.powers }) })]
						})
					]
				}) : void 0,
				actions: /* @__PURE__ */ g("div", {
					className: "hf-dock",
					children: [/* @__PURE__ */ g("div", {
						className: "hf-dock-main",
						children: [
							/* @__PURE__ */ g("div", {
								className: "hf-who",
								children: [
									D && /* @__PURE__ */ h("span", {
										className: "hf-ava",
										style: { backgroundColor: fe.hex },
										children: /* @__PURE__ */ h("img", {
											src: a[D.avatar % a.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ g("span", {
										className: "hf-who-text",
										children: [/* @__PURE__ */ h("strong", { children: D ? te(D, re) : "" }), /* @__PURE__ */ g("span", { children: [O ? Q(O.id, _) : "", O?.defeated ? ` · ${_("games.horrified.heroDefeated")}` : ""] })]
									}),
									O && v.turn.hero === O.id && /* @__PURE__ */ h("span", {
										className: "hf-pips",
										role: "img",
										"aria-label": _("games.horrified.actionsLeft", {
											left: v.turn.actionsLeft,
											max: v.turn.actionsMax
										}),
										children: Array.from({ length: v.turn.actionsMax }, (e, t) => /* @__PURE__ */ h("i", {
											"aria-hidden": "true",
											"data-on": t < v.turn.actionsLeft
										}, t))
									})
								]
							}),
							/* @__PURE__ */ h("div", {
								className: "hf-hand",
								"aria-label": _("games.horrified.handTitle"),
								children: O?.items.length ? O.items.map((e) => {
									let t = _n(e.type), n = _("games.horrified.itemAria", {
										item: mn(e.uid, _),
										color: gn(t, _),
										n: yn(e.uid, O.id)
									});
									return /* @__PURE__ */ g("span", {
										className: `hf-hand-item is-${t}`,
										role: "img",
										"aria-label": n,
										title: n,
										children: [
											/* @__PURE__ */ h("i", { "aria-hidden": "true" }),
											/* @__PURE__ */ h("span", { children: mn(e.uid, _) }),
											/* @__PURE__ */ h("b", { children: yn(e.uid, O.id) })
										]
									}, e.uid);
								}) : /* @__PURE__ */ h("span", {
									className: "hf-muted",
									children: _("games.horrified.handEmpty")
								})
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "hf-tool hf-end",
								disabled: !A,
								onClick: () => P({ type: "endTurn" }),
								children: _("games.horrified.endTurn")
							})
						]
					}), ae ? /* @__PURE__ */ g("div", {
						className: "hf-tools hf-dest",
						children: [/* @__PURE__ */ h("span", {
							className: "hf-dest-hint",
							children: _("games.horrified.chooseTargetSpace")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "hf-tool",
							onClick: () => C(null),
							children: _("games.horrified.cancel")
						})]
					}) : Te]
				}),
				children: /* @__PURE__ */ g("div", {
					className: "hf-center",
					children: [/* @__PURE__ */ h("div", {
						className: "hf-board-wrap",
						children: /* @__PURE__ */ h(zn, {
							pub: v,
							members: t,
							eligible: ae ? N : null,
							onSpace: (e) => ae ? Se(e) : b(e)
						})
					}), /* @__PURE__ */ g("aside", {
						className: "hf-rail",
						"aria-label": _("games.horrified.tasksTitle"),
						children: [
							/* @__PURE__ */ h("p", {
								className: "hf-rail-title",
								children: _("games.horrified.tasksTitle")
							}),
							/* @__PURE__ */ h("ul", {
								className: "hf-rail-list",
								children: v.chosen.map((e) => {
									let t = v.defeated.includes(e);
									return /* @__PURE__ */ g("li", {
										className: `hf-rail-task${t ? " is-done" : ""}`,
										style: { "--hf-monster": cn[e] },
										children: [/* @__PURE__ */ g("div", {
											className: "hf-rail-head",
											children: [/* @__PURE__ */ h("strong", { children: dn(e, _) }), t ? /* @__PURE__ */ h("span", {
												className: "hf-tag is-done",
												children: _("games.horrified.defeatedTag")
											}) : v.frenzy === e ? /* @__PURE__ */ h("span", {
												className: "hf-tag is-frenzy",
												children: _("games.horrified.frenzyTag")
											}) : null]
										}), /* @__PURE__ */ h("p", { children: Yn(v, e, _) })]
									}, e);
								})
							}),
							/* @__PURE__ */ g("div", {
								className: "hf-rail-villagers",
								children: [/* @__PURE__ */ g("p", {
									className: "hf-rail-title",
									children: [_("games.horrified.villagersTitle"), /* @__PURE__ */ h("span", { children: _("games.horrified.rescuedCount", { n: me }) })]
								}), pe.length > 0 ? /* @__PURE__ */ h("ul", { children: pe.map((e) => /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ h("strong", { children: $(e.id, _) }), /* @__PURE__ */ h("span", { children: _("games.horrified.villagerAt", { space: Z(e.space, _) }) })] }, e.id)) }) : /* @__PURE__ */ h("p", {
									className: "hf-rail-empty",
									children: _("games.horrified.railNoVillagers")
								})]
							}),
							/* @__PURE__ */ g("div", {
								className: "hf-rail-decks",
								children: [/* @__PURE__ */ h("span", { children: _("games.horrified.monsterDeck", { n: v.monsterDeckCount }) }), /* @__PURE__ */ h("span", { children: _("games.horrified.bag", { n: v.bagCount }) })]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ h(Wn, {
				pub: v,
				space: y,
				open: !!y,
				onClose: () => b(null),
				myRid: m,
				members: t,
				send: P,
				busy: w
			}),
			j && /* @__PURE__ */ h(Kn, {
				pub: v,
				send: P,
				busy: w
			}),
			M && v.mummyMoves > 0 && /* @__PURE__ */ h(qn, {
				pub: v,
				send: P,
				busy: w
			}),
			M && v.fbMoves && /* @__PURE__ */ h(Jn, {
				pub: v,
				send: P,
				busy: w
			}),
			/* @__PURE__ */ h(Xn, {
				pub: v,
				open: x === "tasks",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ h(Zn, {
				pub: v,
				open: x === "villagers",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ h(Qn, {
				pub: v,
				myRid: m,
				canPlay: v.phase === "hero" && !v.prompt && !v.ending && !w,
				send: P,
				open: x === "perks",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ h($n, {
				pub: v,
				hero: O,
				send: P,
				open: x === "special",
				onClose: () => S(null),
				canPick: N.length > 0,
				onPickOnMap: () => O && C(O.id)
			}),
			oe && /* @__PURE__ */ h(d, {
				log: v.log,
				line: (e) => Pn(e, _),
				onClose: () => se(!1)
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var rr = k.length;
function ir(e) {
	let t = /* @__PURE__ */ new Map([[e, 0]]), n = [e];
	for (; n.length;) {
		let e = n.shift();
		for (let r of b[e]) y[r].water || t.has(r) || (t.set(r, t.get(e) + 1), n.push(r));
	}
	return t;
}
function ar(e, t) {
	if (e === t) return null;
	let n = /* @__PURE__ */ new Map(), r = [e];
	for (; r.length;) {
		let i = r.shift();
		for (let a of b[i]) if (!(y[a].water || a === e || n.has(a))) {
			if (n.set(a, i), a === t) {
				let r = t;
				for (; n.get(r) !== e;) {
					let e = n.get(r);
					if (!e) return null;
					r = e;
				}
				return r;
			}
			r.push(a);
		}
	}
	return null;
}
function or(e) {
	return e.D.num === 0 && j.every((t) => t === "D" || e[t].faceUp && e[t].num === Number(t));
}
function sr(e, t, n) {
	let r = +(e.id === "scientist"), i = e.items.filter((e) => S[e.type].color === t).sort((e, t) => S[t.type].strength - S[e.type].strength), a = [], o = 0;
	for (let e of i) {
		if (o >= n) break;
		a.push(e.uid), o += S[e.type].strength + r;
	}
	return o >= n ? a : null;
}
function cr(e, t) {
	return e.items.filter((e) => S[e.type].color === t);
}
function lr(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	if (r.dracula && r.dracula.space === n && !r.dracula.coffins.length) {
		let e = sr(t, "yellow", 6);
		if (e) return {
			type: "defeat",
			monster: "dracula",
			uids: e
		};
	}
	if (r.creature && r.creature.space === n && r.creature.boat === rr) {
		let [e] = cr(t, "red"), [n] = cr(t, "blue"), [r] = cr(t, "yellow");
		if (e && n && r) return {
			type: "defeat",
			monster: "creature",
			uids: [
				e.uid,
				n.uid,
				r.uid
			]
		};
	}
	if (r.mummy && r.mummy.space === n && or(r.mummy.slots)) {
		let e = sr(t, "red", 9);
		if (e) return {
			type: "defeat",
			monster: "mummy",
			uids: e
		};
	}
	if (r.wolfman && r.wolfman.space === n && r.wolfman.cure === t.id) {
		let e = sr(t, "red", 6);
		if (e) return {
			type: "defeat",
			monster: "wolfman",
			uids: e
		};
	}
	if (r.invisibleman && r.invisibleman.space === n && r.invisibleman.spots.every((e) => e !== null)) {
		let e = sr(t, "red", 9);
		if (e) return {
			type: "defeat",
			monster: "invisibleman",
			uids: e
		};
	}
	return null;
}
function ur(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	if (r.dracula && r.dracula.coffins.includes(n)) {
		let e = sr(t, "red", 6);
		if (e) return {
			type: "advance",
			monster: "dracula",
			uids: e
		};
	}
	if (r.creature && n === "camp" && r.creature.boat < rr) {
		let e = null;
		for (let n of t.items) {
			let t = S[n.type].color;
			for (let i = r.creature.boat + 1; i <= rr; i++) if (k[i - 1] === t) {
				(!e || i > e.next) && (e = {
					uid: n.uid,
					next: i
				});
				break;
			}
		}
		if (e) return {
			type: "advance",
			monster: "creature",
			uids: [e.uid]
		};
	}
	if (r.fb) {
		if (r.fb.frank === n) {
			let [e] = cr(t, "yellow");
			if (e) return {
				type: "advance",
				monster: "frank",
				uids: [e.uid]
			};
		}
		if (r.fb.bride === n) {
			let [e] = cr(t, "blue");
			if (e) return {
				type: "advance",
				monster: "bride",
				uids: [e.uid]
			};
		}
	}
	if (r.mummy && n === "museum") {
		let [e] = cr(t, "yellow");
		if (e) return {
			type: "advance",
			monster: "mummy",
			uids: [e.uid]
		};
	}
	if (r.wolfman && n === "laboratory") {
		let e = +(t.id === "scientist"), n = cr(t, "blue").find((t) => {
			let n = S[t.type].strength;
			return r.wolfman.bottles.some((t, r) => t === null && (D[r] === n || e > 0 && D[r] === n + e));
		});
		if (n) return {
			type: "advance",
			monster: "wolfman",
			uids: [n.uid]
		};
	}
	if (r.invisibleman && n === "precinct") {
		let e = t.items.find((e) => le.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t));
		if (e) return {
			type: "advance",
			monster: "invisibleman",
			uids: [e.uid]
		};
	}
	return null;
}
function dr(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	let i = [], a = (e) => cr(t, e).length > 0;
	r.dracula && (r.dracula.coffins.length && a("red") ? i.push(...r.dracula.coffins) : !r.dracula.coffins.length && a("yellow") && i.push(r.dracula.space ?? "crypt")), r.creature && (t.items.length && r.creature.boat < rr ? i.push("camp") : r.creature.boat === rr && i.push(r.creature.space ?? "lagoon")), r.fb && (a("yellow") && r.fb.frank && i.push(r.fb.frank), a("blue") && r.fb.bride && i.push(r.fb.bride)), r.mummy && (a("yellow") ? i.push("museum") : a("red") && or(r.mummy.slots) && i.push(r.mummy.space ?? "museum")), r.wolfman && (a("blue") ? i.push("laboratory") : a("red") && r.wolfman.cure === t.id && i.push(r.wolfman.space ?? "mansion")), r.invisibleman && (t.items.some((e) => le.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t)) ? i.push("precinct") : a("red") && r.invisibleman.spots.every((e) => e !== null) && i.push(r.invisibleman.space ?? "inn"));
	let o = ir(n), s = i.filter((e) => o.has(e));
	if (s.length) return s.sort((e, t) => (o.get(e) ?? 0) - (o.get(t) ?? 0)), s[0];
	let c = e.spaceItems.filter((e) => e.items.length && o.has(e.space));
	if (c.length) return c.sort((e, t) => (o.get(e.space) ?? 0) - (o.get(t.space) ?? 0)), c[0].space;
	let l = [];
	r.dracula?.space && l.push(r.dracula.space), r.creature?.space && l.push(r.creature.space), r.fb?.frank && l.push(r.fb.frank), r.fb?.bride && l.push(r.fb.bride), r.mummy?.space && l.push(r.mummy.space), r.wolfman?.space && l.push(r.wolfman.space), r.invisibleman?.space && l.push(r.invisibleman.space);
	let u = l.filter((e) => o.has(e));
	return u.length ? (u.sort((e, t) => (o.get(e) ?? 0) - (o.get(t) ?? 0)), u[0]) : null;
}
function fr(e) {
	let t = e.monsters.mummy;
	if (!t) return { type: "mummyDone" };
	let n = t.slots;
	for (let e of j) {
		let t = n[e];
		if (!(t.num <= 0 || !t.faceUp)) {
			for (let r of M[e]) if (n[r].num === 0 && t.num === Number(r)) return {
				type: "mummySlide",
				from: e,
				to: r
			};
		}
	}
	for (let e of j) if (n[e].num > 0 && !n[e].faceUp) return {
		type: "mummyFlip",
		slot: e
	};
	return { type: "mummyDone" };
}
function pr(e) {
	let t = e.fbMoves;
	if (!t) return { type: "fbDone" };
	let n = e.monsters.fb;
	if (!n) return { type: "fbDone" };
	let r = t.figure === "frank" ? n.frank : n.bride, i = t.figure === "frank" ? n.bride : n.frank;
	if (!r || !i || r === i) return { type: "fbDone" };
	let a = ir(r).get(i);
	if (a !== void 0 && a <= t.remaining) return {
		type: "fbMove",
		to: i
	};
	let o = ar(r, i);
	return o ? {
		type: "fbMove",
		to: o
	} : { type: "fbDone" };
}
function mr(e) {
	let t = e.prompt;
	if (!t) return null;
	let n = t.options;
	if (!n.length) return null;
	let r = (e) => ({
		type: "choose",
		decision: t.decision,
		choice: e.id
	}), i = (e) => n.find((t) => !e || t.kind === e) ?? n[0];
	switch (t.kind) {
		case "defend": {
			let e = n.filter((e) => e.kind === "defend" && e.item);
			e.sort((e, t) => {
				let n = e.item.slice(0, e.item.indexOf("#")), r = t.item.slice(0, t.item.indexOf("#"));
				return S[n].strength - S[r].strength;
			});
			let t = e[0];
			return r(t ?? i("takeHit"));
		}
		case "attack":
		case "gaze": return r(n.find((e) => e.hero) ?? n[0]);
		case "thief": {
			let t = (t) => t ? e.spaceItems.find((e) => e.space === t)?.items.length ?? 0 : 0;
			return r([...n].sort((e, n) => t(e.space) - t(n.space))[0]);
		}
		case "heroDest":
		case "investigate":
		case "investigateHero":
		case "hurry": return r(i("space"));
		case "carry": return r(i("carryConfirm"));
		case "figureDest":
		case "repel": return r(i("stay"));
		case "moveFigure":
		case "moveHero":
		case "placeFigure":
		case "deliveryFrom":
		case "deliveryTo":
		case "deliveryItem": return r(n[0]);
		case "perkMode": return r(i("modeMove"));
		default: return r(n[0]);
	}
}
var hr = (e, t) => {
	let n = e.public;
	if (n.ending || n.phase === "done") return null;
	if (n.prompt) {
		if (!n.prompt.owners.includes(t.rid) || n.turn.owner !== t.rid) return null;
		let e = mr(n);
		return e ? { action: e } : null;
	}
	if (n.turn.owner !== t.rid) return null;
	let r = n.heroes.find((e) => e.id === n.turn.hero);
	if (!r || r.defeated) return null;
	if (n.mummyMoves > 0) return { action: fr(n) };
	if (n.fbMoves) return { action: pr(n) };
	if (n.phase !== "hero") return null;
	let i = r.space;
	if (!i) return null;
	let a = (e) => r.perks.find((t) => t.id === e);
	if (n.turn.actionsLeft <= 1) {
		let e = a("lateNight");
		if (e) return { action: {
			type: "playPerk",
			uid: e.uid
		} };
	}
	let o = a("breakOfDawn");
	if (o && n.monsterDeckCount > 0) return { action: {
		type: "playPerk",
		uid: o.uid
	} };
	if (n.turn.actionsLeft <= 0) return { action: { type: "endTurn" } };
	let s = lr(n, r);
	if (s) return { action: s };
	let c = ur(n, r);
	if (c) return { action: c };
	let l = n.spaceItems.find((e) => e.space === i);
	if (l?.items.length) return { action: {
		type: "pickup",
		uids: l.items.slice(0, 12).map((e) => e.uid)
	} };
	let u = dr(n, r);
	if (u && u !== i) {
		let e = ar(i, u);
		if (e) return { action: {
			type: "move",
			to: e,
			villagers: Object.values(n.villagers).filter((e) => e.status === "board" && e.space === i).map((e) => e.id)
		} };
	}
	return { action: { type: "endTurn" } };
}, gr = {
	triumph: "games.horrified.endingWin",
	terror: "games.horrified.endingTerror",
	time: "games.horrified.endingTime"
};
function _r({ public: e, members: t, onPlayAgain: n, onBackToLobby: r }) {
	let i = s(), o = e, l = !!o.ending?.win, u = o.ending?.reason ?? (l ? "triumph" : "terror"), d = Object.values(o.villagers).filter((e) => e.status === "safe").length, p = Object.values(o.villagers).filter((e) => e.status === "defeated").length, ee = (e) => t.find((t) => t.rid === e)?.name ?? e, te = n ?? r;
	return /* @__PURE__ */ h("div", {
		className: `hf-over ${l ? "is-win" : "is-loss"}`,
		children: /* @__PURE__ */ h(f, {
			adaptive: !0,
			scroll: !1,
			className: "hf-over-screen",
			banner: /* @__PURE__ */ g("header", {
				className: "hf-over-heading",
				children: [
					/* @__PURE__ */ h("p", {
						className: "hf-over-kicker",
						children: i("games.horrified.name")
					}),
					/* @__PURE__ */ h("h1", {
						className: "hf-over-title",
						children: i(l ? "games.horrified.overWin" : "games.horrified.overLoss")
					}),
					/* @__PURE__ */ h("p", {
						className: "hf-over-reason",
						children: i(gr[u])
					})
				]
			}),
			actionsHeight: "hf-over-action-height",
			actions: te ? /* @__PURE__ */ g("div", {
				className: "hf-over-actions safe-b",
				children: [n && /* @__PURE__ */ h("button", {
					type: "button",
					className: "hf-over-btn is-primary",
					onClick: n,
					children: i("session.result.playAgain")
				}), r && /* @__PURE__ */ h("button", {
					type: "button",
					className: "hf-over-btn",
					onClick: r,
					children: i("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "hf-over-wait safe-b",
				children: i("session.result.waitHost")
			}),
			children: /* @__PURE__ */ g("div", {
				className: "hf-over-body",
				children: [
					/* @__PURE__ */ g("ul", {
						className: "hf-over-stats",
						children: [
							/* @__PURE__ */ g("li", { children: [/* @__PURE__ */ g("span", {
								className: "hf-over-stat-value",
								children: [
									o.defeated.length,
									" / ",
									o.chosen.length
								]
							}), /* @__PURE__ */ h("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overMonsters")
							})] }),
							/* @__PURE__ */ g("li", { children: [/* @__PURE__ */ g("span", {
								className: "hf-over-stat-value",
								children: [d, " / 10"]
							}), /* @__PURE__ */ h("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overRescued")
							})] }),
							/* @__PURE__ */ g("li", { children: [/* @__PURE__ */ g("span", {
								className: "hf-over-stat-value",
								children: [o.terror, " / 7"]
							}), /* @__PURE__ */ h("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overTerror")
							})] })
						]
					}),
					/* @__PURE__ */ h("ul", {
						className: "hf-over-monsters",
						children: o.chosen.map((e) => /* @__PURE__ */ g("li", {
							className: o.defeated.includes(e) ? "is-cleared" : "",
							children: [/* @__PURE__ */ h("span", {
								className: "hf-over-monster-name",
								children: i(en[e])
							}), o.defeated.includes(e) && /* @__PURE__ */ h("span", {
								className: "hf-over-monster-tag",
								children: i("games.horrified.defeatedTag")
							})]
						}, e))
					}),
					p > 0 && /* @__PURE__ */ h("p", {
						className: "hf-over-note",
						children: i("games.horrified.overVillagersLost", { n: p })
					}),
					/* @__PURE__ */ h("ul", {
						className: "hf-over-members",
						children: t.map((e) => /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ h("span", {
							className: "hf-over-avatar",
							style: { background: c[e.colorIndex % c.length].hex },
							children: /* @__PURE__ */ h("img", {
								src: a[e.avatar % a.length],
								alt: "",
								draggable: !1
							})
						}), /* @__PURE__ */ h("span", {
							className: "hf-over-name",
							children: ee(e.rid)
						})] }, e.rid))
					})
				]
			})
		})
	});
}
//#endregion
//#region src/game/options.tsx
var vr = {
	dracula: "#7b3fb5",
	mummy: "#b58b3f",
	frankenstein: "#4f7d4a",
	creature: "#2f7d8f",
	wolfman: "#8c5a2f",
	invisibleman: "#6b6f8a"
};
function yr({ value: e, onChange: t }) {
	let n = s(), r = Dt.catch({ monsters: ["creature", "dracula"] }).parse(e), i = r.monsters.length, a = (e) => {
		t({ monsters: r.monsters.includes(e) ? r.monsters.filter((t) => t !== e) : [...r.monsters, e] });
	};
	return /* @__PURE__ */ g("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ h(ie, {
				title: n("games.horrified.monstersChosen"),
				count: n("games.horrified.optionsCount", { n: i }),
				columns: 3,
				children: T.map((e) => /* @__PURE__ */ h(re, {
					name: "horrified-monster",
					value: e,
					checked: r.monsters.includes(e),
					disabled: !r.monsters.includes(e) && i >= 4,
					accent: vr[e],
					label: n(en[e]),
					onChange: () => a(e)
				}, e))
			}),
			/* @__PURE__ */ h("p", {
				className: "text-xs leading-snug text-ink/65",
				children: n("games.horrified.optionsHint")
			}),
			i === 0 && /* @__PURE__ */ h("p", {
				className: "text-xs font-bold text-rose-700",
				children: n("games.horrified.optionsInvalid")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var br = {
	definition: Kt,
	View: tr,
	bot: hr,
	OverView: _r,
	Options: yr,
	locales: {
		zh: {
			name: "夺命惊魂",
			desc: "合作对抗德古拉、科学怪人等经典怪物，在恐惧吞噬全城之前完成并击败所有怪物",
			rules: "目标:\n你们扮演同城的民间英雄，在恐惧吞噬全城之前完成所有被选中怪物的任务，并把它们逐一击败。所选怪物全部被击败时，你们立即获胜。\n恐惧值表示全城的不安程度。每有一名英雄或村民被击败，恐惧值上升一点；恐惧值到达七点时，你们立即失败。\n怪物牌堆耗尽后，若还需要翻开一张怪物卡，你们立即失败。\n准备:\n· 将版图展开。本局可以选择一到四只怪物；第一次游戏推荐选择黑湖妖潭与德古拉。\n· 每名玩家随机获得一张英雄徽章，把自己的英雄棋子放在徽章标示的起始地点。\n· 将六十张物品卡洗混，正面朝下组成物品袋。从物品袋中抽出十二张物品，逐一放到各自卡面印制的出现地点；之后抽出的物品同样放到印制地点。\n· 将三十张怪物卡洗混，正面朝下组成怪物牌堆；将二十张特殊牌洗混，组成特殊牌堆，并给每名玩家发一张正面朝上的特殊牌。\n· 按照所选怪物的配置放好棋子与配件。德古拉放在墓穴，四具棺材分别放在墓穴、地牢、墓地与洞穴；黑湖妖潭放在咸水湖，船放在怪物垫上的起点；科学怪人放在墓地，其新娘放在地牢；木乃伊放在博物馆，并按怪物任务说明摆好圣甲虫谜题；狼人放在豪宅，解药放在怪物垫右侧；隐形人放在旅店。\n· 恐惧标记放在零位。单人游戏时，恐惧标记改为放在三点位，并从特殊牌堆中移除特殊投递与调查两张牌。\n· 由第一位入座的玩家开始行动，之后按入座顺序轮流进行回合。\n回合:\n每名玩家的回合分为英雄阶段与怪物阶段，依次进行。\n英雄阶段中，当前玩家按照英雄徽章所示的行动数执行行动。每次移动、引导、拾取、分享、推进任务、击败怪物或使用特殊行动，各消耗一个行动。\n任何玩家都可以在英雄阶段随时打出自己持有的特殊牌，打出特殊牌不消耗行动。\n当前玩家结束英雄阶段后，进入怪物阶段。\n怪物阶段依次翻开一张怪物卡，结算卡上的物品、事件与怪物行动，然后轮到下一名玩家。\n英雄行动:\n· 移动：把英雄移到相邻的陆地点。英雄可以把当前地点任意数量的村民一起带到目的地。由特殊牌或特殊行动产生的移动同样遵循移动规则，可以带走同地点的村民。\n· 引导：把与英雄同一地点的一名村民移到相邻的陆地点，或者把相邻地点的一名村民移到英雄所在地点。\n· 拾取：拿取当前地点任意数量的物品。\n· 分享：当前地点任意两名英雄可以互相转交任意数量的物品，不必涉及当前英雄；持有解药的英雄也可以把解药交给同地点的其他英雄。分享消耗一个行动。\n· 推进任务：按照怪物任务的要求，在指定地点使用物品。被使用的物品放入物品弃牌堆。\n· 击败怪物：按照怪物任务的要求，在怪物所在地点使用物品。被使用的物品放入物品弃牌堆。\n· 特殊行动：按照英雄徽章上的说明执行。特殊行动同样消耗一个行动；科学家的能力持续生效，不消耗行动。\n水地点包括咸水湖、河流与码头岸边。英雄与村民不能进入水地点；只有黑湖妖潭可以进入水地点。\n物品:\n物品分为红、蓝、黄三色，卡面数字表示物品的强度。科学家使用物品时，物品的强度增加一点。\n抽取物品时，把物品放在卡面印制的出现地点。物品袋为空时，把物品弃牌堆洗混，作为新的物品袋。\n英雄被怪物命中时，可以弃掉一张物品抵消这次命中；如果没有物品可以弃，或者选择不弃物品，英雄被击败。\n村民:\n十名村民各自有一个安全地点。村民因事件出现在其出场地点。\n村民到达安全地点时立即获救，并从棋盘移出；当前玩家抽取一张特殊牌。\n村民被怪物命中时立即被击败，恐惧值上升一点。村民没有物品，无法抵消命中。\n英雄被击败:\n英雄被击败时，把英雄棋子移出棋盘，恐惧值上升一点。\n被击败的玩家在自己的下一个回合开始时，把英雄放回医院，并以完整的行动数继续游戏。英雄保留全部物品与特殊牌。\n怪物阶段:\n怪物卡分为物品、事件与怪物行动三段，按顺序结算。\n· 物品：按卡面所示数量抽取物品，逐一放到其印制的出现地点。\n· 事件：按卡面说明执行。事件涉及的怪物不在本局或已被击败时，忽略该事件。\n· 怪物行动：按卡面从左到右逐个结算。每个怪物符号让对应怪物朝最近的人物移动，最多移动卡面所示的步数，走到人物所在的地点即停止；然后该怪物攻击一个目标。被攻击的英雄可以弃一张物品抵消命中；命中无法抵消时英雄被击败。村民被命中时立即被击败。怪物同时有英雄与村民可选时，优先攻击英雄；距离相同且目标不止一个时，由当前玩家在掷骰前选择目标。\n· 骰子每颗有三个命中面、两个空白面和一个力量面。每个命中造成一次命中，每个力量触发一次该怪物的力量。\n· 狂暴符号让持有狂暴标记的怪物再执行一次行动。开局时狂暴标记放在狂暴顺序最低的在场怪物上；事件要求移交时，交给狂暴顺序更高的下一只在场怪物。\n怪物任务:\n德古拉:\n· 任务：在有棺材的地点使用任意数量的红色物品，总强度达到六点，砸碎该地点的棺材。\n· 击败：四具棺材全部砸碎后，在德古拉所在地点使用任意数量的黄色物品，总强度达到六点。\n· 力量：黑暗魅惑。把当前玩家的英雄移到德古拉所在地点。\n黑湖妖潭:\n· 任务：在营地使用一张任意颜色的物品，把船推进到下一处该颜色的标记。船道共有十九站，第十九站为巢穴；巢穴标记为蓝色，因此推进到巢穴的物品必须是蓝色。\n· 击败：船停在巢穴后，在黑湖妖潭所在地点使用红、蓝、黄物品各一张。\n· 力量：把船向起点后退一站。\n科学怪人与新娘:\n· 任务：在科学怪人所在地点使用一张黄色物品，增加科学怪人的人性进度；在新娘所在地点使用一张蓝色物品，增加新娘的人性进度。进度增加量等于物品强度，随后可以让该怪物移动至多等同于进度增加量的步数。科学怪人的目标为十一点，新娘的目标为八点；达到目标时，该怪物的转盘翻面。\n· 击败：两只怪物的转盘都翻面后，只要它们位于同一地点，就立即被击败，不需要执行击败行动。\n· 相遇：两只怪物在转盘全部翻面前进入同一地点时，恐惧值上升一点，然后把科学怪人放回墓地，把新娘放回地牢。\n· 力量：新娘朝科学怪人移动一步。\n木乃伊:\n· 谜题：圣甲虫谜题有六个编号位与一个中央空位。开局时，编号一到三的圣甲虫随机放在左侧三个位置，编号四到六的圣甲虫随机放在右侧三个位置，全部正面朝上。\n· 任务：在博物馆使用一张黄色物品，获得等同于物品强度的移动次数。一次移动可以把一只正面朝上的圣甲虫滑到相邻空位，或者把一只反面朝上的圣甲虫翻回正面。\n· 击败：六只圣甲虫全部正面朝上，并且编号一到六各自位于对应编号的位置，中央空位为空；此后在木乃伊所在地点使用任意数量的红色物品，总强度达到九点。\n· 力量：把当前正面朝上且编号最小的圣甲虫翻成反面。\n狼人:\n· 任务：在实验室使用一张蓝色物品，把它放进强度相符的空血瓶位。血瓶位需要的强度依次为一、一、二、二、三、三。科学家可以使用强度比空位高一点的物品。\n· 解药：六个血瓶位全部填满时，填上最后一个血瓶位的英雄取得解药。解药可以交给其他英雄，但不能用于抵消命中。\n· 击败：由持有解药的英雄在狼人所在地点使用解药，并弃掉任意数量的红色物品，总强度达到六点。\n· 力量：狼人所在地点的所有人物各受一次命中。\n隐形人:\n· 任务：在警局使用一张物品，若该物品的印制地点与任一空线索位相符，就把物品放进该线索位。线索位分别在旅店、谷仓、豪宅、实验室与学院。\n· 击败：五个线索位全部填满后，在隐形人所在地点使用任意数量的红色物品，总强度达到九点。\n· 力量：隐形人朝最近的村民移动两步。\n特殊牌:\n英雄救出村民时，当前玩家抽取一张特殊牌。任何玩家可以在英雄阶段打出自己持有的特殊牌，打出特殊牌不消耗行动。\n· 破晓：跳过下一次怪物阶段，并抽取两张物品。\n· 深夜：当前回合额外获得两个行动。\n· 侦探来访：把隐形人放到任意地点，或者把任意怪物移动三格。\n· 出租车：把一名英雄放到任意非水地点。\n· 挥舞十字架：把德古拉放到任意地点，或者把任意怪物移动三格。\n· 疾行：把一名英雄移动至多四格。\n· 私刑：把科学怪人或新娘放到任意地点，或者把任意怪物移动三格。\n· 囤积：每名玩家各抽取一张物品。\n· 特殊投递：一名英雄可以把任意数量物品交给另一名英雄，不受地点限制。\n· 催促：每名英雄移动至多两格。\n· 调查：选择一个有英雄的地点，把任意数量英雄放到该地点。\n· 猎物：把狼人放到任意地点，或者把任意怪物移动三格。\n· 古老之力：把木乃伊放到任意地点，或者把任意怪物移动三格。\n· 炫耀武力：把黑湖妖潭放到任意地点，或者把任意怪物移动三格。\n· 击退：把每只怪物移动至多两格。\n游戏结束:\n所选怪物全部被击败时，你们立即获胜。\n恐惧值到达七点时，你们立即失败。\n怪物牌堆为空时，若还需要翻开怪物卡，你们立即失败。最后一张怪物卡会完整结算，之后先进行最后一次英雄阶段，再判断是否还有牌可翻。\n单人游戏:\n单人游戏由一名玩家控制一名英雄，其余规则不变。\n· 恐惧值从三点开始。\n· 不使用信使；开局时从英雄池中排除信使。\n· 从特殊牌堆中移除特殊投递与调查两张牌。\n· 推荐选择两只怪物进行单人游戏。",
			phaseHero: "英雄阶段",
			phaseMonster: "怪物阶段",
			phaseDone: "对局结束",
			terror: "恐惧 {{n}} / 7",
			turnLabel: "{{name}} 的回合",
			yourTurn: "轮到你行动",
			waitingTurn: "等待{{name}}行动…",
			actionsLeft: "行动 {{left}} / {{max}}",
			handTitle: "物品",
			handEmpty: "尚未持有物品",
			perksTitle: "特殊牌",
			perksEmpty: "尚未持有特殊牌",
			playPerk: "打出",
			itemStrength: "强度 {{n}}",
			colorRed: "红",
			colorBlue: "蓝",
			colorYellow: "黄",
			itemAria: "{{item}}，{{color}}色，强度 {{n}}",
			boardItems: "地点的物品",
			boardLabel: "小镇地图",
			waterTag: "水域",
			noItems: "没有物品",
			personsHere: "人物",
			noPersons: "没有人物",
			monstersHere: "怪物",
			noMonsters: "没有怪物",
			spaceActions: "可执行行动",
			noSpaceActions: "此处没有可用行动",
			moveTo: "移动到{{space}}",
			moveWith: "带 {{n}} 名村民同行",
			guideTitle: "引导村民",
			guideTo: "把{{villager}}引导到{{space}}",
			pickupTitle: "拾取物品",
			pickupN: "拾取所选 {{n}} 张",
			shareTitle: "转交物品",
			shareFrom: "由{{hero}}给出",
			shareTo: "交给{{hero}}",
			giveCure: "交出解药",
			advanceTitle: "推进任务",
			advanceButton: "推进{{monster}}",
			defeatTitle: "击败怪物",
			defeatButton: "击败{{monster}}",
			specialTitle: "特殊行动",
			specialButton: "使用{{hero}}的特殊行动",
			endTurn: "结束回合",
			doneButton: "完成",
			cancel: "取消",
			close: "关闭",
			chooseTargetSpace: "选择目的地",
			chooseTargetHero: "选择英雄",
			chooseTargetVillager: "选择村民",
			chooseTargetFigure: "选择怪物",
			chooseMode: "选择效果",
			modePlace: "放置到任意地点",
			modeMove: "移动任意怪物三格",
			stay: "留在原地",
			skipMove: "不移动",
			done: "完成",
			leadTitle: "同行村民",
			noLeadVillager: "没有可同行的村民",
			selectItemsTitle: "选择物品",
			selectItemsHint: "点击物品切换选择",
			needItems: "至少选择一张物品",
			strengthSum: "已选强度 {{n}}",
			strengthNeed: "需要总强度 {{n}}",
			invalidSelection: "当前选择不满足任务条件",
			heroOwner: "{{hero}}（{{name}}）",
			youTag: "你",
			heroDefeated: "已被击败",
			heroRevive: "下一个回合在医院复苏",
			tasksTitle: "怪物任务",
			openTasks: "怪物任务",
			taskAdvance: "任务",
			taskDefeat: "击败",
			taskPower: "力量",
			defeatedTag: "已击败",
			frenzyTag: "狂暴",
			coffins: "棺材 {{n}} / 4",
			boat: "船 {{n}} / 19",
			boatLair: "船已停在巢穴",
			bottles: "血瓶 {{n}} / 6",
			spots: "线索 {{n}} / 5",
			cureLabel: "解药",
			cureHolder: "解药：{{hero}}",
			cureUnclaimed: "解药尚未取得",
			mummyPuzzle: "圣甲虫谜题",
			mummySolved: "圣甲虫已全部归位",
			mummyUnsolved: "圣甲虫尚未全部归位",
			frankProgress: "科学怪人进度 {{n}} / {{target}}",
			brideProgress: "新娘进度 {{n}} / {{target}}",
			bag: "物品袋 {{n}}",
			itemDiscard: "物品弃牌 {{n}}",
			monsterDeck: "怪物牌堆 {{n}}",
			monsterDiscard: "怪物弃牌 {{n}}",
			perkDeck: "特殊牌堆 {{n}}",
			perkDiscard: "特殊牌弃牌 {{n}}",
			lastRollTitle: "最近一次掷骰",
			rollHits: "命中 {{n}}",
			rollPowers: "力量 {{n}}",
			cardLabel: "怪物卡 {{n}}",
			eventLabel: "事件：{{event}}",
			huntedTag: "追猎：{{hero}}",
			soulTag: "灵位：{{hero}}",
			frenzyShort: "狂暴：{{monster}}",
			villagersTitle: "村民",
			rescuedCount: "已获救 {{n}} / 10",
			railNoVillagers: "场上暂无村民",
			villagerNone: "未出场",
			villagerAt: "在{{space}}",
			villagerSafeTag: "安全地点",
			villagerSafe: "安全地点：{{space}}",
			villagerSafeStatus: "已获救",
			villagerDefeatedStatus: "被击败",
			logTitle: "行动记录",
			openLog: "行动记录",
			logEmpty: "暂无记录",
			promptTitle: "请选择",
			promptWaiting: "等待{{name}}选择…",
			promptAttack: "选择被攻击的目标",
			promptDefend: "被命中：弃物品抵消或承受攻击",
			promptThief: "隐形人窃贼：选择地点",
			promptPlaceFigure: "选择要放置的怪物",
			promptFigureDest: "{{figure}}的移动目的地",
			promptMoveFigure: "选择要移动的怪物",
			promptHeroDest: "{{hero}}的移动目的地",
			promptMoveHero: "选择要移动的英雄",
			promptCarry: "选择要同行的村民",
			carryConfirm: "确认同行",
			promptHurry: "催促{{hero}}移动两格",
			promptInvestigate: "调查：选择集合地点",
			promptInvestigateHero: "把其他英雄聚集到这里",
			promptRepel: "击退：选择要移动的怪物",
			promptDeliveryFrom: "特殊投递：选择交出物品的英雄",
			promptDeliveryTo: "特殊投递：选择接收物品的英雄",
			promptDeliveryItem: "选择交给{{hero}}的物品",
			promptGaze: "催眠凝视：选择被牵引的人物",
			promptPerkMode: "选择特殊牌效果",
			takeHit: "承受攻击",
			defendWith: "弃掉{{item}}抵消",
			mummyPending: "圣甲虫移动：剩余 {{n}} 次",
			mummySlideHint: "点击一只正面朝上的圣甲虫，再点击相邻空位",
			mummyFlipHint: "点击反面朝上的圣甲虫把它翻正",
			mummyDoneButton: "完成谜题",
			mummyPickFirst: "先选择一只正面朝上的圣甲虫",
			mummyInvalidTarget: "只能滑到相邻空位",
			fbPending: "移动{{figure}}：剩余 {{n}} 步",
			fbPendingHint: "点击高亮地点移动，或选择完成",
			endingTitle: "对局结束",
			endingWin: "所有怪物都被击败，你们获胜",
			endingTerror: "恐惧值到达七点，你们失败",
			endingTime: "怪物牌堆耗尽，你们失败",
			overWin: "小镇得救了",
			overLoss: "恐惧吞噬了小镇",
			overMonsters: "已击败怪物",
			overRescued: "已获救村民",
			overTerror: "最终恐惧",
			overVillagersLost: "有 {{n}} 名村民被击败。",
			invalidAction: "当前操作无法执行",
			waitingOther: "等待其他玩家…",
			selectPerkConfirm: "打出{{perk}}",
			cancelsPerk: "暂不打出",
			pendingMoves: "{{figure}}移动中",
			monstersChosen: "本局怪物",
			deckInfo: "牌堆",
			itemAt: "{{item}}出现在{{space}}",
			safeSpaceShort: "安全地点",
			monstersTitle: "怪物",
			heroesTitle: "英雄",
			optionsHint: "选择本局要对抗的怪物，数量为一到四只。",
			optionsRecommended: "推荐组合",
			optionsRecommendedValue: "黑湖妖潭与德古拉",
			optionsCount: "已选择 {{n}} 只",
			optionsInvalid: "至少选择一只怪物，最多选择四只",
			spaceCave: "洞穴",
			spaceCamp: "营地",
			spacePrecinct: "警局",
			spaceInn: "旅店",
			spaceBarn: "谷仓",
			spaceDungeon: "地牢",
			spaceLagoon: "咸水湖",
			spaceBridgeWest: "西桥",
			spaceFountain: "喷泉",
			spaceLamp: "路灯路口",
			spaceMansion: "豪宅",
			spaceAbbey: "修道院",
			spaceCrypt: "墓穴",
			spaceMuseum: "博物馆",
			spaceChurch: "教堂",
			spaceHospital: "医院",
			spaceGraveyard: "墓地",
			spaceLaboratory: "实验室",
			spaceInstitute: "学院",
			spaceWaterfront: "码头岸边",
			spaceDocks: "码头",
			spaceTower: "塔楼",
			spaceTheatre: "剧院",
			spaceRiver: "河流",
			spaceBridgeEast: "东桥",
			spaceShop: "商店",
			itemBeartrap: "熊夹",
			itemRapier: "细剑",
			itemPistol: "手枪",
			itemSilvercane: "银手杖",
			itemShovel: "铁锹",
			itemPitchfork: "干草叉",
			itemDart: "飞镖",
			itemKnife: "刀",
			itemFirepoker: "拨火棍",
			itemTorch: "火把",
			itemSpeargun: "鱼叉枪",
			itemRifle: "步枪",
			itemResearch: "研究资料",
			itemAnatomy: "解剖学书",
			itemKite: "风筝",
			itemRotenone: "鱼藤酮",
			itemCentrifuge: "离心机",
			itemFossil: "化石",
			itemAnalysis: "分析报告",
			itemTelescope: "望远镜",
			itemExperiment: "实验记录",
			itemSearchlight: "探照灯",
			itemCamera: "相机",
			itemCosmicray: "宇宙射线扩散器",
			itemMonocane: "曼陀罗合剂",
			itemNebularium: "雾化器",
			itemTablet: "石板",
			itemFlower: "花",
			itemWine: "葡萄酒",
			itemGarlic: "大蒜",
			itemCharm: "护符",
			itemTarot: "塔罗牌",
			itemMirroredbox: "镜匣",
			itemCrucifix: "十字架",
			itemWolfsbane: "附子草",
			itemViolin: "小提琴",
			itemStake: "木桩",
			itemScroll: "托特卷轴",
			itemCanopic: "卡诺匹斯罐",
			heroArchaeologist: "考古学家",
			heroCourier: "信使",
			heroExplorer: "探险家",
			heroInspector: "督察",
			heroMayor: "市长",
			heroProfessor: "教授",
			heroScientist: "科学家",
			heroArchaeologistShort: "考古",
			heroCourierShort: "信使",
			heroExplorerShort: "探险",
			heroInspectorShort: "督察",
			heroMayorShort: "市长",
			heroProfessorShort: "教授",
			heroScientistShort: "科学",
			heroArchaeologistSpecial: "特殊行动：从相邻地点取走物品。",
			heroCourierSpecial: "特殊行动：移到任意有另一名英雄的地点。",
			heroExplorerSpecial: "特殊行动：移到任意非水地点。",
			heroInspectorSpecial: "特殊行动：移到任意有怪物的非水地点。",
			heroMayorSpecial: "没有特殊行动，但每回合有五个行动。",
			heroProfessorSpecial: "特殊行动：把任一英雄或村民移动一格。",
			heroScientistSpecial: "被动能力：使用物品时，物品强度增加一点。",
			villagerFritz: "弗里茨",
			villagerMaria: "玛丽亚",
			villagerMaleva: "玛列娃",
			villagerPearson: "皮尔逊教授",
			villagerWilbur: "威尔伯与奇克",
			villagerRenfield: "伦菲尔德",
			villagerReed: "里德博士",
			villagerCranley: "克兰利博士",
			villagerLucy: "露西",
			villagerElizabeth: "伊丽莎白",
			villagerFritzShort: "弗里",
			villagerMariaShort: "玛丽",
			villagerMalevaShort: "玛列",
			villagerPearsonShort: "皮尔",
			villagerWilburShort: "威尔",
			villagerRenfieldShort: "伦菲",
			villagerReedShort: "里德",
			villagerCranleyShort: "克兰",
			villagerLucyShort: "露西",
			villagerElizabethShort: "伊丽",
			monsterDracula: "德古拉",
			monsterMummy: "木乃伊",
			monsterFrankenstein: "科学怪人",
			monsterBride: "新娘",
			monsterCreature: "黑湖妖潭",
			monsterWolfman: "狼人",
			monsterInvisibleman: "隐形人",
			monsterDraculaShort: "德古",
			monsterMummyShort: "木乃",
			monsterFrankensteinShort: "科学",
			monsterCreatureShort: "海怪",
			monsterWolfmanShort: "狼人",
			monsterInvisiblemanShort: "隐形",
			monsterFrankShort: "弗兰",
			monsterBrideShort: "新娘",
			monsterDraculaAdvance: "德古拉位于有棺材的地点时，使用任意数量的红色物品，总强度达到六点，砸碎该地点的棺材。",
			monsterDraculaDefeat: "四具棺材全部砸碎后，在德古拉所在地点使用任意数量的黄色物品，总强度达到六点。",
			monsterDraculaPower: "黑暗魅惑：把当前玩家的英雄移到德古拉所在地点。",
			monsterCreatureAdvance: "在营地使用一张任意颜色的物品，把船推进到下一处该颜色的标记。",
			monsterCreatureDefeat: "船停在巢穴后，在黑湖妖潭所在地点使用红、蓝、黄物品各一张。",
			monsterCreaturePower: "把船向起点后退一站。",
			monsterFrankensteinAdvance: "在科学怪人所在地点使用黄色物品，在新娘所在地点使用蓝色物品，按强度增加人性进度并移动对应步数。",
			monsterFrankensteinDefeat: "两者转盘都翻面后，位于同一地点时立即被击败。",
			monsterFrankensteinPower: "新娘朝科学怪人移动一步。",
			monsterMummyAdvance: "在博物馆使用一张黄色物品，获得等同于其强度的圣甲虫移动次数。",
			monsterMummyDefeat: "圣甲虫全部归位后，在木乃伊所在地点使用任意数量的红色物品，总强度达到九点。",
			monsterMummyPower: "把当前正面朝上且编号最小的圣甲虫翻成反面。",
			monsterWolfmanAdvance: "在实验室使用一张蓝色物品，把它放进强度相符的空血瓶位。",
			monsterWolfmanDefeat: "由持有解药的英雄在狼人所在地点使用解药，并弃掉任意数量的红色物品，总强度达到六点。",
			monsterWolfmanPower: "狼人所在地点的所有人物各受一次命中。",
			monsterInvisiblemanAdvance: "在警局使用一张物品，其印制地点与空线索位相符时，把物品放进该线索位。",
			monsterInvisiblemanDefeat: "五个线索位全部填满后，在隐形人所在地点使用任意数量的红色物品，总强度达到九点。",
			monsterInvisiblemanPower: "隐形人朝最近的村民移动两步。",
			eventOnTheMove: "怪物迁徙：狂暴标记移交给下一只怪物，村民朝安全地点移动一格。",
			eventMeeting: "相会：新娘朝科学怪人移动两格。",
			eventHunt: "追猎：指定一名英雄，狼人朝其移动三格。",
			eventThief: "窃贼：隐形人移到物品最多的地点，并弃掉该地点的全部物品。",
			eventRetreatLagoon: "退却：黑湖妖潭移到咸水湖。",
			eventRetreatRiver: "退却：黑湖妖潭移到河流。",
			eventRetreatWaterfront: "退却：黑湖妖潭移到码头岸边。",
			eventInnocent: "无辜者：玛丽亚出现在谷仓。",
			eventInsaneSurvivor: "疯癫的幸存者：伦菲尔德出现在码头。",
			eventWorriedFiancee: "忧心的未婚妻：伊丽莎白出现在豪宅。",
			eventEnthralled: "被蛊惑者：露西出现在剧院。",
			eventDelivery: "送信人：威尔伯与奇克出现在商店。",
			eventFortuneTeller: "占卜师：玛列娃出现在营地。",
			eventHurriedAssistant: "匆忙的助手：弗里茨出现在塔楼。",
			eventReincarnatedSoul: "转世灵魂：指定一名英雄持有灵位，并朝木乃伊移动三格。",
			eventHypnoticGaze: "催眠凝视：离德古拉最近的人物朝德古拉移动三格。",
			eventSunrise: "日出：德古拉回到墓穴。",
			eventFormOfTheBat: "蝙蝠形态：德古拉移到当前玩家英雄的地点。",
			eventEgyptianExpert: "埃及学者：皮尔逊教授出现在洞穴。",
			eventFormerEmployer: "旧日雇主：克兰利博士出现在实验室。",
			eventIchthyologist: "鱼类学家：里德博士出现在学院。",
			perkBreakOfDawn: "破晓：跳过下一次怪物阶段，并抽取两张物品。",
			perkLateNight: "深夜：当前回合额外获得两个行动。",
			perkDetective: "侦探来访：把隐形人放到任意地点，或者把任意怪物移动三格。",
			perkTaxiRide: "出租车：把一名英雄放到任意非水地点。",
			perkCrucifix: "挥舞十字架：把德古拉放到任意地点，或者把任意怪物移动三格。",
			perkRush: "疾行：把一名英雄移动至多四格。",
			perkMobJustice: "私刑：把科学怪人或新娘放到任意地点，或者把任意怪物移动三格。",
			perkOverstock: "囤积：每名玩家各抽取一张物品。",
			perkSpecialDelivery: "特殊投递：一名英雄可以把任意数量物品交给另一名英雄，不受地点限制。",
			perkHurry: "催促：每名英雄移动至多两格。",
			perkInvestigation: "调查：选择一个有英雄的地点，把任意数量英雄放到该地点。",
			perkHuntedPrey: "猎物：把狼人放到任意地点，或者把任意怪物移动三格。",
			perkAncients: "古老之力：把木乃伊放到任意地点，或者把任意怪物移动三格。",
			perkShowForce: "炫耀武力：把黑湖妖潭放到任意地点，或者把任意怪物移动三格。",
			perkRepel: "击退：把每只怪物移动至多两格。",
			logTurnStart: "{{hero}}开始行动",
			logHeroEnd: "{{hero}}结束行动",
			logHeroMoved: "{{hero}}移动到{{space}}",
			logVillagerMoved: "{{villager}}移动到{{space}}",
			logPickup: "{{hero}}拾取了 {{n}} 张物品",
			logItemGiven: "{{hero}}把物品交给{{hero2}}",
			logCureGiven: "{{hero}}把解药交给{{hero2}}",
			logAdvance: "{{hero}}使用物品推进{{figure}} {{n}} 点",
			logDefeat: "{{hero}}击败了{{monster}}",
			logMonsterDefeated: "{{monster}}被击败",
			logCoffinBroken: "{{hero}}砸碎了{{space}}的棺材",
			logBoatAdvance: "{{hero}}把船推进到第 {{n}} 站",
			logBoatBack: "船后退到第 {{n}} 站",
			logBottleFilled: "{{hero}}填入血瓶（需要 {{n}} 点强度）",
			logCureTaken: "{{hero}}取得解药",
			logSpotFilled: "{{hero}}补齐了{{space}}的线索",
			logMummyAdvance: "{{hero}}获得 {{n}} 次圣甲虫移动",
			logScarabSlide: "圣甲虫滑到空位",
			logScarabFlip: "圣甲虫翻回正面",
			logScarabFlipped: "圣甲虫被翻成反面",
			logMummyDone: "圣甲虫移动结束",
			logFbFlipped: "{{figure}}的转盘翻面",
			logFbMeet: "两只科学怪人相遇，恐惧上升",
			logFbDefeated: "两只科学怪人重逢，怪物被击败",
			logItemPlaced: "{{item}}出现在{{space}}",
			logTerror: "恐惧上升 {{n}} 点",
			logHeroDefeated: "{{hero}}被击败",
			logVillagerDefeated: "{{villager}}被击败",
			logVillagerPlaced: "{{villager}}出现在{{space}}",
			logRescued: "{{villager}}获救",
			logRevived: "{{hero}}在医院复苏",
			logMonsterCard: "翻开怪物卡 {{n}}",
			logMonsterMoved: "{{figure}}移动到{{space}}",
			logMonsterSkipped: "本次怪物阶段被跳过",
			logMonsterWillSkip: "下一次怪物阶段将被跳过",
			logRoll: "{{figure}}掷出 {{n}} 次命中与 {{n2}} 次力量",
			logHitHero: "{{hero}}被击中",
			logHitVillager: "{{villager}}被击中",
			logDefended: "{{hero}}弃掉{{item}}抵消命中",
			logCharmed: "{{hero}}被魅惑到{{space}}",
			logHunted: "{{hero}}被狼人追猎",
			logSoul: "{{hero}}取得灵位",
			logFrenzyMoved: "狂暴标记移到{{monster}}",
			logPerkGain: "{{hero}}获得特殊牌{{perk}}",
			logPerkPlayed: "打出特殊牌{{perk}}",
			logActions: "获得 {{n}} 个额外行动",
			logThief: "隐形人偷走了{{space}}的物品",
			logEventIgnored: "{{monster}}不在本局，事件被忽略",
			logWin: "胜利：怪物全部被击败",
			logLose: "失败",
			logFrenzy: "狂暴标记在{{monster}}上",
			logMoved: "{{figure}}移动到{{space}}",
			logAttack: "{{figure}}攻击{{who}}"
		},
		en: {
			name: "Horrified",
			desc: "Work together against Dracula, Frankenstein's monster, and other classic creatures to finish their tasks and defeat them all before terror overwhelms the town",
			rules: "Objective:\nYou play as local heroes. Before terror overwhelms the town, complete the tasks of every chosen monster and defeat them one by one. The moment every chosen monster is defeated, you win immediately.\nTerror marks how unsettled the town has become. Each time a hero or villager is defeated, terror rises by one. When terror reaches seven, you lose immediately.\nIf you must draw a monster card and the monster deck is empty, you lose immediately.\nSetup:\n· Unfold the board. You may choose one to four monsters for the game; for a first game, Dracula and the Creature from the Black Lagoon are recommended.\n· Each player takes a random hero badge and places their hero figure on the starting space shown on the badge.\n· Shuffle the sixty item cards face down to form the item bag. Draw twelve items from the bag and place each on the appearance space printed on its card; items drawn later are placed the same way.\n· Shuffle the thirty monster cards face down to form the monster deck, and shuffle the twenty perk cards to form the perk deck, then deal one face-up perk card to each player.\n· Set up the figures and components for each chosen monster. Place Dracula in the Crypt, with the four coffins in the Crypt, the Dungeon, the Graveyard, and the Cave; place the Creature in the Lagoon with the boat at the start of its monster mat; place Frankenstein's monster in the Graveyard and the Bride in the Dungeon; place the Mummy in the Museum and set up the scarab puzzle as its task explains; place the Wolfman in the Mansion with the antidote on the right side of its monster mat; place the Invisible Man in the Inn.\n· Place the terror marker on zero. In a solo game, place the terror marker on three instead and remove the Special Delivery and Investigation perk cards from the perk deck.\n· The first player to sit begins, and play continues in seating order.\nTurn:\nEach player's turn consists of a hero phase followed by a monster phase.\nIn the hero phase, the current player performs actions equal to the number shown on their hero badge. Moving, guiding, picking up, sharing, advancing a task, defeating a monster, and using a special action each costs one action.\nAny player may play a perk card they hold at any time during the hero phase, and playing a perk card does not cost an action.\nWhen the current player ends the hero phase, the monster phase begins.\nIn the monster phase, draw one monster card, resolve its item, event, and monster steps in order, then the next player's turn begins.\nHero actions:\n· Move: move your hero to an adjacent land space. Your hero may bring any number of villagers from the current space along to the destination. Movement from a perk card or special action follows the same move rules and may bring villagers from that space along.\n· Guide: move one villager in your hero's space to an adjacent land space, or move one villager from an adjacent space to your hero's space.\n· Pick up: take any number of items from the current space.\n· Share: any two heroes in the current space may give any number of items to each other; the exchange does not have to involve the current hero. A hero holding the antidote may also give it to another hero in the same space. Sharing costs one action.\n· Advance a task: use items at the required space as described by the monster's task. Used items go to the item discard pile.\n· Defeat a monster: use items at the monster's space as described by the monster's task. Used items go to the item discard pile.\n· Special action: perform the action described on your hero badge. A special action also costs one action; the Scientist's ability is continuous and costs no action.\nWater spaces include the Lagoon, the River, and the Waterfront. Heroes and villagers cannot enter water spaces; only the Creature can enter them.\nItems:\nItems come in red, blue, and yellow, and the number on the card is its strength. When the Scientist uses an item, its strength increases by one.\nWhen you draw an item, place it on the appearance space printed on its card. When the item bag is empty, shuffle the item discard pile to form a new bag.\nWhen a hero is hit by a monster, they may discard one item to cancel the hit; if they have no item to discard, or choose not to discard one, the hero is defeated.\nVillagers:\nEach of the ten villagers has a safe space. Villagers appear at their appearance space because of events.\nA villager is rescued immediately upon reaching their safe space and is removed from the board; the current player draws one perk card.\nA villager is defeated immediately when hit by a monster, and terror rises by one. Villagers have no items and cannot cancel hits.\nHeroes defeated:\nWhen a hero is defeated, remove the hero figure from the board and raise terror by one.\nAt the start of their next turn, the defeated player places their hero in the Hospital and continues with a full number of actions. The hero keeps all items and perk cards.\nMonster phase:\nA monster card has three parts: items, event, and monster actions, resolved in that order.\n· Items: draw items as shown on the card and place each on its printed appearance space.\n· Event: follow the card's instructions. If the monster involved is not in this game or has already been defeated, ignore the event.\n· Monster actions: resolve each monster symbol from left to right. Each monster symbol moves that monster toward the nearest person, up to the number of steps shown on the card, stopping when it reaches the person's space; then the monster attacks one target. A hit hero may discard one item to cancel the hit; if the hit cannot be canceled, the hero is defeated. A villager hit by a monster is defeated immediately. When a monster could attack either a hero or a villager, it attacks the hero first; if several targets are equally distant, the current player chooses the target before the dice are rolled.\n· Each die has three hit faces, two blank faces, and one power face. Each hit deals one hit, and each power triggers that monster's power once.\n· A frenzy symbol makes the monster holding the frenzy marker take another action. At the start of the game, place the frenzy marker on the monster in play with the lowest frenzy order; when an event passes it, give it to the next monster in play with the next higher frenzy order.\nMonster tasks:\nDracula:\n· Task: use any number of red items with a total strength of at least six on a space with a coffin to smash that coffin.\n· Defeat: after all four coffins are smashed, use any number of yellow items with a total strength of at least six on Dracula's space.\n· Power: Dark Charm. Move the current player's hero to Dracula's space.\nCreature from the Black Lagoon:\n· Task: at the Camp, use one item of any color to move the boat to the next marker of that color. The boat path has nineteen stops, and the nineteenth stop is the lair; the lair marker is blue, so the item used to reach the lair must be blue.\n· Defeat: after the boat reaches the lair, use one red, one blue, and one yellow item on the Creature's space.\n· Power: move the boat back one stop toward the start.\nFrankenstein's Monster and the Bride:\n· Task: use one yellow item on Frankenstein's monster's space to increase its humanity, and use one blue item on the Bride's space to increase her humanity. The increase equals the item's strength, after which that monster may move up to a number of steps equal to the increase. The monster's target is eleven and the Bride's target is eight; when a monster reaches its target, its dial flips over.\n· Defeat: after both dials are flipped, the two monsters are defeated immediately while they are on the same space, without a defeat action.\n· Meeting: if the two monsters enter the same space before both dials are flipped, terror rises by one, then place Frankenstein's monster back in the Graveyard and the Bride back in the Dungeon.\n· Power: the Bride moves one step toward Frankenstein's monster.\nMummy:\n· Puzzle: the scarab puzzle has six numbered positions and one empty center. At setup, scarabs one to three are placed randomly on the three left positions and scarabs four to six randomly on the three right positions, all face up.\n· Task: at the Museum, use one yellow item to gain a number of scarab moves equal to the item's strength. One move slides one face-up scarab to an adjacent empty position, or flips one face-down scarab back face up.\n· Defeat: with all six scarabs face up, scarabs one to six each on the matching numbered position, and the center empty, use any number of red items with a total strength of at least nine on the Mummy's space.\n· Power: flip the lowest-numbered face-up scarab face down.\nWolfman:\n· Task: at the Laboratory, use one blue item and place it in an empty blood vial slot matching its strength. The slots require strengths one, one, two, two, three, and three in order. The Scientist may use an item one strength higher than the slot requires.\n· Antidote: when all six slots are filled, the hero who filled the last slot takes the antidote. The antidote may be given to other heroes but cannot be used to cancel a hit.\n· Defeat: the hero holding the antidote uses it on the Wolfman's space and discards any number of red items with a total strength of at least six.\n· Power: every person on the Wolfman's space takes one hit.\nInvisible Man:\n· Task: at the Police Station, use one item; if the item's printed appearance space matches an empty clue slot, place the item in that slot. The clue slots are the Inn, the Barn, the Mansion, the Laboratory, and the Institute.\n· Defeat: after all five clue slots are filled, use any number of red items with a total strength of at least nine on the Invisible Man's space.\n· Power: the Invisible Man moves two steps toward the nearest villager.\nPerk cards:\nWhen a hero rescues a villager, the current player draws one perk card. Any player may play a perk card they hold at any time during the hero phase, and playing a perk card does not cost an action.\n· Break of Dawn: skip the next monster phase and draw two items.\n· Late Night: gain two extra actions this turn.\n· Detective Visits: place the Invisible Man on any space, or move any monster three spaces.\n· Taxi Ride: place one hero on any non-water space.\n· Brandish Crucifix: place Dracula on any space, or move any monster three spaces.\n· Rush: move one hero up to four spaces.\n· Mob Justice: place Frankenstein's monster or the Bride on any space, or move any monster three spaces.\n· Overstock: each player draws one item.\n· Special Delivery: one hero may give any number of items to another hero regardless of space.\n· Hurry: each hero moves up to two spaces.\n· Investigation: choose a space with a hero and place any number of heroes there.\n· Hunted Prey: place the Wolfman on any space, or move any monster three spaces.\n· Ancient Power: place the Mummy on any space, or move any monster three spaces.\n· Show of Force: place the Creature on any space, or move any monster three spaces.\n· Repel: move every monster up to two spaces.\nGame end:\nThe moment every chosen monster is defeated, you win immediately.\nWhen terror reaches seven, you lose immediately.\nWhen the monster deck is empty and you must draw a monster card, you lose immediately. The final monster card is fully resolved, then one last hero phase is played before you check whether a card remains to be drawn.\nSolo game:\nIn a solo game, one player controls one hero and all other rules stay the same.\n· Terror starts at three.\n· Do not use the Courier; remove the Courier from the hero pool at setup.\n· Remove the Special Delivery and Investigation perk cards from the perk deck.\n· Two monsters are recommended for a solo game.",
			phaseHero: "Hero phase",
			phaseMonster: "Monster phase",
			phaseDone: "Game over",
			terror: "Terror {{n}} / 7",
			turnLabel: "{{name}}'s turn",
			yourTurn: "Your turn",
			waitingTurn: "Waiting for {{name}}…",
			actionsLeft: "Actions {{left}} / {{max}}",
			handTitle: "Items",
			handEmpty: "No items yet",
			perksTitle: "Perk cards",
			perksEmpty: "No perk cards yet",
			playPerk: "Play",
			itemStrength: "Strength {{n}}",
			colorRed: "Red",
			colorBlue: "Blue",
			colorYellow: "Yellow",
			itemAria: "{{item}}, {{color}}, strength {{n}}",
			boardItems: "Items on spaces",
			boardLabel: "Town map",
			waterTag: "Water",
			noItems: "No items",
			personsHere: "People",
			noPersons: "No people",
			monstersHere: "Monsters",
			noMonsters: "No monsters",
			spaceActions: "Available actions",
			noSpaceActions: "No actions available here",
			moveTo: "Move to {{space}}",
			moveWith: "Bring {{n}} villagers",
			guideTitle: "Guide a villager",
			guideTo: "Guide {{villager}} to {{space}}",
			pickupTitle: "Pick up items",
			pickupN: "Pick up selected {{n}}",
			shareTitle: "Trade items",
			shareFrom: "From {{hero}}",
			shareTo: "Give to {{hero}}",
			giveCure: "Give the antidote",
			advanceTitle: "Advance a task",
			advanceButton: "Advance {{monster}}",
			defeatTitle: "Defeat a monster",
			defeatButton: "Defeat {{monster}}",
			specialTitle: "Special action",
			specialButton: "Use {{hero}}'s special action",
			endTurn: "End turn",
			doneButton: "Done",
			cancel: "Cancel",
			close: "Close",
			chooseTargetSpace: "Choose a destination",
			chooseTargetHero: "Choose a hero",
			chooseTargetVillager: "Choose a villager",
			chooseTargetFigure: "Choose a monster",
			chooseMode: "Choose an effect",
			modePlace: "Place on any space",
			modeMove: "Move any monster three spaces",
			stay: "Stay here",
			skipMove: "Do not move",
			done: "Done",
			leadTitle: "Villagers coming along",
			noLeadVillager: "No villagers can come along",
			selectItemsTitle: "Select items",
			selectItemsHint: "Tap items to toggle selection",
			needItems: "Select at least one item",
			strengthSum: "Selected strength {{n}}",
			strengthNeed: "Needs total strength {{n}}",
			invalidSelection: "The selection does not meet the task",
			heroOwner: "{{hero}} ({{name}})",
			youTag: "You",
			heroDefeated: "Defeated",
			heroRevive: "Revives in the Hospital next turn",
			tasksTitle: "Monster tasks",
			openTasks: "Monster tasks",
			taskAdvance: "Task",
			taskDefeat: "Defeat",
			taskPower: "Power",
			defeatedTag: "Defeated",
			frenzyTag: "Frenzy",
			coffins: "Coffins {{n}} / 4",
			boat: "Boat {{n}} / 19",
			boatLair: "The boat waits at the lair",
			bottles: "Vials {{n}} / 6",
			spots: "Clues {{n}} / 5",
			cureLabel: "Antidote",
			cureHolder: "Antidote: {{hero}}",
			cureUnclaimed: "Antidote not yet claimed",
			mummyPuzzle: "Scarab puzzle",
			mummySolved: "Every scarab is in place",
			mummyUnsolved: "The scarabs are not all in place",
			frankProgress: "Monster humanity {{n}} / {{target}}",
			brideProgress: "Bride humanity {{n}} / {{target}}",
			bag: "Item bag {{n}}",
			itemDiscard: "Item discard {{n}}",
			monsterDeck: "Monster deck {{n}}",
			monsterDiscard: "Monster discard {{n}}",
			perkDeck: "Perk deck {{n}}",
			perkDiscard: "Perk discard {{n}}",
			lastRollTitle: "Latest roll",
			rollHits: "Hits {{n}}",
			rollPowers: "Powers {{n}}",
			cardLabel: "Monster card {{n}}",
			eventLabel: "Event: {{event}}",
			huntedTag: "Hunted: {{hero}}",
			soulTag: "Soul: {{hero}}",
			frenzyShort: "Frenzy: {{monster}}",
			villagersTitle: "Villagers",
			rescuedCount: "Rescued {{n}} / 10",
			railNoVillagers: "No villagers on the board",
			villagerNone: "Not yet appeared",
			villagerAt: "At {{space}}",
			villagerSafeTag: "Safe space",
			villagerSafe: "Safe space: {{space}}",
			villagerSafeStatus: "Rescued",
			villagerDefeatedStatus: "Defeated",
			logTitle: "Action log",
			openLog: "Action log",
			logEmpty: "No entries yet",
			promptTitle: "Choose",
			promptWaiting: "Waiting for {{name}} to choose…",
			promptAttack: "Choose the target of the attack",
			promptDefend: "Hit: discard an item or accept the attack",
			promptThief: "Invisible thief: choose a space",
			promptPlaceFigure: "Choose the monster to place",
			promptFigureDest: "Destination for {{figure}}",
			promptMoveFigure: "Choose the monster to move",
			promptHeroDest: "Destination for {{hero}}",
			promptMoveHero: "Choose the hero to move",
			promptCarry: "Choose villagers to bring along",
			carryConfirm: "Confirm",
			promptHurry: "Hurry: move {{hero}} two spaces",
			promptInvestigate: "Investigation: choose a gathering space",
			promptInvestigateHero: "Gather the other heroes here",
			promptRepel: "Repel: choose the monster to move",
			promptDeliveryFrom: "Special Delivery: choose the hero giving items",
			promptDeliveryTo: "Special Delivery: choose the hero receiving items",
			promptDeliveryItem: "Choose the item to give to {{hero}}",
			promptGaze: "Hypnotic Gaze: choose the person to pull",
			promptPerkMode: "Choose the perk effect",
			takeHit: "Accept the attack",
			defendWith: "Discard {{item}} to cancel",
			mummyPending: "Scarab moves left: {{n}}",
			mummySlideHint: "Tap a face-up scarab, then an adjacent empty position",
			mummyFlipHint: "Tap a face-down scarab to flip it face up",
			mummyDoneButton: "Finish the puzzle",
			mummyPickFirst: "Choose a face-up scarab first",
			mummyInvalidTarget: "A scarab can only slide to an adjacent empty position",
			fbPending: "Move {{figure}}: {{n}} steps left",
			fbPendingHint: "Tap a highlighted space to move, or choose Done",
			endingTitle: "Game over",
			endingWin: "Every monster is defeated — you win",
			endingTerror: "Terror reached seven — you lose",
			endingTime: "The monster deck ran out — you lose",
			overWin: "The town is saved",
			overLoss: "Terror has taken the town",
			overMonsters: "Monsters defeated",
			overRescued: "Villagers rescued",
			overTerror: "Final terror",
			overVillagersLost: "{{n}} villagers were defeated.",
			invalidAction: "That action cannot be performed now",
			waitingOther: "Waiting for other players…",
			selectPerkConfirm: "Play {{perk}}",
			cancelsPerk: "Not now",
			pendingMoves: "{{figure}} is moving",
			monstersChosen: "Monsters this game",
			deckInfo: "Decks",
			itemAt: "{{item}} appears at {{space}}",
			safeSpaceShort: "Safe space",
			monstersTitle: "Monsters",
			heroesTitle: "Heroes",
			optionsHint: "Choose the monsters to face this game, one to four.",
			optionsRecommended: "Recommended",
			optionsRecommendedValue: "Dracula and the Creature",
			optionsCount: "{{n}} chosen",
			optionsInvalid: "Choose at least one monster and at most four",
			spaceCave: "Cave",
			spaceCamp: "Camp",
			spacePrecinct: "Police Station",
			spaceInn: "Inn",
			spaceBarn: "Barn",
			spaceDungeon: "Dungeon",
			spaceLagoon: "Lagoon",
			spaceBridgeWest: "West Bridge",
			spaceFountain: "Fountain",
			spaceLamp: "Lamp Post",
			spaceMansion: "Mansion",
			spaceAbbey: "Abbey",
			spaceCrypt: "Crypt",
			spaceMuseum: "Museum",
			spaceChurch: "Church",
			spaceHospital: "Hospital",
			spaceGraveyard: "Graveyard",
			spaceLaboratory: "Laboratory",
			spaceInstitute: "Institute",
			spaceWaterfront: "Waterfront",
			spaceDocks: "Docks",
			spaceTower: "Tower",
			spaceTheatre: "Theatre",
			spaceRiver: "River",
			spaceBridgeEast: "East Bridge",
			spaceShop: "Shop",
			itemBeartrap: "Bear Trap",
			itemRapier: "Rapier",
			itemPistol: "Pistol",
			itemSilvercane: "Silver Cane",
			itemShovel: "Shovel",
			itemPitchfork: "Pitchfork",
			itemDart: "Dart",
			itemKnife: "Knife",
			itemFirepoker: "Fire Poker",
			itemTorch: "Torch",
			itemSpeargun: "Speargun",
			itemRifle: "Rifle",
			itemResearch: "Research Notes",
			itemAnatomy: "Anatomy Book",
			itemKite: "Kite",
			itemRotenone: "Rotenone",
			itemCentrifuge: "Centrifuge",
			itemFossil: "Fossil",
			itemAnalysis: "Analysis Report",
			itemTelescope: "Telescope",
			itemExperiment: "Experiment Log",
			itemSearchlight: "Searchlight",
			itemCamera: "Camera",
			itemCosmicray: "Cosmic Ray Diffuser",
			itemMonocane: "Monocane Mixture",
			itemNebularium: "Nebularium",
			itemTablet: "Tablet",
			itemFlower: "Flower",
			itemWine: "Wine",
			itemGarlic: "Garlic",
			itemCharm: "Charm",
			itemTarot: "Tarot Cards",
			itemMirroredbox: "Mirrored Box",
			itemCrucifix: "Crucifix",
			itemWolfsbane: "Wolfsbane",
			itemViolin: "Violin",
			itemStake: "Stake",
			itemScroll: "Scroll of Thoth",
			itemCanopic: "Canopic Jar",
			heroArchaeologist: "Archaeologist",
			heroCourier: "Courier",
			heroExplorer: "Explorer",
			heroInspector: "Inspector",
			heroMayor: "Mayor",
			heroProfessor: "Professor",
			heroScientist: "Scientist",
			heroArchaeologistShort: "Arch",
			heroCourierShort: "Cour",
			heroExplorerShort: "Expl",
			heroInspectorShort: "Insp",
			heroMayorShort: "Mayor",
			heroProfessorShort: "Prof",
			heroScientistShort: "Sci",
			heroArchaeologistSpecial: "Special action: take items from an adjacent space.",
			heroCourierSpecial: "Special action: move to any space with another hero.",
			heroExplorerSpecial: "Special action: move to any non-water space.",
			heroInspectorSpecial: "Special action: move to any non-water space with a monster.",
			heroMayorSpecial: "No special action, but five actions each turn.",
			heroProfessorSpecial: "Special action: move any hero or villager one space.",
			heroScientistSpecial: "Continuous ability: when you use an item, its strength increases by one.",
			villagerFritz: "Fritz",
			villagerMaria: "Maria",
			villagerMaleva: "Maleva",
			villagerPearson: "Professor Pearson",
			villagerWilbur: "Wilbur and Chick",
			villagerRenfield: "Renfield",
			villagerReed: "Dr. Reed",
			villagerCranley: "Dr. Cranley",
			villagerLucy: "Lucy",
			villagerElizabeth: "Elizabeth",
			villagerFritzShort: "Fritz",
			villagerMariaShort: "Maria",
			villagerMalevaShort: "Maleva",
			villagerPearsonShort: "Pearson",
			villagerWilburShort: "Wilbur",
			villagerRenfieldShort: "Renfield",
			villagerReedShort: "Reed",
			villagerCranleyShort: "Cranley",
			villagerLucyShort: "Lucy",
			villagerElizabethShort: "Eliz",
			monsterDracula: "Dracula",
			monsterMummy: "Mummy",
			monsterFrankenstein: "Frankenstein's Monster",
			monsterBride: "Bride",
			monsterCreature: "Creature from the Black Lagoon",
			monsterWolfman: "Wolfman",
			monsterInvisibleman: "Invisible Man",
			monsterDraculaShort: "Drac",
			monsterMummyShort: "Mummy",
			monsterFrankensteinShort: "Frank",
			monsterCreatureShort: "Creature",
			monsterWolfmanShort: "Wolfman",
			monsterInvisiblemanShort: "Invis",
			monsterFrankShort: "Monster",
			monsterBrideShort: "Bride",
			monsterDraculaAdvance: "While Dracula is on a space with a coffin, use any number of red items with a total strength of at least six to smash that coffin.",
			monsterDraculaDefeat: "After all four coffins are smashed, use any number of yellow items with a total strength of at least six on Dracula's space.",
			monsterDraculaPower: "Dark Charm: move the current player's hero to Dracula's space.",
			monsterCreatureAdvance: "At the Camp, use one item of any color to move the boat to the next marker of that color.",
			monsterCreatureDefeat: "After the boat reaches the lair, use one red, one blue, and one yellow item on the Creature's space.",
			monsterCreaturePower: "Move the boat back one stop toward the start.",
			monsterFrankensteinAdvance: "Use a yellow item on the monster's space and a blue item on the Bride's space to raise humanity by their strength and move that monster the same number of steps.",
			monsterFrankensteinDefeat: "After both dials are flipped, the two monsters are defeated immediately while on the same space.",
			monsterFrankensteinPower: "The Bride moves one step toward the monster.",
			monsterMummyAdvance: "At the Museum, use one yellow item to gain scarab moves equal to its strength.",
			monsterMummyDefeat: "After every scarab is in place, use any number of red items with a total strength of at least nine on the Mummy's space.",
			monsterMummyPower: "Flip the lowest-numbered face-up scarab face down.",
			monsterWolfmanAdvance: "At the Laboratory, use one blue item and place it in an empty vial slot matching its strength.",
			monsterWolfmanDefeat: "The hero holding the antidote uses it on the Wolfman's space and discards any number of red items with a total strength of at least six.",
			monsterWolfmanPower: "Every person on the Wolfman's space takes one hit.",
			monsterInvisiblemanAdvance: "At the Police Station, use one item; if its printed space matches an empty clue slot, place it in that slot.",
			monsterInvisiblemanDefeat: "After all five clue slots are filled, use any number of red items with a total strength of at least nine on the Invisible Man's space.",
			monsterInvisiblemanPower: "The Invisible Man moves two steps toward the nearest villager.",
			eventOnTheMove: "On the Move: pass the frenzy marker to the next monster and move a villager one step toward its safe space.",
			eventMeeting: "Meeting: the Bride moves two steps toward the monster.",
			eventHunt: "Hunt: name a hero, and the Wolfman moves three steps toward them.",
			eventThief: "Thief: the Invisible Man moves to the space with the most items and discards every item there.",
			eventRetreatLagoon: "Retreat: the Creature moves to the Lagoon.",
			eventRetreatRiver: "Retreat: the Creature moves to the River.",
			eventRetreatWaterfront: "Retreat: the Creature moves to the Waterfront.",
			eventInnocent: "Innocent: Maria appears at the Barn.",
			eventInsaneSurvivor: "Insane Survivor: Renfield appears at the Docks.",
			eventWorriedFiancee: "Worried Fiancée: Elizabeth appears at the Mansion.",
			eventEnthralled: "Enthralled: Lucy appears at the Theatre.",
			eventDelivery: "Delivery: Wilbur and Chick appear at the Shop.",
			eventFortuneTeller: "Fortune Teller: Maleva appears at the Camp.",
			eventHurriedAssistant: "Hurried Assistant: Fritz appears at the Tower.",
			eventReincarnatedSoul: "Reincarnated Soul: name a hero to hold the soul and move three steps toward the Mummy.",
			eventHypnoticGaze: "Hypnotic Gaze: the person nearest Dracula moves three steps toward Dracula.",
			eventSunrise: "Sunrise: Dracula returns to the Crypt.",
			eventFormOfTheBat: "Form of the Bat: Dracula moves to the current player's hero's space.",
			eventEgyptianExpert: "Egyptian Expert: Professor Pearson appears at the Cave.",
			eventFormerEmployer: "Former Employer: Dr. Cranley appears at the Laboratory.",
			eventIchthyologist: "Ichthyologist: Dr. Reed appears at the Institute.",
			perkBreakOfDawn: "Break of Dawn: skip the next monster phase and draw two items.",
			perkLateNight: "Late Night: gain two extra actions this turn.",
			perkDetective: "Detective Visits: place the Invisible Man on any space, or move any monster three spaces.",
			perkTaxiRide: "Taxi Ride: place one hero on any non-water space.",
			perkCrucifix: "Brandish Crucifix: place Dracula on any space, or move any monster three spaces.",
			perkRush: "Rush: move one hero up to four spaces.",
			perkMobJustice: "Mob Justice: place the monster or the Bride on any space, or move any monster three spaces.",
			perkOverstock: "Overstock: each player draws one item.",
			perkSpecialDelivery: "Special Delivery: one hero may give any number of items to another hero regardless of space.",
			perkHurry: "Hurry: each hero moves up to two spaces.",
			perkInvestigation: "Investigation: choose a space with a hero and place any number of heroes there.",
			perkHuntedPrey: "Hunted Prey: place the Wolfman on any space, or move any monster three spaces.",
			perkAncients: "Ancient Power: place the Mummy on any space, or move any monster three spaces.",
			perkShowForce: "Show of Force: place the Creature on any space, or move any monster three spaces.",
			perkRepel: "Repel: move every monster up to two spaces.",
			logTurnStart: "{{hero}} begins their turn",
			logHeroEnd: "{{hero}} ends their turn",
			logHeroMoved: "{{hero}} moves to {{space}}",
			logVillagerMoved: "{{villager}} moves to {{space}}",
			logPickup: "{{hero}} picks up {{n}} items",
			logItemGiven: "{{hero}} gives an item to {{hero2}}",
			logCureGiven: "{{hero}} gives the antidote to {{hero2}}",
			logAdvance: "{{hero}} uses items to advance {{figure}} by {{n}}",
			logDefeat: "{{hero}} defeats {{monster}}",
			logMonsterDefeated: "{{monster}} is defeated",
			logCoffinBroken: "{{hero}} smashes the coffin at {{space}}",
			logBoatAdvance: "{{hero}} moves the boat to stop {{n}}",
			logBoatBack: "The boat falls back to stop {{n}}",
			logBottleFilled: "{{hero}} fills a vial (needs strength {{n}})",
			logCureTaken: "{{hero}} takes the antidote",
			logSpotFilled: "{{hero}} fills the clue at {{space}}",
			logMummyAdvance: "{{hero}} gains {{n}} scarab moves",
			logScarabSlide: "A scarab slides into an empty position",
			logScarabFlip: "A scarab flips face up",
			logScarabFlipped: "A scarab flips face down",
			logMummyDone: "Scarab moves end",
			logFbFlipped: "The dial of {{figure}} flips over",
			logFbMeet: "The two monsters meet, and terror rises",
			logFbDefeated: "The two monsters reunite, and the monster is defeated",
			logItemPlaced: "{{item}} appears at {{space}}",
			logTerror: "Terror rises by {{n}}",
			logHeroDefeated: "{{hero}} is defeated",
			logVillagerDefeated: "{{villager}} is defeated",
			logVillagerPlaced: "{{villager}} appears at {{space}}",
			logRescued: "{{villager}} is rescued",
			logRevived: "{{hero}} revives in the Hospital",
			logMonsterCard: "Monster card {{n}} is revealed",
			logMonsterMoved: "{{figure}} moves to {{space}}",
			logMonsterSkipped: "This monster phase is skipped",
			logMonsterWillSkip: "The next monster phase will be skipped",
			logRoll: "{{figure}} rolls {{n}} hits and {{n2}} powers",
			logHitHero: "{{hero}} is hit",
			logHitVillager: "{{villager}} is hit",
			logDefended: "{{hero}} discards {{item}} to cancel the hit",
			logCharmed: "{{hero}} is charmed to {{space}}",
			logHunted: "{{hero}} is hunted by the Wolfman",
			logSoul: "{{hero}} takes the soul",
			logFrenzyMoved: "The frenzy marker moves to {{monster}}",
			logPerkGain: "{{hero}} gains the perk {{perk}}",
			logPerkPlayed: "{{perk}} is played",
			logActions: "Gain {{n}} extra actions",
			logThief: "The Invisible Man steals the items at {{space}}",
			logEventIgnored: "{{monster}} is not in this game, and the event is ignored",
			logWin: "Victory: every monster is defeated",
			logLose: "Defeat",
			logFrenzy: "The frenzy marker is on {{monster}}",
			logMoved: "{{figure}} moves to {{space}}",
			logAttack: "{{figure}} attacks {{who}}"
		}
	}
};
//#endregion
export { br as default };
