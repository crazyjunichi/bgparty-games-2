import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { usePrefersReducedMotion as u } from "@bgparty/sdk/fx/use-reduced-motion";
import { LogSheet as d } from "@bgparty/sdk/ui/log-sheet";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { SheetView as h } from "@bgparty/sdk/sheet-view";
import { gameAssetUrl as ee } from "@bgparty/sdk/assets";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
import { BottomSheet as v } from "@bgparty/sdk/bottom-sheet";
import { OptionCheckbox as te, OptionSection as ne } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var y = /* @__PURE__ */ "cave.camp.precinct.inn.barn.dungeon.lagoon.bridgeWest.fountain.lamp.mansion.abbey.crypt.museum.church.hospital.graveyard.laboratory.institute.waterfront.docks.tower.theatre.river.bridgeEast.shop".split("."), b = {
	cave: {
		x: 88,
		y: 245,
		water: !1
	},
	camp: {
		x: 212,
		y: 200,
		water: !1
	},
	precinct: {
		x: 420,
		y: 182,
		water: !1
	},
	inn: {
		x: 570,
		y: 160,
		water: !1
	},
	barn: {
		x: 742,
		y: 166,
		water: !1
	},
	dungeon: {
		x: 915,
		y: 195,
		water: !1
	},
	lagoon: {
		x: 175,
		y: 370,
		water: !0
	},
	bridgeWest: {
		x: 338,
		y: 372,
		water: !1
	},
	fountain: {
		x: 478,
		y: 322,
		water: !1
	},
	lamp: {
		x: 358,
		y: 655,
		water: !1
	},
	mansion: {
		x: 275,
		y: 535,
		water: !1
	},
	abbey: {
		x: 90,
		y: 600,
		water: !1
	},
	crypt: {
		x: 80,
		y: 790,
		water: !1
	},
	museum: {
		x: 225,
		y: 755,
		water: !1
	},
	church: {
		x: 450,
		y: 800,
		water: !1
	},
	hospital: {
		x: 360,
		y: 915,
		water: !1
	},
	graveyard: {
		x: 610,
		y: 895,
		water: !1
	},
	laboratory: {
		x: 700,
		y: 745,
		water: !1
	},
	institute: {
		x: 820,
		y: 890,
		water: !1
	},
	waterfront: {
		x: 900,
		y: 700,
		water: !0
	},
	docks: {
		x: 880,
		y: 525,
		water: !1
	},
	tower: {
		x: 845,
		y: 350,
		water: !1
	},
	theatre: {
		x: 615,
		y: 345,
		water: !1
	},
	river: {
		x: 470,
		y: 460,
		water: !0
	},
	bridgeEast: {
		x: 690,
		y: 527,
		water: !1
	},
	shop: {
		x: 555,
		y: 640,
		water: !1
	}
}, x = {
	cave: ["lagoon", "camp"],
	camp: ["cave", "bridgeWest"],
	precinct: ["fountain"],
	inn: ["fountain"],
	barn: ["theatre"],
	dungeon: ["tower"],
	lagoon: [
		"cave",
		"abbey",
		"bridgeWest"
	],
	bridgeWest: [
		"lagoon",
		"mansion",
		"river",
		"fountain",
		"camp"
	],
	fountain: [
		"bridgeWest",
		"precinct",
		"inn",
		"theatre"
	],
	lamp: [
		"museum",
		"church",
		"shop",
		"mansion"
	],
	mansion: [
		"abbey",
		"lamp",
		"bridgeWest"
	],
	abbey: [
		"crypt",
		"mansion",
		"lagoon"
	],
	crypt: ["abbey"],
	museum: ["lamp"],
	church: [
		"hospital",
		"graveyard",
		"lamp"
	],
	hospital: ["church"],
	graveyard: ["church"],
	laboratory: ["institute", "shop"],
	institute: ["laboratory", "waterfront"],
	waterfront: [
		"institute",
		"bridgeEast",
		"docks"
	],
	docks: ["tower", "waterfront"],
	tower: [
		"theatre",
		"docks",
		"dungeon"
	],
	theatre: [
		"fountain",
		"bridgeEast",
		"tower",
		"barn"
	],
	river: ["bridgeWest", "bridgeEast"],
	bridgeEast: [
		"river",
		"shop",
		"waterfront",
		"theatre"
	],
	shop: [
		"lamp",
		"laboratory",
		"bridgeEast"
	]
}, re = /* @__PURE__ */ "beartrap.rapier.pistol.silvercane.shovel.pitchfork.dart.knife.firepoker.torch.speargun.rifle.research.anatomy.kite.rotenone.centrifuge.fossil.analysis.telescope.experiment.searchlight.camera.cosmicray.monocane.nebularium.tablet.flower.wine.garlic.charm.tarot.mirroredbox.crucifix.wolfsbane.violin.stake.scroll.canopic".split("."), S = {
	beartrap: {
		color: "red",
		strength: 4,
		space: "shop",
		count: 1
	},
	rapier: {
		color: "red",
		strength: 5,
		space: "theatre",
		count: 2
	},
	pistol: {
		color: "red",
		strength: 6,
		space: "precinct",
		count: 2
	},
	silvercane: {
		color: "red",
		strength: 6,
		space: "shop",
		count: 1
	},
	shovel: {
		color: "red",
		strength: 2,
		space: "graveyard",
		count: 2
	},
	pitchfork: {
		color: "red",
		strength: 4,
		space: "barn",
		count: 2
	},
	dart: {
		color: "red",
		strength: 2,
		space: "inn",
		count: 2
	},
	knife: {
		color: "red",
		strength: 3,
		space: "docks",
		count: 2
	},
	firepoker: {
		color: "red",
		strength: 3,
		space: "mansion",
		count: 2
	},
	torch: {
		color: "red",
		strength: 5,
		space: "barn",
		count: 2
	},
	speargun: {
		color: "red",
		strength: 4,
		space: "institute",
		count: 1
	},
	rifle: {
		color: "red",
		strength: 6,
		space: "barn",
		count: 1
	},
	research: {
		color: "blue",
		strength: 2,
		space: "tower",
		count: 2
	},
	anatomy: {
		color: "blue",
		strength: 1,
		space: "institute",
		count: 2
	},
	kite: {
		color: "blue",
		strength: 1,
		space: "tower",
		count: 2
	},
	rotenone: {
		color: "blue",
		strength: 3,
		space: "institute",
		count: 1
	},
	centrifuge: {
		color: "blue",
		strength: 1,
		space: "laboratory",
		count: 2
	},
	fossil: {
		color: "blue",
		strength: 3,
		space: "camp",
		count: 1
	},
	analysis: {
		color: "blue",
		strength: 2,
		space: "institute",
		count: 2
	},
	telescope: {
		color: "blue",
		strength: 2,
		space: "mansion",
		count: 1
	},
	experiment: {
		color: "blue",
		strength: 2,
		space: "laboratory",
		count: 2
	},
	searchlight: {
		color: "blue",
		strength: 2,
		space: "precinct",
		count: 1
	},
	camera: {
		color: "blue",
		strength: 3,
		space: "laboratory",
		count: 1
	},
	cosmicray: {
		color: "blue",
		strength: 3,
		space: "tower",
		count: 1
	},
	monocane: {
		color: "blue",
		strength: 3,
		space: "inn",
		count: 1
	},
	nebularium: {
		color: "blue",
		strength: 3,
		space: "tower",
		count: 1
	},
	tablet: {
		color: "yellow",
		strength: 3,
		space: "museum",
		count: 1
	},
	flower: {
		color: "yellow",
		strength: 2,
		space: "docks",
		count: 2
	},
	wine: {
		color: "yellow",
		strength: 2,
		space: "church",
		count: 2
	},
	garlic: {
		color: "yellow",
		strength: 2,
		space: "inn",
		count: 2
	},
	charm: {
		color: "yellow",
		strength: 4,
		space: "camp",
		count: 1
	},
	tarot: {
		color: "yellow",
		strength: 3,
		space: "camp",
		count: 1
	},
	mirroredbox: {
		color: "yellow",
		strength: 3,
		space: "mansion",
		count: 2
	},
	crucifix: {
		color: "yellow",
		strength: 4,
		space: "church",
		count: 2
	},
	wolfsbane: {
		color: "yellow",
		strength: 4,
		space: "camp",
		count: 2
	},
	violin: {
		color: "yellow",
		strength: 3,
		space: "camp",
		count: 1
	},
	stake: {
		color: "yellow",
		strength: 3,
		space: "abbey",
		count: 2
	},
	scroll: {
		color: "yellow",
		strength: 4,
		space: "museum",
		count: 1
	},
	canopic: {
		color: "yellow",
		strength: 3,
		space: "museum",
		count: 1
	}
}, C = re.flatMap((e) => Array(S[e].count).fill(e)), w = [
	"archaeologist",
	"courier",
	"explorer",
	"inspector",
	"mayor",
	"professor",
	"scientist"
], ie = {
	archaeologist: {
		actions: 4,
		start: "docks",
		special: "archaeologist"
	},
	courier: {
		actions: 4,
		start: "shop",
		special: "courier"
	},
	explorer: {
		actions: 3,
		start: "camp",
		special: "explorer"
	},
	inspector: {
		actions: 4,
		start: "precinct",
		special: "inspector"
	},
	mayor: {
		actions: 5,
		start: "theatre",
		special: null
	},
	professor: {
		actions: 4,
		start: "hospital",
		special: "professor"
	},
	scientist: {
		actions: 4,
		start: "institute",
		special: "scientist"
	}
}, ae = [
	"fritz",
	"maria",
	"maleva",
	"pearson",
	"wilbur",
	"renfield",
	"reed",
	"cranley",
	"lucy",
	"elizabeth"
], T = {
	fritz: {
		safe: "institute",
		spawn: "tower"
	},
	maria: {
		safe: "camp",
		spawn: "barn"
	},
	maleva: {
		safe: "shop",
		spawn: "camp"
	},
	pearson: {
		safe: "museum",
		spawn: "cave"
	},
	wilbur: {
		safe: "dungeon",
		spawn: "shop"
	},
	renfield: {
		safe: "hospital",
		spawn: "docks"
	},
	reed: {
		safe: "camp",
		spawn: "institute"
	},
	cranley: {
		safe: "precinct",
		spawn: "laboratory"
	},
	lucy: {
		safe: "mansion",
		spawn: "theatre"
	},
	elizabeth: {
		safe: "tower",
		spawn: "mansion"
	}
}, E = [
	"dracula",
	"mummy",
	"frankenstein",
	"creature",
	"wolfman",
	"invisibleman"
], D = {
	dracula: 1,
	mummy: 2,
	frankenstein: 3,
	creature: 4,
	wolfman: 5,
	invisibleman: 6
}, oe = [
	"crypt",
	"dungeon",
	"graveyard",
	"cave"
], O = [
	"inn",
	"barn",
	"mansion",
	"laboratory",
	"institute"
], k = [
	1,
	1,
	2,
	2,
	3,
	3
], A = {
	frank: 11,
	bride: 8
}, j = [
	"red",
	"yellow",
	"blue",
	"yellow",
	"blue",
	"red",
	"yellow",
	"blue",
	"yellow",
	"blue",
	"red",
	"yellow",
	"blue",
	"red",
	"red",
	"yellow",
	"blue",
	"red",
	"blue"
], M = j.length, N = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"D"
], se = {
	6: ["1", "5"],
	1: ["6", "2"],
	2: [
		"1",
		"3",
		"D"
	],
	3: ["2", "4"],
	4: ["3", "5"],
	5: [
		"4",
		"6",
		"D"
	],
	D: ["2", "5"]
}, ce = {
	6: {
		x: 33,
		y: 26
	},
	1: {
		x: 67,
		y: 26
	},
	5: {
		x: 18,
		y: 50
	},
	2: {
		x: 82,
		y: 50
	},
	D: {
		x: 50,
		y: 50
	},
	4: {
		x: 33,
		y: 74
	},
	3: {
		x: 67,
		y: 74
	}
}, P = (e, t, n) => ({
	monster: e,
	move: t,
	dice: n
}), le = [
	{
		items: 3,
		event: "onTheMove",
		strikes: [P("frenzy", 3, 2)]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			P("creature", 2, 1),
			P("wolfman", 2, 1),
			P("invisibleman", 2, 1)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			P("creature", 1, 2),
			P("dracula", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "retreatLagoon",
		strikes: [
			P("mummy", 1, 3),
			P("bride", 1, 3),
			P("frenzy", 1, 3)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			P("creature", 1, 2),
			P("dracula", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 3,
		event: "onTheMove",
		strikes: [P("frenzy", 3, 2)]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			P("creature", 2, 1),
			P("wolfman", 2, 1),
			P("invisibleman", 2, 1)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			P("mummy", 1, 3),
			P("creature", 1, 3),
			P("frankenstein", 1, 3)
		]
	},
	{
		items: 3,
		event: "innocent",
		strikes: [
			P("frankenstein", 1, 3),
			P("bride", 1, 3),
			P("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "insaneSurvivor",
		strikes: [P("dracula", 2, 2), P("frenzy", 2, 2)]
	},
	{
		items: 3,
		event: "worriedFiancee",
		strikes: [
			P("frankenstein", 1, 2),
			P("bride", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 3,
		event: "enthralled",
		strikes: [P("dracula", 2, 1), P("frenzy", 2, 1)]
	},
	{
		items: 3,
		event: "delivery",
		strikes: [
			P("frankenstein", 1, 3),
			P("bride", 1, 3),
			P("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "fortuneTeller",
		strikes: [P("wolfman", 1, 2), P("frenzy", 1, 2)]
	},
	{
		items: 3,
		event: "hurriedAssistant",
		strikes: [
			P("frankenstein", 1, 2),
			P("bride", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			P("wolfman", 1, 2),
			P("dracula", 1, 2),
			P("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "hypnoticGaze",
		strikes: [
			P("mummy", 1, 2),
			P("invisibleman", 1, 2),
			P("creature", 1, 2)
		]
	},
	{
		items: 0,
		event: "sunrise",
		strikes: [
			P("invisibleman", 1, 2),
			P("frankenstein", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			P("mummy", 1, 3),
			P("creature", 1, 3),
			P("frankenstein", 1, 3)
		]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			P("wolfman", 1, 2),
			P("dracula", 1, 2),
			P("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "thief",
		strikes: [
			P("mummy", 1, 3),
			P("creature", 1, 3),
			P("frankenstein", 1, 3)
		]
	},
	{
		items: 2,
		event: "meeting",
		strikes: [
			P("creature", 2, 1),
			P("wolfman", 2, 1),
			P("invisibleman", 2, 1)
		]
	},
	{
		items: 3,
		event: "egyptianExpert",
		strikes: [P("mummy", 2, 2), P("frenzy", 2, 2)]
	},
	{
		items: 3,
		event: "formerEmployer",
		strikes: [P("invisibleman", 1, 2), P("frenzy", 1, 2)]
	},
	{
		items: 0,
		event: "reincarnatedSoul",
		strikes: [
			P("wolfman", 1, 2),
			P("dracula", 1, 2),
			P("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "formOfTheBat",
		strikes: [
			P("wolfman", 1, 2),
			P("creature", 1, 2),
			P("invisibleman", 1, 2)
		]
	},
	{
		items: 2,
		event: "hunt",
		strikes: [
			P("creature", 1, 2),
			P("dracula", 1, 2),
			P("frenzy", 1, 2)
		]
	},
	{
		items: 0,
		event: "retreatRiver",
		strikes: [
			P("wolfman", 1, 3),
			P("bride", 1, 3),
			P("frenzy", 1, 3)
		]
	},
	{
		items: 0,
		event: "retreatWaterfront",
		strikes: [
			P("wolfman", 1, 3),
			P("bride", 1, 3),
			P("frenzy", 1, 3)
		]
	},
	{
		items: 3,
		event: "ichthyologist",
		strikes: [P("creature", 1, 2), P("frenzy", 1, 2)]
	}
], ue = [
	"breakOfDawn",
	"lateNight",
	"detective",
	"taxiRide",
	"crucifix",
	"rush",
	"mobJustice",
	"overstock",
	"specialDelivery",
	"hurry",
	"investigation",
	"huntedPrey",
	"ancients",
	"showForce",
	"repel"
], de = [
	"breakOfDawn",
	"lateNight",
	"detective",
	"taxiRide",
	"crucifix",
	"rush",
	"taxiRide",
	"mobJustice",
	"overstock",
	"specialDelivery",
	"hurry",
	"investigation",
	"overstock",
	"breakOfDawn",
	"lateNight",
	"huntedPrey",
	"ancients",
	"showForce",
	"repel",
	"rush"
];
function fe(e, t) {
	let n = /* @__PURE__ */ new Map([[e, {
		to: e,
		prev: null,
		dist: 0
	}]]), r = [e];
	for (; r.length;) {
		let e = r.shift(), i = n.get(e);
		for (let a of x[e]) !n.has(a) && t(a) && (n.set(a, {
			to: a,
			prev: e,
			dist: i.dist + 1
		}), r.push(a));
	}
	return n;
}
function pe(e, t) {
	let n = [], r = t;
	for (; r !== null;) n.push(r), r = e.get(r)?.prev ?? null;
	return n.reverse();
}
function me(e) {
	return !b[e].water;
}
//#endregion
//#region src/game/meta.ts
var F = {
	id: "horrified",
	uuid: "acbff95d-4892-457b-bf84-0a3dfd3e8caa",
	tier: "alpha",
	mechanics: [
		"action-points",
		"dice-rolling",
		"grid-movement",
		"set-collection"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.horrified.name",
	descKey: "games.horrified.desc",
	rulesKey: "games.horrified.rules",
	icon: "🦇",
	iconImg: "games/horrified.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2, 3],
	accent: "#7b3fb5",
	releasedAt: "2026-11-28T15:53:00+08:00",
	search: {
		py: "duo ming jing hun",
		init: "dmjh"
	},
	hotseat: "open"
}, he = [
	"dracula",
	"mummy",
	"frank",
	"bride",
	"creature",
	"wolfman",
	"invisibleman"
];
function ge(e) {
	return e === "frank" || e === "bride" ? "frankenstein" : e;
}
function _e(e, t) {
	return `${e}#${t}`;
}
function I(e) {
	return e.slice(0, e.indexOf("#"));
}
function ve(e, t) {
	return `${e}#${t}`;
}
function ye(e) {
	return e.slice(0, e.indexOf("#"));
}
//#endregion
//#region src/game/logic.ts
function L(e, ...t) {
	e.queue.unshift(...t);
}
function R(e, t) {
	e.log.push(t), e.log.length > 80 && e.log.splice(0, e.log.length - 80);
}
function be(e) {
	return e.heroes[e.turn];
}
function z(e, t) {
	return e.heroes.find((e) => e.id === t) ?? null;
}
function xe(e, t) {
	return z(e, t)?.owner ?? null;
}
function Se(e) {
	return e === "scientist";
}
function Ce(e, t) {
	return S[I(t)].strength + +!!Se(e);
}
function we(e, t) {
	return t.reduce((t, n) => t + Ce(e, n), 0);
}
function B(e) {
	return S[I(e)].color;
}
function V(e, t) {
	return e.config.monsters.includes(t) && !e.defeated.includes(t);
}
function H(e, t) {
	return V(e, ge(t)) ? U(e, t) !== null : !1;
}
function U(e, t) {
	switch (t) {
		case "dracula": return e.monsters.dracula.space;
		case "creature": return e.monsters.creature.space;
		case "frank": return e.monsters.fb.frank;
		case "bride": return e.monsters.fb.bride;
		case "mummy": return e.monsters.mummy.space;
		case "wolfman": return e.monsters.wolfman.space;
		case "invisibleman": return e.monsters.invisibleman.space;
	}
}
function Te(e, t, n) {
	switch (t) {
		case "dracula":
			e.monsters.dracula.space = n;
			break;
		case "creature":
			e.monsters.creature.space = n;
			break;
		case "frank":
			e.monsters.fb.frank = n;
			break;
		case "bride":
			e.monsters.fb.bride = n;
			break;
		case "mummy":
			e.monsters.mummy.space = n;
			break;
		case "wolfman":
			e.monsters.wolfman.space = n;
			break;
		case "invisibleman": e.monsters.invisibleman.space = n;
	}
}
function Ee(e, t) {
	if (t === "frenzy") {
		let t = e.frenzy;
		return t === "frankenstein" ? "frank" : t;
	}
	return t === "frankenstein" ? "frank" : t;
}
function De(e) {
	let t = [];
	return V(e, "creature") && t.push("creature"), V(e, "dracula") && t.push("dracula"), V(e, "frankenstein") && t.push("frank", "bride"), V(e, "mummy") && t.push("mummy"), V(e, "wolfman") && t.push("wolfman"), V(e, "invisibleman") && t.push("invisibleman"), t;
}
function Oe(e) {
	return fe(e, (e) => !b[e].water);
}
function ke(e, t) {
	return fe(t, (t) => e === "creature" || !b[t].water);
}
function Ae(e, t, n) {
	return [...fe(e, (e) => n || !b[e].water).values()].filter((e) => e.dist > 0 && e.dist <= t).map((e) => e.to);
}
function je(e, t) {
	return x[e].includes(t) && !b[t].water;
}
function Me(e, t, n, r) {
	let i = U(e, t);
	if (!i) return null;
	if (i === n || r <= 0) return i;
	let a = ke(t, i);
	if (!a.has(n)) return null;
	let o = pe(a, n), s = o[Math.min(r, o.length - 1)];
	return Te(e, t, s), R(e, {
		k: "monsterMoved",
		figure: t,
		space: s
	}), s;
}
function Ne(e, t, n, r) {
	let i = Ie(e, t);
	if (!i || i === n || r <= 0) return;
	let a = Oe(i);
	if (!a.has(n)) return;
	let o = pe(a, n), s = o[Math.min(r, o.length - 1)];
	if (t.kind === "hero") {
		let n = z(e, t.id);
		if (!n || n.defeated) return;
		n.space = s, R(e, {
			k: "heroMoved",
			hero: n.id,
			space: s
		});
	} else Pe(e, t.id, s);
}
function Pe(e, t, n) {
	let r = e.villagers[t];
	r.status === "board" && (r.space = n, R(e, {
		k: "villagerMoved",
		villager: t,
		space: n
	}), Xe(e));
}
function Fe(e, t, n) {
	let r = e.villagers[t];
	if (r.status !== "board" || !r.space) return;
	let i = Oe(r.space), a = T[t].safe;
	if (!i.has(a)) return;
	let o = pe(i, a);
	Pe(e, t, o[Math.min(n, o.length - 1)]);
}
function Ie(e, t) {
	return t.kind === "hero" ? z(e, t.id)?.space ?? null : e.villagers[t.id]?.space ?? null;
}
function Le(e, t) {
	return e.heroes.filter((e) => !e.defeated && e.space === t).map((e) => e.id);
}
function Re(e, t) {
	return Object.keys(e.villagers).filter((n) => e.villagers[n].status === "board" && e.villagers[n].space === t);
}
function ze(e, t) {
	return [...Le(e, t).map((e) => ({
		kind: "hero",
		id: e
	})), ...Re(e, t).map((e) => ({
		kind: "villager",
		id: e
	}))];
}
function Be(e, t) {
	let n = e.villagers[t];
	return n.status === "none" && (n.status = "board", n.space = T[t].spawn, R(e, {
		k: "villagerPlaced",
		villager: t,
		space: n.space
	}), !0);
}
function Ve(e, t) {
	let n = U(e, t);
	if (!n) return null;
	let r = ke(t, n), i = Infinity, a = [];
	for (let t of e.heroes) {
		if (t.defeated || !t.space) continue;
		let e = r.get(t.space);
		e && (e.dist < i ? (i = e.dist, a = [{
			kind: "hero",
			id: t.id
		}]) : e.dist === i && a.push({
			kind: "hero",
			id: t.id
		}));
	}
	for (let t of Object.keys(e.villagers)) {
		let n = e.villagers[t];
		if (n.status !== "board" || !n.space) continue;
		let o = r.get(n.space);
		o && (o.dist < i ? (i = o.dist, a = [{
			kind: "villager",
			id: t
		}]) : o.dist === i && a.push({
			kind: "villager",
			id: t
		}));
	}
	return a.length ? {
		dist: i,
		list: a
	} : null;
}
function He(e, t) {
	let n = U(e, t);
	if (!n) return null;
	let r = ke(t, n), i = Infinity, a = null;
	for (let t of Object.keys(e.villagers)) {
		let n = e.villagers[t];
		if (n.status !== "board" || !n.space) continue;
		let o = r.get(n.space);
		o && o.dist < i && (i = o.dist, a = t);
	}
	return a;
}
function Ue(e) {
	return e.heroes.filter((e) => !e.defeated).map((e) => e.id);
}
function We(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1), a = r[n];
		r[n] = r[i], r[i] = a;
	}
	return r;
}
function Ge(t) {
	return e(t.seed, t.cursor++, 6);
}
function Ke(e) {
	if (!e.bag.length) {
		if (!e.itemDiscard.length) return null;
		e.bag = We(e, e.itemDiscard), e.itemDiscard = [];
	}
	let t = e.bag.pop(), n = S[I(t)].space;
	return e.spaceItems[n].push(t), R(e, {
		k: "itemPlaced",
		item: t,
		space: n
	}), t;
}
function qe(e, t) {
	e.itemDiscard.push(t);
}
function Je(e, t) {
	if (!e.perkDeck.length) {
		if (!e.perkDiscard.length) return null;
		e.perkDeck = We(e, e.perkDiscard), e.perkDiscard = [];
	}
	let n = e.perkDeck.pop(), r = z(e, t);
	return r ? (r.perks.push(n), R(e, {
		k: "perkGain",
		hero: t,
		perk: ye(n)
	}), n) : null;
}
function Ye(e) {
	let t = be(e);
	for (let n of Object.keys(e.villagers)) {
		let r = e.villagers[n];
		r.status === "board" && r.space === T[n].safe && (r.status = "safe", r.space = null, R(e, {
			k: "rescued",
			villager: n,
			hero: t?.id
		}), t && Je(e, t.id));
	}
}
function Xe(e) {
	Ye(e);
}
function Ze(e, t = 1) {
	e.terror = Math.min(7, e.terror + t), R(e, {
		k: "terror",
		n: t
	});
}
function Qe(e, t) {
	let n = z(e, t);
	n && !n.defeated && (n.defeated = !0, n.space = null, Ze(e), R(e, {
		k: "heroDefeated",
		hero: t
	}));
}
function $e(e, t) {
	let n = e.villagers[t];
	n.status === "board" && (n.status = "defeated", n.space = null, Ze(e), R(e, {
		k: "villagerDefeated",
		villager: t
	}));
}
function et(e) {
	let t = e.config.monsters.filter((t) => !e.defeated.includes(t)).sort((e, t) => D[e] - D[t]);
	if (!t.length) return;
	let n = t.indexOf(e.frenzy), r = n < 0 ? t[0] : t[(n + 1) % t.length];
	r !== e.frenzy && (e.frenzy = r, R(e, {
		k: "frenzyMoved",
		monster: r
	}));
}
function tt(e, t) {
	if (!e.defeated.includes(t)) {
		switch (e.defeated.push(t), R(e, {
			k: "monsterDefeated",
			monster: t
		}), t) {
			case "dracula":
				e.monsters.dracula.space = null;
				break;
			case "creature":
				e.monsters.creature.space = null;
				break;
			case "frankenstein":
				e.monsters.fb.frank = null, e.monsters.fb.bride = null;
				break;
			case "mummy":
				e.monsters.mummy.space = null, e.soul = null;
				break;
			case "wolfman":
				e.monsters.wolfman.space = null;
				for (let t of e.monsters.wolfman.bottles) t && qe(e, t);
				e.monsters.wolfman.bottles = e.monsters.wolfman.bottles.map(() => null), e.monsters.wolfman.cure = null, e.hunted = null;
				break;
			case "invisibleman":
				e.monsters.invisibleman.space = null;
				for (let t of e.monsters.invisibleman.spots) t && qe(e, t);
				e.monsters.invisibleman.spots = e.monsters.invisibleman.spots.map(() => null);
		}
		e.frenzy === t && et(e);
	}
}
function nt(e) {
	let t = e.monsters.mummy.slots;
	for (let e of [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6"
	]) {
		let n = t[e];
		if (n.num !== Number(e) || !n.faceUp) return !1;
	}
	return t.D.num === 0;
}
function rt(e) {
	if (e.ending || e.defeated.includes("frankenstein")) return;
	let t = e.monsters.fb;
	if (t.frank && t.bride && t.frank === t.bride) {
		if (t.flipped.frank && t.flipped.bride) {
			e.queue.some((e) => e.kind === "fbCombine") || L(e, { kind: "fbCombine" });
			return;
		}
		e.terror = Math.min(7, e.terror + 1), R(e, {
			k: "fbMeet",
			space: t.frank
		}), t.frank = "graveyard", t.bride = "dungeon", e.fbMoves = null;
	}
}
function it(e, t, n) {
	e.ending || (e.ending = {
		win: t,
		reason: n
	}, e.phase = "done", e.prompt = null, e.queue = [], R(e, {
		k: t ? "win" : "lose",
		ok: t,
		n: n === "terror" ? 2 : n === "time" ? 3 : 1
	}));
}
function at(e) {
	if (!e.ending) {
		if (e.terror >= 7) {
			it(e, !1, "terror");
			return;
		}
		e.config.monsters.every((t) => e.defeated.includes(t)) && it(e, !0, "triumph");
	}
}
function ot(e) {
	rt(e), at(e);
}
function W(e, t, n = {}) {
	return {
		id: "",
		kind: e,
		ops: t,
		...n
	};
}
function G(e, t, n, r) {
	if (e.ending || !r.length) return;
	e.decision += 1;
	let i = e.decision;
	e.prompt = {
		decision: i,
		kind: n,
		owners: [...new Set(t.filter(Boolean))],
		options: r.map((e, t) => ({
			...e,
			id: `${i}:${t}`
		}))
	};
}
function st(e) {
	let t = be(e);
	return t ? [t.owner] : [];
}
function ct(e, t) {
	return [.../* @__PURE__ */ new Set([...st(e), xe(e, t) ?? ""])];
}
function lt(e) {
	e.turn = (e.turn + 1) % e.players.length;
	let t = be(e);
	e.phase = "hero", e.cardIndex = null, e.mummyMoves = 0, e.fbMoves = null, t.defeated && (t.defeated = !1, t.space = "hospital", R(e, {
		k: "revived",
		hero: t.id,
		space: "hospital"
	})), e.actionsLeft = ut[t.id], R(e, {
		k: "turnStart",
		hero: t.id
	});
}
var ut = Object.fromEntries(Object.entries(ie).map(([e, t]) => [e, t.actions]));
function dt(e) {
	return ut[e];
}
//#endregion
//#region src/game/ops.ts
function K(e) {
	return e.phase === "hero" ? [...e.players] : st(e);
}
function ft(e) {
	return e.kind === "hero" ? { hero: e.id } : { villager: e.id };
}
var pt = {
	meeting: "frankenstein",
	hunt: "wolfman",
	thief: "invisibleman",
	retreatLagoon: "creature",
	retreatRiver: "creature",
	retreatWaterfront: "creature",
	reincarnatedSoul: "mummy",
	hypnoticGaze: "dracula",
	sunrise: "dracula",
	formOfTheBat: "dracula"
};
function mt(e, t) {
	switch (t.kind) {
		case "monsterBegin": {
			if (e.ending) return;
			if (e.skipMonster) {
				e.skipMonster = !1, R(e, { k: "monsterSkipped" }), L(e, { kind: "cardEnd" });
				return;
			}
			if (!e.monsterDeck.length) {
				it(e, !1, "time");
				return;
			}
			let t = e.monsterDeck.pop(), n = le[t];
			e.cardIndex = t, e.monsterDiscard.push(t), R(e, {
				k: "monsterCard",
				n: t
			}), L(e, {
				kind: "drawItems",
				n: n.items
			}, {
				kind: "event",
				event: n.event
			}, ...n.strikes.map((e) => ({
				kind: "strike",
				symbol: e.monster,
				move: e.move,
				dice: e.dice
			})), { kind: "cardEnd" });
			return;
		}
		case "drawItems":
			for (let n = 0; n < t.n; n++) Ke(e);
			return;
		case "drawItemsEach":
			e.players.forEach(() => Ke(e));
			return;
		case "addActions":
			e.actionsLeft += t.n, R(e, {
				k: "actions",
				n: t.n
			});
			return;
		case "event": {
			let n = pt[t.event];
			if (n && !V(e, n)) {
				R(e, {
					k: "eventIgnored",
					monster: n
				});
				return;
			}
			_t(e, t.event);
			return;
		}
		case "askThief": {
			let t = y.map((t) => ({
				space: t,
				n: e.spaceItems[t].length
			})), n = Math.max(0, ...t.map((e) => e.n));
			if (!n) return;
			let r = t.filter((e) => e.n === n).map((e) => e.space);
			if (r.length === 1) {
				L(e, {
					kind: "thief",
					space: r[0]
				});
				return;
			}
			G(e, K(e), "thief", r.map((e) => W("thief", [{
				kind: "thief",
				space: e
			}], { space: e })));
			return;
		}
		case "thief":
			e.monsters.invisibleman.space = t.space;
			for (let n of e.spaceItems[t.space]) e.itemDiscard.push(n);
			e.spaceItems[t.space] = [], R(e, {
				k: "thief",
				space: t.space
			});
			return;
		case "strike": {
			let n = Ee(e, t.symbol);
			if (!n || !H(e, n) || !U(e, n)) return;
			let r = Ve(e, n);
			if (!r) return;
			let i = r.list;
			if (i.some((e) => e.kind === "hero") && (i = i.filter((e) => e.kind === "hero")), new Set(i.map((t) => ht(e, t))).size === 1) {
				L(e, {
					kind: "strikeGo",
					figure: n,
					target: i[0],
					move: t.move,
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", i.map((e) => W("attack", [{
				kind: "strikeGo",
				figure: n,
				target: e,
				move: t.move,
				dice: t.dice
			}], ft(e))));
			return;
		}
		case "strikeGo": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = ht(e, t.target);
			if (!r) return;
			if (n !== r) {
				let i = ke(t.figure, n);
				if (i.has(r)) {
					let n = pe(i, r), a = n[Math.min(t.move, n.length - 1)];
					Te(e, t.figure, a), R(e, {
						k: "monsterMoved",
						figure: t.figure,
						space: a
					});
				}
			}
			let i = U(e, t.figure);
			if (!i) return;
			let a = ze(e, i);
			if (a.some((e) => e.kind === "hero") && (a = a.filter((e) => e.kind === "hero")), !a.length) return;
			if (a.length === 1) {
				L(e, {
					kind: "strikeRoll",
					figure: t.figure,
					target: a[0],
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", a.map((e) => W("attack", [{
				kind: "strikeRoll",
				figure: t.figure,
				target: e,
				dice: t.dice
			}], ft(e))));
			return;
		}
		case "strikeRoll": {
			let n = [];
			for (let r = 0; r < t.dice; r++) n.push(Ge(e));
			let r = n.filter((e) => e < 3).length, i = n.filter((e) => e === 5).length;
			e.lastRoll = {
				figure: t.figure,
				dice: n,
				hits: r,
				powers: i
			}, R(e, {
				k: "roll",
				figure: t.figure,
				n: r,
				n2: i
			});
			let a = [];
			for (let e = 0; e < r; e++) a.push(t.target.kind === "hero" ? {
				kind: "hitHero",
				hero: t.target.id
			} : {
				kind: "hitVillager",
				villager: t.target.id
			});
			for (let e = 0; e < i; e++) a.push({
				kind: "power",
				figure: t.figure
			});
			a.length && L(e, ...a);
			return;
		}
		case "hitHero": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			if (!n.items.length) {
				Qe(e, t.hero), R(e, {
					k: "hit",
					hero: t.hero
				});
				return;
			}
			G(e, [.../* @__PURE__ */ new Set([...ct(e, t.hero), ...K(e)])], "defend", [...n.items.map((e) => W("defend", [{
				kind: "defend",
				hero: t.hero,
				uid: e
			}], {
				hero: t.hero,
				item: e
			})), W("takeHit", [{
				kind: "takeHit",
				hero: t.hero
			}], { hero: t.hero })]);
			return;
		}
		case "hitVillager":
			if (e.villagers[t.villager].status !== "board") return;
			$e(e, t.villager), R(e, {
				k: "hit",
				villager: t.villager
			});
			return;
		case "defend": {
			let n = z(e, t.hero);
			if (!n) return;
			let r = n.items.indexOf(t.uid);
			if (r < 0) return;
			n.items.splice(r, 1), e.itemDiscard.push(t.uid), R(e, {
				k: "defended",
				hero: t.hero,
				item: t.uid
			});
			return;
		}
		case "takeHit": {
			let n = z(e, t.hero);
			if (!n || n.defeated) return;
			Qe(e, t.hero), R(e, {
				k: "hit",
				hero: t.hero
			});
			return;
		}
		case "power":
			gt(e, t.figure);
			return;
		case "cardEnd":
			if (e.ending) return;
			lt(e);
			return;
		case "endGame":
			it(e, t.win, t.reason);
			return;
		case "gainPerk":
			Je(e, t.hero);
			return;
		case "skipMonster":
			e.skipMonster = !0, R(e, { k: "monsterWillSkip" });
			return;
		case "moveFigure":
			Te(e, t.figure, t.to), R(e, {
				k: "monsterMoved",
				figure: t.figure,
				space: t.to
			});
			return;
		case "moveHero": {
			let n = z(e, t.hero);
			if (!n || n.defeated) return;
			n.space = t.to, R(e, {
				k: "heroMoved",
				hero: t.hero,
				space: t.to
			});
			return;
		}
		case "moveVillager":
			Pe(e, t.villager, t.to);
			return;
		case "transferItem": {
			let n = z(e, t.from), r = z(e, t.to);
			if (!n || !r) return;
			let i = n.items.indexOf(t.uid);
			if (i < 0) return;
			n.items.splice(i, 1), r.items.push(t.uid), R(e, {
				k: "itemGiven",
				hero: t.from,
				hero2: t.to,
				item: t.uid
			});
			return;
		}
		case "transferCure":
			if (e.monsters.wolfman.cure !== t.from) return;
			e.monsters.wolfman.cure = t.to, R(e, {
				k: "cureGiven",
				hero: t.from,
				hero2: t.to
			});
			return;
		case "fbReset":
			e.monsters.fb.frank = "graveyard", e.monsters.fb.bride = "dungeon";
			return;
		case "fbCombine":
			tt(e, "frankenstein"), R(e, { k: "fbDefeated" });
			return;
		case "askPlaceNamed": {
			let n = t.figures.filter((t) => H(e, t));
			if (!n.length) return;
			if (n.length > 1) {
				G(e, K(e), "placeFigure", n.map((e) => W("figure", [{
					kind: "askPlaceNamed",
					figures: [e]
				}], { figure: e })));
				return;
			}
			let r = n[0], i = y.filter((e) => r === "creature" || !b[e].water);
			G(e, K(e), "placeFigure", i.map((e) => W("place", [{
				kind: "moveFigure",
				figure: r,
				to: e
			}], {
				figure: r,
				space: e
			})));
			return;
		}
		case "askFigureDest": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = [...ke(t.figure, n).values()].filter((e) => e.dist > 0 && e.dist <= t.steps).map((e) => e.to), i = [W("stay", [], { figure: t.figure }), ...r.map((e) => W("space", [{
				kind: "moveFigure",
				figure: t.figure,
				to: e
			}], {
				figure: t.figure,
				space: e
			}))];
			G(e, K(e), "figureDest", i);
			return;
		}
		case "askMoveAny": {
			let n = De(e).filter((t) => U(e, t));
			if (!n.length) return;
			G(e, K(e), "moveFigure", n.map((e) => W("figure", [{
				kind: "askFigureDest",
				figure: e,
				steps: t.steps
			}], { figure: e })));
			return;
		}
		case "askHeroMove":
			if (!t.heroes.length) return;
			G(e, K(e), "moveHero", t.heroes.map((e) => W("hero", [{
				kind: "askHeroDest",
				hero: e,
				steps: t.steps,
				anyLand: !0,
				carry: t.carry
			}], { hero: e })));
			return;
		case "askHeroDest": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			let r = Ae(n.space, t.steps, !1), i = t.carry && Re(e, n.space).length > 0, a = [W("stay", [], { hero: t.hero }), ...r.map((e) => W("space", [i ? {
				kind: "askHeroCarry",
				hero: t.hero,
				to: e,
				chosen: [],
				remaining: []
			} : {
				kind: "moveHero",
				hero: t.hero,
				to: e
			}], {
				hero: t.hero,
				space: e
			}))];
			G(e, K(e), "heroDest", a);
			return;
		}
		case "askHeroCarry": {
			let n = z(e, t.hero);
			if (!n || n.defeated || !n.space) return;
			let r = Re(e, n.space);
			if (!r.length) {
				L(e, {
					kind: "moveHero",
					hero: t.hero,
					to: t.to
				}), t.remaining.length && L(e, {
					kind: "askHurry",
					remaining: t.remaining
				});
				return;
			}
			let i = t.chosen.filter((e) => r.includes(e)), a = (e) => i.includes(e) ? i.filter((t) => t !== e) : [...i, e], o = [...r.map((e) => W(i.includes(e) ? "villagerOn" : "villagerOff", [{
				kind: "askHeroCarry",
				hero: t.hero,
				to: t.to,
				chosen: a(e),
				remaining: t.remaining
			}], { villager: e })), W("carryConfirm", [
				{
					kind: "moveHero",
					hero: t.hero,
					to: t.to
				},
				...i.map((e) => ({
					kind: "moveVillager",
					villager: e,
					to: t.to
				})),
				...t.remaining.length ? [{
					kind: "askHurry",
					remaining: t.remaining
				}] : []
			])];
			G(e, K(e), "carry", o);
			return;
		}
		case "askHurry": {
			let [n, ...r] = t.remaining;
			if (!n) return;
			let i = z(e, n);
			if (!i || i.defeated || !i.space) {
				L(e, {
					kind: "askHurry",
					remaining: r
				});
				return;
			}
			let a = Ae(i.space, 2, !1), o = Re(e, i.space).length > 0, s = [W("stay", [{
				kind: "askHurry",
				remaining: r
			}], { hero: n }), ...a.map((e) => W("space", o ? [{
				kind: "askHeroCarry",
				hero: n,
				to: e,
				chosen: [],
				remaining: r
			}] : [{
				kind: "moveHero",
				hero: n,
				to: e
			}, {
				kind: "askHurry",
				remaining: r
			}], {
				hero: n,
				space: e
			}))];
			G(e, K(e), "hurry", s);
			return;
		}
		case "askInvestigate": {
			let t = [...new Set(e.heroes.filter((e) => !e.defeated && e.space).map((e) => e.space))];
			if (!t.length) return;
			G(e, K(e), "investigate", t.map((t) => W("space", [{
				kind: "askInvestigateHero",
				space: t,
				remaining: Ue(e).filter((n) => z(e, n)?.space !== t)
			}], { space: t })));
			return;
		}
		case "askInvestigateHero": {
			let n = t.remaining.filter((n) => {
				let r = z(e, n);
				return !!r && !r.defeated && r.space !== t.space;
			}).map((e) => W("hero", [{
				kind: "moveHero",
				hero: e,
				to: t.space
			}, {
				kind: "askInvestigateHero",
				space: t.space,
				remaining: t.remaining.filter((t) => t !== e)
			}], { hero: e }));
			n.push(W("done", [], {})), G(e, K(e), "investigateHero", n);
			return;
		}
		case "askRepel": {
			let [n, ...r] = t.remaining;
			if (!n) return;
			if (!H(e, n) || !U(e, n)) {
				L(e, {
					kind: "askRepel",
					remaining: r
				});
				return;
			}
			let i = [...ke(n, U(e, n)).values()].filter((e) => e.dist > 0 && e.dist <= 2).map((e) => e.to), a = [W("stay", [{
				kind: "askRepel",
				remaining: r
			}], { figure: n }), ...i.map((e) => W("space", [{
				kind: "moveFigure",
				figure: n,
				to: e
			}, {
				kind: "askRepel",
				remaining: r
			}], {
				figure: n,
				space: e
			}))];
			G(e, K(e), "repel", a);
			return;
		}
		case "askDeliveryFrom": {
			let t = e.heroes.filter((e) => e.items.length > 0);
			if (!t.length) return;
			G(e, K(e), "deliveryFrom", t.map((e) => W("hero", [{
				kind: "askDeliveryTo",
				from: e.id
			}], { hero: e.id })));
			return;
		}
		case "askDeliveryTo": {
			if (!z(e, t.from)) return;
			let n = e.heroes.filter((e) => e.id !== t.from);
			if (!n.length) return;
			G(e, K(e), "deliveryTo", n.map((e) => W("hero", [{
				kind: "askDeliveryItem",
				from: t.from,
				to: e.id
			}], {
				hero: e.id,
				hero2: t.from
			})));
			return;
		}
		case "askDeliveryItem": {
			let n = z(e, t.from);
			if (!n) return;
			let r = n.items.map((e) => W("item", [{
				kind: "transferItem",
				from: t.from,
				to: t.to,
				uid: e
			}, {
				kind: "askDeliveryItem",
				from: t.from,
				to: t.to
			}], {
				item: e,
				hero: t.to
			}));
			r.push(W("done", [], {})), G(e, K(e), "deliveryItem", r);
			return;
		}
		case "askAttackTarget": {
			let n = U(e, t.figure);
			if (!n) return;
			let r = ze(e, n);
			if (r.some((e) => e.kind === "hero") && (r = r.filter((e) => e.kind === "hero")), !r.length) return;
			if (r.length === 1) {
				L(e, {
					kind: "strikeRoll",
					figure: t.figure,
					target: r[0],
					dice: t.dice
				});
				return;
			}
			G(e, K(e), "attack", r.map((e) => W("attack", [{
				kind: "strikeRoll",
				figure: t.figure,
				target: e,
				dice: t.dice
			}], ft(e))));
			return;
		}
		case "askGaze": {
			let t = Ve(e, "dracula");
			if (!t) return;
			G(e, K(e), "gaze", t.list.map((e) => W("gaze", [{
				kind: "gazeMove",
				person: e
			}], ft(e))));
			return;
		}
		case "gazeMove": {
			let n = e.monsters.dracula.space;
			if (!n) return;
			Ne(e, t.person, n, 3);
			return;
		}
	}
}
function ht(e, t) {
	return t.kind === "hero" ? z(e, t.id)?.space ?? null : e.villagers[t.id]?.space ?? null;
}
function gt(e, t) {
	switch (t) {
		case "dracula": {
			let t = be(e), n = e.monsters.dracula.space;
			if (!t || t.defeated || !n || t.space === n) return;
			t.space = n, R(e, {
				k: "charmed",
				hero: t.id,
				space: n
			});
			return;
		}
		case "creature":
			if (e.monsters.creature.boat <= 0) return;
			--e.monsters.creature.boat, R(e, {
				k: "boatBack",
				n: e.monsters.creature.boat
			});
			return;
		case "frank":
		case "bride": {
			let { frank: t, bride: n } = e.monsters.fb;
			if (!t || !n) return;
			Me(e, "bride", t, 1);
			return;
		}
		case "mummy": {
			let t = null, n = Infinity;
			for (let r of N) {
				let i = e.monsters.mummy.slots[r];
				i.faceUp && i.num > 0 && i.num < n && (n = i.num, t = r);
			}
			if (!t) return;
			e.monsters.mummy.slots[t].faceUp = !1, R(e, {
				k: "scarabFlipped",
				slot: t
			});
			return;
		}
		case "wolfman": {
			let t = e.monsters.wolfman.space;
			if (!t) return;
			for (let n of Le(e, t)) L(e, {
				kind: "hitHero",
				hero: n
			});
			for (let n of Re(e, t)) L(e, {
				kind: "hitVillager",
				villager: n
			});
			return;
		}
		case "invisibleman": {
			let t = He(e, "invisibleman");
			if (!t) return;
			let n = e.villagers[t].space;
			if (!n) return;
			Me(e, "invisibleman", n, 2);
			return;
		}
	}
}
function _t(e, t) {
	switch (t) {
		case "onTheMove":
			et(e);
			for (let t of Object.keys(e.villagers)) e.villagers[t].status === "board" && Fe(e, t, 1);
			return;
		case "meeting": {
			let { frank: t, bride: n } = e.monsters.fb;
			t && n && Me(e, "bride", t, 2);
			return;
		}
		case "hunt": {
			if (e.hunted === null) {
				let t = be(e);
				t && (e.hunted = t.id, R(e, {
					k: "hunted",
					hero: t.id
				}));
			}
			let t = e.hunted ? z(e, e.hunted) : null;
			if (!t || t.defeated || !t.space) return;
			Me(e, "wolfman", t.space, 3);
			return;
		}
		case "thief":
			L(e, { kind: "askThief" });
			return;
		case "retreatLagoon":
		case "retreatRiver":
		case "retreatWaterfront": {
			let n = t === "retreatLagoon" ? "lagoon" : t === "retreatRiver" ? "river" : "waterfront";
			e.monsters.creature.space = n, R(e, {
				k: "monsterMoved",
				figure: "creature",
				space: n
			});
			return;
		}
		case "innocent":
			Be(e, "maria");
			return;
		case "insaneSurvivor":
			Be(e, "renfield");
			return;
		case "worriedFiancee":
			Be(e, "elizabeth");
			return;
		case "enthralled":
			Be(e, "lucy");
			return;
		case "delivery":
			Be(e, "wilbur");
			return;
		case "fortuneTeller":
			Be(e, "maleva");
			return;
		case "hurriedAssistant":
			Be(e, "fritz");
			return;
		case "egyptianExpert":
			Be(e, "pearson");
			return;
		case "formerEmployer":
			Be(e, "cranley");
			return;
		case "ichthyologist":
			Be(e, "reed");
			return;
		case "reincarnatedSoul": {
			if (e.soul === null) {
				let t = be(e);
				t && (e.soul = t.id, R(e, {
					k: "soul",
					hero: t.id
				}));
			}
			let t = e.soul ? z(e, e.soul) : null, n = e.monsters.mummy.space;
			if (!t || t.defeated || !t.space || !n) return;
			Ne(e, {
				kind: "hero",
				id: t.id
			}, n, 3);
			return;
		}
		case "hypnoticGaze":
			L(e, { kind: "askGaze" });
			return;
		case "sunrise":
			e.monsters.dracula.space = "crypt", R(e, {
				k: "monsterMoved",
				figure: "dracula",
				space: "crypt"
			});
			return;
		case "formOfTheBat": {
			let t = be(e);
			if (!t || t.defeated || !t.space) return;
			e.monsters.dracula.space = t.space, R(e, {
				k: "monsterMoved",
				figure: "dracula",
				space: t.space
			});
			return;
		}
	}
}
function vt(e, t) {
	let n = ye(t);
	switch (R(e, {
		k: "perkPlayed",
		perk: n
	}), n) {
		case "breakOfDawn":
			e.skipMonster = !0, L(e, {
				kind: "drawItems",
				n: 2
			});
			return;
		case "lateNight":
			e.actionsLeft += 2, R(e, {
				k: "actions",
				n: 2
			});
			return;
		case "overstock":
			L(e, {
				kind: "drawItems",
				n: e.players.length
			});
			return;
		case "taxiRide":
			L(e, {
				kind: "askHeroMove",
				heroes: Ue(e),
				steps: 99,
				carry: !1
			});
			return;
		case "rush":
			L(e, {
				kind: "askHeroMove",
				heroes: Ue(e),
				steps: 4,
				carry: !0
			});
			return;
		case "hurry":
			L(e, {
				kind: "askHurry",
				remaining: Ue(e)
			});
			return;
		case "investigation":
			L(e, { kind: "askInvestigate" });
			return;
		case "repel":
			L(e, {
				kind: "askRepel",
				remaining: De(e)
			});
			return;
		case "specialDelivery":
			L(e, { kind: "askDeliveryFrom" });
			return;
		case "detective":
			yt(e, ["invisibleman"]);
			return;
		case "crucifix":
			yt(e, ["dracula"]);
			return;
		case "huntedPrey":
			yt(e, ["wolfman"]);
			return;
		case "ancients":
			yt(e, ["mummy"]);
			return;
		case "showForce":
			yt(e, ["creature"]);
			return;
		case "mobJustice":
			yt(e, ["frank", "bride"]);
			return;
	}
}
function yt(e, t) {
	let n = t.filter((t) => H(e, t)), r = [];
	n.length && r.push(W("modePlace", [{
		kind: "askPlaceNamed",
		figures: n
	}])), r.push(W("modeMove", [{
		kind: "askMoveAny",
		steps: 3
	}])), G(e, K(e), "perkMode", r);
}
//#endregion
//#region src/game/actions.ts
var q = { code: "games.horrified.invalidAction" };
function bt(e, t, n) {
	if (t.type === "choose" || t.type === "tick" || e.ending) return q;
	if (t.type === "playPerk") {
		if (e.phase !== "hero" || e.prompt || e.queue.length || !e.players.includes(n)) return q;
		let r = e.heroes.find((e) => e.perks.includes(t.uid));
		return r ? (r.perks.splice(r.perks.indexOf(t.uid), 1), e.perkDiscard.push(t.uid), vt(e, t.uid), null) : q;
	}
	let r = be(e);
	if (!r || r.owner !== n || r.defeated || e.phase !== "hero" || e.prompt || e.queue.length) return q;
	if (e.mummyMoves > 0 || e.fbMoves) return t.type === "mummySlide" || t.type === "mummyFlip" || t.type === "mummyDone" ? e.mummyMoves > 0 ? xt(e, t) : q : (t.type === "fbMove" || t.type === "fbDone") && e.fbMoves ? St(e, t) : q;
	if (t.type === "mummySlide" || t.type === "mummyFlip" || t.type === "mummyDone" || t.type === "fbMove" || t.type === "fbDone") return q;
	if (t.type === "endTurn") return e.phase = "monster", e.actionsLeft = 0, e.mummyMoves = 0, e.fbMoves = null, R(e, {
		k: "heroEnd",
		hero: r.id
	}), L(e, { kind: "monsterBegin" }), null;
	if (e.actionsLeft <= 0) return q;
	let i = r.space;
	if (!i) return q;
	switch (t.type) {
		case "move": {
			if (!je(i, t.to)) return q;
			let n = [...new Set(t.villagers)];
			for (let t of n) {
				let n = e.villagers[t];
				if (n.status !== "board" || n.space !== i) return q;
			}
			r.space = t.to, R(e, {
				k: "heroMoved",
				hero: r.id,
				space: t.to
			});
			for (let r of n) {
				let n = e.villagers[r];
				n.space = t.to, R(e, {
					k: "villagerMoved",
					villager: r,
					space: t.to
				});
			}
			return --e.actionsLeft, Xe(e), null;
		}
		case "guide": {
			let n = e.villagers[t.villager];
			if (n.status !== "board" || !n.space) return q;
			let r = n.space === i && je(i, t.to), a = t.to === i && je(i, n.space);
			return !r && !a ? q : (Pe(e, t.villager, t.to), --e.actionsLeft, null);
		}
		case "pickup": {
			let n = [...new Set(t.uids)], a = e.spaceItems[i];
			if (n.some((e) => !a.includes(e))) return q;
			for (let e of n) a.splice(a.indexOf(e), 1);
			return r.items.push(...n), R(e, {
				k: "pickup",
				hero: r.id,
				n: n.length
			}), --e.actionsLeft, null;
		}
		case "share": {
			let n = z(e, t.from), r = z(e, t.to);
			if (!n || !r || n.defeated || r.defeated || n.id === r.id || n.space !== i || r.space !== i) return q;
			let a = [...new Set(t.uids)];
			if (a.some((e) => !n.items.includes(e)) || t.cure && e.monsters.wolfman.cure !== n.id || !a.length && !t.cure) return q;
			for (let t of a) n.items.splice(n.items.indexOf(t), 1), r.items.push(t), R(e, {
				k: "itemGiven",
				hero: n.id,
				hero2: r.id,
				item: t
			});
			return t.cure && (e.monsters.wolfman.cure = r.id, R(e, {
				k: "cureGiven",
				hero: n.id,
				hero2: r.id
			})), --e.actionsLeft, null;
		}
		case "advance": return Ct(e, r.id, i, t.monster, t.uids);
		case "defeat": return Tt(e, r.id, i, t.monster, t.uids);
		case "specialArchaeologist": {
			if (r.id !== "archaeologist" || !je(i, t.space)) return q;
			let n = [...new Set(t.uids)];
			if (!n.length) return q;
			let a = e.spaceItems[t.space];
			if (n.some((e) => !a.includes(e))) return q;
			for (let e of n) a.splice(a.indexOf(e), 1);
			return r.items.push(...n), R(e, {
				k: "pickup",
				hero: r.id,
				n: n.length,
				space: t.space
			}), --e.actionsLeft, null;
		}
		case "specialCourier": return r.id !== "courier" || !e.heroes.some((e) => e.id !== r.id && !e.defeated && e.space === t.to) ? q : (r.space = t.to, R(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Xe(e), null);
		case "specialExplorer": return r.id !== "explorer" || b[t.to].water ? q : (r.space = t.to, R(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Xe(e), null);
		case "specialInspector": return r.id !== "inspector" || b[t.to].water || !(H(e, "dracula") && U(e, "dracula") === t.to || H(e, "creature") && U(e, "creature") === t.to || H(e, "mummy") && U(e, "mummy") === t.to || H(e, "wolfman") && U(e, "wolfman") === t.to || H(e, "invisibleman") && U(e, "invisibleman") === t.to || H(e, "frank") && U(e, "frank") === t.to || H(e, "bride") && U(e, "bride") === t.to) ? q : (r.space = t.to, R(e, {
			k: "heroMoved",
			hero: r.id,
			space: t.to
		}), --e.actionsLeft, Xe(e), null);
		case "specialProfessor": {
			if (r.id !== "professor" || !!t.hero == !!t.villager) return q;
			let n = t.hero ? z(e, t.hero)?.space ?? null : e.villagers[t.villager].space;
			if (!n || !je(n, t.to)) return q;
			if (t.hero) {
				let n = z(e, t.hero);
				if (!n || n.defeated) return q;
				let r = [...new Set(t.villagers)], i = n.space;
				if (r.some((t) => e.villagers[t].status !== "board" || e.villagers[t].space !== i)) return q;
				n.space = t.to, R(e, {
					k: "heroMoved",
					hero: n.id,
					space: t.to
				});
				for (let n of r) e.villagers[n].space = t.to, R(e, {
					k: "villagerMoved",
					villager: n,
					space: t.to
				});
				Xe(e);
			} else {
				if (t.villagers.length || e.villagers[t.villager].status !== "board") return q;
				Pe(e, t.villager, t.to);
			}
			return --e.actionsLeft, null;
		}
		default: return q;
	}
}
function xt(e, t) {
	if (t.type === "mummyDone") return e.mummyMoves = 0, R(e, { k: "mummyDone" }), null;
	if (t.type === "mummyFlip") {
		let n = e.monsters.mummy.slots[t.slot];
		return n.num <= 0 || n.faceUp ? q : (n.faceUp = !0, --e.mummyMoves, R(e, {
			k: "scarabFlip",
			slot: t.slot
		}), null);
	}
	let n = e.monsters.mummy.slots[t.from], r = e.monsters.mummy.slots[t.to];
	return n.num <= 0 || !n.faceUp || r.num !== 0 || !se[t.from].includes(t.to) ? q : (r.num = n.num, r.faceUp = !0, n.num = 0, n.faceUp = !1, --e.mummyMoves, R(e, {
		k: "scarabSlide",
		slot: t.from
	}), null);
}
function St(e, t) {
	let n = e.fbMoves;
	if (!n) return q;
	if (t.type === "fbDone") return e.fbMoves = null, null;
	let r = n.figure;
	if (!H(e, r)) return q;
	let i = U(e, r);
	if (!i || i === t.to) return q;
	let a = ke(r, i).get(t.to);
	if (!a || a.dist > n.remaining) return q;
	Te(e, r, t.to), R(e, {
		k: "monsterMoved",
		figure: r,
		space: t.to
	});
	let o = n.remaining - a.dist;
	return e.fbMoves = o > 0 ? {
		figure: r,
		remaining: o
	} : null, null;
}
function Ct(e, t, n, r, i) {
	let a = z(e, t);
	if (!H(e, r)) return q;
	let o = [...new Set(i)];
	switch (r) {
		case "dracula":
			if (!e.monsters.dracula.coffins.includes(n) || !o.length || o.some((e) => !a.items.includes(e) || B(e) !== "red") || we(t, o) < 6) return q;
			for (let t of o) a.items.splice(a.items.indexOf(t), 1), qe(e, t);
			return e.monsters.dracula.coffins = e.monsters.dracula.coffins.filter((e) => e !== n), R(e, {
				k: "coffinBroken",
				hero: t,
				space: n
			}), --e.actionsLeft, null;
		case "creature": {
			if (n !== "camp" || o.length !== 1 || !a.items.includes(o[0])) return q;
			let r = e.monsters.creature.boat;
			if (r >= M) return q;
			let i = B(o[0]), s = -1;
			for (let e = r + 1; e <= M; e++) if (j[e - 1] === i) {
				s = e;
				break;
			}
			return s < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), qe(e, o[0]), e.monsters.creature.boat = s, R(e, {
				k: "boatAdvance",
				hero: t,
				n: s
			}), --e.actionsLeft, null);
		}
		case "frank":
		case "bride": {
			if (U(e, r) !== n) return q;
			let i = r === "frank" ? "yellow" : "blue";
			if (o.length !== 1 || !a.items.includes(o[0]) || B(o[0]) !== i) return q;
			let s = Ce(t, o[0]);
			a.items.splice(a.items.indexOf(o[0]), 1), qe(e, o[0]);
			let c = e.monsters.fb;
			c.score[r] += s;
			let l = A[r];
			return !c.flipped[r] && c.score[r] >= l && (c.flipped[r] = !0, R(e, {
				k: "fbFlipped",
				figure: r,
				n: c.score[r]
			})), e.fbMoves = {
				figure: r,
				remaining: s
			}, R(e, {
				k: "advance",
				hero: t,
				figure: r,
				n: s
			}), --e.actionsLeft, null;
		}
		case "mummy": {
			if (n !== "museum" || o.length !== 1 || !a.items.includes(o[0]) || B(o[0]) !== "yellow") return q;
			let r = Ce(t, o[0]);
			return a.items.splice(a.items.indexOf(o[0]), 1), qe(e, o[0]), e.mummyMoves = r, R(e, {
				k: "mummyAdvance",
				hero: t,
				n: r
			}), --e.actionsLeft, null;
		}
		case "wolfman": {
			if (n !== "laboratory" || o.length !== 1 || !a.items.includes(o[0]) || B(o[0]) !== "blue") return q;
			let r = S[I(o[0])].strength, i = Se(t) ? [r, r + 1] : [r], s = e.monsters.wolfman.bottles.findIndex((e, t) => e === null && i.includes(k[t]));
			return s < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), e.monsters.wolfman.bottles[s] = o[0], R(e, {
				k: "bottleFilled",
				hero: t,
				n: k[s]
			}), e.monsters.wolfman.bottles.every((e) => e !== null) && (e.monsters.wolfman.cure = t, R(e, {
				k: "cureTaken",
				hero: t
			})), --e.actionsLeft, null);
		}
		case "invisibleman": {
			if (n !== "precinct" || o.length !== 1 || !a.items.includes(o[0])) return q;
			let r = S[I(o[0])].space, i = e.monsters.invisibleman.spots.findIndex((e, t) => e === null && O[t] === r);
			return i < 0 ? q : (a.items.splice(a.items.indexOf(o[0]), 1), e.monsters.invisibleman.spots[i] = o[0], R(e, {
				k: "spotFilled",
				hero: t,
				space: r
			}), --e.actionsLeft, null);
		}
	}
}
function wt(e, t, n, r) {
	let i = z(e, t);
	return !i || !n.length || n.some((e) => !i.items.includes(e) || B(e) !== "red") ? !1 : we(t, n) >= r;
}
function Tt(e, t, n, r, i) {
	let a = z(e, t);
	if (!H(e, r)) return q;
	let o = [...new Set(i)];
	if (o.length !== i.length) return q;
	let s = (t, n) => {
		for (let r of t) a.items.splice(a.items.indexOf(r), 1), n && qe(e, r);
	};
	switch (r) {
		case "dracula": return U(e, "dracula") !== n || e.monsters.dracula.coffins.length || !o.length || o.some((e) => !a.items.includes(e) || B(e) !== "yellow") || we(t, o) < 6 ? q : (s(o, !0), tt(e, "dracula"), R(e, {
			k: "defeat",
			hero: t,
			monster: "dracula"
		}), --e.actionsLeft, null);
		case "creature": {
			if (U(e, "creature") !== n || e.monsters.creature.boat !== M || o.length !== 3 || o.some((e) => !a.items.includes(e))) return q;
			let r = o.map(B);
			return [
				"red",
				"blue",
				"yellow"
			].every((e) => r.includes(e)) ? (s(o, !0), tt(e, "creature"), R(e, {
				k: "defeat",
				hero: t,
				monster: "creature"
			}), --e.actionsLeft, null) : q;
		}
		case "mummy": return U(e, "mummy") !== n || !nt(e) || !wt(e, t, o, 9) ? q : (s(o, !0), tt(e, "mummy"), R(e, {
			k: "defeat",
			hero: t,
			monster: "mummy"
		}), --e.actionsLeft, null);
		case "wolfman": return U(e, "wolfman") !== n || e.monsters.wolfman.cure !== t || !wt(e, t, o, 6) ? q : (s(o, !0), e.monsters.wolfman.cure = null, tt(e, "wolfman"), R(e, {
			k: "defeat",
			hero: t,
			monster: "wolfman"
		}), --e.actionsLeft, null);
		case "invisibleman": return U(e, "invisibleman") !== n || e.monsters.invisibleman.spots.some((e) => e === null) || !wt(e, t, o, 9) ? q : (s(o, !0), tt(e, "invisibleman"), R(e, {
			k: "defeat",
			hero: t,
			monster: "invisibleman"
		}), --e.actionsLeft, null);
		case "frank":
		case "bride": return q;
	}
}
//#endregion
//#region src/game/schema.ts
var Et = t.object({ monsters: t.array(t.enum(E)).min(1).max(4).refine((e) => new Set(e).size === e.length).default(["creature", "dracula"]) }).prefault({}), J = t.enum(w), Y = t.enum(y), Dt = t.enum(ae), Ot = t.enum(he), X = t.string().min(1).max(40), kt = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		to: Y,
		villagers: t.array(Dt).max(10).default([])
	}),
	t.object({
		type: t.literal("guide"),
		villager: Dt,
		to: Y
	}),
	t.object({
		type: t.literal("pickup"),
		uids: t.array(X).min(1).max(12)
	}),
	t.object({
		type: t.literal("share"),
		from: J,
		to: J,
		uids: t.array(X).max(12).default([]),
		cure: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("advance"),
		monster: Ot,
		uids: t.array(X).max(12)
	}),
	t.object({
		type: t.literal("defeat"),
		monster: Ot,
		uids: t.array(X).max(12)
	}),
	t.object({
		type: t.literal("mummySlide"),
		from: t.enum(N),
		to: t.enum(N)
	}),
	t.object({
		type: t.literal("mummyFlip"),
		slot: t.enum(N)
	}),
	t.object({ type: t.literal("mummyDone") }),
	t.object({
		type: t.literal("fbMove"),
		to: Y
	}),
	t.object({ type: t.literal("fbDone") }),
	t.object({
		type: t.literal("specialArchaeologist"),
		space: Y,
		uids: t.array(X).min(1).max(12)
	}),
	t.object({
		type: t.literal("specialCourier"),
		to: Y
	}),
	t.object({
		type: t.literal("specialExplorer"),
		to: Y
	}),
	t.object({
		type: t.literal("specialInspector"),
		to: Y
	}),
	t.object({
		type: t.literal("specialProfessor"),
		hero: J.optional(),
		villager: Dt.optional(),
		to: Y,
		villagers: t.array(Dt).max(10).default([])
	}),
	t.object({
		type: t.literal("playPerk"),
		uid: X
	}),
	t.object({
		type: t.literal("choose"),
		decision: t.int().nonnegative(),
		choice: t.string().min(1).max(80)
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), At = t.object({
	id: t.string(),
	kind: t.string(),
	hero: J.optional(),
	hero2: J.optional(),
	figure: Ot.optional(),
	villager: Dt.optional(),
	space: Y.optional(),
	slot: t.enum(N).optional(),
	item: X.optional()
}), jt = t.object({
	decision: t.int().nonnegative(),
	kind: t.string(),
	owners: t.array(t.string()),
	options: t.array(At)
}), Mt = t.object({
	uid: X,
	type: t.enum(re)
}), Nt = t.object({
	id: Dt,
	status: t.enum([
		"none",
		"board",
		"safe",
		"defeated"
	]),
	space: Y.nullable()
}), Pt = t.object({
	id: J,
	owner: t.string(),
	space: Y.nullable(),
	items: t.array(Mt),
	perks: t.array(t.object({
		uid: X,
		id: t.string()
	})),
	defeated: t.boolean()
}), Ft = t.object({
	k: t.string(),
	hero: J.optional(),
	hero2: J.optional(),
	figure: Ot.optional(),
	monster: t.enum(E).optional(),
	villager: Dt.optional(),
	space: Y.optional(),
	perk: t.enum(ue).optional(),
	item: X.optional(),
	slot: t.enum(N).optional(),
	n: t.int().optional(),
	n2: t.int().optional(),
	ok: t.boolean().optional()
}), It = t.object({
	num: t.int().min(0).max(6),
	faceUp: t.boolean()
}), Lt = t.record(t.enum(N), It), Rt = t.object({
	chosen: t.array(t.enum(E)),
	phase: t.enum([
		"hero",
		"monster",
		"done"
	]),
	terror: t.int().min(0).max(7),
	turn: t.object({
		owner: t.string(),
		hero: J,
		actionsLeft: t.int().nonnegative(),
		actionsMax: t.int().nonnegative()
	}),
	heroes: t.array(Pt),
	villagers: t.record(Dt, Nt),
	monsters: t.object({
		dracula: t.object({
			space: Y.nullable(),
			coffins: t.array(Y)
		}).nullable(),
		creature: t.object({
			space: Y.nullable(),
			boat: t.int().min(0).max(19)
		}).nullable(),
		fb: t.object({
			frank: Y.nullable(),
			bride: Y.nullable(),
			score: t.object({
				frank: t.int().nonnegative(),
				bride: t.int().nonnegative()
			}),
			flipped: t.object({
				frank: t.boolean(),
				bride: t.boolean()
			})
		}).nullable(),
		mummy: t.object({
			space: Y.nullable(),
			slots: Lt
		}).nullable(),
		wolfman: t.object({
			space: Y.nullable(),
			bottles: t.array(X.nullable()),
			cure: J.nullable()
		}).nullable(),
		invisibleman: t.object({
			space: Y.nullable(),
			spots: t.array(X.nullable())
		}).nullable()
	}),
	defeated: t.array(t.enum(E)),
	frenzy: t.enum(E),
	hunted: J.nullable(),
	soul: J.nullable(),
	spaceItems: t.array(t.object({
		space: Y,
		items: t.array(Mt)
	})),
	bagCount: t.int().nonnegative(),
	itemDiscardCount: t.int().nonnegative(),
	perkDeckCount: t.int().nonnegative(),
	perkDiscardCount: t.int().nonnegative(),
	monsterDeckCount: t.int().nonnegative(),
	monsterDiscardCount: t.int().nonnegative(),
	cardIndex: t.int().nonnegative().nullable(),
	lastRoll: t.object({
		figure: Ot,
		dice: t.array(t.int().min(0).max(5)),
		hits: t.int().nonnegative(),
		powers: t.int().nonnegative()
	}).nullable(),
	mummyMoves: t.int().nonnegative(),
	fbMoves: t.object({
		figure: t.enum(["frank", "bride"]),
		remaining: t.int().nonnegative()
	}).nullable(),
	skipMonster: t.boolean(),
	prompt: jt.nullable(),
	ending: t.object({
		win: t.boolean(),
		reason: t.enum([
			"triumph",
			"terror",
			"time"
		])
	}).nullable(),
	log: t.array(Ft)
}), zt = t.object({});
//#endregion
//#region src/game/rules.ts
function Bt(e, t, n) {
	let r = e.monsters, i = {
		config: { monsters: r },
		players: [...t],
		heroes: [],
		villagers: Object.fromEntries(ae.map((e) => [e, {
			id: e,
			status: "none",
			space: null
		}])),
		monsters: {
			dracula: {
				space: null,
				coffins: [...oe]
			},
			creature: {
				space: null,
				boat: 0
			},
			fb: {
				frank: null,
				bride: null,
				score: {
					frank: 0,
					bride: 0
				},
				flipped: {
					frank: !1,
					bride: !1
				}
			},
			mummy: {
				space: null,
				slots: {}
			},
			wolfman: {
				space: null,
				bottles: Array.from({ length: 6 }, () => null),
				cure: null
			},
			invisibleman: {
				space: null,
				spots: Array.from({ length: 5 }, () => null)
			}
		},
		defeated: [],
		frenzy: r.reduce((e, t) => D[e] <= D[t] ? e : t),
		hunted: null,
		soul: null,
		spaceItems: Object.fromEntries(y.map((e) => [e, []])),
		bag: [],
		itemDiscard: [],
		perkDeck: [],
		perkDiscard: [],
		monsterDeck: [],
		monsterDiscard: [],
		cardIndex: null,
		lastRoll: null,
		terror: t.length === 1 ? 3 : 0,
		turn: 0,
		phase: "hero",
		actionsLeft: 0,
		mummyMoves: 0,
		fbMoves: null,
		skipMonster: !1,
		queue: [],
		prompt: null,
		decision: 0,
		seed: n,
		cursor: 0,
		ending: null,
		log: []
	}, a = /* @__PURE__ */ new Map();
	i.bag = We(i, C.map((e) => {
		let t = a.get(e) ?? 0;
		return a.set(e, t + 1), _e(e, t);
	})), i.monsterDeck = We(i, Array.from({ length: 30 }, (e, t) => t));
	let o = /* @__PURE__ */ new Map();
	if (i.perkDeck = We(i, de.filter((e) => t.length !== 1 || e !== "specialDelivery" && e !== "investigation").map((e) => {
		let t = o.get(e) ?? 0;
		return o.set(e, t + 1), ve(e, t);
	})), r.includes("dracula") && (i.monsters.dracula.space = "crypt"), r.includes("creature") && (i.monsters.creature.space = "lagoon"), r.includes("frankenstein") && (i.monsters.fb.frank = "graveyard", i.monsters.fb.bride = "dungeon"), r.includes("mummy")) {
		i.monsters.mummy.space = "museum";
		let e = We(i, [
			1,
			2,
			3
		]), t = We(i, [
			4,
			5,
			6
		]), n = i.monsters.mummy.slots;
		n[1] = {
			num: t[0],
			faceUp: !0
		}, n[2] = {
			num: t[1],
			faceUp: !0
		}, n[3] = {
			num: t[2],
			faceUp: !0
		}, n[4] = {
			num: e[0],
			faceUp: !0
		}, n[5] = {
			num: e[1],
			faceUp: !0
		}, n[6] = {
			num: e[2],
			faceUp: !0
		}, n.D = {
			num: 0,
			faceUp: !1
		};
	}
	r.includes("wolfman") && (i.monsters.wolfman.space = "mansion"), r.includes("invisibleman") && (i.monsters.invisibleman.space = "inn");
	let s = We(i, w.filter((e) => t.length !== 1 || e !== "courier"));
	i.heroes = t.map((e, t) => {
		let n = s[t % s.length];
		return {
			id: n,
			owner: e,
			space: ie[n].start,
			items: [],
			perks: [],
			defeated: !1
		};
	});
	for (let e of i.heroes) Je(i, e.id);
	for (let e = 0; e < 12 && i.bag.length; e += 1) {
		let e = i.bag.pop();
		i.spaceItems[S[I(e)].space].push(e);
	}
	return i.actionsLeft = dt(i.heroes[0].id), i.heroes[0] && R(i, {
		k: "turnStart",
		hero: i.heroes[0].id
	}), { state: i };
}
function Vt(e, t, n) {
	if (e.ending) return { code: "games.horrified.invalidAction" };
	if (t.type === "choose") {
		let r = e.prompt;
		if (!r || !r.owners.includes(n.by) || t.decision !== r.decision) return { code: "games.horrified.invalidAction" };
		let i = r.options.find((e) => e.id === t.choice);
		if (!i) return { code: "games.horrified.invalidAction" };
		let a = structuredClone(e);
		return a.prompt = null, L(a, ...i.ops), ot(a), { state: a };
	}
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.prompt || !e.queue.length) return { code: "games.horrified.invalidAction" };
		let t = structuredClone(e);
		return mt(t, t.queue.shift()), ot(t), { state: t };
	}
	let r = structuredClone(e);
	return bt(r, t, n.by) || (ot(r), { state: r });
}
function Ht(e) {
	return e ? {
		decision: e.decision,
		kind: e.kind,
		owners: [...e.owners],
		options: e.options.map((e) => ({
			id: e.id,
			kind: e.kind,
			hero: e.hero,
			hero2: e.hero2,
			figure: e.figure,
			villager: e.villager,
			space: e.space,
			slot: e.slot,
			item: e.item
		}))
	} : null;
}
function Ut(e) {
	return Object.fromEntries(N.map((t) => [t, { ...e.monsters.mummy.slots[t] }]));
}
function Wt(e) {
	let t = be(e), n = (t) => e.config.monsters.includes(t) && !e.defeated.includes(t);
	return { public: {
		chosen: [...e.config.monsters],
		phase: e.phase,
		terror: e.terror,
		turn: {
			owner: t?.owner ?? "",
			hero: t?.id ?? e.heroes[0].id,
			actionsLeft: e.actionsLeft,
			actionsMax: t ? dt(t.id) : 0
		},
		heroes: e.heroes.map((e) => ({
			id: e.id,
			owner: e.owner,
			space: e.space,
			items: e.items.map((e) => ({
				uid: e,
				type: I(e)
			})),
			perks: e.perks.map((e) => ({
				uid: e,
				id: ye(e)
			})),
			defeated: e.defeated
		})),
		villagers: Object.fromEntries(ae.map((t) => [t, { ...e.villagers[t] }])),
		monsters: {
			dracula: n("dracula") ? {
				space: e.monsters.dracula.space,
				coffins: [...e.monsters.dracula.coffins]
			} : null,
			creature: n("creature") ? {
				space: e.monsters.creature.space,
				boat: e.monsters.creature.boat
			} : null,
			fb: n("frankenstein") ? {
				frank: e.monsters.fb.frank,
				bride: e.monsters.fb.bride,
				score: { ...e.monsters.fb.score },
				flipped: { ...e.monsters.fb.flipped }
			} : null,
			mummy: n("mummy") ? {
				space: e.monsters.mummy.space,
				slots: Ut(e)
			} : null,
			wolfman: n("wolfman") ? {
				space: e.monsters.wolfman.space,
				bottles: [...e.monsters.wolfman.bottles],
				cure: e.monsters.wolfman.cure
			} : null,
			invisibleman: n("invisibleman") ? {
				space: e.monsters.invisibleman.space,
				spots: [...e.monsters.invisibleman.spots]
			} : null
		},
		defeated: [...e.defeated],
		frenzy: e.frenzy,
		hunted: e.hunted,
		soul: e.soul,
		spaceItems: y.map((t) => ({
			space: t,
			items: e.spaceItems[t].map((e) => ({
				uid: e,
				type: I(e)
			}))
		})),
		bagCount: e.bag.length,
		itemDiscardCount: e.itemDiscard.length,
		perkDeckCount: e.perkDeck.length,
		perkDiscardCount: e.perkDiscard.length,
		monsterDeckCount: e.monsterDeck.length,
		monsterDiscardCount: e.monsterDiscard.length,
		cardIndex: e.cardIndex,
		lastRoll: e.lastRoll ? {
			...e.lastRoll,
			dice: [...e.lastRoll.dice]
		} : null,
		mummyMoves: e.mummyMoves,
		fbMoves: e.fbMoves ? { ...e.fbMoves } : null,
		skipMonster: e.skipMonster,
		prompt: Ht(e.prompt),
		ending: e.ending ? { ...e.ending } : null,
		log: e.log.map((e) => ({ ...e }))
	} };
}
var Gt = {
	meta: F,
	saveCompatibility: { version: "1" },
	schemas: {
		action: kt,
		config: Et,
		publicView: Rt,
		privateView: zt
	},
	setup: Bt,
	reduce: Vt,
	viewFor: Wt,
	status(e) {
		if (!e.ending) return { phase: e.phase };
		let t = [...e.players];
		return {
			phase: "done",
			winner: e.ending.win ? [...t] : [],
			ranking: t
		};
	},
	nextTickIn: (e) => !e.ending && !e.prompt && e.queue.length ? 420 : null
}, Kt = {
	red: "games.horrified.colorRed",
	blue: "games.horrified.colorBlue",
	yellow: "games.horrified.colorYellow"
}, qt = {
	cave: "games.horrified.spaceCave",
	camp: "games.horrified.spaceCamp",
	precinct: "games.horrified.spacePrecinct",
	inn: "games.horrified.spaceInn",
	barn: "games.horrified.spaceBarn",
	dungeon: "games.horrified.spaceDungeon",
	lagoon: "games.horrified.spaceLagoon",
	bridgeWest: "games.horrified.spaceBridgeWest",
	fountain: "games.horrified.spaceFountain",
	lamp: "games.horrified.spaceLamp",
	mansion: "games.horrified.spaceMansion",
	abbey: "games.horrified.spaceAbbey",
	crypt: "games.horrified.spaceCrypt",
	museum: "games.horrified.spaceMuseum",
	church: "games.horrified.spaceChurch",
	hospital: "games.horrified.spaceHospital",
	graveyard: "games.horrified.spaceGraveyard",
	laboratory: "games.horrified.spaceLaboratory",
	institute: "games.horrified.spaceInstitute",
	waterfront: "games.horrified.spaceWaterfront",
	docks: "games.horrified.spaceDocks",
	tower: "games.horrified.spaceTower",
	theatre: "games.horrified.spaceTheatre",
	river: "games.horrified.spaceRiver",
	bridgeEast: "games.horrified.spaceBridgeEast",
	shop: "games.horrified.spaceShop"
}, Jt = {
	beartrap: "games.horrified.itemBeartrap",
	rapier: "games.horrified.itemRapier",
	pistol: "games.horrified.itemPistol",
	silvercane: "games.horrified.itemSilvercane",
	shovel: "games.horrified.itemShovel",
	pitchfork: "games.horrified.itemPitchfork",
	dart: "games.horrified.itemDart",
	knife: "games.horrified.itemKnife",
	firepoker: "games.horrified.itemFirepoker",
	torch: "games.horrified.itemTorch",
	speargun: "games.horrified.itemSpeargun",
	rifle: "games.horrified.itemRifle",
	research: "games.horrified.itemResearch",
	anatomy: "games.horrified.itemAnatomy",
	kite: "games.horrified.itemKite",
	rotenone: "games.horrified.itemRotenone",
	centrifuge: "games.horrified.itemCentrifuge",
	fossil: "games.horrified.itemFossil",
	analysis: "games.horrified.itemAnalysis",
	telescope: "games.horrified.itemTelescope",
	experiment: "games.horrified.itemExperiment",
	searchlight: "games.horrified.itemSearchlight",
	camera: "games.horrified.itemCamera",
	cosmicray: "games.horrified.itemCosmicray",
	monocane: "games.horrified.itemMonocane",
	nebularium: "games.horrified.itemNebularium",
	tablet: "games.horrified.itemTablet",
	flower: "games.horrified.itemFlower",
	wine: "games.horrified.itemWine",
	garlic: "games.horrified.itemGarlic",
	charm: "games.horrified.itemCharm",
	tarot: "games.horrified.itemTarot",
	mirroredbox: "games.horrified.itemMirroredbox",
	crucifix: "games.horrified.itemCrucifix",
	wolfsbane: "games.horrified.itemWolfsbane",
	violin: "games.horrified.itemViolin",
	stake: "games.horrified.itemStake",
	scroll: "games.horrified.itemScroll",
	canopic: "games.horrified.itemCanopic"
}, Yt = {
	archaeologist: "games.horrified.heroArchaeologist",
	courier: "games.horrified.heroCourier",
	explorer: "games.horrified.heroExplorer",
	inspector: "games.horrified.heroInspector",
	mayor: "games.horrified.heroMayor",
	professor: "games.horrified.heroProfessor",
	scientist: "games.horrified.heroScientist"
}, Xt = {
	archaeologist: "games.horrified.heroArchaeologistShort",
	courier: "games.horrified.heroCourierShort",
	explorer: "games.horrified.heroExplorerShort",
	inspector: "games.horrified.heroInspectorShort",
	mayor: "games.horrified.heroMayorShort",
	professor: "games.horrified.heroProfessorShort",
	scientist: "games.horrified.heroScientistShort"
}, Zt = {
	fritz: "games.horrified.villagerFritz",
	maria: "games.horrified.villagerMaria",
	maleva: "games.horrified.villagerMaleva",
	pearson: "games.horrified.villagerPearson",
	wilbur: "games.horrified.villagerWilbur",
	renfield: "games.horrified.villagerRenfield",
	reed: "games.horrified.villagerReed",
	cranley: "games.horrified.villagerCranley",
	lucy: "games.horrified.villagerLucy",
	elizabeth: "games.horrified.villagerElizabeth"
}, Qt = {
	fritz: "games.horrified.villagerFritzShort",
	maria: "games.horrified.villagerMariaShort",
	maleva: "games.horrified.villagerMalevaShort",
	pearson: "games.horrified.villagerPearsonShort",
	wilbur: "games.horrified.villagerWilburShort",
	renfield: "games.horrified.villagerRenfieldShort",
	reed: "games.horrified.villagerReedShort",
	cranley: "games.horrified.villagerCranleyShort",
	lucy: "games.horrified.villagerLucyShort",
	elizabeth: "games.horrified.villagerElizabethShort"
}, $t = {
	dracula: "games.horrified.monsterDracula",
	mummy: "games.horrified.monsterMummy",
	frankenstein: "games.horrified.monsterFrankenstein",
	creature: "games.horrified.monsterCreature",
	wolfman: "games.horrified.monsterWolfman",
	invisibleman: "games.horrified.monsterInvisibleman"
}, en = {
	dracula: "games.horrified.monsterDracula",
	mummy: "games.horrified.monsterMummy",
	frank: "games.horrified.monsterFrankenstein",
	bride: "games.horrified.monsterBride",
	creature: "games.horrified.monsterCreature",
	wolfman: "games.horrified.monsterWolfman",
	invisibleman: "games.horrified.monsterInvisibleman"
}, tn = {
	dracula: "games.horrified.monsterDraculaShort",
	mummy: "games.horrified.monsterMummyShort",
	frank: "games.horrified.monsterFrankShort",
	bride: "games.horrified.monsterBrideShort",
	creature: "games.horrified.monsterCreatureShort",
	wolfman: "games.horrified.monsterWolfmanShort",
	invisibleman: "games.horrified.monsterInvisiblemanShort"
}, nn = {
	dracula: {
		advance: "games.horrified.monsterDraculaAdvance",
		defeat: "games.horrified.monsterDraculaDefeat",
		power: "games.horrified.monsterDraculaPower"
	},
	mummy: {
		advance: "games.horrified.monsterMummyAdvance",
		defeat: "games.horrified.monsterMummyDefeat",
		power: "games.horrified.monsterMummyPower"
	},
	frankenstein: {
		advance: "games.horrified.monsterFrankensteinAdvance",
		defeat: "games.horrified.monsterFrankensteinDefeat",
		power: "games.horrified.monsterFrankensteinPower"
	},
	creature: {
		advance: "games.horrified.monsterCreatureAdvance",
		defeat: "games.horrified.monsterCreatureDefeat",
		power: "games.horrified.monsterCreaturePower"
	},
	wolfman: {
		advance: "games.horrified.monsterWolfmanAdvance",
		defeat: "games.horrified.monsterWolfmanDefeat",
		power: "games.horrified.monsterWolfmanPower"
	},
	invisibleman: {
		advance: "games.horrified.monsterInvisiblemanAdvance",
		defeat: "games.horrified.monsterInvisiblemanDefeat",
		power: "games.horrified.monsterInvisiblemanPower"
	}
}, rn = {
	breakOfDawn: "games.horrified.perkBreakOfDawn",
	lateNight: "games.horrified.perkLateNight",
	detective: "games.horrified.perkDetective",
	taxiRide: "games.horrified.perkTaxiRide",
	crucifix: "games.horrified.perkCrucifix",
	rush: "games.horrified.perkRush",
	mobJustice: "games.horrified.perkMobJustice",
	overstock: "games.horrified.perkOverstock",
	specialDelivery: "games.horrified.perkSpecialDelivery",
	hurry: "games.horrified.perkHurry",
	investigation: "games.horrified.perkInvestigation",
	huntedPrey: "games.horrified.perkHuntedPrey",
	ancients: "games.horrified.perkAncients",
	showForce: "games.horrified.perkShowForce",
	repel: "games.horrified.perkRepel"
}, an = {
	turnStart: "games.horrified.logTurnStart",
	heroEnd: "games.horrified.logHeroEnd",
	heroMoved: "games.horrified.logHeroMoved",
	villagerMoved: "games.horrified.logVillagerMoved",
	pickup: "games.horrified.logPickup",
	itemGiven: "games.horrified.logItemGiven",
	cureGiven: "games.horrified.logCureGiven",
	advance: "games.horrified.logAdvance",
	defeat: "games.horrified.logDefeat",
	monsterDefeated: "games.horrified.logMonsterDefeated",
	coffinBroken: "games.horrified.logCoffinBroken",
	boatAdvance: "games.horrified.logBoatAdvance",
	boatBack: "games.horrified.logBoatBack",
	bottleFilled: "games.horrified.logBottleFilled",
	cureTaken: "games.horrified.logCureTaken",
	spotFilled: "games.horrified.logSpotFilled",
	mummyAdvance: "games.horrified.logMummyAdvance",
	scarabSlide: "games.horrified.logScarabSlide",
	scarabFlip: "games.horrified.logScarabFlip",
	scarabFlipped: "games.horrified.logScarabFlipped",
	mummyDone: "games.horrified.logMummyDone",
	fbFlipped: "games.horrified.logFbFlipped",
	fbMeet: "games.horrified.logFbMeet",
	fbDefeated: "games.horrified.logFbDefeated",
	itemPlaced: "games.horrified.logItemPlaced",
	terror: "games.horrified.logTerror",
	heroDefeated: "games.horrified.logHeroDefeated",
	villagerDefeated: "games.horrified.logVillagerDefeated",
	villagerPlaced: "games.horrified.logVillagerPlaced",
	rescued: "games.horrified.logRescued",
	revived: "games.horrified.logRevived",
	monsterCard: "games.horrified.logMonsterCard",
	monsterMoved: "games.horrified.logMonsterMoved",
	monsterSkipped: "games.horrified.logMonsterSkipped",
	monsterWillSkip: "games.horrified.logMonsterWillSkip",
	roll: "games.horrified.logRoll",
	hitHero: "games.horrified.logHitHero",
	hitVillager: "games.horrified.logHitVillager",
	defended: "games.horrified.logDefended",
	charmed: "games.horrified.logCharmed",
	hunted: "games.horrified.logHunted",
	soul: "games.horrified.logSoul",
	frenzyMoved: "games.horrified.logFrenzyMoved",
	perkGain: "games.horrified.logPerkGain",
	perkPlayed: "games.horrified.logPerkPlayed",
	actions: "games.horrified.logActions",
	thief: "games.horrified.logThief",
	eventIgnored: "games.horrified.logEventIgnored",
	win: "games.horrified.logWin",
	lose: "games.horrified.logLose",
	frenzy: "games.horrified.logFrenzy",
	moved: "games.horrified.logMoved",
	attack: "games.horrified.logAttack"
}, on = {
	attack: "games.horrified.promptAttack",
	defend: "games.horrified.promptDefend",
	thief: "games.horrified.promptThief",
	placeFigure: "games.horrified.promptPlaceFigure",
	figureDest: "games.horrified.promptFigureDest",
	moveFigure: "games.horrified.promptMoveFigure",
	heroDest: "games.horrified.promptHeroDest",
	moveHero: "games.horrified.promptMoveHero",
	carry: "games.horrified.promptCarry",
	hurry: "games.horrified.promptHurry",
	investigate: "games.horrified.promptInvestigate",
	investigateHero: "games.horrified.promptInvestigateHero",
	repel: "games.horrified.promptRepel",
	deliveryFrom: "games.horrified.promptDeliveryFrom",
	deliveryTo: "games.horrified.promptDeliveryTo",
	deliveryItem: "games.horrified.promptDeliveryItem",
	gaze: "games.horrified.promptGaze",
	perkMode: "games.horrified.promptPerkMode"
}, sn = {
	dracula: "#7b3fb5",
	mummy: "#b58b3f",
	frankenstein: "#4f7d4a",
	creature: "#2f7d8f",
	wolfman: "#8c5a2f",
	invisibleman: "#6b6f8a"
};
({ ...sn });
var Z = (e, t) => t(qt[e]), Q = (e, t) => t(Yt[e]), cn = (e, t) => t(Xt[e]), $ = (e, t) => t(Zt[e]), ln = (e, t) => t(Qt[e]), un = (e, t) => t($t[e]), dn = (e, t) => t(en[e]), fn = (e, t) => t(tn[e]), pn = (e, t) => t(Jt[I(e)]), mn = (e, t) => t(rn[ye(e)]), hn = (e, t) => t(Kt[e]), gn = (e) => S[e].color, _n = (e, t) => S[e].strength + +(t === "scientist"), vn = (e, t) => _n(I(e), t), yn = (e, t) => e.items.filter((e) => gn(e.type) === t), bn = (e, t) => t.reduce((t, n) => t + vn(n, e.id), 0);
function xn(e, t) {
	let n = [], r = e.monsters;
	return r.dracula?.space === t && n.push({
		figure: "dracula",
		monster: "dracula"
	}), r.creature?.space === t && n.push({
		figure: "creature",
		monster: "creature"
	}), r.fb?.frank === t && n.push({
		figure: "frank",
		monster: "frankenstein"
	}), r.fb?.bride === t && n.push({
		figure: "bride",
		monster: "frankenstein"
	}), r.mummy?.space === t && n.push({
		figure: "mummy",
		monster: "mummy"
	}), r.wolfman?.space === t && n.push({
		figure: "wolfman",
		monster: "wolfman"
	}), r.invisibleman?.space === t && n.push({
		figure: "invisibleman",
		monster: "invisibleman"
	}), n;
}
function Sn(e, t) {
	return e.heroes.filter((e) => !e.defeated && e.space === t);
}
function Cn(e, t) {
	return Object.values(e.villagers).filter((e) => e.status === "board" && e.space === t).map((e) => e.id);
}
function wn(e, t) {
	return e.spaceItems.find((e) => e.space === t)?.items.map((e) => e.uid) ?? [];
}
var Tn = (e) => e.D.num === 0 && [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6"
].every((t) => e[t].faceUp && e[t].num === Number(t));
function En(e, t) {
	let n = t.space;
	if (!n) return [];
	let r = e.monsters, i = [], a = yn(t, "red").map((e) => e.uid), o = yn(t, "blue").map((e) => e.uid), s = yn(t, "yellow").map((e) => e.uid), c = (e) => e.reduce((e, n) => e + vn(n, t.id), 0);
	if (r.dracula && (r.dracula.coffins.includes(n) && c(a) >= 6 ? i.push({
		mode: "advance",
		monster: "dracula",
		figure: "dracula",
		uids: a,
		single: !1,
		need: 6
	}) : r.dracula.space === n && r.dracula.coffins.length === 0 && c(s) >= 6 && i.push({
		mode: "defeat",
		monster: "dracula",
		figure: "dracula",
		uids: s,
		single: !1,
		need: 6
	})), r.creature && r.creature.boat < M && n === "camp") {
		let e = j.slice(r.creature.boat), n = t.items.filter((t) => e.includes(gn(t.type))).map((e) => e.uid);
		n.length && i.push({
			mode: "advance",
			monster: "creature",
			figure: "creature",
			uids: n,
			single: !0,
			need: 1
		});
	}
	if (r.creature && r.creature.space === n && r.creature.boat === M) {
		let e = yn(t, "red")[0], n = yn(t, "blue")[0], r = yn(t, "yellow")[0];
		e && n && r && i.push({
			mode: "defeat",
			monster: "creature",
			figure: "creature",
			uids: [
				e.uid,
				n.uid,
				r.uid
			],
			single: !1,
			need: 3
		});
	}
	if (r.fb && (n === r.fb.frank && s.length && i.push({
		mode: "advance",
		monster: "frankenstein",
		figure: "frank",
		uids: s,
		single: !0,
		need: 1
	}), n === r.fb.bride && o.length && i.push({
		mode: "advance",
		monster: "frankenstein",
		figure: "bride",
		uids: o,
		single: !0,
		need: 1
	})), r.mummy && (n === "museum" && s.length && i.push({
		mode: "advance",
		monster: "mummy",
		figure: "mummy",
		uids: s,
		single: !0,
		need: 1
	}), n === r.mummy.space && Tn(r.mummy.slots) && c(a) >= 9 && i.push({
		mode: "defeat",
		monster: "mummy",
		figure: "mummy",
		uids: a,
		single: !1,
		need: 9
	})), r.wolfman) {
		if (n === "laboratory") {
			let e = o.filter((e) => {
				let n = S[I(e)].strength;
				return r.wolfman.bottles.some((e, r) => e === null && (k[r] === n || k[r] === n + +(t.id === "scientist")));
			});
			e.length && i.push({
				mode: "advance",
				monster: "wolfman",
				figure: "wolfman",
				uids: e,
				single: !0,
				need: 1
			});
		}
		n === r.wolfman.space && r.wolfman.cure === t.id && c(a) >= 6 && i.push({
			mode: "defeat",
			monster: "wolfman",
			figure: "wolfman",
			uids: a,
			single: !1,
			need: 6
		});
	}
	if (r.invisibleman) {
		if (n === "precinct") {
			let e = t.items.filter((e) => O.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t)).map((e) => e.uid);
			e.length && i.push({
				mode: "advance",
				monster: "invisibleman",
				figure: "invisibleman",
				uids: e,
				single: !0,
				need: 1
			});
		}
		n === r.invisibleman.space && r.invisibleman.spots.every((e) => e !== null) && c(a) >= 9 && i.push({
			mode: "defeat",
			monster: "invisibleman",
			figure: "invisibleman",
			uids: a,
			single: !1,
			need: 9
		});
	}
	return i;
}
function Dn(e, t) {
	if (t.single) return t.uids.slice(0, 1);
	if (t.monster === "creature") return t.uids.slice(0, 3);
	let n = [...t.uids].sort((t, n) => vn(t, e.id) - vn(n, e.id)), r = [], i = 0;
	for (let a of n) {
		if (i >= t.need) break;
		r.push(a), i += vn(a, e.id);
	}
	return r;
}
function On(e, t, n) {
	if (t.single) return n.length === 1;
	if (t.monster === "creature") {
		let e = new Set(n.map((e) => gn(I(e))));
		return n.length === 3 && e.has("red") && e.has("blue") && e.has("yellow");
	}
	return bn(e, n) >= t.need;
}
function kn(e, t) {
	return !t || t.defeated || !t.space ? null : t.id === "explorer" ? Object.keys(b).filter((e) => !b[e].water) : t.id === "courier" ? e.heroes.filter((e) => !e.defeated && e.id !== t.id && e.space && e.space !== t.space).map((e) => e.space) : t.id === "inspector" ? Object.keys(b).filter((t) => !b[t].water && xn(e, t).length > 0) : null;
}
function An(e) {
	return x[e].filter((e) => !b[e].water);
}
function jn(e, t) {
	return [...fe(e, me).values()].filter((e) => e.dist > 0 && e.dist <= t).map((e) => e.to);
}
function Mn(e, t) {
	let n = e.hero ? Q(e.hero, t) : "", r = e.hero2 ? Q(e.hero2, t) : "";
	if (e.k === "hit") return e.villager ? t("games.horrified.logHitVillager", { villager: $(e.villager, t) }) : t("games.horrified.logHitHero", { hero: n });
	if (e.k === "win") return t("games.horrified.logWin");
	if (e.k === "lose") return t("games.horrified.logLose");
	let i = an[e.k];
	if (!i) return "";
	let a = {
		hero: n,
		hero2: r,
		n: e.n ?? 0,
		n2: e.n2 ?? 0
	};
	return e.figure && (a.figure = dn(e.figure, t)), e.monster && (a.monster = un(e.monster, t)), e.villager && (a.villager = $(e.villager, t)), e.space && (a.space = Z(e.space, t)), e.perk && (a.perk = t(rn[e.perk])), e.item && (a.item = pn(e.item, t)), t(i, a);
}
//#endregion
//#region src/game/monster-progress.tsx
function Nn({ broken: e = !1 }) {
	return /* @__PURE__ */ _("g", {
		className: "hf-coffin-mark",
		"data-broken": e,
		children: [
			/* @__PURE__ */ g("path", {
				className: "hf-coffin-body",
				d: "M-7-13H7L11-7 7 12H-7L-11-7Z"
			}),
			/* @__PURE__ */ g("path", {
				className: "hf-coffin-lid",
				d: "M-4-10H4L8-6 5 9H-5L-8-6ZM0-6V5M-3-2H3",
				fill: "#574032",
				stroke: "#dab485"
			}),
			/* @__PURE__ */ g("path", {
				className: "hf-coffin-crack",
				d: "m-9-3 8 1-2 4 6 2-3 6",
				fill: "none",
				stroke: "#f3e4cc",
				strokeWidth: "1.7"
			})
		]
	});
}
function Pn({ pub: e, id: t }) {
	let n = s(), { dracula: r, creature: i, wolfman: a, invisibleman: o, fb: c } = e.monsters;
	return t === "dracula" && r ? /* @__PURE__ */ g("ul", {
		className: "hf-coffins",
		children: oe.map((e) => {
			let t = !r.coffins.includes(e);
			return /* @__PURE__ */ _("li", {
				"data-broken": t,
				"aria-label": n(t ? "games.horrified.coffinBrokenAt" : "games.horrified.coffinAt", { space: Z(e, n) }),
				children: [
					/* @__PURE__ */ g("svg", {
						viewBox: "-14 -16 28 32",
						"aria-hidden": "true",
						children: /* @__PURE__ */ g(Nn, { broken: t })
					}),
					/* @__PURE__ */ g("span", { children: Z(e, n) }),
					t && /* @__PURE__ */ g("small", { children: n("games.horrified.coffinBroken") })
				]
			}, e);
		})
	}) : t === "creature" && i ? /* @__PURE__ */ _("div", {
		className: "hf-boat",
		children: [/* @__PURE__ */ g("ol", {
			"aria-label": n("games.horrified.boat", { n: i.boat }),
			children: [null, ...j].map((e, t) => {
				let r = t === 0 ? n("games.horrified.boatStart") : t === M ? n("games.horrified.boatEnd") : null, a = e ? n("games.horrified.boatStop", {
					n: t,
					color: hn(e, n)
				}) : r;
				return /* @__PURE__ */ _("li", {
					title: a ?? void 0,
					"aria-label": a ?? void 0,
					style: t >= 10 ? { "--hf-boat-col": 20 - t } : void 0,
					"aria-current": t === i.boat ? "step" : void 0,
					children: [/* @__PURE__ */ g("span", {
						className: "hf-boat-node",
						"aria-hidden": "true",
						children: /* @__PURE__ */ g("i", { className: e ? `hf-dot is-${e}` : "hf-boat-start" })
					}), r && /* @__PURE__ */ g("small", {
						className: "hf-boat-endpoint",
						"aria-hidden": "true",
						children: r
					})]
				}, t);
			})
		}), /* @__PURE__ */ _("svg", {
			className: "hf-boat-ship",
			"data-row": i.boat < 10 ? 0 : 1,
			style: {
				"--hf-boat-wide": `${(i.boat + .5) * 5}%`,
				"--hf-boat-narrow": `${(i.boat < 10 ? i.boat + .5 : 19.5 - i.boat) * 10}%`
			},
			viewBox: "-11 -11 22 22",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ g("path", {
				d: "M-9 4H9L6 8H-6ZM-1-9V2H7Z",
				fill: "currentColor"
			}), /* @__PURE__ */ g("path", {
				d: "M-1-9V4",
				stroke: "currentColor",
				strokeWidth: "1.5"
			})]
		})]
	}) : t === "wolfman" && a ? /* @__PURE__ */ g("ul", {
		className: "hf-progress-slots hf-vials",
		"aria-hidden": "true",
		children: k.map((e, t) => /* @__PURE__ */ g("li", {
			"data-filled": !!a.bottles[t],
			children: e
		}, t))
	}) : t === "invisibleman" && o ? /* @__PURE__ */ g("ul", {
		className: "hf-progress-slots",
		children: O.map((e, t) => /* @__PURE__ */ _("li", {
			"data-filled": !!o.spots[t],
			children: [
				/* @__PURE__ */ g("span", {
					"aria-hidden": "true",
					children: o.spots[t] ? "✓" : "◇"
				}),
				" ",
				Z(e, n)
			]
		}, e))
	}) : t === "frankenstein" && c ? /* @__PURE__ */ g("div", {
		className: "hf-humanity",
		children: ["frank", "bride"].map((e) => /* @__PURE__ */ g("meter", {
			min: 0,
			max: A[e],
			value: Math.min(c.score[e], A[e]),
			"aria-label": dn(e, n)
		}, e))
	}) : null;
}
//#endregion
//#region src/game/board.tsx
var Fn = {
	w: 1e3,
	h: 1003
}, In = 54, Ln = 7, Rn = 12, zn = 10, Bn = [
	54,
	112,
	169,
	226,
	283,
	341,
	398,
	456
], Vn = {
	"cave:camp": [[137, 237], [176, 230]],
	"cave:lagoon": [[114, 279], [141, 330]],
	"camp:bridgeWest": [
		[235, 268],
		[280, 301],
		[320, 336]
	],
	"precinct:fountain": [[421, 236], [445, 288]],
	"inn:fountain": [[534, 219], [509, 264]],
	"barn:theatre": [
		[705, 244],
		[684, 293],
		[678, 336]
	],
	"dungeon:tower": [[850, 248], [853, 309]],
	"lagoon:abbey": [
		[118, 425],
		[94, 453],
		[124, 496],
		[120, 547]
	],
	"bridgeWest:mansion": [
		[308, 408],
		[308, 469],
		[342, 494],
		[322, 526]
	],
	"mansion:abbey": [[208, 553], [157, 587]],
	"mansion:lamp": [[325, 555], [336, 610]],
	"lamp:museum": [[308, 715], [268, 743]],
	"lamp:church": [[394, 711], [421, 759]],
	"church:hospital": [[422, 852], [405, 890]],
	"docks:tower": [
		[859, 487],
		[846, 438],
		[853, 392]
	],
	"waterfront:docks": [[905, 656], [878, 592]],
	"waterfront:bridgeEast": [
		[848, 658],
		[789, 609],
		[739, 570]
	],
	"river:bridgeEast": [[535, 499], [609, 510]],
	"bridgeEast:shop": [[640, 590], [595, 612]]
}, Hn = y.flatMap((e) => x[e].filter((t) => y.indexOf(t) > y.indexOf(e)).map((t) => {
	let n = b[e], r = b[t], i = Vn[`${e}:${t}`] ?? Vn[`${t}:${e}`]?.slice().reverse() ?? [];
	return {
		from: e,
		to: t,
		points: [
			[n.x, n.y],
			...i,
			[r.x, r.y]
		].map((e) => e.join(",")).join(" "),
		water: n.water || r.water
	};
}));
function Un(e, t) {
	let n = e.currentTarget.querySelector(".hf-town-world")?.getScreenCTM();
	if (!n) return null;
	let r = new DOMPoint(e.clientX, e.clientY).matrixTransform(n.inverse()), i = null, a = Infinity;
	for (let e of t) {
		let t = b[e], n = r.x - t.x, o = r.y - t.y;
		if (Math.abs(n) > In || Math.abs(o - Ln) > In) continue;
		let s = n * n + o * o;
		s < a && (i = e, a = s);
	}
	return i;
}
function Wn(e, t) {
	return Math.hypot(t.clientX - e.x, t.clientY - e.y) > e.slop;
}
function Gn({ pub: e, members: t, eligible: n, walkSpaces: i, selected: a, onSpace: o }) {
	let c = s(), l = n ?? y, u = r(/* @__PURE__ */ new Set()), d = r(null), f = r(null);
	function p(e) {
		if (e.button !== 0) return;
		f.current = null, u.current.add(e.pointerId);
		let t = u.current.size === 1 && e.isPrimary ? Un(e, l) : null;
		d.current = t ? {
			id: e.pointerId,
			space: t,
			x: e.clientX,
			y: e.clientY,
			slop: e.pointerType === "touch" ? Rn : zn
		} : null;
	}
	function m(e) {
		let t = d.current;
		t?.id === e.pointerId && Wn(t, e) && (d.current = null);
	}
	function ee(e) {
		if (!u.current.delete(e.pointerId)) return;
		let t = d.current;
		d.current = null, t && t.id === e.pointerId && !Wn(t, e) && Un(e, l) === t.space && (f.current = t.space);
	}
	function _(e) {
		let t = f.current;
		f.current = null, e.detail !== 0 && t && l.includes(t) && (e.stopPropagation(), o(t));
	}
	function v(e) {
		u.current.delete(e.pointerId) && (d.current = null);
	}
	return /* @__PURE__ */ g("div", {
		className: "hf-board",
		role: "group",
		"aria-label": c("games.horrified.boardLabel"),
		onPointerDownCapture: p,
		onPointerMoveCapture: m,
		onPointerUpCapture: ee,
		onClickCapture: _,
		onPointerCancelCapture: v,
		onLostPointerCaptureCapture: (e) => {
			e.target instanceof SVGSVGElement && v(e);
		},
		children: /* @__PURE__ */ g(h, {
			sheetW: Fn.w,
			sheetH: Fn.h,
			fitKey: "horrified-town",
			clampToSheet: !0,
			readOnly: !0,
			children: /* @__PURE__ */ g(Kn, {
				pub: e,
				members: t,
				targets: n ?? i,
				selectable: l,
				selected: a,
				onSpace: o
			})
		})
	});
}
function Kn({ pub: e, members: t, targets: n, selectable: r, selected: i, onSpace: o }) {
	let l = s(), u = e.heroes.find((t) => t.id === e.turn.hero);
	return /* @__PURE__ */ _("g", {
		className: "hf-town-world",
		children: [
			/* @__PURE__ */ _("g", {
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ g("image", {
						className: "hf-town-art",
						href: ee("games/horrified/town-night.webp"),
						width: Fn.w,
						height: Fn.h,
						preserveAspectRatio: "none"
					}),
					/* @__PURE__ */ g("rect", {
						className: "hf-town-wash",
						width: Fn.w,
						height: Fn.h
					}),
					/* @__PURE__ */ g("rect", {
						className: "hf-town-frame",
						x: "6",
						y: "6",
						width: Fn.w - 12,
						height: Fn.h - 12
					}),
					Hn.map(({ from: e, to: t, points: n, water: r }) => /* @__PURE__ */ _("g", {
						className: "hf-town-route",
						"data-water": r,
						children: [/* @__PURE__ */ g("polyline", {
							points: n,
							className: "hf-route-under"
						}), /* @__PURE__ */ g("polyline", {
							points: n,
							className: "hf-route-line"
						})]
					}, `${e}-${t}`)),
					Bn.map((t, n) => /* @__PURE__ */ _("g", {
						transform: `translate(${t} 0)`,
						className: "hf-terror-cell",
						"data-current": n === e.terror,
						children: [/* @__PURE__ */ g("path", { d: "M-25 27H25L17 72 0 78-17 72Z" }), /* @__PURE__ */ g("text", {
							x: "0",
							y: "51",
							dominantBaseline: "central",
							textAnchor: "middle",
							children: n
						})]
					}, n)),
					/* @__PURE__ */ _("g", {
						className: "hf-terror-marker",
						style: { "--hf-terror-x": `${Bn[e.terror]}px` },
						children: [/* @__PURE__ */ g("path", {
							d: "M-29 22H29L20 75 0 83-20 75Z",
							className: "hf-terror-outline"
						}), /* @__PURE__ */ g("path", {
							d: "m0 78-7 12h14z",
							className: "hf-terror-pointer"
						})]
					})
				]
			}),
			y.map((e) => {
				let { x: t, y: a, water: s } = b[e], c = Z(e, l), u = r.includes(e), d = n.includes(e);
				return /* @__PURE__ */ _("g", {
					className: "hf-town-space",
					"data-space": e,
					"data-water": s,
					"data-target": d,
					role: u ? "button" : void 0,
					tabIndex: u ? 0 : void 0,
					"aria-label": u ? c : void 0,
					"aria-hidden": !u || void 0,
					onKeyDown: u ? (t) => {
						(t.key === "Enter" || t.key === " ") && (t.preventDefault(), o(e));
					} : void 0,
					children: [
						/* @__PURE__ */ g("title", { children: c }),
						/* @__PURE__ */ g("circle", {
							cx: t,
							cy: a,
							r: 23,
							className: "hf-town-node"
						}),
						/* @__PURE__ */ g("circle", {
							cx: t,
							cy: a,
							r: 4,
							className: "hf-town-node-center",
							pointerEvents: "none"
						}),
						(d || i === e) && /* @__PURE__ */ _("g", {
							pointerEvents: "none",
							children: [/* @__PURE__ */ g("ellipse", {
								cx: t,
								cy: a,
								rx: 37,
								ry: 34,
								className: "hf-destination-base"
							}), /* @__PURE__ */ g("ellipse", {
								cx: t,
								cy: a,
								rx: 37,
								ry: 34,
								className: d ? "hf-destination-line" : "hf-destination-selected"
							})]
						}),
						/* @__PURE__ */ g("foreignObject", {
							x: Math.max(5, Math.min(t - 84, Fn.w - 173)),
							y: a + 31,
							width: 168,
							height: 55,
							pointerEvents: "none",
							"aria-hidden": "true",
							children: /* @__PURE__ */ g("div", {
								className: "hf-town-name",
								children: c
							})
						})
					]
				}, e);
			}),
			/* @__PURE__ */ _("g", {
				"aria-hidden": "true",
				pointerEvents: "none",
				children: [y.map((t) => {
					let { x: n, y: r } = b[t], i = xn(e, t), a = Cn(e, t), o = wn(e, t).length;
					return /* @__PURE__ */ _("g", { children: [
						t === u?.space && !u.defeated && /* @__PURE__ */ g("circle", {
							cx: n,
							cy: r,
							r: 31,
							fill: "none",
							stroke: "#ffe2a5",
							strokeWidth: 3.2,
							className: "hf-turn-ring"
						}),
						e.monsters.dracula?.coffins.includes(t) && !e.defeated.includes("dracula") && /* @__PURE__ */ _("g", {
							transform: `translate(${n + 27} ${r - 25})`,
							pointerEvents: "none",
							children: [/* @__PURE__ */ g("circle", {
								r: "13",
								fill: "#322621",
								stroke: "#f0c797",
								strokeWidth: "2"
							}), /* @__PURE__ */ g("g", {
								transform: "scale(.72)",
								children: /* @__PURE__ */ g(Nn, {})
							})]
						}),
						i.map(({ figure: t, monster: a }, o) => {
							let s = n + (o - (i.length - 1) / 2) * 40, c = r - 34, u = e.frenzy === a;
							return /* @__PURE__ */ _("g", {
								transform: `translate(${s} ${c})`,
								pointerEvents: "none",
								children: [
									/* @__PURE__ */ g("path", {
										d: "M-18-16H18V6L0 21-18 6Z",
										fill: sn[a],
										stroke: "#ffe4b5",
										strokeWidth: 2.4
									}),
									/* @__PURE__ */ g("text", {
										y: 1,
										textAnchor: "middle",
										dominantBaseline: "central",
										fontSize: 11,
										fontWeight: 800,
										fill: "#fff",
										stroke: "#151a22",
										strokeWidth: "3",
										paintOrder: "stroke",
										children: fn(t, l)
									}),
									u && /* @__PURE__ */ _("g", {
										transform: "translate(13 -13)",
										children: [/* @__PURE__ */ g("circle", {
											r: 8,
											fill: "#c026d3",
											stroke: "#fff",
											strokeWidth: 1.6
										}), /* @__PURE__ */ g("text", {
											y: 1,
											textAnchor: "middle",
											dominantBaseline: "central",
											fontSize: 9,
											fontWeight: 900,
											fill: "#fff",
											children: "!"
										})]
									}),
									/* @__PURE__ */ g("title", { children: dn(t, l) })
								]
							}, t);
						}),
						a.slice(0, 4).map((e, t) => {
							let i = n + (t - (Math.min(a.length, 4) - 1) / 2) * 39, o = r + 20;
							return /* @__PURE__ */ _("g", {
								transform: `translate(${i} ${o})`,
								pointerEvents: "none",
								children: [
									/* @__PURE__ */ g("rect", {
										x: -18,
										y: -8,
										width: 36,
										height: 16,
										rx: 5,
										fill: "#f6ebc7",
										stroke: "#6d5a2f",
										strokeWidth: 1.4
									}),
									/* @__PURE__ */ g("text", {
										y: 1,
										textAnchor: "middle",
										dominantBaseline: "central",
										fontSize: 9,
										fontWeight: 700,
										fill: "#3c3116",
										children: ln(e, l)
									}),
									/* @__PURE__ */ g("title", { children: ln(e, l) })
								]
							}, e);
						}),
						a.length > 4 && /* @__PURE__ */ _("g", {
							transform: `translate(${n + 78} ${r + 20})`,
							pointerEvents: "none",
							children: [/* @__PURE__ */ g("rect", {
								x: -12,
								y: -8,
								width: 24,
								height: 16,
								rx: 5,
								fill: "#6d5a2f"
							}), /* @__PURE__ */ _("text", {
								y: 1,
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: 9,
								fontWeight: 800,
								fill: "#fff",
								children: ["+", a.length - 4]
							})]
						}),
						o > 0 && /* @__PURE__ */ _("g", {
							transform: `translate(${n + 37} ${r + 3})`,
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ g("circle", {
									r: 10,
									fill: "#f5c542",
									stroke: "#5c4712",
									strokeWidth: 1.6
								}),
								/* @__PURE__ */ g("text", {
									y: 1,
									textAnchor: "middle",
									dominantBaseline: "central",
									fontSize: 11,
									fontWeight: 900,
									fill: "#2a2109",
									children: o
								}),
								/* @__PURE__ */ g("title", { children: l("games.horrified.boardItems") })
							]
						})
					] }, t);
				}), e.heroes.map((n) => {
					if (!n.space || n.defeated) return null;
					let r = t.find((e) => e.rid === n.owner), i = c[(r?.colorIndex ?? 0) % c.length].hex, { x: o, y: s } = b[n.space], d = Sn(e, n.space), f = d.findIndex((e) => e.id === n.id) - (d.length - 1) / 2, p = `hf-av-${n.id}`;
					return /* @__PURE__ */ _("g", {
						className: "hf-hero-piece",
						pointerEvents: "none",
						style: { transform: `translate(${o + f * 36}px, ${s}px)` },
						children: [
							/* @__PURE__ */ g("circle", {
								r: 18,
								fill: i,
								stroke: n.id === u?.id ? "#ffdd9f" : "#101823",
								strokeWidth: 3
							}),
							/* @__PURE__ */ g("clipPath", {
								id: p,
								children: /* @__PURE__ */ g("circle", { r: 14 })
							}),
							/* @__PURE__ */ g("image", {
								href: a[(r?.avatar ?? 0) % a.length],
								x: -14,
								y: -14,
								width: 28,
								height: 28,
								clipPath: `url(#${p})`,
								preserveAspectRatio: "xMidYMid slice"
							}),
							/* @__PURE__ */ g("title", { children: Q(n.id, l) })
						]
					}, n.id);
				})]
			})
		]
	});
}
//#endregion
//#region src/game/panels.tsx
function qn(e) {
	let t = o((e) => e.locale);
	return (n) => {
		let r = e.find((e) => e.rid === n);
		return r ? m(r, t) : "";
	};
}
function Jn({ uid: e, hero: t, selected: n, onToggle: r }) {
	let i = s(), a = gn(I(e)), o = `${pn(e, i)} ${i("games.horrified.itemStrength", { n: vn(e, t.id) })}`;
	return /* @__PURE__ */ _("button", {
		type: "button",
		className: `hf-chip hf-item is-${a}`,
		"data-selected": !!n,
		disabled: !r,
		"aria-pressed": !!n,
		"aria-label": o,
		title: o,
		onClick: r,
		children: [
			/* @__PURE__ */ g("i", {
				className: `hf-dot is-${a}`,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ g("span", { children: pn(e, i) }),
			/* @__PURE__ */ g("b", { children: vn(e, t.id) })
		]
	});
}
function Yn({ title: e, children: t, hint: n, decision: r }) {
	return /* @__PURE__ */ _("section", {
		className: "hf-sheet-section",
		"data-decision": r || void 0,
		children: [/* @__PURE__ */ _("h3", { children: [e, n && /* @__PURE__ */ g("small", { children: n })] }), t]
	});
}
function Xn({ pub: e, space: t, open: n, onClose: r, myRid: a, members: o, send: c, busy: l }) {
	let u = s(), d = qn(o), f = e.heroes.find((e) => e.owner === a), [p, m] = i([]), [h, ee] = i([]), [te, ne] = i(f?.id ?? null), [y, x] = i(null), [re, S] = i([]), [C, w] = i(null), ie = `${t}:${e.turn.hero}:${e.phase}:${e.turn.owner}:${e.log.length}`, [ae, T] = i(ie);
	ae !== ie && (T(ie), m([]), ee([]), ne(f?.id ?? null), x(null), S([]), w(null));
	let E = e.phase === "hero" && e.turn.owner === a && !e.prompt && e.mummyMoves <= 0 && !e.fbMoves && !e.ending && !l, D = !!f && !f.defeated && f.space === t, oe = t ? wn(e, t) : [], O = t ? Sn(e, t) : [], k = t ? Cn(e, t) : [], A = t ? xn(e, t) : [], j = te ? O.find((e) => e.id === te) : void 0, M = j && y ? O.find((e) => e.id === y && e.id !== j.id) : void 0, N = (e, t, n = 12) => e.includes(t) ? e.filter((e) => e !== t) : e.length >= n ? e : [...e, t];
	if (!t) return null;
	let se = E && !!f && !f.defeated && f.space !== t && !!f.space && An(f.space).includes(t), ce = f && f.space && !f.defeated ? Cn(e, f.space) : [], P = f && D ? En(e, f) : [], le = D ? An(t).flatMap((t) => Cn(e, t)) : [], ue = C && f ? /* @__PURE__ */ _("div", {
		className: "hf-sheet-footer",
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			className: "hf-btn",
			onClick: () => w(null),
			children: u("games.horrified.cancel")
		}), /* @__PURE__ */ g("button", {
			type: "button",
			className: "hf-btn hf-primary",
			disabled: !E || !On(f, C.option, C.uids),
			onClick: () => {
				c({
					type: C.option.mode,
					monster: C.option.figure,
					uids: C.uids
				}), w(null);
			},
			children: u("games.horrified.done")
		})]
	}) : se ? /* @__PURE__ */ g("div", {
		className: "hf-sheet-footer",
		children: /* @__PURE__ */ g("button", {
			type: "button",
			className: "hf-btn hf-primary",
			onClick: () => {
				c({
					type: "move",
					to: t,
					villagers: h
				}), ee([]);
			},
			children: u("games.horrified.moveTo", { space: Z(t, u) })
		})
	}) : void 0;
	return /* @__PURE__ */ g(v, {
		open: n,
		onClose: r,
		label: Z(t, u),
		title: `${Z(t, u)}${b[t].water ? ` · ${u("games.horrified.waterTag")}` : ""}`,
		footer: ue,
		tall: !0,
		children: /* @__PURE__ */ _("div", {
			className: "hf-sheet",
			children: [
				P.length > 0 && f && /* @__PURE__ */ _(Yn, {
					title: u("games.horrified.spaceActions"),
					decision: !0,
					children: [/* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: P.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: `hf-btn ${e.mode === "defeat" ? "hf-danger" : "hf-primary"}`,
							onClick: () => w({
								option: e,
								uids: Dn(f, e)
							}),
							children: u(e.mode === "advance" ? "games.horrified.advanceButton" : "games.horrified.defeatButton", { monster: un(e.monster, u) })
						}, `${e.mode}-${e.figure}`))
					}), C && /* @__PURE__ */ _("div", {
						className: "hf-task-pick",
						children: [
							/* @__PURE__ */ g("p", {
								className: "hf-muted",
								children: C.option.single ? u("games.horrified.selectItemsHint") : u("games.horrified.strengthSum", { n: bn(f, C.uids) })
							}),
							/* @__PURE__ */ g("div", {
								className: "hf-chips",
								children: C.option.uids.map((e) => /* @__PURE__ */ g(Jn, {
									uid: e,
									hero: f,
									selected: C.uids.includes(e),
									onToggle: () => w((t) => t && {
										...t,
										uids: t.option.single ? t.uids.includes(e) ? [] : [e] : N(t.uids, e)
									})
								}, e))
							}),
							!C.option.single && /* @__PURE__ */ g("p", {
								className: `hf-strength${On(f, C.option, C.uids) ? "" : " is-short"}`,
								children: u("games.horrified.strengthNeed", { n: C.option.need })
							})
						]
					})]
				}),
				se && ce.length > 0 && /* @__PURE__ */ g(Yn, {
					title: u("games.horrified.moveTo", { space: Z(t, u) }),
					decision: !0,
					children: /* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: ce.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": h.includes(e),
							onClick: () => ee((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
							children: $(e, u)
						}, e))
					})
				}),
				oe.length > 0 && /* @__PURE__ */ _(Yn, {
					title: u("games.horrified.boardItems"),
					hint: E && D ? u("games.horrified.selectItemsHint") : void 0,
					children: [/* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: oe.map((t) => /* @__PURE__ */ g(Jn, {
							uid: t,
							hero: f ?? e.heroes[0],
							selected: p.includes(t),
							onToggle: E && D ? () => m((e) => N(e, t)) : void 0
						}, t))
					}), E && D && /* @__PURE__ */ g("button", {
						type: "button",
						className: "hf-btn hf-primary",
						disabled: !p.length,
						onClick: () => {
							c({
								type: "pickup",
								uids: p
							}), m([]);
						},
						children: u("games.horrified.pickupN", { n: p.length })
					})]
				}),
				/* @__PURE__ */ g(Yn, {
					title: u("games.horrified.personsHere"),
					children: O.length + k.length === 0 ? /* @__PURE__ */ g("p", {
						className: "hf-muted",
						children: u("games.horrified.noPersons")
					}) : /* @__PURE__ */ _("ul", {
						className: "hf-people",
						children: [O.map((e) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ _("span", {
							className: "hf-hero-tag",
							children: [Q(e.id, u), /* @__PURE__ */ g("small", { children: d(e.owner) })]
						}), e.perks.length > 0 && /* @__PURE__ */ _("small", {
							className: "hf-muted",
							children: [
								u("games.horrified.perksTitle"),
								" ",
								e.perks.length
							]
						})] }, e.id)), k.map((e) => /* @__PURE__ */ g("li", { children: /* @__PURE__ */ g("span", {
							className: "hf-villager-tag",
							children: $(e, u)
						}) }, e))]
					})
				}),
				/* @__PURE__ */ g(Yn, {
					title: u("games.horrified.monstersHere"),
					children: A.length === 0 ? /* @__PURE__ */ g("p", {
						className: "hf-muted",
						children: u("games.horrified.noMonsters")
					}) : /* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: A.map(({ figure: e, monster: t }) => /* @__PURE__ */ g("span", {
							className: "hf-monster-tag",
							style: { backgroundColor: sn[t] },
							children: dn(e, u)
						}, e))
					})
				}),
				E && D && (k.length > 0 || le.length > 0) && /* @__PURE__ */ _(Yn, {
					title: u("games.horrified.guideTitle"),
					children: [k.map((e) => An(t).length === 0 ? null : /* @__PURE__ */ _("div", {
						className: "hf-guide-row",
						children: [/* @__PURE__ */ g("span", { children: $(e, u) }), /* @__PURE__ */ g("div", {
							className: "hf-chips",
							children: An(t).map((t) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "hf-btn hf-small",
								onClick: () => c({
									type: "guide",
									villager: e,
									to: t
								}),
								children: u("games.horrified.guideTo", {
									villager: $(e, u),
									space: Z(t, u)
								})
							}, t))
						})]
					}, e)), le.map((e) => /* @__PURE__ */ _("div", {
						className: "hf-guide-row",
						children: [/* @__PURE__ */ g("span", { children: $(e, u) }), /* @__PURE__ */ g("div", {
							className: "hf-chips",
							children: /* @__PURE__ */ g("button", {
								type: "button",
								className: "hf-btn hf-small",
								onClick: () => c({
									type: "guide",
									villager: e,
									to: t
								}),
								children: u("games.horrified.guideTo", {
									villager: $(e, u),
									space: Z(t, u)
								})
							})
						})]
					}, e))]
				}),
				E && D && O.length > 1 && /* @__PURE__ */ _(Yn, {
					title: u("games.horrified.shareTitle"),
					children: [
						/* @__PURE__ */ g("div", {
							className: "hf-chips",
							children: O.map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "hf-btn hf-small",
								"data-selected": te === e.id,
								onClick: () => {
									ne(e.id), x(null), S([]);
								},
								children: u("games.horrified.shareFrom", { hero: Q(e.id, u) })
							}, e.id))
						}),
						j && /* @__PURE__ */ g("div", {
							className: "hf-chips",
							children: O.filter((e) => e.id !== j.id).map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "hf-btn hf-small",
								"data-selected": y === e.id,
								onClick: () => {
									x(y === e.id ? null : e.id), S([]);
								},
								children: u("games.horrified.shareTo", { hero: Q(e.id, u) })
							}, e.id))
						}),
						j && M && /* @__PURE__ */ _("div", {
							className: "hf-share",
							children: [/* @__PURE__ */ g("div", {
								className: "hf-chips",
								children: j.items.map((e) => /* @__PURE__ */ g(Jn, {
									uid: e.uid,
									hero: j,
									selected: re.includes(e.uid),
									onToggle: () => S((t) => N(t, e.uid))
								}, e.uid))
							}), /* @__PURE__ */ _("div", {
								className: "hf-row",
								children: [/* @__PURE__ */ g("button", {
									type: "button",
									className: "hf-btn hf-primary",
									disabled: !re.length,
									onClick: () => {
										c({
											type: "share",
											from: j.id,
											to: M.id,
											uids: re,
											cure: !1
										}), S([]);
									},
									children: u("games.horrified.shareTitle")
								}), e.monsters.wolfman?.cure === j.id && /* @__PURE__ */ g("button", {
									type: "button",
									className: "hf-btn",
									onClick: () => c({
										type: "share",
										from: j.id,
										to: M.id,
										uids: [],
										cure: !0
									}),
									children: u("games.horrified.giveCure")
								})]
							})]
						})
					]
				}),
				!E && /* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: u("games.horrified.waitingOther")
				})
			]
		})
	});
}
function Zn(e, t) {
	return e.kind === "defend" && e.item ? t("games.horrified.defendWith", { item: pn(e.item, t) }) : e.kind === "takeHit" ? t("games.horrified.takeHit") : e.kind === "stay" ? t("games.horrified.stay") : e.kind === "done" ? t("games.horrified.done") : e.kind === "carryConfirm" ? t("games.horrified.carryConfirm") : e.kind === "villagerOn" && e.villager ? `✓ ${$(e.villager, t)}` : e.kind === "villagerOff" && e.villager ? $(e.villager, t) : e.kind === "modePlace" ? t("games.horrified.modePlace") : e.kind === "modeMove" ? t("games.horrified.modeMove") : e.space ? Z(e.space, t) : e.hero ? Q(e.hero, t) : e.villager ? $(e.villager, t) : e.figure ? dn(e.figure, t) : e.item ? pn(e.item, t) : t("games.horrified.done");
}
function Qn({ pub: e, send: t, busy: n }) {
	let r = s(), i = e.prompt;
	if (!i) return null;
	let a = on[i.kind] ?? "games.horrified.promptTitle";
	return /* @__PURE__ */ g(v, {
		open: !0,
		label: r("games.horrified.promptTitle"),
		title: r(a),
		children: /* @__PURE__ */ g("div", {
			className: "hf-prompt",
			children: /* @__PURE__ */ g("div", {
				className: "hf-chips",
				children: i.options.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					className: "hf-btn hf-option",
					disabled: n,
					onClick: () => t({
						type: "choose",
						decision: i.decision,
						choice: e.id
					}),
					children: Zn(e, r)
				}, e.id))
			})
		})
	});
}
function $n({ pub: e, send: t, busy: n }) {
	let r = s(), [a, o] = i(null), c = e.monsters.mummy, l = e.mummyMoves, [u, d] = i(l);
	if (u !== l && (d(l), o(null)), !c || l <= 0) return null;
	let f = c.slots, p = (e) => {
		if (n) return;
		let r = f[e];
		if (a && r.num === 0 && se[a].includes(e)) {
			t({
				type: "mummySlide",
				from: a,
				to: e
			}), o(null);
			return;
		}
		if (r.num > 0 && !r.faceUp) {
			t({
				type: "mummyFlip",
				slot: e
			}), o(null);
			return;
		}
		r.num > 0 && r.faceUp && o(a === e ? null : e);
	};
	return /* @__PURE__ */ g(v, {
		open: !0,
		label: r("games.horrified.mummyPuzzle"),
		title: r("games.horrified.mummyPuzzle"),
		children: /* @__PURE__ */ _("div", {
			className: "hf-mummy",
			children: [
				/* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: r("games.horrified.mummyPending", { n: l })
				}),
				/* @__PURE__ */ _("svg", {
					viewBox: "0 0 100 100",
					className: "hf-mummy-board",
					role: "group",
					"aria-label": r("games.horrified.mummyPuzzle"),
					children: [N.flatMap((e) => se[e].map((t) => /* @__PURE__ */ g("line", {
						x1: ce[e].x,
						y1: ce[e].y,
						x2: ce[t].x,
						y2: ce[t].y,
						className: "hf-mummy-link"
					}, `${e}-${t}`))), N.map((e) => {
						let t = f[e], n = ce[e], i = t.num === 0, o = !!a && i && se[a].includes(e);
						return /* @__PURE__ */ _("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": i ? r("games.horrified.mummyInvalidTarget") : String(e),
							className: `hf-mummy-cell${a === e ? " is-picked" : ""}${o ? " is-target" : ""}${!t.faceUp && !i ? " is-back" : ""}`,
							onClick: () => p(e),
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), p(e));
							},
							children: [/* @__PURE__ */ g("rect", {
								x: n.x - 9,
								y: n.y - 9,
								width: 18,
								height: 18,
								rx: 3.5
							}), !i && /* @__PURE__ */ g("text", {
								x: n.x,
								y: n.y + 4,
								textAnchor: "middle",
								children: t.faceUp ? t.num : "?"
							})]
						}, e);
					})]
				}),
				/* @__PURE__ */ g("p", {
					className: "hf-hint",
					children: r("games.horrified.mummySlideHint")
				}),
				/* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: r("games.horrified.mummyFlipHint")
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: "hf-btn hf-primary",
					disabled: n,
					onClick: () => t({ type: "mummyDone" }),
					children: r("games.horrified.mummyDoneButton")
				})
			]
		})
	});
}
function er({ pub: e, send: t, busy: n }) {
	let r = s(), i = e.fbMoves, a = e.monsters.fb;
	if (!i || !a) return null;
	let o = i.figure === "frank" ? a.frank : a.bride;
	if (!o) return null;
	let c = jn(o, i.remaining);
	return /* @__PURE__ */ g(v, {
		open: !0,
		label: r("games.horrified.fbPending", {
			figure: dn(i.figure, r),
			n: i.remaining
		}),
		title: r("games.horrified.fbPending", {
			figure: dn(i.figure, r),
			n: i.remaining
		}),
		children: /* @__PURE__ */ _("div", {
			className: "hf-sheet",
			children: [
				/* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: r("games.horrified.fbPendingHint")
				}),
				/* @__PURE__ */ g("div", {
					className: "hf-chips",
					children: c.map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						className: "hf-btn",
						disabled: n,
						onClick: () => t({
							type: "fbMove",
							to: e
						}),
						children: Z(e, r)
					}, e))
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: "hf-btn hf-primary",
					disabled: n,
					onClick: () => t({ type: "fbDone" }),
					children: r("games.horrified.done")
				})
			]
		})
	});
}
function tr(e, t, n) {
	let r = e.monsters;
	return t === "dracula" && r.dracula ? n("games.horrified.coffins", { n: 4 - r.dracula.coffins.length }) : t === "creature" && r.creature ? n(r.creature.boat === M ? "games.horrified.boatLair" : "games.horrified.boat", { n: r.creature.boat }) : t === "frankenstein" && r.fb ? `${n("games.horrified.frankProgress", {
		n: r.fb.score.frank,
		target: A.frank
	})} · ${n("games.horrified.brideProgress", {
		n: r.fb.score.bride,
		target: A.bride
	})}` : t === "mummy" && r.mummy ? n(Tn(r.mummy.slots) ? "games.horrified.mummySolved" : "games.horrified.mummyUnsolved") : t === "wolfman" && r.wolfman ? n("games.horrified.bottles", { n: r.wolfman.bottles.filter(Boolean).length }) : t === "invisibleman" && r.invisibleman ? n("games.horrified.spots", { n: r.invisibleman.spots.filter(Boolean).length }) : "";
}
function nr({ pub: e, open: t, onClose: n }) {
	let r = s();
	return /* @__PURE__ */ g("div", {
		className: "hf-task-sheet",
		children: /* @__PURE__ */ g(v, {
			open: t,
			onClose: n,
			label: r("games.horrified.tasksTitle"),
			title: r("games.horrified.tasksTitle"),
			tall: !0,
			children: /* @__PURE__ */ g("div", {
				className: "hf-tasks",
				children: e.chosen.map((t) => {
					let n = nn[t], i = e.defeated.includes(t);
					return /* @__PURE__ */ _("article", {
						"data-monster": t,
						className: `hf-task${i ? " is-done" : ""}`,
						children: [
							/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("strong", { children: un(t, r) }), /* @__PURE__ */ _("div", {
								className: "hf-tags",
								children: [i && /* @__PURE__ */ g("span", {
									className: "hf-tag is-done",
									children: r("games.horrified.defeatedTag")
								}), e.frenzy === t && !i && /* @__PURE__ */ g("span", {
									className: "hf-tag is-frenzy",
									children: r("games.horrified.frenzyTag")
								})]
							})] }),
							/* @__PURE__ */ g("p", {
								className: "hf-task-progress",
								children: tr(e, t, r)
							}),
							/* @__PURE__ */ g(Pn, {
								pub: e,
								id: t
							}),
							/* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: r("games.horrified.taskDetails") }), /* @__PURE__ */ _("dl", { children: [
								/* @__PURE__ */ g("dt", { children: r("games.horrified.taskAdvance") }),
								/* @__PURE__ */ g("dd", { children: r(n.advance) }),
								/* @__PURE__ */ g("dt", { children: r("games.horrified.taskDefeat") }),
								/* @__PURE__ */ g("dd", { children: r(n.defeat) }),
								/* @__PURE__ */ g("dt", { children: r("games.horrified.taskPower") }),
								/* @__PURE__ */ g("dd", { children: r(n.power) })
							] })] })
						]
					}, t);
				})
			})
		})
	});
}
function rr({ pub: e, open: t, onClose: n }) {
	let r = s(), i = Object.values(e.villagers), a = i.filter((e) => e.status === "safe").length;
	return /* @__PURE__ */ g(v, {
		open: t,
		onClose: n,
		label: r("games.horrified.villagersTitle"),
		title: r("games.horrified.villagersTitle"),
		tall: !0,
		children: /* @__PURE__ */ _("div", {
			className: "hf-sheet",
			children: [/* @__PURE__ */ g("p", {
				className: "hf-muted",
				children: r("games.horrified.rescuedCount", { n: a })
			}), /* @__PURE__ */ g("ul", {
				className: "hf-villagers",
				children: i.map((e) => /* @__PURE__ */ _("li", {
					"data-status": e.status,
					children: [
						/* @__PURE__ */ g("strong", { children: $(e.id, r) }),
						/* @__PURE__ */ g("span", { children: e.status === "board" && e.space ? r("games.horrified.villagerAt", { space: Z(e.space, r) }) : e.status === "safe" ? r("games.horrified.villagerSafeStatus") : e.status === "defeated" ? r("games.horrified.villagerDefeatedStatus") : r("games.horrified.villagerNone") }),
						/* @__PURE__ */ g("small", { children: r("games.horrified.villagerSafe", { space: Z(T[e.id].safe, r) }) })
					]
				}, e.id))
			})]
		})
	});
}
function ir({ pub: e, myRid: t, canPlay: n, send: r, open: i, onClose: a }) {
	let o = s();
	return /* @__PURE__ */ g(v, {
		open: i,
		onClose: a,
		label: o("games.horrified.perksTitle"),
		title: o("games.horrified.perksTitle"),
		tall: !0,
		children: /* @__PURE__ */ g("div", {
			className: "hf-sheet",
			children: e.heroes.map((e) => /* @__PURE__ */ g(Yn, {
				title: `${Q(e.id, o)}${e.owner === t ? ` · ${o("games.horrified.youTag")}` : ""}`,
				children: e.perks.length === 0 ? /* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: o("games.horrified.perksEmpty")
				}) : /* @__PURE__ */ g("div", {
					className: "hf-perk-list",
					children: e.perks.map((i) => {
						let a = mn(i.uid, o), s = a.search(/[:：]/);
						return /* @__PURE__ */ _("article", {
							className: "hf-perk",
							children: [
								/* @__PURE__ */ g("strong", { children: s < 0 ? a : a.slice(0, s) }),
								s >= 0 && /* @__PURE__ */ g("p", { children: a.slice(s + 1).trim() }),
								e.owner === t && n && /* @__PURE__ */ g("button", {
									type: "button",
									className: "hf-btn hf-small hf-primary",
									onClick: () => r({
										type: "playPerk",
										uid: i.uid
									}),
									children: o("games.horrified.playPerk")
								})
							]
						}, i.uid);
					})
				})
			}, e.id))
		})
	});
}
function ar({ pub: e, hero: t, send: n, open: r, onClose: a, onPickOnMap: o, canPick: c = !0 }) {
	let l = s(), [u, d] = i(null), [f, p] = i([]), m = `${t?.id ?? ""}:${r}`, [h, ee] = i(m);
	if (h !== m && (ee(m), d(null), p([])), !t || t.defeated) return null;
	let te = l("games.horrified.specialButton", { hero: Q(t.id, l) });
	if (t.id === "archaeologist") {
		let i = t.space ? x[t.space].filter((t) => wn(e, t).length > 0) : [];
		return /* @__PURE__ */ g(v, {
			open: r,
			onClose: a,
			label: l("games.horrified.specialTitle"),
			title: te,
			children: /* @__PURE__ */ _("div", {
				className: "hf-sheet",
				children: [/* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: l("games.horrified.heroArchaeologistSpecial")
				}), i.length === 0 ? /* @__PURE__ */ g("p", {
					className: "hf-muted",
					children: l("games.horrified.noItems")
				}) : /* @__PURE__ */ g("div", {
					className: "hf-chips",
					children: i.map((t) => /* @__PURE__ */ _("button", {
						type: "button",
						className: "hf-btn",
						onClick: () => {
							n({
								type: "specialArchaeologist",
								space: t,
								uids: wn(e, t).slice(0, 12)
							}), a();
						},
						children: [
							Z(t, l),
							" · ",
							wn(e, t).length
						]
					}, t))
				})]
			})
		});
	}
	if (t.id === "professor") {
		let t = e.heroes.filter((e) => !e.defeated && e.space), i = Object.values(e.villagers).filter((e) => e.status === "board" && e.space), o = u ? u.kind === "hero" ? e.heroes.find((e) => e.id === u.id)?.space : e.villagers[u.id]?.space : null, s = o ? An(o) : [], c = u?.kind === "hero" && o ? Cn(e, o) : [];
		return /* @__PURE__ */ g(v, {
			open: r,
			onClose: a,
			label: l("games.horrified.specialTitle"),
			title: te,
			children: /* @__PURE__ */ _("div", {
				className: "hf-sheet",
				children: [
					/* @__PURE__ */ g("p", {
						className: "hf-muted",
						children: l("games.horrified.heroProfessorSpecial")
					}),
					/* @__PURE__ */ _("div", {
						className: "hf-chips",
						children: [t.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": u?.kind === "hero" && u.id === e.id,
							onClick: () => {
								d({
									kind: "hero",
									id: e.id
								}), p([]);
							},
							children: cn(e.id, l)
						}, e.id)), i.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": u?.kind === "villager" && u.id === e.id,
							onClick: () => {
								d({
									kind: "villager",
									id: e.id
								}), p([]);
							},
							children: $(e.id, l)
						}, e.id))]
					}),
					c.length > 0 && /* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: c.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-btn hf-small",
							"data-selected": f.includes(e),
							onClick: () => p((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]),
							children: $(e, l)
						}, e))
					}),
					u && /* @__PURE__ */ g("div", {
						className: "hf-chips",
						children: s.map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-btn hf-primary hf-small",
							onClick: () => {
								n(u.kind === "hero" ? {
									type: "specialProfessor",
									hero: u.id,
									to: e,
									villagers: f
								} : {
									type: "specialProfessor",
									villager: u.id,
									to: e,
									villagers: []
								}), d(null), p([]);
							},
							children: Z(e, l)
						}, e))
					})
				]
			})
		});
	}
	return /* @__PURE__ */ g(v, {
		open: r,
		onClose: a,
		label: l("games.horrified.specialTitle"),
		title: te,
		children: /* @__PURE__ */ _("div", {
			className: "hf-sheet",
			children: [/* @__PURE__ */ g("p", {
				className: "hf-muted",
				children: l(t.id === "courier" ? "games.horrified.heroCourierSpecial" : t.id === "explorer" ? "games.horrified.heroExplorerSpecial" : "games.horrified.heroInspectorSpecial")
			}), /* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-btn hf-primary",
				disabled: !c,
				onClick: () => {
					o(), a();
				},
				children: l("games.horrified.chooseTargetSpace")
			})]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
var or = {
	triumph: "games.horrified.endingWin",
	terror: "games.horrified.endingTerror",
	time: "games.horrified.endingTime"
};
function sr(e) {
	return /* @__PURE__ */ g(cr, { ...e });
}
function cr({ public: e, members: t, myRid: h, send: ee }) {
	l();
	let v = s(), te = o((e) => e.locale), ne = u(), y = e, [b, x] = i(null), [re, S] = i(null), [C, w] = i(null), [ie, ae] = i(!1), [T, E] = i(!1), D = r(null), [oe, O] = i(h);
	oe !== h && (O(h), x(null), S(null), w(null), ae(!1), E(!1));
	let k = t.find((e) => e.rid === h), A = y.heroes.find((e) => e.owner === h), j = y.heroes.find((e) => e.id === y.turn.hero), M = y.phase === "hero" && y.turn.owner === h && !y.prompt && y.mummyMoves <= 0 && !y.fbMoves && !y.ending && !T, N = y.prompt && y.prompt.owners.includes(h) ? y.prompt : null, se = y.turn.owner === h && !y.ending, ce = A ? kn(y, A) : null, P = ce ? [...new Set(ce)] : [], le = C === A?.id && M, ue = M && A?.space && !A.defeated ? An(A.space) : [], de = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? m(n, te) : "";
	}, fe = c[(k?.colorIndex ?? 0) % c.length], pe = Object.values(y.villagers).filter((e) => e.status === "board" && e.space), me = Object.values(y.villagers).filter((e) => e.status === "safe").length;
	function F(e) {
		T || (E(!0), ee(e), D.current && window.clearTimeout(D.current), D.current = window.setTimeout(() => E(!1), 1200));
	}
	let he = r(y.log.length);
	n(() => {
		y.log.length !== he.current && (he.current = y.log.length, E(!1), D.current && window.clearTimeout(D.current));
	}, [y.log.length]), n(() => () => {
		D.current && window.clearTimeout(D.current);
	}, []);
	let ge = y.prompt ? `prompt:${y.prompt.decision}` : y.mummyMoves > 0 ? `mummy:${y.mummyMoves}` : y.fbMoves ? `fb:${y.fbMoves.figure}:${y.fbMoves.remaining}` : "", [_e, I] = i(ge);
	_e !== ge && (I(ge), ge && (x(null), S(null), w(null)));
	let ve = `${y.turn.owner}:${y.turn.hero}`, [ye, L] = i(ve);
	ye !== ve && (L(ve), w(null));
	let R = y.log.reduce((e, t, n) => t.k === "roll" ? n : e, -1), be = r(R), [z, xe] = i(0);
	n(() => {
		R <= be.current || (be.current = R, xe((e) => e + 1));
	}, [R]), n(() => {
		if (!z) return;
		let e = window.setTimeout(() => xe(0), 3600);
		return () => window.clearTimeout(e);
	}, [z]);
	function Se(e) {
		A && C === A.id && (A.id === "explorer" ? F({
			type: "specialExplorer",
			to: e
		}) : A.id === "courier" ? F({
			type: "specialCourier",
			to: e
		}) : A.id === "inspector" && F({
			type: "specialInspector",
			to: e
		}), w(null));
	}
	let Ce = y.ending, we = "info", B, V;
	Ce ? (we = "done", B = v(or[Ce.reason]), V = v("games.horrified.endingTitle")) : y.prompt ? (B = v(on[y.prompt.kind] ?? "games.horrified.promptTitle"), N ? (we = "accent", V = v("games.horrified.yourTurn")) : V = v("games.horrified.promptWaiting", { name: de(y.prompt.owners[0] ?? y.turn.owner) })) : se && y.mummyMoves > 0 ? (we = "accent", B = v("games.horrified.mummyPending", { n: y.mummyMoves }), V = A ? Q(A.id, v) : void 0) : se && y.fbMoves ? (we = "accent", B = v("games.horrified.fbPending", {
		figure: dn(y.fbMoves.figure, v),
		n: y.fbMoves.remaining
	}), V = A ? Q(A.id, v) : void 0) : y.phase === "monster" ? (we = "warn", B = v("games.horrified.phaseMonster"), V = v("games.horrified.monsterDeck", { n: y.monsterDeckCount })) : y.turn.owner === h ? (we = "accent", B = v("games.horrified.yourTurn"), V = `${j ? Q(j.id, v) : ""} · ${v("games.horrified.actionsLeft", {
		left: y.turn.actionsLeft,
		max: y.turn.actionsMax
	})}`) : (B = v("games.horrified.waitingTurn", { name: de(y.turn.owner) }), V = v("games.horrified.phaseHero"));
	let H = /* @__PURE__ */ _("div", {
		className: "hf-tools",
		children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-tool",
				disabled: !M || !A || A.defeated,
				onClick: () => S("special"),
				children: v("games.horrified.specialTitle")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("tasks"),
				children: [v("games.horrified.openTasks"), y.frenzy && !y.defeated.includes(y.frenzy) && /* @__PURE__ */ g("b", {
					className: "hf-tool-mark",
					"aria-label": v("games.horrified.frenzyTag"),
					children: "!"
				})]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("villagers"),
				children: v("games.horrified.villagersTitle")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => S("perks"),
				children: [v("games.horrified.perksTitle"), !!A?.perks.length && /* @__PURE__ */ g("b", {
					className: "hf-tool-mark",
					children: A.perks.length
				})]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "hf-tool",
				onClick: () => ae(!0),
				children: v("games.horrified.openLog")
			})
		]
	});
	return /* @__PURE__ */ _("div", {
		className: "hf-shell",
		children: [
			/* @__PURE__ */ g(f, {
				adaptive: !0,
				scroll: !1,
				className: `hf-game${ne ? " hf-reduced" : ""}`,
				actionsHeight: "hf-dock-slot",
				banner: /* @__PURE__ */ _("div", {
					className: "hf-top",
					children: [/* @__PURE__ */ _("div", {
						className: "hf-phase",
						"data-tone": we,
						children: [/* @__PURE__ */ _("div", {
							className: "hf-phase-copy",
							children: [/* @__PURE__ */ g("strong", { children: le ? v("games.horrified.chooseTargetSpace") : B }), V && /* @__PURE__ */ g("span", { children: V })]
						}), /* @__PURE__ */ g("span", {
							className: "hf-terror",
							"aria-live": "polite",
							children: v("games.horrified.terror", { n: y.terror })
						})]
					}), /* @__PURE__ */ g(p, {
						members: t,
						myRid: h,
						variant: "mini",
						adaptive: !0,
						scroll: !0,
						dimmed: (e) => y.heroes.find((t) => t.owner === e)?.defeated ?? !1,
						status: (e) => {
							let t = y.heroes.find((t) => t.owner === e);
							return t ? /* @__PURE__ */ _("span", {
								className: "hf-seat-status",
								children: [cn(t.id, v), t.defeated ? ` · ${v("games.horrified.heroDefeated")}` : ""]
							}) : null;
						}
					})]
				}),
				overlay: z > 0 && y.lastRoll ? /* @__PURE__ */ _("div", {
					className: "hf-float",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ _("div", {
							className: "hf-float-head",
							children: [/* @__PURE__ */ g("span", { children: v("games.horrified.lastRollTitle") }), /* @__PURE__ */ g("span", { children: dn(y.lastRoll.figure, v) })]
						}),
						/* @__PURE__ */ g("div", {
							className: "hf-dice",
							"aria-hidden": "true",
							children: y.lastRoll.dice.map((e, t) => /* @__PURE__ */ g("i", {
								className: `hf-die is-${e < 3 ? "hit" : e === 5 ? "power" : "blank"}`,
								children: e < 3 ? "✕" : e === 5 ? "★" : "·"
							}, t))
						}),
						/* @__PURE__ */ _("div", {
							className: "hf-float-sum",
							children: [/* @__PURE__ */ g("span", { children: v("games.horrified.rollHits", { n: y.lastRoll.hits }) }), /* @__PURE__ */ g("span", { children: v("games.horrified.rollPowers", { n: y.lastRoll.powers }) })]
						})
					]
				}) : void 0,
				actions: /* @__PURE__ */ _("div", {
					className: "hf-dock",
					children: [/* @__PURE__ */ _("div", {
						className: "hf-dock-main",
						children: [
							/* @__PURE__ */ _("div", {
								className: "hf-who",
								children: [
									k && /* @__PURE__ */ g("span", {
										className: "hf-ava",
										style: { backgroundColor: fe.hex },
										children: /* @__PURE__ */ g("img", {
											src: a[k.avatar % a.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ _("span", {
										className: "hf-who-text",
										children: [/* @__PURE__ */ g("strong", { children: k ? m(k, te) : "" }), /* @__PURE__ */ _("span", { children: [A ? Q(A.id, v) : "", A?.defeated ? ` · ${v("games.horrified.heroDefeated")}` : ""] })]
									}),
									A && y.turn.hero === A.id && /* @__PURE__ */ g("span", {
										className: "hf-pips",
										role: "img",
										"aria-label": v("games.horrified.actionsLeft", {
											left: y.turn.actionsLeft,
											max: y.turn.actionsMax
										}),
										children: Array.from({ length: y.turn.actionsMax }, (e, t) => /* @__PURE__ */ g("i", {
											"aria-hidden": "true",
											"data-on": t < y.turn.actionsLeft
										}, t))
									})
								]
							}),
							/* @__PURE__ */ g("div", {
								className: "hf-hand",
								"aria-label": v("games.horrified.handTitle"),
								children: A?.items.length ? A.items.map((e) => {
									let t = gn(e.type), n = v("games.horrified.itemAria", {
										item: pn(e.uid, v),
										color: hn(t, v),
										n: vn(e.uid, A.id)
									});
									return /* @__PURE__ */ _("span", {
										className: `hf-hand-item is-${t}`,
										role: "img",
										"aria-label": n,
										title: n,
										children: [
											/* @__PURE__ */ g("i", { "aria-hidden": "true" }),
											/* @__PURE__ */ g("span", { children: pn(e.uid, v) }),
											/* @__PURE__ */ g("b", { children: vn(e.uid, A.id) })
										]
									}, e.uid);
								}) : /* @__PURE__ */ g("span", {
									className: "hf-muted",
									children: v("games.horrified.handEmpty")
								})
							}),
							/* @__PURE__ */ g("button", {
								type: "button",
								className: "hf-tool hf-end",
								disabled: !M,
								onClick: () => F({ type: "endTurn" }),
								children: v("games.horrified.endTurn")
							})
						]
					}), le ? /* @__PURE__ */ _("div", {
						className: "hf-tools hf-dest",
						children: [/* @__PURE__ */ g("span", {
							className: "hf-dest-hint",
							children: v("games.horrified.chooseTargetSpace")
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: "hf-tool",
							onClick: () => w(null),
							children: v("games.horrified.cancel")
						})]
					}) : H]
				}),
				children: /* @__PURE__ */ _("div", {
					className: "hf-center",
					children: [/* @__PURE__ */ g("div", {
						className: "hf-board-wrap",
						children: /* @__PURE__ */ g(Gn, {
							pub: y,
							members: t,
							eligible: le ? P : null,
							walkSpaces: ue,
							selected: b,
							onSpace: (e) => le ? Se(e) : x(e)
						})
					}), /* @__PURE__ */ _("aside", {
						className: "hf-rail",
						"aria-label": v("games.horrified.tasksTitle"),
						children: [
							/* @__PURE__ */ g("p", {
								className: "hf-rail-title",
								children: v("games.horrified.tasksTitle")
							}),
							/* @__PURE__ */ g("ul", {
								className: "hf-rail-list",
								children: y.chosen.map((e) => {
									let t = y.defeated.includes(e);
									return /* @__PURE__ */ _("li", {
										"data-monster": e,
										className: `hf-rail-task${t ? " is-done" : ""}`,
										children: [
											/* @__PURE__ */ _("div", {
												className: "hf-rail-head",
												children: [/* @__PURE__ */ g("strong", { children: un(e, v) }), t ? /* @__PURE__ */ g("span", {
													className: "hf-tag is-done",
													children: v("games.horrified.defeatedTag")
												}) : y.frenzy === e ? /* @__PURE__ */ g("span", {
													className: "hf-tag is-frenzy",
													children: v("games.horrified.frenzyTag")
												}) : null]
											}),
											/* @__PURE__ */ g("p", {
												className: "hf-task-progress",
												children: tr(y, e, v)
											}),
											/* @__PURE__ */ g(Pn, {
												pub: y,
												id: e
											}),
											!t && (e === "dracula" || e === "creature") && /* @__PURE__ */ g("p", {
												className: "hf-rail-instruction",
												children: v(nn[e].advance)
											})
										]
									}, e);
								})
							}),
							/* @__PURE__ */ _("div", {
								className: "hf-rail-villagers",
								children: [/* @__PURE__ */ _("p", {
									className: "hf-rail-title",
									children: [v("games.horrified.villagersTitle"), /* @__PURE__ */ g("span", { children: v("games.horrified.rescuedCount", { n: me }) })]
								}), pe.length > 0 ? /* @__PURE__ */ g("ul", { children: pe.map((e) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g("strong", { children: $(e.id, v) }), /* @__PURE__ */ g("span", { children: v("games.horrified.villagerAt", { space: Z(e.space, v) }) })] }, e.id)) }) : /* @__PURE__ */ g("p", {
									className: "hf-rail-empty",
									children: v("games.horrified.railNoVillagers")
								})]
							}),
							/* @__PURE__ */ _("div", {
								className: "hf-rail-decks",
								children: [/* @__PURE__ */ g("span", { children: v("games.horrified.monsterDeck", { n: y.monsterDeckCount }) }), /* @__PURE__ */ g("span", { children: v("games.horrified.bag", { n: y.bagCount }) })]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ g(Xn, {
				pub: y,
				space: b,
				open: !!b,
				onClose: () => x(null),
				myRid: h,
				members: t,
				send: F,
				busy: T
			}),
			N && /* @__PURE__ */ g(Qn, {
				pub: y,
				send: F,
				busy: T
			}),
			se && y.mummyMoves > 0 && /* @__PURE__ */ g($n, {
				pub: y,
				send: F,
				busy: T
			}),
			se && y.fbMoves && /* @__PURE__ */ g(er, {
				pub: y,
				send: F,
				busy: T
			}),
			/* @__PURE__ */ g(nr, {
				pub: y,
				open: re === "tasks",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ g(rr, {
				pub: y,
				open: re === "villagers",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ g(ir, {
				pub: y,
				myRid: h,
				canPlay: y.phase === "hero" && !y.prompt && !y.ending && !T,
				send: F,
				open: re === "perks",
				onClose: () => S(null)
			}),
			/* @__PURE__ */ g(ar, {
				pub: y,
				hero: A,
				send: F,
				open: re === "special",
				onClose: () => S(null),
				canPick: P.length > 0,
				onPickOnMap: () => A && w(A.id)
			}),
			ie && /* @__PURE__ */ g("div", {
				className: "hf-log",
				children: /* @__PURE__ */ g(d, {
					log: y.log,
					line: (e) => Mn(e, v),
					onClose: () => ae(!1)
				})
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var lr = j.length;
function ur(e) {
	let t = /* @__PURE__ */ new Map([[e, 0]]), n = [e];
	for (; n.length;) {
		let e = n.shift();
		for (let r of x[e]) b[r].water || t.has(r) || (t.set(r, t.get(e) + 1), n.push(r));
	}
	return t;
}
function dr(e, t) {
	if (e === t) return null;
	let n = /* @__PURE__ */ new Map(), r = [e];
	for (; r.length;) {
		let i = r.shift();
		for (let a of x[i]) if (!(b[a].water || a === e || n.has(a))) {
			if (n.set(a, i), a === t) {
				let r = t;
				for (; n.get(r) !== e;) {
					let e = n.get(r);
					if (!e) return null;
					r = e;
				}
				return r;
			}
			r.push(a);
		}
	}
	return null;
}
function fr(e) {
	return e.D.num === 0 && N.every((t) => t === "D" || e[t].faceUp && e[t].num === Number(t));
}
function pr(e, t, n) {
	let r = +(e.id === "scientist"), i = e.items.filter((e) => S[e.type].color === t).sort((e, t) => S[t.type].strength - S[e.type].strength), a = [], o = 0;
	for (let e of i) {
		if (o >= n) break;
		a.push(e.uid), o += S[e.type].strength + r;
	}
	return o >= n ? a : null;
}
function mr(e, t) {
	return e.items.filter((e) => S[e.type].color === t);
}
function hr(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	if (r.dracula && r.dracula.space === n && !r.dracula.coffins.length) {
		let e = pr(t, "yellow", 6);
		if (e) return {
			type: "defeat",
			monster: "dracula",
			uids: e
		};
	}
	if (r.creature && r.creature.space === n && r.creature.boat === lr) {
		let [e] = mr(t, "red"), [n] = mr(t, "blue"), [r] = mr(t, "yellow");
		if (e && n && r) return {
			type: "defeat",
			monster: "creature",
			uids: [
				e.uid,
				n.uid,
				r.uid
			]
		};
	}
	if (r.mummy && r.mummy.space === n && fr(r.mummy.slots)) {
		let e = pr(t, "red", 9);
		if (e) return {
			type: "defeat",
			monster: "mummy",
			uids: e
		};
	}
	if (r.wolfman && r.wolfman.space === n && r.wolfman.cure === t.id) {
		let e = pr(t, "red", 6);
		if (e) return {
			type: "defeat",
			monster: "wolfman",
			uids: e
		};
	}
	if (r.invisibleman && r.invisibleman.space === n && r.invisibleman.spots.every((e) => e !== null)) {
		let e = pr(t, "red", 9);
		if (e) return {
			type: "defeat",
			monster: "invisibleman",
			uids: e
		};
	}
	return null;
}
function gr(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	if (r.dracula && r.dracula.coffins.includes(n)) {
		let e = pr(t, "red", 6);
		if (e) return {
			type: "advance",
			monster: "dracula",
			uids: e
		};
	}
	if (r.creature && n === "camp" && r.creature.boat < lr) {
		let e = null;
		for (let n of t.items) {
			let t = S[n.type].color;
			for (let i = r.creature.boat + 1; i <= lr; i++) if (j[i - 1] === t) {
				(!e || i > e.next) && (e = {
					uid: n.uid,
					next: i
				});
				break;
			}
		}
		if (e) return {
			type: "advance",
			monster: "creature",
			uids: [e.uid]
		};
	}
	if (r.fb) {
		if (r.fb.frank === n) {
			let [e] = mr(t, "yellow");
			if (e) return {
				type: "advance",
				monster: "frank",
				uids: [e.uid]
			};
		}
		if (r.fb.bride === n) {
			let [e] = mr(t, "blue");
			if (e) return {
				type: "advance",
				monster: "bride",
				uids: [e.uid]
			};
		}
	}
	if (r.mummy && n === "museum") {
		let [e] = mr(t, "yellow");
		if (e) return {
			type: "advance",
			monster: "mummy",
			uids: [e.uid]
		};
	}
	if (r.wolfman && n === "laboratory") {
		let e = +(t.id === "scientist"), n = mr(t, "blue").find((t) => {
			let n = S[t.type].strength;
			return r.wolfman.bottles.some((t, r) => t === null && (k[r] === n || e > 0 && k[r] === n + e));
		});
		if (n) return {
			type: "advance",
			monster: "wolfman",
			uids: [n.uid]
		};
	}
	if (r.invisibleman && n === "precinct") {
		let e = t.items.find((e) => O.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t));
		if (e) return {
			type: "advance",
			monster: "invisibleman",
			uids: [e.uid]
		};
	}
	return null;
}
function _r(e, t) {
	let n = t.space, r = e.monsters;
	if (!n) return null;
	let i = [], a = (e) => mr(t, e).length > 0;
	r.dracula && (r.dracula.coffins.length && a("red") ? i.push(...r.dracula.coffins) : !r.dracula.coffins.length && a("yellow") && i.push(r.dracula.space ?? "crypt")), r.creature && (t.items.length && r.creature.boat < lr ? i.push("camp") : r.creature.boat === lr && i.push(r.creature.space ?? "lagoon")), r.fb && (a("yellow") && r.fb.frank && i.push(r.fb.frank), a("blue") && r.fb.bride && i.push(r.fb.bride)), r.mummy && (a("yellow") ? i.push("museum") : a("red") && fr(r.mummy.slots) && i.push(r.mummy.space ?? "museum")), r.wolfman && (a("blue") ? i.push("laboratory") : a("red") && r.wolfman.cure === t.id && i.push(r.wolfman.space ?? "mansion")), r.invisibleman && (t.items.some((e) => O.some((t, n) => r.invisibleman.spots[n] === null && S[e.type].space === t)) ? i.push("precinct") : a("red") && r.invisibleman.spots.every((e) => e !== null) && i.push(r.invisibleman.space ?? "inn"));
	let o = ur(n), s = i.filter((e) => o.has(e));
	if (s.length) return s.sort((e, t) => (o.get(e) ?? 0) - (o.get(t) ?? 0)), s[0];
	let c = e.spaceItems.filter((e) => e.items.length && o.has(e.space));
	if (c.length) return c.sort((e, t) => (o.get(e.space) ?? 0) - (o.get(t.space) ?? 0)), c[0].space;
	let l = [];
	r.dracula?.space && l.push(r.dracula.space), r.creature?.space && l.push(r.creature.space), r.fb?.frank && l.push(r.fb.frank), r.fb?.bride && l.push(r.fb.bride), r.mummy?.space && l.push(r.mummy.space), r.wolfman?.space && l.push(r.wolfman.space), r.invisibleman?.space && l.push(r.invisibleman.space);
	let u = l.filter((e) => o.has(e));
	return u.length ? (u.sort((e, t) => (o.get(e) ?? 0) - (o.get(t) ?? 0)), u[0]) : null;
}
function vr(e) {
	let t = e.monsters.mummy;
	if (!t) return { type: "mummyDone" };
	let n = t.slots;
	for (let e of N) {
		let t = n[e];
		if (!(t.num <= 0 || !t.faceUp)) {
			for (let r of se[e]) if (n[r].num === 0 && t.num === Number(r)) return {
				type: "mummySlide",
				from: e,
				to: r
			};
		}
	}
	for (let e of N) if (n[e].num > 0 && !n[e].faceUp) return {
		type: "mummyFlip",
		slot: e
	};
	return { type: "mummyDone" };
}
function yr(e) {
	let t = e.fbMoves;
	if (!t) return { type: "fbDone" };
	let n = e.monsters.fb;
	if (!n) return { type: "fbDone" };
	let r = t.figure === "frank" ? n.frank : n.bride, i = t.figure === "frank" ? n.bride : n.frank;
	if (!r || !i || r === i) return { type: "fbDone" };
	let a = ur(r).get(i);
	if (a !== void 0 && a <= t.remaining) return {
		type: "fbMove",
		to: i
	};
	let o = dr(r, i);
	return o ? {
		type: "fbMove",
		to: o
	} : { type: "fbDone" };
}
function br(e) {
	let t = e.prompt;
	if (!t) return null;
	let n = t.options;
	if (!n.length) return null;
	let r = (e) => ({
		type: "choose",
		decision: t.decision,
		choice: e.id
	}), i = (e) => n.find((t) => !e || t.kind === e) ?? n[0];
	switch (t.kind) {
		case "defend": {
			let e = n.filter((e) => e.kind === "defend" && e.item);
			e.sort((e, t) => {
				let n = e.item.slice(0, e.item.indexOf("#")), r = t.item.slice(0, t.item.indexOf("#"));
				return S[n].strength - S[r].strength;
			});
			let t = e[0];
			return r(t ?? i("takeHit"));
		}
		case "attack":
		case "gaze": return r(n.find((e) => e.hero) ?? n[0]);
		case "thief": {
			let t = (t) => t ? e.spaceItems.find((e) => e.space === t)?.items.length ?? 0 : 0;
			return r([...n].sort((e, n) => t(e.space) - t(n.space))[0]);
		}
		case "heroDest":
		case "investigate":
		case "investigateHero":
		case "hurry": return r(i("space"));
		case "carry": return r(i("carryConfirm"));
		case "figureDest":
		case "repel": return r(i("stay"));
		case "moveFigure":
		case "moveHero":
		case "placeFigure":
		case "deliveryFrom":
		case "deliveryTo":
		case "deliveryItem": return r(n[0]);
		case "perkMode": return r(i("modeMove"));
		default: return r(n[0]);
	}
}
var xr = (e, t) => {
	let n = e.public;
	if (n.ending || n.phase === "done") return null;
	if (n.prompt) {
		if (!n.prompt.owners.includes(t.rid) || n.turn.owner !== t.rid) return null;
		let e = br(n);
		return e ? { action: e } : null;
	}
	if (n.turn.owner !== t.rid) return null;
	let r = n.heroes.find((e) => e.id === n.turn.hero);
	if (!r || r.defeated) return null;
	if (n.mummyMoves > 0) return { action: vr(n) };
	if (n.fbMoves) return { action: yr(n) };
	if (n.phase !== "hero") return null;
	let i = r.space;
	if (!i) return null;
	let a = (e) => r.perks.find((t) => t.id === e);
	if (n.turn.actionsLeft <= 1) {
		let e = a("lateNight");
		if (e) return { action: {
			type: "playPerk",
			uid: e.uid
		} };
	}
	let o = a("breakOfDawn");
	if (o && n.monsterDeckCount > 0) return { action: {
		type: "playPerk",
		uid: o.uid
	} };
	if (n.turn.actionsLeft <= 0) return { action: { type: "endTurn" } };
	let s = hr(n, r);
	if (s) return { action: s };
	let c = gr(n, r);
	if (c) return { action: c };
	let l = n.spaceItems.find((e) => e.space === i);
	if (l?.items.length) return { action: {
		type: "pickup",
		uids: l.items.slice(0, 12).map((e) => e.uid)
	} };
	let u = _r(n, r);
	if (u && u !== i) {
		let e = dr(i, u);
		if (e) return { action: {
			type: "move",
			to: e,
			villagers: Object.values(n.villagers).filter((e) => e.status === "board" && e.space === i).map((e) => e.id)
		} };
	}
	return { action: { type: "endTurn" } };
}, Sr = {
	triumph: "games.horrified.endingWin",
	terror: "games.horrified.endingTerror",
	time: "games.horrified.endingTime"
};
function Cr({ public: e, members: t, onPlayAgain: n, onBackToLobby: r }) {
	let i = s(), o = e, l = !!o.ending?.win, u = o.ending?.reason ?? (l ? "triumph" : "terror"), d = Object.values(o.villagers).filter((e) => e.status === "safe").length, p = Object.values(o.villagers).filter((e) => e.status === "defeated").length, m = (e) => t.find((t) => t.rid === e)?.name ?? e, h = n ?? r;
	return /* @__PURE__ */ g("div", {
		className: `hf-over ${l ? "is-win" : "is-loss"}`,
		children: /* @__PURE__ */ g(f, {
			adaptive: !0,
			scroll: !1,
			className: "hf-over-screen",
			banner: /* @__PURE__ */ _("header", {
				className: "hf-over-heading",
				children: [
					/* @__PURE__ */ g("p", {
						className: "hf-over-kicker",
						children: i("games.horrified.name")
					}),
					/* @__PURE__ */ g("h1", {
						className: "hf-over-title",
						children: i(l ? "games.horrified.overWin" : "games.horrified.overLoss")
					}),
					/* @__PURE__ */ g("p", {
						className: "hf-over-reason",
						children: i(Sr[u])
					})
				]
			}),
			actionsHeight: "hf-over-action-height",
			actions: h ? /* @__PURE__ */ _("div", {
				className: "hf-over-actions safe-b",
				children: [n && /* @__PURE__ */ g("button", {
					type: "button",
					className: "hf-over-btn is-primary",
					onClick: n,
					children: i("session.result.playAgain")
				}), r && /* @__PURE__ */ g("button", {
					type: "button",
					className: "hf-over-btn",
					onClick: r,
					children: i("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ g("p", {
				className: "hf-over-wait safe-b",
				children: i("session.result.waitHost")
			}),
			children: /* @__PURE__ */ _("div", {
				className: "hf-over-body",
				children: [
					/* @__PURE__ */ _("ul", {
						className: "hf-over-stats",
						children: [
							/* @__PURE__ */ _("li", { children: [/* @__PURE__ */ _("span", {
								className: "hf-over-stat-value",
								children: [
									o.defeated.length,
									" / ",
									o.chosen.length
								]
							}), /* @__PURE__ */ g("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overMonsters")
							})] }),
							/* @__PURE__ */ _("li", { children: [/* @__PURE__ */ _("span", {
								className: "hf-over-stat-value",
								children: [d, " / 10"]
							}), /* @__PURE__ */ g("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overRescued")
							})] }),
							/* @__PURE__ */ _("li", { children: [/* @__PURE__ */ _("span", {
								className: "hf-over-stat-value",
								children: [o.terror, " / 7"]
							}), /* @__PURE__ */ g("span", {
								className: "hf-over-stat-label",
								children: i("games.horrified.overTerror")
							})] })
						]
					}),
					/* @__PURE__ */ g("ul", {
						className: "hf-over-monsters",
						children: o.chosen.map((e) => /* @__PURE__ */ _("li", {
							className: o.defeated.includes(e) ? "is-cleared" : "",
							children: [/* @__PURE__ */ g("span", {
								className: "hf-over-monster-name",
								children: i($t[e])
							}), o.defeated.includes(e) && /* @__PURE__ */ g("span", {
								className: "hf-over-monster-tag",
								children: i("games.horrified.defeatedTag")
							})]
						}, e))
					}),
					p > 0 && /* @__PURE__ */ g("p", {
						className: "hf-over-note",
						children: i("games.horrified.overVillagersLost", { n: p })
					}),
					/* @__PURE__ */ g("ul", {
						className: "hf-over-members",
						children: t.map((e) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g("span", {
							className: "hf-over-avatar",
							style: { background: c[e.colorIndex % c.length].hex },
							children: /* @__PURE__ */ g("img", {
								src: a[e.avatar % a.length],
								alt: "",
								draggable: !1
							})
						}), /* @__PURE__ */ g("span", {
							className: "hf-over-name",
							children: m(e.rid)
						})] }, e.rid))
					})
				]
			})
		})
	});
}
//#endregion
//#region src/game/options.tsx
var wr = {
	dracula: "#7b3fb5",
	mummy: "#b58b3f",
	frankenstein: "#4f7d4a",
	creature: "#2f7d8f",
	wolfman: "#8c5a2f",
	invisibleman: "#6b6f8a"
};
function Tr({ value: e, onChange: t }) {
	let n = s(), r = Et.catch({ monsters: ["creature", "dracula"] }).parse(e), i = r.monsters.length, a = (e) => {
		t({ monsters: r.monsters.includes(e) ? r.monsters.filter((t) => t !== e) : [...r.monsters, e] });
	};
	return /* @__PURE__ */ _("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ g(ne, {
				title: n("games.horrified.monstersChosen"),
				count: n("games.horrified.optionsCount", { n: i }),
				columns: 3,
				children: E.map((e) => /* @__PURE__ */ g(te, {
					name: "horrified-monster",
					value: e,
					checked: r.monsters.includes(e),
					disabled: !r.monsters.includes(e) && i >= 4,
					accent: wr[e],
					label: n($t[e]),
					onChange: () => a(e)
				}, e))
			}),
			/* @__PURE__ */ g("p", {
				className: "text-xs leading-snug text-ink/65",
				children: n("games.horrified.optionsHint")
			}),
			i === 0 && /* @__PURE__ */ g("p", {
				className: "text-xs font-bold text-rose-700",
				children: n("games.horrified.optionsInvalid")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var Er = {
	definition: Gt,
	View: sr,
	bot: xr,
	OverView: Cr,
	Options: Tr,
	locales: {
		zh: {
			name: "夺命惊魂",
			desc: "合作对抗德古拉、科学怪人等经典怪物，在恐惧吞噬全城之前完成并击败所有怪物",
			rules: "目标:\n你们扮演同城的民间英雄，在恐惧吞噬全城之前完成所有被选中怪物的任务，并把它们逐一击败。所选怪物全部被击败时，你们立即获胜。\n恐惧值表示全城的不安程度。每有一名英雄或村民被击败，恐惧值上升一点；恐惧值到达七点时，你们立即失败。\n怪物牌堆耗尽后，若还需要翻开一张怪物卡，你们立即失败。\n准备:\n· 将版图展开。本局可以选择一到四只怪物；第一次游戏推荐选择黑湖妖潭与德古拉。\n· 每名玩家随机获得一张英雄徽章，把自己的英雄棋子放在徽章标示的起始地点。\n· 将六十张物品卡洗混，正面朝下组成物品袋。从物品袋中抽出十二张物品，逐一放到各自卡面印制的出现地点；之后抽出的物品同样放到印制地点。\n· 将三十张怪物卡洗混，正面朝下组成怪物牌堆；将二十张特殊牌洗混，组成特殊牌堆，并给每名玩家发一张正面朝上的特殊牌。\n· 按照所选怪物的配置放好棋子与配件。德古拉放在墓穴，四具棺材分别放在墓穴、地牢、墓地与洞穴；黑湖妖潭放在咸水湖，船放在怪物垫上的起点；科学怪人放在墓地，其新娘放在地牢；木乃伊放在博物馆，并按怪物任务说明摆好圣甲虫谜题；狼人放在豪宅，解药放在怪物垫右侧；隐形人放在旅店。\n· 恐惧标记放在零位。单人游戏时，恐惧标记改为放在三点位，并从特殊牌堆中移除特殊投递与调查两张牌。\n· 由第一位入座的玩家开始行动，之后按入座顺序轮流进行回合。\n回合:\n每名玩家的回合分为英雄阶段与怪物阶段，依次进行。\n英雄阶段中，当前玩家按照英雄徽章所示的行动数执行行动。每次移动、引导、拾取、分享、推进任务、击败怪物或使用特殊行动，各消耗一个行动。\n任何玩家都可以在英雄阶段随时打出自己持有的特殊牌，打出特殊牌不消耗行动。\n当前玩家结束英雄阶段后，进入怪物阶段。\n怪物阶段依次翻开一张怪物卡，结算卡上的物品、事件与怪物行动，然后轮到下一名玩家。\n英雄行动:\n· 移动：把英雄移到相邻的陆地点。英雄可以把当前地点任意数量的村民一起带到目的地。由特殊牌或特殊行动产生的移动同样遵循移动规则，可以带走同地点的村民。\n· 引导：把与英雄同一地点的一名村民移到相邻的陆地点，或者把相邻地点的一名村民移到英雄所在地点。\n· 拾取：拿取当前地点任意数量的物品。\n· 分享：当前地点任意两名英雄可以互相转交任意数量的物品，不必涉及当前英雄；持有解药的英雄也可以把解药交给同地点的其他英雄。分享消耗一个行动。\n· 推进任务：按照怪物任务的要求，在指定地点使用物品。被使用的物品放入物品弃牌堆。\n· 击败怪物：按照怪物任务的要求，在怪物所在地点使用物品。被使用的物品放入物品弃牌堆。\n· 特殊行动：按照英雄徽章上的说明执行。特殊行动同样消耗一个行动；科学家的能力持续生效，不消耗行动。\n水地点包括咸水湖、河流与码头岸边。英雄与村民不能进入水地点；只有黑湖妖潭可以进入水地点。\n物品:\n物品分为红、蓝、黄三色，卡面数字表示物品的强度。科学家使用物品时，物品的强度增加一点。\n抽取物品时，把物品放在卡面印制的出现地点。物品袋为空时，把物品弃牌堆洗混，作为新的物品袋。\n英雄被怪物命中时，可以弃掉一张物品抵消这次命中；如果没有物品可以弃，或者选择不弃物品，英雄被击败。\n村民:\n十名村民各自有一个安全地点。村民因事件出现在其出场地点。\n村民到达安全地点时立即获救，并从棋盘移出；当前玩家抽取一张特殊牌。\n村民被怪物命中时立即被击败，恐惧值上升一点。村民没有物品，无法抵消命中。\n英雄被击败:\n英雄被击败时，把英雄棋子移出棋盘，恐惧值上升一点。\n被击败的玩家在自己的下一个回合开始时，把英雄放回医院，并以完整的行动数继续游戏。英雄保留全部物品与特殊牌。\n怪物阶段:\n怪物卡分为物品、事件与怪物行动三段，按顺序结算。\n· 物品：按卡面所示数量抽取物品，逐一放到其印制的出现地点。\n· 事件：按卡面说明执行。事件涉及的怪物不在本局或已被击败时，忽略该事件。\n· 怪物行动：按卡面从左到右逐个结算。每个怪物符号让对应怪物朝最近的人物移动，最多移动卡面所示的步数，走到人物所在的地点即停止；然后该怪物攻击一个目标。被攻击的英雄可以弃一张物品抵消命中；命中无法抵消时英雄被击败。村民被命中时立即被击败。怪物同时有英雄与村民可选时，优先攻击英雄；距离相同且目标不止一个时，由当前玩家在掷骰前选择目标。\n· 骰子每颗有三个命中面、两个空白面和一个力量面。每个命中造成一次命中，每个力量触发一次该怪物的力量。\n· 狂暴符号让持有狂暴标记的怪物再执行一次行动。开局时狂暴标记放在狂暴顺序最低的在场怪物上；事件要求移交时，交给狂暴顺序更高的下一只在场怪物。\n怪物任务:\n德古拉:\n· 任务：在有棺材的地点使用任意数量的红色物品，总强度达到六点，砸碎该地点的棺材。\n· 击败：四具棺材全部砸碎后，在德古拉所在地点使用任意数量的黄色物品，总强度达到六点。\n· 力量：黑暗魅惑。把当前玩家的英雄移到德古拉所在地点。\n黑湖妖潭:\n· 任务：在营地使用一张任意颜色的物品，把船推进到下一处该颜色的标记。船道共有十九站，第十九站为巢穴；巢穴标记为蓝色，因此推进到巢穴的物品必须是蓝色。\n· 击败：船停在巢穴后，在黑湖妖潭所在地点使用红、蓝、黄物品各一张。\n· 力量：把船向起点后退一站。\n科学怪人与新娘:\n· 任务：在科学怪人所在地点使用一张黄色物品，增加科学怪人的人性进度；在新娘所在地点使用一张蓝色物品，增加新娘的人性进度。进度增加量等于物品强度，随后可以让该怪物移动至多等同于进度增加量的步数。科学怪人的目标为十一点，新娘的目标为八点；达到目标时，该怪物的转盘翻面。\n· 击败：两只怪物的转盘都翻面后，只要它们位于同一地点，就立即被击败，不需要执行击败行动。\n· 相遇：两只怪物在转盘全部翻面前进入同一地点时，恐惧值上升一点，然后把科学怪人放回墓地，把新娘放回地牢。\n· 力量：新娘朝科学怪人移动一步。\n木乃伊:\n· 谜题：圣甲虫谜题有六个编号位与一个中央空位。开局时，编号一到三的圣甲虫随机放在左侧三个位置，编号四到六的圣甲虫随机放在右侧三个位置，全部正面朝上。\n· 任务：在博物馆使用一张黄色物品，获得等同于物品强度的移动次数。一次移动可以把一只正面朝上的圣甲虫滑到相邻空位，或者把一只反面朝上的圣甲虫翻回正面。\n· 击败：六只圣甲虫全部正面朝上，并且编号一到六各自位于对应编号的位置，中央空位为空；此后在木乃伊所在地点使用任意数量的红色物品，总强度达到九点。\n· 力量：把当前正面朝上且编号最小的圣甲虫翻成反面。\n狼人:\n· 任务：在实验室使用一张蓝色物品，把它放进强度相符的空血瓶位。血瓶位需要的强度依次为一、一、二、二、三、三。科学家可以使用强度比空位高一点的物品。\n· 解药：六个血瓶位全部填满时，填上最后一个血瓶位的英雄取得解药。解药可以交给其他英雄，但不能用于抵消命中。\n· 击败：由持有解药的英雄在狼人所在地点使用解药，并弃掉任意数量的红色物品，总强度达到六点。\n· 力量：狼人所在地点的所有人物各受一次命中。\n隐形人:\n· 任务：在警局使用一张物品，若该物品的印制地点与任一空线索位相符，就把物品放进该线索位。线索位分别在旅店、谷仓、豪宅、实验室与学院。\n· 击败：五个线索位全部填满后，在隐形人所在地点使用任意数量的红色物品，总强度达到九点。\n· 力量：隐形人朝最近的村民移动两步。\n特殊牌:\n英雄救出村民时，当前玩家抽取一张特殊牌。任何玩家可以在英雄阶段打出自己持有的特殊牌，打出特殊牌不消耗行动。\n· 破晓：跳过下一次怪物阶段，并抽取两张物品。\n· 深夜：当前回合额外获得两个行动。\n· 侦探来访：把隐形人放到任意地点，或者把任意怪物移动三格。\n· 出租车：把一名英雄放到任意非水地点。\n· 挥舞十字架：把德古拉放到任意地点，或者把任意怪物移动三格。\n· 疾行：把一名英雄移动至多四格。\n· 私刑：把科学怪人或新娘放到任意地点，或者把任意怪物移动三格。\n· 囤积：每名玩家各抽取一张物品。\n· 特殊投递：一名英雄可以把任意数量物品交给另一名英雄，不受地点限制。\n· 催促：每名英雄移动至多两格。\n· 调查：选择一个有英雄的地点，把任意数量英雄放到该地点。\n· 猎物：把狼人放到任意地点，或者把任意怪物移动三格。\n· 古老之力：把木乃伊放到任意地点，或者把任意怪物移动三格。\n· 炫耀武力：把黑湖妖潭放到任意地点，或者把任意怪物移动三格。\n· 击退：把每只怪物移动至多两格。\n游戏结束:\n所选怪物全部被击败时，你们立即获胜。\n恐惧值到达七点时，你们立即失败。\n怪物牌堆为空时，若还需要翻开怪物卡，你们立即失败。最后一张怪物卡会完整结算，之后先进行最后一次英雄阶段，再判断是否还有牌可翻。\n单人游戏:\n单人游戏由一名玩家控制一名英雄，其余规则不变。\n· 恐惧值从三点开始。\n· 不使用信使；开局时从英雄池中排除信使。\n· 从特殊牌堆中移除特殊投递与调查两张牌。\n· 推荐选择两只怪物进行单人游戏。",
			phaseHero: "英雄阶段",
			phaseMonster: "怪物阶段",
			phaseDone: "对局结束",
			terror: "恐惧 {{n}} / 7",
			turnLabel: "{{name}} 的回合",
			yourTurn: "轮到你行动",
			waitingTurn: "等待{{name}}行动…",
			actionsLeft: "行动 {{left}} / {{max}}",
			handTitle: "物品",
			handEmpty: "尚未持有物品",
			perksTitle: "特殊牌",
			perksEmpty: "尚未持有特殊牌",
			playPerk: "打出",
			itemStrength: "强度 {{n}}",
			colorRed: "红",
			colorBlue: "蓝",
			colorYellow: "黄",
			itemAria: "{{item}}，{{color}}色，强度 {{n}}",
			boardItems: "地点的物品",
			boardLabel: "小镇地图",
			waterTag: "水域",
			noItems: "没有物品",
			personsHere: "人物",
			noPersons: "没有人物",
			monstersHere: "怪物",
			noMonsters: "没有怪物",
			spaceActions: "可执行行动",
			noSpaceActions: "此处没有可用行动",
			moveTo: "移动到{{space}}",
			moveWith: "带 {{n}} 名村民同行",
			guideTitle: "引导村民",
			guideTo: "把{{villager}}引导到{{space}}",
			pickupTitle: "拾取物品",
			pickupN: "拾取所选 {{n}} 张",
			shareTitle: "转交物品",
			shareFrom: "由{{hero}}给出",
			shareTo: "交给{{hero}}",
			giveCure: "交出解药",
			advanceTitle: "推进任务",
			advanceButton: "推进{{monster}}",
			defeatTitle: "击败怪物",
			defeatButton: "击败{{monster}}",
			specialTitle: "特殊行动",
			specialButton: "使用{{hero}}的特殊行动",
			endTurn: "结束回合",
			doneButton: "完成",
			cancel: "取消",
			close: "关闭",
			chooseTargetSpace: "选择目的地",
			chooseTargetHero: "选择英雄",
			chooseTargetVillager: "选择村民",
			chooseTargetFigure: "选择怪物",
			chooseMode: "选择效果",
			modePlace: "放置到任意地点",
			modeMove: "移动任意怪物三格",
			stay: "留在原地",
			skipMove: "不移动",
			done: "完成",
			leadTitle: "同行村民",
			noLeadVillager: "没有可同行的村民",
			selectItemsTitle: "选择物品",
			selectItemsHint: "点击物品切换选择",
			needItems: "至少选择一张物品",
			strengthSum: "已选强度 {{n}}",
			strengthNeed: "需要总强度 {{n}}",
			invalidSelection: "当前选择不满足任务条件",
			heroOwner: "{{hero}}（{{name}}）",
			youTag: "你",
			heroDefeated: "已被击败",
			heroRevive: "下一个回合在医院复苏",
			tasksTitle: "怪物任务",
			openTasks: "怪物任务",
			taskAdvance: "任务",
			taskDefeat: "击败",
			taskPower: "力量",
			defeatedTag: "已击败",
			frenzyTag: "狂暴",
			coffins: "棺材 {{n}} / 4",
			coffinAt: "{{space}}的棺材",
			coffinBrokenAt: "{{space}}的棺材已砸碎",
			coffinBroken: "已砸碎",
			taskDetails: "任务说明",
			boatStart: "起点",
			boatEnd: "巢穴",
			boatStop: "第 {{n}} 站，{{color}}色",
			boat: "船 {{n}} / 19",
			boatLair: "船已停在巢穴",
			bottles: "血瓶 {{n}} / 6",
			spots: "线索 {{n}} / 5",
			cureLabel: "解药",
			cureHolder: "解药：{{hero}}",
			cureUnclaimed: "解药尚未取得",
			mummyPuzzle: "圣甲虫谜题",
			mummySolved: "圣甲虫已全部归位",
			mummyUnsolved: "圣甲虫尚未全部归位",
			frankProgress: "科学怪人进度 {{n}} / {{target}}",
			brideProgress: "新娘进度 {{n}} / {{target}}",
			bag: "物品袋 {{n}}",
			itemDiscard: "物品弃牌 {{n}}",
			monsterDeck: "怪物牌堆 {{n}}",
			monsterDiscard: "怪物弃牌 {{n}}",
			perkDeck: "特殊牌堆 {{n}}",
			perkDiscard: "特殊牌弃牌 {{n}}",
			lastRollTitle: "最近一次掷骰",
			rollHits: "命中 {{n}}",
			rollPowers: "力量 {{n}}",
			cardLabel: "怪物卡 {{n}}",
			eventLabel: "事件：{{event}}",
			huntedTag: "追猎：{{hero}}",
			soulTag: "灵位：{{hero}}",
			frenzyShort: "狂暴：{{monster}}",
			villagersTitle: "村民",
			rescuedCount: "已获救 {{n}} / 10",
			railNoVillagers: "场上暂无村民",
			villagerNone: "未出场",
			villagerAt: "在{{space}}",
			villagerSafeTag: "安全地点",
			villagerSafe: "安全地点：{{space}}",
			villagerSafeStatus: "已获救",
			villagerDefeatedStatus: "被击败",
			logTitle: "行动记录",
			openLog: "行动记录",
			logEmpty: "暂无记录",
			promptTitle: "请选择",
			promptWaiting: "等待{{name}}选择…",
			promptAttack: "选择被攻击的目标",
			promptDefend: "被命中：弃物品抵消或承受攻击",
			promptThief: "隐形人窃贼：选择地点",
			promptPlaceFigure: "选择要放置的怪物",
			promptFigureDest: "{{figure}}的移动目的地",
			promptMoveFigure: "选择要移动的怪物",
			promptHeroDest: "{{hero}}的移动目的地",
			promptMoveHero: "选择要移动的英雄",
			promptCarry: "选择要同行的村民",
			carryConfirm: "确认同行",
			promptHurry: "催促{{hero}}移动两格",
			promptInvestigate: "调查：选择集合地点",
			promptInvestigateHero: "把其他英雄聚集到这里",
			promptRepel: "击退：选择要移动的怪物",
			promptDeliveryFrom: "特殊投递：选择交出物品的英雄",
			promptDeliveryTo: "特殊投递：选择接收物品的英雄",
			promptDeliveryItem: "选择交给{{hero}}的物品",
			promptGaze: "催眠凝视：选择被牵引的人物",
			promptPerkMode: "选择特殊牌效果",
			takeHit: "承受攻击",
			defendWith: "弃掉{{item}}抵消",
			mummyPending: "圣甲虫移动：剩余 {{n}} 次",
			mummySlideHint: "点击一只正面朝上的圣甲虫，再点击相邻空位",
			mummyFlipHint: "点击反面朝上的圣甲虫把它翻正",
			mummyDoneButton: "完成谜题",
			mummyPickFirst: "先选择一只正面朝上的圣甲虫",
			mummyInvalidTarget: "只能滑到相邻空位",
			fbPending: "移动{{figure}}：剩余 {{n}} 步",
			fbPendingHint: "点击高亮地点移动，或选择完成",
			endingTitle: "对局结束",
			endingWin: "所有怪物都被击败，你们获胜",
			endingTerror: "恐惧值到达七点，你们失败",
			endingTime: "怪物牌堆耗尽，你们失败",
			overWin: "小镇得救了",
			overLoss: "恐惧吞噬了小镇",
			overMonsters: "已击败怪物",
			overRescued: "已获救村民",
			overTerror: "最终恐惧",
			overVillagersLost: "有 {{n}} 名村民被击败。",
			invalidAction: "当前操作无法执行",
			waitingOther: "等待其他玩家…",
			selectPerkConfirm: "打出{{perk}}",
			cancelsPerk: "暂不打出",
			pendingMoves: "{{figure}}移动中",
			monstersChosen: "本局怪物",
			deckInfo: "牌堆",
			itemAt: "{{item}}出现在{{space}}",
			safeSpaceShort: "安全地点",
			monstersTitle: "怪物",
			heroesTitle: "英雄",
			optionsHint: "选择本局要对抗的怪物，数量为一到四只。",
			optionsRecommended: "推荐组合",
			optionsRecommendedValue: "黑湖妖潭与德古拉",
			optionsCount: "已选择 {{n}} 只",
			optionsInvalid: "至少选择一只怪物，最多选择四只",
			spaceCave: "洞穴",
			spaceCamp: "营地",
			spacePrecinct: "警局",
			spaceInn: "旅店",
			spaceBarn: "谷仓",
			spaceDungeon: "地牢",
			spaceLagoon: "咸水湖",
			spaceBridgeWest: "西桥",
			spaceFountain: "喷泉",
			spaceLamp: "路灯路口",
			spaceMansion: "豪宅",
			spaceAbbey: "修道院",
			spaceCrypt: "墓穴",
			spaceMuseum: "博物馆",
			spaceChurch: "教堂",
			spaceHospital: "医院",
			spaceGraveyard: "墓地",
			spaceLaboratory: "实验室",
			spaceInstitute: "学院",
			spaceWaterfront: "码头岸边",
			spaceDocks: "码头",
			spaceTower: "塔楼",
			spaceTheatre: "剧院",
			spaceRiver: "河流",
			spaceBridgeEast: "东桥",
			spaceShop: "商店",
			itemBeartrap: "熊夹",
			itemRapier: "细剑",
			itemPistol: "手枪",
			itemSilvercane: "银手杖",
			itemShovel: "铁锹",
			itemPitchfork: "干草叉",
			itemDart: "飞镖",
			itemKnife: "刀",
			itemFirepoker: "拨火棍",
			itemTorch: "火把",
			itemSpeargun: "鱼叉枪",
			itemRifle: "步枪",
			itemResearch: "研究资料",
			itemAnatomy: "解剖学书",
			itemKite: "风筝",
			itemRotenone: "鱼藤酮",
			itemCentrifuge: "离心机",
			itemFossil: "化石",
			itemAnalysis: "分析报告",
			itemTelescope: "望远镜",
			itemExperiment: "实验记录",
			itemSearchlight: "探照灯",
			itemCamera: "相机",
			itemCosmicray: "宇宙射线扩散器",
			itemMonocane: "曼陀罗合剂",
			itemNebularium: "雾化器",
			itemTablet: "石板",
			itemFlower: "花",
			itemWine: "葡萄酒",
			itemGarlic: "大蒜",
			itemCharm: "护符",
			itemTarot: "塔罗牌",
			itemMirroredbox: "镜匣",
			itemCrucifix: "十字架",
			itemWolfsbane: "附子草",
			itemViolin: "小提琴",
			itemStake: "木桩",
			itemScroll: "托特卷轴",
			itemCanopic: "卡诺匹斯罐",
			heroArchaeologist: "考古学家",
			heroCourier: "信使",
			heroExplorer: "探险家",
			heroInspector: "督察",
			heroMayor: "市长",
			heroProfessor: "教授",
			heroScientist: "科学家",
			heroArchaeologistShort: "考古",
			heroCourierShort: "信使",
			heroExplorerShort: "探险",
			heroInspectorShort: "督察",
			heroMayorShort: "市长",
			heroProfessorShort: "教授",
			heroScientistShort: "科学",
			heroArchaeologistSpecial: "特殊行动：从相邻地点取走物品。",
			heroCourierSpecial: "特殊行动：移到任意有另一名英雄的地点。",
			heroExplorerSpecial: "特殊行动：移到任意非水地点。",
			heroInspectorSpecial: "特殊行动：移到任意有怪物的非水地点。",
			heroMayorSpecial: "没有特殊行动，但每回合有五个行动。",
			heroProfessorSpecial: "特殊行动：把任一英雄或村民移动一格。",
			heroScientistSpecial: "被动能力：使用物品时，物品强度增加一点。",
			villagerFritz: "弗里茨",
			villagerMaria: "玛丽亚",
			villagerMaleva: "玛列娃",
			villagerPearson: "皮尔逊教授",
			villagerWilbur: "威尔伯与奇克",
			villagerRenfield: "伦菲尔德",
			villagerReed: "里德博士",
			villagerCranley: "克兰利博士",
			villagerLucy: "露西",
			villagerElizabeth: "伊丽莎白",
			villagerFritzShort: "弗里",
			villagerMariaShort: "玛丽",
			villagerMalevaShort: "玛列",
			villagerPearsonShort: "皮尔",
			villagerWilburShort: "威尔",
			villagerRenfieldShort: "伦菲",
			villagerReedShort: "里德",
			villagerCranleyShort: "克兰",
			villagerLucyShort: "露西",
			villagerElizabethShort: "伊丽",
			monsterDracula: "德古拉",
			monsterMummy: "木乃伊",
			monsterFrankenstein: "科学怪人",
			monsterBride: "新娘",
			monsterCreature: "黑湖妖潭",
			monsterWolfman: "狼人",
			monsterInvisibleman: "隐形人",
			monsterDraculaShort: "德古",
			monsterMummyShort: "木乃",
			monsterFrankensteinShort: "科学",
			monsterCreatureShort: "海怪",
			monsterWolfmanShort: "狼人",
			monsterInvisiblemanShort: "隐形",
			monsterFrankShort: "弗兰",
			monsterBrideShort: "新娘",
			monsterDraculaAdvance: "在有棺材的地点使用任意数量的红色物品，总强度达到六点，即可砸碎该地点的棺材。",
			monsterDraculaDefeat: "四具棺材全部砸碎后，在德古拉所在地点使用任意数量的黄色物品，总强度达到六点。",
			monsterDraculaPower: "黑暗魅惑：把当前玩家的英雄移到德古拉所在地点。",
			monsterCreatureAdvance: "在营地使用一张任意颜色的物品，把船推进到下一处该颜色的标记。",
			monsterCreatureDefeat: "船停在巢穴后，在黑湖妖潭所在地点使用红、蓝、黄物品各一张。",
			monsterCreaturePower: "把船向起点后退一站。",
			monsterFrankensteinAdvance: "在科学怪人所在地点使用黄色物品，在新娘所在地点使用蓝色物品，按强度增加人性进度并移动对应步数。",
			monsterFrankensteinDefeat: "两者转盘都翻面后，位于同一地点时立即被击败。",
			monsterFrankensteinPower: "新娘朝科学怪人移动一步。",
			monsterMummyAdvance: "在博物馆使用一张黄色物品，获得等同于其强度的圣甲虫移动次数。",
			monsterMummyDefeat: "圣甲虫全部归位后，在木乃伊所在地点使用任意数量的红色物品，总强度达到九点。",
			monsterMummyPower: "把当前正面朝上且编号最小的圣甲虫翻成反面。",
			monsterWolfmanAdvance: "在实验室使用一张蓝色物品，把它放进强度相符的空血瓶位。",
			monsterWolfmanDefeat: "由持有解药的英雄在狼人所在地点使用解药，并弃掉任意数量的红色物品，总强度达到六点。",
			monsterWolfmanPower: "狼人所在地点的所有人物各受一次命中。",
			monsterInvisiblemanAdvance: "在警局使用一张物品，其印制地点与空线索位相符时，把物品放进该线索位。",
			monsterInvisiblemanDefeat: "五个线索位全部填满后，在隐形人所在地点使用任意数量的红色物品，总强度达到九点。",
			monsterInvisiblemanPower: "隐形人朝最近的村民移动两步。",
			eventOnTheMove: "怪物迁徙：狂暴标记移交给下一只怪物，村民朝安全地点移动一格。",
			eventMeeting: "相会：新娘朝科学怪人移动两格。",
			eventHunt: "追猎：指定一名英雄，狼人朝其移动三格。",
			eventThief: "窃贼：隐形人移到物品最多的地点，并弃掉该地点的全部物品。",
			eventRetreatLagoon: "退却：黑湖妖潭移到咸水湖。",
			eventRetreatRiver: "退却：黑湖妖潭移到河流。",
			eventRetreatWaterfront: "退却：黑湖妖潭移到码头岸边。",
			eventInnocent: "无辜者：玛丽亚出现在谷仓。",
			eventInsaneSurvivor: "疯癫的幸存者：伦菲尔德出现在码头。",
			eventWorriedFiancee: "忧心的未婚妻：伊丽莎白出现在豪宅。",
			eventEnthralled: "被蛊惑者：露西出现在剧院。",
			eventDelivery: "送信人：威尔伯与奇克出现在商店。",
			eventFortuneTeller: "占卜师：玛列娃出现在营地。",
			eventHurriedAssistant: "匆忙的助手：弗里茨出现在塔楼。",
			eventReincarnatedSoul: "转世灵魂：指定一名英雄持有灵位，并朝木乃伊移动三格。",
			eventHypnoticGaze: "催眠凝视：离德古拉最近的人物朝德古拉移动三格。",
			eventSunrise: "日出：德古拉回到墓穴。",
			eventFormOfTheBat: "蝙蝠形态：德古拉移到当前玩家英雄的地点。",
			eventEgyptianExpert: "埃及学者：皮尔逊教授出现在洞穴。",
			eventFormerEmployer: "旧日雇主：克兰利博士出现在实验室。",
			eventIchthyologist: "鱼类学家：里德博士出现在学院。",
			perkBreakOfDawn: "破晓：跳过下一次怪物阶段，并抽取两张物品。",
			perkLateNight: "深夜：当前回合额外获得两个行动。",
			perkDetective: "侦探来访：把隐形人放到任意地点，或者把任意怪物移动三格。",
			perkTaxiRide: "出租车：把一名英雄放到任意非水地点。",
			perkCrucifix: "挥舞十字架：把德古拉放到任意地点，或者把任意怪物移动三格。",
			perkRush: "疾行：把一名英雄移动至多四格。",
			perkMobJustice: "私刑：把科学怪人或新娘放到任意地点，或者把任意怪物移动三格。",
			perkOverstock: "囤积：每名玩家各抽取一张物品。",
			perkSpecialDelivery: "特殊投递：一名英雄可以把任意数量物品交给另一名英雄，不受地点限制。",
			perkHurry: "催促：每名英雄移动至多两格。",
			perkInvestigation: "调查：选择一个有英雄的地点，把任意数量英雄放到该地点。",
			perkHuntedPrey: "猎物：把狼人放到任意地点，或者把任意怪物移动三格。",
			perkAncients: "古老之力：把木乃伊放到任意地点，或者把任意怪物移动三格。",
			perkShowForce: "炫耀武力：把黑湖妖潭放到任意地点，或者把任意怪物移动三格。",
			perkRepel: "击退：把每只怪物移动至多两格。",
			logTurnStart: "{{hero}}开始行动",
			logHeroEnd: "{{hero}}结束行动",
			logHeroMoved: "{{hero}}移动到{{space}}",
			logVillagerMoved: "{{villager}}移动到{{space}}",
			logPickup: "{{hero}}拾取了 {{n}} 张物品",
			logItemGiven: "{{hero}}把物品交给{{hero2}}",
			logCureGiven: "{{hero}}把解药交给{{hero2}}",
			logAdvance: "{{hero}}使用物品推进{{figure}} {{n}} 点",
			logDefeat: "{{hero}}击败了{{monster}}",
			logMonsterDefeated: "{{monster}}被击败",
			logCoffinBroken: "{{hero}}砸碎了{{space}}的棺材",
			logBoatAdvance: "{{hero}}把船推进到第 {{n}} 站",
			logBoatBack: "船后退到第 {{n}} 站",
			logBottleFilled: "{{hero}}填入血瓶（需要 {{n}} 点强度）",
			logCureTaken: "{{hero}}取得解药",
			logSpotFilled: "{{hero}}补齐了{{space}}的线索",
			logMummyAdvance: "{{hero}}获得 {{n}} 次圣甲虫移动",
			logScarabSlide: "圣甲虫滑到空位",
			logScarabFlip: "圣甲虫翻回正面",
			logScarabFlipped: "圣甲虫被翻成反面",
			logMummyDone: "圣甲虫移动结束",
			logFbFlipped: "{{figure}}的转盘翻面",
			logFbMeet: "两只科学怪人相遇，恐惧上升",
			logFbDefeated: "两只科学怪人重逢，怪物被击败",
			logItemPlaced: "{{item}}出现在{{space}}",
			logTerror: "恐惧上升 {{n}} 点",
			logHeroDefeated: "{{hero}}被击败",
			logVillagerDefeated: "{{villager}}被击败",
			logVillagerPlaced: "{{villager}}出现在{{space}}",
			logRescued: "{{villager}}获救",
			logRevived: "{{hero}}在医院复苏",
			logMonsterCard: "翻开怪物卡 {{n}}",
			logMonsterMoved: "{{figure}}移动到{{space}}",
			logMonsterSkipped: "本次怪物阶段被跳过",
			logMonsterWillSkip: "下一次怪物阶段将被跳过",
			logRoll: "{{figure}}掷出 {{n}} 次命中与 {{n2}} 次力量",
			logHitHero: "{{hero}}被击中",
			logHitVillager: "{{villager}}被击中",
			logDefended: "{{hero}}弃掉{{item}}抵消命中",
			logCharmed: "{{hero}}被魅惑到{{space}}",
			logHunted: "{{hero}}被狼人追猎",
			logSoul: "{{hero}}取得灵位",
			logFrenzyMoved: "狂暴标记移到{{monster}}",
			logPerkGain: "{{hero}}获得特殊牌{{perk}}",
			logPerkPlayed: "打出特殊牌{{perk}}",
			logActions: "获得 {{n}} 个额外行动",
			logThief: "隐形人偷走了{{space}}的物品",
			logEventIgnored: "{{monster}}不在本局，事件被忽略",
			logWin: "胜利：怪物全部被击败",
			logLose: "失败",
			logFrenzy: "狂暴标记在{{monster}}上",
			logMoved: "{{figure}}移动到{{space}}",
			logAttack: "{{figure}}攻击{{who}}"
		},
		en: {
			name: "Horrified",
			desc: "Work together against Dracula, Frankenstein's monster, and other classic creatures to finish their tasks and defeat them all before terror overwhelms the town",
			rules: "Objective:\nYou play as local heroes. Before terror overwhelms the town, complete the tasks of every chosen monster and defeat them one by one. The moment every chosen monster is defeated, you win immediately.\nTerror marks how unsettled the town has become. Each time a hero or villager is defeated, terror rises by one. When terror reaches seven, you lose immediately.\nIf you must draw a monster card and the monster deck is empty, you lose immediately.\nSetup:\n· Unfold the board. You may choose one to four monsters for the game; for a first game, Dracula and the Creature from the Black Lagoon are recommended.\n· Each player takes a random hero badge and places their hero figure on the starting space shown on the badge.\n· Shuffle the sixty item cards face down to form the item bag. Draw twelve items from the bag and place each on the appearance space printed on its card; items drawn later are placed the same way.\n· Shuffle the thirty monster cards face down to form the monster deck, and shuffle the twenty perk cards to form the perk deck, then deal one face-up perk card to each player.\n· Set up the figures and components for each chosen monster. Place Dracula in the Crypt, with the four coffins in the Crypt, the Dungeon, the Graveyard, and the Cave; place the Creature in the Lagoon with the boat at the start of its monster mat; place Frankenstein's monster in the Graveyard and the Bride in the Dungeon; place the Mummy in the Museum and set up the scarab puzzle as its task explains; place the Wolfman in the Mansion with the antidote on the right side of its monster mat; place the Invisible Man in the Inn.\n· Place the terror marker on zero. In a solo game, place the terror marker on three instead and remove the Special Delivery and Investigation perk cards from the perk deck.\n· The first player to sit begins, and play continues in seating order.\nTurn:\nEach player's turn consists of a hero phase followed by a monster phase.\nIn the hero phase, the current player performs actions equal to the number shown on their hero badge. Moving, guiding, picking up, sharing, advancing a task, defeating a monster, and using a special action each costs one action.\nAny player may play a perk card they hold at any time during the hero phase, and playing a perk card does not cost an action.\nWhen the current player ends the hero phase, the monster phase begins.\nIn the monster phase, draw one monster card, resolve its item, event, and monster steps in order, then the next player's turn begins.\nHero actions:\n· Move: move your hero to an adjacent land space. Your hero may bring any number of villagers from the current space along to the destination. Movement from a perk card or special action follows the same move rules and may bring villagers from that space along.\n· Guide: move one villager in your hero's space to an adjacent land space, or move one villager from an adjacent space to your hero's space.\n· Pick up: take any number of items from the current space.\n· Share: any two heroes in the current space may give any number of items to each other; the exchange does not have to involve the current hero. A hero holding the antidote may also give it to another hero in the same space. Sharing costs one action.\n· Advance a task: use items at the required space as described by the monster's task. Used items go to the item discard pile.\n· Defeat a monster: use items at the monster's space as described by the monster's task. Used items go to the item discard pile.\n· Special action: perform the action described on your hero badge. A special action also costs one action; the Scientist's ability is continuous and costs no action.\nWater spaces include the Lagoon, the River, and the Waterfront. Heroes and villagers cannot enter water spaces; only the Creature can enter them.\nItems:\nItems come in red, blue, and yellow, and the number on the card is its strength. When the Scientist uses an item, its strength increases by one.\nWhen you draw an item, place it on the appearance space printed on its card. When the item bag is empty, shuffle the item discard pile to form a new bag.\nWhen a hero is hit by a monster, they may discard one item to cancel the hit; if they have no item to discard, or choose not to discard one, the hero is defeated.\nVillagers:\nEach of the ten villagers has a safe space. Villagers appear at their appearance space because of events.\nA villager is rescued immediately upon reaching their safe space and is removed from the board; the current player draws one perk card.\nA villager is defeated immediately when hit by a monster, and terror rises by one. Villagers have no items and cannot cancel hits.\nHeroes defeated:\nWhen a hero is defeated, remove the hero figure from the board and raise terror by one.\nAt the start of their next turn, the defeated player places their hero in the Hospital and continues with a full number of actions. The hero keeps all items and perk cards.\nMonster phase:\nA monster card has three parts: items, event, and monster actions, resolved in that order.\n· Items: draw items as shown on the card and place each on its printed appearance space.\n· Event: follow the card's instructions. If the monster involved is not in this game or has already been defeated, ignore the event.\n· Monster actions: resolve each monster symbol from left to right. Each monster symbol moves that monster toward the nearest person, up to the number of steps shown on the card, stopping when it reaches the person's space; then the monster attacks one target. A hit hero may discard one item to cancel the hit; if the hit cannot be canceled, the hero is defeated. A villager hit by a monster is defeated immediately. When a monster could attack either a hero or a villager, it attacks the hero first; if several targets are equally distant, the current player chooses the target before the dice are rolled.\n· Each die has three hit faces, two blank faces, and one power face. Each hit deals one hit, and each power triggers that monster's power once.\n· A frenzy symbol makes the monster holding the frenzy marker take another action. At the start of the game, place the frenzy marker on the monster in play with the lowest frenzy order; when an event passes it, give it to the next monster in play with the next higher frenzy order.\nMonster tasks:\nDracula:\n· Task: use any number of red items with a total strength of at least six on a space with a coffin to smash that coffin.\n· Defeat: after all four coffins are smashed, use any number of yellow items with a total strength of at least six on Dracula's space.\n· Power: Dark Charm. Move the current player's hero to Dracula's space.\nCreature from the Black Lagoon:\n· Task: at the Camp, use one item of any color to move the boat to the next marker of that color. The boat path has nineteen stops, and the nineteenth stop is the lair; the lair marker is blue, so the item used to reach the lair must be blue.\n· Defeat: after the boat reaches the lair, use one red, one blue, and one yellow item on the Creature's space.\n· Power: move the boat back one stop toward the start.\nFrankenstein's Monster and the Bride:\n· Task: use one yellow item on Frankenstein's monster's space to increase its humanity, and use one blue item on the Bride's space to increase her humanity. The increase equals the item's strength, after which that monster may move up to a number of steps equal to the increase. The monster's target is eleven and the Bride's target is eight; when a monster reaches its target, its dial flips over.\n· Defeat: after both dials are flipped, the two monsters are defeated immediately while they are on the same space, without a defeat action.\n· Meeting: if the two monsters enter the same space before both dials are flipped, terror rises by one, then place Frankenstein's monster back in the Graveyard and the Bride back in the Dungeon.\n· Power: the Bride moves one step toward Frankenstein's monster.\nMummy:\n· Puzzle: the scarab puzzle has six numbered positions and one empty center. At setup, scarabs one to three are placed randomly on the three left positions and scarabs four to six randomly on the three right positions, all face up.\n· Task: at the Museum, use one yellow item to gain a number of scarab moves equal to the item's strength. One move slides one face-up scarab to an adjacent empty position, or flips one face-down scarab back face up.\n· Defeat: with all six scarabs face up, scarabs one to six each on the matching numbered position, and the center empty, use any number of red items with a total strength of at least nine on the Mummy's space.\n· Power: flip the lowest-numbered face-up scarab face down.\nWolfman:\n· Task: at the Laboratory, use one blue item and place it in an empty blood vial slot matching its strength. The slots require strengths one, one, two, two, three, and three in order. The Scientist may use an item one strength higher than the slot requires.\n· Antidote: when all six slots are filled, the hero who filled the last slot takes the antidote. The antidote may be given to other heroes but cannot be used to cancel a hit.\n· Defeat: the hero holding the antidote uses it on the Wolfman's space and discards any number of red items with a total strength of at least six.\n· Power: every person on the Wolfman's space takes one hit.\nInvisible Man:\n· Task: at the Police Station, use one item; if the item's printed appearance space matches an empty clue slot, place the item in that slot. The clue slots are the Inn, the Barn, the Mansion, the Laboratory, and the Institute.\n· Defeat: after all five clue slots are filled, use any number of red items with a total strength of at least nine on the Invisible Man's space.\n· Power: the Invisible Man moves two steps toward the nearest villager.\nPerk cards:\nWhen a hero rescues a villager, the current player draws one perk card. Any player may play a perk card they hold at any time during the hero phase, and playing a perk card does not cost an action.\n· Break of Dawn: skip the next monster phase and draw two items.\n· Late Night: gain two extra actions this turn.\n· Detective Visits: place the Invisible Man on any space, or move any monster three spaces.\n· Taxi Ride: place one hero on any non-water space.\n· Brandish Crucifix: place Dracula on any space, or move any monster three spaces.\n· Rush: move one hero up to four spaces.\n· Mob Justice: place Frankenstein's monster or the Bride on any space, or move any monster three spaces.\n· Overstock: each player draws one item.\n· Special Delivery: one hero may give any number of items to another hero regardless of space.\n· Hurry: each hero moves up to two spaces.\n· Investigation: choose a space with a hero and place any number of heroes there.\n· Hunted Prey: place the Wolfman on any space, or move any monster three spaces.\n· Ancient Power: place the Mummy on any space, or move any monster three spaces.\n· Show of Force: place the Creature on any space, or move any monster three spaces.\n· Repel: move every monster up to two spaces.\nGame end:\nThe moment every chosen monster is defeated, you win immediately.\nWhen terror reaches seven, you lose immediately.\nWhen the monster deck is empty and you must draw a monster card, you lose immediately. The final monster card is fully resolved, then one last hero phase is played before you check whether a card remains to be drawn.\nSolo game:\nIn a solo game, one player controls one hero and all other rules stay the same.\n· Terror starts at three.\n· Do not use the Courier; remove the Courier from the hero pool at setup.\n· Remove the Special Delivery and Investigation perk cards from the perk deck.\n· Two monsters are recommended for a solo game.",
			phaseHero: "Hero phase",
			phaseMonster: "Monster phase",
			phaseDone: "Game over",
			terror: "Terror {{n}} / 7",
			turnLabel: "{{name}}'s turn",
			yourTurn: "Your turn",
			waitingTurn: "Waiting for {{name}}…",
			actionsLeft: "Actions {{left}} / {{max}}",
			handTitle: "Items",
			handEmpty: "No items yet",
			perksTitle: "Perk cards",
			perksEmpty: "No perk cards yet",
			playPerk: "Play",
			itemStrength: "Strength {{n}}",
			colorRed: "Red",
			colorBlue: "Blue",
			colorYellow: "Yellow",
			itemAria: "{{item}}, {{color}}, strength {{n}}",
			boardItems: "Items on spaces",
			boardLabel: "Town map",
			waterTag: "Water",
			noItems: "No items",
			personsHere: "People",
			noPersons: "No people",
			monstersHere: "Monsters",
			noMonsters: "No monsters",
			spaceActions: "Available actions",
			noSpaceActions: "No actions available here",
			moveTo: "Move to {{space}}",
			moveWith: "Bring {{n}} villagers",
			guideTitle: "Guide a villager",
			guideTo: "Guide {{villager}} to {{space}}",
			pickupTitle: "Pick up items",
			pickupN: "Pick up selected {{n}}",
			shareTitle: "Trade items",
			shareFrom: "From {{hero}}",
			shareTo: "Give to {{hero}}",
			giveCure: "Give the antidote",
			advanceTitle: "Advance a task",
			advanceButton: "Advance {{monster}}",
			defeatTitle: "Defeat a monster",
			defeatButton: "Defeat {{monster}}",
			specialTitle: "Special action",
			specialButton: "Use {{hero}}'s special action",
			endTurn: "End turn",
			doneButton: "Done",
			cancel: "Cancel",
			close: "Close",
			chooseTargetSpace: "Choose a destination",
			chooseTargetHero: "Choose a hero",
			chooseTargetVillager: "Choose a villager",
			chooseTargetFigure: "Choose a monster",
			chooseMode: "Choose an effect",
			modePlace: "Place on any space",
			modeMove: "Move any monster three spaces",
			stay: "Stay here",
			skipMove: "Do not move",
			done: "Done",
			leadTitle: "Villagers coming along",
			noLeadVillager: "No villagers can come along",
			selectItemsTitle: "Select items",
			selectItemsHint: "Tap items to toggle selection",
			needItems: "Select at least one item",
			strengthSum: "Selected strength {{n}}",
			strengthNeed: "Needs total strength {{n}}",
			invalidSelection: "The selection does not meet the task",
			heroOwner: "{{hero}} ({{name}})",
			youTag: "You",
			heroDefeated: "Defeated",
			heroRevive: "Revives in the Hospital next turn",
			tasksTitle: "Monster tasks",
			openTasks: "Monster tasks",
			taskAdvance: "Task",
			taskDefeat: "Defeat",
			taskPower: "Power",
			defeatedTag: "Defeated",
			frenzyTag: "Frenzy",
			coffins: "Coffins {{n}} / 4",
			coffinAt: "Coffin at {{space}}",
			coffinBrokenAt: "Coffin at {{space}} smashed",
			coffinBroken: "Smashed",
			taskDetails: "Task details",
			boatStart: "Start",
			boatEnd: "Lair",
			boatStop: "Stop {{n}}, {{color}}",
			boat: "Boat {{n}} / 19",
			boatLair: "The boat waits at the lair",
			bottles: "Vials {{n}} / 6",
			spots: "Clues {{n}} / 5",
			cureLabel: "Antidote",
			cureHolder: "Antidote: {{hero}}",
			cureUnclaimed: "Antidote not yet claimed",
			mummyPuzzle: "Scarab puzzle",
			mummySolved: "Every scarab is in place",
			mummyUnsolved: "The scarabs are not all in place",
			frankProgress: "Monster humanity {{n}} / {{target}}",
			brideProgress: "Bride humanity {{n}} / {{target}}",
			bag: "Item bag {{n}}",
			itemDiscard: "Item discard {{n}}",
			monsterDeck: "Monster deck {{n}}",
			monsterDiscard: "Monster discard {{n}}",
			perkDeck: "Perk deck {{n}}",
			perkDiscard: "Perk discard {{n}}",
			lastRollTitle: "Latest roll",
			rollHits: "Hits {{n}}",
			rollPowers: "Powers {{n}}",
			cardLabel: "Monster card {{n}}",
			eventLabel: "Event: {{event}}",
			huntedTag: "Hunted: {{hero}}",
			soulTag: "Soul: {{hero}}",
			frenzyShort: "Frenzy: {{monster}}",
			villagersTitle: "Villagers",
			rescuedCount: "Rescued {{n}} / 10",
			railNoVillagers: "No villagers on the board",
			villagerNone: "Not yet appeared",
			villagerAt: "At {{space}}",
			villagerSafeTag: "Safe space",
			villagerSafe: "Safe space: {{space}}",
			villagerSafeStatus: "Rescued",
			villagerDefeatedStatus: "Defeated",
			logTitle: "Action log",
			openLog: "Action log",
			logEmpty: "No entries yet",
			promptTitle: "Choose",
			promptWaiting: "Waiting for {{name}} to choose…",
			promptAttack: "Choose the target of the attack",
			promptDefend: "Hit: discard an item or accept the attack",
			promptThief: "Invisible thief: choose a space",
			promptPlaceFigure: "Choose the monster to place",
			promptFigureDest: "Destination for {{figure}}",
			promptMoveFigure: "Choose the monster to move",
			promptHeroDest: "Destination for {{hero}}",
			promptMoveHero: "Choose the hero to move",
			promptCarry: "Choose villagers to bring along",
			carryConfirm: "Confirm",
			promptHurry: "Hurry: move {{hero}} two spaces",
			promptInvestigate: "Investigation: choose a gathering space",
			promptInvestigateHero: "Gather the other heroes here",
			promptRepel: "Repel: choose the monster to move",
			promptDeliveryFrom: "Special Delivery: choose the hero giving items",
			promptDeliveryTo: "Special Delivery: choose the hero receiving items",
			promptDeliveryItem: "Choose the item to give to {{hero}}",
			promptGaze: "Hypnotic Gaze: choose the person to pull",
			promptPerkMode: "Choose the perk effect",
			takeHit: "Accept the attack",
			defendWith: "Discard {{item}} to cancel",
			mummyPending: "Scarab moves left: {{n}}",
			mummySlideHint: "Tap a face-up scarab, then an adjacent empty position",
			mummyFlipHint: "Tap a face-down scarab to flip it face up",
			mummyDoneButton: "Finish the puzzle",
			mummyPickFirst: "Choose a face-up scarab first",
			mummyInvalidTarget: "A scarab can only slide to an adjacent empty position",
			fbPending: "Move {{figure}}: {{n}} steps left",
			fbPendingHint: "Tap a highlighted space to move, or choose Done",
			endingTitle: "Game over",
			endingWin: "Every monster is defeated — you win",
			endingTerror: "Terror reached seven — you lose",
			endingTime: "The monster deck ran out — you lose",
			overWin: "The town is saved",
			overLoss: "Terror has taken the town",
			overMonsters: "Monsters defeated",
			overRescued: "Villagers rescued",
			overTerror: "Final terror",
			overVillagersLost: "{{n}} villagers were defeated.",
			invalidAction: "That action cannot be performed now",
			waitingOther: "Waiting for other players…",
			selectPerkConfirm: "Play {{perk}}",
			cancelsPerk: "Not now",
			pendingMoves: "{{figure}} is moving",
			monstersChosen: "Monsters this game",
			deckInfo: "Decks",
			itemAt: "{{item}} appears at {{space}}",
			safeSpaceShort: "Safe space",
			monstersTitle: "Monsters",
			heroesTitle: "Heroes",
			optionsHint: "Choose the monsters to face this game, one to four.",
			optionsRecommended: "Recommended",
			optionsRecommendedValue: "Dracula and the Creature",
			optionsCount: "{{n}} chosen",
			optionsInvalid: "Choose at least one monster and at most four",
			spaceCave: "Cave",
			spaceCamp: "Camp",
			spacePrecinct: "Police Station",
			spaceInn: "Inn",
			spaceBarn: "Barn",
			spaceDungeon: "Dungeon",
			spaceLagoon: "Lagoon",
			spaceBridgeWest: "West Bridge",
			spaceFountain: "Fountain",
			spaceLamp: "Lamp Post",
			spaceMansion: "Mansion",
			spaceAbbey: "Abbey",
			spaceCrypt: "Crypt",
			spaceMuseum: "Museum",
			spaceChurch: "Church",
			spaceHospital: "Hospital",
			spaceGraveyard: "Graveyard",
			spaceLaboratory: "Laboratory",
			spaceInstitute: "Institute",
			spaceWaterfront: "Waterfront",
			spaceDocks: "Docks",
			spaceTower: "Tower",
			spaceTheatre: "Theatre",
			spaceRiver: "River",
			spaceBridgeEast: "East Bridge",
			spaceShop: "Shop",
			itemBeartrap: "Bear Trap",
			itemRapier: "Rapier",
			itemPistol: "Pistol",
			itemSilvercane: "Silver Cane",
			itemShovel: "Shovel",
			itemPitchfork: "Pitchfork",
			itemDart: "Dart",
			itemKnife: "Knife",
			itemFirepoker: "Fire Poker",
			itemTorch: "Torch",
			itemSpeargun: "Speargun",
			itemRifle: "Rifle",
			itemResearch: "Research Notes",
			itemAnatomy: "Anatomy Book",
			itemKite: "Kite",
			itemRotenone: "Rotenone",
			itemCentrifuge: "Centrifuge",
			itemFossil: "Fossil",
			itemAnalysis: "Analysis Report",
			itemTelescope: "Telescope",
			itemExperiment: "Experiment Log",
			itemSearchlight: "Searchlight",
			itemCamera: "Camera",
			itemCosmicray: "Cosmic Ray Diffuser",
			itemMonocane: "Monocane Mixture",
			itemNebularium: "Nebularium",
			itemTablet: "Tablet",
			itemFlower: "Flower",
			itemWine: "Wine",
			itemGarlic: "Garlic",
			itemCharm: "Charm",
			itemTarot: "Tarot Cards",
			itemMirroredbox: "Mirrored Box",
			itemCrucifix: "Crucifix",
			itemWolfsbane: "Wolfsbane",
			itemViolin: "Violin",
			itemStake: "Stake",
			itemScroll: "Scroll of Thoth",
			itemCanopic: "Canopic Jar",
			heroArchaeologist: "Archaeologist",
			heroCourier: "Courier",
			heroExplorer: "Explorer",
			heroInspector: "Inspector",
			heroMayor: "Mayor",
			heroProfessor: "Professor",
			heroScientist: "Scientist",
			heroArchaeologistShort: "Arch",
			heroCourierShort: "Cour",
			heroExplorerShort: "Expl",
			heroInspectorShort: "Insp",
			heroMayorShort: "Mayor",
			heroProfessorShort: "Prof",
			heroScientistShort: "Sci",
			heroArchaeologistSpecial: "Special action: take items from an adjacent space.",
			heroCourierSpecial: "Special action: move to any space with another hero.",
			heroExplorerSpecial: "Special action: move to any non-water space.",
			heroInspectorSpecial: "Special action: move to any non-water space with a monster.",
			heroMayorSpecial: "No special action, but five actions each turn.",
			heroProfessorSpecial: "Special action: move any hero or villager one space.",
			heroScientistSpecial: "Continuous ability: when you use an item, its strength increases by one.",
			villagerFritz: "Fritz",
			villagerMaria: "Maria",
			villagerMaleva: "Maleva",
			villagerPearson: "Professor Pearson",
			villagerWilbur: "Wilbur and Chick",
			villagerRenfield: "Renfield",
			villagerReed: "Dr. Reed",
			villagerCranley: "Dr. Cranley",
			villagerLucy: "Lucy",
			villagerElizabeth: "Elizabeth",
			villagerFritzShort: "Fritz",
			villagerMariaShort: "Maria",
			villagerMalevaShort: "Maleva",
			villagerPearsonShort: "Pearson",
			villagerWilburShort: "Wilbur",
			villagerRenfieldShort: "Renfield",
			villagerReedShort: "Reed",
			villagerCranleyShort: "Cranley",
			villagerLucyShort: "Lucy",
			villagerElizabethShort: "Eliz",
			monsterDracula: "Dracula",
			monsterMummy: "Mummy",
			monsterFrankenstein: "Frankenstein's Monster",
			monsterBride: "Bride",
			monsterCreature: "Creature from the Black Lagoon",
			monsterWolfman: "Wolfman",
			monsterInvisibleman: "Invisible Man",
			monsterDraculaShort: "Drac",
			monsterMummyShort: "Mummy",
			monsterFrankensteinShort: "Frank",
			monsterCreatureShort: "Creature",
			monsterWolfmanShort: "Wolfman",
			monsterInvisiblemanShort: "Invis",
			monsterFrankShort: "Monster",
			monsterBrideShort: "Bride",
			monsterDraculaAdvance: "On a space with a coffin, use any number of red items with a total strength of at least six to smash that coffin.",
			monsterDraculaDefeat: "After all four coffins are smashed, use any number of yellow items with a total strength of at least six on Dracula's space.",
			monsterDraculaPower: "Dark Charm: move the current player's hero to Dracula's space.",
			monsterCreatureAdvance: "At the Camp, use one item of any color to move the boat to the next marker of that color.",
			monsterCreatureDefeat: "After the boat reaches the lair, use one red, one blue, and one yellow item on the Creature's space.",
			monsterCreaturePower: "Move the boat back one stop toward the start.",
			monsterFrankensteinAdvance: "Use a yellow item on the monster's space and a blue item on the Bride's space to raise humanity by their strength and move that monster the same number of steps.",
			monsterFrankensteinDefeat: "After both dials are flipped, the two monsters are defeated immediately while on the same space.",
			monsterFrankensteinPower: "The Bride moves one step toward the monster.",
			monsterMummyAdvance: "At the Museum, use one yellow item to gain scarab moves equal to its strength.",
			monsterMummyDefeat: "After every scarab is in place, use any number of red items with a total strength of at least nine on the Mummy's space.",
			monsterMummyPower: "Flip the lowest-numbered face-up scarab face down.",
			monsterWolfmanAdvance: "At the Laboratory, use one blue item and place it in an empty vial slot matching its strength.",
			monsterWolfmanDefeat: "The hero holding the antidote uses it on the Wolfman's space and discards any number of red items with a total strength of at least six.",
			monsterWolfmanPower: "Every person on the Wolfman's space takes one hit.",
			monsterInvisiblemanAdvance: "At the Police Station, use one item; if its printed space matches an empty clue slot, place it in that slot.",
			monsterInvisiblemanDefeat: "After all five clue slots are filled, use any number of red items with a total strength of at least nine on the Invisible Man's space.",
			monsterInvisiblemanPower: "The Invisible Man moves two steps toward the nearest villager.",
			eventOnTheMove: "On the Move: pass the frenzy marker to the next monster and move a villager one step toward its safe space.",
			eventMeeting: "Meeting: the Bride moves two steps toward the monster.",
			eventHunt: "Hunt: name a hero, and the Wolfman moves three steps toward them.",
			eventThief: "Thief: the Invisible Man moves to the space with the most items and discards every item there.",
			eventRetreatLagoon: "Retreat: the Creature moves to the Lagoon.",
			eventRetreatRiver: "Retreat: the Creature moves to the River.",
			eventRetreatWaterfront: "Retreat: the Creature moves to the Waterfront.",
			eventInnocent: "Innocent: Maria appears at the Barn.",
			eventInsaneSurvivor: "Insane Survivor: Renfield appears at the Docks.",
			eventWorriedFiancee: "Worried Fiancée: Elizabeth appears at the Mansion.",
			eventEnthralled: "Enthralled: Lucy appears at the Theatre.",
			eventDelivery: "Delivery: Wilbur and Chick appear at the Shop.",
			eventFortuneTeller: "Fortune Teller: Maleva appears at the Camp.",
			eventHurriedAssistant: "Hurried Assistant: Fritz appears at the Tower.",
			eventReincarnatedSoul: "Reincarnated Soul: name a hero to hold the soul and move three steps toward the Mummy.",
			eventHypnoticGaze: "Hypnotic Gaze: the person nearest Dracula moves three steps toward Dracula.",
			eventSunrise: "Sunrise: Dracula returns to the Crypt.",
			eventFormOfTheBat: "Form of the Bat: Dracula moves to the current player's hero's space.",
			eventEgyptianExpert: "Egyptian Expert: Professor Pearson appears at the Cave.",
			eventFormerEmployer: "Former Employer: Dr. Cranley appears at the Laboratory.",
			eventIchthyologist: "Ichthyologist: Dr. Reed appears at the Institute.",
			perkBreakOfDawn: "Break of Dawn: skip the next monster phase and draw two items.",
			perkLateNight: "Late Night: gain two extra actions this turn.",
			perkDetective: "Detective Visits: place the Invisible Man on any space, or move any monster three spaces.",
			perkTaxiRide: "Taxi Ride: place one hero on any non-water space.",
			perkCrucifix: "Brandish Crucifix: place Dracula on any space, or move any monster three spaces.",
			perkRush: "Rush: move one hero up to four spaces.",
			perkMobJustice: "Mob Justice: place the monster or the Bride on any space, or move any monster three spaces.",
			perkOverstock: "Overstock: each player draws one item.",
			perkSpecialDelivery: "Special Delivery: one hero may give any number of items to another hero regardless of space.",
			perkHurry: "Hurry: each hero moves up to two spaces.",
			perkInvestigation: "Investigation: choose a space with a hero and place any number of heroes there.",
			perkHuntedPrey: "Hunted Prey: place the Wolfman on any space, or move any monster three spaces.",
			perkAncients: "Ancient Power: place the Mummy on any space, or move any monster three spaces.",
			perkShowForce: "Show of Force: place the Creature on any space, or move any monster three spaces.",
			perkRepel: "Repel: move every monster up to two spaces.",
			logTurnStart: "{{hero}} begins their turn",
			logHeroEnd: "{{hero}} ends their turn",
			logHeroMoved: "{{hero}} moves to {{space}}",
			logVillagerMoved: "{{villager}} moves to {{space}}",
			logPickup: "{{hero}} picks up {{n}} items",
			logItemGiven: "{{hero}} gives an item to {{hero2}}",
			logCureGiven: "{{hero}} gives the antidote to {{hero2}}",
			logAdvance: "{{hero}} uses items to advance {{figure}} by {{n}}",
			logDefeat: "{{hero}} defeats {{monster}}",
			logMonsterDefeated: "{{monster}} is defeated",
			logCoffinBroken: "{{hero}} smashes the coffin at {{space}}",
			logBoatAdvance: "{{hero}} moves the boat to stop {{n}}",
			logBoatBack: "The boat falls back to stop {{n}}",
			logBottleFilled: "{{hero}} fills a vial (needs strength {{n}})",
			logCureTaken: "{{hero}} takes the antidote",
			logSpotFilled: "{{hero}} fills the clue at {{space}}",
			logMummyAdvance: "{{hero}} gains {{n}} scarab moves",
			logScarabSlide: "A scarab slides into an empty position",
			logScarabFlip: "A scarab flips face up",
			logScarabFlipped: "A scarab flips face down",
			logMummyDone: "Scarab moves end",
			logFbFlipped: "The dial of {{figure}} flips over",
			logFbMeet: "The two monsters meet, and terror rises",
			logFbDefeated: "The two monsters reunite, and the monster is defeated",
			logItemPlaced: "{{item}} appears at {{space}}",
			logTerror: "Terror rises by {{n}}",
			logHeroDefeated: "{{hero}} is defeated",
			logVillagerDefeated: "{{villager}} is defeated",
			logVillagerPlaced: "{{villager}} appears at {{space}}",
			logRescued: "{{villager}} is rescued",
			logRevived: "{{hero}} revives in the Hospital",
			logMonsterCard: "Monster card {{n}} is revealed",
			logMonsterMoved: "{{figure}} moves to {{space}}",
			logMonsterSkipped: "This monster phase is skipped",
			logMonsterWillSkip: "The next monster phase will be skipped",
			logRoll: "{{figure}} rolls {{n}} hits and {{n2}} powers",
			logHitHero: "{{hero}} is hit",
			logHitVillager: "{{villager}} is hit",
			logDefended: "{{hero}} discards {{item}} to cancel the hit",
			logCharmed: "{{hero}} is charmed to {{space}}",
			logHunted: "{{hero}} is hunted by the Wolfman",
			logSoul: "{{hero}} takes the soul",
			logFrenzyMoved: "The frenzy marker moves to {{monster}}",
			logPerkGain: "{{hero}} gains the perk {{perk}}",
			logPerkPlayed: "{{perk}} is played",
			logActions: "Gain {{n}} extra actions",
			logThief: "The Invisible Man steals the items at {{space}}",
			logEventIgnored: "{{monster}} is not in this game, and the event is ignored",
			logWin: "Victory: every monster is defeated",
			logLose: "Defeat",
			logFrenzy: "The frenzy marker is on {{monster}}",
			logMoved: "{{figure}} moves to {{space}}",
			logAttack: "{{figure}} attacks {{who}}"
		}
	}
};
//#endregion
export { Er as default };
