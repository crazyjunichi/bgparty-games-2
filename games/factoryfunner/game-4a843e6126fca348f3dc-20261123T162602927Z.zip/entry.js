import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as f, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
//#region src/game/tiles.ts
var g = [
	"N",
	"NE",
	"SE",
	"S",
	"SW",
	"NW"
], _ = (e, t, n) => ({
	edge: e,
	kind: "in",
	colors: [t],
	n
}), v = (e, t, n) => ({
	edge: e,
	kind: "out",
	colors: [t],
	n
}), y = (e) => ({
	edge: e,
	kind: "out",
	colors: ["black"],
	n: 1
}), b = [
	{
		id: 1,
		name: "Reduc-Tank",
		rev: 5,
		ports: [_("SW", "yellow", 3), v("SE", "blue", 1)]
	},
	{
		id: 2,
		name: "Packmaster",
		rev: 9,
		ports: [
			_("NE", "yellow", 3),
			_("SE", "blue", 2),
			y("SW")
		]
	},
	{
		id: 3,
		name: "The Judger",
		rev: 7,
		ports: [_("N", "blue", 1), v("SW", "yellow", 1)]
	},
	{
		id: 4,
		name: "Compressor",
		rev: 3,
		ports: [_("SW", "pink", 3), v("NE", "yellow", 2)]
	},
	{
		id: 5,
		name: "Crystalizer",
		rev: 8,
		ports: [
			_("N", "yellow", 3),
			_("NE", "green", 3),
			y("SW")
		]
	},
	{
		id: 6,
		name: "Smileificator",
		rev: 7,
		ports: [
			_("SW", "blue", 3),
			_("SE", "yellow", 1),
			v("N", "pink", 3)
		]
	},
	{
		id: 7,
		name: "Piper",
		rev: 4,
		ports: [
			_("NE", "pink", 3),
			_("SE", "blue", 2),
			v("SW", "yellow", 3)
		]
	},
	{
		id: 8,
		name: "Vinylnator",
		rev: 8,
		ports: [
			_("N", "pink", 2),
			_("SE", "yellow", 2),
			v("SW", "blue", 2)
		]
	},
	{
		id: 9,
		name: "Rainbowrizer",
		rev: 6,
		ports: [
			_("N", "pink", 3),
			_("NW", "yellow", 1),
			{
				edge: "SE",
				kind: "out",
				colors: [
					"pink",
					"yellow",
					"green",
					"blue"
				],
				n: 1
			}
		]
	},
	{
		id: 10,
		name: "Thinktank",
		rev: 9,
		ports: [
			_("N", "blue", 3),
			_("SE", "green", 2),
			v("SW", "blue", 1)
		]
	},
	{
		id: 11,
		name: "D-6 Quantizer",
		rev: 6,
		ports: [
			_("SW", "pink", 3),
			_("SE", "yellow", 3),
			v("N", "green", 2)
		]
	},
	{
		id: 12,
		name: "Nautilus",
		rev: 6,
		ports: [_("SE", "blue", 2), v("SW", "pink", 1)]
	},
	{
		id: 13,
		name: "Focuser",
		rev: 2,
		ports: [_("SW", "yellow", 2), v("N", "green", 3)]
	},
	{
		id: 14,
		name: "Explosor",
		rev: 8,
		ports: [
			_("SW", "pink", 1),
			_("SE", "blue", 1),
			v("N", "blue", 3)
		]
	},
	{
		id: 15,
		name: "Accelerator",
		rev: 6,
		ports: [
			_("NE", "green", 1),
			_("SE", "pink", 2),
			v("NW", "pink", 3)
		]
	},
	{
		id: 16,
		name: "DasHulk",
		rev: 6,
		ports: [
			_("N", "pink", 3),
			_("NW", "yellow", 1),
			v("SE", "yellow", 3)
		]
	},
	{
		id: 17,
		name: "Metamorphozor",
		rev: 10,
		ports: [
			_("N", "yellow", 1),
			_("NE", "pink", 1),
			v("SW", "yellow", 1)
		]
	},
	{
		id: 18,
		name: "BoxerX",
		rev: 7,
		ports: [
			_("NE", "green", 3),
			_("SE", "blue", 3),
			v("NW", "pink", 1)
		]
	},
	{
		id: 19,
		name: "Multiplier",
		rev: 5,
		ports: [_("SE", "pink", 1), v("N", "pink", 2)]
	},
	{
		id: 20,
		name: "Trifurnace",
		rev: 7,
		ports: [
			_("NE", "blue", 1),
			_("SE", "yellow", 3),
			v("SW", "blue", 2)
		]
	},
	{
		id: 21,
		name: "Ringmaster",
		rev: 7,
		ports: [
			_("NE", "yellow", 2),
			_("SE", "blue", 1),
			v("NW", "green", 3)
		]
	},
	{
		id: 22,
		name: "Shredder",
		rev: 13,
		ports: [
			_("N", "yellow", 1),
			_("NE", "pink", 3),
			_("SE", "blue", 2),
			v("SW", "green", 1)
		]
	},
	{
		id: 23,
		name: "Rebuilder",
		rev: 8,
		ports: [
			_("N", "blue", 2),
			{
				edge: "NE",
				kind: "in",
				colors: ["pink", "yellow"],
				n: 2
			},
			y("SW")
		]
	},
	{
		id: 24,
		name: "Boilnado",
		rev: 4,
		ports: [_("SE", "green", 1), v("NW", "blue", 3)]
	},
	{
		id: 25,
		name: "Cwalichecker",
		rev: 14,
		ports: [
			_("N", "blue", 1),
			_("NE", "green", 3),
			_("SE", "yellow", 1),
			y("SW")
		]
	},
	{
		id: 26,
		name: "Umeaker",
		rev: 7,
		ports: [
			_("NE", "blue", 3),
			_("SE", "green", 1),
			v("NW", "pink", 1),
			v("SW", "yellow", 2)
		]
	},
	{
		id: 27,
		name: "Magnetizer",
		rev: 9,
		ports: [
			_("NW", "green", 1),
			_("SW", "blue", 1),
			v("NE", "pink", 2)
		]
	},
	{
		id: 28,
		name: "Time Machine",
		rev: 7,
		ports: [_("NW", "green", 1), y("SE")]
	},
	{
		id: 29,
		name: "Conservator",
		rev: 12,
		ports: [
			_("N", "pink", 2),
			_("NW", "yellow", 2),
			_("SW", "green", 1),
			v("SE", "pink", 2)
		]
	},
	{
		id: 30,
		name: "Freedomizer",
		rev: 11,
		ports: [
			_("N", "green", 2),
			_("NW", "blue", 1),
			_("SW", "pink", 1),
			v("SE", "yellow", 3)
		]
	},
	{
		id: 31,
		name: "Hexopacker",
		rev: 13,
		ports: [
			_("N", "pink", 1),
			_("SE", "blue", 1),
			y("SW")
		]
	},
	{
		id: 32,
		name: "Retrofactor",
		rev: 9,
		ports: [
			_("N", "blue", 2),
			_("NE", "yellow", 2),
			v("SW", "green", 1)
		]
	},
	{
		id: 33,
		name: "Max-X-Boil",
		rev: 9,
		ports: [
			_("NE", "yellow", 3),
			_("SE", "pink", 1),
			v("SW", "blue", 1)
		]
	},
	{
		id: 34,
		name: "Uberlight",
		rev: 8,
		ports: [
			_("SW", "green", 3),
			_("NW", "yellow", 1),
			v("SE", "pink", 2)
		]
	},
	{
		id: 35,
		name: "Pixellator",
		rev: 7,
		ports: [
			_("NE", "blue", 2),
			_("SE", "pink", 2),
			v("SW", "green", 2)
		]
	},
	{
		id: 36,
		name: "Boom Tube",
		rev: 7,
		ports: [
			_("NE", "blue", 3),
			_("SE", "yellow", 2),
			v("SW", "yellow", 1)
		]
	},
	{
		id: 37,
		name: "Lavafuzer",
		rev: 9,
		ports: [
			_("N", "blue", 2),
			_("SE", "green", 3),
			v("SW", "yellow", 1)
		]
	},
	{
		id: 38,
		name: "Mondrianator",
		rev: 10,
		ports: [
			_("NW", "green", 2),
			_("SW", "blue", 2),
			y("SE")
		]
	},
	{
		id: 39,
		name: "Meepler",
		rev: 8,
		ports: [
			_("NW", "pink", 3),
			_("SW", "green", 1),
			v("NE", "yellow", 2)
		]
	},
	{
		id: 40,
		name: "Ectotrapper",
		rev: 7,
		ports: [
			_("NW", "pink", 1),
			_("SW", "yellow", 1),
			v("SE", "green", 3)
		]
	},
	{
		id: 41,
		name: "Zapp3000",
		rev: 10,
		ports: [
			_("N", "pink", 3),
			_("SE", "green", 1),
			v("SW", "green", 1)
		]
	},
	{
		id: 42,
		name: "Meltdown",
		rev: 7,
		ports: [
			_("N", "green", 3),
			_("NE", "blue", 1),
			v("SW", "yellow", 1)
		]
	},
	{
		id: 43,
		name: "Spectrumizer",
		rev: 9,
		ports: [
			_("NW", "yellow", 2),
			_("SW", "green", 2),
			v("NE", "pink", 1)
		]
	},
	{
		id: 44,
		name: "Maxi Mixer",
		rev: 5,
		ports: [
			_("N", "green", 2),
			_("NE", "pink", 2),
			v("SW", "blue", 3)
		]
	},
	{
		id: 45,
		name: "Supersealer",
		rev: 12,
		ports: [
			_("NE", "green", 2),
			_("SE", "pink", 1),
			y("SW")
		]
	},
	{
		id: 46,
		name: "Bagmeister",
		rev: 11,
		ports: [
			_("NW", "yellow", 1),
			_("SW", "pink", 3),
			y("SE")
		]
	},
	{
		id: 47,
		name: "Dissip-82",
		rev: 8,
		ports: [
			_("NW", "green", 1),
			_("SW", "yellow", 2),
			v("NE", "blue", 2)
		]
	},
	{
		id: 48,
		name: "Moisture-rizer",
		rev: 6,
		ports: [
			_("N", "blue", 3),
			_("NE", "green", 2),
			v("SW", "green", 2)
		]
	}
], x = Object.fromEntries(b.map((e) => [e.id, e])), S = (e) => g.indexOf(e), C = (e, t) => g[(S(e) + t) % 6];
function ee(e) {
	return e.ports.map((e, t) => e.colors.length > 1 ? t : -1).filter((e) => e >= 0);
}
//#endregion
//#region src/game/board.ts
var w = Math.sqrt(3), T = (e, t) => `${e},${t}`;
function E(e) {
	let [t, n] = e.split(",").map(Number);
	return [t, n];
}
function D(e, t) {
	return [1.5 * e, w * (t + e / 2)];
}
var O = {
	N: [0, -1],
	NE: [1, -1],
	SE: [1, 0],
	S: [0, 1],
	SW: [-1, 1],
	NW: [-1, 0]
}, k = {
	N: "S",
	S: "N",
	NE: "SW",
	SW: "NE",
	SE: "NW",
	NW: "SE"
};
function A(e, t) {
	let [n, r] = E(e), [i, a] = O[t];
	return T(n + i, r + a);
}
function j(e) {
	switch (e) {
		case "N": return [0, -w / 2];
		case "S": return [0, w / 2];
		case "NE": return [.75, -w / 4];
		case "NW": return [-.75, -w / 4];
		case "SE": return [.75, w / 4];
		case "SW": return [-.75, w / 4];
	}
}
function M(e, t) {
	return (Math.abs(e) + Math.abs(t) + Math.abs(e + t)) / 2;
}
var te = T(0, 0), ne = (() => {
	let e = [];
	for (let t = -3; t <= 3; t++) for (let n = -3; n <= 3; n++) M(t, n) <= 3 && e.push(T(t, n));
	return e;
})(), N = new Set(ne.filter((e) => e !== te));
function re(e, t, n) {
	return e.length === 1 ? e[0] : n?.[t] ?? e[0];
}
function P(e, t) {
	let n = x[e];
	return n ? t === void 0 || t.length === n.ports.length && n.ports.every((e, n) => e.colors.includes(t[n])) : !1;
}
function F(e) {
	return x[e.id].ports.map((t, n) => ({
		edge: C(t.edge, e.rot),
		kind: t.kind,
		color: re(t.colors, n, e.portColors),
		n: t.n
	}));
}
function I(e) {
	return e.kind === "machine" ? F(e).map((e) => ({
		edge: e.edge,
		color: e.color,
		kind: e.kind,
		n: e.n
	})) : g.map((t) => ({
		edge: t,
		color: e.color
	}));
}
function ie(e) {
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e)) for (let e of I(r)) {
		let r = `${n}|${e.edge}`;
		t.set(r, {
			key: r,
			cell: n,
			edge: e.edge,
			color: e.color,
			kind: e.kind,
			n: e.n
		});
	}
	return t;
}
var L = class {
	parent = /* @__PURE__ */ new Map();
	find(e) {
		let t = e;
		for (;;) {
			let e = this.parent.get(t);
			if (e === void 0) {
				this.parent.set(t, t);
				break;
			}
			if (e === t) break;
			t = e;
		}
		let n = e;
		for (; n !== t;) {
			let e = this.parent.get(n);
			this.parent.set(n, t), n = e;
		}
		return t;
	}
	union(e, t) {
		let n = this.find(e), r = this.find(t);
		n !== r && this.parent.set(n, r);
	}
};
function R(e) {
	let t = ie(e), n = new L();
	for (let [t, r] of Object.entries(e)) {
		if (r.kind === "machine") continue;
		let e = g.map((e) => `${t}|${e}`);
		for (let t = 1; t < e.length; t++) n.union(e[0], e[t]);
	}
	for (let e of t.values()) {
		let r = A(e.cell, e.edge), i = t.get(`${r}|${k[e.edge]}`);
		i && i.color === e.color && n.union(e.key, i.key);
	}
	let r = /* @__PURE__ */ new Map(), i = (e) => {
		let t = r.get(e);
		return t || (t = {
			outCap: 0,
			demand: 0,
			hasSupply: !1,
			hasSink: !1,
			hasMachinePort: !1,
			outPorts: [],
			inPorts: [],
			pipeCells: [],
			supplyCells: [],
			outputCells: []
		}, r.set(e, t)), t;
	};
	for (let e of t.values()) {
		let t = i(n.find(e.key));
		e.kind === "out" ? (t.outCap += e.n ?? 1, t.hasMachinePort = !0, t.outPorts.push(e)) : e.kind === "in" && (t.demand += e.n ?? 1, t.hasMachinePort = !0, t.inPorts.push(e));
	}
	for (let [t, r] of Object.entries(e)) {
		let e = i(n.find(`${t}|${g[0]}`));
		r.kind === "supply" ? (e.hasSupply = !0, e.supplyCells.push(t)) : r.kind === "output" ? (e.hasSink = !0, e.outputCells.push(t)) : r.kind === "pipe" && e.pipeCells.push(t);
	}
	return {
		nodes: t,
		dsu: n,
		comps: r
	};
}
function ae(e) {
	let { comps: t } = R(e);
	return [...t.values()].map((e) => ({
		supplyCells: e.supplyCells,
		outputCells: e.outputCells,
		pipeCells: e.pipeCells,
		inPorts: e.inPorts.map((e) => ({
			cell: e.cell,
			edge: e.edge,
			color: e.color,
			n: e.n ?? 1
		})),
		outPorts: e.outPorts.map((e) => ({
			cell: e.cell,
			edge: e.edge,
			color: e.color,
			n: e.n ?? 1
		}))
	}));
}
function z(e) {
	let { dsu: t, comps: n } = R(e), r = {}, i = {}, a = 0, o = (e) => ({
		ok: !1,
		error: e,
		chipDots: 0,
		machines: r,
		chipsByMachine: i
	}), s = (e) => t.find(e);
	for (let e of n.values()) {
		if (e.outPorts.length > 0 && e.outCap > e.demand && !e.hasSink) return o("outputDead");
		if (e.supplyCells.length > 0 && (e.demand === 0 || e.outCap > 0)) return o(e.outCap > 0 ? "merge" : "supplyDead");
		if (e.outputCells.length > 0 && e.outCap === 0) return o("sinkDead");
		if (e.pipeCells.length > 0 && !e.hasMachinePort) return o("pipeDead");
		if (e.inPorts.length > 0) {
			if (e.hasSupply && e.outCap > 0) return o("merge");
			if (!e.hasSupply) {
				if (e.outCap < e.demand) return o("noSource");
				for (let t of e.inPorts) i[t.cell] = (i[t.cell] ?? 0) + (t.n ?? 1), a += t.n ?? 1;
			}
		}
	}
	for (let [t, n] of Object.entries(e)) {
		if (n.kind !== "machine") continue;
		let e = F(n);
		for (let n = 0; n < e.length; n++) for (let r = 0; r < e.length; r++) if (e[n].kind === "in" && e[r].kind === "out" && e[n].color === e[r].color && s(`${t}|${e[n].edge}`) === s(`${t}|${e[r].edge}`)) return o("perpetual");
		r[t] = !0;
	}
	return {
		ok: !0,
		chipDots: a,
		machines: r,
		chipsByMachine: i
	};
}
function oe(e, t, n, r, i, a, o) {
	let s = { ...e };
	for (let e of o) delete s[e];
	s[n] = {
		kind: "machine",
		id: t,
		rot: r,
		portColors: i
	};
	for (let e of a) e.kind === "supply" ? s[e.cell] = {
		kind: "supply",
		color: e.color
	} : e.kind === "output" ? s[e.cell] = {
		kind: "output",
		color: e.color
	} : s[e.cell] = {
		kind: "pipe",
		color: e.color
	};
	return s;
}
function B(e) {
	return Object.values(e).filter((e) => e.kind === "output" && e.color !== "black").length;
}
function V(e) {
	let t = {
		pink: 0,
		yellow: 0,
		green: 0,
		blue: 0
	};
	for (let n of Object.values(e)) n.kind === "supply" && (t[n.color] += 1);
	return t;
}
//#endregion
//#region src/game/meta.ts
var se = {
	id: "factoryfunner",
	uuid: "9880c7ad-aeac-445b-820b-ad9787c1716e",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"engine-building",
		"route-building"
	],
	interactionTags: [],
	nameKey: "games.factoryfunner.name",
	descKey: "games.factoryfunner.desc",
	rulesKey: "games.factoryfunner.rules",
	icon: "🏭",
	iconImg: "games/factoryfunner.webp",
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	accent: "#c2410c",
	releasedAt: "2026-11-23T15:40:17+08:00",
	search: {
		py: "gong chang le fan tian",
		init: "gclft"
	},
	hotseat: "open"
}, ce = t.enum([
	"pink",
	"yellow",
	"green",
	"blue"
]), H = t.enum([
	"pink",
	"yellow",
	"green",
	"blue",
	"black"
]);
t.enum([
	"N",
	"NE",
	"SE",
	"S",
	"SW",
	"NW"
]);
var U = t.string().regex(/^-?\d+,-?\d+$/), le = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("machine"),
		id: t.int().min(1).max(48),
		rot: t.int().min(0).max(5),
		portColors: t.array(H).optional()
	}),
	t.object({
		kind: t.literal("supply"),
		color: ce
	}),
	t.object({
		kind: t.literal("output"),
		color: H
	}),
	t.object({
		kind: t.literal("pipe"),
		color: H
	})
]), ue = t.object({
	cell: U,
	kind: t.enum([
		"supply",
		"output",
		"pipe"
	]),
	color: H
}), de = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("build"),
		machine: t.int().min(1).max(48),
		cell: U,
		rot: t.int().min(0).max(5),
		portColors: t.array(H).optional(),
		add: t.array(ue).max(30),
		remove: t.array(U).max(30)
	}),
	t.object({
		type: t.literal("skip"),
		machine: t.int().min(1).max(48).optional()
	}),
	t.object({
		type: t.literal("recolor"),
		cell: U,
		portColors: t.array(H).min(1).max(6)
	})
]), W = t.string(), fe = t.object({
	phase: t.enum(["play", "done"]),
	actor: W.optional(),
	round: t.int().min(0),
	players: t.array(t.object({
		rid: W,
		money: t.number(),
		turns: t.int().min(0)
	})),
	display: t.array(t.int().min(1).max(48)),
	deckCount: t.int().min(0),
	boards: t.record(W, t.record(U, le))
}), G = t.object({}), K = 3;
function q(t, n) {
	let r = [...t], i = 0;
	for (let t = r.length - 1; t > 0; --t) {
		let a = e(n, i, t + 1);
		i += 1, [r[t], r[a]] = [r[a], r[t]];
	}
	return {
		order: r,
		cursor: i
	};
}
function pe(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function me(e) {
	return Object.values(e.turnsTaken).reduce((e, t) => e + t, 0);
}
function J(t, n, r) {
	let { order: i, cursor: a } = q(b.map((e) => e.id), r), o = i, s = [];
	for (; s.length < K && o.length > 0;) s.push(o.pop());
	let c = e(r, a, n.length);
	return {
		state: {
			seed: r,
			rngCursor: a + 1,
			players: n,
			phase: "play",
			turnIdx: c,
			turnsTaken: Object.fromEntries(n.map((e) => [e, 0])),
			deck: o,
			display: s,
			discard: [],
			boards: Object.fromEntries(n.map((e) => [e, {}])),
			money: Object.fromEntries(n.map((e) => [e, 10]))
		},
		fx: []
	};
}
function he(e) {
	for (; e.display.length < K;) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) return;
			e.deck = pe(e, e.discard), e.discard = [];
		}
		e.display.push(e.deck.pop());
	}
}
function ge(e) {
	let t = e.players[e.turnIdx];
	e.turnsTaken[t] += 1;
	let n = e.players.length;
	for (let t = 1; t <= n; t += 1) {
		let r = (e.turnIdx + t) % n;
		if (e.turnsTaken[e.players[r]] < 8) {
			e.turnIdx = r;
			return;
		}
	}
	e.phase = "done";
}
function _e(e, t) {
	let n = e.players[e.turnIdx], r = e.boards[n];
	if (!e.display.includes(t.machine)) return { code: "games.factoryfunner.errNoSuchMachine" };
	if (!N.has(t.cell)) return { code: "games.factoryfunner.errBadCell" };
	if (!P(t.machine, t.portColors)) return { code: "games.factoryfunner.errBadPortColors" };
	let i = new Set(t.remove);
	for (let e of i) {
		let t = r[e];
		if (!t) return { code: "games.factoryfunner.errNothingToRemove" };
		if (t.kind === "machine") return { code: "games.factoryfunner.errCannotMoveMachine" };
	}
	let a = (e) => !N.has(e) || !!r[e] && !i.has(e);
	if (a(t.cell)) return { code: "games.factoryfunner.errCellOccupied" };
	let o = /* @__PURE__ */ new Set();
	for (let e of t.add) {
		if (e.cell === t.cell || o.has(e.cell)) return { code: "games.factoryfunner.errCellOccupied" };
		if (o.add(e.cell), e.kind === "supply" && e.color === "black") return { code: "games.factoryfunner.errBadSupply" };
		if (a(e.cell)) return { code: "games.factoryfunner.errCellOccupied" };
	}
	return ve(oe(r, t.machine, t.cell, t.rot, t.portColors, t.add, t.remove));
}
function ve(e) {
	if (B(e) > 3) return { code: "games.factoryfunner.errTooManyWhite" };
	let t = V(e);
	for (let e of [
		"pink",
		"yellow",
		"green",
		"blue"
	]) if (t[e] > 1) return { code: "games.factoryfunner.errDuplicateSupply" };
	let n = z(e);
	return n.ok ? null : {
		overlap: { code: "games.factoryfunner.errCellOccupied" },
		outputDead: { code: "games.factoryfunner.errOutputDead" },
		merge: { code: "games.factoryfunner.errMerge" },
		perpetual: { code: "games.factoryfunner.errPerpetual" },
		noSource: { code: "games.factoryfunner.errNoSource" },
		supplyDead: { code: "games.factoryfunner.errDeadPiece" },
		sinkDead: { code: "games.factoryfunner.errDeadPiece" },
		pipeDead: { code: "games.factoryfunner.errDeadPiece" }
	}[n.error ?? "noSource"] ?? { code: "games.factoryfunner.errNoSource" };
}
function ye(e, t, n) {
	if (e.phase !== "play") return { code: "games.factoryfunner.errPhase" };
	let r = e.players[e.turnIdx];
	if (n.by !== r) return { code: "games.factoryfunner.errNotYourTurn" };
	let i = structuredClone(e);
	if (t.type === "skip") {
		if (t.machine !== void 0) {
			if (!i.display.includes(t.machine)) return { code: "games.factoryfunner.errNoSuchMachine" };
			i.display = i.display.filter((e) => e !== t.machine), i.discard.push(t.machine), he(i);
		}
		return ge(i), {
			state: i,
			fx: [{
				kind: "ffSkip",
				rid: r
			}]
		};
	}
	if (t.type === "recolor") {
		let e = i.boards[r], n = e[t.cell];
		if (!n || n.kind !== "machine") return { code: "games.factoryfunner.errNoMachineHere" };
		if (!P(n.id, t.portColors)) return { code: "games.factoryfunner.errBadPortColors" };
		let a = {
			...e,
			[t.cell]: {
				...n,
				portColors: [...t.portColors]
			}
		};
		return ve(a) || (i.boards[r] = a, {
			state: i,
			fx: []
		});
	}
	let a = _e(e, t);
	if (a) return a;
	let o = i.boards[r];
	i.boards[r] = oe(o, t.machine, t.cell, t.rot, t.portColors, t.add, t.remove);
	let s = x[t.machine].rev, c = t.add.length;
	i.money[r] += s - c, i.display = i.display.filter((e) => e !== t.machine), he(i), ge(i);
	let l = [{
		kind: "ffBuild",
		rid: r,
		data: {
			machine: t.machine,
			cell: t.cell,
			rot: t.rot,
			add: t.add.length,
			rev: s,
			cost: c
		}
	}];
	return i.phase === "done" && l.push({ kind: "gameEnd" }), {
		state: i,
		fx: l
	};
}
function be(e) {
	return {
		public: {
			phase: e.phase,
			actor: e.phase === "play" ? e.players[e.turnIdx] : void 0,
			round: Math.floor(me(e) / e.players.length) + 1,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				turns: e.turnsTaken[t]
			})),
			display: e.display,
			deckCount: e.deck.length,
			boards: e.boards
		},
		private: {}
	};
}
function xe(e, t) {
	let n = z(e.boards[t]).chipDots;
	return {
		score: e.money[t] + 3 * n,
		chips: n
	};
}
function Y(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = xe(e, n).score;
	let n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
var Se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: se,
	schemas: {
		action: de,
		publicView: fe,
		privateView: G
	},
	setup: J,
	reduce: ye,
	viewFor: be,
	status: Y
}, X = {
	pink: "#e0629a",
	yellow: "#e7b53a",
	green: "#57b06a",
	blue: "#4a86d8",
	black: "#23262e"
}, Ce = Array.from({ length: 6 }, (e, t) => {
	let n = Math.PI / 3 * t;
	return [Math.cos(n), Math.sin(n)];
}), Z = (e, t, n = 1) => Ce.map(([r, i]) => `${(e + r * n).toFixed(3)},${(t + i * n).toFixed(3)}`).join(" "), Q = .6, $ = .055, we = .055, Te = .26, Ee = 10, De = 8, Oe = {
	x: -6.6,
	y: -7.2,
	w: 13.2,
	h: 14.4
};
function ke({ edge: e, kind: t, n: r, colors: i, radius: a, cx: o, cy: s }) {
	let [c, l] = j(e), u = Math.atan2(l, c) * 180 / Math.PI + 90, d = a * $ * 2, f = d + a * we, p = a * Te, g = t === "in" ? (r - 1) * f + d + a * .16 : a * .34, _ = "ffp" + n().replace(/[^a-zA-Z0-9_-]/g, "");
	return /* @__PURE__ */ h("g", {
		transform: `translate(${(o + c * a * Q).toFixed(3)} ${(s + l * a * Q).toFixed(3)}) rotate(${u.toFixed(1)})`,
		children: [
			/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ m("clipPath", {
				id: _,
				children: /* @__PURE__ */ m("rect", {
					x: -g / 2,
					y: -p / 2,
					width: g,
					height: p,
					rx: p / 2
				})
			}) }),
			/* @__PURE__ */ m("rect", {
				x: -g / 2,
				y: -p / 2,
				width: g,
				height: p,
				rx: p / 2,
				fill: X[i[0] ?? "black"],
				stroke: "#23262e",
				strokeWidth: a * .035
			}),
			i.length > 1 && /* @__PURE__ */ m("g", {
				clipPath: `url(#${_})`,
				children: i.map((e, t) => /* @__PURE__ */ m("rect", {
					x: -g / 2 + t * g / i.length,
					y: -p / 2,
					width: g / i.length,
					height: p,
					fill: X[e]
				}, e))
			}),
			t === "in" ? Array.from({ length: r }, (e, t) => /* @__PURE__ */ m("circle", {
				cx: (t - (r - 1) / 2) * f,
				cy: 0,
				r: a * $ * .82,
				fill: "#fdfbf4",
				stroke: "#3a3326",
				strokeWidth: a * .012
			}, t)) : /* @__PURE__ */ m("text", {
				x: 0,
				y: 0,
				textAnchor: "middle",
				dominantBaseline: "central",
				className: "ff-port-num",
				style: { fontSize: a * .2 },
				children: r
			})
		]
	});
}
function Ae({ id: e, rot: t, portColors: n, cx: r, cy: i, radius: a }) {
	let o = x[e];
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("polygon", {
			points: Z(r, i, a),
			className: "ff-hex ff-hex--machine"
		}),
		/* @__PURE__ */ m("polygon", {
			points: Z(r, i, a * .36),
			fill: "#3a3326",
			stroke: "#23262e",
			strokeWidth: a * .02
		}),
		/* @__PURE__ */ m("text", {
			x: r,
			y: i + a * .015,
			className: "ff-machine-rev",
			style: { fontSize: a * .3 },
			textAnchor: "middle",
			dominantBaseline: "middle",
			children: o.rev
		}),
		o.ports.map((e, o) => /* @__PURE__ */ m(ke, {
			edge: C(e.edge, t),
			kind: e.kind,
			n: e.n,
			colors: n ? [re(e.colors, o, n)] : e.colors,
			radius: a,
			cx: r,
			cy: i
		}, o))
	] });
}
function je({ cx: e, cy: t, radius: n, color: r }) {
	return /* @__PURE__ */ m("g", { children: g.map((i) => {
		let [a, o] = j(i);
		return /* @__PURE__ */ m("circle", {
			cx: e + a * n * .9,
			cy: t + o * n * .9,
			r: n * .1,
			fill: X[r]
		}, i);
	}) });
}
function Me({ piece: e, cx: t, cy: n, radius: r }) {
	return e.kind === "machine" ? /* @__PURE__ */ m(Ae, {
		id: e.id,
		rot: e.rot,
		portColors: e.portColors,
		cx: t,
		cy: n,
		radius: r
	}) : e.kind === "supply" ? /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("polygon", {
			points: Z(t, n, r),
			fill: X[e.color],
			stroke: "#23262e",
			strokeWidth: r * .05
		}),
		/* @__PURE__ */ m("circle", {
			cx: t,
			cy: n,
			r: r * .5,
			fill: "none",
			stroke: "#fdfbf4",
			strokeWidth: r * .1,
			opacity: .9
		}),
		/* @__PURE__ */ m("circle", {
			cx: t,
			cy: n,
			r: r * .16,
			fill: "#fdfbf4",
			opacity: .95
		}),
		/* @__PURE__ */ m(je, {
			cx: t,
			cy: n,
			radius: r,
			color: e.color
		})
	] }) : e.kind === "output" ? /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("polygon", {
			points: Z(t, n, r),
			fill: "#fdfbf4",
			stroke: X[e.color],
			strokeWidth: r * .11
		}),
		/* @__PURE__ */ m("circle", {
			cx: t,
			cy: n,
			r: r * .32,
			fill: "none",
			stroke: X[e.color],
			strokeWidth: r * .13
		}),
		/* @__PURE__ */ m(je, {
			cx: t,
			cy: n,
			radius: r,
			color: e.color
		})
	] }) : /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("polygon", {
			points: Z(t, n, r),
			fill: X[e.color],
			stroke: "#23262e",
			strokeWidth: r * .05,
			opacity: .92
		}),
		/* @__PURE__ */ m("line", {
			x1: t - r * .62,
			y1: n,
			x2: t + r * .62,
			y2: n,
			stroke: "#fdfbf4",
			strokeWidth: r * .2,
			opacity: .85,
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ m(je, {
			cx: t,
			cy: n,
			radius: r,
			color: e.color
		})
	] });
}
function Ne(e) {
	return /* @__PURE__ */ m(Pe, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Pe({ pub: e, members: t, myRid: n, send: g }) {
	let _ = c(), v = s((e) => e.locale), [y, b] = o(null), [S, C] = o(null), [w, T] = o([]), [O, k] = o([]), [A, j] = o(null), [M, P] = o(null), [F, I] = o(null), ie = a(null), L = a(null), [R, ae] = o({
		ox: 0,
		oy: 0,
		s: 1
	}), B = e.phase === "play" && e.actor === n, V = i(() => e.boards[n] ?? {}, [e.boards, n]), ce = e.players.reduce((e, t) => e + t.turns, 0), H = `${e.actor ?? ""}:${ce}:${e.phase}`, [U, le] = o(H);
	U !== H && (le(H), b(null), C(null), T([]), k([]), j(null), P(null), I(null));
	let ue = (e) => l[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % l.length].hex, de = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? p(n, v) : e;
	};
	r(() => {
		let e = () => {
			let e = ie.current, t = L.current;
			if (!e || !t) return;
			let n = e.getScreenCTM();
			if (!n) return;
			let r = t.getBoundingClientRect(), i = new DOMPoint(0, 0).matrixTransform(n);
			ae({
				ox: i.x - r.left,
				oy: i.y - r.top,
				s: n.a
			});
		};
		e();
		let t = new ResizeObserver(e);
		return L.current && t.observe(L.current), window.addEventListener("resize", e), () => {
			t.disconnect(), window.removeEventListener("resize", e);
		};
	}, []);
	let W = (e) => R.ox + R.s * e, fe = (e) => R.oy + R.s * e, G = i(() => S ? oe(V, S.machine, S.cell, S.rot, S.portColors, w, O) : null, [
		S,
		V,
		w,
		O
	]), K = G ?? V, q = G ? ve(G) : null, pe = i(() => z(K).chipsByMachine, [K]), me = (e) => x[e].ports.map((e) => e.colors[0]), J = () => {
		b(null), C(null), T([]), k([]), j(null), P(null), I(null);
	}, he = (e) => {
		if (B) {
			if (T([]), k([]), j(null), P(null), I(null), y === e) {
				b(null), C(null);
				return;
			}
			b(e), C(null);
		}
	}, ge = (e) => {
		k((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), j(null);
	}, _e = (e) => {
		let t = V[e];
		return B && !S && t?.kind === "machine" && ee(x[t.id]).length > 0;
	}, ye = (e) => {
		if (!B) return;
		if (!S && _e(e)) {
			P((t) => t === e ? null : e), I(null);
			return;
		}
		if (M && (P(null), I(null)), y === null || !N.has(e)) return;
		let t = V[e];
		if (!S) {
			if (w.some((t) => t.cell === e)) {
				T((t) => t.filter((t) => t.cell !== e));
				return;
			}
			if (t) {
				t.kind !== "machine" && ge(e);
				return;
			}
			C({
				machine: y,
				cell: e,
				rot: 0,
				portColors: me(y)
			});
			return;
		}
		if (e !== S.cell) {
			if (w.some((t) => t.cell === e)) {
				T((t) => t.filter((t) => t.cell !== e));
				return;
			}
			if (t) {
				t.kind !== "machine" && ge(e);
				return;
			}
			j(e);
		}
	}, be = (e) => C((t) => t && {
		...t,
		rot: (t.rot + e + 6) % 6
	}), xe = (e, t) => C((n) => {
		if (!n) return n;
		let r = [...n.portColors];
		return r[e] = t, {
			...n,
			portColors: r
		};
	}), Y = M ? V[M] : void 0, Se = Y?.kind === "machine" ? x[Y.id] : null, X = (e, t) => {
		if (!M || !Y || Y.kind !== "machine") return;
		let n = x[Y.id].ports.map((e, t) => re(e.colors, t, Y.portColors));
		n[e] = t;
		let r = ve({
			...V,
			[M]: {
				...Y,
				portColors: n
			}
		});
		if (r) {
			I(r.code);
			return;
		}
		I(null), g({
			type: "recolor",
			cell: M,
			portColors: n
		});
	}, Ce = () => {
		S && y !== null && !q && e.display.includes(y) && (g({
			type: "build",
			machine: y,
			cell: S.cell,
			rot: S.rot,
			portColors: S.portColors,
			add: w,
			remove: O
		}), J());
	}, Q = (e, t) => {
		A && (T((n) => [...n, {
			cell: A,
			kind: e,
			color: t
		}]), j(null));
	}, $ = B ? "accent" : "info", we = B ? _(y ? S ? "games.factoryfunner.stageConnect" : "games.factoryfunner.stagePlace" : "games.factoryfunner.stagePick") : _("games.factoryfunner.waitTurn", { name: de(e.actor ?? "") }), Te = G ? z(G).chipDots : z(V).chipDots, ke = e.players.find((e) => e.rid === n)?.money ?? Ee, je = e.players.find((e) => e.rid === n)?.turns ?? 0, Ne = t.filter((t) => e.players.some((e) => e.rid === t.rid));
	return /* @__PURE__ */ m("div", {
		className: "ff-screen",
		children: /* @__PURE__ */ m(d, {
			adaptive: !0,
			className: "ff-game",
			scroll: !1,
			actionsHeight: "ff-actions-slot",
			banner: /* @__PURE__ */ m("div", {
				className: "ff-header",
				children: /* @__PURE__ */ m(u, {
					tone: $,
					text: we,
					chip: _("games.factoryfunner.deckChip", { n: e.deckCount }),
					accent: se.accent
				})
			}),
			actions: /* @__PURE__ */ h("div", {
				className: "ff-actions",
				children: [/* @__PURE__ */ h("div", {
					className: "ff-status",
					children: [
						/* @__PURE__ */ m("span", {
							className: "ff-status__cash",
							children: _("games.factoryfunner.myCash", { n: ke })
						}),
						/* @__PURE__ */ m("span", {
							className: "ff-status__chips",
							children: _("games.factoryfunner.myChips", { n: Te })
						}),
						/* @__PURE__ */ m("span", {
							className: "ff-status__turns",
							children: _("games.factoryfunner.myTurns", {
								n: je,
								total: De
							})
						})
					]
				}), /* @__PURE__ */ h("div", {
					className: "ff-buttons",
					children: [S && /* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-btn ff-btn--cancel",
						onClick: J,
						children: _("games.factoryfunner.cancel")
					}), B && /* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-btn ff-btn--skip",
						disabled: y === null && e.display.length > 0,
						onClick: () => {
							g(y === null ? { type: "skip" } : {
								type: "skip",
								machine: y
							}), J();
						},
						children: _(y === null ? "games.factoryfunner.skip" : "games.factoryfunner.takeOnly")
					})]
				})]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "ff-main",
				children: [
					/* @__PURE__ */ h("div", {
						className: "ff-display",
						role: "list",
						children: [e.display.map((e) => {
							let t = x[e], n = y === e;
							return /* @__PURE__ */ h("button", {
								type: "button",
								role: "listitem",
								className: `ff-card${n ? " is-selected" : ""}`,
								disabled: !(B && !S),
								"aria-pressed": n,
								"aria-label": _("games.factoryfunner.machineCardAria", {
									name: t.name,
									rev: t.rev
								}),
								onClick: () => he(e),
								children: [/* @__PURE__ */ m("svg", {
									viewBox: "-1.15 -1.15 2.3 2.3",
									className: "ff-card__svg",
									"aria-hidden": !0,
									children: /* @__PURE__ */ m(Ae, {
										id: e,
										rot: 0,
										cx: 0,
										cy: 0,
										radius: 1
									})
								}), /* @__PURE__ */ m("span", {
									className: "ff-card__name",
									children: t.name
								})]
							}, e);
						}), e.display.length === 0 && /* @__PURE__ */ m("div", {
							className: "ff-display-empty",
							children: _("games.factoryfunner.deckEmpty")
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "ff-stage",
						children: /* @__PURE__ */ h("div", {
							className: "ff-board-wrap",
							ref: L,
							children: [
								/* @__PURE__ */ m("svg", {
									ref: ie,
									className: "ff-board",
									viewBox: `${Oe.x} ${Oe.y} ${Oe.w} ${Oe.h}`,
									preserveAspectRatio: "xMidYMid meet",
									role: "img",
									"aria-label": _("games.factoryfunner.boardAria"),
									children: ne.map((e) => {
										let [t, n] = E(e), [r, i] = D(t, n);
										if (e === te) return /* @__PURE__ */ h("g", {
											"aria-hidden": !0,
											children: [/* @__PURE__ */ m("polygon", {
												points: Z(r, i, .94),
												className: "ff-hex ff-hex--blocked"
											}), /* @__PURE__ */ m("circle", {
												cx: r,
												cy: i,
												r: .22,
												className: "ff-blocked-mark"
											})]
										}, e);
										let a = K[e], o = B && y !== null, s = _e(e), c = o || s, l = o ? _("games.factoryfunner.cellAria") : s ? _("games.factoryfunner.recolorAria") : void 0;
										return /* @__PURE__ */ h("g", {
											className: `ff-cell${o ? " is-active" : ""}${s ? " is-recolorable" : ""}`,
											onClick: () => ye(e),
											role: c ? "button" : void 0,
											tabIndex: c ? 0 : void 0,
											"aria-label": l,
											onKeyDown: c ? (t) => {
												(t.key === "Enter" || t.key === " ") && (t.preventDefault(), ye(e));
											} : void 0,
											children: [
												/* @__PURE__ */ m("polygon", {
													points: Z(r, i, .96),
													className: "ff-hex ff-hex--cell"
												}),
												a && /* @__PURE__ */ m(Me, {
													piece: a,
													cx: r,
													cy: i,
													radius: .9
												}),
												s && /* @__PURE__ */ m("polygon", {
													points: Z(r, i, .9),
													className: "ff-hex ff-hex--recolor"
												}),
												a?.kind === "machine" && (pe[e] ?? 0) > 0 && /* @__PURE__ */ m(Fe, {
													cell: e,
													piece: a,
													cx: r,
													cy: i,
													radius: .9
												})
											]
										}, e);
									})
								}),
								S && y !== null && /* @__PURE__ */ m(Le, {
									left: W(D(E(S.cell)[0], E(S.cell)[1])[0]),
									top: fe(D(E(S.cell)[0], E(S.cell)[1])[1]),
									below: D(E(S.cell)[0], E(S.cell)[1])[1] < 0,
									def: x[y],
									ghost: S,
									valid: !q,
									errorText: q ? _(q.code, q.params) : null,
									onRotate: be,
									onPortColor: xe,
									onConfirm: Ce,
									onCancel: J
								}),
								A && /* @__PURE__ */ m(ze, {
									left: W(D(E(A)[0], E(A)[1])[0]),
									top: fe(D(E(A)[0], E(A)[1])[1]),
									onPick: Q,
									onClose: () => j(null)
								}),
								M && Se && Y?.kind === "machine" && /* @__PURE__ */ m(Ie, {
									left: W(D(E(M)[0], E(M)[1])[0]),
									top: fe(D(E(M)[0], E(M)[1])[1]),
									def: Se,
									piece: Y,
									errorText: F ? _(F) : null,
									onPick: X,
									onClose: () => {
										P(null), I(null);
									}
								})
							]
						})
					}),
					/* @__PURE__ */ m("ul", {
						className: "ff-players",
						style: { gridTemplateColumns: `repeat(${Ne.length}, minmax(0, 1fr))` },
						children: Ne.map((t) => {
							let r = e.players.find((e) => e.rid === t.rid);
							return /* @__PURE__ */ h("li", {
								className: `ff-player${t.rid === e.actor && e.phase === "play" ? " is-turn" : ""}`,
								style: { "--seat-color": ue(t.rid) },
								children: [
									/* @__PURE__ */ m(f, {
										m: t,
										myRid: n,
										action: t.rid === e.actor && e.phase === "play" ? "pending" : null,
										anchorName: `seat:${t.rid}`,
										box: "ff-player__avatar",
										img: "ff-player__avatar-img"
									}),
									/* @__PURE__ */ m("span", {
										className: "ff-player__name",
										title: de(t.rid),
										children: de(t.rid)
									}),
									/* @__PURE__ */ h("span", {
										className: "ff-player__cash",
										children: ["$", r.money]
									}),
									/* @__PURE__ */ m("span", {
										className: "ff-player__turns",
										children: _("games.factoryfunner.turnsAria", { n: r.turns })
									})
								]
							}, t.rid);
						})
					})
				]
			})
		})
	});
}
function Fe({ cell: e, piece: t, cx: n, cy: r, radius: i }) {
	if (t.kind !== "machine") return null;
	let a = F(t), o = i * $ * 2 + i * we;
	return /* @__PURE__ */ m("g", {
		"aria-hidden": !0,
		children: a.flatMap((t, a) => {
			if (t.kind !== "in") return [];
			let [s, c] = j(t.edge), l = Math.atan2(c, s) * 180 / Math.PI + 90;
			return Array.from({ length: t.n }, (u, d) => /* @__PURE__ */ m("circle", {
				r: i * $ * 1.05,
				fill: "#fdfbf4",
				stroke: "#b8860b",
				strokeWidth: i * .022,
				transform: `translate(${(n + s * i * Q).toFixed(3)} ${(r + c * i * Q).toFixed(3)}) rotate(${l.toFixed(1)}) translate(${((d - (t.n - 1) / 2) * o).toFixed(3)} 0)`
			}, `${e}:${a}:${d}`));
		})
	});
}
function Ie({ left: e, top: t, def: n, piece: r, errorText: i, onPick: a, onClose: o }) {
	let s = c();
	return /* @__PURE__ */ h("div", {
		className: "ff-machine-pop",
		style: {
			left: e,
			top: t
		},
		role: "dialog",
		"aria-label": s("games.factoryfunner.recolorTitle"),
		children: [
			/* @__PURE__ */ h("div", {
				className: "ff-palette__title",
				children: [s("games.factoryfunner.recolorTitle"), /* @__PURE__ */ m("button", {
					type: "button",
					className: "ff-palette__close",
					"aria-label": s("games.factoryfunner.close"),
					onClick: o,
					children: "✕"
				})]
			}),
			ee(n).map((e) => {
				let t = n.ports[e], i = re(t.colors, e, r.portColors);
				return /* @__PURE__ */ h("div", {
					className: "ff-palette__row",
					children: [/* @__PURE__ */ m("span", {
						className: "ff-palette__label",
						children: s(t.kind === "in" ? "games.factoryfunner.portInput" : "games.factoryfunner.portOutput")
					}), t.colors.map((t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `ff-swatch${i === t ? " is-on" : ""}`,
						style: { background: X[t] },
						"aria-label": s(Re[t]),
						"aria-pressed": i === t,
						onClick: () => a(e, t)
					}, t))]
				}, e);
			}),
			i && /* @__PURE__ */ m("div", {
				className: "ff-palette__err",
				role: "status",
				children: i
			})
		]
	});
}
function Le({ left: e, top: t, below: n, def: r, ghost: i, valid: a, errorText: o, onRotate: s, onPortColor: l, onConfirm: u, onCancel: d }) {
	let f = c(), p = r.ports.map((e, t) => e.colors.length > 1 ? t : -1).filter((e) => e >= 0);
	return /* @__PURE__ */ h("div", {
		className: `ff-ghost-tools${n ? " is-below" : ""}`,
		style: {
			left: e,
			top: t
		},
		children: [
			/* @__PURE__ */ h("div", {
				className: "ff-ghost-tools__row",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.rotateLeft"),
						onClick: () => s(-1),
						children: "↺"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.rotateRight"),
						onClick: () => s(1),
						children: "↻"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-tool ff-tool--ok",
						disabled: !a,
						onClick: u,
						"aria-label": a ? f("games.factoryfunner.confirm") : o ?? f("games.factoryfunner.confirm"),
						children: a ? "✓" : "✕"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.cancel"),
						onClick: d,
						children: "✕"
					})
				]
			}),
			p.map((e) => /* @__PURE__ */ m("div", {
				className: "ff-ghost-tools__row ff-ghost-tools__colors",
				children: r.ports[e].colors.map((t) => /* @__PURE__ */ m("button", {
					type: "button",
					className: `ff-swatch${i.portColors[e] === t ? " is-on" : ""}`,
					style: { background: X[t] },
					"aria-label": f(Re[t]),
					"aria-pressed": i.portColors[e] === t,
					onClick: () => l(e, t)
				}, t))
			}, e)),
			o && /* @__PURE__ */ m("div", {
				className: "ff-ghost-tools__err",
				role: "status",
				children: o
			})
		]
	});
}
var Re = {
	pink: "games.factoryfunner.colorPink",
	yellow: "games.factoryfunner.colorYellow",
	green: "games.factoryfunner.colorGreen",
	blue: "games.factoryfunner.colorBlue",
	black: "games.factoryfunner.colorBlack"
};
function ze({ left: e, top: t, onPick: n, onClose: r }) {
	let i = c(), a = [
		{
			kind: "supply",
			label: i("games.factoryfunner.kindSupply"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue"
			]
		},
		{
			kind: "output",
			label: i("games.factoryfunner.kindOutput"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue",
				"black"
			]
		},
		{
			kind: "pipe",
			label: i("games.factoryfunner.kindPipe"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue",
				"black"
			]
		}
	];
	return /* @__PURE__ */ h("div", {
		className: "ff-palette",
		style: {
			left: e,
			top: t
		},
		children: [/* @__PURE__ */ h("div", {
			className: "ff-palette__title",
			children: [i("games.factoryfunner.paletteTitle"), /* @__PURE__ */ m("button", {
				type: "button",
				className: "ff-palette__close",
				"aria-label": i("games.factoryfunner.close"),
				onClick: r,
				children: "✕"
			})]
		}), a.map((e) => /* @__PURE__ */ h("div", {
			className: "ff-palette__row",
			children: [/* @__PURE__ */ m("span", {
				className: "ff-palette__label",
				children: e.label
			}), e.colors.map((t) => /* @__PURE__ */ m("button", {
				type: "button",
				className: "ff-swatch",
				style: { background: X[t] },
				"aria-label": `${e.label} ${i(Re[t])}`,
				onClick: () => n(e.kind, t)
			}, t))]
		}, e.kind))]
	});
}
//#endregion
//#region src/game/bot.ts
var Be = {
	costWeight: 1,
	chipWeight: 2.5,
	spaceWeight: .06,
	maxPipe: 6
};
function Ve(e, t, n) {
	for (let r of I(e)) if (r.edge === t && r.color === n) return { kind: r.kind };
	return null;
}
function He(e, t, n, r) {
	let i = Ve(e, t, n);
	return i ? e.kind === "pipe" ? !0 : r === "in" ? e.kind === "supply" || e.kind === "machine" && i.kind === "out" : e.kind === "output" || e.kind === "machine" && i.kind === "in" : !1;
}
function Ue(e) {
	if (B(e) > 3) return null;
	let t = V(e);
	for (let e of [
		"pink",
		"yellow",
		"green",
		"blue"
	]) if (t[e] > 1) return null;
	let n = z(e);
	return n.ok ? n.chipDots : null;
}
function We(e, t, n, r, i, a, o = !1) {
	if (r[e]) return null;
	let s = /* @__PURE__ */ new Map([[e, null]]), c = /* @__PURE__ */ new Map([[e, 0]]), l = [e], u = null;
	for (; l.length > 0;) {
		let e = l.shift(), d = c.get(e);
		for (let a of g) {
			let s = A(e, a);
			if (s === i) continue;
			let c = r[s];
			if (c && He(c, k[a], t, n) && (!o || c.kind === "supply")) {
				u = e;
				break;
			}
		}
		if (u) break;
		if (!(d >= a)) for (let t of g) {
			let n = A(e, t);
			n === i || !N.has(n) || r[n] || s.has(n) || (s.set(n, e), c.set(n, d + 1), l.push(n));
		}
	}
	if (!u) return null;
	let d = [], f = u;
	for (; f;) d.push(f), f = s.get(f) ?? null;
	return d.map((e) => ({
		cell: e,
		kind: "pipe",
		color: t
	}));
}
function Ge(e, t, n, r, i, a) {
	if (!N.has(e) || !N.has(t) || r[t] || r[e] || e === i || t === i) return null;
	if (e === t) return [{
		cell: e,
		kind: "pipe",
		color: n
	}];
	let o = /* @__PURE__ */ new Map([[e, null]]), s = /* @__PURE__ */ new Map([[e, 0]]), c = [e], l = null;
	for (; c.length > 0;) {
		let e = c.shift(), n = s.get(e);
		for (let n of g) if (A(e, n) === t) {
			l = e;
			break;
		}
		if (l) break;
		if (!(n >= a)) for (let a of g) {
			let l = A(e, a);
			l === t || l === i || !N.has(l) || r[l] || o.has(l) || (o.set(l, e), s.set(l, n + 1), c.push(l));
		}
	}
	if (!l) return null;
	let u = [], d = l;
	for (; d;) u.push(d), d = o.get(d) ?? null;
	return u.map((e) => ({
		cell: e,
		kind: "pipe",
		color: n
	}));
}
function Ke(e, t) {
	let n = new Map(e.adds.map((e) => [e.cell, e]));
	for (let r of t.adds) {
		if (e.removes.includes(r.cell)) return null;
		let t = n.get(r.cell);
		if (t) {
			if (t.kind !== r.kind || t.color !== r.color) return null;
			continue;
		}
		n.set(r.cell, r);
	}
	let r = new Set(e.removes);
	for (let e of t.removes) {
		if (n.has(e)) return null;
		r.add(e);
	}
	return {
		adds: [...n.values()],
		removes: [...r]
	};
}
function qe(e = Be) {
	return function(t, n) {
		let r = t.public;
		if (r.phase !== "play" || r.actor !== n.rid) return null;
		let i = r.boards[n.rid] ?? {};
		if (r.display.length === 0) return { action: { type: "skip" } };
		let a = [], o = [];
		for (let e of ae(i)) {
			if (e.supplyCells.length === 1 && e.inPorts.length === 1 && e.outPorts.length === 0) {
				let t = e.inPorts[0];
				t.color !== "black" && a.push({
					cell: t.cell,
					edge: t.edge,
					color: t.color,
					n: t.n,
					supplyCell: e.supplyCells[0]
				});
			}
			if (e.outputCells.length === 1 && e.outPorts.length === 1 && e.inPorts.length === 0) {
				let t = e.outPorts[0];
				o.push({
					cell: t.cell,
					edge: t.edge,
					color: t.color,
					n: t.n,
					tankCell: e.outputCells[0]
				});
			}
		}
		let s = { v: null }, c = (t, n) => {
			let r = Ue(t);
			if (r === null) return;
			let i = n, a = x[i.machine].rev - i.add.length * e.costWeight + r * e.chipWeight - Object.keys(t).length * e.spaceWeight;
			(!s.v || a > s.v.score) && (s.v = {
				action: n,
				score: a
			});
		};
		for (let t of r.display) {
			let n = x[t];
			for (let r of ne) if (N.has(r) && !i[r]) for (let s = 0; s < 6; s += 1) {
				let l = [], u = !1;
				for (let t of n.ports) {
					let n = A(r, C(t.edge, s));
					if (!N.has(n) || n === r) {
						u = !0;
						break;
					}
					let c = [];
					for (let s of t.colors) {
						if (i[n]) {
							c.push({
								color: s,
								adds: [],
								removes: []
							});
							continue;
						}
						if (c.push({
							color: s,
							adds: [{
								cell: n,
								kind: t.kind === "in" ? "supply" : "output",
								color: s
							}],
							removes: []
						}), t.kind === "in") {
							let a = We(n, s, "in", i, r, e.maxPipe, !0);
							a && c.push({
								color: s,
								adds: a,
								removes: []
							});
							let l = We(n, s, "in", i, r, e.maxPipe);
							l && c.push({
								color: s,
								adds: l,
								removes: []
							});
							for (let a of o) {
								if (a.color !== s || a.n !== t.n) continue;
								let o = Ge(A(a.cell, a.edge), n, s, i, r, e.maxPipe);
								o && c.push({
									color: s,
									adds: o,
									removes: [a.tankCell]
								});
							}
						} else for (let o of a) {
							if (o.color !== s || o.n !== t.n) continue;
							let a = Ge(n, A(o.cell, o.edge), s, i, r, e.maxPipe);
							a && c.push({
								color: s,
								adds: a,
								removes: [o.supplyCell]
							});
						}
					}
					if (c.length === 0) {
						u = !0;
						break;
					}
					l.push(c);
				}
				if (u) continue;
				let d = n.ports.map((e) => e.colors[0]), f = (e, a) => {
					if (e === n.ports.length) {
						let e = oe(i, t, r, s, [...d], a.adds, a.removes);
						c(e, {
							type: "build",
							machine: t,
							cell: r,
							rot: s,
							portColors: [...d],
							add: a.adds,
							remove: a.removes
						});
						return;
					}
					for (let t of l[e]) {
						d[e] = t.color;
						let n = Ke(a, t);
						n && f(e + 1, n);
					}
					d[e] = n.ports[e].colors[0];
				};
				f(0, {
					adds: [],
					removes: []
				});
			}
		}
		if (s.v) return { action: s.v.action };
		let l = r.display[0];
		for (let e of r.display) x[e].rev < x[l].rev && (l = e);
		return { action: {
			type: "skip",
			machine: l
		} };
	};
}
var Je = qe();
//#endregion
//#region src/game/game-over-row.tsx
function Ye({ public: e, rid: t }) {
	let n = c(), r = e, i = r.boards[t] ?? {}, a = z(i).chipDots, o = r.players.find((e) => e.rid === t)?.money ?? 0, s = Object.values(i).filter((e) => e.kind === "machine").length;
	return /* @__PURE__ */ h("div", {
		className: "ff-end",
		children: [/* @__PURE__ */ m(Ze, { board: i }), /* @__PURE__ */ h("div", {
			className: "ff-end__lines",
			children: [
				/* @__PURE__ */ m("span", { children: n("games.factoryfunner.endCash", { n: o }) }),
				/* @__PURE__ */ m("span", { children: n("games.factoryfunner.endChips", {
					n: a,
					score: a * 3
				}) }),
				/* @__PURE__ */ m("span", {
					className: "ff-end__total",
					children: n("games.factoryfunner.endScore", { n: o + a * 3 })
				}),
				/* @__PURE__ */ m("span", {
					className: "ff-end__note",
					children: n("games.factoryfunner.endMachines", { n: s })
				})
			]
		})]
	});
}
var Xe = "-5.7 -6.4 11.4 12.8";
function Ze({ board: e }) {
	return /* @__PURE__ */ m("svg", {
		className: "ff-end__board",
		viewBox: Xe,
		"aria-hidden": !0,
		children: ne.map((t) => {
			let [n, r] = E(t), [i, a] = D(n, r), o = Z(i, a, .92);
			if (t === te) return /* @__PURE__ */ m("polygon", {
				points: o,
				className: "ff-end__hex is-block"
			}, t);
			let s = e[t];
			if (!s) return /* @__PURE__ */ m("polygon", {
				points: o,
				className: "ff-end__hex"
			}, t);
			if (s.kind === "machine") return /* @__PURE__ */ m("polygon", {
				points: o,
				className: "ff-end__hex is-machine"
			}, t);
			let c = s.kind === "output" && s.color !== "black";
			return /* @__PURE__ */ m("polygon", {
				points: o,
				className: "ff-end__hex",
				style: { fill: c ? "#fdfbf4" : X[s.color] },
				stroke: X[s.color],
				strokeWidth: c ? .16 : .08
			}, t);
		})
	});
}
//#endregion
//#region src/index.tsx
var Qe = {
	definition: Se,
	View: Ne,
	bot: Je,
	RowView: Ye,
	locales: {
		zh: {
			name: "工厂乐翻天",
			desc: "选装机器、连接管线，把原料加工成成品，八轮后钱最多者获胜",
			rules: "目标:\n每位玩家经营一座工厂。你在八轮里各选取并安装一台机器，把它接入工厂网络，让原料从供应罐流入机器、加工后再送入下一台机器或输出罐。机器本身带来收入，妥善串联机器还能在终局额外得分，八轮结束后钱最多者获胜。\n准备:\n· 每位玩家拿一块工厂板。工厂板共 37 个六边形格，中央一格为障碍、不能放置任何物件，其余 36 格为可放置的空格。\n· 把全部 48 台机器洗匀，面朝下组成牌堆，从牌堆翻开三台作为公共待选区；被取走一台后，立即从牌堆补一台。\n· 每位玩家的现金从 10 元开始，随机决定起始玩家，之后按座位顺序轮流行动。\n机器板:\n· 每台机器是一块六边形板块。板块边缘的彩色端口中，带白色圆点的一侧是输入端，圆点的数量表示这个端口需要几个单位的原料；带白色数字的一侧是输出端，数字表示这个端口能够产出几个单位的成品。\n· 板块中央的数字是这台机器的收入，安装时立即获得。\n· 有些机器的端口可以用多种颜色，板块上以分色标出可选的颜色。安装时先选定一种颜色。机器安装之后，在轮到自己行动时可以点选这台机器更改这些端口的颜色；改色不消耗行动，但改完之后整座工厂仍然必须保持合法。\n回合:\n每回合，当前玩家从待选区选择一台机器，安装到自己的工厂板上，随即从牌堆补一台到待选区。如果无法把选中的机器合法安装，可以取走这台机器而不安装，不会受到惩罚。当牌堆用尽时，把玩家没有安装的机器重新洗匀，组成新的牌堆。每位玩家各进行八个回合，八轮之后游戏结束。\n安装与花费:\n· 机器可以任意旋转，共有六个朝向。安装机器本身免费，每安装一台立即获得机器板中央标示的收入。\n· 每放置一个储罐或一根管道需要支付 1 元。\n· 机器与储罐只能放在空格上，管道同样占用一个空格。\n· 之前回合安装的机器不能再移动或取回；之前回合放置的储罐与管道可以免费取回。\n连接规则:\n· 机器的每个输入端与输出端都必须接入工厂网络。\n· 输入端要么连接同色的供应储罐，要么由其他机器的同色输出供给。\n· 输出端要么把产物送入其他机器的同色输入端，要么收入同色的输出储罐。\n· 相连的端口颜色必须相同，不能混色。\n· 汇集到一台机器的输入总量不能超过向它供料的输出总量；同一份输出可以拆分供给多台机器。\n· 一台机器的输出不能经由任何路径接回它自己的输入。\n· 不允许死端：任何储罐与管道都必须接入某台机器的端口，所有输出储罐都必须有产物送入。\n储罐与管道:\n· 供应储罐分为粉、黄、绿、蓝四色，每种颜色每位玩家最多放置一个。供应储罐无限产出，可同时供应多台机器，不会消耗。\n· 输出储罐用于收集机器产物。白色输出储罐每位玩家最多放置三个，每个只能收集一种颜色；黑色输出储罐数量不限，只能收集黑色成品。\n· 管道占用一个空格并携带一种颜色，用来把同色端口串联延长；四种颜色不能混用。\n清晰圆片:\n· 当一台机器的输入由其他机器供料、而不是由供应储罐供料时，在它的每个被机器供料的输入点上放一枚清晰圆片。\n· 如果之后改用供应储罐供料，就移除对应的清晰圆片。\n· 每枚清晰圆片按其覆盖的点数，在终局计分时每点计 3 元。\n计分:\n· 八轮全部结束后结算：所有现金加上清晰圆片的计分，总分最高者获胜，并列则共享胜利。",
			deckChip: "牌堆 {{n}}",
			turnChip: "第 {{n}} 回合",
			waitTurn: "等 {{name}} 行动…",
			stagePick: "从待选区选一台机器",
			stagePlace: "点空格安装机器",
			stageConnect: "旋转机器、补上储罐或管道，再确认安装",
			machineCardAria: "{{name}}，收入 {{rev}} 元",
			deckEmpty: "待选区暂无机器",
			turnsAria: "已进行 {{n}} 回合",
			myCash: "现金 {{n}} 元",
			myChips: "圆片 {{n}} 点",
			myTurns: "回合 {{n}} / {{total}}",
			rotateLeft: "逆时针旋转",
			rotateRight: "顺时针旋转",
			confirm: "确认安装",
			cancel: "取消",
			skip: "跳过本回合",
			takeOnly: "取走但不安装",
			boardAria: "你的工厂板",
			cellAria: "工厂格",
			recolorAria: "更改这台机器的端口颜色",
			recolorTitle: "更改端口颜色",
			portInput: "输入",
			portOutput: "输出",
			paletteTitle: "在此格放置部件",
			close: "关闭",
			kindSupply: "供应罐",
			kindOutput: "输出罐",
			kindPipe: "管道",
			colorPink: "粉色",
			colorYellow: "黄色",
			colorGreen: "绿色",
			colorBlue: "蓝色",
			colorBlack: "黑色",
			errNoSuchMachine: "待选区没有这台机器",
			errBadCell: "这格不能放置",
			errNothingToRemove: "这里没有可取回的物件",
			errCannotMoveMachine: "已安装的机器不能移动或取回",
			errCellOccupied: "这格已被占用",
			errTooManyWhite: "白色输出储罐最多三个",
			errDuplicateSupply: "同色供应储罐最多一个",
			errOutputDead: "有产物没有被任何机器或输出储罐接收",
			errMerge: "机器产物与供应储罐不能混接到同一输入端",
			errPerpetual: "机器的输出不能接回它自己的输入",
			errNoSource: "有输入点没有得到足够的供料",
			errDeadPiece: "有储罐或管道没有接入机器",
			errBadPortColors: "端口颜色与这台机器不符",
			errBadSupply: "供应储罐只能是粉色、黄色、绿色或蓝色",
			errNoMachineHere: "这里没有已安装的机器",
			errPhase: "当前不能进行这个操作",
			errNotYourTurn: "现在轮不到你",
			endCash: "现金 {{n}} 元",
			endChips: "清晰圆片 {{n}} 点，计 {{score}} 元",
			endScore: "合计 {{n}} 元",
			endMachines: "工厂里有 {{n}} 台机器"
		},
		en: {
			name: "Factory Funner",
			desc: "Draft machines, wire your pipes, and process products — most money after eight rounds wins",
			rules: "Goal:\nEach player runs a factory. Over eight rounds you each draft one machine per round and install it into your factory network, so that product flows from supply reservoirs through machines and on to other machines or output reservoirs. Machines earn revenue when installed, and chaining them earns extra points at the end. After eight rounds, the player with the most money wins.\nSetup:\n· Each player takes one factory board. A board has 37 hexagonal spaces in all; the center space is an obstacle and nothing may be placed on it, leaving 36 playable spaces.\n· Shuffle all 48 machines face down into a deck, then turn three face up into a shared display. Whenever a machine is taken, immediately refill the display from the deck.\n· Each player starts with $10. The first player is chosen at random, and play proceeds in seat order.\nMachines:\n· Each machine is a hexagonal tile. Around its edge, a colored port marked with white dots is an input, and the number of dots shows how many units of material that port needs; a colored port marked with a white number is an output, and the number shows how many units it produces.\n· The number at the center of the tile is the machine's revenue, gained as soon as the machine is installed.\n· Some machine ports accept more than one color, shown on the tile as several color bands. Choose one color when you install the machine. On your later turns you may tap an installed machine to change these port colors; changing colors does not use your action, but the whole factory must remain legal afterwards.\nTurn:\nOn your turn, choose one machine from the display and install it on your factory board, then refill the display from the deck. If you cannot legally install the machine you chose, you may take it without installing it, with no penalty. When the deck runs out, shuffle the machines that players did not install to form a new deck. Every player takes eight turns, after which the game ends.\nInstalling and costs:\n· Machines may be rotated freely into any of six orientations. Placing a machine is free, and you gain the revenue shown at the center of its tile as soon as it is installed.\n· Each reservoir or pipe you place costs $1.\n· Machines and reservoirs may only be placed on empty spaces; pipes also occupy one space.\n· Machines installed on earlier turns can never be moved or taken back; reservoirs and pipes placed on earlier turns can be taken back for free.\nConnecting:\n· Every input and output of a machine must connect into the factory network.\n· An input either connects to a supply reservoir of the same color, or is fed by a same-color output from another machine.\n· An output either feeds a same-color input of another machine, or is collected by a same-color output reservoir.\n· Connected ports must share the same color; colors cannot be mixed.\n· The total input gathered by a machine cannot exceed the total output feeding it; one output may be split to feed several machines.\n· A machine's output may never, by any path, connect back to its own input.\n· No dead ends are allowed: every reservoir and pipe must connect to a machine port, and every output reservoir must receive product.\nReservoirs and pipes:\n· Supply reservoirs come in pink, yellow, green, and blue. Each player may place at most one of each color. A supply reservoir produces without limit, can feed several machines at once, and is never consumed.\n· Output reservoirs collect machine product. Each player may place at most three white output reservoirs, and each collects a single color; black output reservoirs are unlimited and collect only black end product.\n· A pipe occupies one space and carries one color, extending a same-color connection; the four colors cannot be mixed in one pipe.\nClear chips:\n· When a machine's input is fed by another machine rather than by a supply reservoir, place a clear chip on each input dot fed by a machine.\n· If that input later switches to a supply reservoir, remove the clear chip.\n· At the end, each clear chip scores $3 for every dot it covers.\nScoring:\n· After all eight rounds, add every player's cash to the value of their clear chips. The highest total wins; ties share the win.",
			deckChip: "Deck {{n}}",
			turnChip: "Round {{n}}",
			waitTurn: "Waiting for {{name}}…",
			stagePick: "Choose a machine from the display",
			stagePlace: "Tap an empty space to install the machine",
			stageConnect: "Rotate the machine, add reservoirs or pipes, then confirm",
			machineCardAria: "{{name}}, revenue {{rev}}",
			deckEmpty: "No machines in the display",
			turnsAria: "{{n}} turns taken",
			myCash: "Cash ${{n}}",
			myChips: "Chips {{n}} dots",
			myTurns: "Turn {{n}} / {{total}}",
			rotateLeft: "Rotate counterclockwise",
			rotateRight: "Rotate clockwise",
			confirm: "Confirm install",
			cancel: "Cancel",
			skip: "Skip this turn",
			takeOnly: "Take without installing",
			boardAria: "Your factory board",
			cellAria: "Factory space",
			recolorAria: "Change this machine's port colors",
			recolorTitle: "Change port colors",
			portInput: "Input",
			portOutput: "Output",
			paletteTitle: "Place a component here",
			close: "Close",
			kindSupply: "Supply",
			kindOutput: "Output",
			kindPipe: "Pipe",
			colorPink: "pink",
			colorYellow: "yellow",
			colorGreen: "green",
			colorBlue: "blue",
			colorBlack: "black",
			errNoSuchMachine: "That machine is not in the display",
			errBadCell: "That space cannot hold a piece",
			errNothingToRemove: "There is nothing to take back here",
			errCannotMoveMachine: "An installed machine cannot be moved or taken back",
			errCellOccupied: "That space is already occupied",
			errTooManyWhite: "At most three white output reservoirs",
			errDuplicateSupply: "At most one supply reservoir of each color",
			errOutputDead: "Some product is not received by any machine or output reservoir",
			errMerge: "Machine product and supply reservoirs cannot feed the same input",
			errPerpetual: "A machine's output cannot connect back to its own input",
			errNoSource: "Some input is not getting enough supply",
			errDeadPiece: "Some reservoir or pipe is not connected to a machine",
			errBadPortColors: "Those port colors do not match this machine",
			errBadSupply: "A supply reservoir must be pink, yellow, green, or blue",
			errNoMachineHere: "There is no installed machine here",
			errPhase: "You cannot do that right now",
			errNotYourTurn: "It is not your turn",
			endCash: "Cash ${{n}}",
			endChips: "Clear chips {{n}} dots, worth ${{score}}",
			endScore: "Total ${{n}}",
			endMachines: "{{n}} machines in the factory"
		}
	}
};
//#endregion
export { Qe as default };
