import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconClose as l, IconRotate as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { SheetView as v } from "@bgparty/sdk/sheet-view";
import { ConfirmButton as y } from "@bgparty/sdk/confirm-button";
//#region src/game/tiles.ts
var b = [
	"N",
	"NE",
	"SE",
	"S",
	"SW",
	"NW"
], x = (e, t, n) => ({
	edge: e,
	kind: "in",
	colors: [t],
	n
}), S = (e, t, n) => ({
	edge: e,
	kind: "out",
	colors: [t],
	n
}), C = (e) => ({
	edge: e,
	kind: "out",
	colors: ["black"],
	n: 1
}), w = [
	{
		id: 1,
		name: "Reduc-Tank",
		rev: 5,
		ports: [x("SW", "yellow", 3), S("SE", "blue", 1)]
	},
	{
		id: 2,
		name: "Packmaster",
		rev: 9,
		ports: [
			x("NE", "yellow", 3),
			x("SE", "blue", 2),
			C("SW")
		]
	},
	{
		id: 3,
		name: "The Judger",
		rev: 7,
		ports: [x("N", "blue", 1), S("SW", "yellow", 1)]
	},
	{
		id: 4,
		name: "Compressor",
		rev: 3,
		ports: [x("SW", "pink", 3), S("NE", "yellow", 2)]
	},
	{
		id: 5,
		name: "Crystalizer",
		rev: 8,
		ports: [
			x("N", "yellow", 3),
			x("NE", "green", 3),
			C("SW")
		]
	},
	{
		id: 6,
		name: "Smileificator",
		rev: 7,
		ports: [
			x("SW", "blue", 3),
			x("SE", "yellow", 1),
			S("N", "pink", 3)
		]
	},
	{
		id: 7,
		name: "Piper",
		rev: 4,
		ports: [
			x("NE", "pink", 3),
			x("SE", "blue", 2),
			S("SW", "yellow", 3)
		]
	},
	{
		id: 8,
		name: "Vinylnator",
		rev: 8,
		ports: [
			x("N", "pink", 2),
			x("SE", "yellow", 2),
			S("SW", "blue", 2)
		]
	},
	{
		id: 9,
		name: "Rainbowrizer",
		rev: 6,
		ports: [
			x("N", "pink", 3),
			x("NW", "yellow", 1),
			{
				edge: "SE",
				kind: "out",
				colors: [
					"pink",
					"yellow",
					"green",
					"blue"
				],
				n: 1
			}
		]
	},
	{
		id: 10,
		name: "Thinktank",
		rev: 9,
		ports: [
			x("N", "blue", 3),
			x("SE", "green", 2),
			S("SW", "blue", 1)
		]
	},
	{
		id: 11,
		name: "D-6 Quantizer",
		rev: 6,
		ports: [
			x("SW", "pink", 3),
			x("SE", "yellow", 3),
			S("N", "green", 2)
		]
	},
	{
		id: 12,
		name: "Nautilus",
		rev: 6,
		ports: [x("SE", "blue", 2), S("SW", "pink", 1)]
	},
	{
		id: 13,
		name: "Focuser",
		rev: 2,
		ports: [x("SW", "yellow", 2), S("N", "green", 3)]
	},
	{
		id: 14,
		name: "Explosor",
		rev: 8,
		ports: [
			x("SW", "pink", 1),
			x("SE", "blue", 1),
			S("N", "blue", 3)
		]
	},
	{
		id: 15,
		name: "Accelerator",
		rev: 6,
		ports: [
			x("NE", "green", 1),
			x("SE", "pink", 2),
			S("NW", "pink", 3)
		]
	},
	{
		id: 16,
		name: "DasHulk",
		rev: 6,
		ports: [
			x("N", "pink", 3),
			x("NW", "yellow", 1),
			S("SE", "yellow", 3)
		]
	},
	{
		id: 17,
		name: "Metamorphozor",
		rev: 10,
		ports: [
			x("N", "yellow", 1),
			x("NE", "pink", 1),
			S("SW", "yellow", 1)
		]
	},
	{
		id: 18,
		name: "BoxerX",
		rev: 7,
		ports: [
			x("NE", "green", 3),
			x("SE", "blue", 3),
			S("NW", "pink", 1)
		]
	},
	{
		id: 19,
		name: "Multiplier",
		rev: 5,
		ports: [x("SE", "pink", 1), S("N", "pink", 2)]
	},
	{
		id: 20,
		name: "Trifurnace",
		rev: 7,
		ports: [
			x("NE", "blue", 1),
			x("SE", "yellow", 3),
			S("SW", "blue", 2)
		]
	},
	{
		id: 21,
		name: "Ringmaster",
		rev: 7,
		ports: [
			x("NE", "yellow", 2),
			x("SE", "blue", 1),
			S("NW", "green", 3)
		]
	},
	{
		id: 22,
		name: "Shredder",
		rev: 13,
		ports: [
			x("N", "yellow", 1),
			x("NE", "pink", 3),
			x("SE", "blue", 2),
			S("SW", "green", 1)
		]
	},
	{
		id: 23,
		name: "Rebuilder",
		rev: 8,
		ports: [
			x("N", "blue", 2),
			{
				edge: "NE",
				kind: "in",
				colors: ["pink", "yellow"],
				n: 2
			},
			C("SW")
		]
	},
	{
		id: 24,
		name: "Boilnado",
		rev: 4,
		ports: [x("SE", "green", 1), S("NW", "blue", 3)]
	},
	{
		id: 25,
		name: "Cwalichecker",
		rev: 14,
		ports: [
			x("N", "blue", 1),
			x("NE", "green", 3),
			x("SE", "yellow", 1),
			C("SW")
		]
	},
	{
		id: 26,
		name: "Umeaker",
		rev: 7,
		ports: [
			x("NE", "blue", 3),
			x("SE", "green", 1),
			S("NW", "pink", 1),
			S("SW", "yellow", 2)
		]
	},
	{
		id: 27,
		name: "Magnetizer",
		rev: 9,
		ports: [
			x("NW", "green", 1),
			x("SW", "blue", 1),
			S("NE", "pink", 2)
		]
	},
	{
		id: 28,
		name: "Time Machine",
		rev: 7,
		ports: [x("NW", "green", 1), C("SE")]
	},
	{
		id: 29,
		name: "Conservator",
		rev: 12,
		ports: [
			x("N", "pink", 2),
			x("NW", "yellow", 2),
			x("SW", "green", 1),
			S("SE", "pink", 2)
		]
	},
	{
		id: 30,
		name: "Freedomizer",
		rev: 11,
		ports: [
			x("N", "green", 2),
			x("NW", "blue", 1),
			x("SW", "pink", 1),
			S("SE", "yellow", 3)
		]
	},
	{
		id: 31,
		name: "Hexopacker",
		rev: 13,
		ports: [
			x("N", "pink", 1),
			x("SE", "blue", 1),
			C("SW")
		]
	},
	{
		id: 32,
		name: "Retrofactor",
		rev: 9,
		ports: [
			x("N", "blue", 2),
			x("NE", "yellow", 2),
			S("SW", "green", 1)
		]
	},
	{
		id: 33,
		name: "Max-X-Boil",
		rev: 9,
		ports: [
			x("NE", "yellow", 3),
			x("SE", "pink", 1),
			S("SW", "blue", 1)
		]
	},
	{
		id: 34,
		name: "Uberlight",
		rev: 8,
		ports: [
			x("SW", "green", 3),
			x("NW", "yellow", 1),
			S("SE", "pink", 2)
		]
	},
	{
		id: 35,
		name: "Pixellator",
		rev: 7,
		ports: [
			x("NE", "blue", 2),
			x("SE", "pink", 2),
			S("SW", "green", 2)
		]
	},
	{
		id: 36,
		name: "Boom Tube",
		rev: 7,
		ports: [
			x("NE", "blue", 3),
			x("SE", "yellow", 2),
			S("SW", "yellow", 1)
		]
	},
	{
		id: 37,
		name: "Lavafuzer",
		rev: 9,
		ports: [
			x("N", "blue", 2),
			x("SE", "green", 3),
			S("SW", "yellow", 1)
		]
	},
	{
		id: 38,
		name: "Mondrianator",
		rev: 10,
		ports: [
			x("NW", "green", 2),
			x("SW", "blue", 2),
			C("SE")
		]
	},
	{
		id: 39,
		name: "Meepler",
		rev: 8,
		ports: [
			x("NW", "pink", 3),
			x("SW", "green", 1),
			S("NE", "yellow", 2)
		]
	},
	{
		id: 40,
		name: "Ectotrapper",
		rev: 7,
		ports: [
			x("NW", "pink", 1),
			x("SW", "yellow", 1),
			S("SE", "green", 3)
		]
	},
	{
		id: 41,
		name: "Zapp3000",
		rev: 10,
		ports: [
			x("N", "pink", 3),
			x("SE", "green", 1),
			S("SW", "green", 1)
		]
	},
	{
		id: 42,
		name: "Meltdown",
		rev: 7,
		ports: [
			x("N", "green", 3),
			x("NE", "blue", 1),
			S("SW", "yellow", 1)
		]
	},
	{
		id: 43,
		name: "Spectrumizer",
		rev: 9,
		ports: [
			x("NW", "yellow", 2),
			x("SW", "green", 2),
			S("NE", "pink", 1)
		]
	},
	{
		id: 44,
		name: "Maxi Mixer",
		rev: 5,
		ports: [
			x("N", "green", 2),
			x("NE", "pink", 2),
			S("SW", "blue", 3)
		]
	},
	{
		id: 45,
		name: "Supersealer",
		rev: 12,
		ports: [
			x("NE", "green", 2),
			x("SE", "pink", 1),
			C("SW")
		]
	},
	{
		id: 46,
		name: "Bagmeister",
		rev: 11,
		ports: [
			x("NW", "yellow", 1),
			x("SW", "pink", 3),
			C("SE")
		]
	},
	{
		id: 47,
		name: "Dissip-82",
		rev: 8,
		ports: [
			x("NW", "green", 1),
			x("SW", "yellow", 2),
			S("NE", "blue", 2)
		]
	},
	{
		id: 48,
		name: "Moisture-rizer",
		rev: 6,
		ports: [
			x("N", "blue", 3),
			x("NE", "green", 2),
			S("SW", "green", 2)
		]
	}
], T = Object.fromEntries(w.map((e) => [e.id, e])), E = (e) => b.indexOf(e), D = (e, t) => b[(E(e) + t) % 6];
function O(e) {
	return e.ports.map((e, t) => e.colors.length > 1 ? t : -1).filter((e) => e >= 0);
}
//#endregion
//#region src/game/board.ts
var k = Math.sqrt(3), A = (e, t) => `${e},${t}`;
function j(e) {
	let [t, n] = e.split(",").map(Number);
	return [t, n];
}
function M(e, t) {
	return [1.5 * e, k * (t + e / 2)];
}
var N = {
	N: [0, -1],
	NE: [1, -1],
	SE: [1, 0],
	S: [0, 1],
	SW: [-1, 1],
	NW: [-1, 0]
}, P = {
	N: "S",
	S: "N",
	NE: "SW",
	SW: "NE",
	SE: "NW",
	NW: "SE"
};
function F(e, t) {
	let [n, r] = j(e), [i, a] = N[t];
	return A(n + i, r + a);
}
function I(e) {
	switch (e) {
		case "N": return [0, -k / 2];
		case "S": return [0, k / 2];
		case "NE": return [.75, -k / 4];
		case "NW": return [-.75, -k / 4];
		case "SE": return [.75, k / 4];
		case "SW": return [-.75, k / 4];
	}
}
function L(e, t) {
	return (Math.abs(e) + Math.abs(t) + Math.abs(e + t)) / 2;
}
var ee = A(0, 0), R = (() => {
	let e = [];
	for (let t = -3; t <= 3; t++) for (let n = -3; n <= 3; n++) L(t, n) <= 3 && e.push(A(t, n));
	return e;
})(), z = new Set(R.filter((e) => e !== ee));
function B(e, t, n) {
	return e.length === 1 ? e[0] : n?.[t] ?? e[0];
}
function te(e, t) {
	let n = T[e];
	return n ? t === void 0 || t.length === n.ports.length && n.ports.every((e, n) => e.colors.includes(t[n])) : !1;
}
function V(e) {
	return T[e.id].ports.map((t, n) => ({
		edge: D(t.edge, e.rot),
		kind: t.kind,
		color: B(t.colors, n, e.portColors),
		n: t.n
	}));
}
function ne(e) {
	return e.kind === "machine" ? V(e).map((e) => ({
		edge: e.edge,
		color: e.color,
		kind: e.kind,
		n: e.n
	})) : b.map((t) => ({
		edge: t,
		color: e.color
	}));
}
function H(e) {
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e)) for (let e of ne(r)) {
		let r = `${n}|${e.edge}`;
		t.set(r, {
			key: r,
			cell: n,
			edge: e.edge,
			color: e.color,
			kind: e.kind,
			n: e.n
		});
	}
	return t;
}
var re = class {
	parent = /* @__PURE__ */ new Map();
	find(e) {
		let t = e;
		for (;;) {
			let e = this.parent.get(t);
			if (e === void 0) {
				this.parent.set(t, t);
				break;
			}
			if (e === t) break;
			t = e;
		}
		let n = e;
		for (; n !== t;) {
			let e = this.parent.get(n);
			this.parent.set(n, t), n = e;
		}
		return t;
	}
	union(e, t) {
		let n = this.find(e), r = this.find(t);
		n !== r && this.parent.set(n, r);
	}
};
function U(e) {
	let t = H(e), n = new re();
	for (let [t, r] of Object.entries(e)) {
		if (r.kind === "machine") continue;
		let e = b.map((e) => `${t}|${e}`);
		for (let t = 1; t < e.length; t++) n.union(e[0], e[t]);
	}
	for (let e of t.values()) {
		let r = F(e.cell, e.edge), i = t.get(`${r}|${P[e.edge]}`);
		i && i.color === e.color && n.union(e.key, i.key);
	}
	let r = /* @__PURE__ */ new Map(), i = (e) => {
		let t = r.get(e);
		return t || (t = {
			outCap: 0,
			demand: 0,
			hasSupply: !1,
			hasSink: !1,
			hasMachinePort: !1,
			outPorts: [],
			inPorts: [],
			pipeCells: [],
			supplyCells: [],
			outputCells: []
		}, r.set(e, t)), t;
	};
	for (let e of t.values()) {
		let t = i(n.find(e.key));
		e.kind === "out" ? (t.outCap += e.n ?? 1, t.hasMachinePort = !0, t.outPorts.push(e)) : e.kind === "in" && (t.demand += e.n ?? 1, t.hasMachinePort = !0, t.inPorts.push(e));
	}
	for (let [t, r] of Object.entries(e)) {
		let e = i(n.find(`${t}|${b[0]}`));
		r.kind === "supply" ? (e.hasSupply = !0, e.supplyCells.push(t)) : r.kind === "output" ? (e.hasSink = !0, e.outputCells.push(t)) : r.kind === "pipe" && e.pipeCells.push(t);
	}
	return {
		nodes: t,
		dsu: n,
		comps: r
	};
}
function ie(e) {
	let { comps: t } = U(e);
	return [...t.values()].map((e) => ({
		supplyCells: e.supplyCells,
		outputCells: e.outputCells,
		pipeCells: e.pipeCells,
		inPorts: e.inPorts.map((e) => ({
			cell: e.cell,
			edge: e.edge,
			color: e.color,
			n: e.n ?? 1
		})),
		outPorts: e.outPorts.map((e) => ({
			cell: e.cell,
			edge: e.edge,
			color: e.color,
			n: e.n ?? 1
		}))
	}));
}
function W(e) {
	let { dsu: t, comps: n } = U(e), r = {}, i = {}, a = 0, o = (e) => ({
		ok: !1,
		error: e,
		chipDots: 0,
		machines: r,
		chipsByMachine: i
	}), s = (e) => t.find(e);
	for (let e of n.values()) {
		if (e.outPorts.length > 0 && e.outCap > e.demand && !e.hasSink) return o("outputDead");
		if (e.supplyCells.length > 0 && (e.demand === 0 || e.outCap > 0)) return o(e.outCap > 0 ? "merge" : "supplyDead");
		if (e.outputCells.length > 0 && e.outCap === 0) return o("sinkDead");
		if (e.pipeCells.length > 0 && !e.hasMachinePort) return o("pipeDead");
		if (e.inPorts.length > 0) {
			if (e.hasSupply && e.outCap > 0) return o("merge");
			if (!e.hasSupply) {
				if (e.outCap < e.demand) return o("noSource");
				for (let t of e.inPorts) i[t.cell] = (i[t.cell] ?? 0) + (t.n ?? 1), a += t.n ?? 1;
			}
		}
	}
	for (let [t, n] of Object.entries(e)) {
		if (n.kind !== "machine") continue;
		let e = V(n);
		for (let n = 0; n < e.length; n++) for (let r = 0; r < e.length; r++) if (e[n].kind === "in" && e[r].kind === "out" && e[n].color === e[r].color && s(`${t}|${e[n].edge}`) === s(`${t}|${e[r].edge}`)) return o("perpetual");
		r[t] = !0;
	}
	return {
		ok: !0,
		chipDots: a,
		machines: r,
		chipsByMachine: i
	};
}
function ae(e, t, n, r, i, a, o) {
	let s = { ...e };
	for (let e of o) delete s[e];
	s[n] = {
		kind: "machine",
		id: t,
		rot: r,
		portColors: i
	};
	for (let e of a) e.kind === "supply" ? s[e.cell] = {
		kind: "supply",
		color: e.color
	} : e.kind === "output" ? s[e.cell] = {
		kind: "output",
		color: e.color
	} : s[e.cell] = {
		kind: "pipe",
		color: e.color
	};
	return s;
}
function oe(e) {
	return Object.values(e).filter((e) => e.kind === "output" && e.color !== "black").length;
}
function G(e) {
	let t = {
		pink: 0,
		yellow: 0,
		green: 0,
		blue: 0
	};
	for (let n of Object.values(e)) n.kind === "supply" && (t[n.color] += 1);
	return t;
}
//#endregion
//#region src/game/meta.ts
var se = {
	id: "factoryfunner",
	uuid: "9880c7ad-aeac-445b-820b-ad9787c1716e",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"engine-building",
		"route-building"
	],
	interactionTags: [],
	nameKey: "games.factoryfunner.name",
	descKey: "games.factoryfunner.desc",
	rulesKey: "games.factoryfunner.rules",
	icon: "🏭",
	iconImg: "games/factoryfunner.webp",
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	accent: "#c2410c",
	releasedAt: "2026-11-23T15:40:17+08:00",
	search: {
		py: "gong chang le fan tian",
		init: "gclft"
	},
	hotseat: "open"
}, ce = t.enum([
	"pink",
	"yellow",
	"green",
	"blue"
]), K = t.enum([
	"pink",
	"yellow",
	"green",
	"blue",
	"black"
]);
t.enum([
	"N",
	"NE",
	"SE",
	"S",
	"SW",
	"NW"
]);
var q = t.string().regex(/^-?\d+,-?\d+$/), J = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("machine"),
		id: t.int().min(1).max(48),
		rot: t.int().min(0).max(5),
		portColors: t.array(K).optional()
	}),
	t.object({
		kind: t.literal("supply"),
		color: ce
	}),
	t.object({
		kind: t.literal("output"),
		color: K
	}),
	t.object({
		kind: t.literal("pipe"),
		color: K
	})
]), le = t.object({
	cell: q,
	kind: t.enum([
		"supply",
		"output",
		"pipe"
	]),
	color: K
}), ue = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("build"),
		machine: t.int().min(1).max(48),
		cell: q,
		rot: t.int().min(0).max(5),
		portColors: t.array(K).optional(),
		add: t.array(le).max(30),
		remove: t.array(q).max(30)
	}),
	t.object({
		type: t.literal("skip"),
		machine: t.int().min(1).max(48).optional()
	}),
	t.object({
		type: t.literal("recolor"),
		cell: q,
		portColors: t.array(K).min(1).max(6)
	})
]), Y = t.string(), X = t.object({
	phase: t.enum(["play", "done"]),
	solo: t.boolean(),
	actor: Y.optional(),
	round: t.int().min(0),
	players: t.array(t.object({
		rid: Y,
		money: t.number(),
		turns: t.int().min(0)
	})),
	display: t.array(t.int().min(1).max(48)),
	deckCount: t.int().min(0),
	boards: t.record(Y, t.record(q, J))
}), de = t.object({}), fe = 3;
function pe(t, n) {
	let r = [...t], i = 0;
	for (let t = r.length - 1; t > 0; --t) {
		let a = e(n, i, t + 1);
		i += 1, [r[t], r[a]] = [r[a], r[t]];
	}
	return {
		order: r,
		cursor: i
	};
}
function me(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function he(e) {
	return Object.values(e.turnsTaken).reduce((e, t) => e + t, 0);
}
function ge(t, n, r) {
	let { order: i, cursor: a } = pe(w.map((e) => e.id), r), o = n.length === 1, s = o ? i.slice(0, 8) : i, c = [];
	if (o) c.push(s.pop());
	else for (; c.length < fe && s.length > 0;) c.push(s.pop());
	let l = o ? 0 : e(r, a, n.length);
	return {
		state: {
			seed: r,
			rngCursor: a + +!o,
			players: n,
			mode: o ? "solo" : "multi",
			phase: "play",
			turnIdx: l,
			turnsTaken: Object.fromEntries(n.map((e) => [e, 0])),
			deck: s,
			display: c,
			discard: [],
			boards: Object.fromEntries(n.map((e) => [e, {}])),
			money: Object.fromEntries(n.map((e) => [e, 10]))
		},
		fx: []
	};
}
function _e(e) {
	for (; e.display.length < fe;) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) return;
			e.deck = me(e, e.discard), e.discard = [];
		}
		e.display.push(e.deck.pop());
	}
}
function ve(e) {
	e.display = e.deck.length > 0 ? [e.deck.pop()] : [];
}
function Z(e) {
	let t = e.players[e.turnIdx];
	e.turnsTaken[t] += 1;
	let n = e.players.length;
	for (let t = 1; t <= n; t += 1) {
		let r = (e.turnIdx + t) % n;
		if (e.turnsTaken[e.players[r]] < 8) {
			e.turnIdx = r;
			return;
		}
	}
	e.phase = "done";
}
function ye(e, t) {
	let n = e.players[e.turnIdx], r = e.boards[n];
	if (!e.display.includes(t.machine)) return { code: "games.factoryfunner.errNoSuchMachine" };
	if (!z.has(t.cell)) return { code: "games.factoryfunner.errBadCell" };
	if (!te(t.machine, t.portColors)) return { code: "games.factoryfunner.errBadPortColors" };
	let i = new Set(t.remove);
	for (let e of i) {
		let t = r[e];
		if (!t) return { code: "games.factoryfunner.errNothingToRemove" };
		if (t.kind === "machine") return { code: "games.factoryfunner.errCannotMoveMachine" };
	}
	let a = (e) => !z.has(e) || !!r[e] && !i.has(e);
	if (a(t.cell)) return { code: "games.factoryfunner.errCellOccupied" };
	let o = /* @__PURE__ */ new Set();
	for (let e of t.add) {
		if (e.cell === t.cell || o.has(e.cell)) return { code: "games.factoryfunner.errCellOccupied" };
		if (o.add(e.cell), e.kind === "supply" && e.color === "black") return { code: "games.factoryfunner.errBadSupply" };
		if (a(e.cell)) return { code: "games.factoryfunner.errCellOccupied" };
	}
	return be(ae(r, t.machine, t.cell, t.rot, t.portColors, t.add, t.remove));
}
function be(e) {
	if (oe(e) > 3) return { code: "games.factoryfunner.errTooManyWhite" };
	let t = G(e);
	for (let e of [
		"pink",
		"yellow",
		"green",
		"blue"
	]) if (t[e] > 1) return { code: "games.factoryfunner.errDuplicateSupply" };
	let n = W(e);
	return n.ok ? null : {
		overlap: { code: "games.factoryfunner.errCellOccupied" },
		outputDead: { code: "games.factoryfunner.errOutputDead" },
		merge: { code: "games.factoryfunner.errMerge" },
		perpetual: { code: "games.factoryfunner.errPerpetual" },
		noSource: { code: "games.factoryfunner.errNoSource" },
		supplyDead: { code: "games.factoryfunner.errDeadPiece" },
		sinkDead: { code: "games.factoryfunner.errDeadPiece" },
		pipeDead: { code: "games.factoryfunner.errDeadPiece" }
	}[n.error ?? "noSource"] ?? { code: "games.factoryfunner.errNoSource" };
}
function xe(e, t, n) {
	if (e.phase !== "play") return { code: "games.factoryfunner.errPhase" };
	let r = e.players[e.turnIdx];
	if (n.by !== r) return { code: "games.factoryfunner.errNotYourTurn" };
	let i = structuredClone(e);
	if (t.type === "skip") {
		if (t.machine !== void 0 && !i.display.includes(t.machine)) return { code: "games.factoryfunner.errNoSuchMachine" };
		let e = t.machine ?? (i.mode === "solo" ? i.display[0] : void 0);
		return e !== void 0 && (i.display = i.display.filter((t) => t !== e), i.mode === "solo" ? ve(i) : (i.discard.push(e), _e(i))), Z(i), {
			state: i,
			fx: [{
				kind: "ffSkip",
				rid: r
			}]
		};
	}
	if (t.type === "recolor") {
		let e = i.boards[r], n = e[t.cell];
		if (!n || n.kind !== "machine") return { code: "games.factoryfunner.errNoMachineHere" };
		if (!te(n.id, t.portColors)) return { code: "games.factoryfunner.errBadPortColors" };
		let a = {
			...e,
			[t.cell]: {
				...n,
				portColors: [...t.portColors]
			}
		};
		return be(a) || (i.boards[r] = a, {
			state: i,
			fx: []
		});
	}
	let a = ye(e, t);
	if (a) return a;
	let o = i.boards[r];
	i.boards[r] = ae(o, t.machine, t.cell, t.rot, t.portColors, t.add, t.remove);
	let s = T[t.machine].rev, c = t.add.length;
	i.money[r] += s - c, i.display = i.display.filter((e) => e !== t.machine), i.mode === "solo" ? ve(i) : _e(i), Z(i);
	let l = [{
		kind: "ffBuild",
		rid: r,
		data: {
			machine: t.machine,
			cell: t.cell,
			rot: t.rot,
			add: t.add.length,
			rev: s,
			cost: c
		}
	}];
	return i.phase === "done" && l.push({ kind: "gameEnd" }), {
		state: i,
		fx: l
	};
}
function Se(e) {
	return {
		public: {
			phase: e.phase,
			solo: e.mode === "solo",
			actor: e.phase === "play" ? e.players[e.turnIdx] : void 0,
			round: Math.floor(he(e) / e.players.length) + 1,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				turns: e.turnsTaken[t]
			})),
			display: e.display,
			deckCount: e.deck.length,
			boards: e.boards
		},
		private: {}
	};
}
function Ce(e, t) {
	let n = W(e.boards[t]).chipDots;
	return {
		score: e.money[t] + 3 * n,
		chips: n
	};
}
function we(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = Ce(e, n).score;
	if (e.mode === "solo") return {
		phase: "done",
		winner: [],
		ranking: [e.players[0]],
		scores: t
	};
	let n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
var Te = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: se,
	schemas: {
		action: ue,
		publicView: X,
		privateView: de
	},
	setup: ge,
	reduce: xe,
	viewFor: Se,
	status: we
}, Q = {
	pink: "#e0629a",
	yellow: "#e7b53a",
	green: "#57b06a",
	blue: "#4a86d8",
	black: "#23262e"
}, Ee = .965, De = Array.from({ length: 6 }, (e, t) => {
	let n = Math.PI / 3 * t;
	return [Math.cos(n), Math.sin(n)];
}), $ = (e, t, n = 1) => De.map(([r, i]) => `${(e + r * n).toFixed(3)},${(t + i * n).toFixed(3)}`).join(" "), Oe = .94, ke = .048, Ae = .038, je = .255, Me = "-5.85 -6.45 11.7 12.9";
function Ne(e) {
	let t = /* @__PURE__ */ new Map();
	for (let { supplyCells: n, inPorts: r, outPorts: i } of e) {
		let e = r.reduce((e, t) => e + t.n, 0), a = i.reduce((e, t) => e + t.n, 0);
		if (!(n.length || a < e)) for (let { cell: e, edge: n } of r) {
			let r = t.get(e) ?? /* @__PURE__ */ new Set();
			r.add(n), t.set(e, r);
		}
	}
	return t;
}
var Pe = {
	tank: "M-29 19V-8Q-29-24 0-24T29-8V19H-29M-29-7Q0 7 29-7M-15 19V26M15 19V26",
	pack: "M-31 18H32M7 18L16-7-4-24-23-13-24-5M-28-8L-29 1-20 5-14-1M12-6L-6-17M-3 18V9H5M21 18V10H31V18",
	arc: "M-31 17V2A31 25 0 0 1 31 2V17M-22 17V3A22 16 0 0 1 22 3V17M-13 17V4A13 7 0 0 1 13 4V17",
	belt: "M-31 18H34L24 8H-26ZM-24 8V-21H21V8M-16-14H13V0H-16ZM-19 18V23M20 18V23",
	press: "M-28 22V-22H25V22M-28 17H25M-13-16V-3H13V-16M-15 10H15",
	coil: "M-29 22V-14H-14V12H0V-20H15V12H29V-14M-29 22H29",
	furnace: "M-30 20H29V-6L21-14H-18L-30-6ZM4-14V-27H18V-14M-17 19V2H14V19M-7 2V19",
	rotor: "M-29 17L-21-15 5-24 29-7 18 17ZM-18 9L1-11 16 9ZM-25 25H23",
	tower: "M-27 22H27M-18 22V-20H12V22M12 12H25V22M-19-4H12M-7-17V-6",
	mixer: "M-25-14H25L15 20H-15ZM0-25V6M-10 3L0 7 10 3M-19 24H19"
}, Fe = /* @__PURE__ */ "tank.pack.press.press.furnace.mixer.coil.rotor.arc.tank.tower.coil.rotor.furnace.press.tower.belt.pack.rotor.furnace.rotor.press.belt.tank.tower.mixer.coil.tower.tank.press.pack.belt.furnace.tower.belt.coil.furnace.press.pack.tank.coil.furnace.arc.mixer.press.pack.rotor.tank".split(".");
function Ie(e, t, n, r) {
	let [i, a] = I(e);
	return [t + i * r * Oe, n + a * r * Oe];
}
function Le({ edge: e, kind: t, n: r, colors: i, radius: a, cx: o, cy: s, chip: c }) {
	let l = n(), [u, d] = Ie(e, o, s, a), f = a * je, p = a * (ke * 2 + Ae), m = t === "out" ? a * .46 : Math.max(a * .33, (r - 1) * p + a * .23), h = t === "out" && i.length === 1 && i[0] === "black", v = a * .064, y = t === "out" ? `M${-m / 2} ${-f / 2} H${m * .32} L${m / 2} 0 L${m * .32} ${f / 2} H${-m / 2}Z` : `M${-m / 2 + f / 3} ${-f / 2} H${m / 2 - f / 3} Q${m / 2} ${-f / 2} ${m / 2} 0 Q${m / 2} ${f / 2} ${m / 2 - f / 3} ${f / 2} H${-m / 2 + f / 3} Q${-m / 2} ${f / 2} ${-m / 2} 0 Q${-m / 2} ${-f / 2} ${-m / 2 + f / 3} ${-f / 2}Z`;
	return /* @__PURE__ */ _("g", {
		transform: `translate(${u} ${d})`,
		children: [
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("clipPath", {
				id: l,
				children: /* @__PURE__ */ g("path", { d: y })
			}) }),
			/* @__PURE__ */ g("g", {
				clipPath: `url(#${l})`,
				children: i.map((e, t) => /* @__PURE__ */ g("rect", {
					x: -m / 2 + t * m / i.length,
					y: -f / 2,
					width: m / i.length + a * .008,
					height: f,
					fill: Q[e]
				}, e))
			}),
			/* @__PURE__ */ g("path", {
				d: y,
				className: "ff-port-edge",
				strokeWidth: a * .027
			}),
			t === "in" ? Array.from({ length: r }, (e, t) => /* @__PURE__ */ g("circle", {
				cx: (t - (r - 1) / 2) * p,
				r: a * ke,
				className: c ? "ff-input-dot ff-input-dot--chip" : "ff-input-dot",
				strokeWidth: a * (c ? .026 : .012)
			}, t)) : h ? /* @__PURE__ */ g("path", {
				d: `M0 ${-v} L${v} 0 0 ${v} ${-v} 0Z`,
				className: "ff-port-num"
			}) : /* @__PURE__ */ g("text", {
				x: -m * .05,
				textAnchor: "middle",
				dominantBaseline: "central",
				className: i.length > 1 || i[0] === "yellow" ? "ff-port-num ff-port-num--dark" : "ff-port-num",
				fontSize: a * .207,
				children: r
			})
		]
	});
}
function Re({ id: e, rot: t, portColors: n, cx: r, cy: i, radius: a, chips: o }) {
	let s = T[e];
	return /* @__PURE__ */ _("g", {
		className: "ff-machine-art",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("polygon", {
				points: $(r, i + a * .055, a),
				className: "ff-hex ff-hex--machine-edge"
			}),
			/* @__PURE__ */ g("polygon", {
				points: $(r, i, a),
				className: "ff-hex ff-hex--machine"
			}),
			/* @__PURE__ */ g("polygon", {
				points: $(r, i, a * .91),
				className: "ff-hex ff-hex--machine-face"
			}),
			/* @__PURE__ */ g("path", {
				d: Pe[Fe[e - 1]],
				transform: `translate(${r} ${i - a * .205}) scale(${a / 90})`,
				className: "ff-machine-silhouette"
			}),
			/* @__PURE__ */ g("polygon", {
				points: $(r, i + a * .28, a * .265),
				className: "ff-revenue",
				strokeWidth: a * .03
			}),
			/* @__PURE__ */ g("text", {
				x: r,
				y: i + a * .28,
				className: "ff-machine-rev",
				fontSize: a * .3,
				textAnchor: "middle",
				dominantBaseline: "central",
				children: s.rev
			}),
			s.ports.map((e, s) => {
				let c = D(e.edge, t);
				return /* @__PURE__ */ g(Le, {
					edge: c,
					kind: e.kind,
					n: e.n,
					radius: a,
					cx: r,
					cy: i,
					colors: n ? [B(e.colors, s, n)] : e.colors,
					chip: o?.has(c) ?? !1
				}, e.edge);
			})
		]
	});
}
function ze({ cx: e, cy: t }) {
	return /* @__PURE__ */ _("g", {
		"aria-hidden": "true",
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ g("polygon", {
				points: $(0, 0, .95),
				className: "ff-hex ff-hex--blocked"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-.53-.17V.27L-.3.48H.32L.53.27V-.17Z",
				className: "ff-obstacle-shell"
			}),
			/* @__PURE__ */ g("ellipse", {
				cy: "-.16",
				rx: ".53",
				ry: ".22",
				className: "ff-obstacle-top"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-.32.05-.21.36H.24L.36.07M-.21.36V.43M.24.36V.43",
				className: "ff-obstacle-braces"
			}),
			/* @__PURE__ */ g("circle", {
				cy: "-.37",
				r: ".2",
				className: "ff-obstacle-top"
			})
		]
	});
}
function Be({ piece: e, cx: t, cy: n, chips: r }) {
	if (e.kind === "machine") return /* @__PURE__ */ g(Re, {
		id: e.id,
		rot: e.rot,
		portColors: e.portColors,
		cx: t,
		cy: n,
		radius: .9,
		chips: r
	});
	let i = Q[e.color], a = e.kind === "output" && e.color !== "black" ? "#f2e7cb" : i;
	return /* @__PURE__ */ _("g", {
		"aria-hidden": "true",
		transform: `translate(${t} ${n})`,
		children: [
			/* @__PURE__ */ g("polygon", {
				points: $(0, 0, .82),
				className: "ff-hex ff-component-base"
			}),
			b.map((e) => {
				let [t, n] = I(e), r = {
					x1: t * .24,
					y1: n * .24,
					x2: t * .94,
					y2: n * .94
				};
				return /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("line", {
					...r,
					className: "ff-component-pipe-edge"
				}), /* @__PURE__ */ g("line", {
					...r,
					stroke: i,
					className: "ff-component-pipe"
				})] }, e);
			}),
			e.kind === "pipe" ? /* @__PURE__ */ g("path", {
				d: "M-.22-.11H.22V.11H-.22Z M-.12-.12V.12 M.12-.12V.12",
				fill: i,
				className: "ff-component-fitting"
			}) : /* @__PURE__ */ _("g", { children: [
				/* @__PURE__ */ g("path", {
					d: "M-.34-.14V.2Q0 .38.34 .2V-.14",
					fill: a,
					className: "ff-tank"
				}),
				/* @__PURE__ */ g("ellipse", {
					cy: "-.14",
					rx: ".34",
					ry: ".15",
					fill: a,
					className: "ff-tank"
				}),
				/* @__PURE__ */ g("ellipse", {
					cy: "-.14",
					rx: ".23",
					ry: ".077",
					className: "ff-tank-ring"
				}),
				e.kind === "supply" ? /* @__PURE__ */ g("circle", {
					cy: ".16",
					r: ".055",
					className: "ff-tank-dot"
				}) : /* @__PURE__ */ g("path", {
					d: "M-.1.16H.1",
					className: "ff-tank-output"
				})
			] })
		]
	});
}
function Ve({ ports: e }) {
	return /* @__PURE__ */ g("g", {
		"aria-hidden": "true",
		className: "ff-connections",
		children: e.map((e) => {
			let [t, n] = M(...j(e.cell)), [r, i] = I(e.edge);
			return /* @__PURE__ */ g("line", {
				x1: t + r * .92,
				y1: n + i * .92,
				x2: t + r * 1.22,
				y2: n + i * 1.22
			}, `${e.cell}:${e.edge}`);
		})
	});
}
function He({ board: e, label: t, chipEdges: n }) {
	return /* @__PURE__ */ g("svg", {
		className: "ff-board",
		viewBox: Me,
		role: t ? "img" : void 0,
		"aria-label": t,
		"aria-hidden": !t || void 0,
		children: /* @__PURE__ */ g(Ue, {
			board: e,
			chipEdges: n
		})
	});
}
function Ue({ board: e, chipEdges: t }) {
	return R.map((n) => {
		let [r, i] = M(...j(n)), a = e[n];
		return /* @__PURE__ */ g("g", { children: n === ee ? /* @__PURE__ */ g(ze, {
			cx: r,
			cy: i
		}) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("polygon", {
			points: $(r, i, Ee),
			className: "ff-hex ff-hex--cell"
		}), a && /* @__PURE__ */ g(Be, {
			piece: a,
			cx: r,
			cy: i,
			chips: t?.get(n)
		})] }) }, n);
	});
}
//#endregion
//#region src/game/board-viewport.tsx
var We = 11.7, Ge = 12.9, Ke = [{
	key: "board",
	rect: {
		x: 0,
		y: 0,
		w: We,
		h: Ge
	}
}];
function qe(e, t, n) {
	let { left: r, top: i, width: a, height: o, scale: s } = e;
	if (s <= 0) return null;
	let c = r + s * t, l = i + s * n, u = Math.max(0, -c, c - a) / s, d = Math.max(0, -l, l - o) / s;
	return d >= .965 * k / 2 || u + d / k >= .965 ? null : {
		left: Math.max(0, Math.min(a, c)),
		top: Math.max(0, Math.min(o, l))
	};
}
function Je({ label: e, children: t, overlay: n, onTapCell: i, onProjection: s }) {
	let l = c(), [u, d] = o(0), f = a(null), p = a(null), m = a(null);
	r(() => {
		let e = f.current, t = p.current;
		if (!s || !e || !t?.parentElement) return;
		let n = () => {
			let n = t.getScreenCTM(), { left: r, top: i, width: a, height: o } = e.getBoundingClientRect();
			n && a && o && s({
				left: n.e - r,
				top: n.f - i,
				scale: n.a,
				width: a,
				height: o
			});
		}, r = new MutationObserver(n);
		r.observe(t.parentElement, {
			attributes: !0,
			attributeFilter: ["transform"]
		});
		let i = new ResizeObserver(n);
		return i.observe(e), n(), () => {
			r.disconnect(), i.disconnect();
		};
	}, [s]);
	let h = (e) => {
		let t = e instanceof Element ? e.closest("[data-ff-cell]") : null;
		return t && p.current?.contains(t) ? t.getAttribute("data-ff-cell") : null;
	};
	return /* @__PURE__ */ _("div", {
		className: "ff-board-viewport",
		children: [/* @__PURE__ */ _("div", {
			className: "ff-board-canvas",
			ref: f,
			onPointerDownCapture: i ? (e) => {
				let t = h(e.target);
				m.current = t && e.isPrimary && e.button === 0 ? {
					cell: t,
					pointerId: e.pointerId
				} : null;
			} : void 0,
			onPointerUpCapture: i ? (e) => {
				let t = document.elementFromPoint(e.clientX, e.clientY);
				(m.current?.pointerId !== e.pointerId || h(t) !== m.current.cell) && (m.current = null);
			} : void 0,
			onPointerCancelCapture: i ? () => {
				m.current = null;
			} : void 0,
			children: [/* @__PURE__ */ g(v, {
				sheetW: We,
				sheetH: Ge,
				fitKey: String(u),
				clampToSheet: !0,
				highlight: "off",
				readOnly: !i,
				eligible: i ? Ke : void 0,
				onTapEligible: i ? () => {
					let e = m.current?.cell;
					m.current = null, e && i(e);
				} : void 0,
				children: /* @__PURE__ */ g("g", {
					ref: p,
					transform: `translate(${We / 2} ${Ge / 2})`,
					role: i ? "group" : "img",
					"aria-label": e,
					children: t
				})
			}), n]
		}), /* @__PURE__ */ g("div", {
			className: "ff-board-toolbar",
			children: /* @__PURE__ */ g("button", {
				type: "button",
				className: "ff-btn ff-board-fit",
				onClick: () => d((e) => e + 1),
				children: l("games.factoryfunner.fitBoard")
			})
		})]
	});
}
//#endregion
//#region src/game/locales/zh.ts
var Ye = {
	name: "工厂乐翻天",
	desc: "选装机器、连接管线，把原料加工成成品；八轮后按总分排名，支持单人模式",
	rules: "目标:\n每位玩家经营一座工厂。你在八轮里各选取并安装一台机器，把它接入工厂网络，让原料从供应罐流入机器、加工后再送入下一台机器或输出罐。机器本身带来收入，妥善串联机器还能在终局额外得分；多人游戏中，八轮结束后钱最多者获胜。单人规则见下文。\n准备:\n· 每位玩家拿一块工厂板。工厂板共 37 个六边形格，中央一格为障碍、不能放置任何物件，其余 36 格为可放置的空格。\n· 多人游戏时，把全部 48 台机器洗匀，面朝下组成牌堆，从牌堆翻开三台作为公共待选区；被取走一台后，立即从牌堆补一台。\n· 每位玩家的现金从 10 元开始。多人游戏时随机决定起始玩家，之后按座位顺序轮流行动。\n机器板:\n· 每台机器是一块六边形板块。边缘的圆角端口是输入端，白点数量表示所需的原料单位数。带尖角的端口是输出端，数字表示产量，黑底白菱形表示产出 1 单位黑色成品。\n· 牌心的浅色轮廓用来辨识机型。黑底数字是安装这台机器时立即获得的收入。\n· 有些机器的端口可以用多种颜色，板块上以分色标出可选的颜色。安装时先选定一种颜色。机器安装之后，在轮到自己行动时可以点选这台机器更改这些端口的颜色；改色不消耗行动，但改完之后整座工厂仍然必须保持合法。\n回合:\n多人游戏时，每回合由当前玩家从待选区选择一台机器，安装到自己的工厂板上，随即从牌堆补一台到待选区。如果无法把选中的机器合法安装，可以取走这台机器而不安装，不会受到惩罚。当牌堆用尽时，把玩家没有安装的机器重新洗匀，组成新的牌堆。每位玩家各进行八个回合，八轮之后游戏结束。\n单人模式:\n· 单人游戏时，从全部机器中随机抽出八台，面朝下组成牌堆；每个回合翻开牌堆顶的一台机器，尝试把它安装进工厂。若无法安装或不愿安装，可以放弃这台机器，不会受到惩罚。\n· 牌堆抽完即结束，共进行八个回合；结束后按与多人游戏相同的方式结算现金与清晰圆片。\n安装与花费:\n· 机器可以任意旋转，共有六个朝向。安装机器本身免费，并会立即获得黑底数字所示的收入。\n· 每放置一个储罐或一根管道需要支付 1 元。\n· 机器与储罐只能放在空格上，管道同样占用一个空格。\n· 之前回合安装的机器不能再移动或取回；之前回合放置的储罐与管道可以免费取回。\n连接规则:\n· 机器的每个输入端与输出端都必须接入工厂网络。\n· 输入端要么连接同色的供应储罐，要么由其他机器的同色输出供给。\n· 输出端要么把产物送入其他机器的同色输入端，要么收入同色的输出储罐。\n· 相连的端口颜色必须相同，不能混色。\n· 汇集到一台机器的输入总量不能超过向它供料的输出总量；同一份输出可以拆分供给多台机器。\n· 一台机器的输出不能经由任何路径接回它自己的输入。\n· 不允许死端：任何储罐与管道都必须接入某台机器的端口，所有输出储罐都必须有产物送入。\n储罐与管道:\n· 供应储罐分为粉、黄、绿、蓝四色，每种颜色每位玩家最多放置一个。供应储罐无限产出，可同时供应多台机器，不会消耗。\n· 输出储罐用于收集机器产物。白色输出储罐每位玩家最多放置三个，每个只能收集一种颜色；黑色输出储罐数量不限，只能收集黑色成品。\n· 管道占用一个空格并携带一种颜色，用来把同色端口串联延长；四种颜色不能混用。\n清晰圆片:\n· 当一台机器的输入由其他机器供料、而不是由供应储罐供料时，在它的每个被机器供料的输入点上放一枚清晰圆片。\n· 如果之后改用供应储罐供料，就移除对应的清晰圆片。\n· 每枚清晰圆片按其覆盖的点数，在终局计分时每点计 3 元。\n计分:\n· 八轮全部结束后结算：所有现金加上清晰圆片的计分，总分最高者获胜，并列则共享胜利。",
	deckChip: "牌堆 {{n}}",
	turnChip: "第 {{n}} 回合",
	waitTurn: "等 {{name}} 行动…",
	stagePick: "从待选区选一台机器",
	stagePlace: "选择一个空格",
	stageConnect: "点空格添加储罐或管道",
	stageReady: "端口已接通，可以安装",
	soloStagePick: "选择本回合翻开的机器",
	soloSkip: "跳过这台机器",
	machineCardAria: "{{name}}，收入 {{rev}} 元",
	deckEmpty: "待选区暂无机器",
	turnsAria: "已进行 {{n}} 回合",
	myCash: "现金 {{n}} 元",
	myChips: "圆片 {{n}} 点",
	myTurns: "回合 {{n}} / {{total}}",
	rotateLeft: "逆时针旋转",
	rotateRight: "顺时针旋转",
	confirm: "确认安装",
	cancel: "取消",
	skip: "跳过本回合",
	takeOnly: "取走但不安装",
	boardAria: "你的工厂板",
	cellAria: "工厂格",
	recolorAria: "更改这台机器的端口颜色",
	recolorTitle: "更改端口颜色",
	portInput: "输入",
	portOutput: "输出",
	paletteTitle: "在此格放置部件",
	close: "关闭",
	kindSupply: "供应罐",
	kindOutput: "输出罐",
	kindPipe: "管道",
	colorPink: "粉色",
	colorYellow: "黄色",
	colorGreen: "绿色",
	colorBlue: "蓝色",
	colorBlack: "黑色",
	errNoSuchMachine: "待选区没有这台机器",
	errBadCell: "这格不能放置",
	errNothingToRemove: "这里没有可取回的物件",
	errCannotMoveMachine: "已安装的机器不能移动或取回",
	errCellOccupied: "这格已被占用",
	errTooManyWhite: "白色输出储罐最多三个",
	errDuplicateSupply: "同色供应储罐最多一个",
	errOutputDead: "有产物没有被任何机器或输出储罐接收",
	errMerge: "机器产物与供应储罐不能混接到同一输入端",
	errPerpetual: "机器的输出不能接回它自己的输入",
	errNoSource: "有输入点没有得到足够的供料",
	errDeadPiece: "有储罐或管道没有接入机器",
	errBadPortColors: "端口颜色与这台机器不符",
	errBadSupply: "供应储罐只能是粉色、黄色、绿色或蓝色",
	errNoMachineHere: "这里没有已安装的机器",
	errPhase: "当前不能进行这个操作",
	errNotYourTurn: "现在轮不到你",
	endCash: "现金 {{n}} 元",
	endChips: "清晰圆片 {{n}} 点，计 {{score}} 元",
	endScore: "合计 {{n}} 元",
	endMachines: "工厂里有 {{n}} 台机器",
	displayTitle: "待选机器",
	playersTitle: "玩家",
	acting: "当前行动",
	cashAmount: "{{n}} 元",
	chipLabel: "清晰圆片",
	chipAmount: "{{n}} 点",
	cashLabel: "现金",
	totalLabel: "总分",
	chipEquation: "× {{value}} = {{score}} 元",
	endingTitle: "工厂交付结算",
	soloResult: "本局成绩",
	ranking: "排名",
	rank: "第 {{n}} 名",
	tiedRank: "并列第 {{n}} 名",
	winner: "获胜",
	scoreTab: "成绩",
	factoryTab: "工厂回看",
	factoryOf: "{{name}}的工厂",
	scoreOf: "{{name}}的计分明细",
	confirmLobby: "确认返回大厅",
	confirmAgain: "确认再来一局",
	addHere: "在这格放置储罐或管道",
	placeHere: "在这格预览机器",
	removePiece: "取回部件",
	restorePiece: "恢复部件",
	undoPiece: "撤销暂放的部件",
	showTools: "显示机器工具",
	hideTools: "收起机器工具",
	cellAction: "第 {{column}} 列第 {{row}} 格，{{action}}",
	fitBoard: "回全景"
}, Xe = {
	1: "减量罐",
	2: "包装大师",
	3: "裁判机",
	4: "压缩机",
	5: "结晶器",
	6: "微笑机",
	7: "导管机",
	8: "乙烯基加工机",
	9: "彩虹发生器",
	10: "思考罐",
	11: "D-6 量化器",
	12: "鹦鹉螺",
	13: "聚焦器",
	14: "爆破机",
	15: "加速器",
	16: "巨力机",
	17: "变形机",
	18: "X 型装箱机",
	19: "倍增器",
	20: "三联炉",
	21: "环形机",
	22: "粉碎机",
	23: "重组机",
	24: "沸腾旋风炉",
	25: "品质检测机",
	26: "优造机",
	27: "磁化器",
	28: "时间机器",
	29: "节能机",
	30: "解放机",
	31: "六角包装机",
	32: "复古加工机",
	33: "极限沸腾炉",
	34: "超亮灯",
	35: "像素发生器",
	36: "爆鸣管",
	37: "熔岩熔接机",
	38: "蒙德里安机",
	39: "米宝制造机",
	40: "幽灵捕捉机",
	41: "闪电 3000",
	42: "熔融炉",
	43: "光谱发生器",
	44: "大型混合机",
	45: "超级封口机",
	46: "装袋大师",
	47: "耗散器 82",
	48: "加湿器"
}, Ze = 8;
function Qe(e) {
	return /* @__PURE__ */ g($e, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function $e({ pub: e, members: t, myRid: n, send: r }) {
	let a = c(), l = s((e) => e.locale), [u, v] = o(null), [y, b] = o(null), [x, S] = o(!1), [C, w] = o([]), [E, D] = o([]), [k, A] = o(null), [N, P] = o(null), [F, I] = o(null), [L, te] = o(null), [V, ne] = o(null), H = e.phase === "play" && e.actor === n, re = e.solo, U = i(() => e.boards[n] ?? {}, [e.boards, n]), oe = e.players.reduce((e, t) => e + t.turns, 0), G = `${n}:${e.actor ?? ""}:${oe}:${e.phase}`, [se, ce] = o(G);
	se !== G && (ce(G), v(null), b(null), S(!1), w([]), D([]), A(null), P(null), I(null));
	let K = (e) => d[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % d.length].hex, q = (e) => {
		let n = t.find((t) => t.rid === e), r = d[(n?.colorIndex ?? 0) % d.length];
		return n && m(n, l).trim() || a(r.nameKey);
	}, J = (e) => {
		if (!V || !e) return null;
		let t = qe(V, ...M(...j(e)));
		if (!t) return null;
		let n = t.top < V.height / 2, r = n ? V.height - t.top : t.top;
		return {
			...t,
			below: n,
			offset: Math.min(Math.max(10, V.scale * .79), Math.max(8, r - 85))
		};
	}, le = i(() => y ? ae(U, y.machine, y.cell, y.rot, y.portColors, C, E) : null, [
		y,
		U,
		C,
		E
	]), ue = le ?? U, Y = le ? be(le) : null, X = Y ? U : ue, de = i(() => ie(X), [X]), fe = i(() => Ne(de), [de]), pe = i(() => W(X).chipDots, [X]), me = e.players.find((e) => e.rid === n)?.turns ?? 0, he = L ? U[L.cell] : void 0, ge = L?.rid === n && me === L.turn + 1 && he?.kind === "machine" && he.id === L.machine ? L.cell : null, _e = y && !Y ? de.flatMap(({ inPorts: e, outPorts: t }) => [...e, ...t]).filter((e) => e.cell === y.cell) : [], ve = (e) => T[e].ports.map((e) => e.colors[0]), Z = () => {
		v(null), b(null), S(!1), w([]), D([]), A(null), P(null), I(null);
	}, ye = (e) => {
		if (H) {
			if (w([]), D([]), A(null), P(null), I(null), u === e) {
				v(null), b(null);
				return;
			}
			v(e), b(null);
		}
	}, xe = (e) => {
		D((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), A(null);
	}, Se = (e) => {
		let t = U[e];
		return H && !y && t?.kind === "machine" && O(T[t.id]).length > 0;
	}, Ce = (e) => {
		if (!H) return;
		if (!y && Se(e)) {
			P((t) => t === e ? null : e), I(null);
			return;
		}
		if (N && (P(null), I(null)), u === null || !z.has(e)) return;
		let t = U[e];
		if (!y) {
			if (C.some((t) => t.cell === e)) {
				w((t) => t.filter((t) => t.cell !== e));
				return;
			}
			if (t) {
				t.kind !== "machine" && xe(e);
				return;
			}
			b({
				machine: u,
				cell: e,
				rot: 0,
				portColors: ve(u)
			});
			return;
		}
		if (e === y.cell) {
			k ? A(null) : S((e) => !e);
			return;
		}
		if (C.some((t) => t.cell === e)) {
			w((t) => t.filter((t) => t.cell !== e));
			return;
		}
		if (t) {
			t.kind !== "machine" && xe(e);
			return;
		}
		A(e);
	}, we = (e) => b((t) => t && {
		...t,
		rot: (t.rot + e + 6) % 6
	}), Te = (e, t) => b((n) => {
		if (!n) return n;
		let r = [...n.portColors];
		return r[e] = t, {
			...n,
			portColors: r
		};
	}), Q = N ? U[N] : void 0, De = Q?.kind === "machine" ? T[Q.id] : null, Oe = (e, t) => {
		if (!N || !Q || Q.kind !== "machine") return;
		let n = T[Q.id].ports.map((e, t) => B(e.colors, t, Q.portColors));
		n[e] = t;
		let i = be({
			...U,
			[N]: {
				...Q,
				portColors: n
			}
		});
		if (i) {
			I(i.code);
			return;
		}
		I(null), r({
			type: "recolor",
			cell: N,
			portColors: n
		});
	}, ke = () => {
		y && u !== null && !Y && e.display.includes(u) && (te({
			rid: n,
			turn: me,
			cell: y.cell,
			machine: u
		}), r({
			type: "build",
			machine: u,
			cell: y.cell,
			rot: y.rot,
			portColors: y.portColors,
			add: C,
			remove: E
		}), Z());
	}, Ae = (e, t) => {
		k && (w((n) => [...n, {
			cell: k,
			kind: e,
			color: t
		}]), A(null));
	}, je = H ? a(u === null ? re ? "games.factoryfunner.soloStagePick" : "games.factoryfunner.stagePick" : y ? Y ? "games.factoryfunner.stageConnect" : "games.factoryfunner.stageReady" : "games.factoryfunner.stagePlace") : a("games.factoryfunner.waitTurn", { name: q(e.actor ?? "") }), Me = t.filter((t) => e.players.some((e) => e.rid === t.rid)), Pe = J(y?.cell ?? null), Fe = J(k), Ie = J(N);
	return /* @__PURE__ */ g("div", {
		className: "ff-screen",
		children: /* @__PURE__ */ g(f, {
			adaptive: !0,
			className: "ff-game",
			scroll: !1,
			actionsHeight: "ff-actions-slot",
			banner: /* @__PURE__ */ _("div", {
				className: "ff-header",
				children: [/* @__PURE__ */ g("h1", {
					className: "ff-title",
					children: a("games.factoryfunner.name")
				}), /* @__PURE__ */ g("span", {
					className: "ff-round",
					children: a("games.factoryfunner.turnChip", { n: Math.min(e.round, Ze) })
				})]
			}),
			actions: /* @__PURE__ */ _("div", {
				className: "ff-actions",
				children: [/* @__PURE__ */ _("div", {
					className: "ff-status",
					children: [/* @__PURE__ */ g("span", { children: a("games.factoryfunner.chipLabel") }), /* @__PURE__ */ g("strong", { children: a("games.factoryfunner.chipAmount", { n: pe }) })]
				}), /* @__PURE__ */ g("div", {
					className: "ff-buttons",
					children: H && (re || u !== null || e.display.length === 0) && /* @__PURE__ */ g("button", {
						type: "button",
						className: "ff-btn ff-btn--skip",
						onClick: () => {
							r(u === null ? { type: "skip" } : {
								type: "skip",
								machine: u
							}), Z();
						},
						children: a(u === null ? re ? "games.factoryfunner.soloSkip" : "games.factoryfunner.skip" : "games.factoryfunner.takeOnly")
					})
				})]
			}),
			children: /* @__PURE__ */ _("div", {
				className: "ff-main",
				children: [
					/* @__PURE__ */ g("div", {
						className: "ff-phase",
						role: "status",
						children: je
					}),
					/* @__PURE__ */ _("section", {
						className: "ff-rack",
						"aria-label": a("games.factoryfunner.displayTitle"),
						children: [/* @__PURE__ */ _("div", {
							className: "ff-rail-head",
							children: [/* @__PURE__ */ g("h2", { children: a("games.factoryfunner.displayTitle") }), /* @__PURE__ */ g("span", { children: a("games.factoryfunner.deckChip", { n: e.deckCount }) })]
						}), /* @__PURE__ */ _("div", {
							className: "ff-display",
							children: [e.display.map((e) => {
								let t = T[e], n = l === "zh" ? Xe[e] ?? t.name : t.name, r = u === e;
								return /* @__PURE__ */ _("button", {
									type: "button",
									className: `ff-card${r ? " is-selected" : ""}`,
									disabled: !(H && !y),
									"aria-pressed": r,
									"aria-label": a("games.factoryfunner.machineCardAria", {
										name: n,
										rev: t.rev
									}),
									onClick: () => ye(e),
									children: [/* @__PURE__ */ g("svg", {
										viewBox: "-1.15 -1.15 2.3 2.3",
										className: "ff-card__svg",
										"aria-hidden": !0,
										children: /* @__PURE__ */ g(Re, {
											id: e,
											rot: 0,
											cx: 0,
											cy: 0,
											radius: 1
										})
									}), /* @__PURE__ */ g("span", {
										className: "ff-card__name",
										title: n,
										children: n
									})]
								}, e);
							}), e.display.length === 0 && /* @__PURE__ */ g("div", {
								className: "ff-display-empty",
								children: a("games.factoryfunner.deckEmpty")
							})]
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "ff-stage",
						children: /* @__PURE__ */ _(Je, {
							label: a("games.factoryfunner.boardAria"),
							onTapCell: Ce,
							onProjection: ne,
							overlay: /* @__PURE__ */ _(h, { children: [
								y && Pe && u !== null && !k && !x && /* @__PURE__ */ g(nt, {
									anchor: Pe,
									def: T[u],
									ghost: y,
									valid: !Y,
									errorText: Y ? a(Y.code, Y.params) : null,
									onRotate: we,
									onPortColor: Te,
									onConfirm: ke,
									onCancel: Z
								}),
								Fe && /* @__PURE__ */ g(it, {
									anchor: Fe,
									onPick: Ae,
									onClose: () => A(null)
								}),
								Ie && De && Q?.kind === "machine" && /* @__PURE__ */ g(tt, {
									anchor: Ie,
									def: De,
									piece: Q,
									errorText: F ? a(F) : null,
									onPick: Oe,
									onClose: () => {
										P(null), I(null);
									}
								})
							] }),
							children: [R.map((e) => {
								let [t, n] = j(e), [r, i] = M(t, n);
								if (e === ee) return /* @__PURE__ */ g(ze, {
									cx: r,
									cy: i
								}, e);
								let o = ue[e], s = U[e], c = y?.cell === e, l = H && u !== null && !s && y?.cell !== e && !o, d = H && u !== null && (s ? s.kind !== "machine" : o && o.kind !== "machine"), f = Se(e), p = (l || d || f || c) && V && qe(V, r, i), m = c ? a(x ? "games.factoryfunner.showTools" : "games.factoryfunner.hideTools") : f ? a("games.factoryfunner.recolorAria") : l ? a(y ? "games.factoryfunner.addHere" : "games.factoryfunner.placeHere") : d ? a(s ? o ? "games.factoryfunner.removePiece" : "games.factoryfunner.restorePiece" : "games.factoryfunner.undoPiece") : void 0, h = p && m ? a("games.factoryfunner.cellAction", {
									column: t + 3 + 1,
									row: n + 3 + 1 + Math.min(0, t),
									action: m
								}) : void 0;
								return /* @__PURE__ */ _("g", {
									className: `ff-cell${p ? " is-active" : ""}${l && y ? " is-connecting" : ""}`,
									"data-ff-cell": p ? e : void 0,
									onClick: p ? (t) => {
										t.detail === 0 && Ce(e);
									} : void 0,
									role: p ? "button" : void 0,
									tabIndex: p ? 0 : void 0,
									"aria-label": h,
									"aria-expanded": p && c ? !x && !k : void 0,
									onKeyDown: p ? (t) => {
										(t.key === "Enter" || t.key === " ") && (t.preventDefault(), Ce(e));
									} : void 0,
									children: [
										/* @__PURE__ */ g("polygon", {
											points: $(r, i, Ee),
											className: "ff-hex ff-hex--cell"
										}),
										o && /* @__PURE__ */ g(Be, {
											piece: o,
											cx: r,
											cy: i,
											chips: fe.get(e)
										}),
										(l || f || y?.cell === e) && /* @__PURE__ */ g("polygon", {
											points: $(r, i, l ? .845 : .94),
											className: `ff-target${f ? " ff-target--recolor" : ""}${y?.cell === e ? " ff-target--staged" : ""}`
										}),
										ge === e && /* @__PURE__ */ g("polygon", {
											points: $(r, i, .93),
											className: "ff-settle"
										})
									]
								}, e);
							}), _e.length > 0 && /* @__PURE__ */ g(Ve, { ports: _e })]
						})
					}),
					/* @__PURE__ */ _("section", {
						className: "ff-seats",
						"aria-label": a("games.factoryfunner.playersTitle"),
						children: [/* @__PURE__ */ g("h2", { children: a("games.factoryfunner.playersTitle") }), /* @__PURE__ */ g("ul", {
							className: "ff-players",
							children: Me.map((t) => {
								let r = e.players.find((e) => e.rid === t.rid);
								return /* @__PURE__ */ _("li", {
									className: `ff-player${t.rid === e.actor && e.phase === "play" ? " is-turn" : ""}`,
									style: { "--ff-seat": K(t.rid) },
									"aria-current": t.rid === e.actor && e.phase === "play" ? "true" : void 0,
									children: [
										/* @__PURE__ */ g(p, {
											m: t,
											myRid: n,
											action: null,
											anchorName: `seat:${t.rid}`,
											box: "ff-player__avatar",
											img: "ff-player__avatar-img"
										}),
										/* @__PURE__ */ g("span", {
											className: "ff-player__name",
											title: q(t.rid),
											children: q(t.rid)
										}),
										/* @__PURE__ */ g("span", {
											className: "ff-player__cash",
											children: a("games.factoryfunner.cashAmount", { n: r.money })
										}),
										t.rid === e.actor && e.phase === "play" && /* @__PURE__ */ g("span", {
											className: "ff-player__turns",
											children: a("games.factoryfunner.acting")
										})
									]
								}, t.rid);
							})
						})]
					})
				]
			})
		})
	});
}
function et({ left: e, top: t, offset: n }) {
	return {
		"--ff-pop-x": `${e}px`,
		"--ff-pop-y": `${t}px`,
		"--ff-pop-offset": `${n}px`
	};
}
function tt({ anchor: e, def: t, piece: n, errorText: r, onPick: i, onClose: a }) {
	let o = c();
	return /* @__PURE__ */ _("div", {
		className: `ff-pop ff-machine-pop${e.below ? " is-below" : ""}`,
		style: et(e),
		role: "dialog",
		"aria-label": o("games.factoryfunner.recolorTitle"),
		children: [
			/* @__PURE__ */ _("div", {
				className: "ff-palette__title",
				children: [o("games.factoryfunner.recolorTitle"), /* @__PURE__ */ g("button", {
					type: "button",
					className: "ff-tool",
					"aria-label": o("games.factoryfunner.close"),
					onClick: a,
					children: /* @__PURE__ */ g(l, { size: 16 })
				})]
			}),
			O(t).map((e) => {
				let r = t.ports[e], a = B(r.colors, e, n.portColors);
				return /* @__PURE__ */ _("div", {
					className: "ff-palette__row",
					children: [/* @__PURE__ */ g("span", {
						className: "ff-palette__label",
						children: o(r.kind === "in" ? "games.factoryfunner.portInput" : "games.factoryfunner.portOutput")
					}), r.colors.map((t) => /* @__PURE__ */ g("button", {
						type: "button",
						className: `ff-swatch${a === t ? " is-on" : ""}`,
						style: { background: Q[t] },
						"aria-label": o(rt[t]),
						"aria-pressed": a === t,
						onClick: () => i(e, t)
					}, t))]
				}, e);
			}),
			r && /* @__PURE__ */ g("div", {
				className: "ff-palette__err",
				role: "status",
				children: r
			})
		]
	});
}
function nt({ anchor: e, def: t, ghost: n, valid: r, errorText: i, onRotate: a, onPortColor: o, onConfirm: s, onCancel: d }) {
	let f = c(), p = O(t);
	return /* @__PURE__ */ _("div", {
		className: `ff-pop ff-ghost-tools${e.below ? " is-below" : ""}`,
		style: et(e),
		children: [
			/* @__PURE__ */ _("div", {
				className: "ff-ghost-tools__row",
				children: [
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.rotateLeft"),
						onClick: () => a(-1),
						children: /* @__PURE__ */ g(u, {
							size: 16,
							className: "ff-rotate-left"
						})
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.rotateRight"),
						onClick: () => a(1),
						children: /* @__PURE__ */ g(u, { size: 16 })
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "ff-tool ff-tool--ok",
						disabled: !r,
						onClick: s,
						children: f("games.factoryfunner.confirm")
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "ff-tool",
						"aria-label": f("games.factoryfunner.cancel"),
						onClick: d,
						children: /* @__PURE__ */ g(l, { size: 16 })
					})
				]
			}),
			p.map((e) => /* @__PURE__ */ g("div", {
				className: "ff-ghost-tools__row ff-ghost-tools__colors",
				children: t.ports[e].colors.map((t) => /* @__PURE__ */ g("button", {
					type: "button",
					className: `ff-swatch${n.portColors[e] === t ? " is-on" : ""}`,
					style: { background: Q[t] },
					"aria-label": f(rt[t]),
					"aria-pressed": n.portColors[e] === t,
					onClick: () => o(e, t)
				}, t))
			}, e)),
			i && /* @__PURE__ */ g("div", {
				className: "ff-ghost-tools__err",
				role: "status",
				children: i
			})
		]
	});
}
var rt = {
	pink: "games.factoryfunner.colorPink",
	yellow: "games.factoryfunner.colorYellow",
	green: "games.factoryfunner.colorGreen",
	blue: "games.factoryfunner.colorBlue",
	black: "games.factoryfunner.colorBlack"
};
function it({ anchor: e, onPick: t, onClose: n }) {
	let r = c(), i = [
		{
			kind: "supply",
			label: r("games.factoryfunner.kindSupply"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue"
			]
		},
		{
			kind: "output",
			label: r("games.factoryfunner.kindOutput"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue",
				"black"
			]
		},
		{
			kind: "pipe",
			label: r("games.factoryfunner.kindPipe"),
			colors: [
				"pink",
				"yellow",
				"green",
				"blue",
				"black"
			]
		}
	];
	return /* @__PURE__ */ _("div", {
		className: `ff-pop ff-palette${e.below ? " is-below" : ""}`,
		style: et(e),
		role: "dialog",
		"aria-label": r("games.factoryfunner.paletteTitle"),
		children: [/* @__PURE__ */ _("div", {
			className: "ff-palette__title",
			children: [r("games.factoryfunner.paletteTitle"), /* @__PURE__ */ g("button", {
				type: "button",
				className: "ff-tool",
				"aria-label": r("games.factoryfunner.close"),
				onClick: n,
				children: /* @__PURE__ */ g(l, { size: 16 })
			})]
		}), i.map((e) => /* @__PURE__ */ _("div", {
			className: "ff-palette__row",
			children: [/* @__PURE__ */ g("span", {
				className: "ff-palette__label",
				children: e.label
			}), e.colors.map((n) => /* @__PURE__ */ g("button", {
				type: "button",
				className: "ff-swatch",
				style: { background: Q[n] },
				"aria-label": `${e.label} ${r(rt[n])}`,
				onClick: () => t(e.kind, n)
			}, n))]
		}, e.kind))]
	});
}
//#endregion
//#region src/game/bot.ts
var at = {
	costWeight: 1,
	chipWeight: 2.5,
	spaceWeight: .06,
	maxPipe: 6
};
function ot(e, t, n) {
	for (let r of ne(e)) if (r.edge === t && r.color === n) return { kind: r.kind };
	return null;
}
function st(e, t, n, r) {
	let i = ot(e, t, n);
	return i ? e.kind === "pipe" ? !0 : r === "in" ? e.kind === "supply" || e.kind === "machine" && i.kind === "out" : e.kind === "output" || e.kind === "machine" && i.kind === "in" : !1;
}
function ct(e) {
	if (oe(e) > 3) return null;
	let t = G(e);
	for (let e of [
		"pink",
		"yellow",
		"green",
		"blue"
	]) if (t[e] > 1) return null;
	let n = W(e);
	return n.ok ? n.chipDots : null;
}
function lt(e, t, n, r, i, a, o = !1) {
	if (r[e]) return null;
	let s = /* @__PURE__ */ new Map([[e, null]]), c = /* @__PURE__ */ new Map([[e, 0]]), l = [e], u = null;
	for (; l.length > 0;) {
		let e = l.shift(), d = c.get(e);
		for (let a of b) {
			let s = F(e, a);
			if (s === i) continue;
			let c = r[s];
			if (c && st(c, P[a], t, n) && (!o || c.kind === "supply")) {
				u = e;
				break;
			}
		}
		if (u) break;
		if (!(d >= a)) for (let t of b) {
			let n = F(e, t);
			n === i || !z.has(n) || r[n] || s.has(n) || (s.set(n, e), c.set(n, d + 1), l.push(n));
		}
	}
	if (!u) return null;
	let d = [], f = u;
	for (; f;) d.push(f), f = s.get(f) ?? null;
	return d.map((e) => ({
		cell: e,
		kind: "pipe",
		color: t
	}));
}
function ut(e, t, n, r, i, a) {
	if (!z.has(e) || !z.has(t) || r[t] || r[e] || e === i || t === i) return null;
	if (e === t) return [{
		cell: e,
		kind: "pipe",
		color: n
	}];
	let o = /* @__PURE__ */ new Map([[e, null]]), s = /* @__PURE__ */ new Map([[e, 0]]), c = [e], l = null;
	for (; c.length > 0;) {
		let e = c.shift(), n = s.get(e);
		for (let n of b) if (F(e, n) === t) {
			l = e;
			break;
		}
		if (l) break;
		if (!(n >= a)) for (let a of b) {
			let l = F(e, a);
			l === t || l === i || !z.has(l) || r[l] || o.has(l) || (o.set(l, e), s.set(l, n + 1), c.push(l));
		}
	}
	if (!l) return null;
	let u = [], d = l;
	for (; d;) u.push(d), d = o.get(d) ?? null;
	return u.map((e) => ({
		cell: e,
		kind: "pipe",
		color: n
	}));
}
function dt(e, t) {
	let n = new Map(e.adds.map((e) => [e.cell, e]));
	for (let r of t.adds) {
		if (e.removes.includes(r.cell)) return null;
		let t = n.get(r.cell);
		if (t) {
			if (t.kind !== r.kind || t.color !== r.color) return null;
			continue;
		}
		n.set(r.cell, r);
	}
	let r = new Set(e.removes);
	for (let e of t.removes) {
		if (n.has(e)) return null;
		r.add(e);
	}
	return {
		adds: [...n.values()],
		removes: [...r]
	};
}
function ft(e = at) {
	return function(t, n) {
		let r = t.public;
		if (r.phase !== "play" || r.actor !== n.rid) return null;
		let i = r.boards[n.rid] ?? {};
		if (r.display.length === 0) return { action: { type: "skip" } };
		let a = [], o = [];
		for (let e of ie(i)) {
			if (e.supplyCells.length === 1 && e.inPorts.length === 1 && e.outPorts.length === 0) {
				let t = e.inPorts[0];
				t.color !== "black" && a.push({
					cell: t.cell,
					edge: t.edge,
					color: t.color,
					n: t.n,
					supplyCell: e.supplyCells[0]
				});
			}
			if (e.outputCells.length === 1 && e.outPorts.length === 1 && e.inPorts.length === 0) {
				let t = e.outPorts[0];
				o.push({
					cell: t.cell,
					edge: t.edge,
					color: t.color,
					n: t.n,
					tankCell: e.outputCells[0]
				});
			}
		}
		let s = { v: null }, c = (t, n) => {
			let r = ct(t);
			if (r === null) return;
			let i = n, a = T[i.machine].rev - i.add.length * e.costWeight + r * e.chipWeight - Object.keys(t).length * e.spaceWeight;
			(!s.v || a > s.v.score) && (s.v = {
				action: n,
				score: a
			});
		};
		for (let t of r.display) {
			let n = T[t];
			for (let r of R) if (z.has(r) && !i[r]) for (let s = 0; s < 6; s += 1) {
				let l = [], u = !1;
				for (let t of n.ports) {
					let n = F(r, D(t.edge, s));
					if (!z.has(n) || n === r) {
						u = !0;
						break;
					}
					let c = [];
					for (let s of t.colors) {
						if (i[n]) {
							c.push({
								color: s,
								adds: [],
								removes: []
							});
							continue;
						}
						if (c.push({
							color: s,
							adds: [{
								cell: n,
								kind: t.kind === "in" ? "supply" : "output",
								color: s
							}],
							removes: []
						}), t.kind === "in") {
							let a = lt(n, s, "in", i, r, e.maxPipe, !0);
							a && c.push({
								color: s,
								adds: a,
								removes: []
							});
							let l = lt(n, s, "in", i, r, e.maxPipe);
							l && c.push({
								color: s,
								adds: l,
								removes: []
							});
							for (let a of o) {
								if (a.color !== s || a.n !== t.n) continue;
								let o = ut(F(a.cell, a.edge), n, s, i, r, e.maxPipe);
								o && c.push({
									color: s,
									adds: o,
									removes: [a.tankCell]
								});
							}
						} else for (let o of a) {
							if (o.color !== s || o.n !== t.n) continue;
							let a = ut(n, F(o.cell, o.edge), s, i, r, e.maxPipe);
							a && c.push({
								color: s,
								adds: a,
								removes: [o.supplyCell]
							});
						}
					}
					if (c.length === 0) {
						u = !0;
						break;
					}
					l.push(c);
				}
				if (u) continue;
				let d = n.ports.map((e) => e.colors[0]), f = (e, a) => {
					if (e === n.ports.length) {
						let e = ae(i, t, r, s, [...d], a.adds, a.removes);
						c(e, {
							type: "build",
							machine: t,
							cell: r,
							rot: s,
							portColors: [...d],
							add: a.adds,
							remove: a.removes
						});
						return;
					}
					for (let t of l[e]) {
						d[e] = t.color;
						let n = dt(a, t);
						n && f(e + 1, n);
					}
					d[e] = n.ports[e].colors[0];
				};
				f(0, {
					adds: [],
					removes: []
				});
			}
		}
		if (s.v) return { action: s.v.action };
		let l = r.display[0];
		for (let e of r.display) T[e].rev < T[l].rev && (l = e);
		return { action: {
			type: "skip",
			machine: l
		} };
	};
}
var pt = ft();
//#endregion
//#region src/game/game-over-row.tsx
function mt({ public: e, rid: t }) {
	let n = e, r = n.boards[t] ?? {}, i = W(r).chipDots, a = n.players.find((e) => e.rid === t)?.money ?? 0;
	return /* @__PURE__ */ _("div", {
		className: "ff-end",
		children: [/* @__PURE__ */ g("div", {
			className: "ff-end-thumbnail",
			children: /* @__PURE__ */ g(He, { board: r })
		}), /* @__PURE__ */ g(ht, {
			money: a,
			chips: i
		})]
	});
}
function ht({ money: e, chips: t }) {
	let n = c(), r = t * 3;
	return /* @__PURE__ */ _("dl", {
		className: "ff-score",
		children: [
			/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: n("games.factoryfunner.cashLabel") }), /* @__PURE__ */ g("dd", { children: n("games.factoryfunner.cashAmount", { n: e }) })] }),
			/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("dt", { children: [
				n("games.factoryfunner.chipLabel"),
				" ",
				n("games.factoryfunner.chipAmount", { n: t })
			] }), /* @__PURE__ */ g("dd", { children: n("games.factoryfunner.chipEquation", {
				value: 3,
				score: r
			}) })] }),
			/* @__PURE__ */ _("div", {
				className: "ff-score__total",
				children: [/* @__PURE__ */ g("dt", { children: n("games.factoryfunner.totalLabel") }), /* @__PURE__ */ g("dd", { children: n("games.factoryfunner.cashAmount", { n: e + r }) })]
			})
		]
	});
}
//#endregion
//#region src/game/game-over.tsx
function gt({ result: e, public: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l }) {
	let u = c(), f = s((e) => e.locale), v = t, [b, x] = o(e.ranking[0] ?? r), [S, C] = o(!1), w = v.boards[b] ?? {}, T = v.players.find((e) => e.rid === b)?.money ?? 0, E = W(w).chipDots, D = (e) => {
		let t = n.find((t) => t.rid === e), r = d[(t?.colorIndex ?? 0) % d.length];
		return t && m(t, f).trim() || u(r.nameKey);
	}, O = e.ranking.map((t) => e.scores?.[t]), k = u("games.factoryfunner.factoryOf", { name: D(b) });
	return /* @__PURE__ */ _("div", {
		className: `ff-screen ff-result${S ? " is-reviewing" : ""}`,
		children: [
			/* @__PURE__ */ _("header", {
				className: "ff-result-header",
				children: [/* @__PURE__ */ g("h1", {
					className: "ff-title",
					children: u(v.solo ? "games.factoryfunner.soloResult" : "games.factoryfunner.endingTitle")
				}), i !== void 0 && /* @__PURE__ */ g("span", { children: u("session.hint.usedCount", { n: i }) })]
			}),
			/* @__PURE__ */ _("div", {
				className: "ff-result-switch",
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: "ff-btn",
					"aria-pressed": !S,
					onClick: () => C(!1),
					children: u("games.factoryfunner.scoreTab")
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "ff-btn",
					"aria-pressed": S,
					onClick: () => C(!0),
					children: u("games.factoryfunner.factoryTab")
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "ff-result-main",
				children: [/* @__PURE__ */ _("section", {
					className: "ff-result-ranking",
					"aria-label": u(v.solo ? "games.factoryfunner.soloResult" : "games.factoryfunner.ranking"),
					children: [
						!v.solo && /* @__PURE__ */ g("h2", {
							className: "ff-result-rank-title",
							children: u("games.factoryfunner.ranking")
						}),
						/* @__PURE__ */ g("ol", {
							className: "ff-ranks",
							children: e.ranking.map((t, i) => {
								let a = n.find((e) => e.rid === t), o = O[i], s = o === void 0 ? i : O.indexOf(o), c = o !== void 0 && O.lastIndexOf(o) > s, l = e.autopilot?.[t];
								return /* @__PURE__ */ g("li", { children: /* @__PURE__ */ _("button", {
									type: "button",
									className: "ff-rank",
									"aria-pressed": t === b,
									onClick: () => x(t),
									children: [
										a && /* @__PURE__ */ g(p, {
											m: a,
											myRid: r,
											action: null,
											anchorName: null,
											box: "ff-player__avatar",
											img: "ff-player__avatar-img"
										}),
										/* @__PURE__ */ _("span", {
											className: "ff-rank__identity",
											children: [
												/* @__PURE__ */ g("strong", { children: D(t) }),
												!v.solo && /* @__PURE__ */ _("small", { children: [u(c ? "games.factoryfunner.tiedRank" : "games.factoryfunner.rank", { n: s + 1 }), e.winner.includes(t) && /* @__PURE__ */ _(h, { children: [" · ", u("games.factoryfunner.winner")] })] }),
												l !== void 0 && l > 0 && /* @__PURE__ */ g("small", { children: u("session.autopilot.share", { n: Math.round(l * 100) }) })
											]
										}),
										o !== void 0 && /* @__PURE__ */ g("strong", {
											className: "ff-rank__points",
											children: o
										})
									]
								}) }, t);
							})
						}),
						/* @__PURE__ */ g("h2", { children: u("games.factoryfunner.scoreOf", { name: D(b) }) }),
						/* @__PURE__ */ g(ht, {
							money: T,
							chips: E
						}),
						/* @__PURE__ */ g("button", {
							className: "ff-result-preview",
							type: "button",
							onClick: () => C(!0),
							"aria-label": u("games.factoryfunner.factoryTab"),
							children: /* @__PURE__ */ g(He, { board: w })
						})
					]
				}), /* @__PURE__ */ _("section", {
					className: "ff-result-factory",
					children: [/* @__PURE__ */ g("h2", { children: k }), /* @__PURE__ */ g(Je, {
						label: k,
						children: /* @__PURE__ */ g(Ue, {
							board: w,
							chipEdges: Ne(ie(w))
						})
					})]
				})]
			}),
			/* @__PURE__ */ _("footer", {
				className: "ff-result-footer",
				children: [
					l && /* @__PURE__ */ g(y, {
						compact: !0,
						label: u("session.result.backToLobby"),
						confirmLabel: u("games.factoryfunner.confirmLobby"),
						onConfirm: l,
						className: "ff-result-button"
					}),
					a && /* @__PURE__ */ g(y, {
						compact: !0,
						label: u("session.result.playAgain"),
						confirmLabel: u("games.factoryfunner.confirmAgain"),
						onConfirm: a,
						className: "ff-result-button ff-result-button--primary"
					}),
					!l && !a && /* @__PURE__ */ g("span", { children: u("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var _t = {
	definition: Te,
	View: Qe,
	bot: pt,
	OverView: gt,
	RowView: mt,
	locales: {
		zh: Ye,
		en: {
			name: "Factory Funner",
			desc: "Draft machines, wire your pipes, and process products — highest total after eight rounds wins; solo mode supported",
			rules: "Goal:\nEach player runs a factory. Over eight rounds you each draft one machine per round and install it into your factory network, so that product flows from supply reservoirs through machines and on to other machines or output reservoirs. Machines earn revenue when installed, and chaining them earns extra points at the end. In a multiplayer game, the player with the most money after eight rounds wins; solo rules are described below.\nSetup:\n· Each player takes one factory board. A board has 37 hexagonal spaces in all; the center space is an obstacle and nothing may be placed on it, leaving 36 playable spaces.\n· In a multiplayer game, shuffle all 48 machines face down into a deck, then turn three face up into a shared display. Whenever a machine is taken, immediately refill the display from the deck.\n· Each player starts with $10. In a multiplayer game, the first player is chosen at random, and play proceeds in seat order.\nMachines:\n· Each machine is a hexagonal tile. A rounded port is an input, and its white dots show how many units of material it needs. A pointed port is an output. Its number shows how many units it produces, and a white diamond on a black port means one unit of black end product.\n· The pale silhouette identifies the machine. The number on the black plate is the revenue you gain when you install it.\n· Some machine ports accept more than one color, shown on the tile as several color bands. Choose one color when you install the machine. On your later turns you may tap an installed machine to change these port colors; changing colors does not use your action, but the whole factory must remain legal afterwards.\nTurn:\nIn a multiplayer game, on your turn, choose one machine from the display and install it on your factory board, then refill the display from the deck. If you cannot legally install the machine you chose, you may take it without installing it, with no penalty. When the deck runs out, shuffle the machines that players did not install to form a new deck. Every player takes eight turns, after which the game ends.\nSolo mode:\n· In a solo game, randomly take eight machines from the full set and form them into a face-down deck. Each turn, turn over the top machine of the deck and try to install it in your factory. If you cannot or do not wish to install it, you may give up that machine with no penalty.\n· The game lasts eight turns, until the deck is empty. At the end, score cash and clear chips exactly as in the multiplayer game.\nInstalling and costs:\n· Machines may be rotated freely into any of six orientations. Placing a machine is free, and you immediately gain the revenue on its black plate.\n· Each reservoir or pipe you place costs $1.\n· Machines and reservoirs may only be placed on empty spaces; pipes also occupy one space.\n· Machines installed on earlier turns can never be moved or taken back; reservoirs and pipes placed on earlier turns can be taken back for free.\nConnecting:\n· Every input and output of a machine must connect into the factory network.\n· An input either connects to a supply reservoir of the same color, or is fed by a same-color output from another machine.\n· An output either feeds a same-color input of another machine, or is collected by a same-color output reservoir.\n· Connected ports must share the same color; colors cannot be mixed.\n· The total input gathered by a machine cannot exceed the total output feeding it; one output may be split to feed several machines.\n· A machine's output may never, by any path, connect back to its own input.\n· No dead ends are allowed: every reservoir and pipe must connect to a machine port, and every output reservoir must receive product.\nReservoirs and pipes:\n· Supply reservoirs come in pink, yellow, green, and blue. Each player may place at most one of each color. A supply reservoir produces without limit, can feed several machines at once, and is never consumed.\n· Output reservoirs collect machine product. Each player may place at most three white output reservoirs, and each collects a single color; black output reservoirs are unlimited and collect only black end product.\n· A pipe occupies one space and carries one color, extending a same-color connection; the four colors cannot be mixed in one pipe.\nClear chips:\n· When a machine's input is fed by another machine rather than by a supply reservoir, place a clear chip on each input dot fed by a machine.\n· If that input later switches to a supply reservoir, remove the clear chip.\n· At the end, each clear chip scores $3 for every dot it covers.\nScoring:\n· After all eight rounds, add every player's cash to the value of their clear chips. The highest total wins; ties share the win.",
			deckChip: "Deck {{n}}",
			turnChip: "Round {{n}}",
			waitTurn: "Waiting for {{name}}…",
			stagePick: "Choose a machine from the display",
			stagePlace: "Choose an empty space",
			stageConnect: "Tap a space to add a reservoir or pipe",
			stageReady: "All ports connected. Ready to install.",
			soloStagePick: "Choose the revealed machine",
			soloSkip: "Skip this machine",
			machineCardAria: "{{name}}, revenue {{rev}}",
			deckEmpty: "No machines in the display",
			turnsAria: "{{n}} turns taken",
			myCash: "Cash ${{n}}",
			myChips: "Chips {{n}} dots",
			myTurns: "Turn {{n}} / {{total}}",
			rotateLeft: "Rotate counterclockwise",
			rotateRight: "Rotate clockwise",
			confirm: "Confirm install",
			cancel: "Cancel",
			skip: "Skip this turn",
			takeOnly: "Take without installing",
			boardAria: "Your factory board",
			cellAria: "Factory space",
			recolorAria: "Change this machine's port colors",
			recolorTitle: "Change port colors",
			portInput: "Input",
			portOutput: "Output",
			paletteTitle: "Place a component here",
			close: "Close",
			kindSupply: "Supply",
			kindOutput: "Output",
			kindPipe: "Pipe",
			colorPink: "pink",
			colorYellow: "yellow",
			colorGreen: "green",
			colorBlue: "blue",
			colorBlack: "black",
			errNoSuchMachine: "That machine is not in the display",
			errBadCell: "That space cannot hold a piece",
			errNothingToRemove: "There is nothing to take back here",
			errCannotMoveMachine: "An installed machine cannot be moved or taken back",
			errCellOccupied: "That space is already occupied",
			errTooManyWhite: "At most three white output reservoirs",
			errDuplicateSupply: "At most one supply reservoir of each color",
			errOutputDead: "Some product is not received by any machine or output reservoir",
			errMerge: "Machine product and supply reservoirs cannot feed the same input",
			errPerpetual: "A machine's output cannot connect back to its own input",
			errNoSource: "Some input is not getting enough supply",
			errDeadPiece: "Some reservoir or pipe is not connected to a machine",
			errBadPortColors: "Those port colors do not match this machine",
			errBadSupply: "A supply reservoir must be pink, yellow, green, or blue",
			errNoMachineHere: "There is no installed machine here",
			errPhase: "You cannot do that right now",
			errNotYourTurn: "It is not your turn",
			endCash: "Cash ${{n}}",
			endChips: "Clear chips: {{n}} · ${{score}}",
			endScore: "Total ${{n}}",
			endMachines: "{{n}} machines in the factory",
			displayTitle: "Machine display",
			playersTitle: "Players",
			acting: "Current turn",
			cashAmount: "${{n}}",
			chipLabel: "Clear chips",
			chipAmount: "{{n}}",
			cashLabel: "Cash",
			totalLabel: "Total",
			chipEquation: "× {{value}} = ${{score}}",
			endingTitle: "Factory results",
			soloResult: "Your result",
			ranking: "Standings",
			rank: "Rank {{n}}",
			tiedRank: "Tied for rank {{n}}",
			winner: "Winner",
			scoreTab: "Scores",
			factoryTab: "Review factory",
			factoryOf: "{{name}}’s factory",
			scoreOf: "Score breakdown · {{name}}",
			confirmLobby: "Confirm return",
			confirmAgain: "Confirm rematch",
			addHere: "Add a reservoir or pipe here",
			placeHere: "Preview the machine here",
			removePiece: "Take back the component",
			restorePiece: "Restore the component",
			undoPiece: "Remove the staged component",
			showTools: "Show machine controls",
			hideTools: "Hide machine controls",
			cellAction: "Column {{column}}, space {{row}}: {{action}}",
			fitBoard: "Fit board"
		}
	}
};
//#endregion
export { _t as default };
