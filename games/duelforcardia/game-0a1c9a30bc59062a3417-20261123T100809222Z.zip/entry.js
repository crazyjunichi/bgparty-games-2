import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { IconInfo as s } from "@bgparty/sdk/icons";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { AVATARS as g } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as _ } from "@bgparty/sdk/player-colors";
import { GameOverScreen as ee } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as v, OptionSection as te } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var y = {
	rebellion: "#4d9b45",
	academy: "#e0b52a",
	guild: "#d14b3f",
	dynasty: "#4b7fc4"
}, b = [
	"rebellion",
	"academy",
	"guild",
	"dynasty"
], x = [
	{
		id: "i1",
		deck: 1,
		n: 1,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "i2",
		deck: 1,
		n: 2,
		faction: "academy",
		type: "instant"
	},
	{
		id: "i3",
		deck: 1,
		n: 3,
		faction: "guild",
		type: "instant"
	},
	{
		id: "i4",
		deck: 1,
		n: 4,
		faction: "dynasty",
		type: "ongoing"
	},
	{
		id: "i5",
		deck: 1,
		n: 5,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "i6",
		deck: 1,
		n: 6,
		faction: "academy",
		type: "instant"
	},
	{
		id: "i7",
		deck: 1,
		n: 7,
		faction: "guild",
		type: "instant"
	},
	{
		id: "i8",
		deck: 1,
		n: 8,
		faction: "dynasty",
		type: "ongoing"
	},
	{
		id: "i9",
		deck: 1,
		n: 9,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "i10",
		deck: 1,
		n: 10,
		faction: "academy",
		type: "instant"
	},
	{
		id: "i11",
		deck: 1,
		n: 11,
		faction: "guild",
		type: "instant"
	},
	{
		id: "i12",
		deck: 1,
		n: 12,
		faction: "dynasty",
		type: "ongoing"
	},
	{
		id: "i13",
		deck: 1,
		n: 13,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "i14",
		deck: 1,
		n: 14,
		faction: "academy",
		type: "instant"
	},
	{
		id: "i15",
		deck: 1,
		n: 15,
		faction: "guild",
		type: "instant"
	},
	{
		id: "i16",
		deck: 1,
		n: 16,
		faction: "dynasty",
		type: "instant"
	}
], S = [
	{
		id: "ii1",
		deck: 2,
		n: 1,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "ii2",
		deck: 2,
		n: 2,
		faction: "academy",
		type: "instant"
	},
	{
		id: "ii3",
		deck: 2,
		n: 3,
		faction: "guild",
		type: "instant"
	},
	{
		id: "ii4",
		deck: 2,
		n: 4,
		faction: "dynasty",
		type: "instant"
	},
	{
		id: "ii5",
		deck: 2,
		n: 5,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "ii6",
		deck: 2,
		n: 6,
		faction: "academy",
		type: "instant"
	},
	{
		id: "ii7",
		deck: 2,
		n: 7,
		faction: "guild",
		type: "instant"
	},
	{
		id: "ii8",
		deck: 2,
		n: 8,
		faction: "dynasty",
		type: "ongoing"
	},
	{
		id: "ii9",
		deck: 2,
		n: 9,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "ii10",
		deck: 2,
		n: 10,
		faction: "academy",
		type: "instant"
	},
	{
		id: "ii11",
		deck: 2,
		n: 11,
		faction: "guild",
		type: "instant"
	},
	{
		id: "ii12",
		deck: 2,
		n: 12,
		faction: "dynasty",
		type: "ongoing"
	},
	{
		id: "ii13",
		deck: 2,
		n: 13,
		faction: "rebellion",
		type: "instant"
	},
	{
		id: "ii14",
		deck: 2,
		n: 14,
		faction: "academy",
		type: "instant"
	},
	{
		id: "ii15",
		deck: 2,
		n: 15,
		faction: "guild",
		type: "ongoing"
	},
	{
		id: "ii16",
		deck: 2,
		n: 16,
		faction: "dynasty",
		type: "instant"
	}
], C = [...x, ...S], w = Object.fromEntries(C.map((e) => [e.id, e]));
C.map((e) => e.id);
var T = [
	{
		id: "serpent",
		skulls: 1
	},
	{
		id: "bazaar",
		skulls: 1
	},
	{
		id: "founders",
		skulls: 3
	},
	{
		id: "library",
		skulls: 2
	},
	{
		id: "scrapyard",
		skulls: 2
	},
	{
		id: "auction",
		skulls: 2
	},
	{
		id: "catacombs",
		skulls: 3
	},
	{
		id: "swamp",
		skulls: 2
	}
], ne = Object.fromEntries(T.map((e) => [e.id, e])), E = T.map((e) => e.id), D = (e, t) => `p${e}:${t}`, O = (e) => e.slice(e.indexOf(":") + 1), k = {
	id: "duelforcardia",
	uuid: "3d8a5b4e-95fc-4628-9529-bbe93ca7bc62",
	tier: "alpha",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	nameKey: "games.duelforcardia.name",
	descKey: "games.duelforcardia.desc",
	rulesKey: "games.duelforcardia.rules",
	icon: "🃏",
	iconImg: "games/duelforcardia.webp",
	rulesUrl: { en: "https://www.hans-im-glueck.de/wp-content/uploads/2025/07/Cardia_rules_a4_EN.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#8b5cf6",
	releasedAt: "2026-11-22T22:51:05+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 900
}, A = t.int(), re = t.union([t.literal(0), t.literal(1)]), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("play"),
		card: t.string().min(1)
	}),
	t.object({
		type: t.literal("act"),
		kind: t.enum([
			"faction",
			"card",
			"hand",
			"confirm",
			"mode",
			"choice",
			"skip"
		]),
		target: t.string().default(""),
		n: A.optional()
	})
]), j = t.object({
	deck: t.enum(["I", "II"]).default("I"),
	location: t.enum(["none", ...E]).default("none")
}).default({
	deck: "I",
	location: "none"
}), ae = t.object({
	uid: t.string(),
	def: t.string().nullable(),
	owner: re,
	mods: A,
	token: t.boolean(),
	influence: A,
	signets: A,
	faceDown: t.boolean()
}), oe = t.object({
	index: A,
	a: ae.nullable(),
	b: ae.nullable(),
	revealed: t.boolean(),
	dead: t.boolean(),
	sigA: A,
	sigB: A,
	winner: t.enum([
		"a",
		"b",
		"both",
		"tie"
	]).nullable(),
	resolvedRound: A
}), M = t.object({
	kind: t.string(),
	rid: t.string(),
	op: t.string(),
	count: A.optional(),
	factions: t.array(t.string()).optional(),
	modes: t.array(t.string()).optional()
}), N = t.object({
	seq: A,
	kind: t.string(),
	rid: t.string(),
	target: t.string(),
	n: A
}), se = t.object({
	phase: t.enum([
		"preplay",
		"choose",
		"resolve",
		"done"
	]),
	round: A,
	players: t.array(t.object({
		rid: t.string(),
		signets: A,
		hand: A,
		deck: A,
		discard: A,
		discardCards: t.array(t.string()),
		played: t.boolean()
	})),
	lanes: t.array(oe),
	currentIndex: A,
	location: t.string().nullable(),
	deck: t.enum(["I", "II"]),
	task: M.nullable(),
	last: N,
	log: t.array(N),
	winner: t.enum([
		"a",
		"b",
		"draw"
	]).nullable(),
	winReason: t.string()
}), ce = t.object({
	side: re,
	hand: t.array(ae),
	legal: t.array(ie),
	peek: t.array(t.string()),
	nextMod: A
}), P = (e) => +(e === 0), F = (e) => e === 0 ? "a" : "b", I = (e, t) => e[F(t)], le = (e, t, n) => {
	e[F(t)] = n;
}, L = (e) => w[e.def].n + e.mods, ue = (e, t, n) => e.lanes.some((e) => !e.dead && I(e, t)?.def === n && !!I(e, t)?.token);
function de(e, t) {
	for (let n = t - 1; n >= 0; --n) if (!e.lanes[n].dead) return n;
	return null;
}
function fe(e, t) {
	for (let n = t + 1; n < e.lanes.length; n += 1) if (!e.lanes[n].dead) return n;
	return null;
}
function R(e, t) {
	let n = e.lanes[t], r = {
		aWin: !1,
		bWin: !1,
		tie: !1,
		judgeTie: !1,
		sigA: 0,
		sigB: 0
	};
	if (!n || n.dead || !n.revealed || !n.a || !n.b) return r;
	let i = n.a, a = n.b, o = L(i), s = L(a), c = o > s, l = s > o, u = o === s;
	(i.token && i.def === "i4" || a.token && a.def === "i4") && (c = !1, l = !1, u = !0);
	let d = fe(e, t);
	if (d !== null) {
		let t = e.lanes[d], n = !!(t.a?.token && t.a.def === "ii12"), r = !!(t.b?.token && t.b.def === "ii12");
		n && r ? (c = !1, l = !1, u = !0) : n ? (c = !0, l = !1, u = !1) : r && (c = !1, l = !0, u = !1);
	}
	let f = !1;
	if (u) {
		let t = ue(e, 0, "i8"), n = ue(e, 1, "i8");
		(t || n) && (f = !0, u = !1, t && n ? (c = !0, l = !0) : t ? c = !0 : l = !0);
	}
	let p = +!!c, m = +!!l;
	if (c && i.token && i.def === "ii8" && (p += 1), l && a.token && a.def === "ii8" && (m += 1), d !== null) {
		let t = e.lanes[d], n = Number(!!(t.a?.token && t.a.def === "i12")) + Number(!!(t.b?.token && t.b.def === "i12"));
		c && (p += n), l && (m += n);
	}
	return {
		aWin: c,
		bWin: l,
		tie: u,
		judgeTie: f,
		sigA: p,
		sigB: m
	};
}
function z(e, t) {
	return e.lanes.reduce((n, r, i) => {
		let a = R(e, i);
		return n + (t === 0 ? a.sigA : a.sigB);
	}, 0);
}
function pe(e, t) {
	let n = 0, r = 0;
	for (let i = 0; i < e.lanes.length; i += 1) {
		if (e.lanes[i].dead) continue;
		let a = R(e, i);
		(t === 0 ? a.aWin : a.bWin) ? (r += 1, n = Math.max(n, r)) : r = 0;
	}
	return n;
}
function B(e, t, n = "", r = "", i = 0) {
	let a = {
		seq: e.last.seq + 1,
		kind: t,
		rid: n,
		target: r,
		n: i
	};
	e.last = a, e.log.push(a), e.log.length > 40 && e.log.splice(0, e.log.length - 40);
}
function V(e, t, n) {
	e.winner = t, e.winReason = n, e.phase = "done", e.task = null, e.steps = [], e.serpentQueue = [], B(e, "winGame", t === "draw" ? "" : e.players[t].rid, n);
}
function H(e) {
	if (e.winner !== null) return !0;
	if (e.location === "founders") {
		let t = pe(e, 0) >= 3, n = pe(e, 1) >= 3;
		if (t || n) return V(e, t && n ? "draw" : +!t, "founders"), !0;
	}
	let t = [];
	for (let n = 0; n < e.lanes.length; n += 1) {
		let r = e.lanes[n];
		if (!r.dead) for (let i of [0, 1]) {
			let a = I(r, i);
			if (!a?.token || a.def !== "ii15") continue;
			let o = fe(e, n);
			if (o === null || e.lanes[o].resolvedRound < a.armedRound) continue;
			let s = R(e, o);
			(i === 0 ? s.aWin : s.bWin) && t.push(i);
		}
	}
	if (t.length > 0) {
		let n = [...new Set(t)];
		return V(e, n.length > 1 ? "draw" : n[0], "mechanical"), !0;
	}
	return !1;
}
function U(e) {
	let t = e.outcomeCache;
	if (e.outcomeCache = e.lanes.map((t, n) => {
		let r = R(e, n);
		return {
			a: r.aWin,
			b: r.bWin
		};
	}), e.location === "serpent") for (let n = 0; n < Math.min(e.lanes.length, e.revealLane); n += 1) {
		let r = t[n] ?? {
			a: !1,
			b: !1
		}, i = e.outcomeCache[n];
		i.a && !r.a && me(e, n, 0), i.b && !r.b && me(e, n, 1);
	}
}
function me(e, t, n) {
	e.serpentQueue.some((e) => e.lane === t && e.side === n) || e.serpentQueue.push({
		lane: t,
		side: n
	});
}
function W(e, t, n) {
	let r = e.players[t], i = 0;
	for (let e = 0; e < n && r.deck.length > 0; e += 1) {
		let e = r.deck.shift();
		r.hand.push(e), i += 1;
	}
	return i;
}
function he(e, t) {
	if (e.location !== "bazaar") return;
	let n = e.players[t];
	if (n.hand.length <= 1 && n.deck.length > 0) {
		let r = W(e, t, 4);
		r > 0 && B(e, "draw", n.rid, "", r);
	}
}
function G(e, t, n) {
	let r = e.players[t], i = r.hand.indexOf(n);
	return i < 0 ? !1 : (r.hand.splice(i, 1), r.discard.push(O(n)), he(e, t), !0);
}
function ge(e, t, n) {
	let r = e.players[t], i = r.deck.splice(0, n);
	return r.discard.push(...i.map(O)), i.length;
}
function _e(e, t) {
	let n = e.players[t], r = n.deck.length;
	return n.discard.push(...n.deck.map(O)), n.deck = [], r;
}
function ve(t, n) {
	let r = t.players[n];
	for (let n = r.deck.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor, n + 1);
		t.cursor += 1, [r.deck[n], r.deck[i]] = [r.deck[i], r.deck[n]];
	}
}
function K(e, t) {
	for (let n = 0; n < e.lanes.length; n += 1) {
		let r = e.lanes[n];
		if (!r.dead) for (let e of [0, 1]) {
			let i = I(r, e);
			if (i?.uid === t) return {
				lane: n,
				side: e,
				card: i
			};
		}
	}
	return null;
}
function ye(e, t, n) {
	let r = K(e, t);
	r && (r.card.mods += n, U(e), H(e));
}
function q(e, t, n, r) {
	let i = I(e.lanes[t], n);
	i && (i.mods += r, U(e), H(e));
}
function be(e, t, n) {
	e.players[t].nextMods.push(n);
}
function J(e, t, n, r, i = {}) {
	e.task = {
		kind: t,
		rid: n,
		op: r,
		data: i
	};
}
function xe(e) {
	let t = e.lanes[e.lanes.length - 1];
	if (t && !t.dead && t.round === e.round && (!t.a || !t.b)) return t;
	let n = {
		a: null,
		b: null,
		revealed: !1,
		dead: !1,
		resolvedRound: 0,
		round: e.round
	};
	return e.lanes.push(n), n;
}
function Se(e) {
	!e.a && !e.b && (e.dead = !0);
}
function Ce(e, t, n) {
	let r = e.lanes[t], i = I(r, n);
	return i ? (i.pendingBonus !== 0 && e.phase === "resolve" && t === e.revealLane && e.players[n].nextMods.push(i.pendingBonus), le(r, n, null), e.players[n].discard.push(i.def), Se(r), !0) : !1;
}
function we(e, t, n) {
	let r = e.lanes[t], i = I(r, n);
	return i ? (le(r, n, null), e.players[n].hand.push(i.uid), Se(r), !0) : !1;
}
function Te(e, t, n) {
	let r = I(e.lanes[t], n);
	r && (r.token || (r.token = !0, r.armedRound = e.round, B(e, "token", e.players[n].rid, r.def)), U(e), H(e));
}
function Ee(t, n, r) {
	let i = j.parse(t), a = i.deck === "I" ? x : S, o = {
		players: [{
			rid: n[0],
			hand: [],
			deck: [],
			discard: [],
			nextMods: [],
			librarian: 0,
			preplay: !1,
			blackmail: null
		}, {
			rid: n[1],
			hand: [],
			deck: [],
			discard: [],
			nextMods: [],
			librarian: 0,
			preplay: !1,
			blackmail: null
		}],
		seed: r,
		cursor: 0,
		round: 1,
		phase: "choose",
		lanes: [],
		location: i.location === "none" ? null : i.location,
		deck: i.deck,
		task: null,
		steps: [],
		winner: null,
		winReason: "",
		last: {
			seq: 0,
			kind: "setup",
			rid: "",
			target: "",
			n: 0
		},
		log: [],
		outcomeCache: [],
		serpentQueue: [],
		revealLibSides: [],
		revealLane: -1,
		preplayQueue: [],
		endBottoms: [],
		blackmailQueue: [],
		blackmailLane: -1
	};
	for (let t of [0, 1]) {
		let n = a.map((e) => D(t, e.id));
		for (let t = n.length - 1; t > 0; --t) {
			let i = e(r, o.cursor, t + 1);
			o.cursor += 1, [n[t], n[i]] = [n[i], n[t]];
		}
		o.players[t].deck = n, W(o, t, o.location === "library" ? 2 : 5);
	}
	return { state: o };
}
function Y(e, t) {
	let n = e.players.findIndex((e) => e.rid === t.rid);
	if (n < 0) return [];
	let r = n, i = t.data, a = typeof i.lane == "number" ? i.lane : null, o = e.players[r], s = [], c = (e, t) => s.push({
		type: "act",
		kind: e,
		target: t
	}), l = () => e.lanes.flatMap((e) => e.dead ? [] : [e.a, e.b]).filter((e) => !!e), u = () => e.lanes.flatMap((e, t) => !e.dead && I(e, r) ? [{
		lane: t,
		card: I(e, r)
	}] : []);
	switch (t.op) {
		case "palace-faction":
		case "ambusher-faction":
		case "witch-faction":
		case "blackmail-faction":
			for (let e of b) c("faction", e);
			break;
		case "palace-confirm":
			c("confirm", "yes"), c("confirm", "no");
			break;
		case "void-mode":
			l().some((e) => e.mods !== 0) && c("mode", "mods"), l().some((e) => e.token) && c("mode", "tokens");
			break;
		case "void-card":
			for (let e of l()) c("card", e.uid);
			break;
		case "swamp-card":
			for (let e of u()) e.lane !== a && c("card", e.card.uid);
			break;
		case "magistra-card": {
			let t = a === null ? null : I(e.lanes[a], r);
			if (!t) break;
			let n = i.visited ?? [];
			for (let e of u()) e.lane !== a && (n.includes(e.card.uid) || w[e.card.def].type === "instant" && L(e.card) >= L(t) && c("card", e.card.uid));
			break;
		}
		case "illusionist-card": {
			let t = i.visited ?? [];
			for (let n of u()) {
				if (t.includes(n.card.uid)) continue;
				let i = R(e, n.lane), a = r === 0 ? i.sigB : i.sigA, o = r === 0 ? i.sigA : i.sigB;
				a > 0 && o === 0 && c("card", n.card.uid);
			}
			break;
		}
		case "inventor-first":
			for (let e of l()) c("card", e.uid);
			break;
		case "inventor-second": {
			let e = String(i.first ?? "");
			for (let t of l()) t.uid !== e && c("card", t.uid);
			break;
		}
		case "kinesis-source":
			for (let e of u()) (e.card.mods !== 0 || e.card.token) && c("card", e.card.uid);
			break;
		case "kinesis-target": {
			let e = String(i.source ?? "");
			for (let t of u()) t.card.uid !== e && c("card", t.card.uid);
			break;
		}
		case "prodigy-card":
			for (let e of u()) L(e.card) <= 8 && c("card", e.card.uid);
			break;
		case "envoy-mode":
			c("mode", "any"), c("mode", "next");
			break;
		case "envoy-card":
			for (let e of l()) c("card", e.uid);
			break;
		case "elemental-hand":
			for (let e of o.hand) w[O(e)].type === "instant" && c("hand", e);
			break;
		case "librarian-choice":
			c("choice", "plus2"), c("choice", "minus2");
			break;
		case "scrapyard-bottom":
		case "serpent-discard":
		case "blackmail-discard":
			for (let e of o.hand) c("hand", e);
			break;
		case "successor-keep": {
			let e = i.kept ?? [];
			for (let t of o.hand) e.includes(t) || c("hand", t);
			break;
		}
		case "revolutionary-discard": for (let e of o.hand) c("hand", e);
	}
	return s;
}
function De(e, t) {
	if (e.phase === "done" || e.winner !== null) return [];
	if (e.task) return e.task.rid === t ? Y(e, e.task) : [];
	let n = e.players.findIndex((e) => e.rid === t);
	if (n < 0) return [];
	if (e.phase === "preplay") return e.preplayQueue[0] === n ? e.players[n].hand.map((e) => ({
		type: "play",
		card: e
	})) : [];
	if (e.phase === "choose") {
		let t = e.lanes[e.lanes.length - 1];
		return t && t.round === e.round && I(t, n) ? [] : e.players[n].hand.map((e) => ({
			type: "play",
			card: e
		}));
	}
	return [];
}
function Oe(e, t, n, r) {
	let i = n.revealed || e.faceUp || e.owner === t;
	return {
		uid: e.uid,
		def: i ? e.def : null,
		owner: e.owner,
		mods: i ? e.mods : 0,
		token: i ? e.token : !1,
		influence: i ? L(e) : 0,
		signets: n.revealed ? r : 0,
		faceDown: !n.revealed
	};
}
function ke(e, t) {
	let n = e.players[0].rid === t ? 0 : 1, r = e.lanes.map((t, r) => {
		let i = R(e, r), a = t.revealed ? i.aWin && i.bWin ? "both" : i.aWin ? "a" : i.bWin ? "b" : "tie" : null;
		return {
			index: r,
			a: t.a ? Oe(t.a, n, t, i.sigA) : null,
			b: t.b ? Oe(t.b, n, t, i.sigB) : null,
			revealed: t.revealed,
			dead: t.dead,
			sigA: t.revealed ? i.sigA : 0,
			sigB: t.revealed ? i.sigB : 0,
			winner: a,
			resolvedRound: t.resolvedRound
		};
	}), i = e.lanes[e.lanes.length - 1], a = null;
	e.task && (a = {
		kind: e.task.kind,
		rid: e.task.rid,
		op: e.task.op,
		...typeof e.task.data.count == "number" ? { count: e.task.data.count } : {},
		...e.task.op.endsWith("faction") ? { factions: b } : {},
		...e.task.op === "void-mode" ? { modes: ["mods", "tokens"].filter((t) => Y(e, e.task).some((e) => e.type === "act" && e.target === t)) } : {},
		...e.task.op === "envoy-mode" ? { modes: ["any", "next"] } : {}
	});
	let o = {
		side: n,
		hand: e.players[n].hand.map((e) => {
			let t = O(e);
			return {
				uid: e,
				def: t,
				owner: n,
				mods: 0,
				token: !1,
				influence: w[t].n,
				signets: 0,
				faceDown: !1
			};
		}),
		legal: De(e, t),
		peek: e.lanes.flatMap((e) => {
			let t = I(e, n);
			return t && !e.revealed ? [t.def] : [];
		}),
		nextMod: e.players[n].nextMods.reduce((e, t) => e + t, 0)
	};
	return {
		public: {
			phase: e.phase,
			round: e.round,
			players: e.players.map((t, n) => ({
				rid: t.rid,
				signets: z(e, n),
				hand: t.hand.length,
				deck: t.deck.length,
				discard: t.discard.length,
				discardCards: [...t.discard],
				played: !!(i && i.round === e.round && I(i, n))
			})),
			lanes: r,
			currentIndex: e.lanes.length - 1,
			location: e.location,
			deck: e.deck,
			task: a,
			last: e.last,
			log: e.log.slice(-16),
			winner: e.winner === null ? null : e.winner === "draw" ? "draw" : e.winner === 0 ? "a" : "b",
			winReason: e.winReason
		},
		private: o
	};
}
function Ae(t, n) {
	let r = t.players[n];
	if (r.hand.length === 0) return null;
	let i = e(t.seed, t.cursor, r.hand.length);
	t.cursor += 1;
	let [a] = r.hand.splice(i, 1);
	return a;
}
var X = () => ({ code: "games.duelforcardia.invalid" });
function je(e) {
	for (; e.revealLibSides.length > 0;) {
		let t = e.revealLibSides[0], n = I(e.lanes[e.revealLane], t);
		if (!n || !n.librarianPending) {
			e.revealLibSides.shift();
			continue;
		}
		return J(e, "choice", e.players[t].rid, "librarian-choice", {
			lane: e.revealLane,
			side: t
		}), !0;
	}
	return !1;
}
function Me(e, t, n, r, i = []) {
	let a = e.players[n], o = P(n), s = e.players[o], c = I(e.lanes[t], n);
	switch (B(e, "ability", a.rid, r), r) {
		case "i1":
			Ce(e, t, 0), Ce(e, t, 1), U(e), H(e), B(e, "discard", a.rid, "", 2);
			break;
		case "i2": {
			let i = [], o = e.lanes.flatMap((e) => e.dead ? [] : [e.a, e.b]).filter((e) => !!e);
			o.some((e) => e.mods !== 0) && i.push("mods"), o.some((e) => e.token) && i.push("tokens"), i.length > 0 && J(e, "mode", a.rid, "void-mode", {
				lane: t,
				side: n,
				src: r
			});
			break;
		}
		case "i3":
			be(e, n, -5);
			break;
		case "i5":
			ge(e, o, 2), B(e, "discard", s.rid, "", 2);
			break;
		case "i6":
			s.preplay = !0;
			break;
		case "i7":
			J(e, "faction", a.rid, "palace-faction", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "i9":
			J(e, "faction", a.rid, "ambusher-faction", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "i10": {
			if (Ce(e, t, o), s.hand.length === 0) {
				V(e, n, "noPlay");
				break;
			}
			let r = Ae(e, o);
			r && (e.lanes[t][F(o)] = {
				uid: r,
				def: O(r),
				owner: o,
				mods: 0,
				token: !1,
				faceUp: !0,
				noAbility: !0,
				armedRound: 0,
				librarianPending: !1,
				blackmail: null,
				pendingBonus: 0
			}), U(e), H(e);
			break;
		}
		case "i11": {
			let r = de(e, t);
			r !== null && q(e, r, n, 3), be(e, n, 3);
			break;
		}
		case "i13":
			J(e, "card", a.rid, "swamp-card", {
				lane: t,
				side: n,
				src: r
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "i14":
			J(e, "card", a.rid, "magistra-card", {
				lane: t,
				side: n,
				src: r,
				visited: [...i, c?.uid ?? ""]
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "i15":
			J(e, "card", a.rid, "inventor-first", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "i16":
			V(e, n, "djinn");
			break;
		case "ii1": {
			let n = I(e.lanes[t], o);
			if (c && n) {
				let r = L(n) - L(c);
				r > 0 && q(e, t, o, -r);
			}
			break;
		}
		case "ii2":
			J(e, "card", a.rid, "kinesis-source", {
				lane: t,
				side: n,
				src: r
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "ii3":
			J(e, "mode", a.rid, "envoy-mode", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "ii4":
			c && q(e, t, n, 4);
			break;
		case "ii5":
			s.hand.length === 0 ? W(e, o, 2) : J(e, "hand", s.rid, "revolutionary-discard", {
				lane: t,
				side: n,
				src: r,
				remaining: Math.min(2, s.hand.length)
			});
			break;
		case "ii6":
			a.librarian += 1;
			break;
		case "ii7":
			J(e, "card", a.rid, "prodigy-card", {
				lane: t,
				side: n,
				src: r
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "ii9":
			J(e, "faction", a.rid, "blackmail-faction", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "ii10":
			J(e, "card", a.rid, "illusionist-card", {
				lane: t,
				side: n,
				src: r,
				visited: [...i, c?.uid ?? ""]
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "ii11":
			be(e, n, 5);
			break;
		case "ii13":
			J(e, "faction", a.rid, "witch-faction", {
				lane: t,
				side: n,
				src: r
			});
			break;
		case "ii14":
			J(e, "hand", a.rid, "elemental-hand", {
				lane: t,
				side: n,
				src: r
			}), Y(e, e.task).length === 0 && (e.task = null);
			break;
		case "ii16": _e(e, o), s.hand.length > 2 && J(e, "hand", s.rid, "successor-keep", {
			lane: t,
			side: n,
			src: r,
			kept: []
		});
	}
}
function Ne(e, t) {
	let n = e.task;
	if (!n || !Y(e, n).some((e) => e.type === "act" && e.kind === t.kind && e.target === t.target)) return X();
	let r = e.players.findIndex((e) => e.rid === n.rid);
	if (r < 0) return X();
	let i = r, a = e.players[i], o = P(i), s = e.players[o], c = n.data, l = typeof c.lane == "number" ? c.lane : -1, u = n.op;
	switch (e.task = null, u) {
		case "palace-faction": {
			let n = t.target, r = l >= 0 ? I(e.lanes[l], i) : null;
			s.hand.some((e) => w[O(e)].faction === n) ? J(e, "confirm", s.rid, "palace-confirm", {
				lane: l,
				side: i,
				faction: n
			}) : r && q(e, l, i, 7);
			break;
		}
		case "palace-confirm": {
			let n = String(c.faction);
			if (t.target === "yes") {
				let t = s.hand.find((e) => w[O(e)].faction === n);
				t && G(e, o, t);
			} else q(e, l, i, 7);
			break;
		}
		case "ambusher-faction": {
			let n = t.target, r = s.hand.filter((e) => w[O(e)].faction === n);
			for (let t of r) G(e, o, t);
			B(e, "discard", s.rid, n, r.length);
			break;
		}
		case "void-mode":
			J(e, "card", a.rid, "void-card", {
				lane: l,
				side: i,
				mode: t.target
			});
			break;
		case "void-card": {
			let n = K(e, t.target);
			n && (c.mode === "mods" ? n.card.mods = 0 : n.card.token = !1, U(e), H(e));
			break;
		}
		case "swamp-card": {
			let n = K(e, t.target);
			n && n.side === i && n.lane !== l && (we(e, n.lane, i), Ce(e, n.lane, o), U(e), H(e));
			break;
		}
		case "magistra-card": {
			let n = K(e, t.target);
			if (n) {
				let t = [...c.visited ?? [], n.card.uid];
				e.steps.unshift({
					op: "ability",
					lane: l,
					side: i,
					src: n.card.def,
					copy: !0,
					visited: t
				});
			}
			break;
		}
		case "illusionist-card": {
			let n = K(e, t.target);
			if (n) {
				let t = [...c.visited ?? [], n.card.uid];
				e.steps.unshift({
					op: "ability",
					lane: n.lane,
					side: n.side,
					src: n.card.def,
					illusion: !0,
					visited: t
				});
			}
			break;
		}
		case "inventor-first":
			J(e, "card", a.rid, "inventor-second", {
				lane: l,
				side: i,
				first: t.target
			});
			break;
		case "inventor-second":
			ye(e, String(c.first), 3), ye(e, t.target, -3), U(e), H(e);
			break;
		case "kinesis-source":
			J(e, "card", a.rid, "kinesis-target", {
				lane: l,
				side: i,
				source: t.target
			});
			break;
		case "kinesis-target": {
			let n = K(e, String(c.source)), r = K(e, t.target);
			n && r && n.side === i && r.side === i && (r.card.mods += n.card.mods, n.card.mods = 0, n.card.token && (n.card.token = !1, r.card.token = !0, r.card.armedRound = e.round), U(e), H(e));
			break;
		}
		case "prodigy-card":
			ye(e, t.target, 3);
			break;
		case "envoy-mode":
			t.target === "next" ? be(e, i, -3) : J(e, "card", a.rid, "envoy-card", {
				lane: l,
				side: i
			});
			break;
		case "envoy-card":
			ye(e, t.target, -3);
			break;
		case "elemental-hand": {
			let n = t.target, r = O(n);
			if (G(e, i, n)) {
				e.steps.unshift({
					op: "draw",
					side: i,
					n: 1
				});
				let t = c.visited ?? [];
				e.steps.unshift({
					op: "ability",
					lane: l,
					side: i,
					src: r,
					copy: !0,
					visited: [...t, I(e.lanes[l], i)?.uid ?? ""]
				});
			}
			break;
		}
		case "witch-faction": {
			let n = t.target, r = s.hand.filter((e) => w[O(e)].faction === n);
			for (let t of r) G(e, o, t);
			let i = s.deck.filter((e) => w[O(e)].faction === n);
			s.deck = s.deck.filter((e) => w[O(e)].faction !== n), s.discard.push(...i.map(O)), ve(e, o), B(e, "discard", s.rid, n, r.length + i.length);
			break;
		}
		case "blackmail-faction":
			s.blackmail = t.target;
			break;
		case "librarian-choice": {
			let n = Number(c.lane), r = Number(c.side), i = I(e.lanes[n], r);
			i && (i.librarianPending = !1, i.mods += t.target === "plus2" ? 2 : -2, U(e), H(e)), je(e);
			break;
		}
		case "scrapyard-bottom": {
			let n = a.hand.indexOf(t.target);
			n >= 0 && (a.hand.splice(n, 1), a.deck.push(t.target)), e.endBottoms = e.endBottoms.filter((e) => e !== i);
			let r = e.endBottoms.find((t) => e.players[t].hand.length > 0);
			r === void 0 ? Be(e) : J(e, "hand", e.players[r].rid, "scrapyard-bottom", {});
			break;
		}
		case "successor-keep": {
			let n = [...c.kept ?? [], t.target], r = a.hand.filter((e) => !n.includes(e));
			if (n.length < 2 && r.length > 0) J(e, "hand", a.rid, "successor-keep", {
				kept: n,
				count: n.length
			});
			else for (let t of Pe(a.hand, n)) G(e, i, t);
			break;
		}
		case "revolutionary-discard": {
			G(e, i, t.target);
			let n = Math.max(0, Number(c.remaining ?? 1) - 1);
			n > 0 && a.hand.length > 0 ? J(e, "hand", a.rid, "revolutionary-discard", {
				...c,
				remaining: n
			}) : W(e, i, 2);
			break;
		}
		case "serpent-discard":
			G(e, i, t.target);
			break;
		case "blackmail-discard": {
			G(e, i, t.target);
			let n = Math.max(0, Number(c.remaining ?? 1) - 1);
			n > 0 && a.hand.length > 0 ? J(e, "hand", a.rid, "blackmail-discard", {
				...c,
				remaining: n
			}) : (e.blackmailQueue = e.blackmailQueue.filter((e) => e !== i), Fe(e));
			break;
		}
	}
	return We(e), null;
}
function Pe(e, t) {
	return e.filter((e) => !t.includes(e));
}
function Fe(e) {
	let t = e.blackmailQueue[0];
	if (t === void 0) return !1;
	let n = e.players[t];
	return n.hand.length === 0 ? (e.blackmailQueue.shift(), Fe(e)) : (J(e, "hand", n.rid, "blackmail-discard", { remaining: Math.min(2, n.hand.length) }), !0);
}
function Ie(e, t) {
	e.blackmailLane = t, e.blackmailQueue = [];
	for (let n of [0, 1]) {
		let r = I(e.lanes[t], n);
		r?.blackmail && w[r.def].faction !== r.blackmail && e.blackmailQueue.push(n), r && (r.blackmail = null);
	}
	Fe(e);
}
function Le(e, t) {
	let n = e.lanes[t];
	if (e.location === "catacombs") {
		let r = [];
		for (let i of [0, 1]) {
			let a = I(n, i), o = de(e, t), s = o === null ? null : I(e.lanes[o], i);
			a && s && w[a.def].faction === w[s.def].faction && r.push(i);
		}
		if (r.length > 0) {
			V(e, r.length > 1 ? "draw" : P(r[0]), "catacombs");
			return;
		}
	}
	if (e.location === "auction") for (let r of [0, 1]) {
		let i = I(n, r), a = de(e, t), o = a === null ? null : I(e.lanes[a], r);
		i && o && L(i) < L(o) && ge(e, r, 1);
	}
	if (U(e), H(e)) return;
	let r = R(e, t);
	r.aWin && r.bWin || r.aWin ? B(e, "win", e.players[0].rid, "", 1) : r.bWin ? B(e, "win", e.players[1].rid, "", 1) : B(e, "tie");
	let i = null;
	if (!r.tie && !r.judgeTie && (r.aWin && !r.bWin ? i = 1 : r.bWin && !r.aWin && (i = 0)), i !== null) {
		let r = I(n, i);
		r && !r.noAbility && e.steps.push({
			op: "ability",
			lane: t,
			side: i,
			src: r.def
		});
	}
	e.steps.push({ op: "post" }, { op: "end" });
}
function Re(e) {
	if (e.serpentQueue.length > 0) {
		let t = e.serpentQueue.splice(0).sort((e, t) => t.lane - e.lane);
		e.steps.unshift(...t.map((e) => ({
			op: "serpent",
			lane: e.lane,
			side: e.side
		})));
	}
	let t = e.lanes[e.revealLane];
	t && (t.a && (t.a.pendingBonus = 0), t.b && (t.b.pendingBonus = 0)), H(e);
}
function ze(e, t) {
	let n = W(e, t, 1);
	n > 0 && B(e, "draw", e.players[t].rid, "", n);
	let r = P(t);
	e.players[r].hand.length > 0 && J(e, "hand", e.players[r].rid, "serpent-discard", { side: t });
}
function Be(e) {
	if (e.winner !== null) return;
	let t = z(e, 0), n = z(e, 1);
	if (t >= 5 || n >= 5) {
		if (t >= 5 && n >= 5 && t === n) {
			Ve(e);
			return;
		}
		if (t >= 5 && t > n) {
			V(e, 0, "five");
			return;
		}
		if (n >= 5 && n > t) {
			V(e, 1, "five");
			return;
		}
	}
	Ve(e);
}
function Ve(e) {
	if (e.winner !== null) return;
	e.round += 1, e.phase = "choose", e.task = null, e.steps = [], e.preplayQueue = [], e.revealLibSides = [], e.endBottoms = [], e.serpentQueue = [], e.blackmailQueue = [];
	let t = [0, 1].filter((t) => e.players[t].hand.length === 0);
	if (t.length > 0) {
		if (t.length === 2) {
			let t = z(e, 0), n = z(e, 1);
			t === n ? V(e, "draw", "draw") : V(e, t > n ? 0 : 1, "bothNoPlay");
		} else V(e, P(t[0]), "noPlay");
		return;
	}
	let n = [0, 1].filter((t) => e.players[t].preplay);
	if (n.length > 0) {
		e.preplayQueue = n, e.phase = "preplay";
		for (let t of n) e.players[t].preplay = !1;
	}
}
function He(e) {
	if (e.winner !== null) return;
	e.steps = [];
	let t = [];
	for (let n of [0, 1]) {
		let r = e.players[n];
		if (e.location === "bazaar") {
			he(e, n);
			continue;
		}
		if (e.location === "scrapyard") {
			if (r.deck.length >= 2) {
				let i = W(e, n, 2);
				i > 0 && B(e, "draw", r.rid, "", i), r.hand.length > 0 && t.push(n);
			}
			continue;
		}
		let i = W(e, n, e.location === "library" ? 2 : 1);
		i > 0 && B(e, "draw", r.rid, "", i);
	}
	if (t.length > 0) {
		e.endBottoms = t;
		let n = t[0];
		J(e, "hand", e.players[n].rid, "scrapyard-bottom", {});
		return;
	}
	Be(e);
}
function Ue(e) {
	e.phase = "resolve";
	let t = e.lanes.length - 1;
	if (e.location === "swamp" && e.round === 1) {
		e.steps = [{ op: "end" }], We(e);
		return;
	}
	let n = e.location === "swamp" ? de(e, t) : t;
	if (n === null) {
		e.steps = [{ op: "end" }], We(e);
		return;
	}
	e.lanes[n].revealed = !0, e.lanes[n].resolvedRound = e.round, e.revealLane = n, B(e, "reveal"), e.steps = [{
		op: "blackmail",
		lane: n
	}, {
		op: "afterReveal",
		lane: n
	}], e.revealLibSides = [0, 1].filter((t) => !!I(e.lanes[n], t)?.librarianPending), je(e) || We(e);
}
function We(e) {
	let t = 0;
	for (; !e.task && e.steps.length > 0 && e.winner === null && t < 300;) {
		t += 1;
		let n = e.steps.shift();
		switch (n.op) {
			case "ability": {
				if (!I(e.lanes[n.lane], n.side)) break;
				let t = w[n.src];
				if (!t) break;
				t.type === "ongoing" ? Te(e, n.lane, n.side) : Me(e, n.lane, n.side, n.src, n.visited ?? []);
				break;
			}
			case "afterReveal":
				Le(e, n.lane);
				break;
			case "post":
				Re(e);
				break;
			case "end":
				He(e);
				break;
			case "serpent":
				ze(e, n.side);
				break;
			case "draw": {
				let t = W(e, n.side, n.n);
				t > 0 && B(e, "draw", e.players[n.side].rid, "", t);
				break;
			}
			case "blackmail": Ie(e, n.lane);
		}
	}
}
function Ge(e, t, n) {
	if (e.winner !== null || e.phase === "done" || e.task) return X();
	let r = e.players.findIndex((e) => e.rid === t);
	if (r < 0) return X();
	let i = r, a = e.players[i];
	if (!a.hand.includes(n)) return X();
	if (e.phase === "preplay") {
		if (e.preplayQueue[0] !== i) return X();
	} else if (e.phase !== "choose") return X();
	let o = xe(e);
	if (I(o, i)) return X();
	a.hand.splice(a.hand.indexOf(n), 1);
	let s = a.nextMods.reduce((e, t) => e + t, 0);
	a.nextMods = [];
	let c = e.phase === "preplay", l = {
		uid: n,
		def: O(n),
		owner: i,
		mods: s,
		token: !1,
		faceUp: c,
		noAbility: !1,
		armedRound: 0,
		librarianPending: !1,
		blackmail: null,
		pendingBonus: s
	};
	return a.librarian > 0 && (--a.librarian, l.librarianPending = !0), a.blackmail &&= (l.blackmail = a.blackmail, null), le(o, i, l), B(e, "play", t), c && (e.preplayQueue.shift(), e.preplayQueue.length === 0 && (e.phase = "choose")), he(e, i), o.a && o.b && Ue(e), null;
}
function Ke(e, t, n) {
	let r = structuredClone(e);
	return t.type === "tick" ? { state: r } : !r.players.some((e) => e.rid === n.by) || r.winner !== null || r.phase === "done" ? X() : t.type === "play" ? Ge(r, n.by, t.card) ?? { state: r } : !r.task || r.task.rid !== n.by ? X() : Ne(r, t) ?? { state: r };
}
function qe(e) {
	if (e.winner === null) return { phase: e.phase };
	let t = {
		[e.players[0].rid]: z(e, 0),
		[e.players[1].rid]: z(e, 1)
	};
	return e.winner === "draw" ? {
		phase: "done",
		winner: [],
		ranking: [e.players[0].rid, e.players[1].rid],
		scores: t
	} : {
		phase: "done",
		winner: [e.players[e.winner].rid],
		ranking: [e.players[e.winner].rid, e.players[P(e.winner)].rid],
		scores: t
	};
}
var Je = {
	meta: k,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ie,
		publicView: se,
		privateView: ce,
		config: j
	},
	setup: Ee,
	reduce: Ke,
	viewFor: ke,
	status: qe
};
//#endregion
//#region src/game/hall.tsx
function Ye() {
	return /* @__PURE__ */ m("div", {
		className: "dc-hall",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("svg", {
			viewBox: "0 0 1600 900",
			preserveAspectRatio: "xMidYMid slice",
			focusable: "false",
			children: [
				/* @__PURE__ */ h("defs", { children: [
					/* @__PURE__ */ h("linearGradient", {
						id: "dc-window",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [
							/* @__PURE__ */ m("stop", {
								offset: "0%",
								stopColor: "#9fc8c8",
								stopOpacity: "0.3"
							}),
							/* @__PURE__ */ m("stop", {
								offset: "58%",
								stopColor: "#7fa9ad",
								stopOpacity: "0.12"
							}),
							/* @__PURE__ */ m("stop", {
								offset: "100%",
								stopColor: "#7fa9ad",
								stopOpacity: "0"
							})
						]
					}),
					/* @__PURE__ */ h("linearGradient", {
						id: "dc-shaft",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ m("stop", {
							offset: "0%",
							stopColor: "#cfe4df",
							stopOpacity: "0.12"
						}), /* @__PURE__ */ m("stop", {
							offset: "100%",
							stopColor: "#cfe4df",
							stopOpacity: "0"
						})]
					}),
					/* @__PURE__ */ h("radialGradient", {
						id: "dc-candle",
						cx: "50%",
						cy: "50%",
						r: "50%",
						children: [
							/* @__PURE__ */ m("stop", {
								offset: "0%",
								stopColor: "#ffcf8a",
								stopOpacity: "0.72"
							}),
							/* @__PURE__ */ m("stop", {
								offset: "40%",
								stopColor: "#ffb85e",
								stopOpacity: "0.24"
							}),
							/* @__PURE__ */ m("stop", {
								offset: "100%",
								stopColor: "#ffcf8a",
								stopOpacity: "0"
							})
						]
					})
				] }),
				[
					248,
					616,
					984,
					1352
				].map((e) => /* @__PURE__ */ h("g", { children: [
					/* @__PURE__ */ m("path", {
						d: `M ${e - 74} 470 L ${e - 74} 210 Q ${e - 74} 96 ${e} 96 Q ${e + 74} 96 ${e + 74} 210 L ${e + 74} 470 Z`,
						fill: "url(#dc-window)"
					}),
					/* @__PURE__ */ m("path", {
						d: `M ${e - 74} 470 L ${e - 74} 210 Q ${e - 74} 96 ${e} 96 Q ${e + 74} 96 ${e + 74} 210 L ${e + 74} 470 Z`,
						fill: "none",
						stroke: "#b9d2cc",
						strokeOpacity: "0.18",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ m("line", {
						x1: e,
						y1: "132",
						x2: e,
						y2: "470",
						stroke: "#b9d2cc",
						strokeOpacity: "0.14",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ m("line", {
						x1: e - 74,
						y1: "300",
						x2: e + 74,
						y2: "300",
						stroke: "#b9d2cc",
						strokeOpacity: "0.1",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ m("path", {
						d: `M ${e - 60} 470 L ${e - 120} 900 L ${e + 120} 900 L ${e + 60} 470 Z`,
						fill: "url(#dc-shaft)"
					})
				] }, e)),
				[
					60,
					334,
					790,
					1266,
					1540
				].map((e) => /* @__PURE__ */ m("rect", {
					x: e - 8,
					y: "40",
					width: "16",
					height: "820",
					fill: "#050807",
					opacity: "0.6"
				}, e)),
				[160, 1440].map((e) => /* @__PURE__ */ h("g", { children: [
					/* @__PURE__ */ m("circle", {
						cx: e,
						cy: "352",
						r: "120",
						fill: "url(#dc-candle)"
					}),
					/* @__PURE__ */ m("rect", {
						x: e - 4,
						y: "352",
						width: "8",
						height: "54",
						rx: "3",
						fill: "#d9c8a4",
						opacity: "0.5"
					}),
					/* @__PURE__ */ m("rect", {
						x: e - 26,
						y: "404",
						width: "52",
						height: "8",
						rx: "4",
						fill: "#7a6a4c",
						opacity: "0.5"
					})
				] }, e)),
				/* @__PURE__ */ m("path", {
					d: "M0 772 Q400 700 800 748 T1600 728 L1600 900 L0 900 Z",
					fill: "#050706",
					opacity: "0.7"
				})
			]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
var Xe = "games.duelforcardia.ui.encounterTrack", Z = (e) => `games.duelforcardia.cards.${e}.name`, Ze = (e) => `games.duelforcardia.cards.${e}.ability`, Qe = (e) => `games.duelforcardia.factions.${e}`, Q = (e, t) => `games.duelforcardia.locations.${e}.${t}`, $e = (e) => `games.duelforcardia.tasks.${e}`, et = (e) => `games.duelforcardia.modes.${e}`;
function tt(e) {
	let t = e.public, s = e.private, p = o(), g = a((e) => e.locale);
	c();
	let _ = s?.side ?? 0, ee = e.myRid, v = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? f(n, g) : t;
	}, te = t.players[_], x = s?.legal ?? [], S = x.filter((e) => e.type === "act"), C = new Set(x.filter((e) => e.type === "play").map((e) => e.card)), w = `${ee}|${t.round}|${t.phase}|${t.currentIndex}|${t.task?.rid ?? ""}|${t.task?.op ?? ""}|${te?.hand ?? 0}`, [T, ne] = i({
		scope: w,
		uid: null
	}), E = T.scope === w && T.uid && s?.hand.some((e) => e.uid === T.uid) ? T.uid : null, [D, O] = i(null), k = r(null), A = r(null), [re, ie] = i(null);
	n(() => {
		let e = A.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver(([e]) => {
			let t = e.contentRect.height;
			ie(t < 520 ? "tiny" : t < 700 ? "compact" : null);
		});
		return t.observe(e), () => t.disconnect();
	}, []), n(() => {
		let e = k.current;
		if (!e) return;
		let t = requestAnimationFrame(() => {
			e.scrollLeft = e.scrollWidth;
		});
		return () => cancelAnimationFrame(t);
	}, [
		t.currentIndex,
		t.lanes.length,
		t.round
	]), n(() => {
		let e = k.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver(() => {
			e.scrollLeft = e.scrollWidth;
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let j = t.task && t.task.rid === ee ? t.task : null, ae = t.task ? t.task.rid : "", oe = (t) => e.send({
		type: "act",
		kind: t.kind,
		target: t.target
	}), M = "info", N, se = "";
	t.phase === "done" ? (M = "done", N = t.winner === "draw" ? p("games.duelforcardia.ui.drawTitle") : t.winner === (_ === 0 ? "a" : "b") ? p("games.duelforcardia.ui.victoryTitle") : p("games.duelforcardia.ui.defeatTitle"), se = t.winReason ? p(`games.duelforcardia.winReasons.${t.winReason}`) : "") : t.task ? (M = j ? "accent" : "info", N = j ? p("games.duelforcardia.ui.yourTurn") : p("games.duelforcardia.ui.waitTask", { name: v(ae) })) : t.phase === "preplay" ? (M = C.size > 0 ? "accent" : "info", N = C.size > 0 ? p("games.duelforcardia.ui.preplay") : p("games.duelforcardia.ui.waiting")) : t.phase === "choose" && C.size > 0 ? (M = "accent", N = p("games.duelforcardia.ui.yourTurn")) : N = p("games.duelforcardia.ui.waiting");
	let ce = nt({
		t: p,
		pub: t,
		priv: s,
		mySide: _,
		myTask: j,
		acts: S,
		playable: C,
		pickedUid: E,
		nameOf: v,
		onPick: (e) => ne({
			scope: w,
			uid: e
		}),
		onAct: oe,
		onPlay: (t) => e.send({
			type: "play",
			card: t
		})
	}), P = D?.kind === "card" ? mt(t, s, D.uid) : null, F = P?.card.def ?? null;
	return /* @__PURE__ */ h("div", {
		className: "dc-root",
		ref: A,
		"data-size": re ?? void 0,
		children: [
			/* @__PURE__ */ m(Ye, {}),
			/* @__PURE__ */ m(l, {
				adaptive: !0,
				className: "dc-screen",
				scroll: !1,
				actionsHeight: "dc-actions-height",
				banner: /* @__PURE__ */ h("div", {
					className: "dc-banner",
					children: [/* @__PURE__ */ m("div", {
						className: "dc-banner-row",
						children: /* @__PURE__ */ m(u, {
							tone: M,
							accent: "#1b211e",
							chip: p("games.duelforcardia.ui.round", { n: t.round }),
							text: N,
							sub: se || void 0
						})
					}), /* @__PURE__ */ m(d, {
						members: e.members,
						myRid: ee,
						variant: "plate",
						action: (e) => {
							if (t.phase === "done") return null;
							let n = t.players.find((t) => t.rid === e);
							return n ? t.task && t.task.rid === e ? "pending" : t.phase === "choose" || t.phase === "preplay" ? n.played ? "done" : "pending" : null : null;
						},
						status: (e) => {
							let n = t.players.find((t) => t.rid === e);
							return n ? /* @__PURE__ */ h("span", {
								className: "dc-seat-status",
								children: [
									/* @__PURE__ */ h("span", {
										className: "dc-seat-sig",
										"aria-label": `${p("games.duelforcardia.ui.signets")} ${n.signets}`,
										children: [/* @__PURE__ */ m(ht, { count: n.signets }), /* @__PURE__ */ m("b", { children: n.signets })]
									}),
									/* @__PURE__ */ h("span", {
										className: "dc-seat-count",
										children: [/* @__PURE__ */ m("i", { children: p("games.duelforcardia.ui.hand") }), n.hand]
									}),
									/* @__PURE__ */ h("span", {
										className: "dc-seat-count",
										children: [/* @__PURE__ */ m("i", { children: p("games.duelforcardia.ui.deck") }), n.deck]
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "dc-seat-count dc-discard-link",
										onClick: () => O({
											kind: "discard",
											side: t.players.findIndex((t) => t.rid === e)
										}),
										"aria-label": `${p("games.duelforcardia.ui.discard")} ${n.discard}`,
										children: [/* @__PURE__ */ m("i", { children: p("games.duelforcardia.ui.discard") }), n.discard]
									})
								]
							}) : null;
						}
					})]
				}),
				actions: ce,
				children: /* @__PURE__ */ h("div", {
					className: "dc-table",
					children: [
						/* @__PURE__ */ m(ct, {
							pub: t,
							t: p,
							onOpen: () => O({ kind: "location" })
						}),
						/* @__PURE__ */ h("section", {
							className: "dc-arena",
							"aria-label": p(Xe),
							children: [
								t.location && /* @__PURE__ */ m("div", {
									className: "dc-arena-atmos",
									"aria-hidden": !0,
									children: /* @__PURE__ */ m("img", {
										src: `games/duelforcardia/loc-${t.location}.webp`,
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ h("header", {
									className: "dc-arena-head",
									children: [/* @__PURE__ */ m("span", {
										className: "dc-arena-title",
										children: p(Xe)
									}), /* @__PURE__ */ m(ft, {
										pub: t,
										t: p,
										nameOf: v
									})]
								}),
								/* @__PURE__ */ h("div", {
									className: "dc-lanes",
									ref: k,
									children: [t.lanes.length === 0 && /* @__PURE__ */ h("div", {
										className: "dc-lanes-empty",
										children: [/* @__PURE__ */ h("span", {
											className: "dc-empty-ring",
											"aria-hidden": !0,
											children: [b.map((e) => /* @__PURE__ */ m("span", {
												style: { "--fac": y[e] },
												children: /* @__PURE__ */ m(gt, {
													faction: e,
													size: 18
												})
											}, e)), /* @__PURE__ */ m("i", { children: "✦" })]
										}), /* @__PURE__ */ m("span", { children: p("games.duelforcardia.ui.choose") })]
									}), t.lanes.filter((e) => !e.dead).map((e) => /* @__PURE__ */ m(rt, {
										lane: e,
										current: e.index === t.currentIndex,
										mySide: _,
										t: p,
										acts: S,
										onOpenCard: (e) => O({
											kind: "card",
											uid: e
										}),
										onAct: oe
									}, e.index))]
								})
							]
						}),
						/* @__PURE__ */ m(at, {
							hand: s?.hand ?? [],
							nextMod: s?.nextMod ?? 0,
							selected: E,
							playable: C,
							acts: S,
							t: p,
							onPick: (e) => ne({
								scope: w,
								uid: E === e ? null : e
							}),
							onAct: oe,
							onInspect: (e) => O({
								kind: "card",
								uid: e
							})
						})
					]
				})
			}),
			D && /* @__PURE__ */ h(pt, {
				title: D.kind === "location" ? t.location ? p(Q(t.location, "name")) : p("games.duelforcardia.noLocation") : D.kind === "discard" ? p("games.duelforcardia.ui.discardTitle", { name: v(t.players[D.side].rid) }) : p(F ? Z(F) : "games.duelforcardia.ui.tapDetails"),
				closeLabel: p("games.duelforcardia.ui.close"),
				onClose: () => O(null),
				children: [
					D.kind === "location" && t.location && /* @__PURE__ */ m(lt, {
						id: t.location,
						t: p
					}),
					D.kind === "discard" && /* @__PURE__ */ m(dt, {
						pub: t,
						side: D.side,
						t: p
					}),
					D.kind === "card" && P && F && /* @__PURE__ */ m(ut, {
						card: P.card,
						def: F,
						t: p,
						mySide: _
					}),
					D.kind === "card" && !P && /* @__PURE__ */ m("p", {
						className: "dc-modal-note",
						children: p("games.duelforcardia.ui.empty")
					})
				]
			})
		]
	});
}
function nt({ t: e, pub: t, priv: n, mySide: r, myTask: i, acts: a, playable: o, pickedUid: s, nameOf: c, onPick: l, onAct: u, onPlay: d }) {
	let f = n?.hand.find((e) => e.uid === s), p, g;
	t.phase === "done" ? (p = t.winner === "draw" ? e("games.duelforcardia.ui.drawTitle") : t.winner === (r === 0 ? "a" : "b") ? e("games.duelforcardia.ui.victoryTitle") : e("games.duelforcardia.ui.defeatTitle"), g = t.winReason ? e(`games.duelforcardia.winReasons.${t.winReason}`) : "") : t.task ? i ? (p = e($e(i.op)), g = i.op === "successor-keep" ? e("games.duelforcardia.ui.keepCount", { n: i.count ?? 0 }) : i.kind === "hand" ? e("games.duelforcardia.ui.pickHand") : e("games.duelforcardia.ui.pickTarget")) : (p = e("games.duelforcardia.ui.waitTask", { name: c(t.task.rid) }), g = e($e(t.task.op))) : o.size > 0 ? (p = f?.def ? e(Z(f.def)) : e("games.duelforcardia.ui.choose"), g = f?.def ? e(Ze(f.def)) : e("games.duelforcardia.ui.pickHand")) : (p = e("games.duelforcardia.ui.waiting"), g = e("games.duelforcardia.ui.choose"));
	let _ = null;
	return i ? i.kind === "faction" ? _ = /* @__PURE__ */ m("div", {
		className: "dc-btn-row dc-faction-row",
		children: a.filter((e) => e.kind === "faction").map((t) => /* @__PURE__ */ h("button", {
			type: "button",
			className: "dc-faction-btn",
			style: { "--fac": y[t.target] },
			onClick: () => u(t),
			children: [/* @__PURE__ */ m(gt, {
				faction: t.target,
				size: 16
			}), e(Qe(t.target))]
		}, t.target))
	}) : i.kind === "confirm" ? _ = /* @__PURE__ */ m("div", {
		className: "dc-btn-row",
		children: a.filter((e) => e.kind === "confirm").map((t) => /* @__PURE__ */ m("button", {
			type: "button",
			className: `dc-btn ${t.target === "yes" ? "is-primary" : ""}`,
			onClick: () => u(t),
			children: t.target === "yes" ? e("games.duelforcardia.ui.yes") : e("games.duelforcardia.ui.no")
		}, t.target))
	}) : (i.kind === "mode" || i.kind === "choice") && (_ = /* @__PURE__ */ m("div", {
		className: "dc-btn-row",
		children: a.filter((e) => e.kind === i.kind).map((t) => /* @__PURE__ */ m("button", {
			type: "button",
			className: "dc-btn",
			onClick: () => u(t),
			children: e(et(t.target))
		}, t.target))
	})) : o.size > 0 && (_ = /* @__PURE__ */ h("div", {
		className: "dc-btn-row",
		children: [s && /* @__PURE__ */ m("button", {
			type: "button",
			className: "dc-btn",
			onClick: () => l(null),
			children: e("games.duelforcardia.ui.cancel")
		}), /* @__PURE__ */ m("button", {
			type: "button",
			className: "dc-btn is-primary",
			disabled: !s || !o.has(s),
			onClick: () => {
				s && o.has(s) && d(s);
			},
			children: e("games.duelforcardia.ui.play")
		})]
	})), /* @__PURE__ */ h("div", {
		className: "dc-actions",
		children: [/* @__PURE__ */ h("div", {
			className: "dc-actions-text",
			children: [/* @__PURE__ */ m("p", {
				className: "dc-actions-title",
				children: p
			}), /* @__PURE__ */ m("p", {
				className: "dc-actions-sub",
				children: g
			})]
		}), /* @__PURE__ */ m("div", {
			className: "dc-actions-buttons",
			children: _
		})]
	});
}
function rt({ lane: e, current: t, mySide: n, t: r, acts: i, onOpenCard: a, onAct: o }) {
	let s = n === 0 ? e.a : e.b, c = n === 0 ? e.b : e.a, l = e.winner === null ? null : e.winner === "both" ? "both" : e.winner === "tie" ? "tie" : e.winner === (n === 0 ? "a" : "b") ? "mine" : "theirs", u = e.revealed ? l === "tie" ? "=" : l ? "✦" : "·" : "·";
	return /* @__PURE__ */ h("div", {
		className: `dc-lane${t ? " is-current" : ""}`,
		"data-win": l ?? void 0,
		"data-current": t ? "true" : void 0,
		children: [
			/* @__PURE__ */ m("span", {
				className: "dc-lane-no",
				children: String(e.index + 1).padStart(2, "0")
			}),
			/* @__PURE__ */ m(it, {
				card: c,
				orientation: "theirs",
				t: r,
				acts: i,
				onOpen: a,
				onAct: o
			}),
			/* @__PURE__ */ m("span", {
				className: "dc-lane-mark",
				"data-result": e.revealed ? l ?? "none" : "hidden",
				"aria-label": e.revealed ? r(l === "tie" ? "games.duelforcardia.ui.draw" : "games.duelforcardia.ui.current") : r("games.duelforcardia.ui.faceDown"),
				children: u
			}),
			/* @__PURE__ */ m(it, {
				card: s,
				orientation: "mine",
				t: r,
				acts: i,
				onOpen: a,
				onAct: o
			})
		]
	});
}
function it({ card: e, orientation: t, t: n, acts: r, onOpen: i, onAct: a }) {
	if (!e) return /* @__PURE__ */ m("span", {
		className: "dc-lane-empty",
		"aria-label": n("games.duelforcardia.ui.empty"),
		"data-orientation": t,
		children: "+"
	});
	let o = e.def, s = r.find((t) => t.target === e.uid), c = n(o ? Z(o) : "games.duelforcardia.ui.faceDown");
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: `dc-card dc-card--lane${s ? " is-legal" : ""}${e.faceDown ? " is-facedown" : ""}`,
		style: { "--fac": o ? y[w[o].faction] : "#5f5470" },
		"aria-label": s ? `${c} — ${n("games.duelforcardia.ui.pickTarget")}` : c,
		onClick: () => {
			s ? a(s) : i(e.uid);
		},
		children: [/* @__PURE__ */ m(ot, {
			card: e,
			def: o,
			t: n
		}), s && /* @__PURE__ */ m(st, {})]
	});
}
function at({ hand: e, nextMod: t, selected: n, playable: r, acts: i, t: a, onPick: o, onAct: c, onInspect: l }) {
	return /* @__PURE__ */ h("section", {
		className: "dc-hand-rail",
		"aria-label": a("games.duelforcardia.ui.hand"),
		children: [/* @__PURE__ */ h("header", {
			className: "dc-hand-head",
			children: [
				/* @__PURE__ */ m("span", {
					className: "dc-hand-title",
					children: a("games.duelforcardia.ui.hand")
				}),
				/* @__PURE__ */ m("span", {
					className: "dc-hand-count",
					children: e.length
				}),
				t !== 0 && /* @__PURE__ */ m("span", {
					className: "dc-nextmod",
					children: a("games.duelforcardia.ui.nextMod", { n: t > 0 ? `+${t}` : String(t) })
				})
			]
		}), /* @__PURE__ */ h("div", {
			className: "dc-hand",
			children: [e.length === 0 && /* @__PURE__ */ m("span", {
				className: "dc-hand-empty",
				children: a("games.duelforcardia.ui.empty")
			}), e.map((e) => {
				let t = e.def, u = i.find((t) => t.target === e.uid), d = r.has(e.uid), f = n === e.uid;
				return /* @__PURE__ */ h("div", {
					className: `dc-hand-slot${f ? " is-selected" : ""}`,
					children: [/* @__PURE__ */ h("button", {
						type: "button",
						className: `dc-card dc-card--hand${f ? " is-selected" : ""}${u || d ? " is-legal" : ""}${e.faceDown ? " is-facedown" : ""}`,
						style: { "--fac": t ? y[w[t].faction] : "#5f5470" },
						"aria-pressed": f,
						"aria-label": a(t ? Z(t) : "games.duelforcardia.ui.faceDown"),
						onClick: () => {
							u ? c(u) : d ? o(e.uid) : l(e.uid);
						},
						children: [/* @__PURE__ */ m(ot, {
							card: e,
							def: t,
							t: a
						}), (u || d) && /* @__PURE__ */ m(st, {})]
					}), t && /* @__PURE__ */ m("button", {
						type: "button",
						className: "dc-hand-info",
						"aria-label": `${a(Z(t))} — ${a("games.duelforcardia.ui.tapDetails")}`,
						onClick: () => l(e.uid),
						children: /* @__PURE__ */ m(s, {})
					})]
				}, e.uid);
			})]
		})]
	});
}
function ot({ card: e, def: t, t: n }) {
	if (!t) return /* @__PURE__ */ h("span", {
		className: "dc-card-back",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("span", {
			className: "dc-card-back-crest",
			children: "✦"
		}), /* @__PURE__ */ m("span", { className: "dc-card-back-line" })]
	});
	let r = w[t], i = e.faceDown;
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("span", {
			className: "dc-card-art",
			children: [
				/* @__PURE__ */ m("img", {
					src: `games/duelforcardia/art-${t}.webp`,
					alt: "",
					loading: "lazy",
					draggable: !1
				}),
				/* @__PURE__ */ m("span", {
					className: "dc-card-scrim",
					"aria-hidden": !0
				}),
				/* @__PURE__ */ h("span", {
					className: "dc-card-head",
					children: [/* @__PURE__ */ m("b", {
						className: "dc-card-inf",
						children: e.influence
					}), /* @__PURE__ */ m(gt, {
						faction: r.faction,
						size: 14
					})]
				}),
				e.mods !== 0 && /* @__PURE__ */ h("span", {
					className: `dc-card-mod${e.mods > 0 ? " is-plus" : " is-minus"}`,
					children: [e.mods > 0 ? "+" : "", e.mods]
				}),
				e.token && /* @__PURE__ */ m("span", {
					className: "dc-card-token",
					title: n("games.duelforcardia.ui.ongoing"),
					"aria-label": n("games.duelforcardia.ui.ongoing"),
					children: "◈"
				}),
				i && /* @__PURE__ */ m("span", {
					className: "dc-card-veil",
					children: n("games.duelforcardia.ui.faceDown")
				})
			]
		}),
		/* @__PURE__ */ h("span", {
			className: "dc-card-body",
			children: [/* @__PURE__ */ m("span", {
				className: "dc-card-name",
				children: n(Z(t))
			}), /* @__PURE__ */ m("span", {
				className: "dc-card-ability",
				children: n(Ze(t))
			})]
		}),
		e.signets > 0 && /* @__PURE__ */ h("span", {
			className: "dc-card-signets",
			"aria-label": `${n("games.duelforcardia.ui.signetsOnCard")} ${e.signets}`,
			children: [Array.from({ length: Math.min(3, e.signets) }, (e, t) => /* @__PURE__ */ m(_t, { size: 10 }, t)), e.signets > 3 && /* @__PURE__ */ h("span", { children: ["×", e.signets] })]
		})
	] });
}
function st() {
	return /* @__PURE__ */ m("svg", {
		className: "dc-ants",
		viewBox: "0 0 100 142",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		focusable: "false",
		children: /* @__PURE__ */ m("rect", {
			x: "1.1",
			y: "1.1",
			width: "97.8",
			height: "139.8",
			rx: "5"
		})
	});
}
function ct({ pub: e, t, onOpen: n }) {
	if (!e.location) return /* @__PURE__ */ h("div", {
		className: "dc-loc-banner dc-loc-none",
		children: [/* @__PURE__ */ m("span", {
			className: "dc-loc-crest",
			"aria-hidden": !0,
			children: "✦"
		}), /* @__PURE__ */ m("span", {
			className: "dc-loc-none-text",
			children: t("games.duelforcardia.noLocation")
		})]
	});
	let r = ne[e.location];
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: "dc-loc-banner",
		onClick: n,
		"aria-label": `${t(Q(e.location, "name"))} — ${t("games.duelforcardia.ui.tapDetails")}`,
		children: [
			/* @__PURE__ */ m("img", {
				className: "dc-loc-img",
				src: `games/duelforcardia/loc-${e.location}.webp`,
				alt: "",
				loading: "lazy",
				draggable: !1
			}),
			/* @__PURE__ */ m("span", {
				className: "dc-loc-veil",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ h("span", {
				className: "dc-loc-info",
				children: [
					/* @__PURE__ */ m("span", {
						className: "dc-loc-kicker",
						children: t("games.duelforcardia.ui.location")
					}),
					/* @__PURE__ */ m("span", {
						className: "dc-loc-name",
						children: t(Q(e.location, "name"))
					}),
					/* @__PURE__ */ m("span", {
						className: "dc-loc-skulls",
						"aria-label": t("games.duelforcardia.ui.difficulty", { n: r.skulls }),
						children: Array.from({ length: r.skulls }, (e, t) => /* @__PURE__ */ m(vt, { size: 11 }, t))
					}),
					/* @__PURE__ */ m("span", {
						className: "dc-loc-text",
						children: t(Q(e.location, "text"))
					})
				]
			})
		]
	});
}
function lt({ id: e, t }) {
	let n = ne[e];
	return /* @__PURE__ */ h("div", {
		className: "dc-detail dc-detail--location",
		children: [
			/* @__PURE__ */ m("img", {
				className: "dc-detail-art",
				src: `games/duelforcardia/loc-${e}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ h("div", {
				className: "dc-detail-stats",
				children: [/* @__PURE__ */ m("span", { children: t("games.duelforcardia.ui.location") }), /* @__PURE__ */ h("span", {
					className: "dc-detail-skulls",
					children: [t("games.duelforcardia.ui.difficulty", { n: n.skulls }), Array.from({ length: n.skulls }, (e, t) => /* @__PURE__ */ m(vt, { size: 13 }, t))]
				})]
			}),
			/* @__PURE__ */ m("p", {
				className: "dc-detail-text",
				children: t(Q(e, "text"))
			})
		]
	});
}
function ut({ card: e, def: t, t: n, mySide: r }) {
	let i = w[t];
	return /* @__PURE__ */ h("div", {
		className: "dc-detail dc-detail--card",
		children: [/* @__PURE__ */ m("div", {
			className: "dc-detail-cardart",
			style: { "--fac": y[i.faction] },
			children: /* @__PURE__ */ m("div", {
				className: "dc-card dc-card--static",
				children: /* @__PURE__ */ m(ot, {
					card: e,
					def: t,
					t: n
				})
			})
		}), /* @__PURE__ */ h("div", {
			className: "dc-detail-info",
			children: [
				/* @__PURE__ */ h("div", {
					className: "dc-detail-stats",
					children: [
						/* @__PURE__ */ h("span", {
							className: "dc-detail-inf",
							children: [
								n("games.duelforcardia.ui.influence"),
								" ",
								e.influence
							]
						}),
						/* @__PURE__ */ h("span", {
							style: { color: y[i.faction] },
							children: [/* @__PURE__ */ m(gt, {
								faction: i.faction,
								size: 14
							}), n(Qe(i.faction))]
						}),
						/* @__PURE__ */ m("span", { children: n(i.type === "instant" ? "games.duelforcardia.ui.ability" : "games.duelforcardia.ui.ongoing") })
					]
				}),
				e.mods !== 0 && /* @__PURE__ */ h("p", {
					className: "dc-detail-note",
					children: [
						n("games.duelforcardia.ui.modifiers"),
						": ",
						e.mods > 0 ? "+" : "",
						e.mods
					]
				}),
				e.signets > 0 && /* @__PURE__ */ h("p", {
					className: "dc-detail-note",
					children: [
						n("games.duelforcardia.ui.signetsOnCard"),
						": ",
						e.signets
					]
				}),
				e.faceDown && e.owner === r && /* @__PURE__ */ m("p", {
					className: "dc-detail-note",
					children: n("games.duelforcardia.ui.faceDown")
				}),
				/* @__PURE__ */ m("p", {
					className: "dc-detail-text",
					children: n(Ze(t))
				})
			]
		})]
	});
}
function dt({ pub: e, side: t, t: n }) {
	let r = e.players[t]?.discardCards ?? [];
	return /* @__PURE__ */ h("div", {
		className: "dc-detail dc-detail--discard",
		children: [/* @__PURE__ */ m("p", {
			className: "dc-detail-note",
			children: n("games.duelforcardia.ui.discardHint")
		}), r.length === 0 ? /* @__PURE__ */ m("p", {
			className: "dc-modal-note",
			children: n("games.duelforcardia.ui.discardEmpty")
		}) : /* @__PURE__ */ m("div", {
			className: "dc-discard-grid",
			children: r.map((e, r) => {
				let i = w[e];
				if (!i) return null;
				let a = {
					uid: `discard-${t}-${r}`,
					def: e,
					owner: t,
					mods: 0,
					token: !1,
					influence: i.n,
					signets: 0,
					faceDown: !1
				};
				return /* @__PURE__ */ m("div", {
					className: "dc-card dc-card--static",
					style: { "--fac": y[i.faction] },
					children: /* @__PURE__ */ m(ot, {
						card: a,
						def: e,
						t: n
					})
				}, a.uid);
			})
		})]
	});
}
function ft({ pub: e, t, nameOf: n }) {
	let r = e.last, i;
	switch (r.kind) {
		case "play":
			i = t("games.duelforcardia.logs.play", { name: n(r.rid) });
			break;
		case "reveal":
			i = t("games.duelforcardia.logs.reveal");
			break;
		case "win":
			i = t("games.duelforcardia.logs.win", { name: n(r.rid) });
			break;
		case "tie":
			i = t("games.duelforcardia.logs.tie");
			break;
		case "ability":
			i = t("games.duelforcardia.logs.ability", {
				name: n(r.rid),
				card: t(Z(r.target))
			});
			break;
		case "draw":
			i = t("games.duelforcardia.logs.draw", {
				name: n(r.rid),
				n: r.n
			});
			break;
		case "discard":
			i = t("games.duelforcardia.logs.discard", {
				name: n(r.rid),
				n: r.n
			});
			break;
		case "mod":
			i = t("games.duelforcardia.logs.mod", { name: n(r.rid) });
			break;
		case "token":
			i = t("games.duelforcardia.logs.token", { name: n(r.rid) });
			break;
		case "winGame":
			i = r.rid ? t("games.duelforcardia.logs.winGame", { name: n(r.rid) }) : t("games.duelforcardia.ui.draw");
			break;
		default: i = "";
	}
	return i ? /* @__PURE__ */ h("span", {
		className: "dc-last",
		role: "status",
		children: [/* @__PURE__ */ m("span", {
			className: "dc-last-label",
			children: t("games.duelforcardia.ui.latest")
		}), /* @__PURE__ */ m("span", {
			className: "dc-last-text",
			children: i
		})]
	}) : /* @__PURE__ */ m("span", {
		className: "dc-last",
		"aria-hidden": !0
	});
}
function pt({ title: e, closeLabel: t, onClose: n, children: r }) {
	return /* @__PURE__ */ m("div", {
		className: "dc-modal-shade",
		onClick: n,
		children: /* @__PURE__ */ h("section", {
			className: "dc-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				e.key === "Escape" && n();
			},
			children: [/* @__PURE__ */ h("header", {
				className: "dc-modal-head",
				children: [/* @__PURE__ */ m("h2", { children: e }), /* @__PURE__ */ m("button", {
					type: "button",
					onClick: n,
					"aria-label": t,
					children: "×"
				})]
			}), /* @__PURE__ */ m("div", {
				className: "dc-modal-body",
				children: r
			})]
		})
	});
}
function mt(e, t, n) {
	let r = t?.hand.find((e) => e.uid === n);
	if (r) return { card: r };
	for (let t of e.lanes) {
		if (t.a?.uid === n) return {
			card: t.a,
			lane: t
		};
		if (t.b?.uid === n) return {
			card: t.b,
			lane: t
		};
	}
	return null;
}
function ht({ count: e }) {
	return /* @__PURE__ */ m("span", {
		className: "dc-sig-pips",
		"aria-hidden": !0,
		children: Array.from({ length: 5 }, (t, n) => /* @__PURE__ */ m("i", { className: n < e ? "is-filled" : void 0 }, n))
	});
}
function gt({ faction: e, size: t = 14 }) {
	return /* @__PURE__ */ h("svg", {
		className: "dc-faction-mark",
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		style: { color: y[e] },
		children: [
			e === "rebellion" && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M6 21c-2.3 0-3.9-1.4-3.9-3.5 0-2 1.6-3.4 4.1-3.4h4.1c1.3 0 2-.6 2-1.6 0-1-.7-1.6-2-1.6H5.1v-2.6h5.6c2.9 0 4.8 1.6 4.8 4 0 2.5-1.9 4.2-5 4.2H6.2c-.8 0-1.3.4-1.3 1s.5 1 1.3 1h6.1v2.5H6Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "16.7",
					cy: "4.4",
					r: "2.3",
					fill: "currentColor"
				}),
				/* @__PURE__ */ m("path", {
					d: "m18.9 3.1 2.8-1.2-1.2 2.7z",
					fill: "currentColor"
				})
			] }),
			e === "academy" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M12 8.1c-4.4 0-7.9 2.5-9.1 4.9 1.2 2.4 4.7 4.9 9.1 4.9s7.9-2.5 9.1-4.9C19.9 10.6 16.4 8.1 12 8.1Zm0 2.3a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2Z",
				fill: "currentColor"
			}), /* @__PURE__ */ m("path", {
				d: "M12 1.4 13.2 5h-2.4zM6.2 2.9l2.1 3.1-2.6.9zM17.8 2.9l.5 4-2.6-.9zM2.3 7.6l3 1.8-2.3 2zM21.7 7.6l-.7 3.8-2.3-2z",
				fill: "currentColor"
			})] }),
			e === "guild" && /* @__PURE__ */ h("g", {
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.3",
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ m("path", { d: "M4 20 15.4 8.6" }),
					/* @__PURE__ */ m("path", { d: "M4 4 15.4 15.4" }),
					/* @__PURE__ */ m("circle", {
						cx: "18",
						cy: "6",
						r: "2.9"
					}),
					/* @__PURE__ */ m("rect", {
						x: "15.4",
						y: "15.4",
						width: "4.6",
						height: "4.6",
						rx: "1",
						transform: "rotate(45 17.7 17.7)",
						fill: "currentColor",
						stroke: "none"
					})
				]
			}),
			e === "dynasty" && /* @__PURE__ */ m("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M4.5 21V6h2.2V3h2.4v3h1.6V3h2.6v3h1.6V3h2.4v3h2.2v15h-5.3v-5.4a1.55 1.55 0 0 0-3.1 0V21H4.5Zm6.6-13h1.8v3.2h-1.8V8Z",
				fill: "currentColor"
			})
		]
	});
}
function _t({ size: e = 12 }) {
	return /* @__PURE__ */ h("svg", {
		className: "dc-signet-icon",
		width: e,
		height: e,
		viewBox: "0 0 20 20",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ m("circle", {
			cx: "10",
			cy: "10",
			r: "7.2",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.4"
		}), /* @__PURE__ */ m("circle", {
			cx: "10",
			cy: "10",
			r: "2.2",
			fill: "currentColor"
		})]
	});
}
function vt({ size: e = 11 }) {
	return /* @__PURE__ */ h("svg", {
		className: "dc-skull-icon",
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M12 2c-5 0-8 3.4-8 8 0 2.9 1.4 5 3.4 6.2V20h2.2v-2h1.2v2h2.4v-2h1.2v2h2.2v-3.8C18.6 15 20 12.9 20 10c0-4.6-3-8-8-8Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "9",
				cy: "10",
				r: "1.7",
				fill: "#101412"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "15",
				cy: "10",
				r: "1.7",
				fill: "#101412"
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
var yt = {
	i1: 5,
	i2: 4,
	i3: 2,
	i4: 5,
	i5: 3,
	i6: 3,
	i7: 4,
	i8: 8,
	i9: 4,
	i10: 9,
	i11: 4,
	i12: 6,
	i13: 4,
	i14: 5,
	i15: 5,
	i16: 10,
	ii1: 5,
	ii2: 5,
	ii3: 3,
	ii4: 3,
	ii5: 4,
	ii6: 3,
	ii7: 4,
	ii8: 6,
	ii9: 4,
	ii10: 8,
	ii11: 4,
	ii12: 7,
	ii13: 5,
	ii14: 5,
	ii15: 10,
	ii16: 8
};
function $(e) {
	return yt[e] ?? 2;
}
function bt(e, t) {
	for (let n of e.lanes) {
		if (n.a?.uid === t) return {
			card: n.a,
			lane: n,
			side: "a"
		};
		if (n.b?.uid === t) return {
			card: n.b,
			lane: n,
			side: "b"
		};
	}
	return null;
}
function xt(e, t, n) {
	let r = w[n.def], i = t.side, a = e.players[i]?.signets ?? 0, o = e.players[1 - i]?.signets ?? 0, s = a >= 4 || o >= 4, c = r.n * (s ? 1.45 : .72);
	return r.type === "ongoing" && (c += 1.4), c += $(n.def) * (s ? .38 : .62), r.n <= 3 && (c += s ? 0 : 1.2), r.n >= 14 && (c += s ? 1.2 : .2), c;
}
function St(e, t) {
	let n = new Map(b.map((e) => [e, 0]));
	for (let r of e.lanes) {
		let e = t.side === 0 ? r.b : r.a;
		if (e?.def) {
			let t = w[e.def]?.faction;
			t && n.set(t, (n.get(t) ?? 0) + 1);
		}
	}
	return [...n.entries()].sort((e, t) => t[1] - e[1])[0][0];
}
function Ct(e, t, n, r) {
	let i = bt(e, n.target);
	if (!i) {
		let e = t.hand.find((e) => e.uid === n.target);
		if (!e?.def) return -100;
		let i = w[e.def];
		switch (r) {
			case "elemental-hand": return $(e.def);
			case "successor-keep": return i.n * 2 + $(e.def);
			default: return -i.n;
		}
	}
	let a = i.card.owner === t.side, o = i.card.influence, s = i.card.def ? $(i.card.def) : 0;
	switch (r) {
		case "void-card": return a ? -o - s : o + s + (i.card.token ? 3 : 0) + (i.card.mods === 0 ? 0 : 2);
		case "swamp-card": return ((i.side === "a" ? i.lane.b : i.lane.a)?.influence ?? 0) - o;
		case "magistra-card": return s + (i.card.def === "i16" || i.card.def === "i10" ? 6 : 0);
		case "illusionist-card": return s;
		case "inventor-first": return a ? o * .4 + s : -o;
		case "inventor-second": return a ? -o : o * .7 + s;
		case "kinesis-source": return (i.card.mods === 0 ? 0 : 4) + (i.card.token ? 5 : 0);
		case "kinesis-target": return a ? o * .5 + s : -100;
		case "prodigy-card": return a ? o * .4 + s : -100;
		case "envoy-card": return a ? -o : o;
		default: return a ? o * .3 + s : -o;
	}
}
function wt(e, t, n) {
	if (n.type === "play") {
		let r = t.hand.find((e) => e.uid === n.card);
		return r?.def ? xt(e, t, {
			uid: r.uid,
			def: r.def
		}) : -100;
	}
	if (n.type === "tick") return -100;
	let r = e.task?.op ?? "";
	switch (n.kind) {
		case "faction": {
			let r = St(e, t);
			return n.target === r ? 5 : 1;
		}
		case "confirm": return n.target === "yes" ? t.hand.length > 2 ? 4 : 1 : 2;
		case "mode": return r === "void-mode" ? n.target === "tokens" ? 4 : 3 : r === "envoy-mode" ? n.target === "any" ? 4 : 1 : 2;
		case "choice": return n.target === "plus2" ? 4 : 2;
		case "hand": {
			let e = t.hand.find((e) => e.uid === n.target);
			return e?.def ? r === "successor-keep" ? w[e.def].n + $(e.def) : -w[e.def].n : -100;
		}
		case "card": return Ct(e, t, n, r);
		case "skip": return -5;
	}
	return 0;
}
var Tt = (e, t) => {
	let n = e.private, r = n?.legal ?? [];
	if (!n || r.length === 0) return null;
	if (t.difficulty === "weak") return { action: r[Math.floor(Math.random() * r.length)] };
	let i = r[0], a = -Infinity;
	for (let t of r) {
		let r = wt(e.public, n, t);
		r > a && (i = t, a = r);
	}
	return { action: i };
};
//#endregion
//#region src/game/game-over.tsx
function Et({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: s }) {
	let c = o(), l = a((e) => e.locale), u = /* @__PURE__ */ m(ee, {
		result: e,
		members: n,
		myRid: r,
		accent: "#c9a35b",
		onPlayAgain: i,
		onBackToLobby: s
	}), d = se.safeParse(t);
	if (!d.success) return u;
	let p = d.data;
	if (p.phase !== "done") return u;
	let v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, l) : e;
	}, te = e.winner.includes(r), y = e.winner.length === 0 ? c("games.duelforcardia.ui.drawTitle") : c(te ? "games.duelforcardia.ui.victoryTitle" : "games.duelforcardia.ui.defeatTitle"), b = i ?? s, x = e.ranking.length === 2 ? e.ranking : p.players.map((e) => e.rid);
	return /* @__PURE__ */ h("div", {
		className: "dc-over",
		children: [
			/* @__PURE__ */ m(Ye, {}),
			/* @__PURE__ */ m("div", {
				className: "dc-over-glow",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ h("svg", {
				className: "dc-over-arch",
				viewBox: "0 0 1200 760",
				preserveAspectRatio: "xMidYMax meet",
				"aria-hidden": !0,
				focusable: "false",
				children: [
					/* @__PURE__ */ m("path", {
						d: "M120 760 L120 330 Q120 80 600 80 Q1080 80 1080 330 L1080 760",
						fill: "none",
						stroke: "rgba(201,163,91,0.28)",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ m("path", {
						d: "M170 760 L170 350 Q170 130 600 130 Q1030 130 1030 350 L1030 760",
						fill: "none",
						stroke: "rgba(201,163,91,0.12)",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ m("circle", {
						cx: "600",
						cy: "150",
						r: "7",
						fill: "rgba(201,163,91,0.5)"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "dc-over-emblem",
				"aria-hidden": !0,
				children: /* @__PURE__ */ m("span", { children: "✦" })
			}),
			/* @__PURE__ */ h("div", {
				className: "dc-over-inner",
				children: [
					/* @__PURE__ */ h("header", {
						className: "dc-over-head",
						children: [
							/* @__PURE__ */ m("span", {
								className: "dc-over-crest",
								"aria-hidden": !0,
								children: "✦"
							}),
							/* @__PURE__ */ m("h1", { children: y }),
							p.winReason && /* @__PURE__ */ m("p", { children: c(`games.duelforcardia.winReasons.${p.winReason}`) })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "dc-over-players",
						children: x.map((t) => {
							let i = p.players.find((e) => e.rid === t), a = n.find((e) => e.rid === t), o = e.scores?.[t] ?? i?.signets ?? 0, s = a ? _[a.colorIndex % _.length].hex : "#c9a35b";
							return /* @__PURE__ */ h("section", {
								className: "dc-over-player",
								"data-won": e.winner.includes(t) ? "true" : void 0,
								children: [
									a && /* @__PURE__ */ m("span", {
										className: "dc-over-avatar",
										style: { borderColor: s },
										children: /* @__PURE__ */ m("img", {
											src: g[a.avatar % g.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ h("h2", { children: [v(t), t === r && /* @__PURE__ */ m("small", { children: c("games.duelforcardia.ui.you") })] }),
									/* @__PURE__ */ m("div", {
										className: "dc-over-signets",
										"aria-label": c("games.duelforcardia.ui.signetsFinal"),
										children: Array.from({ length: 5 }, (e, t) => /* @__PURE__ */ m("i", {
											className: t < o ? "is-filled" : void 0,
											"aria-hidden": !0
										}, t))
									}),
									/* @__PURE__ */ h("p", {
										className: "dc-over-score",
										children: [/* @__PURE__ */ m("b", { children: o }), /* @__PURE__ */ m("span", { children: c("games.duelforcardia.ui.signetsFinal") })]
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ h("p", {
						className: "dc-over-rounds",
						children: [
							c("games.duelforcardia.ui.encounters"),
							": ",
							p.round
						]
					}),
					b ? /* @__PURE__ */ h("div", {
						className: "dc-over-controls",
						children: [i && /* @__PURE__ */ m("button", {
							type: "button",
							className: "dc-over-primary",
							onClick: i,
							children: c("session.result.playAgain")
						}), s && /* @__PURE__ */ m("button", {
							type: "button",
							className: "dc-over-secondary",
							onClick: s,
							children: c("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ m("p", {
						className: "dc-over-wait",
						children: c("session.result.waitHost")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Dt({ value: e, onChange: t }) {
	let n = o(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0), a = (e) => {
		switch (e) {
			case "serpent": return n("games.duelforcardia.locations.serpent.name");
			case "bazaar": return n("games.duelforcardia.locations.bazaar.name");
			case "founders": return n("games.duelforcardia.locations.founders.name");
			case "library": return n("games.duelforcardia.locations.library.name");
			case "scrapyard": return n("games.duelforcardia.locations.scrapyard.name");
			case "auction": return n("games.duelforcardia.locations.auction.name");
			case "catacombs": return n("games.duelforcardia.locations.catacombs.name");
			case "swamp": return n("games.duelforcardia.locations.swamp.name");
		}
	};
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ m(te, {
			title: n("games.duelforcardia.optDeck"),
			columns: 2,
			children: ["I", "II"].map((e) => /* @__PURE__ */ m(v, {
				name: "duelforcardia-deck",
				value: e,
				checked: i.deck === e,
				label: n(e === "I" ? "games.duelforcardia.deckI" : "games.duelforcardia.deckII"),
				accent: k.accent,
				onChange: () => t({
					...i,
					deck: e
				})
			}, e))
		}), /* @__PURE__ */ m(te, {
			title: n("games.duelforcardia.optLocation"),
			columns: 2,
			children: ["none", ...E].map((e) => /* @__PURE__ */ m(v, {
				name: "duelforcardia-location",
				value: e,
				checked: i.location === e,
				label: e === "none" ? n("games.duelforcardia.noLocation") : `${a(e)} · ${T.find((t) => t.id === e)?.skulls ?? 0}`,
				accent: k.accent,
				onChange: () => t({
					...i,
					location: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/index.tsx
var Ot = {
	definition: Je,
	View: tt,
	bot: Tt,
	OverView: Et,
	Options: Dt,
	locales: {
		zh: {
			name: "Duel for Cardia",
			desc: "双方轮流出牌交锋，以影响力争夺印戒；率先取得五枚印戒的人获胜。",
			invalid: "当前无法执行这个行动，请重新选择。",
			optDeck: "牌库",
			deckI: "牌库 I（基础）",
			deckII: "牌库 II（进阶）",
			optLocation: "地点",
			noLocation: "不使用地点",
			factions: {
				rebellion: "起义军",
				academy: "学院",
				guild: "公会",
				dynasty: "王朝"
			},
			cards: {
				i1: {
					name: "雇佣刀手",
					ability: "弃置这张牌与它相对的牌，然后关闭因此空出的交锋位置。"
				},
				i2: {
					name: "虚空法师",
					ability: "选择任意一张已打出的牌，移除其上的全部影响力增减标记，或移除其上的全部持续标记。"
				},
				i3: {
					name: "外科医师",
					ability: "你打出的下一张牌失去 5 点影响力。"
				},
				i4: {
					name: "调停者",
					ability: "本次交锋视为平局。"
				},
				i5: {
					name: "破坏者",
					ability: "对手从其牌库顶弃置 2 张牌。"
				},
				i6: {
					name: "预言师",
					ability: "在下一场交锋中，对手先于你亮出其打出的牌。"
				},
				i7: {
					name: "宫廷守卫",
					ability: "选择一个阵营。对手可以弃置其手中 1 张该阵营的牌；若对手不弃置，这张牌获得 7 点影响力。"
				},
				i8: {
					name: "法官",
					ability: "你赢得所有平局的交锋，包括今后的交锋。由平局改为获胜时，不触发对方牌的能力。"
				},
				i9: {
					name: "伏击者",
					ability: "选择一个阵营。对手弃置其手中所有该阵营的牌。"
				},
				i10: {
					name: "傀儡师",
					ability: "弃置对手当前交锋中的牌，然后从对手手中随机抽取 1 张牌替换它。被抽出的牌不触发能力。"
				},
				i11: {
					name: "钟表匠",
					ability: "上一场交锋中你打出的牌，以及你打出的下一张牌，各获得 3 点影响力。"
				},
				i12: {
					name: "司库",
					ability: "上一场交锋的获胜牌额外计 1 枚印戒。"
				},
				i13: {
					name: "沼泽守卫",
					ability: "将你另一张已打出的牌收回手中，并弃置与它相对的牌。"
				},
				i14: {
					name: "女导师",
					ability: "复制并发动你另一张已打出的牌的即时能力；该牌的影响力必须不低于这张牌。"
				},
				i15: {
					name: "发明家",
					ability: "任意一张牌获得 3 点影响力，另一张任意牌失去 3 点影响力。"
				},
				i16: {
					name: "灯神",
					ability: "你立即赢得本局游戏。"
				},
				ii1: {
					name: "投毒者",
					ability: "降低对手当前交锋中牌的影响力，直到本次交锋成为平局。"
				},
				ii2: {
					name: "念力法师",
					ability: "将你一张牌上的全部影响力增减标记与持续标记移到你另一张已打出的牌上。"
				},
				ii3: {
					name: "使节",
					ability: "任意一张牌失去 3 点影响力，或你打出的下一张牌失去 3 点影响力。"
				},
				ii4: {
					name: "税吏",
					ability: "这张牌获得 4 点影响力。"
				},
				ii5: {
					name: "革命者",
					ability: "对手弃置其手中 2 张牌，然后抽取 2 张牌。"
				},
				ii6: {
					name: "图书管理员",
					ability: "你打出的下一张牌亮出后，你选择使其获得 2 点影响力或失去 2 点影响力。"
				},
				ii7: {
					name: "神童",
					ability: "你一张影响力不高于 8 的已打出牌获得 3 点影响力。"
				},
				ii8: {
					name: "贵族",
					ability: "若这张牌赢得其交锋，它额外计 1 枚印戒。"
				},
				ii9: {
					name: "勒索者",
					ability: "选择一个阵营。若对手下一场打出的牌不属于该阵营，对手在亮牌后弃置其手中 2 张牌。"
				},
				ii10: {
					name: "幻术师",
					ability: "发动你一张正输掉其交锋的牌的能力。"
				},
				ii11: {
					name: "工程师",
					ability: "在能力结算之后，你打出的下一张牌获得 5 点影响力。"
				},
				ii12: {
					name: "顾问",
					ability: "在上一场交锋中，你的牌获胜，对手的牌落败。"
				},
				ii13: {
					name: "巫王",
					ability: "选择一个阵营。对手弃置其手中与牌库中所有该阵营的牌，然后洗混其牌库。"
				},
				ii14: {
					name: "元素师",
					ability: "弃置你手中 1 张具有即时能力的牌，复制并发动该能力，然后抽取 1 张牌。"
				},
				ii15: {
					name: "机械灯神",
					ability: "若你赢得下一场交锋，你立即赢得本局游戏。"
				},
				ii16: {
					name: "继任者",
					ability: "对手弃置其整个牌库，并只保留手中 2 张牌。"
				}
			},
			locations: {
				serpent: {
					name: "蛇神殿",
					text: "每当你赢得一场过去的交锋时，你抽取 1 张牌，对手弃置其手中 1 张牌。"
				},
				bazaar: {
					name: "集市",
					text: "每轮结束时，你不抽牌。每当你手中只有 1 张或更少的牌时，立即抽取 4 张牌。"
				},
				founders: {
					name: "建城纪念日",
					text: "若你曾连续赢得 3 场交锋，你立即赢得本局游戏。"
				},
				library: {
					name: "大图书馆",
					text: "游戏开始时，你抽取 2 张牌而非 5 张。每轮结束时，你抽取 2 张牌而非 1 张。"
				},
				scrapyard: {
					name: "废料场",
					text: "每轮结束时，若你的牌库中至少有 2 张牌，你抽取 2 张牌而非 1 张，然后将手中 1 张牌置于你的牌库底部。"
				},
				auction: {
					name: "拍卖行",
					text: "每当你亮出的牌影响力低于你上一场交锋的牌时，你弃置牌库顶的 1 张牌。"
				},
				catacombs: {
					name: "闹鬼地下墓穴",
					text: "若你亮出的牌与你上一场交锋的牌属于同一阵营，你立即输掉本局游戏。"
				},
				swamp: {
					name: "迷雾沼泽",
					text: "你打出牌后，不亮出当前交锋的牌；改为亮出并结算上一场交锋。"
				}
			},
			tasks: {
				"palace-faction": "选择一个阵营，对手可以弃置该阵营的一张手牌。",
				"palace-confirm": "是否弃置 1 张该阵营的手牌，以避免对方的宫廷守卫获得 7 点影响力？",
				"ambusher-faction": "选择一个阵营，对手将弃置手中所有该阵营的牌。",
				"void-mode": "选择要移除的内容。",
				"void-card": "选择一张已打出的牌。",
				"swamp-card": "选择你另一张已打出的牌。",
				"magistra-card": "选择一张影响力不低于女导师的已打出牌，复制其即时能力。",
				"illusionist-card": "选择你一张正输掉其交锋的牌。",
				"inventor-first": "选择获得 3 点影响力的牌。",
				"inventor-second": "选择另一张失去 3 点影响力的牌。",
				"kinesis-source": "选择要移走标记的己方牌。",
				"kinesis-target": "选择接收标记的另一张己方牌。",
				"prodigy-card": "选择一张影响力不高于 8 的己方牌。",
				"envoy-mode": "选择使节的效果。",
				"envoy-card": "选择失去 3 点影响力的牌。",
				"elemental-hand": "选择手中一张具有即时能力的牌。",
				"witch-faction": "选择一个阵营。",
				"blackmail-faction": "选择一个阵营，作为对手下一场可能打出的阵营。",
				"librarian-choice": "选择下一张牌的影响力修正。",
				"scrapyard-bottom": "选择一张手牌置于你的牌库底部。",
				"successor-keep": "选择要保留的 2 张手牌。",
				"serpent-discard": "蛇神殿：选择并弃置 1 张手牌。",
				"blackmail-discard": "勒索者：选择并弃置 2 张手牌。",
				"revolutionary-discard": "革命者：选择并弃置 2 张手牌。",
				generic: "请选择一项。"
			},
			modes: {
				mods: "移除全部影响力标记",
				tokens: "移除全部持续标记",
				any: "任意一张牌",
				next: "下一张打出的牌",
				plus2: "获得 2 点影响力",
				minus2: "失去 2 点影响力"
			},
			ui: {
				round: "第 {{n}} 轮",
				choose: "选择一张手牌",
				preplay: "你先亮出下一张牌",
				waiting: "等待对手出牌",
				play: "打出这张牌",
				selected: "已选择",
				cancel: "取消选择",
				confirm: "确认",
				yes: "弃置",
				no: "不弃置",
				skip: "跳过",
				signets: "印戒",
				influence: "影响力",
				hand: "手牌",
				deck: "牌库",
				discard: "弃牌堆",
				discardTitle: "{{name}} 的弃牌堆",
				discardHint: "双方均可随时查看任意一方的弃牌堆。",
				discardEmpty: "弃牌堆为空。",
				location: "地点",
				you: "你",
				opponent: "对手",
				yourCard: "你的牌",
				opponentCard: "对手的牌",
				faceDown: "未亮出",
				empty: "没有牌",
				current: "当前交锋",
				previous: "上一场交锋",
				noTasks: "没有需要处理的效果",
				log: "最近事件",
				rulesOpen: "查看规则",
				win: "胜利",
				lose: "失败",
				draw: "平局",
				signetsFinal: "最终印戒",
				rounds: "交锋轮数",
				yourTurn: "轮到你出牌",
				pickTarget: "点击高亮的牌完成选择",
				pickHand: "点击高亮的手牌完成选择",
				waitTask: "等待 {{name}} 处理效果",
				ability: "能力",
				modifiers: "影响力修正",
				ongoing: "持续能力",
				signetsOnCard: "印戒",
				keepCount: "已保留 {{n}}/2",
				close: "关闭",
				deckLeft: "牌库 {{n}}",
				latest: "最近事件",
				tapDetails: "点按查看牌面详情",
				difficulty: "难度 {{n}}",
				victoryTitle: "你赢得了卡迪亚",
				defeatTitle: "你输掉了这一局",
				drawTitle: "这一局以平局结束",
				reason: "获胜原因",
				encounters: "交锋数",
				encounterTrack: "交锋轨道",
				nextMod: "下一张牌 {{n}}"
			},
			logs: {
				play: "{{name}} 打出了一张牌。",
				reveal: "双方亮出了交锋牌。",
				win: "{{name}} 赢得了这次交锋。",
				tie: "这次交锋为平局。",
				ability: "{{name}} 发动了{{card}}的能力。",
				draw: "{{name}} 抽取了 {{n}} 张牌。",
				discard: "{{name}} 弃置了 {{n}} 张牌。",
				mod: "{{name}} 调整了一张牌的影响力。",
				token: "{{name}} 在一张牌上放置了持续标记。",
				winGame: "{{name}} 赢得了本局游戏。"
			},
			winReasons: {
				noPlay: "对手无法出牌。",
				opponentNoPlay: "你无法出牌。",
				djinn: "灯神的能力使玩家立即获胜。",
				founders: "建城纪念日：连续赢得 3 场交锋。",
				mechanical: "机械灯神：赢得下一场交锋。",
				catacombs: "闹鬼地下墓穴：亮出了与上一场同阵营的牌。",
				five: "轮末拥有 5 枚或更多印戒。",
				bothNoPlay: "双方都无法出牌，印戒较多者获胜。",
				draw: "双方都无法出牌且印戒数量相同。"
			},
			rules: "目标：\n每位玩家使用相同的 16 张角色牌牌库进行对决。双方轮流打出一张牌形成交锋，影响力较高的牌赢得交锋并获得印戒。率先让自己打出的牌上累计 5 枚印戒的玩家赢得本局游戏。\n\n准备：\n· 双方选择相同的牌库（牌库 I 或牌库 II）。每名玩家洗混自己的 16 张角色牌，抽取 5 张作为手牌，其余牌作为自己的牌库。\n· 如果选择了地点，把该地点牌正面朝上放在桌上。地点的规则对整个游戏持续生效，并且对双方同时适用。\n· 把印戒、影响力增减标记和持续标记放在双方都能拿到的公共供应区。印戒和持续标记的数量按需要取用；持续标记不足时可以用合适的替代物。\n\n每轮流程：\n阶段 1：出牌与亮牌。双方各从手中选择 1 张牌，背面朝上放在自己一侧，形成一场新的交锋。双方都放好后，同时亮出这两张牌并比较影响力。影响力较高的牌赢得这次交锋，从供应区拿取 1 枚印戒放在获胜牌上。若双方影响力相同，这次交锋为平局，不放置印戒，并跳过阶段 2。\n阶段 2：发动能力。只有输掉当前交锋的玩家发动其失败牌的能力。玩家必须尽可能完整地结算能力，包括能力对其他牌造成的后果。能力与一般规则冲突时，以能力文字为准。\n阶段 3：轮末。双方各从自己的牌库顶抽取 1 张牌。牌库为空时不能抽牌，也不要洗混弃牌堆；不能抽牌不会导致失败。随后开始下一轮。\n\n影响力与标记：\n· 牌的基础影响力印在牌上。影响力增减标记会立即加入或扣除该牌的影响力，并在标记留在牌上期间持续生效。一张牌可以同时有正负标记，合计后可能为负数。\n· 每当一张牌的影响力超过与它相对的牌，就把印戒放到影响力较高的牌上，并把对方牌上的印戒放回供应区。若两张牌影响力相同，则把该交锋中的印戒放回供应区。\n· 能力使过去的交锋改变胜负时，只移动或移除印戒，不再次发动新落败牌的能力。\n· 若能力要求把标记放在“你打出的下一张牌”上，就把标记放在当前交锋中你下一张牌的位置；你亮出下一张牌时立即把标记放到该牌上，并在阶段 1 比较影响力时计入。\n\n能力类型：\n· 即时能力：发动时立即结算一次，然后结束。\n· 持续能力：发动时在牌上放置 1 枚持续标记。只要标记留在牌上，能力就持续生效；即使这张牌后来赢得交锋，能力仍然有效。持续标记被移除时，能力立即失效，并立即结算由此产生的所有变化。\n\n交锋位置与弃牌：\n· “上一场交锋”指当前交锋沿出牌方向相邻的上一场交锋。“过去的交锋”指当前交锋之前的所有交锋。“下一场交锋”指沿出牌方向紧随其后的交锋。\n· 弃置的牌正面朝上放入弃牌堆，牌上的标记放回供应区。双方可以随时查看双方的弃牌堆。\n· 若一场交锋中的两张牌都被弃置，后续交锋会向前移动以填补空位，位置关系按移动后的顺序重新确定。\n\n结束条件：\n· 阶段 1：若对手无法打出一张牌，你立即赢得本局游戏。\n· 阶段 2：若你发动的能力说明你赢得本局游戏，你立即获胜。\n· 阶段 3：轮末拥有 5 枚或更多印戒的玩家获胜。若双方都拥有至少 5 枚且数量相同，游戏继续，直到一方印戒更多或以其他方式获胜。\n· 若阶段 1 中双方都无法出牌，印戒较多者获胜；若印戒数量相同，本局为平局。\n\n牌库 I 的卡牌能力：\n· 雇佣刀手（影响力 1，起义军，即时能力）：弃置这张牌与它相对的牌，然后关闭因此空出的交锋位置。\n· 虚空法师（影响力 2，学院，即时能力）：选择任意一张已打出的牌，移除其上的全部影响力增减标记，或移除其上的全部持续标记。\n· 外科医师（影响力 3，公会，即时能力）：你打出的下一张牌失去 5 点影响力。\n· 调停者（影响力 4，王朝，持续能力）：本次交锋视为平局。\n· 破坏者（影响力 5，起义军，即时能力）：对手从其牌库顶弃置 2 张牌。\n· 预言师（影响力 6，学院，即时能力）：在下一场交锋中，对手先于你亮出其打出的牌。\n· 宫廷守卫（影响力 7，公会，即时能力）：选择一个阵营。对手可以弃置其手中 1 张该阵营的牌；若对手不弃置，这张牌获得 7 点影响力。\n· 法官（影响力 8，王朝，持续能力）：你赢得所有平局的交锋，包括今后的交锋。由平局改为获胜时，不触发对方牌的能力。\n· 伏击者（影响力 9，起义军，即时能力）：选择一个阵营。对手弃置其手中所有该阵营的牌。\n· 傀儡师（影响力 10，学院，即时能力）：弃置对手当前交锋中的牌，然后从对手手中随机抽取 1 张牌替换它。被抽出的牌不触发能力。\n· 钟表匠（影响力 11，公会，即时能力）：上一场交锋中你打出的牌，以及你打出的下一张牌，各获得 3 点影响力。\n· 司库（影响力 12，王朝，持续能力）：上一场交锋的获胜牌额外计 1 枚印戒。\n· 沼泽守卫（影响力 13，起义军，即时能力）：将你另一张已打出的牌收回手中，并弃置与它相对的牌。\n· 女导师（影响力 14，学院，即时能力）：复制并发动你另一张已打出的牌的即时能力；该牌的影响力必须不低于这张牌。\n· 发明家（影响力 15，公会，即时能力）：任意一张牌获得 3 点影响力，另一张任意牌失去 3 点影响力。\n· 灯神（影响力 16，王朝，即时能力）：你立即赢得本局游戏。\n\n牌库 II 的卡牌能力：\n· 投毒者（影响力 1，起义军，即时能力）：降低对手当前交锋中牌的影响力，直到本次交锋成为平局。\n· 念力法师（影响力 2，学院，即时能力）：将你一张牌上的全部影响力增减标记与持续标记移到你另一张已打出的牌上。\n· 使节（影响力 3，公会，即时能力）：任意一张牌失去 3 点影响力，或你打出的下一张牌失去 3 点影响力。\n· 税吏（影响力 4，王朝，即时能力）：这张牌获得 4 点影响力。\n· 革命者（影响力 5，起义军，即时能力）：对手弃置其手中 2 张牌，然后抽取 2 张牌。\n· 图书管理员（影响力 6，学院，即时能力）：你打出的下一张牌亮出后，你选择使其获得 2 点影响力或失去 2 点影响力。\n· 神童（影响力 7，公会，即时能力）：你一张影响力不高于 8 的已打出牌获得 3 点影响力。\n· 贵族（影响力 8，王朝，持续能力）：若这张牌赢得其交锋，它额外计 1 枚印戒。\n· 勒索者（影响力 9，起义军，即时能力）：选择一个阵营。若对手下一场打出的牌不属于该阵营，对手在亮牌后弃置其手中 2 张牌。\n· 幻术师（影响力 10，学院，即时能力）：发动你一张正输掉其交锋的牌的能力。\n· 工程师（影响力 11，公会，即时能力）：在能力结算之后，你打出的下一张牌获得 5 点影响力。\n· 顾问（影响力 12，王朝，持续能力）：在上一场交锋中，你的牌获胜，对手的牌落败。\n· 巫王（影响力 13，起义军，即时能力）：选择一个阵营。对手弃置其手中与牌库中所有该阵营的牌，然后洗混其牌库。\n· 元素师（影响力 14，学院，即时能力）：弃置你手中 1 张具有即时能力的牌，复制并发动该能力，然后抽取 1 张牌。\n· 机械灯神（影响力 15，公会，持续能力）：若你赢得下一场交锋，你立即赢得本局游戏。\n· 继任者（影响力 16，王朝，即时能力）：对手弃置其整个牌库，并只保留手中 2 张牌。\n\n地点：\n· 蛇神殿（难度 1）：每当你赢得一场过去的交锋时，你抽取 1 张牌，对手弃置其手中 1 张牌。\n· 集市（难度 1）：每轮结束时，你不抽牌。每当你手中只有 1 张或更少的牌时，立即抽取 4 张牌。\n· 建城纪念日（难度 3）：若你曾连续赢得 3 场交锋，你立即赢得本局游戏。\n· 大图书馆（难度 2）：游戏开始时，你抽取 2 张牌而非 5 张。每轮结束时，你抽取 2 张牌而非 1 张。\n· 废料场（难度 2）：每轮结束时，若你的牌库中至少有 2 张牌，你抽取 2 张牌而非 1 张，然后将手中 1 张牌置于你的牌库底部。\n· 拍卖行（难度 2）：每当你亮出的牌影响力低于你上一场交锋的牌时，你弃置牌库顶的 1 张牌。\n· 闹鬼地下墓穴（难度 3）：若你亮出的牌与你上一场交锋的牌属于同一阵营，你立即输掉本局游戏。\n· 迷雾沼泽（难度 2）：你打出牌后，不亮出当前交锋的牌；改为亮出并结算上一场交锋。"
		},
		en: {
			name: "Duel for Cardia",
			desc: "Two rivals play cards into successive encounters, competing for signets. The first to collect five signets wins.",
			invalid: "That action is not available. Please choose again.",
			optDeck: "Deck",
			deckI: "Deck I (basic)",
			deckII: "Deck II (advanced)",
			optLocation: "Location",
			noLocation: "No location",
			factions: {
				rebellion: "Rebellion",
				academy: "Academy",
				guild: "Guild",
				dynasty: "Dynasty"
			},
			cards: {
				i1: {
					name: "Hired Blade",
					ability: "Discard this card and the opposing card, then close the encounter position left empty."
				},
				i2: {
					name: "Void Mage",
					ability: "Choose any played card and remove either all influence modifiers or all ongoing tokens from it."
				},
				i3: {
					name: "Surgeon",
					ability: "The next card you play gets -5 influence."
				},
				i4: {
					name: "Mediator",
					ability: "This encounter is a tie."
				},
				i5: {
					name: "Saboteur",
					ability: "Your opponent discards the top 2 cards of their deck."
				},
				i6: {
					name: "Fortune Teller",
					ability: "In the next encounter, your opponent reveals their card before you play yours."
				},
				i7: {
					name: "Palace Guard",
					ability: "Choose a faction. Your opponent may discard 1 card of it from hand; if not, this card gets +7 influence."
				},
				i8: {
					name: "Judge",
					ability: "You win all ties, including future ones. When a tie becomes your win, the opposing ability does not trigger."
				},
				i9: {
					name: "Ambusher",
					ability: "Choose a faction. Your opponent discards all cards of that faction from their hand."
				},
				i10: {
					name: "Puppeteer",
					ability: "Replace the opposing card with a random card from your opponent's hand; it does not trigger its ability."
				},
				i11: {
					name: "Clockmaker",
					ability: "Your card in the previous encounter and the next card you play each get +3 influence."
				},
				i12: {
					name: "Treasurer",
					ability: "The card that wins the previous encounter is worth 1 additional signet."
				},
				i13: {
					name: "Swamp Guardian",
					ability: "Take one of your other played cards back into your hand and discard the card opposing it."
				},
				i14: {
					name: "Magistra",
					ability: "Copy the instant ability of another of your played cards with influence at least as high as this card."
				},
				i15: {
					name: "Inventor",
					ability: "Give any one card +3 influence and any other card -3 influence."
				},
				i16: {
					name: "Djinn",
					ability: "You immediately win the game."
				},
				ii1: {
					name: "Poisoner",
					ability: "Reduce the influence of the opposing card until this encounter is a tie."
				},
				ii2: {
					name: "Kinesis Mage",
					ability: "Move all modifiers and ongoing tokens from one of your cards to another of your played cards."
				},
				ii3: {
					name: "Envoy",
					ability: "Give any one card -3 influence, or give the next card you play -3 influence."
				},
				ii4: {
					name: "Tax Collector",
					ability: "This card gets +4 influence."
				},
				ii5: {
					name: "Revolutionary",
					ability: "Your opponent discards 2 cards from their hand, then draws 2 cards."
				},
				ii6: {
					name: "Librarian",
					ability: "After the next card you play is revealed, choose whether it gets +2 or -2 influence."
				},
				ii7: {
					name: "Prodigy",
					ability: "One of your played cards with 8 or less influence gets +3 influence."
				},
				ii8: {
					name: "Aristocrat",
					ability: "If this card wins its encounter, it is worth 1 additional signet."
				},
				ii9: {
					name: "Blackmailer",
					ability: "Choose a faction. If your opponent's next card is not that faction, they discard 2 cards after revealing it."
				},
				ii10: {
					name: "Illusionist",
					ability: "Activate the ability of one of your cards that is losing its encounter."
				},
				ii11: {
					name: "Engineer",
					ability: "After abilities are resolved, the next card you play gets +5 influence."
				},
				ii12: {
					name: "Counselor",
					ability: "In the previous encounter, your card wins and the opposing card loses."
				},
				ii13: {
					name: "Witch King",
					ability: "Choose a faction. Your opponent discards all cards of it from hand and deck, then shuffles their deck."
				},
				ii14: {
					name: "Elemental",
					ability: "Discard a card with an instant ability from your hand, copy that ability, then draw 1 card."
				},
				ii15: {
					name: "Mechanical Djinn",
					ability: "If you win the following encounter, you immediately win the game."
				},
				ii16: {
					name: "Successor",
					ability: "Your opponent discards their entire deck and all but 2 cards from their hand."
				}
			},
			locations: {
				serpent: {
					name: "Serpent Temple",
					text: "Whenever you win a past encounter, draw 1 card and your opponent discards 1 card from their hand."
				},
				bazaar: {
					name: "Bazaar",
					text: "At the end of each round, do not draw cards. Whenever you have 1 card or fewer in hand, immediately draw 4 cards."
				},
				founders: {
					name: "Founder's Day",
					text: "If you ever win 3 successive encounters, you immediately win the game."
				},
				library: {
					name: "Grand Library",
					text: "At the beginning of the game, draw 2 cards instead of 5. At the end of each round, draw 2 cards instead of 1."
				},
				scrapyard: {
					name: "Scrapyard",
					text: "At the end of each round, if your deck has at least 2 cards, draw 2 cards instead of 1, then place 1 card from your hand under your deck."
				},
				auction: {
					name: "Auction House",
					text: "Whenever you reveal a card with less influence than your card in the previous encounter, discard the top card of your deck."
				},
				catacombs: {
					name: "Haunted Catacombs",
					text: "If you reveal a card of the same faction as your card in the previous encounter, you immediately lose the game."
				},
				swamp: {
					name: "Foggy Swamp",
					text: "After you place cards, do not reveal the current encounter. Instead, reveal and resolve the previous encounter."
				}
			},
			tasks: {
				"palace-faction": "Choose a faction. Your opponent may discard one card of that faction from their hand.",
				"palace-confirm": "Discard 1 card of that faction to prevent the Palace Guard from getting +7 influence?",
				"ambusher-faction": "Choose a faction. Your opponent will discard every card of that faction from their hand.",
				"void-mode": "Choose what to remove.",
				"void-card": "Choose a played card.",
				"swamp-card": "Choose another of your played cards.",
				"magistra-card": "Choose a played card with at least the Magistra influence to copy its instant ability.",
				"illusionist-card": "Choose one of your cards that is losing its encounter.",
				"inventor-first": "Choose the card that gets +3 influence.",
				"inventor-second": "Choose a different card that gets -3 influence.",
				"kinesis-source": "Choose your card to move the markers from.",
				"kinesis-target": "Choose another of your cards to receive the markers.",
				"prodigy-card": "Choose one of your cards with 8 or less influence.",
				"envoy-mode": "Choose the Envoy effect.",
				"envoy-card": "Choose the card that gets -3 influence.",
				"elemental-hand": "Choose a card with an instant ability from your hand.",
				"witch-faction": "Choose a faction.",
				"blackmail-faction": "Choose a faction your opponent may play next.",
				"librarian-choice": "Choose the influence adjustment for the next card.",
				"scrapyard-bottom": "Choose a card from your hand to place under your deck.",
				"successor-keep": "Choose 2 cards from your hand to keep.",
				"serpent-discard": "Serpent Temple: choose and discard 1 card from your hand.",
				"blackmail-discard": "Blackmailer: choose and discard 2 cards from your hand.",
				"revolutionary-discard": "Revolutionary: choose and discard 2 cards from your hand.",
				generic: "Choose an option."
			},
			modes: {
				mods: "Remove all influence modifiers",
				tokens: "Remove all ongoing tokens",
				any: "Any one card",
				next: "The next card you play",
				plus2: "+2 influence",
				minus2: "-2 influence"
			},
			ui: {
				round: "Round {{n}}",
				choose: "Choose a card from your hand",
				preplay: "Reveal your next card first",
				waiting: "Waiting for your opponent",
				play: "Play this card",
				selected: "Selected",
				cancel: "Clear selection",
				confirm: "Confirm",
				yes: "Discard",
				no: "Do not discard",
				skip: "Skip",
				signets: "Signets",
				influence: "Influence",
				hand: "Hand",
				deck: "Deck",
				discard: "Discard",
				discardTitle: "{{name}}'s discard pile",
				discardHint: "Either player may look through either discard pile at any time.",
				discardEmpty: "The discard pile is empty.",
				location: "Location",
				you: "You",
				opponent: "Opponent",
				yourCard: "Your card",
				opponentCard: "Opponent card",
				faceDown: "Face down",
				empty: "No cards",
				current: "Current encounter",
				previous: "Previous encounter",
				noTasks: "No effect is waiting",
				log: "Recent events",
				rulesOpen: "View rules",
				win: "Victory",
				lose: "Defeat",
				draw: "Draw",
				signetsFinal: "Final signets",
				rounds: "Encounters",
				yourTurn: "Your turn to play a card",
				pickTarget: "Tap a highlighted card to choose it",
				pickHand: "Tap a highlighted card in your hand",
				waitTask: "Waiting for {{name}} to resolve an effect",
				ability: "Ability",
				modifiers: "Influence modifiers",
				ongoing: "Ongoing ability",
				signetsOnCard: "Signets",
				keepCount: "Kept {{n}}/2",
				close: "Close",
				deckLeft: "Deck {{n}}",
				latest: "Latest event",
				tapDetails: "Tap for card details",
				difficulty: "Difficulty {{n}}",
				victoryTitle: "You won Cardia",
				defeatTitle: "You lost this duel",
				drawTitle: "This duel ended in a draw",
				reason: "Win condition",
				encounters: "Encounters",
				encounterTrack: "Encounter track",
				nextMod: "Next card {{n}}"
			},
			logs: {
				play: "{{name}} played a card.",
				reveal: "Both encounter cards were revealed.",
				win: "{{name}} won the encounter.",
				tie: "The encounter is a tie.",
				ability: "{{name}} activated {{card}}.",
				draw: "{{name}} drew {{n}} card(s).",
				discard: "{{name}} discarded {{n}} card(s).",
				mod: "{{name}} adjusted the influence of a card.",
				token: "{{name}} placed an ongoing token on a card.",
				winGame: "{{name}} won the game."
			},
			winReasons: {
				noPlay: "The opponent cannot play a card.",
				opponentNoPlay: "You cannot play a card.",
				djinn: "The Djinn ability wins the game immediately.",
				founders: "Founder's Day: 3 successive encounters won.",
				mechanical: "Mechanical Djinn: the following encounter was won.",
				catacombs: "Haunted Catacombs: a card of the same faction as the previous card was revealed.",
				five: "5 or more signets at the end of the round.",
				bothNoPlay: "Neither player can play; the player with more signets wins.",
				draw: "Neither player can play and both have the same number of signets."
			},
			rules: "Goal:\nEach player duels with the same 16-character deck. You play one card at a time to form encounters, and the higher influence wins a signet. The first player to collect 5 signets on their played cards wins the game.\n\nSetup:\n· Both players choose the same deck (Deck I or Deck II). Each player shuffles their own 16 character cards, draws 5 cards as their hand, and places the rest face down as their deck.\n· If you choose a location, place that location card face up on the table. Its rule applies for the whole game and to both players.\n· Place the signets, influence modifiers, and ongoing tokens within reach as a shared supply. Take as many signets and ongoing tokens as needed; if tokens run out, use suitable substitutes.\n\nEach round:\nPhase 1: Play and reveal. Each player chooses 1 card from their hand and places it face down on their side, forming a new encounter. After both have placed, reveal both cards simultaneously and compare their influence. The higher-influence card wins the encounter; take 1 signet from the supply and place it on the winning card. If both influences are equal, the encounter is a tie, no signet is placed, and phase 2 is skipped.\nPhase 2: Activate an ability. Only the player whose card loses the current encounter activates that card ability. Resolve the ability as fully as possible, including all consequences for other cards. If an ability contradicts the general rules, the ability takes precedence.\nPhase 3: End of the round. Each player draws 1 card from the top of their deck. If a deck is empty, that player cannot draw; do not shuffle the discard pile, and being unable to draw does not cause a loss. Then begin the next round.\n\nInfluence and modifiers:\n· A card printed influence is its base value. Influence modifiers are added to or subtracted from that value immediately and remain in effect while the modifiers stay on the card. Positive and negative modifiers on the same card are combined, and the total influence can be negative.\n· Whenever a card influence exceeds that of the opposing card, place a signet on the higher-influence card and return any signets on the opposing card to the supply. If both influences are equal, return the encounter signets to the supply.\n· If an ability changes the result of a past encounter, move or remove the signets, but do not activate the ability of the card that newly loses.\n· If an ability places a modifier on “the next card you play,” place it in the space for your next card in the current encounter. When you reveal that card, place the modifier on it immediately; the modifier counts during the phase 1 influence comparison.\n\nAbility types:\n· Instant ability: activate it once and resolve it immediately.\n· Ongoing ability: place 1 ongoing token on the card when you activate it. The ability remains in effect while the token stays on the card, even if that card later wins its encounter. If the token is removed, the ability ends immediately and any resulting changes are resolved immediately.\n\nEncounter positions and discards:\n· “Previous encounter” means the encounter immediately before the current one in the direction of play. “Past encounters” means every encounter before the current one. “Following encounter” means the encounter immediately after the current one in the direction of play.\n· Discarded cards go face up into the discard pile, and any tokens on them return to the supply. Both players may inspect both discard piles at any time.\n· If both cards in an encounter are discarded, later encounters shift forward to close the gap, and all position references are recalculated from the new order.\n\nEnd of the game:\n· Phase 1: if your opponent cannot play a card, you immediately win the game.\n· Phase 2: if an ability you activate says you win the game, you immediately win.\n· Phase 3: at the end of the round, a player with 5 or more signets wins. If both players have at least 5 signets and the same number, continue playing until one player has more signets or wins another way.\n· If both players cannot play in phase 1, the player with more signets wins; if both have the same number, the game is a draw.\n\nDeck I card abilities:\n· Hired Blade (influence 1, Rebellion, instant ability): Discard this card and the opposing card, then close the encounter position left empty.\n· Void Mage (influence 2, Academy, instant ability): Choose any played card and remove either all influence modifiers or all ongoing tokens from it.\n· Surgeon (influence 3, Guild, instant ability): The next card you play gets -5 influence.\n· Mediator (influence 4, Dynasty, ongoing ability): This encounter is a tie.\n· Saboteur (influence 5, Rebellion, instant ability): Your opponent discards the top 2 cards of their deck.\n· Fortune Teller (influence 6, Academy, instant ability): In the next encounter, your opponent reveals their card before you play yours.\n· Palace Guard (influence 7, Guild, instant ability): Choose a faction. Your opponent may discard 1 card of that faction from their hand; if they do not, this card gets +7 influence.\n· Judge (influence 8, Dynasty, ongoing ability): You win all tied encounters, including future ones. When a tie becomes your win, the opposing card ability is not triggered.\n· Ambusher (influence 9, Rebellion, instant ability): Choose a faction. Your opponent discards all cards of that faction from their hand.\n· Puppeteer (influence 10, Academy, instant ability): Discard the opposing card, then replace it with a random card from your opponent hand. The drawn card does not trigger its ability.\n· Clockmaker (influence 11, Guild, instant ability): Your card in the previous encounter and the next card you play each get +3 influence.\n· Treasurer (influence 12, Dynasty, ongoing ability): The card that wins the previous encounter is worth 1 additional signet.\n· Swamp Guardian (influence 13, Rebellion, instant ability): Take one of your other played cards back into your hand and discard the card opposing it.\n· Magistra (influence 14, Academy, instant ability): Copy and activate the instant ability of one of your other played cards whose influence is at least as high as this card influence.\n· Inventor (influence 15, Guild, instant ability): Give any one card +3 influence and any other card -3 influence.\n· Djinn (influence 16, Dynasty, instant ability): You immediately win the game.\n\nDeck II card abilities:\n· Poisoner (influence 1, Rebellion, instant ability): Reduce the influence of the opposing card until this encounter is a tie.\n· Kinesis Mage (influence 2, Academy, instant ability): Move all influence modifiers and ongoing tokens from one of your cards to another of your played cards.\n· Envoy (influence 3, Guild, instant ability): Give any one card -3 influence, or give the next card you play -3 influence.\n· Tax Collector (influence 4, Dynasty, instant ability): This card gets +4 influence.\n· Revolutionary (influence 5, Rebellion, instant ability): Your opponent discards 2 cards from their hand, then draws 2 cards.\n· Librarian (influence 6, Academy, instant ability): After the next card you play is revealed, choose whether it gets +2 or -2 influence.\n· Prodigy (influence 7, Guild, instant ability): One of your played cards with 8 or less influence gets +3 influence.\n· Aristocrat (influence 8, Dynasty, ongoing ability): If this card wins its encounter, it is worth 1 additional signet.\n· Blackmailer (influence 9, Rebellion, instant ability): Choose a faction. If your opponent next played card is not of that faction, they discard 2 cards from their hand after revealing it.\n· Illusionist (influence 10, Academy, instant ability): Activate the ability of one of your cards that is losing its encounter.\n· Engineer (influence 11, Guild, instant ability): After abilities are resolved, the next card you play gets +5 influence.\n· Counselor (influence 12, Dynasty, ongoing ability): In the previous encounter, your card wins and the opposing card loses.\n· Witch King (influence 13, Rebellion, instant ability): Choose a faction. Your opponent discards all cards of that faction from their hand and deck, then shuffles their deck.\n· Elemental (influence 14, Academy, instant ability): Discard a card with an instant ability from your hand, copy and activate that ability, then draw 1 card.\n· Mechanical Djinn (influence 15, Guild, ongoing ability): If you win the following encounter, you immediately win the game.\n· Successor (influence 16, Dynasty, instant ability): Your opponent discards their entire deck and all but 2 cards from their hand.\n\nLocations:\n· Serpent Temple (difficulty 1): Whenever you win a past encounter, draw 1 card and your opponent discards 1 card from their hand.\n· Bazaar (difficulty 1): At the end of each round, do not draw cards. Whenever you have 1 card or fewer in hand, immediately draw 4 cards.\n· Founder's Day (difficulty 3): If you ever win 3 successive encounters, you immediately win the game.\n· Grand Library (difficulty 2): At the beginning of the game, draw 2 cards instead of 5. At the end of each round, draw 2 cards instead of 1.\n· Scrapyard (difficulty 2): At the end of each round, if your deck has at least 2 cards, draw 2 cards instead of 1, then place 1 card from your hand under your deck.\n· Auction House (difficulty 2): Whenever you reveal a card with less influence than your card in the previous encounter, discard the top card of your deck.\n· Haunted Catacombs (difficulty 3): If you reveal a card of the same faction as your card in the previous encounter, you immediately lose the game.\n· Foggy Swamp (difficulty 2): After you place cards, do not reveal the current encounter. Instead, reveal and resolve the previous encounter."
		}
	}
};
//#endregion
export { Ot as default };
