import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useI18nSettings as n, useT as r } from "@bgparty/sdk/i18n";
import { useWakeLock as i } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as o, seatName as s } from "@bgparty/sdk/ui/player-strip";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { useEffect as d, useMemo as f, useRef as p, useState as m } from "react";
import { useFrame as h, useThree as g } from "@react-three/fiber";
import { CanvasTexture as _, ExtrudeGeometry as v, Path as y, RepeatWrapping as b, SRGBColorSpace as x, Shape as S, Vector3 as C } from "three";
import { ResilientCanvas as w } from "@bgparty/sdk/three/resilient-canvas";
import { usePrefersReducedMotion as T } from "@bgparty/sdk/fx/use-reduced-motion";
import { ConfirmButton as E } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as D, OptionRadio as O, OptionSection as k } from "@bgparty/sdk/ui/game-options";
//#region src/game/meta.ts
var A = {
	id: "quarto",
	uuid: "e9986755-81d3-4a40-b922-b512a94ded5e",
	tier: "alpha",
	mechanics: ["tile-placement"],
	interactionTags: [],
	nameKey: "games.quarto.name",
	descKey: "games.quarto.desc",
	rulesKey: "games.quarto.rules",
	icon: "◉",
	iconImg: "games/quarto.webp",
	rulesUrl: { fr: "https://www.gigamic.com/index.php?controller=attachment&id_attachment=72" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#875b36",
	releasedAt: "2026-11-14T04:38:00+08:00",
	search: {
		py: "tong zhu zhen",
		init: "tzz"
	},
	hotseat: "open"
}, j = (e) => +(e === 0), M = (e) => [
	1,
	2,
	4,
	8
].filter((t) => (e & t) !== 0).length, N = [
	...Array.from({ length: 4 }, (e, t) => Array.from({ length: 4 }, (e, n) => t * 4 + n)),
	...Array.from({ length: 4 }, (e, t) => Array.from({ length: 4 }, (e, n) => n * 4 + t)),
	[
		0,
		5,
		10,
		15
	],
	[
		3,
		6,
		9,
		12
	]
], P = Array.from({ length: 9 }, (e, t) => {
	let n = Math.floor(t / 3) * 4 + t % 3;
	return [
		n,
		n + 1,
		n + 4,
		n + 5
	];
});
function F(e, t) {
	let n = e.mode === "advanced" ? [...N, ...P] : N;
	for (let r of n) {
		if (!r.includes(t)) continue;
		let n = r.map((t) => e.board[t]);
		if (n.some((e) => e === null)) continue;
		let i = n;
		if (((i.reduce((e, t) => e & t, 15) | i.reduce((e, t) => e & ~t, 15)) & e.features) !== 0) return r;
	}
	return [];
}
function I(e) {
	return e.flatMap((e, t) => e === null ? [t] : []);
}
//#endregion
//#region src/game/schema.ts
var L = t.int().min(0).max(15), R = t.int().min(0).max(15), z = t.union([t.literal(0), t.literal(1)]), B = t.object({
	mode: t.enum([
		"classic",
		"advanced",
		"beginner"
	]).default("classic"),
	features: t.int().min(1).max(14).default(1)
}).default({
	mode: "classic",
	features: 1
}), V = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: t.discriminatedUnion("type", [
			t.object({
				type: t.literal("choose"),
				piece: L,
				revision: t.int().nonnegative()
			}),
			t.object({
				type: t.literal("place"),
				cell: R,
				revision: t.int().nonnegative()
			}),
			t.object({
				type: t.literal("claim"),
				revision: t.int().nonnegative()
			}),
			t.object({
				type: t.literal("pass"),
				revision: t.int().nonnegative()
			}),
			t.object({
				type: t.literal("tick"),
				now: t.number().finite()
			})
		]),
		config: B,
		publicView: t.object({
			board: t.array(L.nullable()).length(16),
			remaining: t.array(L),
			selected: L.nullable(),
			players: t.tuple([t.string(), t.string()]),
			turn: z,
			phase: t.enum([
				"choose",
				"place",
				"moving",
				"done"
			]),
			nextPhase: t.enum([
				"choose",
				"place",
				"done"
			]).nullable(),
			mode: t.enum([
				"classic",
				"advanced",
				"beginner"
			]),
			features: t.int().min(1).max(15),
			revision: t.int().nonnegative(),
			canClaim: t.boolean(),
			lastCell: R.nullable(),
			winner: z.nullable(),
			winningCells: t.array(R),
			lastPiece: L.nullable()
		}),
		privateView: t.object({})
	},
	setup(t, n, r) {
		let i = B.parse(t), a = e(r, 0, 2) === 0 ? n : [...n].reverse(), o = i.mode === "beginner" && M(i.features) <= 3 ? i.features : 15;
		return { state: {
			board: Array(16).fill(null),
			remaining: Array.from({ length: 16 }, (e, t) => t),
			selected: null,
			players: [a[0], a[1]],
			turn: 0,
			phase: "choose",
			nextPhase: null,
			mode: i.mode,
			features: o,
			revision: 0,
			canClaim: !1,
			lastCell: null,
			winner: null,
			winningCells: [],
			lastPiece: null
		} };
	},
	reduce(e, t, n) {
		if (t.type === "tick") return n.by === "$engine" ? e.phase !== "moving" || !e.nextPhase ? { state: e } : { state: {
			...e,
			phase: e.nextPhase,
			nextPhase: null,
			revision: e.revision + 1
		} } : { code: "games.quarto.errTurn" };
		if (e.phase === "done" || e.phase === "moving" || e.players[e.turn] !== n.by) return { code: "games.quarto.errTurn" };
		if (t.revision !== e.revision) return { code: "games.quarto.errStale" };
		if (t.type === "claim") {
			if (!e.canClaim || e.lastCell === null) return { code: "games.quarto.errClaim" };
			let t = F(e, e.lastCell);
			return t.length ? { state: {
				...e,
				phase: "done",
				winner: e.turn,
				winningCells: t,
				revision: e.revision + 1
			} } : { code: "games.quarto.errClaim" };
		}
		if (t.type === "pass") return e.phase !== "choose" || e.remaining.length !== 0 ? { code: "games.quarto.errTarget" } : { state: {
			...e,
			phase: "done",
			canClaim: !1,
			revision: e.revision + 1
		} };
		if (t.type === "choose") return e.phase !== "choose" || !e.remaining.includes(t.piece) ? { code: "games.quarto.errTarget" } : { state: {
			...e,
			phase: "moving",
			nextPhase: "place",
			selected: t.piece,
			remaining: e.remaining.filter((e) => e !== t.piece),
			turn: j(e.turn),
			revision: e.revision + 1,
			lastPiece: t.piece
		} };
		if (e.phase !== "place" || e.selected === null || e.board[t.cell] !== null) return { code: "games.quarto.errTarget" };
		let r = [...e.board];
		r[t.cell] = e.selected;
		let i = F({
			...e,
			board: r
		}, t.cell), a = e.remaining.length === 0 && i.length === 0;
		return { state: {
			...e,
			board: r,
			selected: null,
			lastCell: t.cell,
			lastPiece: e.selected,
			canClaim: i.length > 0,
			phase: "moving",
			nextPhase: a ? "done" : "choose",
			revision: e.revision + 1
		} };
	},
	viewFor(e) {
		return {
			public: structuredClone(e),
			private: {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.winner === null ? [...e.players] : [e.players[e.winner]],
			ranking: e.winner === 1 ? [...e.players].reverse() : [...e.players]
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.phase === "moving" ? 350 : null;
	}
};
//#endregion
//#region src/game/access.tsx
function H() {
	let e = r();
	return (t) => e("games.quarto.featureLabel", {
		color: e(t & 1 ? "games.quarto.dark" : "games.quarto.light"),
		shape: e(t & 2 ? "games.quarto.square" : "games.quarto.round"),
		height: e(t & 4 ? "games.quarto.tall" : "games.quarto.short"),
		hollow: e(t & 8 ? "games.quarto.hollowPiece" : "games.quarto.solid")
	});
}
function U({ pub: e, active: t, onPiece: n, onCell: i }) {
	let a = r(), o = H();
	return /* @__PURE__ */ u("div", {
		className: "quarto-access-content",
		children: [/* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h3", { children: a("games.quarto.board") }), /* @__PURE__ */ l("div", {
			className: "quarto-access-grid",
			children: e.board.map((n, r) => /* @__PURE__ */ l("button", {
				type: "button",
				disabled: !t || e.phase !== "place" || n !== null,
				"aria-label": a("games.quarto.cellAria", {
					row: Math.floor(r / 4) + 1,
					col: r % 4 + 1,
					piece: n === null ? a("games.quarto.empty") : o(n)
				}),
				onClick: () => i(r),
				children: n === null ? "·" : /* @__PURE__ */ l("span", {
					className: "quarto-access-piece",
					"data-dark": !!(n & 1),
					"data-square": !!(n & 2),
					"data-tall": !!(n & 4),
					"data-hollow": !!(n & 8)
				})
			}, r))
		})] }), /* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h3", { children: a("games.quarto.reserve") }), /* @__PURE__ */ l("div", {
			className: "quarto-access-grid",
			children: e.remaining.map((r) => /* @__PURE__ */ l("button", {
				type: "button",
				disabled: !t || e.phase !== "choose",
				"aria-label": a("games.quarto.chooseAria", { piece: o(r) }),
				onClick: () => n(r),
				children: /* @__PURE__ */ l("span", {
					className: "quarto-access-piece",
					"data-dark": !!(r & 1),
					"data-square": !!(r & 2),
					"data-tall": !!(r & 4),
					"data-hollow": !!(r & 8)
				})
			}, r))
		})] })]
	});
}
//#endregion
//#region src/game/board3d.tsx
var W = 1.32, G = [
	0,
	4,
	1,
	5,
	2,
	6,
	3,
	7,
	8,
	12,
	9,
	13,
	10,
	14,
	11,
	15
], K = (e) => e & 4 ? 1.45 : .45;
function q(e, t, n, r, i) {
	let a = document.createElement("canvas");
	a.width = 512, a.height = 512;
	let o = a.getContext("2d"), s = e, c = () => (s = s * 1664525 + 1013904223 >>> 0, s / 4294967296);
	o.fillStyle = t, o.fillRect(0, 0, 512, 512);
	for (let e = 0; e < 280; e++) {
		let t = c() * 512, i = 4 + c() * 24;
		o.beginPath(), o.moveTo(t, -10), o.bezierCurveTo(t + i, 130, t - i, 340, t + (c() - .5) * 20, 522), o.strokeStyle = e % 4 ? n : r, o.globalAlpha = .018 + c() * .055, o.lineWidth = .35 + c() * 1.3, o.stroke();
	}
	let l = new _(a);
	return l.colorSpace = x, l.wrapS = l.wrapT = b, l.anisotropy = i, l;
}
function J(e, t, n) {
	let r = -e / 2, i = -t / 2, a = .16, o = new S();
	return o.moveTo(r + a, i), o.lineTo(r + e - a, i), o.quadraticCurveTo(r + e, i, r + e, i + a), o.lineTo(r + e, i + t - a), o.quadraticCurveTo(r + e, i + t, r + e - a, i + t), o.lineTo(r + a, i + t), o.quadraticCurveTo(r, i + t, r, i + t - a), o.lineTo(r, i + a), o.quadraticCurveTo(r, i, r + a, i), new v(o, {
		depth: n,
		bevelEnabled: !0,
		bevelSize: .05,
		bevelThickness: .05,
		bevelSegments: 3,
		curveSegments: 5
	});
}
function Y(e) {
	let t = !!(e & 2), n = !!(e & 8), r = new S();
	if (t ? (r.moveTo(-.34, -.34), r.lineTo(.34, -.34), r.lineTo(.34, .34), r.lineTo(-.34, .34), r.closePath()) : r.absarc(0, 0, .355, 0, Math.PI * 2, !1), n) {
		let e = new y();
		t ? (e.moveTo(-.185, -.185), e.lineTo(-.185, .185), e.lineTo(.185, .185), e.lineTo(.185, -.185), e.closePath()) : e.absarc(0, 0, .19, 0, Math.PI * 2, !0), r.holes.push(e);
	}
	return new v(r, {
		depth: K(e),
		bevelEnabled: !0,
		bevelSize: .025,
		bevelThickness: .025,
		bevelSegments: 3,
		curveSegments: 32
	});
}
function ee({ piece: e, target: t, canChoose: n, onClick: r, wood: i }) {
	let a = p(null), [o] = m(() => t), s = f(() => Y(e), [e]), c = p(null), _ = T(), v = g((e) => e.invalidate), [y, b, x] = t, S = f(() => new C(y, b, x), [
		y,
		b,
		x
	]);
	d(() => {
		let e = a.current;
		e && (_ ? (e.position.copy(S), c.current = null) : e.position.distanceTo(S) > .002 && (c.current = {
			from: e.position.clone(),
			to: S,
			started: performance.now()
		}), v());
	}, [
		S,
		v,
		_
	]), d(() => () => s.dispose(), [s]), h(() => {
		let e = a.current, t = c.current;
		if (!e || !t) return;
		let n = Math.min(1, (performance.now() - t.started) / 300), r = (e) => e * e * (3 - 2 * e);
		n < .25 ? (e.position.copy(t.from), e.position.y += (2.12 - t.from.y) * r(n / .25)) : n < .75 ? (e.position.lerpVectors(t.from, t.to, r((n - .25) / .5)), e.position.y = 2.12) : (e.position.copy(t.to), e.position.y = 2.12 + (t.to.y - 2.12) * r((n - .75) / .25)), n === 1 ? c.current = null : v();
	});
	let w = !!(e & 4), E = !!(e & 8), D = !!(e & 2), O = !!(e & 1);
	return /* @__PURE__ */ u("group", {
		ref: a,
		position: o,
		onClick: (e) => {
			n && (e.stopPropagation(), r());
		},
		children: [n && /* @__PURE__ */ u("mesh", {
			position: [
				0,
				.012,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ l("ringGeometry", { args: [
				.37,
				.39,
				32
			] }), /* @__PURE__ */ l("meshBasicMaterial", {
				color: "#e4c786",
				transparent: !0,
				opacity: .58
			})]
		}), /* @__PURE__ */ u("group", {
			scale: [
				w ? .8 : 1,
				1,
				w ? .8 : 1
			],
			children: [/* @__PURE__ */ l("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				geometry: s,
				castShadow: !0,
				receiveShadow: !0,
				children: /* @__PURE__ */ l("meshStandardMaterial", {
					map: O ? i.dark : i.light,
					color: O ? "#d2a47f" : "#f3e3c0",
					roughness: O ? .62 : .58
				})
			}), E && /* @__PURE__ */ u("mesh", {
				position: [
					0,
					K(e) - .25,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [D ? /* @__PURE__ */ l("planeGeometry", { args: [.365, .365] }) : /* @__PURE__ */ l("circleGeometry", { args: [.188, 40] }), /* @__PURE__ */ l("meshStandardMaterial", {
					color: O ? "#25180e" : "#765333",
					roughness: 1
				})]
			})]
		})]
	});
}
function te({ portrait: e }) {
	let t = g((e) => e.size), n = g((e) => e.camera), r = g((e) => e.invalidate);
	return d(() => {
		n.position.set(e ? 5 : 7, 29, 13), n.lookAt(0, .2, 0), Object.assign(n, { zoom: Math.min(t.width / (e ? 9.7 : 17.8), t.height / (e ? 17.8 : 12.7)) }), n.updateProjectionMatrix(), r();
	}, [
		n,
		t.width,
		t.height,
		e,
		r
	]), null;
}
function ne() {
	let e = p(null), t = T(), n = g((e) => e.invalidate);
	return h((r, i) => {
		!t && e.current && (e.current.rotation.y += i * .65, n());
	}), /* @__PURE__ */ l("group", {
		ref: e,
		position: [
			0,
			.009,
			0
		],
		children: Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ u("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				t * Math.PI / 6
			],
			children: [/* @__PURE__ */ l("ringGeometry", { args: [
				.38,
				.42,
				4,
				1,
				0,
				Math.PI / 9
			] }), /* @__PURE__ */ l("meshBasicMaterial", { color: "#fff0bd" })]
		}, t))
	});
}
function re({ markers: e, onTargets: t }) {
	let n = g((e) => e.camera), r = g((e) => e.size), i = g((e) => e.invalidate), a = JSON.stringify({
		markers: e,
		w: r.width,
		h: r.height
	}), o = p("");
	return d(() => {
		i();
	}, [a, i]), h(() => {
		o.current !== a && (o.current = a, n.updateMatrixWorld(), t(e.map(({ kind: e, index: t, position: i }) => {
			let a = new C(...i).project(n);
			return {
				kind: e,
				index: t,
				x: (a.x + 1) * r.width / 2,
				y: (1 - a.y) * r.height / 2,
				width: n.zoom * .7,
				height: n.zoom * (e === "piece" ? .6 : .65)
			};
		})));
	}), null;
}
function ie({ pub: e, active: t, onPiece: n, onCell: r, onTargets: i }) {
	let a = g((e) => e.size), o = g((e) => e.gl), s = f(() => {
		let e = Math.min(4, o.capabilities.getMaxAnisotropy());
		return {
			board: q(17, "#c3996b", "#5b321e", "#f5d8a2", e),
			light: q(34, "#ead5aa", "#9c7042", "#fff1d0", e),
			dark: q(56, "#70432b", "#28130d", "#c28d64", e)
		};
	}, [o]), p = f(() => J(6.2, 6.2, .48), []), m = f(() => J(6.08, 6.08, .18), []);
	d(() => () => {
		Object.values(s).forEach((e) => e.dispose()), p.dispose(), m.dispose();
	}, [
		s,
		p,
		m
	]);
	let h = a.width / Math.max(1, a.height) < 1.05, [_, v] = h ? [-18.25 / 13, -3.65] : [-3.48, 0], [y, b] = h ? [21 / 13, 4.2] : [3.48, 0], x = (e) => [
		_ + (e % 4 - 1.5) * W,
		.49,
		v + (Math.floor(e / 4) - 1.5) * W
	], S = (e) => {
		let t = G.indexOf(e), n = (t % 4 - 1.5) * 1.35, r = (Math.floor(t / 4) - 1.5) * 1.8, i = h ? 5 : 7, a = Math.hypot(i, 13), o = 13 / a, s = i / a;
		return [
			y + n * o + r * s,
			-.32,
			b - n * s + r * o
		];
	}, C = h ? [
		3.05,
		-.32,
		v
	] : [
		_,
		-.32,
		-4.05
	], w = t ? e.phase === "choose" ? e.remaining.map((e) => {
		let [t, n, r] = S(e);
		return {
			kind: "piece",
			index: e,
			position: [
				t,
				n + K(e),
				r
			]
		};
	}) : e.phase === "place" ? e.board.flatMap((e, t) => e === null ? [{
		kind: "cell",
		index: t,
		position: x(t)
	}] : []) : [] : [];
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(te, { portrait: h }),
		/* @__PURE__ */ l(re, {
			markers: w,
			onTargets: i
		}),
		/* @__PURE__ */ l("color", {
			attach: "background",
			args: ["#343d32"]
		}),
		/* @__PURE__ */ l("hemisphereLight", { args: [
			"#f5e6cc",
			"#667063",
			1.65
		] }),
		/* @__PURE__ */ l("directionalLight", {
			position: [
				-8,
				22,
				10
			],
			color: "#fff3dc",
			intensity: 2.3,
			castShadow: !0,
			"shadow-mapSize-width": 2048,
			"shadow-mapSize-height": 2048,
			"shadow-camera-left": -16,
			"shadow-camera-right": 16,
			"shadow-camera-top": 16,
			"shadow-camera-bottom": -16,
			"shadow-camera-near": 1,
			"shadow-camera-far": 40,
			"shadow-bias": -3e-4,
			"shadow-normalBias": .018,
			"shadow-radius": 3,
			"shadow-blurSamples": 8
		}),
		/* @__PURE__ */ l("directionalLight", {
			position: [
				8,
				8,
				-9
			],
			color: "#b8c5ae",
			intensity: .65
		}),
		/* @__PURE__ */ u("mesh", {
			position: [
				0,
				-.37,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			receiveShadow: !0,
			children: [/* @__PURE__ */ l("planeGeometry", { args: [60, 60] }), /* @__PURE__ */ l("meshStandardMaterial", {
				color: "#343d32",
				roughness: 1
			})]
		}),
		/* @__PURE__ */ l("mesh", {
			geometry: p,
			position: [
				_,
				-.2,
				v
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: /* @__PURE__ */ l("meshStandardMaterial", {
				color: "#815633",
				roughness: .72
			})
		}),
		/* @__PURE__ */ l("mesh", {
			geometry: m,
			position: [
				_,
				.24,
				v
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: /* @__PURE__ */ l("meshStandardMaterial", {
				map: s.board,
				roughness: .67
			})
		}),
		e.board.map((n, i) => {
			let [a, , o] = x(i), s = t && e.phase === "place" && n === null;
			return /* @__PURE__ */ u("group", {
				position: [
					a,
					.477,
					o
				],
				children: [
					/* @__PURE__ */ u("mesh", {
						rotation: [
							-Math.PI / 2,
							0,
							0
						],
						receiveShadow: !0,
						children: [/* @__PURE__ */ l("circleGeometry", { args: [.445, 48] }), /* @__PURE__ */ l("meshStandardMaterial", {
							color: "#8a5a34",
							roughness: .76
						})]
					}),
					/* @__PURE__ */ u("mesh", {
						position: [
							0,
							.004,
							0
						],
						rotation: [
							-Math.PI / 2,
							0,
							0
						],
						receiveShadow: !0,
						onClick: (e) => {
							s && (e.stopPropagation(), r(i));
						},
						children: [/* @__PURE__ */ l("circleGeometry", { args: [.378, 48] }), /* @__PURE__ */ l("meshStandardMaterial", {
							color: e.winningCells.includes(i) ? "#dec981" : "#ab8055",
							roughness: .92
						})]
					}),
					/* @__PURE__ */ u("mesh", {
						position: [
							0,
							.008,
							0
						],
						rotation: [
							-Math.PI / 2,
							0,
							0
						],
						receiveShadow: !0,
						children: [/* @__PURE__ */ l("ringGeometry", { args: [
							.405,
							.435,
							48
						] }), /* @__PURE__ */ l("meshStandardMaterial", {
							color: "#d1ac75",
							roughness: .54,
							metalness: .13
						})]
					}),
					s && /* @__PURE__ */ l(ne, {}),
					e.winningCells.includes(i) && /* @__PURE__ */ u("mesh", {
						position: [
							0,
							.013,
							0
						],
						rotation: [
							-Math.PI / 2,
							0,
							0
						],
						children: [/* @__PURE__ */ l("ringGeometry", { args: [
							.4,
							.46,
							32
						] }), /* @__PURE__ */ l("meshBasicMaterial", { color: "#714920" })]
					})
				]
			}, i);
		}),
		Array.from({ length: 16 }, (r, i) => {
			let a = e.board.indexOf(i), o = a >= 0 ? x(a) : e.selected === i ? C : S(i);
			return /* @__PURE__ */ l(ee, {
				piece: i,
				target: o,
				wood: s,
				canChoose: t && e.phase === "choose" && e.remaining.includes(i),
				onClick: () => n(i)
			}, i);
		})
	] });
}
function X({ fallback: e, ...t }) {
	let [n, i] = m([]), [a, o] = m(!1), s = r(), c = H();
	return /* @__PURE__ */ u("div", {
		className: "quarto-canvas",
		children: [/* @__PURE__ */ l(w, {
			orthographic: !0,
			shadows: "variance",
			camera: {
				position: [
					7,
					29,
					13
				],
				near: .1,
				far: 100,
				zoom: 50
			},
			dpr: [1, 2],
			frameloop: "demand",
			gl: {
				antialias: !0,
				powerPreference: "low-power"
			},
			onCreated: ({ gl: e }) => {
				e.toneMappingExposure = 1.2;
			},
			recoveryFallback: e,
			onRecoveryChange: o,
			children: /* @__PURE__ */ l(ie, {
				...t,
				onTargets: i
			})
		}), !a && n.map((e) => /* @__PURE__ */ l("button", {
			type: "button",
			className: "quarto-hit",
			style: {
				left: e.x,
				top: e.y,
				width: e.width,
				height: e.height
			},
			"aria-label": e.kind === "piece" ? s("games.quarto.chooseAria", { piece: c(e.index) }) : s("games.quarto.placeAria", {
				row: Math.floor(e.index / 4) + 1,
				col: e.index % 4 + 1
			}),
			onClick: () => e.kind === "piece" ? t.onPiece(e.index) : t.onCell(e.index)
		}, `${e.kind}:${e.index}`))]
	});
}
//#endregion
//#region src/game/view-player.tsx
function ae({ public: e, members: t, myRid: c, send: d }) {
	let f = e, p = r(), m = n((e) => e.locale), h = H();
	i();
	let g = f.players[f.turn] === c, _ = t.find((e) => e.rid === f.players[f.turn]), v = _ ? s(_, m) : p("games.quarto.name"), y = (e) => {
		g && f.phase === "choose" && d({
			type: "choose",
			piece: e,
			revision: f.revision
		});
	}, b = (e) => {
		g && f.phase === "place" && d({
			type: "place",
			cell: e,
			revision: f.revision
		});
	}, x = [
		[1, p("games.quarto.color")],
		[2, p("games.quarto.shape")],
		[4, p("games.quarto.height")],
		[8, p("games.quarto.hollow")]
	], S = f.mode === "beginner" ? `${p("games.quarto.beginner")} · ${x.filter(([e]) => (f.features & e) !== 0).map(([, e]) => e).join(m === "zh" ? "、" : ", ")}` : f.mode === "advanced" ? p("games.quarto.advanced") : null, C = f.phase === "moving" ? p("games.quarto.moving") : g ? f.phase === "choose" ? p("games.quarto.choose") : p("games.quarto.place") : p("games.quarto.waiting", { name: v }), w = /* @__PURE__ */ l(U, {
		pub: f,
		active: g,
		onPiece: y,
		onCell: b
	});
	return /* @__PURE__ */ l(a, {
		adaptive: !0,
		scroll: !1,
		className: "quarto-screen",
		banner: /* @__PURE__ */ u("header", {
			className: "quarto-header",
			children: [
				/* @__PURE__ */ u("div", {
					className: "quarto-title",
					children: [/* @__PURE__ */ l("span", { children: "QUARTO" }), m === "zh" && /* @__PURE__ */ l("small", { children: p("games.quarto.name") })]
				}),
				/* @__PURE__ */ u("div", {
					className: "quarto-status",
					children: [
						/* @__PURE__ */ l("span", { children: p("games.quarto.acting", { name: v }) }),
						/* @__PURE__ */ l("strong", {
							"aria-live": "polite",
							children: C
						}),
						S && /* @__PURE__ */ l("em", { children: S })
					]
				}),
				/* @__PURE__ */ l("div", {
					className: "quarto-players",
					children: f.players.map((e) => {
						let n = t.find((t) => t.rid === e);
						return n ? /* @__PURE__ */ u("div", {
							className: "quarto-player",
							"data-current": e === f.players[f.turn],
							children: [/* @__PURE__ */ l(o, {
								m: n,
								myRid: c,
								action: e === f.players[f.turn] ? "pending" : null,
								anchorName: null,
								box: "size-9",
								img: "size-7"
							}), /* @__PURE__ */ l("span", { children: s(n, m) })]
						}, e) : null;
					})
				})
			]
		}),
		children: /* @__PURE__ */ u("div", {
			className: "quarto-stage",
			children: [
				/* @__PURE__ */ l(X, {
					pub: f,
					active: g,
					onPiece: y,
					onCell: b,
					fallback: /* @__PURE__ */ u("div", {
						className: "quarto-fallback",
						children: [/* @__PURE__ */ l("p", { children: p("games.quarto.webglFallback") }), w]
					})
				}),
				f.selected !== null && /* @__PURE__ */ u("div", {
					className: "quarto-legend",
					"aria-live": "polite",
					children: [/* @__PURE__ */ l("span", { children: p("games.quarto.selected") }), /* @__PURE__ */ l("strong", { children: h(f.selected) })]
				}),
				/* @__PURE__ */ u("div", {
					className: "quarto-actions",
					children: [
						g && f.lastCell !== null && f.phase !== "moving" && f.phase !== "done" && /* @__PURE__ */ l("button", {
							type: "button",
							className: "quarto-claim",
							onClick: () => d({
								type: "claim",
								revision: f.revision
							}),
							children: p("games.quarto.claim")
						}),
						g && f.phase === "choose" && f.remaining.length === 0 && /* @__PURE__ */ l("button", {
							type: "button",
							className: "quarto-pass",
							onClick: () => d({
								type: "pass",
								revision: f.revision
							}),
							children: p("games.quarto.pass")
						}),
						/* @__PURE__ */ u("details", {
							className: "quarto-access",
							children: [/* @__PURE__ */ l("summary", { children: p("games.quarto.access") }), w]
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/game/bot.ts
var oe = {
	safePieces: 1,
	replySearch: 1
};
function Z(e, t) {
	return I(e.board).map((n) => {
		let r = [...e.board];
		return r[n] = t, {
			cell: n,
			board: r,
			wins: F({
				...e,
				board: r
			}, n).length > 0
		};
	});
}
function Q(e, t) {
	return Z(e, t).some((e) => e.wins);
}
function $(e, t, n, r, i) {
	let a = [...e.board];
	a[r] = t;
	let o = {
		...e,
		board: a
	};
	if (F(o, r).length) return 1e5;
	if (!n.length) return 0;
	let s = n.filter((e) => !Q(o, e));
	if (!s.length) return -5e4;
	let c = s.length * i.safePieces;
	if (i.replySearch && n.length <= 6) {
		let e = -Infinity;
		for (let t of s) {
			let r = n.filter((e) => e !== t), i = -Infinity;
			for (let e of Z(o, t)) {
				if (e.wins) {
					i = 1e5;
					break;
				}
				let t = {
					...o,
					board: e.board
				}, n = r.filter((e) => !Q(t, e)).length;
				i = Math.max(i, r.length && n === 0 ? -5e4 : n);
			}
			e = Math.max(e, -i);
		}
		c += e;
	}
	return c;
}
function se(e) {
	let t = Math.floor(2 ** 32 / e) * e, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return n[0] % e;
}
function ce(e = oe, t = se) {
	let n = (e) => e[t(e.length)];
	return ({ public: t }, r) => {
		if (t.players[t.turn] !== r.rid || t.phase === "moving" || t.phase === "done") return null;
		if (t.canClaim) return { action: {
			type: "claim",
			revision: t.revision
		} };
		if (t.phase === "choose") {
			if (!t.remaining.length) return { action: {
				type: "pass",
				revision: t.revision
			} };
			if (r.difficulty === "weak") return { action: {
				type: "choose",
				piece: n(t.remaining),
				revision: t.revision
			} };
			let i = t.remaining.map((n) => {
				let r = t.remaining.filter((e) => e !== n);
				return {
					piece: n,
					score: -Math.max(...Z(t, n).map(({ cell: i }) => $(t, n, r, i, e)))
				};
			}).sort((e, t) => t.score - e.score);
			return { action: {
				type: "choose",
				piece: n(i.filter((e) => e.score === i[0].score)).piece,
				revision: t.revision
			} };
		}
		if (t.selected === null) return null;
		let i = Z(t, t.selected);
		if (!i.length) return null;
		if (r.difficulty === "weak") return { action: {
			type: "place",
			cell: n(i).cell,
			revision: t.revision
		} };
		let a = i.map((n) => ({
			...n,
			score: $(t, t.selected, t.remaining, n.cell, e)
		})).sort((e, t) => t.score - e.score);
		return { action: {
			type: "place",
			cell: n(a.filter((e) => e.score === a[0].score)).cell,
			revision: t.revision
		} };
	};
}
var le = ce(), ue = (e, t, n) => e.type === "choose" ? n("games.quarto.hintChoose", { piece: n("games.quarto.featureLabel", {
	color: n(e.piece & 1 ? "games.quarto.dark" : "games.quarto.light"),
	shape: n(e.piece & 2 ? "games.quarto.square" : "games.quarto.round"),
	height: n(e.piece & 4 ? "games.quarto.tall" : "games.quarto.short"),
	hollow: n(e.piece & 8 ? "games.quarto.hollowPiece" : "games.quarto.solid")
}) }) : e.type === "place" ? n("games.quarto.hintPlace", {
	row: Math.floor(e.cell / 4) + 1,
	col: e.cell % 4 + 1
}) : e.type === "claim" ? n("games.quarto.hintClaim") : e.type === "pass" ? n("games.quarto.hintPass") : "";
//#endregion
//#region src/game/game-over.tsx
function de({ public: e, result: t, members: i, onPlayAgain: a, onBackToLobby: o }) {
	let c = e, f = r(), h = n((e) => e.locale), [g, _] = m(!0), v = p(null), y = p(null), b = p(null);
	d(() => {
		(g ? v : y).current?.focus();
	}, [g]);
	let x = i.find((e) => e.rid === t.winner[0]), S = t.winner.length === 1 ? f("games.quarto.won", { name: x ? s(x, h) : f("games.quarto.name") }) : f("games.quarto.draw"), C = () => {};
	return /* @__PURE__ */ u("div", {
		className: "quarto-over",
		children: [/* @__PURE__ */ l(X, {
			pub: c,
			active: !1,
			onPiece: C,
			onCell: C,
			fallback: /* @__PURE__ */ l(U, {
				pub: c,
				active: !1,
				onPiece: C,
				onCell: C
			})
		}), g ? /* @__PURE__ */ l("div", {
			className: "quarto-over-shade",
			children: /* @__PURE__ */ u("section", {
				className: "quarto-over-card",
				ref: b,
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "quarto-result-title",
				onKeyDown: (e) => {
					if (e.key === "Escape" && (e.stopPropagation(), _(!1)), e.key !== "Tab") return;
					let t = Array.from(b.current?.querySelectorAll("button:not(:disabled)") ?? []);
					e.shiftKey && document.activeElement === t[0] ? (e.preventDefault(), t.at(-1)?.focus()) : !e.shiftKey && document.activeElement === t.at(-1) && (e.preventDefault(), t[0]?.focus());
				},
				children: [
					/* @__PURE__ */ u("small", { children: ["QUARTO · ", f("games.quarto.final")] }),
					/* @__PURE__ */ l("h1", {
						id: "quarto-result-title",
						children: S
					}),
					/* @__PURE__ */ u("div", {
						className: "quarto-over-buttons",
						children: [
							/* @__PURE__ */ l("button", {
								type: "button",
								ref: v,
								onClick: () => _(!1),
								children: f("games.quarto.review")
							}),
							a && /* @__PURE__ */ l(E, {
								label: f("session.result.playAgain"),
								confirmLabel: f("games.quarto.confirmAgain"),
								onConfirm: a
							}),
							o && /* @__PURE__ */ l(E, {
								label: f("session.result.backToLobby"),
								confirmLabel: f("games.quarto.confirmLeave"),
								onConfirm: o
							}),
							!a && !o && /* @__PURE__ */ l("p", { children: f("session.result.waitHost") })
						]
					})
				]
			})
		}) : /* @__PURE__ */ l("button", {
			type: "button",
			ref: y,
			className: "quarto-show-result",
			onClick: () => _(!0),
			children: f("games.quarto.showResult")
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function fe({ value: e, onChange: t }) {
	let n = r(), i = B.safeParse(e).success ? B.parse(e) : B.parse(void 0), a = [
		["classic", n("games.quarto.classic")],
		["advanced", n("games.quarto.advanced")],
		["beginner", n("games.quarto.beginner")]
	], o = [
		[1, n("games.quarto.color")],
		[2, n("games.quarto.shape")],
		[4, n("games.quarto.height")],
		[8, n("games.quarto.hollow")]
	];
	return /* @__PURE__ */ u("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ l(k, {
			title: n("games.quarto.mode"),
			children: a.map(([e, n]) => /* @__PURE__ */ l(O, {
				name: "quarto-mode",
				value: e,
				label: n,
				checked: i.mode === e,
				accent: A.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), i.mode === "beginner" && /* @__PURE__ */ l(k, {
			title: n("games.quarto.features"),
			children: o.map(([e, n]) => {
				let r = (i.features & e) !== 0;
				return /* @__PURE__ */ l(D, {
					name: "quarto-features",
					value: String(e),
					label: n,
					checked: r,
					disabled: r ? M(i.features) === 1 : M(i.features) === 3,
					accent: A.accent,
					onChange: () => t({
						...i,
						features: i.features ^ e
					})
				}, e);
			})
		})]
	});
}
//#endregion
//#region src/index.tsx
var pe = {
	definition: V,
	View: ae,
	bot: le,
	describe: ue,
	OverView: de,
	Options: fe,
	locales: {
		zh: {
			name: "同柱阵",
			desc: "为对手选子，连成共同特征",
			rules: "目标：\n在棋盘上组成一条具有至少一种共同特征的四子连线，并及时宣布“Quarto”。\n准备：\n将 16 枚棋子放在棋盘旁。每枚棋子都有四组特征：深色或浅色、圆形或方形、高或矮、空心或实心。所有棋子都不相同。随机决定首先选子的人。\n回合：\n· 选子的人从盘外选择一枚棋子交给对手。\n· 对手必须将这枚棋子放到棋盘的任意空位，然后从剩余棋子中选择一枚交回给对方。双方如此交替。\n宣布胜利：\n· 落子后，如果该棋子与同一横行、竖列或对角线上的另外三枚棋子具有至少一种共同特征，落子者可以立即宣布“Quarto”获胜。四枚棋子不必由同一人放置，也可能同时具有多种共同特征。\n· 如果落子者没有宣布，而是把下一枚棋子交给对手，对手可以在放置那枚棋子之前宣布“Quarto”，指出刚形成的连线并获胜。\n· 如果双方都没有在该连线形成的回合宣布，它便不再具有胜利效力；之后必须形成新的连线。\n结束：\n宣布并指出有效连线的玩家获胜。所有棋子都放完且无人宣布胜利时，游戏以和局结束。\n变体：\n· 入门模式：开局时选择一至三组特征，只有所选特征能够构成连线。\n· 进阶模式：除了横、竖、斜连线，四枚棋子在相邻的两行两列方格组成方阵且具有共同特征时，也可以宣布胜利。",
			mode: "游戏模式",
			classic: "经典",
			advanced: "进阶",
			beginner: "入门",
			features: "可用特征（选择一至三项）",
			color: "颜色",
			shape: "形状",
			height: "高度",
			hollow: "空心或实心",
			choose: "选择一枚棋子交给对手",
			place: "将交给你的棋子放在空位",
			moving: "棋子移动中",
			waiting: "等待{{name}}",
			acting: "{{name}}正在行动",
			reserve: "待选棋子",
			board: "棋盘",
			selected: "待放棋子",
			access: "键盘与辅助操作",
			claim: "宣布 Quarto",
			pass: "结束对局",
			cellAria: "第{{row}}行第{{col}}列：{{piece}}",
			placeAria: "将待放棋子放在第{{row}}行第{{col}}列",
			chooseAria: "将{{piece}}交给对手",
			empty: "空位",
			light: "浅色",
			dark: "深色",
			round: "圆形",
			square: "方形",
			tall: "高",
			short: "矮",
			solid: "实心",
			hollowPiece: "空心",
			featureLabel: "{{color}}、{{shape}}、{{height}}、{{hollow}}",
			errTurn: "现在不能执行这个动作。",
			errStale: "局面已更新，请重新选择。",
			errClaim: "刚放置的棋子没有形成有效连线。",
			errTarget: "请选择可用的棋子或空位。",
			final: "对局结束",
			won: "{{name}}获胜",
			draw: "和局",
			review: "回看棋盘",
			showResult: "查看结果",
			hintChoose: "把{{piece}}交给对手。",
			hintPlace: "将棋子放在第{{row}}行第{{col}}列。",
			hintClaim: "宣布 Quarto。",
			hintPass: "结束对局。",
			confirmAgain: "确认再来一局",
			confirmLeave: "确认返回大厅",
			webglFallback: "3D 暂不可用，已切换为棋盘视图。"
		},
		en: {
			name: "Quarto",
			desc: "Choose a piece for your opponent and make a matching line",
			rules: "Objective:\nMake a line of four pieces that share at least one characteristic, and call “Quarto” in time.\nSetup:\nPut the 16 pieces beside the board. Each piece has four characteristics: light or dark, round or square, tall or short, and hollow or solid. Every piece is unique. Choose the first player to select a piece at random.\nTaking turns:\n· The player selecting a piece gives any unused piece to the opponent.\n· The opponent must place it on any empty space, then select one of the remaining pieces for the other player. Continue alternating in this way.\nCalling a win:\n· After placing a piece, if it and the other three pieces in the same row, column, or diagonal share at least one characteristic, the player may immediately call “Quarto” to win. The four pieces need not have been placed by the same player and may share more than one characteristic.\n· If that player does not call and gives the next piece to the opponent, the opponent may call “Quarto” and point out the newly formed line before placing that piece. The opponent then wins.\n· If neither player calls during the turn in which the line is formed, it no longer counts; a new line must be formed to win.\nEnd of the game:\nThe player who calls and points out a valid line wins. If all pieces are placed and nobody calls a win, the game is a draw.\nVariants:\n· Beginner: select one to three characteristics at setup. Only the selected characteristics can complete a line.\n· Advanced: in addition to rows, columns, and diagonals, four pieces in an adjacent 2×2 square can win when they share a characteristic.",
			mode: "Game mode",
			classic: "Classic",
			advanced: "Advanced",
			beginner: "Beginner",
			features: "Active characteristics (choose one to three)",
			color: "Colour",
			shape: "Shape",
			height: "Height",
			hollow: "Hollow or solid",
			choose: "Choose a piece for your opponent",
			place: "Place the piece you were given on an empty space",
			moving: "Moving piece",
			waiting: "Waiting for {{name}}",
			acting: "{{name}} is playing",
			reserve: "Available pieces",
			board: "Board",
			selected: "Piece to place",
			access: "Keyboard and accessible controls",
			claim: "Call Quarto",
			pass: "End the game",
			cellAria: "Row {{row}}, column {{col}}: {{piece}}",
			placeAria: "Place the piece in row {{row}}, column {{col}}",
			chooseAria: "Give {{piece}} to your opponent",
			empty: "empty space",
			light: "light",
			dark: "dark",
			round: "round",
			square: "square",
			tall: "tall",
			short: "short",
			solid: "solid",
			hollowPiece: "hollow",
			featureLabel: "{{color}}, {{shape}}, {{height}}, {{hollow}}",
			errTurn: "You cannot do that now.",
			errStale: "The position has changed. Please choose again.",
			errClaim: "The last piece did not make a valid line.",
			errTarget: "Choose an available piece or empty space.",
			final: "Game over",
			won: "{{name}} wins",
			draw: "Draw",
			review: "Review the board",
			showResult: "View result",
			hintChoose: "Give {{piece}} to your opponent.",
			hintPlace: "Place the piece in row {{row}}, column {{col}}.",
			hintClaim: "Call Quarto.",
			hintPass: "End the game.",
			confirmAgain: "Confirm another game",
			confirmLeave: "Confirm return to lobby",
			webglFallback: "3D is unavailable; the board view is shown instead."
		}
	}
};
//#endregion
export { pe as default };
