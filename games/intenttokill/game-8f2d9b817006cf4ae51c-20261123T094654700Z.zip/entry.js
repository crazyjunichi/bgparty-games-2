import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { gameAssetUrl as a } from "@bgparty/sdk/assets";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useGameT as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { IconHistory as u } from "@bgparty/sdk/icons";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as te, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/game/data.ts
var h = [
	"authority",
	"press",
	"outcasts",
	"medicine",
	"government",
	"labor",
	"criminals",
	"jetset",
	"immigrants"
], g = {
	authority: "games.intenttokill.group.authority",
	press: "games.intenttokill.group.press",
	outcasts: "games.intenttokill.group.outcasts",
	medicine: "games.intenttokill.group.medicine",
	government: "games.intenttokill.group.government",
	labor: "games.intenttokill.group.labor",
	criminals: "games.intenttokill.group.criminals",
	jetset: "games.intenttokill.group.jetset",
	immigrants: "games.intenttokill.group.immigrants"
}, _ = [
	{
		key: "actress",
		nameKey: "games.intenttokill.civ.actress",
		sex: "female",
		age: 20,
		build: "S",
		height: "medium",
		group: "jetset"
	},
	{
		key: "secretagent",
		nameKey: "games.intenttokill.civ.secretagent",
		sex: "male",
		age: 20,
		build: "M",
		height: "tall",
		group: "government"
	},
	{
		key: "artist",
		nameKey: "games.intenttokill.civ.artist",
		sex: "female",
		age: 40,
		build: "L",
		height: "tall",
		group: "jetset"
	},
	{
		key: "bartender",
		nameKey: "games.intenttokill.civ.bartender",
		sex: "female",
		age: 40,
		build: "L",
		height: "medium",
		group: "criminals"
	},
	{
		key: "ballplayer",
		nameKey: "games.intenttokill.civ.ballplayer",
		sex: "male",
		age: 20,
		build: "L",
		height: "short",
		group: "jetset"
	},
	{
		key: "beggar",
		nameKey: "games.intenttokill.civ.beggar",
		sex: "male",
		age: 60,
		build: "S",
		height: "short",
		group: "outcasts"
	},
	{
		key: "bouncer",
		nameKey: "games.intenttokill.civ.bouncer",
		sex: "male",
		age: 20,
		build: "L",
		height: "tall",
		group: "criminals"
	},
	{
		key: "greaser",
		nameKey: "games.intenttokill.civ.greaser",
		sex: "male",
		age: 20,
		build: "L",
		height: "medium",
		group: "outcasts"
	},
	{
		key: "catlady",
		nameKey: "games.intenttokill.civ.catlady",
		sex: "female",
		age: 60,
		build: "M",
		height: "medium",
		group: "outcasts"
	},
	{
		key: "congressman",
		nameKey: "games.intenttokill.civ.congressman",
		sex: "male",
		age: 60,
		build: "L",
		height: "medium",
		group: "government"
	},
	{
		key: "coroner",
		nameKey: "games.intenttokill.civ.coroner",
		sex: "female",
		age: 60,
		build: "S",
		height: "short",
		group: "medicine"
	},
	{
		key: "showgirl",
		nameKey: "games.intenttokill.civ.showgirl",
		sex: "female",
		age: 20,
		build: "S",
		height: "tall",
		group: "outcasts"
	},
	{
		key: "newscaster",
		nameKey: "games.intenttokill.civ.newscaster",
		sex: "male",
		age: 60,
		build: "M",
		height: "short",
		group: "press"
	},
	{
		key: "dispatcher",
		nameKey: "games.intenttokill.civ.dispatcher",
		sex: "male",
		age: 60,
		build: "M",
		height: "tall",
		group: "authority"
	},
	{
		key: "mafiadon",
		nameKey: "games.intenttokill.civ.mafiadon",
		sex: "male",
		age: 60,
		build: "S",
		height: "medium",
		group: "criminals"
	},
	{
		key: "busdriver",
		nameKey: "games.intenttokill.civ.busdriver",
		sex: "male",
		age: 60,
		build: "L",
		height: "short",
		group: "labor"
	},
	{
		key: "pharmacist",
		nameKey: "games.intenttokill.civ.pharmacist",
		sex: "female",
		age: 20,
		build: "L",
		height: "medium",
		group: "medicine"
	},
	{
		key: "benefactor",
		nameKey: "games.intenttokill.civ.benefactor",
		sex: "male",
		age: 40,
		build: "M",
		height: "medium",
		group: "jetset"
	},
	{
		key: "fireman",
		nameKey: "games.intenttokill.civ.fireman",
		sex: "male",
		age: 40,
		build: "S",
		height: "tall",
		group: "labor"
	},
	{
		key: "photographer",
		nameKey: "games.intenttokill.civ.photographer",
		sex: "male",
		age: 40,
		build: "L",
		height: "tall",
		group: "press"
	},
	{
		key: "gangster",
		nameKey: "games.intenttokill.civ.gangster",
		sex: "male",
		age: 40,
		build: "M",
		height: "short",
		group: "criminals"
	},
	{
		key: "icecreamman",
		nameKey: "games.intenttokill.civ.icecreamman",
		sex: "male",
		age: 20,
		build: "M",
		height: "medium",
		group: "labor"
	},
	{
		key: "informant",
		nameKey: "games.intenttokill.civ.informant",
		sex: "female",
		age: 20,
		build: "S",
		height: "short",
		group: "criminals"
	},
	{
		key: "deputy",
		nameKey: "games.intenttokill.civ.deputy",
		sex: "female",
		age: 20,
		build: "M",
		height: "medium",
		group: "authority"
	},
	{
		key: "reporter",
		nameKey: "games.intenttokill.civ.reporter",
		sex: "female",
		age: 20,
		build: "M",
		height: "tall",
		group: "press"
	},
	{
		key: "judge",
		nameKey: "games.intenttokill.civ.judge",
		sex: "female",
		age: 60,
		build: "L",
		height: "short",
		group: "authority"
	},
	{
		key: "lawyer",
		nameKey: "games.intenttokill.civ.lawyer",
		sex: "female",
		age: 40,
		build: "S",
		height: "tall",
		group: "authority"
	},
	{
		key: "librarian",
		nameKey: "games.intenttokill.civ.librarian",
		sex: "female",
		age: 60,
		build: "S",
		height: "medium",
		group: "labor"
	},
	{
		key: "lobbyist",
		nameKey: "games.intenttokill.civ.lobbyist",
		sex: "female",
		age: 60,
		build: "S",
		height: "tall",
		group: "government"
	},
	{
		key: "navysailor",
		nameKey: "games.intenttokill.civ.navysailor",
		sex: "male",
		age: 20,
		build: "S",
		height: "tall",
		group: "immigrants"
	},
	{
		key: "mayor",
		nameKey: "games.intenttokill.civ.mayor",
		sex: "male",
		age: 40,
		build: "S",
		height: "short",
		group: "government"
	},
	{
		key: "musician",
		nameKey: "games.intenttokill.civ.musician",
		sex: "male",
		age: 40,
		build: "L",
		height: "short",
		group: "immigrants"
	},
	{
		key: "psychic",
		nameKey: "games.intenttokill.civ.psychic",
		sex: "female",
		age: 20,
		build: "M",
		height: "short",
		group: "immigrants"
	},
	{
		key: "nun",
		nameKey: "games.intenttokill.civ.nun",
		sex: "female",
		age: 60,
		build: "L",
		height: "tall",
		group: "immigrants"
	},
	{
		key: "nurse",
		nameKey: "games.intenttokill.civ.nurse",
		sex: "female",
		age: 40,
		build: "M",
		height: "tall",
		group: "medicine"
	},
	{
		key: "paperboy",
		nameKey: "games.intenttokill.civ.paperboy",
		sex: "male",
		age: 20,
		build: "S",
		height: "medium",
		group: "press"
	},
	{
		key: "patrolman",
		nameKey: "games.intenttokill.civ.patrolman",
		sex: "male",
		age: 20,
		build: "S",
		height: "short",
		group: "authority"
	},
	{
		key: "ambassador",
		nameKey: "games.intenttokill.civ.ambassador",
		sex: "female",
		age: 40,
		build: "M",
		height: "medium",
		group: "government"
	},
	{
		key: "mailwoman",
		nameKey: "games.intenttokill.civ.mailwoman",
		sex: "female",
		age: 40,
		build: "S",
		height: "short",
		group: "press"
	},
	{
		key: "professor",
		nameKey: "games.intenttokill.civ.professor",
		sex: "male",
		age: 60,
		build: "M",
		height: "medium",
		group: "immigrants"
	},
	{
		key: "stateattorney",
		nameKey: "games.intenttokill.civ.stateattorney",
		sex: "male",
		age: 40,
		build: "L",
		height: "medium",
		group: "authority"
	},
	{
		key: "psychiatrist",
		nameKey: "games.intenttokill.civ.psychiatrist",
		sex: "male",
		age: 60,
		build: "S",
		height: "tall",
		group: "jetset"
	},
	{
		key: "editor",
		nameKey: "games.intenttokill.civ.editor",
		sex: "female",
		age: 60,
		build: "L",
		height: "medium",
		group: "press"
	},
	{
		key: "restaurateur",
		nameKey: "games.intenttokill.civ.restaurateur",
		sex: "female",
		age: 60,
		build: "M",
		height: "short",
		group: "jetset"
	},
	{
		key: "orderly",
		nameKey: "games.intenttokill.civ.orderly",
		sex: "male",
		age: 20,
		build: "M",
		height: "short",
		group: "medicine"
	},
	{
		key: "secretary",
		nameKey: "games.intenttokill.civ.secretary",
		sex: "female",
		age: 20,
		build: "L",
		height: "short",
		group: "government"
	},
	{
		key: "fence",
		nameKey: "games.intenttokill.civ.fence",
		sex: "female",
		age: 60,
		build: "M",
		height: "tall",
		group: "criminals"
	},
	{
		key: "cabincrew",
		nameKey: "games.intenttokill.civ.cabincrew",
		sex: "female",
		age: 40,
		build: "S",
		height: "medium",
		group: "immigrants"
	},
	{
		key: "surgeon",
		nameKey: "games.intenttokill.civ.surgeon",
		sex: "male",
		age: 40,
		build: "S",
		height: "medium",
		group: "medicine"
	},
	{
		key: "riveter",
		nameKey: "games.intenttokill.civ.riveter",
		sex: "female",
		age: 20,
		build: "L",
		height: "tall",
		group: "labor"
	},
	{
		key: "veterinarian",
		nameKey: "games.intenttokill.civ.veterinarian",
		sex: "male",
		age: 60,
		build: "L",
		height: "tall",
		group: "medicine"
	},
	{
		key: "veteran",
		nameKey: "games.intenttokill.civ.veteran",
		sex: "male",
		age: 40,
		build: "M",
		height: "tall",
		group: "outcasts"
	},
	{
		key: "waitress",
		nameKey: "games.intenttokill.civ.waitress",
		sex: "female",
		age: 40,
		build: "M",
		height: "short",
		group: "labor"
	},
	{
		key: "warwidow",
		nameKey: "games.intenttokill.civ.warwidow",
		sex: "female",
		age: 40,
		build: "L",
		height: "short",
		group: "outcasts"
	}
], v = [
	"games.intenttokill.district.rockyhall",
	"games.intenttokill.district.docks",
	"games.intenttokill.district.littleitaly",
	"games.intenttokill.district.goldenbeach",
	"games.intenttokill.district.westside",
	"games.intenttokill.district.businesscenter",
	"games.intenttokill.district.presidentsquare",
	"games.intenttokill.district.eastside",
	"games.intenttokill.district.chinatown",
	"games.intenttokill.district.centralpark",
	"games.intenttokill.district.santacruz",
	"games.intenttokill.district.riverstation",
	"games.intenttokill.district.stadium",
	"games.intenttokill.district.richmond",
	"games.intenttokill.district.universitycampus",
	"games.intenttokill.district.oldcity"
], y = {
	0: "fire",
	2: "hospital",
	5: "police",
	7: "diner",
	9: "diner",
	11: "hospital",
	12: "fire",
	14: "police"
}, ne = {
	police: "games.intenttokill.building.police",
	diner: "games.intenttokill.building.diner",
	hospital: "games.intenttokill.building.hospital",
	fire: "games.intenttokill.building.fire"
}, re = [
	5,
	6,
	9,
	10
], b = Array.from({ length: 16 }, (e, t) => {
	let n = Math.floor(t / 4), r = t % 4, i = [];
	return n > 0 && i.push(t - 4), n < 3 && i.push(t + 4), r > 0 && i.push(t - 1), r < 3 && i.push(t + 1), i;
}), x = Array.from({ length: 16 }, (e, t) => {
	let n = Math.floor(t / 4), r = t % 4, i = [];
	for (let e = -1; e <= 1; e += 1) for (let t = -1; t <= 1; t += 1) {
		if (e === 0 && t === 0) continue;
		let a = n + e, o = r + t;
		a >= 0 && a < 4 && o >= 0 && o < 4 && i.push(a * 4 + o);
	}
	return i;
}), S = [
	"psychopath",
	"cutthroat",
	"spy",
	"cannibal",
	"vigilante",
	"radical",
	"cultist",
	"killer",
	"sadist",
	"terrorist",
	"maniac",
	"robber"
], ie = {
	psychopath: "games.intenttokill.motive.psychopath.name",
	cutthroat: "games.intenttokill.motive.cutthroat.name",
	spy: "games.intenttokill.motive.spy.name",
	cannibal: "games.intenttokill.motive.cannibal.name",
	vigilante: "games.intenttokill.motive.vigilante.name",
	radical: "games.intenttokill.motive.radical.name",
	cultist: "games.intenttokill.motive.cultist.name",
	killer: "games.intenttokill.motive.killer.name",
	sadist: "games.intenttokill.motive.sadist.name",
	terrorist: "games.intenttokill.motive.terrorist.name",
	maniac: "games.intenttokill.motive.maniac.name",
	robber: "games.intenttokill.motive.robber.name"
}, ae = {
	psychopath: "games.intenttokill.motive.psychopath.text",
	cutthroat: "games.intenttokill.motive.cutthroat.text",
	spy: "games.intenttokill.motive.spy.text",
	cannibal: "games.intenttokill.motive.cannibal.text",
	vigilante: "games.intenttokill.motive.vigilante.text",
	radical: "games.intenttokill.motive.radical.text",
	cultist: "games.intenttokill.motive.cultist.text",
	killer: "games.intenttokill.motive.killer.text",
	sadist: "games.intenttokill.motive.sadist.text",
	terrorist: "games.intenttokill.motive.terrorist.text",
	maniac: "games.intenttokill.motive.maniac.text",
	robber: "games.intenttokill.motive.robber.text"
}, oe = [
	"male",
	"female",
	"young",
	"middle",
	"senior",
	"thin",
	"mediumBuild",
	"heavy",
	"tall",
	"mediumHeight",
	"short"
], se = {
	male: "games.intenttokill.q.male",
	female: "games.intenttokill.q.female",
	young: "games.intenttokill.q.young",
	middle: "games.intenttokill.q.middle",
	senior: "games.intenttokill.q.senior",
	thin: "games.intenttokill.q.thin",
	mediumBuild: "games.intenttokill.q.mediumBuild",
	heavy: "games.intenttokill.q.heavy",
	tall: "games.intenttokill.q.tall",
	mediumHeight: "games.intenttokill.q.mediumHeight",
	short: "games.intenttokill.q.short"
}, ce = {
	id: "intenttokill",
	uuid: "b7f4c2d1-6a3e-4f8b-9c2d-5e1a7f0b3c64",
	tier: "alpha",
	mechanics: [
		"deduction",
		"grid-movement",
		"action-points"
	],
	interactionTags: ["hidden-roles"],
	nameKey: "games.intenttokill.name",
	descKey: "games.intenttokill.desc",
	rulesKey: "games.intenttokill.rules",
	icon: "🕵️",
	iconImg: "games/intenttokill.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#a3203a",
	releasedAt: "2026-11-22T22:46:22+08:00",
	search: {
		py: "an cang sha ji",
		init: "acsj"
	},
	hotseat: "cover"
}, le = t.string(), C = t.int().min(0).max(19), w = t.int().min(0).max(15), ue = t.enum(["detective", "murderer"]), T = t.enum(S), E = t.enum(h), D = t.enum(oe), de = t.enum([
	"setup",
	"intimidate",
	"murder",
	"response",
	"investigate",
	"answers",
	"fire",
	"cityMurderer",
	"cityDetective",
	"accuseChoice",
	"accuse",
	"done"
]), fe = t.enum([
	"question",
	"diner",
	"police",
	"hospital",
	"fire"
]), pe = t.object({
	civ: C,
	q: D
}), me = t.object({
	civ: C,
	to: w
}), he = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("placeDetective"),
		block: w
	}),
	t.object({
		type: t.literal("intimidate"),
		civs: t.array(C).max(2)
	}),
	t.object({
		type: t.literal("murder"),
		civ: C
	}),
	t.object({ type: t.literal("refuse") }),
	t.object({
		type: t.literal("respond"),
		moves: t.array(me).max(3)
	}),
	t.object({
		type: t.literal("question"),
		block: w,
		asks: t.array(pe).min(1).max(3)
	}),
	t.object({
		type: t.literal("diner"),
		civ: C,
		q: D
	}),
	t.object({
		type: t.literal("police"),
		civ: C
	}),
	t.object({
		type: t.literal("hospital"),
		civ: C
	}),
	t.object({ type: t.literal("fireStation") }),
	t.object({
		type: t.literal("move"),
		to: w
	}),
	t.object({
		type: t.literal("surveillance"),
		civ: C
	}),
	t.object({
		type: t.literal("answer"),
		answers: t.array(t.boolean()).min(1).max(3)
	}),
	t.object({
		type: t.literal("moveGroup"),
		group: E.optional(),
		moves: t.array(me).max(20)
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("accuse"),
		civ: C,
		motive: T
	}),
	t.object({ type: t.literal("continue") })
]), ge = t.object({
	kind: t.enum([
		"round",
		"intimidate",
		"murder",
		"refuse",
		"question",
		"answer",
		"surveillance",
		"move",
		"comfort",
		"city",
		"groupMove",
		"accuse",
		"win",
		"system"
	]),
	civ: C.optional(),
	civ2: C.optional(),
	q: D.optional(),
	answer: t.boolean().optional(),
	group: E.optional(),
	block: w.optional(),
	n: t.int().optional()
}), _e = t.union([
	t.object({
		kind: t.literal("answers"),
		asks: t.array(pe).min(1).max(3),
		by: ue
	}),
	t.object({
		kind: t.literal("response"),
		block: w,
		civs: t.array(C).max(3)
	}),
	t.object({
		kind: t.literal("fire"),
		group: E.nullable(),
		choose: t.boolean()
	}),
	t.object({
		kind: t.literal("city"),
		group: E.nullable(),
		choose: t.boolean()
	})
]), O = t.object({
	players: t.tuple([le, le]),
	roles: t.record(le, ue),
	round: t.int().min(1),
	phase: de,
	turn: le,
	murders: t.int().min(0).max(5),
	civilians: t.array(t.object({
		id: C,
		card: t.int().min(0).max(53),
		block: t.int().min(-1).max(15),
		intimidated: t.boolean(),
		dead: t.boolean()
	})),
	marker: w,
	surveillance: C.nullable(),
	crimes: t.array(t.object({
		block: w,
		civ: C,
		order: t.int().min(1).max(5)
	})),
	victimArea: t.array(C),
	motiveChoices: t.array(T).length(6),
	socialStackCount: t.int().min(0).max(9),
	investigation: t.object({
		moves: t.int().min(0).max(2),
		actions: t.int().min(0).max(2),
		used: t.array(fe)
	}).nullable(),
	pending: _e.nullable(),
	questionLog: t.array(t.object({
		civ: C,
		q: D,
		answer: t.boolean()
	})),
	log: t.array(ge),
	reveal: t.object({
		civ: C,
		motive: T
	}).nullable(),
	winner: le.nullable(),
	winReason: t.enum([
		"detective",
		"murderer",
		"secondRefusal"
	]).nullable()
}), ve = t.object({
	role: ue,
	secret: t.object({
		murdererCiv: C,
		poiCiv: C,
		motive: T,
		supporters: E,
		drawnGroups: t.array(E).length(3)
	}).nullable()
}), k = (e, t) => _[e.civilians[t].card], A = (e, t) => e.players.find((n) => e.roles[n] === t), j = (e, t) => e.players[0] === t ? e.players[1] : e.players[0], ye = (e) => e.civilians.filter((e) => e.alive), M = (e, t) => e.civilians.filter((e) => e.alive && e.block === t), be = (e) => new Set(e.crimes.map((e) => e.block)), N = (e, t) => e.crimes.some((e) => e.block === t), P = (e, t) => b[e].includes(t);
function F(t, n) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function xe(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; --t) {
		let r = F(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function Se(e, t) {
	return t[F(e, t.length)];
}
function I(e, t) {
	e.log.push(t), e.log.length > 120 && e.log.splice(0, e.log.length - 120);
}
function L(e) {
	return { code: e };
}
function Ce(e) {
	let t = xe(e, _.map((e, t) => t)).slice(0, 20), n = [];
	for (let e of [
		0,
		3,
		12,
		15
	]) n.push(e, e);
	for (let e = 0; e < 16; e += 1) [
		0,
		3,
		12,
		15
	].includes(e) || n.push(e);
	e.civilians = t.map((e, t) => ({
		id: t,
		card: e,
		block: n[t],
		intimidated: !1,
		alive: !0
	}));
}
function R(e) {
	let t = /* @__PURE__ */ new Set([
		"psychopath|cannibal",
		"radical|psychopath",
		"radical|cannibal"
	]);
	for (let n = 0; n < 100; n += 1) {
		let n = xe(e, [...S]).slice(0, 6), r = new Set(n), i = !1;
		for (let e of t) {
			let [t, n] = e.split("|");
			r.has(t) && r.has(n) && (i = !0);
		}
		if (!i) return n;
	}
	return [
		"maniac",
		"sadist",
		"cutthroat",
		"vigilante",
		"killer",
		"terrorist"
	];
}
function z(e, t) {
	return k(e, t).group;
}
function B(e, t, n, r) {
	let i = k(e, n);
	if (t === "spy" && !y[r] || t === "cutthroat" && re.includes(r) || t === "killer" && M(e, r).length !== 1 || t === "sadist" && e.civilians[n].intimidated || t === "vigilante" && x[e.marker].includes(r)) return !1;
	if (t === "robber") {
		let t = e.crimes[e.crimes.length - 1];
		if (t && P(t.block, r)) return !1;
	}
	if (t === "cultist") {
		let t = e.crimes[e.crimes.length - 1];
		return t ? i.group !== z(e, t.civ) : i.group !== z(e, e.poiCiv);
	}
	if (t === "terrorist" && e.crimes.some((t) => z(e, t.civ) === i.group)) return !1;
	if (t === "maniac") {
		let t = e.crimes[0];
		if (t && k(e, t.civ).sex !== i.sex) return !1;
	}
	if (t === "psychopath") {
		let t = new Set(e.crimes.map((t) => k(e, t.civ).age));
		if (t.add(i.age), t.size > 2) return !1;
	}
	return !0;
}
function we(e) {
	return e.crimes.map((e) => ({
		civ: e.civ,
		block: e.block
	}));
}
function V(e, t, n) {
	if (n.length !== 5 || t === "cannibal" && new Set(n.map((t) => k(e, t.civ).build)).size !== 3 || t === "cultist" && !n.some((t) => t.civ === e.poiCiv)) return !1;
	if (t === "radical") {
		let t = /* @__PURE__ */ new Map();
		for (let r of n) t.set(z(e, r.civ), (t.get(z(e, r.civ)) ?? 0) + 1);
		if (Math.max(...t.values()) < 3) return !1;
	}
	return !0;
}
function Te(e, t, n, r) {
	for (let i = 0; i < n.length; i += 1) {
		let a = n[i], o = k(e, a.civ);
		if (t === "spy" && !y[a.block] || t === "cutthroat" && re.includes(a.block) || t === "robber" && i > 0 && P(n[i - 1].block, a.block) || t === "cultist" && (i === 0 && o.group === z(e, e.poiCiv) || i > 0 && o.group === z(e, n[i - 1].civ)) || t === "terrorist" && n.slice(0, i).some((t) => z(e, t.civ) === o.group) || t === "maniac" && i > 0 && o.sex !== k(e, n[0].civ).sex || t === "psychopath" && new Set(n.slice(0, i + 1).map((t) => k(e, t.civ).age)).size > 2 || i === r && (t === "killer" && M(e, a.block).length !== 1 || t === "sadist" && e.civilians[a.civ].intimidated || t === "vigilante" && x[e.marker].includes(a.block))) return !1;
	}
	return !(t === "cultist" && n.length < 5 && !e.civilians[e.poiCiv].alive && !n.some((t) => t.civ === e.poiCiv));
}
function Ee(e, t, n, r, i, a, o, s, c, l, u, ee, d) {
	if (r === 0) return V(e, t, n);
	let f = `${r}|${o}|${s}|${c}|${l}|${u}|${ee}|${d}`, te = i.get(f);
	if (te !== void 0) return te;
	let p = be(e);
	for (let e of n) p.add(e.block);
	let m = !1;
	for (let f of a) {
		if (d & 1 << f) continue;
		let te = e.civilians[f];
		if (!te.alive || f === e.murdererCiv) continue;
		let g = te.block;
		if (g < 0 || p.has(g)) continue;
		let _ = k(e, f);
		if (t === "spy" && !y[g] || t === "cutthroat" && re.includes(g) || t === "killer" && M(e, g).filter((e) => !(d & 1 << e.id)).length !== 1 || t === "robber" && ee !== null && P(ee, g) || t === "cultist" && (u !== null && _.group === u || r === 1 && !(d & 1 << e.poiCiv) && f !== e.poiCiv) || t === "terrorist" && s & 1 << h.indexOf(_.group) || t === "maniac" && l !== 0 && !(l & 1 << (_.sex === "male" ? 0 : 1))) continue;
		let v = 1 << [
			20,
			40,
			60
		].indexOf(_.age);
		if (t === "psychopath") {
			let e = o | v, t = 0;
			for (let n = 0; n < 3; n += 1) e & 1 << n && (t += 1);
			if (t > 2) continue;
		}
		let ne = o | v, b = s | 1 << h.indexOf(_.group), x = c | 1 << [
			"S",
			"M",
			"L"
		].indexOf(_.build), S = l | 1 << (_.sex === "male" ? 0 : 1);
		if (Ee(e, t, [...n, {
			civ: f,
			block: g
		}], r - 1, i, a, ne, b, x, S, _.group, g, d | 1 << f)) {
			m = !0;
			break;
		}
	}
	return i.set(f, m), m;
}
function H(e, t, n) {
	if (!Te(e, t, n, n.length - 1)) return !1;
	let r = 5 - n.length;
	if (r === 0) return V(e, t, n);
	let i = ye(e).map((e) => e.id), a = 0, o = 0, s = 0, c = 0;
	for (let t of n) {
		let n = k(e, t.civ);
		a |= 1 << [
			20,
			40,
			60
		].indexOf(n.age), o |= 1 << h.indexOf(n.group), s |= 1 << [
			"S",
			"M",
			"L"
		].indexOf(n.build), c |= 1 << (n.sex === "male" ? 0 : 1);
	}
	let l = n[n.length - 1], u = n.reduce((e, t) => e | 1 << t.civ, 0);
	return Ee(e, t, n, r, /* @__PURE__ */ new Map(), i, a, o, s, c, l ? z(e, l.civ) : null, l ? l.block : null, u);
}
function U(e, t) {
	let n = e.civilians[t];
	if (!n || !n.alive || t === e.murdererCiv || n.block === e.marker || N(e, n.block) || n.block < 0 || !B(e, e.motive, t, n.block)) return !1;
	let r = [...we(e), {
		civ: t,
		block: n.block
	}];
	return H(e, e.motive, r);
}
function De(e, t, n) {
	return U({
		players: e.players,
		seed: 0,
		cursor: 0,
		roles: e.roles,
		round: e.round,
		phase: e.phase,
		turn: e.turn,
		civilians: e.civilians.map((e) => ({
			id: e.id,
			card: e.card,
			block: e.block,
			intimidated: e.intimidated,
			alive: !e.dead
		})),
		murdererCiv: t.murdererCiv,
		poiCiv: t.poiCiv,
		motive: t.motive,
		motiveChoices: [...e.motiveChoices],
		supporters: t.supporters,
		drawnGroups: [...t.drawnGroups],
		marker: e.marker,
		surveillance: e.surveillance,
		crimes: e.crimes.map((e) => ({ ...e })),
		murders: e.murders,
		refusals: 0,
		investigation: null,
		pending: null,
		socialStack: [],
		cityReturns: [],
		questionLog: [],
		log: [],
		winner: null,
		winReason: null
	}, n);
}
function Oe(e, t) {
	let n = k(e, e.murdererCiv);
	switch (t) {
		case "male": return n.sex === "male";
		case "female": return n.sex === "female";
		case "young": return n.age === 20;
		case "middle": return n.age === 40;
		case "senior": return n.age === 60;
		case "thin": return n.build === "S";
		case "mediumBuild": return n.build === "M";
		case "heavy": return n.build === "L";
		case "tall": return n.height === "tall";
		case "mediumHeight": return n.height === "medium";
		case "short": return n.height === "short";
	}
}
function ke(e, t) {
	return t === e.murdererCiv || t === e.poiCiv || z(e, t) === e.supporters;
}
function W(e) {
	if (e.socialStack.length === 0) return {
		group: null,
		choose: !0
	};
	let t = F(e, e.socialStack.length), n = e.socialStack.splice(t, 1)[0];
	return {
		group: n,
		choose: !ye(e).some((t) => z(e, t.id) === n)
	};
}
function G(e) {
	let t = 0;
	for (let n of e.civilians) n.alive && n.block === e.marker && n.intimidated && (n.intimidated = !1, t += 1);
	t && I(e, {
		kind: "comfort",
		block: e.marker,
		n: t
	});
}
function K(e, t) {
	e.round = t, e.phase = "intimidate", e.turn = A(e, "murderer"), e.investigation = null, e.pending = null, I(e, {
		kind: "round",
		n: t
	});
}
function Ae(e) {
	G(e), e.cityReturns = [];
	let t = W(e);
	e.phase = "cityMurderer", e.turn = A(e, "murderer"), e.investigation = null, e.pending = {
		kind: "city",
		group: t.group,
		choose: t.choose
	};
}
function je(e) {
	if (e.phase === "cityMurderer") {
		let t = W(e);
		e.phase = "cityDetective", e.turn = A(e, "detective"), e.pending = {
			kind: "city",
			group: t.group,
			choose: t.choose
		};
		return;
	}
	for (let t of e.cityReturns) e.socialStack.push(t);
	e.cityReturns = [], e.pending = null;
	let t = e.refusals > 0 ? 6 : 5;
	if (e.murders >= 5 || e.round >= t) {
		e.phase = "accuse", e.turn = A(e, "detective");
		return;
	}
	if (e.round >= 3) {
		e.phase = "accuseChoice", e.turn = A(e, "detective");
		return;
	}
	K(e, e.round + 1);
}
function Me(e, t, n) {
	e.winner = t, e.winReason = n, e.phase = "done", e.pending = null, e.investigation = null, I(e, {
		kind: "win",
		n: +(n === "detective")
	});
}
var Ne = {
	meta: ce,
	saveCompatibility: { version: "1" },
	schemas: {
		action: he,
		publicView: O,
		privateView: ve
	},
	setup(e, t, n) {
		let r = {
			players: [t[0], t[1]],
			seed: n,
			cursor: 0,
			roles: {},
			round: 1,
			phase: "setup",
			turn: t[0],
			civilians: [],
			murdererCiv: 0,
			poiCiv: 0,
			motive: "maniac",
			motiveChoices: [],
			supporters: "authority",
			drawnGroups: [],
			marker: 0,
			surveillance: null,
			crimes: [],
			murders: 0,
			refusals: 0,
			investigation: null,
			pending: null,
			socialStack: [],
			cityReturns: [],
			questionLog: [],
			log: [],
			winner: null,
			winReason: null
		}, i = t[F(r, 2)], a = t.find((e) => e !== i);
		r.roles = {
			[i]: "murderer",
			[a]: "detective"
		}, r.turn = a, Ce(r);
		let o = F(r, 20), s = F(r, 20);
		for (; s === o;) s = F(r, 20);
		r.murdererCiv = o, r.poiCiv = s, r.motiveChoices = R(r), r.motive = Se(r, r.motiveChoices);
		let c = xe(r, [...h]).slice(0, 3);
		return r.drawnGroups = c, r.supporters = c[F(r, 3)], r.socialStack = h.filter((e) => !c.includes(e)), I(r, {
			kind: "system",
			n: 2
		}), { state: r };
	},
	reduce(e, t, n) {
		let r = structuredClone(e);
		if (!r.players.includes(n.by)) return L("games.intenttokill.err.notPlayer");
		let i = r.roles[n.by], a = r.turn === n.by;
		if (t.type === "placeDetective") return r.phase === "setup" ? i === "detective" ? t.block < 0 || t.block > 15 ? L("games.intenttokill.err.badTarget") : (r.marker = t.block, K(r, 1), { state: r }) : L("games.intenttokill.err.notYourRole") : L("games.intenttokill.err.wrongPhase");
		if (!a) return L("games.intenttokill.err.notYourTurn");
		if (t.type === "intimidate") {
			if (r.phase !== "intimidate" || i !== "murderer") return L("games.intenttokill.err.wrongPhase");
			let e = ye(r).filter((e) => e.block !== r.marker).map((e) => e.id), n = Math.min(2, e.length);
			if (t.civs.length !== n || new Set(t.civs).size !== n) return L("games.intenttokill.err.badChoice");
			if (!t.civs.every((t) => e.includes(t))) return L("games.intenttokill.err.badTarget");
			for (let e of t.civs) r.civilians[e].intimidated = !0;
			return I(r, {
				kind: "intimidate",
				civ: t.civs[0],
				civ2: t.civs[1]
			}), r.phase = "murder", { state: r };
		}
		if (t.type === "murder") {
			if (r.phase !== "murder" || i !== "murderer") return L("games.intenttokill.err.wrongPhase");
			if (!U(r, t.civ)) return L("games.intenttokill.err.badVictim");
			let e = r.civilians[t.civ].block;
			r.surveillance === t.civ && (r.surveillance = null, I(r, {
				kind: "surveillance",
				civ: t.civ,
				answer: !0
			})), r.civilians[t.civ].alive = !1, r.civilians[t.civ].block = -1, r.murders += 1, r.crimes.push({
				block: e,
				civ: t.civ,
				order: r.murders
			}), I(r, {
				kind: "murder",
				civ: t.civ,
				block: e,
				n: r.murders
			});
			let n = M(r, e).map((e) => e.id);
			return r.phase = "response", r.turn = A(r, "detective"), r.investigation = null, r.pending = {
				kind: "response",
				block: e,
				civs: n
			}, { state: r };
		}
		if (t.type === "refuse") return r.phase !== "murder" || i !== "murderer" ? L("games.intenttokill.err.wrongPhase") : (r.refusals += 1, I(r, {
			kind: "refuse",
			n: r.refusals
		}), r.refusals >= 2 ? (Me(r, A(r, "detective"), "secondRefusal"), { state: r }) : (r.phase = "investigate", r.turn = A(r, "detective"), r.investigation = {
			moves: 2,
			actions: 2,
			used: []
		}, r.pending = null, { state: r }));
		if (t.type === "respond") {
			if (r.phase !== "response" || i !== "detective" || !r.pending || r.pending.kind !== "response") return L("games.intenttokill.err.wrongPhase");
			let e = r.pending, n = e.civs;
			if (t.moves.length !== n.length || new Set(t.moves.map((e) => e.civ)).size !== n.length) return L("games.intenttokill.err.badMove");
			let a = /* @__PURE__ */ new Map();
			for (let e of t.moves) {
				if (!n.includes(e.civ)) return L("games.intenttokill.err.badMove");
				let t = r.civilians[e.civ];
				if (!t.alive) return L("games.intenttokill.err.badMove");
				let i = b[t.block].filter((e) => !N(r, e) && M(r, e).length < 3), o = Array.from({ length: 16 }, (e, t) => t).filter((e) => !N(r, e) && M(r, e).length < 3), s = e.to;
				if (s < 0 || s > 15 || s === t.block || (i.length ? !i.includes(s) : !o.includes(s))) return L("games.intenttokill.err.badMove");
				a.set(e.civ, s);
			}
			let o = /* @__PURE__ */ new Map();
			for (let e of r.civilians) e.alive && !a.has(e.id) && o.set(e.block, (o.get(e.block) ?? 0) + 1);
			for (let [, e] of a) o.set(e, (o.get(e) ?? 0) + 1);
			for (let [, e] of o) if (e > 3) return L("games.intenttokill.err.noSpace");
			for (let [e, t] of a) r.civilians[e].block = t;
			return r.marker = e.block, I(r, {
				kind: "move",
				block: r.marker,
				n: a.size
			}), r.pending = null, r.phase = "investigate", r.turn = A(r, "detective"), r.investigation = {
				moves: 2,
				actions: 2,
				used: []
			}, { state: r };
		}
		if (t.type === "question") {
			if (r.phase !== "investigate" || i !== "detective" || !r.investigation) return L("games.intenttokill.err.wrongPhase");
			if (r.investigation.actions <= 0 || r.investigation.used.includes("question")) return L("games.intenttokill.err.noAction");
			if (t.block !== r.marker) return L("games.intenttokill.err.badTarget");
			let e = M(r, r.marker).filter((e) => !e.intimidated).map((e) => e.id);
			return e.length ? t.asks.length !== e.length || new Set(t.asks.map((e) => e.civ)).size !== e.length ? L("games.intenttokill.err.badChoice") : t.asks.every((t) => e.includes(t.civ)) ? (--r.investigation.actions, r.investigation.used.push("question"), r.pending = {
				kind: "answers",
				asks: t.asks,
				by: "murderer"
			}, r.phase = "answers", r.turn = A(r, "murderer"), { state: r }) : L("games.intenttokill.err.badTarget") : L("games.intenttokill.err.badTarget");
		}
		if (t.type === "diner") {
			if (r.phase !== "investigate" || i !== "detective" || !r.investigation) return L("games.intenttokill.err.wrongPhase");
			if (y[r.marker] !== "diner") return L("games.intenttokill.err.badTarget");
			if (r.investigation.actions <= 0 || r.investigation.used.includes("diner")) return L("games.intenttokill.err.noAction");
			let e = r.civilians[t.civ];
			return !e || !e.alive || e.intimidated || e.block !== r.marker && !P(r.marker, e.block) ? L("games.intenttokill.err.badTarget") : (--r.investigation.actions, r.investigation.used.push("diner"), r.pending = {
				kind: "answers",
				asks: [{
					civ: t.civ,
					q: t.q
				}],
				by: "murderer"
			}, r.phase = "answers", r.turn = A(r, "murderer"), { state: r });
		}
		if (t.type === "police") {
			if (r.phase !== "investigate" || i !== "detective" || !r.investigation) return L("games.intenttokill.err.wrongPhase");
			if (y[r.marker] !== "police") return L("games.intenttokill.err.badTarget");
			if (r.investigation.actions <= 0 || r.investigation.used.includes("police")) return L("games.intenttokill.err.noAction");
			let e = r.civilians[t.civ];
			return !e || !e.alive || e.block !== r.marker && !P(r.marker, e.block) ? L("games.intenttokill.err.badTarget") : (--r.investigation.actions, r.investigation.used.push("police"), r.surveillance = t.civ, { state: r });
		}
		if (t.type === "hospital") {
			if (r.phase !== "investigate" || i !== "detective" || !r.investigation) return L("games.intenttokill.err.wrongPhase");
			if (y[r.marker] !== "hospital") return L("games.intenttokill.err.badTarget");
			if (r.investigation.actions <= 0 || r.investigation.used.includes("hospital")) return L("games.intenttokill.err.noAction");
			let e = r.civilians[t.civ];
			return !e || !e.alive || !e.intimidated || e.block !== r.marker && !P(r.marker, e.block) ? L("games.intenttokill.err.badTarget") : (--r.investigation.actions, r.investigation.used.push("hospital"), e.intimidated = !1, { state: r });
		}
		if (t.type === "fireStation") {
			if (r.phase !== "investigate" || i !== "detective" || !r.investigation) return L("games.intenttokill.err.wrongPhase");
			if (y[r.marker] !== "fire") return L("games.intenttokill.err.badTarget");
			if (r.investigation.actions <= 0 || r.investigation.used.includes("fire")) return L("games.intenttokill.err.noAction");
			--r.investigation.actions, r.investigation.used.push("fire");
			let e = W(r);
			return r.pending = {
				kind: "fire",
				group: e.group,
				choose: e.choose
			}, r.phase = "fire", r.turn = A(r, "detective"), { state: r };
		}
		if (t.type === "move") return r.phase !== "investigate" || i !== "detective" || !r.investigation ? L("games.intenttokill.err.wrongPhase") : r.investigation.moves <= 0 ? L("games.intenttokill.err.noAction") : P(r.marker, t.to) ? (r.marker = t.to, --r.investigation.moves, I(r, {
			kind: "move",
			block: r.marker
		}), { state: r }) : L("games.intenttokill.err.badMove");
		if (t.type === "surveillance") {
			if (r.phase !== "investigate" || i !== "detective") return L("games.intenttokill.err.wrongPhase");
			if (r.surveillance === null || r.surveillance !== t.civ) return L("games.intenttokill.err.badTarget");
			let e = r.civilians[t.civ], n = !(!e.alive || t.civ === r.murdererCiv || e.block === r.marker) && U(r, t.civ);
			return r.surveillance = null, I(r, {
				kind: "surveillance",
				civ: t.civ,
				answer: n
			}), { state: r };
		}
		if (t.type === "answer") {
			if (r.phase !== "answers" || i !== "murderer" || !r.pending || r.pending.kind !== "answers") return L("games.intenttokill.err.wrongPhase");
			if (t.answers.length !== r.pending.asks.length) return L("games.intenttokill.err.badAnswer");
			for (let e = 0; e < r.pending.asks.length; e += 1) {
				let n = r.pending.asks[e], i = t.answers[e];
				if (!ke(r, n.civ) && i !== Oe(r, n.q)) return L("games.intenttokill.err.badAnswer");
			}
			for (let e = 0; e < r.pending.asks.length; e += 1) {
				let n = r.pending.asks[e];
				r.questionLog.push({
					civ: n.civ,
					q: n.q,
					answer: t.answers[e]
				}), I(r, {
					kind: "answer",
					civ: n.civ,
					q: n.q,
					answer: t.answers[e]
				});
			}
			return r.pending = null, r.phase = "investigate", r.turn = A(r, "detective"), { state: r };
		}
		if (t.type === "moveGroup") {
			if (!r.pending || r.pending.kind !== "fire" && r.pending.kind !== "city") return L("games.intenttokill.err.wrongPhase");
			if (r.phase === "fire" && i !== "detective" || (r.phase === "cityMurderer" || r.phase === "cityDetective") && r.turn !== n.by) return L("games.intenttokill.err.notYourTurn");
			let e = r.pending, a = e.group;
			if (e.choose) {
				if (!t.group || !ye(r).some((e) => z(r, e.id) === t.group)) return L("games.intenttokill.err.badGroup");
				a = t.group;
			} else if (t.group && t.group !== e.group) return L("games.intenttokill.err.badGroup");
			if (!a) return L("games.intenttokill.err.badGroup");
			let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map();
			for (let e of t.moves) {
				let t = r.civilians[e.civ];
				if (!t || !t.alive || t.block < 0) return L("games.intenttokill.err.badMove");
				if (z(r, e.civ) !== a) return L("games.intenttokill.err.badGroup");
				if (o.has(e.civ) || !P(t.block, e.to) || N(r, e.to)) return L("games.intenttokill.err.badMove");
				o.add(e.civ), s.set(e.civ, e.to);
			}
			let c = /* @__PURE__ */ new Map();
			for (let e of r.civilians) e.alive && !s.has(e.id) && c.set(e.block, (c.get(e.block) ?? 0) + 1);
			for (let [, e] of s) c.set(e, (c.get(e) ?? 0) + 1);
			for (let [, e] of c) if (e > 3) return L("games.intenttokill.err.noSpace");
			for (let [e, t] of s) r.civilians[e].block = t;
			return I(r, {
				kind: "groupMove",
				group: a,
				n: s.size
			}), e.kind === "fire" ? (e.group && !e.choose && r.socialStack.push(e.group), r.pending = null, r.phase = "investigate", r.turn = A(r, "detective"), { state: r }) : (e.group && !e.choose && r.cityReturns.push(e.group), r.pending = null, je(r), { state: r });
		}
		if (t.type === "endTurn") return r.phase !== "investigate" || i !== "detective" ? L("games.intenttokill.err.wrongPhase") : (Ae(r), { state: r });
		if (t.type === "continue") return r.phase !== "accuseChoice" || i !== "detective" ? L("games.intenttokill.err.wrongPhase") : (K(r, r.round + 1), { state: r });
		if (t.type === "accuse") {
			if (r.phase !== "accuseChoice" && r.phase !== "accuse" || i !== "detective") return L("games.intenttokill.err.wrongPhase");
			let e = r.civilians[t.civ];
			return !e || !e.alive ? L("games.intenttokill.err.badTarget") : r.motiveChoices.includes(t.motive) ? (I(r, {
				kind: "accuse",
				civ: t.civ
			}), t.civ === r.murdererCiv && t.motive === r.motive ? Me(r, A(r, "detective"), "detective") : Me(r, A(r, "murderer"), "murderer"), { state: r }) : L("games.intenttokill.err.badChoice");
		}
		return L("games.intenttokill.err.wrongPhase");
	},
	viewFor(e, t) {
		let n = {
			players: e.players,
			roles: e.roles,
			round: e.round,
			phase: e.phase,
			turn: e.turn,
			murders: e.murders,
			civilians: e.civilians.map((e) => ({
				id: e.id,
				card: e.card,
				block: e.block,
				intimidated: e.intimidated,
				dead: !e.alive
			})),
			marker: e.marker,
			surveillance: e.surveillance,
			crimes: e.crimes,
			victimArea: e.crimes.map((e) => e.civ),
			motiveChoices: e.motiveChoices,
			socialStackCount: e.socialStack.length,
			investigation: e.investigation ? {
				...e.investigation,
				used: [...e.investigation.used]
			} : null,
			pending: e.pending,
			questionLog: e.questionLog,
			log: e.log,
			reveal: e.winner ? {
				civ: e.murdererCiv,
				motive: e.motive
			} : null,
			winner: e.winner,
			winReason: e.winReason
		}, r = e.roles[t];
		return {
			public: n,
			private: r === "murderer" ? {
				role: r,
				secret: {
					murdererCiv: e.murdererCiv,
					poiCiv: e.poiCiv,
					motive: e.motive,
					supporters: e.supporters,
					drawnGroups: e.drawnGroups
				}
			} : {
				role: r,
				secret: null
			}
		};
	},
	status(e) {
		if (!e.winner) return { phase: e.phase };
		let t = j(e, e.winner);
		return {
			phase: e.phase,
			winner: [e.winner],
			ranking: [e.winner, t],
			scores: {
				[e.winner]: 1,
				[t]: 0
			}
		};
	}
}, q = (e) => e.replace("games.intenttokill.", ""), Pe = v.map(q), Fe = (e) => a(`games/intenttokill/${e}`), Ie = {
	authority: "g-authority",
	press: "g-press",
	outcasts: "g-outcasts",
	medicine: "g-medicine",
	government: "g-government",
	labor: "g-labor",
	criminals: "g-criminals",
	jetset: "g-jetset",
	immigrants: "g-immigrants"
}, Le = /* @__PURE__ */ new Set([
	1,
	3,
	11
]), Re = /* @__PURE__ */ new Set([
	9,
	10,
	14
]), ze = /* @__PURE__ */ new Set([6]);
function Be({ kind: e }) {
	return e === "police" ? /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("path", {
				d: "M12 1.6 20.4 4.8v6.4c0 5.2-3.5 9.2-8.4 11.2-4.9-2-8.4-6-8.4-11.2V4.8Z",
				fill: "currentColor",
				stroke: "#fff8e6",
				strokeWidth: "1.3",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "9",
				cy: "10.2",
				r: "2.3",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "15",
				cy: "10.2",
				r: "2.3",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ p("path", {
				d: "M11.3 10.2h1.4",
				stroke: "#fff8e6",
				strokeWidth: "1.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M7.4 12.2v2.1M16.6 12.2v2.1",
				stroke: "#fff8e6",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			})
		]
	}) : e === "diner" ? /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("path", {
				d: "M12 1.4c1.8 0 2.9 1.3 4.5 1.5 1.9.2 3.1 1.4 3.4 3.3.3 1.6 1.4 2.7 1.4 4.5s-1.1 2.9-1.4 4.5c-.3 1.9-1.5 3.1-3.4 3.3-1.6.2-2.7 1.5-4.5 1.5s-2.9-1.3-4.5-1.5c-1.9-.2-3.1-1.4-3.4-3.3-.3-1.6-1.4-2.7-1.4-4.5s1.1-2.9 1.4-4.5c.3-1.9 1.5-3.1 3.4-3.3C9.1 2.7 10.2 1.4 12 1.4Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ p("path", {
				d: "M7.4 8.4h8v5.1a4 4 0 0 1-8 0Z",
				fill: "#fff8e6",
				opacity: ".16"
			}),
			/* @__PURE__ */ p("path", {
				d: "M7.6 8.6h7.8v4.8a3.9 3.9 0 0 1-7.8 0Zm7.8 1.3h1.3a1.5 1.5 0 0 1 0 3h-1.3",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M10.2 6.1c.5-.6 1.4-.6 1.9 0s1.4.6 1.9 0",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.2",
				strokeLinecap: "round"
			})
		]
	}) : e === "hospital" ? /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("path", {
				d: "M14 1.8h-4v7.1H2.9v4h7.1v7.1h4v-7.1h7.1v-4H14Z",
				fill: "currentColor",
				stroke: "#fff8e6",
				strokeWidth: "1.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M9 15.4h4.4a2.9 2.9 0 0 0 0-5.8H9",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M10.9 7.5 8.2 9.6l2.7 2.1",
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.6",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})
		]
	}) : /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("path", {
				d: "M12 2.1 14.1 3.4 16.6 3 17.9 5.1 20.2 6 19.8 8.5 21.1 10.6 19.8 12.7 20.2 15.2 17.9 16.1 16.6 18.2 14.1 17.8 12 19.1 9.9 17.8 7.4 18.2 6.1 16.1 3.8 15.2 4.2 12.7 2.9 10.6 4.2 8.5 3.8 6 6.1 5.1 7.4 3 9.9 3.4Z",
				fill: "currentColor",
				stroke: "#fff8e6",
				strokeWidth: "1.1",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M12 6.2v11.6M6.2 12h11.6",
				stroke: "#fff8e6",
				strokeWidth: "1.8",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "m12 5 1.5 2.2h-3ZM12 19l1.5-2.2h-3ZM5 12l2.2-1.5v3ZM19 12l-2.2-1.5v3Z",
				fill: "#fff8e6"
			})
		]
	});
}
function Ve(e, t) {
	let n = _[e];
	switch (t) {
		case "male": return n.sex === "male";
		case "female": return n.sex === "female";
		case "young": return n.age === 20;
		case "middle": return n.age === 40;
		case "senior": return n.age === 60;
		case "thin": return n.build === "S";
		case "mediumBuild": return n.build === "M";
		case "heavy": return n.build === "L";
		case "tall": return n.height === "tall";
		case "mediumHeight": return n.height === "medium";
		case "short": return n.height === "short";
	}
}
function He(e, t, n) {
	let r = _[t.civilians[e]?.card ?? 0];
	return e === n.murdererCiv || e === n.poiCiv || r.group === n.supporters;
}
function J({ card: e, dead: t, intimidated: n, selected: r, stamp: i, onClick: a }) {
	let o = s("intenttokill"), c = _[e], l = o(q(c.nameKey)), u = o(`sex.${c.sex}`), ee = o(`age.${c.age === 20 ? "young" : c.age === 40 ? "middle" : "senior"}`), d = o(`build.${c.build}`), f = o(`height.${c.height}`), h = `${l} · ${o(q(g[c.group]))} · ${u} · ${ee} · ${d} · ${f}${t ? " · " + o("label.dead") : ""}${n ? " · " + o("label.intimidated") : ""}`, v = /* @__PURE__ */ m(te, { children: [
		/* @__PURE__ */ m("span", {
			className: "itk-card-photo",
			children: [
				/* @__PURE__ */ p("img", {
					src: Fe(`civ/${String(e).padStart(2, "0")}.webp`),
					alt: "",
					draggable: !1
				}),
				n && /* @__PURE__ */ p("span", {
					className: "itk-card-stamp is-intim",
					"aria-hidden": !0,
					children: o("label.intimidated")
				}),
				t && /* @__PURE__ */ p("span", {
					className: "itk-card-stamp is-dead",
					"aria-hidden": !0,
					children: o("label.dead")
				}),
				i && /* @__PURE__ */ p("span", {
					className: "itk-card-stamp is-role",
					children: i
				})
			]
		}),
		/* @__PURE__ */ p("span", {
			className: "itk-card-band",
			children: /* @__PURE__ */ p("span", { children: l })
		}),
		/* @__PURE__ */ m("span", {
			className: "itk-card-traits",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ p("span", {
					className: `itk-trait-sex is-${c.sex}`,
					children: c.sex === "female" ? "♀" : "♂"
				}),
				/* @__PURE__ */ m("span", {
					className: "itk-trait-age",
					children: [c.age, /* @__PURE__ */ p("i", { children: o("label.yearsShort") })]
				}),
				/* @__PURE__ */ p("span", {
					className: `itk-trait-build is-${c.build}`,
					children: c.build
				}),
				/* @__PURE__ */ m("span", {
					className: `itk-trait-height is-${c.height}`,
					children: [
						/* @__PURE__ */ p("i", {}),
						/* @__PURE__ */ p("i", {}),
						/* @__PURE__ */ p("i", {})
					]
				})
			]
		})
	] }), y = `itk-card ${Ie[c.group]}${r ? " is-selected" : ""}${t ? " is-dead" : ""}${n ? " is-intimidated" : ""}`;
	return a ? /* @__PURE__ */ p("button", {
		type: "button",
		className: y,
		"aria-label": h,
		title: h,
		onClick: a,
		children: v
	}) : /* @__PURE__ */ p("div", {
		className: y,
		role: "img",
		"aria-label": h,
		title: h,
		children: v
	});
}
function Ue({ motive: e, selected: t, truth: n, disabled: r, onPick: i }) {
	let a = s("intenttokill"), o = a(q(ie[e])), c = a(q(ae[e]));
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: `itk-motive${t ? " is-picked" : ""}${n ? " is-truth" : ""}`,
		onClick: i,
		disabled: r,
		"aria-label": `${o} · ${c}`,
		title: c,
		children: [/* @__PURE__ */ m("span", {
			className: "itk-motive-card",
			children: [/* @__PURE__ */ p("span", {
				className: "itk-motive-art",
				children: /* @__PURE__ */ p("img", {
					src: Fe(`motive/${e}.webp`),
					alt: "",
					draggable: !1
				})
			}), /* @__PURE__ */ p("span", {
				className: "itk-motive-name",
				children: o
			})]
		}), /* @__PURE__ */ m("span", {
			className: "itk-motive-copy",
			children: [
				/* @__PURE__ */ p("span", {
					className: "itk-motive-rule",
					children: c
				}),
				t && /* @__PURE__ */ p("span", {
					className: "itk-motive-mark",
					children: a("label.selected")
				}),
				n && /* @__PURE__ */ p("span", {
					className: "itk-motive-truth",
					"aria-hidden": !0,
					children: "★"
				})
			]
		})]
	});
}
function We({ order: e, card: t }) {
	let n = s("intenttokill");
	return t === void 0 ? /* @__PURE__ */ m("div", {
		className: "itk-victim is-empty",
		role: "img",
		"aria-label": n("label.victimSlot", { n: e }),
		children: [
			/* @__PURE__ */ p("span", {
				className: "itk-victim-no",
				children: e
			}),
			/* @__PURE__ */ p("svg", {
				viewBox: "0 0 40 60",
				className: "itk-chalk",
				"aria-hidden": "true",
				children: /* @__PURE__ */ p("path", {
					d: "M20 8a5.4 5.4 0 1 1 0 10.8A5.4 5.4 0 0 1 20 8Zm0 13.2c6 0 10 3.3 10 8.2v5.1H10v-5.1c0-4.9 4-8.2 10-8.2Zm-8.4 14h16.8L34 52H6Z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.6",
					strokeLinejoin: "round"
				})
			}),
			/* @__PURE__ */ p("span", {
				className: "itk-victim-hint",
				children: n("label.victimSlotShort")
			})
		]
	}) : /* @__PURE__ */ m("div", {
		className: "itk-victim is-filled",
		children: [/* @__PURE__ */ p("span", {
			className: "itk-victim-no",
			children: e
		}), /* @__PURE__ */ p(J, {
			card: t,
			dead: !0
		})]
	});
}
function Ge(e) {
	l();
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Ke, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ke({ pub: e, priv: t, members: a, myRid: c, send: l }) {
	let v = s("intenttokill"), x = t.role === "murderer", S = t.secret, ae = e.turn === c, le = a.find((e) => e.rid === c), C = a.find((e) => e.rid !== c), [w, ue] = i(null), [T, E] = i(null), [D, de] = i([]), [fe, pe] = i({}), [me, he] = i({}), [ge, _e] = i({}), [O, ve] = i(null), [k, A] = i({}), [j, ye] = i(null), [M, be] = i(null), [N, P] = i(null), [F, xe] = i(!1), Se = r(e.murders);
	n(() => {
		if (e.murders > Se.current) {
			xe(!0);
			let t = window.setTimeout(() => xe(!1), 1100);
			return Se.current = e.murders, () => window.clearTimeout(t);
		}
		Se.current = e.murders;
	}, [e.murders]);
	let I = `${e.round}|${e.phase}|${e.turn}|${e.pending?.kind ?? ""}|${e.investigation?.actions ?? ""}`, [L, Ce] = i(I);
	L !== I && (Ce(I), de([]), pe({}), he({}), _e({}), ve(null), A({}), ye(null), P(null)), n(() => {
		if (!N) return;
		let e = window.setTimeout(() => P(null), 2600);
		return () => window.clearTimeout(e);
	}, [N]);
	let R = (t) => {
		let n = e.civilians[t];
		return n ? v(q(_[n.card].nameKey)) : "";
	}, z = (e) => v(q(g[e])), B = (e) => e >= 0 && e < 16 ? v(Pe[e]) : "", we = (e) => v(q(ie[e])), V = (e) => v(q(se[e])), Te = (e) => y[e] ? v(q(ne[y[e]])) : "", Ee = (t) => e.civilians.filter((e) => !e.dead && e.block === t), H = (e) => b[e] ?? [], U = (e) => Ee(e).length < 3, Oe = (t) => e.crimes.find((e) => e.block === t), ke = (e) => !!Oe(e), W = T === null ? null : e.civilians[T] ?? null;
	T !== null && (!W || W.dead) && E(null);
	let G = W && !W.dead ? W : null, K = G ? _[G.card] : null, Ae = w === null ? [] : Ee(w), je = ae || e.phase === "setup" && t.role === "detective" ? "accent" : e.phase === "done" ? "done" : "info", Me = e.phase === "setup" ? t.role === "detective" ? v("prompt.setup") : v("prompt.waiting") : e.phase === "intimidate" ? v(x ? "prompt.intimidate" : "prompt.waiting") : e.phase === "murder" ? v(x ? "prompt.murder" : "prompt.waiting") : e.phase === "response" ? t.role === "detective" ? v("prompt.response") : v("prompt.waiting") : e.phase === "investigate" ? t.role === "detective" ? v("prompt.investigate") : v("prompt.waiting") : e.phase === "answers" ? v(x ? "prompt.yourAnswers" : "prompt.answers") : e.phase === "fire" ? t.role === "detective" ? v("prompt.fire") : v("prompt.waiting") : e.phase === "cityMurderer" ? v(x ? "prompt.cityMurderer" : "prompt.waiting") : e.phase === "cityDetective" ? t.role === "detective" ? v("prompt.cityDetective") : v("prompt.waiting") : e.phase === "accuseChoice" ? t.role === "detective" ? v("prompt.accuseChoice") : v("prompt.waiting") : e.phase === "accuse" ? t.role === "detective" ? v("prompt.accuse") : v("prompt.waiting") : v("prompt.done"), Ne = e.civilians.filter((t) => !t.dead && t.block !== e.marker).map((e) => e.id), Ge = w === e.marker ? Ee(e.marker).filter((e) => !e.intimidated).map((e) => e.id) : [], Ke = y[e.marker], Je = e.civilians.filter((t) => !t.dead && (t.block === e.marker || H(e.marker).includes(t.block))).map((e) => e.id), Y = Je.filter((t) => !e.civilians[t].intimidated), Ye = Je.filter((t) => e.civilians[t].intimidated), Xe = x && S && T !== null && !e.civilians[T].dead && De(e, S, T), X = e.pending && (e.pending.kind === "city" || e.pending.kind === "fire") ? O ?? e.pending.group : null, Z = X ? e.civilians.filter((e) => !e.dead && _[e.card].group === X) : [], Q = e.pending && (e.pending.kind === "city" || e.pending.kind === "fire") && e.pending.choose, Ze = (e) => {
		switch (e.kind) {
			case "round": return v("log.round", { n: e.n ?? 0 });
			case "intimidate": return v("log.intimidate", {
				a: R(e.civ ?? 0),
				b: R(e.civ2 ?? 0)
			});
			case "murder": return v("log.murder", {
				a: R(e.civ ?? 0),
				b: B(e.block ?? 0)
			});
			case "refuse": return v("log.refuse");
			case "question": return v("log.question", {
				a: R(e.civ ?? 0),
				b: V(e.q ?? "male")
			});
			case "answer": return v("log.answer", {
				a: R(e.civ ?? 0),
				b: e.answer ? v("label.yes") : v("label.no")
			});
			case "surveillance": return v("log.surveillance", {
				a: R(e.civ ?? 0),
				b: e.answer ? v("label.yes") : v("label.no")
			});
			case "move": return v("log.move", { a: B(e.block ?? 0) });
			case "comfort": return v("log.comfort", { n: e.n ?? 0 });
			case "groupMove": return v("log.groupMove", {
				a: z(e.group ?? "authority"),
				n: e.n ?? 0
			});
			case "accuse": return v("log.accuse", { a: R(e.civ ?? 0) });
			case "win": return v("log.win");
			default: return "";
		}
	}, Qe = () => {
		if (w !== e.marker || !Ge.length) {
			P(v("label.emptyBlock"));
			return;
		}
		let t = Ge.map((e) => ({
			civ: e,
			q: me[e] ?? "male"
		}));
		l({
			type: "question",
			block: e.marker,
			asks: t
		}), he({});
	}, $e = () => {
		if (!e.pending || e.pending.kind !== "answers" || !S) return;
		let t = e.civilians[S.murdererCiv].card;
		l({
			type: "answer",
			answers: e.pending.asks.map((e) => ge[e.civ] ?? Ve(t, e.q))
		}), _e({});
	}, et = () => {
		if (!e.pending || e.pending.kind !== "response") return;
		let t = e.pending.civs.map((e) => ({
			civ: e,
			to: fe[e]
		})).filter((e) => typeof e.to == "number");
		if (t.length !== e.pending.civs.length) {
			P(v("err.badMove"));
			return;
		}
		l({
			type: "respond",
			moves: t
		});
	}, tt = (t = !1) => {
		if (!e.pending || e.pending.kind !== "city" && e.pending.kind !== "fire") return;
		if (Q && !O) {
			P(v("label.chooseGroup"));
			return;
		}
		let n = t ? [] : Z.map((e) => ({
			civ: e.id,
			to: k[e.id]
		})).filter((e) => typeof e.to == "number");
		l({
			type: "moveGroup",
			group: O ?? void 0,
			moves: n
		}), A({}), ve(null);
	}, nt = v(M === "log" ? "label.eventLog" : M === "notes" ? "label.questionLog" : "label.secret"), rt = M !== null, it = (t) => /* @__PURE__ */ m("div", {
		className: `itk-victims itk-victims--${t}`,
		children: [/* @__PURE__ */ m("p", {
			className: "itk-victims-title",
			children: [/* @__PURE__ */ p("span", { children: v("label.victimArea") }), /* @__PURE__ */ m("b", { children: [e.murders, " / 5"] })]
		}), /* @__PURE__ */ p("div", {
			className: "itk-victim-slots",
			children: [
				1,
				2,
				3,
				4,
				5
			].map((t) => {
				let n = e.crimes.find((e) => e.order === t);
				return /* @__PURE__ */ p(We, {
					order: t,
					card: n ? e.civilians[n.civ].card : void 0
				}, `${t}-${n?.civ ?? "empty"}`);
			})
		})]
	});
	function at(e) {
		return Ne.includes(e) && (D.includes(e) || D.length < Math.min(2, Ne.length));
	}
	function $(t) {
		e.phase === "intimidate" && x && de((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < 2 ? [...e, t] : e);
	}
	let ot = /* @__PURE__ */ p("section", {
		className: "itk-map-area",
		"aria-label": v("boardTitle"),
		children: /* @__PURE__ */ m("div", {
			className: "itk-map-sheet",
			children: [
				/* @__PURE__ */ m("header", {
					className: "itk-map-head",
					children: [/* @__PURE__ */ p("span", {
						className: "itk-map-title",
						children: v("mapTitle")
					}), /* @__PURE__ */ p("span", {
						className: "itk-map-sub",
						children: v("mapSub")
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "itk-map-body",
					children: [
						/* @__PURE__ */ m("aside", {
							className: "itk-map-margin is-left",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ p("span", {
									className: "itk-map-vert",
									children: v("mapTitle")
								}),
								/* @__PURE__ */ m("svg", {
									className: "itk-map-compass",
									viewBox: "0 0 48 48",
									children: [
										/* @__PURE__ */ p("circle", {
											cx: "24",
											cy: "24",
											r: "16",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "1.2"
										}),
										/* @__PURE__ */ p("path", {
											d: "M24 4 28 24 24 44 20 24Z",
											fill: "currentColor",
											opacity: ".75"
										}),
										/* @__PURE__ */ p("path", {
											d: "M4 24 24 20 44 24 24 28Z",
											fill: "currentColor",
											opacity: ".4"
										}),
										/* @__PURE__ */ p("text", {
											x: "24",
											y: "11",
											textAnchor: "middle",
											fontSize: "6",
											fill: "currentColor",
											children: "N"
										})
									]
								}),
								/* @__PURE__ */ p("span", {
									className: "itk-map-seal",
									children: "1962"
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							className: "itk-city",
							role: "grid",
							"aria-label": v("boardTitle"),
							children: Array.from({ length: 16 }, (t, n) => {
								let r = Oe(n), i = Ee(n), a = y[n], o = e.phase === "setup" || e.phase === "investigate" && H(e.marker).includes(n), s = [
									B(n),
									a ? Te(n) : "",
									r ? `${v("label.crimeScene")} ${r.order}` : "",
									n === e.marker ? v("label.marker") : ""
								].filter(Boolean).join(" · ");
								return /* @__PURE__ */ m("div", {
									role: "gridcell",
									tabIndex: 0,
									"aria-label": s,
									className: `itk-block${w === n ? " is-selected" : ""}${n === e.marker ? " has-marker" : ""}${r ? " has-crime" : ""}${o ? " is-target" : ""}${re.includes(n) ? " is-center" : ""}${Le.has(n) ? " is-water" : ""}${Re.has(n) ? " is-park" : ""}${ze.has(n) ? " is-plaza" : ""}`,
									onClick: () => {
										ue(n), E(null);
									},
									onKeyDown: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), ue(n), E(null));
									},
									children: [
										/* @__PURE__ */ m("div", {
											className: "itk-block-head",
											children: [/* @__PURE__ */ p("span", {
												className: "itk-district",
												children: B(n)
											}), a && /* @__PURE__ */ p("span", {
												className: `itk-building itk-building-${a}`,
												title: Te(n),
												"aria-label": Te(n),
												children: /* @__PURE__ */ p(Be, { kind: a })
											})]
										}),
										/* @__PURE__ */ m("div", {
											className: "itk-chip-row",
											children: [i.map((t) => {
												let n = _[t.card], r = x && S ? He(t.id, e, S) : !1, i = x && S && e.phase === "murder" ? De(e, S, t.id) : !1, a = e.phase === "intimidate" && x && at(t.id), o = D.includes(t.id);
												return /* @__PURE__ */ m("button", {
													type: "button",
													className: `itk-chip ${Ie[n.group]}${T === t.id ? " is-selected" : ""}${t.intimidated ? " is-intimidated" : ""}${i ? " is-hunted" : ""}${a ? " is-eligible" : ""}${o ? " is-chosen" : ""}`,
													onClick: (n) => {
														n.stopPropagation(), E(t.id), ue(t.block), x && e.phase === "intimidate" && $(t.id);
													},
													"aria-label": `${R(t.id)}${t.intimidated ? " · " + v("label.intimidated") : ""}`,
													children: [
														/* @__PURE__ */ p("img", {
															src: Fe(`civ/${String(t.card).padStart(2, "0")}.webp`),
															alt: "",
															draggable: !1
														}),
														t.intimidated && /* @__PURE__ */ p("span", {
															className: "itk-chip-x",
															"aria-hidden": !0,
															children: "✕"
														}),
														r && /* @__PURE__ */ p("span", {
															className: "itk-chip-lie",
															"aria-hidden": !0,
															children: "*"
														}),
														o && /* @__PURE__ */ p("span", {
															className: "itk-chip-pick",
															"aria-hidden": !0,
															children: "✓"
														}),
														e.surveillance === t.id && /* @__PURE__ */ p("span", {
															className: "itk-chip-surv",
															"aria-hidden": !0,
															children: "◎"
														})
													]
												}, t.id);
											}), !i.length && !r && /* @__PURE__ */ p("span", {
												className: "itk-block-empty",
												"aria-hidden": !0
											})]
										}),
										n === e.marker && /* @__PURE__ */ p("span", {
											className: "itk-marker",
											"aria-label": v("label.marker"),
											children: /* @__PURE__ */ m("svg", {
												viewBox: "0 0 24 24",
												"aria-hidden": "true",
												children: [/* @__PURE__ */ p("path", {
													d: "M12 2.2 19 5v6.2c0 4.8-2.9 8.3-7 10-4.1-1.7-7-5.2-7-10V5Z",
													fill: "currentColor",
													stroke: "#f4ead2",
													strokeWidth: "1.4",
													strokeLinejoin: "round"
												}), /* @__PURE__ */ p("circle", {
													cx: "12",
													cy: "10",
													r: "3.1",
													fill: "none",
													stroke: "#f4ead2",
													strokeWidth: "1.6"
												})]
											})
										}),
										r && /* @__PURE__ */ p("span", {
											className: "itk-crime",
											"aria-hidden": !0,
											children: /* @__PURE__ */ p("i", { children: r.order })
										})
									]
								}, n);
							})
						}),
						/* @__PURE__ */ m("aside", {
							className: "itk-map-margin is-right",
							children: [/* @__PURE__ */ p("p", {
								className: "itk-kicker",
								children: v("label.districtIndex")
							}), /* @__PURE__ */ p("ol", { children: Pe.map((e, t) => /* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p("span", { children: String(t + 1).padStart(2, "0") }), v(e)] }, e)) })]
						})
					]
				}),
				/* @__PURE__ */ m("footer", {
					className: "itk-map-foot",
					children: [/* @__PURE__ */ p("span", {
						className: "itk-legend",
						"aria-label": v("label.legend"),
						children: [
							"police",
							"diner",
							"hospital",
							"fire"
						].map((e) => /* @__PURE__ */ p("span", {
							className: `itk-legend-item itk-building-${e}`,
							title: v(`building.${e}`),
							children: /* @__PURE__ */ p(Be, { kind: e })
						}, e))
					}), /* @__PURE__ */ p("span", {
						className: "itk-scale",
						children: v("mapScale")
					})]
				})
			]
		})
	}), st = /* @__PURE__ */ m("aside", {
		className: "itk-casefile",
		children: [
			/* @__PURE__ */ m("div", {
				className: "itk-casefile-head",
				children: [/* @__PURE__ */ m("div", {
					className: "itk-casefile-title",
					children: [
						/* @__PURE__ */ p("p", {
							className: "itk-kicker",
							children: v("caseFile")
						}),
						/* @__PURE__ */ p("h2", { children: w === null ? v("boardTitle") : B(w) }),
						w !== null && y[w] && /* @__PURE__ */ p("p", {
							className: "itk-sub",
							children: Te(w)
						})
					]
				}), /* @__PURE__ */ m("div", {
					className: "itk-head-btns",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "itk-text-btn",
							onClick: () => be("notes"),
							children: v("label.questionLog")
						}),
						x && /* @__PURE__ */ p("button", {
							type: "button",
							className: "itk-text-btn is-secret",
							onClick: () => be("secret"),
							children: v("label.secret")
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "itk-icon-btn",
							onClick: () => be("log"),
							"aria-label": v("label.eventLog"),
							children: /* @__PURE__ */ p(u, { size: 17 })
						})
					]
				})]
			}),
			it("rack"),
			/* @__PURE__ */ m("div", {
				className: "itk-casefile-body",
				children: [
					G && K ? /* @__PURE__ */ m("div", {
						className: "itk-dossier",
						children: [/* @__PURE__ */ p("div", {
							className: "itk-dossier-card",
							children: /* @__PURE__ */ p(J, {
								card: G.card,
								dead: G.dead,
								intimidated: G.intimidated,
								stamp: x && G.id === S?.murdererCiv ? v("label.identity") : x && G.id === S?.poiCiv ? v("label.poi") : void 0
							})
						}, T), /* @__PURE__ */ m("div", {
							className: "itk-dossier-copy",
							children: [
								/* @__PURE__ */ p("h3", { children: R(G.id) }),
								/* @__PURE__ */ p("p", {
									className: "itk-dossier-group",
									children: z(K.group)
								}),
								/* @__PURE__ */ p("dl", {
									className: "itk-traits-list",
									children: /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: v("label.traits") }), /* @__PURE__ */ m("dd", { children: [
										v(`sex.${K.sex}`),
										" · ",
										v(`age.${K.age === 20 ? "young" : K.age === 40 ? "middle" : "senior"}`),
										" · ",
										v(`build.${K.build}`),
										" · ",
										v(`height.${K.height}`)
									] })] })
								}),
								/* @__PURE__ */ m("p", {
									className: "itk-tags",
									children: [
										G.dead && /* @__PURE__ */ p("span", {
											className: "itk-tag is-dead",
											children: v("label.dead")
										}),
										G.intimidated && /* @__PURE__ */ p("span", {
											className: "itk-tag is-intim",
											children: v("label.intimidated")
										}),
										x && S && (G.id === S.murdererCiv ? /* @__PURE__ */ p("span", {
											className: "itk-tag is-own",
											children: v("label.identity")
										}) : He(G.id, e, S) ? /* @__PURE__ */ p("span", {
											className: "itk-tag is-lie",
											children: v("label.mayLie")
										}) : /* @__PURE__ */ p("span", {
											className: "itk-tag",
											children: v("label.mustTellTruth")
										}))
									]
								}),
								x && G.id === S?.poiCiv && /* @__PURE__ */ p("p", {
									className: "itk-note",
									children: v("label.poi")
								})
							]
						})]
					}) : w === null ? /* @__PURE__ */ m("div", {
						className: "itk-brief",
						children: [
							/* @__PURE__ */ p("p", { children: Me }),
							e.phase === "investigate" && e.investigation && /* @__PURE__ */ m("div", {
								className: "itk-pips",
								children: [/* @__PURE__ */ p("span", { children: v("label.actions", { n: e.investigation.actions }) }), /* @__PURE__ */ p("span", { children: v("label.moves", { n: e.investigation.moves }) })]
							}),
							e.phase === "setup" && e.crimes.length === 0 && /* @__PURE__ */ p("p", {
								className: "itk-muted",
								children: v("boardHint")
							})
						]
					}) : /* @__PURE__ */ m("div", {
						className: "itk-roster",
						children: [Ae.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: `itk-roster-row${T === e.id ? " is-selected" : ""}`,
							onClick: () => E(e.id),
							children: [/* @__PURE__ */ p(J, {
								card: e.card,
								intimidated: e.intimidated
							}), /* @__PURE__ */ m("span", {
								className: "itk-roster-copy",
								children: [/* @__PURE__ */ p("b", { children: R(e.id) }), /* @__PURE__ */ p("small", { children: e.intimidated ? v("label.intimidated") : z(_[e.card].group) })]
							})]
						}, e.id)), !Ae.length && /* @__PURE__ */ p("p", {
							className: "itk-empty-note",
							children: v("label.emptyBlock")
						})]
					}),
					w === e.marker && lt(),
					/* @__PURE__ */ m("div", {
						className: "itk-motive-wrap",
						children: [/* @__PURE__ */ m("p", {
							className: "itk-sec-head",
							children: [/* @__PURE__ */ p("span", { children: v("label.motiveChoices") }), /* @__PURE__ */ p("i", { "aria-hidden": !0 })]
						}), /* @__PURE__ */ p("div", {
							className: "itk-motives",
							children: e.motiveChoices.map((t) => /* @__PURE__ */ p(Ue, {
								motive: t,
								selected: j === t,
								truth: !!(x && S?.motive === t),
								disabled: e.phase !== "accuse" && e.phase !== "accuseChoice",
								onPick: () => (e.phase === "accuse" || e.phase === "accuseChoice") && ye(t)
							}, t))
						})]
					})
				]
			})
		]
	}), ct = /* @__PURE__ */ m("aside", {
		className: "itk-ledger",
		"aria-label": v("caseFile"),
		children: [
			/* @__PURE__ */ m("div", {
				className: "itk-ledger-stamp",
				children: [/* @__PURE__ */ p("span", { children: v("label.roundShort") }), /* @__PURE__ */ p("strong", { children: e.round })]
			}),
			/* @__PURE__ */ m("div", {
				className: "itk-ledger-bodies",
				children: [
					/* @__PURE__ */ p("span", { children: v("label.murdersShort") }),
					/* @__PURE__ */ p("ol", {
						"aria-label": v("murders", { n: e.murders }),
						children: [
							1,
							2,
							3,
							4,
							5
						].map((t) => /* @__PURE__ */ p("li", {
							className: t <= e.murders ? "is-on" : "",
							"aria-hidden": !0
						}, t))
					}),
					/* @__PURE__ */ m("b", { children: [e.murders, " / 5"] })
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "itk-ledger-legend",
				children: [/* @__PURE__ */ p("span", {
					className: "itk-kicker",
					children: v("label.legend")
				}), /* @__PURE__ */ p("ul", { children: [
					"police",
					"diner",
					"hospital",
					"fire"
				].map((e) => /* @__PURE__ */ m("li", {
					className: `itk-building-${e}`,
					children: [/* @__PURE__ */ p(Be, { kind: e }), /* @__PURE__ */ p("span", { children: v(`building.${e}`) })]
				}, e)) })]
			}),
			/* @__PURE__ */ m("div", {
				className: "itk-ledger-log",
				children: [/* @__PURE__ */ p("span", {
					className: "itk-kicker",
					children: v("label.eventLog")
				}), /* @__PURE__ */ p("ol", { children: e.log.slice(-7).reverse().map((e, t) => {
					let n = Ze(e);
					return n ? /* @__PURE__ */ p("li", { children: n }, t) : null;
				}) })]
			})
		]
	});
	function lt() {
		return e.phase === "investigate" && t.role === "detective" && w === e.marker && Ge.length ? /* @__PURE__ */ m("div", {
			className: "itk-question-editor",
			children: [/* @__PURE__ */ m("p", {
				className: "itk-sec-head",
				children: [/* @__PURE__ */ p("span", { children: v("btn.question") }), /* @__PURE__ */ p("i", { "aria-hidden": !0 })]
			}), Ge.map((e) => /* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("span", { children: R(e) }), /* @__PURE__ */ p("select", {
				value: me[e] ?? "male",
				onChange: (t) => he((n) => ({
					...n,
					[e]: t.target.value
				})),
				children: oe.map((e) => /* @__PURE__ */ p("option", {
					value: e,
					children: V(e)
				}, e))
			})] }, e))]
		}) : null;
	}
	let ut = e.phase === "setup" && t.role === "detective" ? /* @__PURE__ */ m("div", {
		className: "itk-action-row",
		children: [/* @__PURE__ */ p("span", {
			className: "itk-action-info",
			children: w === null ? v("boardHint") : B(w)
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			disabled: w === null,
			onClick: () => w !== null && l({
				type: "placeDetective",
				block: w
			}),
			children: v("btn.placeDetective")
		})]
	}) : null, dt = e.phase === "intimidate" && x ? /* @__PURE__ */ m("div", {
		className: "itk-action-row",
		children: [/* @__PURE__ */ m("span", {
			className: "itk-action-info",
			children: [
				v("label.selected"),
				": ",
				D.length,
				" / ",
				Math.min(2, Ne.length)
			]
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			disabled: D.length !== Math.min(2, Ne.length),
			onClick: () => l({
				type: "intimidate",
				civs: D
			}),
			children: v("btn.intimidate")
		})]
	}) : null, ft = e.phase === "murder" && x ? /* @__PURE__ */ m("div", {
		className: "itk-action-row",
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			disabled: !Xe,
			onClick: () => T !== null && l({
				type: "murder",
				civ: T
			}),
			children: v("btn.murder")
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-ghost",
			onClick: () => l({ type: "refuse" }),
			children: v("btn.refuse")
		})]
	}) : null, pt = e.phase === "response" && t.role === "detective" && e.pending?.kind === "response" ? /* @__PURE__ */ m("div", {
		className: "itk-response",
		children: [e.pending.civs.map((t) => /* @__PURE__ */ m("label", {
			className: "itk-dest-row",
			children: [/* @__PURE__ */ p("span", { children: R(t) }), /* @__PURE__ */ m("select", {
				value: fe[t] ?? "",
				onChange: (e) => pe((n) => ({
					...n,
					[t]: Number(e.target.value)
				})),
				children: [
					/* @__PURE__ */ p("option", {
						value: "",
						children: v("label.chooseDestination")
					}),
					H(e.civilians[t].block).filter((e) => !ke(e) && U(e)).map((e) => /* @__PURE__ */ p("option", {
						value: e,
						children: B(e)
					}, e)),
					!H(e.civilians[t].block).some((e) => !ke(e) && U(e)) && Array.from({ length: 16 }, (e, t) => t).filter((e) => !ke(e) && U(e)).map((e) => /* @__PURE__ */ p("option", {
						value: e,
						children: B(e)
					}, e))
				]
			})]
		}, t)), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			onClick: et,
			children: v("btn.respond")
		})]
	}) : null, mt = e.phase === "answers" && x && e.pending?.kind === "answers" && S ? /* @__PURE__ */ m("div", {
		className: "itk-answers",
		children: [e.pending.asks.map((t) => {
			let n = ge[t.civ] ?? Ve(e.civilians[S.murdererCiv].card, t.q), r = He(t.civ, e, S);
			return /* @__PURE__ */ m("div", {
				className: `itk-answer-row${r ? " may-lie" : ""}`,
				children: [
					/* @__PURE__ */ m("span", {
						className: "itk-answer-name",
						children: [R(t.civ), /* @__PURE__ */ p("small", { children: v(r ? "label.mayLie" : "label.mustTellTruth") })]
					}),
					/* @__PURE__ */ p("span", {
						className: "itk-answer-q",
						children: V(t.q)
					}),
					/* @__PURE__ */ m("span", {
						className: "itk-toggle",
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							className: n ? "is-on" : "",
							onClick: () => _e((e) => ({
								...e,
								[t.civ]: !0
							})),
							children: v("label.yes")
						}), /* @__PURE__ */ p("button", {
							type: "button",
							className: n ? "" : "is-on",
							onClick: () => _e((e) => ({
								...e,
								[t.civ]: !1
							})),
							children: v("label.no")
						})]
					})
				]
			}, t.civ);
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			onClick: $e,
			children: v("btn.submit")
		})]
	}) : null, ht = e.phase === "investigate" && t.role === "detective" ? /* @__PURE__ */ m("div", {
		className: "itk-investigate",
		children: [/* @__PURE__ */ m("div", {
			className: "itk-action-row",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-primary",
					disabled: w !== e.marker || !Ge.length || (e.investigation?.actions ?? 0) <= 0,
					onClick: Qe,
					children: v("btn.question")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-ghost",
					disabled: w === null || !H(e.marker).includes(w) || (e.investigation?.moves ?? 0) <= 0,
					onClick: () => w !== null && l({
						type: "move",
						to: w
					}),
					children: v("btn.move")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-ghost",
					onClick: () => l({ type: "endTurn" }),
					children: v("btn.endTurn")
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: "itk-action-row is-tools",
			children: [
				Ke === "diner" && /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-chip-btn",
					disabled: T === null || !Y.includes(T),
					onClick: () => T !== null && l({
						type: "diner",
						civ: T,
						q: me[T] ?? "male"
					}),
					children: v("btn.diner")
				}),
				Ke === "police" && /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-chip-btn",
					disabled: T === null || !Je.includes(T),
					onClick: () => T !== null && l({
						type: "police",
						civ: T
					}),
					children: v("btn.police")
				}),
				Ke === "hospital" && /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-chip-btn",
					disabled: T === null || !Ye.includes(T),
					onClick: () => T !== null && l({
						type: "hospital",
						civ: T
					}),
					children: v("btn.hospital")
				}),
				Ke === "fire" && /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-chip-btn",
					onClick: () => l({ type: "fireStation" }),
					children: v("btn.fire")
				}),
				e.surveillance !== null && /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-chip-btn",
					onClick: () => l({
						type: "surveillance",
						civ: e.surveillance
					}),
					children: v("btn.surveillance")
				}),
				T !== null && Ke === "diner" && Y.includes(T) && /* @__PURE__ */ p("select", {
					className: "itk-inline-select",
					value: me[T] ?? "male",
					onChange: (e) => he((t) => ({
						...t,
						[T]: e.target.value
					})),
					children: oe.map((e) => /* @__PURE__ */ p("option", {
						value: e,
						children: V(e)
					}, e))
				})
			]
		})]
	}) : null, gt = (e.phase === "fire" || e.phase === "cityMurderer" || e.phase === "cityDetective") && e.pending && (e.pending.kind === "city" || e.pending.kind === "fire") && ae ? /* @__PURE__ */ m("div", {
		className: "itk-group",
		children: [
			/* @__PURE__ */ p("div", {
				className: "itk-group-head",
				children: Q ? /* @__PURE__ */ p("div", {
					className: "itk-group-list",
					children: h.filter((t) => e.civilians.some((e) => !e.dead && _[e.card].group === t)).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: O === e ? "is-on" : "",
						onClick: () => ve(e),
						children: z(e)
					}, e))
				}) : X ? /* @__PURE__ */ p("span", {
					className: "itk-action-info",
					children: z(X)
				}) : /* @__PURE__ */ p("span", {
					className: "itk-action-info",
					children: v("label.none")
				})
			}),
			X && /* @__PURE__ */ m("div", {
				className: "itk-group-rows",
				children: [Z.map((e) => /* @__PURE__ */ m("label", {
					className: "itk-dest-row",
					children: [/* @__PURE__ */ p("span", { children: R(e.id) }), /* @__PURE__ */ m("select", {
						value: k[e.id] ?? "",
						onChange: (t) => A((n) => ({
							...n,
							[e.id]: Number(t.target.value)
						})),
						children: [/* @__PURE__ */ p("option", {
							value: "",
							children: v("label.none")
						}), H(e.block).filter((e) => !ke(e) && U(e)).map((e) => /* @__PURE__ */ p("option", {
							value: e,
							children: B(e)
						}, e))]
					})]
				}, e.id)), !Z.length && /* @__PURE__ */ p("span", {
					className: "itk-muted",
					children: v("label.emptyBlock")
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "itk-action-row",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-primary",
					disabled: !(!Q || O),
					onClick: () => tt(!1),
					children: v("btn.confirm")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "itk-ghost",
					disabled: !(!Q || O),
					onClick: () => tt(!0),
					children: v("label.none")
				})]
			})
		]
	}) : null, _t = e.phase === "accuseChoice" && t.role === "detective" ? /* @__PURE__ */ p("div", {
		className: "itk-action-row",
		children: /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			onClick: () => l({ type: "continue" }),
			children: v("btn.continue")
		})
	}) : null, vt = (e.phase === "accuse" || e.phase === "accuseChoice") && t.role === "detective" ? /* @__PURE__ */ m("div", {
		className: "itk-action-row",
		children: [/* @__PURE__ */ m("span", {
			className: "itk-action-info",
			children: [
				T === null ? v("btn.choose") : R(T),
				" · ",
				j ? we(j) : v("btn.choose")
			]
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "itk-primary",
			disabled: T === null || !j || e.civilians[T].dead,
			onClick: () => T !== null && j && l({
				type: "accuse",
				civ: T,
				motive: j
			}),
			children: v("btn.accuse")
		})]
	}) : null, yt = /* @__PURE__ */ p("div", {
		className: "itk-actions",
		children: /* @__PURE__ */ m("div", {
			className: "itk-actions-inner",
			children: [
				ut,
				dt,
				ft,
				pt,
				mt,
				ht,
				gt,
				_t,
				vt,
				!(ut || dt || ft || pt || mt || ht || gt || _t || vt) && /* @__PURE__ */ p("p", {
					className: "itk-wait",
					children: e.phase === "done" ? v("prompt.done") : v("prompt.waiting")
				})
			]
		})
	}), bt = N ? /* @__PURE__ */ p("div", {
		className: "itk-toast",
		role: "status",
		children: N
	}) : null;
	return /* @__PURE__ */ m(te, { children: [/* @__PURE__ */ p(ee, {
		actionsHeight: "h-32 itk-actions-slot",
		banner: /* @__PURE__ */ m("div", {
			className: "itk-banner",
			children: [/* @__PURE__ */ p(f, {
				tone: je,
				text: Me,
				sub: e.phase === "done" ? v("result.reveal", {
					civ: e.reveal ? R(e.reveal.civ) : "",
					motive: e.reveal ? we(e.reveal.motive) : ""
				}) : ae ? `${le?.name ?? ""}` : `${C?.name ?? ""}`,
				chip: `${v("round", { n: e.round })} · ${v("murders", { n: e.murders })}`,
				accent: ce.accent
			}), /* @__PURE__ */ p(d, {
				members: a,
				myRid: c,
				variant: "plate",
				status: (t) => /* @__PURE__ */ p("span", {
					className: "itk-role-tag",
					children: v(`role.${e.roles[t]}`)
				}),
				action: (t) => e.phase === "done" ? null : e.turn === t ? "pending" : null
			})]
		}),
		actions: yt,
		overlay: bt,
		children: /* @__PURE__ */ m("div", {
			className: `itk-stage is-${e.phase}`,
			children: [
				ct,
				ot,
				st,
				F && /* @__PURE__ */ p("span", {
					className: "itk-flash",
					"aria-hidden": !0
				})
			]
		})
	}), /* @__PURE__ */ m(o, {
		open: rt,
		label: nt,
		title: nt,
		onClose: () => be(null),
		children: [
			M === "log" && /* @__PURE__ */ p("ol", {
				className: "itk-sheet-log",
				children: e.log.slice().reverse().map((e, t) => {
					let n = Ze(e);
					return n ? /* @__PURE__ */ p("li", { children: n }, t) : null;
				})
			}),
			M === "notes" && /* @__PURE__ */ p(qe, {
				pub: e,
				nameOfCiv: R,
				questionName: V
			}),
			M === "secret" && S && /* @__PURE__ */ m("div", {
				className: "itk-secret",
				children: [
					/* @__PURE__ */ m("div", {
						className: "itk-secret-block",
						children: [
							/* @__PURE__ */ p("p", {
								className: "itk-kicker",
								children: v("label.identity")
							}),
							/* @__PURE__ */ p(J, {
								card: e.civilians[S.murdererCiv].card,
								stamp: v("label.identity")
							}),
							/* @__PURE__ */ p("p", { children: R(S.murdererCiv) })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "itk-secret-block",
						children: [
							/* @__PURE__ */ p("p", {
								className: "itk-kicker",
								children: v("label.poi")
							}),
							/* @__PURE__ */ p(J, {
								card: e.civilians[S.poiCiv].card,
								stamp: v("label.poi")
							}),
							/* @__PURE__ */ p("p", { children: R(S.poiCiv) })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "itk-secret-copy",
						children: [
							/* @__PURE__ */ m("p", { children: [/* @__PURE__ */ p("span", { children: v("label.supporters") }), z(S.supporters)] }),
							/* @__PURE__ */ m("p", { children: [/* @__PURE__ */ p("span", { children: v("label.drawnGroups") }), S.drawnGroups.map(z).join(v("label.listSep")) || v("label.none")] }),
							/* @__PURE__ */ m("div", {
								className: "itk-secret-motive",
								children: [/* @__PURE__ */ p("p", {
									className: "itk-kicker",
									children: v("label.motiveChoices")
								}), /* @__PURE__ */ p(Ue, {
									motive: S.motive,
									truth: !0
								})]
							})
						]
					})
				]
			})
		]
	})] });
}
function qe({ pub: e, nameOfCiv: t, questionName: n }) {
	let r = s("intenttokill");
	return e.questionLog.length ? /* @__PURE__ */ p("ul", {
		className: "itk-notes",
		children: e.questionLog.slice().reverse().map((e, i) => /* @__PURE__ */ m("li", { children: [
			/* @__PURE__ */ p("span", { children: t(e.civ) }),
			/* @__PURE__ */ p("em", { children: n(e.q) }),
			/* @__PURE__ */ p("b", {
				className: e.answer ? "is-yes" : "is-no",
				children: e.answer ? r("label.yes") : r("label.no")
			})
		] }, i))
	}) : /* @__PURE__ */ p("p", {
		className: "itk-empty-note",
		children: r("label.none")
	});
}
//#endregion
//#region src/game/bot.ts
var Je = (e) => {
	let t = 2166136261;
	for (let n = 0; n < e.length; n += 1) t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
	return t >>> 0;
}, Y = (e, t) => e[Je(t) % e.length], Ye = (e, t) => {
	let n = [...e];
	for (let e = n.length - 1; e > 0; --e) {
		let r = Je(`${t}:${e}`) % (e + 1);
		[n[e], n[r]] = [n[r], n[e]];
	}
	return n;
}, Xe = (e, t) => {
	let n = _[e];
	switch (t) {
		case "male": return n.sex === "male";
		case "female": return n.sex === "female";
		case "young": return n.age === 20;
		case "middle": return n.age === 40;
		case "senior": return n.age === 60;
		case "thin": return n.build === "S";
		case "mediumBuild": return n.build === "M";
		case "heavy": return n.build === "L";
		case "tall": return n.height === "tall";
		case "mediumHeight": return n.height === "medium";
		case "short": return n.height === "short";
	}
}, X = (e) => _[e].group, Z = (e) => e.civilians.filter((e) => !e.dead), Q = (e, t) => e.civilians.filter((e) => !e.dead && e.block === t), Ze = (e, t) => e.crimes.some((e) => e.block === t);
function Qe(e) {
	let t = Z(e).map((e) => e.card), n = "male", r = Infinity;
	for (let e of oe) {
		let i = t.filter((t) => Xe(t, e)).length, a = Math.abs(i - t.length / 2);
		a < r && (r = a, n = e);
	}
	return n;
}
function $e(e, t, n) {
	return Q(e, t).length + (n.get(t) ?? 0) < 3;
}
function et(e, t, n) {
	let r = e.civilians[n], i = _[r.card], a = 0;
	if (t.motive === "spy" && y[r.block] && (a += 2), t.motive === "killer" && Q(e, r.block).length === 1 && (a += 1.5), t.motive === "terrorist" && (a += e.crimes.some((t) => X(e.civilians[t.civ].card) === i.group) ? -2 : 1), t.motive === "maniac" && e.crimes.length && (a += (X(e.civilians[e.crimes[0].civ].card), i.group, 0)), t.motive === "psychopath") {
		let t = new Set(e.crimes.map((t) => _[e.civilians[t.civ].card].age));
		t.add(i.age), a += t.size <= 2 ? 1 : -3;
	}
	if (t.motive === "radical") {
		let t = e.crimes.filter((t) => X(e.civilians[t.civ].card) === i.group).length;
		a += t * .5;
	}
	if (t.motive === "cultist" && n === t.poiCiv && (a += 3), t.motive === "cannibal") {
		let t = new Set(e.crimes.map((t) => _[e.civilians[t.civ].card].build));
		a += t.has(i.build) ? .2 : 1;
	}
	return a -= b[e.marker].includes(r.block) ? .2 : 0, a;
}
function tt(e, t, n) {
	if (e.phase === "intimidate") {
		let t = Z(e).filter((t) => t.block !== e.marker).map((e) => e.id), r = Math.min(2, t.length);
		return {
			type: "intimidate",
			civs: Ye(t, `${e.round}:intimidate:${n.rid}`).slice(0, r)
		};
	}
	if (e.phase === "murder") {
		let r = Z(e).filter((n) => n.id !== t.murdererCiv && De(e, t, n.id));
		if (!r.length) return { type: "refuse" };
		if (n.difficulty === "weak") return {
			type: "murder",
			civ: Y(r, `${e.round}:weak`).id
		};
		let i = r.map((n) => ({
			id: n.id,
			score: et(e, t, n.id)
		}));
		return i.sort((e, t) => t.score - e.score || e.id - t.id), {
			type: "murder",
			civ: i[0].id
		};
	}
	if (e.phase === "answers" && e.pending?.kind === "answers") {
		let n = e.civilians[t.murdererCiv].card;
		return {
			type: "answer",
			answers: e.pending.asks.map((r) => {
				let i = e.civilians[r.civ].card, a = Xe(n, r.q);
				return r.civ !== t.murdererCiv && r.civ !== t.poiCiv && X(i) !== t.supporters ? a : r.civ === t.murdererCiv || r.civ === t.poiCiv || Je(`${e.round}:${r.civ}:${r.q}`) % 10 < 6 ? !a : a;
			})
		};
	}
	return e.phase === "cityMurderer" && e.pending && (e.pending.kind === "city" || e.pending.kind === "fire") ? nt(e, n.rid) : { type: "endTurn" };
}
function nt(e, t) {
	let n = e.pending;
	if (!n || n.kind !== "city" && n.kind !== "fire") return { type: "endTurn" };
	if (n.choose) {
		let n = h.filter((t) => Z(e).some((e) => X(e.card) === t));
		return {
			type: "moveGroup",
			group: n.length ? Y(n, `${e.round}:group:${t}`) : void 0,
			moves: []
		};
	}
	return {
		type: "moveGroup",
		group: n.group ?? void 0,
		moves: []
	};
}
function rt(e, t) {
	let n = Z(e).map((t) => ({
		civ: t.id,
		bad: e.questionLog.reduce((e, n) => e + (Xe(t.card, n.q) === n.answer ? 0 : 1), 0)
	})).sort((e, t) => e.bad - t.bad || e.civ - t.civ), r = e.crimes.map((e) => e.civ).map((t) => _[e.civilians[t].card]), i = (t) => {
		let n = 0;
		if (t === "cutthroat" && (n += r.every((t, n) => !re.includes(e.crimes[n].block)) ? 1 : -4), t === "spy" && (n += r.every((t, n) => y[e.crimes[n].block]) ? 1 : -4), t === "maniac" && (n += new Set(r.map((e) => e.sex)).size === 1 ? 1 : -4), t === "terrorist" && (n += new Set(r.map((e) => e.group)).size === r.length ? 1 : -4), t === "psychopath" && (n += new Set(r.map((e) => e.age)).size <= 2 ? 1 : -4), t === "radical") {
			let e = /* @__PURE__ */ new Map();
			for (let t of r) e.set(t.group, (e.get(t.group) ?? 0) + 1);
			n += Math.max(0, ...e.values()) >= 3 ? 1 : -1;
		}
		return t === "sadist" && (n += 0), n;
	}, a = [...e.motiveChoices].sort((e, t) => i(t) - i(e) || e.localeCompare(t))[0], o = n[0], s = o ? n.filter((e) => e.bad === o.bad) : [];
	return {
		type: "accuse",
		civ: s.length ? Y(s, `${e.round}:accuse:${t.rid}`).civ : 0,
		motive: a
	};
}
function it(e, t) {
	if (e.phase === "setup") return {
		type: "placeDetective",
		block: Y(re, `${t.rid}:setup`)
	};
	if (e.phase === "response" && e.pending?.kind === "response") {
		let t = /* @__PURE__ */ new Map(), n = [];
		for (let r of e.pending.civs) {
			let i = b[e.civilians[r].block].filter((n) => !Ze(e, n) && $e(e, n, t)), a = Array.from({ length: 16 }, (e, t) => t).filter((n) => !Ze(e, n) && $e(e, n, t)), o = i[0] ?? a[0];
			o !== void 0 && (t.set(o, (t.get(o) ?? 0) + 1), n.push({
				civ: r,
				to: o
			}));
		}
		return {
			type: "respond",
			moves: n
		};
	}
	if (e.phase === "investigate" && e.investigation) {
		let n = e.investigation, r = Q(e, e.marker).filter((e) => !e.intimidated);
		if (n.actions > 0 && !n.used.includes("question") && r.length) {
			let t = Qe(e);
			return {
				type: "question",
				block: e.marker,
				asks: r.map((e) => ({
					civ: e.id,
					q: t
				}))
			};
		}
		if (n.actions > 0 && y[e.marker] === "hospital" && !n.used.includes("hospital")) {
			let t = e.civilians.find((t) => !t.dead && t.intimidated && (t.block === e.marker || b[e.marker].includes(t.block)));
			if (t) return {
				type: "hospital",
				civ: t.id
			};
		}
		if (n.actions > 0 && y[e.marker] === "diner" && !n.used.includes("diner")) {
			let t = e.civilians.find((t) => !t.dead && !t.intimidated && (t.block === e.marker || b[e.marker].includes(t.block)));
			if (t) return {
				type: "diner",
				civ: t.id,
				q: Qe(e)
			};
		}
		if (n.actions > 0 && y[e.marker] === "police" && !n.used.includes("police")) {
			let t = e.civilians.find((t) => !t.dead && (t.block === e.marker || b[e.marker].includes(t.block)));
			if (t) return {
				type: "police",
				civ: t.id
			};
		}
		return n.moves > 0 ? {
			type: "move",
			to: Y(b[e.marker].filter((t) => !Ze(e, t) || !0), `${e.round}:move:${t.rid}:${n.moves}`)
		} : { type: "endTurn" };
	}
	return e.phase === "fire" || e.phase === "cityDetective" ? nt(e, t.rid) : e.phase === "accuseChoice" ? e.round >= 5 ? rt(e, t) : { type: "continue" } : e.phase === "accuse" ? rt(e, t) : { type: "endTurn" };
}
var at = (e, t) => {
	let n = e.public, r = e.private;
	return !r || n.phase === "done" ? null : r.role === "murderer" ? n.turn === t.rid ? { action: tt(n, r.secret, t) } : null : r.role === "detective" ? n.phase !== "setup" && n.turn !== t.rid ? null : { action: it(n, t) } : null;
}, $ = (e) => e, ot = (e, t, n) => {
	switch (e.type) {
		case "placeDetective": return n($("games.intenttokill.btn.placeDetective"));
		case "intimidate": return n($("games.intenttokill.btn.intimidate"));
		case "murder": return n($("games.intenttokill.btn.murder"));
		case "refuse": return n($("games.intenttokill.btn.refuse"));
		case "respond": return n($("games.intenttokill.btn.respond"));
		case "question": return n($("games.intenttokill.btn.question"));
		case "diner": return n($("games.intenttokill.btn.diner"));
		case "police": return n($("games.intenttokill.btn.police"));
		case "hospital": return n($("games.intenttokill.btn.hospital"));
		case "fireStation": return n($("games.intenttokill.btn.fire"));
		case "move": return n($("games.intenttokill.btn.move"));
		case "surveillance": return n($("games.intenttokill.btn.surveillance"));
		case "answer": return n($("games.intenttokill.btn.submit"));
		case "moveGroup": return n($("games.intenttokill.btn.confirm"));
		case "endTurn": return n($("games.intenttokill.btn.endTurn"));
		case "accuse": return n($("games.intenttokill.btn.accuse"));
		case "continue": return n($("games.intenttokill.btn.continue"));
		default: return "";
	}
}, st = (e) => e.replace("games.intenttokill.", "");
function ct(e) {
	let t = s("intenttokill"), n = c(), r = e.public, i = r.reveal, a = (e) => r.civilians[e] ? t(st(_[r.civilians[e].card].nameKey)) : "", o = i ? t(st(ie[i.motive])) : "", l = i ? t(st(ae[i.motive])) : "", u = r.winReason === "detective" || r.winReason === "secondRefusal", ee = [
		1,
		2,
		3,
		4,
		5
	].map((e) => {
		let t = r.crimes.find((t) => t.order === e);
		return {
			order: e,
			card: t ? r.civilians[t.civ]?.card : void 0
		};
	}), f = e.onPlayAgain ?? e.onBackToLobby;
	return /* @__PURE__ */ p("div", {
		className: "itk-result",
		children: /* @__PURE__ */ m("div", {
			className: "itk-result-sheet",
			children: [
				/* @__PURE__ */ m("header", {
					className: "itk-result-masthead",
					children: [
						/* @__PURE__ */ m("span", {
							className: "itk-kicker",
							children: [
								t("result.caseClosed"),
								" · ",
								t("result.finalRound", { n: r.round })
							]
						}),
						/* @__PURE__ */ p("h1", { children: t(u ? "result.detectiveWin" : "result.murdererWin") }),
						/* @__PURE__ */ m("p", {
							className: "itk-result-verdict",
							children: [/* @__PURE__ */ p("span", {
								className: "itk-result-verdict-label",
								children: t("result.verdict")
							}), t(u ? "result.verdictOk" : "result.verdictBad")]
						}),
						r.winReason === "secondRefusal" && /* @__PURE__ */ p("p", {
							className: "itk-result-reason",
							children: t("result.secondRefusal")
						}),
						/* @__PURE__ */ p("span", {
							className: "itk-result-stamp",
							"aria-hidden": !0,
							children: t("result.caseClosed")
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "itk-result-grid",
					children: [
						/* @__PURE__ */ m("section", {
							className: "itk-result-truth",
							children: [/* @__PURE__ */ p("p", {
								className: "itk-kicker",
								children: t("result.truth")
							}), i && /* @__PURE__ */ m("div", {
								className: "itk-result-truth-row",
								children: [/* @__PURE__ */ m("div", {
									className: "itk-result-person",
									children: [
										/* @__PURE__ */ p(J, {
											card: r.civilians[i.civ].card,
											stamp: t("result.murdererLabel")
										}),
										/* @__PURE__ */ p("b", { children: a(i.civ) }),
										/* @__PURE__ */ p("span", { children: t("role.murderer") })
									]
								}), /* @__PURE__ */ m("div", {
									className: "itk-result-motive",
									children: [/* @__PURE__ */ p(Ue, {
										motive: i.motive,
										truth: !0,
										disabled: !0
									}), /* @__PURE__ */ m("div", {
										className: "itk-result-motive-copy",
										children: [
											/* @__PURE__ */ p("span", {
												className: "itk-kicker",
												children: t("result.motiveLabel")
											}),
											/* @__PURE__ */ p("b", { children: o }),
											/* @__PURE__ */ p("p", { children: l })
										]
									})]
								})]
							})]
						}),
						/* @__PURE__ */ m("section", {
							className: "itk-result-victims",
							children: [/* @__PURE__ */ p("p", {
								className: "itk-kicker",
								children: t("result.victimOrder")
							}), /* @__PURE__ */ p("div", {
								className: "itk-result-victim-row",
								children: ee.map(({ order: e, card: t }) => /* @__PURE__ */ m("div", {
									className: `itk-result-victim${t === void 0 ? " is-empty" : ""}`,
									children: [/* @__PURE__ */ p("span", {
										className: "itk-result-victim-no",
										children: e
									}), t === void 0 ? /* @__PURE__ */ p("span", {
										className: "itk-result-victim-empty",
										"aria-hidden": !0
									}) : /* @__PURE__ */ p(J, {
										card: t,
										dead: !0
									})]
								}, e))
							})]
						}),
						/* @__PURE__ */ m("section", {
							className: "itk-result-players",
							children: [
								/* @__PURE__ */ p("p", {
									className: "itk-kicker",
									children: t("result.players")
								}),
								/* @__PURE__ */ p(d, {
									members: e.members,
									myRid: e.myRid,
									variant: "plate",
									status: (e) => /* @__PURE__ */ p("span", {
										className: "itk-role-tag",
										children: t(`role.${r.roles[e]}`)
									}),
									action: (e) => r.winner === e ? "pending" : null
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ p("p", {
									className: "itk-result-hints",
									children: n("session.hint.usedCount", { n: e.hintCount })
								})
							]
						})
					]
				}),
				f ? /* @__PURE__ */ m("div", {
					className: "itk-result-actions",
					children: [e.onPlayAgain && /* @__PURE__ */ p("button", {
						type: "button",
						className: "itk-result-btn",
						style: { background: ce.accent },
						onClick: e.onPlayAgain,
						children: n("session.result.playAgain")
					}), e.onBackToLobby && /* @__PURE__ */ p("button", {
						type: "button",
						className: "itk-result-back",
						onClick: e.onBackToLobby,
						children: n("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "itk-result-wait",
					children: n("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/index.tsx
var lt = {
	definition: Ne,
	View: Ge,
	bot: at,
	describe: ot,
	OverView: ct,
	locales: {
		zh: {
			name: "暗藏杀机",
			desc: "在 1960 年代美国城市中，一名连环杀手与一名警探围绕五起命案展开的推理对决。",
			rules: "目标:\n· 一名玩家扮演凶手，另一名玩家扮演警探。凶手必须在隐藏身份与动机的同时杀死 5 名平民；警探必须在第 5 起命案发生后指出凶手及其真实动机。\n· 警探同时指出正确的凶手和动机时警探获胜；任一项错误则凶手获胜。\n\n准备:\n· 从 54 名平民中随机抽取 20 名。四个角落街区各放 2 名平民，其余 12 个街区各放 1 名平民。每个街区最多容纳 3 名平民。\n· 凶手随机指定其中 1 名平民作为自己，再指定另 1 名作为目标人物，并记录两者的特征。凶手与目标人物的身份不向警探公开。\n· 从 12 种动机中随机选出 6 种作为本局可能的动机，放在双方可见的位置；凶手从中秘密抽取 1 种作为真实动机。\n· 凶手秘密抽取 3 个社会群体标记，其中 1 个是支持者群体；另外 2 个放回盒中。剩余 6 个社会群体标记组成抽签堆。\n· 警探把侦探标记放在任意街区，并获得监视标记。随后开始第 1 轮。\n\n流程:\n· 每轮依次进行凶手阶段、警探阶段和城市阶段。第 5 起命案发生的轮次是最后一轮。\n\n凶手阶段:\n· 恐吓:凶手选择 2 名不在侦探标记所在街区的平民，将其翻为黑白面。被恐吓的平民不能被警探审问。若可选平民不足 2 名，则恐吓所有可选平民。\n· 行凶:凶手选择 1 名符合真实动机的平民杀害。受害者不能是凶手本人，不能与侦探标记位于同一街区，也不能位于已有犯罪现场的街区。\n· 凶手把对应序号的犯罪现场卡放到受害者所在街区，再把受害者卡移到受害者区。被杀害的平民离开城市。\n· 凶手每局可以拒绝行凶一次；拒绝后本轮不进行行凶，恐吓结束后直接进入警探阶段，本局延长到 6 轮。第二次拒绝行凶时，凶手立即失败。\n\n警探阶段:\n· 初步响应:警探把侦探标记移到新的犯罪现场街区，并把该街区内的其他平民移到相邻街区。若没有相邻空位，可以移到城市中任意有空位的街区。平民不能进入犯罪现场。\n· 调查:警探获得 2 个行动和 2 个移动点。行动可以用于审问平民、使用当前街区的建筑，或执行其他调查动作；每种行动每轮最多使用一次。移动点可以在行动前后使用，每点移动到相邻街区。未使用的行动和移动点不会保留到下一轮。\n· 审问:警探可以审问当前街区中所有未被恐吓的平民，每名平民回答 1 个问题。问题只能询问凶手的性别、年龄、体型或身高。凶手对每名被审问的平民分别回答“是”或“否”。若被审问的平民是凶手本人、目标人物或支持者群体的成员，凶手可以撒谎；其他平民必须如实回答。\n· 警察局:若侦探标记所在街区有警察局，警探可以把监视标记放到当前或相邻街区的 1 名平民身上；若监视标记已在某名平民身上，则改为移动它。\n· 餐馆:若侦探标记所在街区有餐馆，警探可以审问当前或相邻街区的 1 名未被恐吓的平民，并询问 1 个问题。\n· 医院:若侦探标记所在街区有医院，警探可以安抚当前或相邻街区的 1 名被恐吓平民，将其翻回彩色面。\n· 消防站:若侦探标记所在街区有消防站，警探从社会群体抽签堆随机抽取 1 个标记，然后可以把该群体的每名平民移动一次到相邻街区。抽取后把该标记放回抽签堆。\n· 监视:警探可以随时移除监视标记，并询问凶手：“你现在能杀害这名平民吗？”凶手必须根据真实动机如实回答。若目标平民是凶手本人，或与侦探标记位于同一街区，答案必定为“否”。监视不消耗行动，也不属于审问。若凶手杀害了带有监视标记的平民，监视标记回到警探手中，等同于对同一问题回答了“是”。\n\n城市阶段:\n· 安抚:警探标记所在街区中的被恐吓平民翻回彩色面。\n· 凶手先从社会群体抽签堆随机抽取 1 个标记，并可以向相邻街区移动该群体的每名平民一次。随后警探抽取 1 个标记，并以同样方式移动该群体的平民。抽出的标记在使用后放回抽签堆。\n· 若抽到的社会群体在城市中没有平民，抽签者可以选择任意一个仍有平民的社会群体来移动；该抽取标记放入盒中，不再返回抽签堆。\n\n结束:\n· 第 5 起命案发生的轮次结束后，警探必须指出 1 名平民作为凶手，并从 6 种可能动机中指出 1 种作为真实动机。两项都正确时警探获胜，否则凶手获胜。\n· 从第 3 轮结束起，警探可以在每轮结束时提前指认；提前指认错误时凶手立即获胜。若凶手拒绝过一次行凶，本局在第 6 轮结束后必须进行指认。\n\n动机:\n· 心理变态:所有受害者的年龄最多只能有两种不同取值。\n· 冷血屠夫:不能在城市的 4 个中央街区行凶。\n· 间谍:所有受害者都必须在带有建筑的街区遇害。\n· 食人魔:5 名受害者中必须包含瘦削、中等和魁梧三种体型。\n· 地下判官:不能杀害侦探标记周围 8 个街区内的任何人。侦探标记位于城市边缘时，受限街区会减少。\n· 激进分子:至少 3 名受害者必须属于同一个社会群体。\n· 狂热信徒:第 1 名受害者必须与目标人物的社会群体不同；每名受害者都必须与上一名受害者的社会群体不同；5 名受害者中必须包含目标人物。\n· 职业杀手:只能杀害独自位于一个街区的平民。\n· 施虐狂:不能杀害被恐吓的平民。\n· 恐怖分子:所有受害者必须属于不同的社会群体。\n· 疯子:所有受害者必须是同一性别。\n· 劫匪:不能杀害与上一个犯罪现场相邻的街区中的任何人。",
			role: {
				detective: "警探",
				murderer: "凶手"
			},
			phase: {
				setup: "选择起始街区",
				intimidate: "凶手恐吓平民",
				murder: "凶手选择受害者",
				response: "警探赶往现场",
				investigate: "警探调查",
				answers: "凶手回答问题",
				fire: "消防站行动",
				cityMurderer: "城市阶段 · 凶手移动",
				cityDetective: "城市阶段 · 警探移动",
				accuseChoice: "是否提前指认",
				accuse: "最终指认",
				done: "对局结束"
			},
			you: "你",
			opponent: "对手",
			round: "第 {{n}} 轮",
			murders: "命案 {{n}} / 5",
			caseFile: "案件卷宗",
			mapTitle: "城市命案地图",
			mapSub: "警务处 · 1962 年档案",
			mapScale: "比例 1:12000 · 城市制图处",
			boardTitle: "城市街区",
			boardHint: "点击街区查看平民与可用行动",
			district: {
				rockyhall: "洛基厅",
				docks: "码头区",
				littleitaly: "小意大利",
				goldenbeach: "黄金海滩",
				westside: "西区",
				businesscenter: "商业中心",
				presidentsquare: "总统广场",
				eastside: "东区",
				chinatown: "唐人街",
				centralpark: "中央公园",
				santacruz: "圣克鲁斯",
				riverstation: "河站",
				stadium: "体育场",
				richmond: "里士满",
				universitycampus: "大学城",
				oldcity: "老城"
			},
			building: {
				police: "警察局",
				diner: "餐馆",
				hospital: "医院",
				fire: "消防站"
			},
			group: {
				authority: "执法部门",
				press: "新闻界",
				outcasts: "边缘人",
				medicine: "医疗界",
				government: "政界",
				labor: "劳工",
				criminals: "犯罪集团",
				jetset: "名流圈",
				immigrants: "移民"
			},
			civ: {
				actress: "女演员",
				secretagent: "特工",
				artist: "艺术家",
				bartender: "酒保",
				ballplayer: "棒球手",
				beggar: "乞丐",
				bouncer: "保镖",
				greaser: "机车手",
				catlady: "猫夫人",
				congressman: "国会议员",
				coroner: "验尸官",
				showgirl: "歌舞女郎",
				newscaster: "新闻主播",
				dispatcher: "调度员",
				mafiadon: "黑手党首领",
				busdriver: "公交司机",
				pharmacist: "药剂师",
				benefactor: "慈善家",
				fireman: "消防员",
				photographer: "摄影师",
				gangster: "黑帮分子",
				icecreamman: "冰淇淋小贩",
				informant: "线人",
				deputy: "副警长",
				reporter: "记者",
				judge: "法官",
				lawyer: "律师",
				librarian: "图书管理员",
				lobbyist: "说客",
				navysailor: "海军水兵",
				mayor: "市长",
				musician: "音乐家",
				psychic: "灵媒",
				nun: "修女",
				nurse: "护士",
				paperboy: "报童",
				patrolman: "巡警",
				ambassador: "大使",
				mailwoman: "女邮差",
				professor: "教授",
				stateattorney: "州检察官",
				psychiatrist: "精神科医生",
				editor: "编辑",
				restaurateur: "餐馆老板",
				orderly: "医院勤杂工",
				secretary: "秘书",
				fence: "销赃者",
				cabincrew: "空乘",
				surgeon: "外科医生",
				riveter: "铆工",
				veterinarian: "兽医",
				veteran: "退伍军人",
				waitress: "女服务员",
				warwidow: "战争遗孀"
			},
			sex: {
				male: "男性",
				female: "女性"
			},
			age: {
				young: "20 岁",
				middle: "40 岁",
				senior: "60 岁"
			},
			build: {
				S: "瘦削",
				M: "中等",
				L: "魁梧"
			},
			height: {
				short: "矮小",
				medium: "中等",
				tall: "高挑"
			},
			motive: {
				psychopath: {
					name: "心理变态",
					text: "所有受害者的年龄最多只能有两种不同取值。"
				},
				cutthroat: {
					name: "冷血屠夫",
					text: "不能在城市的 4 个中央街区行凶。"
				},
				spy: {
					name: "间谍",
					text: "所有受害者都必须在带有建筑的街区遇害。"
				},
				cannibal: {
					name: "食人魔",
					text: "5 名受害者中必须包含瘦削、中等和魁梧三种体型。"
				},
				vigilante: {
					name: "地下判官",
					text: "不能杀害侦探标记周围 8 个街区内的任何人。侦探标记位于城市边缘时，受限街区会减少。"
				},
				radical: {
					name: "激进分子",
					text: "至少 3 名受害者必须属于同一个社会群体。"
				},
				cultist: {
					name: "狂热信徒",
					text: "第 1 名受害者必须与目标人物的社会群体不同；每名受害者都必须与上一名受害者的社会群体不同；5 名受害者中必须包含目标人物。"
				},
				killer: {
					name: "职业杀手",
					text: "只能杀害独自位于一个街区的平民。"
				},
				sadist: {
					name: "施虐狂",
					text: "不能杀害被恐吓的平民。"
				},
				terrorist: {
					name: "恐怖分子",
					text: "所有受害者必须属于不同的社会群体。"
				},
				maniac: {
					name: "疯子",
					text: "所有受害者必须是同一性别。"
				},
				robber: {
					name: "劫匪",
					text: "不能杀害与上一个犯罪现场相邻的街区中的任何人。"
				}
			},
			q: {
				male: "凶手是男性吗？",
				female: "凶手是女性吗？",
				young: "凶手是 20 岁的年轻人吗？",
				middle: "凶手是 40 岁的中年人吗？",
				senior: "凶手是 60 岁的老年人吗？",
				thin: "凶手体型瘦削吗？",
				mediumBuild: "凶手体型中等吗？",
				heavy: "凶手体型魁梧吗？",
				tall: "凶手身材高挑吗？",
				mediumHeight: "凶手身材中等吗？",
				short: "凶手身材矮小吗？"
			},
			label: {
				victimArea: "受害者区",
				crimeScene: "犯罪现场",
				marker: "侦探标记",
				surveillance: "监视标记",
				motiveChoices: "本局可能的动机",
				socialStack: "社会群体抽签堆",
				actions: "行动 {{n}}",
				moves: "移动点 {{n}}",
				secret: "你的秘密",
				identity: "你的身份",
				traits: "特征",
				poi: "目标人物",
				supporters: "支持者群体",
				drawnGroups: "已抽取的社会群体",
				questionLog: "审问记录",
				eventLog: "事件记录",
				dead: "已遇害",
				intimidated: "被恐吓",
				normal: "正常",
				emptyBlock: "此街区没有平民",
				selected: "已选",
				none: "无",
				hidden: "未知",
				yes: "是",
				no: "否",
				mustTellTruth: "必须如实回答",
				mayLie: "可以撒谎",
				chooseDestination: "选择目的地",
				chooseGroup: "选择社会群体",
				yearsShort: "岁",
				victimSlot: "第 {{n}} 位受害者",
				victimSlotShort: "待发现",
				roundShort: "轮次",
				murdersShort: "命案",
				legend: "地标图例",
				districtIndex: "街区索引",
				listSep: "、"
			},
			btn: {
				placeDetective: "在此街区开始",
				intimidate: "恐吓所选平民",
				murder: "杀害此人",
				refuse: "拒绝行凶",
				respond: "赶往现场",
				question: "审问本街区",
				diner: "餐馆审问",
				police: "放置监视",
				hospital: "安抚平民",
				fire: "消防站行动",
				move: "移动侦探",
				surveillance: "使用监视",
				endTurn: "结束调查",
				accuse: "指认",
				continue: "继续下一轮",
				confirm: "确认",
				cancel: "取消",
				close: "关闭",
				back: "返回",
				useAction: "使用行动",
				choose: "选择",
				submit: "提交",
				selectAll: "全选",
				clear: "清空"
			},
			prompt: {
				setup: "选择侦探标记的起始街区。",
				intimidate: "选择 2 名不在侦探标记所在街区的平民进行恐吓。",
				murder: "选择 1 名符合动机的平民杀害，或拒绝行凶。",
				response: "为犯罪现场街区内的平民选择相邻目的地。",
				investigate: "使用 2 个行动和 2 个移动点调查，完成后结束调查。",
				answers: "凶手正在回答审问。",
				yourAnswers: "逐条回答警探的问题。",
				fire: "移动抽到的社会群体中的平民，每名平民最多移动一次。",
				cityMurderer: "抽取社会群体标记，并移动该群体的平民。",
				cityDetective: "抽取社会群体标记，并移动该群体的平民。",
				accuseChoice: "你可以继续下一轮，或现在指认凶手与动机。",
				accuse: "指认凶手与真实动机。",
				done: "对局结束。",
				waiting: "等待对手操作。"
			},
			log: {
				round: "第 {{n}} 轮开始。",
				intimidate: "凶手恐吓了 {{a}} 和 {{b}}。",
				murder: "{{a}} 在{{b}}遇害。",
				refuse: "凶手拒绝行凶。",
				question: "警探审问了 {{a}}：{{b}}",
				answer: "{{a}} 回答：{{b}}。",
				surveillance: "监视 {{a}}：凶手回答 {{b}}。",
				move: "侦探移动到{{a}}。",
				comfort: "警探安抚了 {{n}} 名平民。",
				city: "城市阶段：{{a}}。",
				groupMove: "{{a}} 群体移动了 {{n}} 名平民。",
				accuse: "警探指认 {{a}} 为凶手。",
				win: "对局结束。",
				system: ""
			},
			result: {
				caseClosed: "案件归档",
				finalRound: "第 {{n}} 轮结束",
				truth: "真相",
				victimOrder: "命案顺序",
				players: "本局玩家",
				murdererLabel: "凶手",
				motiveLabel: "真实动机",
				verdict: "指认结论",
				verdictOk: "指认正确",
				verdictBad: "指认错误",
				detectiveWin: "警探获胜",
				murdererWin: "凶手获胜",
				secondRefusal: "凶手第二次拒绝行凶，警探获胜。",
				reveal: "凶手是 {{civ}}，真实动机是 {{motive}}。"
			},
			err: {
				notPlayer: "你不是本局玩家。",
				notYourRole: "当前身份不能执行这个行动。",
				notYourTurn: "现在轮不到你。",
				wrongPhase: "当前阶段不能执行这个行动。",
				badChoice: "选择不符合规则。",
				badTarget: "目标不符合规则。",
				badVictim: "这名平民不符合动机或行凶条件。",
				badMove: "移动目标不合法。",
				noSpace: "目标街区已满。",
				noAction: "本轮的这类行动已经用完。",
				badAnswer: "这个回答不符合规则。",
				badGroup: "社会群体选择不合法。",
				badAccuse: "指认内容不合法。"
			}
		},
		en: {
			name: "Intent to Kill",
			desc: "A noir deduction duel between a serial killer and a detective over five murders in a 1960s American city.",
			rules: "Objective:\n· One player is the Murderer and the other is the Detective. The Murderer must kill 5 civilians while hiding their identity and motive. The Detective must name the Murderer and the true motive after the fifth murder.\n· The Detective wins by naming both the correct Murderer and the correct motive. If either answer is wrong, the Murderer wins.\n\nSetup:\n· Randomly draw 20 civilians from the 54 civilian cards. Place 2 civilians in each corner block and 1 civilian in each of the other 12 blocks. A block can contain at most 3 civilians.\n· The Murderer secretly designates one of the 20 civilians as themself and another as the Person of Interest, and records both sets of characteristics. Neither identity is revealed to the Detective.\n· Randomly choose 6 of the 12 motives as this game's possible motives and place them face up where both players can see them. The Murderer secretly draws 1 of those 6 as the true motive.\n· The Murderer secretly draws 3 Social Group tokens. One of them is the Supporters group. The other 2 are returned to the box. The remaining 6 Social Group tokens form the draw stack.\n· The Detective places the Detective marker in any block and takes the Surveillance token. The first round then begins.\n\nRound:\n· Each round consists of the Murderer Phase, the Detective Phase, and the City Phase. The round in which the fifth murder occurs is the final round.\n\nMurderer Phase:\n· Intimidation: The Murderer chooses 2 civilians that are not in the block with the Detective marker and flips them to their black-and-white side. Intimidated civilians cannot be questioned by the Detective. If fewer than 2 civilians are eligible, the Murderer intimidates every eligible civilian.\n· Murder: The Murderer chooses 1 civilian who fits the true motive and murders them. The victim cannot be the Murderer, cannot be in the block with the Detective marker, and cannot be in a block that already contains a Crime Scene.\n· The Murderer places the next Crime Scene card in the victim's block, then moves the victim's card to the Victim area. The murdered civilian leaves the city.\n· The Murderer may refuse to murder once per game. After refusing, no murder takes place and play continues with the Detective Phase immediately after intimidation; the game lasts 6 rounds instead of 5. If the Murderer refuses a second time, the Murderer immediately loses.\n\nDetective Phase:\n· Initial Response: The Detective moves the Detective marker to the new Crime Scene block and moves every other civilian in that block to an adjacent block. If no adjacent space is available, the Detective may move them to any block with space. Civilians can never move into a Crime Scene block.\n· Investigation: The Detective receives 2 actions and 2 movement points. An action can be used to question civilians, use a building in the current block, or perform another investigation action. Each kind of action can be used at most once per round. Movement points can be spent before, between, or after actions, and each point moves the Detective marker to an adjacent block. Unused actions and movement points do not carry over.\n· Questioning: The Detective may question every non-intimidated civilian in the current block, asking each civilian 1 question. A question may only ask about the Murderer's sex, age, build, or height. The Murderer answers each questioned civilian separately with \"yes\" or \"no\". If the questioned civilian is the Murderer, the Person of Interest, or a member of the Supporters group, the Murderer may lie. Every other civilian must answer truthfully.\n· Police Station: If the Detective marker's block contains a Police Station, the Detective may place the Surveillance token on a civilian in this or an adjacent block. If the token is already on a civilian, the Detective may move it instead.\n· Diner: If the Detective marker's block contains a Diner, the Detective may question 1 non-intimidated civilian in this or an adjacent block with 1 question.\n· Hospital: If the Detective marker's block contains a Hospital, the Detective may comfort 1 intimidated civilian in this or an adjacent block, flipping that civilian back to the colored side.\n· Fire Station: If the Detective marker's block contains a Fire Station, the Detective draws 1 random Social Group token from the draw stack, then may move every civilian of that group once to an adjacent block. Return the drawn token to the draw stack afterwards.\n· Surveillance: The Detective may remove the Surveillance token at any time and ask the Murderer, \"Can you murder this civilian right now?\" The Murderer must answer truthfully according to the true motive. If the target civilian is the Murderer, or is in the same block as the Detective marker, the answer is always \"no\". Surveillance does not cost an action and is not Questioning. If the Murderer kills a civilian that carries the Surveillance token, the token returns to the Detective and counts as a de-facto answer of \"yes\" to the same question.\n\nCity Phase:\n· Comfort: Every intimidated civilian in the Detective marker's block is flipped back to the colored side.\n· The Murderer first draws 1 random Social Group token from the draw stack and may move every civilian of that group once to an adjacent block. The Detective then draws 1 token and moves that group in the same way. Each drawn token returns to the draw stack after use.\n· If the drawn Social Group has no civilians in the city, the player who drew it may choose any Social Group that still has civilians and move that group instead. The drawn token is placed in the box and does not return to the draw stack.\n\nEnd of Game:\n· After the round in which the fifth murder occurs, the Detective must name 1 civilian as the Murderer and 1 of the 6 possible motives as the true motive. If both answers are correct, the Detective wins; otherwise the Murderer wins.\n· Starting after round 3, the Detective may accuse early at the end of each round. If an early accusation is wrong, the Murderer immediately wins. If the Murderer refused to murder once, the Detective must accuse after round 6.\n\nMotives:\n· Psychopath: All victims can be of no more than two different ages.\n· Cutthroat: You cannot murder in the 4 central blocks of the city.\n· Spy: All victims have to be murdered in blocks with buildings.\n· Cannibal: The 5 victims must include all three builds: thin, medium, and heavy.\n· Vigilante: You cannot murder anyone in the 8 blocks surrounding the Detective marker. Fewer blocks are restricted when the Detective marker is on the edge of the city.\n· Radical: At least 3 of the victims have to be from the same Social Group.\n· Cultist: The first victim must be from a different Social Group than the Person of Interest; each victim must be from a different Social Group than the previous victim; the Person of Interest must be among the 5 victims.\n· Killer: You can only murder civilians that are alone in a block.\n· Sadist: You cannot murder intimidated civilians.\n· Terrorist: All victims have to be from different Social Groups.\n· Maniac: All victims have to be of the same sex.\n· Robber: You cannot murder anyone in a block adjacent to the previous Crime Scene.",
			role: {
				detective: "Detective",
				murderer: "Murderer"
			},
			phase: {
				setup: "Choose starting block",
				intimidate: "Murderer intimidates",
				murder: "Murderer chooses a victim",
				response: "Detective responds",
				investigate: "Detective investigates",
				answers: "Murderer answers questions",
				fire: "Fire Station action",
				cityMurderer: "City Phase · Murderer moves",
				cityDetective: "City Phase · Detective moves",
				accuseChoice: "Accuse early?",
				accuse: "Final accusation",
				done: "Game over"
			},
			you: "You",
			opponent: "Opponent",
			round: "Round {{n}}",
			murders: "Murders {{n}} / 5",
			caseFile: "Case File",
			mapTitle: "City Homicide Map",
			mapSub: "Police Department · 1962 records",
			mapScale: "Scale 1:12000 · City Survey",
			boardTitle: "City blocks",
			boardHint: "Tap a block to inspect civilians and available actions",
			district: {
				rockyhall: "Rocky Hall",
				docks: "Docks",
				littleitaly: "Little Italy",
				goldenbeach: "Golden Beach",
				westside: "West Side",
				businesscenter: "Business Center",
				presidentsquare: "President Square",
				eastside: "East Side",
				chinatown: "Chinatown",
				centralpark: "Central Park",
				santacruz: "Santa Cruz",
				riverstation: "River Station",
				stadium: "Stadium",
				richmond: "Richmond",
				universitycampus: "University Campus",
				oldcity: "Old City"
			},
			building: {
				police: "Police Station",
				diner: "Diner",
				hospital: "Hospital",
				fire: "Fire Station"
			},
			group: {
				authority: "Authority",
				press: "Press",
				outcasts: "Outcasts",
				medicine: "Medicine",
				government: "Government",
				labor: "Labor",
				criminals: "Criminals",
				jetset: "Jet Set",
				immigrants: "Immigrants"
			},
			civ: {
				actress: "Actress",
				secretagent: "Secret Agent",
				artist: "Artist",
				bartender: "Bartender",
				ballplayer: "Ballplayer",
				beggar: "Beggar",
				bouncer: "Bouncer",
				greaser: "Greaser",
				catlady: "Cat Lady",
				congressman: "Congressman",
				coroner: "Coroner",
				showgirl: "Showgirl",
				newscaster: "Newscaster",
				dispatcher: "Dispatcher",
				mafiadon: "Mafia Don",
				busdriver: "Bus Driver",
				pharmacist: "Pharmacist",
				benefactor: "Benefactor",
				fireman: "Fireman",
				photographer: "Photographer",
				gangster: "Gangster",
				icecreamman: "Ice Cream Man",
				informant: "Informant",
				deputy: "Deputy",
				reporter: "Reporter",
				judge: "Judge",
				lawyer: "Lawyer",
				librarian: "Librarian",
				lobbyist: "Lobbyist",
				navysailor: "Navy Sailor",
				mayor: "Mayor",
				musician: "Musician",
				psychic: "Psychic",
				nun: "Nun",
				nurse: "Nurse",
				paperboy: "Paperboy",
				patrolman: "Patrolman",
				ambassador: "Ambassador",
				mailwoman: "Mailwoman",
				professor: "Professor",
				stateattorney: "State Attorney",
				psychiatrist: "Psychiatrist",
				editor: "Editor",
				restaurateur: "Restaurateur",
				orderly: "Orderly",
				secretary: "Secretary",
				fence: "Fence",
				cabincrew: "Cabin Crew",
				surgeon: "Surgeon",
				riveter: "Riveter",
				veterinarian: "Veterinarian",
				veteran: "Veteran",
				waitress: "Waitress",
				warwidow: "War Widow"
			},
			sex: {
				male: "Male",
				female: "Female"
			},
			age: {
				young: "20 years old",
				middle: "40 years old",
				senior: "60 years old"
			},
			build: {
				S: "Thin",
				M: "Medium",
				L: "Heavy"
			},
			height: {
				short: "Short",
				medium: "Medium",
				tall: "Tall"
			},
			motive: {
				psychopath: {
					name: "Psychopath",
					text: "All victims can be of no more than two different ages."
				},
				cutthroat: {
					name: "Cutthroat",
					text: "You cannot murder in the 4 central blocks of the city."
				},
				spy: {
					name: "Spy",
					text: "All victims have to be murdered in blocks with buildings."
				},
				cannibal: {
					name: "Cannibal",
					text: "The 5 victims must include all three builds: thin, medium, and heavy."
				},
				vigilante: {
					name: "Vigilante",
					text: "You cannot murder anyone in the 8 blocks surrounding the Detective marker. Fewer blocks are restricted when the Detective marker is on the edge of the city."
				},
				radical: {
					name: "Radical",
					text: "At least 3 of the victims have to be from the same Social Group."
				},
				cultist: {
					name: "Cultist",
					text: "The first victim must be from a different Social Group than the Person of Interest; each victim must be from a different Social Group than the previous victim; the Person of Interest must be among the 5 victims."
				},
				killer: {
					name: "Killer",
					text: "You can only murder civilians that are alone in a block."
				},
				sadist: {
					name: "Sadist",
					text: "You cannot murder intimidated civilians."
				},
				terrorist: {
					name: "Terrorist",
					text: "All victims have to be from different Social Groups."
				},
				maniac: {
					name: "Maniac",
					text: "All victims have to be of the same sex."
				},
				robber: {
					name: "Robber",
					text: "You cannot murder anyone in a block adjacent to the previous Crime Scene."
				}
			},
			q: {
				male: "Is the Murderer male?",
				female: "Is the Murderer female?",
				young: "Is the Murderer 20 years old?",
				middle: "Is the Murderer 40 years old?",
				senior: "Is the Murderer 60 years old?",
				thin: "Is the Murderer thin?",
				mediumBuild: "Is the Murderer of medium build?",
				heavy: "Is the Murderer heavy?",
				tall: "Is the Murderer tall?",
				mediumHeight: "Is the Murderer of medium height?",
				short: "Is the Murderer short?"
			},
			label: {
				victimArea: "Victim area",
				crimeScene: "Crime Scene",
				marker: "Detective marker",
				surveillance: "Surveillance token",
				motiveChoices: "Possible motives",
				socialStack: "Social Group stack",
				actions: "Actions {{n}}",
				moves: "Movement {{n}}",
				secret: "Your secret",
				identity: "Your identity",
				traits: "Traits",
				poi: "Person of Interest",
				supporters: "Supporters group",
				drawnGroups: "Drawn Social Groups",
				questionLog: "Question log",
				eventLog: "Event log",
				dead: "Murdered",
				intimidated: "Intimidated",
				normal: "Normal",
				emptyBlock: "No civilians in this block",
				selected: "Selected",
				none: "None",
				hidden: "Unknown",
				yes: "Yes",
				no: "No",
				mustTellTruth: "Must answer truthfully",
				mayLie: "May lie",
				chooseDestination: "Choose a destination",
				chooseGroup: "Choose a Social Group",
				yearsShort: "yrs",
				victimSlot: "Victim {{n}}",
				victimSlotShort: "Pending",
				roundShort: "Round",
				murdersShort: "Murders",
				legend: "Landmark legend",
				districtIndex: "District index",
				listSep: ", "
			},
			btn: {
				placeDetective: "Start here",
				intimidate: "Intimidate selected",
				murder: "Murder this civilian",
				refuse: "Refuse to murder",
				respond: "Respond to the Crime Scene",
				question: "Question this block",
				diner: "Diner question",
				police: "Place Surveillance",
				hospital: "Comfort civilian",
				fire: "Fire Station action",
				move: "Move Detective",
				surveillance: "Use Surveillance",
				endTurn: "End investigation",
				accuse: "Accuse",
				continue: "Continue to next round",
				confirm: "Confirm",
				cancel: "Cancel",
				close: "Close",
				back: "Back",
				useAction: "Use action",
				choose: "Choose",
				submit: "Submit",
				selectAll: "Select all",
				clear: "Clear"
			},
			prompt: {
				setup: "Choose the starting block for the Detective marker.",
				intimidate: "Choose 2 civilians outside the Detective marker block to intimidate.",
				murder: "Choose a civilian who fits the motive, or refuse to murder.",
				response: "Choose adjacent destinations for civilians in the Crime Scene block.",
				investigate: "Use 2 actions and 2 movement points, then end the investigation.",
				answers: "The Murderer is answering questions.",
				yourAnswers: "Answer each question from the Detective.",
				fire: "Move civilians of the drawn Social Group. Each civilian may move once.",
				cityMurderer: "Draw a Social Group token and move that group.",
				cityDetective: "Draw a Social Group token and move that group.",
				accuseChoice: "Continue to the next round, or accuse now.",
				accuse: "Name the Murderer and the true motive.",
				done: "The game is over.",
				waiting: "Waiting for the opponent."
			},
			log: {
				round: "Round {{n}} begins.",
				intimidate: "The Murderer intimidated {{a}} and {{b}}.",
				murder: "{{a}} was murdered in {{b}}.",
				refuse: "The Murderer refused to murder.",
				question: "The Detective questioned {{a}}: {{b}}",
				answer: "{{a}} answered: {{b}}.",
				surveillance: "Surveillance on {{a}} — the Murderer answered: {{b}}.",
				move: "The Detective moved to {{a}}.",
				comfort: "The Detective comforted {{n}} civilians.",
				city: "City Phase: {{a}}.",
				groupMove: "The {{a}} group moved {{n}} civilians.",
				accuse: "The Detective accused {{a}} of being the Murderer.",
				win: "The game is over.",
				system: ""
			},
			result: {
				caseClosed: "Case closed",
				finalRound: "Ended in round {{n}}",
				truth: "The truth",
				victimOrder: "Murder order",
				players: "Players",
				murdererLabel: "Murderer",
				motiveLabel: "True motive",
				verdict: "Verdict",
				verdictOk: "Correct accusation",
				verdictBad: "Wrong accusation",
				detectiveWin: "The Detective wins",
				murdererWin: "The Murderer wins",
				secondRefusal: "The Murderer refused a second time. The Detective wins.",
				reveal: "The Murderer was {{civ}}, and the true motive was {{motive}}."
			},
			err: {
				notPlayer: "You are not a player in this game.",
				notYourRole: "Your role cannot perform this action.",
				notYourTurn: "It is not your turn.",
				wrongPhase: "This action is not available in the current phase.",
				badChoice: "That selection does not follow the rules.",
				badTarget: "That target does not follow the rules.",
				badVictim: "This civilian does not fit the motive or the murder conditions.",
				badMove: "That move is not legal.",
				noSpace: "The destination block is full.",
				noAction: "You have already used that action this round.",
				badAnswer: "That answer does not follow the rules.",
				badGroup: "That Social Group choice is not legal.",
				badAccuse: "That accusation is not legal."
			}
		}
	}
};
//#endregion
export { lt as default };
