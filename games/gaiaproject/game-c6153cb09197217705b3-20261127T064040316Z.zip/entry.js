import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var y = {
	terrans: {
		id: "terrans",
		planet: "terra",
		color: "#3f7fd0",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				4,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { gaia: 1 },
		ability: "abilityTerrans"
	},
	lantids: {
		id: "lantids",
		planet: "terra",
		color: "#2f9fb8",
		init: {
			credits: 13,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				4,
				0,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: {},
		ability: "abilityLantids"
	},
	taklons: {
		id: "taklons",
		planet: "swamp",
		color: "#8a6134",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: {},
		ability: "abilityTaklons"
	},
	ambas: {
		id: "ambas",
		planet: "swamp",
		color: "#a9553c",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 2,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { nav: 1 },
		ability: "abilityAmbas"
	},
	gleens: {
		id: "gleens",
		planet: "desert",
		color: "#c8a03c",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 0,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { nav: 1 },
		ability: "abilityGleens"
	},
	xenos: {
		id: "xenos",
		planet: "desert",
		color: "#c9a421",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { ai: 1 },
		ability: "abilityXenos"
	},
	ivits: {
		id: "ivits",
		planet: "oxide",
		color: "#b8433f",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 1,
			tokens: 0
		},
		research: {},
		ability: "abilityIvits"
	},
	hadschhallas: {
		id: "hadschhallas",
		planet: "oxide",
		color: "#c05a35",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 3,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { eco: 1 },
		ability: "abilityHadschHallas"
	},
	bescods: {
		id: "bescods",
		planet: "titanium",
		color: "#8d949e",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 1,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 0,
			qic: 0,
			tokens: 0
		},
		research: {},
		ability: "abilityBescods"
	},
	firaks: {
		id: "firaks",
		planet: "titanium",
		color: "#6c7480",
		init: {
			credits: 15,
			ores: 3,
			knowledge: 2,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 2,
			qic: 0,
			tokens: 0
		},
		research: {},
		ability: "abilityFiraks"
	},
	geodens: {
		id: "geodens",
		planet: "volcanic",
		color: "#c76a2f",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { terra: 1 },
		ability: "abilityGeodens"
	},
	baltaks: {
		id: "baltaks",
		planet: "volcanic",
		color: "#c44d2f",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 3,
			qic: 0,
			power: [
				2,
				2,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { gaia: 1 },
		ability: "abilityBaltaks"
	},
	nevlas: {
		id: "nevlas",
		planet: "ice",
		color: "#9fb8c9",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 2,
			qic: 1,
			power: [
				2,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { sci: 1 },
		ability: "abilityNevlas"
	},
	itars: {
		id: "itars",
		planet: "ice",
		color: "#d7e3ec",
		init: {
			credits: 15,
			ores: 5,
			knowledge: 3,
			qic: 1,
			power: [
				4,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 1
		},
		research: {},
		ability: "abilityItars"
	},
	spacegiants: {
		id: "spacegiants",
		planet: "protoplanet",
		color: "#7c6fd0",
		init: {
			credits: 15,
			ores: 6,
			knowledge: 3,
			qic: 1,
			power: [
				4,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { nav: 1 },
		ability: "abilitySpaceGiants"
	},
	moweyds: {
		id: "moweyds",
		planet: "protoplanet",
		color: "#3f9e8c",
		init: {
			credits: 15,
			ores: 6,
			knowledge: 5,
			qic: 2,
			power: [
				4,
				4,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { gaia: 1 },
		ability: "abilityMoweyds"
	},
	darkanians: {
		id: "darkanians",
		planet: "asteroid",
		color: "#9a5bb5",
		init: {
			credits: 15,
			ores: 7,
			knowledge: 3,
			qic: 1,
			power: [
				4,
				2,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: {
			nav: 1,
			eco: 1
		},
		ability: "abilityDarkanians"
	},
	tinkeroids: {
		id: "tinkeroids",
		planet: "asteroid",
		color: "#b0a43a",
		init: {
			credits: 15,
			ores: 4,
			knowledge: 2,
			qic: 1,
			power: [
				4,
				2,
				0
			]
		},
		income: {
			credits: 0,
			ores: 1,
			knowledge: 1,
			qic: 0,
			tokens: 0
		},
		research: { sci: 1 },
		ability: "abilityTinkeroids"
	}
}, b = [
	"terrans",
	"lantids",
	"taklons",
	"ambas",
	"gleens",
	"xenos",
	"ivits",
	"hadschhallas",
	"bescods",
	"firaks",
	"geodens",
	"baltaks",
	"nevlas",
	"itars"
], x = [
	"spacegiants",
	"moweyds",
	"darkanians",
	"tinkeroids"
], S = b, C = [...b, ...x], ee = {
	terra: {
		color: "#4f9a52",
		glyph: "M2 12 L12 3 L22 12 L12 21 Z",
		name: "planetTerra",
		terraformable: !0
	},
	swamp: {
		color: "#7a6592",
		glyph: "M3 15 Q8 8 12 13 Q16 18 21 10 L21 20 L3 20 Z",
		name: "planetSwamp",
		terraformable: !0
	},
	desert: {
		color: "#c9a54e",
		glyph: "M3 17 Q7 10 12 14 Q17 18 21 12 L21 20 L3 20 Z",
		name: "planetDesert",
		terraformable: !0
	},
	oxide: {
		color: "#bd5b3f",
		glyph: "M12 3 L21 12 L12 21 L3 12 Z M12 8 L16 12 L12 16 L8 12 Z",
		name: "planetOxide",
		terraformable: !0
	},
	titanium: {
		color: "#8f9aa6",
		glyph: "M4 14 L9 5 L15 9 L20 6 L20 18 L4 18 Z",
		name: "planetTitanium",
		terraformable: !0
	},
	volcanic: {
		color: "#9c3f38",
		glyph: "M12 3 L20 20 L14 16 L12 21 L10 16 L4 20 Z",
		name: "planetVolcanic",
		terraformable: !0
	},
	ice: {
		color: "#bcd7e6",
		glyph: "M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z",
		name: "planetIce",
		terraformable: !0
	},
	gaia: {
		color: "#3fc7a4",
		glyph: "M12 4 A8 8 0 1 0 12 20 A8 8 0 1 0 12 4 M12 7 A5 5 0 1 1 12 17 A5 5 0 1 1 12 7",
		name: "planetGaia",
		terraformable: !1
	},
	transdim: {
		color: "#8066d6",
		glyph: "M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 M12 7 A5 5 0 1 1 12 17 A5 5 0 1 1 12 7",
		name: "planetTransdim",
		terraformable: !1
	},
	asteroid: {
		color: "#8b7f6a",
		glyph: "M5 12 L9 6 L16 5 L20 11 L16 18 L8 19 Z M10 10 L13 9 L15 12 L12 15 L9 14 Z",
		name: "planetAsteroid",
		terraformable: !1
	},
	protoplanet: {
		color: "#7f9fb5",
		glyph: "M4 18 Q12 4 20 18 Z M7 18 Q12 9 17 18 Z",
		name: "planetProtoplanet",
		terraformable: !1
	},
	lostplanet: {
		color: "#2f3a4d",
		glyph: "M12 4 A8 8 0 1 0 12 20 A8 8 0 1 0 12 4 M5 12 L19 12",
		name: "planetLost",
		terraformable: !1
	}
}, w = [
	{
		id: "terra",
		color: "#4f9a52",
		name: "trackTerra"
	},
	{
		id: "nav",
		color: "#3f78b8",
		name: "trackNav"
	},
	{
		id: "ai",
		color: "#c9773a",
		name: "trackAi"
	},
	{
		id: "gaia",
		color: "#3fa79a",
		name: "trackGaia"
	},
	{
		id: "eco",
		color: "#c2a13c",
		name: "trackEco"
	},
	{
		id: "sci",
		color: "#a65062",
		name: "trackSci"
	}
], te = w.map((e) => e.id), T = {
	terra: 0,
	nav: 1,
	ai: 2,
	gaia: 3,
	eco: 4,
	sci: 5
}, ne = {
	terrans: {
		terra: 0,
		ice: 1,
		oxide: 1,
		titanium: 2,
		volcanic: 2,
		desert: 3,
		swamp: 3
	},
	lantids: {
		terra: 0,
		ice: 1,
		oxide: 1,
		titanium: 2,
		volcanic: 2,
		desert: 3,
		swamp: 3
	},
	ambas: {
		swamp: 0,
		desert: 1,
		titanium: 1,
		ice: 2,
		volcanic: 2,
		terra: 3,
		oxide: 3
	},
	taklons: {
		swamp: 0,
		desert: 1,
		titanium: 1,
		ice: 2,
		volcanic: 2,
		terra: 3,
		oxide: 3
	},
	bescods: {
		titanium: 0,
		swamp: 1,
		ice: 1,
		desert: 2,
		terra: 2,
		oxide: 3,
		volcanic: 3
	},
	firaks: {
		titanium: 0,
		swamp: 1,
		ice: 1,
		desert: 2,
		terra: 2,
		oxide: 3,
		volcanic: 3
	},
	itars: {
		ice: 0,
		terra: 1,
		titanium: 1,
		oxide: 2,
		swamp: 2,
		desert: 3,
		volcanic: 3
	},
	nevlas: {
		ice: 0,
		terra: 1,
		titanium: 1,
		oxide: 2,
		swamp: 2,
		desert: 3,
		volcanic: 3
	},
	hadschhallas: {
		oxide: 0,
		terra: 1,
		volcanic: 1,
		desert: 2,
		ice: 2,
		titanium: 3,
		swamp: 3
	},
	ivits: {
		oxide: 0,
		terra: 1,
		volcanic: 1,
		desert: 2,
		ice: 2,
		titanium: 3,
		swamp: 3
	},
	baltaks: {
		volcanic: 0,
		desert: 1,
		oxide: 1,
		swamp: 2,
		terra: 2,
		ice: 3,
		titanium: 3
	},
	geodens: {
		volcanic: 0,
		desert: 1,
		oxide: 1,
		swamp: 2,
		terra: 2,
		ice: 3,
		titanium: 3
	},
	gleens: {
		desert: 0,
		swamp: 1,
		volcanic: 1,
		oxide: 2,
		titanium: 2,
		ice: 3,
		terra: 3
	},
	xenos: {
		desert: 0,
		swamp: 1,
		volcanic: 1,
		oxide: 2,
		titanium: 2,
		ice: 3,
		terra: 3
	},
	spacegiants: {
		terra: 2,
		swamp: 2,
		desert: 2,
		oxide: 2,
		titanium: 2,
		volcanic: 2,
		ice: 2
	},
	darkanians: {
		terra: 1,
		swamp: 1,
		desert: 1,
		oxide: 1,
		titanium: 1,
		volcanic: 1,
		ice: 1
	},
	moweyds: {
		terra: 1,
		swamp: 1,
		desert: 1,
		oxide: 1,
		titanium: 1,
		volcanic: 1,
		ice: 1
	},
	tinkeroids: {
		terra: 1,
		swamp: 1,
		desert: 1,
		oxide: 1,
		titanium: 1,
		volcanic: 1,
		ice: 1
	}
};
function E(e, t) {
	return t === "gaia" || t === "lostplanet" || t === "transdim" || t === "asteroid" ? 0 : t === "protoplanet" ? 3 : ne[e][t] ?? 0;
}
function re(e) {
	return e <= 1 ? 3 : e === 2 ? 2 : 1;
}
function ie(e) {
	return e <= 2 ? 6 : e === 3 ? 4 : 3;
}
function ae(e) {
	return e <= 1 ? 1 : e <= 3 ? 2 : e === 4 ? 3 : 4;
}
var oe = [
	{
		id: "S_power4",
		kind: "standard",
		name: "techPower4",
		desc: "techPower4Desc",
		effect: {
			kind: "action",
			action: "power4"
		}
	},
	{
		id: "S_oreQic",
		kind: "standard",
		name: "techOreQic",
		desc: "techOreQicDesc",
		effect: {
			kind: "immediate",
			ores: 1,
			qic: 1
		}
	},
	{
		id: "S_knwTypes",
		kind: "standard",
		name: "techKnwTypes",
		desc: "techKnwTypesDesc",
		effect: {
			kind: "immediatePerType",
			knowledge: 1
		}
	},
	{
		id: "S_7vp",
		kind: "standard",
		name: "tech7vp",
		desc: "tech7vpDesc",
		effect: {
			kind: "immediate",
			vp: 7
		}
	},
	{
		id: "S_incOrePow",
		kind: "standard",
		name: "techIncOrePow",
		desc: "techIncOrePowDesc",
		effect: {
			kind: "income",
			ores: 1,
			power: 1
		}
	},
	{
		id: "S_incKnwC",
		kind: "standard",
		name: "techIncKnwC",
		desc: "techIncKnwCDesc",
		effect: {
			kind: "income",
			knowledge: 1,
			credits: 1
		}
	},
	{
		id: "S_inc4c",
		kind: "standard",
		name: "techInc4c",
		desc: "techInc4cDesc",
		effect: {
			kind: "income",
			credits: 4
		}
	},
	{
		id: "S_big4pow",
		kind: "standard",
		name: "techBig4pow",
		desc: "techBig4powDesc",
		effect: {
			kind: "passive",
			passive: "big4"
		}
	},
	{
		id: "S_gaia3vp",
		kind: "standard",
		name: "techGaia3vp",
		desc: "techGaia3vpDesc",
		effect: {
			kind: "passive",
			passive: "gaia3vp"
		}
	}
], se = [
	{
		id: "A_qic5c",
		kind: "advanced",
		name: "advQic5c",
		desc: "advQic5cDesc",
		effect: {
			kind: "action",
			action: "qic5c"
		}
	},
	{
		id: "A_ore3",
		kind: "advanced",
		name: "advOre3",
		desc: "advOre3Desc",
		effect: {
			kind: "action",
			action: "ore3"
		}
	},
	{
		id: "A_knw3",
		kind: "advanced",
		name: "advKnw3",
		desc: "advKnw3Desc",
		effect: {
			kind: "action",
			action: "knowledge3"
		}
	},
	{
		id: "A_mine2",
		kind: "advanced",
		name: "advMine2",
		desc: "advMine2Desc",
		effect: {
			kind: "immediatePer",
			metric: "mine",
			vp: 2
		}
	},
	{
		id: "A_ts4",
		kind: "advanced",
		name: "advTs4",
		desc: "advTs4Desc",
		effect: {
			kind: "immediatePer",
			metric: "ts",
			vp: 4
		}
	},
	{
		id: "A_fed5",
		kind: "advanced",
		name: "advFed5",
		desc: "advFed5Desc",
		effect: {
			kind: "immediatePer",
			metric: "federation",
			vp: 5
		}
	},
	{
		id: "A_sector2",
		kind: "advanced",
		name: "advSector2",
		desc: "advSector2Desc",
		effect: {
			kind: "immediatePer",
			metric: "sector",
			vp: 2
		}
	},
	{
		id: "A_gaia2",
		kind: "advanced",
		name: "advGaia2",
		desc: "advGaia2Desc",
		effect: {
			kind: "immediatePer",
			metric: "gaia",
			vp: 2
		}
	},
	{
		id: "A_sector1o",
		kind: "advanced",
		name: "advSector1o",
		desc: "advSector1oDesc",
		effect: {
			kind: "immediatePer",
			metric: "sectorOre",
			ores: 1
		}
	},
	{
		id: "A_passFed3",
		kind: "advanced",
		name: "advPassFed3",
		desc: "advPassFed3Desc",
		effect: {
			kind: "pass",
			metric: "federation",
			vp: 3
		}
	},
	{
		id: "A_passRl3",
		kind: "advanced",
		name: "advPassRl3",
		desc: "advPassRl3Desc",
		effect: {
			kind: "pass",
			metric: "rl",
			vp: 3
		}
	},
	{
		id: "A_passType1",
		kind: "advanced",
		name: "advPassType1",
		desc: "advPassType1Desc",
		effect: {
			kind: "pass",
			metric: "type",
			vp: 1
		}
	},
	{
		id: "A_res2vp",
		kind: "advanced",
		name: "advRes2vp",
		desc: "advRes2vpDesc",
		effect: {
			kind: "passive",
			passive: "research2vp"
		}
	},
	{
		id: "A_mine3",
		kind: "advanced",
		name: "advMine3",
		desc: "advMine3Desc",
		effect: {
			kind: "passive",
			passive: "mine3vp"
		}
	},
	{
		id: "A_ts3",
		kind: "advanced",
		name: "advTs3",
		desc: "advTs3Desc",
		effect: {
			kind: "passive",
			passive: "ts3vp"
		}
	}
], D = Object.fromEntries([...oe, ...se].map((e) => [e.id, e])), ce = [
	{
		id: "lf_mine2free",
		kind: "standard",
		name: "lfMine2free",
		desc: "lfMine2freeDesc",
		effect: {
			kind: "freeMineTerra",
			steps: 2
		}
	},
	{
		id: "lf_piDsVp",
		kind: "standard",
		name: "lfPiDsVp",
		desc: "lfPiDsVpDesc",
		effect: {
			kind: "immediatePer",
			metric: "piAcademyDs",
			vp: 2
		}
	},
	{
		id: "lf_range1",
		kind: "standard",
		name: "lfRange1",
		desc: "lfRange1Desc",
		effect: {
			kind: "passive",
			passive: "range1"
		}
	}
], le = [
	{
		id: "lfA_sector4",
		kind: "advanced",
		name: "lfASector4",
		desc: "lfASector4Desc",
		effect: {
			kind: "immediatePer",
			metric: "sector",
			vp: 4
		}
	},
	{
		id: "lfA_flat9",
		kind: "advanced",
		name: "lfAFlat9",
		desc: "lfAFlat9Desc",
		effect: {
			kind: "immediate",
			vp: 9
		}
	},
	{
		id: "lfA_passAsteroid2",
		kind: "advanced",
		name: "lfAPassAsteroid2",
		desc: "lfAPassAsteroid2Desc",
		effect: {
			kind: "pass",
			metric: "asteroid",
			vp: 2
		}
	},
	{
		id: "lfA_passDs2",
		kind: "advanced",
		name: "lfAPassDs2",
		desc: "lfAPassDs2Desc",
		effect: {
			kind: "pass",
			metric: "dsSector",
			vp: 2
		}
	},
	{
		id: "lfA_gaia4",
		kind: "advanced",
		name: "lfAGaia4",
		desc: "lfAGaia4Desc",
		effect: {
			kind: "immediatePer",
			metric: "gaia",
			vp: 4
		}
	},
	{
		id: "lfA_oreIncome2",
		kind: "advanced",
		name: "lfAOreIncome2",
		desc: "lfAOreIncome2Desc",
		effect: {
			kind: "income",
			ores: 2
		}
	}
], ue = Object.fromEntries([...ce, ...le].map((e) => [e.id, e])), O = {
	...D,
	...ue
}, de = [
	{
		id: "B_oreKnw",
		name: "boostOreKnw",
		desc: "boostOreKnwDesc",
		income: {
			ores: 1,
			knowledge: 1
		}
	},
	{
		id: "B_tokensOre",
		name: "boostTokensOre",
		desc: "boostTokensOreDesc",
		income: {
			ores: 1,
			tokens: 2
		}
	},
	{
		id: "B_creditsQic",
		name: "boostCreditsQic",
		desc: "boostCreditsQicDesc",
		income: {
			credits: 2,
			qic: 1
		}
	},
	{
		id: "B_terraformCredits",
		name: "boostTerraformCredits",
		desc: "boostTerraformCreditsDesc",
		income: { credits: 2 },
		action: "terraform1"
	},
	{
		id: "B_rangePower",
		name: "boostRangePower",
		desc: "boostRangePowerDesc",
		income: { power: 2 },
		action: "range3"
	},
	{
		id: "B_mineOre",
		name: "boostMineOre",
		desc: "boostMineOreDesc",
		income: { ores: 1 },
		pass: "mine"
	},
	{
		id: "B_tsOre",
		name: "boostTsOre",
		desc: "boostTsOreDesc",
		income: { ores: 1 },
		pass: "ts2"
	},
	{
		id: "B_rlKnw",
		name: "boostRlKnw",
		desc: "boostRlKnwDesc",
		income: { knowledge: 1 },
		pass: "rl3"
	},
	{
		id: "B_bigPower",
		name: "boostBigPower",
		desc: "boostBigPowerDesc",
		income: { power: 4 },
		pass: "big4"
	},
	{
		id: "B_gaiaCredits",
		name: "boostGaiaCredits",
		desc: "boostGaiaCreditsDesc",
		income: { credits: 4 },
		pass: "gaia1"
	}
], fe = Object.fromEntries(de.map((e) => [e.id, e])), pe = [
	{
		id: "lfB_gaiaformers",
		name: "lfBGaiaformers",
		desc: "lfBGaiaformersDesc",
		income: { ores: 1 },
		pass: "gaiaformers"
	},
	{
		id: "lfB_types",
		name: "lfBTypes",
		desc: "lfBTypesDesc",
		income: { credits: 3 },
		pass: "types"
	},
	{
		id: "lfB_dsSectors",
		name: "lfBDsSectors",
		desc: "lfBDsSectorsDesc",
		income: { power: 2 },
		pass: "dsSectors"
	},
	{
		id: "lfB_gaiaFree",
		name: "lfBGaiaFree",
		desc: "lfBGaiaFreeDesc",
		income: { ores: 1 },
		action: "gaiaFree"
	}
], me = {
	...fe,
	...Object.fromEntries(pe.map((e) => [e.id, e]))
}, he = [
	{
		id: "terra2",
		name: "scoreTerra2"
	},
	{
		id: "research2",
		name: "scoreResearch2"
	},
	{
		id: "mine2",
		name: "scoreMine2"
	},
	{
		id: "ts3",
		name: "scoreTs3"
	},
	{
		id: "ts4",
		name: "scoreTs4"
	},
	{
		id: "gaia3",
		name: "scoreGaia3"
	},
	{
		id: "gaia4",
		name: "scoreGaia4"
	},
	{
		id: "big5",
		name: "scoreBig5"
	},
	{
		id: "big5b",
		name: "scoreBig5"
	},
	{
		id: "federation5",
		name: "scoreFederation5"
	}
], ge = [
	{
		id: "lf_sector",
		name: "scoreLfSector"
	},
	{
		id: "lf_type",
		name: "scoreLfType"
	},
	{
		id: "lf_rl",
		name: "scoreLfRl"
	}
], _e = [
	{
		id: "fedBuildings",
		name: "finalFedBuildings"
	},
	{
		id: "buildings",
		name: "finalBuildings"
	},
	{
		id: "types",
		name: "finalTypes"
	},
	{
		id: "gaiaPlanets",
		name: "finalGaiaPlanets"
	},
	{
		id: "sectors",
		name: "finalSectors"
	},
	{
		id: "satellites",
		name: "finalSatellites"
	}
], ve = [
	{
		id: "lf_asteroids",
		name: "finalLfAsteroids"
	},
	{
		id: "lf_piAcademy",
		name: "finalLfPiAcademy"
	},
	{
		id: "lf_outerSectors",
		name: "finalLfOuterSectors"
	}
], ye = Object.fromEntries([
	{
		id: "knowledge",
		name: "fedKnowledge",
		desc: "fedKnowledgeDesc",
		vp: 6,
		rewards: { knowledge: 2 }
	},
	{
		id: "credits",
		name: "fedCredits",
		desc: "fedCreditsDesc",
		vp: 7,
		rewards: { credits: 6 }
	},
	{
		id: "ores",
		name: "fedOres",
		desc: "fedOresDesc",
		vp: 7,
		rewards: { ores: 2 }
	},
	{
		id: "power",
		name: "fedPower",
		desc: "fedPowerDesc",
		vp: 8,
		rewards: { tokens: 2 }
	},
	{
		id: "qic",
		name: "fedQic",
		desc: "fedQicDesc",
		vp: 8,
		rewards: { qic: 1 }
	},
	{
		id: "points",
		name: "fedPoints",
		desc: "fedPointsDesc",
		vp: 12,
		rewards: {}
	},
	{
		id: "gleens",
		name: "fedGleens",
		desc: "fedGleensDesc",
		vp: 0,
		rewards: {
			ores: 1,
			knowledge: 1,
			credits: 2
		}
	}
].map((e) => [e.id, e])), be = [
	{
		id: "p_knw3",
		name: "powerKnw3",
		desc: "powerKnw3Desc",
		cost: 7
	},
	{
		id: "p_terra2",
		name: "powerTerra2",
		desc: "powerTerra2Desc",
		cost: 5
	},
	{
		id: "p_ore2",
		name: "powerOre2",
		desc: "powerOre2Desc",
		cost: 4
	},
	{
		id: "p_credits7",
		name: "powerCredits7",
		desc: "powerCredits7Desc",
		cost: 4
	},
	{
		id: "p_knw2",
		name: "powerKnw2",
		desc: "powerKnw2Desc",
		cost: 4
	},
	{
		id: "p_terra1",
		name: "powerTerra1",
		desc: "powerTerra1Desc",
		cost: 3
	},
	{
		id: "p_tokens2",
		name: "powerTokens2",
		desc: "powerTokens2Desc",
		cost: 3
	}
], xe = [
	{
		id: "q_tech",
		name: "qicTech",
		desc: "qicTechDesc",
		cost: 4
	},
	{
		id: "q_rescore",
		name: "qicRescore",
		desc: "qicRescoreDesc",
		cost: 3
	},
	{
		id: "q_types",
		name: "qicTypes",
		desc: "qicTypesDesc",
		cost: 2
	}
], Se = [
	{
		id: "f_burn",
		name: "freeBurn",
		desc: "freeBurnDesc"
	},
	{
		id: "f_powQic",
		name: "freePowQic",
		desc: "freePowQicDesc"
	},
	{
		id: "f_powOre",
		name: "freePowOre",
		desc: "freePowOreDesc"
	},
	{
		id: "f_qicOre",
		name: "freeQicOre",
		desc: "freeQicOreDesc"
	},
	{
		id: "f_powKnw",
		name: "freePowKnw",
		desc: "freePowKnwDesc"
	},
	{
		id: "f_powCredit",
		name: "freePowCredit",
		desc: "freePowCreditDesc"
	},
	{
		id: "f_knwCredit",
		name: "freeKnwCredit",
		desc: "freeKnwCreditDesc"
	},
	{
		id: "f_oreCredit",
		name: "freeOreCredit",
		desc: "freeOreCreditDesc"
	},
	{
		id: "f_orePower",
		name: "freeOrePower",
		desc: "freeOrePowerDesc"
	}
], Ce = {
	mine: "buildingMine",
	ts: "buildingTs",
	rl: "buildingRl",
	pi: "buildingPi",
	ac: "buildingAc"
}, we = {
	mine: 1,
	ts: 2,
	rl: 2,
	pi: 3,
	ac: 3
}, k = {
	mine: 8,
	ts: 4,
	rl: 3,
	pi: 1,
	ac: 2
};
function A(e) {
	return `games.gaiaproject.${e}`;
}
//#endregion
//#region src/game/map.ts
var Te = [
	{
		row: 0,
		col: 2
	},
	{
		row: 1,
		col: 1
	},
	{
		row: 1,
		col: 3
	},
	{
		row: 2,
		col: 0
	},
	{
		row: 2,
		col: 2
	},
	{
		row: 2,
		col: 4
	},
	{
		row: 3,
		col: 1
	},
	{
		row: 3,
		col: 3
	},
	{
		row: 4,
		col: 0
	},
	{
		row: 4,
		col: 2
	},
	{
		row: 4,
		col: 4
	},
	{
		row: 5,
		col: 1
	},
	{
		row: 5,
		col: 3
	},
	{
		row: 6,
		col: 0
	},
	{
		row: 6,
		col: 2
	},
	{
		row: 6,
		col: 4
	},
	{
		row: 7,
		col: 1
	},
	{
		row: 7,
		col: 3
	},
	{
		row: 8,
		col: 2
	}
], Ee = [
	"terra",
	"swamp",
	"desert",
	"oxide",
	"titanium",
	"volcanic",
	"ice",
	"gaia",
	"transdim"
], De = (e, t) => ({
	id: e,
	planets: t.map(([e, t]) => ({
		index: e,
		code: t
	}))
}), Oe = Object.fromEntries([
	De("1", [
		[6, 1],
		[7, 0],
		[8, 2],
		[10, 8],
		[17, 5],
		[18, 3]
	]),
	De("2", [
		[0, 4],
		[1, 5],
		[7, 6],
		[10, 2],
		[11, 1],
		[16, 3],
		[17, 8]
	]),
	De("3", [
		[0, 8],
		[6, 7],
		[10, 4],
		[12, 6],
		[16, 0],
		[18, 2]
	]),
	De("4", [
		[0, 4],
		[4, 3],
		[8, 6],
		[11, 5],
		[12, 1],
		[15, 0]
	]),
	De("5", [
		[0, 6],
		[5, 8],
		[6, 7],
		[10, 3],
		[16, 5],
		[18, 2]
	]),
	De("5outlined", [
		[0, 6],
		[5, 8],
		[6, 7],
		[10, 3],
		[16, 5]
	]),
	De("6", [
		[2, 8],
		[6, 1],
		[7, 0],
		[14, 7],
		[15, 2],
		[17, 8]
	]),
	De("6outlined", [
		[2, 8],
		[7, 0],
		[14, 7],
		[15, 2],
		[17, 8]
	]),
	De("7", [
		[2, 1],
		[3, 8],
		[4, 3],
		[11, 7],
		[12, 7],
		[18, 4]
	]),
	De("7outlined", [
		[3, 8],
		[4, 7],
		[11, 7],
		[12, 1],
		[18, 4]
	]),
	De("8", [
		[0, 0],
		[4, 6],
		[5, 8],
		[11, 5],
		[12, 4],
		[16, 8]
	]),
	De("9", [
		[1, 5],
		[2, 8],
		[5, 6],
		[11, 4],
		[12, 7],
		[13, 1]
	]),
	De("10", [
		[2, 8],
		[5, 8],
		[6, 2],
		[12, 7],
		[13, 0],
		[16, 3]
	])
].map((e) => [e.id, e])), ke = [
	{
		sectors: [
			"1",
			"5outlined",
			"2",
			"3",
			"6outlined",
			"4",
			"7outlined"
		],
		origins: [
			{
				row: 0,
				col: 3
			},
			{
				row: 1,
				col: 8
			},
			{
				row: 7,
				col: 0
			},
			{
				row: 8,
				col: 5
			},
			{
				row: 9,
				col: 10
			},
			{
				row: 15,
				col: 2
			},
			{
				row: 16,
				col: 7
			}
		]
	},
	{
		sectors: [
			"1",
			"5outlined",
			"2",
			"3",
			"6outlined",
			"4",
			"7outlined"
		],
		origins: [
			{
				row: 0,
				col: 3
			},
			{
				row: 1,
				col: 8
			},
			{
				row: 7,
				col: 0
			},
			{
				row: 8,
				col: 5
			},
			{
				row: 9,
				col: 10
			},
			{
				row: 15,
				col: 2
			},
			{
				row: 16,
				col: 7
			}
		]
	},
	{
		sectors: [
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"10"
		],
		origins: [
			{
				row: 0,
				col: 3
			},
			{
				row: 1,
				col: 8
			},
			{
				row: 2,
				col: 13
			},
			{
				row: 7,
				col: 0
			},
			{
				row: 8,
				col: 5
			},
			{
				row: 9,
				col: 10
			},
			{
				row: 10,
				col: 15
			},
			{
				row: 15,
				col: 2
			},
			{
				row: 16,
				col: 7
			},
			{
				row: 17,
				col: 12
			}
		]
	}
], Ae = [
	[
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	],
	[
		5,
		1,
		8,
		-3,
		3,
		10,
		-2,
		5,
		-7
	],
	[
		15,
		9,
		15,
		2,
		8,
		13,
		1,
		7,
		-6
	],
	[
		18,
		16,
		14,
		12,
		10,
		8,
		6,
		4,
		2
	],
	[
		13,
		15,
		6,
		15,
		7,
		-2,
		8,
		-1,
		9
	],
	[
		3,
		7,
		-1,
		10,
		2,
		-5,
		5,
		-3,
		8
	]
];
function je(e) {
	let t = Ae[e % 6], n = [];
	for (let e = 0; e < 19; e += 1) e < 9 ? n.push(e + t[e]) : e === 9 ? n.push(9) : n.push(e - t[18 - e]);
	return n;
}
var j = [
	0,
	1,
	2,
	3,
	4,
	5
].map(je);
function M(e) {
	return !!e && e !== "gaia" && e !== "transdim" && e !== "asteroid" && e !== "protoplanet" && e !== "lostplanet";
}
function Me(e, t) {
	return [
		[e - 1, t - 1],
		[e - 1, t + 1],
		[e, t - 2],
		[e, t + 2],
		[e + 1, t - 1],
		[e + 1, t + 1]
	];
}
function Ne(e, t) {
	let n = Math.abs(e.row - t.row), r = Math.abs(e.col - t.col);
	return Math.max(n, (n + r) / 2);
}
function Pe(e, t = !1) {
	return t && e === 3 ? {
		sectors: [
			"1",
			"2",
			"3",
			"4",
			"5outlined",
			"6outlined",
			"7outlined",
			"9",
			"10"
		],
		origins: [
			{
				row: 0,
				col: 3
			},
			{
				row: 1,
				col: 8
			},
			{
				row: 2,
				col: 13
			},
			{
				row: 7,
				col: 0
			},
			{
				row: 8,
				col: 5
			},
			{
				row: 9,
				col: 10
			},
			{
				row: 15,
				col: 2
			},
			{
				row: 16,
				col: 7
			},
			{
				row: 17,
				col: 12
			}
		]
	} : ke[Math.min(Math.max(e, 1), 3) - 1];
}
var Fe = [
	"asteroid",
	"asteroid",
	"asteroid",
	"asteroid",
	"asteroid",
	"protoplanet",
	"protoplanet",
	"terra",
	"swamp",
	"desert",
	"oxide",
	"titanium",
	"volcanic",
	"ice",
	"terra",
	"swamp",
	"desert",
	"oxide",
	"titanium",
	"volcanic",
	"ice"
];
function N(t, n, r, i) {
	let a = r, o = new Set(t.map((e) => `${e.row},${e.col}`)), s = [];
	for (let e of t) for (let [t, n] of Me(e.row, e.col)) {
		let e = `${t},${n}`;
		o.has(e) || (o.add(e), s.push({
			row: t,
			col: n
		}));
	}
	let c = t.reduce((e, t) => e + t.row, 0) / t.length, l = t.reduce((e, t) => e + t.col, 0) / t.length, u = s.map((e) => ({
		p: e,
		angle: Math.atan2(e.row - c + (e.col - l) / 4, .75 * (e.col - l))
	})).sort((e, t) => e.angle - t.angle), d = i <= 2 ? 3 : 4, f = i <= 2 ? 6 : 8, p = e(n, a++, u.length), m = u.map(({ p: e }) => e), h = [m.splice(p, 1)[0]];
	for (; h.length < d;) {
		let e = 0, t = -1;
		for (let [n, r] of m.entries()) {
			let i = Math.min(...h.map((e) => Ne(e, r)));
			i > t && (e = n, t = i);
		}
		h.push(m.splice(e, 1)[0]);
	}
	let g = h.map(({ row: e, col: t }, n) => ({
		id: `dock-${n + 1}`,
		slot: 20 + n,
		sectorId: `I${n + 1}`,
		index: 0,
		row: e,
		col: t,
		planet: null,
		outer: !1
	})), _ = u.filter(({ p: e }) => !h.includes(e)), v = Array(f).fill(0), y = _.map((e, t) => {
		let n = Math.min(f - 1, Math.floor(t * f / _.length)), r = `O${n + 1}`, i = v[n];
		return v[n] += 1, {
			id: `${r}-${i}`,
			slot: 10 + n,
			sectorId: r,
			index: i,
			row: e.p.row,
			col: e.p.col,
			planet: null,
			outer: !0
		};
	}), b = new Map(t.map((e) => [`${e.row},${e.col}`, e]));
	for (let t of y) {
		let r = /* @__PURE__ */ new Set();
		for (let [e, n] of Me(t.row, t.col)) {
			let t = b.get(`${e},${n}`);
			t?.planet && M(t.planet) && r.add(t.planet);
		}
		let i = null;
		for (let t = 0; t < 12 && !i; t += 1) {
			let t = Fe[e(n, a, Fe.length)] ?? null;
			a += 1, t && !r.has(t) && (i = t);
		}
		i ||= Fe.filter((e) => !r.has(e))[0] ?? null, t.planet = i, b.set(`${t.row},${t.col}`, t);
	}
	return {
		hexes: [...y, ...g],
		docks: g.map(({ id: e }) => e),
		cursor: a
	};
}
function Ie(t, n, r, i = !1) {
	let a = Pe(t, i), o = r, s = (e, t) => {
		let n = [];
		return e.forEach((e, r) => {
			let i = Oe[e], o = a.origins[r], s = j[t[r]], c = /* @__PURE__ */ new Map();
			for (let e of i.planets) c.set(e.index, Ee[e.code]);
			for (let t = 0; t < 19; t += 1) {
				let i = Te[t];
				n.push({
					id: `${r}-${t}`,
					slot: r,
					sectorId: e,
					index: t,
					row: o.row + i.row,
					col: o.col + i.col,
					planet: c.get(s[t]) ?? null,
					outer: !1
				});
			}
		}), n;
	}, c = (e) => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e) t.set(`${n.row},${n.col}`, n);
		let n = 0;
		for (let r of e) if (M(r.planet)) for (let [e, i] of Me(r.row, r.col)) {
			let a = t.get(`${e},${i}`);
			a && M(a.planet) && a.planet === r.planet && (n += 1);
		}
		return n;
	}, l = (e) => {
		if (!i) return {
			hexes: e,
			cursor: o,
			docks: []
		};
		let r = N(e, n, o, t);
		return o = r.cursor, {
			hexes: [...e, ...r.hexes],
			cursor: o,
			docks: r.docks
		};
	}, u = null, d = Infinity;
	for (let t = 0; t < 240; t += 1) {
		let t = [...a.sectors];
		for (let r = t.length - 1; r > 0; --r) {
			let i = e(n, o, r + 1);
			o += 1, [t[r], t[i]] = [t[i], t[r]];
		}
		let r = s(t, t.map(() => {
			let t = e(n, o, 6);
			return o += 1, t;
		})), i = c(r);
		if (i === 0) return l(r);
		i < d && (d = i, u = r);
	}
	return l(u);
}
function Le(e, t) {
	return Ne(e, t) === 1;
}
//#endregion
//#region src/game/lostfleet.ts
var Re = [
	"terra",
	"swamp",
	"desert",
	"oxide",
	"titanium",
	"volcanic",
	"ice"
], ze = {
	1: [
		"eclipse",
		"twilight",
		"tfmars"
	],
	2: [
		"eclipse",
		"twilight",
		"tfmars"
	],
	3: [
		"eclipse",
		"twilight",
		"tfmars",
		"rebellion"
	],
	4: [
		"eclipse",
		"twilight",
		"tfmars",
		"rebellion"
	]
}, Be = Object.fromEntries([
	{
		id: "eclipse",
		name: "shipEclipse",
		charges: [
			0,
			2,
			3,
			3
		],
		actions: [
			{
				id: "e_qic",
				pay: "qic",
				cost: { qic: 2 },
				reward: {
					kind: "vpPerType",
					base: 2
				}
			},
			{
				id: "e_power",
				pay: "power",
				cost: {
					power: 3,
					knowledge: 2
				},
				reward: { kind: "advanceResearch" }
			},
			{
				id: "e_credits",
				pay: "credits",
				cost: { credits: 6 },
				reward: { kind: "freeAsteroidMine" }
			}
		]
	},
	{
		id: "twilight",
		name: "shipTwilight",
		charges: [
			0,
			2,
			3,
			3
		],
		actions: [
			{
				id: "t_qic",
				pay: "qic",
				cost: { qic: 2 },
				reward: { kind: "repeatFed" }
			},
			{
				id: "t_power",
				pay: "power",
				cost: {
					power: 3,
					ores: 2
				},
				reward: { kind: "freeUpgradeRl" }
			},
			{
				id: "t_knowledge",
				pay: "knowledge",
				cost: { knowledge: 1 },
				reward: { kind: "range3" }
			}
		]
	},
	{
		id: "tfmars",
		name: "shipTfMars",
		charges: [
			0,
			2,
			3,
			3
		],
		actions: [
			{
				id: "m_qic",
				pay: "qic",
				cost: { qic: 2 },
				reward: { kind: "standardTech" }
			},
			{
				id: "m_power",
				pay: "power",
				cost: { power: 2 },
				reward: { kind: "gaiaProject" }
			},
			{
				id: "m_credits",
				pay: "credits",
				cost: { credits: 3 },
				reward: { kind: "freeMine1" }
			}
		]
	},
	{
		id: "rebellion",
		name: "shipRebellion",
		charges: [
			0,
			2,
			3,
			3
		],
		actions: [
			{
				id: "r_qic",
				pay: "qic",
				cost: { qic: 2 },
				reward: { kind: "tech" }
			},
			{
				id: "r_power",
				pay: "power",
				cost: {
					power: 3,
					ores: 1
				},
				reward: { kind: "freeUpgradeTs" }
			},
			{
				id: "r_knowledge",
				pay: "knowledge",
				cost: { knowledge: 2 },
				reward: {
					kind: "creditsQic",
					credits: 2,
					qic: 1
				}
			}
		]
	}
].map((e) => [e.id, e])), Ve = [
	{
		id: "art_mine1",
		name: "artifactVpMine",
		effect: {
			kind: "vpMine",
			vp: 7
		}
	},
	{
		id: "art_mine2",
		name: "artifactVpMine",
		effect: {
			kind: "vpMine",
			vp: 7
		}
	},
	{
		id: "art_terra",
		name: "artifactVpTerra",
		effect: {
			kind: "vpPerResearch",
			track: "terra",
			per: 3
		}
	},
	{
		id: "art_nav",
		name: "artifactVpNav",
		effect: {
			kind: "vpPerResearch",
			track: "nav",
			per: 3
		}
	},
	{
		id: "art_ai",
		name: "artifactVpAi",
		effect: {
			kind: "vpPerResearch",
			track: "ai",
			per: 3
		}
	},
	{
		id: "art_gaia",
		name: "artifactVpGaia",
		effect: {
			kind: "vpPerResearch",
			track: "gaia",
			per: 3
		}
	},
	{
		id: "art_eco",
		name: "artifactVpEco",
		effect: {
			kind: "vpPerResearch",
			track: "eco",
			per: 3
		}
	},
	{
		id: "art_sci",
		name: "artifactVpSci",
		effect: {
			kind: "vpPerResearch",
			track: "sci",
			per: 3
		}
	},
	{
		id: "art_area3",
		name: "artifactVpArea3",
		effect: {
			kind: "vpPerArea3",
			vp: 3
		}
	},
	{
		id: "art_power",
		name: "artifactPowerIncome",
		effect: {
			kind: "powerIncome3",
			power: 2
		}
	},
	{
		id: "art_res1",
		name: "artifactResources",
		effect: {
			kind: "resources",
			knowledge: 1,
			ores: 1
		}
	},
	{
		id: "art_res2",
		name: "artifactResources",
		effect: {
			kind: "resources",
			credits: 3,
			power: 3
		}
	},
	{
		id: "art_res3",
		name: "artifactResources",
		effect: {
			kind: "resources",
			credits: 5,
			power: 2
		}
	}
], He = Object.fromEntries(Ve.map((e) => [e.id, e])), Ue = [
	{
		id: "tk_mine1",
		name: "tinkerMine1",
		rounds: "early",
		effect: {
			kind: "buildMine",
			freeSteps: 1
		}
	},
	{
		id: "tk_qic1",
		name: "tinkerQic1",
		rounds: "early",
		effect: {
			kind: "qic",
			n: 1
		}
	},
	{
		id: "tk_charge4",
		name: "tinkerCharge4",
		rounds: "early",
		effect: {
			kind: "charge",
			n: 4
		}
	},
	{
		id: "tk_mine3",
		name: "tinkerMine3",
		rounds: "late",
		effect: {
			kind: "buildMine",
			freeSteps: 3
		}
	},
	{
		id: "tk_knw3",
		name: "tinkerKnw3",
		rounds: "late",
		effect: {
			kind: "knowledge",
			n: 3
		}
	},
	{
		id: "tk_qic2",
		name: "tinkerQic2",
		rounds: "late",
		effect: {
			kind: "qic",
			n: 2
		}
	}
], We = Object.fromEntries(Ue.map((e) => [e.id, e])), Ge = [
	{
		id: "gold_points",
		name: "goldPoints",
		kind: "points",
		vp: 12,
		green: !0
	},
	{
		id: "gold_mineRange",
		name: "goldMineRange",
		kind: "mineRange",
		vp: 0,
		green: !0
	},
	{
		id: "gold_tech",
		name: "goldTech",
		kind: "tech",
		vp: 0,
		green: !0
	},
	{
		id: "gold_mine3",
		name: "goldMine3",
		kind: "mine3",
		vp: 0,
		green: !0
	}
], Ke = Object.fromEntries(Ge.map((e) => [e.id, e]));
function P(e, t) {
	return e.players[t];
}
function qe(e, t) {
	return e.players.findIndex((e) => e.rid === t);
}
function F(e, t) {
	return e.hexes.find((e) => e.id === t);
}
function I(e, t, n, r, i) {
	e.log.push(i == null ? {
		rid: t,
		kind: n,
		value: r
	} : {
		rid: t,
		kind: n,
		value: r,
		n: i
	});
}
function L(e, t) {
	e.vp += t;
}
function R(e, t) {
	e.credits = Math.min(30, e.credits + Math.max(0, t));
}
function z(e, t) {
	e.ores = Math.min(15, e.ores + Math.max(0, t));
}
function B(e, t) {
	e.knowledge = Math.min(15, e.knowledge + Math.max(0, t));
}
function V(e, t) {
	if (!(t <= 0)) {
		if (e.faction === "gleens" && !e.academies.includes("right")) {
			z(e, t);
			return;
		}
		e.qic = Math.min(15, e.qic + t);
	}
}
function Je(e, t) {
	return e.credits < t ? !1 : (e.credits -= t, !0);
}
function Ye(e, t) {
	return e.ores < t ? !1 : (e.ores -= t, !0);
}
function Xe(e, t) {
	return e.knowledge < t ? !1 : (e.knowledge -= t, !0);
}
function Ze(e, t) {
	return e.qic < t ? !1 : (e.qic -= t, !0);
}
function Qe(e) {
	return e.power[0] + e.power[1] + e.power[2];
}
function $e(e, t) {
	let n = Math.max(0, 50 - Qe(e) - e.gaiaPower), r = Math.min(n, Math.max(0, t));
	return e.power[0] += r, r;
}
function et(e, t) {
	let n = Math.max(0, t), r = 0;
	for (; n > 0;) {
		if (e.power[0] > 0) --e.power[0], e.power[1] += 1;
		else if (e.brainstone === "I") e.brainstone = "II";
		else if (e.power[1] > 0) --e.power[1], e.power[2] += 1;
		else if (e.brainstone === "II") e.brainstone = "III";
		else break;
		r += 1, --n;
	}
	return r;
}
function tt(e) {
	return e.power[0] + e.power[1] + +(e.brainstone === "I" || e.brainstone === "II");
}
function H(e, t) {
	let n = Math.max(0, t), r = 0;
	for (let t of [
		0,
		1,
		2
	]) for (; n > 0 && e.power[t] > 0;) --e.power[t], --n, r += 1;
	return r;
}
function nt(e) {
	let t = new Set(e.advTechs.map((e) => e.covers));
	return [...e.techs.filter((e) => !t.has(e)), ...e.advTechs.map((e) => e.id)];
}
function rt(e, t) {
	return nt(e).some((e) => {
		let n = O[e];
		return n?.effect.kind === "passive" && n.effect.passive === t;
	});
}
function it(e, t, n) {
	let r = qe(e, t.rid);
	if (n.parasite === r) return we.mine;
	if (!n.structure || n.structure.seat !== r) return 0;
	let i = n.structure.type, a = we[i];
	return (i === "pi" || i === "ac") && rt(t, "big4") && (a = 4), t.faction === "bescods" && t.pi && n.planet === "titanium" && (a += 1), t.powerRings.includes(n.id) && (a += 2), a;
}
function at(e) {
	let t = e.tracks[T.nav];
	return (t <= 1 ? 1 : t <= 3 ? 2 : t === 4 ? 3 : 4) + +!!rt(e, "range1");
}
function U(e, t) {
	return e.hexes.filter((e) => e.structure?.seat === t || e.parasite === t || e.station === t || e.lostPlanet === t);
}
function W(e, t, n, r = 0, i = e.players[t].qic) {
	if (n.gaiaformer === t) return 0;
	let a = e.players[t], o = at(a) + r, s = U(e, t), c = null;
	for (let e of s) {
		if (e.id === n.id) continue;
		let t = Ne(e, n);
		if (t < 1) continue;
		if (t <= o) return 0;
		let r = Math.ceil((t - o) / 2);
		r > i || (c == null || r < c) && (c = r);
	}
	return c;
}
function ot(e, t, n) {
	let r = {
		kind: "blocked",
		steps: 0,
		qic: 0,
		ore: 0,
		orePerStep: 0,
		vpOnBuild: 0
	};
	if (!n.planet || n.structure || n.lostPlanet != null || n.planet === "transdim") return r;
	let i = t.tracks[T.terra], a = i <= 1 ? 3 : i === 2 ? 2 : 1;
	if (n.planet === "gaia") {
		if (n.gaiaformer === qe(e, t.rid)) return {
			kind: "gaia",
			steps: 0,
			qic: 0,
			ore: 0,
			orePerStep: 0,
			vpOnBuild: 0
		};
		let r = t.faction === "gleens" && !t.academies.includes("right"), i = t.faction === "tinkeroids" || t.faction === "darkanians" || t.faction === "spacegiants" ? 2 : 1;
		return {
			kind: "gaia",
			steps: 0,
			qic: r ? 0 : i,
			ore: +!!r,
			orePerStep: 0,
			vpOnBuild: 0
		};
	}
	return n.planet === "asteroid" ? {
		kind: "asteroid",
		steps: 0,
		qic: 0,
		ore: 0,
		orePerStep: a,
		vpOnBuild: 0
	} : n.planet === "protoplanet" ? {
		kind: "protoplanet",
		steps: 3,
		qic: 0,
		ore: 0,
		orePerStep: a,
		vpOnBuild: 6
	} : {
		kind: "normal",
		steps: (t.faction === "moweyds" || t.faction === "tinkeroids") && t.lfTerra.includes(n.planet) ? 3 : E(t.faction, n.planet),
		qic: 0,
		ore: 0,
		orePerStep: a,
		vpOnBuild: 0
	};
}
function st(e, t) {
	return e.tracks[T[t]];
}
function ct(e, t) {
	return !(st(e, t) >= 5 || e.faction === "baltaks" && t === "nav" && !e.pi);
}
function lt(e) {
	return e.fedTokens.some((e) => e.green);
}
function ut(e) {
	let t = e.fedTokens.find((e) => e.green);
	return t ? (t.green = !1, !0) : !1;
}
function dt(e, t, n, r) {
	if (!n.structure || n.structure.seat !== t) return null;
	let i = n.structure.type, a = e.players[t].faction === "bescods";
	return (r === "ts" ? i === "mine" : r === "rl" ? i === "ts" : r === "pi" ? a ? i === "rl" : i === "ts" : a ? i === "ts" : i === "rl") ? r === "ts" ? ft(e, t, n, 2) ? {
		credits: 3,
		ores: 2
	} : {
		credits: 6,
		ores: 2
	} : r === "pi" ? a ? {
		credits: 6,
		ores: 6
	} : {
		credits: 6,
		ores: 4
	} : r === "rl" ? {
		credits: 5,
		ores: 3
	} : a ? {
		credits: 6,
		ores: 4
	} : {
		credits: 6,
		ores: 6
	} : null;
}
function G(e, t) {
	let n = qe(e, t.rid), r = {
		mines: 0,
		ts: 0,
		rl: 0,
		pi: 0,
		ac: 0,
		satellites: 0,
		sectors: 0,
		fedBuildings: 0,
		lostPlanet: 0,
		stations: 0
	}, i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	for (let t of e.hexes) {
		if (t.structure?.seat === n) {
			let e = t.structure.type;
			e === "mine" ? r.mines += 1 : e === "ts" ? r.ts += 1 : e === "rl" ? r.rl += 1 : e === "pi" ? r.pi += 1 : r.ac += 1, t.planet && i.add(t.planet), a.add(t.sectorId), t.federation != null && (r.fedBuildings += 1);
		}
		t.parasite === n && (r.mines += 1, a.add(t.sectorId)), t.lostPlanet === n && (r.mines += 1, r.lostPlanet += 1, i.add("lostplanet"), a.add(t.sectorId), t.federation != null && (r.fedBuildings += 1)), t.station === n && (r.stations += 1), t.satellites.includes(n) && (r.satellites += 1);
	}
	r.sectors = a.size, t.buildings = r, t.knownTypes = [...i], t.pi = r.pi > 0, t.academies = e.hexes.filter((e) => e.structure?.seat === n && e.structure.type === "ac").map((e) => e.structure?.side === "right" ? "right" : "left");
}
function ft(e, t, n, r) {
	return e.hexes.some((e) => [
		e.structure?.seat,
		e.parasite,
		e.lostPlanet,
		e.station
	].some((e) => e != null && e !== t) && Ne(e, n) <= r);
}
function pt(e, t) {
	let n = y[t.faction], r = t.buildings, i = {
		credits: n.income.credits,
		ores: n.income.ores,
		knowledge: n.income.knowledge,
		qic: n.income.qic,
		charge: 0,
		powerTokens: n.income.tokens
	};
	t.faction === "bescods" ? i.credits += [
		0,
		3,
		7,
		12
	][Math.min(r.rl, 3)] : i.credits += [
		0,
		3,
		7,
		11,
		16
	][Math.min(r.ts, 4)], i.ores += [
		0,
		1,
		2,
		2,
		3,
		4,
		5,
		6,
		7
	][Math.min(r.mines, 8)], t.faction === "gleens" && t.pi && (i.ores += 1), t.faction === "bescods" ? i.knowledge += r.ts : t.faction !== "nevlas" && (i.knowledge += r.rl), t.academies.includes("left") && (i.knowledge += t.faction === "itars" ? 3 : 2), t.faction === "xenos" && t.pi && (i.qic += 1), t.pi && (i.charge += 4, i.powerTokens += {
		ambas: 2,
		baltaks: 1,
		bescods: 2,
		firaks: 1,
		geodens: 1,
		gleens: 0,
		hadschhallas: 1,
		itars: 1,
		ivits: 1,
		lantids: 0,
		nevlas: 1,
		taklons: 1,
		terrans: 1,
		xenos: 0,
		spacegiants: 0,
		moweyds: 0,
		darkanians: 0,
		tinkeroids: 0
	}[t.faction]), t.faction === "nevlas" && (i.charge += r.rl * 2);
	let a = [
		{
			credits: 0,
			ores: 0,
			charge: 0
		},
		{
			credits: 2,
			ores: 0,
			charge: 1
		},
		{
			credits: 2,
			ores: 1,
			charge: 2
		},
		{
			credits: 3,
			ores: 1,
			charge: 3
		},
		{
			credits: 4,
			ores: 2,
			charge: 4
		}
	], o = t.tracks[T.eco], s = a[Math.min(o, 4)];
	i.credits += s.credits, i.ores += s.ores, i.charge += s.charge;
	let c = t.tracks[T.sci];
	if (c >= 1 && c <= 4 && (i.knowledge += c), t.booster) {
		let e = me[t.booster];
		e?.income && (i.credits += e.income.credits ?? 0, i.ores += e.income.ores ?? 0, i.knowledge += e.income.knowledge ?? 0, i.qic += e.income.qic ?? 0, i.charge += e.income.power ?? 0, i.powerTokens += e.income.tokens ?? 0);
	}
	let l = nt(t);
	for (let e of l) {
		let t = O[e];
		t && t.effect.kind === "income" && (i.credits += t.effect.credits ?? 0, i.ores += t.effect.ores ?? 0, i.knowledge += t.effect.knowledge ?? 0, i.charge += t.effect.power ?? 0);
	}
	return i;
}
//#endregion
//#region src/game/score.ts
function mt(e) {
	e.players.forEach((t) => G(e, t));
	let t = /* @__PURE__ */ new Map();
	for (let n of e.players) {
		let r = gt(e, n), i = yt(n), a = Math.floor((n.credits + n.knowledge + n.ores) / 3);
		L(n, i + a), t.set(n.rid, {
			rid: n.rid,
			total: 0,
			fedBuildings: r.fedBuildings,
			buildings: r.buildings,
			types: r.types,
			gaia: r.gaia,
			sectors: r.sectors,
			satellites: r.satellites,
			vp: n.vp,
			research: i,
			resources: a,
			asteroids: r.asteroids,
			piAcademy: r.piAcademy,
			outerSectors: r.outerSectors,
			awards: []
		});
	}
	let n = e.players.length <= 2, r = [...t.values()];
	if (n) {
		let e = _t(), t = {
			rid: "$ghost",
			total: 0,
			fedBuildings: e.fedBuildings,
			buildings: e.buildings,
			types: e.types,
			gaia: e.gaia,
			sectors: e.sectors,
			satellites: e.satellites,
			vp: 0,
			research: 0,
			resources: 0,
			asteroids: e.asteroids,
			piAcademy: e.piAcademy,
			outerSectors: e.outerSectors,
			awards: []
		};
		r.push(t);
	}
	for (let t of e.finalTiles) {
		let e = r.map((e) => ({
			row: e,
			value: ht(e, t)
		})).sort((e, t) => t.value - e.value), n = [
			18,
			12,
			6,
			0
		], i = 0;
		for (; i < e.length;) {
			let r = i;
			for (; r + 1 < e.length && e[r + 1].value === e[i].value;) r += 1;
			let a = e.slice(i, r + 1), o = n.slice(i, i + a.length).reduce((e, t) => e + t, 0), s = t === "lf_piAcademy" && a[0].value === 0 ? 0 : Math.floor(o / a.length);
			for (let e of a) e.row.awards.push({
				id: t,
				count: e.value,
				vp: s
			}), e.row.total += s;
			if (a.every((e) => e.value === 0)) break;
			i = r + 1;
		}
	}
	let i = [...t.values()];
	for (let t of i) {
		t.total += t.vp;
		let n = e.players.find((e) => e.rid === t.rid);
		n.vp = t.total;
	}
	for (let e of r) e.rid === "$ghost" && (e.total += e.vp);
	let a = [...i].sort((e, t) => t.total - e.total), o = a[0]?.total ?? 0;
	return {
		winners: a.filter((e) => e.total === o).map((e) => e.rid),
		rows: r,
		ghost: n
	};
}
function ht(e, t) {
	switch (t) {
		case "fedBuildings": return e.fedBuildings;
		case "buildings": return e.buildings;
		case "types": return e.types;
		case "gaiaPlanets": return e.gaia;
		case "sectors": return e.sectors;
		case "satellites": return e.satellites;
		case "lf_asteroids": return e.asteroids;
		case "lf_piAcademy": return e.piAcademy;
		case "lf_outerSectors": return e.outerSectors;
		default: return 0;
	}
}
function gt(e, t) {
	let n = e.players.findIndex((e) => e.rid === t.rid), r = 0, i = 0, a = 0, o = /* @__PURE__ */ new Set(), s = [], c = [];
	for (let t of e.hexes) t.structure?.seat === n && (t.planet === "gaia" && (r += 1), t.planet === "asteroid" && (i += 1), t.outer && o.add(t.sectorId), t.structure.type === "pi" && s.push(t), t.structure.type === "ac" && c.push(t)), t.parasite === n && (t.planet === "asteroid" && (i += 1), t.outer && o.add(t.sectorId)), t.lostPlanet === n && t.outer && o.add(t.sectorId);
	let l = o.size;
	for (let e of s) for (let t of c) a = Math.max(a, Ne(e, t));
	return {
		fedBuildings: t.buildings.fedBuildings,
		buildings: t.buildings.mines + t.buildings.ts + t.buildings.rl + t.buildings.pi + t.buildings.ac,
		types: t.knownTypes.length,
		gaia: r,
		sectors: t.buildings.sectors,
		satellites: t.buildings.satellites + t.buildings.stations,
		asteroids: i,
		piAcademy: a,
		outerSectors: l
	};
}
function _t() {
	return {
		fedBuildings: 10,
		buildings: 11,
		types: 5,
		gaia: 4,
		sectors: 6,
		satellites: 8,
		asteroids: 0,
		piAcademy: 0,
		outerSectors: 0
	};
}
function vt(e) {
	if (e.phase !== "done" || !e.result) return { phase: e.phase };
	let t = {};
	for (let n of e.result.rows) n.rid !== "$ghost" && (t[n.rid] = n.total);
	let n = [...e.result.rows].filter((e) => e.rid !== "$ghost").sort((e, t) => t.total - e.total).map((e) => e.rid);
	return {
		phase: e.phase,
		winner: e.result.winners,
		ranking: n,
		scores: t
	};
}
function yt(e) {
	return e.tracks.reduce((e, t) => e + Math.max(0, t - 2) * 4, 0);
}
//#endregion
//#region src/game/actions.ts
var K = (e) => ({ code: `games.gaiaproject.${e}` });
function bt(e, t, n) {
	let r = qe(e, t);
	if (r < 0) return K("errSeat");
	if (e.phase === "done") return K("errDone");
	if (n.type === "charge") return Ot(e, r, n.take);
	if (e.pending) return K("errPending");
	if (e.roundDecision) {
		if (e.roundDecision.seat !== r) return K("errNotYourTurn");
		let t = P(e, r);
		if (e.roundDecision.kind === "tinker" && n.type === "tinkerPick") return q(e, r).includes(n.tile) ? (t.tinkerTile = n.tile, t.usedTinkerTiles.push(n.tile), I(e, t.rid, "tinkerPick", n.tile), e.roundDecision = null, e.activeSeat = e.turnSeat, null) : K("errAbility");
		if (e.roundDecision.kind === "itars") {
			if (n.type === "gaiaFinish") return wt(e), null;
			if (n.type === "faction" && n.kind === "itarsTech") {
				if (t.gaiaPower < 4) return K("errPower");
				t.gaiaPower -= 4;
				let i = Vt(e, r, n);
				return i.error ? i.error : (i.placedHex && Et(e, r, [i.placedHex]) || (t.gaiaPower < 4 || kn(e, r).length === 0) && wt(e), null);
			}
		}
		return K("errPhase");
	}
	if (e.phase === "draft") return n.type === "draft" ? e.draftSeat === r ? kt(e, r, n.booster) : K("errNotYourTurn") : K("errPhase");
	if (e.phase !== "play" || n.type === "draft") return K("errPhase");
	let i = P(e, r);
	if (e.turnSeat !== r) return K("errNotYourTurn");
	if (i.passed) return K("errPassed");
	switch (n.type) {
		case "build": return X(e, r, n);
		case "gaia": return It(e, r, n);
		case "upgrade": return zt(e, r, n);
		case "federation": return Xt(e, r, n);
		case "research": return Ut(e, r, n);
		case "power": return nn(e, r, n);
		case "qic": return Z(e, r, n);
		case "free": return an(e, r, n);
		case "useTile": return sn(e, r, n);
		case "academy": return cn(e, r);
		case "faction": return ln(e, r, n);
		case "explore": return dn(e, r, n);
		case "examine": return fn(e, r, n);
		case "shipAction": return mn(e, r, n);
		case "booster": return un(e, r, n);
		case "pass": return _n(e, r, n.booster ?? void 0);
		default: return K("errAction");
	}
}
function xt(e) {
	let t = e.players.length;
	for (let n = 1; n <= t; n += 1) {
		let r = (e.turnSeat + n) % t;
		if (!e.players[r].passed) {
			e.turnSeat = r, e.activeSeat = r;
			return;
		}
	}
	St(e);
}
function St(e) {
	for (let t of e.players) t.tinkerTile = null;
	if (e.round >= 6) {
		e.phase = "done", e.result = mt(e), I(e, "$engine", "gameEnd", "");
		return;
	}
	e.round += 1;
	for (let t of e.players) t.passed = !1, t.usedAbilities = [], t.usedTiles = [];
	for (let t of e.ships) t.usedActions = [];
	e.usedPower = [], e.usedQic = [], e.pending = null, e.turnSeat = e.firstSeat, e.activeSeat = e.firstSeat, I(e, "$engine", "round", "", e.round), Ct(e);
}
function Ct(e) {
	for (let t of e.players) {
		let n = Tt(e, t);
		R(t, n.credits), z(t, n.ores), B(t, n.knowledge), V(t, n.qic), et(t, n.charge), $e(t, n.powerTokens);
	}
	for (let t of e.hexes) t.gaiaformer != null && (t.gaiaformed = !0, t.planet = "gaia");
	let t = e.players.findIndex((t, n) => t.faction === "itars" && t.pi && t.gaiaPower >= 4 && kn(e, n).length > 0);
	if (t >= 0) {
		e.roundDecision = {
			kind: "itars",
			seat: t
		}, e.activeSeat = t;
		return;
	}
	wt(e);
}
function wt(e) {
	for (let t of e.players) {
		let e = t.gaiaPower;
		t.gaiaPower = 0, e > 0 && (t.faction === "terrans" ? t.power[1] += e : t.power[0] += e), t.brainstone === "gaia" && (t.brainstone = "I"), t.gaiaformersGaia > 0 && (t.gaiaformers += t.gaiaformersGaia, t.gaiaformersGaia = 0);
	}
	let t = e.players.findIndex((e) => e.faction === "tinkeroids");
	t >= 0 ? (e.players[t].tinkerTile = null, e.roundDecision = {
		kind: "tinker",
		seat: t
	}, e.activeSeat = t) : (e.roundDecision = null, e.activeSeat = e.turnSeat);
}
function q(e, t) {
	let n = e.round <= 3 ? "early" : "late";
	return Ue.filter((r) => r.rounds === n && !e.players[t].usedTinkerTiles.includes(r.id)).map(({ id: e }) => e);
}
function Tt(e, t) {
	return pt(e, t);
}
function J(e, t, n = []) {
	let r = n.filter((e) => e != null);
	r.length > 0 && Et(e, t, r) || xt(e);
}
function Et(e, t, n) {
	let r = e.players.length, i = [];
	for (let a = 1; a < r; a += 1) {
		let o = (t + a) % r, s = e.players[o], c = 0;
		for (let t of e.hexes) {
			if (!Y(t, n)) continue;
			let r = Dt(e, o, t);
			r > c && (c = r);
		}
		if (c <= 0) continue;
		let l = Math.min(c, tt(s), s.vp + 1);
		l <= 0 || i.push({
			seat: o,
			power: l,
			vp: l - 1
		});
	}
	return i.length !== 0 && (e.pending = {
		queue: i,
		builder: t
	}, e.activeSeat = i[0].seat, !0);
}
function Y(e, t) {
	for (let n of t) {
		let t = Ne(e, n);
		if (t >= 1 && t <= 2) return !0;
	}
	return !1;
}
function Dt(e, t, n) {
	let r = e.players[t];
	return n.parasite === t ? we.mine : n.structure?.seat === t ? it(e, r, n) : n.lostPlanet === t || n.station === t ? we.mine : 0;
}
function Ot(e, t, n) {
	let r = e.pending;
	if (!r || r.queue[0]?.seat !== t) return K("errCharge");
	let i = r.queue.shift();
	if (n) {
		let n = e.players[t], r = et(n, i.power);
		i.vp > 0 && L(n, -i.vp), n.faction === "taklons" && n.pi && $e(n, 1), I(e, n.rid, "charge", "charge", r);
	}
	if (r.queue.length === 0) {
		if (e.pending = null, e.roundDecision?.kind === "itars") {
			let t = e.roundDecision.seat;
			e.players[t].gaiaPower < 4 || kn(e, t).length === 0 ? wt(e) : e.activeSeat = t;
		} else xt(e);
	} else e.pending = {
		queue: r.queue,
		builder: r.builder
	}, e.activeSeat = r.queue[0].seat;
	return null;
}
function kt(e, t, n) {
	let r = e.boosterPool.indexOf(n);
	if (r < 0) return K("errBooster");
	e.boosterPool.splice(r, 1);
	let i = P(e, t);
	i.booster = n, I(e, i.rid, "draft", n);
	let a = e.draftOrder.indexOf(t), o = a + 1 < e.draftOrder.length ? e.draftOrder[a + 1] : null;
	return e.draftSeat = o, o ?? (e.phase = "play", e.firstSeat = 0, e.turnSeat = 0, e.activeSeat = 0, Ct(e)), null;
}
var At = {
	credits: 2,
	ores: 1
};
function jt(e, t, n = 0, r = 0) {
	let i = P(e, t), a = [];
	if (i.buildings.mines >= k.mine) return a;
	for (let o of e.hexes) {
		if (o.lostPlanet != null || o.planet == null) continue;
		if (o.structure && o.structure.seat !== t) {
			if (i.faction === "lantids" && o.parasite == null) {
				let n = W(e, t, o);
				if (n == null || n > i.qic) continue;
				a.push({
					hex: o,
					parasite: !0,
					steps: 0,
					stepOre: 0,
					oreCost: At.ores,
					credits: At.credits,
					qic: n,
					range: n,
					asteroid: !1,
					prototype: !1
				});
			}
			continue;
		}
		if (o.structure || o.planet === "transdim" || o.planet === "gaia" && o.gaiaformer != null && o.gaiaformer !== t) continue;
		let s = W(e, t, o, n);
		if (s == null) continue;
		let c = ot(e, i, o);
		if (c.kind === "blocked" || c.kind === "asteroid" && i.gaiaformers < 1) continue;
		let l = s + c.qic;
		if (l > i.qic) continue;
		let u = Math.max(0, c.steps - r);
		a.push({
			hex: o,
			parasite: !1,
			steps: c.steps,
			stepOre: c.orePerStep,
			oreCost: c.kind === "asteroid" ? 0 : 1 + u * c.orePerStep + c.ore,
			credits: c.kind === "asteroid" ? 0 : 2,
			qic: l,
			range: s,
			asteroid: c.kind === "asteroid",
			prototype: c.kind === "protoplanet"
		});
	}
	return a;
}
function Mt(e, t, n = 0) {
	let r = P(e, t), i = [];
	if (r.gaiaformers < 1 || r.tracks[T.gaia] < 1) return i;
	let a = ie(r.tracks[T.gaia]);
	if (r.power[2] + +(r.brainstone === "III") < a) return i;
	for (let o of e.hexes) {
		if (o.planet !== "transdim" || o.gaiaformer != null || o.structure) continue;
		let s = W(e, t, o, n);
		s == null || s > r.qic || i.push({
			hex: o.id,
			power: a,
			qic: s
		});
	}
	return i;
}
function X(e, t, n) {
	return Nt(e, t, {
		hex: n.hex,
		payQic: n.payQic,
		parasite: n.parasite === !0
	});
}
function Nt(e, t, n) {
	let r = P(e, t), i = F(e, n.hex);
	if (!i) return K("errHex");
	if (i.lostPlanet != null) return K("errOccupied");
	if (i.planet == null) return K("errNoPlanet");
	let a = n.parasite === !0;
	if (a) {
		if (r.faction !== "lantids" || !i.structure || i.structure.seat === t || i.parasite != null) return K("errParasite");
		if (r.buildings.mines >= k.mine) return K("errSupply");
		let a = n.skipRange ? 0 : W(e, t, i) ?? null;
		if (a == null) return K("errUnreachable");
		let o = n.rangeBonus ? Math.max(0, a - n.rangeBonus) : a;
		return o !== n.payQic || !Ze(r, o) ? K("errQic") : Je(r, At.credits) ? Ye(r, At.ores) ? (i.parasite = t, r.faction === "lantids" && r.pi && B(r, 2), G(e, r), yn(e, r, {
			gaia: !1,
			sectorNew: !1,
			typeNew: !1
		}), I(e, r.rid, "parasite", i.id, 1), J(e, t, [i]), null) : K("errOres") : K("errCredits");
	}
	if (i.structure) return K("errOccupied");
	if (i.planet === "transdim") return K("errTransdim");
	if (i.planet === "gaia" && i.gaiaformer != null && i.gaiaformer !== t) return K("errGaiaformerBlock");
	let o = ot(e, r, i);
	if (o.kind === "blocked") return K("errNoPlanet");
	if (r.buildings.mines >= k.mine) return K("errSupply");
	let s = n.skipRange ? 0 : W(e, t, i, n.rangeBonus ?? 0);
	if (s == null) return K("errUnreachable");
	let c = s + o.qic;
	if (c !== n.payQic || !Ze(r, c)) return K("errQic");
	if (o.kind === "asteroid") {
		if (!n.skipGaiaformer && r.gaiaformers < 1) return K("errNoGaiaformer");
	} else if (o.ore > 0 && !Ye(r, o.ore)) return K("errOres");
	let l = n.freeSteps ?? 0, u = Math.max(0, o.steps - l), d = n.freeBuildCost === !0, f = o.kind === "asteroid" ? 0 : +!d + u * o.orePerStep;
	if (o.kind !== "asteroid" && !d && !Je(r, 2)) return K("errCredits");
	if (f > 0 && !Ye(r, f)) return K("errOres");
	let p = i.planet != null && i.planet !== "gaia" && !r.knownTypes.includes(i.planet), m = !e.hexes.some((e) => e.sectorId === i.sectorId && e !== i && Pt(t, e));
	i.structure = {
		seat: t,
		type: "mine",
		side: null
	}, i.gaiaformer === t && (i.gaiaformer = null, r.gaiaformers += 1), o.kind === "asteroid" && !n.skipGaiaformer && (--r.gaiaformers, r.gaiaformersLost += 1);
	let h = i.planet === "gaia";
	return i.artifact != null && (r.artifacts.push(i.artifact), i.artifact = null, L(r, 5)), G(e, r), o.kind === "protoplanet" && L(r, 6), vn(e) === "terra2" && o.steps > 0 && L(r, 2 * o.steps), h && r.faction === "gleens" && L(r, 2), m && r.faction === "darkanians" && r.pi && (R(r, 2), B(r, 1)), h && r.faction === "geodens" && r.pi && p && B(r, 3), !h && r.faction === "geodens" && r.pi && p && B(r, 3), yn(e, r, {
		gaia: h,
		sectorNew: m,
		typeNew: p
	}), Cn(r, "gaia3vp") && h && L(r, 3), Cn(r, "mine3vp") && L(r, 3), a || Ft(e, t, i), I(e, r.rid, "build", i.id, o.steps), J(e, t, [i]), null;
}
function Pt(e, t) {
	return t.structure?.seat === e || t.parasite === e || t.lostPlanet === e || t.station === e;
}
function Ft(e, t, n) {
	let r = e.federations.find((r) => r.seat === t && r.hexes.some((t) => {
		let r = F(e, t);
		return r ? Le(r, n) || r.id === n.id : !1;
	}) || r.satellites.some((t) => {
		let r = F(e, t);
		return !!r && Le(r, n);
	}));
	r && (r.hexes.includes(n.id) || r.hexes.push(n.id), n.federation = r.id);
}
function It(e, t, n) {
	return Lt(e, t, n.hex, n.payQic, 0);
}
function Lt(e, t, n, r, i, a = !1) {
	let o = P(e, t);
	if (o.tracks[T.gaia] < 1) return K("errGaiaTrack");
	if (o.gaiaformers < 1 || n == null) return K("errNoGaiaformer");
	let s = F(e, n);
	if (!s) return K("errHex");
	if (s.planet !== "transdim") return K("errTransdim");
	if (s.gaiaformer != null) return K("errGaiaformerBlock");
	if (s.structure) return K("errOccupied");
	let c = W(e, t, s, i);
	if (c == null) return K("errUnreachable");
	if (c !== r || !Ze(o, c)) return K("errQic");
	let l = a ? 0 : ie(o.tracks[T.gaia]);
	return Rt(o, l) ? (s.gaiaformer = t, --o.gaiaformers, a && (s.gaiaformed = !0, s.planet = "gaia"), I(e, o.rid, "gaia", s.id, l), J(e, t), null) : K("errPower");
}
function Rt(e, t) {
	if (t <= 0) return !0;
	let n = e.power[2], r = +(e.brainstone === "III");
	if (n + r < t) return !1;
	let i = t;
	for (; i > 0 && n > 0;) --e.power[2], e.gaiaPower += 1, --n, --i;
	return i > 0 && e.brainstone === "III" && (e.brainstone = "gaia", e.gaiaPower += 1, --i), i <= 0;
}
function zt(e, t, n) {
	let r = P(e, t), i = F(e, n.hex);
	if (!i) return K("errHex");
	if (!i.structure || i.structure.seat !== t) return K("errOccupied");
	let a = n.to, o = dt(e, t, i, a);
	if (!o) return K("errUpgrade");
	if (a === "ts" && r.buildings.ts >= k.ts || a === "rl" && r.buildings.rl >= k.rl || a === "pi" && r.buildings.pi >= k.pi || a === "ac" && r.buildings.ac >= k.ac) return K("errSupply");
	let s = null;
	if (a === "ac" && (s = n.side ?? null, s == null || r.academies.includes(s))) return K("errSide");
	let c = a === "rl" || a === "ac" || a === "pi" && r.faction === "spacegiants" && kn(e, t).length > 0;
	if (c && !n.tech) return K("errTech");
	if (!Je(r, o.credits)) return K("errCredits");
	if (!Ye(r, o.ores)) return K("errOres");
	i.structure = {
		seat: t,
		type: a,
		side: s
	}, G(e, r), I(e, r.rid, "upgrade", i.id, 0);
	let l = [i];
	if (a === "ts" && bn(e, r, "ts"), a === "rl" && bn(e, r, "rl"), (a === "pi" || a === "ac") && bn(e, r, "big"), a === "pi" && r.faction === "gleens" && !r.fedTokens.some((e) => e.type === "gleens") && en(e, r, "gleens"), c) {
		let r = Vt(e, t, n);
		if (r.error) return r.error;
		r.placedHex && l.push(r.placedHex);
	}
	return J(e, t, l), null;
}
function Bt(e, t, n) {
	let r = P(e, t);
	return n == null ? e.lostFleet && (r.vp >= 25 || e.players.length >= 3 && e.ships.filter((e) => e.shuttles.includes(t)).length >= 3) : r.tracks[T[n]] >= 4;
}
function Vt(e, t, n) {
	let r = P(e, t);
	if (!n.tech) return { error: K("errTech") };
	let i;
	if (n.advanced) {
		let i = e.advancedTiles.find((e) => e.id === n.tech);
		if (!i) return { error: K("errTechUnavailable") };
		if (r.advTechs.some((e) => e.id === i.id)) return { error: K("errTechOwned") };
		if (!Bt(e, t, i.track)) return { error: K("errTechTrack") };
		if (!lt(r)) return { error: K("errNoGreen") };
		let a = n.cover;
		return !a || !r.techs.includes(a) || r.coveredTechs.includes(a) ? { error: K("errCover") } : (ut(r), r.coveredTechs.push(a), r.advTechs.push({
			id: i.id,
			covers: a
		}), e.advancedTiles = e.advancedTiles.filter((e) => e.id !== i.id), Ht(e, r, i.id), I(e, r.rid, "tech", i.id), n.track ? Wt(e, t, n.track, !1, n.lostHex, n.lostPayQic) : { error: null });
	}
	let a = e.techPiles.find((e) => e.id === n.tech);
	if (!a || a.remaining <= 0) return { error: K("errTechUnavailable") };
	if (r.techs.includes(a.id) || r.advTechs.some((e) => e.id === a.id)) return { error: K("errTechOwned") };
	if (--a.remaining, r.techs.push(a.id), Ht(e, r, a.id), I(e, r.rid, "tech", a.id), a.track != null) {
		let r = Wt(e, t, a.track, !0, n.lostHex, n.lostPayQic);
		if (r.error) return { error: r.error };
		i = r.placedHex;
	} else if (n.track) {
		let r = Wt(e, t, n.track, !1, n.lostHex, n.lostPayQic);
		if (r.error) return { error: r.error };
		i = r.placedHex;
	}
	return {
		error: null,
		placedHex: i
	};
}
function Ht(e, t, n) {
	let r = O[n];
	if (!r) return;
	let i = r.effect;
	if (i.kind === "immediate") i.credits && R(t, i.credits), i.ores && z(t, i.ores), i.knowledge && B(t, i.knowledge), i.qic && V(t, i.qic), i.vp && L(t, i.vp);
	else if (i.kind === "immediatePerType") B(t, i.knowledge * t.knownTypes.length);
	else if (i.kind === "immediatePer") {
		let n = t.buildings;
		if (i.metric === "mine" && L(t, (i.vp ?? 0) * n.mines), i.metric === "ts" && L(t, (i.vp ?? 0) * n.ts), i.metric === "federation" && L(t, (i.vp ?? 0) * t.fedTokens.length), i.metric === "sector" && L(t, (i.vp ?? 0) * n.sectors), i.metric === "gaia") {
			let n = 0;
			for (let r of e.hexes) r.structure?.seat === qe(e, t.rid) && r.planet === "gaia" && (n += 1);
			L(t, (i.vp ?? 0) * n);
		}
		i.metric === "sectorOre" && z(t, (i.ores ?? 0) * n.sectors), i.metric === "piAcademyDs" && L(t, (i.vp ?? 0) * (n.pi + n.ac + wn(e, qe(e, t.rid))));
	}
}
function Ut(e, t, n) {
	let r = P(e, t);
	if (!ct(r, n.track)) return K("errTrackMax");
	if (!Xe(r, 4)) return K("errKnowledge");
	let i = Wt(e, t, n.track, !1, n.hex, n.payQic);
	return i.error ? i.error : (J(e, t, i.placedHex ? [i.placedHex] : []), null);
}
function Wt(e, t, n, r = !1, i, a) {
	let o = P(e, t), s = T[n], c = o.tracks[s];
	if (c >= 5) return r ? { error: null } : { error: K("errTrackMax") };
	if (o.faction === "baltaks" && n === "nav" && !o.pi) return r ? { error: null } : { error: K("errBaltaksNav") };
	if (c === 4) {
		if (!lt(o)) return r ? { error: null } : { error: K("errNoGreen") };
		if (e.players.some((e) => e !== o && e.tracks[s] >= 5)) return r ? { error: null } : { error: K("errTrackFull") };
		if (n === "nav" && !i && Gt(e, t, 1).length === 0) return r ? { error: null } : { error: K("errLostPlanet") };
		ut(o);
	}
	o.tracks[s] = c + 1;
	let l = c + 1;
	l === 3 && et(o, 3);
	let u;
	switch (n) {
		case "terra":
			if (l === 1 && z(o, 2), l === 4 && z(o, 2), l === 5) {
				let t = e.terraformingToken;
				t && e.fedSupply[t] > 0 && en(e, o, t);
			}
			break;
		case "nav":
			if ((l === 1 || l === 3) && V(o, 1), l === 5) {
				let n = Kt(e, t, i, a);
				if (n.error) return { error: n.error };
				u = n.hex;
			}
			break;
		case "ai":
			(l === 1 || l === 2) && V(o, 1), (l === 3 || l === 4) && V(o, 2), l === 5 && V(o, 4);
			break;
		case "gaia":
			if ((l === 1 || l === 3 || l === 4) && (o.gaiaformers = Math.min(3, o.gaiaformers + 1)), l === 2 && $e(o, 3), l === 5) {
				L(o, 4);
				for (let n of e.hexes) n.structure?.seat === t && n.planet === "gaia" && L(o, 1);
			}
			break;
		case "eco":
			l === 5 && (z(o, 3), R(o, 6), et(o, 6));
			break;
		case "sci": l === 5 && B(o, 9);
	}
	return xn(e, o), Cn(o, "research2vp") && L(o, 2), I(e, o.rid, "research", n, l), {
		error: null,
		placedHex: u
	};
}
function Gt(e, t, n = 0, r = e.players[t].qic) {
	return e.hexes.flatMap((i) => {
		if (i.planet != null || i.structure != null || i.lostPlanet != null || i.station != null || i.satellites.length > 0 || i.gaiaformer != null || e.ships.some(({ dock: e }) => e === i.id)) return [];
		let a = W(e, t, i, n, r);
		return a == null ? [] : [{
			hex: i,
			payQic: a
		}];
	});
}
function Kt(e, t, n, r) {
	let i = P(e, t), a = Gt(e, t);
	if (a.length === 0) return { error: K("errLostPlanet") };
	if (n) {
		let o = a.find(({ hex: e }) => e.id === n);
		return o ? r != null && o.payQic !== r || !Ze(i, o.payQic) ? { error: K("errQic") } : qt(e, t, o.hex) : { error: K("errLostPlanet") };
	}
	let o = a.reduce((e, t) => t.payQic < e.payQic ? t : e);
	return Ze(i, o.payQic) ? qt(e, t, o.hex) : { error: K("errQic") };
}
function qt(e, t, n) {
	let r = P(e, t), i = !e.hexes.some((e) => e.sectorId === n.sectorId && Pt(t, e));
	return n.lostPlanet = t, G(e, r), i && r.faction === "darkanians" && r.pi && (R(r, 2), B(r, 1)), yn(e, r, {
		gaia: !1,
		sectorNew: i,
		typeNew: !0
	}), I(e, r.rid, "lostPlanet", n.id), {
		error: null,
		hex: n
	};
}
function Jt(e) {
	return e.faction === "xenos" && e.pi ? 6 : 7;
}
function Yt(e, t, n) {
	return n.structure?.seat === t ? it(e, e.players[t], n) : n.parasite === t || n.lostPlanet === t || n.station === t ? we.mine : null;
}
function Xt(e, t, n) {
	let r = P(e, t), i = [], a = /* @__PURE__ */ new Set();
	for (let r of n.hexes) {
		let n = F(e, r);
		if (!n || a.has(r) || (a.add(r), n.federation != null) || Yt(e, t, n) == null) return K("errFedHex");
		i.push(n);
	}
	if (i.length === 0) return K("errFedHex");
	let o = [];
	for (let r of n.satellites) {
		let n = F(e, r);
		if (!n || a.has(r) || e.ships.some(({ dock: e }) => e === r) || (a.add(r), n.planet != null || n.structure || n.lostPlanet != null || n.station != null) || n.satellites.includes(t)) return K("errFedSatellite");
		o.push(n);
	}
	let s = i.reduce((n, r) => n + (Yt(e, t, r) ?? 0), 0), c = e.federations.filter((e) => e.seat === t), l = r.faction === "ivits" ? c[0] : void 0;
	if (!l) for (let t of c) {
		let n = [...t.hexes, ...t.satellites].map((t) => F(e, t)).filter((e) => !!e);
		for (let e of [...i, ...o]) if (n.some((t) => Le(t, e))) return K("errFedAdjacent");
	}
	if (o.length > 0) {
		if (r.faction === "ivits") {
			if (!Ze(r, o.length)) return K("errQic");
		} else if (H(r, o.length) < o.length) return K("errPower");
	}
	if (l) {
		let a = l, c = r.fedTokens.length + 1;
		if (s + a.hexes.reduce((n, r) => {
			let i = F(e, r);
			return n + (i ? Yt(e, t, i) ?? 0 : 0);
		}, 0) < 7 * c) return K("errFedPower");
		if (!Zt(e, [...a.hexes, ...a.satellites], [...i, ...o])) return K("errFedConnected");
		for (let e of i) a.hexes.includes(e.id) || a.hexes.push(e.id), e.federation = a.id;
		for (let e of o) a.satellites.includes(e.id) || a.satellites.push(e.id), e.satellites.push(t);
		G(e, r);
		let u = Qt(e, t, n.token, n);
		return u.error ? u.error : (u.ended || J(e, t), null);
	}
	if (s < Jt(r)) return K("errFedPower");
	if (!Zt(e, [], [...i, ...o])) return K("errFedConnected");
	let u = {
		id: e.federations.length + 1,
		seat: t,
		hexes: i.map((e) => e.id),
		satellites: o.map((e) => e.id),
		token: n.token
	};
	e.federations.push(u);
	for (let e of i) e.federation = u.id;
	for (let e of o) e.satellites.push(t);
	G(e, r);
	let d = Qt(e, t, n.token, n);
	return d.error ? d.error : (I(e, r.rid, "federation", String(u.id), s), d.ended || J(e, t), null);
}
function Zt(e, t, n) {
	if (n.length === 0) return !0;
	let r = [...t.map((t) => F(e, t)), ...n].filter((e) => !!e);
	if (r.length === 0) return !0;
	let i = n[0], a = new Map(r.map((e) => [e.id, e])), o = [i.id], s = new Set(o);
	for (; o.length > 0;) {
		let e = o.shift(), t = a.get(e);
		for (let [e, n] of a) s.has(e) || Le(t, n) && (s.add(e), o.push(e));
	}
	if (t.length > 0) {
		for (let e of n) if (!s.has(e.id)) return !1;
	} else for (let e of n) if (!s.has(e.id)) return !1;
	return !0;
}
function Qt(e, t, n, r) {
	let i = P(e, t), a = Ke[n];
	if (a) {
		let o = e.ships.find((e) => e.goldToken === n && e.shuttles.includes(t));
		return o ? (o.goldToken = null, i.fedTokens.push({
			type: n,
			green: a.green
		}), I(e, i.rid, "fedToken", n, a.vp), $t(e, t, a.kind, a.vp, r)) : {
			error: K("errFedToken"),
			ended: !1
		};
	}
	return !(n in e.fedSupply) || e.fedSupply[n] <= 0 ? {
		error: K("errFedToken"),
		ended: !1
	} : (en(e, i, n), {
		error: null,
		ended: !1
	});
}
function $t(e, t, n, r, i) {
	let a = P(e, t);
	if (n === "points") return L(a, r), {
		error: null,
		ended: !1
	};
	if (n === "tech") {
		let n = Vt(e, t, {
			tech: i.goldTech,
			advanced: i.goldAdvanced,
			cover: i.goldCover,
			track: i.goldTrack,
			lostHex: i.goldLostHex,
			lostPayQic: i.goldLostPayQic
		});
		return !n.error && n.placedHex ? (J(e, t, [n.placedHex]), {
			error: null,
			ended: !0
		}) : {
			error: n.error,
			ended: !1
		};
	}
	if (!i.goldHex) return {
		error: K("errHex"),
		ended: !1
	};
	if (n === "mineRange") {
		let n = Nt(e, t, {
			hex: i.goldHex,
			payQic: i.goldPayQic,
			skipRange: !0,
			freeBuildCost: !0
		});
		return {
			error: n,
			ended: n == null
		};
	}
	if (n === "mine3") {
		let n = Nt(e, t, {
			hex: i.goldHex,
			payQic: i.goldPayQic,
			freeSteps: 3,
			freeBuildCost: !0
		});
		return {
			error: n,
			ended: n == null
		};
	}
	return {
		error: K("errAction"),
		ended: !1
	};
}
function en(e, t, n) {
	let r = ye[n];
	if (r) {
		if (n !== "gleens") {
			if (e.fedSupply[n] == null || e.fedSupply[n] <= 0) return;
			--e.fedSupply[n];
		}
		t.fedTokens.push({
			type: n,
			green: n !== "points"
		}), r.rewards.credits && R(t, r.rewards.credits), r.rewards.ores && z(t, r.rewards.ores), r.rewards.knowledge && B(t, r.rewards.knowledge), r.rewards.qic && V(t, r.rewards.qic), r.rewards.tokens && $e(t, r.rewards.tokens), r.vp > 0 && L(t, r.vp), Sn(e, t), I(e, t.rid, "fedToken", n, r.vp);
	}
}
function tn(e, t) {
	return e.some((e) => e.endsWith(`:${t}`));
}
function nn(e, t, n) {
	let r = P(e, t), i = be.find((e) => e.id === n.id);
	if (!i) return K("errAction");
	let a = `${t}:${i.id}`;
	if (tn(e.usedPower, i.id)) return K("errUsed");
	if (!rn(r, i.cost)) return K("errPower");
	if (e.usedPower.push(a), I(e, r.rid, "powerAction", i.id, i.cost), i.id === "p_terra2" || i.id === "p_terra1") {
		let r = i.id === "p_terra2" ? 2 : 1;
		return n.hex ? Nt(e, t, {
			hex: n.hex,
			payQic: n.payQic,
			freeSteps: r,
			parasite: n.parasite === !0
		}) : K("errHex");
	}
	return i.id === "p_knw3" ? B(r, 3) : i.id === "p_ore2" ? z(r, 2) : i.id === "p_credits7" ? R(r, 7) : i.id === "p_knw2" ? B(r, 2) : i.id === "p_tokens2" && $e(r, 2), J(e, t), null;
}
function rn(e, t) {
	if (t <= 0) return !0;
	let n = e.brainstone === "III" ? 3 : 0;
	if (e.faction === "nevlas" && e.pi) {
		let n = Math.ceil(t / 2);
		if (e.power[2] + +(e.brainstone === "III") < n) return !1;
		let r = n;
		for (; r > 0;) e.power[2] > 0 ? (--e.power[2], e.power[0] += 1) : e.brainstone === "III" && (e.brainstone = "I"), --r;
		return !0;
	}
	if (e.power[2] + n < t) return !1;
	let r = t;
	for (e.brainstone === "III" && e.power[2] < t && (e.brainstone = "I", r -= 3); r > 0 && e.power[2] > 0;) --e.power[2], e.power[0] += 1, --r;
	return r <= 0;
}
function Z(e, t, n) {
	if (e.lostFleet) return K("errAction");
	let r = P(e, t), i = xe.find((e) => e.id === n.id);
	if (!i) return K("errAction");
	let a = `${t}:${i.id}`;
	if (tn(e.usedQic, i.id)) return K("errUsed");
	let o = i.cost;
	if (!Ze(r, o)) return K("errQic");
	if (e.usedQic.push(a), I(e, r.rid, "qicAction", i.id, o), i.id === "q_tech") {
		let r = Vt(e, t, n);
		return r.error ? r.error : (J(e, t, r.placedHex ? [r.placedHex] : []), null);
	}
	if (i.id === "q_rescore") {
		let i = n.token;
		if (r.fedTokens.findIndex((e) => e.type === i) < 0) return K("errNoToken");
		let a = ye[i];
		return a ? (a.rewards.credits && R(r, a.rewards.credits), a.rewards.ores && z(r, a.rewards.ores), a.rewards.knowledge && B(r, a.rewards.knowledge), a.rewards.qic && V(r, a.rewards.qic), a.rewards.tokens && $e(r, a.rewards.tokens), a.vp > 0 && L(r, a.vp), J(e, t), null) : K("errNoToken");
	}
	return L(r, 3 + r.knownTypes.length), J(e, t), null;
}
function an(e, t, n) {
	let r = P(e, t), i = n.credits === !0 && r.faction === "hadschhallas" && r.pi;
	switch (n.id) {
		case "f_burn":
			if (r.power[1] < 2) return K("errPower");
			r.power[1] -= 2, r.power[2] += 1, r.faction === "itars" && (r.gaiaPower += 1);
			break;
		case "f_powQic":
			if (!on(r, 4, i)) return K("errPower");
			V(r, 1);
			break;
		case "f_powOre":
			if (!on(r, 3, i)) return K("errPower");
			z(r, 1);
			break;
		case "f_powKnw":
			if (!on(r, 4, i)) return K("errPower");
			B(r, 1);
			break;
		case "f_powCredit":
			if (!on(r, 1, i)) return K("errPower");
			R(r, 1);
			break;
		case "f_qicOre":
			if (!Ze(r, 1)) return K("errQic");
			z(r, 1);
			break;
		case "f_knwCredit":
			if (!Xe(r, 1)) return K("errKnowledge");
			R(r, 1);
			break;
		case "f_oreCredit":
			if (!Ye(r, 1)) return K("errOres");
			R(r, 1);
			break;
		case "f_orePower":
			if (!Ye(r, 1)) return K("errOres");
			$e(r, 1);
			break;
		default: return K("errAction");
	}
	return I(e, r.rid, "freeAction", n.id), null;
}
function on(e, t, n) {
	return n ? Je(e, t) : rn(e, t);
}
function sn(e, t, n) {
	let r = P(e, t), i = n.id, a = O[i];
	if (!a) return K("errAction");
	if (!r.techs.includes(i) && !r.advTechs.some((e) => e.id === i)) return K("errTechOwned");
	if (r.usedTiles.includes(i)) return K("errUsed");
	if (a.effect.kind === "freeMineTerra") return r.usedTiles.push(i), n.hex ? Nt(e, t, {
		hex: n.hex,
		payQic: n.payQic,
		freeSteps: a.effect.steps,
		skipRange: a.effect.endlessRange === !0,
		freeBuildCost: e.lostFleet
	}) : K("errHex");
	if (a.effect.kind !== "action") return K("errAction");
	switch (r.usedTiles.push(i), a.effect.action) {
		case "power4":
			$e(r, 4);
			break;
		case "qic5c":
			V(r, 1), R(r, 5);
			break;
		case "ore3":
			z(r, 3);
			break;
		case "knowledge3": B(r, 3);
	}
	return I(e, r.rid, "useTile", i), J(e, t), null;
}
function cn(e, t) {
	let n = P(e, t);
	return n.academies.includes("right") ? n.usedAbilities.includes("academy") ? K("errUsed") : (n.usedAbilities.push("academy"), n.faction === "baltaks" ? R(n, 4) : V(n, 1), I(e, n.rid, "academy", "right"), J(e, t), null) : K("errNoAcademy");
}
function ln(e, t, n) {
	let r = P(e, t);
	switch (n.kind) {
		case "swapPI": {
			if (r.faction !== "ambas" || !r.pi) return K("errAbility");
			if (r.usedAbilities.includes("swapPI")) return K("errUsed");
			if (!n.hex) return K("errHex");
			let i = F(e, n.hex);
			if (!i || i.structure?.seat !== t || i.structure.type !== "mine") return K("errHex");
			let a = e.hexes.find((e) => e.structure?.seat === t && e.structure.type === "pi");
			return a ? (a.structure = {
				seat: t,
				type: "mine",
				side: null
			}, i.structure = {
				seat: t,
				type: "pi",
				side: null
			}, r.usedAbilities.push("swapPI"), G(e, r), I(e, r.rid, "faction", "swapPI"), J(e, t), null) : K("errAbility");
		}
		case "downgradeRL": {
			if (r.faction !== "firaks" || !r.pi) return K("errAbility");
			if (!n.hex || !n.track) return K("errHex");
			let i = F(e, n.hex);
			if (!i || i.structure?.seat !== t || i.structure.type !== "rl") return K("errHex");
			i.structure = {
				seat: t,
				type: "ts",
				side: null
			}, G(e, r), bn(e, r, "ts");
			let a = Wt(e, t, n.track, !1, n.lostHex, n.lostPayQic);
			return a.error ? a.error : (I(e, r.rid, "faction", "downgradeRL"), J(e, t, a.placedHex ? [i, a.placedHex] : [i]), null);
		}
		case "advanceLowest": {
			if (r.faction !== "bescods") return K("errAbility");
			if (r.usedAbilities.includes("advanceLowest")) return K("errUsed");
			let i = Infinity;
			for (let e of r.tracks) e < 5 && (i = Math.min(i, e));
			if (!Number.isFinite(i)) return K("errTrackMax");
			let a = An(e, t).filter((e) => r.tracks[T[e]] === i), o = n.track ?? a[0];
			if (!o || !a.includes(o)) return K("errTrack");
			r.usedAbilities.push("advanceLowest");
			let s = Wt(e, t, o, !1, n.lostHex, n.lostPayQic);
			return s.error ? s.error : (I(e, r.rid, "faction", "advanceLowest"), J(e, t, s.placedHex ? [s.placedHex] : []), null);
		}
		case "baltaqGaiaformer": return r.faction === "baltaks" ? r.gaiaformers < 1 ? K("errNoGaiaformer") : (--r.gaiaformers, r.gaiaformersGaia += 1, V(r, 1), I(e, r.rid, "faction", "baltaqGaiaformer"), null) : K("errAbility");
		case "nevlasKnowledge": return r.faction === "nevlas" ? Rt(r, 1) ? (B(r, 1), I(e, r.rid, "faction", "nevlasKnowledge"), null) : K("errPower") : K("errAbility");
		case "spaceStation": {
			if (r.faction !== "ivits" || !r.pi) return K("errAbility");
			if (r.usedAbilities.includes("spaceStation")) return K("errUsed");
			if (!n.hex) return K("errHex");
			let i = F(e, n.hex);
			if (!i || i.planet != null || i.station != null || i.structure || i.lostPlanet != null || e.ships.some(({ dock: e }) => e === i.id)) return K("errHex");
			let a = W(e, t, i);
			return a == null || a !== n.payQic || !Ze(r, a) ? K("errQic") : (i.station = t, r.usedAbilities.push("spaceStation"), G(e, r), I(e, r.rid, "faction", "spaceStation"), J(e, t), null);
		}
		case "giantsMine": return r.faction === "spacegiants" ? r.permUsed.includes("giantsMine") ? K("errUsed") : n.hex ? (r.permUsed.push("giantsMine"), Nt(e, t, {
			hex: n.hex,
			payQic: n.payQic,
			freeSteps: 2
		})) : K("errHex") : K("errAbility");
		case "moweydRing": {
			if (r.faction !== "moweyds" || !r.pi) return K("errAbility");
			if (r.usedAbilities.includes("moweydRing")) return K("errUsed");
			if (!n.hex) return K("errHex");
			let i = F(e, n.hex);
			return !i || i.structure?.seat !== t || r.powerRings.includes(i.id) ? K("errHex") : (r.powerRings.push(i.id), r.usedAbilities.push("moweydRing"), I(e, r.rid, "faction", "moweydRing"), J(e, t), null);
		}
		case "tinkerAction": {
			if (r.faction !== "tinkeroids" || !r.pi) return K("errAbility");
			if (r.usedAbilities.includes("tinkerAction")) return K("errUsed");
			let i = r.tinkerTile ? We[r.tinkerTile] : null;
			if (!i) return K("errAbility");
			r.usedAbilities.push("tinkerAction");
			let a = i.effect;
			return a.kind === "buildMine" ? n.hex ? Nt(e, t, {
				hex: n.hex,
				payQic: n.payQic,
				freeSteps: a.freeSteps
			}) : K("errHex") : (a.kind === "knowledge" && B(r, a.n), a.kind === "qic" && V(r, a.n), a.kind === "charge" && et(r, a.n), I(e, r.rid, "faction", "tinkerAction"), J(e, t), null);
		}
		default: return K("errAbility");
	}
}
function un(e, t, n) {
	let r = P(e, t);
	if (r.booster !== n.id) return K("errBooster");
	let i = me[n.id];
	if (!i || i.action == null) return K("errAction");
	let a = `booster:${n.id}`;
	return r.usedAbilities.includes(a) ? K("errUsed") : (r.usedAbilities.push(a), i.action === "terraform1" ? n.hex ? Nt(e, t, {
		hex: n.hex,
		payQic: n.payQic,
		freeSteps: 1
	}) : K("errHex") : i.action === "gaiaFree" ? n.hex ? Lt(e, t, n.hex, n.payQic, 0, !0) : K("errHex") : n.mode === "gaia" ? n.hex ? Lt(e, t, n.hex, n.payQic, 3) : K("errHex") : n.hex ? Nt(e, t, {
		hex: n.hex,
		payQic: n.payQic,
		rangeBonus: 3
	}) : K("errHex"));
}
function dn(e, t, n) {
	let r = P(e, t), i = e.ships.find((e) => e.id === n.ship);
	if (!i) return K("errAction");
	if (r.shuttlesAvail < 1 || i.shuttles.includes(t)) return K("errShuttle");
	let a = i.shuttles.length;
	if (a >= 4) return K("errShuttle");
	let o = F(e, i.dock);
	if (!o) return K("errHex");
	let s = W(e, t, o);
	if (s == null) return K("errUnreachable");
	if (s !== n.payQic) return K("errQic");
	let c = +(r.faction === "nevlas" || r.faction === "itars");
	if (Qe(r) < c) return K("errPower");
	if (!Ze(r, s)) return K("errQic");
	let l = 5 + (r.faction === "baltaks" ? 2 : 0);
	L(r, -l), c > 0 && H(r, c), r.faction === "taklons" && (r.brainstone = "gaia"), i.shuttles.push(t), --r.shuttlesAvail;
	let u = Be[i.id]?.charges[a] ?? 0;
	return u > 0 && et(r, u), I(e, r.rid, "explore", i.id, l), J(e, t), null;
}
function fn(e, t, n) {
	let r = P(e, t), i = e.ships.find((e) => e.id === "twilight");
	if (!i || !i.shuttles.includes(t)) return K("errShuttle");
	if (i.artifacts.length === 0) return K("errArtifact");
	if (Qe(r) < 6) return K("errPower");
	let a = n.artifact ? i.artifacts.indexOf(n.artifact) : -1;
	if (a < 0) return K("errArtifact");
	H(r, 6);
	let o = i.artifacts.splice(a, 1)[0];
	return r.artifacts.push(o), pn(r, o), I(e, r.rid, "artifact", o), J(e, t), null;
}
function pn(e, t) {
	let n = He[t]?.effect;
	if (n) {
		if (n.kind === "vpMine" && L(e, n.vp), n.kind === "vpPerResearch" && L(e, n.per * e.tracks[T[n.track]]), n.kind === "vpPerArea3") {
			let t = 0;
			for (let n of e.tracks) n >= 3 && (t += 1);
			L(e, n.vp * t);
		}
		if (n.kind === "powerIncome3") {
			let t = Math.max(0, 50 - Qe(e) - e.gaiaPower);
			e.power[2] += Math.min(t, n.power);
		}
		n.kind === "resources" && (n.credits && R(e, n.credits), n.ores && z(e, n.ores), n.knowledge && B(e, n.knowledge), n.qic && V(e, n.qic), n.power && $e(e, n.power));
	}
}
function mn(e, t, n) {
	let r = P(e, t), i = e.ships.find((e) => e.id === n.ship);
	if (!i) return K("errAction");
	if (!i.shuttles.includes(t)) return K("errShuttle");
	let a = Be[i.id]?.actions.find((e) => e.id === n.action);
	if (!a) return K("errAction");
	if (i.usedActions.includes(a.id)) return K("errUsed");
	let o = a.cost;
	if (o.qic && !Ze(r, o.qic)) return K("errQic");
	if (o.knowledge && !Xe(r, o.knowledge)) return K("errKnowledge");
	if (o.credits && !Je(r, o.credits)) return K("errCredits");
	if (o.ores && !Ye(r, o.ores)) return K("errOres");
	if (o.power && !rn(r, o.power)) return K("errPower");
	i.usedActions.push(a.id), I(e, r.rid, "shipAction", a.id);
	let s = hn(e, t, i, a.reward, n);
	return s.error ? s.error : (s.ended || J(e, t), null);
}
function hn(e, t, n, r, i) {
	let a = P(e, t);
	switch (r.kind) {
		case "vpPerType": return L(a, r.base * a.knownTypes.length), {
			error: null,
			ended: !1
		};
		case "creditsQic": return R(a, r.credits), V(a, r.qic), {
			error: null,
			ended: !1
		};
		case "advanceResearch": {
			if (!i.track) return {
				error: K("errTrack"),
				ended: !1
			};
			let n = Wt(e, t, i.track, !1, i.lostHex, i.lostPayQic);
			return !n.error && n.placedHex ? (J(e, t, [n.placedHex]), {
				error: null,
				ended: !0
			}) : {
				error: n.error,
				ended: !1
			};
		}
		case "repeatFed": {
			let e = i.token;
			if (!e || !a.fedTokens.some((t) => t.type === e)) return {
				error: K("errFedToken"),
				ended: !1
			};
			let t = ye[e];
			return t && (t.rewards.credits && R(a, t.rewards.credits), t.rewards.ores && z(a, t.rewards.ores), t.rewards.knowledge && B(a, t.rewards.knowledge), t.rewards.qic && V(a, t.rewards.qic), t.rewards.tokens && $e(a, t.rewards.tokens), t.vp > 0 && L(a, t.vp)), {
				error: null,
				ended: !1
			};
		}
		case "freeAsteroidMine": {
			if (!i.hex) return {
				error: K("errHex"),
				ended: !1
			};
			let n = Nt(e, t, {
				hex: i.hex,
				payQic: i.payQic,
				skipGaiaformer: !0,
				freeBuildCost: !0
			});
			return {
				error: n,
				ended: n == null
			};
		}
		case "range3": {
			if (!i.hex) return {
				error: K("errHex"),
				ended: !1
			};
			let n = Nt(e, t, {
				hex: i.hex,
				payQic: i.payQic,
				rangeBonus: 3
			});
			return {
				error: n,
				ended: n == null
			};
		}
		case "freeMine1": {
			if (!i.hex) return {
				error: K("errHex"),
				ended: !1
			};
			let n = Nt(e, t, {
				hex: i.hex,
				payQic: i.payQic,
				freeSteps: 1
			});
			return {
				error: n,
				ended: n == null
			};
		}
		case "freeUpgradeRl":
		case "freeUpgradeTs": {
			if (!i.hex) return {
				error: K("errHex"),
				ended: !1
			};
			let n = gn(e, t, i, r.kind === "freeUpgradeRl" ? "rl" : "ts");
			return {
				error: n,
				ended: n == null
			};
		}
		case "gaiaProject": {
			if (!i.hex) return {
				error: K("errHex"),
				ended: !1
			};
			let n = Lt(e, t, i.hex, i.payQic, 0, !0);
			return {
				error: n,
				ended: n == null
			};
		}
		case "standardTech":
		case "tech": {
			if (r.kind === "standardTech") {
				if (!i.tech || !n.techs.includes(i.tech) || i.advanced) return {
					error: K("errTech"),
					ended: !1
				};
				if (a.techs.includes(i.tech)) return {
					error: K("errTechOwned"),
					ended: !1
				};
				n.techs = n.techs.filter((e) => e !== i.tech), a.techs.push(i.tech), Ht(e, a, i.tech), I(e, a.rid, "tech", i.tech);
			}
			let o = r.kind === "tech" ? Vt(e, t, i) : i.track ? Wt(e, t, i.track, !1, i.lostHex, i.lostPayQic) : { error: null };
			return !o.error && o.placedHex ? (J(e, t, [o.placedHex]), {
				error: null,
				ended: !0
			}) : {
				error: o.error,
				ended: !1
			};
		}
		default: return {
			error: K("errAction"),
			ended: !1
		};
	}
}
function gn(e, t, n, r) {
	let i = P(e, t);
	if (!n.hex) return K("errHex");
	let a = F(e, n.hex);
	if (!a || !a.structure || a.structure.seat !== t) return K("errOccupied");
	let o = r === "ts" ? "mine" : "ts";
	if (a.structure.type !== o) return K("errUpgrade");
	if (r === "ts" && i.buildings.ts >= k.ts || r === "rl" && i.buildings.rl >= k.rl) return K("errSupply");
	a.structure = {
		seat: t,
		type: r,
		side: null
	}, G(e, i), I(e, i.rid, "upgrade", a.id, 0);
	let s = [a];
	if (r === "ts" && bn(e, i, "ts"), r === "rl") {
		bn(e, i, "rl");
		let r = Vt(e, t, n);
		if (r.error) return r.error;
		r.placedHex && s.push(r.placedHex);
	}
	return J(e, t, s), null;
}
function _n(e, t, n) {
	let r = P(e, t), i = !e.players.some((e) => e !== r && e.passed), a = En(e, t);
	if (a > 0 && L(r, a), e.round < 6) {
		let t = n;
		if (t ??= e.boosterPool[0], t == null) return K("errBooster");
		let i = e.boosterPool.indexOf(t);
		if (i < 0 || t === r.booster) return K("errBooster");
		e.boosterPool.splice(i, 1), r.booster && e.boosterPool.push(r.booster), r.booster = t;
	} else r.booster && e.boosterPool.push(r.booster), r.booster = null;
	return r.passed = !0, i && (e.firstSeat = t), I(e, r.rid, "pass", r.booster ?? "", a), xt(e), null;
}
function vn(e) {
	return e.roundTiles[e.round - 1] ?? null;
}
function yn(e, t, n) {
	let r = vn(e);
	r === "mine2" && L(t, 2), n.gaia && r === "gaia3" && L(t, 3), n.gaia && r === "gaia4" && L(t, 4), n.sectorNew && r === "lf_sector" && L(t, 3), n.typeNew && r === "lf_type" && L(t, 3);
}
function bn(e, t, n) {
	let r = vn(e);
	n === "ts" && r === "ts3" && L(t, 3), n === "ts" && r === "ts4" && L(t, 4), n === "big" && (r === "big5" || r === "big5b") && L(t, 5), n === "rl" && r === "lf_rl" && L(t, 4), n === "ts" && Cn(t, "ts3vp") && L(t, 3);
}
function xn(e, t) {
	vn(e) === "research2" && L(t, 2);
}
function Sn(e, t) {
	vn(e) === "federation5" && L(t, 5);
}
function Cn(e, t) {
	let n = new Set(e.advTechs.map((e) => e.covers));
	return [...e.techs.filter((e) => !n.has(e)), ...e.advTechs.map((e) => e.id)].some((e) => {
		let n = O[e];
		return n?.effect.kind === "passive" && n.effect.passive === t;
	});
}
function wn(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.hexes) r.outer && (r.structure?.seat === t || r.parasite === t || r.lostPlanet === t) && n.add(r.sectorId);
	return n.size;
}
function Tn(e, t) {
	let n = 0;
	for (let r of e.hexes) r.planet === "asteroid" && (r.structure?.seat === t || r.parasite === t) && (n += 1);
	return n;
}
function En(e, t) {
	let n = P(e, t), r = 0, i = n.booster ? me[n.booster] : null;
	if (i?.pass) {
		if (i.pass === "mine" && (r += n.buildings.mines), i.pass === "ts2" && (r += 2 * n.buildings.ts), i.pass === "rl3" && (r += 3 * n.buildings.rl), i.pass === "big4" && (r += 4 * (n.buildings.pi + n.buildings.ac)), i.pass === "gaia1") {
			let n = 0;
			for (let r of e.hexes) r.structure?.seat === t && r.planet === "gaia" && (n += 1);
			r += n;
		}
		i.pass === "gaiaformers" && (r += 3 * (n.gaiaformers + n.gaiaformersGaia)), i.pass === "types" && (r += n.knownTypes.length), i.pass === "dsSectors" && (r += 2 * wn(e, t));
	}
	for (let i of n.advTechs) {
		let a = O[i.id];
		a?.effect.kind === "pass" && (a.effect.metric === "federation" && (r += 3 * n.fedTokens.length), a.effect.metric === "rl" && (r += 3 * n.buildings.rl), a.effect.metric === "type" && (r += n.knownTypes.length), a.effect.metric === "asteroid" && (r += 2 * Tn(e, t)), a.effect.metric === "dsSector" && (r += 2 * wn(e, t)));
	}
	return r;
}
function Dn(e, t) {
	let n = P(e, t), r = jt(e, t).map((e) => ({
		hex: e.hex.id,
		steps: e.steps,
		stepOre: e.stepOre,
		oreCost: e.oreCost,
		credits: e.credits,
		qic: e.qic,
		range: e.range,
		parasite: e.parasite || void 0,
		asteroid: e.asteroid || void 0,
		prototype: e.prototype || void 0
	})), i = Mt(e, t), a = [];
	for (let r of e.hexes) if (r.structure?.seat === t) for (let i of [
		"ts",
		"pi",
		"rl",
		"ac"
	]) {
		let o = dt(e, t, r, i);
		if (o && !(i === "ts" && n.buildings.ts >= k.ts) && !(i === "rl" && n.buildings.rl >= k.rl) && !(i === "pi" && n.buildings.pi >= k.pi) && !(i === "ac" && n.buildings.ac >= k.ac)) {
			if (i === "ac") for (let e of ["left", "right"]) n.academies.includes(e) || a.push({
				hex: r.id,
				to: i,
				credits: o.credits,
				ores: o.ores,
				side: e,
				gainsTech: !0
			});
			else {
				let s = i === "rl" || i === "pi" && n.faction === "spacegiants" && kn(e, t).length > 0;
				a.push({
					hex: r.id,
					to: i,
					credits: o.credits,
					ores: o.ores,
					gainsTech: s
				});
			}
		}
	}
	let o = An(e, t), s = n.knowledge < 4 ? [] : o, c = ct(n, "nav") && n.tracks[T.nav] === 4 && lt(n) && !e.players.some((e) => e !== n && e.tracks[T.nav] === 5) ? Gt(e, t, 1, n.qic + 1).map(({ hex: e, payQic: t }) => ({
		hex: e.id,
		payQic: t
	})) : [], l = jn(e, t), u = Object.keys(e.fedSupply).filter((t) => e.fedSupply[t] > 0);
	if (e.lostFleet) for (let n of e.ships) n.goldToken && n.shuttles.includes(t) && u.push(n.goldToken);
	let d = Jt(n), f = [];
	for (let r of be) if (!tn(e.usedPower, r.id) && On(n, r.cost)) {
		if (r.id === "p_terra1" || r.id === "p_terra2") {
			let n = r.id === "p_terra2" ? 2 : 1;
			for (let i of jt(e, t, 0, n)) i.asteroid || f.push({
				id: r.id,
				hex: i.hex.id,
				payQic: i.qic,
				parasite: i.parasite || void 0,
				oreCost: i.oreCost,
				credits: i.credits
			});
		} else f.push({ id: r.id });
	}
	let p = [];
	for (let r of e.lostFleet ? [] : xe) tn(e.usedQic, r.id) || n.qic < r.cost || (r.id !== "q_rescore" || n.fedTokens.length !== 0) && (r.id !== "q_tech" || kn(e, t).length !== 0) && p.push(r.id);
	let m = [];
	n.power[1] >= 2 && m.push("f_burn");
	for (let [e, t] of [
		["f_powQic", 4],
		["f_powOre", 3],
		["f_powKnw", 4],
		["f_powCredit", 1]
	]) (On(n, t) || n.faction === "hadschhallas" && n.pi && n.credits >= t) && m.push(e);
	n.qic >= 1 && m.push("f_qicOre"), n.knowledge >= 1 && m.push("f_knwCredit"), n.ores >= 1 && (m.push("f_oreCredit"), m.push("f_orePower"));
	let h = [];
	for (let e of [...n.techs, ...n.advTechs.map((e) => e.id)]) O[e]?.effect.kind === "action" && !n.usedTiles.includes(e) && h.push(e);
	let g = [];
	if (n.booster) {
		let r = me[n.booster], i = `booster:${n.booster}`;
		if (r?.action && !n.usedAbilities.includes(i)) {
			if (r.action === "terraform1") for (let r of jt(e, t, 0, 1)) r.asteroid || r.parasite || g.push({
				id: n.booster,
				hex: r.hex.id,
				mode: "build",
				qic: r.qic,
				oreCost: r.oreCost,
				credits: r.credits
			});
			else if (r.action === "gaiaFree") for (let r of Mt(e, t)) g.push({
				id: n.booster,
				hex: r.hex,
				mode: "gaia",
				qic: r.qic
			});
			else {
				for (let r of jt(e, t, 3)) r.asteroid || r.parasite || g.push({
					id: n.booster,
					hex: r.hex.id,
					mode: "build",
					qic: r.qic,
					oreCost: r.oreCost,
					credits: r.credits
				});
				for (let r of Mt(e, t, 3)) g.push({
					id: n.booster,
					hex: r.hex,
					mode: "gaia",
					qic: r.qic
				});
			}
		}
	}
	let _ = [];
	if (n.pi) {
		if (n.faction === "ambas") {
			let r = e.hexes.find((e) => e.structure?.seat === t && e.structure.type === "mine");
			r && !n.usedAbilities.includes("swapPI") && _.push({
				kind: "swapPI",
				hex: r.id
			});
		}
		if (n.faction === "firaks") {
			let n = An(e, t);
			for (let r of e.hexes) if (r.structure?.seat === t && r.structure.type === "rl") for (let e of n) _.push({
				kind: "downgradeRL",
				hex: r.id,
				track: e
			});
		}
		if (n.faction === "ivits" && !n.usedAbilities.includes("spaceStation")) for (let r of e.hexes) {
			if (r.planet != null || r.station != null || r.structure || r.lostPlanet != null || e.ships.some(({ dock: e }) => e === r.id)) continue;
			let i = W(e, t, r);
			i == null || i > n.qic || _.push({
				kind: "spaceStation",
				hex: r.id,
				payQic: i
			});
		}
	}
	if (n.faction === "bescods" && !n.usedAbilities.includes("advanceLowest")) {
		let e = Math.min(...n.tracks);
		for (let t of o) n.tracks[T[t]] === e && _.push({
			kind: "advanceLowest",
			track: t
		});
	}
	if (n.faction === "baltaks" && n.gaiaformers > 0 && _.push({ kind: "baltaqGaiaformer" }), n.faction === "nevlas" && _.push({ kind: "nevlasKnowledge" }), n.faction === "spacegiants" && !n.permUsed.includes("giantsMine")) for (let r of jt(e, t, 0, 2)) r.asteroid || r.parasite || r.oreCost > n.ores || r.credits > n.credits || _.push({
		kind: "giantsMine",
		hex: r.hex.id,
		payQic: r.qic
	});
	if (n.faction === "moweyds" && n.pi && !n.usedAbilities.includes("moweydRing")) for (let r of e.hexes) r.structure?.seat !== t || n.powerRings.includes(r.id) || _.push({
		kind: "moweydRing",
		hex: r.id
	});
	if (n.faction === "tinkeroids" && n.pi && !n.usedAbilities.includes("tinkerAction")) {
		let r = n.tinkerTile ? We[n.tinkerTile] : null;
		if (r?.effect.kind === "buildMine") for (let i of jt(e, t, 0, r.effect.freeSteps)) i.asteroid || i.parasite || i.oreCost > n.ores || i.credits > n.credits || _.push({
			kind: "tinkerAction",
			hex: i.hex.id,
			payQic: i.qic
		});
		else r && _.push({ kind: "tinkerAction" });
	}
	let v = n.academies.includes("right") && !n.usedAbilities.includes("academy"), y = [], b = [], x = [], S = [], C = !1;
	if (e.lostFleet) {
		let r = +(n.faction === "nevlas" || n.faction === "itars"), i = Qe(n) >= r, a = n.techs.filter((e) => !n.coveredTechs.includes(e)), o = n.faction === "ivits" && l.length > 0 ? Math.min(...l.map((e) => e.satellites.length)) : 0;
		for (let r of e.ships) {
			let s = r.shuttles.includes(t);
			if (n.shuttlesAvail > 0 && !s && r.shuttles.length < 4 && i) {
				let i = F(e, r.dock), a = i ? W(e, t, i) : null;
				a != null && a <= n.qic && y.push({
					ship: r.id,
					payQic: a
				});
			}
			if (!s) continue;
			let c = Be[r.id];
			if (c) {
				if (r.goldToken) {
					let i = Ke[r.goldToken];
					if (i?.kind === "mineRange" || i?.kind === "mine3") {
						let a = jt(e, t, i.kind === "mineRange" ? 99 : 0, i.kind === "mine3" ? 3 : 0);
						for (let e of a) e.asteroid || e.parasite || e.oreCost - 1 > n.ores || e.qic + o > n.qic || S.push({
							token: r.goldToken,
							hex: e.hex.id,
							payQic: e.qic
						});
					}
				}
				for (let i of c.actions) {
					if (r.usedActions.includes(i.id)) continue;
					let o = i.cost;
					if (o.qic && n.qic < o.qic || o.knowledge && n.knowledge < o.knowledge || o.credits && n.credits < o.credits || o.ores && n.ores < o.ores || o.power && !On(n, o.power)) continue;
					let s = n.qic - (o.qic ?? 0), c = n.ores - (o.ores ?? 0), l = n.credits - (o.credits ?? 0), u = Qe(n) - (o.power ?? 0), d = (e) => b.push({
						ship: r.id,
						action: i.id,
						...e
					});
					switch (i.reward.kind) {
						case "vpPerType":
						case "creditsQic":
							d({});
							break;
						case "advanceResearch":
							for (let r of An(e, t)) (r !== "nav" || n.tracks[T.nav] !== 4 || Gt(e, t, 1, s).length !== 0) && d({ track: r });
							break;
						case "repeatFed":
							for (let e of new Set(n.fedTokens.map((e) => e.type))) d({ token: e });
							break;
						case "standardTech":
							for (let e of r.techs) n.techs.includes(e) || d({ tech: e });
							break;
						case "tech":
							for (let n of kn(e, t)) d({
								tech: n.id,
								advanced: n.advanced || void 0,
								cover: n.advanced ? a[0] : void 0
							});
							break;
						case "freeAsteroidMine":
							if (n.buildings.mines >= k.mine) break;
							for (let n of e.hexes) {
								if (n.planet !== "asteroid" || n.structure || n.lostPlanet != null) continue;
								let r = W(e, t, n);
								r == null || r > s || d({
									hex: n.id,
									payQic: r
								});
							}
							break;
						case "range3":
							for (let n of jt(e, t, 3)) n.asteroid || n.oreCost > c || n.credits > l || n.qic > s || d({
								hex: n.hex.id,
								payQic: n.qic
							});
							break;
						case "freeMine1":
							for (let n of jt(e, t, 0, 1)) n.asteroid || n.oreCost > c || n.credits > l || n.qic > s || d({
								hex: n.hex.id,
								payQic: n.qic
							});
							break;
						case "gaiaProject":
							for (let n of Mt(e, t)) n.qic > s || n.power > u || d({
								hex: n.hex,
								payQic: n.qic
							});
							break;
						case "freeUpgradeTs":
							for (let r of e.hexes) r.structure?.seat === t && r.structure.type === "mine" && (n.buildings.ts >= k.ts || d({ hex: r.id }));
							break;
						case "freeUpgradeRl":
							if (n.buildings.rl >= k.rl) break;
							for (let n of e.hexes) if (n.structure?.seat === t && n.structure.type === "ts") for (let r of kn(e, t)) d({
								hex: n.id,
								tech: r.id,
								advanced: r.advanced || void 0,
								cover: r.advanced ? a[0] : void 0
							});
					}
				}
			}
		}
		let s = e.ships.find((e) => e.id === "twilight");
		C = !!s && s.shuttles.includes(t) && s.artifacts.length > 0 && Qe(n) >= 6;
		for (let r of [...n.techs, ...n.advTechs.map((e) => e.id)]) {
			let i = O[r];
			if (!(i?.effect.kind !== "freeMineTerra" || n.usedTiles.includes(r))) for (let a of jt(e, t, 0, i.effect.steps)) {
				if (a.asteroid || a.oreCost - 1 > n.ores) continue;
				let e = i.effect.endlessRange ? a.qic - (a.range ?? 0) : a.qic;
				x.push({
					id: r,
					hex: a.hex.id,
					payQic: e
				});
			}
		}
	}
	let ee = e.phase === "draft" && e.draftSeat === t ? [...e.boosterPool] : [], w = e.round < 6 ? [...e.boosterPool].filter((e) => e !== n.booster) : [], te = En(e, t), ne = e.pending && e.pending.queue[0]?.seat === t ? {
		power: e.pending.queue[0].power,
		vp: e.pending.queue[0].vp
	} : null, E = kn(e, t), re = pt(e, n), ie = {
		credits: re.credits,
		ores: re.ores,
		knowledge: re.knowledge,
		qic: re.qic,
		power: re.charge,
		tokens: re.powerTokens
	};
	return {
		builds: r,
		gaia: i,
		upgrades: a,
		research: s,
		lostPlanet: c,
		advanceTracks: o,
		federations: l,
		fedTokens: u,
		fedThreshold: d,
		power: f,
		qic: p,
		free: m,
		useTiles: h,
		freeMines: x,
		goldMines: S,
		boosters: g,
		faction: _,
		academy: v,
		explore: y,
		examine: C,
		shipActions: b,
		draft: ee,
		tinkerChoices: e.roundDecision?.kind === "tinker" && e.roundDecision.seat === t ? q(e, t) : [],
		pass: e.phase === "play" && !e.roundDecision && !n.passed && e.turnSeat === t,
		passBoosters: w,
		passPoints: te,
		charge: ne,
		techs: E,
		passive: ie
	};
}
function On(e, t) {
	return e.faction === "nevlas" && e.pi ? e.power[2] + +(e.brainstone === "III") >= Math.ceil(t / 2) : e.power[2] + (e.brainstone === "III" ? 3 : 0) >= t;
}
function kn(e, t) {
	let n = P(e, t), r = [], i = An(e, t), a = An(e, t, 1);
	for (let t of e.techPiles) t.remaining <= 0 || n.techs.includes(t.id) || n.advTechs.some((e) => e.id === t.id) || r.push({
		id: t.id,
		advanced: !1,
		track: t.track,
		advanceTracks: i
	});
	for (let i of e.advancedTiles) Bt(e, t, i.track) && lt(n) && n.techs.some((e) => !n.coveredTechs.includes(e)) && r.push({
		id: i.id,
		advanced: !0,
		track: i.track,
		advanceTracks: a
	});
	return r;
}
function An(e, t, n = 0) {
	let r = P(e, t), i = r.fedTokens.filter((e) => e.green).length;
	return te.filter((a) => !(!ct(r, a) || r.tracks[T[a]] === 4 && (i <= n || e.players.some((e) => e !== r && e.tracks[T[a]] >= 5) || a === "nav" && Gt(e, t, 1).length === 0)));
}
function jn(e, t) {
	let n = P(e, t), r = [], i = e.federations.filter((e) => e.seat === t), a = i.flatMap((e) => [...e.hexes, ...e.satellites]).map((t) => F(e, t)).filter((e) => !!e), o = n.faction === "ivits" && i.length > 0, s = o ? 7 * (n.fedTokens.length + 1) : Jt(n), c = o ? i[0].hexes.reduce((n, r) => {
		let i = F(e, r);
		return n + (i ? Yt(e, t, i) ?? 0 : 0);
	}, 0) : 0, l = /* @__PURE__ */ new Set();
	for (let n of e.hexes) {
		if (n.federation != null || l.has(n.id) || Yt(e, t, n) == null) continue;
		let i = [], u = [n], d = /* @__PURE__ */ new Set([n.id]);
		for (; u.length > 0;) {
			let n = u.shift();
			i.push(n);
			for (let r of e.hexes) d.has(r.id) || r.federation != null || Yt(e, t, r) != null && Le(n, r) && (d.add(r.id), u.push(r));
		}
		for (let e of i) l.add(e.id);
		let f = i.reduce((n, r) => n + (Yt(e, t, r) ?? 0), 0);
		if (!(f + c < s)) {
			if (o) {
				if (!i.some((e) => a.some((t) => Le(e, t) || e.id === t.id))) continue;
			} else if (a.some((e) => i.some((t) => Le(t, e)))) continue;
			r.push({
				hexes: i.map((e) => e.id),
				satellites: [],
				power: f,
				need: Math.max(0, s - c - f)
			});
		}
	}
	return r.slice(0, 6);
}
//#endregion
//#region src/game/meta.ts
var Mn = {
	id: "gaiaproject",
	uuid: "333c76d2-cd5c-419c-a8da-8696387a79d2",
	tier: "alpha",
	mechanics: [
		"engine-building",
		"tile-placement",
		"area-control",
		"action-points"
	],
	interactionTags: [],
	nameKey: "games.gaiaproject.name",
	descKey: "games.gaiaproject.desc",
	rulesKey: "games.gaiaproject.rules",
	icon: "🪐",
	iconImg: "games/gaiaproject.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#5fe3d2",
	releasedAt: "2026-11-26T19:30:00+08:00",
	search: {
		py: "gai ya ji hua",
		init: "gyjh"
	},
	hotseat: "cover",
	botDelayMs: 900
}, Nn = t.object({ lostFleet: t.boolean().default(!1) }).prefault({}), Pn = t.enum([
	"terra",
	"nav",
	"ai",
	"gaia",
	"eco",
	"sci"
]), Q = t.string().max(40), Fn = t.string().max(40), In = t.string().max(40), Ln = t.object({
	kind: t.enum(["itars", "tinker"]),
	seat: t.int()
}), Rn = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		booster: t.string().max(40)
	}),
	t.object({
		type: t.literal("build"),
		hex: Q,
		payQic: t.int().min(0).max(8).default(0),
		parasite: t.boolean().optional()
	}),
	t.object({
		type: t.literal("gaia"),
		hex: Q,
		payQic: t.int().min(0).max(8).default(0)
	}),
	t.object({
		type: t.literal("upgrade"),
		hex: Q,
		to: t.enum([
			"ts",
			"pi",
			"rl",
			"ac"
		]),
		side: t.enum(["left", "right"]).optional(),
		tech: Fn.optional(),
		advanced: t.boolean().optional(),
		track: Pn.optional(),
		cover: Fn.optional(),
		lostHex: Q.optional(),
		lostPayQic: t.int().min(0).max(8).optional()
	}),
	t.object({
		type: t.literal("federation"),
		token: In,
		hexes: t.array(Q).min(1).max(40),
		satellites: t.array(Q).max(24).default([]),
		goldHex: Q.optional(),
		goldPayQic: t.int().min(0).max(8).default(0),
		goldTech: Fn.optional(),
		goldAdvanced: t.boolean().optional(),
		goldCover: Fn.optional(),
		goldTrack: Pn.optional(),
		goldLostHex: Q.optional(),
		goldLostPayQic: t.int().min(0).max(8).optional()
	}),
	t.object({
		type: t.literal("research"),
		track: Pn,
		hex: Q.optional(),
		payQic: t.int().min(0).max(8).default(0)
	}),
	t.object({
		type: t.literal("power"),
		id: t.string().max(40),
		hex: Q.optional(),
		payQic: t.int().min(0).max(8).default(0),
		parasite: t.boolean().optional()
	}),
	t.object({
		type: t.literal("qic"),
		id: t.string().max(40),
		token: In.optional(),
		tech: Fn.optional(),
		advanced: t.boolean().optional(),
		track: Pn.optional(),
		cover: Fn.optional(),
		lostHex: Q.optional(),
		lostPayQic: t.int().min(0).max(8).optional()
	}),
	t.object({
		type: t.literal("free"),
		id: t.string().max(40),
		credits: t.boolean().optional()
	}),
	t.object({
		type: t.literal("useTile"),
		id: t.string().max(40),
		hex: Q.optional(),
		payQic: t.int().min(0).max(8).default(0)
	}),
	t.object({ type: t.literal("academy") }),
	t.object({
		type: t.literal("tinkerPick"),
		tile: Fn
	}),
	t.object({ type: t.literal("gaiaFinish") }),
	t.object({
		type: t.literal("faction"),
		kind: t.enum([
			"swapPI",
			"downgradeRL",
			"advanceLowest",
			"itarsTech",
			"baltaqGaiaformer",
			"nevlasKnowledge",
			"spaceStation",
			"moweydRing",
			"tinkerAction",
			"giantsMine"
		]),
		hex: Q.optional(),
		track: Pn.optional(),
		payQic: t.int().min(0).max(8).default(0),
		tech: Fn.optional(),
		advanced: t.boolean().optional(),
		cover: Fn.optional(),
		lostHex: Q.optional(),
		lostPayQic: t.int().min(0).max(8).optional()
	}),
	t.object({
		type: t.literal("explore"),
		ship: t.string().max(40),
		payQic: t.int().min(0).max(8).default(0)
	}),
	t.object({
		type: t.literal("examine"),
		artifact: t.string().max(40).optional()
	}),
	t.object({
		type: t.literal("shipAction"),
		ship: t.string().max(40),
		action: t.string().max(40),
		hex: Q.optional(),
		payQic: t.int().min(0).max(8).default(0),
		track: Pn.optional(),
		token: In.optional(),
		tech: Fn.optional(),
		advanced: t.boolean().optional(),
		cover: Fn.optional(),
		lostHex: Q.optional(),
		lostPayQic: t.int().min(0).max(8).optional()
	}),
	t.object({
		type: t.literal("booster"),
		id: t.string().max(40),
		hex: Q.optional(),
		mode: t.enum(["build", "gaia"]).default("build"),
		payQic: t.int().min(0).max(8).default(0)
	}),
	t.object({
		type: t.literal("pass"),
		booster: t.string().max(40).nullable().optional()
	}),
	t.object({
		type: t.literal("charge"),
		take: t.boolean()
	})
]), zn = t.object({
	credits: t.int().optional(),
	ores: t.int().optional(),
	knowledge: t.int().optional(),
	qic: t.int().optional(),
	power: t.int().optional(),
	tokens: t.int().optional(),
	vp: t.int().optional()
}), Bn = t.object({
	seat: t.int(),
	rid: t.string(),
	faction: t.string(),
	vp: t.int(),
	credits: t.int(),
	ores: t.int(),
	knowledge: t.int(),
	qic: t.int(),
	power: t.tuple([
		t.int(),
		t.int(),
		t.int()
	]),
	gaiaPower: t.int(),
	brainstone: t.enum([
		"I",
		"II",
		"III",
		"gaia"
	]).nullable(),
	gaiaformers: t.int(),
	gaiaformersGaia: t.int(),
	gaiaformersLost: t.int(),
	tracks: t.array(t.int()),
	techs: t.array(t.string()),
	advTechs: t.array(t.object({
		id: t.string(),
		covers: t.string()
	})),
	fedTokens: t.array(t.object({
		type: t.string(),
		green: t.boolean()
	})),
	booster: t.string().nullable(),
	passed: t.boolean(),
	pi: t.boolean(),
	academies: t.array(t.enum(["left", "right"])),
	knownTypes: t.array(t.string()),
	artifacts: t.array(t.string()),
	buildings: t.object({
		mines: t.int(),
		ts: t.int(),
		rl: t.int(),
		pi: t.int(),
		ac: t.int(),
		satellites: t.int(),
		sectors: t.int(),
		fedBuildings: t.int(),
		lostPlanet: t.int(),
		stations: t.int()
	}),
	usedAbilities: t.array(t.string()),
	usedTiles: t.array(t.string()),
	shuttlesAvail: t.int().default(0),
	lfTerra: t.array(t.string()).default([]),
	powerRings: t.array(t.string()).default([]),
	tinkerTile: t.string().nullable().default(null),
	lfRangeBonus: t.int().default(0)
}), Vn = t.object({
	id: t.string(),
	row: t.int(),
	col: t.int(),
	planet: t.string().nullable(),
	gaiaformed: t.boolean(),
	outer: t.boolean(),
	sector: t.string(),
	structure: t.object({
		seat: t.int(),
		type: t.string(),
		side: t.enum(["left", "right"]).nullable()
	}).nullable(),
	parasite: t.int().nullable(),
	satellites: t.array(t.int()),
	station: t.int().nullable(),
	gaiaformer: t.int().nullable(),
	lostPlanet: t.int().nullable(),
	artifact: t.string().nullable(),
	federation: t.int().nullable()
}), Hn = t.object({
	id: t.int(),
	seat: t.int(),
	hexes: t.array(t.string()),
	satellites: t.array(t.string()),
	token: t.string()
}), Un = t.object({
	hex: t.string(),
	steps: t.int(),
	stepOre: t.int(),
	oreCost: t.int(),
	credits: t.int(),
	qic: t.int(),
	range: t.int().nullable(),
	parasite: t.boolean().optional(),
	asteroid: t.boolean().optional(),
	prototype: t.boolean().optional()
}), Wn = t.object({
	hex: t.string(),
	to: t.string(),
	credits: t.int(),
	ores: t.int(),
	side: t.enum(["left", "right"]).optional(),
	gainsTech: t.boolean().optional()
}), Gn = t.object({
	phase: t.enum([
		"draft",
		"play",
		"done"
	]),
	round: t.int(),
	activeSeat: t.int(),
	turnSeat: t.int(),
	firstSeat: t.int(),
	draftOrder: t.array(t.int()),
	draftSeat: t.int().nullable(),
	players: t.array(Bn),
	hexes: t.array(Vn),
	federations: t.array(Hn),
	techPiles: t.array(t.object({
		id: t.string(),
		kind: t.string(),
		track: t.string().nullable(),
		remaining: t.int()
	})),
	advancedTiles: t.array(t.object({
		id: t.string(),
		track: t.string().nullable()
	})),
	roundTiles: t.array(t.string()),
	finalTiles: t.array(t.string()),
	boosterPool: t.array(t.string()),
	fedSupply: t.record(t.string(), t.int()),
	terraformingToken: t.string().nullable(),
	usedPower: t.array(t.string()),
	usedQic: t.array(t.string()),
	lostFleet: t.boolean(),
	ships: t.array(t.object({
		id: t.string(),
		shuttles: t.array(t.int()),
		goldToken: t.string().nullable(),
		artifacts: t.array(t.string()),
		techs: t.array(t.string()),
		usedActions: t.array(t.string()),
		dock: t.string()
	})).default([]),
	pending: t.object({
		seat: t.int(),
		power: t.int(),
		vp: t.int()
	}).nullable(),
	roundDecision: Ln.nullable(),
	hints: t.object({
		builds: t.array(Un),
		gaia: t.array(t.object({
			hex: t.string(),
			power: t.int(),
			qic: t.int()
		})),
		upgrades: t.array(Wn),
		research: t.array(t.string()),
		lostPlanet: t.array(t.object({
			hex: t.string(),
			payQic: t.int()
		})).default([]),
		advanceTracks: t.array(t.string()),
		federations: t.array(t.object({
			hexes: t.array(t.string()),
			satellites: t.array(t.string()),
			power: t.int(),
			need: t.int().optional()
		})),
		fedTokens: t.array(t.string()),
		fedThreshold: t.int(),
		power: t.array(t.object({
			id: t.string(),
			hex: t.string().optional(),
			payQic: t.int().optional(),
			parasite: t.boolean().optional(),
			oreCost: t.int().optional(),
			credits: t.int().optional()
		})),
		qic: t.array(t.string()),
		free: t.array(t.string()),
		useTiles: t.array(t.string()),
		freeMines: t.array(t.object({
			id: t.string(),
			hex: t.string(),
			payQic: t.int()
		})).default([]),
		goldMines: t.array(t.object({
			token: t.string(),
			hex: t.string(),
			payQic: t.int()
		})).default([]),
		boosters: t.array(t.object({
			id: t.string(),
			hex: t.string().optional(),
			mode: t.enum(["build", "gaia"]).optional(),
			qic: t.int().optional(),
			oreCost: t.int().optional(),
			credits: t.int().optional()
		})),
		faction: t.array(t.object({
			kind: t.string(),
			hex: t.string().optional(),
			track: t.string().optional(),
			payQic: t.int().optional(),
			tech: t.string().optional(),
			advanced: t.boolean().optional(),
			cover: t.string().optional()
		})),
		academy: t.boolean(),
		explore: t.array(t.object({
			ship: t.string(),
			payQic: t.int()
		})).default([]),
		examine: t.boolean().default(!1),
		shipActions: t.array(t.object({
			ship: t.string(),
			action: t.string(),
			hex: Q.optional(),
			payQic: t.int().min(0).max(8).optional(),
			track: Pn.optional(),
			token: In.optional(),
			tech: Fn.optional(),
			advanced: t.boolean().optional(),
			cover: Fn.optional(),
			lostHex: Q.optional(),
			lostPayQic: t.int().min(0).max(8).optional()
		})).default([]),
		draft: t.array(t.string()),
		tinkerChoices: t.array(t.string()),
		pass: t.boolean(),
		passBoosters: t.array(t.string()),
		passPoints: t.int(),
		charge: t.object({
			power: t.int(),
			vp: t.int()
		}).nullable(),
		techs: t.array(t.object({
			id: t.string(),
			advanced: t.boolean(),
			track: t.string().nullable(),
			advanceTracks: t.array(Pn)
		})),
		passive: zn
	}),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		value: t.string(),
		n: t.int().optional()
	})),
	result: t.object({
		winners: t.array(t.string()),
		rows: t.array(t.object({
			rid: t.string(),
			total: t.int(),
			fedBuildings: t.int(),
			buildings: t.int(),
			types: t.int(),
			gaia: t.int(),
			sectors: t.int(),
			satellites: t.int(),
			vp: t.int(),
			research: t.int(),
			resources: t.int(),
			asteroids: t.int(),
			piAcademy: t.int(),
			outerSectors: t.int(),
			awards: t.array(t.object({
				id: t.string(),
				count: t.int(),
				vp: t.int()
			}))
		})),
		ghost: t.boolean()
	}).nullable()
}), Kn = t.object({ seat: t.int() });
//#endregion
//#region src/game/setup.ts
function qn(t, n) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function Jn(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; --t) {
		let r = qn(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function Yn(e, t) {
	return {
		rid: e,
		faction: t,
		vp: 10,
		credits: 0,
		ores: 0,
		knowledge: 0,
		qic: 0,
		power: [
			0,
			0,
			0
		],
		gaiaPower: 0,
		brainstone: t === "taklons" ? "I" : null,
		gaiaformers: 0,
		gaiaformersGaia: 0,
		gaiaformersLost: 0,
		tracks: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		techs: [],
		coveredTechs: [],
		advTechs: [],
		fedTokens: [],
		booster: null,
		passed: !1,
		pi: !1,
		academies: [],
		knownTypes: [],
		artifacts: [],
		buildings: {
			mines: 0,
			ts: 0,
			rl: 0,
			pi: 0,
			ac: 0,
			satellites: 0,
			sectors: 0,
			fedBuildings: 0,
			lostPlanet: 0,
			stations: 0
		},
		usedAbilities: [],
		usedTiles: [],
		shuttlesAvail: 0,
		lfTerra: [],
		powerRings: [],
		tinkerTile: null,
		usedTinkerTiles: [],
		lfRangeBonus: 0,
		permUsed: []
	};
}
function Xn(e) {
	let t = y[e.faction].research;
	for (let n of te) {
		let r = t[n] ?? 0;
		e.tracks[te.indexOf(n)] = r, !(r < 1) && (n === "terra" && z(e, 2), (n === "nav" || n === "ai") && V(e, 1), n === "gaia" && (e.gaiaformers += 1));
	}
}
function Zn(e, t, n, r, i) {
	let a = e.hexes.filter((e) => !e.structure && e.lostPlanet == null && e.planet === i);
	if (a.length === 0) throw Error(`No unoccupied starting planet of type ${i}`);
	let o = a[qn(t, a.length)];
	o && (o.structure = {
		seat: n,
		type: r,
		side: null
	});
}
function Qn(e, t) {
	let n = [];
	for (let e of t) Re.includes(e) && !n.includes(e) && n.length < 3 && n.push(e);
	let r = Re.filter((e) => !n.includes(e));
	for (; n.length < 3 && r.length > 0;) {
		let [t] = r.splice(qn(e, r.length), 1);
		t && n.push(t);
	}
	return n;
}
function $n(e, t, n) {
	let r = ze[t] ?? ze[3], i = Jn(e, Ge.map((e) => e.id)), a = Jn(e, ce.map((e) => e.id)).slice(0, t <= 2 ? 2 : 3), o = r.map((e, t) => ({
		id: e,
		shuttles: [],
		goldToken: i[t % i.length] ?? null,
		artifacts: [],
		techs: e === "tfmars" ? a : [],
		usedActions: [],
		dock: n[t]
	})), s = o.find((e) => e.id === "twilight");
	return s && (s.artifacts = Jn(e, Ve.map((e) => e.id)).slice(0, t)), o;
}
function er(e, t, n) {
	let r = {
		seed: n,
		cursor: 0
	}, i = !!e.lostFleet, a = t.length, o = Jn(r, i ? C : S), s = Ie(a, n, r.cursor, i);
	r.cursor = s.cursor;
	let c = s.hexes.map((e) => ({
		...e,
		gaiaformed: !1,
		structure: null,
		parasite: null,
		satellites: [],
		station: null,
		gaiaformer: null,
		lostPlanet: null,
		artifact: null,
		federation: null
	})), l = /* @__PURE__ */ new Set(), u = o.filter((e) => {
		let t = y[e].planet;
		if (x.includes(e)) return c.filter((e) => e.planet === t).length >= 1;
		let n = e === "ivits" ? 1 : e === "xenos" ? 3 : 2;
		return l.has(t) || c.filter((e) => e.planet === t).length < n ? !1 : (l.add(t), !0);
	}).slice(0, a);
	if (u.length < a) throw Error("Not enough eligible starting factions");
	let d = Jn(r, [...he.map((e) => e.id), ...i ? ge.map((e) => e.id) : []]).slice(0, 6), f = Jn(r, [..._e.map((e) => e.id), ...i ? ve.map((e) => e.id) : []]).slice(0, 2), p = Jn(r, [...de, ...i ? pe : []].map((e) => e.id)).slice(0, a + 3), m = {
		knowledge: 3,
		credits: 3,
		ores: 3,
		power: 3,
		qic: 3,
		points: 3
	}, h = Object.keys(m), g = h[qn(r, h.length)];
	--m[g];
	let _ = Jn(r, oe.map((e) => e.id)), v = Jn(r, te), b = _.map((e, t) => ({
		id: e,
		track: t < 6 ? v[t] : null,
		remaining: 4
	})), ee = i ? [...se.map((e) => e.id), ...le.map((e) => e.id)] : se.map((e) => e.id), w = i ? 7 : 6, T = Jn(r, ee).slice(0, w).map((e, t) => ({
		id: e,
		track: te[t] ?? null
	})), ne = i ? $n(r, a, s.docks) : [], E = {
		seed: n,
		cursor: r.cursor,
		players: t.map((e, t) => Yn(e, u[t])),
		hexes: c,
		federations: [],
		techPiles: b,
		advancedTiles: T,
		roundTiles: d,
		finalTiles: f,
		boosterPool: p,
		fedSupply: m,
		terraformingToken: g,
		usedPower: [],
		usedQic: [],
		phase: "draft",
		round: 1,
		activeSeat: 0,
		turnSeat: 0,
		firstSeat: 0,
		draftOrder: [],
		draftSeat: null,
		pending: null,
		roundDecision: null,
		log: [],
		result: null,
		lostFleet: i,
		ships: ne
	};
	E.players.forEach((e) => {
		let t = y[e.faction];
		e.credits = t.init.credits, e.ores = t.init.ores, e.knowledge = t.init.knowledge, e.qic = t.init.qic, e.power = [...t.init.power], Xn(e);
	});
	let re = E.players.map((e) => y[e.faction].planet).filter((e) => Re.includes(e));
	if (E.players.forEach((e, t) => {
		let n = y[e.faction];
		if (x.includes(e.faction)) {
			e.shuttlesAvail = a <= 2 ? 2 : 3, e.faction === "tinkeroids" ? (Zn(E, r, t, "pi", n.planet), e.lfTerra = Qn(r, re)) : (Zn(E, r, t, "mine", n.planet), e.faction === "moweyds" && (e.lfTerra = Qn(r, re)));
			return;
		}
		e.faction === "ivits" ? Zn(E, r, t, "pi", "oxide") : (Zn(E, r, t, "mine", n.planet), Zn(E, r, t, "mine", n.planet), e.faction === "xenos" && Zn(E, r, t, "mine", n.planet));
	}), i) {
		let e = E.players.findIndex((e) => e.faction === "moweyds"), t = ne.find((e) => e.id === "tfmars");
		e >= 0 && t && (t.shuttles.push(e), E.players[e].shuttlesAvail = Math.max(0, E.players[e].shuttlesAvail - 1));
	}
	E.players.forEach((e) => {
		G(E, e), I(E, e.rid, "setup", e.faction);
	}), E.draftOrder = [];
	for (let e = a - 1; e >= 0; --e) E.draftOrder.push(e);
	return E.draftSeat = E.draftOrder[0], E.activeSeat = 0, E.turnSeat = 0, E.firstSeat = 0, E.cursor = r.cursor, { state: E };
}
//#endregion
//#region src/game/rules.ts
function tr(e, t, n) {
	let { state: r } = er(e, t, n);
	return {
		state: r,
		fx: []
	};
}
function nr(e, t, n) {
	let r = structuredClone(e), i = bt(r, n.by, t);
	if (i) return i;
	for (let e of r.players) G(r, e);
	return {
		state: r,
		fx: []
	};
}
function rr(e, t) {
	let n = qe(e, t);
	return {
		public: {
			phase: e.phase,
			round: e.round,
			activeSeat: e.activeSeat,
			turnSeat: e.turnSeat,
			firstSeat: e.firstSeat,
			draftOrder: [...e.draftOrder],
			draftSeat: e.draftSeat,
			players: e.players.map((e, t) => ({
				seat: t,
				rid: e.rid,
				faction: e.faction,
				vp: e.vp,
				credits: e.credits,
				ores: e.ores,
				knowledge: e.knowledge,
				qic: e.qic,
				power: [...e.power],
				gaiaPower: e.gaiaPower,
				brainstone: e.brainstone,
				gaiaformers: e.gaiaformers,
				gaiaformersGaia: e.gaiaformersGaia,
				gaiaformersLost: e.gaiaformersLost,
				tracks: [...e.tracks],
				techs: [...e.techs],
				advTechs: e.advTechs.map((e) => ({
					id: e.id,
					covers: e.covers
				})),
				fedTokens: e.fedTokens.map((e) => ({
					type: e.type,
					green: e.green
				})),
				booster: e.booster,
				passed: e.passed,
				pi: e.pi,
				academies: [...e.academies],
				knownTypes: [...e.knownTypes],
				artifacts: [...e.artifacts],
				buildings: { ...e.buildings },
				usedAbilities: [...e.usedAbilities],
				usedTiles: [...e.usedTiles],
				shuttlesAvail: e.shuttlesAvail,
				lfTerra: [...e.lfTerra],
				powerRings: [...e.powerRings],
				tinkerTile: e.tinkerTile,
				lfRangeBonus: e.lfRangeBonus
			})),
			hexes: e.hexes.map((e) => ({
				id: e.id,
				row: e.row,
				col: e.col,
				planet: e.planet,
				gaiaformed: e.gaiaformed,
				outer: e.outer,
				sector: e.sectorId,
				structure: e.structure ? {
					seat: e.structure.seat,
					type: e.structure.type,
					side: e.structure.side
				} : null,
				parasite: e.parasite,
				satellites: [...e.satellites],
				station: e.station,
				gaiaformer: e.gaiaformer,
				lostPlanet: e.lostPlanet,
				artifact: e.artifact,
				federation: e.federation
			})),
			federations: e.federations.map((e) => ({
				id: e.id,
				seat: e.seat,
				hexes: [...e.hexes],
				satellites: [...e.satellites],
				token: e.token
			})),
			techPiles: e.techPiles.map((e) => ({
				id: e.id,
				kind: O[e.id]?.kind ?? "standard",
				track: e.track,
				remaining: e.remaining
			})),
			advancedTiles: e.advancedTiles.map((e) => ({
				id: e.id,
				track: e.track
			})),
			roundTiles: [...e.roundTiles],
			finalTiles: [...e.finalTiles],
			boosterPool: [...e.boosterPool],
			fedSupply: { ...e.fedSupply },
			terraformingToken: e.terraformingToken,
			usedPower: [...e.usedPower],
			usedQic: [...e.usedQic],
			lostFleet: e.lostFleet,
			ships: e.ships.map((e) => ({
				id: e.id,
				shuttles: [...e.shuttles],
				goldToken: e.goldToken,
				artifacts: [...e.artifacts],
				techs: [...e.techs],
				usedActions: [...e.usedActions],
				dock: e.dock
			})),
			pending: e.pending && e.pending.queue[0] ? {
				seat: e.pending.queue[0].seat,
				power: e.pending.queue[0].power,
				vp: e.pending.queue[0].vp
			} : null,
			roundDecision: e.roundDecision,
			hints: n < 0 ? ir() : Dn(e, n),
			log: e.log.slice(-80),
			result: e.result
		},
		private: { seat: n }
	};
}
function ir() {
	return {
		builds: [],
		gaia: [],
		upgrades: [],
		research: [],
		lostPlanet: [],
		advanceTracks: [],
		federations: [],
		fedTokens: [],
		fedThreshold: 7,
		power: [],
		qic: [],
		free: [],
		useTiles: [],
		freeMines: [],
		goldMines: [],
		boosters: [],
		faction: [],
		academy: !1,
		explore: [],
		examine: !1,
		shipActions: [],
		draft: [],
		tinkerChoices: [],
		pass: !1,
		passBoosters: [],
		passPoints: 0,
		charge: null,
		techs: [],
		passive: {}
	};
}
function ar(e) {
	return e.phase === "done" ? vt(e) : { phase: e.phase };
}
var or = {
	saveCompatibility: { version: "4" },
	meta: Mn,
	schemas: {
		action: Rn,
		publicView: Gn,
		privateView: Kn,
		config: Nn
	},
	setup: tr,
	reduce: nr,
	viewFor: rr,
	status: ar
}, sr = {
	vp: /* @__PURE__ */ m("path", { d: "M12 3.2 14.7 9l6.3.6-4.8 4.2 1.4 6.2L12 16.8 6.4 20l1.4-6.2L3 9.6 9.3 9Z" }),
	credits: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "8.2"
	}), /* @__PURE__ */ m("path", { d: "M12 6.6v10.8M9.2 9.4c0-1.3 1.2-2.2 2.8-2.2s2.8.9 2.8 2.2-1.2 2-2.8 2.2-2.8.9-2.8 2.2 1.2 2.2 2.8 2.2 2.8-.9 2.8-2.2" })] }),
	ores: /* @__PURE__ */ h("g", {
		stroke: "#3c475e",
		strokeWidth: "1",
		children: [
			/* @__PURE__ */ m("path", {
				fill: "#d2d9e4",
				d: "M6 17 3.5 14.2 6.8 8.8 9 6.4h8l2.1 2 1.4 6.9-3.2 2.5H8Z"
			}),
			/* @__PURE__ */ m("path", {
				fill: "#f0f4f9",
				d: "m6.8 8.8 2.2-2.4h8l2.1 2-3.1 3.5H8Z"
			}),
			/* @__PURE__ */ m("path", {
				fill: "#8795aa",
				d: "m16 11.9 3.1-3.5 1.4 6.9-3.2 2.5-1.3-2.6Z"
			})
		]
	}),
	knowledge: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3.6 19.2 8v8L12 20.4 4.8 16V8Z" }), /* @__PURE__ */ m("path", { d: "M12 8.4 15.4 10.4v3.2L12 15.6 8.6 13.6v-3.2Z" })] }),
	qic: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
		fill: "#77db9b",
		d: "m12 3 8 4.5v9L12 21l-8-4.5v-9Z"
	}), /* @__PURE__ */ m("path", {
		stroke: "#205e3d",
		d: "m4 7.5 8 4.5 8-4.5M12 12v9"
	})] }),
	power: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "8.4",
		fill: "#ae83ef"
	}), /* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "5",
		stroke: "#61438c"
	})] }),
	gaiaPower: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "8"
	}), /* @__PURE__ */ m("path", { d: "M12 5.4c2.7 1.9 4.2 4.1 4.2 6.6 0 2.6-1.8 4.9-4.2 6.6-2.4-1.7-4.2-4-4.2-6.6 0-2.5 1.5-4.7 4.2-6.6Z" })] }),
	brainstone: /* @__PURE__ */ m("path", { d: "M12 4.2 16.6 7v6L12 15.8 7.4 13V7ZM12 15.8v4M9 10h6" }),
	gaiaformer: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "12",
			r: "6.4"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "12",
			r: "2"
		}),
		/* @__PURE__ */ m("path", { d: "M12 3v3.6M12 17.4V21M3 12h3.6M17.4 12H21" })
	] }),
	types: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "12",
			r: "8"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "12",
			cy: "12",
			rx: "3.6",
			ry: "8"
		}),
		/* @__PURE__ */ m("path", { d: "M4 12h16" })
	] }),
	federation: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", { d: "M12 3.4 18.6 7.4v8.2L12 20.6 5.4 15.6V7.4Z" }),
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "12",
			r: "2.4"
		}),
		/* @__PURE__ */ m("path", { d: "M12 3.4v5M17.8 8.6l-4.2 2.4M17.8 15.4l-4.2-2.4M6.2 15.4l4.2-2.4M6.2 8.6l4.2 2.4" })
	] }),
	satellite: /* @__PURE__ */ m("path", { d: "M12 6.6 16 12l-4 5.4L8 12Z" }),
	terraform: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M4 18h16M7.4 18l2.6-6 2.6 3 2.4-7 3 10" }), /* @__PURE__ */ m("path", { d: "M9.4 8.6V5h4" })] }),
	nav: /* @__PURE__ */ m("path", { d: "M4.6 18.4c3-6.2 6.4-9.4 10.2-9.4M11 6.8h4.4v4.4M4 13.4h4.4V9" }),
	tech: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("rect", {
		x: "5",
		y: "5",
		width: "14",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ m("path", { d: "M9 9h6v6H9ZM12 2.6v2.4M12 19v2.4M2.6 12H5M19 12h2.4" })] }),
	build: /* @__PURE__ */ m("path", { d: "M12 3.4 17 12l-5 8.6L7 12Z M7 12h10M9.4 8.4h5.2" }),
	upgrade: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 16.6V5.2M8.2 9 12 5.2 15.8 9" }), /* @__PURE__ */ m("path", { d: "M5 19.2h14" })] }),
	research: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", { d: "M5.4 19.4 18.6 6.2" }),
		/* @__PURE__ */ m("circle", {
			cx: "7",
			cy: "17",
			r: "2.2"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "10.4",
			cy: "13.6",
			r: "2.2"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "13.8",
			cy: "10.2",
			r: "2.2"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "17.2",
			cy: "6.8",
			r: "2.2"
		})
	] }),
	actions: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3.2 18.4 6.8v7.2L12 17.6 5.6 14V6.8Z" }), /* @__PURE__ */ m("path", { d: "M12 8.2v4.4M9.8 10.4h4.4" })] }),
	pass: /* @__PURE__ */ m("path", { d: "M7 21V4M7 5h10.4l-2.6 4 2.6 4H7" }),
	info: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "8.4"
	}), /* @__PURE__ */ m("path", { d: "M12 11v5.2M12 7.8v.2" })] }),
	log: /* @__PURE__ */ m("path", { d: "M6 5h12M6 9.4h12M6 13.8h12M6 18.2h8" }),
	swap: /* @__PURE__ */ m("path", { d: "M5 9.4h12M13.6 6 17 9.4l-3.4 3.4M19 14.6H7M10.4 11.2 7 14.6l3.4 3.4" }),
	gaiaToken: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "7",
		r: "3.4"
	}), /* @__PURE__ */ m("path", { d: "M6 14c1.4-1.8 3.6-2.8 6-2.8s4.6 1 6 2.8M8.4 20c.8-1.4 2-2.2 3.6-2.2s2.8.8 3.6 2.2" })] }),
	asteroid: /* @__PURE__ */ m("path", { d: "M12 3.6 15 8l5 .6-3.4 3.6.8 5-5.4-1.8-5.4 1.8.8-5L4 8.6 9 8Z" }),
	orbit: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "7.6",
		strokeDasharray: "2.4 2.4"
	}), /* @__PURE__ */ m("circle", {
		cx: "17.4",
		cy: "6.6",
		r: "2.2"
	})] }),
	gain: /* @__PURE__ */ m("path", { d: "M12 4v12M7.4 11.4 12 16l4.6-4.6M4.6 20h14.8" }),
	cost: /* @__PURE__ */ m("path", { d: "M12 20V8M7.4 12.6 12 8l4.6 4.6M4.6 4h14.8" }),
	zoomIn: /* @__PURE__ */ m("path", { d: "M5 12h14M12 5v14" }),
	zoomOut: /* @__PURE__ */ m("path", { d: "M5 12h14" }),
	fitMap: /* @__PURE__ */ m("path", { d: "M4 9V4h5m6 0h5v5m0 6v5h-5m-6 0H4v-5" }),
	ai: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", { d: "M12 7v10M7 12h10" }),
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "5",
			r: "2.3"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "19",
			r: "2.3"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "5",
			cy: "12",
			r: "2.3"
		}),
		/* @__PURE__ */ m("circle", {
			cx: "19",
			cy: "12",
			r: "2.3"
		})
	] }),
	science: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("ellipse", {
			cx: "12",
			cy: "12",
			rx: "9",
			ry: "3.5"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "12",
			cy: "12",
			rx: "9",
			ry: "3.5",
			transform: "rotate(60 12 12)"
		}),
		/* @__PURE__ */ m("ellipse", {
			cx: "12",
			cy: "12",
			rx: "9",
			ry: "3.5",
			transform: "rotate(120 12 12)"
		})
	] }),
	sector: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3 20 7.5v9L12 21 4 16.5v-9Z M4 7.5l8 4.5 8-4.5M12 12v9" }), /* @__PURE__ */ m("path", { d: "m8 5.2 8 4.5v4.4" })] }),
	lock: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("rect", {
		x: "5.5",
		y: "10",
		width: "13",
		height: "10",
		rx: "2"
	}), /* @__PURE__ */ m("path", { d: "M8.5 10V7a3.5 3.5 0 1 1 7 0v3M12 14v2.5" })] }),
	used: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
		cx: "12",
		cy: "12",
		r: "8"
	}), /* @__PURE__ */ m("path", { d: "m8 12 3 3 5-6" })] }),
	ship: /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("path", { d: "M12 3.6c2.4 1.7 3.6 4.1 3.6 6.9v4L12 16.5l-3.6-2v-4c0-2.8 1.2-5.2 3.6-6.9Z" }),
		/* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "9.4",
			r: "1.4"
		}),
		/* @__PURE__ */ m("path", { d: "M8.4 13.2 5.4 15.6V19l3-1.7M15.6 13.2l3 2.4V19l-3-1.7" })
	] }),
	shuttle: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3.8 15.2 9v4.8L12 19.6 8.8 13.8V9Z" }), /* @__PURE__ */ m("path", { d: "M8.8 13.6 12 11.6l3.2 2" })] }),
	artifact: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3.4 16.6 8.4 12 20.6 7.4 8.4Z" }), /* @__PURE__ */ m("path", { d: "M7.4 8.4h9.2M9.6 8.4 12 20.6M14.4 8.4 12 20.6" })] }),
	gold: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", { d: "M12 3 19 7v10l-7 4-7-4V7Z" }), /* @__PURE__ */ m("path", { d: "M12 8.2l1.4 3 3.2.3-2.4 2.2.8 3.1-3-1.7-3 1.7.8-3.1-2.4-2.2 3.2-.3Z" })] })
}, cr = {
	fedBuildings: "federation",
	buildings: "build",
	types: "types",
	gaiaPlanets: "gaiaformer",
	sectors: "sector",
	satellites: "satellite",
	lf_asteroids: "asteroid",
	lf_piAcademy: "nav",
	lf_outerSectors: "orbit"
};
function $({ name: e, size: t = 18, className: n = "", strokeWidth: r = 1.8 }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		width: t,
		height: t,
		"aria-hidden": !0,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: r,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className: `gp-icon${n ? ` ${n}` : ""}`,
		children: sr[e]
	});
}
function lr({ icon: e, value: t, warn: n, title: r }) {
	return /* @__PURE__ */ h("span", {
		className: `gp-stat${n ? " is-warn" : ""}`,
		title: r,
		children: [/* @__PURE__ */ m($, {
			name: e,
			size: 14
		}), /* @__PURE__ */ m("b", { children: t })]
	});
}
var ur = Math.sqrt(3), dr = 46 * .95;
function fr(e, t) {
	return {
		x: 69 * e,
		y: ur / 2 * 46 * t
	};
}
var pr = [
	[46, 0],
	[23, ur / 2 * 46],
	[-23, ur / 2 * 46],
	[-46, 0],
	[-23, -(ur / 2) * 46],
	[23, -(ur / 2) * 46]
], mr = pr.map(([e, t]) => `${e.toFixed(1)},${t.toFixed(1)}`).join(" "), hr = [
	[1, 1],
	[0, 2],
	[-1, 1],
	[-1, -1],
	[0, -2],
	[1, -1]
], gr = [
	"#172442",
	"#1e2446",
	"#302449",
	"#332433",
	"#182e41",
	"#1d2843"
];
function _r(e) {
	return gr[(Number(e.replace(/\D/g, "")) || 0) % gr.length];
}
function vr(e) {
	return e == null || e < 0 ? "#93a7c4" : u[e % u.length].hex;
}
function yr(e) {
	let t = Infinity, n = Infinity, r = -Infinity, i = -Infinity;
	for (let a of e) {
		let e = fr(a.row, a.col);
		t = Math.min(t, e.x - 46), r = Math.max(r, e.x + 46), n = Math.min(n, e.y - ur * 46 / 2), i = Math.max(i, e.y + ur * 46 / 2);
	}
	return Number.isFinite(t) ? {
		minX: t,
		minY: n,
		maxX: r,
		maxY: i
	} : {
		minX: -46,
		minY: -46,
		maxX: 46,
		maxY: 46
	};
}
function br(e, t, n) {
	let r = yr(e), i = r.maxX - r.minX, a = r.maxY - r.minY, o = Math.min(t / i, n / a) * .92;
	return {
		k: o,
		x: (t - i * o) / 2 - r.minX * o,
		y: (n - a * o) / 2 - r.minY * o
	};
}
function xr(e, t, n, r, i) {
	let a = e.hexes.filter((e) => e.structure?.seat === t || e.parasite === t || e.station === t || e.lostPlanet === t)[0];
	if (!a) return i;
	let o = fr(a.row, a.col), s = Math.min(1.35, Math.max(i.k * 1.9, .85));
	return {
		k: s,
		x: n / 2 - o.x * s,
		y: r / 2 - o.y * s
	};
}
function Sr({ view: e, seat: t, mode: s, legal: c, selected: u, previewMine: d, builtHex: f, buildCard: g, fedSel: _, fedSatellites: v, foundedHex: y, pickable: b, colorOfSeat: x, onPick: S }) {
	let C = l(), w = (e) => e == null || e < 0 ? "#93a7c4" : x ? x(e) : vr(e), te = a(null), [T, ne] = o({
		w: 0,
		h: 0
	}), [E, re] = o({
		x: 0,
		y: 0,
		k: 1
	}), ie = a(E), ae = n((e) => {
		ie.current = e, re(e);
	}, []), oe = e.hexes.map((e) => e.id).join(",");
	i(() => {
		let e = te.current;
		if (!e) return;
		let t = new ResizeObserver((e) => {
			let t = e[0]?.contentRect;
			t && ne((e) => Math.abs(e.w - t.width) < 1 && Math.abs(e.h - t.height) < 1 ? e : {
				w: t.width,
				h: t.height
			});
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let se = n((t, n) => {
		t <= 0 || n <= 0 || ae(br(e.hexes, t, n));
	}, [e.hexes, ae]), D = a("");
	r(() => {
		if (T.w <= 0 || T.h <= 0) return;
		let e = `${oe}|${t}|${T.w}|${T.h}`;
		D.current !== e && (D.current = e, se(T.w, T.h));
	}, [
		oe,
		t,
		T.w,
		T.h,
		se
	]);
	let ce = n(() => {
		T.w > 0 && se(T.w, T.h);
	}, [
		se,
		T.h,
		T.w
	]), le = () => ae(xr(e, t, T.w, T.h, br(e.hexes, T.w, T.h))), ue = n((t, n, r) => {
		let i = ie.current, a = n ?? T.w / 2, o = r ?? T.h / 2, s = Math.min(2.4, Math.max(Math.min(.18, br(e.hexes, T.w, T.h).k), i.k * t)), c = s / i.k;
		ae({
			k: s,
			x: a - (a - i.x) * c,
			y: o - (o - i.y) * c
		});
	}, [
		T.h,
		T.w,
		e.hexes,
		ae
	]), O = a(/* @__PURE__ */ new Map()), de = a(null), fe = (e) => {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		};
	}, pe = (e) => {
		if (e.button !== 0 && e.pointerType === "mouse") return;
		let t = fe(e);
		if (O.current.set(e.pointerId, t), e.currentTarget.setPointerCapture(e.pointerId), O.current.size === 1) de.current = {
			moved: !1,
			pinch: 0,
			startDist: 0,
			startK: ie.current.k,
			startMid: t,
			startTf: ie.current
		};
		else if (O.current.size === 2) {
			let [e, t] = [...O.current.values()], n = {
				x: (e.x + t.x) / 2,
				y: (e.y + t.y) / 2
			};
			de.current = {
				moved: !0,
				pinch: 0,
				startDist: Math.hypot(e.x - t.x, e.y - t.y),
				startK: ie.current.k,
				startMid: n,
				startTf: ie.current
			};
		}
	}, me = (t) => {
		if (!O.current.get(t.pointerId)) return;
		let n = fe(t);
		O.current.set(t.pointerId, n);
		let r = de.current;
		if (!r) return;
		if (O.current.size >= 2) {
			let [t, n] = [...O.current.values()], i = Math.hypot(t.x - n.x, t.y - n.y), a = {
				x: (t.x + n.x) / 2,
				y: (t.y + n.y) / 2
			};
			if (r.startDist > 0) {
				let t = Math.min(2.4, Math.max(Math.min(.18, br(e.hexes, T.w, T.h).k), r.startK * (i / r.startDist))), n = t / r.startTf.k;
				ae({
					k: t,
					x: a.x - (r.startMid.x - r.startTf.x) * n,
					y: a.y - (r.startMid.y - r.startTf.y) * n
				});
			}
			return;
		}
		let i = n.x - r.startMid.x, a = n.y - r.startMid.y;
		!r.moved && Math.hypot(i, a) > 8 && (r.moved = !0), r.moved && ae({
			...r.startTf,
			x: r.startTf.x + i,
			y: r.startTf.y + a
		});
	}, he = (t) => {
		let n = O.current.size === 1, r = de.current;
		if (O.current.delete(t.pointerId), O.current.size > 0) {
			let e = [...O.current.values()][0];
			e && (de.current = {
				moved: !0,
				pinch: 0,
				startDist: 0,
				startK: ie.current.k,
				startMid: e,
				startTf: ie.current
			});
			return;
		}
		if (de.current = null, !n || !r || r.moved) return;
		let i = fe(t), a = ie.current, o = (i.x - a.x) / a.k, s = (i.y - a.y) / a.k, c = null, l = dr;
		for (let t of e.hexes) {
			let e = fr(t.row, t.col), n = Math.hypot(e.x - o, e.y - s);
			n < l && (c = t, l = n);
		}
		c && S(c);
	};
	r(() => {
		let e = te.current;
		if (!e) return;
		let t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect();
			ue(t.deltaY < 0 ? 1.12 : 1 / 1.12, t.clientX - n.left, t.clientY - n.top);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [ue]);
	let ge = new Set(e.federations.flatMap((e) => e.hexes)), _e = (t, n, r) => {
		let i = e.hexes.filter((e) => t.has(e.id));
		return /* @__PURE__ */ m("g", {
			className: "gp-fed-links",
			"data-style": r,
			stroke: n,
			children: i.flatMap((e, t) => {
				let n = fr(e.row, e.col);
				return i.slice(t + 1).filter((t) => Le(e, t)).map((t) => {
					let r = fr(t.row, t.col);
					return /* @__PURE__ */ m("line", {
						x1: n.x,
						y1: n.y,
						x2: r.x,
						y2: r.y,
						pathLength: 100
					}, `${e.id}/${t.id}`);
				});
			})
		});
	}, ve = _ ? _e(/* @__PURE__ */ new Set([..._, ...v ?? []]), "#ffd47d", "preview") : null, ye = e.hexes.length > 12, be = Cr(e.hexes), xe = new Map(e.hexes.map((e) => [`${e.row}:${e.col}`, e.sector])), Se = g ? e.hexes.find((e) => e.id === u) : void 0, Ce = Se ? fr(Se.row, Se.col) : null, we = Ce ? {
		"--gp-anchor-x": `${Ce.x * E.k + E.x}px`,
		"--gp-anchor-y": `${Ce.y * E.k + E.y}px`,
		"--gp-anchor-radius": `${46 * E.k}px`
	} : void 0;
	return /* @__PURE__ */ h("div", {
		ref: te,
		className: "gp-board",
		children: [
			/* @__PURE__ */ m("div", {
				className: "gp-map-surface",
				onPointerDown: pe,
				onPointerMove: me,
				onPointerUp: he,
				onPointerCancel: (e) => {
					O.current.delete(e.pointerId), de.current = null;
				},
				children: /* @__PURE__ */ h("svg", {
					viewBox: `0 0 ${Math.max(1, T.w)} ${Math.max(1, T.h)}`,
					role: "group",
					"aria-label": C("games.gaiaproject.mapTitle"),
					children: [
						/* @__PURE__ */ h("defs", { children: [
							/* @__PURE__ */ h("radialGradient", {
								id: "gp-space",
								cx: "50%",
								cy: "42%",
								r: "70%",
								children: [/* @__PURE__ */ m("stop", {
									offset: "0",
									stopColor: "#151934"
								}), /* @__PURE__ */ m("stop", {
									offset: "1",
									stopColor: "#050712"
								})]
							}),
							/* @__PURE__ */ h("radialGradient", {
								id: "gp-selected-glow",
								cx: "50%",
								cy: "50%",
								r: "60%",
								children: [/* @__PURE__ */ m("stop", {
									offset: "0",
									stopColor: "#5fe3d2",
									stopOpacity: "0.4"
								}), /* @__PURE__ */ m("stop", {
									offset: "1",
									stopColor: "#5fe3d2",
									stopOpacity: "0"
								})]
							}),
							/* @__PURE__ */ h("radialGradient", {
								id: "gp-nebula",
								children: [
									/* @__PURE__ */ m("stop", {
										stopColor: "#ba8df8",
										stopOpacity: ".44"
									}),
									/* @__PURE__ */ m("stop", {
										offset: ".4",
										stopColor: "#6858c5",
										stopOpacity: ".29"
									}),
									/* @__PURE__ */ m("stop", {
										offset: "1",
										stopColor: "#365797",
										stopOpacity: "0"
									})
								]
							}),
							/* @__PURE__ */ h("radialGradient", {
								id: "gp-planet-shade",
								cx: "32%",
								cy: "25%",
								r: "76%",
								children: [
									/* @__PURE__ */ m("stop", {
										stopColor: "#fff",
										stopOpacity: ".39"
									}),
									/* @__PURE__ */ m("stop", {
										offset: ".5",
										stopColor: "#fff",
										stopOpacity: "0"
									}),
									/* @__PURE__ */ m("stop", {
										offset: "1",
										stopColor: "#080917",
										stopOpacity: ".64"
									})
								]
							}),
							/* @__PURE__ */ h("pattern", {
								id: "gp-stars",
								width: "173",
								height: "139",
								patternUnits: "userSpaceOnUse",
								fill: "#c5deff",
								children: [
									/* @__PURE__ */ m("circle", {
										cx: "14",
										cy: "38",
										r: ".8"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "39",
										cy: "117",
										r: ".55"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "81",
										cy: "15",
										r: ".65"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "121",
										cy: "85",
										r: "1.1"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "155",
										cy: "110",
										r: ".7"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "68",
										cy: "66",
										r: ".6"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "151",
										cy: "20",
										r: ".5"
									}),
									/* @__PURE__ */ m("circle", {
										cx: "16",
										cy: "95",
										r: ".5"
									})
								]
							}),
							/* @__PURE__ */ m("clipPath", {
								id: "gp-map-outline",
								children: e.hexes.map((e) => {
									let { x: t, y: n } = fr(e.row, e.col);
									return /* @__PURE__ */ m("polygon", {
										points: mr,
										transform: `translate(${t} ${n})`
									}, e.id);
								})
							})
						] }),
						/* @__PURE__ */ m("rect", {
							width: T.w,
							height: T.h,
							fill: "url(#gp-space)"
						}),
						/* @__PURE__ */ m("rect", {
							width: T.w,
							height: T.h,
							fill: "url(#gp-stars)",
							opacity: ".45"
						}),
						/* @__PURE__ */ h("g", {
							transform: `translate(${E.x} ${E.y}) scale(${E.k})`,
							children: [
								/* @__PURE__ */ h("g", {
									clipPath: "url(#gp-map-outline)",
									children: [
										e.hexes.map((e) => {
											let { x: t, y: n } = fr(e.row, e.col);
											return /* @__PURE__ */ m("polygon", {
												points: mr,
												transform: `translate(${t} ${n})`,
												fill: _r(e.sector)
											}, e.id);
										}),
										be.map(({ key: e, x: t, y: n }) => /* @__PURE__ */ m("ellipse", {
											cx: t,
											cy: n,
											rx: 154.1,
											ry: 46 * 2.65,
											fill: "url(#gp-nebula)"
										}, e)),
										/* @__PURE__ */ m("rect", {
											x: "-5000",
											y: "-5000",
											width: "10000",
											height: "10000",
											fill: "url(#gp-stars)",
											opacity: ".64"
										})
									]
								}),
								/* @__PURE__ */ m("g", {
									stroke: "#7787b5",
									strokeWidth: 2,
									fill: "none",
									strokeLinecap: "round",
									opacity: .72,
									children: e.hexes.map((e) => {
										let t = fr(e.row, e.col);
										return pr.map((n, r) => {
											let [i, a] = hr[r], o = xe.get(`${e.row + i}:${e.col + a}`);
											if (o === e.sector || o && (i < 0 || i === 0 && a < 0)) return null;
											let s = pr[r], c = pr[(r + 1) % 6];
											return /* @__PURE__ */ m("line", {
												x1: t.x + s[0],
												y1: t.y + s[1],
												x2: t.x + c[0],
												y2: t.y + c[1]
											}, `${e.id}-e${r}`);
										});
									})
								}),
								/* @__PURE__ */ h("g", {
									pointerEvents: "none",
									children: [e.federations.map((e) => /* @__PURE__ */ m("g", { children: _e(/* @__PURE__ */ new Set([...e.hexes, ...e.satellites]), w(e.seat), y && e.seat === t && e.hexes.includes(y) ? "formed" : "existing") }, e.id)), ve]
								}),
								/* @__PURE__ */ m("g", { children: e.hexes.map((e) => {
									let n = fr(e.row, e.col), r = e.gaiaformed ? "gaia" : e.planet, i = e.id === u, a = c.has(e.id), o = r ? ee[r]?.name : e.station == null ? e.lostPlanet == null ? a ? "mapEmptyCell" : void 0 : "planetLost" : "mapStation", l = ge.has(e.id), g = _?.has(e.id) ?? !1, y = (b?.has(e.id) ?? !1) && !g;
									return /* @__PURE__ */ h("g", {
										transform: `translate(${n.x} ${n.y})`,
										"aria-pressed": o ? i : void 0,
										role: o ? "button" : void 0,
										tabIndex: o ? 0 : void 0,
										"aria-label": o ? `${C(A(o))} · ${C(A(e.outer ? "mapOuterSector" : "mapSector"), { id: e.sector.replace(/\D/g, "") })}` : void 0,
										onKeyDown: o ? (t) => {
											(t.key === "Enter" || t.key === " ") && (t.preventDefault(), S(e));
										} : void 0,
										children: [
											/* @__PURE__ */ m("polygon", {
												points: mr,
												fill: "none",
												stroke: "#7380a9",
												strokeOpacity: ".25",
												strokeWidth: .85
											}),
											r && r in ee && /* @__PURE__ */ m(wr, {
												planet: r,
												planetRaw: e.planet,
												gaiaformed: e.gaiaformed
											}),
											e.lostPlanet != null && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
												r: 46 * .4,
												fill: "#1b2534",
												stroke: "#7c8ba3",
												strokeWidth: 1.4,
												strokeDasharray: "4 3"
											}), /* @__PURE__ */ m("line", {
												x1: -11.96,
												y1: 0,
												x2: 11.96,
												y2: 0,
												stroke: w(e.lostPlanet),
												strokeWidth: 4,
												strokeLinecap: "round"
											})] }),
											e.artifact && /* @__PURE__ */ m(Er, {}),
											e.structure && /* @__PURE__ */ m("g", {
												className: f === e.id && e.structure.seat === t ? "gp-mine-landed" : void 0,
												children: /* @__PURE__ */ m(Tr, {
													type: e.structure.type,
													color: w(e.structure.seat)
												})
											}),
											e.parasite != null && /* @__PURE__ */ m("g", {
												transform: "translate(22.08 12.88)",
												children: /* @__PURE__ */ m("g", {
													className: f === e.id && e.parasite === t ? "gp-mine-landed" : void 0,
													transform: "scale(.53)",
													children: /* @__PURE__ */ m(Tr, {
														type: "mine",
														color: w(e.parasite)
													})
												})
											}),
											e.satellites.length > 0 && e.satellites.map((e, t) => {
												let n = (-90 + t * 55) * (Math.PI / 180);
												return /* @__PURE__ */ m("g", {
													transform: `translate(${Math.cos(n) * 46 * .5} ${Math.sin(n) * 46 * .5})`,
													children: /* @__PURE__ */ m("path", {
														d: "M0 -5.98 L5.98 0 L0 5.98 L-5.98 0 Z",
														fill: w(e),
														stroke: "#08101a",
														strokeWidth: 1
													})
												}, t);
											}),
											e.station != null && /* @__PURE__ */ m("g", {
												transform: "translate(-19.32 -19.32)",
												children: /* @__PURE__ */ m("polygon", {
													points: mr,
													transform: "scale(0.16)",
													fill: "#0b1420",
													stroke: w(e.station),
													strokeWidth: 8
												})
											}),
											e.gaiaformer != null && /* @__PURE__ */ h("g", {
												stroke: w(e.gaiaformer),
												strokeWidth: 2.2,
												fill: "none",
												children: [/* @__PURE__ */ m("circle", {
													r: 46 * .3,
													strokeDasharray: "6 4"
												}), [
													0,
													60,
													120,
													180,
													240,
													300
												].map((e) => {
													let t = e * Math.PI / 180;
													return /* @__PURE__ */ m("line", {
														x1: Math.cos(t) * 46 * .24,
														y1: Math.sin(t) * 46 * .24,
														x2: Math.cos(t) * 46 * .34,
														y2: Math.sin(t) * 46 * .34
													}, e);
												})]
											}),
											l && /* @__PURE__ */ m("polygon", {
												points: mr,
												fill: "none",
												stroke: "#e8c46a",
												strokeWidth: 2.6,
												opacity: .9
											}),
											y && /* @__PURE__ */ m("polygon", {
												className: "gp-target-path",
												points: mr,
												fill: "none",
												stroke: "#e8c46a",
												strokeWidth: 2,
												strokeDasharray: "8 5",
												opacity: .9
											}),
											g && /* @__PURE__ */ m("polygon", {
												points: mr,
												fill: "#e8c46a",
												fillOpacity: .16,
												stroke: "#ffd98a",
												strokeWidth: 3
											}),
											v?.includes(e.id) && /* @__PURE__ */ m("path", {
												className: "gp-fed-preview-satellite",
												d: "M0 -10 10 0 0 10 -10 0Z"
											}),
											a && /* @__PURE__ */ m("polygon", {
												className: "gp-target-path",
												points: mr,
												fill: "#5fe3d2",
												fillOpacity: .08,
												stroke: "#5fe3d2",
												strokeWidth: 2.2,
												strokeDasharray: "8 5"
											}),
											i && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
												r: 46 * 1.06,
												fill: "url(#gp-selected-glow)"
											}), /* @__PURE__ */ m("polygon", {
												points: mr,
												fill: "none",
												stroke: "#eafcff",
												strokeWidth: 3
											})] }),
											d?.hex === e.id && /* @__PURE__ */ m("g", {
												opacity: ".68",
												transform: d.parasite ? "translate(22.08 12.88) scale(.53)" : void 0,
												children: /* @__PURE__ */ m(Tr, {
													type: "mine",
													color: w(t)
												})
											}),
											f === e.id && (e.structure?.seat === t || e.parasite === t) && /* @__PURE__ */ m("circle", {
												className: "gp-mine-ripple",
												r: 34.04,
												fill: "none",
												stroke: w(t),
												strokeWidth: "2.5"
											}),
											s === "federation" && e.id === u && /* @__PURE__ */ m("polygon", {
												points: mr,
												fill: "none",
												stroke: "#ffd98a",
												strokeWidth: 3.4
											})
										]
									}, e.id);
								}) }),
								e.ships.map((t) => {
									let n = e.hexes.find((e) => e.id === t.dock);
									if (!n) return null;
									let r = fr(n.row, n.col), i = Be[t.id], a = C(A(i?.name ?? t.id));
									return /* @__PURE__ */ h("g", {
										transform: `translate(${r.x} ${r.y})`,
										pointerEvents: "none",
										children: [
											/* @__PURE__ */ m("title", { children: a }),
											/* @__PURE__ */ h("g", {
												transform: "translate(-23.92 -15.64)",
												children: [/* @__PURE__ */ m("rect", {
													x: -8,
													y: -8,
													width: 16,
													height: 16,
													rx: 4,
													fill: "#0b1224",
													stroke: "#e8c46a",
													strokeWidth: 1.5
												}), /* @__PURE__ */ h("g", {
													transform: "translate(-6 -6) scale(0.5)",
													children: [/* @__PURE__ */ m("path", {
														d: "M12 3.6c2.4 1.7 3.6 4.1 3.6 6.9v4L12 16.5l-3.6-2v-4c0-2.8 1.2-5.2 3.6-6.9Z",
														fill: "none",
														stroke: "#e8c46a",
														strokeWidth: 2.4
													}), /* @__PURE__ */ m("circle", {
														cx: "12",
														cy: "9.4",
														r: "1.4",
														fill: "#e8c46a"
													})]
												})]
											}),
											t.goldToken && /* @__PURE__ */ h("g", {
												transform: `translate(21.16 ${-46 * .4})`,
												children: [/* @__PURE__ */ m("polygon", {
													points: "0,-6 5.2,-3 5.2,3 0,6 -5.2,3 -5.2,-3",
													fill: "#e8c46a",
													stroke: "#3a2c08",
													strokeWidth: .9
												}), /* @__PURE__ */ m("path", {
													d: "M0 -2.4l.8 1.7 1.8.2-1.3 1.2.4 1.8L0 1.6l-1.7 1 .4-1.8L-2.6-.5l1.8-.2Z",
													fill: "#3a2c08"
												})]
											}),
											[
												0,
												1,
												2,
												3
											].map((e) => {
												let n = t.shuttles[e];
												return /* @__PURE__ */ m("circle", {
													cx: -16.56 + e * 46 * .24,
													cy: 19.32,
													r: 46 * .075,
													fill: n == null ? "#1b2436" : w(n),
													stroke: n == null ? "#3a4a68" : "#eafcff",
													strokeWidth: .9
												}, e);
											}),
											t.artifacts.length > 0 && /* @__PURE__ */ h("g", {
												transform: `translate(20.24 ${46 * .4})`,
												children: [/* @__PURE__ */ m("circle", {
													r: 6,
													fill: "#1b1226",
													stroke: "#c9a6ff",
													strokeWidth: .9
												}), /* @__PURE__ */ m("text", {
													textAnchor: "middle",
													dy: "2.6",
													fontSize: 7,
													fill: "#e6d6ff",
													fontFamily: "ui-monospace, monospace",
													children: t.artifacts.length
												})]
											})
										]
									}, `ship-${t.id}`);
								}),
								ye && /* @__PURE__ */ m("g", {
									fill: "#a1b2d2",
									fontSize: 46 * .33,
									fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
									textAnchor: "middle",
									opacity: .74,
									pointerEvents: "none",
									children: be.map(({ key: e, x: t, y: n, label: r }) => /* @__PURE__ */ m("text", {
										x: t,
										y: n,
										children: r.startsWith("O") ? r : r.replace(/\D/g, "").padStart(2, "0")
									}, e))
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "gp-board-tools",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-map-btn",
						onClick: () => ue(1.25),
						"aria-label": C("games.gaiaproject.mapZoomIn"),
						children: /* @__PURE__ */ m($, {
							name: "zoomIn",
							size: 18
						})
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-map-btn",
						onClick: () => ue(1 / 1.25),
						"aria-label": C("games.gaiaproject.mapZoomOut"),
						children: /* @__PURE__ */ m($, {
							name: "zoomOut",
							size: 18
						})
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-map-btn",
						onClick: ce,
						"aria-label": C("games.gaiaproject.mapFit"),
						children: /* @__PURE__ */ m($, {
							name: "fitMap",
							size: 18
						})
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-map-btn",
						onClick: le,
						"aria-label": C("games.gaiaproject.mapFocus"),
						children: /* @__PURE__ */ m($, {
							name: "gaiaformer",
							size: 18
						})
					})
				]
			}),
			Ce && /* @__PURE__ */ m("div", {
				className: `gp-card gp-card-build${Ce.x * E.k + E.x > T.w * .64 ? " gp-card-left" : ""}`,
				style: we,
				children: g
			})
		]
	});
}
function Cr(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = t.get(n.sector);
		e ? e.push(n) : t.set(n.sector, [n]);
	}
	let n = [];
	for (let [e, r] of t) {
		let t = 0, i = 0;
		for (let e of r) {
			let n = fr(e.row, e.col);
			t += n.x, i += n.y;
		}
		n.push({
			key: e,
			x: t / r.length,
			y: i / r.length,
			label: e
		});
	}
	return n;
}
function wr({ planet: e, planetRaw: t, gaiaformed: n }) {
	let r = ee[e], i = 46 * .66, a = 46 / 26;
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("circle", {
			cy: 2.5,
			r: 32.36,
			fill: "#080916",
			opacity: ".84"
		}),
		/* @__PURE__ */ m("circle", {
			r: i,
			fill: r.color,
			stroke: "#c4d6ed",
			strokeOpacity: ".56",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ m("circle", {
			r: i,
			fill: "url(#gp-planet-shade)"
		}),
		n && /* @__PURE__ */ m("circle", {
			r: 33.36,
			fill: "none",
			stroke: "#a8ffe6",
			strokeWidth: 1.6,
			opacity: .8
		}),
		!n && t === "transdim" && /* @__PURE__ */ m("circle", {
			r: 32.86,
			fill: "none",
			stroke: "#b9a6ff",
			strokeWidth: 1.3,
			strokeDasharray: "4 4",
			opacity: .8
		}),
		/* @__PURE__ */ m("g", {
			transform: `translate(${-12 * a} ${-12 * a}) scale(${a})`,
			children: /* @__PURE__ */ m("path", {
				d: r.glyph,
				fill: "#050a12",
				fillOpacity: .5,
				stroke: "#f2f7ff",
				strokeOpacity: .55,
				strokeWidth: 1.1
			})
		})
	] });
}
function Tr({ type: e, color: t }) {
	let n = 16.56, r = "#050a12";
	switch (e) {
		case "mine": return /* @__PURE__ */ h("g", {
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ m("path", {
					d: `M-16.56 ${n * .47} -11.0952 ${-16.56 * .22} 0 -18.216 ${n * .73} -3.312 ${n} ${n * .47} 0 ${n * .88}Z`,
					fill: t,
					stroke: r,
					strokeWidth: 2.6
				}),
				/* @__PURE__ */ m("path", {
					d: `M0 -16.56 0 ${n * .62} ${n * .82} ${n * .41} ${n * .58} -2.6496Z`,
					fill: "#10132a",
					opacity: ".38"
				}),
				/* @__PURE__ */ m("path", {
					d: `M-12.5856 ${n * .39} 0 ${-16.56 * .89}`,
					stroke: "#fff",
					strokeOpacity: ".68",
					strokeWidth: "1.6"
				})
			]
		});
		case "ts": return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
			d: `M-16.56 ${n * .55} L${-16.56 * .7} ${-16.56 * .35} L${n * .7} ${-16.56 * .35} L${n} ${n * .55} Z`,
			fill: t,
			stroke: r,
			strokeWidth: 2
		}), /* @__PURE__ */ m("line", {
			x1: -16.56 * 1.15,
			y1: n * .6,
			x2: n * 1.15,
			y2: n * .6,
			stroke: t,
			strokeWidth: 3,
			strokeLinecap: "round"
		})] });
		case "rl": return /* @__PURE__ */ h("g", {
			fill: t,
			stroke: r,
			strokeWidth: 1.8,
			children: [/* @__PURE__ */ m("rect", {
				x: -16.56 * .85,
				y: -13.248,
				width: n * .55,
				height: n * 1.6,
				rx: 2
			}), /* @__PURE__ */ m("rect", {
				x: n * .3,
				y: -13.248,
				width: n * .55,
				height: n * 1.6,
				rx: 2
			})]
		});
		case "pi": return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
			r: n * .82,
			fill: t,
			stroke: r,
			strokeWidth: 2
		}), /* @__PURE__ */ m("circle", {
			r: n * .34,
			fill: "#0b1420",
			stroke: "#f2f7ff",
			strokeWidth: 1,
			opacity: .7
		})] });
		case "ac": return /* @__PURE__ */ m("path", {
			d: `M0 -16.56 L${n * .4} -6.624 L${n} -5.2992 L${n * .62} ${n * .28} L${n * .86} ${n * .9} L0 ${n * .5} L${-16.56 * .86} ${n * .9} L${-16.56 * .62} ${n * .28} L-16.56 -5.2992 L-6.624 -6.624 Z`,
			fill: t,
			stroke: r,
			strokeWidth: 2
		});
		default: return null;
	}
}
function Er() {
	let e = 10.12;
	return /* @__PURE__ */ m("g", {
		transform: "translate(19.32 19.32)",
		children: /* @__PURE__ */ m("path", {
			d: `M0 -10.12 L${e * .3} ${-10.12 * .3} L${e} 0 L${e * .3} ${e * .3} L0 ${e} L${-10.12 * .3} ${e * .3} L-10.12 0 L${-10.12 * .3} ${-10.12 * .3} Z`,
			fill: "#e8c46a",
			stroke: "#050a12",
			strokeWidth: 1
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
var Dr = {
	info: "games.gaiaproject.infoTitle",
	log: "games.gaiaproject.logTitle",
	actions: "games.gaiaproject.actionsTitle",
	research: "games.gaiaproject.researchTitle",
	tech: "games.gaiaproject.techTitle",
	pass: "games.gaiaproject.passTitle",
	rescore: "games.gaiaproject.rescoreTitle",
	ships: "games.gaiaproject.shipsTitle"
}, Or = {
	terrans: "games.gaiaproject.factionTerrans",
	lantids: "games.gaiaproject.factionLantids",
	taklons: "games.gaiaproject.factionTaklons",
	ambas: "games.gaiaproject.factionAmbas",
	gleens: "games.gaiaproject.factionGleens",
	xenos: "games.gaiaproject.factionXenos",
	ivits: "games.gaiaproject.factionIvits",
	hadschhallas: "games.gaiaproject.factionHadschHallas",
	bescods: "games.gaiaproject.factionBescods",
	firaks: "games.gaiaproject.factionFiraks",
	geodens: "games.gaiaproject.factionGeodens",
	baltaks: "games.gaiaproject.factionBaltaks",
	nevlas: "games.gaiaproject.factionNevlas",
	itars: "games.gaiaproject.factionItars",
	spacegiants: "games.gaiaproject.factionSpaceGiants",
	moweyds: "games.gaiaproject.factionMoweyds",
	darkanians: "games.gaiaproject.factionDarkanians",
	tinkeroids: "games.gaiaproject.factionTinkeroids"
}, kr = Object.fromEntries([
	...he,
	...ge,
	..._e,
	...ve
].map((e) => [e.id, A(e.name)])), Ar = Object.fromEntries(w.map((e) => [e.id, e])), jr = {
	terra: {
		icon: "terraform",
		color: "#ed9c71"
	},
	nav: {
		icon: "nav",
		color: "#adc4ff"
	},
	ai: {
		icon: "ai",
		color: "#9de595"
	},
	gaia: {
		icon: "gaiaformer",
		color: "#ed98df"
	},
	eco: {
		icon: "credits",
		color: "#facc78"
	},
	sci: {
		icon: "science",
		color: "#74d7f0"
	}
}, Mr = {
	p_knw3: {
		icon: "knowledge",
		amount: 3
	},
	p_terra2: {
		icon: "terraform",
		amount: 2
	},
	p_ore2: {
		icon: "ores",
		amount: 2
	},
	p_credits7: {
		icon: "credits",
		amount: 7
	},
	p_knw2: {
		icon: "knowledge",
		amount: 2
	},
	p_terra1: {
		icon: "terraform",
		amount: 1
	},
	p_tokens2: {
		icon: "power",
		amount: 2
	},
	q_tech: { icon: "tech" },
	q_rescore: { icon: "federation" },
	q_types: { icon: "types" }
}, Nr = {
	immediate: "gain",
	immediatePerType: "types",
	income: "credits",
	action: "actions",
	passive: "orbit",
	pass: "pass",
	immediatePer: "vp",
	freeMineTerra: "build"
}, Pr = {
	vpPerType: "games.gaiaproject.shipRewardVpPerType",
	advanceResearch: "games.gaiaproject.shipRewardAdvanceResearch",
	freeAsteroidMine: "games.gaiaproject.shipRewardFreeAsteroidMine",
	repeatFed: "games.gaiaproject.shipRewardRepeatFed",
	freeUpgradeRl: "games.gaiaproject.shipRewardFreeUpgradeRl",
	range3: "games.gaiaproject.shipRewardRange3",
	standardTech: "games.gaiaproject.shipRewardStandardTech",
	gaiaProject: "games.gaiaproject.shipRewardGaiaProject",
	freeMine1: "games.gaiaproject.shipRewardFreeMine1",
	tech: "games.gaiaproject.shipRewardTech",
	freeUpgradeTs: "games.gaiaproject.shipRewardFreeUpgradeTs",
	creditsQic: "games.gaiaproject.shipRewardCreditsQic"
}, Fr = {
	f_powQic: 4,
	f_powOre: 3,
	f_powKnw: 4,
	f_powCredit: 1
};
function Ir(e) {
	return w.some((t) => t.id === e) ? e : null;
}
function Lr(e) {
	let t = l(), n = e.public, r = e.private?.seat ?? n.players.find((t) => t.rid === e.myRid)?.seat ?? -1;
	return d(), r < 0 ? /* @__PURE__ */ m(f, {
		adaptive: !0,
		scroll: !1,
		className: "gp-screen",
		children: /* @__PURE__ */ m("div", {
			className: "gp-empty",
			children: t(A("errSeat"))
		})
	}) : /* @__PURE__ */ m(Rr, {
		pub: n,
		seat: r,
		members: e.members,
		send: e.send,
		t
	});
}
function Rr({ pub: e, seat: t, members: n, send: i, t: a }) {
	let [l, d] = o(null), [g, _] = o("info"), [v, b] = o("idle"), [x, S] = o(null), [C, te] = o(null), [ne, E] = o(null), [oe, se] = o(null), [D, ce] = o(null), [le, ue] = o(null), [de, pe] = o(null), [me, he] = o(null), [ge, _e] = o(null), [ve, we] = o(null), [k, Te] = o(null), [Ee, De] = o(null), [Oe, ke] = o(null), [Ae, je] = o(null);
	r(() => {
		if (Ee == null) return;
		let e = window.setTimeout(() => De(null), 1200);
		return () => window.clearTimeout(e);
	}, [Ee]), r(() => {
		if (Oe == null) return;
		let e = window.setTimeout(() => ke(null), 1150);
		return () => window.clearTimeout(e);
	}, [Oe]);
	let j = e.players.find((e) => e.seat === t), M = e.hints, Me = e.pending?.seat ?? null, Ne = Me === t && M.charge != null, Pe = e.roundDecision, Fe = Pe?.seat === t && Me == null, N = e.phase === "play" && !Pe && e.turnSeat === t && !j.passed && Me == null, Ie = (e) => n.find((t) => t.rid === e), Le = (t) => {
		let n = Ie(t)?.colorIndex ?? e.players.find((e) => e.rid === t)?.seat ?? 0;
		return u[n % u.length] ?? u[0];
	}, Re = (t) => {
		let n = e.players.find((e) => e.seat === t);
		return n ? Le(n.rid).hex : u[t % u.length].hex;
	}, ze = (e) => e === "$ghost" ? a(A("overGhost")) : Ie(e)?.name || a(Le(e).nameKey), Ve = (e) => s[(Ie(e)?.avatar ?? 0) % s.length], Ue = (t) => e.players.find((e) => e.seat === t)?.rid ?? "", Ge = (t) => t ? e.hexes.find((e) => e.id === t) : void 0, P = (e) => {
		let t = y[e];
		return t ? a(Or[t.id]) : e;
	}, qe = (e, t = !1) => {
		if (t && e) return a(A(ee.gaia.name));
		if (!e) return a(A("mapEmptyCell"));
		let n = ee[e];
		return a(A(n?.name ?? "mapEmptyCell"));
	}, F = (e) => {
		let t = Ir(e);
		return t ? a(A(Ar[t].name)) : e;
	}, I = (e) => {
		let t = O[e];
		return t ? a(A(t.name)) : e;
	}, L = (e) => {
		let t = O[e];
		return t ? a(A(t.desc)) : "";
	}, R = (e) => {
		let t = fe[e];
		return t ? a(A(t.name)) : e;
	}, z = (e) => {
		let t = fe[e];
		return t ? a(A(t.desc)) : "";
	}, B = (e) => {
		let t = ye[e];
		return t ? a(A(t.name)) : e;
	}, V = (e) => {
		let t = be.find((t) => t.id === e);
		return t ? a(A(t.name)) : e;
	}, Je = (e) => {
		let t = xe.find((t) => t.id === e);
		return t ? a(A(t.name)) : e;
	}, Ye = (e) => {
		let t = Be[e];
		return t ? a(A(t.name)) : e;
	}, Xe = (e) => {
		let t = He[e];
		if (!t) return e;
		let n = t.effect, r = a(A(t.name));
		return n.kind === "resources" ? `${r} · ${[
			["resCredits", n.credits],
			["resOres", n.ores],
			["resKnowledge", n.knowledge],
			["resQic", n.qic],
			["resPowerTokens", n.power]
		].filter(([, e]) => e).map(([e, t]) => `${t} ${a(A(e))}`).join(" · ")}` : r;
	}, Ze = (e) => {
		let t = Ke[e];
		return t ? a(A(t.name)) : e;
	}, Qe = (e) => {
		let t = We[e];
		return t ? a(A(t.name)) : e;
	}, $e = (e) => {
		let t = Object.values(Be).flatMap((e) => e.actions).find((t) => t.id === e), n = t ? Pr[t.reward.kind] : void 0;
		return n ? a(n) : e;
	}, et = (e) => {
		let t = Se.find((t) => t.id === e);
		return t ? a(A(t.name)) : e;
	}, tt = (e) => a(A(Ce[e] ?? "buildingMine")), H = (e) => {
		let t = Ge(e);
		return t ? `${qe(t.planet, t.gaiaformed)} · ${a(A(t.outer ? "mapOuterSector" : "mapSector"), { id: t.sector.replace(/\D/g, "") })}` : e;
	}, nt = `${e.phase}|${e.round}|${e.turnSeat}|${e.draftSeat ?? "x"}|${Me ?? "x"}|${Pe?.kind ?? "x"}|${t}|${j.passed}`, [rt, it] = o({
		key: nt,
		seat: t
	});
	nt !== rt.key && (it({
		key: nt,
		seat: t
	}), b("idle"), S(null), te(null), E(null), se(null), Te(null), t !== rt.seat && (De(null), ke(null), je(null)), d((t) => !Ne && (t === "info" || t === "log" || t === "ships" || e.phase === "play" && (t === "research" || t === "actions")) ? t : null));
	let at = (e) => {
		b("idle"), S(null), te(null), E(null), d((t) => t === "info" || t === "log" || t === e ? t : null);
	}, U = (e, t) => {
		e.type === "build" && De(e.hex), e.type === "federation" && ke(e.hexes[0] ?? null), i(e), at(t);
	}, W = (e) => i(e), ot = (e) => {
		_(e), d(e), e === "tech" && (ue(null), pe(null), he(null)), e === "pass" && _e(null), e === "research" && je(null);
	}, st = () => d(null), ct = () => {
		b("idle"), S(null), te(null), E(null), se(null), d(null);
	}, lt = (e) => {
		ce(e), ot("tech");
	}, ut = (e) => {
		te(e), b("idle"), S(null), E(null), d(null);
	}, dt = () => {
		let e = j.fedTokens[0]?.type ?? null;
		we(e), ot("rescore");
	}, G = /* @__PURE__ */ new Map();
	for (let e of M.builds) G.has(e.hex) || G.set(e.hex, e);
	let ft = /* @__PURE__ */ new Map();
	for (let e of M.gaia) ft.has(e.hex) || ft.set(e.hex, e);
	let pt = /* @__PURE__ */ new Map();
	for (let e of M.upgrades) {
		let t = pt.get(e.hex) ?? [];
		t.push(e), pt.set(e.hex, t);
	}
	let mt = /* @__PURE__ */ new Map();
	for (let e of M.faction) e.kind === "spaceStation" && e.hex && mt.set(e.hex, e);
	let ht = j.faction === "nevlas" && j.pi ? 2 * (j.power[2] + +(j.brainstone === "III")) : j.power[2] + (j.brainstone === "III" ? 3 : 0), gt = (e) => ht >= e, _t = (e) => j.credits >= e.credits && j.ores >= e.oreCost, vt = (e) => j.credits >= e.credits && j.ores >= e.ores && (!e.gainsTech || M.techs.length > 0), yt = /* @__PURE__ */ new Set();
	if (v === "federation") for (let e of M.federations) for (let t of e.hexes) yt.add(t);
	let K = /* @__PURE__ */ new Set();
	if (C) {
		if (C.kind === "power") for (let e of M.power) e.id === C.id && e.hex && (j.credits < (e.credits ?? 2) || j.ores < (e.oreCost ?? 1) || K.add(e.hex));
		else if (C.kind === "booster") for (let e of M.boosters) e.id === C.id && e.hex && (e.mode ?? "build") === C.mode && (C.mode === "build" && (j.credits < (e.credits ?? 2) || j.ores < (e.oreCost ?? 1)) || K.add(e.hex));
		else if (C.kind === "lostPlanet") for (let { hex: e, payQic: t } of M.lostPlanet) t <= C.availableQic && K.add(e);
		else if (C.kind === "freeMine") for (let e of M.freeMines) e.id === C.id && K.add(e.hex);
		else if (C.kind === "giantsMine") for (let e of M.faction) e.kind === "giantsMine" && e.hex && K.add(e.hex);
		else if (C.kind === "ring") for (let e of M.faction) e.kind === "moweydRing" && e.hex && K.add(e.hex);
		else if (C.kind === "tinkerBuild") for (let e of M.faction) e.kind === "tinkerAction" && e.hex && K.add(e.hex);
		else if (C.kind === "goldMine") for (let e of M.goldMines) e.token === C.token && K.add(e.hex);
		else for (let e of mt.keys()) K.add(e);
	} else if (v === "build") for (let e of M.builds) _t(e) && K.add(e.hex);
	else if (v === "gaia") for (let e of M.gaia) K.add(e.hex);
	else if (v === "upgrade") for (let e of M.upgrades) vt(e) && K.add(e.hex);
	let bt = v === "federation" && ne ? M.federations.find((e) => e.hexes.length === ne.size && e.hexes.every((e) => ne.has(e))) : void 0, xt = C ? C.kind === "booster" && C.mode === "gaia" ? "gaia" : "build" : v, St = (e) => {
		if (!Ne) {
			if (C) {
				K.has(e.id) && S(e.id);
				return;
			}
			if (v === "federation") {
				if (!yt.has(e.id)) return;
				let t = M.federations.find((t) => t.hexes.includes(e.id));
				if (!t) return;
				E(new Set(t.hexes)), S(e.id), se((e) => e && M.fedTokens.includes(e) ? e : null);
				return;
			}
			if (N && v !== "idle" && K.has(e.id)) {
				S(e.id);
				return;
			}
			S(e.id);
		}
	}, Ct = (e) => {
		if (v === e && !C) {
			ct();
			return;
		}
		b(e), te(null), S(null), E(null), se(null), d(null);
	}, wt = (e, t, n, r = 0) => /* @__PURE__ */ h("span", {
		className: "gp-costs",
		children: [
			e > 0 && /* @__PURE__ */ h("span", {
				className: "gp-cost",
				title: a(A("buildCostCredits"), { n: e }),
				children: [/* @__PURE__ */ m($, {
					name: "credits",
					size: 13
				}), e]
			}),
			t > 0 && /* @__PURE__ */ h("span", {
				className: "gp-cost",
				title: a(A("buildCostOres"), { n: t }),
				children: [/* @__PURE__ */ m($, {
					name: "ores",
					size: 13
				}), t]
			}),
			n > 0 && /* @__PURE__ */ h("span", {
				className: "gp-cost",
				title: a(A("buildCostQic"), { n }),
				children: [/* @__PURE__ */ m($, {
					name: "qic",
					size: 13
				}), n]
			}),
			r > 0 && /* @__PURE__ */ h("span", {
				className: "gp-cost",
				title: a(A("buildCostSteps"), { n: r }),
				children: [/* @__PURE__ */ m($, {
					name: "terraform",
					size: 13
				}), r]
			})
		]
	}), q = Ge(x), Tt = x ? G.get(x) : void 0, J = x ? ft.get(x) : void 0, Et = x ? pt.get(x) ?? [] : [], Y = N && !C && (v === "idle" || v === "build") ? Tt : void 0, Dt = C?.kind === "power" && x ? M.power.find((e) => e.id === C.id && e.hex === x) : void 0, Ot = C?.kind === "booster" && x ? M.boosters.find((e) => e.id === C.id && e.hex === x && (e.mode ?? "build") === C.mode) : void 0, kt = C?.kind === "station" && x ? mt.get(x) : void 0, At = M.charge, jt = j.techs.filter((e) => !j.advTechs.some((t) => t.covers === e)), Mt = D?.kind === "ship" ? D.standardOnly ? M.shipActions.filter((e) => e.ship === D.ship && e.action === D.action && e.tech).map((e) => ({
		id: e.tech,
		advanced: !1,
		track: null,
		advanceTracks: M.advanceTracks.flatMap((e) => {
			let t = Ir(e);
			return t ? [t] : [];
		})
	})) : M.techs.filter((e) => M.shipActions.some((t) => t.ship === D.ship && t.action === D.action && t.hex === D.hex && t.tech === e.id)) : M.techs, X = Mt.find((e) => e.id === le), Nt = Mt.filter((e) => !e.advanced), Pt = Mt.filter((e) => e.advanced), Ft = D?.kind === "ship" ? D.qic : D?.kind === "qic" ? xe.find(({ id: e }) => e === "q_tech").cost : D?.kind === "gold" && j.faction === "ivits" ? D.satellites.length : 0, It = X ? O[X.id]?.effect : void 0, Lt = j.qic - Ft + (It?.kind === "immediate" ? It.qic ?? 0 : 0), Rt = j.tracks[T.nav] === 4 && M.lostPlanet.some(({ payQic: e }) => e <= Lt), zt = X?.advanceTracks.filter((e) => e !== "nav" || j.tracks[T.nav] !== 4 || Rt) ?? [], Bt = [...new Set(j.fedTokens.map((e) => e.type))], Vt = M.faction.filter((e) => e.kind === "spaceStation" && e.hex), Ht = M.faction.find((e) => e.kind === "swapPI" && e.hex), Ut = M.faction.find((e) => e.kind === "baltaqGaiaformer"), Wt = M.faction.find((e) => e.kind === "nevlasKnowledge"), Gt = M.faction.some((e) => e.kind === "giantsMine" && e.hex), Kt = M.faction.some((e) => e.kind === "moweydRing" && e.hex), qt = M.faction.find((e) => e.kind === "tinkerAction"), Jt = j.booster ? fe[j.booster] : null, Yt = M.builds.some(_t), Xt = M.upgrades.some(vt), Zt = () => e.phase === "done" ? a(A("donePhase")) : Ne ? a(A("chargePhase")) : Me == null ? e.phase === "draft" ? a(A("draftPhase")) : Pe ? a(A(Pe.kind === "itars" ? "gaiaPhaseTitle" : "tinkerPickTitle")) : j.passed ? a(A("passedTag")) : N ? a(A("turnYou")) : a(A("turnWaiting"), { name: ze(Ue(e.turnSeat)) }) : a(A("chargeWait"), { name: ze(Ue(Me)) }), Qt = () => e.phase === "done" ? a(A("donePhase")) : Ne ? a(A("hintCharge")) : e.phase === "draft" ? e.draftSeat === t ? a(A("hintDraft")) : a(A("hintDraftWait")) : !N && !C ? a(A("hintNotTurn")) : C ? C.kind === "lostPlanet" ? a(A("hintResearchNav")) : C.kind === "station" ? a(A("hintSelectStation")) : C.kind === "ring" ? a(A("hintSelectRing")) : C.kind === "booster" && C.mode === "gaia" ? a(A("hintSelectGaia")) : a(A("hintSelectBuild")) : a(A(v === "build" ? x ? "hintSelectBuild" : "hintBuild" : v === "gaia" ? x ? "hintSelectGaia" : "hintGaia" : v === "upgrade" ? x ? "hintSelectUpgrade" : "hintUpgrade" : v === "federation" ? "fedPickCluster" : "hintIdle")), $t = (e) => e.startsWith("booster:") ? R(e.slice(8)) : e === "academy" ? a(A("logAcademy")) : e === "swapPI" ? a(A("factionSwapPI")) : e === "downgradeRL" ? a(A("factionDowngradeRLShort")) : e === "advanceLowest" ? a(A("factionAdvanceLowest")) : e === "itarsTech" ? a(A("factionItarsTech")) : e === "baltaqGaiaformer" ? a(A("factionBaltaqGaiaformer")) : e === "nevlasKnowledge" ? a(A("factionNevlasKnowledge")) : e === "spaceStation" ? a(A("factionSpaceStation")) : e === "tinkerPick" ? a(A("tinkerPickTitle")) : e === "giantsMine" ? a(A("factionGiantsMine")) : e === "moweydRing" ? a(A("factionMoweydRing")) : e === "tinkerAction" ? a(A("factionTinkerAction")) : e, en = /* @__PURE__ */ h("div", {
		className: "gp-banner",
		children: [
			/* @__PURE__ */ h("div", {
				className: "gp-head",
				children: [
					/* @__PURE__ */ m("span", {
						className: "gp-phase gp-round-update",
						children: e.phase === "play" ? a(A("roundN"), { n: e.round }) : Zt()
					}, e.round),
					e.lostFleet && /* @__PURE__ */ m("span", {
						className: "gp-experiment",
						children: a(A("experimentLabel"))
					}),
					e.phase === "play" && e.roundTiles[e.round - 1] && /* @__PURE__ */ h("span", {
						className: "gp-roundtile gp-round-update",
						children: [/* @__PURE__ */ m($, {
							name: "vp",
							size: 13
						}), a(kr[e.roundTiles[e.round - 1]] ?? A("roundScoring"))]
					}, e.roundTiles[e.round - 1]),
					e.phase !== "draft" && /* @__PURE__ */ m("span", {
						className: `gp-status${N ? " is-turn" : ""}`,
						children: Zt()
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "gp-telemetry",
				children: [/* @__PURE__ */ h("div", {
					className: "gp-resources",
					role: "group",
					"aria-label": a(A("infoResources")),
					children: [
						/* @__PURE__ */ m(lr, {
							icon: "credits",
							title: a(A("resCredits")),
							value: j.credits
						}),
						/* @__PURE__ */ m(lr, {
							icon: "ores",
							title: a(A("resOres")),
							value: j.ores
						}),
						/* @__PURE__ */ m(lr, {
							icon: "knowledge",
							title: a(A("resKnowledge")),
							value: j.knowledge
						}),
						/* @__PURE__ */ m(lr, {
							icon: "qic",
							title: a(A("resQic")),
							value: j.qic
						})
					]
				}), /* @__PURE__ */ h("div", {
					className: "gp-power-bowls",
					children: [j.power.map((e, t) => /* @__PURE__ */ h("span", {
						className: "gp-power-bowl",
						children: [/* @__PURE__ */ m("small", { children: [
							"I",
							"II",
							"III"
						][t] }), /* @__PURE__ */ m("b", { children: e })]
					}, t)), /* @__PURE__ */ m(lr, {
						icon: "gaiaPower",
						value: j.gaiaPower,
						title: a(A("resGaiaPower"))
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "gp-plates",
				children: e.players.map((t) => /* @__PURE__ */ h("div", {
					className: `gp-plate${e.turnSeat === t.seat && e.phase === "play" ? " is-turn" : ""}${t.passed ? " is-passed" : ""}`,
					style: { "--gp-seat": Le(t.rid).hex },
					children: [
						/* @__PURE__ */ m("img", {
							className: "gp-ava",
							src: Ve(t.rid),
							alt: ""
						}),
						/* @__PURE__ */ h("span", {
							className: "gp-plate-text",
							children: [/* @__PURE__ */ m("b", {
								className: "gp-plate-name",
								title: ze(t.rid),
								children: ze(t.rid)
							}), /* @__PURE__ */ m("small", {
								className: "gp-plate-faction",
								children: P(t.faction)
							})]
						}),
						/* @__PURE__ */ m("span", {
							className: "gp-score-update",
							children: /* @__PURE__ */ m(lr, {
								icon: "vp",
								value: t.vp
							})
						}, t.vp),
						t.passed && /* @__PURE__ */ m("span", {
							className: "gp-tag",
							children: a(A("passedTag"))
						}),
						Me === t.seat && /* @__PURE__ */ m("span", {
							className: "gp-tag is-charge",
							children: a(A("chargePhase"))
						})
					]
				}, t.rid))
			})
		]
	}), nn = (e, t, n, r, i, a) => /* @__PURE__ */ h("button", {
		type: "button",
		className: `gp-act${i ? " is-on" : ""}`,
		disabled: !r,
		"aria-pressed": i,
		onClick: a,
		children: [/* @__PURE__ */ m($, {
			name: t,
			size: 18
		}), /* @__PURE__ */ m("span", { children: n })]
	}, e), rn;
	rn = e.phase === "draft" ? /* @__PURE__ */ h("div", {
		className: "gp-acts",
		children: [/* @__PURE__ */ h("div", {
			className: "gp-act-msg",
			children: [/* @__PURE__ */ m($, {
				name: "pass",
				size: 14
			}), /* @__PURE__ */ m("span", { children: Qt() })]
		}), /* @__PURE__ */ h("div", {
			className: "gp-act-row",
			children: [
				M.draft.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "gp-draft-tile",
					onClick: () => U({
						type: "draft",
						booster: e
					}),
					children: [/* @__PURE__ */ m("b", { children: R(e) }), /* @__PURE__ */ m("small", { children: z(e) })]
				}, e)),
				nn("info", "info", a(A("actInfo")), !0, l === "info", () => ot("info")),
				nn("log", "log", a(A("actLog")), !0, l === "log", () => ot("log"))
			]
		})]
	}) : /* @__PURE__ */ h("div", {
		className: "gp-acts",
		children: [/* @__PURE__ */ h("div", {
			className: "gp-act-msg",
			children: [/* @__PURE__ */ m($, {
				name: Ne ? "power" : "info",
				size: 14
			}), /* @__PURE__ */ m("span", { children: Qt() })]
		}), /* @__PURE__ */ h("div", {
			className: "gp-act-row",
			children: [
				nn("build", "build", a(A("actBuild")), N && Yt, v === "build" || C?.kind === "power", () => Ct("build")),
				nn("upgrade", "upgrade", a(A("actUpgrade")), N && Xt, v === "upgrade", () => Ct("upgrade")),
				nn("research", "research", a(A("actResearch")), e.phase === "play" && !Ne, l === "research", () => ot("research")),
				nn("gaia", "gaiaformer", a(A("actGaia")), N && M.gaia.length > 0, v === "gaia" || C?.kind === "booster" && C.mode === "gaia", () => Ct("gaia")),
				nn("federation", "federation", a(A("actFederation")), N && M.federations.length > 0 && M.fedTokens.length > 0, v === "federation", () => Ct("federation")),
				e.lostFleet && nn("ships", "ship", a(A("actShips")), !0, l === "ships", () => ot("ships")),
				nn("actions", "actions", a(A("actActions")), e.phase === "play" && !Ne, l === "actions" || C?.kind === "station", () => ot("actions")),
				nn("pass", "pass", a(A("actPass")), N && M.pass, l === "pass", () => ot("pass")),
				nn("info", "info", a(A("actInfo")), !0, l === "info", () => ot("info")),
				nn("log", "log", a(A("actLog")), !0, l === "log", () => ot("log"))
			]
		})]
	});
	let Z = /* @__PURE__ */ m("button", {
		type: "button",
		className: "gp-btn",
		onClick: ct,
		children: a(A("actClose"))
	}), an = (e, t, n, r) => {
		let i = Ke[e];
		if (i) return /* @__PURE__ */ h("button", {
			type: "button",
			className: "gp-fed-token is-gold",
			"aria-pressed": t === e,
			onClick: () => n(e),
			children: [
				/* @__PURE__ */ m("span", {
					className: "gp-fed-face is-gold",
					children: /* @__PURE__ */ m($, {
						name: "gold",
						size: 21
					})
				}),
				/* @__PURE__ */ m("b", { children: Ze(e) }),
				i.vp > 0 && /* @__PURE__ */ m("span", {
					className: "gp-fed-rewards",
					children: /* @__PURE__ */ h("span", { children: [
						/* @__PURE__ */ m($, {
							name: "vp",
							size: 13
						}),
						i.vp,
						/* @__PURE__ */ h("span", {
							className: "sr-only",
							children: [" ", a(A("resVP"))]
						})
					] })
				}),
				/* @__PURE__ */ m("small", { children: a(A("lfAlliance")) })
			]
		}, e);
		let o = ye[e];
		if (!o) return null;
		let s = [
			{
				icon: "vp",
				amount: o.vp,
				label: "resVP"
			},
			{
				icon: "credits",
				amount: o.rewards.credits,
				label: "resCredits"
			},
			{
				icon: "ores",
				amount: o.rewards.ores,
				label: "resOres"
			},
			{
				icon: "knowledge",
				amount: o.rewards.knowledge,
				label: "resKnowledge"
			},
			{
				icon: "qic",
				amount: o.rewards.qic,
				label: "resQic"
			},
			{
				icon: "power",
				amount: o.rewards.tokens,
				label: "resPowerTokens"
			}
		];
		return /* @__PURE__ */ h("button", {
			type: "button",
			className: "gp-fed-token",
			"aria-pressed": t === e,
			onClick: () => n(e),
			children: [
				/* @__PURE__ */ m("span", {
					className: "gp-fed-face",
					children: /* @__PURE__ */ m($, {
						name: "federation",
						size: 21
					})
				}),
				/* @__PURE__ */ m("b", { children: B(e) }),
				/* @__PURE__ */ m("span", {
					className: "gp-fed-rewards",
					children: s.filter(({ amount: e }) => e).map(({ icon: e, amount: t, label: n }) => /* @__PURE__ */ h("span", { children: [
						/* @__PURE__ */ m($, {
							name: e,
							size: 13
						}),
						t,
						/* @__PURE__ */ h("span", {
							className: "sr-only",
							children: [" ", a(A(n))]
						})
					] }, e))
				}),
				r !== void 0 && /* @__PURE__ */ m("small", { children: a(A("techRemaining"), { n: r }) })
			]
		}, e);
	}, on = (() => {
		if (v === "federation" && bt) {
			let t = oe && M.fedTokens.includes(oe) ? oe : null, n = t ? Ke[t] : void 0, r = !n || n.kind === "points" || (n.kind === "tech" ? M.techs.some((e) => !e.advanced || jt.length > 0) : M.goldMines.some((e) => e.token === t)), i = (e) => ({
				type: "federation",
				token: t,
				hexes: [...bt.hexes],
				satellites: [...bt.satellites],
				goldPayQic: 0,
				...e
			});
			return /* @__PURE__ */ h("div", {
				className: "gp-fed-order",
				children: [
					/* @__PURE__ */ h("div", {
						className: "gp-fed-heading",
						children: [/* @__PURE__ */ m($, {
							name: n ? "gold" : "federation",
							size: 27
						}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: a(A("federationTitle")) }), /* @__PURE__ */ m("span", { children: a(A("federationBuildings"), { n: bt.hexes.length }) })] })]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-fed-metrics",
						children: [
							/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
								name: "power",
								size: 17
							}), a(A("federationPower"), { n: bt.power })] }),
							/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
								name: "satellite",
								size: 17
							}), a(A("federationSatellites"), { n: bt.satellites.length })] }),
							bt.satellites.length > 0 && /* @__PURE__ */ m("span", { children: a(A(j.faction === "ivits" ? "federationQicCost" : "federationPowerCost"), { n: bt.satellites.length }) })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "gp-fed-tokens",
						role: "group",
						"aria-label": a(A("federationToken")),
						children: M.fedTokens.map((n) => an(n, t, se, e.fedSupply[n]))
					}),
					n && n.kind !== "points" && /* @__PURE__ */ m("div", {
						className: `gp-note${r ? "" : " is-bad"}`,
						children: a(A(n.kind === "tech" ? "goldTechHint" : n.kind === "mineRange" ? "goldMineRangeHint" : "goldMine3Hint"))
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							disabled: !t || !N || !r,
							onClick: () => {
								if (t && r) {
									if (n?.kind === "tech") {
										lt({
											kind: "gold",
											token: t,
											hexes: [...bt.hexes],
											satellites: [...bt.satellites]
										});
										return;
									}
									if (n && n.kind !== "points") {
										ut({
											kind: "goldMine",
											token: t,
											hexes: [...bt.hexes],
											satellites: [...bt.satellites]
										});
										return;
									}
									U(i({}));
								}
							},
							children: a(A("federationConfirm"))
						}), Z]
					})
				]
			});
		}
		if (C) {
			if (C.kind === "lostPlanet") {
				let e = M.lostPlanet.find(({ hex: e }) => e === x && K.has(e)), { action: t } = C;
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: qe("lostplanet")
					}),
					/* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: e ? /* @__PURE__ */ h(p, { children: [t.type === "research" && /* @__PURE__ */ m("span", {
							className: "gp-costs",
							children: /* @__PURE__ */ h("span", {
								className: "gp-cost",
								children: [/* @__PURE__ */ m($, {
									name: "knowledge",
									size: 13
								}), 4]
							})
						}), wt(0, 0, e.payQic)] }) : Qt()
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [e && /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => U(t.type === "research" ? {
								...t,
								hex: e.hex,
								payQic: e.payQic
							} : t.type === "federation" ? {
								...t,
								goldLostHex: e.hex,
								goldLostPayQic: e.payQic
							} : {
								...t,
								lostHex: e.hex,
								lostPayQic: e.payQic
							}),
							children: a(A("actConfirm"))
						}), Z]
					})
				] });
			}
			if (C.kind === "goldMine") {
				let e = Ke[C.token], t = x ? M.goldMines.find((e) => e.token === C.token && e.hex === x) : void 0;
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: t ? H(t.hex) : Ze(C.token)
					}),
					/* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: a(A(e?.kind === "mineRange" ? "goldMineRangeHint" : "goldMine3Hint"))
					}),
					t && /* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: wt(0, 0, t.payQic)
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [t && /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => U({
								type: "federation",
								token: C.token,
								hexes: [...C.hexes],
								satellites: [...C.satellites],
								goldHex: t.hex,
								goldPayQic: t.payQic
							}),
							children: a(A("actConfirm"))
						}), Z]
					})
				] });
			}
			if (C.kind === "freeMine") {
				let e = x ? M.freeMines.find((e) => e.id === C.id && e.hex === x) : void 0;
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: I(C.id)
					}),
					e ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: H(e.hex)
					}), /* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: wt(0, 0, e.payQic)
					})] }) : /* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: Qt()
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [e && /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => U({
								type: "useTile",
								id: C.id,
								hex: e.hex,
								payQic: e.payQic
							}),
							children: a(A("actConfirm"))
						}), Z]
					})
				] });
			}
			if (C.kind === "giantsMine" || C.kind === "tinkerBuild") {
				let e = C.kind === "giantsMine" ? "giantsMine" : "tinkerAction", t = x ? M.faction.find((t) => t.kind === e && t.hex === x) : void 0;
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: a(A(e === "giantsMine" ? "factionGiantsMine" : "factionTinkerAction"))
					}),
					t ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: H(t.hex)
					}), /* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: wt(0, 0, t.payQic ?? 0)
					})] }) : /* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: Qt()
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [t && /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => U({
								type: "faction",
								kind: e,
								hex: t.hex,
								payQic: t.payQic ?? 0
							}),
							children: a(A("actConfirm"))
						}), Z]
					})
				] });
			}
			if (C.kind === "ring") {
				let e = x ? M.faction.find((e) => e.kind === "moweydRing" && e.hex === x) : void 0;
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: a(A("factionMoweydRing"))
					}),
					e ? /* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: H(e.hex)
					}) : /* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: Qt()
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [e && /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => U({
								type: "faction",
								kind: "moweydRing",
								hex: e.hex,
								payQic: 0
							}),
							children: a(A("actConfirm"))
						}), Z]
					})
				] });
			}
			if (!q) return /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("div", {
					className: "gp-card-title",
					children: C.kind === "station" ? a(A("factionSpaceStation")) : C.kind === "power" ? V(C.id) : R(C.id)
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-line is-dim",
					children: Qt()
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-row",
					children: Z
				})
			] });
			if (C.kind === "station") return kt ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("div", {
					className: "gp-card-title",
					children: a(A("factionSpaceStation"))
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-line",
					children: H(q.id)
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-line",
					children: wt(0, 0, kt.payQic ?? 0)
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-card-row",
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-btn is-main",
						onClick: () => U({
							type: "faction",
							kind: "spaceStation",
							hex: q.id,
							payQic: kt.payQic ?? 0
						}),
						children: a(A("factionSpaceStation"))
					}), Z]
				})
			] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
				className: "gp-card-title",
				children: H(q.id)
			}), /* @__PURE__ */ m("div", {
				className: "gp-card-row",
				children: Z
			})] });
			if (C.kind === "power") {
				if (!Dt) return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
					className: "gp-card-title",
					children: H(q.id)
				}), /* @__PURE__ */ m("div", {
					className: "gp-card-row",
					children: Z
				})] });
				let e = be.find((e) => e.id === C.id), t = j.credits >= (Dt.credits ?? 2) && j.ores >= (Dt.oreCost ?? 1);
				return /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "gp-card-title",
						children: V(C.id)
					}),
					/* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: H(q.id)
					}),
					/* @__PURE__ */ m("div", {
						className: "gp-card-line",
						children: wt(Dt.credits ?? 2, Dt.oreCost ?? 1, Dt.payQic ?? 0)
					}),
					e && /* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: a(A(e.desc))
					}),
					!t && /* @__PURE__ */ m("div", {
						className: "gp-warn",
						children: j.credits < (Dt.credits ?? 2) ? a(A("errCredits")) : a(A("errOres"))
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							disabled: !t,
							onClick: () => U({
								type: "power",
								id: C.id,
								hex: q.id,
								payQic: Dt.payQic ?? 0,
								parasite: Dt.parasite
							}),
							children: C.id === "p_terra2" ? a(A("powerTerra2")) : a(A("powerTerra1"))
						}), Z]
					})
				] });
			}
			if (!Ot) return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
				className: "gp-card-title",
				children: H(q.id)
			}), /* @__PURE__ */ m("div", {
				className: "gp-card-row",
				children: Z
			})] });
			let e = C.mode === "gaia", t = e || j.credits >= (Ot.credits ?? 2) && j.ores >= (Ot.oreCost ?? 1);
			return /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("div", {
					className: "gp-card-title",
					children: R(C.id)
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-line",
					children: H(q.id)
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-card-line",
					children: [e ? /* @__PURE__ */ h("span", {
						className: "gp-card-stat",
						children: [/* @__PURE__ */ m($, {
							name: "gaiaformer",
							size: 14
						}), a(A("gaiaPowerCost"), { n: ie(j.tracks[T.gaia]) })]
					}) : wt(Ot.credits ?? 2, Ot.oreCost ?? 1, Ot.qic ?? 0), !e && (Ot.qic ?? 0) > 0 && wt(0, 0, Ot.qic ?? 0)]
				}),
				!t && /* @__PURE__ */ m("div", {
					className: "gp-warn",
					children: a(A("errCredits"))
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-card-row",
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-btn is-main",
						disabled: !t,
						onClick: () => U({
							type: "booster",
							id: C.id,
							hex: q.id,
							mode: C.mode,
							payQic: Ot.qic ?? 0
						}),
						children: a(A(e ? "gaiaAction" : "buildAction"))
					}), Z]
				})
			] });
		}
		if (Y) {
			let e = _t(Y), t = [
				{
					icon: "credits",
					value: Y.credits,
					label: "resCredits"
				},
				{
					icon: "ores",
					value: Y.oreCost,
					label: "resOres"
				},
				{
					icon: "qic",
					value: Y.qic,
					label: "resQic"
				}
			].filter((e) => e.value > 0);
			return /* @__PURE__ */ h("div", {
				className: "gp-build-order",
				children: [
					/* @__PURE__ */ h("div", {
						className: "gp-build-object",
						children: [/* @__PURE__ */ m("div", {
							className: "gp-build-symbol",
							children: /* @__PURE__ */ m($, {
								name: "build",
								size: 28
							})
						}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("div", {
							className: "gp-card-title",
							children: H(Y.hex)
						}), /* @__PURE__ */ m("div", {
							className: "gp-card-line is-dim",
							children: tt("mine")
						})] })]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-build-price",
						children: [
							/* @__PURE__ */ m("span", { children: a(A("buildCostTitle")) }),
							t.length > 0 ? /* @__PURE__ */ m("div", {
								className: "gp-build-costs",
								children: t.map(({ icon: e, value: t, label: n }) => /* @__PURE__ */ h("span", { children: [
									/* @__PURE__ */ m($, {
										name: e,
										size: 15
									}),
									/* @__PURE__ */ m("b", { children: t }),
									a(A(n))
								] }, e))
							}) : /* @__PURE__ */ m("strong", { children: a(A("buildNoCost")) }),
							Y.steps > 0 && /* @__PURE__ */ m("small", { children: a(A("buildTerraformDetail"), {
								steps: Y.steps,
								ore: Y.stepOre
							}) })
						]
					}),
					Y.parasite && /* @__PURE__ */ m("div", {
						className: "gp-card-line is-dim",
						children: a(A("mapParasite"))
					}),
					!e && /* @__PURE__ */ m("div", {
						className: "gp-warn",
						children: j.credits < Y.credits ? a(A("errCredits")) : a(A("errOres"))
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-card-row",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							disabled: !e,
							onClick: () => U({
								type: "build",
								hex: Y.hex,
								payQic: Y.qic,
								parasite: Y.parasite ? !0 : void 0
							}),
							children: a(A("buildAction"))
						}), Z]
					})
				]
			});
		}
		if (v === "gaia" && J) return /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("div", {
				className: "gp-card-title",
				children: a(A("gaiaAction"))
			}),
			/* @__PURE__ */ m("div", {
				className: "gp-card-line",
				children: H(J.hex)
			}),
			/* @__PURE__ */ h("div", {
				className: "gp-card-line",
				children: [/* @__PURE__ */ h("span", {
					className: "gp-card-stat",
					children: [/* @__PURE__ */ m($, {
						name: "power",
						size: 14
					}), a(A("gaiaPowerCost"), { n: J.power })]
				}), J.qic > 0 && wt(0, 0, J.qic)]
			}),
			/* @__PURE__ */ h("div", {
				className: "gp-card-row",
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					className: "gp-btn is-main",
					onClick: () => U({
						type: "gaia",
						hex: J.hex,
						payQic: J.qic
					}),
					children: a(A("gaiaAction"))
				}), Z]
			})
		] });
		if (v === "upgrade" && Et.length > 0) {
			let e = Et.filter(vt);
			return /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("div", {
					className: "gp-card-title",
					children: [
						a(A("actUpgrade")),
						" · ",
						H(q.id)
					]
				}),
				e.length === 0 && /* @__PURE__ */ m("div", {
					className: "gp-warn",
					children: a(A("noTargets"))
				}),
				e.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "gp-card-option",
					onClick: () => {
						e.gainsTech ? lt({
							kind: "upgrade",
							hex: e.hex,
							to: e.to,
							side: e.side
						}) : U({
							type: "upgrade",
							hex: e.hex,
							to: e.to,
							side: e.side
						});
					},
					children: [/* @__PURE__ */ h("span", {
						className: "gp-card-option-main",
						children: [
							/* @__PURE__ */ m("b", { children: a(A("upgradeAction"), { building: tt(e.to) }) }),
							e.side && /* @__PURE__ */ m("small", { children: a(e.side === "left" ? A("sideLeft") : A("sideRight")) }),
							e.gainsTech && /* @__PURE__ */ m("small", { children: a(A("upgradeTechHint")) })
						]
					}), wt(e.credits, e.ores, 0)]
				}, `${e.to}-${e.side ?? ""}`)),
				/* @__PURE__ */ m("div", {
					className: "gp-card-row",
					children: Z
				})
			] });
		}
		if (q) {
			let t = q.structure?.seat, n = q.federation == null ? void 0 : e.federations.find((e) => e.id === q.federation);
			return /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("div", {
					className: "gp-card-title",
					children: a(A("mapCardTitle"))
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-line",
					children: H(q.id)
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-card-line is-dim",
					children: [
						q.outer ? a(A("mapOuter")) : "",
						q.structure ? ` · ${tt(q.structure.type)}${t == null ? "" : ` · ${ze(Ue(t))}`}` : "",
						q.lostPlanet == null ? "" : ` · ${qe("lostplanet")}`,
						q.station == null ? "" : ` · ${a(A("mapStation"))}`,
						q.gaiaformer == null ? "" : ` · ${a(A("mapGaiaformer"))}`,
						q.parasite == null ? "" : ` · ${a(A("mapParasite"))}`,
						q.artifact ? ` · ${a(A("mapArtifact"))}` : "",
						n ? ` · ${a(A("mapFederation"))}` : ""
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-card-row",
					children: Z
				})
			] });
		}
		return null;
	})(), sn = (n) => {
		let r = y[j.faction], i = [
			{
				icon: "vp",
				value: j.vp,
				label: a(A("resVP"))
			},
			{
				icon: "credits",
				value: j.credits,
				label: a(A("resCredits"))
			},
			{
				icon: "ores",
				value: j.ores,
				label: a(A("resOres"))
			},
			{
				icon: "knowledge",
				value: j.knowledge,
				label: a(A("resKnowledge"))
			},
			{
				icon: "qic",
				value: j.qic,
				label: a(A("resQic"))
			},
			{
				icon: "power",
				value: j.power[2],
				label: a(A("resPowerIII"))
			},
			{
				icon: "power",
				value: j.power[1],
				label: a(A("resPowerII"))
			},
			{
				icon: "power",
				value: j.power[0],
				label: a(A("resPowerI"))
			},
			{
				icon: "power",
				value: M.passive.power ?? 0,
				label: a(A("resPowerTokens"))
			},
			{
				icon: "gaiaPower",
				value: j.gaiaPower,
				label: a(A("resGaiaPower"))
			},
			{
				icon: "gaiaformer",
				value: j.gaiaformers,
				label: a(A("resGaiaformers"))
			},
			{
				icon: "types",
				value: j.knownTypes.length,
				label: a(A("resTypes"))
			},
			{
				icon: "federation",
				value: j.fedTokens.length,
				label: a(A("resFederation"))
			}
		];
		return j.brainstone && i.splice(9, 0, {
			icon: "brainstone",
			value: j.brainstone,
			label: a(A("resBrain"))
		}), e.lostFleet && i.push({
			icon: "shuttle",
			value: j.shuttlesAvail,
			label: a(A("resShuttles"))
		}), /* @__PURE__ */ h("div", {
			className: "gp-info",
			children: [
				/* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [
						/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("infoFaction"))
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-row-line",
							children: [/* @__PURE__ */ m("b", { children: r ? P(j.faction) : j.faction }), r && /* @__PURE__ */ m("small", {
								className: "gp-dim",
								children: qe(r.planet)
							})]
						}),
						r && /* @__PURE__ */ m("div", {
							className: "gp-note",
							children: a(A(r.ability))
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("infoResources"))
					}), /* @__PURE__ */ m("div", {
						className: "gp-resgrid",
						children: i.map((e) => /* @__PURE__ */ m(lr, {
							icon: e.icon,
							value: e.value,
							title: e.label
						}, e.label))
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("infoResearch"))
					}), w.map((e) => /* @__PURE__ */ h("div", {
						className: "gp-track",
						children: [
							/* @__PURE__ */ m("span", {
								className: "gp-track-dot",
								style: { background: e.color }
							}),
							/* @__PURE__ */ m("span", {
								className: "gp-track-name",
								children: a(A(e.name))
							}),
							/* @__PURE__ */ m("span", {
								className: "gp-pips",
								children: [
									1,
									2,
									3,
									4,
									5
								].map((t) => /* @__PURE__ */ m("i", { className: j.tracks[T[e.id]] >= t ? "is-on" : "" }, t))
							})
						]
					}, e.id))]
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("infoIncome"))
					}), /* @__PURE__ */ h("div", {
						className: "gp-resgrid",
						children: [
							/* @__PURE__ */ m(lr, {
								icon: "credits",
								value: M.passive.credits ?? 0,
								title: a(A("resCredits"))
							}),
							/* @__PURE__ */ m(lr, {
								icon: "ores",
								value: M.passive.ores ?? 0,
								title: a(A("resOres"))
							}),
							/* @__PURE__ */ m(lr, {
								icon: "knowledge",
								value: M.passive.knowledge ?? 0,
								title: a(A("resKnowledge"))
							}),
							/* @__PURE__ */ m(lr, {
								icon: "qic",
								value: M.passive.qic ?? 0,
								title: a(A("resQic"))
							}),
							/* @__PURE__ */ m(lr, {
								icon: "power",
								value: M.passive.power ?? 0,
								title: a(A("resPower"))
							}),
							/* @__PURE__ */ m(lr, {
								icon: "power",
								value: M.passive.tokens ?? 0,
								title: a(A("resPowerTokens"))
							})
						]
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [
						/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("infoBuildings"))
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: tt("mine") }), /* @__PURE__ */ m("b", { children: j.buildings.mines })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: tt("ts") }), /* @__PURE__ */ m("b", { children: j.buildings.ts })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: tt("rl") }), /* @__PURE__ */ m("b", { children: j.buildings.rl })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: tt("pi") }), /* @__PURE__ */ m("b", { children: j.buildings.pi })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: tt("ac") }), /* @__PURE__ */ m("b", { children: j.buildings.ac })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: a(A("mapSatellite")) }), /* @__PURE__ */ m("b", { children: j.buildings.satellites })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: a(A("mapStation")) }), /* @__PURE__ */ m("b", { children: j.buildings.stations })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-kv",
							children: [/* @__PURE__ */ m("span", { children: a(A("mapSector"), { id: "#" }) }), /* @__PURE__ */ m("b", { children: j.buildings.sectors })]
						})
					]
				}),
				n && /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoTechs"))
							}),
							j.techs.length === 0 && j.advTechs.length === 0 && /* @__PURE__ */ m("div", {
								className: "gp-dim",
								children: a(A("infoNone"))
							}),
							/* @__PURE__ */ h("div", {
								className: "gp-chiprow",
								children: [j.techs.map((e) => /* @__PURE__ */ m("span", {
									className: `gp-chip is-static${j.advTechs.some((t) => t.covers === e) ? " is-covered" : ""}`,
									children: I(e)
								}, e)), j.advTechs.map((e) => /* @__PURE__ */ m("span", {
									className: "gp-chip is-static is-adv",
									children: I(e.id)
								}, e.id))]
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoFedTokens"))
							}),
							j.fedTokens.length === 0 && /* @__PURE__ */ m("div", {
								className: "gp-dim",
								children: a(A("infoNone"))
							}),
							/* @__PURE__ */ m("div", {
								className: "gp-chiprow",
								children: j.fedTokens.map((e, t) => /* @__PURE__ */ m("span", {
									className: `gp-chip is-static${e.green ? " is-green" : ""}`,
									children: B(e.type)
								}, `${e.type}-${t}`))
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoBooster"))
							}),
							/* @__PURE__ */ m("div", {
								className: "gp-row-line",
								children: /* @__PURE__ */ m("b", { children: j.booster ? R(j.booster) : a(A("infoNone")) })
							}),
							Jt && /* @__PURE__ */ m("div", {
								className: "gp-note",
								children: z(Jt.id)
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoUsedActions"))
							}),
							/* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoUsedPower")) }), /* @__PURE__ */ m("b", { children: e.usedPower.filter((e) => e.startsWith(`${t}:`)).length })]
							}),
							/* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoUsedQic")) }), /* @__PURE__ */ m("b", { children: e.usedQic.filter((e) => e.startsWith(`${t}:`)).length })]
							}),
							j.usedTiles.length > 0 && /* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoUsedTiles")) }), /* @__PURE__ */ m("b", { children: j.usedTiles.map(I).join(" · ") })]
							}),
							j.usedAbilities.length > 0 && /* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoUsedActions")) }), /* @__PURE__ */ m("b", { children: j.usedAbilities.map($t).join(" · ") })]
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("infoFedSupply"))
						}), /* @__PURE__ */ m("div", {
							className: "gp-chiprow",
							children: Object.entries(e.fedSupply).map(([e, t]) => /* @__PURE__ */ h("span", {
								className: "gp-chip is-static",
								children: [
									B(e),
									" ",
									t
								]
							}, e))
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoArtifacts"))
							}),
							/* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("mapArtifact")) }), /* @__PURE__ */ m("b", { children: j.artifacts.length })]
							}),
							j.artifacts.length > 0 && /* @__PURE__ */ m("div", {
								className: "gp-chiprow",
								children: j.artifacts.map((e, t) => /* @__PURE__ */ h("span", {
									className: "gp-chip is-static",
									children: [/* @__PURE__ */ m($, {
										name: "artifact",
										size: 12
									}), Xe(e)]
								}, `${e}-${t}`))
							})
						]
					}),
					(j.lfTerra.length > 0 || j.powerRings.length > 0 || j.tinkerTile) && /* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [
							/* @__PURE__ */ m("div", {
								className: "gp-sec-label",
								children: a(A("infoLostFleet"))
							}),
							j.lfTerra.length > 0 && /* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoLfTerra")) }), /* @__PURE__ */ m("b", { children: j.lfTerra.map((e) => qe(e)).join(" · ") })]
							}),
							j.powerRings.length > 0 && /* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoPowerRings")) }), /* @__PURE__ */ m("b", { children: j.powerRings.length })]
							}),
							j.tinkerTile && /* @__PURE__ */ h("div", {
								className: "gp-kv",
								children: [/* @__PURE__ */ m("span", { children: a(A("infoTinkerTile")) }), /* @__PURE__ */ m("b", { children: Qe(j.tinkerTile) })]
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("infoRoundTiles"))
						}), /* @__PURE__ */ m("div", {
							className: "gp-chiprow",
							children: e.roundTiles.map((t, n) => /* @__PURE__ */ m("span", {
								className: `gp-chip is-static${n < e.round - 1 ? " is-covered" : ""}`,
								children: a(kr[t] ?? A("roundScoring"))
							}, `${t}-${n}`))
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "gp-sec",
						children: [/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("infoFinalTiles"))
						}), /* @__PURE__ */ m("div", {
							className: "gp-chiprow",
							children: e.finalTiles.map((e) => /* @__PURE__ */ m("span", {
								className: "gp-chip is-static",
								children: a(kr[e] ?? A("finalScoring"))
							}, e))
						})]
					})
				] })
			]
		});
	}, cn = (t) => {
		let n = t.rid === "$engine" || t.rid === "" ? "" : ze(t.rid);
		switch (t.kind) {
			case "setup": return {
				who: n,
				text: a(A("logSetup"), { faction: P(t.value) })
			};
			case "charge": return {
				who: n,
				text: a(A("logCharge"))
			};
			case "draft": return {
				who: n,
				text: `${a(A("logDraft"))} · ${R(t.value)}`
			};
			case "parasite": return {
				who: n,
				text: `${a(A("logParasite"))} · ${H(t.value)}`
			};
			case "build": return {
				who: n,
				text: `${a(A("logBuild"))} · ${H(t.value)}`
			};
			case "gaia": return {
				who: n,
				text: `${a(A("logGaia"))} · ${H(t.value)}`
			};
			case "upgrade": return {
				who: n,
				text: `${a(A("logUpgrade"))} · ${H(t.value)}`
			};
			case "tech": return {
				who: n,
				text: a(A("logTech"), { name: I(t.value) })
			};
			case "research": return {
				who: n,
				text: a(A("logResearch"), {
					track: F(t.value),
					n: t.n ?? 0
				})
			};
			case "lostPlanet": return {
				who: n,
				text: `${a(A("logLostPlanet"))} · ${H(t.value)}`
			};
			case "federation": return {
				who: n,
				text: a(A("logFederation"))
			};
			case "fedToken": return {
				who: n,
				text: a(A("logFedToken"), { name: B(t.value) })
			};
			case "powerAction": return {
				who: n,
				text: a(A("logPower"), { name: V(t.value) })
			};
			case "qicAction": return {
				who: n,
				text: a(A("logQic"), { name: Je(t.value) })
			};
			case "freeAction": return {
				who: n,
				text: a(A("logFree"), { name: et(t.value) })
			};
			case "useTile": return {
				who: n,
				text: a(A("logUseTile"), { name: I(t.value) })
			};
			case "explore": return {
				who: n,
				text: a(A("logExplore"), { ship: Ye(t.value) })
			};
			case "artifact": return {
				who: n,
				text: a(A("logArtifact"), { name: Xe(t.value) })
			};
			case "shipAction": return {
				who: n,
				text: a(A("logShipAction"), { name: $e(t.value) })
			};
			case "academy": return {
				who: n,
				text: a(A("logAcademy"))
			};
			case "faction": return {
				who: n,
				text: a(A("logFaction"))
			};
			case "tinkerPick": return {
				who: n,
				text: Qe(t.value)
			};
			case "pass": return {
				who: n,
				text: a(A("logPass"))
			};
			case "round": return {
				who: n,
				text: a(A("logRound"), { n: t.n ?? e.round })
			};
			case "gameEnd": return {
				who: n,
				text: a(A("logGameEnd"))
			};
			default: return {
				who: n,
				text: t.kind
			};
		}
	}, ln = () => {
		let t = e.log.slice(-60).reverse();
		return t.length === 0 ? /* @__PURE__ */ m("div", {
			className: "gp-dim",
			children: a(A("logEmpty"))
		}) : /* @__PURE__ */ m("div", {
			className: "gp-log",
			children: t.map((e, t) => {
				let { who: n, text: r } = cn(e);
				return /* @__PURE__ */ h("div", {
					className: "gp-log-row",
					children: [n && /* @__PURE__ */ m("b", { children: n }), /* @__PURE__ */ m("span", { children: r })]
				}, `${t}-${e.kind}-${e.value}`);
			})
		});
	}, un = (t, n) => {
		let r = (e, t) => a(A(e), t), i = [];
		return n === 3 && i.push(r("researchChargePower", { n: 3 })), t === "terra" ? (i.push(r("researchOreRate", { n: re(n) })), (n === 1 || n === 4) && i.push(r("researchGainOre", { n: 2 })), n === 5 && e.terraformingToken && i.push(r("researchGainFederation", { name: B(e.terraformingToken) }))) : t === "nav" ? (i.push(r("researchRange", { n: ae(n) })), (n === 1 || n === 3) && i.push(r("researchGainQic", { n: 1 })), n === 5 && i.push(r("hintResearchNav"))) : t === "ai" && n > 0 ? i.push(r("researchGainQic", { n: n === 5 ? 4 : n >= 3 ? 2 : 1 })) : t === "gaia" && n > 0 ? (i.push(r("gaiaPowerCost", { n: ie(n) })), (n === 1 || n === 3 || n === 4) && i.push(r("researchGainFormer")), n === 2 && i.push(r("researchGainTokens", { n: 3 })), n === 5 && i.push(r("researchGaiaScore"))) : t === "eco" && n > 0 ? n < 5 ? i.push(r("researchEconomyIncome", {
			credits: [
				0,
				2,
				2,
				3,
				4
			][n],
			ores: [
				0,
				0,
				1,
				1,
				2
			][n],
			power: n
		})) : i.push(r("researchEconomyTop")) : t === "sci" && n > 0 && i.push(n === 5 ? r("researchScienceTop") : r("researchScienceIncome", { n })), i;
	}, dn = (e, t, n) => {
		let r = O[e]?.effect;
		return /* @__PURE__ */ h("button", {
			type: "button",
			className: "gp-research-tile",
			"data-advanced": t,
			"aria-pressed": Ae != null && "tile" in Ae && Ae.tile === e,
			onClick: () => je({
				tile: e,
				remaining: n
			}),
			children: [
				/* @__PURE__ */ m($, {
					name: r ? Nr[r.kind] : "tech",
					size: 15
				}),
				/* @__PURE__ */ m("span", { children: I(e) }),
				n !== void 0 && /* @__PURE__ */ m("b", { children: n })
			]
		}, e);
	}, fn = () => /* @__PURE__ */ h("div", {
		className: "gp-sheet gp-research-board",
		children: [
			/* @__PURE__ */ h("div", {
				className: "gp-research-key",
				children: [
					/* @__PURE__ */ m($, {
						name: "knowledge",
						size: 17
					}),
					/* @__PURE__ */ m("span", { children: a(A("researchHint"), { n: 4 }) }),
					/* @__PURE__ */ m("strong", { children: a(A("boardResource"), {
						name: a(A("resKnowledge")),
						n: j.knowledge
					}) })
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "gp-research-lanes",
				children: w.map(({ id: t }) => {
					let n = T[t], r = j.tracks[n] ?? 0, i = e.advancedTiles.find((e) => e.track === t), o = e.techPiles.find((e) => e.track === t), s = jr[t];
					return /* @__PURE__ */ h("section", {
						className: "gp-research-lane",
						style: { "--gp-rail": s.color },
						children: [
							/* @__PURE__ */ h("h3", { children: [/* @__PURE__ */ m($, {
								name: s.icon,
								size: 22
							}), F(t)] }),
							/* @__PURE__ */ m("div", {
								className: "gp-research-slot gp-research-advanced",
								children: i ? dn(i.id, !0) : /* @__PURE__ */ m("span", { children: a(A("techSlotEmpty")) })
							}),
							/* @__PURE__ */ m("div", {
								className: "gp-level-grid",
								children: [
									0,
									1,
									2,
									3,
									4,
									5
								].map((i) => {
									let o = e.players.filter((e) => e.tracks[n] === i), s = N && i === r + 1 && M.research.includes(t), c = Ae != null && "track" in Ae && Ae.track === t && Ae.level === i;
									return /* @__PURE__ */ h("button", {
										type: "button",
										className: "gp-level",
										"data-current": i === r,
										"data-next": s,
										"aria-pressed": c,
										"aria-label": `${F(t)} · ${a(A("researchLevel"), { n: i })}${o.length ? ` · ${o.map((e) => ze(e.rid)).join(", ")}` : ""}`,
										onClick: () => je({
											track: t,
											level: i
										}),
										children: [
											/* @__PURE__ */ m("b", { children: i }),
											/* @__PURE__ */ m("span", {
												className: "gp-level-players",
												"aria-hidden": !0,
												children: o.map((e) => /* @__PURE__ */ m("img", {
													src: Ve(e.rid),
													alt: "",
													title: ze(e.rid),
													style: { "--gp-seat": Le(e.rid).hex }
												}, e.rid))
											}),
											s && /* @__PURE__ */ m("svg", {
												className: "gp-level-outline",
												viewBox: "0 0 100 38",
												preserveAspectRatio: "none",
												"aria-hidden": !0,
												children: /* @__PURE__ */ m("rect", {
													className: "gp-target-path",
													x: "2",
													y: "2",
													width: "96",
													height: "34",
													rx: "4",
													vectorEffect: "non-scaling-stroke"
												})
											})
										]
									}, i);
								})
							}),
							/* @__PURE__ */ m("div", {
								className: "gp-research-slot gp-research-standard",
								children: o ? dn(o.id, !1, o.remaining) : /* @__PURE__ */ m("span", { children: a(A("techSlotEmpty")) })
							})
						]
					}, t);
				})
			}),
			/* @__PURE__ */ h("section", {
				className: "gp-open-tech",
				children: [/* @__PURE__ */ m("h3", { children: a(A("techIndependent")) }), /* @__PURE__ */ m("div", { children: e.techPiles.filter((e) => e.track == null).map((e) => dn(e.id, !1, e.remaining)) })]
			}),
			e.lostFleet && /* @__PURE__ */ h("section", {
				className: "gp-open-tech",
				children: [
					/* @__PURE__ */ m("h3", { children: a(A("techFleetAdvanced")) }),
					/* @__PURE__ */ m("p", { children: a(A(e.players.length >= 3 ? "techFleetRequirementShips" : "techFleetRequirementPoints")) }),
					/* @__PURE__ */ m("div", { children: e.advancedTiles.filter((e) => e.track == null).map((e) => dn(e.id, !0)) })
				]
			})
		]
	}), pn = () => {
		if (!Ae) return null;
		if ("tile" in Ae) {
			let { tile: e, remaining: t } = Ae, n = N && M.qic.includes("q_tech") ? M.techs.find((t) => t.id === e) : void 0;
			return /* @__PURE__ */ h("div", {
				className: "gp-research-detail",
				children: [
					/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: I(e) }), t !== void 0 && /* @__PURE__ */ m("small", { children: a(A("techRemaining"), { n: t }) })] }),
					/* @__PURE__ */ m("p", { children: L(e) }),
					n && /* @__PURE__ */ h("button", {
						type: "button",
						className: "gp-btn is-main",
						onClick: () => {
							lt({ kind: "qic" }), ue(e), n.advanced && pe(jt[0] ?? null);
						},
						children: [/* @__PURE__ */ m($, {
							name: "qic",
							size: 16
						}), a(A("techAcquireQic"), { n: xe[0].cost })]
					})
				]
			});
		}
		let { track: n, level: r } = Ae, i = T[n], o = j.tracks[i] ?? 0, s = N && r === o + 1 && M.research.includes(n), c = e.players.filter((e) => e.tracks[i] === r), l = un(n, r), u = j.knowledge < 4 ? "errKnowledge" : r === 5 && e.players.some((e) => e.seat !== t && e.tracks[i] === 5) ? "errTrackFull" : r === 5 && !j.fedTokens.some((e) => e.green) ? "errNoGreen" : "researchBlocked";
		return /* @__PURE__ */ h("div", {
			className: "gp-research-detail",
			style: { "--gp-rail": jr[n].color },
			children: [
				/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("strong", { children: [
					F(n),
					" · ",
					a(A("researchLevel"), { n: r })
				] }), c.length > 0 && /* @__PURE__ */ m("small", { children: c.map((e) => ze(e.rid)).join(" · ") })] }),
				l.length > 0 && /* @__PURE__ */ m("ul", { children: l.map((e) => /* @__PURE__ */ m("li", { children: e }, e)) }),
				s ? /* @__PURE__ */ h("button", {
					type: "button",
					className: "gp-btn is-main",
					onClick: () => {
						let e = {
							type: "research",
							track: n,
							payQic: 0
						};
						n === "nav" && r === 5 ? ut({
							kind: "lostPlanet",
							action: e,
							availableQic: j.qic
						}) : U(e, "research");
					},
					children: [/* @__PURE__ */ m($, {
						name: "knowledge",
						size: 16
					}), a(A("researchPayAdvance"), { n: 4 })]
				}) : N && r === o + 1 && /* @__PURE__ */ m("p", {
					className: "gp-dim",
					children: a(A(u))
				})
			]
		});
	}, mn = () => {
		if (!X || !D || X.advanced && !de) return;
		let e = X.id, t = X.advanced || void 0, n = X.advanced ? de ?? void 0 : void 0, r = X.advanced || X.track == null ? me ?? void 0 : void 0, i = D.kind === "ship" ? {
			type: "shipAction",
			ship: D.ship,
			action: D.action,
			hex: D.hex,
			payQic: 0,
			tech: e,
			advanced: t,
			cover: n,
			track: r
		} : D.kind === "gold" ? {
			type: "federation",
			token: D.token,
			hexes: [...D.hexes],
			satellites: [...D.satellites],
			goldPayQic: 0,
			goldTech: e,
			goldAdvanced: t,
			goldCover: n,
			goldTrack: r
		} : D.kind === "upgrade" ? {
			type: "upgrade",
			hex: D.hex,
			to: D.to,
			side: D.side,
			tech: e,
			advanced: t,
			cover: n,
			track: r
		} : D.kind === "qic" ? {
			type: "qic",
			id: "q_tech",
			tech: e,
			advanced: t,
			cover: n,
			track: r
		} : {
			type: "faction",
			kind: "itarsTech",
			payQic: 0,
			tech: e,
			advanced: t,
			cover: n,
			track: r
		};
		(t ? r : X.track ?? r) === "nav" && Rt ? ut({
			kind: "lostPlanet",
			action: i,
			availableQic: Lt
		}) : U(i);
	}, hn = () => {
		if (Mt.length === 0) return /* @__PURE__ */ m("div", {
			className: "gp-sheet",
			children: /* @__PURE__ */ m("div", {
				className: "gp-dim",
				children: a(A("techEmpty"))
			})
		});
		let e = ({ id: e, advanced: t, track: n }) => /* @__PURE__ */ h("button", {
			type: "button",
			className: "gp-tech-choice",
			"data-advanced": t,
			"aria-pressed": le === e,
			onClick: () => {
				ue(e), he(null), pe(t ? jt[0] ?? null : null);
			},
			children: [/* @__PURE__ */ m("span", {
				className: "gp-tech-symbol",
				children: /* @__PURE__ */ m($, {
					name: Nr[O[e]?.effect.kind] ?? "tech",
					size: 24
				})
			}), /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [
					/* @__PURE__ */ m("b", { children: I(e) }),
					/* @__PURE__ */ m("small", { children: L(e) }),
					/* @__PURE__ */ m("span", { children: n ? F(n) : a(A(t ? "techFleetAdvanced" : "techIndependent")) })
				]
			})]
		}, e);
		return /* @__PURE__ */ h("div", {
			className: "gp-sheet",
			children: [
				Nt.length > 0 && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("techStandard"))
					}), /* @__PURE__ */ m("div", {
						className: "gp-tech-choices",
						children: Nt.map(e)
					})]
				}),
				Pt.length > 0 && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [
						/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("techAdvanced"))
						}),
						/* @__PURE__ */ m("div", {
							className: "gp-note",
							children: a(A("techAdvancedRequires"))
						}),
						/* @__PURE__ */ m("div", {
							className: "gp-tech-choices",
							children: Pt.map(e)
						})
					]
				}),
				X?.advanced && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("techCoverLabel"))
					}), /* @__PURE__ */ m("div", {
						className: "gp-chiprow",
						children: jt.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: `gp-chip${de === e ? " is-on" : ""}`,
							onClick: () => pe(e),
							children: I(e)
						}, e))
					})]
				}),
				X && (X.advanced || X.track == null) && zt.length > 0 && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("techTrackPick"))
					}), /* @__PURE__ */ m("div", {
						className: "gp-chiprow",
						children: zt.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: `gp-chip${me === e ? " is-on" : ""}`,
							"aria-pressed": me === e,
							onClick: () => he(me === e ? null : e),
							children: F(e)
						}, e))
					})]
				}),
				X && !X.advanced && X.track != null && /* @__PURE__ */ m("div", {
					className: "gp-note",
					children: F(X.track)
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					className: "gp-btn is-main",
					disabled: !X || X.advanced && !de,
					onClick: mn,
					children: a(A("actConfirm"))
				})
			]
		});
	}, gn = () => {
		let n = !e.players.some((e) => e.seat !== t && e.passed);
		return /* @__PURE__ */ h("div", {
			className: "gp-sheet",
			children: [
				/* @__PURE__ */ m("div", {
					className: "gp-note",
					children: a(A("passHint"))
				}),
				M.passPoints > 0 && /* @__PURE__ */ m("div", {
					className: "gp-note",
					children: a(A("passPoints"), { n: M.passPoints })
				}),
				n && /* @__PURE__ */ m("div", {
					className: "gp-note is-good",
					children: a(A("passFirst"))
				}),
				e.round < 6 ? /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [
						/* @__PURE__ */ m("div", {
							className: "gp-sec-label",
							children: a(A("passChooseBooster"))
						}),
						/* @__PURE__ */ m("div", {
							className: "gp-note",
							children: a(A("passNeedBooster"))
						}),
						M.passBoosters.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							className: `gp-row-act${ge === e ? " is-on" : ""}`,
							onClick: () => _e(e),
							children: /* @__PURE__ */ h("span", {
								className: "gp-row-main",
								children: [/* @__PURE__ */ m("b", { children: R(e) }), /* @__PURE__ */ m("small", { children: z(e) })]
							})
						}, e))
					]
				}) : /* @__PURE__ */ m("div", {
					className: "gp-note",
					children: a(A("passLastRound"))
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					className: "gp-btn is-main",
					disabled: e.round < 6 && !ge,
					onClick: () => U({
						type: "pass",
						booster: e.round < 6 ? ge ?? void 0 : void 0
					}),
					children: a(A("passConfirm"))
				})
			]
		});
	}, _n = () => {
		let e = Bt.filter((e) => ye[e]);
		return /* @__PURE__ */ h("div", {
			className: "gp-sheet",
			children: [
				/* @__PURE__ */ m("div", {
					className: "gp-note",
					children: a(A("qicRescoreDesc"))
				}),
				/* @__PURE__ */ m("div", {
					className: "gp-fed-tokens",
					children: e.map((e) => an(e, ve, we))
				}),
				e.length === 0 && /* @__PURE__ */ m("div", {
					className: "gp-dim",
					children: a(A("noTargets"))
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					className: "gp-btn is-main",
					disabled: !ve,
					onClick: () => ve && U({
						type: "qic",
						id: "q_rescore",
						token: ve
					}),
					children: a(A("actConfirm"))
				})
			]
		});
	}, vn = () => {
		let t = [], n = (t) => {
			let n = t === "power" ? be : xe, r = t === "power" ? e.usedPower : e.usedQic;
			return /* @__PURE__ */ h("section", {
				className: "gp-action-bank",
				"data-resource": t,
				children: [/* @__PURE__ */ h("h3", { children: [
					/* @__PURE__ */ m($, {
						name: t,
						size: 19
					}),
					a(A(t === "power" ? "actionsPowerBoard" : "actionsQicBoard")),
					/* @__PURE__ */ m("strong", { children: a(A("boardResource"), {
						name: a(A(t === "power" ? "resPower" : "resQic")),
						n: t === "power" ? ht : j.qic
					}) })
				] }), /* @__PURE__ */ m("div", {
					className: "gp-action-bank-grid",
					children: n.map((e) => {
						let { id: n, cost: i } = e, o = n === "p_terra1" || n === "p_terra2", s = tn(r, n), c = t === "power" ? gt(i) : j.qic >= i, l = t === "power" ? M.power.some((e) => e.id === n && (!o || !!e.hex && j.credits >= (e.credits ?? 2) && j.ores >= (e.oreCost ?? 1))) : M.qic.includes(n), u = N && l && !s, d = s ? "actionsSpent" : c ? N && !l ? "noTargets" : null : t === "power" ? "actionsLowPower" : "actionsLowQic", f = Mr[n], p = n === "q_types" ? 3 + j.knownTypes.length : f.amount;
						return /* @__PURE__ */ h("button", {
							type: "button",
							className: "gp-action-space",
							"data-spent": s,
							disabled: !u,
							onClick: () => {
								o ? ut({
									kind: "power",
									id: n
								}) : t === "power" ? U({
									type: "power",
									id: n,
									payQic: 0
								}, "actions") : n === "q_tech" ? lt({ kind: "qic" }) : n === "q_rescore" ? dt() : U({
									type: "qic",
									id: n
								}, "actions");
							},
							children: [
								/* @__PURE__ */ h("span", {
									className: "gp-action-cost",
									children: [
										/* @__PURE__ */ m($, {
											name: t,
											size: 14
										}),
										i,
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: [" ", a(A(t === "power" ? "resPower" : "resQic"))]
										})
									]
								}),
								/* @__PURE__ */ h("span", {
									className: "gp-action-emblem",
									children: [/* @__PURE__ */ m($, {
										name: f.icon,
										size: 27
									}), p != null && /* @__PURE__ */ m("b", { children: p })]
								}),
								/* @__PURE__ */ m("span", {
									className: "gp-action-name",
									children: a(A(e.name))
								}),
								d && /* @__PURE__ */ h("small", { children: [/* @__PURE__ */ m($, {
									name: s ? "used" : "lock",
									size: 12
								}), a(A(d))] })
							]
						}, n);
					})
				})]
			});
		};
		for (let e of M.useTiles) t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => U({
				type: "useTile",
				id: e,
				payQic: 0
			}),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: I(e) }), /* @__PURE__ */ m("small", { children: L(e) })]
			})
		}, `tile-${e}`));
		let r = /* @__PURE__ */ new Map();
		for (let e of M.freeMines) {
			let t = r.get(e.id) ?? [];
			t.push(e), r.set(e.id, t);
		}
		for (let [e] of r) t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => ut({
				kind: "freeMine",
				id: e
			}),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: I(e) }), /* @__PURE__ */ m("small", { children: L(e) })]
			})
		}, `fmine-${e}`));
		if (Jt?.action && M.boosters.length > 0) {
			let e = [...new Set(M.boosters.map((e) => e.mode ?? "build"))];
			for (let n of e) t.push(/* @__PURE__ */ m("button", {
				type: "button",
				className: "gp-row-act",
				onClick: () => ut({
					kind: "booster",
					id: Jt.id,
					mode: n
				}),
				children: /* @__PURE__ */ h("span", {
					className: "gp-row-main",
					children: [/* @__PURE__ */ m("b", { children: R(Jt.id) }), /* @__PURE__ */ m("small", { children: a(A(n === "gaia" ? "gaiaAction" : "buildAction")) })]
				})
			}, `booster-${n}`));
		}
		for (let e of M.faction) if (e.kind !== "spaceStation" && e.kind !== "swapPI" && e.kind !== "baltaqGaiaformer" && e.kind !== "nevlasKnowledge" && e.kind !== "giantsMine" && e.kind !== "moweydRing" && e.kind !== "tinkerAction" && (e.kind === "downgradeRL" || e.kind === "advanceLowest")) {
			let n = e.kind;
			t.push(/* @__PURE__ */ m("button", {
				type: "button",
				className: "gp-row-act",
				onClick: () => {
					let t = Ir(e.track ?? "") ?? void 0, r = {
						type: "faction",
						kind: n,
						hex: e.hex,
						track: t,
						payQic: 0
					};
					t === "nav" && j.tracks[T.nav] === 4 ? ut({
						kind: "lostPlanet",
						action: r,
						availableQic: j.qic
					}) : U(r);
				},
				children: /* @__PURE__ */ h("span", {
					className: "gp-row-main",
					children: [/* @__PURE__ */ m("b", { children: n === "downgradeRL" ? a(A("factionDowngradeRL"), { track: F(e.track ?? "") }) : `${a(A("factionAdvanceLowest"))} · ${F(e.track ?? "")}` }), e.hex && /* @__PURE__ */ m("small", { children: H(e.hex) })]
				})
			}, `${n}-${e.hex}-${e.track}`));
		}
		Gt && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => ut({ kind: "giantsMine" }),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: a(A("factionGiantsMine")) }), /* @__PURE__ */ m("small", { children: a(A("hintSelectBuild")) })]
			})
		}, "faction-giants-mine")), Kt && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => ut({ kind: "ring" }),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: a(A("factionMoweydRing")) }), /* @__PURE__ */ m("small", { children: a(A("hintSelectRing")) })]
			})
		}, "faction-ring")), qt && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => {
				qt.hex ? ut({ kind: "tinkerBuild" }) : W({
					type: "faction",
					kind: "tinkerAction",
					payQic: 0
				});
			},
			children: /* @__PURE__ */ m("span", {
				className: "gp-row-main",
				children: /* @__PURE__ */ m("b", { children: a(A("factionTinkerAction")) })
			})
		}, "faction-tinker")), Ht && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => U({
				type: "faction",
				kind: "swapPI",
				hex: Ht.hex,
				payQic: 0
			}),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: a(A("factionSwapPI")) }), /* @__PURE__ */ m("small", { children: H(Ht.hex ?? "") })]
			})
		}, "faction-swap")), Ut && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => W({
				type: "faction",
				kind: "baltaqGaiaformer",
				payQic: 0
			}),
			children: /* @__PURE__ */ m("span", {
				className: "gp-row-main",
				children: /* @__PURE__ */ m("b", { children: a(A("factionBaltaqGaiaformer")) })
			})
		}, "faction-baltak")), Wt && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => W({
				type: "faction",
				kind: "nevlasKnowledge",
				payQic: 0
			}),
			children: /* @__PURE__ */ m("span", {
				className: "gp-row-main",
				children: /* @__PURE__ */ m("b", { children: a(A("factionNevlasKnowledge")) })
			})
		}, "faction-nevlas")), Vt.length > 0 && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => ut({ kind: "station" }),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: a(A("factionSpaceStation")) }), /* @__PURE__ */ m("small", { children: a(A("hintSelectStation")) })]
			})
		}, "faction-station")), M.academy && t.push(/* @__PURE__ */ m("button", {
			type: "button",
			className: "gp-row-act",
			onClick: () => U({ type: "academy" }),
			children: /* @__PURE__ */ h("span", {
				className: "gp-row-main",
				children: [/* @__PURE__ */ m("b", { children: a(A("academyAction")) }), /* @__PURE__ */ m("small", { children: a(A("academyHint")) })]
			})
		}, "academy"));
		let i = M.free.flatMap((e) => {
			let t = Se.find((t) => t.id === e);
			if (!t) return [];
			let n = Fr[e];
			if (n != null && j.faction === "hadschhallas" && j.pi) {
				let r = gt(n), i = j.credits >= n;
				return [/* @__PURE__ */ h("div", {
					className: "gp-free",
					children: [/* @__PURE__ */ h("div", {
						className: "gp-row-line",
						children: [/* @__PURE__ */ m("b", { children: a(A(t.name)) }), /* @__PURE__ */ m("small", {
							className: "gp-dim",
							children: a(A(t.desc))
						})]
					}), /* @__PURE__ */ h("div", {
						className: "gp-dual",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn",
							disabled: !r,
							onClick: () => W({
								type: "free",
								id: e
							}),
							children: a(A("actionsUsePower"))
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn",
							disabled: !i,
							onClick: () => W({
								type: "free",
								id: e,
								credits: !0
							}),
							children: a(A("actionsUseCredits"))
						})]
					})]
				}, `free-${e}`)];
			}
			return [/* @__PURE__ */ m("button", {
				type: "button",
				className: "gp-row-act",
				onClick: () => W({
					type: "free",
					id: e
				}),
				children: /* @__PURE__ */ h("span", {
					className: "gp-row-main",
					children: [/* @__PURE__ */ m("b", { children: a(A(t.name)) }), /* @__PURE__ */ m("small", { children: a(A(t.desc)) })]
				})
			}, `free-${e}`)];
		});
		return /* @__PURE__ */ h("div", {
			className: "gp-sheet gp-action-deck",
			children: [
				n("power"),
				!e.lostFleet && n("qic"),
				N && t.length > 0 && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("actionsPersonal"))
					}), t]
				}),
				N && i.length > 0 && /* @__PURE__ */ h("div", {
					className: "gp-sec",
					children: [/* @__PURE__ */ m("div", {
						className: "gp-sec-label",
						children: a(A("actionsFree"))
					}), i]
				})
			]
		});
	}, yn = () => {
		if (!e.lostFleet || e.ships.length === 0) return /* @__PURE__ */ m("div", {
			className: "gp-sheet",
			children: /* @__PURE__ */ m("div", {
				className: "gp-dim",
				children: a(A("shipsEmpty"))
			})
		});
		let n = +(j.faction === "nevlas" || j.faction === "itars"), r = 5 + (j.faction === "baltaks" ? 2 : 0), i = (e) => /* @__PURE__ */ h("span", {
			className: "gp-cost",
			children: [
				e.qic != null && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
					name: "qic",
					size: 13
				}), e.qic] }),
				e.power != null && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
					name: "power",
					size: 13
				}), e.power] }),
				e.knowledge != null && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
					name: "knowledge",
					size: 13
				}), e.knowledge] }),
				e.credits != null && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
					name: "credits",
					size: 13
				}), e.credits] }),
				e.ores != null && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
					name: "ores",
					size: 13
				}), e.ores] })
			]
		}), o = (e) => e.hex ? H(e.hex) : e.track ? F(e.track) : e.token ? B(e.token) : e.tech ? I(e.tech) : a(A("actConfirm"));
		return /* @__PURE__ */ m("div", {
			className: "gp-sheet gp-ships",
			children: e.ships.map((s, c) => {
				let l = Be[s.id];
				if (!l) return null;
				let u = s.shuttles.includes(t), d = M.explore.find((e) => e.ship === s.id), f = N && u && s.id === "twilight" && M.examine, p = k && s.artifacts.includes(k) ? k : null;
				return /* @__PURE__ */ h("section", {
					className: "gp-ship",
					"data-mine": u,
					children: [
						/* @__PURE__ */ h("header", {
							className: "gp-ship-head",
							children: [
								/* @__PURE__ */ m("span", {
									className: "gp-ship-emblem",
									style: { "--gp-ship-color": Re(u ? t : s.shuttles[0] ?? e.turnSeat) },
									children: /* @__PURE__ */ m($, {
										name: "ship",
										size: 22
									})
								}),
								/* @__PURE__ */ h("div", {
									className: "gp-ship-name",
									children: [/* @__PURE__ */ m("b", { children: Ye(s.id) }), /* @__PURE__ */ m("small", { children: a(A("shipDock"), { hex: c + 1 }) })]
								}),
								s.goldToken && /* @__PURE__ */ h("span", {
									className: "gp-chip is-gold",
									children: [/* @__PURE__ */ m($, {
										name: "gold",
										size: 13
									}), Ze(s.goldToken)]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "gp-ship-slots",
							"aria-label": a(A("lfShuttles")),
							children: l.charges.map((e, t) => {
								let n = s.shuttles[t];
								return /* @__PURE__ */ h("span", {
									className: "gp-ship-slot",
									"data-owner": n ?? void 0,
									style: n == null ? void 0 : { "--gp-slot-color": Re(n) },
									children: [
										/* @__PURE__ */ m($, {
											name: "shuttle",
											size: 15
										}),
										n != null && /* @__PURE__ */ m("i", { "aria-hidden": !0 }),
										e > 0 && /* @__PURE__ */ h("b", { children: [/* @__PURE__ */ m($, {
											name: "power",
											size: 11
										}), e] })
									]
								}, t);
							})
						}),
						(s.artifacts.length > 0 || s.techs.length > 0) && /* @__PURE__ */ h("div", {
							className: "gp-ship-chips",
							children: [s.artifacts.map((e) => f ? /* @__PURE__ */ h("button", {
								type: "button",
								className: `gp-chip${p === e ? " is-on" : ""}`,
								"aria-pressed": p === e,
								onClick: () => Te(e),
								children: [/* @__PURE__ */ m($, {
									name: "artifact",
									size: 13
								}), Xe(e)]
							}, e) : /* @__PURE__ */ h("span", {
								className: "gp-chip",
								children: [/* @__PURE__ */ m($, {
									name: "artifact",
									size: 13
								}), Xe(e)]
							}, e)), s.techs.map((e) => /* @__PURE__ */ h("span", {
								className: "gp-chip",
								children: [/* @__PURE__ */ m($, {
									name: "tech",
									size: 13
								}), I(e)]
							}, e))]
						}),
						N && !u && d && /* @__PURE__ */ h("button", {
							type: "button",
							className: "gp-btn is-main gp-ship-explore",
							onClick: () => U({
								type: "explore",
								ship: s.id,
								payQic: d.payQic
							}),
							children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
								name: "shuttle",
								size: 15
							}), a(A("lfExplore"))] }), /* @__PURE__ */ h("span", {
								className: "gp-cost",
								children: [
									/* @__PURE__ */ h("span", { children: [
										/* @__PURE__ */ m($, {
											name: "vp",
											size: 13
										}),
										r,
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: [" ", a(A("resVP"))]
										})
									] }),
									n > 0 && /* @__PURE__ */ h("span", { children: [
										/* @__PURE__ */ m($, {
											name: "power",
											size: 13
										}),
										n,
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: [" ", a(A("resPowerTokens"))]
										})
									] }),
									j.faction === "taklons" && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
										name: "brainstone",
										size: 13
									}), /* @__PURE__ */ m("span", {
										className: "sr-only",
										children: a(A("lfBrainstoneCost"))
									})] }),
									d.payQic > 0 && /* @__PURE__ */ h("span", { children: [
										/* @__PURE__ */ m($, {
											name: "qic",
											size: 13
										}),
										d.payQic,
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: [" ", a(A("resQic"))]
										})
									] })
								]
							})]
						}),
						f && /* @__PURE__ */ h("button", {
							type: "button",
							className: "gp-btn is-main gp-ship-explore",
							disabled: !p,
							onClick: () => {
								p && (W({
									type: "examine",
									artifact: p
								}), Te(null));
							},
							children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
								name: "artifact",
								size: 15
							}), a(A("lfExamine"))] }), /* @__PURE__ */ m("span", {
								className: "gp-cost",
								children: /* @__PURE__ */ h("span", { children: [
									/* @__PURE__ */ m($, {
										name: "power",
										size: 13
									}),
									"6",
									/* @__PURE__ */ h("span", {
										className: "sr-only",
										children: [" ", a(A("resPowerTokens"))]
									})
								] })
							})]
						}),
						u && /* @__PURE__ */ m("div", {
							className: "gp-ship-actions",
							children: l.actions.map((e) => {
								let t = s.usedActions.includes(e.id), n = M.shipActions.filter((t) => t.ship === s.id && t.action === e.id), r = e.reward.kind === "tech" || e.reward.kind === "standardTech" || e.reward.kind === "freeUpgradeRl", c = r ? [...new Map(n.map((e) => [e.hex, e])).values()] : n;
								return /* @__PURE__ */ h("div", {
									className: "gp-ship-action",
									"data-state": t ? "used" : n.length === 0 ? "off" : "ready",
									children: [/* @__PURE__ */ h("div", {
										className: "gp-ship-action-head",
										children: [/* @__PURE__ */ m("span", { children: $e(e.id) }), i(e.cost)]
									}), t ? /* @__PURE__ */ h("small", { children: [/* @__PURE__ */ m($, {
										name: "used",
										size: 12
									}), a(A("actionsSpent"))] }) : n.length === 0 ? /* @__PURE__ */ h("small", { children: [/* @__PURE__ */ m($, {
										name: "lock",
										size: 12
									}), a(A("noTargets"))] }) : /* @__PURE__ */ m("div", {
										className: "gp-ship-choice",
										children: c.map((t, n) => /* @__PURE__ */ m("button", {
											type: "button",
											className: "gp-btn",
											disabled: !N,
											onClick: () => {
												if (r) {
													lt({
														kind: "ship",
														ship: s.id,
														action: e.id,
														hex: t.hex,
														qic: e.cost.qic ?? 0,
														standardOnly: e.reward.kind === "standardTech"
													});
													return;
												}
												let n = {
													type: "shipAction",
													ship: s.id,
													action: e.id,
													hex: t.hex,
													payQic: t.payQic ?? 0,
													track: t.track,
													token: t.token
												};
												t.track === "nav" && j.tracks[T.nav] === 4 ? ut({
													kind: "lostPlanet",
													action: n,
													availableQic: j.qic - (e.cost.qic ?? 0)
												}) : U(n);
											},
											children: r && !t.hex ? a(A("techTitle")) : o(t)
										}, n))
									})]
								}, e.id);
							})
						})
					]
				}, s.id);
			})
		});
	};
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(f, {
		adaptive: !0,
		scroll: !1,
		className: "gp-screen",
		actionsHeight: "gp-actions-slot",
		banner: en,
		actions: rn,
		overlay: Ne && At ? /* @__PURE__ */ m("div", {
			className: "gp-charge",
			children: /* @__PURE__ */ h("div", {
				className: "gp-charge-box",
				children: [
					/* @__PURE__ */ m("strong", { children: a(A("chargeTitle")) }),
					/* @__PURE__ */ m("p", { children: a(A("chargeHint"), {
						power: At.power,
						vp: At.vp
					}) }),
					/* @__PURE__ */ h("div", {
						className: "gp-dual",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn is-main",
							onClick: () => W({
								type: "charge",
								take: !0
							}),
							children: a(A("chargeTake"))
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "gp-btn",
							onClick: () => W({
								type: "charge",
								take: !1
							}),
							children: a(A("chargeSkip"))
						})]
					})
				]
			})
		}) : Fe && !C && l !== "tech" && Pe ? /* @__PURE__ */ m("div", {
			className: "gp-charge",
			children: /* @__PURE__ */ h("div", {
				className: "gp-charge-box",
				children: [/* @__PURE__ */ m("strong", { children: a(A(Pe.kind === "itars" ? "gaiaPhaseTitle" : "tinkerPickTitle")) }), Pe.kind === "itars" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("p", { children: a(A("gaiaPhaseItars")) }), /* @__PURE__ */ h("div", {
					className: "gp-dual",
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-btn is-main",
						onClick: () => lt({ kind: "itars" }),
						children: a(A("factionItarsTech"))
					}), /* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-btn",
						onClick: () => U({ type: "gaiaFinish" }),
						children: a(A("gaiaPhaseFinish"))
					})]
				})] }) : /* @__PURE__ */ m("div", {
					className: "gp-chiprow",
					children: M.tinkerChoices.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "gp-btn",
						onClick: () => U({
							type: "tinkerPick",
							tile: e
						}),
						children: Qe(e)
					}, e))
				})]
			})
		}) : null,
		children: /* @__PURE__ */ h("div", {
			className: "gp-main",
			children: [/* @__PURE__ */ h("div", {
				className: "gp-board-wrap",
				children: [/* @__PURE__ */ m(Sr, {
					view: e,
					seat: t,
					mode: xt,
					legal: K,
					selected: x,
					previewMine: Y && _t(Y) ? {
						hex: Y.hex,
						parasite: !!Y.parasite
					} : void 0,
					builtHex: Ee,
					buildCard: Y ? on : null,
					fedSel: ne ?? void 0,
					fedSatellites: bt?.satellites,
					foundedHex: Oe,
					pickable: v === "federation" ? yt : void 0,
					colorOfSeat: Re,
					onPick: St
				}), on && !Y && /* @__PURE__ */ m("div", {
					className: `gp-card${bt ? " gp-card-federation" : ""}`,
					children: on
				})]
			}), /* @__PURE__ */ h("aside", {
				className: "gp-side",
				"aria-label": a(A("infoTitle")),
				children: [
					/* @__PURE__ */ h("div", {
						className: "gp-side-head",
						children: [/* @__PURE__ */ m($, {
							name: "orbit",
							size: 18
						}), /* @__PURE__ */ m("span", { children: P(j.faction) })]
					}),
					/* @__PURE__ */ h("section", {
						className: "gp-side-section",
						children: [/* @__PURE__ */ m("h2", { children: a(A("infoFinalTiles")) }), e.finalTiles.map((e) => /* @__PURE__ */ h("div", {
							className: "gp-side-tile",
							children: [/* @__PURE__ */ m($, {
								name: cr[e] ?? "vp",
								size: 21
							}), a(kr[e] ?? A("finalScoring"))]
						}, e))]
					}),
					/* @__PURE__ */ h("section", {
						className: "gp-side-section",
						children: [/* @__PURE__ */ m("h2", { children: a(A("infoResearch")) }), w.map((t) => {
							let n = j.tracks[T[t.id]] ?? 0;
							return /* @__PURE__ */ h("button", {
								type: "button",
								className: "gp-side-track",
								disabled: e.phase !== "play" || Ne,
								style: { "--gp-track-color": jr[t.id].color },
								onClick: () => {
									ot("research"), je({
										track: t.id,
										level: Math.min(5, n + 1)
									});
								},
								children: [
									/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m($, {
										name: jr[t.id].icon,
										size: 17
									}), F(t.id)] }),
									/* @__PURE__ */ m("div", {
										className: "gp-side-pips",
										"aria-hidden": !0,
										children: [
											1,
											2,
											3,
											4,
											5
										].map((e) => /* @__PURE__ */ m("i", { className: e <= n ? "is-on" : void 0 }, e))
									}),
									/* @__PURE__ */ m("b", { children: n })
								]
							}, t.id);
						})]
					}),
					Jt && /* @__PURE__ */ h("section", {
						className: "gp-side-section",
						children: [/* @__PURE__ */ m("h2", { children: a(A("infoBooster")) }), /* @__PURE__ */ h("div", {
							className: "gp-side-booster",
							children: [/* @__PURE__ */ m($, {
								name: "gain",
								size: 20
							}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("b", { children: R(Jt.id) }), /* @__PURE__ */ m("p", { children: z(Jt.id) })] })]
						})]
					}),
					e.lostFleet && e.ships.length > 0 && /* @__PURE__ */ h("section", {
						className: "gp-side-section",
						children: [/* @__PURE__ */ m("h2", { children: a(A("shipsTitle")) }), e.ships.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "gp-side-ship",
							onClick: () => ot("ships"),
							children: [
								/* @__PURE__ */ m($, {
									name: "ship",
									size: 18
								}),
								/* @__PURE__ */ m("span", { children: Ye(e.id) }),
								/* @__PURE__ */ h("b", { children: [e.shuttles.length, /* @__PURE__ */ h("span", {
									className: "sr-only",
									children: [" ", a(A("lfShuttles"))]
								})] }),
								e.goldToken && /* @__PURE__ */ m($, {
									name: "gold",
									size: 14
								})
							]
						}, e.id))]
					})
				]
			})]
		})
	}), /* @__PURE__ */ m("div", {
		className: "gp-sheet-shell",
		"data-board": g === "research" || g === "actions" || g === "tech",
		children: /* @__PURE__ */ m(c, {
			open: l != null,
			onClose: st,
			label: a(Dr[g]),
			title: /* @__PURE__ */ h("span", {
				className: "gp-sheet-title",
				children: [/* @__PURE__ */ m($, {
					name: g === "research" ? "science" : g === "actions" ? "actions" : g === "tech" ? "tech" : g === "log" ? "log" : g === "ships" ? "ship" : "info",
					size: 21
				}), a(Dr[g])]
			}),
			footer: g === "research" ? pn() : void 0,
			tall: !0,
			children: ((e) => e === "info" ? /* @__PURE__ */ m("div", {
				className: "gp-sheet",
				children: sn(!0)
			}) : e === "log" ? /* @__PURE__ */ m("div", {
				className: "gp-sheet",
				children: ln()
			}) : e === "research" ? fn() : e === "tech" ? hn() : e === "pass" ? gn() : e === "rescore" ? _n() : e === "ships" ? yn() : vn())(g)
		})
	})] });
}
//#endregion
//#region src/game/bot.ts
var zr = {
	knowledge: 9.5,
	credits: 9.5,
	ores: 10.2,
	power: 10.5,
	qic: 10,
	points: 12,
	gleens: 4,
	gold_points: 12,
	gold_mineRange: 7,
	gold_tech: 7,
	gold_mine3: 7
}, Br = {
	terra: .2,
	nav: .1,
	ai: .25,
	gaia: .2,
	eco: .25,
	sci: .15
};
function Vr() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Hr(e) {
	if (e && typeof e == "object" && "free" in e) {
		let t = e.free;
		if (typeof t == "number") return { free: t };
	}
	return { free: 0 };
}
function Ur(e, t) {
	return e.hexes.find((e) => e.id === t);
}
function Wr(e, t) {
	return t.structure?.seat === e || t.parasite === e || t.station === e || t.lostPlanet === e;
}
function Gr(e, t) {
	return e.hexes.filter((e) => e.structure?.seat === t && e.planet === "gaia").length;
}
function Kr(e) {
	return new Set(e.advTechs.map((e) => e.covers));
}
function qr(e) {
	let t = Kr(e);
	return e.techs.filter((e) => !t.has(e));
}
function Jr(e) {
	return (zr[e] ?? 6) + (e === "points" ? 0 : 2.5);
}
function Yr(e, t, n) {
	let r = [...e.fedTokens].sort((e, t) => Jr(t) - Jr(e));
	for (let i of r) {
		let r = Ke[i];
		if (!r || r.kind === "points") return {
			token: i,
			goldQic: 0
		};
		if (r.kind === "tech") {
			let r = $r(e, t, n);
			if (!r) continue;
			return {
				token: i,
				goldQic: 0,
				goldTech: r,
				goldTrack: r.track
			};
		}
		let a = e.goldMines.find((e) => e.token === i);
		if (a) return {
			token: i,
			goldQic: a.payQic,
			goldHex: a.hex
		};
	}
	return null;
}
function Xr(e, t, n) {
	let r = Be[n.ship]?.actions.find((e) => e.id === n.action);
	if (!r) return 1;
	switch (r.reward.kind) {
		case "vpPerType": return 1.2 + .15 * t.knownTypes.length;
		case "creditsQic": return 1.3;
		case "advanceResearch": return n.track ? 2.4 + Zr(n.track, t, e) : 1.5;
		case "repeatFed": return 1.6 + (n.token ? Jr(n.token) * .15 : 0);
		case "standardTech": return n.tech ? 2 + Qr(n.tech, t, e) : 1.5;
		case "tech": return n.tech ? 1.8 + .4 * Qr(n.tech, t, e) : 1.5;
		case "freeAsteroidMine": return 2.4;
		case "range3": return 2.2;
		case "freeMine1": return 2.2;
		case "gaiaProject": return 2;
		case "freeUpgradeRl": return 2.3;
		case "freeUpgradeTs": return 2.2;
	}
	return 1.5;
}
function Zr(e, t, n) {
	let r = t.tracks[T[e]] + 1, i = Br[e];
	switch (r === 3 && (i += .9), e) {
		case "terra":
			(r === 1 || r === 4) && (i += .8), r === 5 && (i += 1.6);
			break;
		case "nav":
			(r === 1 || r === 3) && (i += .5), r === 5 && (i += 2.2);
			break;
		case "ai":
			i += r <= 2 ? .5 : r <= 4 ? 1 : 2;
			break;
		case "gaia":
			(r === 1 || r === 3 || r === 4) && (i += 1.1), r === 2 && (i += .7), r === 5 && (i += 2 + .5 * Gr(n, t.seat));
			break;
		case "eco":
			r === 1 && (i += .5), r === 2 && (i += .8), r === 3 && (i += 1), r === 4 && (i += 1.3), r === 5 && (i += 2.2);
			break;
		case "sci": i += r === 5 ? 2.8 : .4 * r;
	}
	return i;
}
function Qr(e, t, n) {
	let r = O[e];
	if (!r) return 0;
	let i = r.effect, a = Math.max(0, 6 - n.round + 1);
	if (i.kind === "freeMineTerra") return 3 + i.steps;
	if (i.kind === "immediate") return (i.vp ?? 0) * 1 + (i.credits ?? 0) * .15 + (i.ores ?? 0) * .5 + (i.knowledge ?? 0) * .6 + (i.qic ?? 0) * .6;
	if (i.kind === "immediatePerType") return i.knowledge * t.knownTypes.length * .55;
	if (i.kind === "income") return ((i.credits ?? 0) * .2 + (i.ores ?? 0) * .5 + (i.knowledge ?? 0) * .6 + (i.power ?? 0) * .3) * Math.min(a, 4);
	if (i.kind === "action") return i.action === "power4" ? 2.1 : i.action === "qic5c" ? 2.4 : i.action === "ore3" ? 2 : 1.8;
	if (i.kind === "passive") return i.passive === "big4" ? 1.2 : i.passive === "gaia3vp" ? .8 + Gr(n, t.seat) * .8 : i.passive === "mine3vp" ? Math.min(t.buildings.mines, 4) * .7 : i.passive === "ts3vp" ? Math.min(t.buildings.ts, 3) * .7 : 1.5;
	if (i.kind === "pass") return i.metric === "federation" ? .4 + t.fedTokens.length * .8 : i.metric === "rl" ? .4 + t.buildings.rl * .8 : .4 + t.knownTypes.length * .5;
	let o = i.metric === "mine" ? t.buildings.mines : i.metric === "ts" ? t.buildings.ts : i.metric === "federation" ? t.fedTokens.length : i.metric === "gaia" ? Gr(n, t.seat) : t.buildings.sectors;
	return ((i.vp ?? 0) + (i.ores ?? 0) * .7) * o * .8;
}
function $r(e, t, n) {
	let r = qr(t), i = null;
	for (let a of e.techs) {
		if (a.advanced && r.length === 0) continue;
		let e = Qr(a.id, t, n);
		if (a.advanced && (e -= 1.2), !i || e > i.value) {
			let o = a.advanced || a.track == null ? a.advanceTracks.filter((e) => e !== "nav" || t.tracks[T.nav] < 4).reduce((e, r) => e && Zr(e, t, n) >= Zr(r, t, n) ? e : r, void 0) : void 0;
			i = {
				tech: a.id,
				advanced: a.advanced,
				cover: a.advanced ? r[0] : void 0,
				track: o,
				value: e
			};
		}
	}
	return i;
}
function ei(e, t, n) {
	return !e.hexes.some((e) => e.sector === n.sector && e.id !== n.id && Wr(t, e));
}
function ti(e, t) {
	return t.planet != null && t.planet !== "gaia" && !e.knownTypes.includes(t.planet);
}
function ni(e, t, n, r) {
	let i = e.roundTiles[e.round - 1] ?? "", a = 3.3;
	return r.parasite && (a -= .6), r.asteroid && (a -= n.gaiaformers >= 2 ? .4 : 2.2), r.prototype && (a += 2.5), r.hex.artifact != null && (a += 4.5), r.hex.planet === "gaia" && !r.asteroid && (a += 1), i === "mine2" && (a += 2), r.parasite || ((i === "gaia3" || i === "gaia4") && r.hex.planet === "gaia" && (a += i === "gaia3" ? 3 : 4), i === "lf_sector" && ei(e, t, r.hex) && (a += 3), i === "lf_type" && ti(n, r.hex) && (a += 3)), i === "terra2" && (a += 2 * r.steps), n.credits - r.credits < 2 && (a -= .5), n.ores - r.oreCost < 1 && !r.asteroid && (a -= .3), a;
}
function ri(e) {
	return e.hexes.some((e) => e.planet == null && e.structure == null && e.lostPlanet == null && e.station == null && e.satellites.length === 0);
}
function ii(e, t, n) {
	return te.filter((r) => {
		let i = n.tracks[T[r]];
		return !(i >= 5 || n.faction === "baltaks" && r === "nav" && !n.pi || i === 4 && (!n.fedTokens.some((e) => e.green) || e.players.some((e) => e.seat !== t && e.tracks[T[r]] >= 5) || r === "nav" && !ri(e)));
	});
}
function ai(e, t, n, r) {
	let i = [], a = e.roundTiles[e.round - 1] ?? "";
	for (let a of r.builds) {
		let r = Ur(e, a.hex);
		r && (n.credits < a.credits || n.ores < a.oreCost || i.push({
			action: {
				type: "build",
				hex: a.hex,
				payQic: a.qic,
				parasite: a.parasite ? !0 : void 0
			},
			score: ni(e, t, n, {
				hex: r,
				steps: a.steps,
				credits: a.credits,
				oreCost: a.oreCost,
				parasite: !!a.parasite,
				asteroid: !!a.asteroid,
				prototype: !!a.prototype
			})
		}));
	}
	for (let t of r.upgrades) {
		if (n.credits < t.credits || n.ores < t.ores) continue;
		let o = null;
		if (t.gainsTech && (o = $r(r, n, e), !o)) continue;
		let s = t.to === "ts" ? 2.6 : t.to === "pi" ? 4.2 : t.to === "rl" ? 3.1 : 3.3;
		t.to === "pi" && (s += .4), o && (s += .45 * o.value), t.to === "ts" && (a === "ts3" || a === "ts4") && (s += a === "ts3" ? 3 : 4), t.to === "rl" && a === "lf_rl" && (s += 4), (t.to === "pi" || t.to === "ac") && (a === "big5" || a === "big5b") && (s += 5), i.push({
			action: {
				type: "upgrade",
				hex: t.hex,
				to: t.to,
				side: t.side,
				tech: o?.tech,
				advanced: o?.advanced,
				cover: o?.cover,
				track: o?.track
			},
			score: s
		});
	}
	for (let t of r.research) {
		let o = 2.8 + Zr(t, n, e);
		a === "research2" && (o += 2);
		let s = t === "nav" && n.tracks[T.nav] === 4 ? r.lostPlanet.filter(({ payQic: e }) => e <= n.qic).sort((e, t) => e.payQic - t.payQic)[0] : void 0;
		i.push({
			action: {
				type: "research",
				track: t,
				hex: s?.hex,
				payQic: s?.payQic ?? 0
			},
			score: o
		});
	}
	if (r.fedTokens.length > 0 && r.federations.length > 0) {
		let t = Yr(r, n, e);
		if (t) for (let e of r.federations) {
			let n = 3 + Jr(t.token) * .45;
			a === "federation5" && (n += 5), i.push({
				action: {
					type: "federation",
					token: t.token,
					hexes: [...e.hexes],
					satellites: [...e.satellites],
					goldPayQic: t.goldQic,
					goldHex: t.goldHex,
					goldTech: t.goldTech?.tech,
					goldAdvanced: t.goldTech?.advanced || void 0,
					goldCover: t.goldTech?.cover,
					goldTrack: t.goldTrack
				},
				score: n
			});
		}
	}
	for (let e of r.gaia) {
		let t = 2.2;
		n.gaiaformers >= 2 && (t += .3), i.push({
			action: {
				type: "gaia",
				hex: e.hex,
				payQic: e.qic
			},
			score: t
		});
	}
	for (let a of r.power) if (a.id === "p_terra1" || a.id === "p_terra2") {
		let r = a.hex ? Ur(e, a.hex) : void 0;
		if (!r) continue;
		let o = a.credits ?? 2, s = a.oreCost ?? 1;
		if (n.credits < o || n.ores < s) continue;
		let c = ni(e, t, n, {
			hex: r,
			steps: r.planet ? E(n.faction, r.planet) : 0,
			credits: o,
			oreCost: s,
			parasite: !!a.parasite,
			asteroid: r.planet === "asteroid",
			prototype: r.planet === "protoplanet"
		}) - 1.3;
		i.push({
			action: {
				type: "power",
				id: a.id,
				hex: a.hex,
				payQic: a.payQic ?? 0,
				parasite: a.parasite
			},
			score: c
		});
	} else {
		let e = 1;
		a.id === "p_credits7" ? e = n.credits < 6 ? 1.8 : 1 : a.id === "p_knw3" ? e = n.knowledge < 4 ? 1.9 : .9 : a.id === "p_ore2" ? e = 1.3 : a.id === "p_knw2" ? e = 1.1 : a.id === "p_tokens2" && (e = 1.2), i.push({
			action: {
				type: "power",
				id: a.id,
				payQic: 0
			},
			score: e
		});
	}
	for (let t of r.qic) if (t === "q_tech") {
		let a = $r(r, n, e);
		if (!a) continue;
		i.push({
			action: {
				type: "qic",
				id: t,
				tech: a.tech,
				advanced: a.advanced,
				cover: a.cover,
				track: a.track
			},
			score: 2.4 + .45 * a.value
		});
	} else if (t === "q_rescore") {
		if (n.fedTokens.length === 0) continue;
		let e = n.fedTokens[0].type;
		for (let t of n.fedTokens) Jr(t.type) > Jr(e) && (e = t.type);
		i.push({
			action: {
				type: "qic",
				id: t,
				token: e
			},
			score: 1.4 + Jr(e) * .15
		});
	} else i.push({
		action: {
			type: "qic",
			id: t
		},
		score: 1.2 + n.knownTypes.length * .25
	});
	for (let e of r.useTiles) {
		let t = O[e], n = 1.4;
		t?.effect.kind === "action" && (n = t.effect.action === "qic5c" ? 2 : t.effect.action === "ore3" ? 1.9 : t.effect.action === "power4" ? 1.6 : 1.5), i.push({
			action: {
				type: "useTile",
				id: e,
				payQic: 0
			},
			score: n
		});
	}
	let o = ii(e, t, n);
	for (let s of r.faction) switch (s.kind) {
		case "downgradeRL": {
			if (!s.hex || !s.track) break;
			let e = 3.5 + Br[s.track];
			(a === "ts3" || a === "ts4") && (e += a === "ts3" ? 3 : 4), a === "research2" && (e += 2), i.push({
				action: {
					type: "faction",
					kind: "downgradeRL",
					hex: s.hex,
					track: s.track,
					payQic: 0
				},
				score: e
			});
			break;
		}
		case "advanceLowest": {
			if (o.length === 0) break;
			let e = 3.3;
			a === "research2" && (e += 2), i.push({
				action: {
					type: "faction",
					kind: "advanceLowest",
					track: s.track,
					payQic: 0
				},
				score: e
			});
			break;
		}
		case "spaceStation":
			if (!s.hex) break;
			i.push({
				action: {
					type: "faction",
					kind: "spaceStation",
					hex: s.hex,
					payQic: s.payQic ?? 0
				},
				score: 2
			});
			break;
		case "swapPI":
			if (!s.hex) break;
			i.push({
				action: {
					type: "faction",
					kind: "swapPI",
					hex: s.hex,
					payQic: 0
				},
				score: 1.5
			});
			break;
		case "giantsMine": {
			let r = s.hex ? Ur(e, s.hex) : void 0;
			if (!r || !s.hex) break;
			let a = r.planet ? E(n.faction, r.planet) : 0;
			i.push({
				action: {
					type: "faction",
					kind: "giantsMine",
					hex: s.hex,
					payQic: s.payQic ?? 0
				},
				score: ni(e, t, n, {
					hex: r,
					steps: a,
					credits: 2,
					oreCost: 1 + Math.max(0, a - 2),
					parasite: !1,
					asteroid: !1,
					prototype: r.planet === "protoplanet"
				}) - .2
			});
			break;
		}
		case "moweydRing":
			if (!s.hex) break;
			i.push({
				action: {
					type: "faction",
					kind: "moweydRing",
					hex: s.hex,
					payQic: 0
				},
				score: 1.7
			});
			break;
		case "tinkerAction": if (s.hex) {
			let r = Ur(e, s.hex);
			if (!r) break;
			i.push({
				action: {
					type: "faction",
					kind: "tinkerAction",
					hex: s.hex,
					payQic: s.payQic ?? 0
				},
				score: ni(e, t, n, {
					hex: r,
					steps: 0,
					credits: 2,
					oreCost: 1,
					parasite: !1,
					asteroid: !1,
					prototype: r.planet === "protoplanet"
				}) - .2
			});
		} else i.push({
			action: {
				type: "faction",
				kind: "tinkerAction",
				payQic: 0
			},
			score: 1.6
		});
	}
	for (let t of r.explore) {
		let n = e.ships.find((e) => e.id === t.ship), r = 1.9;
		n && n.shuttles.length > 0 && (r += .4), e.round >= 5 && (r -= .6), i.push({
			action: {
				type: "explore",
				ship: t.ship,
				payQic: t.payQic
			},
			score: r
		});
	}
	let s = e.ships.find(({ id: e }) => e === "twilight")?.artifacts[0];
	r.examine && s && i.push({
		action: {
			type: "examine",
			artifact: s
		},
		score: 2.4
	});
	for (let t of r.shipActions) i.push({
		action: {
			type: "shipAction",
			ship: t.ship,
			action: t.action,
			hex: t.hex,
			payQic: t.payQic ?? 0,
			track: t.track,
			token: t.token,
			tech: t.tech,
			advanced: t.advanced,
			cover: t.cover,
			lostHex: t.lostHex,
			lostPayQic: t.lostPayQic
		},
		score: Xr(e, n, t)
	});
	for (let a of r.freeMines) {
		let r = Ur(e, a.hex);
		r && i.push({
			action: {
				type: "useTile",
				id: a.id,
				hex: a.hex,
				payQic: a.payQic
			},
			score: ni(e, t, n, {
				hex: r,
				steps: 0,
				credits: 0,
				oreCost: 0,
				parasite: !1,
				asteroid: !1,
				prototype: r.planet === "protoplanet"
			}) - .2
		});
	}
	for (let a of r.boosters) {
		if (!a.hex) continue;
		let r = Ur(e, a.hex);
		if (!r) continue;
		if (a.mode === "gaia") {
			i.push({
				action: {
					type: "booster",
					id: a.id,
					hex: a.hex,
					mode: "gaia",
					payQic: a.qic ?? 0
				},
				score: 2
			});
			continue;
		}
		let o = a.credits ?? 2, s = a.oreCost ?? 1;
		if (n.credits < o || n.ores < s) continue;
		let c = r.planet ? E(n.faction, r.planet) : 0;
		i.push({
			action: {
				type: "booster",
				id: a.id,
				hex: a.hex,
				mode: "build",
				payQic: a.qic ?? 0
			},
			score: ni(e, t, n, {
				hex: r,
				steps: c,
				credits: o,
				oreCost: s,
				parasite: !1,
				asteroid: r.planet === "asteroid",
				prototype: r.planet === "protoplanet"
			}) - .4
		});
	}
	return r.academy && i.push({
		action: { type: "academy" },
		score: 1.4
	}), i;
}
function oi(e, t, n) {
	let r = t.players[n], i = si[e];
	if (!i) return 0;
	let a = 0, o = i.income;
	if (o && (a += (o.credits ?? 0) * .18 + (o.ores ?? 0) * .5 + (o.knowledge ?? 0) * .6 + (o.power ?? 0) * .25 + (o.tokens ?? 0) * .6 + (o.qic ?? 0) * .8), i.pass) {
		let e = {
			mine: r.buildings.mines,
			ts2: 2 * r.buildings.ts,
			rl3: 3 * r.buildings.rl,
			big4: 4 * (r.buildings.pi + r.buildings.ac),
			gaia1: Gr(t, n)
		};
		a += e[i.pass] * .45;
	}
	return i.action === "terraform1" && (a += 1.8), i.action === "range3" && (a += 1.3), a;
}
var si = {
	B_oreKnw: { income: {
		ores: 1,
		knowledge: 1
	} },
	B_tokensOre: { income: {
		ores: 1,
		tokens: 2
	} },
	B_creditsQic: { income: {
		credits: 2,
		qic: 1
	} },
	B_terraformCredits: {
		income: { credits: 2 },
		action: "terraform1"
	},
	B_rangePower: {
		income: { power: 2 },
		action: "range3"
	},
	B_mineOre: {
		income: { ores: 1 },
		pass: "mine"
	},
	B_tsOre: {
		income: { ores: 1 },
		pass: "ts2"
	},
	B_rlKnw: {
		income: { knowledge: 1 },
		pass: "rl3"
	},
	B_bigPower: {
		income: { power: 4 },
		pass: "big4"
	},
	B_gaiaCredits: {
		income: { credits: 4 },
		pass: "gaia1"
	}
};
function ci(e, t, n) {
	if (e.length === 0) return null;
	let r = e[0];
	for (let i of e) oi(i, t, n) > oi(r, t, n) && (r = i);
	return r;
}
function li(e, t) {
	if (e.round >= 6) return { type: "pass" };
	let n = e.players[t].booster;
	return {
		type: "pass",
		booster: ci(e.hints.passBoosters.filter((e) => e !== n), e, t)
	};
}
function ui(e) {
	return e.faction === "baltaks" && e.gaiaformers > 0 && e.qic === 0 ? {
		type: "faction",
		kind: "baltaqGaiaformer",
		payQic: 0
	} : null;
}
var di = (e, t) => {
	let n = e.public, r = e.private?.seat ?? -1;
	if (r < 0 || n.phase === "done") return null;
	let i = n.players[r], a = Hr(t.memory);
	if (n.pending) {
		if (n.pending.seat !== r) return null;
		let e = n.hints.charge;
		return e ? {
			action: {
				type: "charge",
				take: e.vp <= 2
			},
			memory: a
		} : null;
	}
	if (n.phase === "draft") {
		if (n.draftSeat !== r) return null;
		let e = ci(n.hints.draft, n, r);
		return e ? {
			action: {
				type: "draft",
				booster: e
			},
			memory: a
		} : null;
	}
	if (n.roundDecision) {
		if (n.roundDecision.seat !== r) return null;
		if (n.roundDecision.kind === "tinker") {
			let e = n.hints.tinkerChoices[0];
			return e ? {
				action: {
					type: "tinkerPick",
					tile: e
				},
				memory: a
			} : null;
		}
		let e = $r(n.hints, i, n);
		if (!e) return {
			action: { type: "gaiaFinish" },
			memory: a
		};
		let { tech: t, advanced: o, cover: s, track: c } = e;
		return {
			action: {
				type: "faction",
				kind: "itarsTech",
				payQic: 0,
				tech: t,
				advanced: o,
				cover: s,
				track: c
			},
			memory: a
		};
	}
	if (n.turnSeat !== r || i.passed) return null;
	if (a.free < 3) {
		let e = ui(i);
		if (e) return {
			action: e,
			memory: { free: a.free + 1 }
		};
	}
	if (!n.hints.pass) return null;
	let o = ai(n, r, i, n.hints);
	t.difficulty === "weak" && (o = o.map((e) => ({
		...e,
		score: e.score * (.7 + Vr() * .6)
	})));
	let s = null;
	for (let e of o) (!s || e.score > s.score) && (s = e);
	return !s || s.score < .8 ? {
		action: li(n, r),
		memory: { free: 0 }
	} : {
		action: s.action,
		memory: { free: 0 }
	};
}, fi = Object.fromEntries([..._e, ...ve].map(({ id: e, name: t }) => [e, A(t)]));
function pi({ public: e, result: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: c }) {
	let d = l(), f = e, [p, _] = o(!0), v = f.result?.rows ?? [], y = (e) => v.find((t) => t.rid === e), b = (e) => y(e)?.total ?? t.scores?.[e] ?? 0, x = f.result?.ghost && v.some((e) => e.rid === "$ghost") ? [...t.ranking, "$ghost"] : t.ranking, S = (e) => n.find((t) => t.rid === e), C = (e) => {
		let t = S(e)?.colorIndex ?? f.players.find((t) => t.rid === e)?.seat ?? 0;
		return u[t % u.length] ?? u[0];
	}, ee = (e) => e === "$ghost" ? d("games.gaiaproject.overGhost") : S(e)?.name || d(C(e).nameKey), w = (e) => s[(S(e)?.avatar ?? 0) % s.length], te = (e) => t.ranking.filter((t) => b(t) > b(e)).length + 1, T = t.winner.map(ee);
	return /* @__PURE__ */ h("div", {
		className: "gp-screen gp-over",
		children: [
			/* @__PURE__ */ m("div", {
				className: "gp-over-scene",
				inert: p,
				children: /* @__PURE__ */ m(Lr, {
					public: f,
					members: n,
					myRid: r,
					send: () => {}
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "gp-over-overlay",
				hidden: !p,
				children: /* @__PURE__ */ h("section", {
					className: "gp-over-panel",
					"aria-label": d("games.gaiaproject.overTitle"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "gp-over-head",
							children: [/* @__PURE__ */ h("div", {
								className: "gp-over-emblem",
								"aria-hidden": !0,
								children: [/* @__PURE__ */ m($, {
									name: "orbit",
									size: 39
								}), /* @__PURE__ */ m($, {
									name: "vp",
									size: 16
								})]
							}), /* @__PURE__ */ h("div", { children: [
								/* @__PURE__ */ m("h1", { children: d("games.gaiaproject.overTitle") }),
								f.lostFleet && /* @__PURE__ */ m("span", {
									className: "gp-experiment",
									children: d(A("experimentLabel"))
								}),
								T.length > 0 && t.ranking.length > 1 && /* @__PURE__ */ h("p", {
									className: "gp-over-winners",
									children: [
										d("games.gaiaproject.overWinner"),
										" · ",
										T.join(" · ")
									]
								})
							] })]
						}),
						/* @__PURE__ */ h("div", {
							className: "gp-over-scroll",
							role: "region",
							"aria-label": d(A("overDetail")),
							tabIndex: 0,
							children: [
								/* @__PURE__ */ h("div", {
									className: "gp-over-ledger",
									children: [/* @__PURE__ */ h("section", {
										className: "gp-over-ranks",
										"aria-label": d(A("overRankings")),
										children: [/* @__PURE__ */ m("h2", { children: d(A("overRankings")) }), t.ranking.map((e) => {
											let n = y(e), r = t.winner.includes(e) && t.ranking.length > 1;
											return /* @__PURE__ */ h("article", {
												className: "gp-over-card",
												"data-winner": r,
												style: { "--gp-seat": C(e).hex },
												children: [/* @__PURE__ */ h("header", {
													className: "gp-over-card-head",
													children: [
														/* @__PURE__ */ m("img", {
															className: "gp-ava",
															src: w(e),
															alt: ""
														}),
														/* @__PURE__ */ h("div", {
															className: "gp-over-id",
															children: [/* @__PURE__ */ m("strong", { children: ee(e) }), /* @__PURE__ */ m("small", { children: d("games.gaiaproject.overRank", { n: te(e) }) })]
														}),
														/* @__PURE__ */ h("span", {
															className: "gp-over-total",
															children: [/* @__PURE__ */ m("b", { children: b(e) }), /* @__PURE__ */ m("small", { children: d("games.gaiaproject.overTotal") })]
														})
													]
												}), n && /* @__PURE__ */ h("dl", {
													className: "gp-over-breakdown",
													"aria-label": d("games.gaiaproject.overDetail"),
													children: [
														/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: d("games.gaiaproject.metricVp") }), /* @__PURE__ */ m("dd", { children: n.vp - n.research - n.resources })] }),
														/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: d("games.gaiaproject.metricResearch") }), /* @__PURE__ */ m("dd", { children: n.research })] }),
														/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: d("games.gaiaproject.metricResources") }), /* @__PURE__ */ m("dd", { children: n.resources })] }),
														/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: d("games.gaiaproject.metricAwards") }), /* @__PURE__ */ m("dd", { children: n.awards.reduce((e, t) => e + t.vp, 0) })] })
													]
												})]
											}, e);
										})]
									}), v.length > 0 && /* @__PURE__ */ h("section", {
										className: "gp-over-objectives",
										"aria-label": d(A("overObjectives")),
										children: [/* @__PURE__ */ m("h2", { children: d(A("overObjectives")) }), /* @__PURE__ */ m("div", {
											className: "gp-over-tiles",
											children: f.finalTiles.map((e) => /* @__PURE__ */ h("article", {
												className: "gp-over-tile",
												children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("div", {
													className: "gp-over-tile-symbol",
													children: /* @__PURE__ */ m($, {
														name: cr[e] ?? "vp",
														size: 31
													})
												}), /* @__PURE__ */ m("h3", { children: d(fi[e] ?? A("finalScoring")) })] }), /* @__PURE__ */ h("table", { children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [
													/* @__PURE__ */ m("th", {
														scope: "col",
														children: d(A("overCompetitor"))
													}),
													/* @__PURE__ */ m("th", {
														scope: "col",
														children: d(A(e === "lf_piAcademy" ? "overDistance" : "overCount"))
													}),
													/* @__PURE__ */ m("th", {
														scope: "col",
														children: d(A("overAwardPoints"))
													})
												] }) }), /* @__PURE__ */ m("tbody", { children: x.map((t) => {
													let n = y(t)?.awards.find((t) => t.id === e);
													return n ? /* @__PURE__ */ h("tr", {
														"data-ghost": t === "$ghost",
														children: [
															/* @__PURE__ */ m("th", {
																scope: "row",
																children: /* @__PURE__ */ h("span", {
																	className: "gp-over-competitor",
																	style: { "--gp-seat": C(t).hex },
																	children: [t === "$ghost" ? /* @__PURE__ */ m($, {
																		name: "orbit",
																		size: 22
																	}) : /* @__PURE__ */ m("img", {
																		className: "gp-ava",
																		src: w(t),
																		alt: ""
																	}), /* @__PURE__ */ m("span", { children: ee(t) })]
																})
															}),
															/* @__PURE__ */ m("td", { children: n.count }),
															/* @__PURE__ */ m("td", { children: n.vp > 0 ? `+${n.vp}` : n.vp })
														]
													}, t) : null;
												}) })] })]
											}, e))
										})]
									})]
								}),
								i !== void 0 && /* @__PURE__ */ m("p", {
									className: "gp-over-note",
									children: d("session.hint.usedCount", { n: i })
								}),
								t.ranking.map((e) => {
									let n = t.autopilot?.[e];
									return n ? /* @__PURE__ */ h("p", {
										className: "gp-over-note",
										children: [
											ee(e),
											" · ",
											d("session.autopilot.share", { n: Math.round(n * 100) })
										]
									}, e) : null;
								})
							]
						}),
						/* @__PURE__ */ h("footer", {
							className: "gp-over-actions",
							children: [
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "gp-btn is-main",
									onClick: () => _(!1),
									children: [/* @__PURE__ */ m($, {
										name: "orbit",
										size: 16
									}), d("games.gaiaproject.overReview")]
								}),
								a && /* @__PURE__ */ m(g, {
									compact: !0,
									label: d("session.result.playAgain"),
									confirmLabel: d("games.gaiaproject.confirmAgain"),
									onConfirm: a
								}),
								c && /* @__PURE__ */ m(g, {
									compact: !0,
									label: d("session.result.backToLobby"),
									confirmLabel: d("games.gaiaproject.confirmLobby"),
									onConfirm: c
								}),
								!a && !c && /* @__PURE__ */ m("span", {
									className: "gp-dim",
									children: d("games.gaiaproject.overWaitHost")
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "gp-btn is-main gp-over-restore",
				hidden: p,
				onClick: () => _(!0),
				children: d("games.gaiaproject.overBack")
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function mi({ value: e, onChange: t }) {
	let n = l(), r = Nn.safeParse(e), i = r.success ? r.data : Nn.parse(void 0);
	return /* @__PURE__ */ m(v, {
		title: n("games.gaiaproject.name"),
		children: /* @__PURE__ */ m(_, {
			name: "gaiaproject-lostfleet",
			value: "lostFleet",
			checked: i.lostFleet,
			label: n("games.gaiaproject.optionsLostFleet"),
			hint: n("games.gaiaproject.optionsLostFleetHint"),
			accent: Mn.accent,
			onChange: () => t({
				...i,
				lostFleet: !i.lostFleet
			})
		})
	});
}
//#endregion
//#region src/game/guide.tsx
function hi() {
	let e = l();
	return /* @__PURE__ */ h("div", {
		className: "grid gap-3 p-3",
		children: [
			/* @__PURE__ */ h("section", { children: [/* @__PURE__ */ m("h2", {
				className: "font-bold",
				children: e(A("trackNav"))
			}), /* @__PURE__ */ m("p", { children: e(A("guideRange")) })] }),
			/* @__PURE__ */ h("section", { children: [/* @__PURE__ */ m("h2", {
				className: "font-bold",
				children: e(A("techAdvanced"))
			}), /* @__PURE__ */ h("ul", {
				className: "list-disc space-y-1 pl-5",
				children: [
					/* @__PURE__ */ m("li", { children: e(A("guideTrackTech")) }),
					/* @__PURE__ */ m("li", { children: e(A("guideFleetTech")) }),
					/* @__PURE__ */ m("li", { children: e(A("guideTechAdvance")) })
				]
			})] }),
			/* @__PURE__ */ h("section", { children: [/* @__PURE__ */ m("h2", {
				className: "font-bold",
				children: e(A("guideRoundDecisions"))
			}), /* @__PURE__ */ h("ul", {
				className: "list-disc space-y-1 pl-5",
				children: [/* @__PURE__ */ m("li", { children: e(A("guideItars")) }), /* @__PURE__ */ m("li", { children: e(A("guideTinkeroids")) })]
			})] })
		]
	});
}
//#endregion
//#region src/index.tsx
var gi = {
	definition: or,
	View: Lr,
	bot: di,
	OverView: pi,
	Options: mi,
	Guide: hi,
	locales: {
		zh: {
			name: "盖亚计划",
			desc: "改造行星、扩张联邦、攀爬六条研究轨的星际殖民对决",
			rules: "本游戏支持 2–4 人。通过改造行星、扩建建筑、发展研究和建立联邦获得胜利点，六轮后得分最高的玩家获胜。\n开局:\n· 系统为每位玩家分配一个派系，并在该派系的母星上布置起始建筑。伊维特人从一座行星研究所开始，泽诺斯人从三座矿场开始，其余派系从两座矿场开始。\n· 玩家从末位起逆序选择强化板，随后结算第一轮收入。\n每轮流程:\n· 收入阶段按派系、建筑、研究、强化板和科技板结算收入。盖亚阶段将能量按派系规则从盖亚区移回能量循环，并完成上一轮开始的盖亚改造。\n· 行动阶段轮流行动。玩家通过后停止本轮行动，并在前五轮领取下一轮的强化板。最先通过的玩家成为下一轮先手。所有玩家通过后进入下一轮，第六轮结束后结算。\n行动:\n· 建造矿场时，选择一个可达的行星，支付建筑所需的信用点和矿石。用矿石支付地形改造费用，需要延伸航程时可支付 QIC。\n· 开始盖亚改造时，将一个可用的盖亚改造器放到可达的虚境行星上，并按研究板所示数量将能量标记移入盖亚区。\n· 矿场可以升级为贸易站，贸易站可以升级为行星研究所或实验室，实验室可以升级为学院。建成实验室或学院时获得科技板。取得高级科技板时，翻面一枚绿色联邦标记，并覆盖一张标准科技板。你随后可以选择推进一条符合条件的研究轨。\n· 支付 4 点知识可以推进一级研究。进入第 5 级需要翻面一枚绿色联邦标记，每条轨道只能有一位玩家到达第 5 级。每当推进到航行第 5 级时，在星图上选择一个可达的空格放置失落行星。\n· 组建联邦时，用建筑和卫星连成达到所需战力的整体，并领取一枚联邦标记。每颗卫星放在空格内，通常需要弃置一枚能量标记。新联邦不能与自己的其他联邦相邻。\n· 每个公共行动格每轮全桌只能使用一次。扩展对局的 QIC 行动由舰船提供。支付所示费用后，领取行动格上的收益。自由行动可在自己的回合内执行，多次执行仍不结束回合。\n被动充能:\n· 你建造或升级建筑后，在两格内拥有建筑的对手可以依次选择充能。充能量受他们在范围内最高的建筑战力和可充能量限制。第 1 点免费，之后每充 1 点支付 1 个胜利点。\n终局计分:\n· 两项终局目标均按名次授予 18、12 和 6 分。两人局加入中立目标值参与比较。\n· 每条研究轨从第 3 级起，每达到一级获得 4 分。剩余的信用点、知识和矿石每合计 3 点获得 1 分。\n扩展模式:\n· 建立房间时可以选择启用《The Lost Fleet》扩展。启用后，派系池加入 Space Giants、Moweyds、Darkanians 与 Tinkeroids，并在星图外围布置深空星区与交界区。\n· 两人局使用三艘舰船。三至四人局使用四艘舰船。把探索穿梭机停靠到舰船上时，需要从你的殖民点计算航程并支付费用，通常为 5 点胜利点；停靠后按该机位充能，同时获得这艘舰船提供的行动。\n· 每艘舰船都有三种行动，分别以 QIC、能量、知识或信用点支付，可以换取资源、推进研究、免费建矿、免费升级建筑或重复结算联邦标记等收益。Twilight 舰船上还停放着神器，弃置六枚能量标记后，可以从中选择一件并立即结算。\n· 组建联邦时，如果你的穿梭机停靠的舰船上还有金色联邦标记，你可以改取这枚金色标记。金色标记提供 12 点胜利点、一次自选科技、一次无限射程建矿或一次带 3 步免费改造的建矿。\n· 新行星规则：在小行星上建造矿场需要消耗一个盖亚改造器；在原行星上建造矿场需要 3 步地形改造。\n· Tinkeroids 每轮开始时选一张未用过的拼装片。第 1–3 轮使用第一组，第 4–6 轮使用第二组。本轮结束时移除选中的拼装片。\n· 扩展还提供新的标准科技、高级科技、强化板以及回合计分与终局计分板块，启用后一并加入对局。",
			errSeat: "你不是本局玩家。",
			errDone: "本局已经结束。",
			errPending: "请先完成当前的充能选择。",
			errPhase: "当前阶段不能执行这个行动。",
			errNotYourTurn: "还没有轮到你行动。",
			errPassed: "你已经通过，本轮不能再行动。",
			errAction: "无法识别这个行动。",
			errCharge: "现在不需要你选择充能。",
			errBooster: "强化板不可用。",
			errHex: "目标格不存在。",
			errNoPlanet: "目标格没有可以殖民的行星。",
			errOccupied: "目标格已被占用。",
			errParasite: "不能在这里放置寄生矿。",
			errSupply: "该建筑的供应已经用完。",
			errUnreachable: "航行距离不足，无法到达目标格。",
			errQic: "QIC 不足或支付数量不正确。",
			errCredits: "信用点不足。",
			errOres: "矿石不足。",
			errKnowledge: "知识不足。",
			errPower: "三区能量不足。",
			errTransdim: "盖亚改造器只能放在虚境格，且不能放在已有建筑的虚境格。",
			errGaiaformerBlock: "该盖亚行星上有其他玩家的盖亚改造器。",
			errNoGaiaformer: "没有可用的盖亚改造器，或需要先放置盖亚改造器。",
			errGaiaTrack: "盖亚研究轨尚未开启。",
			errTrackMax: "该研究轨已经到达最高等级。",
			errTrackFull: "已有其他玩家到达该研究轨的最高级。",
			errNoGreen: "抵达 5 级需要一枚翻绿的联邦标记。",
			errBaltaksNav: "没有行星研究所时不能推进航行研究轨。",
			errLostPlanet: "没有可以放置失落行星的空格，或未选择落点。",
			errUpgrade: "该建筑不能升级为所选类型。",
			errSide: "学院方位不可用。",
			errTech: "科技片不可用或条件不足。",
			errTechOwned: "你已经拥有这张科技片。",
			errTechTrack: "推进该研究轨的等级不足。",
			errTechUnavailable: "科技片已经取完。",
			errCover: "需要用这张高级科技片覆盖一张尚未被覆盖的标准科技片。",
			errUsed: "该行动本轮已经使用过。",
			errFedHex: "所选建筑不构成合法联邦。",
			errFedSatellite: "卫星只能放在没有行星的空格上。",
			errFedPower: "连接战力没有达到联邦阈值。",
			errFedToken: "没有可用的联邦标记或无法重结算。",
			errFedAdjacent: "新联邦不能与你已有的联邦相邻。",
			errFedConnected: "所选建筑与卫星没有连成一片。",
			errNoAcademy: "没有可用的学院行动。",
			errNoToken: "没有可用的联邦标记。",
			errAbility: "当前不能使用该派系能力。",
			errShuttle: "没有可用的探索穿梭机，或该舰船已有你的穿梭机、机位已满。",
			errArtifact: "该舰船上没有可取的神器，或你还没有把穿梭机停靠到 Twilight。",
			errTrack: "找不到可以推进的研究轨。",
			planetTerra: "泰拉",
			planetSwamp: "沼泽",
			planetDesert: "沙漠",
			planetOxide: "氧化物",
			planetTitanium: "钛",
			planetVolcanic: "火山",
			planetIce: "冰原",
			planetGaia: "盖亚",
			planetTransdim: "虚境",
			planetAsteroid: "小行星",
			planetProtoplanet: "原行星",
			planetLost: "失落行星",
			trackTerra: "地形改造",
			trackNav: "航行",
			trackAi: "人工智能",
			trackGaia: "盖亚",
			trackEco: "经济",
			trackSci: "科学",
			factionTerrans: "泰拉人",
			factionLantids: "兰蒂德人",
			factionTaklons: "塔克隆人",
			factionAmbas: "安巴人",
			factionGleens: "格林人",
			factionXenos: "泽诺斯人",
			factionIvits: "伊维特人",
			factionHadschHallas: "哈施哈拉人",
			factionBescods: "贝斯科德人",
			factionFiraks: "菲拉克人",
			factionGeodens: "吉奥登人",
			factionBaltaks: "巴尔塔克人",
			factionNevlas: "涅夫拉人",
			factionItars: "伊塔人",
			abilityTerrans: "盖亚阶段的盖亚区能量返回能量 II 区，而不是能量 I 区。",
			abilityLantids: "可以在其他玩家已有建筑的格上放置寄生矿；拥有行星研究所时，放置寄生矿额外获得 2 点知识。",
			abilityTaklons: "脑石可作为额外能量使用；拥有行星研究所时，每次充能额外获得 1 点能量。",
			abilityAmbas: "拥有行星研究所后，每轮可使用一次行动交换行星研究所与矿场的位置。",
			abilityGleens: "在盖亚行星上建造矿场额外获得 2 点胜利点；建立行星研究所时获得一枚格林联邦标记。",
			abilityXenos: "开局额外放置一个矿场；拥有行星研究所时，联邦阈值降为 6。",
			abilityIvits: "空间站可以放置在无行星的格上；已有联邦时，新联邦可以并入其中继续扩张。",
			abilityHadschHallas: "拥有行星研究所时，可用信用点支付获取资源的自由行动；每轮额外获得 3 点信用点。",
			abilityBescods: "每轮可执行一次行动，推进一条自己等级最低的研究轨。",
			abilityFiraks: "拥有行星研究所后，每轮可使用一次行动把实验室降为贸易站，并推进一条研究轨。",
			abilityGeodens: "拥有行星研究所时，首次在一种新的行星类型上建造矿场获得 3 点知识。",
			abilityBaltaks: "没有行星研究所时不能推进航行研究轨；可使用行动把盖亚改造器送回盖亚区并换取 1 点 QIC；右学院奖励改为 4 点信用点。",
			abilityNevlas: "拥有行星研究所时，III 区的每个能量标记当作 2 点能量使用；可使用行动支付 1 点盖亚能量换取 1 点知识。",
			abilityItars: "燃烧能量时，将弃置的标记移入盖亚区。拥有行星研究所后，可以在盖亚阶段每弃置 4 枚盖亚区标记，取得一张科技板。",
			techPower4: "能量行动",
			techPower4Desc: "每轮一次：获得 4 点能量。",
			techOreQic: "矿石与 QIC",
			techOreQicDesc: "立即获得 1 点矿石与 1 点 QIC。",
			techKnwTypes: "类型知识",
			techKnwTypesDesc: "立即按已知行星类型数量获得等量知识。",
			tech7vp: "七分",
			tech7vpDesc: "立即获得 7 点胜利点。",
			techIncOrePow: "矿石与能量收入",
			techIncOrePowDesc: "收入阶段额外获得 1 点矿石与 1 点能量。",
			techIncKnwC: "知识与信用点收入",
			techIncKnwCDesc: "收入阶段额外获得 1 点知识与 1 点信用点。",
			techInc4c: "信用点收入",
			techInc4cDesc: "收入阶段额外获得 4 点信用点。",
			techBig4pow: "大型建筑战力",
			techBig4powDesc: "行星研究所与学院的战力视为 4。",
			techGaia3vp: "盖亚建造",
			techGaia3vpDesc: "每次在盖亚行星上建造矿场获得 3 点胜利点。",
			advQic5c: "QIC 与信用点行动",
			advQic5cDesc: "每轮一次：获得 1 点 QIC 与 5 点信用点。",
			advOre3: "矿石行动",
			advOre3Desc: "每轮一次：获得 3 点矿石。",
			advKnw3: "知识行动",
			advKnw3Desc: "每轮一次：获得 3 点知识。",
			advMine2: "矿场计分",
			advMine2Desc: "立即每座矿场获得 2 点胜利点。",
			advTs4: "贸易站计分",
			advTs4Desc: "立即每座贸易站获得 4 点胜利点。",
			advFed5: "联邦计分",
			advFed5Desc: "立即每枚联邦标记获得 5 点胜利点。",
			advSector2: "星区计分",
			advSector2Desc: "每有一个建有你建筑的星区，立即获得 2 点胜利点。",
			advGaia2: "盖亚计分",
			advGaia2Desc: "立即每颗盖亚行星获得 2 点胜利点。",
			advSector1o: "星区矿石",
			advSector1oDesc: "每有一个建有你建筑的星区，立即获得 1 枚矿石。",
			advPassFed3: "联邦通过计分",
			advPassFed3Desc: "通过时每枚联邦标记获得 3 点胜利点。",
			advPassRl3: "研究所通过计分",
			advPassRl3Desc: "通过时每座研究所获得 3 点胜利点。",
			advPassType1: "类型通过计分",
			advPassType1Desc: "通过时每种已知行星类型获得 1 点胜利点。",
			advRes2vp: "研究计分",
			advRes2vpDesc: "每次推进研究额外获得 2 点胜利点。",
			advMine3: "矿场建造计分",
			advMine3Desc: "每次建造矿场额外获得 3 点胜利点。",
			advTs3: "贸易站升级计分",
			advTs3Desc: "每次升级为贸易站额外获得 3 点胜利点。",
			boostOreKnw: "矿石与知识",
			boostOreKnwDesc: "收入：1 点矿石、1 点知识。",
			boostTokensOre: "能量标记与矿石",
			boostTokensOreDesc: "收入：2 个能量标记、1 点矿石。",
			boostCreditsQic: "信用点与 QIC",
			boostCreditsQicDesc: "收入：2 点信用点、1 点 QIC。",
			boostTerraformCredits: "免费改造",
			boostTerraformCreditsDesc: "收入：2 点信用点。行动：地形改造步数减少 1 步并建造矿场。",
			boostRangePower: "远程航行",
			boostRangePowerDesc: "收入：2 点能量。行动：航行距离增加 3 并建造矿场，或增加 3 后进行盖亚改造。",
			boostMineOre: "矿场收入",
			boostMineOreDesc: "收入：1 点矿石。通过时每座矿场获得 1 点胜利点。",
			boostTsOre: "贸易站收入",
			boostTsOreDesc: "收入：1 点矿石。通过时每座贸易站获得 2 点胜利点。",
			boostRlKnw: "研究所收入",
			boostRlKnwDesc: "收入：1 点知识。通过时每座研究所获得 3 点胜利点。",
			boostBigPower: "大型建筑收入",
			boostBigPowerDesc: "收入：4 点能量。通过时每座行星研究所与学院获得 4 点胜利点。",
			boostGaiaCredits: "盖亚收入",
			boostGaiaCreditsDesc: "收入：4 点信用点。通过时每颗盖亚行星获得 1 点胜利点。",
			scoreTerra2: "每步地形改造 2 分",
			scoreResearch2: "每次推进研究 2 分",
			scoreMine2: "建造矿场 2 分",
			scoreTs3: "升级贸易站 3 分",
			scoreTs4: "升级贸易站 4 分",
			scoreGaia3: "盖亚改造 3 分",
			scoreGaia4: "盖亚改造 4 分",
			scoreBig5: "研究所或学院 5 分",
			scoreFederation5: "组建联邦 5 分",
			scoreLfSector: "新星区 3 分",
			scoreLfType: "新行星类型 3 分",
			scoreLfRl: "研究所 4 分",
			finalFedBuildings: "联邦中的建筑",
			finalBuildings: "建筑总数",
			finalTypes: "行星类型",
			finalGaiaPlanets: "盖亚行星",
			finalSectors: "星区数",
			finalSatellites: "卫星",
			finalLfAsteroids: "小行星",
			finalLfPiAcademy: "研究所与学院距离",
			finalLfOuterSectors: "外环星区",
			fedKnowledge: "知识标记",
			fedKnowledgeDesc: "立即获得 2 点知识，计 6 分。",
			fedCredits: "信用点标记",
			fedCreditsDesc: "立即获得 6 点信用点，计 7 分。",
			fedOres: "矿石标记",
			fedOresDesc: "立即获得 2 点矿石，计 7 分。",
			fedPower: "能量标记",
			fedPowerDesc: "立即获得 2 个能量标记，计 8 分。",
			fedQic: "QIC 标记",
			fedQicDesc: "立即获得 1 点 QIC，计 8 分。",
			fedPoints: "纯分标记",
			fedPointsDesc: "立即获得 12 点胜利点。",
			fedGleens: "格林标记",
			fedGleensDesc: "立即获得 1 点矿石、1 点知识与 2 点信用点，不计分。",
			powerKnw3: "知识行动",
			powerKnw3Desc: "支付 7 点能量，获得 3 点知识。",
			powerTerra2: "双重改造",
			powerTerra2Desc: "支付 5 点能量，免费地形改造 2 步并建造矿场。",
			powerOre2: "矿石行动",
			powerOre2Desc: "支付 4 点能量，获得 2 点矿石。",
			powerCredits7: "信用点行动",
			powerCredits7Desc: "支付 4 点能量，获得 7 点信用点。",
			powerKnw2: "知识行动",
			powerKnw2Desc: "支付 4 点能量，获得 2 点知识。",
			powerTerra1: "改造",
			powerTerra1Desc: "支付 3 点能量，免费地形改造 1 步并建造矿场。",
			powerTokens2: "能量标记行动",
			powerTokens2Desc: "支付 3 点能量，获得 2 个能量标记。",
			qicTech: "科技行动",
			qicTechDesc: "支付 4 点 QIC，取得一张科技片。",
			qicRescore: "重结算",
			qicRescoreDesc: "支付 3 点 QIC，再次结算一枚联邦标记的奖励。",
			qicTypes: "类型计分",
			qicTypesDesc: "支付 2 点 QIC，按已知行星类型数量计分。",
			freeBurn: "燃烧能量",
			freeBurnDesc: "把 2 点能量 II 推入能量 III。",
			freePowQic: "能量换 QIC",
			freePowQicDesc: "支付 4 点能量，获得 1 点 QIC。",
			freePowOre: "能量换矿石",
			freePowOreDesc: "支付 3 点能量，获得 1 点矿石。",
			freeQicOre: "QIC 换矿石",
			freeQicOreDesc: "支付 1 点 QIC，获得 1 点矿石。",
			freePowKnw: "能量换知识",
			freePowKnwDesc: "支付 4 点能量，获得 1 点知识。",
			freePowCredit: "能量换信用点",
			freePowCreditDesc: "支付 1 点能量，获得 1 点信用点。",
			freeKnwCredit: "知识换信用点",
			freeKnwCreditDesc: "支付 1 点知识，获得 1 点信用点。",
			freeOreCredit: "矿石换信用点",
			freeOreCreditDesc: "支付 1 点矿石，获得 1 点信用点。",
			freeOrePower: "矿石换能量",
			freeOrePowerDesc: "支付 1 点矿石，获得 1 个能量标记。",
			buildingMine: "矿场",
			buildingTs: "贸易站",
			buildingRl: "研究所",
			buildingPi: "行星研究所",
			buildingAc: "学院",
			sideLeft: "左侧",
			sideRight: "右侧",
			roundN: "第 {{n}} 轮",
			roundScoring: "本轮计分",
			finalScoring: "终局计分",
			turnYou: "你的回合",
			turnOther: "{{name}} 行动",
			turnWaiting: "等待 {{name}}",
			passedTag: "已通过",
			draftPhase: "轮抽强化板",
			chargePhase: "被动充能",
			donePhase: "对局结束",
			resVP: "胜利点",
			resCredits: "信用点",
			resOres: "矿石",
			resKnowledge: "知识",
			resQic: "QIC",
			resPower: "能量",
			resPowerI: "能量 I",
			resPowerII: "能量 II",
			resPowerIII: "能量 III",
			resPowerTokens: "能量标记",
			resGaiaPower: "盖亚能量",
			resBrain: "脑石",
			resGaiaformers: "盖亚改造器",
			resTypes: "行星类型",
			resFederation: "联邦标记",
			actBuild: "建造",
			actUpgrade: "升级",
			actGaia: "盖亚改造",
			actResearch: "研究",
			actFederation: "联邦",
			actActions: "行动",
			actPass: "通过",
			actInfo: "局面",
			actLog: "日志",
			actClose: "关闭",
			actCancel: "取消",
			actConfirm: "确认",
			hintIdle: "点选行星查看建造费用，或选择一项行动。",
			hintBuild: "选择一颗行星格建造矿场。",
			hintUpgrade: "选择你的建筑进行升级。",
			hintGaia: "选择虚境格放置盖亚改造器。",
			hintNotTurn: "等待其他玩家行动。",
			hintCharge: "先完成充能选择。",
			hintDraft: "选择一块强化板。",
			hintDraftWait: "等待其他玩家轮抽。",
			hintSelectBuild: "点按发光的格子确认建造目标。",
			hintSelectUpgrade: "点按发光的建筑查看可升级类型。",
			hintSelectGaia: "点按发光的虚境格确认盖亚改造。",
			hintSelectStation: "点按发光的无行星格确认放置空间站。",
			hintResearchNav: "选择一个高亮的空格，确认失落行星的位置和航程费用。",
			mapTitle: "星系版图",
			mapZoomIn: "放大",
			mapZoomOut: "缩小",
			mapFit: "全图",
			mapFocus: "定位己方建筑",
			mapSector: "星区 {{id}}",
			mapOuterSector: "外环星区 {{id}}",
			mapOuter: "外环",
			mapEmptyCell: "空置格",
			mapSelected: "已选中",
			mapLegal: "合法目标",
			mapCardTitle: "格子详情",
			mapNoActions: "这个格子当前没有可用行动。",
			mapOwner: "归属",
			mapBuilding: "建筑",
			mapFederation: "联邦",
			mapSatellite: "卫星",
			mapStation: "空间站",
			mapLostPlanet: "失落行星",
			mapArtifact: "神器",
			mapGaiaformer: "盖亚改造器",
			mapParasite: "寄生矿",
			mapPowerLabel: "战力 {{n}}",
			buildCost: "费用",
			buildCostCredits: "{{n}} 信用点",
			buildCostOres: "{{n}} 矿石",
			buildCostQic: "{{n}} QIC",
			buildCostSteps: "改造 {{n}} 步",
			buildCostFree: "其中 {{n}} 步免费",
			buildAction: "建造矿场",
			buildCostTitle: "建造费用",
			buildNoCost: "无需支付资源",
			buildTerraformDetail: "地形改造 {{steps}} 步，每步消耗 {{ore}} 矿石。",
			upgradeAction: "升级为{{building}}",
			gaiaAction: "放置盖亚改造器",
			gaiaPowerCost: "{{n}} 点能量",
			upgradeTechHint: "升级后选择一张科技片。",
			techTitle: "选择科技片",
			techStandard: "标准科技片",
			techAdvanced: "高级科技片",
			techFleetAdvanced: "舰队高级科技",
			techFleetRequirementPoints: "需要至少 25 点胜利点。",
			techFleetRequirementShips: "需要至少 25 点胜利点，或已探索三艘不同的舰船。",
			gaiaPhaseTitle: "盖亚阶段",
			gaiaPhaseItars: "每弃置 4 枚盖亚区能量标记，可以取得一张科技板。",
			gaiaPhaseFinish: "结束盖亚阶段",
			tinkerPickTitle: "选择拼装片",
			guideRange: "每跨过一条相邻六边格的共用边，航程就增加一格。每支付 1 点 QIC，可将本次行动的航程延伸两格。达到航行第 5 级时，在可达的空格上放置失落行星。它的矿场同时计入行星类型和占领星区目标。",
			guideTrackTech: "要取得某条研究轨上的高级科技板，你必须在该轨达到第 4 级或第 5 级。",
			guideFleetTech: "取得《The Lost Fleet》的额外高级科技板需要至少 25 点胜利点。三至四人局中，已探索三艘不同舰船也符合条件。",
			guideTechAdvance: "取得高级科技板后，你可以选择推进一条符合条件的研究轨。若借此升至第 5 级，须再翻面一枚绿色联邦标记。",
			guideRoundDecisions: "行动阶段前的决策",
			guideItars: "拥有行星研究所的伊塔人，可以在返还能量之前，每弃置 4 枚盖亚区标记取得一张科技板。",
			guideTinkeroids: "Tinkeroids 即使没有执行选中拼装片的行动，也要在轮末移除这张片。以后各轮都不能再次选择它。",
			techAdvancedRequires: "翻面一枚绿色联邦标记并覆盖一张标准科技板，随后可以选择推进一条符合条件的研究轨。",
			techCoverLabel: "选择要覆盖的标准科技片",
			techPickCover: "先选择高级科技片，再选择要覆盖的科技片。",
			techCovered: "已覆盖",
			techTrackPick: "选择要推进的研究轨",
			techEmpty: "没有可取得的科技片。",
			techSlotEmpty: "空槽",
			boardResource: "{{name}} {{n}}",
			techIndependent: "自由科技",
			techRemaining: "剩余 {{n}} 枚",
			techAcquireQic: "支付 {{n}} QIC 获取",
			researchTitle: "研究轨",
			researchHint: "支付 {{n}} 点知识，沿一条研究轨推进一级。",
			researchLevel: "等级 {{n}}",
			researchPayAdvance: "支付 {{n}} 知识并推进",
			researchOreRate: "每步地形改造消耗 {{n}} 矿石。",
			researchGainOre: "推进时获得 {{n}} 矿石。",
			researchGainTokens: "推进时获得 {{n}} 枚能量标记。",
			researchChargePower: "推进时充能 {{n}} 点。",
			researchGainQic: "推进时获得 {{n}} QIC。",
			researchGainFederation: "推进时获得联邦标记「{{name}}」。",
			researchGainFormer: "推进时获得一个盖亚改造器。",
			researchRange: "基础航行距离为 {{n}}。",
			researchGaiaScore: "推进时获得 4 分，每个己方已殖民的盖亚行星再获得 1 分。",
			researchEconomyIncome: "每轮收入为 {{credits}} 信用点、{{ores}} 矿石和 {{power}} 点充能。",
			researchEconomyTop: "推进时获得 6 信用点和 3 矿石，并充能 6 点。",
			researchScienceIncome: "每轮获得 {{n}} 知识。",
			researchScienceTop: "推进时获得 9 知识。",
			researchAdvance: "推进",
			researchBlocked: "条件不足",
			researchMax: "已满级",
			researchOwned: "当前科技片",
			researchNone: "尚未取得科技片。",
			federationTitle: "组建联邦",
			federationBuildings: "{{n}} 座建筑或殖民据点",
			federationSatellites: "{{n}} 颗卫星",
			federationPowerCost: "弃置 {{n}} 枚能量标记",
			federationQicCost: "支付 {{n}} QIC",
			federationHint: "选择一组连通的建筑，战力达到 {{n}} 即可取得一枚联邦标记。",
			federationPower: "战力 {{n}}",
			federationNeed: "还差 {{n}} 战力",
			federationMerge: "并入现有联邦，还差 {{n}} 战力",
			federationToken: "联邦标记",
			federationConfirm: "组建联邦",
			federationEmpty: "当前没有可组建的联邦。",
			federationOwned: "已有标记",
			federationBase: "联邦阈值 {{n}}",
			fedPickCluster: "在星图上点按一组发光的建筑。",
			fedSelected: "已选建筑",
			rescoreTitle: "重结算联邦标记",
			noTargets: "当前没有可用目标。",
			actionsTitle: "行动与能力",
			actionsPowerBoard: "能量行动",
			actionsQicBoard: "QIC 行动",
			actionsPersonal: "派系与板块能力",
			actionsSpent: "本轮已用",
			actionsLowPower: "可用能量不足",
			actionsLowQic: "QIC 不足",
			actionsPower: "能量行动",
			actionsQic: "QIC 行动",
			actionsFree: "自由行动",
			actionsTech: "科技行动",
			actionsFaction: "派系能力",
			actionsBooster: "强化板行动",
			actionsAcademy: "学院行动",
			actionsCostPower: "{{n}} 能量",
			actionsCostQic: "{{n}} QIC",
			actionsUsePower: "用能量支付",
			actionsUseCredits: "用信用点支付",
			actionsUsed: "本轮已使用",
			actionsUnavailable: "当前不可用",
			factionSwapPI: "交换行星研究所与矿场",
			factionDowngradeRL: "降为贸易站并推进{{track}}",
			factionDowngradeRLShort: "降为贸易站并推进研究轨",
			factionAdvanceLowest: "推进最低研究轨",
			factionItarsTech: "用盖亚能量取得科技片",
			factionBaltaqGaiaformer: "盖亚改造器换 QIC",
			factionNevlasKnowledge: "盖亚能量换知识",
			factionSpaceStation: "放置空间站",
			factionAbility: "派系能力",
			boosterAction: "使用强化板",
			academyAction: "取得学院奖励",
			academyHint: "每轮一次：右学院提供免费奖励。",
			passTitle: "通过",
			passHint: "结束本轮行动，下一轮开始时取得收入。",
			passFirst: "你将是本轮第一个通过的玩家，取得先手标记。",
			passChooseBooster: "选择下一轮强化板",
			passNeedBooster: "第 1 至 5 轮通过时，必须选择一块下一轮使用的强化板。",
			passPoints: "通过立即获得 {{n}} 点胜利点。",
			passConfirm: "确认通过",
			passLastRound: "第 6 轮通过后将直接进入终局计分。",
			chargeTitle: "被动充能",
			chargeHint: "你可以获得 {{power}} 点能量，并失去 {{vp}} 点胜利点。",
			chargeTake: "充能",
			chargeSkip: "不充能",
			draftTitle: "轮抽强化板",
			draftHint: "选择一块强化板，收入阶段开始时生效。",
			draftWaiting: "等待其他玩家完成轮抽。",
			infoTitle: "局面",
			infoRoundTiles: "回合计分",
			infoFinalTiles: "终局计分",
			infoResearch: "研究等级",
			infoResources: "资源",
			infoBuildings: "建筑",
			infoTechs: "科技片",
			infoFedTokens: "联邦标记",
			infoFaction: "派系",
			infoUsedActions: "本轮已用行动",
			infoUsedPower: "能量行动",
			infoUsedQic: "QIC 行动",
			infoUsedTiles: "科技行动",
			infoIncome: "收入预览",
			infoBooster: "强化板",
			infoFedSupply: "联邦标记供应",
			infoArtifacts: "神器",
			infoNone: "无",
			infoLog: "日志",
			logTitle: "对局日志",
			logEmpty: "暂无记录。",
			logSetup: "{{faction}} 加入对局",
			logCharge: "完成充能",
			logDraft: "轮抽强化板",
			logParasite: "放置寄生矿",
			logBuild: "建造矿场",
			logGaia: "放置盖亚改造器",
			logUpgrade: "升级建筑",
			logTech: "取得科技片：{{name}}",
			logResearch: "推进{{track}}至 {{n}} 级",
			logLostPlanet: "放置失落行星",
			logFederation: "组建联邦",
			logFedToken: "取得联邦标记：{{name}}",
			logPower: "使用能量行动：{{name}}",
			logQic: "使用 QIC 行动：{{name}}",
			logFree: "执行自由行动：{{name}}",
			logUseTile: "使用科技行动：{{name}}",
			logAcademy: "取得学院奖励",
			logFaction: "使用派系能力",
			logPass: "通过",
			logRound: "第 {{n}} 轮开始",
			logGameEnd: "对局结束",
			overTitle: "终局计分",
			overRankings: "总分排名",
			overObjectives: "终局目标",
			overCompetitor: "参评者",
			overCount: "数量",
			overDistance: "距离",
			overAwardPoints: "得分",
			overWinner: "获胜",
			overTotal: "总分",
			overScoreItem: "计分项",
			overGhost: "幽灵对手",
			overRank: "第 {{n}} 名",
			overReview: "查看星图",
			overBack: "返回计分",
			overWaitHost: "等待主机选择是否重开。",
			overDetail: "明细",
			confirmAgain: "确认重开",
			confirmLobby: "确认返回",
			metricFedBuildings: "联邦中的建筑",
			metricBuildings: "建筑总数",
			metricTypes: "行星类型",
			metricGaia: "盖亚行星",
			metricSectors: "星区数",
			metricSatellites: "卫星与空间站",
			metricAsteroids: "小行星",
			metricPiAcademy: "研究所与学院距离",
			metricOuterSectors: "外环星区",
			metricResearch: "研究",
			metricResources: "资源",
			metricVp: "对局中胜利点",
			metricAwards: "终局板块",
			optionsLostFleet: "The Lost Fleet 扩展",
			optionsLostFleetHint: "加入四个扩展派系、舰船板与探索、金色联邦、深空外环与新增计分板。",
			experimentLabel: "The Lost Fleet 扩展",
			chargeWait: "等待 {{name}} 选择充能",
			playerPassed: "{{name}} 已通过",
			useCount: "本轮 {{n}} 次",
			soloGhost: "双人对局会加入中立目标值参与终局名次。",
			factionSpaceGiants: "Space Giants",
			factionMoweyds: "Moweyds",
			factionDarkanians: "Darkanians",
			factionTinkeroids: "Tinkeroids",
			abilitySpaceGiants: "开局只放置 1 个矿场而不放置 2 个矿场。改造标准行星固定需要 2 步地形改造；探索板上拥有一次“建造矿场”行动，可免费进行 2 步地形改造；改造为盖亚行星需要支付 2 点 QIC。行星研究所：开局时立即取得一张自选科技片，此能力只能使用一次。",
			abilityMoweyds: "开局只放置 1 个矿场而不放置 2 个矿场，并在 T F Mars 舰船上放置一个探索穿梭机。三种基础行星类型需要 3 步地形改造，其余基础行星类型需要 1 步。行星研究所：每轮一次，可执行行动，在自己已有建筑的星球上放置能量环（该星球尚无能量环），该建筑的战斗力增加 2。",
			abilityDarkanians: "开局只放置 1 个矿场而不放置 2 个矿场。改造标准行星只需 1 步地形改造，改造为盖亚行星需要支付 2 点 QIC。行星研究所：首次在某个星区或深空星区殖民星球时，获得 2 点信用点与 1 点知识；交界区不算星区。",
			abilityTinkeroids: "开局以行星研究所代替 2 个矿场，并在第二阶段放置。三种基础行星类型需要 3 步地形改造，其余基础行星类型需要 1 步；改造为盖亚行星需要支付 2 点 QIC。拼装片共 6 张，第 1–3 轮使用其中 3 张，第 4–6 轮使用另外 3 张，每轮开始时从对应组中选择一张未用过的拼装片，轮末移除这张片。行星研究所：每轮一次，可执行行动，使用当前拼装片上的行动。",
			shipEclipse: "Eclipse",
			shipTwilight: "Twilight",
			shipTfMars: "T F Mars",
			shipRebellion: "Rebellion",
			lfExplore: "探索舰船",
			lfExamine: "检视遗物",
			lfShuttles: "探索穿梭机",
			lfArtifacts: "遗物",
			lfAlliance: "金色联邦",
			artifactVpMine: "遗物：7 分",
			artifactVpTerra: "遗物：地形改造研究",
			artifactVpNav: "遗物：航行研究",
			artifactVpAi: "遗物：人工智能研究",
			artifactVpGaia: "遗物：盖亚研究",
			artifactVpEco: "遗物：经济研究",
			artifactVpSci: "遗物：科学研究",
			artifactVpArea3: "遗物：研究领域",
			artifactPowerIncome: "遗物：能量收入",
			artifactResources: "遗物：资源",
			tinkerMine3: "拼装片：免费 3 步改造",
			tinkerKnw3: "拼装片：3 知识",
			tinkerQic2: "拼装片：2 QIC",
			tinkerQic1: "拼装片：1 QIC",
			tinkerCharge4: "拼装片：充能 4",
			tinkerMine1: "拼装片：免费 1 步改造",
			goldPoints: "金色联邦：12 分",
			goldMineRange: "金色联邦：无限射程建矿",
			goldTech: "金色联邦：自选科技",
			goldMine3: "金色联邦：免费 3 步改造",
			lfMine2free: "免费建矿（2 步改造）",
			lfMine2freeDesc: "立即执行一次“建造矿场”行动，最多免费进行 2 步地形改造且无需支付建造成本；可额外支付矿石进行第 3 步改造，并可支付 QIC 增加射程。",
			lfPiDsVp: "研究所、学院与深空星区",
			lfPiDsVpDesc: "立即按自己的行星研究所、每座学院，以及已殖民至少一颗行星的每个深空星区获得胜利点。",
			lfRange1: "射程 +1",
			lfRange1Desc: "基础射程永久增加 1，直到此片被高级科技片覆盖。",
			lfASector4: "星区 4 分",
			lfASector4Desc: "立即按每个已殖民的星区获得 4 点胜利点。",
			lfAFlat9: "九分",
			lfAFlat9Desc: "立即获得 9 点胜利点。",
			lfAPassAsteroid2: "通过：小行星",
			lfAPassAsteroid2Desc: "每次通过时，按已殖民的小行星获得 2 点胜利点。",
			lfAPassDs2: "通过：深空星区",
			lfAPassDs2Desc: "每次通过时，按已殖民至少一颗行星的每个深空星区获得 2 点胜利点。",
			lfAGaia4: "盖亚行星 4 分",
			lfAGaia4Desc: "立即按已殖民的每颗盖亚行星获得 4 点胜利点。",
			lfAOreIncome2: "矿石收入",
			lfAOreIncome2Desc: "收入阶段额外获得 2 点矿石。",
			lfBGaiaformers: "通过：盖亚改造器",
			lfBGaiaformersDesc: "收入：1 点矿石。通过时，按自己的每个盖亚改造器获得 3 点胜利点（用于小行星殖民的除外）。",
			lfBTypes: "通过：行星类型",
			lfBTypesDesc: "收入：3 点信用点。通过时，按已殖民的每种行星类型获得 1 点胜利点。",
			lfBDsSectors: "通过：深空星区",
			lfBDsSectorsDesc: "收入：2 点能量。通过时，按已殖民至少一颗行星的每个深空星区获得 2 点胜利点。",
			lfBGaiaFree: "免费盖亚改造",
			lfBGaiaFreeDesc: "收入：1 点矿石。每轮一次，无需将能量移入盖亚区即可执行一次“开始盖亚计划”，并立即把跨维行星改造为盖亚行星。",
			actShips: "舰船",
			shipsTitle: "舰船与探索",
			shipsEmpty: "本局未启用舰船。",
			shipDock: "停靠点 {{hex}}",
			lfExploreHint: "放置探索穿梭机后，舰船按槽位充能，你可在该舰船上执行舰船行动。",
			lfExamineHint: "弃置六枚能量标记，从 Twilight 选择并领取一件遗物。",
			lfBrainstoneCost: "将脑石移入盖亚区",
			shipRewardVpPerType: "按行星类型得分",
			shipRewardAdvanceResearch: "推进研究",
			shipRewardFreeAsteroidMine: "免费殖民小行星",
			shipRewardRepeatFed: "重复联邦标记奖励",
			shipRewardFreeUpgradeRl: "免费升级为研究所",
			shipRewardRange3: "射程 +3 建矿",
			shipRewardStandardTech: "取舰船科技",
			shipRewardGaiaProject: "免费盖亚改造",
			shipRewardFreeMine1: "建矿（免费 1 步改造）",
			shipRewardTech: "自选科技",
			shipRewardFreeUpgradeTs: "免费升级为贸易中心",
			shipRewardCreditsQic: "获得信用点与 QIC",
			factionSpaceGiantsTech: "行星研究所：取得科技",
			factionGiantsMine: "建造矿场（最多免费改造 2 步）",
			factionMoweydRing: "行星研究所：放置能量环",
			factionTinkerAction: "行星研究所：使用拼装片",
			hintSelectRing: "点按自己建筑所在、尚无能量环的星球放置能量环。",
			goldTechHint: "选择一张要取得的科技片。",
			goldMineRangeHint: "点按任意可建造的星球，免费建造矿场且射程不受限制。",
			goldMine3Hint: "点按可建造的星球，免费建造矿场并进行至多 3 步地形改造。",
			resShuttles: "探索穿梭机",
			infoLostFleet: "失落舰队",
			infoLfTerra: "三步行星类型",
			infoPowerRings: "能量环",
			infoTinkerTile: "当前拼装片",
			logExplore: "在 {{ship}} 放置探索穿梭机",
			logArtifact: "取得{{name}}",
			logShipAction: "舰船行动：{{name}}"
		},
		en: {
			name: "Gaia Project",
			desc: "Terraform planets, build federations and climb six research tracks in a contest for the galaxy",
			rules: "This game supports 2–4 players. Earn victory points by settling planets, upgrading buildings, advancing research and forming federations. The player with the most points after six rounds wins.\nSetup:\n· The game deals each player a faction and places its starting buildings on home planets. Ivits begin with one planetary institute. Xenos begin with three mines. Other factions begin with two mines.\n· Draft boosters in reverse seat order, then collect the first round’s income.\nRound structure:\n· During income, collect the benefits provided by your faction, buildings, research, booster and technology tiles. During the Gaia phase, return tokens from the Gaia area to your power cycle as specified by your faction and finish Gaia projects started in the previous round.\n· Take turns during the action phase. When you pass, stop taking actions for the round and, in rounds one through five, claim a booster for the next round. The first player to pass goes first next round. After everyone passes, begin the next round or score the game if round six has ended.\nActions:\n· To build a mine, select a reachable planet and pay the construction cost in credits and ore. Pay ore for any terraforming steps and spend QIC if you need to extend your range.\n· To start a Gaia project, place an available Gaiaformer on a reachable Transdim planet and move the required number of power tokens to the Gaia area.\n· Upgrade a mine to a trading station, a trading station to a planetary institute or research lab, or a research lab to an academy. Building a research lab or an academy grants a technology tile. When you take an advanced tile, flip a green federation token and cover one of your standard tiles. You may then advance on an eligible research track of your choice.\n· Spend 4 knowledge to advance one level on a research track. To reach level 5, flip a green federation token. Only one player can occupy level 5 of each track. Whenever you reach Navigation level 5, choose a reachable empty hex for the Lost Planet.\n· To form a federation, connect buildings and satellites that meet the required power and take a federation token. Each satellite occupies an empty hex and usually costs one discarded power token. A new federation cannot border another of your federations.\n· Each shared action space can be used once per round. In expansion games, QIC actions are available on spaceships. Pay the cost shown to receive its benefit. You can take multiple free actions on your turn without ending it.\nPassive charging:\n· When you build or upgrade, opponents with a building within two hexes may choose to charge. The offer is limited by their highest building power in range and by how much they can charge. The first charge is free. Each additional charge costs 1 victory point.\nFinal scoring:\n· Each final objective awards 18, 12 and 6 points by rank. In a two-player game, a neutral benchmark also competes for these awards.\n· Earn 4 points for each research level reached from level 3 onward. Earn 1 point for every 3 leftover credits, knowledge and ore combined.\nExpansion Mode:\n· You can enable The Lost Fleet expansion when creating a room. When enabled, the faction pool adds Space Giants, Moweyds, Darkanians and Tinkeroids, and the board gains deep space sectors and interspace tiles around the outer edge.\n· Use three spaceships in a two-player game and four spaceships in a three- or four-player game. To dock an exploration shuttle on a spaceship, measure the range from one of your colonies and pay the cost, usually 5 victory points. Docking charges power for that slot and unlocks the actions printed on that spaceship.\n· Each spaceship offers three actions paid with QIC, power, knowledge or credits, granting resources, research advancement, free mines, free upgrades or a repeat of a federation token. The Twilight spaceship also holds artifacts. Discard six power tokens to choose and resolve one of them.\n· When you form a federation and one of your shuttles is on a spaceship that still holds a gold-outlined federation token, you may take that gold token instead. It grants 12 victory points, a tech of your choice, a limitless-range mine, or a mine with up to 3 free terraforming steps.\n· New planet rules: building a mine on an asteroid consumes a Gaiaformer, and building a mine on a protoplanet requires 3 terraforming steps.\n· Tinkeroids choose an unused Tinkering tile at the start of each round. Use the first set in rounds 1–3 and the second set in rounds 4–6. Remove the chosen tile at the end of the round.\n· The expansion also adds new standard and advanced techs, boosters, and round and final scoring tiles, which join the game when enabled.",
			errSeat: "You are not in this game.",
			errDone: "This game is already over.",
			errPending: "Finish the current charging decision first.",
			errPhase: "You cannot take this action in the current phase.",
			errNotYourTurn: "It is not your turn yet.",
			errPassed: "You have passed and cannot act again this round.",
			errAction: "Unrecognized action.",
			errCharge: "You do not need to choose charging now.",
			errBooster: "That booster tile is not available.",
			errHex: "The target space does not exist.",
			errNoPlanet: "The target space has no planet to settle.",
			errOccupied: "The target space is already occupied.",
			errParasite: "You cannot place a parasite mine here.",
			errSupply: "You have no building of that type left in supply.",
			errUnreachable: "Navigation range is insufficient to reach the target space.",
			errQic: "Not enough QIC, or the amount paid is incorrect.",
			errCredits: "Not enough credits.",
			errOres: "Not enough ore.",
			errKnowledge: "Not enough knowledge.",
			errPower: "Not enough power in area III.",
			errTransdim: "Terraformers go on transdimensional spaces without buildings.",
			errGaiaformerBlock: "Another player’s terraformer is on this Gaia planet.",
			errNoGaiaformer: "No terraformer is available, or one must be placed first.",
			errGaiaTrack: "The Gaia research track is not open yet.",
			errTrackMax: "That research track is already at its maximum level.",
			errTrackFull: "Another player has already reached the top of that research track.",
			errNoGreen: "Reaching level 5 requires a flipped federation token.",
			errBaltaksNav: "You cannot advance navigation without a planetary institute.",
			errLostPlanet: "There is no empty space for a lost planet, or none is selected.",
			errUpgrade: "This building cannot be upgraded to the chosen type.",
			errSide: "That academy side is not available.",
			errTech: "The technology tile is unavailable or its requirements are not met.",
			errTechOwned: "You already own that technology tile.",
			errTechTrack: "Your level on that research track is too low.",
			errTechUnavailable: "No copies of that technology tile remain.",
			errCover: "An advanced tile must cover a standard technology tile you have not covered yet.",
			errUsed: "That action has already been used this round.",
			errFedHex: "The selected buildings do not form a valid federation.",
			errFedSatellite: "Satellites may only be placed on spaces without planets.",
			errFedPower: "The connected power does not reach the federation threshold.",
			errFedToken: "No federation token is available, or it cannot be re-scored.",
			errFedAdjacent: "A new federation may not be adjacent to one of yours.",
			errFedConnected: "The selected buildings and satellites are not connected.",
			errNoAcademy: "No academy action is available.",
			errNoToken: "No federation token is available.",
			errAbility: "That faction ability cannot be used now.",
			errShuttle: "No exploration shuttle is available, or this ship already has your shuttle or no free slot.",
			errArtifact: "There is no artifact to take there, or you have not docked a shuttle on Twilight.",
			errTrack: "No research track can be advanced.",
			planetTerra: "Terra",
			planetSwamp: "Swamp",
			planetDesert: "Desert",
			planetOxide: "Oxide",
			planetTitanium: "Titanium",
			planetVolcanic: "Volcanic",
			planetIce: "Ice",
			planetGaia: "Gaia",
			planetTransdim: "Transdim",
			planetAsteroid: "Asteroid",
			planetProtoplanet: "Protoplanet",
			planetLost: "Lost Planet",
			trackTerra: "Terraforming",
			trackNav: "Navigation",
			trackAi: "AI",
			trackGaia: "Gaia",
			trackEco: "Economy",
			trackSci: "Science",
			factionTerrans: "Terrans",
			factionLantids: "Lantids",
			factionTaklons: "Taklons",
			factionAmbas: "Ambas",
			factionGleens: "Gleens",
			factionXenos: "Xenos",
			factionIvits: "Ivits",
			factionHadschHallas: "Hadsch Hallas",
			factionBescods: "Bescods",
			factionFiraks: "Firaks",
			factionGeodens: "Geodens",
			factionBaltaks: "Baltaks",
			factionNevlas: "Nevlas",
			factionItars: "Itars",
			abilityTerrans: "Gaia-phase power returns to area II instead of area I.",
			abilityLantids: "You may place parasite mines on spaces with other players’ buildings; with a planetary institute, placing one also grants 2 knowledge.",
			abilityTaklons: "The brainstone counts as extra power; with a planetary institute, each charging also grants 1 power.",
			abilityAmbas: "With a planetary institute, once per round you may swap your institute and a mine.",
			abilityGleens: "Building a mine on a Gaia planet grants 2 extra victory points; building a planetary institute grants a Gleens federation token.",
			abilityXenos: "You start with an extra mine; with a planetary institute your federation threshold is 6.",
			abilityIvits: "A space station may be placed on a space without a planet; a new federation can merge into your existing one and expand it.",
			abilityHadschHallas: "With a planetary institute, free actions that gain resources may be paid with credits; you gain 3 extra credits each round.",
			abilityBescods: "Once per round, you may take an action to advance one of your lowest research tracks.",
			abilityFiraks: "With a planetary institute, once per round you may downgrade a research lab to a trading station and advance a research track.",
			abilityGeodens: "With a planetary institute, the first mine on each new planet type grants 3 knowledge.",
			abilityBaltaks: "Without a planetary institute you cannot advance navigation; you may return a terraformer to the Gaia area for 1 QIC; the right academy grants 4 credits instead.",
			abilityNevlas: "With a planetary institute, each power token in area III counts as 2 power; you may spend 1 Gaia power for 1 knowledge.",
			abilityItars: "When burning power, move the discarded token to your Gaia area. With a planetary institute, you may spend 4 tokens from that area per technology tile during the Gaia phase.",
			techPower4: "Power action",
			techPower4Desc: "Once per round: gain 4 power.",
			techOreQic: "Ore and QIC",
			techOreQicDesc: "Immediately gain 1 ore and 1 QIC.",
			techKnwTypes: "Type knowledge",
			techKnwTypesDesc: "Immediately gain knowledge equal to your known planet types.",
			tech7vp: "Seven points",
			tech7vpDesc: "Immediately gain 7 victory points.",
			techIncOrePow: "Ore and power income",
			techIncOrePowDesc: "Income phase: gain 1 extra ore and 1 extra power.",
			techIncKnwC: "Knowledge and credit income",
			techIncKnwCDesc: "Income phase: gain 1 extra knowledge and 1 extra credit.",
			techInc4c: "Credit income",
			techInc4cDesc: "Income phase: gain 4 extra credits.",
			techBig4pow: "Large building power",
			techBig4powDesc: "Planetary institutes and academies count as power 4.",
			techGaia3vp: "Gaia building",
			techGaia3vpDesc: "Each mine built on a Gaia planet grants 3 victory points.",
			advQic5c: "QIC and credit action",
			advQic5cDesc: "Once per round: gain 1 QIC and 5 credits.",
			advOre3: "Ore action",
			advOre3Desc: "Once per round: gain 3 ore.",
			advKnw3: "Knowledge action",
			advKnw3Desc: "Once per round: gain 3 knowledge.",
			advMine2: "Mine scoring",
			advMine2Desc: "Immediately gain 2 victory points per mine.",
			advTs4: "Trading station scoring",
			advTs4Desc: "Immediately gain 4 victory points per trading station.",
			advFed5: "Federation scoring",
			advFed5Desc: "Immediately gain 5 victory points per federation token.",
			advSector2: "Sector scoring",
			advSector2Desc: "Immediately gain 2 victory points per sector with your buildings.",
			advGaia2: "Gaia scoring",
			advGaia2Desc: "Immediately gain 2 victory points per Gaia planet.",
			advSector1o: "Sector ore",
			advSector1oDesc: "Immediately gain 1 ore per sector with your buildings.",
			advPassFed3: "Federation pass scoring",
			advPassFed3Desc: "When passing, gain 3 victory points per federation token.",
			advPassRl3: "Institute pass scoring",
			advPassRl3Desc: "When passing, gain 3 victory points per research lab.",
			advPassType1: "Type pass scoring",
			advPassType1Desc: "When passing, gain 1 victory point per known planet type.",
			advRes2vp: "Research scoring",
			advRes2vpDesc: "Each research advance grants 2 extra victory points.",
			advMine3: "Mine building scoring",
			advMine3Desc: "Each mine you build grants 3 extra victory points.",
			advTs3: "Trading station upgrade scoring",
			advTs3Desc: "Each upgrade to a trading station grants 3 extra victory points.",
			boostOreKnw: "Ore and knowledge",
			boostOreKnwDesc: "Income: 1 ore, 1 knowledge.",
			boostTokensOre: "Power tokens and ore",
			boostTokensOreDesc: "Income: 2 power tokens, 1 ore.",
			boostCreditsQic: "Credits and QIC",
			boostCreditsQicDesc: "Income: 2 credits, 1 QIC.",
			boostTerraformCredits: "Free terraforming",
			boostTerraformCreditsDesc: "Income: 2 credits. Action: build a mine with 1 terraforming step free.",
			boostRangePower: "Long range",
			boostRangePowerDesc: "Income: 2 power. Action: build a mine with range +3, or perform a Gaia project with range +3.",
			boostMineOre: "Mine income",
			boostMineOreDesc: "Income: 1 ore. When passing, gain 1 victory point per mine.",
			boostTsOre: "Trading station income",
			boostTsOreDesc: "Income: 1 ore. When passing, gain 2 victory points per trading station.",
			boostRlKnw: "Institute income",
			boostRlKnwDesc: "Income: 1 knowledge. When passing, gain 3 victory points per research lab.",
			boostBigPower: "Large building income",
			boostBigPowerDesc: "Income: 4 power. When passing, gain 4 victory points per planetary institute and academy.",
			boostGaiaCredits: "Gaia income",
			boostGaiaCreditsDesc: "Income: 4 credits. When passing, gain 1 victory point per Gaia planet.",
			scoreTerra2: "Terraforming step: 2 points",
			scoreResearch2: "Research advance: 2 points",
			scoreMine2: "Mine built: 2 points",
			scoreTs3: "Trading station upgrade: 3 points",
			scoreTs4: "Trading station upgrade: 4 points",
			scoreGaia3: "Gaia project: 3 points",
			scoreGaia4: "Gaia project: 4 points",
			scoreBig5: "Institute or academy: 5 points",
			scoreFederation5: "Federation formed: 5 points",
			scoreLfSector: "New sector: 3 points",
			scoreLfType: "New planet type: 3 points",
			scoreLfRl: "Research lab: 4 points",
			finalFedBuildings: "Buildings in federations",
			finalBuildings: "Total buildings",
			finalTypes: "Planet types",
			finalGaiaPlanets: "Gaia planets",
			finalSectors: "Sectors",
			finalSatellites: "Satellites",
			finalLfAsteroids: "Asteroids",
			finalLfPiAcademy: "Institute–academy distance",
			finalLfOuterSectors: "Outer sectors",
			fedKnowledge: "Knowledge token",
			fedKnowledgeDesc: "Immediately gain 2 knowledge; worth 6 points.",
			fedCredits: "Credit token",
			fedCreditsDesc: "Immediately gain 6 credits; worth 7 points.",
			fedOres: "Ore token",
			fedOresDesc: "Immediately gain 2 ore; worth 7 points.",
			fedPower: "Power token",
			fedPowerDesc: "Immediately gain 2 power tokens; worth 8 points.",
			fedQic: "QIC token",
			fedQicDesc: "Immediately gain 1 QIC; worth 8 points.",
			fedPoints: "Point token",
			fedPointsDesc: "Immediately gain 12 victory points.",
			fedGleens: "Gleens token",
			fedGleensDesc: "Immediately gain 1 ore, 1 knowledge and 2 credits; worth no points.",
			powerKnw3: "Knowledge action",
			powerKnw3Desc: "Pay 7 power to gain 3 knowledge.",
			powerTerra2: "Double terraform",
			powerTerra2Desc: "Pay 5 power to build a mine with 2 terraforming steps free.",
			powerOre2: "Ore action",
			powerOre2Desc: "Pay 4 power to gain 2 ore.",
			powerCredits7: "Credit action",
			powerCredits7Desc: "Pay 4 power to gain 7 credits.",
			powerKnw2: "Knowledge action",
			powerKnw2Desc: "Pay 4 power to gain 2 knowledge.",
			powerTerra1: "Terraform",
			powerTerra1Desc: "Pay 3 power to build a mine with 1 terraforming step free.",
			powerTokens2: "Power token action",
			powerTokens2Desc: "Pay 3 power to gain 2 power tokens.",
			qicTech: "Technology action",
			qicTechDesc: "Pay 4 QIC to take a technology tile.",
			qicRescore: "Re-score",
			qicRescoreDesc: "Pay 3 QIC to resolve a federation token reward again.",
			qicTypes: "Type scoring",
			qicTypesDesc: "Pay 2 QIC to score for your known planet types.",
			freeBurn: "Burn power",
			freeBurnDesc: "Move 2 power from area II to area III.",
			freePowQic: "Power to QIC",
			freePowQicDesc: "Pay 4 power to gain 1 QIC.",
			freePowOre: "Power to ore",
			freePowOreDesc: "Pay 3 power to gain 1 ore.",
			freeQicOre: "QIC to ore",
			freeQicOreDesc: "Pay 1 QIC to gain 1 ore.",
			freePowKnw: "Power to knowledge",
			freePowKnwDesc: "Pay 4 power to gain 1 knowledge.",
			freePowCredit: "Power to credits",
			freePowCreditDesc: "Pay 1 power to gain 1 credit.",
			freeKnwCredit: "Knowledge to credits",
			freeKnwCreditDesc: "Pay 1 knowledge to gain 1 credit.",
			freeOreCredit: "Ore to credits",
			freeOreCreditDesc: "Pay 1 ore to gain 1 credit.",
			freeOrePower: "Ore to power",
			freeOrePowerDesc: "Pay 1 ore to gain 1 power token.",
			buildingMine: "Mine",
			buildingTs: "Trading Station",
			buildingRl: "Research Lab",
			buildingPi: "Planetary Institute",
			buildingAc: "Academy",
			sideLeft: "Left",
			sideRight: "Right",
			roundN: "Round {{n}}",
			roundScoring: "Round scoring",
			finalScoring: "Final scoring",
			turnYou: "Your turn",
			turnOther: "{{name}} is acting",
			turnWaiting: "Waiting for {{name}}",
			passedTag: "Passed",
			draftPhase: "Booster draft",
			chargePhase: "Passive charging",
			donePhase: "Game over",
			resVP: "Victory points",
			resCredits: "Credits",
			resOres: "Ore",
			resKnowledge: "Knowledge",
			resQic: "QIC",
			resPower: "Power",
			resPowerI: "Power I",
			resPowerII: "Power II",
			resPowerIII: "Power III",
			resPowerTokens: "Power tokens",
			resGaiaPower: "Gaia power",
			resBrain: "Brainstone",
			resGaiaformers: "Terraformers",
			resTypes: "Planet types",
			resFederation: "Federation tokens",
			actBuild: "Build",
			actUpgrade: "Upgrade",
			actGaia: "Gaia project",
			actResearch: "Research",
			actFederation: "Federation",
			actActions: "Actions",
			actPass: "Pass",
			actInfo: "Status",
			actLog: "Log",
			actClose: "Close",
			actCancel: "Cancel",
			actConfirm: "Confirm",
			hintIdle: "Select a planet to check the building cost, or choose an action.",
			hintBuild: "Choose a planet space to build a mine.",
			hintUpgrade: "Choose one of your buildings to upgrade.",
			hintGaia: "Choose a transdimensional space for your terraformer.",
			hintNotTurn: "Waiting for other players.",
			hintCharge: "Finish the charging choice first.",
			hintDraft: "Choose a booster tile.",
			hintDraftWait: "Waiting for other players to draft.",
			hintSelectBuild: "Tap a highlighted space to confirm the build.",
			hintSelectUpgrade: "Tap a highlighted building to see upgrade options.",
			hintSelectGaia: "Tap a highlighted transdimensional space to confirm the Gaia project.",
			hintSelectStation: "Tap a highlighted space without a planet to confirm the space station.",
			hintResearchNav: "Select a highlighted empty hex to confirm the Lost Planet’s location and range cost.",
			mapTitle: "Galaxy map",
			mapZoomIn: "Zoom in",
			mapZoomOut: "Zoom out",
			mapFit: "Fit",
			mapFocus: "Focus on your structures",
			mapSector: "Sector {{id}}",
			mapOuterSector: "Outer sector {{id}}",
			mapOuter: "Outer ring",
			mapEmptyCell: "Empty space",
			mapSelected: "Selected",
			mapLegal: "Legal target",
			mapCardTitle: "Space details",
			mapNoActions: "No action is available on this space right now.",
			mapOwner: "Owner",
			mapBuilding: "Building",
			mapFederation: "Federation",
			mapSatellite: "Satellite",
			mapStation: "Space station",
			mapLostPlanet: "Lost planet",
			mapArtifact: "Artifact",
			mapGaiaformer: "Terraformer",
			mapParasite: "Parasite mine",
			mapPowerLabel: "Power {{n}}",
			buildCost: "Cost",
			buildCostCredits: "{{n}} credits",
			buildCostOres: "{{n}} ore",
			buildCostQic: "{{n}} QIC",
			buildCostSteps: "{{n}} terraforming steps",
			buildCostFree: "{{n}} steps free",
			buildAction: "Build mine",
			buildCostTitle: "Building cost",
			buildNoCost: "No resources required",
			buildTerraformDetail: "Terraforming steps: {{steps}} at {{ore}} ore each.",
			upgradeAction: "Upgrade to {{building}}",
			gaiaAction: "Place terraformer",
			gaiaPowerCost: "{{n}} power",
			upgradeTechHint: "Choose a technology tile after upgrading.",
			techTitle: "Choose a technology tile",
			techStandard: "Standard tiles",
			techAdvanced: "Advanced tiles",
			techFleetAdvanced: "Fleet advanced technology",
			techFleetRequirementPoints: "Requires at least 25 victory points.",
			techFleetRequirementShips: "Requires at least 25 victory points or exploration of three different spaceships.",
			gaiaPhaseTitle: "Gaia phase",
			gaiaPhaseItars: "Spend 4 tokens from your Gaia area for each technology tile you take.",
			gaiaPhaseFinish: "Finish Gaia phase",
			tinkerPickTitle: "Choose a Tinkering tile",
			guideRange: "Count one space each time you cross a shared hex edge. Each QIC extends your range by two spaces for the current action. At Navigation level 5, choose an unoccupied space in range for the Lost Planet. Its mine counts toward objectives for both planet types and occupied sectors.",
			guideTrackTech: "To take an advanced tile from a research track, you must be at level 4 or 5 on that track.",
			guideFleetTech: "The extra advanced tile in The Lost Fleet requires 25 victory points. In games with three or four players, having explored three different spaceships also qualifies.",
			guideTechAdvance: "After taking an advanced tile, you may advance on an eligible track. If you advance to level 5, flip a second green federation token.",
			guideRoundDecisions: "Decisions before the action phase",
			guideItars: "With a planetary institute, the Itars can spend 4 tokens from their Gaia area per technology tile before returning their remaining tokens to the power cycle.",
			guideTinkeroids: "The Tinkeroids set aside their chosen tile even if they never use its action. They cannot choose it again in a later round.",
			techAdvancedRequires: "Flip a green federation token and cover a standard tile. Advance on an eligible research track if you choose.",
			techCoverLabel: "Choose a standard tile to cover",
			techPickCover: "Choose an advanced tile, then choose the tile it covers.",
			techCovered: "Covered",
			techTrackPick: "Choose a research track to advance",
			techEmpty: "No technology tile is available.",
			techSlotEmpty: "Empty slot",
			boardResource: "{{name}} {{n}}",
			techIndependent: "Independent tiles",
			techRemaining: "{{n}} remaining",
			techAcquireQic: "Acquire for {{n}} QIC",
			researchTitle: "Research tracks",
			researchHint: "Pay {{n}} knowledge to advance one step on a research track.",
			researchLevel: "Level {{n}}",
			researchPayAdvance: "Advance for {{n}} knowledge",
			researchOreRate: "Each terraforming step costs {{n}} ore.",
			researchGainOre: "Gain {{n}} ore when you advance here.",
			researchGainTokens: "Gain {{n}} power tokens when you advance here.",
			researchChargePower: "Charge {{n}} power when you advance here.",
			researchGainQic: "Gain {{n}} QIC when you advance here.",
			researchGainFederation: "Gain the {{name}} federation token when you advance here.",
			researchGainFormer: "Gain a Gaiaformer when you advance here.",
			researchRange: "Your base navigation range is {{n}}.",
			researchGaiaScore: "Score 4 VP plus 1 VP per Gaia planet you have colonized when you advance here.",
			researchEconomyIncome: "Each round, gain {{credits}} credits and {{ores}} ore, and charge {{power}} power.",
			researchEconomyTop: "Gain 6 credits and 3 ore, and charge 6 power when you advance here.",
			researchScienceIncome: "Gain {{n}} knowledge as income each round.",
			researchScienceTop: "Gain 9 knowledge when you advance here.",
			researchAdvance: "Advance",
			researchBlocked: "Requirements not met",
			researchMax: "Maxed",
			researchOwned: "Technology tiles",
			researchNone: "No technology tiles yet.",
			federationTitle: "Form a federation",
			federationBuildings: "{{n}} structures or colonies",
			federationSatellites: "{{n}} satellites",
			federationPowerCost: "Discard {{n}} power tokens",
			federationQicCost: "Pay {{n}} QIC",
			federationHint: "Choose a connected group of buildings whose power reaches {{n}} to take a federation token.",
			federationPower: "Power {{n}}",
			federationNeed: "{{n}} more power needed",
			federationMerge: "Merges into your existing federation; {{n}} more power needed",
			federationToken: "Federation token",
			federationConfirm: "Form federation",
			federationEmpty: "No federation can be formed right now.",
			federationOwned: "Owned tokens",
			federationBase: "Federation threshold {{n}}",
			fedPickCluster: "Tap a glowing group of structures on the map.",
			fedSelected: "Selected structures",
			rescoreTitle: "Rescore a federation token",
			noTargets: "No available targets right now.",
			actionsTitle: "Actions and abilities",
			actionsPowerBoard: "Power actions",
			actionsQicBoard: "QIC actions",
			actionsPersonal: "Faction and tile abilities",
			actionsSpent: "Used this round",
			actionsLowPower: "Insufficient power",
			actionsLowQic: "Insufficient QIC",
			actionsPower: "Power actions",
			actionsQic: "QIC actions",
			actionsFree: "Free actions",
			actionsTech: "Technology actions",
			actionsFaction: "Faction abilities",
			actionsBooster: "Booster action",
			actionsAcademy: "Academy action",
			actionsCostPower: "{{n}} power",
			actionsCostQic: "{{n}} QIC",
			actionsUsePower: "Pay with power",
			actionsUseCredits: "Pay with credits",
			actionsUsed: "Used this round",
			actionsUnavailable: "Not available now",
			factionSwapPI: "Swap planetary institute and mine",
			factionDowngradeRL: "Downgrade to trading station and advance {{track}}",
			factionDowngradeRLShort: "Downgrade to trading station and advance a research track",
			factionAdvanceLowest: "Advance the lowest research track",
			factionItarsTech: "Spend Gaia power for a technology tile",
			factionBaltaqGaiaformer: "Terraformer for QIC",
			factionNevlasKnowledge: "Gaia power for knowledge",
			factionSpaceStation: "Place space station",
			factionAbility: "Faction ability",
			boosterAction: "Use booster",
			academyAction: "Take academy reward",
			academyHint: "Once per round: the right academy grants a free reward.",
			passTitle: "Pass",
			passHint: "End your actions for this round and gain income at the start of the next round.",
			passFirst: "You would be the first to pass this round and take the first-player marker.",
			passChooseBooster: "Choose a booster tile for the next round",
			passNeedBooster: "Passing in rounds 1 to 5 requires choosing a booster tile for the next round.",
			passPoints: "Passing immediately grants {{n}} victory points.",
			passConfirm: "Confirm pass",
			passLastRound: "Passing in round 6 leads directly to final scoring.",
			chargeTitle: "Passive charging",
			chargeHint: "You may gain {{power}} power and lose {{vp}} victory points.",
			chargeTake: "Charge",
			chargeSkip: "Do not charge",
			draftTitle: "Booster draft",
			draftHint: "Choose a booster tile; it takes effect at the start of the income phase.",
			draftWaiting: "Waiting for other players to finish drafting.",
			infoTitle: "Status",
			infoRoundTiles: "Round scoring",
			infoFinalTiles: "Final scoring",
			infoResearch: "Research levels",
			infoResources: "Resources",
			infoBuildings: "Buildings",
			infoTechs: "Technology tiles",
			infoFedTokens: "Federation tokens",
			infoFaction: "Faction",
			infoUsedActions: "Actions used this round",
			infoUsedPower: "Power actions",
			infoUsedQic: "QIC actions",
			infoUsedTiles: "Technology actions",
			infoIncome: "Income preview",
			infoBooster: "Booster tile",
			infoFedSupply: "Federation token supply",
			infoArtifacts: "Artifacts",
			infoNone: "None",
			infoLog: "Log",
			logTitle: "Game log",
			logEmpty: "No entries yet.",
			logSetup: "{{faction}} joined the game",
			logCharge: "Charged power",
			logDraft: "Drafted a booster tile",
			logParasite: "Placed a parasite mine",
			logBuild: "Built a mine",
			logGaia: "Placed a terraformer",
			logUpgrade: "Upgraded a building",
			logTech: "Took technology tile: {{name}}",
			logResearch: "Advanced {{track}} to level {{n}}",
			logLostPlanet: "Placed a lost planet",
			logFederation: "Formed a federation",
			logFedToken: "Took federation token: {{name}}",
			logPower: "Used power action: {{name}}",
			logQic: "Used QIC action: {{name}}",
			logFree: "Used free action: {{name}}",
			logUseTile: "Used technology action: {{name}}",
			logAcademy: "Took academy reward",
			logFaction: "Used faction ability",
			logPass: "Passed",
			logRound: "Round {{n}} began",
			logGameEnd: "Game over",
			overTitle: "Final scoring",
			overRankings: "Final standings",
			overObjectives: "Final objectives",
			overCompetitor: "Contender",
			overCount: "Count",
			overDistance: "Distance",
			overAwardPoints: "Points",
			overWinner: "Winner",
			overTotal: "Total",
			overScoreItem: "Category",
			overGhost: "Ghost opponent",
			overRank: "Rank {{n}}",
			overReview: "View galaxy map",
			overBack: "Back to scores",
			overWaitHost: "Waiting for the host to restart or return to the lobby.",
			overDetail: "Details",
			confirmAgain: "Confirm restart",
			confirmLobby: "Confirm return",
			metricFedBuildings: "Buildings in federations",
			metricBuildings: "Total buildings",
			metricTypes: "Planet types",
			metricGaia: "Gaia planets",
			metricSectors: "Sectors",
			metricSatellites: "Satellites and stations",
			metricAsteroids: "Asteroids",
			metricPiAcademy: "Institute–academy distance",
			metricOuterSectors: "Outer sectors",
			metricResearch: "Research",
			metricResources: "Resources",
			metricVp: "Victory points in game",
			metricAwards: "Final tiles",
			optionsLostFleet: "The Lost Fleet Expansion",
			optionsLostFleetHint: "Adds four factions, spaceship boards and exploration, gold federation tokens, deep space sectors and extra scoring tiles.",
			experimentLabel: "The Lost Fleet Expansion",
			chargeWait: "Waiting for {{name}} to choose charging",
			playerPassed: "{{name}} has passed",
			useCount: "{{n}} times this round",
			soloGhost: "A neutral benchmark competes for final objective awards in two-player games.",
			factionSpaceGiants: "Space Giants",
			factionMoweyds: "Moweyds",
			factionDarkanians: "Darkanians",
			factionTinkeroids: "Tinkeroids",
			abilitySpaceGiants: "Start with 1 mine instead of 2. Terraforming a standard planet always takes 2 steps; you have one \"Build a Mine\" action on your Exploration board with 2 free terraforming steps; making a Gaia planet habitable costs 2 Q.I.C.s. Planetary Institute: immediately take 1 Tech tile of your choice, once only.",
			abilityMoweyds: "Start with 1 mine instead of 2 and place an Exploration Shuttle on the T F Mars spaceship. Three base-game planet types need 3 terraforming steps and the rest need 1. Planetary Institute: once per round as an action, place a Power Ring on a planet with one of your buildings and no ring, increasing that structure’s power by 2.",
			abilityDarkanians: "Start with 1 mine instead of 2. A standard planet needs 1 terraforming step; making a Gaia planet habitable costs 2 Q.I.C.s. Planetary Institute: the first time you colonize a planet in a Space or Deep Space sector, gain 2 credits and 1 knowledge; Interspace tiles do not count as sectors.",
			abilityTinkeroids: "Start with your Planetary Institute instead of 2 mines, placed during the second stage. Three base-game planet types need 3 terraforming steps and the rest need 1; making a Gaia planet habitable costs 2 Q.I.C.s. You have 6 Tinkering tiles, 3 for rounds 1–3 and 3 for rounds 4–6; choose one unused tile from that round’s set at the start of each round and remove it at the end of the round. Planetary Institute: once per round as an action, use the action on your current Tinkering tile.",
			shipEclipse: "Eclipse",
			shipTwilight: "Twilight",
			shipTfMars: "T F Mars",
			shipRebellion: "Rebellion",
			lfExplore: "Explore a spaceship",
			lfExamine: "Examine an artifact",
			lfShuttles: "Exploration Shuttles",
			lfArtifacts: "Artifacts",
			lfAlliance: "Alliance",
			artifactVpMine: "Artifact: 7 points",
			artifactVpTerra: "Artifact: Terraforming research",
			artifactVpNav: "Artifact: Navigation research",
			artifactVpAi: "Artifact: AI research",
			artifactVpGaia: "Artifact: Gaia research",
			artifactVpEco: "Artifact: Economy research",
			artifactVpSci: "Artifact: Science research",
			artifactVpArea3: "Artifact: Research areas",
			artifactPowerIncome: "Artifact: Power income",
			artifactResources: "Artifact: Resources",
			tinkerMine3: "Tinkering: 3 free terraforming steps",
			tinkerKnw3: "Tinkering: 3 knowledge",
			tinkerQic2: "Tinkering: 2 Q.I.C.s",
			tinkerQic1: "Tinkering: 1 Q.I.C.",
			tinkerCharge4: "Tinkering: charge 4 power",
			tinkerMine1: "Tinkering: 1 free terraforming step",
			goldPoints: "Alliance: 12 points",
			goldMineRange: "Alliance: unlimited-range mine",
			goldTech: "Alliance: tech of your choice",
			goldMine3: "Alliance: 3 free terraforming steps",
			lfMine2free: "Free mine (2 steps)",
			lfMine2freeDesc: "Immediately take a \"Build a Mine\" action with up to 2 free terraforming steps and no build cost; you may pay ore for a third step and Q.I.C.s to increase range.",
			lfPiDsVp: "Institute, academies and deep sectors",
			lfPiDsVpDesc: "Immediately gain victory points for your Planetary Institute, each Academy, and each Deep Space sector where you have colonized at least one planet.",
			lfRange1: "Range +1",
			lfRange1Desc: "Your basic range increases by 1 for the rest of the game until this tile is covered by an Advanced Tech tile.",
			lfASector4: "4 VP per sector",
			lfASector4Desc: "Immediately gain 4 victory points for each sector you have colonized.",
			lfAFlat9: "Nine points",
			lfAFlat9Desc: "Immediately gain 9 victory points.",
			lfAPassAsteroid2: "Pass: asteroids",
			lfAPassAsteroid2Desc: "Each time you pass, gain 2 victory points for each asteroid you have colonized.",
			lfAPassDs2: "Pass: deep sectors",
			lfAPassDs2Desc: "Each time you pass, gain 2 victory points for each Deep Space sector where you have colonized at least one planet.",
			lfAGaia4: "4 VP per Gaia planet",
			lfAGaia4Desc: "Immediately gain 4 victory points for each Gaia planet you have colonized.",
			lfAOreIncome2: "Ore income",
			lfAOreIncome2Desc: "Gain 2 additional ore as income.",
			lfBGaiaformers: "Pass: Gaiaformers",
			lfBGaiaformersDesc: "Income: 1 ore. When you pass, gain 3 victory points for each of your Gaiaformers (excluding those used to colonize asteroids).",
			lfBTypes: "Pass: planet types",
			lfBTypesDesc: "Income: 3 credits. When you pass, gain 1 victory point for each planet type you have colonized.",
			lfBDsSectors: "Pass: deep sectors",
			lfBDsSectorsDesc: "Income: 2 power. When you pass, gain 2 victory points for each Deep Space sector where you have colonized at least one planet.",
			lfBGaiaFree: "Free Gaia project",
			lfBGaiaFreeDesc: "Income: 1 ore. Once per round, start a Gaia Project without moving power into the Gaia Area and immediately transform the transdim planet into a Gaia planet.",
			actShips: "Spaceships",
			shipsTitle: "Spaceships & Exploration",
			shipsEmpty: "No spaceships are used in this game.",
			shipDock: "Dock {{hex}}",
			lfExploreHint: "After placing an exploration shuttle, the spaceship charges a slot and you may use its ship actions.",
			lfExamineHint: "Discard six power tokens and choose one artifact from the Twilight.",
			lfBrainstoneCost: "Move the Brainstone to the Gaia area",
			shipRewardVpPerType: "Score per planet type",
			shipRewardAdvanceResearch: "Advance research",
			shipRewardFreeAsteroidMine: "Free asteroid mine",
			shipRewardRepeatFed: "Repeat a federation token",
			shipRewardFreeUpgradeRl: "Free upgrade to Research Lab",
			shipRewardRange3: "Mine with range +3",
			shipRewardStandardTech: "Take a ship tech",
			shipRewardGaiaProject: "Free Gaia Project",
			shipRewardFreeMine1: "Mine (1 free terraform step)",
			shipRewardTech: "Choose a tech",
			shipRewardFreeUpgradeTs: "Free upgrade to Trading Station",
			shipRewardCreditsQic: "Gain credits and QIC",
			factionSpaceGiantsTech: "Planetary Institute: take a tech",
			factionGiantsMine: "Build a mine (up to 2 free terraforming steps)",
			factionMoweydRing: "Planetary Institute: place a power ring",
			factionTinkerAction: "Planetary Institute: use a tinker tile",
			hintSelectRing: "Tap a planet with your building and no power ring to place a power ring.",
			goldTechHint: "Choose the tech tile you want to take.",
			goldMineRangeHint: "Tap any buildable planet to build a mine for free, with unlimited range.",
			goldMine3Hint: "Tap a buildable planet to build a mine for free with up to 3 terraforming steps.",
			resShuttles: "Exploration Shuttles",
			infoLostFleet: "The Lost Fleet",
			infoLfTerra: "Three-step planet types",
			infoPowerRings: "Power rings",
			infoTinkerTile: "Current tinker tile",
			logExplore: "Place an exploration shuttle on {{ship}}",
			logArtifact: "Take {{name}}",
			logShipAction: "Ship action: {{name}}"
		}
	}
};
//#endregion
export { gi as default };
