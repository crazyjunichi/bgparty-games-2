import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useMemo as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { IconLog as c } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
var h = [
	2,
	3,
	4
], g = [
	5,
	6,
	7,
	8
];
function _(e) {
	let t = [];
	for (let n = 0; n < 9; n += 1) for (let r = 0; r < 5; r += 1) t.push({
		color: e,
		symbols: [n],
		feather: !1,
		hoop: null
	});
	for (let n = 0; n < 3; n += 1) t.push({
		color: e,
		symbols: [],
		feather: !0,
		hoop: null
	});
	for (let n of h) t.push({
		color: e,
		symbols: [],
		feather: !1,
		hoop: n
	});
	for (let n = 0; n < 3; n += 1) t.push({
		color: e,
		symbols: [],
		feather: !1,
		hoop: null
	});
	return t;
}
var v = _(0), y = _(1), b = _(2);
function te(e, t, n, r) {
	let i = [];
	for (let a = 0; a < n; a += 1) {
		let n = r !== (a % 2 == 0);
		i.push({
			id: 0,
			...n ? {
				left: t[a],
				right: e[a]
			} : {
				left: e[a],
				right: t[a]
			}
		});
	}
	return i;
}
var ne = [
	...te(v, y, 27, !1),
	...te(y.slice(27), b.slice(0, 27), 27, !0),
	...te(b.slice(27), v.slice(27), 27, !1)
].map((e, t) => ({
	...e,
	id: t
}));
function x(e) {
	return ne[e];
}
function re(e) {
	return e >= 81;
}
function ie(e, t) {
	return 81 + (e - 1) * 3 + t;
}
function S(e) {
	let t = e - 81;
	return {
		set: Math.floor(t / 3) + 1,
		color: t % 3
	};
}
var C = (e) => ({
	color: e,
	symbols: [],
	feather: !1,
	hoop: null
});
function w(e) {
	if (re(e)) {
		let t = S(e).color;
		return [C(t), C(t)];
	}
	let t = x(e);
	return [t.left, t.right];
}
var T = Array.from({ length: 16 }, (e, t) => ({
	id: t + 1,
	category: Math.floor(t / 4)
})), ae = {
	1: {
		threads: 4,
		needles: 1,
		offers: [5]
	},
	2: {
		threads: 4,
		needles: 1,
		offers: [3, 2]
	},
	3: {
		threads: 7,
		needles: 2,
		offers: [
			3,
			2,
			1
		]
	},
	4: {
		threads: 10,
		needles: 2,
		offers: [
			3,
			2,
			2,
			1
		]
	}
}, E = {
	1: { fixed: [] },
	2: { fixed: ["A", "B"] },
	3: { fixed: ["B", "C"] },
	4: { fixed: ["C", "D"] },
	5: {
		fixed: ["A", "D"],
		choose: ["B", "C"]
	}
}, oe = {
	id: "fadenfroh",
	uuid: "3111c69b-1140-4641-833e-6cace2a9584d",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"set-collection",
		"drafting"
	],
	interactionTags: [],
	nameKey: "games.fadenfroh.name",
	descKey: "games.fadenfroh.desc",
	rulesKey: "games.fadenfroh.rules",
	icon: "🧵",
	iconImg: "games/fadenfroh.webp",
	rulesUrl: {
		en: "https://1moretimegames.com/file/ffr",
		de: "https://asmodee-resources.azureedge.net/media/germanyprod/Regeln/fadenfroh-4015566606500-regel.pdf"
	},
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#7d5aa6",
	releasedAt: "2026-11-23T19:24:30+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, D = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("takeMaterial"),
		kind: t.enum([
			"thread",
			"needle",
			"thimble"
		])
	}),
	t.object({
		type: t.literal("takeOffer"),
		index: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("soloTake"),
		cards: t.array(t.int().min(0)).max(2)
	}),
	t.object({
		type: t.literal("exchangeKeep"),
		card: t.int().min(0)
	}),
	t.object({
		type: t.literal("place"),
		card: t.int().min(0),
		row: t.int().min(0).max(2),
		x: t.int().min(-40).max(60),
		needle: t.boolean()
	}),
	t.object({
		type: t.literal("discard"),
		card: t.int().min(0)
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("scoreChoice"),
		which: t.enum(["B", "C"])
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), se = t.object({
	id: t.int().min(0),
	row: t.int().min(0).max(2),
	x: t.int(),
	needle: t.boolean(),
	seq: t.int().min(0)
}), ce = t.object({
	rid: t.string(),
	set: t.int().min(1).max(4),
	score: t.number(),
	roundScore: t.number().nullable(),
	passed: t.boolean(),
	embroiderDone: t.boolean(),
	exchange: t.boolean(),
	supply: t.object({
		threads: t.int().min(0),
		needles: t.int().min(0),
		thimble: t.boolean(),
		cards: t.int().min(0)
	}),
	tableau: t.array(se)
}), le = t.object({
	key: t.string(),
	vp: t.number()
}), ue = t.object({
	round: t.int().min(1).max(5),
	phase: t.enum([
		"shopping",
		"embroidery",
		"scoring",
		"done"
	]),
	solo: t.boolean(),
	startPlayer: t.string(),
	turn: t.string().nullable(),
	mustPass: t.boolean(),
	market: t.object({
		threads: t.int().min(0),
		needles: t.int().min(0),
		thimble: t.boolean(),
		offers: t.array(t.array(t.int().min(0)))
	}),
	scoring: t.object({
		A: t.int().min(1).max(16),
		B: t.int().min(1).max(16),
		C: t.int().min(1).max(16),
		D: t.int().min(1).max(16)
	}),
	deckCount: t.int().min(0),
	discardCount: t.int().min(0),
	players: t.array(ce),
	history: t.array(t.object({
		round: t.int().min(1).max(5),
		scores: t.record(t.string(), t.number()),
		details: t.record(t.string(), t.array(le))
	})),
	choiceCount: t.int().min(0)
}), de = t.object({
	cards: t.array(t.int().min(0)),
	exchange: t.array(t.int().min(0)).nullable(),
	choicePreview: t.object({
		B: t.number(),
		C: t.number()
	}).nullable(),
	myChoice: t.enum(["B", "C"]).nullable()
}), O = (e) => e.players.length === 1;
function fe(e, t) {
	return e.players.find((e) => e.rid === t);
}
function pe(e, t) {
	return e.players.findIndex((e) => e.rid === t);
}
function me(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function k(e, t) {
	for (let n = e.length - 1; n > 0; --n) {
		let r = me(t, n + 1);
		[e[n], e[r]] = [e[r], e[n]];
	}
}
function he(e) {
	if (e.deck.length === 0) {
		if (e.discard.length === 0) return null;
		e.deck = e.discard, e.discard = [], k(e.deck, e);
	}
	return e.deck.pop() ?? null;
}
function ge(e, t) {
	let n = [];
	for (let r = 0; r < t; r += 1) {
		let t = he(e);
		if (t === null) break;
		n.push(t);
	}
	return n;
}
function _e(e, t, n) {
	n === "thread" ? t.supply.threads += 1 : n === "needle" ? t.supply.needles += 1 : (t.supply.thimble = !0, e.thimbleHolder = t.rid);
}
function ve(e, t) {
	t.supply.threads += e.market.threads, t.supply.needles += e.market.needles, e.market.threads = 0, e.market.needles = 0, e.market.thimble && (e.market.thimble = !1, t.supply.thimble = !0, e.thimbleHolder = t.rid);
}
function A(e, t) {
	if (t === "left") {
		for (let t of e.market.offers) if (t.length > 0) {
			e.discard.push(t.shift());
			break;
		}
	} else for (let t = e.market.offers.length - 1; t >= 0; --t) {
		let n = e.market.offers[t];
		if (n.length > 0) {
			e.discard.push(n.pop());
			break;
		}
	}
	e.market.offers = e.market.offers.filter((e) => e.length > 0);
}
function ye(e) {
	if (e.market.needles > 0) {
		--e.market.needles, e.general.needles += 1;
		return;
	}
	if (e.market.thimble) {
		e.market.thimble = !1;
		return;
	}
	e.market.threads > 0 && (--e.market.threads, e.general.threads += 1);
}
function be(e) {
	let t = he(e);
	if (t === null) return;
	let [n, r] = w(t);
	n.feather || n.hoop !== null || r.feather || r.hoop !== null ? ye(e) : n.color === r.color ? A(e, "left") : A(e, "right"), e.discard.push(t);
}
function j(e, t) {
	if (t.supply.threads < 3) {
		t.exchange = null;
		return;
	}
	let n = ge(e, 3);
	if (n.length === 0) {
		t.supply.threads -= 3, e.general.threads += 3, t.exchange = null;
		return;
	}
	t.exchange = { drawn: n };
}
function M(e, t) {
	t.embroiderDone || t.exchange || (e.discard.push(...t.supply.cards), t.supply.cards = [], t.embroiderDone = !0, t.roundScore = null);
}
function N(e) {
	return e.players.every((e) => e.embroiderDone);
}
function P(e, t, n) {
	if (n === 1) {
		let t = 0;
		for (let n of e) t += n.symbols.length, n.feather && (t += 2), n.hoop !== null && (t += 3);
		return t;
	}
	let r = 0;
	for (let i of E[n]?.fixed ?? []) r += V(t[i], e);
	r += Ae(e) * 2 + je(e);
	let i = E[n]?.choose;
	return i && (r += Math.max(...i.map((n) => V(t[n], e)))), r;
}
function xe(e, t, n) {
	let r = Te(t.tableau), i = [];
	if (n === 1) return {
		total: 0,
		items: i
	};
	for (let t of E[n].fixed) i.push({
		key: t,
		vp: V(e.scoring[t], r)
	});
	E[n].choose && t.choice && i.push({
		key: t.choice,
		vp: V(e.scoring[t.choice], r)
	});
	let a = Ae(r) * 2;
	if (a !== 0 && i.push({
		key: "feather",
		vp: a
	}), n === 5) {
		let e = (t.supply.threads + t.supply.needles + +!!t.supply.thimble) * 2;
		e !== 0 && i.push({
			key: "material",
			vp: e
		});
		let n = je(r);
		n !== 0 && i.push({
			key: "hoop",
			vp: n
		});
	}
	return {
		total: i.reduce((e, t) => e + t.vp, 0),
		items: i
	};
}
function Se(e, t) {
	let n = {}, r = {};
	for (let i of e.players) {
		let a = xe(e, i, t);
		i.score += a.total, i.roundScore = a.total, i.choice = null, n[i.rid] = a.total, r[i.rid] = a.items;
	}
	e.history.push({
		round: t,
		scores: n,
		details: r
	});
}
function F(e) {
	if (N(e)) {
		if (e.round === 1) {
			for (let t of e.players) t.roundScore = 0, t.choice = null;
			I(e, 2);
			return;
		}
		if (e.round < 5) {
			Se(e, e.round), I(e, e.round + 1);
			return;
		}
		for (let t of e.players) t.choice = null;
		e.phase = "scoring";
	}
}
function I(e, t) {
	let n = e.thimbleHolder, r = e.players[0]?.supply.thimble ?? !1;
	if (e.round = t, e.phase = "shopping", e.mustPass = !1, e.thimbleHolder = null, t > 1 && n && (e.startPlayer = n), e.soloStart = t === 1 || r, t > 1) {
		e.general.threads += e.market.threads, e.general.needles += e.market.needles;
		for (let t of e.players) t.supply.threads > 2 && (e.general.threads += t.supply.threads - 2, t.supply.threads = 2), t.supply.thimble = !1;
		e.market = {
			threads: 0,
			needles: 0,
			thimble: !0,
			offers: []
		};
	}
	for (let t of e.players) t.passed = !1, t.embroiderDone = !1, t.exchange = null, t.roundScore = null, t.supply.cards = [];
	let i = ae[e.players.length], a = Math.min(i.threads, e.general.threads);
	e.general.threads -= a;
	let o = Math.min(i.needles, e.general.needles);
	e.general.needles -= o, e.market = {
		threads: a,
		needles: o,
		thimble: !0,
		offers: []
	};
	for (let t of i.offers) {
		let n = ge(e, t);
		n.length > 0 && e.market.offers.push(n);
	}
	e.turnIndex = pe(e, e.startPlayer), e.turnIndex < 0 && (e.turnIndex = 0), O(e) && !e.soloStart && be(e);
}
function L(e) {
	return {
		phase: e.phase,
		turn: e.phase === "shopping" ? e.order[e.turnIndex] : null
	};
}
function R(e) {
	e.phase = "embroidery", e.turnIndex = -1, e.mustPass = !1;
}
function Ce(e, t) {
	let n = e.players.length;
	for (let r = 1; r <= n; r += 1) {
		let i = (t + r) % n;
		if (!e.players[i].passed) {
			if (e.turnIndex = i, e.mustPass = !1, !O(e)) {
				let t = e.players.filter((e) => !e.passed);
				t.length === 1 && t[0] === e.players[i] && (ve(e, t[0]), e.mustPass = !0);
			}
			return;
		}
	}
	R(e);
}
function we(e, t, n) {
	let r = e.market.offers[n];
	return r ? (t.supply.cards.push(...r), e.market.offers.splice(n, 1), t.passed = !0, t.supply.threads >= 3 && j(e, t), !0) : !1;
}
function z(e, t, n) {
	let r = e.market.offers.flat();
	if (n.length > 2) return !1;
	let i = new Set(n);
	if (i.size !== n.length) return !1;
	for (let e of n) if (!r.includes(e)) return !1;
	if (n.length === 2) {
		let e = n.map((e) => r.indexOf(e)).sort((e, t) => e - t);
		if (e[1] !== e[0] + 1) return !1;
	}
	let a = r.filter((e) => !i.has(e));
	return t.supply.cards.push(...n), e.discard.push(...a), e.market.offers = [], e.general.threads += e.market.threads, e.general.needles += e.market.needles, e.market.threads = 0, e.market.needles = 0, e.market.thimble = !1, t.passed = !0, t.supply.threads >= 3 && j(e, t), R(e), !0;
}
function Te(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let e of [n.x, n.x + 1]) {
		let r = `${n.row},${e}`, i = t.get(r);
		(!i || n.seq > i.seq) && t.set(r, n);
	}
	let n = [];
	for (let [e, r] of t) {
		let [t, i] = e.split(","), a = Number(t), o = Number(i), s = o - r.x, c = w(r.id), l = s === 0 ? c[0] : c[1];
		n.push({
			...l,
			row: a,
			x: o,
			card: r.id,
			seq: r.seq,
			half: s
		});
	}
	return n;
}
function Ee(e, t) {
	let n = [], r = /* @__PURE__ */ new Set(), i = (e, t, i) => {
		let a = `${e},${t},${+!!i}`;
		r.has(a) || (r.add(a), n.push({
			row: e,
			x: t,
			needle: i
		}));
	};
	for (let n = 0; n < 3; n += 1) {
		let r = e.filter((e) => e.row === n), a = /* @__PURE__ */ new Set();
		for (let e of r) a.add(e.x), a.add(e.x + 1);
		for (let e of a) i(n, e, !1), i(n, e - 1, !1);
		if (t > 0) for (let e of r) for (let t of [e.x - 2, e.x + 2]) !a.has(t) && !a.has(t + 1) && i(n, t, !0);
	}
	return n.sort((e, t) => e.row - t.row || e.x - t.x || Number(e.needle) - Number(t.needle));
}
var B = (e, t) => `${e},${t}`;
function De(e, t) {
	return [
		B(e - 1, t),
		B(e + 1, t),
		B(e, t - 1),
		B(e, t + 1)
	];
}
function Oe(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = t.get(n.color);
		e || (e = /* @__PURE__ */ new Map(), t.set(n.color, e)), e.set(B(n.row, n.x), n);
	}
	let n = /* @__PURE__ */ new Map();
	for (let [e, r] of t) {
		let t = /* @__PURE__ */ new Set(), i = [];
		for (let e of r.keys()) {
			if (t.has(e)) continue;
			let n = 0, a = [e];
			for (t.add(e); a.length;) {
				let e = a.pop();
				n += 1;
				for (let n of De(Math.floor(Number(e.split(",")[0])), Number(e.split(",")[1]))) r.has(n) && !t.has(n) && (t.add(n), a.push(n));
			}
			i.push(n);
		}
		n.set(e, i);
	}
	return n;
}
function V(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let e of t) for (let t of e.symbols) n.set(t, (n.get(t) ?? 0) + 1);
	let r = (e) => n.get(e) ?? 0, i = r(0), a = r(1);
	switch (e) {
		case 1: return Math.max(0, i * 2 - a);
		case 2: return Math.min(i, a) * 4;
		case 3: return (i % 2 == 1 ? i * 2 : 0) + (a % 2 == 0 ? a * 2 : 0);
		case 4: {
			let e = 0;
			for (let n of ke(t, 1)) n >= 3 && (e += 6);
			for (let n of ke(t, 0)) n >= 4 && (e += 9);
			return e;
		}
		case 5: {
			let e = /* @__PURE__ */ new Map();
			for (let n of t) {
				let t = n.symbols.filter((e) => h.includes(e)).length;
				t > 0 && e.set(B(n.row, n.x), t);
			}
			let n = 0;
			for (let r of t) {
				let t = r.symbols.filter((e) => h.includes(e)).length;
				if (t === 0) continue;
				let i = t > 1;
				i ||= De(r.row, r.x).some((t) => (e.get(t) ?? 0) > 0), i || (n += t * 3);
			}
			return n;
		}
		case 6: {
			let e = [
				r(2),
				r(3),
				r(4)
			], t = e.reduce((e, t) => e + t, 0);
			return t * 2 + (new Set(e).size === 3 ? t : 0);
		}
		case 7: {
			let e = [
				r(2),
				r(3),
				r(4)
			], t = Math.max(...e), n = e.reduce((e, t) => e + t, 0);
			return t * 4 - (n - t);
		}
		case 8: {
			let e = [
				r(2),
				r(3),
				r(4)
			];
			return e.reduce((e, t) => e + t, 0) + Math.min(...e) * 6;
		}
		case 9: {
			let e = [
				0,
				0,
				4,
				9,
				15
			], n = 0;
			for (let r = 0; r < 3; r += 1) {
				let i = /* @__PURE__ */ new Set();
				for (let e of t) if (e.row === r) for (let t of e.symbols) g.includes(t) && i.add(t);
				n += e[Math.min(i.size, 4)];
			}
			return n;
		}
		case 10: {
			let e = [
				0,
				2,
				7,
				12
			], n = /* @__PURE__ */ new Map();
			for (let e of t) for (let t of e.symbols) {
				if (!g.includes(t)) continue;
				let r = n.get(e.x);
				r || (r = /* @__PURE__ */ new Map(), n.set(e.x, r)), r.set(t, (r.get(t) ?? 0) + 1);
			}
			let r = 0;
			for (let t of n.values()) r += e[Math.min(Math.max(...t.values()), 3)];
			return r;
		}
		case 11: {
			let e = 0;
			for (let n of g) for (let r of ke(t, n)) r === 2 ? e += 5 : r === 3 ? e += 11 : r >= 4 && (e += 18);
			return e;
		}
		case 12: {
			let e = [
				0,
				0,
				4,
				8,
				13,
				18,
				24
			], n = /* @__PURE__ */ new Map();
			for (let e of t) {
				let t = n.get(e.row) ?? [];
				t.push(e), n.set(e.row, t);
			}
			let r = 0;
			for (let e of n.values()) for (let t of e) e.filter((e) => Math.abs(e.x - t.x) === 1).length === 1 && (r += t.symbols.filter((e) => g.includes(e)).length);
			return e[Math.min(r, 6)];
		}
		case 13: {
			let e = Oe(t), n = 0;
			for (let t of e.values()) n = Math.max(n, ...t, 0);
			return n * 2;
		}
		case 14: {
			let e = 0;
			for (let n of Oe(t).values()) for (let t of n) t >= 4 && (e += 5);
			return e;
		}
		case 15: {
			let e = /* @__PURE__ */ new Map();
			for (let n of t) e.set(B(n.row, n.x), n);
			let n = 0;
			for (let r of t) De(r.row, r.x).some((t) => e.get(t)?.color === r.color) || (n += 1);
			return n + (n >= 16 ? 7 : n >= 12 ? 3 : 0);
		}
		case 16: {
			let e = Oe(t), n = Math.max(0, ...e.get(2) ?? []), r = Math.max(0, ...e.get(0) ?? []);
			return Math.max(0, n * 2 - r * 2);
		}
		default: return 0;
	}
}
function ke(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = r.symbols.filter((e) => e === t).length;
		e > 0 && n.set(B(r.row, r.x), {
			half: r,
			count: e
		});
	}
	let r = /* @__PURE__ */ new Set(), i = [];
	for (let e of n.keys()) {
		if (r.has(e)) continue;
		let t = 0, a = [e];
		for (r.add(e); a.length;) {
			let e = a.pop(), i = n.get(e);
			if (i) {
				t += i.count;
				for (let e of De(i.half.row, i.half.x)) n.has(e) && !r.has(e) && (r.add(e), a.push(e));
			}
		}
		i.push(t);
	}
	return i;
}
function Ae(e) {
	return e.filter((e) => e.feather).length;
}
function je(e) {
	let t = 0;
	for (let n of e) {
		if (n.hoop === null) continue;
		let r = e.reduce((e, t) => e + t.symbols.filter((e) => e === n.hoop).length, 0);
		t += r * 3;
	}
	return t;
}
function Me(e, t, n) {
	let r = [...t], i = {
		seed: n,
		rngCursor: 0
	}, a = Array.from({ length: 81 }, (e, t) => t);
	k(a, i);
	let o = me(i, r.length), s = r[o], c = [
		0,
		1,
		2,
		3
	].map((e) => {
		let t = T.filter((t) => t.category === e).map((e) => e.id);
		return t[me(i, t.length)];
	});
	k(c, i);
	let l = {
		A: c[0],
		B: c[1],
		C: c[2],
		D: c[3]
	}, u = r.map((e, t) => {
		let n = (t - o + r.length) % r.length + 1;
		return {
			rid: e,
			set: n,
			supply: {
				threads: 1,
				needles: 1,
				thimble: !1,
				cards: []
			},
			tableau: [
				0,
				1,
				2
			].map((e) => ({
				id: ie(n, e),
				row: e,
				x: 0,
				needle: !1,
				seq: e
			})),
			passed: !1,
			embroiderDone: !1,
			exchange: null,
			score: 0,
			roundScore: null,
			choice: null
		};
	}), d = {
		seed: n,
		rngCursor: i.rngCursor,
		seq: 3,
		order: r,
		players: u,
		deck: a,
		discard: [],
		market: {
			threads: 0,
			needles: 0,
			thimble: !0,
			offers: []
		},
		general: {
			threads: 18 - r.length,
			needles: 14 - r.length
		},
		round: 1,
		phase: "shopping",
		turnIndex: o,
		startPlayer: s,
		thimbleHolder: s,
		soloStart: !0,
		mustPass: !1,
		scoring: l,
		history: []
	};
	return I(d, 1), { state: d };
}
function Ne(e, t, n) {
	if (t.type === "tick") return { state: e };
	let r = structuredClone(e), i = fe(r, n.by);
	if (!i) return { code: "games.fadenfroh.errNotSeated" };
	if (t.type === "scoreChoice") return r.phase === "scoring" ? i.choice === null ? (i.choice = t.which, r.players.every((e) => e.choice !== null) && (Se(r, 5), r.phase = "done"), { state: r }) : { code: "games.fadenfroh.errAlreadyChosen" } : { code: "games.fadenfroh.errNotScoring" };
	if (r.phase === "done" || r.phase === "scoring") return { code: "games.fadenfroh.errNotYourTurn" };
	if (t.type === "takeMaterial") return r.phase === "shopping" ? r.order[r.turnIndex] === n.by ? r.mustPass ? { code: "games.fadenfroh.errMustPass" } : t.kind === "thread" && r.market.threads <= 0 || t.kind === "needle" && r.market.needles <= 0 || t.kind === "thimble" && !r.market.thimble ? { code: "games.fadenfroh.errNoMaterial" } : (t.kind === "thread" ? --r.market.threads : t.kind === "needle" ? --r.market.needles : r.market.thimble = !1, _e(r, i, t.kind), O(r) ? be(r) : Ce(r, r.turnIndex), { state: r }) : { code: "games.fadenfroh.errNotYourTurn" } : { code: "games.fadenfroh.errShoppingOnly" };
	if (t.type === "takeOffer") return r.phase === "shopping" ? r.order[r.turnIndex] === n.by ? O(r) ? { code: "games.fadenfroh.errSoloTake" } : we(r, i, t.index) ? (Ce(r, r.turnIndex), { state: r }) : { code: "games.fadenfroh.errBadOffer" } : { code: "games.fadenfroh.errNotYourTurn" } : { code: "games.fadenfroh.errShoppingOnly" };
	if (t.type === "soloTake") return O(r) ? r.phase === "shopping" ? z(r, i, t.cards) ? { state: r } : { code: "games.fadenfroh.errBadOffer" } : { code: "games.fadenfroh.errShoppingOnly" } : { code: "games.fadenfroh.errSoloTake" };
	if (!i.passed) return { code: "games.fadenfroh.errNeedPass" };
	if (i.embroiderDone) return { code: "games.fadenfroh.errAlreadyDone" };
	if (t.type === "exchangeKeep") {
		if (!i.exchange || !i.exchange.drawn.includes(t.card)) return { code: "games.fadenfroh.errBadExchange" };
		let e = i.exchange.drawn.filter((e) => e !== t.card);
		return i.exchange = null, i.supply.threads -= 3, r.general.threads += 3, i.supply.cards.push(t.card), r.discard.push(...e), i.supply.threads >= 3 && j(r, i), i.supply.cards.length === 0 && !i.exchange && M(r, i), N(r) && F(r), { state: r };
	}
	if (t.type === "place") {
		if (i.exchange) return { code: "games.fadenfroh.errExchangePending" };
		if (!i.supply.cards.includes(t.card)) return { code: "games.fadenfroh.errNoCard" };
		let e = Ee(i.tableau, i.supply.needles).find((e) => e.row === t.row && e.x === t.x && e.needle === t.needle);
		return e ? (e.needle && --i.supply.needles, i.supply.cards.splice(i.supply.cards.indexOf(t.card), 1), r.seq += 1, i.tableau.push({
			id: t.card,
			row: t.row,
			x: t.x,
			needle: e.needle,
			seq: r.seq
		}), i.supply.cards.length === 0 && !i.exchange && M(r, i), N(r) && F(r), { state: r }) : { code: t.needle ? "games.fadenfroh.errNoNeedle" : "games.fadenfroh.errBadPlacement" };
	}
	return t.type === "discard" ? i.exchange ? { code: "games.fadenfroh.errExchangePending" } : i.supply.cards.includes(t.card) ? (i.supply.cards.splice(i.supply.cards.indexOf(t.card), 1), r.discard.push(t.card), i.supply.cards.length === 0 && !i.exchange && M(r, i), N(r) && F(r), { state: r }) : { code: "games.fadenfroh.errNoCard" } : t.type === "finish" ? i.exchange ? { code: "games.fadenfroh.errExchangePending" } : (M(r, i), N(r) && F(r), { state: r }) : { code: "games.fadenfroh.errNotYourTurn" };
}
function Pe(e, t) {
	let n = fe(e, t), { phase: r, turn: i } = L(e), a = n ? Te(n.tableau) : [], o = e.phase === "scoring" && n ? {
		B: V(e.scoring.B, a),
		C: V(e.scoring.C, a)
	} : null;
	return {
		public: {
			round: e.round,
			phase: r,
			solo: O(e),
			startPlayer: e.startPlayer,
			turn: i,
			mustPass: e.mustPass && i === t,
			market: {
				threads: e.market.threads,
				needles: e.market.needles,
				thimble: e.market.thimble,
				offers: e.market.offers.map((e) => [...e])
			},
			scoring: { ...e.scoring },
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			players: e.players.map((e) => ({
				rid: e.rid,
				set: e.set,
				score: e.score,
				roundScore: e.roundScore,
				passed: e.passed,
				embroiderDone: e.embroiderDone,
				exchange: e.exchange !== null,
				supply: {
					threads: e.supply.threads,
					needles: e.supply.needles,
					thimble: e.supply.thimble,
					cards: e.supply.cards.length
				},
				tableau: e.tableau.map((e) => ({
					id: e.id,
					row: e.row,
					x: e.x,
					needle: e.needle,
					seq: e.seq
				}))
			})),
			history: e.history.map((e) => ({ ...e })),
			choiceCount: e.players.filter((e) => e.choice !== null).length
		},
		private: {
			cards: n ? [...n.supply.cards] : [],
			exchange: n?.exchange ? [...n.exchange.drawn] : null,
			choicePreview: o,
			myChoice: n?.choice ?? null
		}
	};
}
function Fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n.rid] = n.score;
	let n = (t) => fe(e, t)?.set ?? 0, r = [...e.players].map((e) => e.rid).sort((e, r) => t[r] - t[e] || n(r) - n(e));
	return {
		phase: "done",
		winner: [r[0]],
		ranking: r,
		scores: t
	};
}
var H = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: oe,
	schemas: {
		action: D,
		publicView: ue,
		privateView: de
	},
	setup: Me,
	reduce: Ne,
	viewFor: Pe,
	status: Fe
}, U = "#4a382c";
function W({ children: e, className: t, title: n }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		className: t,
		role: n ? "img" : void 0,
		"aria-hidden": !n || void 0,
		children: [n && /* @__PURE__ */ p("title", { children: n }), e]
	});
}
function Ie({ symbol: e, className: t, title: n }) {
	switch (e) {
		case 0: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M12 4.8c1.7 0 3 1 3.4 2.3-1.2.6-2.7.5-3.9-.2-1 .8-2.4 1-3.5.5.5-1.6 2.1-2.6 4-2.6Z",
					fill: "#6f9a4e",
					stroke: "#3f5c2c",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "8.4",
					cy: "13.4",
					r: "3.7",
					fill: "#6371b8",
					stroke: "#333a66",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "15.6",
					cy: "13.4",
					r: "3.7",
					fill: "#5563aa",
					stroke: "#333a66",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "17.6",
					r: "3.7",
					fill: "#6b79c2",
					stroke: "#333a66",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "7.6",
					cy: "12.3",
					r: "0.9",
					fill: "#dfe4ff"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "15",
					cy: "12.2",
					r: "0.8",
					fill: "#dfe4ff"
				})
			]
		});
		case 1: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M5.9 11.6c.2-2.5 2.1-4.3 4.4-4.1.8.1 1.3.4 1.7.9.4-.5.9-.8 1.7-.9 2.3-.2 4.2 1.6 4.4 4.1.4 3.7-2 7.2-6.1 9.2-4.1-2-6.5-5.5-6.1-9.2Z",
					fill: "#c74f49",
					stroke: "#7a2a26",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 7.2c-2.1-1.7-4.6-1.8-6.3-.6 1.3.2 2.2.8 2.7 1.6M12 7.2c2.1-1.7 4.6-1.8 6.3-.6-1.3.2-2.2.8-2.7 1.6",
					fill: "#6f9a4e",
					stroke: "#3f5c2c",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 6.8V4.4",
					stroke: "#3f5c2c",
					strokeWidth: "1.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ m("g", {
					fill: "#f4dfa8",
					children: [
						/* @__PURE__ */ p("ellipse", {
							cx: "9.4",
							cy: "12.6",
							rx: "0.7",
							ry: "1"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "14.6",
							cy: "12.6",
							rx: "0.7",
							ry: "1"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "12",
							cy: "15.4",
							rx: "0.7",
							ry: "1"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "10.5",
							cy: "17.8",
							rx: "0.6",
							ry: "0.9"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "13.5",
							cy: "17.8",
							rx: "0.6",
							ry: "0.9"
						})
					]
				})
			]
		});
		case 2: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("ellipse", {
					cx: "8.7",
					cy: "6.3",
					rx: "1.8",
					ry: "3.6",
					transform: "rotate(-13 8.7 6.3)",
					fill: "#e0c9b6",
					stroke: "#6b5343",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("ellipse", {
					cx: "15.3",
					cy: "6.3",
					rx: "1.8",
					ry: "3.6",
					transform: "rotate(13 15.3 6.3)",
					fill: "#e0c9b6",
					stroke: "#6b5343",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("ellipse", {
					cx: "8.5",
					cy: "6",
					rx: "0.7",
					ry: "2",
					transform: "rotate(-13 8.5 6)",
					fill: "#dba3a3"
				}),
				/* @__PURE__ */ p("ellipse", {
					cx: "15.5",
					cy: "6",
					rx: "0.7",
					ry: "2",
					transform: "rotate(13 15.5 6)",
					fill: "#dba3a3"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "14",
					r: "5.8",
					fill: "#e6d2c1",
					stroke: "#6b5343",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "9.9",
					cy: "13.2",
					r: "0.8",
					fill: U
				}),
				/* @__PURE__ */ p("circle", {
					cx: "14.1",
					cy: "13.2",
					r: "0.8",
					fill: U
				}),
				/* @__PURE__ */ p("path", {
					d: "M11 15.6 12 16.4l1-.8",
					fill: "none",
					stroke: "#8a5a5a",
					strokeWidth: "1",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("path", {
					d: "M7.2 15.2h3.2M7.2 17h3M16.8 15.2h-3.2M16.8 17h-3",
					stroke: "#8a6a56",
					strokeWidth: "0.7",
					strokeLinecap: "round"
				})
			]
		});
		case 3: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M9.6 20.2c-3.1-.5-4.8-2.9-4.4-5.4.4-2 2-3.4 4.1-3.2",
					fill: "none",
					stroke: "#b5793f",
					strokeWidth: "3.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("ellipse", {
					cx: "14.1",
					cy: "15.3",
					rx: "4.2",
					ry: "5",
					fill: "#b5793f",
					stroke: "#6b3f20",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "14.4",
					cy: "9.4",
					r: "3.3",
					fill: "#c1874c",
					stroke: "#6b3f20",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12.6 6.6l-1.2-2.2 2.3.7M15.5 6.5l1.1-2.2-2.2.6",
					fill: "#c1874c",
					stroke: "#6b3f20",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "13.6",
					cy: "9.2",
					r: "0.8",
					fill: U
				}),
				/* @__PURE__ */ p("path", {
					d: "M17 11.4c1.1.3 1.7 1.1 1.7 2.1",
					fill: "none",
					stroke: "#6b3f20",
					strokeWidth: "0.9",
					strokeLinecap: "round"
				})
			]
		});
		case 4: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M5.6 19.6c0-4.9 2.8-8.4 6.4-8.4s6.4 3.5 6.4 8.4c0 1.2-.8 1.9-2 1.9H7.6c-1.2 0-2-.7-2-1.9Z",
					fill: "#8e8a84",
					stroke: "#4d4a45",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 5.6 6.6 3.4l.9 5.3M12 5.6l5.4-2.2-.9 5.3",
					fill: "#a19c94",
					stroke: "#4d4a45",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "9.9",
					cy: "13.4",
					r: "0.9",
					fill: U
				}),
				/* @__PURE__ */ p("circle", {
					cx: "14.1",
					cy: "13.4",
					r: "0.9",
					fill: U
				}),
				/* @__PURE__ */ p("path", {
					d: "M11 15.9 12 16.7l1-.8",
					fill: "none",
					stroke: "#4d4a45",
					strokeWidth: "0.9",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("path", {
					d: "M6.8 15h3.4M6.8 17h3.2M17.2 15h-3.4M17.2 17h-3.2",
					stroke: "#5c5851",
					strokeWidth: "0.7",
					strokeLinecap: "round"
				})
			]
		});
		case 5: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M12 20.4c0-3.4.4-6.8.4-9.4",
					stroke: "#5f7a3d",
					strokeWidth: "1.3",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("g", {
					stroke: "#a08d5c",
					strokeWidth: "0.9",
					strokeLinecap: "round",
					children: /* @__PURE__ */ p("path", { d: "M12 10.6 12 4.6M12 10.6 7.4 6.2M12 10.6l4.6-4.4M12 10.6 5.8 9.6M12 10.6l6.2-1M12 10.6 6.9 12.7M12 10.6l5.1 2.1" })
				}),
				/* @__PURE__ */ m("g", {
					fill: "#c2b07c",
					children: [
						/* @__PURE__ */ p("circle", {
							cx: "12",
							cy: "4.4",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "7.1",
							cy: "6",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "16.9",
							cy: "6",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "5.5",
							cy: "9.5",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "18.5",
							cy: "9.5",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "6.6",
							cy: "13",
							r: "0.9"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "17.4",
							cy: "13",
							r: "0.9"
						})
					]
				}),
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "10.6",
					r: "2",
					fill: "#e0bc5c",
					stroke: "#8f6f2c",
					strokeWidth: "0.8"
				})
			]
		});
		case 6: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M12 20.2c-2.8-1.8-4.6-4.7-4.4-7.9 2.1.2 3.6 1.7 4.4 3.4.8-1.7 2.3-3.2 4.4-3.4.2 3.2-1.6 6.1-4.4 7.9Z",
					fill: "#8a5fb0",
					stroke: "#543a72",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 20.2v-6.6M12 15.4c-1.4-2.2-3-3.3-4.6-3.7M12 15.4c1.4-2.2 3-3.3 4.6-3.7",
					stroke: "#5f7a3d",
					strokeWidth: "1.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("path", {
					d: "M9.4 12.6c-.9-2-2.4-3-4-3.2.3 2.1 1.5 3.7 3.2 4.4M14.6 12.6c.9-2 2.4-3 4-3.2-.3 2.1-1.5 3.7-3.2 4.4",
					fill: "none",
					stroke: "#6f9a4e",
					strokeWidth: "1",
					strokeLinecap: "round"
				})
			]
		});
		case 7: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ p("path", {
					d: "M12 15.4v6",
					stroke: "#5f7a3d",
					strokeWidth: "1.4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 17.6c-1.8-.2-3.2-1.2-4-2.8 1.9-.6 3.6 0 4.8 1.4M12 17.6c1.8-.2 3.2-1.2 4-2.8-1.9-.6-3.6 0-4.8 1.4",
					fill: "#6f9a4e",
					stroke: "#3f5c2c",
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 3.4l1.3 2 2.3-.7.2 2.3 2.2.7-1.2 1.9 1.2 1.9-2.2.7-.2 2.3-2.3-.7-1.3 2-1.3-2-2.3.7-.2-2.3-2.2-.7 1.2-1.9-1.2-1.9 2.2-.7.2-2.3 2.3.7Z",
					fill: "#8a5fb0",
					stroke: "#543a72",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 7v7M9.6 8.4h4.8M9.4 11.6h5.2",
					stroke: "#6a4790",
					strokeWidth: "0.7",
					strokeLinecap: "round"
				})
			]
		});
		case 8: return /* @__PURE__ */ m(W, {
			className: t,
			title: n,
			children: [
				/* @__PURE__ */ m("g", {
					fill: "#f6f1e2",
					stroke: "#9a8c6a",
					strokeWidth: "0.8",
					children: [
						/* @__PURE__ */ p("ellipse", {
							cx: "12",
							cy: "4.6",
							rx: "1.7",
							ry: "3"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "12",
							cy: "19.4",
							rx: "1.7",
							ry: "3"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "4.6",
							cy: "12",
							rx: "3",
							ry: "1.7"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "19.4",
							cy: "12",
							rx: "3",
							ry: "1.7"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "6.8",
							cy: "6.8",
							rx: "1.7",
							ry: "3",
							transform: "rotate(-45 6.8 6.8)"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "17.2",
							cy: "6.8",
							rx: "1.7",
							ry: "3",
							transform: "rotate(45 17.2 6.8)"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "6.8",
							cy: "17.2",
							rx: "1.7",
							ry: "3",
							transform: "rotate(45 6.8 17.2)"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "17.2",
							cy: "17.2",
							rx: "1.7",
							ry: "3",
							transform: "rotate(-45 17.2 17.2)"
						})
					]
				}),
				/* @__PURE__ */ p("circle", {
					cx: "12",
					cy: "12",
					r: "2.6",
					fill: "#e0bc5c",
					stroke: "#8f6f2c",
					strokeWidth: "0.9"
				}),
				/* @__PURE__ */ p("path", {
					d: "M12 20.4V21.4",
					stroke: "#5f7a3d",
					strokeWidth: "1",
					strokeLinecap: "round"
				})
			]
		});
		default: return /* @__PURE__ */ p(W, {
			className: t,
			title: n,
			children: /* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "6",
				fill: "#c9bda5"
			})
		});
	}
}
function G({ className: e, title: t }) {
	return /* @__PURE__ */ m(W, {
		className: e,
		title: t,
		children: [
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				fill: "none",
				stroke: "#a08a52",
				strokeWidth: "1.2",
				strokeDasharray: "2.4 2.2"
			}),
			/* @__PURE__ */ p("g", {
				stroke: "#b09a62",
				strokeWidth: "1",
				strokeLinecap: "round",
				children: /* @__PURE__ */ p("path", { d: "M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.6 5.6l1.6 1.6M16.8 16.8l1.6 1.6M18.4 5.6l-1.6 1.6M7.2 16.8l-1.6 1.6" })
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "2.2",
				fill: "#e3c97e",
				stroke: "#8f7034",
				strokeWidth: "0.9"
			})
		]
	});
}
function Le({ animal: e, className: t, title: n }) {
	return /* @__PURE__ */ m(W, {
		className: t,
		title: n,
		children: [
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.6",
				r: "8",
				fill: "#f6efdc",
				stroke: "#9a6b3c",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.6",
				r: "6.2",
				fill: "none",
				stroke: "#c9a26a",
				strokeWidth: "0.8"
			}),
			/* @__PURE__ */ p("rect", {
				x: "10.8",
				y: "2.6",
				width: "2.4",
				height: "3.4",
				rx: "0.8",
				fill: "#b98c50",
				stroke: "#7a5227",
				strokeWidth: "0.7"
			}),
			/* @__PURE__ */ m("g", {
				fill: "#8a5f3c",
				stroke: "#5d3d24",
				strokeWidth: "0.7",
				children: [
					e === 2 && /* @__PURE__ */ m(f, { children: [
						/* @__PURE__ */ p("ellipse", {
							cx: "10.6",
							cy: "9.4",
							rx: "1",
							ry: "2.2",
							transform: "rotate(-14 10.6 9.4)"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "13.4",
							cy: "9.4",
							rx: "1",
							ry: "2.2",
							transform: "rotate(14 13.4 9.4)"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "12",
							cy: "13.2",
							r: "3.1"
						})
					] }),
					e === 3 && /* @__PURE__ */ m(f, { children: [
						/* @__PURE__ */ p("path", {
							d: "M9 15.8c-1.4-1-1.8-2.5-1.2-3.6.6-1 1.9-1.2 2.9-.5",
							fill: "none",
							stroke: "#8a5f3c",
							strokeWidth: "1.6",
							strokeLinecap: "round"
						}),
						/* @__PURE__ */ p("ellipse", {
							cx: "13.2",
							cy: "13.4",
							rx: "2.2",
							ry: "2.8"
						}),
						/* @__PURE__ */ p("circle", {
							cx: "13.6",
							cy: "9.8",
							r: "1.8"
						})
					] }),
					e === 4 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M12 8.2 9.4 7l.4 2.2M12 8.2 14.6 7l-.4 2.2" }), /* @__PURE__ */ p("circle", {
						cx: "12",
						cy: "12.4",
						r: "3"
					})] })
				]
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.4",
				r: "0.6",
				fill: "#f6efdc"
			})
		]
	});
}
function Re({ tone: e, className: t }) {
	let n = e === "green" ? "#6f9a4e" : e === "yellow" ? "#d9b13f" : "#8a5fb0", r = e === "green" ? "#3f5c2c" : e === "yellow" ? "#8f6f2c" : "#543a72";
	return /* @__PURE__ */ m(W, {
		className: t,
		children: [
			/* @__PURE__ */ p("ellipse", {
				cx: "12.4",
				cy: "13.4",
				rx: "9.4",
				ry: "8.6",
				fill: "rgba(60,40,20,0.22)"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.4",
				r: "9",
				fill: n,
				stroke: r,
				strokeWidth: "1"
			}),
			/* @__PURE__ */ p("g", {
				stroke: r,
				strokeWidth: "0.7",
				opacity: "0.5",
				children: /* @__PURE__ */ p("path", { d: "M12 3.4v3.2M12 18.2v3.2M3.2 12.4h3.2M17.6 12.4h3.2M5.8 6.2l2.3 2.3M15.9 16.3l2.3 2.3M18.2 6.2l-2.3 2.3M8.1 16.3l-2.3 2.3" })
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.4",
				r: "4.2",
				fill: "#f2e7cf",
				stroke: r,
				strokeWidth: "1"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12.4",
				r: "2.6",
				fill: "#e3d3b1"
			}),
			/* @__PURE__ */ p("path", {
				d: "M6.6 8.2c2.8-2.4 8-2.6 10.9-.6",
				fill: "none",
				stroke: "#f8f2e4",
				strokeWidth: "0.9",
				strokeLinecap: "round",
				opacity: "0.75"
			})
		]
	});
}
function K({ className: e }) {
	return /* @__PURE__ */ m(W, {
		className: e,
		children: [
			/* @__PURE__ */ p("rect", {
				x: "2.4",
				y: "4.2",
				width: "19.2",
				height: "15.6",
				rx: "3",
				fill: "#f6f1e4",
				stroke: "#b09a72",
				strokeWidth: "0.9"
			}),
			/* @__PURE__ */ p("rect", {
				x: "4.2",
				y: "5.9",
				width: "15.6",
				height: "12.2",
				rx: "2",
				fill: "none",
				stroke: "#cbb98f",
				strokeWidth: "0.6",
				strokeDasharray: "1.6 1.4"
			}),
			/* @__PURE__ */ p("path", {
				d: "M16.9 7.2 7.1 17.4",
				stroke: "#a9b2ba",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M16.9 7.2 7.1 17.4",
				stroke: "#6d747b",
				strokeWidth: "0.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("ellipse", {
				cx: "16.4",
				cy: "8.4",
				rx: "0.9",
				ry: "1.7",
				transform: "rotate(38 16.4 8.4)",
				fill: "none",
				stroke: "#6d747b",
				strokeWidth: "0.9"
			}),
			/* @__PURE__ */ p("path", {
				d: "M8.2 16.4 7.1 17.4",
				stroke: "#f6f1e4",
				strokeWidth: "0.6",
				strokeLinecap: "round"
			})
		]
	});
}
function ze({ className: e }) {
	return /* @__PURE__ */ m(W, {
		className: e,
		children: [
			/* @__PURE__ */ p("path", {
				d: "M6.4 20v-7.2c0-3.4 2.4-6 5.6-6s5.6 2.6 5.6 6V20Z",
				fill: "#d3d9df",
				stroke: "#6d747b",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ p("path", {
				d: "M7 18.6c1.2-1.8 3-2.8 5-2.8s3.8 1 5 2.8v1.2H7Z",
				fill: "#b7bec6",
				opacity: "0.7"
			}),
			/* @__PURE__ */ p("path", {
				d: "M6.4 15.4h11.2",
				stroke: "#6d747b",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ m("g", {
				fill: "#8d949b",
				children: [
					/* @__PURE__ */ p("circle", {
						cx: "9",
						cy: "10.4",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "12",
						cy: "9.6",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "15",
						cy: "10.4",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "8.4",
						cy: "13",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "10.8",
						cy: "12.4",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "13.2",
						cy: "12.4",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "15.6",
						cy: "13",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "9.4",
						cy: "15.4",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "12",
						cy: "15",
						r: "0.6"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "14.6",
						cy: "15.4",
						r: "0.6"
					})
				]
			}),
			/* @__PURE__ */ p("path", {
				d: "M6.6 19v1.4h10.8V19",
				fill: "#a9b2ba",
				stroke: "#6d747b",
				strokeWidth: "0.8"
			})
		]
	});
}
//#endregion
//#region src/game/card-view.tsx
var q = {
	0: "games.fadenfroh.symBlueberry",
	1: "games.fadenfroh.symStrawberry",
	2: "games.fadenfroh.symBunny",
	3: "games.fadenfroh.symSquirrel",
	4: "games.fadenfroh.symCat",
	5: "games.fadenfroh.symDandelion",
	6: "games.fadenfroh.symCrocus",
	7: "games.fadenfroh.symThistle",
	8: "games.fadenfroh.symDaisy"
}, Be = [
	"games.fadenfroh.colorWhite",
	"games.fadenfroh.colorYellow",
	"games.fadenfroh.colorPurple"
];
function Ve(e, t) {
	let n = e(Be[t.color]), r = e("games.fadenfroh.halfEmpty");
	return t.symbols.length > 0 ? r = t.symbols.map((t) => e(q[t])).join(" ") : t.feather ? r = e("games.fadenfroh.halfFeather") : t.hoop !== null && (r = e("games.fadenfroh.halfHoop", {
		animal: e(q[t.hoop]),
		n: 3
	})), {
		color: n,
		content: r
	};
}
function J(e, t) {
	let [n, r] = w(t), i = Ve(e, n), a = Ve(e, r);
	return `${e("games.fadenfroh.halfAria", {
		color: i.color,
		content: i.content
	})}${e("games.fadenfroh.halfJoin")}${e("games.fadenfroh.halfAria", {
		color: a.color,
		content: a.content
	})}`;
}
function Y({ half: e, size: t = "md" }) {
	let n = s(), r = `fdf-half fdf-half--c${e.color} fdf-half--${t}${e.hoop === null ? "" : " fdf-half--hoop"}`;
	return /* @__PURE__ */ m("span", {
		className: r,
		children: [
			e.symbols.length > 0 && /* @__PURE__ */ p("span", {
				className: "fdf-half__glyphs",
				children: e.symbols.map((e, t) => /* @__PURE__ */ p(Ie, {
					symbol: e,
					className: "fdf-glyph"
				}, t))
			}),
			e.feather && /* @__PURE__ */ p(G, { className: "fdf-glyph" }),
			e.hoop !== null && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Le, {
				animal: e.hoop,
				className: "fdf-glyph",
				title: n("games.fadenfroh.hoopScoreText", {
					animal: n(q[e.hoop]),
					n: 3
				})
			}), /* @__PURE__ */ p("span", {
				className: "fdf-half__hoop-score",
				"aria-hidden": "true",
				children: n("games.fadenfroh.hoopValueShort", { n: 3 })
			})] }),
			e.symbols.length === 0 && !e.feather && e.hoop === null && /* @__PURE__ */ p("span", {
				className: "fdf-half__empty",
				"aria-hidden": "true"
			})
		]
	});
}
function X({ id: e, className: t = "", showSet: n = !1, ariaLabel: r, dim: i = !1, children: a }) {
	let [o, s] = w(e), c = re(e) ? S(e) : null;
	return /* @__PURE__ */ m("span", {
		className: `fdf-card${c ? " fdf-card--start" : ""} ${t}${i ? " fdf-card--dim" : ""}`,
		role: "img",
		"aria-label": r,
		children: [
			/* @__PURE__ */ p(Y, { half: o }),
			/* @__PURE__ */ p(Y, { half: s }),
			n && c && /* @__PURE__ */ p(He, {
				set: c.set,
				color: c.color
			}),
			a
		]
	});
}
function He({ set: e, color: t }) {
	let n = s();
	return /* @__PURE__ */ p("span", {
		className: `fdf-card__set fdf-card__set--c${t}`,
		title: n("games.fadenfroh.startSet", { n: e }),
		"aria-hidden": "true",
		children: e
	});
}
//#endregion
//#region src/game/copy.ts
var Ue = [
	"A",
	"B",
	"C",
	"D"
], Z = {
	A: "games.fadenfroh.slotA",
	B: "games.fadenfroh.slotB",
	C: "games.fadenfroh.slotC",
	D: "games.fadenfroh.slotD"
}, We = {
	1: "games.fadenfroh.card01Name",
	2: "games.fadenfroh.card02Name",
	3: "games.fadenfroh.card03Name",
	4: "games.fadenfroh.card04Name",
	5: "games.fadenfroh.card05Name",
	6: "games.fadenfroh.card06Name",
	7: "games.fadenfroh.card07Name",
	8: "games.fadenfroh.card08Name",
	9: "games.fadenfroh.card09Name",
	10: "games.fadenfroh.card10Name",
	11: "games.fadenfroh.card11Name",
	12: "games.fadenfroh.card12Name",
	13: "games.fadenfroh.card13Name",
	14: "games.fadenfroh.card14Name",
	15: "games.fadenfroh.card15Name",
	16: "games.fadenfroh.card16Name"
}, Q = {
	1: "games.fadenfroh.card01Text",
	2: "games.fadenfroh.card02Text",
	3: "games.fadenfroh.card03Text",
	4: "games.fadenfroh.card04Text",
	5: "games.fadenfroh.card05Text",
	6: "games.fadenfroh.card06Text",
	7: "games.fadenfroh.card07Text",
	8: "games.fadenfroh.card08Text",
	9: "games.fadenfroh.card09Text",
	10: "games.fadenfroh.card10Text",
	11: "games.fadenfroh.card11Text",
	12: "games.fadenfroh.card12Text",
	13: "games.fadenfroh.card13Text",
	14: "games.fadenfroh.card14Text",
	15: "games.fadenfroh.card15Text",
	16: "games.fadenfroh.card16Text"
};
function Ge(e, t, n) {
	return n === "feather" ? e("games.fadenfroh.detailFeather") : n === "hoop" ? e("games.fadenfroh.detailHoop") : n === "material" ? e("games.fadenfroh.detailMaterial") : t.includes(n) ? e("games.fadenfroh.detailFixed", { slot: n }) : e("games.fadenfroh.detailChoice", { slot: n });
}
//#endregion
//#region src/game/staging.ts
function Ke(e, t, n) {
	let r = [];
	for (let i of n) Ee([...e, ...r.map((e, t) => ({
		id: e.card,
		row: e.row,
		x: e.x,
		needle: e.needle,
		seq: 1e6 + t
	}))], Math.max(0, t - r.filter((e) => e.needle).length)).some((e) => e.row === i.row && e.x === i.x && e.needle === i.needle) && r.push(i);
	return r;
}
//#endregion
//#region src/game/view-player.tsx
function qe(e) {
	let t = E[e];
	return t ? [...t.fixed, ...t.choose ?? []] : [];
}
function Je(e, t, n) {
	if (e.key !== t) return [];
	let r = e.ids.filter((e) => n.includes(e));
	return r.length === 2 && Math.abs(n.indexOf(r[0]) - n.indexOf(r[1])) !== 1 ? [r[0]] : r;
}
function Ye(e, t, n) {
	let r = n.indexOf(t);
	return r < 0 ? [...e] : e.includes(t) ? e.filter((e) => e !== t) : e.length === 0 ? [t] : e.length === 1 && Math.abs(n.indexOf(e[0]) - r) === 1 ? [e[0], t] : [t];
}
function Xe(e) {
	return `${e.row}:${e.x}:${+!!e.needle}`;
}
function Ze(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = `${n.row}:${n.x}`, r = t.get(e);
		(!r || r.needle && !n.needle) && t.set(e, n);
	}
	return [...t.values()];
}
function Qe(e) {
	return Math.floor((e - 1) / 4);
}
function $e({ slot: e, num: t, active: n, choose: r, onOpen: i }) {
	let a = s(), o = a(We[t]), c = Qe(t);
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: `fdf-scorecard fdf-scorecard--${e.toLowerCase()}${n ? " is-active" : ""}${r ? " is-choose" : ""}`,
		"aria-label": a("games.fadenfroh.scoringCardAria", {
			slot: a(Z[e]),
			name: o,
			text: a(Q[t])
		}),
		onClick: i,
		children: [
			/* @__PURE__ */ m("span", {
				className: "fdf-scorecard__top",
				children: [/* @__PURE__ */ p("span", {
					className: "fdf-scorecard__slot",
					children: a(Z[e])
				}), /* @__PURE__ */ p("span", {
					className: "fdf-scorecard__num",
					children: a("games.fadenfroh.cardNumber", { n: t })
				})]
			}),
			/* @__PURE__ */ p("strong", {
				className: "fdf-scorecard__name",
				children: o
			}),
			/* @__PURE__ */ p("span", {
				className: "fdf-scorecard__cat",
				"aria-hidden": "true",
				children: c === 3 ? /* @__PURE__ */ m("span", {
					className: "fdf-scorecard__swatches",
					children: [
						/* @__PURE__ */ p("i", {}),
						/* @__PURE__ */ p("i", {}),
						/* @__PURE__ */ p("i", {})
					]
				}) : /* @__PURE__ */ p(Ie, {
					symbol: c === 0 ? 0 : c === 1 ? 2 : 5,
					className: "fdf-scorecard__cat-icon"
				})
			}),
			r && /* @__PURE__ */ p("span", {
				className: "fdf-scorecard__pick",
				children: a("games.fadenfroh.scorePickTag")
			}),
			n && /* @__PURE__ */ p("span", {
				className: "fdf-scorecard__stitch",
				"aria-hidden": "true"
			})
		]
	});
}
function et({ label: e, count: t, icon: n, onClick: r, disabled: i, active: a }) {
	let o = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
		className: "fdf-token__obj",
		children: n
	}), /* @__PURE__ */ m("span", {
		className: "fdf-token__meta",
		children: [/* @__PURE__ */ p("span", {
			className: "fdf-token__label",
			children: e
		}), t !== void 0 && /* @__PURE__ */ p("b", {
			className: "fdf-token__count",
			children: t > 0 ? `×${t}` : "0"
		})]
	})] });
	return r ? /* @__PURE__ */ p("button", {
		type: "button",
		className: `fdf-token fdf-token--take${a ? " is-live" : ""}`,
		onClick: r,
		disabled: i,
		children: o
	}) : /* @__PURE__ */ p("span", {
		className: `fdf-token${a ? " is-live" : ""}${i ? " is-off" : ""}`,
		children: o
	});
}
function tt({ player: e, compact: t }) {
	return /* @__PURE__ */ m("span", {
		className: `fdf-tray${t ? " fdf-tray--compact" : ""}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("span", {
				className: `fdf-tray__item${e.supply.threads > 0 ? "" : " is-off"}`,
				children: [
					/* @__PURE__ */ p(Re, {
						tone: "green",
						className: "fdf-tray__icon"
					}),
					" ",
					/* @__PURE__ */ p("b", { children: e.supply.threads })
				]
			}),
			/* @__PURE__ */ m("span", {
				className: `fdf-tray__item${e.supply.needles > 0 ? "" : " is-off"}`,
				children: [
					/* @__PURE__ */ p(K, { className: "fdf-tray__icon" }),
					" ",
					/* @__PURE__ */ p("b", { children: e.supply.needles })
				]
			}),
			/* @__PURE__ */ p("span", {
				className: `fdf-tray__item${e.supply.thimble ? "" : " is-off"}`,
				children: /* @__PURE__ */ p(ze, { className: "fdf-tray__icon" })
			}),
			!t && e.supply.cards > 0 && /* @__PURE__ */ m("span", {
				className: "fdf-tray__cards",
				children: ["＋", e.supply.cards]
			})
		]
	});
}
function nt(e, t) {
	return e.some((e) => e.x === t.x + 2) ? "right" : "left";
}
function rt(e, t) {
	return e.some((e) => e !== t && e.x + 2 === t.x) ? "left" : e.some((e) => e !== t && e.x === t.x + 2) ? "right" : "left";
}
function it({ row: e, cards: t, widthOptions: n, drops: r, pending: i, selectedId: a, hoverKey: o, onPlace: c }) {
	let l = s(), u = i.map((t, n) => ({
		id: t.card,
		row: e,
		x: t.x,
		needle: t.needle,
		seq: 1e6 + n
	})), d = [...t, ...u], ee = Math.min(0, ...d.map((e) => e.x)), f = Math.max(2, ...d.map((e) => e.x + 2)), h = Math.min(ee, ...n.map((e) => e.x)), g = Math.max(f, ...n.map((e) => e.x + 2)), _ = Math.max(6, g - h), v = `max(0px, calc(50% - var(--fdf-cell) * ${(f - ee) / 2 + (ee - h)}))`, y = { width: `max(calc(var(--fdf-cell) * ${_}), 100%)` };
	return /* @__PURE__ */ m("div", {
		className: "fdf-row",
		"data-row": e + 1,
		children: [/* @__PURE__ */ m("div", {
			className: "fdf-row__label",
			children: [/* @__PURE__ */ p("span", {
				className: "sr-only",
				children: l("games.fadenfroh.rowLabel", { n: e + 1 })
			}), /* @__PURE__ */ p("span", {
				"aria-hidden": "true",
				children: e + 1
			})]
		}), /* @__PURE__ */ p("div", {
			className: "fdf-row__scroll",
			children: /* @__PURE__ */ m("div", {
				className: "fdf-row__track",
				style: y,
				children: [
					t.map((e) => {
						let n = rt(t, e);
						return /* @__PURE__ */ m("div", {
							className: "fdf-slot",
							style: {
								left: `calc(var(--fdf-cell) * ${e.x - h} + ${v})`,
								zIndex: e.seq + 1
							},
							children: [/* @__PURE__ */ p(X, {
								id: e.id,
								showSet: re(e.id),
								ariaLabel: J(l, e.id)
							}), e.needle && /* @__PURE__ */ p("span", {
								className: `fdf-needle fdf-needle--${n}`,
								"aria-hidden": "true",
								children: /* @__PURE__ */ p(K, {})
							})]
						}, e.seq);
					}),
					u.map((e) => {
						let t = nt(d, e);
						return /* @__PURE__ */ m("div", {
							className: "fdf-slot fdf-pending",
							style: {
								left: `calc(var(--fdf-cell) * ${e.x - h} + ${v})`,
								zIndex: 4e3 + e.seq
							},
							children: [
								/* @__PURE__ */ p("span", {
									className: "fdf-pending__card",
									children: /* @__PURE__ */ p(at, { id: e.id })
								}),
								e.needle && /* @__PURE__ */ p("span", {
									className: `fdf-needle fdf-needle--${t}`,
									"aria-hidden": "true",
									children: /* @__PURE__ */ p(K, {})
								}),
								/* @__PURE__ */ p("span", {
									className: "fdf-pending__tag",
									"aria-hidden": "true",
									children: l("games.fadenfroh.pendingTag")
								})
							]
						}, `pending-${e.id}`);
					}),
					r.map((e) => {
						let n = Xe(e), r = o === n && a !== null, i = nt(t, e);
						return /* @__PURE__ */ m("button", {
							type: "button",
							"data-fdf-drop": n,
							className: `fdf-drop${r ? " is-hover" : ""}${e.needle ? " fdf-drop--needle" : ""}`,
							style: {
								left: `calc(var(--fdf-cell) * ${e.x - h} + ${v})`,
								zIndex: 5e3
							},
							"aria-label": e.needle ? l("games.fadenfroh.needlePlaceHere") : l("games.fadenfroh.placeHere"),
							onClick: () => c(e),
							children: [
								/* @__PURE__ */ p("span", {
									className: "fdf-drop__outline",
									"aria-hidden": "true"
								}),
								e.needle && /* @__PURE__ */ p("span", {
									className: `fdf-drop__needle fdf-drop__needle--${i}`,
									"aria-hidden": "true",
									children: /* @__PURE__ */ p(K, {})
								}),
								r && a !== null && /* @__PURE__ */ p("span", {
									className: "fdf-drop__ghost",
									"aria-hidden": "true",
									children: /* @__PURE__ */ p(at, { id: a })
								}),
								r && a !== null && /* @__PURE__ */ p("span", {
									className: "fdf-drop__hint",
									"aria-hidden": "true",
									children: e.needle ? l("games.fadenfroh.needlePlaceHere") : l("games.fadenfroh.placeHere")
								})
							]
						}, n);
					})
				]
			})
		})]
	});
}
function at({ id: e }) {
	let [t, n] = w(e);
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Y, { half: t }), /* @__PURE__ */ p(Y, { half: n })] });
}
function ot(e) {
	let t = e.public, h = e.private, g = s(), _ = o((e) => e.locale), v = e.members, y = e.myRid, b = e.send, [te, ne] = i(!1), [x, ie] = i(null), S = t.players.find((e) => e.rid === y), C = t.phase === "embroidery" && S !== void 0 && S.passed && !S.embroiderDone && !h?.exchange, w = `${t.round}:${t.phase}`, T = `${w}:${+!!C}`, [ae, D] = i({
		key: "",
		card: -1
	}), [se, ce] = i({
		key: "",
		ids: []
	}), [le, ue] = i({
		key: "",
		rid: y
	}), [de, O] = i({
		key: "",
		items: []
	}), [fe, pe] = i(!1), [me, k] = i(null), [he, ge] = i(null), [_e, ve] = i(null), A = r(null), ye = r(!1), be = r(null), j = h?.cards, M = n(() => j ?? [], [j]), N = ae.key === w && M.includes(ae.card) ? ae.card : null, P = de.key === w ? de.items : [], xe = (e) => {
		if (!S) {
			O({
				key: "",
				items: []
			});
			return;
		}
		let t = Ke(S.tableau, S.supply.needles, e), n = e.length - t.length;
		n > 0 && (k(g("games.fadenfroh.pendingInvalidated", { n })), window.setTimeout(() => k(null), 4200)), O({
			key: w,
			items: t
		});
	}, Se = (() => {
		if (!C || !S || N === null) return [];
		let e = P.filter((e) => e.card !== N);
		return Ee([...S.tableau, ...e.map((e, t) => ({
			id: e.card,
			row: e.row,
			x: e.x,
			needle: e.needle,
			seq: 1e6 + t
		}))], Math.max(0, S.supply.needles - e.filter((e) => e.needle).length));
	})(), F = N === null ? [] : Ze(Se), I = le.key === T ? le.rid : C ? y : le.rid, L = t.players.find((e) => e.rid === I) ?? t.players[0], R = (e) => {
		let t = v.find((t) => t.rid === e);
		return t ? ee(t, _) : e;
	}, Ce = (e) => {
		let t = v.find((t) => t.rid === e);
		return t ? a[t.avatar % a.length] : null;
	}, we = n(() => t.market.offers.flat(), [t.market.offers]), z = n(() => Je(se, w, we), [
		se,
		w,
		we
	]), Te = (e) => {
		ue({
			key: T,
			rid: y
		}), D((t) => t.key === w && t.card === e ? {
			key: "",
			card: -1
		} : {
			key: w,
			card: e
		});
	}, B = (e, t) => {
		let n = P.filter((t) => t.card !== e);
		xe([...n, {
			card: e,
			...t
		}]), D({
			key: "",
			card: -1
		}), ve(null);
	}, De = (e) => {
		N !== null && B(N, e);
	}, Oe = () => {
		if (fe) return;
		let e = S ? Ke(S.tableau, S.supply.needles, P) : [];
		pe(!0), window.setTimeout(() => pe(!1), 2600);
		for (let t of e) b({
			type: "place",
			card: t.card,
			row: t.row,
			x: t.x,
			needle: t.needle
		});
		b({ type: "finish" }), O({
			key: "",
			items: []
		}), k(null), D({
			key: "",
			card: -1
		}), ve(null);
	}, V = (e, t) => {
		let n = be.current;
		if (!n) return null;
		let r = n.getBoundingClientRect();
		if (e < r.left - 20 || e > r.right + 20 || t < r.top - 20 || t > r.bottom + 20) return null;
		let i = null, a = Infinity;
		return n.querySelectorAll("[data-fdf-drop]").forEach((n) => {
			let r = n.getBoundingClientRect(), o = Math.hypot(e - (r.left + r.width / 2), t - (r.top + r.height / 2));
			o < a && (a = o, i = n.dataset.fdfDrop ?? null);
		}), i;
	}, ke = (e) => (t) => {
		C && t.button === 0 && (t.currentTarget.setPointerCapture(t.pointerId), A.current = {
			card: e,
			pointerId: t.pointerId,
			startX: t.clientX,
			startY: t.clientY,
			active: !1
		});
	}, Ae = (e) => {
		let t = A.current;
		if (t && t.pointerId === e.pointerId) {
			if (!t.active) {
				if (Math.hypot(e.clientX - t.startX, e.clientY - t.startY) < 7) return;
				t.active = !0, ue({
					key: T,
					rid: y
				}), D({
					key: w,
					card: t.card
				});
			}
			ve(V(e.clientX, e.clientY)), ge({
				card: t.card,
				x: e.clientX,
				y: e.clientY
			});
		}
	}, je = (e) => {
		let t = A.current;
		if (!t || t.pointerId !== e.pointerId || (A.current = null, !t.active)) return;
		ye.current = !0, window.setTimeout(() => {
			ye.current = !1;
		}, 350);
		let n = V(e.clientX, e.clientY);
		if (n) {
			let [e, r, i] = n.split(":").map(Number);
			B(t.card, {
				row: e,
				x: r,
				needle: i === 1
			});
		}
		ve(null), ge(null);
	}, Me = (e) => P.some((t) => t.card === e), Ne = (e) => {
		if (ye.current) {
			ye.current = !1;
			return;
		}
		if (Me(e)) {
			xe(P.filter((t) => t.card !== e)), ue({
				key: T,
				rid: y
			}), D({
				key: w,
				card: e
			});
			return;
		}
		Te(e);
	}, Pe = () => {
		N !== null && (xe(P.filter((e) => e.card !== N)), b({
			type: "discard",
			card: N
		}), D({
			key: "",
			card: -1
		}));
	}, Fe = (e) => {
		we.includes(e) && ce({
			key: w,
			ids: Ye(z, e, we)
		});
	}, H = t.turn === y && S !== void 0 && !S.passed, U = t.phase === "shopping" && H && S !== void 0, W, G = "info", Le = t.turn ? R(t.turn) : "";
	if (t.phase === "done") W = g("games.fadenfroh.bannerDone"), G = "done";
	else if (t.phase === "scoring") {
		let e = h?.myChoice ?? null;
		W = g(e === null ? "games.fadenfroh.bannerScoring" : "games.fadenfroh.bannerScoringWait"), G = e === null ? "accent" : "info";
	} else t.phase === "embroidery" ? S && S.passed && !S.embroiderDone ? (W = g("games.fadenfroh.bannerEmbroidery"), G = "accent") : W = g("games.fadenfroh.bannerEmbroideryWait") : t.solo ? (W = H ? t.mustPass ? g("games.fadenfroh.bannerMustPass") : g("games.fadenfroh.bannerShopping") : g("games.fadenfroh.bannerTurn", { name: Le }), G = H ? "accent" : "info") : t.mustPass ? (W = g("games.fadenfroh.bannerMustPass"), G = "accent") : H ? (W = g("games.fadenfroh.bannerShopping"), G = "accent") : W = g("games.fadenfroh.bannerTurn", { name: Le });
	let q = qe(t.round), Be = /* @__PURE__ */ m("section", {
		className: "fdf-panel fdf-panel--round",
		"aria-label": g("games.fadenfroh.scoringTitle"),
		children: [/* @__PURE__ */ m("div", {
			className: "fdf-round__label",
			children: [/* @__PURE__ */ p("span", {
				className: "fdf-round__round",
				children: g("games.fadenfroh.roundLabel", { n: t.round })
			}), q.length > 0 && /* @__PURE__ */ p("span", {
				className: "fdf-round__active",
				children: q.map((e) => g(Z[e])).join(" · ")
			})]
		}), /* @__PURE__ */ m("div", {
			className: "fdf-round__grid",
			children: [Ue.map((e) => {
				let n = t.scoring[e], r = q.includes(e), i = (E[t.round]?.choose ?? []).includes(e);
				return /* @__PURE__ */ p($e, {
					slot: e,
					num: n,
					active: r,
					choose: i,
					onOpen: () => ie(e)
				}, e);
			}), /* @__PURE__ */ p("span", {
				className: "fdf-round__mark",
				"aria-hidden": "true",
				children: /* @__PURE__ */ p("span", {
					className: "fdf-round__mark-label",
					children: g("games.fadenfroh.roundLabel", { n: t.round })
				})
			})]
		})]
	}), Ve = /* @__PURE__ */ m("section", {
		className: `fdf-panel fdf-panel--market${t.phase === "shopping" ? "" : " fdf-market--closed"}`,
		"aria-label": g("games.fadenfroh.marketTitle"),
		children: [/* @__PURE__ */ m("div", {
			className: "fdf-panel__head",
			children: [/* @__PURE__ */ p("h2", {
				className: "fdf-panel__title",
				children: g("games.fadenfroh.marketTitle")
			}), /* @__PURE__ */ m("span", {
				className: "fdf-market__stats",
				children: [
					t.solo && /* @__PURE__ */ p("span", {
						className: "fdf-tag",
						children: g("games.fadenfroh.soloTag")
					}),
					/* @__PURE__ */ p("span", {
						className: "fdf-stat",
						children: g("games.fadenfroh.deckLeft", { n: t.deckCount })
					}),
					/* @__PURE__ */ p("span", {
						className: "fdf-stat",
						children: g("games.fadenfroh.discardLeft", { n: t.discardCount })
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "fdf-icon-btn",
						"aria-label": g("games.fadenfroh.historyButton"),
						onClick: () => ne(!0),
						children: /* @__PURE__ */ p(c, { size: 18 })
					})
				]
			})]
		}), /* @__PURE__ */ m("div", {
			className: "fdf-market__body",
			children: [
				/* @__PURE__ */ m("div", {
					className: "fdf-materials",
					children: [
						/* @__PURE__ */ p(et, {
							label: g("games.fadenfroh.materialThread"),
							count: t.market.threads,
							icon: /* @__PURE__ */ m("span", {
								className: "fdf-token__stack",
								children: [
									/* @__PURE__ */ p(Re, {
										tone: "purple",
										className: "fdf-mat-icon"
									}),
									/* @__PURE__ */ p(Re, {
										tone: "yellow",
										className: "fdf-mat-icon"
									}),
									/* @__PURE__ */ p(Re, {
										tone: "green",
										className: "fdf-mat-icon"
									})
								]
							}),
							onClick: U && !t.mustPass && t.market.threads > 0 ? () => b({
								type: "takeMaterial",
								kind: "thread"
							}) : void 0,
							disabled: !U || t.mustPass || t.market.threads <= 0,
							active: U && !t.mustPass && t.market.threads > 0
						}),
						/* @__PURE__ */ p(et, {
							label: g("games.fadenfroh.materialNeedle"),
							count: t.market.needles,
							icon: /* @__PURE__ */ p(K, { className: "fdf-mat-icon" }),
							onClick: U && !t.mustPass && t.market.needles > 0 ? () => b({
								type: "takeMaterial",
								kind: "needle"
							}) : void 0,
							disabled: !U || t.mustPass || t.market.needles <= 0,
							active: U && !t.mustPass && t.market.needles > 0
						}),
						/* @__PURE__ */ p(et, {
							label: g("games.fadenfroh.materialThimble"),
							icon: /* @__PURE__ */ p(ze, { className: "fdf-mat-icon" }),
							onClick: U && !t.mustPass && t.market.thimble ? () => b({
								type: "takeMaterial",
								kind: "thimble"
							}) : void 0,
							disabled: !U || t.mustPass || !t.market.thimble,
							active: U && !t.mustPass && t.market.thimble
						})
					]
				}),
				t.market.offers.length === 0 && /* @__PURE__ */ p("p", {
					className: "fdf-muted",
					children: g("games.fadenfroh.marketEmpty")
				}),
				t.solo ? /* @__PURE__ */ p("div", {
					className: "fdf-solo-offers",
					children: t.market.offers.flat().map((e, t) => {
						let n = z.includes(e);
						return /* @__PURE__ */ p("button", {
							type: "button",
							className: `fdf-solo-card${n ? " is-picked" : ""}`,
							"aria-pressed": n,
							"aria-label": J(g, e),
							disabled: !U,
							onClick: () => Fe(e),
							children: /* @__PURE__ */ p(X, { id: e })
						}, `${t}-${e}`);
					})
				}) : /* @__PURE__ */ p("div", {
					className: "fdf-offers",
					children: t.market.offers.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "fdf-offer",
						"aria-label": `${g("games.fadenfroh.offerTitle", { n: t + 1 })} · ${g("games.fadenfroh.offerCards", { n: e.length })} · ${g("games.fadenfroh.offerTake")}`,
						disabled: !U,
						onClick: () => b({
							type: "takeOffer",
							index: t
						}),
						children: [
							/* @__PURE__ */ m("span", {
								className: "fdf-offer__head",
								children: [g("games.fadenfroh.offerTitle", { n: t + 1 }), /* @__PURE__ */ p("span", {
									className: "fdf-offer__count",
									children: g("games.fadenfroh.offerCards", { n: e.length })
								})]
							}),
							/* @__PURE__ */ p("span", {
								className: "fdf-offer__cards",
								children: e.map((e, t) => /* @__PURE__ */ p("span", {
									className: "fdf-offer__card",
									children: /* @__PURE__ */ p(X, { id: e })
								}, `${t}-${e}`))
							}),
							/* @__PURE__ */ p("span", {
								className: "fdf-offer__action",
								children: g("games.fadenfroh.offerTake")
							})
						]
					}, t))
				})
			]
		})]
	}), Y = t.history[t.history.length - 1], He = /* @__PURE__ */ m("section", {
		className: "fdf-panel fdf-panel--notes",
		"aria-label": g("games.fadenfroh.notesTitle"),
		children: [
			/* @__PURE__ */ p("h2", {
				className: "fdf-panel__title",
				children: g("games.fadenfroh.notesTitle")
			}),
			q.length === 0 && /* @__PURE__ */ p("p", {
				className: "fdf-muted",
				children: g("games.fadenfroh.notesNone")
			}),
			/* @__PURE__ */ p("ul", {
				className: "fdf-notes",
				children: Ue.map((e) => /* @__PURE__ */ m("li", {
					className: `fdf-notes__item${q.includes(e) ? " is-active" : ""}`,
					children: [/* @__PURE__ */ p("span", {
						className: "fdf-notes__slot",
						"aria-hidden": "true",
						children: g(Z[e])
					}), /* @__PURE__ */ m("span", {
						className: "fdf-notes__body",
						children: [/* @__PURE__ */ p("strong", { children: g(We[t.scoring[e]]) }), /* @__PURE__ */ p("span", { children: g(Q[t.scoring[e]]) })]
					})]
				}, e))
			}),
			(E[t.round]?.choose ?? []).length > 0 && /* @__PURE__ */ p("p", {
				className: "fdf-muted",
				children: g("games.fadenfroh.notesChoose")
			})
		]
	}), Xe = t.phase !== "shopping" && Y && /* @__PURE__ */ m("section", {
		className: "fdf-panel fdf-panel--review",
		"aria-label": g("games.fadenfroh.historyTitle"),
		children: [/* @__PURE__ */ p("h2", {
			className: "fdf-panel__title",
			children: g("games.fadenfroh.historyRound", { n: Y.round })
		}), /* @__PURE__ */ p("ul", {
			className: "fdf-review",
			children: t.players.map((e) => {
				let t = Y.details[e.rid] ?? [], n = E[Y.round]?.fixed ?? [];
				return /* @__PURE__ */ m("li", {
					className: "fdf-review__line",
					children: [
						/* @__PURE__ */ p("span", {
							className: "fdf-review__name",
							children: R(e.rid)
						}),
						/* @__PURE__ */ p("b", {
							className: "fdf-review__score",
							children: Y.scores[e.rid] ?? 0
						}),
						/* @__PURE__ */ p("span", {
							className: "fdf-review__items",
							children: t.map((e, t) => /* @__PURE__ */ m("span", {
								className: "fdf-review__item",
								children: [
									Ge(g, n, e.key),
									" ",
									e.vp
								]
							}, `${e.key}-${t}`))
						})
					]
				}, e.rid);
			})
		})]
	}), Qe = /* @__PURE__ */ p("div", {
		className: "fdf-seats",
		role: "tablist",
		"aria-label": g("games.fadenfroh.tableauTitle"),
		children: t.players.map((e) => {
			let n = R(e.rid), r = Ce(e.rid), i = v.find((t) => t.rid === e.rid), a = l[(i?.colorIndex ?? 0) % l.length], o = t.phase === "shopping" ? t.turn === e.rid ? g("games.fadenfroh.turnTag") : e.passed ? g("games.fadenfroh.passedTag") : g("games.fadenfroh.notPassedTag") : e.passed ? e.embroiderDone ? g("games.fadenfroh.doneTag") : g("games.fadenfroh.passedTag") : g("games.fadenfroh.notPassedTag");
			return /* @__PURE__ */ m("button", {
				type: "button",
				role: "tab",
				"aria-selected": I === e.rid,
				className: `fdf-seat${I === e.rid ? " is-on" : ""}${t.turn === e.rid ? " is-turn" : ""}`,
				style: { "--fdf-seat-color": a.hex },
				"aria-label": `${g("games.fadenfroh.playerTab", { name: n })} · ${g("games.fadenfroh.totalScore", { n: e.score })} · ${o}`,
				onClick: () => ue({
					key: T,
					rid: e.rid
				}),
				children: [/* @__PURE__ */ p("span", {
					className: "fdf-seat__avatar",
					children: r && /* @__PURE__ */ p("img", {
						src: r,
						alt: "",
						draggable: !1
					})
				}), /* @__PURE__ */ m("span", {
					className: "fdf-seat__body",
					children: [/* @__PURE__ */ m("span", {
						className: "fdf-seat__name",
						children: [n, e.rid === t.startPlayer && /* @__PURE__ */ p("span", {
							className: "fdf-seat__start",
							children: g("games.fadenfroh.startTag")
						})]
					}), /* @__PURE__ */ m("span", {
						className: "fdf-seat__meta",
						children: [
							/* @__PURE__ */ p("b", { children: e.score }),
							" · ",
							o
						]
					})]
				})]
			}, e.rid);
		})
	}), nt = L && /* @__PURE__ */ m("section", {
		className: "fdf-panel fdf-panel--tableau",
		"aria-label": g("games.fadenfroh.tableauTitle"),
		ref: be,
		children: [
			/* @__PURE__ */ m("div", {
				className: "fdf-tableau__head",
				children: [/* @__PURE__ */ m("h2", {
					className: "fdf-panel__title",
					children: [
						R(L.rid),
						" · ",
						g("games.fadenfroh.tableauTitle")
					]
				}), /* @__PURE__ */ p(tt, { player: L })]
			}),
			C && N !== null && /* @__PURE__ */ p("p", {
				className: "fdf-tableau__hint",
				children: F.length > 0 ? g("games.fadenfroh.placeHint") : g("games.fadenfroh.noPlaceHint")
			}),
			/* @__PURE__ */ p("div", {
				className: "fdf-rows",
				children: [
					0,
					1,
					2
				].map((e) => {
					let t = L.tableau.filter((t) => t.row === e).sort((e, t) => e.seq - t.seq), n = L.rid === y && N !== null ? F.filter((t) => t.row === e) : [], r = L.rid === y && C ? Se.filter((t) => t.row === e) : [], i = L.rid === y ? P.filter((t) => t.row === e) : [];
					return /* @__PURE__ */ p(it, {
						row: e,
						cards: t,
						widthOptions: r,
						drops: n,
						pending: i,
						selectedId: L.rid === y ? N : null,
						hoverKey: _e,
						onPlace: De
					}, e);
				})
			})
		]
	}), rt = C && /* @__PURE__ */ m("section", {
		className: "fdf-panel fdf-panel--hand",
		"aria-label": g("games.fadenfroh.handTitle"),
		children: [/* @__PURE__ */ m("div", {
			className: "fdf-hand__head",
			children: [/* @__PURE__ */ m("h2", {
				className: "fdf-panel__title",
				children: [
					g("games.fadenfroh.handTitle"),
					" · ",
					g("games.fadenfroh.supplyCards", { n: M.length })
				]
			}), /* @__PURE__ */ p("span", {
				className: "fdf-muted",
				children: g("games.fadenfroh.handSelectHint")
			})]
		}), M.length === 0 ? /* @__PURE__ */ p("p", {
			className: "fdf-muted",
			children: g("games.fadenfroh.handEmpty")
		}) : /* @__PURE__ */ p("div", {
			className: "fdf-hand",
			children: M.map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				className: `fdf-hand__card${N === e ? " is-picked" : ""}${Me(e) ? " is-staged" : ""}`,
				"aria-pressed": N === e,
				"aria-label": Me(e) ? `${J(g, e)} · ${g("games.fadenfroh.pendingTag")}` : J(g, e),
				onClick: () => Ne(e),
				onPointerDown: ke(e),
				onPointerMove: Ae,
				onPointerUp: je,
				onPointerCancel: je,
				onDragStart: (e) => e.preventDefault(),
				children: [/* @__PURE__ */ p(X, {
					id: e,
					showSet: re(e)
				}), Me(e) && /* @__PURE__ */ p("span", {
					className: "fdf-hand__staged",
					"aria-hidden": "true",
					children: g("games.fadenfroh.pendingTag")
				})]
			}, e))
		})]
	}), at;
	at = t.phase === "shopping" ? t.solo && U ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("button", {
			type: "button",
			className: "fdf-btn fdf-btn--primary",
			disabled: z.length === 0,
			onClick: () => {
				b({
					type: "soloTake",
					cards: z
				}), ce({
					key: "",
					ids: []
				});
			},
			children: g("games.fadenfroh.soloTake")
		}),
		/* @__PURE__ */ p("button", {
			type: "button",
			className: "fdf-btn",
			onClick: () => {
				b({
					type: "soloTake",
					cards: []
				}), ce({
					key: "",
					ids: []
				});
			},
			children: g("games.fadenfroh.soloPass")
		}),
		/* @__PURE__ */ p("span", {
			className: "fdf-bar__hint",
			children: g("games.fadenfroh.soloPickCount", { n: z.length })
		})
	] }) : U ? /* @__PURE__ */ p("span", {
		className: "fdf-bar__hint",
		children: t.mustPass ? g("games.fadenfroh.bannerMustPass") : g("games.fadenfroh.marketHint")
	}) : /* @__PURE__ */ p("span", {
		className: "fdf-bar__hint",
		children: g("games.fadenfroh.bannerTurn", { name: Le })
	}) : t.phase === "embroidery" ? C ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("button", {
			type: "button",
			className: "fdf-btn fdf-btn--primary",
			onClick: Oe,
			disabled: fe,
			children: P.length > 0 ? g("games.fadenfroh.finishConfirm") : g("games.fadenfroh.finishEmbroidery")
		}),
		P.length > 0 && /* @__PURE__ */ p("button", {
			type: "button",
			className: "fdf-btn",
			onClick: () => {
				O({
					key: "",
					items: []
				}), k(null);
			},
			children: g("games.fadenfroh.cancelPending")
		}),
		N !== null && /* @__PURE__ */ p("button", {
			type: "button",
			className: "fdf-btn",
			onClick: Pe,
			children: g("games.fadenfroh.discardCard")
		}),
		/* @__PURE__ */ p("span", {
			className: "fdf-bar__hint",
			children: me ?? (P.length > 0 ? g("games.fadenfroh.pendingHint", { n: P.length }) : g(N === null ? "games.fadenfroh.finishNote" : "games.fadenfroh.placeHint"))
		})
	] }) : /* @__PURE__ */ p("span", {
		className: "fdf-bar__hint",
		children: g("games.fadenfroh.waitingOthers")
	}) : t.phase === "scoring" ? /* @__PURE__ */ p("span", {
		className: "fdf-bar__hint",
		children: (h?.myChoice ?? null) === null ? g("games.fadenfroh.choiceHint") : g("games.fadenfroh.choiceWaiting")
	}) : /* @__PURE__ */ p("span", {
		className: "fdf-bar__hint",
		children: g("games.fadenfroh.bannerDone")
	});
	let ot = t.phase === "scoring" && (h?.myChoice ?? null) === null, st = h?.exchange ?? null;
	return /* @__PURE__ */ m(u, {
		className: "fdf-root",
		actionsHeight: "fdf-actions-h",
		banner: /* @__PURE__ */ p(d, {
			tone: G,
			text: W,
			chip: g("games.fadenfroh.roundLabel", { n: t.round }),
			accent: oe.accent
		}),
		actions: /* @__PURE__ */ p("div", {
			className: "fdf-bar",
			children: at
		}),
		children: [
			/* @__PURE__ */ m("div", {
				className: `fdf-board fdf-board--${t.phase}`,
				children: [
					Qe,
					/* @__PURE__ */ m("div", {
						className: "fdf-col fdf-col--left",
						children: [
							Be,
							He,
							Xe
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "fdf-col fdf-col--center",
						children: [
							nt,
							rt,
							/* @__PURE__ */ m("div", {
								className: "fdf-piles",
								children: [/* @__PURE__ */ m("div", {
									className: "fdf-pile",
									children: [/* @__PURE__ */ m("span", {
										className: "fdf-pile__stack",
										"aria-hidden": "true",
										children: [
											/* @__PURE__ */ p("span", { className: "fdf-pile__back" }),
											/* @__PURE__ */ p("span", { className: "fdf-pile__back" }),
											/* @__PURE__ */ p("span", { className: "fdf-pile__back" })
										]
									}), /* @__PURE__ */ p("span", {
										className: "fdf-pile__label",
										children: g("games.fadenfroh.deckLeft", { n: t.deckCount })
									})]
								}), /* @__PURE__ */ m("div", {
									className: "fdf-pile",
									children: [/* @__PURE__ */ p("span", {
										className: "fdf-pile__stack fdf-pile__stack--discard",
										"aria-hidden": "true",
										children: /* @__PURE__ */ p("span", { className: "fdf-pile__back" })
									}), /* @__PURE__ */ p("span", {
										className: "fdf-pile__label",
										children: g("games.fadenfroh.discardLeft", { n: t.discardCount })
									})]
								})]
							})
						]
					}),
					Ve,
					/* @__PURE__ */ p("div", {
						className: "fdf-table-art",
						"aria-hidden": "true",
						children: /* @__PURE__ */ p("div", {
							className: "fdf-table-art__hoop",
							children: /* @__PURE__ */ p(Ie, {
								symbol: 3,
								className: "fdf-table-art__squirrel"
							})
						})
					})
				]
			}),
			he && N !== null && /* @__PURE__ */ p("div", {
				className: "fdf-dragcard",
				style: {
					left: he.x,
					top: he.y
				},
				"aria-hidden": "true",
				children: /* @__PURE__ */ p(X, { id: N })
			}),
			st && /* @__PURE__ */ p("div", {
				className: "fdf-modal fdf-modal--blocking",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g("games.fadenfroh.exchangeTitle"),
				children: /* @__PURE__ */ m("div", {
					className: "fdf-sheet",
					children: [
						/* @__PURE__ */ p("h2", { children: g("games.fadenfroh.exchangeTitle") }),
						/* @__PURE__ */ p("p", {
							className: "fdf-muted",
							children: g("games.fadenfroh.exchangeHint")
						}),
						/* @__PURE__ */ p("div", {
							className: "fdf-exchange",
							children: st.map((e, t) => /* @__PURE__ */ m("button", {
								type: "button",
								className: "fdf-exchange__card",
								"aria-label": `${g("games.fadenfroh.exchangeCard", { n: t + 1 })} ${J(g, e)}`,
								onClick: () => b({
									type: "exchangeKeep",
									card: e
								}),
								children: [/* @__PURE__ */ p(X, { id: e }), /* @__PURE__ */ p("span", { children: g("games.fadenfroh.exchangeKeep") })]
							}, e))
						})
					]
				})
			}),
			ot && h?.choicePreview && /* @__PURE__ */ p("div", {
				className: "fdf-modal fdf-modal--blocking",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g("games.fadenfroh.choiceTitle"),
				children: /* @__PURE__ */ m("div", {
					className: "fdf-sheet",
					children: [
						/* @__PURE__ */ p("h2", { children: g("games.fadenfroh.choiceTitle") }),
						/* @__PURE__ */ p("p", {
							className: "fdf-muted",
							children: g("games.fadenfroh.choiceHint")
						}),
						/* @__PURE__ */ p("div", {
							className: "fdf-choice",
							children: ["B", "C"].map((e) => {
								let n = t.scoring[e];
								return /* @__PURE__ */ m("button", {
									type: "button",
									className: "fdf-choice__card",
									onClick: () => b({
										type: "scoreChoice",
										which: e
									}),
									children: [
										/* @__PURE__ */ p("span", {
											className: "fdf-choice__slot",
											children: g(Z[e])
										}),
										/* @__PURE__ */ p("strong", { children: g(We[n]) }),
										/* @__PURE__ */ p("span", {
											className: "fdf-choice__text",
											children: g(Q[n])
										}),
										/* @__PURE__ */ p("span", {
											className: "fdf-choice__points",
											children: g("games.fadenfroh.choicePoints", { n: h.choicePreview[e] })
										})
									]
								}, e);
							})
						})
					]
				})
			}),
			x && /* @__PURE__ */ p("div", {
				className: "fdf-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g("games.fadenfroh.scoringTitle"),
				children: /* @__PURE__ */ m("div", {
					className: "fdf-sheet",
					children: [
						/* @__PURE__ */ m("h2", { children: [
							g(Z[x]),
							" · ",
							g(We[t.scoring[x]])
						] }),
						/* @__PURE__ */ p("p", {
							className: "fdf-muted",
							children: g("games.fadenfroh.cardNumber", { n: t.scoring[x] })
						}),
						/* @__PURE__ */ p("p", {
							className: "fdf-detail-text",
							children: g(Q[t.scoring[x]])
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "fdf-btn",
							onClick: () => ie(null),
							children: g("games.fadenfroh.close")
						})
					]
				})
			}),
			te && /* @__PURE__ */ p("div", {
				className: "fdf-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g("games.fadenfroh.historyTitle"),
				children: /* @__PURE__ */ m("div", {
					className: "fdf-sheet fdf-sheet--wide",
					children: [
						/* @__PURE__ */ p("h2", { children: g("games.fadenfroh.historyTitle") }),
						t.history.length === 0 ? /* @__PURE__ */ p("p", {
							className: "fdf-muted",
							children: g("games.fadenfroh.historyEmpty")
						}) : /* @__PURE__ */ p("div", {
							className: "fdf-history",
							children: t.history.map((e) => /* @__PURE__ */ m("section", {
								className: "fdf-history__round",
								children: [/* @__PURE__ */ p("h3", { children: g("games.fadenfroh.historyRound", { n: e.round }) }), t.players.map((t) => {
									let n = e.details[t.rid] ?? [], r = E[e.round]?.fixed ?? [];
									return /* @__PURE__ */ m("div", {
										className: "fdf-history__line",
										children: [
											/* @__PURE__ */ p("span", {
												className: "fdf-history__name",
												children: R(t.rid)
											}),
											/* @__PURE__ */ p("strong", {
												className: "fdf-history__total",
												children: g("games.fadenfroh.historyTotal", { n: e.scores[t.rid] ?? 0 })
											}),
											/* @__PURE__ */ p("span", {
												className: "fdf-history__items",
												children: n.map((e, t) => /* @__PURE__ */ m("span", {
													className: "fdf-history__item",
													children: [
														Ge(g, r, e.key),
														" ",
														e.vp
													]
												}, `${e.key}-${t}`))
											})
										]
									}, t.rid);
								})]
							}, e.round))
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "fdf-btn",
							onClick: () => ne(!1),
							children: g("games.fadenfroh.close")
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
function st(e) {
	return e.symbols.length + (e.feather ? 2 : 0) + (e.hoop === null ? 0 : 2);
}
function $(e) {
	let [t, n] = w(e);
	return st(t) + st(n);
}
function ct(e, t, n) {
	let r = 0, i = 0, a = 0;
	for (let t of e) r += t.symbols.length, t.feather && (i += 1), t.hoop !== null && (a += 1);
	return P([...e], t, n) + r * .2 + i * .4 + a * .8;
}
function lt(e) {
	let t = null;
	return e.market.offers.forEach((e, n) => {
		let r = e.reduce((e, t) => e + $(t), 0);
		(!t || r > t.value) && (t = {
			index: n,
			value: r
		});
	}), t;
}
function ut(e) {
	let t = e[0], n = $(t);
	for (let r of e.slice(1)) {
		let e = $(r);
		e > n && (t = r, n = e);
	}
	return t;
}
function dt(e) {
	let t = e.flat();
	if (t.length === 0) return [];
	let n = [], r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = [t[e]], a = $(t[e]);
		if (a > r && (n = i, r = a), e + 1 < t.length) {
			let i = [t[e], t[e + 1]], a = $(t[e]) + $(t[e + 1]);
			a > r && (n = i, r = a);
		}
	}
	return n;
}
function ft(e, t, n, r, i) {
	let a = ct(Te(t), r, i), o = Ee(t, n), s = Math.max(0, ...t.map((e) => e.seq)) + 1, c = null;
	for (let n of e) for (let e of o) {
		let o = ct(Te([...t, {
			id: n,
			row: e.row,
			x: e.x,
			needle: e.needle,
			seq: s
		}]), r, i) - a;
		(!c || o > c.gain) && (c = {
			card: n,
			...e,
			gain: o
		});
	}
	return c;
}
function pt(e, t) {
	return t.supply.threads < 3 && e.market.threads > 0 ? {
		type: "takeMaterial",
		kind: "thread"
	} : t.supply.needles < 1 && e.market.needles > 0 ? {
		type: "takeMaterial",
		kind: "needle"
	} : t.supply.threads < 3 && e.market.thimble ? {
		type: "takeMaterial",
		kind: "thimble"
	} : {
		type: "soloTake",
		cards: dt(e.market.offers)
	};
}
var mt = (e, t) => {
	let n = e.public, r = e.private, i = n.players.find((e) => e.rid === t.rid);
	if (!i || n.phase === "done") return null;
	if (n.phase === "scoring") {
		if (!r || r.myChoice !== null) return null;
		let e = r.choicePreview;
		return e ? { action: {
			type: "scoreChoice",
			which: e.B >= e.C ? "B" : "C"
		} } : { action: {
			type: "scoreChoice",
			which: "B"
		} };
	}
	if (n.phase === "shopping" && n.turn === t.rid && !i.passed) {
		if (n.solo) return { action: pt(n, i) };
		let e = lt(n);
		return n.mustPass ? e ? { action: {
			type: "takeOffer",
			index: e.index
		} } : null : e ? e.value >= 5 ? { action: {
			type: "takeOffer",
			index: e.index
		} } : n.market.threads > 0 && i.supply.threads < 2 ? { action: {
			type: "takeMaterial",
			kind: "thread"
		} } : n.market.needles > 0 && i.supply.needles < 1 ? { action: {
			type: "takeMaterial",
			kind: "needle"
		} } : n.market.thimble ? { action: {
			type: "takeMaterial",
			kind: "thimble"
		} } : { action: {
			type: "takeOffer",
			index: e.index
		} } : null;
	}
	if (!i.passed || i.embroiderDone) return null;
	if (r?.exchange) return { action: {
		type: "exchangeKeep",
		card: ut(r.exchange)
	} };
	if (!r || r.cards.length === 0) return { action: { type: "finish" } };
	let a = i.tableau, o = ft(r.cards, a, i.supply.needles, n.scoring, n.round);
	if (o && o.gain >= 0) return { action: {
		type: "place",
		card: o.card,
		row: o.row,
		x: o.x,
		needle: o.needle
	} };
	let s = r.cards[0];
	for (let e of r.cards) $(e) < $(s) && (s = e);
	return { action: {
		type: "discard",
		card: s
	} };
}, ht = (e, t, n) => {
	switch (e.type) {
		case "takeMaterial": return e.kind === "thread" ? n("games.fadenfroh.hintTakeThread") : e.kind === "needle" ? n("games.fadenfroh.hintTakeNeedle") : n("games.fadenfroh.hintTakeThimble");
		case "takeOffer": return n("games.fadenfroh.hintTakeOffer", { n: e.index + 1 });
		case "soloTake": return e.cards.length === 0 ? n("games.fadenfroh.hintSoloPass") : n("games.fadenfroh.hintSoloTake", { n: e.cards.length });
		case "exchangeKeep": return n("games.fadenfroh.hintExchange");
		case "place": return e.needle ? n("games.fadenfroh.hintPlaceNeedle", { row: e.row + 1 }) : n("games.fadenfroh.hintPlace", { row: e.row + 1 });
		case "discard": return n("games.fadenfroh.hintDiscard");
		case "finish": return n("games.fadenfroh.hintFinish");
		case "scoreChoice": return n("games.fadenfroh.hintChoose", { slot: e.which });
		default: return n("games.fadenfroh.hintTakeOffer", { n: 1 });
	}
};
//#endregion
//#region src/game/game-over.tsx
function gt(e) {
	let t = e.public, n = e.result, r = s(), c = o((e) => e.locale), [u, d] = i("scores"), f = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? ee(n, c) : t;
	}, h = (e) => n.ranking.indexOf(e) + 1, g = n.winner[0] ? f(n.winner[0]) : null, _ = e.onPlayAgain ?? e.onBackToLobby;
	return /* @__PURE__ */ m("div", {
		className: "fdf-over",
		children: [/* @__PURE__ */ m("header", {
			className: "fdf-over__head",
			children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("p", {
				className: "fdf-over__eyebrow",
				children: r(oe.nameKey)
			}), /* @__PURE__ */ p("h1", {
				className: "fdf-over__title",
				children: r("session.result.title")
			})] }), g && /* @__PURE__ */ p("p", {
				className: "fdf-over__winner",
				children: r("games.fadenfroh.overWinner", { name: g })
			})]
		}), /* @__PURE__ */ m("div", {
			className: "fdf-over__grid",
			children: [/* @__PURE__ */ m("section", {
				className: "fdf-panel fdf-over__standings",
				"aria-label": r("games.fadenfroh.overStandings"),
				children: [
					/* @__PURE__ */ p("h2", {
						className: "fdf-panel__title",
						children: r("games.fadenfroh.overStandings")
					}),
					/* @__PURE__ */ p("ol", {
						className: "fdf-over__list",
						children: n.ranking.map((i) => {
							let o = t.players.find((e) => e.rid === i), s = e.members.find((e) => e.rid === i), c = l[(s?.colorIndex ?? 0) % l.length], u = n.winner.includes(i);
							return /* @__PURE__ */ m("li", {
								className: `fdf-over__row${u ? " is-winner" : ""}`,
								children: [
									/* @__PURE__ */ p("span", {
										className: "fdf-over__rank",
										"aria-hidden": "true",
										children: h(i)
									}),
									/* @__PURE__ */ p("span", {
										className: "fdf-over__avatar",
										style: { backgroundColor: c.hex },
										children: s && /* @__PURE__ */ p("img", {
											src: a[s.avatar % a.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ m("span", {
										className: "fdf-over__name",
										children: [
											f(i),
											i === e.myRid && /* @__PURE__ */ p("span", {
												className: "fdf-over__you",
												children: r("lobby.you")
											}),
											u && /* @__PURE__ */ p("span", {
												className: "fdf-over__win-tag",
												children: r("games.fadenfroh.overTag")
											})
										]
									}),
									/* @__PURE__ */ p("span", {
										className: "fdf-over__score",
										children: n.scores?.[i] ?? o?.score ?? 0
									})
								]
							}, i);
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "fdf-over__actions",
						children: [
							e.onPlayAgain && /* @__PURE__ */ p("button", {
								type: "button",
								className: "fdf-btn fdf-btn--primary",
								onClick: e.onPlayAgain,
								children: r("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ p("button", {
								type: "button",
								className: "fdf-btn",
								onClick: e.onBackToLobby,
								children: r("session.result.backToLobby")
							}),
							!_ && /* @__PURE__ */ p("span", {
								className: "fdf-bar__hint",
								children: r("session.result.waitHost")
							})
						]
					})
				]
			}), /* @__PURE__ */ m("section", {
				className: "fdf-panel fdf-over__review",
				"aria-label": r("games.fadenfroh.overReview"),
				children: [
					/* @__PURE__ */ m("div", {
						className: "fdf-over__tabs",
						role: "tablist",
						"aria-label": r("games.fadenfroh.overReview"),
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							role: "tab",
							"aria-selected": u === "scores",
							className: `fdf-over__tab${u === "scores" ? " is-on" : ""}`,
							onClick: () => d("scores"),
							children: r("games.fadenfroh.historyTitle")
						}), /* @__PURE__ */ p("button", {
							type: "button",
							role: "tab",
							"aria-selected": u === "displays",
							className: `fdf-over__tab${u === "displays" ? " is-on" : ""}`,
							onClick: () => d("displays"),
							children: r("games.fadenfroh.overDisplays")
						})]
					}),
					p(u === "scores" ? _t : vt, {
						pub: t,
						result: n,
						nameOf: f
					}),
					u === "scores" && /* @__PURE__ */ p("ul", {
						className: "fdf-over__notes",
						"aria-label": r("games.fadenfroh.scoringTitle"),
						children: Ue.map((e) => /* @__PURE__ */ m("li", {
							className: "fdf-over__note",
							children: [/* @__PURE__ */ p("span", {
								className: "fdf-over__slot",
								"aria-hidden": "true",
								children: r(Z[e])
							}), /* @__PURE__ */ m("span", {
								className: "fdf-over__note-text",
								children: [
									/* @__PURE__ */ p("strong", { children: r(We[t.scoring[e]]) }),
									" · ",
									r(Q[t.scoring[e]])
								]
							})]
						}, e))
					})
				]
			})]
		})]
	});
}
function _t({ pub: e, result: t, nameOf: n }) {
	let r = s();
	return e.history.length === 0 ? /* @__PURE__ */ p("p", {
		className: "fdf-muted",
		children: r("games.fadenfroh.historyEmpty")
	}) : /* @__PURE__ */ p("div", {
		className: "fdf-over__table-scroll",
		children: /* @__PURE__ */ m("table", {
			className: "fdf-over__table",
			children: [
				/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { scope: "col" }), e.players.map((e) => /* @__PURE__ */ p("th", {
					scope: "col",
					children: n(e.rid)
				}, e.rid))] }) }),
				/* @__PURE__ */ p("tbody", { children: e.history.map((t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
					scope: "row",
					children: r("games.fadenfroh.historyRound", { n: t.round })
				}), e.players.map((e) => {
					let n = t.details[e.rid] ?? [], i = E[t.round]?.fixed ?? [];
					return /* @__PURE__ */ m("td", { children: [/* @__PURE__ */ p("strong", { children: t.scores[e.rid] ?? 0 }), /* @__PURE__ */ p("span", {
						className: "fdf-over__items",
						children: n.map((e, t) => /* @__PURE__ */ m("span", {
							className: "fdf-history__item",
							children: [
								Ge(r, i, e.key),
								" ",
								e.vp
							]
						}, `${e.key}-${t}`))
					})] }, e.rid);
				})] }, t.round)) }),
				/* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
					scope: "row",
					children: r("games.fadenfroh.overTotal")
				}), e.players.map((e) => /* @__PURE__ */ p("td", { children: /* @__PURE__ */ p("strong", { children: t.scores?.[e.rid] ?? e.score }) }, e.rid))] }) })
			]
		})
	});
}
function vt({ pub: e, result: t, nameOf: n }) {
	let r = s();
	return /* @__PURE__ */ p("div", {
		className: "fdf-over__displays",
		children: t.ranking.map((i) => {
			let a = e.players.find((e) => e.rid === i);
			return a ? /* @__PURE__ */ m("section", {
				className: "fdf-over__player",
				"aria-label": n(i),
				children: [/* @__PURE__ */ m("header", {
					className: "fdf-over__player-head",
					children: [/* @__PURE__ */ p("strong", {
						className: "fdf-over__player-name",
						children: n(i)
					}), /* @__PURE__ */ p("span", {
						className: "fdf-stat",
						children: r("games.fadenfroh.totalScore", { n: t.scores?.[i] ?? a.score })
					})]
				}), /* @__PURE__ */ p(yt, { cards: a.tableau })]
			}, i) : null;
		})
	});
}
function yt({ cards: e }) {
	let t = s();
	return /* @__PURE__ */ p("div", {
		className: "fdf-rows",
		children: [
			0,
			1,
			2
		].map((n) => {
			let r = e.filter((e) => e.row === n).sort((e, t) => e.seq - t.seq), i = Math.min(0, ...r.map((e) => e.x)), a = Math.max(2, ...r.map((e) => e.x + 2)), o = i, s = Math.max(6, Math.max(4, a) - o), c = `max(0px, calc(50% - var(--fdf-cell) * ${(a - i) / 2 + (i - o)}))`;
			return /* @__PURE__ */ m("div", {
				className: "fdf-row",
				children: [/* @__PURE__ */ p("div", {
					className: "fdf-row__label",
					"aria-hidden": "true",
					children: n + 1
				}), /* @__PURE__ */ p("div", {
					className: "fdf-row__scroll",
					children: /* @__PURE__ */ p("div", {
						className: "fdf-row__track",
						style: { width: `max(calc(var(--fdf-cell) * ${s}), 100%)` },
						children: r.map((e) => {
							let n = r.some((t) => t !== e && t.x + 2 === e.x) ? "left" : "right";
							return /* @__PURE__ */ m("div", {
								className: "fdf-slot",
								style: {
									left: `calc(var(--fdf-cell) * ${e.x - o} + ${c})`,
									zIndex: e.seq + 1
								},
								children: [/* @__PURE__ */ p(X, {
									id: e.id,
									showSet: re(e.id),
									ariaLabel: J(t, e.id)
								}), e.needle && /* @__PURE__ */ p("span", {
									className: `fdf-needle fdf-needle--${n}`,
									"aria-hidden": "true",
									children: /* @__PURE__ */ p(K, {})
								})]
							}, e.seq);
						})
					})
				})]
			}, n);
		})
	});
}
//#endregion
//#region src/index.tsx
var bt = {
	definition: H,
	View: ot,
	bot: mt,
	describe: ht,
	OverView: gt,
	locales: {
		zh: {
			name: "Fadenfroh",
			desc: "争抢布料与针线，把花纹缝进三行绣布，五轮后得分最高者获胜",
			rules: "目标:\n· 五轮结束时总分最高的玩家获胜；总分相同时，起始卡组号更大的玩家获胜。\n准备:\n· 每名玩家取得同一组的 3 张起始卡，分别放在面前三行的最左端。\n· 每名玩家取得 1 个线轴和 1 根针。\n· 从四个类别各抽 1 张计分卡，洗匀后分别放在轮次板的四角，依次称为 A、B、C、D。\n· 持有顶针的玩家成为第 1 轮的起始玩家。\n每轮流程:\n· 每轮依次经过市场、采购、刺绣和计分四个阶段，共进行五轮。\n市场:\n· 顶针持有者把顶针放入市场，并成为本轮的起始玩家。\n· 按照玩家人数摆出材料与报价；2 人使用 4 个线轴、1 根针和 2 组报价，3 人使用 7 个线轴、2 根针和 3 组报价，4 人使用 10 个线轴、2 根针和 4 组报价。\n· 布料堆用完时，把弃牌堆洗匀后作为新的布料堆。\n采购:\n· 从起始玩家开始按顺时针轮流行动，直到所有玩家都停手。\n· 轮到行动时，可以从市场取走 1 个线轴、1 根针或顶针，也可以停手并取走 1 组报价的全部卡牌。\n· 市场里没有某种材料时，不能选择该材料。\n· 停手取走报价后，本轮的采购对这名玩家结束。\n· 其他玩家都已停手时，你取走市场剩余的全部材料，然后必须停手并取走 1 组报价。\n刺绣:\n· 全部玩家停手后，进入刺绣阶段。\n· 拥有至少 3 个线轴时，必须立即向总供应归还 3 个线轴，从布料堆抽 3 张牌，留下 1 张放入自己的供应区，其余 2 张明置弃牌堆。\n· 兑换后仍有至少 3 个线轴时，重复兑换，直到少于 3 个线轴。\n· 面前有三行，每行以 1 张起始卡开始。\n· 放置的新卡至少覆盖另一张已放牌的 1 个半张；一张卡可以同时覆盖相邻的 2 个半张。\n· 把牌紧贴另一张卡平放而不覆盖时，必须在这两张卡之间放置 1 根针。\n· 卡牌不能旋转，不能塞到其他卡牌之下，已经放好的卡牌也不能再移动。\n· 针不参与同色或同符号的分组，也不影响相邻关系的判定。\n· 不准备摆放的卡牌必须明置弃牌堆，不能保留到下一轮。\n· 全部玩家完成刺绣后，进入计分阶段。\n· 每轮结束时可以保留全部针和至多 2 个线轴，顶针交还给市场。\n计分:\n· 第 1 轮不计分。\n· 第 2 轮计算 A 和 B，第 3 轮计算 B 和 C，第 4 轮计算 C 和 D，第 5 轮计算 A 和 D。\n· 每次计分时，绣布上每个羽毛圈另计 2 分。\n· 第 5 轮计分时，每名玩家从 B 和 C 中选择一张计分卡计分。\n· 第 5 轮计分时，供应区里每个材料另计 2 分。\n· 第 5 轮计分时，绣布上的每个绣绷按其对应符号的数量计分，每个对应符号计 3 分。\n· 只有绣布上可见的半张和符号参与计分，绣绷上的符号不计分。\n· 计分卡的具体条件以当轮展示的卡面说明为准。\n相邻与分组:\n· 两个半张或两个符号共享一条边时视为相邻，只包含上下左右四个方向。\n· 一组由所有相邻且颜色相同或符号相同的半张组成。\n单人规则:\n· 每次取走材料后，翻出布料堆顶牌并明置弃牌堆。\n· 翻出的牌带有羽毛圈或绣绷时，按针、顶针、线轴的顺序从市场归还 1 个材料到总供应。\n· 翻出的牌两个半张颜色相同时，把市场最左边的牌弃置；颜色不同时，把市场最右边的牌弃置。\n· 本轮不是起始玩家时，首次行动前先翻 1 张牌。\n· 停手时最多取走 2 张相邻的市场牌，其余市场牌弃置，剩余材料归还总供应。\n结束:\n· 五轮的计分阶段全部结束后，总分最高的玩家获胜。",
			roundLabel: "第 {{n}} 轮",
			soloTag: "单人局",
			deckLeft: "布料堆 {{n}}",
			discardLeft: "弃牌 {{n}}",
			bannerYourTurn: "轮到你行动",
			bannerTurn: "等 {{name}} 行动…",
			bannerShopping: "取材料或取走一组报价",
			bannerMustPass: "收下剩余材料后，请取走一组报价",
			bannerEmbroidery: "摆放布料，或结束摆放",
			bannerEmbroideryWait: "等其他人完成摆放…",
			bannerScoring: "选择本轮的计分卡 B 或 C",
			bannerScoringWait: "等其他人选择计分卡…",
			bannerDone: "对局结束",
			overWinner: "{{name}} 获胜",
			overTag: "获胜",
			overStandings: "最终排名",
			overDisplays: "绣布回看",
			overReview: "终局回看",
			overTotal: "总分",
			marketTitle: "市场",
			offerTitle: "报价 {{n}}",
			offerCards: "{{n}} 张",
			offerTake: "取走这组",
			offerCancel: "取消选择",
			offerTaken: "已取走",
			marketHint: "每次取 1 项；取走报价即停手",
			materialThread: "线轴",
			materialNeedle: "针",
			materialThimble: "顶针",
			takeThread: "取 1 个线轴",
			takeNeedle: "取 1 根针",
			takeThimble: "取走顶针",
			marketEmpty: "市场已没有材料",
			marketAria: "市场：{{threads}} 个线轴，{{needles}} 根针{{thimble}}",
			thimblePresent: "，以及顶针",
			thimbleAbsent: "",
			soloPickHint: "选至多 2 张相邻的牌取走，其余弃置",
			soloPickCount: "已选 {{n}} 张",
			soloTake: "取走所选牌",
			soloPass: "直接停手",
			soloClear: "清空选择",
			mySupply: "我的供应区",
			supplyThread: "线轴 {{n}}",
			supplyNeedle: "针 {{n}}",
			supplyThimble: "顶针",
			supplyNoThimble: "无顶针",
			supplyCards: "待摆布料 {{n}} 张",
			handTitle: "手中布料",
			handEmpty: "手中没有布料",
			handSelectHint: "拖动或点选布料，安排好后点「结束摆放」一起确认",
			dragHint: "把布料拖到绣布上安排",
			placeHint: "拖到缝线落点安排；结束后一起确认",
			noPlaceHint: "这张牌没有可放置的位置，请弃置",
			pendingTag: "待确认",
			pendingHint: "已安排 {{n}} 张，点结束摆放时一起确认",
			pendingInvalidated: "位置变化后有 {{n}} 张安排失效，已退回手中，请重新安排",
			cancelPending: "取消全部安排",
			discardCard: "弃置所选牌",
			finishEmbroidery: "结束摆放",
			finishConfirm: "确认摆放并结束",
			finishNote: "未摆放的牌会明置弃牌堆",
			waitingOthers: "已结束摆放，等其他人…",
			exchangeTitle: "兑换线轴",
			exchangeHint: "留下 1 张布料，其余 2 张弃置；兑换后仍有 3 个线轴时继续兑换",
			exchangeKeep: "留下这张",
			exchangeCard: "兑换牌 {{n}}",
			tableauTitle: "绣布",
			playerTab: "{{name}}",
			totalScore: "总分 {{n}}",
			roundScore: "本轮 {{n}}",
			passedTag: "已停手",
			doneTag: "已摆完",
			notPassedTag: "采购中",
			turnTag: "行动中",
			startSet: "组 {{n}}",
			startTag: "先手",
			placeNeedleTag: "用针",
			placeHere: "安排在这里",
			needlePlaceHere: "用 1 根针安排在这里",
			rowLabel: "第 {{n}} 行",
			scoringTitle: "本轮计分卡",
			notesTitle: "计分卡条件",
			notesNone: "第 1 轮不计分。",
			notesChoose: "第 5 轮另外从 B 和 C 中选择一张计分。",
			scorePickTag: "二选一",
			scoringCardAria: "计分卡 {{slot}}：{{name}}。{{text}}",
			slotA: "A",
			slotB: "B",
			slotC: "C",
			slotD: "D",
			cardNumber: "{{n}} 号",
			featherLabel: "羽毛圈",
			hoopLabel: "绣绷",
			hoopScoreText: "每个{{animal}}计 {{n}} 分",
			hoopValueShort: "{{n}} 分",
			choiceTitle: "选择计分卡",
			choiceHint: "从 B 和 C 中选择一张计分卡计分",
			choiceB: "选择 B",
			choiceC: "选择 C",
			choicePoints: "{{n}} 分",
			choiceWaiting: "已选择计分卡，等其他人…",
			choicePicked: "已选择 {{slot}}",
			historyButton: "得分记录",
			historyTitle: "得分记录",
			historyEmpty: "还没有计分记录",
			historyRound: "第 {{n}} 轮",
			historyTotal: "合计 {{n}} 分",
			detailFixed: "计分卡 {{slot}}",
			detailFeather: "羽毛圈",
			detailHoop: "绣绷",
			detailMaterial: "留存材料",
			detailChoice: "自选计分卡 {{slot}}",
			close: "关闭",
			colorWhite: "白色",
			colorYellow: "黄色",
			colorPurple: "紫色",
			symBlueberry: "蓝莓",
			symStrawberry: "草莓",
			symBunny: "兔",
			symSquirrel: "松鼠",
			symCat: "猫",
			symDandelion: "蒲公英",
			symCrocus: "番红花",
			symThistle: "蓟",
			symDaisy: "雏菊",
			symFeather: "羽毛圈",
			symHoop: "绣绷",
			halfJoin: "；",
			halfAria: "{{color}}底，{{content}}",
			halfEmpty: "无符号",
			halfFeather: "羽毛圈",
			halfHoop: "{{animal}}绣绷，每个该符号计 {{n}} 分",
			card01Name: "莓果加减",
			card01Text: "每个蓝莓计 2 分，每个草莓扣 1 分，最低 0 分。",
			card02Name: "莓果成对",
			card02Text: "每对草莓与蓝莓计 4 分。",
			card03Name: "奇偶莓果",
			card03Text: "蓝莓数量为奇数时，每个蓝莓计 2 分；草莓数量为偶数时，每个草莓计 2 分。",
			card04Name: "莓果成组",
			card04Text: "每组至少 3 个草莓计 6 分；每组至少 4 个蓝莓计 9 分。",
			card05Name: "独处动物",
			card05Text: "每个不与任何动物相邻的动物计 3 分。",
			card06Name: "动物齐全",
			card06Text: "每个动物计 2 分；三种动物数量各不相同时，每个动物再计 1 分。",
			card07Name: "偏爱一种",
			card07Text: "数量最多的一种动物每个计 4 分，其余两种动物每个扣 1 分。",
			card08Name: "动物三连",
			card08Text: "每个动物计 1 分；每凑齐兔、松鼠、猫各 1 个，再计 6 分。",
			card09Name: "行内花色",
			card09Text: "每行单独计分：2、3、4 种不同花朵分别计 4、9、15 分。",
			card10Name: "列内同花",
			card10Text: "每列单独计分：1、2、3 个同种花朵分别计 2、7、12 分，每列只计一种花。",
			card11Name: "花丛成组",
			card11Text: "每组 2、3、4 个以上花朵分别计 5、11、18 分。",
			card12Name: "边缘花朵",
			card12Text: "最外侧半张上共有 1、2、3、4、5、6 朵花时，分别计 0、4、8、13、18、24 分。",
			card13Name: "单色大组",
			card13Text: "自选一种颜色，其最大连通组每个半张计 2 分。",
			card14Name: "四连同色",
			card14Text: "每种颜色中，每个至少 4 个半张的连通组计 5 分。",
			card15Name: "孤立半张",
			card15Text: "每个不与同色半张相邻的半张计 1 分；这类半张达到 12 个或 16 个时，分别再计 3 分或 7 分。",
			card16Name: "紫白对比",
			card16Text: "紫色最大连通组每个半张计 2 分，白色最大连通组每个半张扣 2 分，最低 0 分。",
			errNotSeated: "你还没有入座",
			errNotScoring: "现在不是计分阶段",
			errAlreadyChosen: "你已经选择过计分卡",
			errNotYourTurn: "现在轮不到你行动",
			errShoppingOnly: "只有采购阶段可以取材料或报价",
			errMustPass: "你必须先取走一组报价",
			errNoMaterial: "市场里已经没有这种材料",
			errSoloTake: "单人局请按单人规则取牌",
			errBadOffer: "这组报价不可用",
			errNeedPass: "请先停手，再进行刺绣",
			errAlreadyDone: "你已完成本轮的刺绣",
			errBadExchange: "这张牌不在兑换的三张牌中",
			errExchangePending: "请先完成线轴兑换",
			errNoCard: "这张牌不在你的手中",
			errNoNeedle: "需要 1 根针才能这样放置",
			errBadPlacement: "这个位置不能放置这张牌",
			hintTakeThread: "取 1 个线轴",
			hintTakeNeedle: "取 1 根针",
			hintTakeThimble: "取走顶针",
			hintTakeOffer: "取走第 {{n}} 组报价",
			hintSoloTake: "取走市场里的 {{n}} 张牌",
			hintSoloPass: "不取牌，直接停手",
			hintExchange: "兑换后留下这张牌",
			hintPlace: "把牌放在第 {{row}} 行",
			hintPlaceNeedle: "用 1 根针把牌放在第 {{row}} 行",
			hintDiscard: "弃置这张牌",
			hintFinish: "结束摆放",
			hintChoose: "选择计分卡 {{slot}}"
		},
		en: {
			name: "Fadenfroh",
			desc: "Race for fabric and materials, stitch patterns into three rows, and score the most after five rounds",
			rules: "Goal:\n· The player with the highest total after five rounds wins; on a tie, the player with the higher starting-card set number wins.\nSetup:\n· Each player takes the 3 starting cards of one set and places them at the left end of the three rows in front of them.\n· Each player takes 1 thread and 1 needle.\n· Draw 1 scoring card from each of the four categories, shuffle them, and place one in each corner of the round overview board as A, B, C, and D.\n· The player holding the thimble becomes the starting player of round 1.\nRound flow:\n· Each round passes through the market, shopping, embroidery, and scoring phases; the game lasts exactly five rounds.\nMarket:\n· The thimble holder places the thimble in the market and becomes the starting player of the round.\n· Lay out materials and offers according to the player count; 2 players use 4 threads, 1 needle, and 2 offers, 3 players use 7 threads, 2 needles, and 3 offers, and 4 players use 10 threads, 2 needles, and 4 offers.\n· If the fabric pile runs out, shuffle the discard pile into a new fabric pile.\nShopping:\n· Play proceeds clockwise from the starting player until every player has passed.\n· On your turn, take 1 thread, 1 needle, or the thimble from the market, or pass and take all cards of 1 offer.\n· If a material is not available in the market, you cannot choose it.\n· After you pass and take an offer, your shopping phase for the round is over.\n· If everyone else has already passed, you take all remaining material from the market and must then pass and take an offer.\nEmbroidery:\n· After every player has passed, the embroidery phase begins.\n· If you have at least 3 threads, you must immediately return 3 threads to the general supply, draw 3 cards, keep 1 in your supply, and place the other 2 face up on the discard pile.\n· If you still have at least 3 threads after the exchange, repeat the exchange until you have fewer than 3 threads.\n· Your display has three rows, each starting with 1 starting card.\n· A new card must cover at least 1 half of another placed card; one card may cover 2 adjacent halves at once.\n· To place a card next to another card without covering it, place 1 needle between those two cards.\n· Cards cannot be rotated, cannot be slid beneath other cards, and placed cards cannot be moved.\n· Needles do not affect color or symbol groups and do not change adjacency.\n· Any card you do not place must go face up on the discard pile and cannot be kept for later rounds.\n· After every player finishes embroidery, the scoring phase begins.\n· At the end of a round you may keep all needles and up to 2 threads, and the thimble returns to the market.\nScoring:\n· There is no scoring in round 1.\n· Round 2 scores A and B, round 3 scores B and C, round 4 scores C and D, and round 5 scores A and D.\n· Every scoring phase also gives 2 VP for each feather circle in your display.\n· In round 5, each player chooses scoring card B or C to score.\n· In round 5, each material in your supply scores 2 VP.\n· In round 5, each embroidery hoop scores 3 VP for each matching symbol in your display.\n· Only halves and symbols visible in your display count; symbols on embroidery hoops do not count.\n· The exact condition of each scoring card is shown on the card during the round.\nAdjacency and groups:\n· Two halves or symbols are adjacent when they share an edge, so only up, down, left, and right count.\n· A group consists of all adjacent halves with the same color or symbols with the same type.\nSolo rules:\n· After each time you take material, reveal the top card of the fabric pile and place it face up on the discard pile.\n· If the revealed card shows a feather circle or an embroidery hoop, return 1 material from the market to the general supply in the order needle, thimble, thread.\n· If the revealed card has the same color on both halves, discard the leftmost market card; if the colors differ, discard the rightmost market card.\n· If you are not the starting player of the round, reveal 1 card before your first turn.\n· When you pass, take up to 2 adjacent market cards, discard all remaining market cards, and return all remaining material to the general supply.\nEnd:\n· After the scoring phase of round 5, the player with the highest total wins.",
			roundLabel: "Round {{n}}",
			soloTag: "Solo",
			deckLeft: "Fabric {{n}}",
			discardLeft: "Discard {{n}}",
			bannerYourTurn: "Your turn",
			bannerTurn: "Waiting for {{name}}…",
			bannerShopping: "Take material or take an offer",
			bannerMustPass: "You took the remaining material — now take an offer",
			bannerEmbroidery: "Place fabric or finish placing",
			bannerEmbroideryWait: "Waiting for the others to finish placing…",
			bannerScoring: "Choose scoring card B or C for this round",
			bannerScoringWait: "Waiting for the others to choose…",
			bannerDone: "Game over",
			overWinner: "{{name}} wins",
			overTag: "Winner",
			overStandings: "Final standings",
			overDisplays: "Final displays",
			overReview: "Endgame review",
			overTotal: "Total",
			marketTitle: "Market",
			offerTitle: "Offer {{n}}",
			offerCards: "{{n}} cards",
			offerTake: "Take this offer",
			offerCancel: "Clear selection",
			offerTaken: "Taken",
			marketHint: "Take 1 item per turn; taking an offer ends your shopping",
			materialThread: "Thread",
			materialNeedle: "Needle",
			materialThimble: "Thimble",
			takeThread: "Take 1 thread",
			takeNeedle: "Take 1 needle",
			takeThimble: "Take the thimble",
			marketEmpty: "The market has no material left",
			marketAria: "Market: {{threads}} threads, {{needles}} needles{{thimble}}",
			thimblePresent: ", and the thimble",
			thimbleAbsent: "",
			soloPickHint: "Take up to 2 adjacent cards; the rest are discarded",
			soloPickCount: "{{n}} selected",
			soloTake: "Take selected cards",
			soloPass: "Pass without taking cards",
			soloClear: "Clear selection",
			mySupply: "My supply",
			supplyThread: "Threads {{n}}",
			supplyNeedle: "Needles {{n}}",
			supplyThimble: "Thimble",
			supplyNoThimble: "No thimble",
			supplyCards: "Fabric to place {{n}}",
			handTitle: "Fabric in hand",
			handEmpty: "No fabric in hand",
			handSelectHint: "Drag or tap cards to set them, then finish to place them all",
			dragHint: "Drag a card onto your display to set it",
			placeHint: "Drag onto a stitched spot; all are placed when you finish",
			noPlaceHint: "This card has no legal spot; discard it",
			pendingTag: "Pending",
			pendingHint: "{{n}} card(s) set; they are placed when you finish",
			pendingInvalidated: "{{n}} pending card(s) no longer fit and returned to your hand",
			cancelPending: "Clear all",
			discardCard: "Discard selected card",
			finishEmbroidery: "Finish placing",
			finishConfirm: "Place all & finish",
			finishNote: "Unplaced cards go face up on the discard pile",
			waitingOthers: "Finished placing; waiting for the others…",
			exchangeTitle: "Exchange threads",
			exchangeHint: "Keep 1 card and discard the other 2; repeat while you still have 3 threads",
			exchangeKeep: "Keep this one",
			exchangeCard: "Exchange card {{n}}",
			tableauTitle: "Display",
			playerTab: "{{name}}",
			totalScore: "Total {{n}}",
			roundScore: "Round {{n}}",
			passedTag: "Passed",
			doneTag: "Done",
			notPassedTag: "Shopping",
			turnTag: "Acting",
			startSet: "Set {{n}}",
			startTag: "First",
			placeNeedleTag: "Needle",
			placeHere: "Set here",
			needlePlaceHere: "Set here with 1 needle",
			rowLabel: "Row {{n}}",
			scoringTitle: "Scoring cards this round",
			notesTitle: "Scoring cards",
			notesNone: "Round 1 has no scoring.",
			notesChoose: "In round 5, also choose card B or C to score.",
			scorePickTag: "Choose one",
			scoringCardAria: "Scoring card {{slot}}: {{name}}. {{text}}",
			slotA: "A",
			slotB: "B",
			slotC: "C",
			slotD: "D",
			cardNumber: "No. {{n}}",
			featherLabel: "Feather circle",
			hoopLabel: "Embroidery hoop",
			hoopScoreText: "{{n}} VP per {{animal}}",
			hoopValueShort: "{{n}} VP",
			choiceTitle: "Choose a scoring card",
			choiceHint: "Score either card B or card C this round",
			choiceB: "Choose B",
			choiceC: "Choose C",
			choicePoints: "{{n}} VP",
			choiceWaiting: "Chosen; waiting for the others…",
			choicePicked: "Chose {{slot}}",
			historyButton: "Score history",
			historyTitle: "Score history",
			historyEmpty: "No scores recorded yet",
			historyRound: "Round {{n}}",
			historyTotal: "Total {{n}} VP",
			detailFixed: "Card {{slot}}",
			detailFeather: "Feather circles",
			detailHoop: "Embroidery hoops",
			detailMaterial: "Materials kept",
			detailChoice: "Chosen card {{slot}}",
			close: "Close",
			colorWhite: "White",
			colorYellow: "Yellow",
			colorPurple: "Purple",
			symBlueberry: "Blueberry",
			symStrawberry: "Strawberry",
			symBunny: "Bunny",
			symSquirrel: "Squirrel",
			symCat: "Cat",
			symDandelion: "Dandelion",
			symCrocus: "Crocus",
			symThistle: "Thistle",
			symDaisy: "Daisy",
			symFeather: "Feather circle",
			symHoop: "Embroidery hoop",
			halfJoin: "; ",
			halfAria: "{{color}} background, {{content}}",
			halfEmpty: "no symbols",
			halfFeather: "feather circle",
			halfHoop: "{{animal}} embroidery hoop, {{n}} VP per matching symbol",
			card01Name: "Berry Balance",
			card01Text: "Score 2 VP per blueberry and lose 1 VP per strawberry, with a minimum of 0 VP.",
			card02Name: "Berry Pairs",
			card02Text: "Score 4 VP for each pair of 1 strawberry and 1 blueberry.",
			card03Name: "Berry Parity",
			card03Text: "Score 2 VP per blueberry when you have an odd number of blueberries; score 2 VP per strawberry when you have an even number of strawberries.",
			card04Name: "Berry Groups",
			card04Text: "Score 6 VP for each group of at least 3 strawberries; score 9 VP for each group of at least 4 blueberries.",
			card05Name: "Lone Animals",
			card05Text: "Score 3 VP for each animal that is not adjacent to any animal.",
			card06Name: "Animal Variety",
			card06Text: "Score 2 VP per animal; if the three animal types have three different counts, score 1 additional VP per animal.",
			card07Name: "Favorite Animal",
			card07Text: "Score 4 VP for each animal of the most common type and lose 1 VP for each animal of the other two types.",
			card08Name: "Animal Trios",
			card08Text: "Score 1 VP per animal; each complete trio of 1 bunny, 1 squirrel, and 1 cat scores 6 more VP.",
			card09Name: "Flowers per Row",
			card09Text: "Each row scores separately: 2, 3, or 4 different flowers score 4, 9, or 15 VP.",
			card10Name: "Flowers per Column",
			card10Text: "Each column scores separately: 1, 2, or 3 identical flowers score 2, 7, or 12 VP, and each column scores only one flower type.",
			card11Name: "Flower Clusters",
			card11Text: "Each group of 2, 3, or 4 or more flowers scores 5, 11, or 18 VP.",
			card12Name: "Edge Flowers",
			card12Text: "With 1, 2, 3, 4, 5, or 6 flowers on the outermost halves, score 0, 4, 8, 13, 18, or 24 VP.",
			card13Name: "Largest Color Group",
			card13Text: "Choose 1 color and score 2 VP for each half in its largest connected group.",
			card14Name: "Color Groups of Four",
			card14Text: "For each color, every connected group of at least 4 halves scores 5 VP.",
			card15Name: "Isolated Halves",
			card15Text: "Score 1 VP for each half that is not adjacent to a half of the same color; if at least 12 or 16 halves qualify, score 3 or 7 additional VP.",
			card16Name: "Purple versus White",
			card16Text: "Score 2 VP per half in your largest purple group and lose 2 VP per half in your largest white group, with a minimum of 0 VP.",
			errNotSeated: "You are not seated in this game",
			errNotScoring: "The game is not in the scoring phase",
			errAlreadyChosen: "You have already chosen a scoring card",
			errNotYourTurn: "It is not your turn",
			errShoppingOnly: "Material and offers can only be taken during shopping",
			errMustPass: "You must take an offer first",
			errNoMaterial: "The market has no more of that material",
			errSoloTake: "Use the solo card-taking rule in this game",
			errBadOffer: "That offer is not available",
			errNeedPass: "Pass first, then embroider",
			errAlreadyDone: "You have already finished embroidery for this round",
			errBadExchange: "That card is not one of the three exchange cards",
			errExchangePending: "Finish the thread exchange first",
			errNoCard: "That card is not in your hand",
			errNoNeedle: "A needle is required for this placement",
			errBadPlacement: "This card cannot be placed in that spot",
			hintTakeThread: "Take 1 thread",
			hintTakeNeedle: "Take 1 needle",
			hintTakeThimble: "Take the thimble",
			hintTakeOffer: "Take offer {{n}}",
			hintSoloTake: "Take {{n}} cards from the market",
			hintSoloPass: "Pass without taking cards",
			hintExchange: "Keep this card from the exchange",
			hintPlace: "Place the card in row {{row}}",
			hintPlaceNeedle: "Place the card in row {{row}} with 1 needle",
			hintDiscard: "Discard this card",
			hintFinish: "Finish placing",
			hintChoose: "Choose scoring card {{slot}}"
		}
	}
};
//#endregion
export { bt as default };
