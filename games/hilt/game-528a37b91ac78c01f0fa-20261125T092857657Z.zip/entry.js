import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { IconBot as f } from "@bgparty/sdk/icons";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
//#region src/game/cards.ts
var m = [
	15,
	23,
	31,
	39,
	47,
	55,
	63
], h = [
	1,
	2,
	3,
	4,
	5,
	6,
	10
];
function g(e) {
	return e >= 0 && e < 63;
}
function _(e) {
	if (!g(e)) return 0;
	for (let t = 0; t < m.length; t += 1) if (e < m[t]) return h[t];
	return 0;
}
function v(e) {
	return e < 63 ? "force" : e < 66 ? "legend" : e < 81 ? "bait" : e < 87 ? "fury" : e < 90 ? "winter" : e < 93 ? "crows" : "doves";
}
var y = {
	force: 0,
	legend: 1,
	bait: 2,
	fury: 3,
	winter: 4,
	crows: 5,
	doves: 6
};
function b(e, t) {
	let n = y[v(e)], r = y[v(t)];
	return n === r ? n === 0 && _(e) - _(t) || e - t : n - r;
}
//#endregion
//#region src/game/meta.ts
var x = {
	id: "hilt",
	uuid: "a28d9eec-332b-4ebd-9ed5-6dc3ef77c3c5",
	tier: "alpha",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	nameKey: "games.hilt.name",
	descKey: "games.hilt.desc",
	rulesKey: "games.hilt.rules",
	icon: "⚔️",
	iconImg: "games/hilt.webp",
	minPlayers: 3,
	maxPlayers: 6,
	accent: "#d81b60",
	releasedAt: "2026-11-25T16:28:30+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, S = t.int().min(0).max(95), C = t.enum([
	"magenta",
	"orange",
	"ivory"
]), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseChip"),
		color: C
	}),
	t.object({
		type: t.literal("play"),
		card: S
	}),
	t.object({
		type: t.literal("pass"),
		discard: t.boolean().optional()
	}),
	t.object({
		type: t.literal("baitPick"),
		card: S
	}),
	t.object({ type: t.literal("continue") })
]), T = t.string(), E = t.int().nonnegative(), D = t.object({
	magenta: E,
	orange: E,
	ivory: E
}), O = t.object({
	phase: t.enum([
		"chipChoice",
		"battle",
		"baitPick",
		"battleEnd",
		"done"
	]),
	round: t.int().min(1),
	chipColor: C.nullable(),
	supply: D,
	favorRid: T,
	turn: T.nullable(),
	players: t.array(t.object({
		rid: T,
		handCount: t.int().nonnegative(),
		chips: D,
		passed: t.boolean()
	})),
	rows: t.record(T, t.array(S)),
	fury: t.record(T, t.boolean()),
	winterCard: S.nullable(),
	bait: t.object({ rid: T }).nullable(),
	revealed: t.object({
		rid: T,
		cards: t.array(S)
	}).nullable(),
	battleResult: t.object({
		winner: T.nullable(),
		reason: t.enum([
			"allPass",
			"crows",
			"doves"
		])
	}).nullable(),
	roundEnd: t.boolean(),
	winner: T.nullable()
}), ee = t.object({ hand: t.array(S) }), k = [
	"magenta",
	"orange",
	"ivory"
], te = () => ({
	magenta: 0,
	orange: 0,
	ivory: 0
}), A = (e) => e.magenta + e.orange + e.ivory;
function j(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r, i + 1);
		r += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return {
		deck: t,
		cursor: r
	};
}
function M(e, t, n) {
	let r = j(Array.from({ length: 96 }, (e, t) => t), n, 0), i = 0, a = {}, o = {}, s = {}, c = {}, l = {};
	for (let e of t) a[e] = r.deck.slice(i, i + 10).sort(b), i += 10, o[e] = te(), s[e] = [], c[e] = !1, l[e] = !1;
	return { state: {
		seed: n,
		rngCursor: r.cursor,
		players: t,
		round: 1,
		hands: a,
		deck: r.deck.slice(i),
		discard: [],
		chips: o,
		supply: {
			magenta: 10,
			orange: 10,
			ivory: 10
		},
		favorRid: t[0],
		phase: "chipChoice",
		chipColor: null,
		rows: s,
		passed: c,
		fury: l,
		winterCard: null,
		turn: null,
		bait: null,
		revealed: null,
		battleResult: null,
		roundEnd: !1,
		winner: null
	} };
}
var N = (e, t) => e.players.indexOf(t);
function P(e, t) {
	return e.players[(N(e, t) + 1) % e.players.length];
}
function F(e, t) {
	let n = P(e, t);
	for (let t = 0; t < e.players.length; t += 1) {
		if (!e.passed[n]) return n;
		n = P(e, n);
	}
	return null;
}
function I(e, t, n) {
	if (v(e) === "legend") return 10;
	if (!g(e)) return 0;
	let r = t ? 1 : _(e);
	return n ? r * 2 : r;
}
function ne(e, t, n, r) {
	let i = e.reduce((e, r) => e + I(r, t, n), 0);
	return r && (i += 1), i;
}
function re(e, t) {
	return ne(e.rows[t], e.winterCard !== null, e.fury[t] ?? !1, e.favorRid === t);
}
function L(e, t) {
	let n = 0;
	for (let r of e.rows[t]) v(r) === "legend" ? n = Math.max(n, 10) : g(r) && (n = Math.max(n, _(r)));
	return n;
}
function R(e, t, n) {
	let r = n.rows[e].length, i = n.rows[t].length;
	if (r !== i) return r < i;
	let a = L(n, e), o = L(n, t);
	if (a !== o) return a > o;
	let s = n.players.length;
	return (N(n, e) - N(n, n.favorRid) + s) % s < (N(n, t) - N(n, n.favorRid) + s) % s;
}
function ie(e, t) {
	let n = t[0];
	for (let r of t.slice(1)) R(r, n, e) && (n = r);
	return n;
}
function z(e) {
	e.phase = "battle";
	for (let t of e.players) e.rows[t] = [], e.passed[t] = e.hands[t].length === 0, e.fury[t] = !1;
	e.winterCard = null, e.bait = null, e.revealed = null, e.battleResult = null, e.roundEnd = !1, e.turn = F(e, e.favorRid);
}
function B(e, t) {
	let n = null;
	if (t !== "doves") {
		let t = e.players.map((t) => ({
			rid: t,
			value: re(e, t)
		})), r = Math.max(...t.map((e) => e.value));
		n = ie(e, t.filter((e) => e.value === r).map((e) => e.rid)), e.chips[n][e.chipColor] += 1, e.favorRid = n;
	}
	if (e.battleResult = {
		winner: n,
		reason: t
	}, e.turn = null, e.bait = null, e.phase = "battleEnd", n) {
		let t = e.chips[n];
		if (t.magenta >= 3 || t.orange >= 3 || t.ivory >= 3 || t.magenta > 0 && t.orange > 0 && t.ivory > 0) {
			e.winner = n, e.phase = "done";
			return;
		}
	}
	let r = e.players.filter((t) => e.hands[t].length > 0);
	if (r.length <= 1) {
		for (let t of r) e.discard.push(...e.hands[t]), e.hands[t] = [];
		e.roundEnd = !0;
	}
}
function V(e, t) {
	if (e.hands[t].length === 0 && (e.passed[t] = !0), e.players.filter((t) => !e.passed[t]).length === 0) {
		B(e, "allPass");
		return;
	}
	e.turn = F(e, t);
}
function ae(e) {
	for (let t of e.players) e.discard.push(...e.rows[t]), e.rows[t] = [];
	e.winterCard !== null && (e.discard.push(e.winterCard), e.winterCard = null), e.revealed = null;
}
function oe(e) {
	let t = [...e.deck, ...e.discard];
	for (let n of e.players) t.push(...e.hands[n]), e.hands[n] = [];
	e.discard = [];
	let n = j(t, e.seed, e.rngCursor);
	e.rngCursor = n.cursor;
	let r = 0;
	for (let t of e.players) {
		let i = 10 + A(e.chips[t]);
		e.hands[t] = n.deck.slice(r, r + i).sort(b), r += i;
	}
	e.deck = n.deck.slice(r), e.round += 1, e.phase = "chipChoice", e.chipColor = null, e.rows = Object.fromEntries(e.players.map((e) => [e, []])), e.passed = Object.fromEntries(e.players.map((e) => [e, !1])), e.fury = Object.fromEntries(e.players.map((e) => [e, !1])), e.winterCard = null, e.turn = null, e.bait = null, e.revealed = null, e.battleResult = null, e.roundEnd = !1;
}
function se(e, t, n) {
	if (t.type === "chooseChip") {
		if (e.phase !== "chipChoice") return { code: "games.hilt.errPhase" };
		if (n.by !== e.favorRid) return { code: "games.hilt.errNotFavor" };
		if (e.supply[t.color] <= 0) return { code: "games.hilt.errNoChip" };
		let r = structuredClone(e);
		return --r.supply[t.color], r.chipColor = t.color, z(r), { state: r };
	}
	if (t.type === "play") {
		if (e.phase !== "battle" || e.turn !== n.by || e.passed[n.by]) return { code: "games.hilt.errNotYourTurn" };
		if (!e.hands[n.by].includes(t.card)) return { code: "games.hilt.errBadCard" };
		let r = v(t.card);
		if (r === "fury" && e.fury[n.by]) return { code: "games.hilt.errFuryPlayed" };
		if (r === "winter" && e.winterCard !== null) return { code: "games.hilt.errWinterPlayed" };
		if (r === "bait" && !e.rows[n.by].some(g)) return { code: "games.hilt.errBaitNoForce" };
		let i = structuredClone(e);
		return i.hands[n.by] = i.hands[n.by].filter((e) => e !== t.card), r === "bait" ? (i.discard.push(t.card), i.bait = { rid: n.by }, i.phase = "baitPick", { state: i }) : (r === "winter" ? i.winterCard = t.card : i.rows[n.by].push(t.card), r === "fury" && (i.fury[n.by] = !0), r === "crows" ? B(i, "crows") : r === "doves" ? B(i, "doves") : V(i, n.by), { state: i });
	}
	if (t.type === "baitPick") {
		if (e.phase !== "baitPick" || e.bait?.rid !== n.by) return { code: "games.hilt.errNotYourTurn" };
		if (!e.rows[n.by].includes(t.card) || !g(t.card)) return { code: "games.hilt.errBadBait" };
		let r = structuredClone(e);
		return r.rows[n.by] = r.rows[n.by].filter((e) => e !== t.card), r.hands[n.by] = [...r.hands[n.by], t.card].sort(b), r.bait = null, r.phase = "battle", V(r, n.by), { state: r };
	}
	if (t.type === "pass") {
		if (e.phase !== "battle" || e.turn !== n.by || e.passed[n.by]) return { code: "games.hilt.errNotYourTurn" };
		if (t.discard && e.hands[n.by].some(g)) return { code: "games.hilt.errCannotDiscard" };
		let r = structuredClone(e);
		return t.discard && (r.revealed = {
			rid: n.by,
			cards: [...r.hands[n.by]]
		}, r.discard.push(...r.hands[n.by]), r.hands[n.by] = []), r.passed[n.by] = !0, r.players.filter((e) => !r.passed[e]).length === 0 ? B(r, "allPass") : r.turn = F(r, n.by), { state: r };
	}
	if (e.phase !== "battleEnd" || n.by !== e.favorRid) return { code: "games.hilt.errPhase" };
	let r = structuredClone(e), i = r.battleResult;
	if (ae(r), r.roundEnd) {
		let e = i?.reason === "doves" ? r.chipColor : null;
		return oe(r), e !== null && (r.chipColor = e, z(r)), { state: r };
	}
	return r.battleResult = null, i?.reason === "doves" ? z(r) : (r.phase = "chipChoice", r.chipColor = null), { state: r };
}
function ce(e, t) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			chipColor: e.chipColor,
			supply: { ...e.supply },
			favorRid: e.favorRid,
			turn: e.turn,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t].length,
				chips: { ...e.chips[t] },
				passed: e.passed[t] ?? !1
			})),
			rows: Object.fromEntries(e.players.map((t) => [t, e.rows[t]])),
			fury: Object.fromEntries(e.players.map((t) => [t, e.fury[t] ?? !1])),
			winterCard: e.winterCard,
			bait: e.bait ? { rid: e.bait.rid } : null,
			revealed: e.revealed ? {
				rid: e.revealed.rid,
				cards: [...e.revealed.cards]
			} : null,
			battleResult: e.battleResult ? { ...e.battleResult } : null,
			roundEnd: e.roundEnd,
			winner: e.winner
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.winner, n = (t) => A(e.chips[t]), r = [...e.players].sort((r, i) => r === t ? -1 : i === t ? 1 : n(i) - n(r) || N(e, r) - N(e, i));
	return {
		phase: "done",
		winner: t ? [t] : [],
		ranking: r,
		scores: Object.fromEntries(e.players.map((e) => [e, n(e)]))
	};
}
var ue = {
	meta: x,
	saveCompatibility: { version: "1" },
	schemas: {
		action: w,
		publicView: O,
		privateView: ee
	},
	setup: M,
	reduce: se,
	viewFor: ce,
	status: le
};
//#endregion
//#region src/game/card.tsx
function H(e, t) {
	return e(t === "bait" ? "games.hilt.cardBaitName" : t === "fury" ? "games.hilt.cardFuryName" : t === "legend" ? "games.hilt.cardLegendName" : t === "winter" ? "games.hilt.cardWinterName" : t === "crows" ? "games.hilt.cardCrowsName" : "games.hilt.cardDovesName");
}
function U(e, t) {
	return e(t === "bait" ? "games.hilt.cardBaitText" : t === "fury" ? "games.hilt.cardFuryText" : t === "legend" ? "games.hilt.cardLegendText" : t === "winter" ? "games.hilt.cardWinterText" : t === "crows" ? "games.hilt.cardCrowsText" : "games.hilt.cardDovesText");
}
function W(e, t) {
	return g(t) ? e("games.hilt.forceName", { n: _(t) }) : H(e, v(t));
}
function G({ card: e, size: t, winter: n = !1, fury: r = !1, selected: i = !1, className: o, style: s }) {
	let c = a(), f = v(e), p = _(e), m = t === "hand", h = f === "legend" ? 10 : g(e) ? (n ? 1 : p) * (r ? 2 : 1) : null, y = f === "legend" || g(e) && h !== p, b = f === "legend" ? "legend" : n ? "winter" : "fury", x = f === "force" ? c("games.hilt.forceAria", { n: p }) : c("games.hilt.cardAria", {
		name: H(c, f),
		text: U(c, f)
	});
	return /* @__PURE__ */ d("span", {
		"aria-label": x,
		"data-kind": f,
		"data-selected": i || void 0,
		className: `hilt-card hilt-card--${t}${f === "force" ? " hilt-card--force" : " hilt-card--fate"}${o ? ` ${o}` : ""}`,
		style: s,
		children: [f === "force" ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ d("svg", {
			"aria-hidden": !0,
			viewBox: "0 0 100 140",
			className: "hilt-card-arcs",
			preserveAspectRatio: "none",
			children: [/* @__PURE__ */ u("path", { d: "M4 132C4 52 40 10 96 10" }), /* @__PURE__ */ u("path", { d: "M0 140C0 62 36 18 92 18" })]
		}), /* @__PURE__ */ u("span", {
			className: "hilt-card-number",
			children: p
		})] }) : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ d("span", {
			className: "hilt-card-fate-head",
			children: [/* @__PURE__ */ u("span", {
				className: "hilt-card-fate-name",
				children: H(c, f)
			}), /* @__PURE__ */ u(de, { kind: f })]
		}), m && /* @__PURE__ */ u("span", {
			className: "hilt-card-fate-text",
			children: U(c, f)
		})] }), y && h !== null && /* @__PURE__ */ d("span", {
			className: "hilt-card-eff",
			"data-eff": b,
			children: [/* @__PURE__ */ u("small", { children: "强" }), h]
		})]
	});
}
function de({ kind: e }) {
	return /* @__PURE__ */ d("svg", {
		"aria-hidden": !0,
		viewBox: "0 0 32 32",
		className: "hilt-glyph",
		"data-kind": e,
		children: [
			e === "bait" && /* @__PURE__ */ u("path", { d: "M21 4v13a6 6 0 0 1-12 0v-3m0 0-3 3m3-3 3 3" }),
			e === "fury" && /* @__PURE__ */ u("path", { d: "M16 3c3 5 8 8 8 15a8 8 0 0 1-16 0c0-4 3-6 4-10 2 2 3 4 3 6 2-3 2-7 1-11Z" }),
			e === "legend" && /* @__PURE__ */ u("path", { d: "m16 3 3.4 7.6 8.2.9-6.1 5.6 1.7 8.1L16 21.1l-7.2 4.1 1.7-8.1L4.4 11.5l8.2-.9Z" }),
			e === "winter" && /* @__PURE__ */ u("path", { d: "M16 4v24M5 10l22 12M27 10 5 22M12 6l4 4 4-4M12 26l4-4 4 4" }),
			e === "crows" && /* @__PURE__ */ u("path", { d: "M4 22c6 1 10-2 13-7 2 2 5 2 9 1-2 3-4 5-7 5-2 6-9 9-15 7l4-3-4-3Z" }),
			e === "doves" && /* @__PURE__ */ u("path", { d: "M5 21c5 1 8-1 11-5 2 2 5 3 9 1-1 4-4 6-7 7-1 3-4 5-8 4l3-3-5-1 2-2-5-1Z" })
		]
	});
}
//#endregion
//#region src/game/chip.tsx
function K({ color: e, size: t = "sm", style: n }) {
	return /* @__PURE__ */ u("span", {
		"aria-hidden": !0,
		className: `${t === "lg" ? "hilt-chip hilt-chip--lg" : t === "xs" ? "hilt-chip hilt-chip--xs" : "hilt-chip"} hilt-chip--${e}`,
		style: n,
		children: /* @__PURE__ */ d("svg", {
			viewBox: "0 0 32 32",
			className: "hilt-chip-svg",
			children: [
				/* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "16",
					r: "14.4",
					className: "hilt-chip-disk"
				}),
				/* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "16",
					r: "12",
					className: "hilt-chip-bevel"
				}),
				/* @__PURE__ */ u("path", {
					d: "M5.6 12.4a11.4 11.4 0 0 1 11-6.7",
					className: "hilt-chip-shine"
				}),
				e === "magenta" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("path", {
					d: "M16 3.8 19.9 12.1 28.2 16 19.9 19.9 16 28.2 12.1 19.9 3.8 16 12.1 12.1Z",
					className: "hilt-chip-mark"
				}), /* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "16",
					r: "3.2",
					className: "hilt-chip-hole"
				})] }),
				e === "orange" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("path", {
					d: "M16 4.6 27.4 26.2H4.6Z",
					className: "hilt-chip-mark"
				}), /* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "19.2",
					r: "3.1",
					className: "hilt-chip-hole"
				})] }),
				e === "ivory" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "16",
					r: "8.8",
					className: "hilt-chip-ring"
				}), /* @__PURE__ */ u("circle", {
					cx: "16",
					cy: "16",
					r: "2.8",
					className: "hilt-chip-mark"
				})] })
			]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
function fe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ u(pe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function pe({ pub: e, priv: t, members: i, myRid: f, send: p }) {
	let m = a(), h = t?.hand ?? [], y = h.join(","), [b, S] = n(null), [C, w] = n(null), T = (e) => i.find((t) => t.rid === e)?.name ?? e, E = (e) => m(e === "magenta" ? "games.hilt.chipMagenta" : e === "orange" ? "games.hilt.chipOrange" : "games.hilt.chipIvory"), D = e.players.find((e) => e.rid === f)?.passed ?? !1, O = e.phase === "battle" && e.turn === f && !D, ee = e.players.filter((e) => e.rid !== f && !e.passed), te = h.some(g), A = O && b?.hand === y && h.includes(b.card) ? b.card : null, j = O && C === y, M = (e) => S(e === null ? null : {
		card: e,
		hand: y
	}), N = (e) => w(e ? y : null), P = "info", F = "", I;
	if (e.phase === "chipChoice") e.favorRid === f ? (P = "accent", F = m("games.hilt.chipChoicePrompt")) : (F = m("games.hilt.waitingFor", { name: T(e.favorRid) }), I = m("games.hilt.chipChoiceAction"));
	else if (e.phase === "battle") {
		let t = e.chipColor ? E(e.chipColor) : "";
		D ? (F = m("games.hilt.youPassed"), I = m("games.hilt.youPassedSub")) : O ? (P = "accent", F = m("games.hilt.turnPlay"), I = ee.length === 0 ? m("games.hilt.turnPlayChain") : t ? m("games.hilt.contestedChip", { color: t }) : void 0) : (F = m("games.hilt.waitingPlay", { name: T(e.turn ?? e.favorRid) }), I = t ? m("games.hilt.contestedChip", { color: t }) : void 0);
	} else e.phase === "baitPick" ? e.bait?.rid === f ? (P = "accent", F = m("games.hilt.baitPickPrompt"), I = m("games.hilt.baitPickSub")) : (F = m("games.hilt.waitingFor", { name: T(e.bait?.rid ?? e.favorRid) }), I = m("games.hilt.baitPickAction")) : e.phase === "battleEnd" && (F = m("games.hilt.battleEndPrompt"), e.favorRid === f ? P = "accent" : I = m("games.hilt.continueWaiting", { name: T(e.favorRid) }));
	let re = (e) => {
		p({
			type: "play",
			card: e
		}), M(null);
	}, L = () => {
		p({ type: "pass" }), M(null), N(!1);
	}, R = () => {
		p({
			type: "pass",
			discard: !0
		}), M(null), N(!1);
	};
	return /* @__PURE__ */ u("div", {
		className: "hilt-screen",
		style: { "--hilt-accent": x.accent },
		children: /* @__PURE__ */ u(s, {
			adaptive: !0,
			scroll: !1,
			className: "hilt-screen-adaptive",
			actionsHeight: "hilt-actions",
			banner: /* @__PURE__ */ u("div", {
				className: "hilt-top",
				children: /* @__PURE__ */ u(c, {
					tone: P,
					text: F,
					sub: I,
					chip: m("games.hilt.round", { n: e.round })
				})
			}),
			actions: /* @__PURE__ */ d("div", {
				className: "hilt-hand",
				children: [/* @__PURE__ */ d("div", {
					className: "hilt-hand-head",
					children: [/* @__PURE__ */ u("span", { children: m("games.hilt.myHand") }), /* @__PURE__ */ u("span", { children: m("games.hilt.handCount", { n: h.length }) })]
				}), /* @__PURE__ */ u("div", {
					className: "hilt-hand-scroll scrollbar-none",
					children: h.length === 0 ? /* @__PURE__ */ u("p", {
						className: "hilt-hand-empty",
						children: m("games.hilt.handEmpty")
					}) : /* @__PURE__ */ u("div", {
						className: "hilt-hand-cards",
						children: h.map((t) => {
							let n = A === t, r = W(m, t);
							return /* @__PURE__ */ d("div", {
								className: "hilt-hand-slot",
								children: [n && O && /* @__PURE__ */ d("div", {
									className: "hilt-hand-tools",
									children: [/* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-mini-btn hilt-mini-btn--primary",
										onClick: () => re(t),
										children: m("games.hilt.play")
									}), /* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-mini-btn",
										onClick: () => M(null),
										children: m("games.hilt.cancel")
									})]
								}), /* @__PURE__ */ u("button", {
									type: "button",
									className: "hilt-hand-card",
									disabled: !O,
									"aria-pressed": n,
									"aria-label": m(n ? "games.hilt.cancelAria" : "games.hilt.selectAria", { name: r }),
									onClick: () => M(n ? null : t),
									children: /* @__PURE__ */ u(G, {
										card: t,
										size: "hand",
										winter: e.winterCard !== null,
										fury: e.fury[f] ?? !1,
										selected: n
									})
								})]
							}, t);
						})
					})
				})]
			}),
			children: /* @__PURE__ */ d("div", {
				className: "hilt-board",
				children: [/* @__PURE__ */ u(me, {
					pub: e,
					myRid: f,
					send: p,
					nameOf: T,
					colorName: E
				}), /* @__PURE__ */ u("ol", {
					className: "hilt-lanes scrollbar-none",
					children: e.players.map((t) => {
						let n = t.rid, a = i.find((e) => e.rid === n), s = n === f, c = e.favorRid === n, h = e.turn === n && (e.phase === "battle" || e.phase === "baitPick"), y = ne(e.rows[n] ?? [], e.winterCard !== null, e.fury[n] ?? !1, c), b = o[(a?.colorIndex ?? 0) % o.length], x = e.phase === "baitPick" && e.bait?.rid === f && s;
						return /* @__PURE__ */ d("li", {
							className: "hilt-lane",
							"data-me": s || void 0,
							"data-current": h || void 0,
							"data-passed": t.passed || void 0,
							"data-favor": c || void 0,
							children: [
								/* @__PURE__ */ d("div", {
									className: "hilt-lane-head",
									children: [
										/* @__PURE__ */ u("span", {
											className: "hilt-lane-avatar",
											style: { backgroundColor: b.hex },
											children: a && /* @__PURE__ */ u("img", {
												src: r[a.avatar % r.length],
												alt: "",
												draggable: !1
											})
										}),
										/* @__PURE__ */ d("div", {
											className: "hilt-lane-who",
											children: [/* @__PURE__ */ d("div", {
												className: "hilt-lane-name",
												children: [
													/* @__PURE__ */ u("span", {
														title: T(n),
														children: T(n)
													}),
													s && /* @__PURE__ */ u("small", {
														className: "hilt-you",
														children: m("games.hilt.me")
													}),
													c && /* @__PURE__ */ d("span", {
														className: "hilt-favor",
														children: [/* @__PURE__ */ u("svg", {
															"aria-hidden": !0,
															viewBox: "0 0 16 16",
															children: /* @__PURE__ */ u("path", { d: "m8 1 2 4.4 4.8.5-3.5 3.3 1 4.7L8 11.6 3.7 13.9l1-4.7L1.2 5.9 6 5.4Z" })
														}), m("games.hilt.favor")]
													}),
													h && /* @__PURE__ */ u("span", {
														className: "hilt-badge hilt-badge--playing",
														children: m("games.hilt.playing")
													}),
													t.passed && /* @__PURE__ */ u("span", {
														className: "hilt-badge hilt-badge--passed",
														children: m("games.hilt.passed")
													}),
													e.fury[n] && /* @__PURE__ */ u("span", {
														className: "hilt-badge hilt-badge--fury",
														children: m("games.hilt.furyActive")
													})
												]
											}), /* @__PURE__ */ d("div", {
												className: "hilt-lane-meta",
												children: [/* @__PURE__ */ u("span", {
													className: "hilt-lane-chips",
													children: k.map((e) => /* @__PURE__ */ d("span", {
														className: "hilt-chipcount",
														"aria-label": m("games.hilt.chipsAria", {
															color: E(e),
															n: t.chips[e]
														}),
														children: [
															/* @__PURE__ */ u(K, {
																color: e,
																size: "xs"
															}),
															/* @__PURE__ */ u("span", {
																className: "hilt-chipcount-name",
																children: E(e)
															}),
															/* @__PURE__ */ u("b", { children: t.chips[e] })
														]
													}, e))
												}), /* @__PURE__ */ u("span", {
													className: "hilt-badge",
													children: m("games.hilt.handCount", { n: t.handCount })
												})]
											})]
										}),
										/* @__PURE__ */ d("div", {
											className: "hilt-lane-strength",
											"aria-label": m("games.hilt.strengthAria", { n: y }),
											children: [/* @__PURE__ */ u("small", { children: m("games.hilt.strengthLabel") }), /* @__PURE__ */ u("b", { children: y })]
										})
									]
								}),
								/* @__PURE__ */ u("div", {
									className: "hilt-lane-row scrollbar-none",
									children: (e.rows[n] ?? []).map((t) => x && g(t) ? /* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-lane-card hilt-lane-card--pick",
										"aria-label": m("games.hilt.baitPickAria", { n: _(t) }),
										onClick: () => p({
											type: "baitPick",
											card: t
										}),
										children: /* @__PURE__ */ u(G, {
											card: t,
											size: "lane",
											winter: e.winterCard !== null,
											fury: e.fury[n] ?? !1
										})
									}, t) : /* @__PURE__ */ u("span", {
										className: "hilt-lane-card",
										children: /* @__PURE__ */ u(G, {
											card: t,
											size: "lane",
											winter: e.winterCard !== null,
											fury: e.fury[n] ?? !1
										})
									}, t))
								}),
								e.revealed?.rid === n && /* @__PURE__ */ d("div", {
									className: "hilt-lane-reveal",
									"aria-label": m("games.hilt.revealedAria", {
										name: T(n),
										cards: e.revealed.cards.map((e) => W(m, e)).join("、")
									}),
									children: [/* @__PURE__ */ u("span", {
										className: "hilt-lane-reveal-label",
										children: m("games.hilt.revealedLabel")
									}), /* @__PURE__ */ u("span", {
										className: "hilt-lane-reveal-cards scrollbar-none",
										children: e.revealed.cards.map((e) => /* @__PURE__ */ u("span", {
											className: "hilt-lane-reveal-card",
											"data-kind": v(e),
											children: W(m, e)
										}, e))
									})]
								}),
								s && /* @__PURE__ */ u("div", {
									className: "hilt-lane-foot",
									children: O && /* @__PURE__ */ d(l, { children: [!te && (j ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-btn hilt-btn--warn",
										onClick: R,
										children: m("games.hilt.discardConfirm")
									}), /* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-btn",
										onClick: () => N(!1),
										children: m("games.hilt.discardCancel")
									})] }) : /* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-btn",
										"aria-label": m("games.hilt.discardHandAria"),
										onClick: () => N(!0),
										children: m("games.hilt.discardHand")
									})), /* @__PURE__ */ u("button", {
										type: "button",
										className: "hilt-btn hilt-btn--primary",
										"aria-label": m("games.hilt.passAria"),
										onClick: L,
										children: m("games.hilt.pass")
									})] })
								})
							]
						}, n);
					})
				})]
			})
		})
	});
}
function me({ pub: e, myRid: t, send: n, nameOf: r, colorName: i }) {
	let o = a(), s = e.favorRid === t, c = e.chipColor, f = e.battleResult, p = f?.reason === "crows" ? o("games.hilt.reasonCrows") : f?.reason === "doves" ? o("games.hilt.reasonDoves") : null;
	return /* @__PURE__ */ d("div", {
		className: "hilt-center",
		"data-phase": e.phase,
		children: [
			e.phase === "chipChoice" && /* @__PURE__ */ d(l, { children: [
				/* @__PURE__ */ u("div", {
					className: "hilt-center-head",
					children: o("games.hilt.battleChip")
				}),
				/* @__PURE__ */ u("div", {
					className: "hilt-chip-choice",
					children: k.map((t) => /* @__PURE__ */ d("button", {
						type: "button",
						className: "hilt-chip-btn",
						disabled: !s || e.supply[t] <= 0,
						"aria-label": o("games.hilt.chipChoiceAria", { color: i(t) }),
						onClick: () => n({
							type: "chooseChip",
							color: t
						}),
						children: [
							/* @__PURE__ */ u(K, {
								color: t,
								size: "sm"
							}),
							/* @__PURE__ */ u("span", {
								className: "hilt-chip-btn-name",
								children: i(t)
							}),
							/* @__PURE__ */ u("small", { children: o("games.hilt.supplyLeft", { n: e.supply[t] }) })
						]
					}, t))
				}),
				!s && /* @__PURE__ */ u("p", {
					className: "hilt-center-note",
					children: o("games.hilt.chipChoiceWaiting", { name: r(e.favorRid) })
				})
			] }),
			(e.phase === "battle" || e.phase === "baitPick") && c && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("div", {
				className: "hilt-center-head",
				children: o("games.hilt.battleChip")
			}), /* @__PURE__ */ d("div", {
				className: "hilt-center-main",
				children: [/* @__PURE__ */ d("span", {
					className: "hilt-center-chip",
					children: [
						/* @__PURE__ */ u(K, {
							color: c,
							size: "lg"
						}),
						/* @__PURE__ */ u("b", { children: i(c) }),
						/* @__PURE__ */ u("small", { children: o("games.hilt.supplyLeft", { n: e.supply[c] }) })
					]
				}), e.winterCard !== null && /* @__PURE__ */ d("span", {
					className: "hilt-center-winter",
					children: [/* @__PURE__ */ u(G, {
						card: e.winterCard,
						size: "result"
					}), /* @__PURE__ */ u("small", { children: o("games.hilt.winterActive") })]
				})]
			})] }),
			e.phase === "battleEnd" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("div", {
				className: "hilt-center-head",
				children: o("games.hilt.battleEndPrompt")
			}), /* @__PURE__ */ d("div", {
				className: "hilt-center-main",
				children: [/* @__PURE__ */ d("div", {
					className: "hilt-center-result",
					children: [
						/* @__PURE__ */ u("b", { children: f?.winner ? o("games.hilt.battleEndWin", { name: r(f.winner) }) : o("games.hilt.battleEndDoves") }),
						p && /* @__PURE__ */ u("small", { children: p }),
						e.roundEnd && /* @__PURE__ */ u("small", { children: o("games.hilt.roundEndNote") })
					]
				}), s ? /* @__PURE__ */ u("button", {
					type: "button",
					className: "hilt-btn hilt-btn--primary",
					onClick: () => n({ type: "continue" }),
					children: o("games.hilt.continue")
				}) : /* @__PURE__ */ u("span", {
					className: "hilt-center-note",
					children: o("games.hilt.continueWaiting", { name: r(e.favorRid) })
				})]
			})] })
		]
	});
}
//#endregion
//#region src/game/bot.ts
var he = [
	"magenta",
	"orange",
	"ivory"
];
function q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function ge(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967296 < e;
}
function _e(e, t) {
	return e.players.find((e) => e.rid === t)?.chips ?? {
		magenta: 0,
		orange: 0,
		ivory: 0
	};
}
function J(e, t) {
	let n = {
		...e,
		[t]: e[t] + 1
	};
	return n.magenta >= 3 || n.orange >= 3 || n.ivory >= 3 || n.magenta > 0 && n.orange > 0 && n.ivory > 0;
}
function ve(e, t) {
	let n = 0;
	for (let r of e.rows[t] ?? []) g(r) && (n += e.winterCard === null ? _(r) : 1);
	return n;
}
function Y(e, t) {
	let n = 0;
	for (let r of e.rows[t] ?? []) v(r) === "legend" && (n += 10);
	return n;
}
function X(e, t) {
	return ve(e, t) * (e.fury[t] ? 2 : 1) + Y(e, t) + +(e.favorRid === t);
}
function Z(e, t) {
	let n = 0;
	for (let r of e.rows[t] ?? []) g(r) && (n += e.fury[t] ? 2 : 1);
	return n + Y(e, t) + +(e.favorRid === t);
}
function ye(e, t) {
	return ve(e, t) * 2 + Y(e, t) + +(e.favorRid === t);
}
function be(e, t) {
	let n = 0;
	for (let r of e.rows[t] ?? []) v(r) === "legend" ? n = Math.max(n, 10) : g(r) && (n = Math.max(n, _(r)));
	return n;
}
function xe(e, t, n) {
	let r = e.rows[t] ?? [], i = e.rows[n] ?? [];
	if (r.length !== i.length) return r.length < i.length;
	let a = be(e, t), o = be(e, n);
	if (a !== o) return a > o;
	let s = e.players.length, c = Math.max(0, e.players.findIndex((t) => t.rid === e.favorRid)), l = e.players.findIndex((e) => e.rid === t), u = e.players.findIndex((e) => e.rid === n);
	return (l - c + s) % s < (u - c + s) % s;
}
function Se(e) {
	let t = e.players[0].rid, n = X(e, t);
	for (let r of e.players.slice(1)) {
		let i = X(e, r.rid);
		(i > n || i === n && xe(e, r.rid, t)) && (t = r.rid, n = i);
	}
	return t;
}
function Q(e, t) {
	let n = 0;
	for (let r of e.players) r.rid !== t && (n = Math.max(n, X(e, r.rid)));
	return n;
}
function Ce(e, t) {
	let n = 0;
	for (let r of e.players) r.rid !== t && (n = Math.max(n, Z(e, r.rid)));
	return n;
}
function we(e, t, n) {
	return v(n) === "legend" ? 10 : g(n) ? (e.winterCard === null ? _(n) : 1) * (e.fury[t] ? 2 : 1) : 0;
}
function Te(e, t, n) {
	return n.filter((n) => {
		let r = v(n);
		return r === "bait" ? (e.rows[t] ?? []).some(g) : r === "fury" ? !e.fury[t] : r !== "winter" || e.winterCard === null;
	});
}
function Ee(e, t, n, r) {
	let i = null, a = Infinity;
	for (let o of n) {
		let n = v(o);
		if (n !== "force" && n !== "legend") continue;
		let s = we(e, t, o);
		s < r || s <= 0 || (s < a || s === a && (i === null || o < i)) && (i = o, a = s);
	}
	return i;
}
function $(e, t) {
	for (let n of e) if (v(n) === t) return n;
	return null;
}
function De(e, t, n) {
	let r = _e(e, t), i = 0;
	J(r, n) ? i += 200 : r[n] > 0 ? i += 60 : he.filter((e) => r[e] > 0).length === 1 && (i += 50);
	for (let r of e.players) r.rid !== t && (J(r.chips, n) ? i -= 250 : r.chips[n] >= 2 && (i -= 120));
	return i;
}
function Oe(e, t, n) {
	let r = he.filter((t) => e.supply[t] > 0);
	if (r.length === 0) return null;
	if (n === "weak") return {
		type: "chooseChip",
		color: q(r)
	};
	let i = r[0], a = -Infinity;
	for (let n of r) {
		let r = De(e, t, n);
		r > a && (i = n, a = r);
	}
	return {
		type: "chooseChip",
		color: i
	};
}
function ke(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	if (e.phase !== "battle" || e.turn !== t || i?.passed) return null;
	let a = Te(e, t, n);
	if (r === "weak") return a.length === 0 || ge(.25) ? { type: "pass" } : {
		type: "play",
		card: q(a)
	};
	if (a.length === 0) return { type: "pass" };
	let o = e.chipColor, s = X(e, t), c = Se(e) === t, l = e.players.filter((e) => e.rid !== t && !e.passed).length === 0, u = Ee(e, t, a, Math.max(1, Q(e, t) - s + 1)), d = o !== null && J(_e(e, t), o), f = o !== null && e.players.some((e) => e.rid !== t && J(e.chips, o)), p = o === null ? 30 : d ? 100 : De(e, t, o), m = p >= 40 || f;
	if (l) {
		if (c) return { type: "pass" };
		if (u !== null) return {
			type: "play",
			card: u
		};
		let n = $(a, "winter");
		if (n !== null && Z(e, t) > Ce(e, t)) return {
			type: "play",
			card: n
		};
		let r = $(a, "fury");
		return r !== null && ye(e, t) > Q(e, t) ? {
			type: "play",
			card: r
		} : { type: "pass" };
	}
	if (c) {
		let e = $(a, "crows");
		return e !== null && p >= 55 ? {
			type: "play",
			card: e
		} : { type: "pass" };
	}
	if (u !== null && m) return {
		type: "play",
		card: u
	};
	if (m) {
		let n = $(a, "winter");
		if (n !== null && Z(e, t) > Ce(e, t)) return {
			type: "play",
			card: n
		};
		let r = $(a, "fury");
		if (r !== null && ye(e, t) > Q(e, t)) return {
			type: "play",
			card: r
		};
	}
	if (f) {
		let e = $(a, "doves");
		if (e !== null) return {
			type: "play",
			card: e
		};
	}
	return { type: "pass" };
}
var Ae = (e, t) => {
	let n = e.public, r = t.rid, i = e.private?.hand ?? [];
	if (n.phase === "chipChoice") {
		if (n.favorRid !== r) return null;
		let e = Oe(n, r, t.difficulty);
		return e ? { action: e } : null;
	}
	if (n.phase === "battle") {
		let e = ke(n, r, i, t.difficulty);
		return e ? { action: e } : null;
	}
	if (n.phase === "baitPick") {
		if (n.bait?.rid !== r) return null;
		let e = (n.rows[r] ?? []).filter(g);
		return e.length === 0 ? null : { action: {
			type: "baitPick",
			card: t.difficulty === "weak" ? q(e) : e.reduce((e, t) => _(t) > _(e) ? t : e, e[0])
		} };
	}
	return n.phase === "battleEnd" && n.favorRid === r ? { action: { type: "continue" } } : null;
}, je = (e, t, n) => e.type === "pass" ? e.discard ? n("games.hilt.discardHandAria") : n("games.hilt.passAria") : e.type === "continue" ? n("games.hilt.continue") : e.type === "baitPick" ? n("games.hilt.baitPickAria", { n: _(e.card) }) : e.type === "chooseChip" ? n("games.hilt.chipChoiceAria", { color: Me(e.color, n) }) : n("games.hilt.playAria", { name: Ne(e.card, n) });
function Me(e, t) {
	return t(e === "magenta" ? "games.hilt.chipMagenta" : e === "orange" ? "games.hilt.chipOrange" : "games.hilt.chipIvory");
}
function Ne(e, t) {
	let n = v(e);
	return n === "force" ? t("games.hilt.forceName", { n: _(e) }) : t(n === "legend" ? "games.hilt.cardLegendName" : n === "bait" ? "games.hilt.cardBaitName" : n === "fury" ? "games.hilt.cardFuryName" : n === "winter" ? "games.hilt.cardWinterName" : n === "crows" ? "games.hilt.cardCrowsName" : "games.hilt.cardDovesName");
}
//#endregion
//#region src/game/game-over.tsx
var Pe = {
	magenta: 0,
	orange: 0,
	ivory: 0
};
function Fe({ result: e, public: t, members: n, myRid: s, onPlayAgain: c, onBackToLobby: l }) {
	let m = a(), h = i((e) => e.locale), g = t, _ = c ?? l, v = (e) => m(e === "magenta" ? "games.hilt.chipMagenta" : e === "orange" ? "games.hilt.chipOrange" : "games.hilt.chipIvory");
	return /* @__PURE__ */ u("div", {
		className: "hilt-result",
		style: { "--hilt-accent": x.accent },
		children: /* @__PURE__ */ d("div", {
			className: "hilt-result-layout",
			children: [
				/* @__PURE__ */ u("h1", {
					className: "hilt-result-title",
					children: m("session.result.title")
				}),
				/* @__PURE__ */ u("p", {
					className: "hilt-result-sub",
					children: m("games.hilt.resultWinLine")
				}),
				/* @__PURE__ */ u("ol", {
					className: "hilt-result-ranking",
					children: e.ranking.map((t, i) => {
						let a = n.find((e) => e.rid === t), c = a ? p(a, h) : t, l = g?.players.find((e) => e.rid === t)?.chips ?? Pe, _ = e.scores?.[t] ?? k.reduce((e, t) => e + l[t], 0), y = e.winner.includes(t), b = e.autopilot?.[t];
						return /* @__PURE__ */ d("li", {
							className: "hilt-result-player",
							"data-winner": y || void 0,
							children: [
								y && /* @__PURE__ */ u("span", {
									className: "hilt-result-cup",
									"aria-hidden": !0,
									children: "🏆"
								}),
								/* @__PURE__ */ u("span", {
									className: "hilt-result-rank",
									children: i + 1
								}),
								/* @__PURE__ */ u("span", {
									className: "hilt-result-avatar",
									style: { backgroundColor: o[(a?.colorIndex ?? 0) % o.length].hex },
									children: a && /* @__PURE__ */ u("img", {
										src: r[a.avatar % r.length],
										alt: "",
										draggable: !1
									})
								}),
								/* @__PURE__ */ d("div", {
									className: "hilt-result-person",
									children: [
										/* @__PURE__ */ d("strong", { children: [c, t === s && /* @__PURE__ */ u("small", { children: m("lobby.you") })] }),
										/* @__PURE__ */ u("div", {
											className: "hilt-result-chips",
											children: k.map((e) => /* @__PURE__ */ d("span", {
												className: "hilt-result-chip",
												"aria-label": m("games.hilt.resultChipAria", {
													color: v(e),
													n: l[e]
												}),
												children: [
													/* @__PURE__ */ u(K, {
														color: e,
														size: "sm"
													}),
													/* @__PURE__ */ u("b", { children: l[e] }),
													/* @__PURE__ */ u("span", { children: v(e) })
												]
											}, e))
										}),
										b !== void 0 && b > 0 && /* @__PURE__ */ d("small", {
											className: "hilt-result-autopilot",
											children: [/* @__PURE__ */ u(f, { size: 14 }), m("session.autopilot.share", { n: Math.round(b * 100) })]
										})
									]
								}),
								/* @__PURE__ */ d("div", {
									className: "hilt-result-total",
									children: [/* @__PURE__ */ u("b", { children: _ }), /* @__PURE__ */ u("small", { children: m("games.hilt.resultTotalLabel") })]
								})
							]
						}, t);
					})
				}),
				_ ? /* @__PURE__ */ d("div", {
					className: "hilt-result-controls safe-b",
					children: [c && /* @__PURE__ */ u("button", {
						type: "button",
						className: "hilt-btn hilt-btn--primary",
						onClick: c,
						children: m("session.result.playAgain")
					}), l && /* @__PURE__ */ u("button", {
						type: "button",
						className: "hilt-btn",
						onClick: l,
						children: m("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ u("p", {
					className: "hilt-result-wait safe-b",
					children: m("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/index.tsx
var Ie = {
	definition: ue,
	View: fe,
	bot: Ae,
	describe: je,
	OverView: Fe,
	locales: {
		zh: {
			name: "Hilt",
			desc: "以力量牌竞逐筹码，率先集齐三枚同色或三色各一枚者获胜",
			rules: "目标:\n战斗结束时赢得筹码。率先集齐同一种颜色的三枚筹码，或者集齐三种颜色各一枚筹码的玩家，赢得游戏。\n准备:\n· 将九十六张牌洗混，其中包括六十三张力量牌和三十三张命运牌；恩宠牌不进入牌堆。\n· 每名玩家获得十张手牌。恩宠牌放在第一名玩家的面前，这名玩家成为首位恩宠持有者。\n· 将三十枚筹码按品红、橙、象牙三种颜色分开，每种颜色十枚，放在桌面中央作为备用量。\n战斗:\n· 每场战斗开始时，恩宠持有者从备用量中选择一种仍有剩余的颜色，把该颜色的一枚筹码放进中央争夺区。\n· 战斗从恩宠持有者左手边的玩家开始，按顺时针方向依次进行。\n· 轮到你行动时，你可以从手牌中打出一张牌，正面朝上放在自己面前，形成一条出牌列。你也可以跳过。\n· 力量牌印有数字，为出牌者增加相应点数的强度。命运牌没有点数，打出时按照牌面说明生效。\n· 没有手牌的玩家不能出牌，在战斗中视为已经跳过。\n· 你跳过之后，本场战斗中不能再打出牌，但你已经打出的牌仍然留在桌面上。\n· 当除你以外的所有玩家都跳过之后，你可以连续打出任意多张牌，直到你也跳过。\n· 当所有玩家都跳过，或者有人打出乌鸦牌或白鸽牌时，战斗立即结束。\n平局:\n· 总强度最高的玩家赢得战斗。如果有多名玩家并列，打出牌数最少的并列玩家获胜。\n· 如果仍然并列，出牌中单张牌点数最高的并列玩家获胜。\n· 如果仍然并列，从恩宠持有者开始按顺时针方向数，最先出现的并列玩家获胜。\n结算:\n· 赢得战斗的玩家拿走中央争夺区的筹码，并取得恩宠牌。恩宠牌放在他的出牌列中，在每场战斗中为他增加一点强度。\n· 战斗结束后，所有玩家本场打出的牌正面朝下放入弃牌堆，手牌不补充。\n· 白鸽牌让战斗立即结束，本场无人获胜。恩宠牌留在原持有者手中，中央争夺区的筹码保留到下一场战斗继续争夺。\n· 乌鸦牌让战斗立即结束，当前总强度最高的玩家按照上述平局规则获胜。\n命运牌:\n· 诱饵：弃掉这张牌，然后把你本场打出的一张力量牌收回手中。你必须在本场打出过力量牌，才能打出诱饵牌。\n· 狂怒：本场战斗中，你打出的所有力量牌强度翻倍。每名玩家每场战斗只能打出一张狂怒牌。\n· 传说：提供十点强度。传说牌不受寒冬牌和狂怒牌影响，也不能被诱饵牌收回。\n· 寒冬：打出后放在桌面中央。每场战斗只能打出一张寒冬牌。本场战斗中，所有玩家的力量牌强度都变为一点。狂怒牌仍然可以使其翻倍为两点，传说牌不受影响。\n· 乌鸦：让战斗立即结束，当前总强度最高的玩家获胜。\n· 白鸽：让战斗立即结束，本场无人获胜。\n跳过:\n· 当你没有力量牌时跳过，你可以向所有人亮出手牌，然后弃掉剩余的全部手牌。\n回合结束:\n· 一场战斗结束后，如果只剩一名玩家还有手牌，这名玩家弃掉全部剩余手牌，本轮结束。\n· 把所有牌重新洗混，每名玩家重新获得十张手牌，并按照他拥有的筹码数量，每枚筹码额外获得一张手牌。\n· 重新发牌后，恩宠牌由上一场战斗的获胜者持有。如果上一场战斗没有获胜者，恩宠牌留在原持有者手中。\n游戏结束:\n· 一名玩家集齐同一种颜色的三枚筹码，或者集齐三种颜色各一枚筹码时，游戏立即结束，这名玩家获胜。",
			round: "第 {{n}} 轮",
			battleChip: "本场筹码",
			contestedChip: "争夺{{color}}筹码",
			supplyLeft: "剩余 {{n}}",
			chipChoicePrompt: "选择本场争夺的筹码颜色",
			chipChoiceWaiting: "等 {{name}} 选择筹码颜色…",
			chipChoiceAria: "选择{{color}}筹码",
			waitingFor: "等 {{name}}…",
			chipChoiceAction: "正在选择筹码颜色",
			chipMagenta: "品红",
			chipOrange: "橙",
			chipIvory: "象牙",
			turnPlay: "轮到你出牌",
			turnPlayChain: "你可以连续打出多张牌",
			waitingPlay: "等 {{name}} 出牌…",
			youPassed: "你已跳过",
			youPassedSub: "等待本场战斗结束",
			baitPickPrompt: "选择一张力量牌",
			baitPickSub: "把它收回手中",
			baitPickAction: "正在收回一张力量牌",
			baitPickAria: "收回力量牌 {{n}}",
			battleEndPrompt: "本场战斗结束",
			battleEndWin: "{{name}} 赢得本场战斗",
			battleEndDoves: "本场战斗无人获胜",
			reasonCrows: "乌鸦牌立即结束战斗",
			reasonDoves: "白鸽牌立即结束战斗",
			roundEndNote: "本轮结束，重新发牌",
			continue: "继续",
			continueWaiting: "等 {{name}} 继续…",
			strengthLabel: "强度",
			strengthAria: "当前强度 {{n}} 点",
			handCount: "手牌 {{n}}",
			chipsAria: "{{color}}筹码 {{n}} 枚",
			favor: "恩宠",
			me: "我",
			passed: "已跳过",
			playing: "出牌中",
			winterActive: "寒冬生效",
			furyActive: "狂怒生效",
			revealedLabel: "已亮出手牌",
			revealedAria: "{{name}} 亮出的手牌：{{cards}}",
			pass: "跳过",
			passAria: "跳过本场战斗",
			discardHand: "亮牌并弃牌",
			discardHandAria: "亮出手牌并弃掉全部剩余手牌",
			discardConfirm: "确认弃牌",
			discardCancel: "取消",
			play: "打出",
			playAria: "打出{{name}}",
			cancel: "取消",
			cancelAria: "取消选择{{name}}",
			selectAria: "选择{{name}}",
			myHand: "我的手牌",
			handEmpty: "手牌已空",
			forceName: "力量 {{n}}",
			forceAria: "力量牌 {{n}}",
			cardBaitName: "诱饵",
			cardBaitText: "弃掉这张牌，收回本场打出的一张力量牌",
			cardFuryName: "狂怒",
			cardFuryText: "本场你的力量牌强度翻倍",
			cardLegendName: "传说",
			cardLegendText: "提供十点强度，不受寒冬与狂怒影响",
			cardWinterName: "寒冬",
			cardWinterText: "本场所有力量牌强度变为一点",
			cardCrowsName: "乌鸦",
			cardCrowsText: "战斗立即结束，当前强度最高者获胜",
			cardDovesName: "白鸽",
			cardDovesText: "战斗立即结束，本场无人获胜",
			cardAria: "{{name}}，{{text}}",
			resultTotal: "共 {{n}} 枚",
			resultTotalLabel: "筹码总数",
			resultWinLine: "率先集齐三枚同色筹码，或集齐三色各一枚",
			resultChipAria: "{{color}}筹码 {{n}} 枚",
			errPhase: "现在不能执行这个操作",
			errNotFavor: "只有恩宠持有者可以选择筹码",
			errNoChip: "这种颜色的筹码已经没有剩余",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errFuryPlayed: "本场战斗你已经打出过狂怒牌",
			errWinterPlayed: "本场战斗已经打出过寒冬牌",
			errBaitNoForce: "你必须先在本场打出力量牌，才能打出诱饵牌",
			errBadBait: "只能收回本场打出的力量牌",
			errCannotDiscard: "手中还有力量牌时不能弃掉全部手牌"
		},
		en: {
			name: "Hilt",
			desc: "Win chips with force cards — first to three of one color or one of each wins",
			rules: "Goal:\nWin chips by winning battles. The first player to collect three chips of one color, or one chip of each of the three colors, wins the game.\nSetup:\n· Shuffle the ninety-six cards: sixty-three force cards and thirty-three fate cards. The Favor card is not part of the deck.\n· Each player receives ten cards. The Favor card is placed in front of the first player, who becomes the first Favor holder.\n· Separate the thirty chips by color (magenta, orange, and ivory), ten of each, and keep them in a central supply.\nBattles:\n· At the start of each battle, the Favor holder chooses a color that still has chips in the supply and places one chip of that color in the central contested area.\n· The battle begins with the player to the left of the Favor holder and proceeds clockwise.\n· On your turn, you may play one card from your hand face up in front of you to form your row, or you may pass.\n· Force cards show a number and add that many strength points to their owner. Fate cards have no number and take effect as described on the card.\n· Players with no cards in hand cannot play and count as having passed.\n· After you pass, you cannot play any more cards this battle, but the cards you already played stay on the table.\n· Once every other player has passed, you may play any number of cards in a row until you pass as well.\n· The battle ends immediately when all players have passed, or when someone plays a Crows or Doves card.\nTies:\n· The player with the highest total strength wins the battle. If players are tied, the tied player who played the fewest cards wins.\n· If they are still tied, the tied player with the highest single card among those they played wins.\n· If they are still tied, count clockwise from the Favor holder; the first tied player reached wins.\nResolution:\n· The winner takes the chip from the central contested area and takes the Favor card. The Favor card sits in their row and adds one strength point in every battle.\n· After the battle, all cards played this battle are discarded face down, and hands are not refilled.\n· Doves ends the battle immediately with no winner. The Favor card stays with its holder, and the central chip remains contested in the next battle.\n· Crows ends the battle immediately; the player with the highest total strength wins using the tie rules above.\nFate cards:\n· Bait: discard this card, then return one force card you played this battle to your hand. You must have played a force card this battle to play Bait.\n· Fury: in this battle, all force cards you played count double. Each player may play only one Fury card per battle.\n· Legend: worth ten strength points. A Legend card is not affected by Winter or Fury and cannot be returned by Bait.\n· Winter: place it in the central area. Only one Winter card may be played per battle. In this battle, every player's force cards are worth one strength point. Fury still doubles them to two, and Legend cards are unaffected.\n· Crows: end the battle immediately; the player with the highest total strength wins.\n· Doves: end the battle immediately with no winner.\nPassing:\n· When you pass and hold no force cards, you may reveal your hand to all players and discard all remaining cards.\nEnding the round:\n· After a battle, if only one player still has cards in hand, that player discards their entire hand and the round ends.\n· Shuffle all cards together, deal ten cards to each player, and deal one extra card for each chip that player owns.\n· After the redeal, the Favor card stays with the winner of the previous battle. If the previous battle had no winner, it stays with its current holder.\nEnd of the game:\n· As soon as a player has three chips of one color, or one chip of each color, the game ends and that player wins.",
			round: "Round {{n}}",
			battleChip: "Chip in play",
			contestedChip: "{{color}} chip contested",
			supplyLeft: "{{n}} left",
			chipChoicePrompt: "Choose the chip color",
			chipChoiceWaiting: "Waiting for {{name}} to choose a chip color…",
			chipChoiceAria: "Choose the {{color}} chip",
			waitingFor: "Waiting for {{name}}…",
			chipChoiceAction: "Choosing the chip color",
			chipMagenta: "Magenta",
			chipOrange: "Orange",
			chipIvory: "Ivory",
			turnPlay: "Your turn to play",
			turnPlayChain: "You may play several cards in a row",
			waitingPlay: "Waiting for {{name}} to play…",
			youPassed: "You passed",
			youPassedSub: "Waiting for the battle to end",
			baitPickPrompt: "Choose a force card",
			baitPickSub: "It returns to your hand",
			baitPickAction: "Taking back a force card",
			baitPickAria: "Take back force card {{n}}",
			battleEndPrompt: "The battle is over",
			battleEndWin: "{{name}} wins the battle",
			battleEndDoves: "No one wins this battle",
			reasonCrows: "Crows ends the battle immediately",
			reasonDoves: "Doves ends the battle immediately",
			roundEndNote: "Round over — cards will be redealt",
			continue: "Continue",
			continueWaiting: "Waiting for {{name}} to continue…",
			strengthLabel: "Strength",
			strengthAria: "Current strength {{n}}",
			handCount: "{{n}} cards",
			chipsAria: "{{n}} {{color}} chips",
			favor: "Favor",
			me: "You",
			passed: "Passed",
			playing: "Playing",
			winterActive: "Winter active",
			furyActive: "Fury active",
			revealedLabel: "Hand revealed",
			revealedAria: "Cards revealed by {{name}}: {{cards}}",
			pass: "Pass",
			passAria: "Pass this battle",
			discardHand: "Reveal & discard",
			discardHandAria: "Reveal your hand and discard every remaining card",
			discardConfirm: "Confirm discard",
			discardCancel: "Cancel",
			play: "Play",
			playAria: "Play {{name}}",
			cancel: "Cancel",
			cancelAria: "Deselect {{name}}",
			selectAria: "Select {{name}}",
			myHand: "My hand",
			handEmpty: "Hand is empty",
			forceName: "Force {{n}}",
			forceAria: "Force card {{n}}",
			cardBaitName: "Bait",
			cardBaitText: "Discard this card, then return one force card you played this battle",
			cardFuryName: "Fury",
			cardFuryText: "Your force cards count double this battle",
			cardLegendName: "Legend",
			cardLegendText: "Worth ten strength, unaffected by Winter and Fury",
			cardWinterName: "Winter",
			cardWinterText: "All force cards are worth one this battle",
			cardCrowsName: "Crows",
			cardCrowsText: "Ends the battle now — highest strength wins",
			cardDovesName: "Doves",
			cardDovesText: "Ends the battle now with no winner",
			cardAria: "{{name}}, {{text}}",
			resultTotal: "{{n}} chips",
			resultTotalLabel: "Total chips",
			resultWinLine: "First to three chips of one color, or one of each",
			resultChipAria: "{{n}} {{color}} chips",
			errPhase: "That action is not possible right now",
			errNotFavor: "Only the Favor holder chooses the chip color",
			errNoChip: "No chips of that color remain",
			errNotYourTurn: "Not your move right now",
			errBadCard: "That card is not in your hand",
			errFuryPlayed: "You already played a Fury card this battle",
			errWinterPlayed: "A Winter card was already played this battle",
			errBaitNoForce: "You must play a force card this battle before playing Bait",
			errBadBait: "You may only return a force card you played this battle",
			errCannotDiscard: "You cannot discard your whole hand while holding force cards"
		}
	}
};
//#endregion
export { Ie as default };
