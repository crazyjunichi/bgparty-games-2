import e from "@dimforge/rapier3d-compat";
import { randomAt as t, randomIntAt as n } from "@bgparty/sdk/engine/prng";
import { z as r } from "zod";
import { useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconCheck as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import * as v from "three";
import { ResilientCanvas as ee } from "@bgparty/sdk/three/resilient-canvas";
import { usePrefersReducedMotion as te } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { GameOverScreen as S } from "@bgparty/sdk/ui/game-over-screen";
import { OptionSection as C, OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
//#region src/game/initialize.ts
var T;
function E() {
	return T ??= e.init().catch((e) => {
		throw T = void 0, e;
	});
}
var D = [
	["cactus", 1],
	["cactus", 1],
	["cactus", 2],
	["cactus", 2],
	["cactus", 3],
	["cactus", 3],
	["cactus", 4],
	["cactus", 5],
	["lamp", 1],
	["lamp", 2],
	["lamp", 2],
	["lamp", 3],
	["lamp", 3],
	["lamp", 4],
	["lamp", 4],
	["lamp", 5],
	["donut", 1],
	["donut", 2],
	["donut", 3],
	["donut", 4],
	["cheese", 1],
	["cheese", 2],
	["cheese", 3],
	["cheese", 4],
	["jelly", 1],
	["jelly", 2],
	["jelly", 3],
	["jelly", 4],
	["none", 1],
	["none", 1],
	["none", 1],
	["none", 2],
	["none", 2],
	["none", 2],
	["none", 3],
	["none", 3],
	["none", 3],
	["none", 4],
	["none", 4],
	["none", 5]
].map(([e, t], n) => ({
	id: `t${String(n + 1).padStart(2, "0")}`,
	points: t,
	icon: e
})), O = Object.fromEntries(D.map((e) => [e.id, e])), k = [
	0,
	2,
	5,
	9,
	14,
	20
], ne = {
	cactus: "games.whirlyderby.iconCactus",
	lamp: "games.whirlyderby.iconLamp",
	donut: "games.whirlyderby.iconDonut",
	cheese: "games.whirlyderby.iconCheese",
	jelly: "games.whirlyderby.iconJelly",
	none: "games.whirlyderby.iconNone"
}, A = .2, j = .85, M = .5, N = .7, P = .42, F = 2.55;
function I(e) {
	return P * Math.max(0, e - M);
}
function L(e = 26, t = 72) {
	let n = [], r = [];
	for (let r = 0; r <= e; r++) {
		let i = M + r / e * 2.5, a = I(i);
		for (let e = 0; e < t; e++) {
			let r = e / t * Math.PI * 2;
			n.push(Math.cos(r) * i, a, Math.sin(r) * i);
		}
	}
	for (let n = 0; n < e; n++) for (let e = 0; e < t; e++) {
		let i = n * t + e, a = n * t + (e + 1) % t, o = (n + 1) * t + e, s = (n + 1) * t + (e + 1) % t;
		r.push(i, o, a, a, o, s);
	}
	return {
		positions: new Float32Array(n),
		indices: new Uint32Array(r)
	};
}
function R(e = 72) {
	let t = [], n = [], r = I(3);
	for (let n = 0; n < e; n++) {
		let i = n / e * Math.PI * 2;
		t.push(Math.cos(i) * 3, r, Math.sin(i) * 3);
	}
	for (let n = 0; n < e; n++) {
		let i = n / e * Math.PI * 2;
		t.push(Math.cos(i) * 3, r + N, Math.sin(i) * 3);
	}
	for (let t = 0; t < e; t++) {
		let r = (t + 1) % e, i = t, a = r, o = e + t, s = e + r;
		n.push(i, a, o, a, s, o);
	}
	return {
		positions: new Float32Array(t),
		indices: new Uint32Array(n)
	};
}
function z(e = 26, t = 72) {
	let n = L(e, t), r = R(t), i = new Float32Array(n.positions.length + r.positions.length);
	i.set(n.positions, 0), i.set(r.positions, n.positions.length);
	let a = n.positions.length / 3, o = new Uint32Array(n.indices.length + r.indices.length);
	o.set(n.indices, 0);
	for (let e = 0; e < r.indices.length; e++) o[n.indices.length + e] = r.indices[e] + a;
	return {
		positions: i,
		indices: o
	};
}
//#endregion
//#region src/game/physics.ts
var re = 1 / 120;
6 * re * 1e3;
var B = 1200, V = 3.8, H = .14, U = .25, ie = .1, ae = .4, W = (e) => Math.round(e * 100) / 100;
function oe(n) {
	let r = n.entries.filter((e) => e.count > 0), i = [], a = n.cursor;
	for (let e of r) for (let r = 0; r < e.count; r++) {
		let o = (t(n.seed, a++) - .5) * .05, s = (t(n.seed, a++) - .5) * .06, c = (t(n.seed, a++) - .5) * .08, l = r * 18;
		i.push({
			rid: e.rid,
			kind: "marble",
			index: r,
			spawnStep: l,
			spawnMs: l / 6 * 50,
			angle: e.angle + o + r * .01,
			radius: F + s,
			speed: V * e.power * (1 + c),
			direction: e.direction,
			body: null,
			track: [],
			finished: !1,
			finishStep: null,
			lastX: 0,
			lastZ: 0
		});
	}
	n.thunderball && i.unshift({
		rid: n.thunderball.rid,
		kind: "thunderball",
		index: -1,
		spawnStep: 288,
		spawnMs: 2400,
		angle: n.thunderball.angle,
		radius: F,
		speed: 0,
		direction: 1,
		body: null,
		track: [],
		finished: !1,
		finishStep: null,
		lastX: 0,
		lastZ: 0
	});
	let o = i.filter((e) => e.kind === "marble").length;
	if (o === 0) return {
		marbles: [],
		tracks: [],
		sampleMs: 50,
		endMs: 0,
		order: [],
		stopped: 0,
		cursor: a
	};
	let s = new e.World({
		x: 0,
		y: -9.81,
		z: 0
	});
	s.timestep = re;
	try {
		let t = z();
		s.createCollider(e.ColliderDesc.trimesh(t.positions, t.indices).setFriction(ie).setRestitution(.1));
		let n = (t) => {
			let n = t.kind === "thunderball", r = n ? 0 : Math.cos(t.angle) * t.radius, i = n ? 0 : Math.sin(t.angle) * t.radius, a = n ? Math.sqrt(j * j - M * M) + j + 1.1 : I(t.radius) + A + .08, o = -Math.sin(t.angle) * t.direction, c = Math.cos(t.angle) * t.direction, l = -Math.cos(t.angle), u = -Math.sin(t.angle), d = o + l * H, f = c + u * H, p = Math.hypot(d, f) || 1, m = n ? 0 : t.speed, h = e.RigidBodyDesc.dynamic().setTranslation(r, a, i).setLinvel(d / p * m, 0, f / p * m).setLinearDamping(n ? .5 : U).setAngularDamping(n ? 1.5 : 1.1).setCcdEnabled(!0), g = s.createRigidBody(h), _ = e.ColliderDesc.ball(n ? j : A).setDensity(.9).setFriction(n ? .12 : .2).setRestitution(n ? .05 : ae);
			s.createCollider(_, g), t.body = g, t.lastX = r, t.lastZ = i;
		}, r = 0, c = -1, l = 0, u = 0, d = Math.max(...i.map((e) => e.spawnStep));
		for (let e = 0; e < B; e++) {
			for (let t of i) !t.body && t.spawnStep === e && n(t);
			s.step();
			let t = !1;
			for (let n of i) {
				if (!n.body || n.finished) continue;
				let r = n.body.translation();
				if (n.lastX = r.x, n.lastZ = r.z, n.kind === "marble" && r.y < -.45) {
					n.finished = !0, n.finishStep = e, c = e, l++, t = !0, n.body.setEnabled(!1);
					continue;
				}
				let i = n.body.linvel();
				i.x * i.x + i.y * i.y + i.z * i.z > .0625 && (t = !0);
			}
			if (e % 6 == 0) {
				r++;
				for (let e of i) {
					if (!e.body) continue;
					let t = e.body.translation();
					e.track.push(W(t.x), W(t.y), W(t.z));
				}
			}
			if (u = t ? 0 : u + 1, l === o && e - c >= 12 || e >= d && u >= 120 && e % 6 == 0) break;
		}
		let f = i.map((e) => ({
			rid: e.rid,
			kind: e.kind,
			spawnMs: e.spawnMs
		})), p = i.map((e) => e.track), m = i.filter((e) => e.kind === "marble").map((e) => ({
			rid: e.rid,
			kind: e.kind,
			finished: e.finished,
			finishMs: e.finishStep === null ? null : W((e.finishStep + 1) / 120 * 1e3),
			distance: W(Math.hypot(e.lastX, e.lastZ))
		}));
		m.sort((e, t) => e.finished === t.finished ? e.finished && t.finished ? (e.finishMs ?? 0) - (t.finishMs ?? 0) : e.distance - t.distance : e.finished ? -1 : 1);
		let h = m.filter((e) => !e.finished).length;
		return {
			marbles: f,
			tracks: p,
			sampleMs: 50,
			endMs: W(r * 50),
			order: m,
			stopped: h,
			cursor: a
		};
	} finally {
		s.free();
	}
}
//#endregion
//#region src/game/meta.ts
var G = {
	id: "whirlyderby",
	uuid: "a6b78339-edbb-4d1a-bd0b-e3387ee18743",
	tier: "alpha",
	mechanics: [
		"race",
		"push-your-luck",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.whirlyderby.name",
	descKey: "games.whirlyderby.desc",
	rulesKey: "games.whirlyderby.rules",
	icon: "🌀",
	iconImg: "games/whirlyderby.webp",
	rulesUrl: { en: "https://happypiranha.com/blogs/board-game-rules/how-to-play-whirly-derby-board-gme-rules-instructions" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [5],
	accent: "#e0552f",
	releasedAt: "2026-11-24T03:06:24+08:00",
	search: {
		py: "xuan feng jing su",
		init: "xfjs"
	},
	hotseat: "cover"
}, se = r.enum([
	"cactus",
	"lamp",
	"donut",
	"cheese",
	"jelly",
	"none"
]), K = r.object({
	id: r.string(),
	points: r.number(),
	icon: se
}), q = r.object({ advanced: r.boolean().default(!0) }).default({ advanced: !0 }), ce = r.object({
	count: r.number().int().min(0).max(5),
	direction: r.union([r.literal(1), r.literal(-1)]),
	power: r.number().min(.6).max(1.4),
	thunderball: r.boolean()
}), le = r.discriminatedUnion("type", [
	r.object({ type: r.literal("reload") }),
	r.object({ type: r.literal("commit") }).extend(ce.shape),
	r.object({
		type: r.literal("pick"),
		card: r.string()
	}),
	r.object({
		type: r.literal("tick"),
		now: r.number()
	})
]), ue = r.object({
	rid: r.string(),
	kind: r.enum(["marble", "thunderball"]),
	spawnMs: r.number()
}), de = r.object({
	marbles: r.array(ue),
	tracks: r.array(r.array(r.number())),
	sampleMs: r.number(),
	endMs: r.number()
}), fe = r.object({
	rid: r.string(),
	finished: r.boolean()
}), pe = r.object({
	order: r.array(fe),
	thunderballDraw: r.object({
		owner: r.string(),
		stopped: r.number(),
		cards: r.array(K)
	}).nullable(),
	lastPlace: r.object({ rid: r.string() }).nullable()
}), me = r.object({
	rid: r.string(),
	seat: r.number(),
	paddock: r.number(),
	box: r.number(),
	reloads: r.number(),
	score: r.number(),
	cards: r.array(K),
	submitted: r.boolean()
}), he = r.object({
	phase: r.enum([
		"select",
		"race",
		"pick",
		"ended"
	]),
	round: r.number(),
	advanced: r.boolean(),
	players: r.array(me),
	prize: r.array(K),
	deckCount: r.number(),
	thunderball: r.object({
		owner: r.string(),
		available: r.boolean()
	}).nullable(),
	race: de.nullable(),
	result: pe.nullable(),
	picks: r.object({
		order: r.array(r.string()),
		index: r.number()
	}).nullable(),
	raceoff: r.object({
		players: r.array(r.string()),
		winner: r.string()
	}).nullable()
}), ge = r.object({
	selection: ce.nullable(),
	canReload: r.boolean(),
	paddock: r.number(),
	thunderballHeld: r.boolean()
}), J = (e) => ({ code: e }), Y = (e) => O[e] ?? {
	id: e,
	points: 0,
	icon: "none"
};
function _e(e, t, r) {
	let i = r;
	for (let r = e.length - 1; r > 0; r--) {
		let a = n(t, i++, r + 1);
		[e[r], e[a]] = [e[a], e[r]];
	}
	return {
		items: e,
		cursor: i
	};
}
function ve(e) {
	return Object.fromEntries(e.order.map((e) => [e, null]));
}
function ye(e, t) {
	let n = {
		cactus: 0,
		lamp: 0,
		donut: 0,
		cheese: 0,
		jelly: 0
	};
	for (let r of e.players[t].cards) {
		let e = Y(r).icon;
		e !== "none" && (n[e] += 1);
	}
	return n;
}
function X(e) {
	let t = {}, n = {};
	for (let r of e.order) {
		let i = e.players[r].cards.map(Y).reduce((e, t) => e + t.points, 0), a = ye(e, r);
		n[r] = a, e.advanced && (i += k[Math.min(a.lamp, k.length - 1)], a.donut > 0 && a.cheese > 0 && a.jelly > 0 && (i += 30)), t[r] = i;
	}
	if (e.advanced) {
		let r = Math.max(0, ...e.order.map((e) => n[e].cactus));
		if (r > 0) for (let i of e.order) n[i].cactus === r && (t[i] += 15);
	}
	return t;
}
function be(e, t) {
	return e.players[t].seat / e.order.length * Math.PI * 2;
}
function xe(e) {
	let t = X(e), n = null, r = Infinity, i = Infinity;
	for (let a of e.order) {
		let o = e.players[a], s = o.paddock + o.box;
		(t[a] < r || t[a] === r && s < i) && (n = a, r = t[a], i = s);
	}
	n && (e.thunderball = {
		owner: n,
		available: !0
	});
}
function Se(e) {
	e.phase = "select", e.selections = ve(e), e.picks = null, e.race = null, e.result = null, e.raceMs = 0;
	for (let t of e.order) {
		let n = e.players[t];
		n.paddock === 0 && (n.box === 0 || n.reloads === 0) && (e.selections[t] = {
			count: 0,
			direction: 1,
			power: 1,
			thunderball: !1
		});
	}
	e.advanced && e.tokens[e.round - 1] === "thunderball" && xe(e), Ee(e);
}
function Ce(e) {
	let t = X(e), n = Math.max(...e.order.map((e) => t[e])), r = e.order.filter((e) => t[e] === n), i;
	if (r.length > 1) {
		let n = oe({
			entries: r.map((t, n) => ({
				rid: t,
				count: 1,
				direction: n % 2 == 0 ? 1 : -1,
				power: 1,
				angle: be(e, t)
			})),
			thunderball: null,
			seed: e.seed,
			cursor: e.cursor
		});
		e.cursor = n.cursor;
		let a = new Map(n.order.map((e, t) => [e.rid, t])), o = [...r].sort((e, t) => (a.get(e) ?? 99) - (a.get(t) ?? 99));
		i = [...o, ...e.order.filter((e) => !r.includes(e)).sort((n, r) => t[r] - t[n] || e.players[n].seat - e.players[r].seat)], e.raceoff = {
			players: r,
			winner: o[0]
		}, e.final = {
			scores: t,
			ranking: i,
			winner: [o[0]]
		};
	} else i = [...e.order].sort((n, r) => t[r] - t[n] || e.players[n].seat - e.players[r].seat), e.raceoff = null, e.final = {
		scores: t,
		ranking: i,
		winner: r
	};
	e.phase = "ended", e.picks = null;
}
function we(e) {
	if (e.picks = null, e.race = null, e.result = null, e.raceMs = 0, e.round >= 8) {
		Ce(e);
		return;
	}
	e.round += 1, e.prize = e.deck.splice(0, 3), Se(e);
}
function Te(e) {
	let t = e.order.length, n = [];
	for (let r of e.order) {
		let i = e.selections[r];
		i && i.count !== 0 && n.push({
			rid: r,
			count: i.count,
			direction: i.direction,
			power: i.power,
			angle: e.players[r].seat / t * Math.PI * 2
		});
	}
	let r = e.order.find((t) => e.selections[t]?.thunderball) ?? null, i = r !== null && e.thunderball !== null && e.thunderball.owner === r && e.thunderball.available ? {
		rid: r,
		angle: be(e, r) + .9
	} : null;
	for (let t of e.order) {
		let n = e.selections[t];
		n && n.count !== 0 && (e.players[t].paddock -= n.count, e.players[t].box += n.count);
	}
	if (n.length === 0) {
		e.selections = ve(e), i && (e.thunderball = null), we(e);
		return;
	}
	let a = oe({
		entries: n,
		thunderball: i,
		seed: e.seed,
		cursor: e.cursor
	});
	e.cursor = a.cursor, e.race = {
		marbles: a.marbles,
		tracks: a.tracks,
		sampleMs: a.sampleMs,
		endMs: a.endMs
	};
	let o = a.order.map((e) => ({
		rid: e.rid,
		finished: e.finished
	})), s = null;
	if (i) {
		let t = Math.min(3, a.stopped), n = t > 0 ? e.deck.splice(0, t) : [];
		n.length > 0 && e.players[i.rid].cards.push(...n), s = {
			owner: i.rid,
			stopped: a.stopped,
			cards: n
		}, e.thunderball = null;
	}
	let c = null;
	if (!i && o.length > 0) {
		let t = o[o.length - 1], n = e.players[t.rid];
		n.box > 0 && (--n.box, n.paddock += 1), c = { rid: t.rid };
	}
	let l = i ? o.filter((e) => e.finished).slice(0, 3).map((e) => e.rid) : o.slice(0, 3).map((e) => e.rid);
	e.result = {
		order: o,
		thunderballDraw: s,
		lastPlace: c
	}, e.picks = l.length > 0 ? {
		order: l,
		index: 0
	} : null, e.phase = "race", e.raceMs = Math.round(a.endMs + 1400), e.selections = ve(e);
}
function Ee(e) {
	e.phase === "select" && e.order.every((t) => e.selections[t] !== null) && Te(e);
}
function De(e, t, n) {
	let r = e;
	if (t.type === "tick") return n.by !== "$engine" || r.phase !== "race" ? J("games.whirlyderby.err.phase") : (r.picks && r.picks.index < r.picks.order.length ? r.phase = "pick" : we(r), { state: r });
	if (!r.order.includes(n.by)) return J("games.whirlyderby.err.notPlayer");
	if (t.type === "reload") {
		if (r.phase !== "select") return J("games.whirlyderby.err.phase");
		if (r.selections[n.by] !== null) return J("games.whirlyderby.err.committed");
		let e = r.players[n.by];
		return e.reloads <= 0 ? J("games.whirlyderby.err.noReload") : e.box <= 0 ? J("games.whirlyderby.err.emptyBox") : (e.paddock += e.box, e.box = 0, --e.reloads, { state: r });
	}
	if (t.type === "commit") {
		if (r.phase !== "select") return J("games.whirlyderby.err.phase");
		if (r.selections[n.by] !== null) return J("games.whirlyderby.err.committed");
		let e = r.players[n.by];
		if (t.count > e.paddock) return J("games.whirlyderby.err.tooMany");
		if (e.paddock > 0 && t.count < 1) return J("games.whirlyderby.err.mustEnter");
		if (e.paddock === 0 && t.count !== 0) return J("games.whirlyderby.err.noMarbles");
		let i = t.thunderball && r.advanced;
		if (i) {
			if (t.count < 1) return J("games.whirlyderby.err.thunderNeedsMarble");
			if (!r.thunderball || r.thunderball.owner !== n.by || !r.thunderball.available) return J("games.whirlyderby.err.noThunderball");
		}
		return r.selections[n.by] = {
			count: t.count,
			direction: t.direction,
			power: t.power,
			thunderball: i
		}, Ee(r), { state: r };
	}
	return t.type === "pick" ? r.phase !== "pick" || !r.picks ? J("games.whirlyderby.err.phase") : r.picks.order[r.picks.index] === n.by ? r.prize.includes(t.card) ? (r.players[n.by].cards.push(t.card), r.prize = r.prize.filter((e) => e !== t.card), r.picks.index += 1, r.picks.index >= r.picks.order.length && we(r), { state: r }) : J("games.whirlyderby.err.badPick") : J("games.whirlyderby.err.notTurn") : J("games.whirlyderby.err.phase");
}
var Oe = {
	meta: G,
	saveCompatibility: {
		version: "2",
		migrate: () => null
	},
	schemas: {
		action: le,
		publicView: he,
		privateView: ge,
		config: q
	},
	setup(e, t, n) {
		let r = q.parse(e ?? {}), i = [...t], a = 0, o = _e(D.map((e) => e.id), n, a);
		a = o.cursor;
		let s = ["standard", "standard"];
		if (r.advanced) {
			let e = _e([
				"standard",
				"standard",
				"standard",
				"standard",
				"thunderball",
				"thunderball"
			], n, a);
			a = e.cursor, s.push(...e.items);
		} else for (let e = 0; e < 6; e++) s.push("standard");
		let c = {
			phase: "select",
			order: i,
			round: 1,
			advanced: r.advanced,
			seed: n,
			cursor: a,
			deck: o.items,
			prize: o.items.splice(0, 3),
			tokens: s,
			players: Object.fromEntries(i.map((e, t) => [e, {
				seat: t,
				paddock: 5,
				box: 0,
				reloads: 2,
				cards: []
			}])),
			selections: {},
			thunderball: null,
			race: null,
			result: null,
			picks: null,
			raceMs: 0,
			raceoff: null,
			final: null
		};
		return Se(c), Ee(c), { state: c };
	},
	reduce: De,
	viewFor(e, t) {
		let n = X(e);
		return {
			public: {
				phase: e.phase,
				round: e.round,
				advanced: e.advanced,
				players: e.order.map((t) => ({
					rid: t,
					seat: e.players[t].seat,
					paddock: e.players[t].paddock,
					box: e.players[t].box,
					reloads: e.players[t].reloads,
					score: n[t],
					cards: e.players[t].cards.map(Y),
					submitted: e.selections[t] !== null
				})),
				prize: e.prize.map(Y),
				deckCount: e.deck.length,
				thunderball: e.thunderball ? {
					owner: e.thunderball.owner,
					available: e.thunderball.available
				} : null,
				race: e.race,
				result: e.result ? {
					order: e.result.order,
					thunderballDraw: e.result.thunderballDraw ? {
						owner: e.result.thunderballDraw.owner,
						stopped: e.result.thunderballDraw.stopped,
						cards: e.result.thunderballDraw.cards.map(Y)
					} : null,
					lastPlace: e.result.lastPlace
				} : null,
				picks: e.picks,
				raceoff: e.raceoff
			},
			private: {
				selection: e.selections[t] ?? null,
				canReload: e.phase === "select" && e.selections[t] === null && e.players[t] !== void 0 && e.players[t].reloads > 0 && e.players[t].box > 0,
				paddock: e.players[t]?.paddock ?? 0,
				thunderballHeld: e.thunderball !== null && e.thunderball.owner === t && e.thunderball.available
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	},
	nextTickIn(e) {
		return e.phase === "race" ? e.raceMs : null;
	}
}, ke = 40, Z = -.72, Q = I(3), Ae = .64, je = 2.4;
function Me() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function Ne(e, t) {
	let n = new v.BufferGeometry();
	n.setAttribute("position", new v.BufferAttribute(e.positions, 3)), n.setIndex(new v.BufferAttribute(e.indices, 1));
	let r = e.positions.length / 3, i = new Float32Array(r * 2), a = Infinity, o = -Infinity;
	for (let t = 0; t < r; t++) {
		let n = e.positions[t * 3 + 1];
		n < a && (a = n), n > o && (o = n);
	}
	let s = o - a || 1;
	for (let n = 0; n < r; n++) {
		let r = e.positions[n * 3], o = e.positions[n * 3 + 1], c = e.positions[n * 3 + 2];
		t === "surface" ? (i[n * 2] = r / 6 + .5, i[n * 2 + 1] = c / 6 + .5) : (i[n * 2] = (Math.atan2(c, r) + Math.PI) / (Math.PI * 2), i[n * 2 + 1] = (o - a) / s);
	}
	return n.setAttribute("uv", new v.BufferAttribute(i, 2)), n.computeVertexNormals(), n;
}
function Pe(e) {
	let t = e >>> 0;
	return () => (t = t * 1664525 + 1013904223 >>> 0, t / 4294967296);
}
function $(e, t, n) {
	let r = document.createElement("canvas");
	r.width = e, r.height = t;
	let i = r.getContext("2d");
	if (!i) return null;
	n(i);
	let a = new v.CanvasTexture(r);
	return a.colorSpace = v.SRGBColorSpace, a.anisotropy = 4, a;
}
function Fe() {
	return $(512, 512, (e) => {
		let t = Pe(6221057), n = e.createRadialGradient(256, 256, 24, 256, 256, 356);
		n.addColorStop(0, "#2a6662"), n.addColorStop(.55, "#1c5252"), n.addColorStop(1, "#0e3537"), e.fillStyle = n, e.fillRect(0, 0, 512, 512), e.lineWidth = 1;
		for (let t = 0; t < 512; t += 4) e.strokeStyle = t % 8 == 0 ? "rgba(190, 233, 216, 0.035)" : "rgba(4, 26, 27, 0.045)", e.beginPath(), e.moveTo(0, t + .5), e.lineTo(512, t + .5), e.stroke(), e.strokeStyle = "rgba(4, 26, 27, 0.03)", e.beginPath(), e.moveTo(t + .5, 0), e.lineTo(t + .5, 512), e.stroke();
		for (let n = 0; n < 1600; n++) e.fillStyle = t() > .5 ? "rgba(217, 244, 228, 0.05)" : "rgba(2, 18, 19, 0.06)", e.beginPath(), e.arc(t() * 512, t() * 512, .5 + t() * 1.6, 0, Math.PI * 2), e.fill();
	});
}
function Ie() {
	return $(512, 512, (e) => {
		let t = Pe(11575792), n = e.createRadialGradient(256, 256, 26, 256, 256, 332);
		n.addColorStop(0, "#ff9560"), n.addColorStop(.4, "#f06633"), n.addColorStop(.78, "#d9471f"), n.addColorStop(1, "#a92f15"), e.fillStyle = n, e.fillRect(0, 0, 512, 512);
		for (let n = 0; n < 150; n++) {
			let n = 40 + t() * 250, r = t() * Math.PI * 2, i = .25 + t() * 1.1;
			e.strokeStyle = t() > .5 ? `rgba(255, 210, 160, ${.04 + t() * .08})` : `rgba(94, 24, 6, ${.03 + t() * .06})`, e.lineWidth = 1 + t() * 5, e.beginPath(), e.arc(256, 256, n, r, r + i), e.stroke();
		}
		for (let t = 64; t < 324; t += 26) e.lineWidth = 2, e.strokeStyle = "rgba(80, 20, 5, 0.1)", e.beginPath(), e.arc(256, 256, t, 0, Math.PI * 2), e.stroke(), e.strokeStyle = "rgba(255, 205, 150, 0.08)", e.beginPath(), e.arc(256, 256, t + 2, 0, Math.PI * 2), e.stroke();
		for (let n = 0; n < 700; n++) e.fillStyle = t() > .5 ? "rgba(255, 225, 190, 0.05)" : "rgba(88, 22, 6, 0.05)", e.beginPath(), e.arc(t() * 512, t() * 512, .4 + t() * 1.2, 0, Math.PI * 2), e.fill();
	});
}
function Le() {
	return $(512, 256, (e) => {
		let t = e.createLinearGradient(0, 0, 0, 256);
		t.addColorStop(0, "#70cae2"), t.addColorStop(.5, "#3a97ba"), t.addColorStop(1, "#226c89"), e.fillStyle = t, e.fillRect(0, 0, 512, 256);
		for (let t = 0; t < 512; t += 64) e.fillStyle = "rgba(9, 48, 60, 0.14)", e.fillRect(t, 0, 3, 256), e.fillStyle = "rgba(214, 245, 255, 0.1)", e.fillRect(t + 3, 0, 2, 256);
		for (let t = 0; t < 256; t += 3) e.fillStyle = t % 6 == 0 ? "rgba(255, 255, 255, 0.03)" : "rgba(6, 40, 52, 0.03)", e.fillRect(0, t, 512, 1);
		for (let t = 32; t < 512; t += 64) for (let n of [18, 238]) e.fillStyle = "rgba(8, 42, 54, 0.35)", e.beginPath(), e.arc(t, n, 3.2, 0, Math.PI * 2), e.fill(), e.fillStyle = "rgba(222, 250, 255, 0.35)", e.beginPath(), e.arc(t - 1, n - 1, 1.4, 0, Math.PI * 2), e.fill();
	});
}
function Re() {
	return $(512, 512, (e) => {
		let t = e.createRadialGradient(256, 180, 30, 256, 260, 420);
		t.addColorStop(0, "#ffe9c4"), t.addColorStop(.45, "#e5c99b"), t.addColorStop(.75, "#a9845c"), t.addColorStop(1, "#4c3826"), e.fillStyle = t, e.fillRect(0, 0, 512, 512), e.globalAlpha = .05, e.fillStyle = "#fff4de";
		for (let t = -6; t < 7; t++) e.beginPath(), e.moveTo(256, 120), e.lineTo(256 + t * 54 - 12, 512), e.lineTo(256 + t * 54 + 12, 512), e.closePath(), e.fill();
		e.globalAlpha = 1;
	});
}
function ze(e, t, n) {
	let r = Math.floor(e.length / 3);
	if (r === 0) return null;
	let i = Math.max(0, t / n), a = Math.min(r - 1, Math.floor(i)), o = Math.min(r - 1, a + 1), s = Math.min(1, Math.max(0, i - a));
	return [
		e[a * 3] + (e[o * 3] - e[a * 3]) * s,
		e[a * 3 + 1] + (e[o * 3 + 1] - e[a * 3 + 1]) * s,
		e[a * 3 + 2] + (e[o * 3 + 2] - e[a * 3 + 2]) * s
	];
}
function Be() {
	let e = a(() => Ne(L(), "surface"), []), t = a(() => Ne(R(), "wall"), []), n = a(() => Ie(), []), r = a(() => Le(), []);
	i(() => () => {
		e.dispose(), t.dispose(), n?.dispose(), r?.dispose();
	}, [
		e,
		t,
		n,
		r
	]);
	let o = a(() => [
		1.4,
		2.15,
		2.85
	], []);
	return /* @__PURE__ */ x("group", { children: [
		/* @__PURE__ */ b("mesh", {
			geometry: e,
			receiveShadow: !0,
			children: /* @__PURE__ */ b("meshStandardMaterial", {
				map: n,
				color: "#ffffff",
				roughness: .46,
				metalness: .05,
				side: v.DoubleSide
			})
		}),
		/* @__PURE__ */ b("mesh", {
			geometry: t,
			castShadow: !0,
			receiveShadow: !0,
			children: /* @__PURE__ */ b("meshStandardMaterial", {
				map: r,
				color: "#ffffff",
				roughness: .5,
				metalness: .08,
				side: v.DoubleSide
			})
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				Q + N,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			castShadow: !0,
			children: [/* @__PURE__ */ b("torusGeometry", { args: [
				3,
				.06,
				10,
				96
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#f7e5c2",
				roughness: .38,
				metalness: .12
			})]
		}),
		o.map((e) => /* @__PURE__ */ x("mesh", {
			position: [
				0,
				I(e) + .012,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("torusGeometry", { args: [
				e,
				.011,
				6,
				96
			] }), /* @__PURE__ */ b("meshBasicMaterial", {
				color: "#ffd0a0",
				transparent: !0,
				opacity: .45
			})]
		}, e)),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				-.24,
				0
			],
			children: [/* @__PURE__ */ b("cylinderGeometry", { args: [
				M,
				M * .8,
				.48,
				48,
				1,
				!0
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#131b20",
				roughness: .9,
				side: v.DoubleSide
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.006,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("circleGeometry", { args: [M, 48] }), /* @__PURE__ */ b("meshBasicMaterial", { color: "#080e11" })]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				.02,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("torusGeometry", { args: [
				M,
				.025,
				8,
				64
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#ffcf7a",
				roughness: .3,
				metalness: .65,
				emissive: "#4a2c00",
				emissiveIntensity: .3
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				(Q + Z) / 2,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: [/* @__PURE__ */ b("cylinderGeometry", { args: [
				3.02,
				3.02,
				Q - Z,
				72,
				1,
				!0
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#b73d22",
				roughness: .65,
				side: v.DoubleSide
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				-.63,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: [/* @__PURE__ */ b("cylinderGeometry", { args: [
				3.24,
				3.12,
				.18,
				72
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#a2381f",
				roughness: .7
			})]
		})
	] });
}
function Ve() {
	let e = a(() => Fe(), []);
	return i(() => () => e?.dispose(), [e]), /* @__PURE__ */ x("group", { children: [
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				Z,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			receiveShadow: !0,
			children: [/* @__PURE__ */ b("circleGeometry", { args: [7.2, 96] }), /* @__PURE__ */ b("meshStandardMaterial", {
				map: e,
				color: "#ffffff",
				roughness: .94
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				-.715,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("ringGeometry", { args: [
				4.55,
				4.7,
				96
			] }), /* @__PURE__ */ b("meshBasicMaterial", {
				color: "#e7d3b0",
				transparent: !0,
				opacity: .42
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				-.715,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("ringGeometry", { args: [
				6.6,
				6.78,
				96
			] }), /* @__PURE__ */ b("meshBasicMaterial", {
				color: "#e7d3b0",
				transparent: !0,
				opacity: .3
			})]
		}),
		/* @__PURE__ */ x("mesh", {
			position: [
				0,
				-.76,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ b("circleGeometry", { args: [7.35, 96] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: "#0c2a2b",
				roughness: .95
			})]
		})
	] });
}
function He({ player: e, seatCount: t, color: n }) {
	let r = e.seat / t * Math.PI * 2, i = Math.cos(r) * 3.95, a = Math.sin(r) * 3.95, o = Array.from({ length: Math.min(e.paddock, 5) }, (e, t) => t), s = Array.from({ length: Math.min(e.reloads, 2) }, (e, t) => t);
	return /* @__PURE__ */ x("group", {
		position: [
			i,
			Z,
			a
		],
		children: [
			/* @__PURE__ */ x("mesh", {
				position: [
					0,
					.055,
					0
				],
				castShadow: !0,
				receiveShadow: !0,
				children: [/* @__PURE__ */ b("cylinderGeometry", { args: [
					.62,
					.66,
					.11,
					36
				] }), /* @__PURE__ */ b("meshStandardMaterial", {
					color: n,
					roughness: .48,
					metalness: .05
				})]
			}),
			/* @__PURE__ */ x("mesh", {
				position: [
					0,
					.113,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ b("ringGeometry", { args: [
					.5,
					.6,
					36
				] }), /* @__PURE__ */ b("meshBasicMaterial", {
					color: "#f6e7cd",
					transparent: !0,
					opacity: .8
				})]
			}),
			/* @__PURE__ */ b("group", {
				position: [
					0,
					.13,
					0
				],
				children: o.map((e) => {
					let t = e % 3, r = Math.floor(e / 3);
					return /* @__PURE__ */ x("mesh", {
						position: [
							(t - 1) * .34,
							A * .9 + r * .29,
							-.1 + r * .02
						],
						castShadow: !0,
						children: [/* @__PURE__ */ b("sphereGeometry", { args: [
							A,
							18,
							14
						] }), /* @__PURE__ */ b("meshPhysicalMaterial", {
							color: n,
							roughness: .2,
							metalness: .04,
							clearcoat: 1,
							clearcoatRoughness: .1
						})]
					}, e);
				})
			}),
			s.map((e, t) => /* @__PURE__ */ x("mesh", {
				position: [
					.42 - t * .22,
					.13,
					.42
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				castShadow: !0,
				children: [/* @__PURE__ */ b("cylinderGeometry", { args: [
					.1,
					.1,
					.035,
					20
				] }), /* @__PURE__ */ b("meshStandardMaterial", {
					color: "#f6e7cd",
					roughness: .45
				})]
			}, `r${e}`))
		]
	});
}
function Ue({ player: e, seatCount: t, selection: n, color: r }) {
	let i = e.seat / t * Math.PI * 2, a = 3.06, o = n.direction === 1 ? 1 : -1;
	return /* @__PURE__ */ x("group", {
		position: [
			Math.cos(i) * a,
			Q + N + .24,
			Math.sin(i) * a
		],
		rotation: [
			0,
			-(i + o * Math.PI / 2),
			0
		],
		children: [/* @__PURE__ */ x("mesh", {
			position: [
				.2 + n.power * .12,
				0,
				0
			],
			castShadow: !0,
			children: [/* @__PURE__ */ b("boxGeometry", { args: [
				.42 + n.power * .26,
				.06,
				.14
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: r,
				roughness: .38,
				metalness: .08,
				emissive: r,
				emissiveIntensity: .18
			})]
		}), /* @__PURE__ */ x("mesh", {
			position: [
				.47 + n.power * .25,
				0,
				0
			],
			rotation: [
				0,
				0,
				-Math.PI / 2
			],
			castShadow: !0,
			children: [/* @__PURE__ */ b("coneGeometry", { args: [
				.13,
				.26,
				14
			] }), /* @__PURE__ */ b("meshStandardMaterial", {
				color: r,
				roughness: .38,
				metalness: .08
			})]
		})]
	});
}
function We({ race: e, phase: t, reducedMotion: n, colorOf: r }) {
	let a = o([]), s = o(null), c = `${e.marbles.length}:${e.endMs}:${e.tracks.length}`;
	return i(() => {
		s.current = null;
	}, [c]), g(() => {
		s.current === null && (s.current = performance.now());
		let r = t === "pick" || n ? e.endMs : performance.now() - s.current;
		e.marbles.forEach((t, n) => {
			let i = a.current[n];
			if (!i) return;
			if (!t || r < t.spawnMs) {
				i.visible = !1;
				return;
			}
			let o = ze(e.tracks[n] ?? [], r - t.spawnMs, e.sampleMs);
			if (!o || o[1] < -.3) {
				i.visible = !1;
				return;
			}
			i.visible = !0, i.position.set(o[0], o[1], o[2]);
		});
	}), /* @__PURE__ */ b(y, { children: e.marbles.map((e, t) => /* @__PURE__ */ b("group", {
		ref: (e) => {
			a.current[t] = e;
		},
		visible: !1,
		children: e.kind === "thunderball" ? /* @__PURE__ */ x("group", { children: [
			/* @__PURE__ */ x("mesh", {
				castShadow: !0,
				children: [/* @__PURE__ */ b("sphereGeometry", { args: [
					j,
					32,
					24
				] }), /* @__PURE__ */ b("meshStandardMaterial", {
					color: "#333b45",
					roughness: .34,
					metalness: .45
				})]
			}),
			/* @__PURE__ */ x("mesh", {
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ b("torusGeometry", { args: [
					j * .93,
					.09,
					10,
					48
				] }), /* @__PURE__ */ b("meshStandardMaterial", {
					color: "#ffc23d",
					roughness: .35,
					metalness: .4,
					emissive: "#9a6400",
					emissiveIntensity: .4
				})]
			}),
			/* @__PURE__ */ x("mesh", {
				position: [
					0,
					j * .72,
					0
				],
				children: [/* @__PURE__ */ b("sphereGeometry", { args: [
					j * .32,
					18,
					14
				] }), /* @__PURE__ */ b("meshStandardMaterial", {
					color: "#4a5361",
					roughness: .4,
					metalness: .3
				})]
			})
		] }) : /* @__PURE__ */ x("mesh", {
			castShadow: !0,
			children: [/* @__PURE__ */ b("sphereGeometry", { args: [
				A,
				22,
				16
			] }), /* @__PURE__ */ b("meshPhysicalMaterial", {
				color: r(e.rid),
				roughness: .18,
				metalness: .04,
				clearcoat: 1,
				clearcoatRoughness: .08
			})]
		})
	}, `${e.rid}:${t}`)) });
}
function Ge({ active: e }) {
	let t = _((e) => e.invalidate);
	return i(() => {
		if (!e) return;
		let n = 0, r = 0, i = (e) => {
			document.visibilityState === "visible" && e - r >= 33 && (t(), r = e), n = requestAnimationFrame(i);
		};
		return n = requestAnimationFrame(i), () => cancelAnimationFrame(n);
	}, [e, t]), null;
}
function Ke({ pan: e, resetKey: t }) {
	let n = _((e) => e.size), r = o(new v.Vector3(0, .45, 0)), i = o(new v.Vector3()), a = o(new v.Vector3()), s = o(!1), c = o(t);
	return g(({ camera: o }, l) => {
		c.current !== t && (c.current = t, s.current = !1);
		let u = Math.tan(ke * Math.PI / 360), d = Math.max(.35, n.width / Math.max(1, n.height)), f = 3.55 / u, p = 4.55 / (u * d), m = Math.max(f, p) * e.current.zoom;
		if (i.current.set(e.current.x, .45, e.current.z), a.current.set(i.current.x, i.current.y + Math.sin(Ae) * m, i.current.z + Math.cos(Ae) * m), !s.current) o.position.copy(a.current), r.current.copy(i.current), s.current = !0;
		else {
			let e = 1 - Math.exp(-l * 14);
			o.position.lerp(a.current, e), r.current.lerp(i.current, e);
		}
		o.lookAt(r.current);
	}), null;
}
function qe({ pub: e, myRid: t, members: n, selection: r }) {
	let c = l(), u = te(), [f, p] = s(0), m = o({
		x: 0,
		z: 0,
		zoom: 1
	}), h = o(/* @__PURE__ */ new Map()), g = o(null), _ = o(() => {}), y = a(() => Re(), []);
	i(() => () => y?.dispose(), [y]);
	let S = (e) => {
		let t = n.find((t) => t.rid === e);
		return d[(t?.colorIndex ?? 0) % d.length].hex;
	}, C = e.players.find((e) => e.rid === t), w = e.race, T = e.players.length;
	return /* @__PURE__ */ x("div", {
		className: "wd-scene",
		children: [
			/* @__PURE__ */ x(ee, {
				className: "wd-canvas",
				shadows: !0,
				gl: {
					antialias: !0,
					powerPreference: "low-power"
				},
				dpr: [1, 2],
				frameloop: "demand",
				camera: {
					fov: ke,
					near: .1,
					far: 120
				},
				onCreated: ({ gl: e, invalidate: t }) => {
					_.current = t, e.outputColorSpace = v.SRGBColorSpace, e.toneMapping = v.ACESFilmicToneMapping, e.toneMappingExposure = 1.06, e.shadowMap.type = v.PCFSoftShadowMap;
				},
				children: [
					y ? /* @__PURE__ */ b("primitive", {
						attach: "background",
						object: y
					}) : /* @__PURE__ */ b("color", {
						attach: "background",
						args: ["#d8bd92"]
					}),
					/* @__PURE__ */ b("hemisphereLight", { args: [
						"#ffeccb",
						"#0d3436",
						1.15
					] }),
					/* @__PURE__ */ b("ambientLight", { intensity: .26 }),
					/* @__PURE__ */ b("directionalLight", {
						castShadow: !0,
						color: "#ffe2b4",
						intensity: 2.5,
						position: [
							-6,
							13,
							9
						],
						"shadow-mapSize-width": 1024,
						"shadow-mapSize-height": 1024,
						"shadow-camera-left": -8,
						"shadow-camera-right": 8,
						"shadow-camera-top": 8,
						"shadow-camera-bottom": -8,
						"shadow-camera-near": 1,
						"shadow-camera-far": 40,
						"shadow-bias": -4e-4,
						"shadow-normalBias": .02
					}),
					/* @__PURE__ */ b("directionalLight", {
						color: "#9edcf0",
						intensity: .8,
						position: [
							9,
							7,
							-10
						]
					}),
					/* @__PURE__ */ b("directionalLight", {
						color: "#ffb27c",
						intensity: .5,
						position: [
							0,
							5,
							-12
						]
					}),
					/* @__PURE__ */ b("pointLight", {
						color: "#ffcf7a",
						intensity: 1.5,
						distance: 3.2,
						decay: 2,
						position: [
							0,
							.9,
							0
						]
					}),
					/* @__PURE__ */ b(Ge, { active: e.phase === "race" && !u }),
					/* @__PURE__ */ b(Ke, {
						pan: m,
						resetKey: f
					}),
					/* @__PURE__ */ b(Ve, {}),
					/* @__PURE__ */ b(Be, {}),
					e.players.map((e) => /* @__PURE__ */ b(He, {
						player: e,
						seatCount: T,
						color: S(e.rid)
					}, e.rid)),
					e.thunderball && (() => {
						let t = e.players.find((t) => t.rid === e.thunderball?.owner);
						if (!t) return null;
						let n = t.seat / T * Math.PI * 2;
						return /* @__PURE__ */ x("mesh", {
							position: [
								Math.cos(n) * 3.95,
								-.52,
								Math.sin(n) * 3.95
							],
							rotation: [
								-Math.PI / 2,
								0,
								0
							],
							children: [/* @__PURE__ */ b("torusGeometry", { args: [
								.52,
								.035,
								8,
								40
							] }), /* @__PURE__ */ b("meshStandardMaterial", {
								color: "#ffc23d",
								roughness: .4,
								emissive: "#7a5200",
								emissiveIntensity: .3
							})]
						});
					})(),
					w && /* @__PURE__ */ b(We, {
						race: w,
						phase: e.phase,
						reducedMotion: u,
						colorOf: S
					}),
					C && r && e.phase === "select" && r.count > 0 && /* @__PURE__ */ b(Ue, {
						player: C,
						seatCount: T,
						selection: r,
						color: S(C.rid)
					})
				]
			}),
			/* @__PURE__ */ b("div", {
				className: "wd-pan",
				"aria-label": c("games.whirlyderby.ui.tapHint"),
				onPointerDown: (e) => {
					if (h.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), h.current.size === 2) {
						let [e, t] = [...h.current.values()];
						g.current = Math.hypot(e.x - t.x, e.y - t.y);
					}
					e.currentTarget.setPointerCapture(e.pointerId);
				},
				onPointerMove: (e) => {
					let t = h.current.get(e.pointerId);
					if (!t) return;
					let n = e.clientX - t.x, r = e.clientY - t.y;
					if (h.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), h.current.size >= 2) {
						let [e, t] = [...h.current.values()], n = Math.hypot(e.x - t.x, e.y - t.y);
						g.current && n > 0 && (m.current.zoom = Math.max(.62, Math.min(2.4, m.current.zoom * g.current / n))), g.current = n;
					} else {
						let e = .011 * m.current.zoom;
						m.current.x = Math.max(-2.4, Math.min(je, m.current.x - n * e)), m.current.z = Math.max(-2.4, Math.min(je, m.current.z - r * e * Math.sin(Ae)));
					}
					_.current();
				},
				onPointerUp: (e) => {
					h.current.delete(e.pointerId), g.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
				},
				onPointerCancel: (e) => {
					h.current.delete(e.pointerId), g.current = null;
				},
				onLostPointerCapture: (e) => {
					h.current.delete(e.pointerId), g.current = null;
				},
				onWheel: (e) => {
					e.preventDefault(), m.current.zoom = Math.max(.62, Math.min(2.4, m.current.zoom * Math.exp(e.deltaY * .001))), _.current();
				}
			}),
			/* @__PURE__ */ b("button", {
				type: "button",
				className: "wd-recenter",
				"aria-label": c("games.whirlyderby.ui.recenter"),
				title: c("games.whirlyderby.ui.recenter"),
				onClick: () => {
					m.current.x = 0, m.current.z = 0, m.current.zoom = 1, p((e) => e + 1);
				},
				children: /* @__PURE__ */ x("svg", {
					width: "20",
					height: "20",
					viewBox: "0 0 24 24",
					"aria-hidden": !0,
					children: [
						/* @__PURE__ */ b("circle", {
							cx: "12",
							cy: "12",
							r: "7",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ b("circle", {
							cx: "12",
							cy: "12",
							r: "2.2",
							fill: "currentColor"
						}),
						/* @__PURE__ */ b("path", {
							d: "M12 2v3M12 19v3M2 12h3M19 12h3",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round"
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/trophy-icon.tsx
function Je({ icon: e, size: t = 28 }) {
	let n = {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": !0
	};
	switch (e) {
		case "cactus": return /* @__PURE__ */ x("svg", {
			...n,
			children: [
				/* @__PURE__ */ b("path", {
					d: "M13 27h6V12c0-2.2-.9-3.5-3-3.5S13 9.8 13 12z",
					fill: "#3f8f4b",
					stroke: "#173d1f",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M13 17H9.5c-1.6 0-2.5-1-2.5-2.6V12",
					fill: "none",
					stroke: "#173d1f",
					strokeWidth: "4.4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M13 17H9.5c-1.6 0-2.5-1-2.5-2.6V12",
					fill: "none",
					stroke: "#54a85f",
					strokeWidth: "2.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M19 14h3c1.5 0 2.4-1 2.4-2.5V9",
					fill: "none",
					stroke: "#173d1f",
					strokeWidth: "4.4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M19 14h3c1.5 0 2.4-1 2.4-2.5V9",
					fill: "none",
					stroke: "#54a85f",
					strokeWidth: "2.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M13 27h6",
					stroke: "#173d1f",
					strokeWidth: "1.8",
					strokeLinecap: "round",
					opacity: "0"
				})
			]
		});
		case "lamp": return /* @__PURE__ */ x("svg", {
			...n,
			children: [
				/* @__PURE__ */ b("defs", { children: /* @__PURE__ */ x("linearGradient", {
					id: "wd-lamp",
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [
						/* @__PURE__ */ b("stop", {
							offset: "0",
							stopColor: "#ff8a5c"
						}),
						/* @__PURE__ */ b("stop", {
							offset: ".55",
							stopColor: "#f24d7c"
						}),
						/* @__PURE__ */ b("stop", {
							offset: "1",
							stopColor: "#b5326f"
						})
					]
				}) }),
				/* @__PURE__ */ b("path", {
					d: "M12.5 5h7l3.2 17.2c.2 1.2-.6 2.3-1.8 2.3H11.1c-1.2 0-2-1.1-1.8-2.3z",
					fill: "url(#wd-lamp)",
					stroke: "#3c1632",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ b("ellipse", {
					cx: "16",
					cy: "24.4",
					rx: "6.6",
					ry: "2.6",
					fill: "#ffcf7a",
					opacity: ".85"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "16",
					cy: "20",
					r: "2.1",
					fill: "#ffe9b8"
				}),
				/* @__PURE__ */ b("path", {
					d: "M13 9.5C14.2 8 17.8 8 19 9.5",
					fill: "none",
					stroke: "#ffd9a1",
					strokeWidth: "1.6",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M11.4 26.2h9.2",
					stroke: "#3c1632",
					strokeWidth: "2.4",
					strokeLinecap: "round"
				})
			]
		});
		case "donut": return /* @__PURE__ */ x("svg", {
			...n,
			children: [
				/* @__PURE__ */ b("circle", {
					cx: "16",
					cy: "16",
					r: "11",
					fill: "#e9a86a",
					stroke: "#5c3218",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "16",
					cy: "16",
					r: "7.2",
					fill: "#f7c7d8",
					stroke: "#5c3218",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "16",
					cy: "16",
					r: "3.2",
					fill: "#fdf3e3",
					stroke: "#5c3218",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ b("path", {
					d: "M11 9.5l1.6 1.2M21 10l-1 1.7M23 16.5l-1.8.4M9 17l1.5-.6M13 23l.6-1.6M19.5 22.5l-1.4-1",
					stroke: "#7d3f8f",
					strokeWidth: "2",
					strokeLinecap: "round"
				})
			]
		});
		case "cheese": return /* @__PURE__ */ x("svg", {
			...n,
			children: [
				/* @__PURE__ */ b("path", {
					d: "M4.5 22.5 16 6l11.5 16.5z",
					fill: "#f6c744",
					stroke: "#5d4412",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M4.5 22.5h23l-2.2 3.2H6.7z",
					fill: "#e0a92b",
					stroke: "#5d4412",
					strokeWidth: "1.6",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "13.5",
					cy: "18",
					r: "1.9",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "19.5",
					cy: "20.5",
					r: "1.3",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ b("circle", {
					cx: "17",
					cy: "13.4",
					r: "1.1",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1"
				})
			]
		});
		case "jelly": return /* @__PURE__ */ x("svg", {
			...n,
			children: [
				/* @__PURE__ */ b("path", {
					d: "M16 4.5c2 3.4 7.6 7.8 7.6 13.6 0 4.6-3.4 7.4-7.6 7.4s-7.6-2.8-7.6-7.4C8.4 12.3 14 7.9 16 4.5z",
					fill: "#d0528f",
					stroke: "#4a1233",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ b("path", {
					d: "M11.4 18.6c0-3 2.1-5.6 3.8-7.6",
					fill: "none",
					stroke: "#ffcfe4",
					strokeWidth: "2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ b("ellipse", {
					cx: "16",
					cy: "27",
					rx: "8.4",
					ry: "2.3",
					fill: "#f6e3cf",
					stroke: "#4a1233",
					strokeWidth: "1.6"
				})
			]
		});
		default: return /* @__PURE__ */ b("svg", {
			...n,
			children: /* @__PURE__ */ b("circle", {
				cx: "16",
				cy: "16",
				r: "8",
				fill: "none",
				stroke: "#9a8a72",
				strokeWidth: "1.8",
				strokeDasharray: "3.2 3"
			})
		});
	}
}
function Ye({ card: e, size: t = "md", selected: n = !1, dimmed: r = !1, onClick: i, ariaLabel: a }) {
	let o = t === "lg" ? 42 : t === "sm" ? 23 : 30, s = /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("span", {
		className: "wd-card-points",
		children: e.points
	}), /* @__PURE__ */ b("span", {
		className: "wd-card-icon",
		children: /* @__PURE__ */ b("span", {
			className: "wd-card-medallion",
			children: /* @__PURE__ */ b(Je, {
				icon: e.icon,
				size: o
			})
		})
	})] });
	return i ? /* @__PURE__ */ b("button", {
		type: "button",
		className: `wd-card wd-card-${t}${n ? " is-selected" : ""}${r ? " is-dimmed" : ""}`,
		"data-icon": e.icon,
		onClick: i,
		"aria-label": a,
		children: s
	}) : /* @__PURE__ */ b("span", {
		role: "img",
		"aria-label": a,
		"data-icon": e.icon,
		className: `wd-card wd-card-${t}${r ? " is-dimmed" : ""}`,
		children: s
	});
}
//#endregion
//#region src/game/view-player.tsx
function Xe({ pub: e }) {
	let t = e.players.length;
	return /* @__PURE__ */ x("svg", {
		className: "wd-fallback",
		viewBox: "-5 -5 10 10",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ b("circle", {
				r: "4.9",
				fill: "#1d4a4e"
			}),
			/* @__PURE__ */ b("circle", {
				r: "3",
				fill: "#e2592f"
			}),
			/* @__PURE__ */ b("circle", {
				r: "3",
				fill: "none",
				stroke: "#f6e7cd",
				strokeWidth: "0.06"
			}),
			/* @__PURE__ */ b("circle", {
				r: "0.5",
				fill: "#0b1114",
				stroke: "#ffcf7a",
				strokeWidth: "0.06"
			}),
			e.players.map((e) => {
				let n = e.seat / t * Math.PI * 2;
				return /* @__PURE__ */ x("g", {
					transform: `translate(${Math.cos(n) * 3.95} ${Math.sin(n) * 3.95})`,
					children: [/* @__PURE__ */ b("circle", {
						r: "0.58",
						fill: "#f6e7cd"
					}), /* @__PURE__ */ b("circle", {
						r: "0.42",
						fill: "#c04424"
					})]
				}, e.rid);
			})
		]
	});
}
function Ze({ public: e, private: t, members: n, myRid: r, send: a }) {
	let g = e, _ = t ?? null, v = l(), ee = c((e) => e.locale), [te] = s(Me), [y, S] = s(() => _ && _.paddock > 0 ? 1 : 0), [C, w] = s(1), [T, E] = s(1), [D, O] = s(!1), [k, A] = s(String(g.round)), j = o(null), M = o(!1);
	i(() => {
		let e = j.current, t = e?.querySelector(".wd-seat.is-self");
		if (!e || !t) return;
		let n = t.offsetLeft - (e.clientWidth - t.clientWidth) / 2;
		e.scrollTo({
			left: Math.max(0, n),
			behavior: M.current ? "smooth" : "auto"
		}), M.current = !0;
	}, [r, g.players.length]), k !== String(g.round) && (A(String(g.round)), S(_ && _.paddock > 0 ? 1 : 0), w(1), E(1), O(!1));
	let N = g.players.find((e) => e.rid === r), P = n.find((e) => e.rid === r), F = P ? d[P.colorIndex % d.length].hex : G.accent, I = _?.selection ?? null, L = _?.paddock ?? 0, R = I ? I.count : Math.min(y, L), z = (_?.thunderballHeld ?? !1) && g.advanced, re = g.phase === "select", B = g.picks ? g.picks.order[g.picks.index] : null, V = g.phase === "pick" && B === r, H = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, ee) : e;
	}, U = (e) => {
		let t = n.find((t) => t.rid === e);
		return d[(t?.colorIndex ?? 0) % d.length].hex;
	}, ie = (e) => v(e === 1 ? "games.whirlyderby.ui.clockwise" : "games.whirlyderby.ui.counter"), ae = () => {
		re && !I && a({
			type: "commit",
			count: R,
			direction: C,
			power: Number(T.toFixed(2)),
			thunderball: z && D && R > 0
		});
	}, W = (() => {
		let e = "info", t, n;
		return g.phase === "select" ? I ? (t = v("games.whirlyderby.ui.committed"), n = v("games.whirlyderby.ui.committedSub")) : (e = "accent", t = v("games.whirlyderby.ui.yourSelect"), n = v("games.whirlyderby.ui.selectHint")) : g.phase === "race" ? (t = v("games.whirlyderby.ui.raceBanner"), n = v("games.whirlyderby.ui.raceSub")) : g.phase === "pick" ? V ? (e = "accent", t = v("games.whirlyderby.ui.yourPick"), n = v("games.whirlyderby.ui.pickHint")) : t = v("games.whirlyderby.ui.waitPick", { name: B ? H(B) : "" }) : (e = "done", t = v("games.whirlyderby.phase.ended")), /* @__PURE__ */ b(p, {
			tone: e,
			text: t,
			sub: n,
			chip: v("games.whirlyderby.ui.round", { n: g.round }),
			accent: G.accent
		});
	})(), oe = /* @__PURE__ */ b("ul", {
		className: "wd-seats",
		ref: j,
		children: g.players.map((e) => {
			let t = n.find((t) => t.rid === e.rid);
			if (!t) return null;
			let i = g.phase === "select" ? e.submitted ? "done" : null : g.phase === "pick" && g.picks && g.picks.order.slice(0, g.picks.index).includes(e.rid) ? "done" : null;
			return /* @__PURE__ */ x("li", {
				className: `wd-seat${e.rid === r ? " is-self" : ""}`,
				style: { "--wd-seat": U(e.rid) },
				children: [
					/* @__PURE__ */ b(m, {
						m: t,
						myRid: r,
						action: i,
						anchorName: null,
						box: "size-6",
						img: "size-5"
					}),
					/* @__PURE__ */ b("span", {
						className: "wd-seat-name",
						children: H(e.rid)
					}),
					/* @__PURE__ */ x("span", {
						className: "wd-seat-stats",
						children: [
							/* @__PURE__ */ b("span", {
								className: "wd-seat-score",
								children: v("games.whirlyderby.ui.scoreLine", { n: e.score })
							}),
							/* @__PURE__ */ x("span", {
								title: v("games.whirlyderby.ui.paddock"),
								children: ["● ", e.paddock]
							}),
							/* @__PURE__ */ x("span", {
								title: v("games.whirlyderby.ui.reloads"),
								children: ["↻ ", e.reloads]
							}),
							g.thunderball?.owner === e.rid && /* @__PURE__ */ b("span", {
								className: "wd-seat-thunder",
								title: v("games.whirlyderby.ui.thunderball"),
								"aria-label": v("games.whirlyderby.ui.thunderball")
							})
						]
					})
				]
			}, e.rid);
		})
	}), se = /* @__PURE__ */ x("div", {
		className: `wd-prize${V ? " is-live" : ""}`,
		children: [
			/* @__PURE__ */ b("span", {
				className: "wd-prize-label",
				children: v("games.whirlyderby.ui.prize")
			}),
			/* @__PURE__ */ b("div", {
				className: "wd-prize-cards",
				children: g.prize.map((e) => /* @__PURE__ */ b(Ye, {
					card: e,
					size: "sm",
					selected: V,
					onClick: V ? () => a({
						type: "pick",
						card: e.id
					}) : void 0,
					ariaLabel: v("games.whirlyderby.ui.pickCardAria", {
						points: e.points,
						icon: v(ne[e.icon])
					})
				}, e.id))
			}),
			/* @__PURE__ */ b("span", {
				className: "wd-deck",
				children: v("games.whirlyderby.ui.deck", { n: g.deckCount })
			})
		]
	}), K = g.phase === "pick" && g.result ? (() => {
		let e = g.result.order, t = e.filter((e) => e.finished).length;
		return /* @__PURE__ */ x("div", {
			className: "wd-result",
			children: [
				/* @__PURE__ */ b("span", {
					className: "wd-result-line",
					children: v("games.whirlyderby.ui.finishSummary", {
						a: t,
						b: e.length
					})
				}),
				/* @__PURE__ */ b("ol", {
					className: "wd-result-list",
					children: e.slice(0, 3).map((e, t) => /* @__PURE__ */ x("li", { children: [
						/* @__PURE__ */ b("span", {
							className: "wd-result-rank",
							children: t + 1
						}),
						/* @__PURE__ */ b("span", {
							className: "wd-result-dot",
							style: { background: U(e.rid) }
						}),
						/* @__PURE__ */ b("span", {
							className: "wd-result-name",
							children: H(e.rid)
						}),
						/* @__PURE__ */ b("span", {
							className: "wd-result-state",
							children: v(e.finished ? "games.whirlyderby.ui.finished" : "games.whirlyderby.ui.stopped")
						})
					] }, `${e.rid}:${t}`))
				}),
				g.result.thunderballDraw && /* @__PURE__ */ b("span", {
					className: "wd-result-line",
					children: v("games.whirlyderby.ui.thunderDraw", {
						name: H(g.result.thunderballDraw.owner),
						n: g.result.thunderballDraw.stopped,
						m: g.result.thunderballDraw.cards.length
					})
				}),
				g.result.lastPlace && /* @__PURE__ */ b("span", {
					className: "wd-result-line",
					children: v("games.whirlyderby.ui.lastPlace", { name: H(g.result.lastPlace.rid) })
				})
			]
		});
	})() : null, q = g.phase === "select" && !I ? /* @__PURE__ */ x("div", {
		className: "wd-actions",
		children: [/* @__PURE__ */ x("div", {
			className: "wd-row",
			children: [
				/* @__PURE__ */ x("div", {
					className: "wd-marble-group",
					children: [/* @__PURE__ */ b("span", {
						className: "wd-group-label",
						children: v("games.whirlyderby.ui.paddock")
					}), /* @__PURE__ */ b("div", {
						className: "wd-marbles",
						role: "group",
						"aria-label": v("games.whirlyderby.ui.yourSelect"),
						children: L === 0 ? /* @__PURE__ */ b("span", {
							className: "wd-empty-note",
							children: v("games.whirlyderby.ui.noMarble")
						}) : Array.from({ length: L }, (e, t) => /* @__PURE__ */ b("button", {
							type: "button",
							className: `wd-marble${t < R ? " is-on" : ""}`,
							"aria-label": v("games.whirlyderby.ui.commit", { n: t + 1 }),
							"aria-pressed": t < R,
							style: { "--wd-marble": F },
							onClick: () => S(R === t + 1 ? Math.max(1, t) : t + 1)
						}, t))
					})]
				}),
				/* @__PURE__ */ x("button", {
					type: "button",
					className: "wd-token wd-token-reload",
					disabled: !_?.canReload,
					onClick: () => a({ type: "reload" }),
					"aria-label": v("games.whirlyderby.ui.reload"),
					title: v("games.whirlyderby.ui.reloadHint", { n: N?.box ?? 0 }),
					children: [/* @__PURE__ */ b("span", {
						className: "wd-token-face",
						children: N?.reloads ?? 0
					}), /* @__PURE__ */ b("span", {
						className: "wd-token-sub",
						children: "↻"
					})]
				}),
				z && /* @__PURE__ */ b("button", {
					type: "button",
					className: `wd-token wd-token-thunder${D && R > 0 ? " is-on" : ""}`,
					"aria-pressed": D && R > 0,
					"aria-label": v("games.whirlyderby.ui.thunderball"),
					title: v("games.whirlyderby.ui.thunderHeld"),
					onClick: () => O((e) => R > 0 && !e),
					children: /* @__PURE__ */ b("span", {
						className: "wd-thunder-orb",
						"aria-hidden": !0
					})
				})
			]
		}), /* @__PURE__ */ x("div", {
			className: "wd-row",
			children: [
				/* @__PURE__ */ x("div", {
					className: "wd-group wd-dir",
					children: [/* @__PURE__ */ b("span", {
						className: "wd-group-label",
						children: v("games.whirlyderby.ui.direction")
					}), /* @__PURE__ */ x("div", {
						className: "wd-seg",
						role: "group",
						"aria-label": v("games.whirlyderby.ui.direction"),
						children: [/* @__PURE__ */ b("button", {
							type: "button",
							className: C === 1 ? "is-on" : "",
							"aria-pressed": C === 1,
							"aria-label": v("games.whirlyderby.ui.clockwise"),
							onClick: () => w(1),
							children: /* @__PURE__ */ b("span", {
								"aria-hidden": !0,
								children: "↻"
							})
						}), /* @__PURE__ */ b("button", {
							type: "button",
							className: C === -1 ? "is-on" : "",
							"aria-pressed": C === -1,
							"aria-label": v("games.whirlyderby.ui.counter"),
							onClick: () => w(-1),
							children: /* @__PURE__ */ b("span", {
								"aria-hidden": !0,
								children: "↺"
							})
						})]
					})]
				}),
				/* @__PURE__ */ x("label", {
					className: "wd-group wd-power",
					children: [
						/* @__PURE__ */ b("span", {
							className: "wd-group-label",
							children: v("games.whirlyderby.ui.power")
						}),
						/* @__PURE__ */ b("input", {
							type: "range",
							min: .6,
							max: 1.4,
							step: .1,
							value: T,
							"aria-label": v("games.whirlyderby.ui.power"),
							onChange: (e) => E(Number(e.currentTarget.value))
						}),
						/* @__PURE__ */ b("span", {
							className: "wd-power-value",
							children: v("games.whirlyderby.ui.powerValue", { n: T.toFixed(1) })
						})
					]
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					className: "wd-commit",
					style: { background: F },
					onClick: ae,
					children: R === 0 ? v("games.whirlyderby.ui.roundEmpty") : v("games.whirlyderby.ui.commit", { n: R })
				})
			]
		})]
	}) : g.phase === "select" && I ? /* @__PURE__ */ x("div", {
		className: "wd-actions wd-actions-locked",
		children: [
			/* @__PURE__ */ b(u, {
				size: 22,
				strokeWidth: 3,
				"aria-hidden": !0
			}),
			/* @__PURE__ */ x("div", {
				className: "wd-locked-text",
				children: [/* @__PURE__ */ b("b", { children: v("games.whirlyderby.ui.committed") }), /* @__PURE__ */ b("span", { children: v("games.whirlyderby.ui.committedSub") })]
			}),
			/* @__PURE__ */ x("div", {
				className: "wd-locked-stats",
				children: [
					/* @__PURE__ */ b("span", { children: v("games.whirlyderby.ui.commit", { n: I.count }) }),
					/* @__PURE__ */ b("span", { children: ie(I.direction) }),
					/* @__PURE__ */ b("span", { children: v("games.whirlyderby.ui.powerValue", { n: I.power.toFixed(1) }) }),
					I.thunderball && /* @__PURE__ */ b("span", { children: v("games.whirlyderby.ui.thunderball") })
				]
			})
		]
	}) : g.phase === "pick" && g.picks ? /* @__PURE__ */ x("div", {
		className: "wd-actions",
		children: [/* @__PURE__ */ x("div", {
			className: "wd-status",
			children: [/* @__PURE__ */ b("b", { children: V ? v("games.whirlyderby.ui.yourPick") : v("games.whirlyderby.ui.waitPick", { name: B ? H(B) : "" }) }), /* @__PURE__ */ b("span", { children: v("games.whirlyderby.ui.pickOrder") })]
		}), /* @__PURE__ */ b("ol", {
			className: "wd-pick-order",
			children: g.picks.order.map((e, t) => /* @__PURE__ */ x("li", {
				className: t === g.picks?.index ? "is-now" : t < (g.picks?.index ?? 0) ? "is-done" : "",
				children: [/* @__PURE__ */ b("span", {
					className: "wd-result-dot",
					style: { background: U(e) }
				}), H(e)]
			}, `${e}:${t}`))
		})]
	}) : /* @__PURE__ */ b("div", {
		className: "wd-actions wd-actions-status",
		children: /* @__PURE__ */ x("div", {
			className: "wd-status",
			children: [/* @__PURE__ */ b("b", { children: g.phase === "race" ? v("games.whirlyderby.ui.raceBanner") : v("games.whirlyderby.phase.ended") }), /* @__PURE__ */ b("span", { children: g.phase === "race" ? v("games.whirlyderby.ui.raceSub") : v("games.whirlyderby.ui.waiting") })]
		})
	});
	return /* @__PURE__ */ b(f, {
		adaptive: !0,
		className: "wd-game",
		scroll: !1,
		actionsHeight: "wd-actions-h",
		banner: /* @__PURE__ */ x("div", {
			className: "wd-banner",
			children: [W, oe]
		}),
		actions: q,
		overlay: K,
		children: /* @__PURE__ */ x("div", {
			className: "wd-stage",
			children: [te ? /* @__PURE__ */ b(qe, {
				pub: g,
				myRid: r,
				members: n,
				selection: I
			}) : /* @__PURE__ */ b(Xe, { pub: g }), se]
		})
	});
}
//#endregion
//#region src/game/bot.ts
var Qe = [
	"donut",
	"cheese",
	"jelly"
];
function $e(e) {
	let t = {
		cactus: 0,
		lamp: 0,
		donut: 0,
		cheese: 0,
		jelly: 0
	};
	for (let n of e) n.icon !== "none" && (t[n.icon] += 1);
	return t;
}
function et(e) {
	let t = Math.min(e, k.length - 1);
	return k[Math.min(t + 1, k.length - 1)] - k[t];
}
function tt(e, t, n, r) {
	if (!r || e.icon === "none") return e.points;
	let i = $e(t), a = e.points;
	return e.icon === "lamp" && (a += et(i.lamp)), e.icon === "cactus" ? i.cactus + 1 > n ? a += 15 : i.cactus + 1 === n && (a += 6) : e.icon !== "lamp" && i[e.icon] === 0 && Qe.filter((t) => t !== e.icon).every((e) => i[e] > 0) && (a += 30), a;
}
function nt(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n);
	if (!i) return null;
	let a = t?.paddock ?? i.paddock;
	if (a === 0) return t?.canReload ? { type: "reload" } : {
		type: "commit",
		count: 0,
		direction: 1,
		power: 1,
		thunderball: !1
	};
	let o = r === "weak", s = i.score < Math.max(...e.players.map((e) => e.score)), c;
	if (o) c = 1 + Math.floor(Math.random() * a);
	else if (e.round >= 8) c = a;
	else {
		let t = s ? 3 : 2;
		e.round <= 2 && (t = Math.min(t, 2)), 8 - e.round <= 2 && (t = Math.max(t, 3)), c = Math.min(a, t);
	}
	c = Math.max(1, Math.min(a, c));
	let l = Math.random() < .5 ? 1 : -1, u = o ? Math.round((.6 + Math.random() * .8) * 10) / 10 : s ? 1.1 : 1, d = !!t?.thunderballHeld && e.advanced;
	return {
		type: "commit",
		count: c,
		direction: l,
		power: u,
		thunderball: d
	};
}
var rt = (e, t) => {
	let { public: n, private: r } = e, i = t.rid;
	if (n.phase === "select") {
		if (r?.selection) return null;
		let e = nt(n, r ?? null, i, t.difficulty);
		return e ? { action: e } : null;
	}
	if (n.phase === "pick") {
		if (!n.picks || n.picks.index >= n.picks.order.length || n.picks.order[n.picks.index] !== i || n.prize.length === 0) return null;
		let e = n.players.find((e) => e.rid === i)?.cards ?? [];
		if (t.difficulty === "weak") return { action: {
			type: "pick",
			card: n.prize[Math.floor(Math.random() * n.prize.length)].id
		} };
		let r = Math.max(0, ...n.players.map((e) => $e(e.cards).cactus)), a = n.prize[0];
		for (let t of n.prize) tt(t, e, r, n.advanced) > tt(a, e, r, n.advanced) && (a = t);
		return { action: {
			type: "pick",
			card: a.id
		} };
	}
	return null;
};
//#endregion
//#region src/game/game-over.tsx
function it(e) {
	let t = l(), n = e.public, r = new Map((n?.players ?? []).map((e) => [e.rid, e])), i = (e) => {
		let n = r.get(e);
		return n ? n.cards.length === 0 ? /* @__PURE__ */ b("div", {
			className: "wd-over-empty",
			children: t("games.whirlyderby.ui.noCards")
		}) : /* @__PURE__ */ b("div", {
			className: "wd-over-cards",
			children: n.cards.map((e) => /* @__PURE__ */ b(Ye, {
				card: e,
				size: "sm",
				ariaLabel: t("games.whirlyderby.ui.pickCardAria", {
					points: e.points,
					icon: t(ne[e.icon])
				})
			}, e.id))
		}) : null;
	};
	return /* @__PURE__ */ b("div", {
		className: "wd-over",
		children: /* @__PURE__ */ b(S, {
			...e,
			accent: G.accent,
			renderRowExtra: i
		})
	});
}
//#endregion
//#region src/game/options.tsx
function at({ value: e, onChange: t }) {
	let n = l(), r = q.safeParse(e), i = r.success ? r.data : q.parse(void 0);
	return /* @__PURE__ */ b(C, {
		title: n("games.whirlyderby.opt.advanced"),
		columns: 2,
		children: /* @__PURE__ */ b("div", {
			className: "col-span-2",
			children: /* @__PURE__ */ b(w, {
				checked: i.advanced,
				label: n("games.whirlyderby.opt.advanced"),
				hint: n("games.whirlyderby.opt.advancedHint"),
				accent: G.accent,
				onChange: () => t({
					...i,
					advanced: !i.advanced
				})
			})
		})
	});
}
//#endregion
//#region src/game/locales/zh.ts
var ot = {
	name: "旋风竞速",
	desc: "秘密投入弹珠，在漏斗赛场里抢进前三，赢取八场比赛的奖杯",
	rules: "目标：进行八场比赛。每场比赛中，你指挥自己颜色的弹珠冲进赛场中央的孔口；名次越靠前，获得的奖杯卡分值越高。八场比赛结束后，总分最高的玩家获胜。\n\n准备：把漏斗赛场放在桌面中央。每位玩家取同色围栏、五颗竞赛弹珠和两枚补给标记，补给标记以“2”面朝上。奖杯卡洗混后背面朝下作为牌堆，翻开三张作为本场奖池。八枚比赛标记以红灯面朝上，第一枚翻到绿灯面表示第一场开始。\n\n每场比赛：\n· 所有玩家同时秘密决定本场投入几颗弹珠，并选择投入的旋向与力度。只要围栏中还有弹珠，本场至少投入一颗。\n· 全部玩家提交后，弹珠从各自的发射位置依次进入赛场。弹珠在漏斗中相互碰撞、绕圈减速，最终滚向中央孔口。\n· 第一颗落入孔口的弹珠获得第一名，其后依次为第二名和第三名。前三名按名次从奖池中取走一张奖杯卡。\n· 没有落入孔口的弹珠停在赛场中，按最终距离孔口的远近排出后续名次。\n· 每场比赛的最后一名可以从赛场收回一颗自己的弹珠，放回围栏。\n· 其余参赛弹珠收回盒中，在余下的比赛中不能使用。\n· 每场结束后，从牌堆补三张奖杯卡作为下一场的奖池，并翻开下一枚比赛标记。\n\n补给：\n· 整场对局中，每位玩家有两次补给机会。使用一次补给，可以把自己盒中的全部弹珠收回围栏。\n· 第一次使用后，补给标记翻到“1”面；第二次使用后，把补给标记弃掉。\n· 围栏和盒中都没有弹珠，且没有可用补给时，本场只能轮空。\n\n终局：\n· 八场比赛后，累计奖杯卡分值最高的玩家获胜。\n· 最高分并列时，并列者各投入一颗弹珠加赛一场，先落入孔口者获胜。\n\n进阶规则：\n· 前两枚比赛标记为普通标记。其余六枚标记中有两枚雷霆球标记，开局时随机混入。\n· 翻到雷霆球标记时，当前分数最低的玩家获得雷霆球；分数相同时，弹珠总数较少的玩家获得。若原持有者尚未使用，雷霆球转交给新的最低分玩家。\n· 雷霆球持有者可以在任意一场使用一次雷霆球，使用时必须同时投入至少一颗普通弹珠。\n· 雷霆球在比赛中落下，封住中央孔口。它挡下的弹珠越多，持有者从牌堆顶获得的奖杯卡越多，最多三张。\n· 雷霆球比赛中，只有落入孔口的弹珠进入前三名并取走奖杯；这场比赛没有最后一名收回弹珠的奖励。\n· 奖杯卡底部印有图标，按以下方式额外加分：仙人掌图标最多的玩家获得十五分，并列最多者各获得十五分；熔岩灯图标越多，加分越高；甜甜圈、奶酪和果冻图标各至少一张时，额外获得三十分。",
	opt: {
		advanced: "进阶规则",
		advancedHint: "加入雷霆球标记、图标套装加分与熔岩灯加分"
	},
	phase: {
		select: "秘密投珠",
		race: "比赛进行中",
		pick: "领取奖杯",
		ended: "结束"
	},
	ui: {
		round: "第 {{n}} / 8 场",
		yourSelect: "秘密选择本场投入的弹珠",
		waitSelect: "等待 {{name}} 提交",
		selectHint: "点击围栏弹珠选择数量，再调整旋向与力度",
		committed: "本场已提交，等待其他玩家",
		committedSub: "旋向与力度已锁定",
		raceBanner: "比赛进行中",
		raceSub: "弹珠正在漏斗中竞速",
		yourPick: "轮到你领取奖杯",
		waitPick: "等待 {{name}} 领取奖杯",
		pickHint: "点击一张奖杯卡收入手中",
		prize: "本场奖杯",
		deck: "牌堆 {{n}}",
		paddock: "围栏",
		box: "盒中",
		reloads: "补给",
		reload: "使用补给",
		reloadHint: "收回盒中 {{n}} 颗弹珠",
		direction: "旋向",
		clockwise: "顺时针",
		counter: "逆时针",
		power: "力度",
		powerValue: "{{n}}×",
		thunderball: "雷霆球",
		thunderHeld: "你持有雷霆球",
		thunderOwner: "雷霆球：{{name}}",
		commit: "投入 {{n}} 颗",
		roundEmpty: "本场轮空",
		roundEmptySub: "围栏与盒中都没有弹珠",
		pickOrder: "领杯顺序",
		finished: "落孔",
		stopped: "未落孔",
		lastPlace: "末位 {{name}} 收回一颗弹珠",
		thunderDraw: "{{name}} 的雷霆球挡下 {{n}} 颗弹珠，抽取 {{m}} 张奖杯卡",
		thunderNoDraw: "{{name}} 的雷霆球没有挡下弹珠",
		finishSummary: "落孔 {{a}} / {{b}}",
		scoreLine: "{{n}} 分",
		marbleLine: "弹珠 {{n}}",
		tapHint: "拖动平移，双指缩放",
		recenter: "复位视角",
		waiting: "等待其他玩家",
		myTurn: "轮到你",
		submitted: "已提交",
		noMarble: "无弹珠可投",
		lastRoundResult: "本场结果",
		pickCardAria: "{{points}} 分，{{icon}}",
		trophyCount: "奖杯 {{n}} 分",
		cardsCount: "奖杯卡 {{n}} 张",
		noCards: "本局没有获得奖杯卡"
	},
	iconCactus: "仙人掌",
	iconLamp: "熔岩灯",
	iconDonut: "甜甜圈",
	iconCheese: "奶酪",
	iconJelly: "果冻",
	iconNone: "无图标",
	err: {
		phase: "当前阶段不能这样操作",
		notPlayer: "你不在本局中",
		committed: "本场已经提交过了",
		noReload: "没有可用的补给",
		emptyBox: "盒中没有弹珠",
		tooMany: "投入数量超过围栏中的弹珠",
		mustEnter: "本场至少投入一颗弹珠",
		noMarbles: "围栏中没有弹珠",
		thunderNeedsMarble: "使用雷霆球时必须同时投入至少一颗弹珠",
		noThunderball: "你没有可用的雷霆球",
		notTurn: "还没轮到你领取奖杯",
		badPick: "这张奖杯卡不在本场奖池中"
	}
}, st = {
	name: "Whirly Derby",
	desc: "Secretly commit your marbles, race them into the funnel, and finish in the top three to claim trophies over eight races",
	rules: "Goal: Play eight races. In each race you steer marbles of your own colour towards the hole at the centre of the arena; the higher you finish, the more valuable the trophy cards you win. After eight races, the player with the highest total score wins.\n\nSetup: Place the funnel arena in the middle of the table. Each player takes the fence, five racing marbles and two reload tokens in their own colour, with the reload tokens showing \"2\". Shuffle the trophy cards face down as a deck and turn three of them face up as this race's prize pool. Place the eight race tokens red side up and turn the first one green to show that race one has begun.\n\nEach race:\n· All players simultaneously decide in secret how many marbles to commit this race, along with the spin direction and the power. As long as marbles remain behind your fence, you must commit at least one.\n· After everyone has committed, the marbles enter the arena one at a time from their launching positions. Inside the funnel they collide, circle and slow down until they roll towards the central hole.\n· The first marble to drop into the hole takes first place, followed by second and third. The top three players each take one trophy card from the prize pool.\n· Marbles that do not drop into the hole come to rest in the arena and are ranked behind the finishers by their final distance from the hole.\n· At the end of each race, the last-place player returns one of their marbles from the arena to behind their fence.\n· All other marbles that took part are returned to the box and cannot be used for the rest of the game.\n· After each race, deal three new trophy cards from the deck as the next race's prize pool and turn the next race token green.\n\nReload:\n· You have two reloads for the whole game. Using one returns every marble in your box to behind your fence.\n· After the first use, flip the reload token to show \"1\"; after the second use, discard the token.\n· If you have no marbles behind your fence and none in your box, and no reload remains, you sit this race out.\n\nEnd of the game:\n· After eight races, the player with the highest total trophy value wins.\n· If the highest score is tied, each tied player commits one marble for an extra sudden-death race, and the first to drop into the hole wins.\n\nAdvanced rules:\n· The first two race tokens are standard. Two of the remaining six tokens are Thunderball tokens and are shuffled in at the start of the game.\n· When a Thunderball token is revealed, the player with the lowest current score receives the Thunderball; if scores are tied, the player with fewer marbles receives it. If the previous holder has not used it yet, the Thunderball passes to the new lowest-scoring player.\n· The holder may use the Thunderball once in any race, and must commit at least one normal marble at the same time.\n· The Thunderball drops during the race and blocks the central hole. The more marbles it stops, the more trophy cards its holder draws from the top of the deck, up to three.\n· In a Thunderball race, only marbles that drop into the hole enter the top three and take trophies; this race has no last-place marble return.\n· The bottom of each trophy card shows an icon that scores extra as follows: the player with the most cactus icons scores fifteen points, and every player tied for the most scores fifteen; the more lava lamp icons you have, the more bonus points you score; and having at least one donut, one cheese and one jelly icon scores thirty extra points.",
	opt: {
		advanced: "Advanced rules",
		advancedHint: "Add Thunderball tokens, icon set bonuses and lava lamp bonuses"
	},
	phase: {
		select: "Secret commitment",
		race: "Race in progress",
		pick: "Claim trophies",
		ended: "Finished"
	},
	ui: {
		round: "Race {{n}} / 8",
		yourSelect: "Choose marbles in secret",
		waitSelect: "Waiting for {{name}}",
		selectHint: "Tap marbles, then set spin and power",
		committed: "Committed, waiting for others",
		committedSub: "Direction and power are locked in",
		raceBanner: "Race in progress",
		raceSub: "Marbles are racing down the funnel",
		yourPick: "Your turn to claim a trophy",
		waitPick: "Waiting for {{name}} to pick",
		pickHint: "Tap a trophy card to take it",
		prize: "This race’s trophies",
		deck: "Deck {{n}}",
		paddock: "Fence",
		box: "Box",
		reloads: "Reloads",
		reload: "Use a reload",
		reloadHint: "Return {{n}} marbles from your box",
		direction: "Direction",
		clockwise: "Clockwise",
		counter: "Counter-clockwise",
		power: "Power",
		powerValue: "{{n}}×",
		thunderball: "Thunderball",
		thunderHeld: "You hold the Thunderball",
		thunderOwner: "Thunderball: {{name}}",
		commit: "Commit {{n}}",
		roundEmpty: "Sit out this race",
		roundEmptySub: "No marbles in your fence or box",
		pickOrder: "Claim order",
		finished: "Dropped in",
		stopped: "Stayed out",
		lastPlace: "Last place {{name}} returns one marble",
		thunderDraw: "{{name}}’s Thunderball stopped {{n}} marbles and drew {{m}} trophy cards",
		thunderNoDraw: "{{name}}’s Thunderball stopped no marbles",
		finishSummary: "Dropped in {{a}} / {{b}}",
		scoreLine: "{{n}} pts",
		marbleLine: "Marbles {{n}}",
		tapHint: "Drag to pan, pinch to zoom",
		recenter: "Recenter view",
		waiting: "Waiting for other players",
		myTurn: "Your turn",
		submitted: "Committed",
		noMarble: "No marbles to commit",
		lastRoundResult: "Race result",
		pickCardAria: "{{points}} points, {{icon}}",
		trophyCount: "Trophies {{n}} pts",
		cardsCount: "Trophy cards {{n}}",
		noCards: "No trophy cards this game"
	},
	iconCactus: "Cactus",
	iconLamp: "Lava lamp",
	iconDonut: "Donut",
	iconCheese: "Cheese",
	iconJelly: "Jelly",
	iconNone: "No icon",
	err: {
		phase: "You cannot do that in this phase",
		notPlayer: "You are not in this game",
		committed: "You have already committed this race",
		noReload: "No reload available",
		emptyBox: "There are no marbles in your box",
		tooMany: "You cannot commit more marbles than your fence holds",
		mustEnter: "You must commit at least one marble this race",
		noMarbles: "No marbles behind your fence",
		thunderNeedsMarble: "You must commit at least one marble to use the Thunderball",
		noThunderball: "You have no usable Thunderball",
		notTurn: "It is not your turn to claim a trophy",
		badPick: "That trophy card is not in this race’s prize pool"
	}
};
//#endregion
//#region src/index.tsx
await E();
var ct = {
	definition: Oe,
	View: Ze,
	bot: rt,
	OverView: it,
	Options: at,
	locales: {
		zh: ot,
		en: st
	}
};
//#endregion
export { ct as default };
