import e from "@dimforge/rapier3d-compat";
import { randomAt as t, randomIntAt as n } from "@bgparty/sdk/engine/prng";
import { z as r } from "zod";
import { useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconCheck as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import * as v from "three";
import { ResilientCanvas as y } from "@bgparty/sdk/three/resilient-canvas";
import { usePrefersReducedMotion as b } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
import { GameOverScreen as w } from "@bgparty/sdk/ui/game-over-screen";
import { OptionSection as T, OptionSwitch as E } from "@bgparty/sdk/ui/game-options";
//#region src/game/initialize.ts
var D;
function ee() {
	return D ??= e.init().catch((e) => {
		throw D = void 0, e;
	});
}
var O = [
	["cactus", 1],
	["cactus", 1],
	["cactus", 2],
	["cactus", 2],
	["cactus", 3],
	["cactus", 3],
	["cactus", 4],
	["cactus", 5],
	["lamp", 1],
	["lamp", 2],
	["lamp", 2],
	["lamp", 3],
	["lamp", 3],
	["lamp", 4],
	["lamp", 4],
	["lamp", 5],
	["donut", 1],
	["donut", 2],
	["donut", 3],
	["donut", 4],
	["cheese", 1],
	["cheese", 2],
	["cheese", 3],
	["cheese", 4],
	["jelly", 1],
	["jelly", 2],
	["jelly", 3],
	["jelly", 4],
	["none", 1],
	["none", 1],
	["none", 1],
	["none", 2],
	["none", 2],
	["none", 2],
	["none", 3],
	["none", 3],
	["none", 3],
	["none", 4],
	["none", 4],
	["none", 5]
].map(([e, t], n) => ({
	id: `t${String(n + 1).padStart(2, "0")}`,
	points: t,
	icon: e
})), te = Object.fromEntries(O.map((e) => [e.id, e])), k = [
	0,
	2,
	5,
	9,
	14,
	20
], ne = {
	cactus: "games.whirlyderby.iconCactus",
	lamp: "games.whirlyderby.iconLamp",
	donut: "games.whirlyderby.iconDonut",
	cheese: "games.whirlyderby.iconCheese",
	jelly: "games.whirlyderby.iconJelly",
	none: "games.whirlyderby.iconNone"
}, A = .2, j = .85, M = .5, N = .7, re = .42, P = 2.55;
function F(e) {
	return re * Math.max(0, e - M);
}
function I(e = 26, t = 72) {
	let n = [], r = [];
	for (let r = 0; r <= e; r++) {
		let i = M + r / e * 2.5, a = F(i);
		for (let e = 0; e < t; e++) {
			let r = e / t * Math.PI * 2;
			n.push(Math.cos(r) * i, a, Math.sin(r) * i);
		}
	}
	for (let n = 0; n < e; n++) for (let e = 0; e < t; e++) {
		let i = n * t + e, a = n * t + (e + 1) % t, o = (n + 1) * t + e, s = (n + 1) * t + (e + 1) % t;
		r.push(i, o, a, a, o, s);
	}
	return {
		positions: new Float32Array(n),
		indices: new Uint32Array(r)
	};
}
function L(e = 72) {
	let t = [], n = [], r = F(3);
	for (let n = 0; n < e; n++) {
		let i = n / e * Math.PI * 2;
		t.push(Math.cos(i) * 3, r, Math.sin(i) * 3);
	}
	for (let n = 0; n < e; n++) {
		let i = n / e * Math.PI * 2;
		t.push(Math.cos(i) * 3, r + N, Math.sin(i) * 3);
	}
	for (let t = 0; t < e; t++) {
		let r = (t + 1) % e, i = t, a = r, o = e + t, s = e + r;
		n.push(i, a, o, a, s, o);
	}
	return {
		positions: new Float32Array(t),
		indices: new Uint32Array(n)
	};
}
function ie(e = 26, t = 72) {
	let n = I(e, t), r = L(t), i = new Float32Array(n.positions.length + r.positions.length);
	i.set(n.positions, 0), i.set(r.positions, n.positions.length);
	let a = n.positions.length / 3, o = new Uint32Array(n.indices.length + r.indices.length);
	o.set(n.indices, 0);
	for (let e = 0; e < r.indices.length; e++) o[n.indices.length + e] = r.indices[e] + a;
	return {
		positions: i,
		indices: o
	};
}
//#endregion
//#region src/game/physics.ts
var R = 1 / 120;
6 * R * 1e3;
var z = 3e3, B = Math.sqrt(160 * P * re) * 1.2, V = .02, ae = .01, oe = .05, se = .01, ce = .9, le = 2.4, ue = 2.2, de = Math.PI / 2, fe = 1.1, pe = -1, me = 6, he = 2, ge = .13, H = (e) => Math.round(e * 100) / 100;
function _e(r) {
	let i = r.entries.filter((e) => e.count > 0), a = [], o = r.cursor, s = [];
	for (let e of i) for (let t = 0; t < e.count; t++) s.push(e.rid);
	for (let e = s.length - 1; e > 0; e--) {
		let t = n(r.seed, o++, e + 1);
		[s[e], s[t]] = [s[t], s[e]];
	}
	for (let e = 0; e < s.length; e++) {
		let n = s.length === 1 ? 0 : e / (s.length - 1) - .5, i = (t(r.seed, o++) - .5) * .12, c = (t(r.seed, o++) - .5) * .1, l = (t(r.seed, o++) - .5) * .16, u = (t(r.seed, o++) - .5) * .36, d = (t(r.seed, o++) - .5) * .16, f = (t(r.seed, o++) - .5) * .024, p = (t(r.seed, o++) - .5) * .36, m = (t(r.seed, o++) - .5) * .024, h = (t(r.seed, o++) - .5) * .24, g = () => (t(r.seed, o++) - .5) * 10, _ = e * me, v = A * (1 + l);
		a.push({
			rid: s[e],
			kind: "marble",
			index: e,
			spawnStep: _,
			spawnMs: _ / 6 * 50,
			angle: de + n * fe + i,
			radius: P + e % he * ge + c,
			size: v,
			speed: B * (1 + u),
			direction: pe,
			density: le * (1 + d),
			friction: Math.max(.02, oe + f),
			restitution: Math.min(1, Math.max(.55, ce + p)),
			damping: Math.max(0, ae + m),
			angularDamping: Math.max(.01, .08 + h),
			spin: {
				x: g(),
				y: g(),
				z: g()
			},
			body: null,
			track: [],
			finished: !1,
			finishStep: null,
			lastX: 0,
			lastZ: 0
		});
	}
	r.thunderball && a.unshift({
		rid: r.thunderball.rid,
		kind: "thunderball",
		index: -1,
		spawnStep: 288,
		spawnMs: 2400,
		angle: 0,
		radius: P,
		size: j,
		speed: 0,
		direction: 1,
		density: .9,
		friction: .12,
		restitution: .05,
		damping: .5,
		angularDamping: 1.5,
		spin: {
			x: 0,
			y: 0,
			z: 0
		},
		body: null,
		track: [],
		finished: !1,
		finishStep: null,
		lastX: 0,
		lastZ: 0
	});
	let c = a.filter((e) => e.kind === "marble").length;
	if (c === 0) return {
		marbles: [],
		tracks: [],
		sampleMs: 50,
		endMs: 0,
		order: [],
		stopped: 0,
		cursor: o
	};
	let l = new e.World({
		x: 0,
		y: -160,
		z: 0
	});
	l.timestep = R;
	try {
		let t = ie();
		l.createCollider(e.ColliderDesc.trimesh(t.positions, t.indices).setFriction(se).setRestitution(.1));
		let n = (t) => {
			let n = t.kind === "thunderball", r = n ? 0 : Math.cos(t.angle) * t.radius, i = n ? 0 : Math.sin(t.angle) * t.radius, a = n ? Math.sqrt(j * j - M * M) + j + 1.1 : F(t.radius) + t.size + .08, o = -Math.sin(t.angle) * t.direction, s = Math.cos(t.angle) * t.direction, c = -Math.cos(t.angle), u = -Math.sin(t.angle), d = o + c * V, f = s + u * V, p = Math.hypot(d, f) || 1, m = n ? 0 : t.speed, h = e.RigidBodyDesc.dynamic().setTranslation(r, a, i).setLinvel(d / p * m, 0, f / p * m).setAngvel(t.spin).setLinearDamping(t.damping).setAngularDamping(t.angularDamping).setCcdEnabled(!0), g = l.createRigidBody(h), _ = e.ColliderDesc.ball(n ? j : t.size).setDensity(t.density).setFriction(t.friction).setRestitution(t.restitution);
			l.createCollider(_, g), t.body = g, t.lastX = r, t.lastZ = i;
		}, r = 0, i = -1, s = 0, u = 0, d = Math.max(...a.map((e) => e.spawnStep));
		for (let e = 0; e < z; e++) {
			for (let t of a) !t.body && t.spawnStep === e && n(t);
			l.step();
			for (let e of a) {
				if (!e.body || e.finished || e.kind !== "marble") continue;
				let t = e.body.translation(), n = Math.hypot(t.x, t.z);
				if (t.y > F(n) + e.size + .08) continue;
				let r = e.body.linvel(), i = Math.hypot(r.x, r.y, r.z);
				if (i < .02) continue;
				let a = e.density * (4 / 3) * Math.PI * e.size ** 3 * ue * R / i;
				e.body.applyImpulse({
					x: -r.x * a,
					y: -r.y * a,
					z: -r.z * a
				}, !0);
			}
			let t = !1;
			for (let n of a) {
				if (!n.body || n.finished) continue;
				let r = n.body.translation();
				if (n.lastX = r.x, n.lastZ = r.z, n.kind === "marble" && r.y < -.45) {
					n.finished = !0, n.finishStep = e, i = e, s++, t = !0, n.body.setEnabled(!1);
					continue;
				}
				let a = n.body.linvel();
				a.x * a.x + a.y * a.y + a.z * a.z > .0625 && (t = !0);
			}
			if (e % 6 == 0) {
				r++;
				for (let e of a) {
					if (!e.body) continue;
					let t = e.body.translation();
					e.track.push(H(t.x), H(t.y), H(t.z));
				}
			}
			if (u = t ? 0 : u + 1, s >= c && e - i >= 12 || e >= d && u >= 120 && e % 6 == 0) break;
		}
		let f = a.map((e) => ({
			rid: e.rid,
			kind: e.kind,
			spawnMs: e.spawnMs
		})), p = a.map((e) => e.track), m = a.filter((e) => e.kind === "marble").map((e) => ({
			rid: e.rid,
			kind: e.kind,
			finished: e.finished,
			finishMs: e.finishStep === null ? null : H((e.finishStep + 1) / 120 * 1e3),
			distance: H(Math.hypot(e.lastX, e.lastZ))
		}));
		m.sort((e, t) => e.finished === t.finished ? e.finished && t.finished ? (e.finishMs ?? 0) - (t.finishMs ?? 0) : e.distance - t.distance : e.finished ? -1 : 1);
		let h = m.filter((e) => !e.finished).length;
		return {
			marbles: f,
			tracks: p,
			sampleMs: 50,
			endMs: H(r * 50),
			order: m,
			stopped: h,
			cursor: o
		};
	} finally {
		l.free();
	}
}
//#endregion
//#region src/game/meta.ts
var U = {
	id: "whirlyderby",
	uuid: "a6b78339-edbb-4d1a-bd0b-e3387ee18743",
	tier: "alpha",
	mechanics: [
		"race",
		"push-your-luck",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.whirlyderby.name",
	descKey: "games.whirlyderby.desc",
	rulesKey: "games.whirlyderby.rules",
	icon: "🌀",
	iconImg: "games/whirlyderby.webp",
	rulesUrl: { en: "https://happypiranha.com/blogs/board-game-rules/how-to-play-whirly-derby-board-gme-rules-instructions" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [5],
	accent: "#e0552f",
	releasedAt: "2026-11-24T03:06:24+08:00",
	search: {
		py: "xuan feng jing su",
		init: "xfjs"
	},
	hotseat: "cover"
}, ve = r.enum([
	"cactus",
	"lamp",
	"donut",
	"cheese",
	"jelly",
	"none"
]), W = r.object({
	id: r.string(),
	points: r.number(),
	icon: ve
}), G = r.object({ advanced: r.boolean().default(!0) }).default({ advanced: !0 }), ye = r.object({
	count: r.number().int().min(0).max(5),
	thunderball: r.boolean()
}), be = r.discriminatedUnion("type", [
	r.object({ type: r.literal("reload") }),
	r.object({ type: r.literal("commit") }).extend(ye.shape),
	r.object({
		type: r.literal("pick"),
		card: r.string()
	}),
	r.object({
		type: r.literal("tick"),
		now: r.number()
	})
]), xe = r.object({
	rid: r.string(),
	kind: r.enum(["marble", "thunderball"]),
	spawnMs: r.number()
}), Se = r.object({
	marbles: r.array(xe),
	tracks: r.array(r.array(r.number())),
	sampleMs: r.number(),
	endMs: r.number()
}), Ce = r.object({
	rid: r.string(),
	finished: r.boolean()
}), we = r.object({
	order: r.array(Ce),
	thunderballDraw: r.object({
		owner: r.string(),
		stopped: r.number(),
		cards: r.array(W)
	}).nullable(),
	lastPlace: r.object({ rid: r.string() }).nullable()
}), Te = r.object({
	rid: r.string(),
	seat: r.number(),
	paddock: r.number(),
	box: r.number(),
	reloads: r.number(),
	score: r.number(),
	cards: r.array(W),
	submitted: r.boolean()
}), Ee = r.object({
	phase: r.enum([
		"select",
		"race",
		"pick",
		"ended"
	]),
	round: r.number(),
	advanced: r.boolean(),
	players: r.array(Te),
	prize: r.array(W),
	deckCount: r.number(),
	thunderball: r.object({
		owner: r.string(),
		available: r.boolean()
	}).nullable(),
	race: Se.nullable(),
	result: we.nullable(),
	picks: r.object({
		order: r.array(r.string()),
		index: r.number()
	}).nullable(),
	raceoff: r.object({
		players: r.array(r.string()),
		winner: r.string()
	}).nullable()
}), De = r.object({
	selection: ye.nullable(),
	canReload: r.boolean(),
	paddock: r.number(),
	thunderballHeld: r.boolean()
}), K = (e) => ({ code: e }), q = (e) => te[e] ?? {
	id: e,
	points: 0,
	icon: "none"
};
function Oe(e, t, r) {
	let i = r;
	for (let r = e.length - 1; r > 0; r--) {
		let a = n(t, i++, r + 1);
		[e[r], e[a]] = [e[a], e[r]];
	}
	return {
		items: e,
		cursor: i
	};
}
function J(e) {
	return Object.fromEntries(e.order.map((e) => [e, null]));
}
function ke(e, t) {
	let n = {
		cactus: 0,
		lamp: 0,
		donut: 0,
		cheese: 0,
		jelly: 0
	};
	for (let r of e.players[t].cards) {
		let e = q(r).icon;
		e !== "none" && (n[e] += 1);
	}
	return n;
}
function Y(e) {
	let t = {}, n = {};
	for (let r of e.order) {
		let i = e.players[r].cards.map(q).reduce((e, t) => e + t.points, 0), a = ke(e, r);
		n[r] = a, e.advanced && (i += k[Math.min(a.lamp, k.length - 1)], a.donut > 0 && a.cheese > 0 && a.jelly > 0 && (i += 30)), t[r] = i;
	}
	if (e.advanced) {
		let r = Math.max(0, ...e.order.map((e) => n[e].cactus));
		if (r > 0) for (let i of e.order) n[i].cactus === r && (t[i] += 15);
	}
	return t;
}
function Ae(e) {
	let t = Y(e), n = null, r = Infinity, i = Infinity;
	for (let a of e.order) {
		let o = e.players[a], s = o.paddock + o.box;
		(t[a] < r || t[a] === r && s < i) && (n = a, r = t[a], i = s);
	}
	n && (e.thunderball = {
		owner: n,
		available: !0
	});
}
function je(e) {
	e.phase = "select", e.selections = J(e), e.picks = null, e.race = null, e.result = null, e.raceMs = 0;
	for (let t of e.order) {
		let n = e.players[t];
		n.paddock === 0 && (n.box === 0 || n.reloads === 0) && (e.selections[t] = {
			count: 0,
			thunderball: !1
		});
	}
	e.advanced && e.tokens[e.round - 1] === "thunderball" && Ae(e), Pe(e);
}
function Me(e) {
	let t = Y(e), n = Math.max(...e.order.map((e) => t[e])), r = e.order.filter((e) => t[e] === n), i;
	if (r.length > 1) {
		let n = _e({
			entries: r.map((e) => ({
				rid: e,
				count: 1
			})),
			thunderball: null,
			seed: e.seed,
			cursor: e.cursor
		});
		e.cursor = n.cursor;
		let a = new Map(n.order.map((e, t) => [e.rid, t])), o = [...r].sort((e, t) => (a.get(e) ?? 99) - (a.get(t) ?? 99));
		i = [...o, ...e.order.filter((e) => !r.includes(e)).sort((n, r) => t[r] - t[n] || e.players[n].seat - e.players[r].seat)], e.raceoff = {
			players: r,
			winner: o[0]
		}, e.final = {
			scores: t,
			ranking: i,
			winner: [o[0]]
		};
	} else i = [...e.order].sort((n, r) => t[r] - t[n] || e.players[n].seat - e.players[r].seat), e.raceoff = null, e.final = {
		scores: t,
		ranking: i,
		winner: r
	};
	e.phase = "ended", e.picks = null;
}
function X(e) {
	if (e.picks = null, e.race = null, e.result = null, e.raceMs = 0, e.round >= 8) {
		Me(e);
		return;
	}
	e.round += 1, e.prize = e.deck.splice(0, 3), je(e);
}
function Ne(e) {
	let t = [];
	for (let n of e.order) {
		let r = e.selections[n];
		r && r.count !== 0 && t.push({
			rid: n,
			count: r.count
		});
	}
	let n = e.order.find((t) => e.selections[t]?.thunderball) ?? null, r = n !== null && e.thunderball !== null && e.thunderball.owner === n && e.thunderball.available ? { rid: n } : null;
	for (let t of e.order) {
		let n = e.selections[t];
		n && n.count !== 0 && (e.players[t].paddock -= n.count, e.players[t].box += n.count);
	}
	if (t.length === 0) {
		e.selections = J(e), r && (e.thunderball = null), X(e);
		return;
	}
	let i = _e({
		entries: t,
		thunderball: r,
		seed: e.seed,
		cursor: e.cursor
	});
	e.cursor = i.cursor, e.race = {
		marbles: i.marbles,
		tracks: i.tracks,
		sampleMs: i.sampleMs,
		endMs: i.endMs
	};
	let a = i.order.map((e) => ({
		rid: e.rid,
		finished: e.finished
	})), o = null;
	if (r) {
		let t = Math.min(3, i.stopped), n = t > 0 ? e.deck.splice(0, t) : [];
		n.length > 0 && e.players[r.rid].cards.push(...n), o = {
			owner: r.rid,
			stopped: i.stopped,
			cards: n
		}, e.thunderball = null;
	}
	let s = null;
	if (!r && a.length > 0) {
		let t = a[a.length - 1], n = e.players[t.rid];
		n.box > 0 && (--n.box, n.paddock += 1), s = { rid: t.rid };
	}
	let c = r ? a.filter((e) => e.finished).slice(0, 3).map((e) => e.rid) : a.slice(0, 3).map((e) => e.rid);
	e.result = {
		order: a,
		thunderballDraw: o,
		lastPlace: s
	}, e.picks = c.length > 0 ? {
		order: c,
		index: 0
	} : null, e.phase = "race", e.raceMs = Math.round(i.endMs + 1400), e.selections = J(e);
}
function Pe(e) {
	e.phase === "select" && e.order.every((t) => e.selections[t] !== null) && Ne(e);
}
function Fe(e, t, n) {
	let r = e;
	if (t.type === "tick") return n.by !== "$engine" || r.phase !== "race" ? K("games.whirlyderby.err.phase") : (r.picks && r.picks.index < r.picks.order.length ? r.phase = "pick" : X(r), { state: r });
	if (!r.order.includes(n.by)) return K("games.whirlyderby.err.notPlayer");
	if (t.type === "reload") {
		if (r.phase !== "select") return K("games.whirlyderby.err.phase");
		if (r.selections[n.by] !== null) return K("games.whirlyderby.err.committed");
		let e = r.players[n.by];
		return e.reloads <= 0 ? K("games.whirlyderby.err.noReload") : e.box <= 0 ? K("games.whirlyderby.err.emptyBox") : (e.paddock += e.box, e.box = 0, --e.reloads, { state: r });
	}
	if (t.type === "commit") {
		if (r.phase !== "select") return K("games.whirlyderby.err.phase");
		if (r.selections[n.by] !== null) return K("games.whirlyderby.err.committed");
		let e = r.players[n.by];
		if (t.count > e.paddock) return K("games.whirlyderby.err.tooMany");
		if (e.paddock > 0 && t.count < 1) return K("games.whirlyderby.err.mustEnter");
		if (e.paddock === 0 && t.count !== 0) return K("games.whirlyderby.err.noMarbles");
		let i = t.thunderball && r.advanced;
		if (i) {
			if (t.count < 1) return K("games.whirlyderby.err.thunderNeedsMarble");
			if (!r.thunderball || r.thunderball.owner !== n.by || !r.thunderball.available) return K("games.whirlyderby.err.noThunderball");
		}
		return r.selections[n.by] = {
			count: t.count,
			thunderball: i
		}, Pe(r), { state: r };
	}
	return t.type === "pick" ? r.phase !== "pick" || !r.picks ? K("games.whirlyderby.err.phase") : r.picks.order[r.picks.index] === n.by ? r.prize.includes(t.card) ? (r.players[n.by].cards.push(t.card), r.prize = r.prize.filter((e) => e !== t.card), r.picks.index += 1, r.picks.index >= r.picks.order.length && X(r), { state: r }) : K("games.whirlyderby.err.badPick") : K("games.whirlyderby.err.notTurn") : K("games.whirlyderby.err.phase");
}
var Ie = {
	meta: U,
	saveCompatibility: {
		version: "4",
		migrate: () => null
	},
	schemas: {
		action: be,
		publicView: Ee,
		privateView: De,
		config: G
	},
	setup(e, t, n) {
		let r = G.parse(e ?? {}), i = [...t], a = 0, o = Oe(O.map((e) => e.id), n, a);
		a = o.cursor;
		let s = ["standard", "standard"];
		if (r.advanced) {
			let e = Oe([
				"standard",
				"standard",
				"standard",
				"standard",
				"thunderball",
				"thunderball"
			], n, a);
			a = e.cursor, s.push(...e.items);
		} else for (let e = 0; e < 6; e++) s.push("standard");
		let c = {
			phase: "select",
			order: i,
			round: 1,
			advanced: r.advanced,
			seed: n,
			cursor: a,
			deck: o.items,
			prize: o.items.splice(0, 3),
			tokens: s,
			players: Object.fromEntries(i.map((e, t) => [e, {
				seat: t,
				paddock: 5,
				box: 0,
				reloads: 2,
				cards: []
			}])),
			selections: {},
			thunderball: null,
			race: null,
			result: null,
			picks: null,
			raceMs: 0,
			raceoff: null,
			final: null
		};
		return je(c), Pe(c), { state: c };
	},
	reduce: Fe,
	viewFor(e, t) {
		let n = Y(e);
		return {
			public: {
				phase: e.phase,
				round: e.round,
				advanced: e.advanced,
				players: e.order.map((t) => ({
					rid: t,
					seat: e.players[t].seat,
					paddock: e.players[t].paddock,
					box: e.players[t].box,
					reloads: e.players[t].reloads,
					score: n[t],
					cards: e.players[t].cards.map(q),
					submitted: e.selections[t] !== null
				})),
				prize: e.prize.map(q),
				deckCount: e.deck.length,
				thunderball: e.thunderball ? {
					owner: e.thunderball.owner,
					available: e.thunderball.available
				} : null,
				race: e.race,
				result: e.result ? {
					order: e.result.order,
					thunderballDraw: e.result.thunderballDraw ? {
						owner: e.result.thunderballDraw.owner,
						stopped: e.result.thunderballDraw.stopped,
						cards: e.result.thunderballDraw.cards.map(q)
					} : null,
					lastPlace: e.result.lastPlace
				} : null,
				picks: e.picks,
				raceoff: e.raceoff
			},
			private: {
				selection: e.selections[t] ?? null,
				canReload: e.phase === "select" && e.selections[t] === null && e.players[t] !== void 0 && e.players[t].reloads > 0 && e.players[t].box > 0,
				paddock: e.players[t]?.paddock ?? 0,
				thunderballHeld: e.thunderball !== null && e.thunderball.owner === t && e.thunderball.available
			}
		};
	},
	status(e) {
		return e.phase !== "ended" || !e.final ? { phase: e.phase } : {
			phase: e.phase,
			winner: e.final.winner,
			ranking: e.final.ranking,
			scores: e.final.scores
		};
	},
	nextTickIn(e) {
		return e.phase === "race" ? e.raceMs : null;
	}
}, Le = 40, Z = -.72, Re = F(3), ze = .64, Be = 1.02, Ve = 7, He = 2.4, Ue = -.3, We = 640, Q = 18;
function Ge() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function Ke(e, t) {
	let n = new v.BufferGeometry();
	n.setAttribute("position", new v.BufferAttribute(e.positions, 3)), n.setIndex(new v.BufferAttribute(e.indices, 1));
	let r = e.positions.length / 3, i = new Float32Array(r * 2), a = Infinity, o = -Infinity;
	for (let t = 0; t < r; t++) {
		let n = e.positions[t * 3 + 1];
		n < a && (a = n), n > o && (o = n);
	}
	let s = o - a || 1;
	for (let n = 0; n < r; n++) {
		let r = e.positions[n * 3], o = e.positions[n * 3 + 1], c = e.positions[n * 3 + 2];
		t === "surface" ? (i[n * 2] = r / 6 + .5, i[n * 2 + 1] = c / 6 + .5) : (i[n * 2] = (Math.atan2(c, r) + Math.PI) / (Math.PI * 2), i[n * 2 + 1] = (o - a) / s);
	}
	return n.setAttribute("uv", new v.BufferAttribute(i, 2)), n.computeVertexNormals(), n;
}
function qe(e) {
	let t = e >>> 0;
	return () => (t = t * 1664525 + 1013904223 >>> 0, t / 4294967296);
}
function $(e, t, n) {
	let r = document.createElement("canvas");
	r.width = e, r.height = t;
	let i = r.getContext("2d");
	if (!i) return null;
	n(i);
	let a = new v.CanvasTexture(r);
	return a.colorSpace = v.SRGBColorSpace, a.anisotropy = 4, a;
}
function Je() {
	return $(512, 512, (e) => {
		let t = qe(6221057), n = e.createRadialGradient(256, 256, 24, 256, 256, 356);
		n.addColorStop(0, "#2a6662"), n.addColorStop(.55, "#1c5252"), n.addColorStop(1, "#0e3537"), e.fillStyle = n, e.fillRect(0, 0, 512, 512), e.lineWidth = 1;
		for (let t = 0; t < 512; t += 4) e.strokeStyle = t % 8 == 0 ? "rgba(190, 233, 216, 0.035)" : "rgba(4, 26, 27, 0.045)", e.beginPath(), e.moveTo(0, t + .5), e.lineTo(512, t + .5), e.stroke(), e.strokeStyle = "rgba(4, 26, 27, 0.03)", e.beginPath(), e.moveTo(t + .5, 0), e.lineTo(t + .5, 512), e.stroke();
		for (let n = 0; n < 1600; n++) e.fillStyle = t() > .5 ? "rgba(217, 244, 228, 0.05)" : "rgba(2, 18, 19, 0.06)", e.beginPath(), e.arc(t() * 512, t() * 512, .5 + t() * 1.6, 0, Math.PI * 2), e.fill();
	});
}
function Ye() {
	return $(512, 512, (e) => {
		let t = qe(11575792), n = e.createRadialGradient(256, 256, 26, 256, 256, 332);
		n.addColorStop(0, "#ff9560"), n.addColorStop(.4, "#f06633"), n.addColorStop(.78, "#d9471f"), n.addColorStop(1, "#a92f15"), e.fillStyle = n, e.fillRect(0, 0, 512, 512);
		for (let n = 0; n < 150; n++) {
			let n = 40 + t() * 250, r = t() * Math.PI * 2, i = .25 + t() * 1.1;
			e.strokeStyle = t() > .5 ? `rgba(255, 210, 160, ${.04 + t() * .08})` : `rgba(94, 24, 6, ${.03 + t() * .06})`, e.lineWidth = 1 + t() * 5, e.beginPath(), e.arc(256, 256, n, r, r + i), e.stroke();
		}
		for (let t = 64; t < 324; t += 26) e.lineWidth = 2, e.strokeStyle = "rgba(80, 20, 5, 0.1)", e.beginPath(), e.arc(256, 256, t, 0, Math.PI * 2), e.stroke(), e.strokeStyle = "rgba(255, 205, 150, 0.08)", e.beginPath(), e.arc(256, 256, t + 2, 0, Math.PI * 2), e.stroke();
		for (let n = 0; n < 700; n++) e.fillStyle = t() > .5 ? "rgba(255, 225, 190, 0.05)" : "rgba(88, 22, 6, 0.05)", e.beginPath(), e.arc(t() * 512, t() * 512, .4 + t() * 1.2, 0, Math.PI * 2), e.fill();
	});
}
function Xe() {
	return $(512, 256, (e) => {
		let t = e.createLinearGradient(0, 0, 0, 256);
		t.addColorStop(0, "#70cae2"), t.addColorStop(.5, "#3a97ba"), t.addColorStop(1, "#226c89"), e.fillStyle = t, e.fillRect(0, 0, 512, 256);
		for (let t = 0; t < 512; t += 64) e.fillStyle = "rgba(9, 48, 60, 0.14)", e.fillRect(t, 0, 3, 256), e.fillStyle = "rgba(214, 245, 255, 0.1)", e.fillRect(t + 3, 0, 2, 256);
		for (let t = 0; t < 256; t += 3) e.fillStyle = t % 6 == 0 ? "rgba(255, 255, 255, 0.03)" : "rgba(6, 40, 52, 0.03)", e.fillRect(0, t, 512, 1);
		for (let t = 32; t < 512; t += 64) for (let n of [18, 238]) e.fillStyle = "rgba(8, 42, 54, 0.35)", e.beginPath(), e.arc(t, n, 3.2, 0, Math.PI * 2), e.fill(), e.fillStyle = "rgba(222, 250, 255, 0.35)", e.beginPath(), e.arc(t - 1, n - 1, 1.4, 0, Math.PI * 2), e.fill();
	});
}
function Ze() {
	return $(512, 512, (e) => {
		let t = e.createRadialGradient(256, 180, 30, 256, 260, 420);
		t.addColorStop(0, "#ffe9c4"), t.addColorStop(.45, "#e5c99b"), t.addColorStop(.75, "#a9845c"), t.addColorStop(1, "#4c3826"), e.fillStyle = t, e.fillRect(0, 0, 512, 512), e.globalAlpha = .05, e.fillStyle = "#fff4de";
		for (let t = -6; t < 7; t++) e.beginPath(), e.moveTo(256, 120), e.lineTo(256 + t * 54 - 12, 512), e.lineTo(256 + t * 54 + 12, 512), e.closePath(), e.fill();
		e.globalAlpha = 1;
	});
}
function Qe(e, t, n) {
	let r = Math.floor(e.length / 3);
	if (r === 0) return null;
	let i = Math.max(0, t / n), a = Math.min(r - 1, Math.floor(i)), o = Math.min(r - 1, a + 1), s = Math.min(1, Math.max(0, i - a));
	return [
		e[a * 3] + (e[o * 3] - e[a * 3]) * s,
		e[a * 3 + 1] + (e[o * 3 + 1] - e[a * 3 + 1]) * s,
		e[a * 3 + 2] + (e[o * 3 + 2] - e[a * 3 + 2]) * s
	];
}
function $e() {
	let e = a(() => Ke(I(), "surface"), []), t = a(() => Ke(L(), "wall"), []), n = a(() => Ye(), []), r = a(() => Xe(), []);
	i(() => () => {
		e.dispose(), t.dispose(), n?.dispose(), r?.dispose();
	}, [
		e,
		t,
		n,
		r
	]);
	let o = a(() => [
		1.4,
		2.15,
		2.85
	], []);
	return /* @__PURE__ */ C("group", { children: [
		/* @__PURE__ */ S("mesh", {
			geometry: e,
			receiveShadow: !0,
			children: /* @__PURE__ */ S("meshStandardMaterial", {
				map: n,
				color: "#ffffff",
				roughness: .46,
				metalness: .05,
				side: v.DoubleSide
			})
		}),
		/* @__PURE__ */ S("mesh", {
			geometry: t,
			castShadow: !0,
			receiveShadow: !0,
			children: /* @__PURE__ */ S("meshStandardMaterial", {
				map: r,
				color: "#ffffff",
				roughness: .5,
				metalness: .08,
				side: v.DoubleSide
			})
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				Re + N,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			castShadow: !0,
			children: [/* @__PURE__ */ S("torusGeometry", { args: [
				3,
				.06,
				10,
				96
			] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#f7e5c2",
				roughness: .38,
				metalness: .12
			})]
		}),
		o.map((e) => /* @__PURE__ */ C("mesh", {
			position: [
				0,
				F(e) + .012,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("torusGeometry", { args: [
				e,
				.011,
				6,
				96
			] }), /* @__PURE__ */ S("meshBasicMaterial", {
				color: "#ffd0a0",
				transparent: !0,
				opacity: .45
			})]
		}, e)),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				-.24,
				0
			],
			children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
				M,
				M * .8,
				.48,
				48,
				1,
				!0
			] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#131b20",
				roughness: .9,
				side: v.DoubleSide
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				.006,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("circleGeometry", { args: [M, 48] }), /* @__PURE__ */ S("meshBasicMaterial", { color: "#080e11" })]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				.02,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("torusGeometry", { args: [
				M,
				.025,
				8,
				64
			] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#ffcf7a",
				roughness: .3,
				metalness: .65,
				emissive: "#4a2c00",
				emissiveIntensity: .3
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				(Re + Z) / 2,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
				3.02,
				3.02,
				Re - Z,
				72,
				1,
				!0
			] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#b73d22",
				roughness: .65,
				side: v.DoubleSide
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				-.63,
				0
			],
			castShadow: !0,
			receiveShadow: !0,
			children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
				3.24,
				3.12,
				.18,
				72
			] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#a2381f",
				roughness: .7
			})]
		})
	] });
}
function et() {
	let e = a(() => Je(), []);
	return i(() => () => e?.dispose(), [e]), /* @__PURE__ */ C("group", { children: [
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				Z,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			receiveShadow: !0,
			children: [/* @__PURE__ */ S("circleGeometry", { args: [7.2, 96] }), /* @__PURE__ */ S("meshStandardMaterial", {
				map: e,
				color: "#ffffff",
				roughness: .94
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				-.715,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("ringGeometry", { args: [
				4.55,
				4.7,
				96
			] }), /* @__PURE__ */ S("meshBasicMaterial", {
				color: "#e7d3b0",
				transparent: !0,
				opacity: .42
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				-.715,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("ringGeometry", { args: [
				6.6,
				6.78,
				96
			] }), /* @__PURE__ */ S("meshBasicMaterial", {
				color: "#e7d3b0",
				transparent: !0,
				opacity: .3
			})]
		}),
		/* @__PURE__ */ C("mesh", {
			position: [
				0,
				-.76,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ S("circleGeometry", { args: [7.35, 96] }), /* @__PURE__ */ S("meshStandardMaterial", {
				color: "#0c2a2b",
				roughness: .95
			})]
		})
	] });
}
function tt({ player: e, seatCount: t, color: n }) {
	let r = e.seat / t * Math.PI * 2, i = Math.cos(r) * 3.95, a = Math.sin(r) * 3.95, o = Array.from({ length: Math.min(e.paddock, 5) }, (e, t) => t), s = Array.from({ length: Math.min(e.reloads, 2) }, (e, t) => t);
	return /* @__PURE__ */ C("group", {
		position: [
			i,
			Z,
			a
		],
		children: [
			/* @__PURE__ */ C("mesh", {
				position: [
					0,
					.055,
					0
				],
				castShadow: !0,
				receiveShadow: !0,
				children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
					.62,
					.66,
					.11,
					36
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: n,
					roughness: .48,
					metalness: .05
				})]
			}),
			/* @__PURE__ */ C("mesh", {
				position: [
					0,
					.113,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ S("ringGeometry", { args: [
					.5,
					.6,
					36
				] }), /* @__PURE__ */ S("meshBasicMaterial", {
					color: "#f6e7cd",
					transparent: !0,
					opacity: .8
				})]
			}),
			/* @__PURE__ */ S("group", {
				position: [
					0,
					.13,
					0
				],
				children: o.map((e) => {
					let t = e % 3, r = Math.floor(e / 3);
					return /* @__PURE__ */ C("mesh", {
						position: [
							(t - 1) * .34,
							A * .9 + r * .29,
							-.1 + r * .02
						],
						castShadow: !0,
						children: [/* @__PURE__ */ S("sphereGeometry", { args: [
							A,
							18,
							14
						] }), /* @__PURE__ */ S("meshPhysicalMaterial", {
							color: n,
							roughness: .2,
							metalness: .04,
							clearcoat: 1,
							clearcoatRoughness: .1
						})]
					}, e);
				})
			}),
			s.map((e, t) => /* @__PURE__ */ C("mesh", {
				position: [
					.42 - t * .22,
					.13,
					.42
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				castShadow: !0,
				children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
					.1,
					.1,
					.035,
					20
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#f6e7cd",
					roughness: .45
				})]
			}, `r${e}`))
		]
	});
}
function nt({ active: e }) {
	return /* @__PURE__ */ C("group", {
		position: [
			0,
			Z,
			3.32
		],
		children: [
			/* @__PURE__ */ C("mesh", {
				position: [
					0,
					.16,
					0
				],
				castShadow: !0,
				receiveShadow: !0,
				children: [/* @__PURE__ */ S("cylinderGeometry", { args: [
					.24,
					.2,
					.32,
					24
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#f6e7cd",
					roughness: .5,
					metalness: .04
				})]
			}),
			/* @__PURE__ */ C("mesh", {
				position: [
					0,
					.325,
					0
				],
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ S("torusGeometry", { args: [
					.235,
					.028,
					8,
					28
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#ffcf7a",
					roughness: .35,
					metalness: .35
				})]
			}),
			e && /* @__PURE__ */ C("group", {
				position: [
					0,
					.46,
					0
				],
				children: [/* @__PURE__ */ C("mesh", {
					position: [
						.28,
						0,
						0
					],
					castShadow: !0,
					children: [/* @__PURE__ */ S("boxGeometry", { args: [
						.36,
						.05,
						.1
					] }), /* @__PURE__ */ S("meshStandardMaterial", {
						color: "#ffcf7a",
						roughness: .35,
						metalness: .2,
						emissive: "#7a5200",
						emissiveIntensity: .25
					})]
				}), /* @__PURE__ */ C("mesh", {
					position: [
						.5,
						0,
						0
					],
					rotation: [
						0,
						0,
						-Math.PI / 2
					],
					castShadow: !0,
					children: [/* @__PURE__ */ S("coneGeometry", { args: [
						.09,
						.18,
						12
					] }), /* @__PURE__ */ S("meshStandardMaterial", {
						color: "#ffcf7a",
						roughness: .35,
						metalness: .2,
						emissive: "#7a5200",
						emissiveIntensity: .25
					})]
				})]
			})
		]
	});
}
function rt({ race: e, phase: t, reducedMotion: n, colorOf: r }) {
	let s = o([]), c = o(null), l = `${e.marbles.length}:${e.endMs}:${e.tracks.length}`, u = o(Array.from({ length: Q }, () => ({
		start: -1,
		color: "#ffffff"
	}))), d = o([]), f = o(0), p = a(() => {
		let t = [];
		return e.marbles.forEach((n, i) => {
			let a = e.tracks[i];
			if (!a) return;
			let o = -1;
			for (let e = 0; e * 3 + 1 < a.length; e++) if (a[e * 3 + 1] < Ue) {
				o = e;
				break;
			}
			o < 0 || t.push({
				at: n.spawnMs + o * e.sampleMs,
				color: n.kind === "thunderball" ? "#ffc23d" : r(n.rid)
			});
		}), t.sort((e, t) => e.at - t.at), t;
	}, [e, r]);
	return i(() => {
		c.current = null, f.current = 0;
		for (let e of u.current) e.start = -1;
	}, [l]), g(() => {
		c.current === null && (c.current = performance.now());
		let r = t === "pick" || n ? e.endMs : performance.now() - c.current;
		if (e.marbles.forEach((t, n) => {
			let i = s.current[n];
			if (!i) return;
			if (!t || r < t.spawnMs) {
				i.visible = !1;
				return;
			}
			let a = Qe(e.tracks[n] ?? [], r - t.spawnMs, e.sampleMs);
			if (!a || a[1] < -.3) {
				i.visible = !1;
				return;
			}
			i.visible = !0, i.position.set(a[0], a[1], a[2]);
		}), !(t !== "race" || n)) {
			for (; f.current < p.length && p[f.current].at <= r;) {
				let e = u.current[f.current % Q], t = d.current[f.current % Q];
				e.start = r, e.color = p[f.current].color, t && t.material.color.set(e.color), f.current += 1;
			}
			u.current.forEach((e, t) => {
				let n = d.current[t];
				if (!n) return;
				let i = e.start < 0 ? Infinity : r - e.start;
				if (i < We) {
					let e = i / We;
					n.visible = !0, n.scale.setScalar(.75 + e * 2.3), n.material.opacity = (1 - e) ** 1.5 * .9;
				} else n.visible &&= !1;
			});
		}
	}), /* @__PURE__ */ C(x, { children: [e.marbles.map((e, t) => /* @__PURE__ */ S("group", {
		ref: (e) => {
			s.current[t] = e;
		},
		visible: !1,
		children: e.kind === "thunderball" ? /* @__PURE__ */ C("group", { children: [
			/* @__PURE__ */ C("mesh", {
				castShadow: !0,
				children: [/* @__PURE__ */ S("sphereGeometry", { args: [
					j,
					32,
					24
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#333b45",
					roughness: .34,
					metalness: .45
				})]
			}),
			/* @__PURE__ */ C("mesh", {
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ S("torusGeometry", { args: [
					j * .93,
					.09,
					10,
					48
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#ffc23d",
					roughness: .35,
					metalness: .4,
					emissive: "#9a6400",
					emissiveIntensity: .4
				})]
			}),
			/* @__PURE__ */ C("mesh", {
				position: [
					0,
					j * .72,
					0
				],
				children: [/* @__PURE__ */ S("sphereGeometry", { args: [
					j * .32,
					18,
					14
				] }), /* @__PURE__ */ S("meshStandardMaterial", {
					color: "#4a5361",
					roughness: .4,
					metalness: .3
				})]
			})
		] }) : /* @__PURE__ */ C("mesh", {
			castShadow: !0,
			children: [/* @__PURE__ */ S("sphereGeometry", { args: [
				A,
				22,
				16
			] }), /* @__PURE__ */ S("meshPhysicalMaterial", {
				color: r(e.rid),
				roughness: .18,
				metalness: .04,
				clearcoat: 1,
				clearcoatRoughness: .08
			})]
		})
	}, `${e.rid}:${t}`)), /* @__PURE__ */ S("group", {
		visible: t === "race" && !n,
		children: Array.from({ length: Q }, (e, t) => /* @__PURE__ */ C("mesh", {
			ref: (e) => {
				d.current[t] = e;
			},
			visible: !1,
			position: [
				0,
				.045,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			renderOrder: 2,
			children: [/* @__PURE__ */ S("ringGeometry", { args: [
				.46,
				.64,
				40
			] }), /* @__PURE__ */ S("meshBasicMaterial", {
				transparent: !0,
				opacity: 0,
				depthWrite: !1,
				blending: v.AdditiveBlending,
				side: v.DoubleSide
			})]
		}, t))
	})] });
}
function it({ active: e }) {
	let t = _((e) => e.invalidate);
	return i(() => {
		if (!e) return;
		let n = 0, r = 0, i = (e) => {
			document.visibilityState === "visible" && e - r >= 33 && (t(), r = e), n = requestAnimationFrame(i);
		};
		return n = requestAnimationFrame(i), () => cancelAnimationFrame(n);
	}, [e, t]), null;
}
function at({ pan: e, resetKey: t, overhead: n, elevationRef: r }) {
	let a = _((e) => e.size), s = _((e) => e.invalidate);
	i(() => {
		s();
	}, [n, s]);
	let c = o(new v.Vector3(0, .45, 0)), l = o(new v.Vector3()), u = o(new v.Vector3()), d = o(!1), f = o(t);
	return g(({ camera: i }, o) => {
		f.current !== t && (f.current = t, d.current = !1);
		let p = n ? Be : ze, m = r.current + (p - r.current) * (1 - Math.exp(-o * Ve));
		r.current = Math.abs(p - m) < .001 ? p : m, r.current !== p && s();
		let h = Math.tan(Le * Math.PI / 360), g = Math.max(.35, a.width / Math.max(1, a.height)), _ = 3.55 / h, v = 4.55 / (h * g), y = Math.min(1, Math.max(0, (r.current - ze) / .38)), b = Math.max(_, v) * e.current.zoom * (1 + .10000000000000009 * y);
		if (l.current.set(e.current.x, .45, e.current.z), u.current.set(l.current.x, l.current.y + Math.sin(r.current) * b, l.current.z + Math.cos(r.current) * b), !d.current) i.position.copy(u.current), c.current.copy(l.current), d.current = !0;
		else {
			let e = 1 - Math.exp(-o * 14);
			i.position.lerp(u.current, e), c.current.lerp(l.current, e);
		}
		i.lookAt(c.current);
	}), null;
}
function ot({ pub: e, members: t }) {
	let n = l(), r = b(), [c, u] = s(0), f = o({
		x: 0,
		z: 0,
		zoom: 1
	}), p = o(ze), m = o(/* @__PURE__ */ new Map()), h = o(null), g = o(() => {}), _ = a(() => Ze(), []);
	i(() => () => _?.dispose(), [_]);
	let x = (e) => {
		let n = t.find((t) => t.rid === e);
		return d[(n?.colorIndex ?? 0) % d.length].hex;
	}, w = e.race, T = e.players.length;
	return /* @__PURE__ */ C("div", {
		className: "wd-scene",
		children: [
			/* @__PURE__ */ C(y, {
				className: "wd-canvas",
				shadows: !0,
				gl: {
					antialias: !0,
					powerPreference: "low-power"
				},
				dpr: [1, 2],
				frameloop: "demand",
				camera: {
					fov: Le,
					near: .1,
					far: 120
				},
				onCreated: ({ gl: e, invalidate: t }) => {
					g.current = t, e.outputColorSpace = v.SRGBColorSpace, e.toneMapping = v.ACESFilmicToneMapping, e.toneMappingExposure = 1.06, e.shadowMap.type = v.PCFSoftShadowMap;
				},
				children: [
					_ ? /* @__PURE__ */ S("primitive", {
						attach: "background",
						object: _
					}) : /* @__PURE__ */ S("color", {
						attach: "background",
						args: ["#d8bd92"]
					}),
					/* @__PURE__ */ S("hemisphereLight", { args: [
						"#ffeccb",
						"#0d3436",
						1.15
					] }),
					/* @__PURE__ */ S("ambientLight", { intensity: .26 }),
					/* @__PURE__ */ S("directionalLight", {
						castShadow: !0,
						color: "#ffe2b4",
						intensity: 2.5,
						position: [
							-6,
							13,
							9
						],
						"shadow-mapSize-width": 1024,
						"shadow-mapSize-height": 1024,
						"shadow-camera-left": -8,
						"shadow-camera-right": 8,
						"shadow-camera-top": 8,
						"shadow-camera-bottom": -8,
						"shadow-camera-near": 1,
						"shadow-camera-far": 40,
						"shadow-bias": -4e-4,
						"shadow-normalBias": .02
					}),
					/* @__PURE__ */ S("directionalLight", {
						color: "#9edcf0",
						intensity: .8,
						position: [
							9,
							7,
							-10
						]
					}),
					/* @__PURE__ */ S("directionalLight", {
						color: "#ffb27c",
						intensity: .5,
						position: [
							0,
							5,
							-12
						]
					}),
					/* @__PURE__ */ S("pointLight", {
						color: "#ffcf7a",
						intensity: 1.5,
						distance: 3.2,
						decay: 2,
						position: [
							0,
							.9,
							0
						]
					}),
					/* @__PURE__ */ S(it, { active: e.phase === "race" && !r }),
					/* @__PURE__ */ S(at, {
						pan: f,
						resetKey: c,
						overhead: e.phase === "race",
						elevationRef: p
					}),
					/* @__PURE__ */ S(et, {}),
					/* @__PURE__ */ S($e, {}),
					/* @__PURE__ */ S(nt, { active: e.phase === "select" }),
					e.players.map((e) => /* @__PURE__ */ S(tt, {
						player: e,
						seatCount: T,
						color: x(e.rid)
					}, e.rid)),
					e.thunderball && (() => {
						let t = e.players.find((t) => t.rid === e.thunderball?.owner);
						if (!t) return null;
						let n = t.seat / T * Math.PI * 2;
						return /* @__PURE__ */ C("mesh", {
							position: [
								Math.cos(n) * 3.95,
								-.52,
								Math.sin(n) * 3.95
							],
							rotation: [
								-Math.PI / 2,
								0,
								0
							],
							children: [/* @__PURE__ */ S("torusGeometry", { args: [
								.52,
								.035,
								8,
								40
							] }), /* @__PURE__ */ S("meshStandardMaterial", {
								color: "#ffc23d",
								roughness: .4,
								emissive: "#7a5200",
								emissiveIntensity: .3
							})]
						});
					})(),
					w && /* @__PURE__ */ S(rt, {
						race: w,
						phase: e.phase,
						reducedMotion: r,
						colorOf: x
					})
				]
			}),
			/* @__PURE__ */ S("div", {
				className: "wd-pan",
				"aria-label": n("games.whirlyderby.ui.tapHint"),
				onPointerDown: (e) => {
					if (m.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), m.current.size === 2) {
						let [e, t] = [...m.current.values()];
						h.current = Math.hypot(e.x - t.x, e.y - t.y);
					}
					e.currentTarget.setPointerCapture(e.pointerId);
				},
				onPointerMove: (e) => {
					let t = m.current.get(e.pointerId);
					if (!t) return;
					let n = e.clientX - t.x, r = e.clientY - t.y;
					if (m.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), m.current.size >= 2) {
						let [e, t] = [...m.current.values()], n = Math.hypot(e.x - t.x, e.y - t.y);
						h.current && n > 0 && (f.current.zoom = Math.max(.62, Math.min(2.4, f.current.zoom * h.current / n))), h.current = n;
					} else {
						let e = .011 * f.current.zoom;
						f.current.x = Math.max(-2.4, Math.min(He, f.current.x - n * e)), f.current.z = Math.max(-2.4, Math.min(He, f.current.z - r * e * Math.sin(p.current)));
					}
					g.current();
				},
				onPointerUp: (e) => {
					m.current.delete(e.pointerId), h.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
				},
				onPointerCancel: (e) => {
					m.current.delete(e.pointerId), h.current = null;
				},
				onLostPointerCapture: (e) => {
					m.current.delete(e.pointerId), h.current = null;
				},
				onWheel: (e) => {
					e.preventDefault(), f.current.zoom = Math.max(.62, Math.min(2.4, f.current.zoom * Math.exp(e.deltaY * .001))), g.current();
				}
			}),
			/* @__PURE__ */ S("button", {
				type: "button",
				className: "wd-recenter",
				"aria-label": n("games.whirlyderby.ui.recenter"),
				title: n("games.whirlyderby.ui.recenter"),
				onClick: () => {
					f.current.x = 0, f.current.z = 0, f.current.zoom = 1, u((e) => e + 1);
				},
				children: /* @__PURE__ */ C("svg", {
					width: "20",
					height: "20",
					viewBox: "0 0 24 24",
					"aria-hidden": !0,
					children: [
						/* @__PURE__ */ S("circle", {
							cx: "12",
							cy: "12",
							r: "7",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ S("circle", {
							cx: "12",
							cy: "12",
							r: "2.2",
							fill: "currentColor"
						}),
						/* @__PURE__ */ S("path", {
							d: "M12 2v3M12 19v3M2 12h3M19 12h3",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round"
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/trophy-icon.tsx
function st({ icon: e, size: t = 28 }) {
	let n = {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": !0
	};
	switch (e) {
		case "cactus": return /* @__PURE__ */ C("svg", {
			...n,
			children: [
				/* @__PURE__ */ S("path", {
					d: "M13 27h6V12c0-2.2-.9-3.5-3-3.5S13 9.8 13 12z",
					fill: "#3f8f4b",
					stroke: "#173d1f",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M13 17H9.5c-1.6 0-2.5-1-2.5-2.6V12",
					fill: "none",
					stroke: "#173d1f",
					strokeWidth: "4.4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M13 17H9.5c-1.6 0-2.5-1-2.5-2.6V12",
					fill: "none",
					stroke: "#54a85f",
					strokeWidth: "2.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M19 14h3c1.5 0 2.4-1 2.4-2.5V9",
					fill: "none",
					stroke: "#173d1f",
					strokeWidth: "4.4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M19 14h3c1.5 0 2.4-1 2.4-2.5V9",
					fill: "none",
					stroke: "#54a85f",
					strokeWidth: "2.2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M13 27h6",
					stroke: "#173d1f",
					strokeWidth: "1.8",
					strokeLinecap: "round",
					opacity: "0"
				})
			]
		});
		case "lamp": return /* @__PURE__ */ C("svg", {
			...n,
			children: [
				/* @__PURE__ */ S("defs", { children: /* @__PURE__ */ C("linearGradient", {
					id: "wd-lamp",
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [
						/* @__PURE__ */ S("stop", {
							offset: "0",
							stopColor: "#ff8a5c"
						}),
						/* @__PURE__ */ S("stop", {
							offset: ".55",
							stopColor: "#f24d7c"
						}),
						/* @__PURE__ */ S("stop", {
							offset: "1",
							stopColor: "#b5326f"
						})
					]
				}) }),
				/* @__PURE__ */ S("path", {
					d: "M12.5 5h7l3.2 17.2c.2 1.2-.6 2.3-1.8 2.3H11.1c-1.2 0-2-1.1-1.8-2.3z",
					fill: "url(#wd-lamp)",
					stroke: "#3c1632",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ S("ellipse", {
					cx: "16",
					cy: "24.4",
					rx: "6.6",
					ry: "2.6",
					fill: "#ffcf7a",
					opacity: ".85"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "16",
					cy: "20",
					r: "2.1",
					fill: "#ffe9b8"
				}),
				/* @__PURE__ */ S("path", {
					d: "M13 9.5C14.2 8 17.8 8 19 9.5",
					fill: "none",
					stroke: "#ffd9a1",
					strokeWidth: "1.6",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M11.4 26.2h9.2",
					stroke: "#3c1632",
					strokeWidth: "2.4",
					strokeLinecap: "round"
				})
			]
		});
		case "donut": return /* @__PURE__ */ C("svg", {
			...n,
			children: [
				/* @__PURE__ */ S("circle", {
					cx: "16",
					cy: "16",
					r: "11",
					fill: "#e9a86a",
					stroke: "#5c3218",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "16",
					cy: "16",
					r: "7.2",
					fill: "#f7c7d8",
					stroke: "#5c3218",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "16",
					cy: "16",
					r: "3.2",
					fill: "#fdf3e3",
					stroke: "#5c3218",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ S("path", {
					d: "M11 9.5l1.6 1.2M21 10l-1 1.7M23 16.5l-1.8.4M9 17l1.5-.6M13 23l.6-1.6M19.5 22.5l-1.4-1",
					stroke: "#7d3f8f",
					strokeWidth: "2",
					strokeLinecap: "round"
				})
			]
		});
		case "cheese": return /* @__PURE__ */ C("svg", {
			...n,
			children: [
				/* @__PURE__ */ S("path", {
					d: "M4.5 22.5 16 6l11.5 16.5z",
					fill: "#f6c744",
					stroke: "#5d4412",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M4.5 22.5h23l-2.2 3.2H6.7z",
					fill: "#e0a92b",
					stroke: "#5d4412",
					strokeWidth: "1.6",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "13.5",
					cy: "18",
					r: "1.9",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "19.5",
					cy: "20.5",
					r: "1.3",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ S("circle", {
					cx: "17",
					cy: "13.4",
					r: "1.1",
					fill: "#e8b02f",
					stroke: "#5d4412",
					strokeWidth: "1"
				})
			]
		});
		case "jelly": return /* @__PURE__ */ C("svg", {
			...n,
			children: [
				/* @__PURE__ */ S("path", {
					d: "M16 4.5c2 3.4 7.6 7.8 7.6 13.6 0 4.6-3.4 7.4-7.6 7.4s-7.6-2.8-7.6-7.4C8.4 12.3 14 7.9 16 4.5z",
					fill: "#d0528f",
					stroke: "#4a1233",
					strokeWidth: "1.8",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ S("path", {
					d: "M11.4 18.6c0-3 2.1-5.6 3.8-7.6",
					fill: "none",
					stroke: "#ffcfe4",
					strokeWidth: "2",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ S("ellipse", {
					cx: "16",
					cy: "27",
					rx: "8.4",
					ry: "2.3",
					fill: "#f6e3cf",
					stroke: "#4a1233",
					strokeWidth: "1.6"
				})
			]
		});
		default: return /* @__PURE__ */ S("svg", {
			...n,
			children: /* @__PURE__ */ S("circle", {
				cx: "16",
				cy: "16",
				r: "8",
				fill: "none",
				stroke: "#9a8a72",
				strokeWidth: "1.8",
				strokeDasharray: "3.2 3"
			})
		});
	}
}
function ct({ card: e, size: t = "md", selected: n = !1, dimmed: r = !1, onClick: i, ariaLabel: a }) {
	let o = t === "lg" ? 42 : t === "sm" ? 23 : 30, s = /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("span", {
		className: "wd-card-points",
		children: e.points
	}), /* @__PURE__ */ S("span", {
		className: "wd-card-icon",
		children: /* @__PURE__ */ S("span", {
			className: "wd-card-medallion",
			children: /* @__PURE__ */ S(st, {
				icon: e.icon,
				size: o
			})
		})
	})] });
	return i ? /* @__PURE__ */ S("button", {
		type: "button",
		className: `wd-card wd-card-${t}${n ? " is-selected" : ""}${r ? " is-dimmed" : ""}`,
		"data-icon": e.icon,
		onClick: i,
		"aria-label": a,
		children: s
	}) : /* @__PURE__ */ S("span", {
		role: "img",
		"aria-label": a,
		"data-icon": e.icon,
		className: `wd-card wd-card-${t}${r ? " is-dimmed" : ""}`,
		children: s
	});
}
//#endregion
//#region src/game/view-player.tsx
function lt() {
	return /* @__PURE__ */ C("svg", {
		className: "wd-fallback",
		viewBox: "-5 -5 10 10",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ S("circle", {
				r: "4.9",
				fill: "#1d4a4e"
			}),
			/* @__PURE__ */ S("circle", {
				r: "3",
				fill: "#e2592f"
			}),
			/* @__PURE__ */ S("circle", {
				r: "3",
				fill: "none",
				stroke: "#f6e7cd",
				strokeWidth: "0.06"
			}),
			/* @__PURE__ */ S("circle", {
				r: "0.5",
				fill: "#0b1114",
				stroke: "#ffcf7a",
				strokeWidth: "0.06"
			}),
			/* @__PURE__ */ C("g", {
				transform: "translate(0 3.95)",
				children: [/* @__PURE__ */ S("rect", {
					x: "-0.42",
					y: "-0.2",
					width: "0.84",
					height: "0.5",
					rx: "0.12",
					fill: "#f6e7cd",
					stroke: "#ffcf7a",
					strokeWidth: "0.06"
				}), /* @__PURE__ */ S("path", {
					d: "M -0.85 0.6 H 0.35 M 0.1 0.4 L 0.4 0.6 L 0.1 0.8",
					fill: "none",
					stroke: "#ffcf7a",
					strokeWidth: "0.08",
					strokeLinecap: "round",
					strokeLinejoin: "round"
				})]
			})
		]
	});
}
function ut({ public: e, private: t, members: n, myRid: r, send: o }) {
	let g = e, _ = t ?? null, v = l(), y = c((e) => e.locale), [b] = s(Ge), [x, w] = s(() => _ && _.paddock > 0 ? 1 : 0), [T, E] = s(!1), [D, ee] = s(String(g.round));
	D !== String(g.round) && (ee(String(g.round)), w(_ && _.paddock > 0 ? 1 : 0), E(!1));
	let O = g.players.find((e) => e.rid === r), te = n.find((e) => e.rid === r), k = te ? d[te.colorIndex % d.length].hex : U.accent, A = _?.selection ?? null, j = _?.paddock ?? 0, M = A ? A.count : Math.min(x, j), N = (_?.thunderballHeld ?? !1) && g.advanced, re = g.phase === "select", P = g.picks ? g.picks.order[g.picks.index] : null, F = g.phase === "pick" && P === r, I = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, y) : e;
	}, L = (e) => {
		let t = n.find((t) => t.rid === e);
		return d[(t?.colorIndex ?? 0) % d.length].hex;
	}, ie = () => {
		re && !A && o({
			type: "commit",
			count: M,
			thunderball: N && T && M > 0
		});
	}, R = a(() => {
		if (!g.race) return [];
		let e = [];
		return g.race.marbles.forEach((t, n) => {
			if (t.kind === "thunderball") return;
			let r = g.race?.tracks[n];
			if (!r) return;
			let i = -1;
			for (let e = 0; e * 3 + 1 < r.length; e++) if (r[e * 3 + 1] < -.3) {
				i = e;
				break;
			}
			i >= 0 && g.race && e.push({
				rid: t.rid,
				at: t.spawnMs + i * g.race.sampleMs
			});
		}), e.sort((e, t) => e.at - t.at), e;
	}, [g.race]), z = g.race ? `${g.race.marbles.length}:${g.race.endMs}:${g.race.tracks.length}` : "", [B, V] = s(0), [ae, oe] = s(z);
	ae !== z && (oe(z), V(0)), i(() => {
		if (g.phase !== "race" || !z) return;
		let e = 0, t = performance.now(), n = () => {
			let r = performance.now() - t, i = 0;
			for (; i < R.length && R[i].at <= r;) i += 1;
			V((e) => e === i ? e : i), e = requestAnimationFrame(n);
		};
		return e = requestAnimationFrame(n), () => cancelAnimationFrame(e);
	}, [
		z,
		g.phase,
		R
	]);
	let se = (() => {
		let e = "info", t, n;
		return g.phase === "select" ? A ? (t = v("games.whirlyderby.ui.committed"), n = v("games.whirlyderby.ui.committedSub")) : (e = "accent", t = v("games.whirlyderby.ui.yourSelect"), n = v("games.whirlyderby.ui.selectHint")) : g.phase === "race" ? (t = v("games.whirlyderby.ui.raceBanner"), n = v("games.whirlyderby.ui.raceSub")) : g.phase === "pick" ? F ? (e = "accent", t = v("games.whirlyderby.ui.yourPick"), n = v("games.whirlyderby.ui.pickHint")) : t = v("games.whirlyderby.ui.waitPick", { name: P ? I(P) : "" }) : (e = "done", t = v("games.whirlyderby.phase.ended")), /* @__PURE__ */ S(p, {
			tone: e,
			text: t,
			sub: n,
			chip: v("games.whirlyderby.ui.round", { n: g.round }),
			accent: U.accent
		});
	})(), ce = /* @__PURE__ */ S("ul", {
		className: "wd-seats",
		children: g.players.map((e) => {
			let t = n.find((t) => t.rid === e.rid);
			if (!t) return null;
			let i = g.phase === "select" ? e.submitted ? "done" : null : g.phase === "pick" && g.picks && g.picks.order.slice(0, g.picks.index).includes(e.rid) ? "done" : null;
			return /* @__PURE__ */ C("li", {
				className: `wd-seat${e.rid === r ? " is-self" : ""}`,
				style: { "--wd-seat": L(e.rid) },
				children: [
					/* @__PURE__ */ S(m, {
						m: t,
						myRid: r,
						action: i,
						anchorName: null,
						box: "size-6",
						img: "size-5"
					}),
					/* @__PURE__ */ S("span", {
						className: "wd-seat-name",
						children: I(e.rid)
					}),
					/* @__PURE__ */ C("span", {
						className: "wd-seat-stats",
						children: [
							/* @__PURE__ */ S("span", {
								className: "wd-seat-score",
								children: v("games.whirlyderby.ui.scoreLine", { n: e.score })
							}),
							/* @__PURE__ */ C("span", {
								title: v("games.whirlyderby.ui.paddock"),
								children: ["● ", e.paddock]
							}),
							/* @__PURE__ */ C("span", {
								title: v("games.whirlyderby.ui.reloads"),
								children: ["↻ ", e.reloads]
							}),
							g.thunderball?.owner === e.rid && /* @__PURE__ */ S("span", {
								className: "wd-seat-thunder",
								title: v("games.whirlyderby.ui.thunderball"),
								"aria-label": v("games.whirlyderby.ui.thunderball")
							})
						]
					})
				]
			}, e.rid);
		})
	}), le = /* @__PURE__ */ C("div", {
		className: `wd-prize${F ? " is-live" : ""}`,
		children: [
			/* @__PURE__ */ S("span", {
				className: "wd-prize-label",
				children: v("games.whirlyderby.ui.prize")
			}),
			/* @__PURE__ */ S("div", {
				className: "wd-prize-cards",
				children: g.prize.map((e) => /* @__PURE__ */ S(ct, {
					card: e,
					size: "sm",
					selected: F,
					onClick: F ? () => o({
						type: "pick",
						card: e.id
					}) : void 0,
					ariaLabel: v("games.whirlyderby.ui.pickCardAria", {
						points: e.points,
						icon: v(ne[e.icon])
					})
				}, e.id))
			}),
			/* @__PURE__ */ S("span", {
				className: "wd-deck",
				children: v("games.whirlyderby.ui.deck", { n: g.deckCount })
			})
		]
	}), ue = g.phase === "pick" && g.result ? (() => {
		let e = g.result.order, t = e.filter((e) => e.finished).length;
		return /* @__PURE__ */ C("div", {
			className: "wd-result",
			children: [
				/* @__PURE__ */ S("span", {
					className: "wd-result-line",
					children: v("games.whirlyderby.ui.finishSummary", {
						a: t,
						b: e.length
					})
				}),
				/* @__PURE__ */ S("ol", {
					className: "wd-result-list",
					children: e.slice(0, 3).map((e, t) => /* @__PURE__ */ C("li", { children: [
						/* @__PURE__ */ S("span", {
							className: "wd-result-rank",
							children: t + 1
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-dot",
							style: { background: L(e.rid) }
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-name",
							children: I(e.rid)
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-state",
							children: v(e.finished ? "games.whirlyderby.ui.finished" : "games.whirlyderby.ui.stopped")
						})
					] }, `${e.rid}:${t}`))
				}),
				g.result.thunderballDraw && /* @__PURE__ */ S("span", {
					className: "wd-result-line",
					children: v("games.whirlyderby.ui.thunderDraw", {
						name: I(g.result.thunderballDraw.owner),
						n: g.result.thunderballDraw.stopped,
						m: g.result.thunderballDraw.cards.length
					})
				}),
				g.result.lastPlace && /* @__PURE__ */ C("div", {
					className: "wd-result-last",
					children: [
						/* @__PURE__ */ S("span", {
							className: "wd-result-last-badge",
							children: v("games.whirlyderby.ui.lastPlaceBadge")
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-dot",
							style: { background: L(g.result.lastPlace.rid) }
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-name",
							children: I(g.result.lastPlace.rid)
						}),
						/* @__PURE__ */ S("span", {
							className: "wd-result-state",
							children: v("games.whirlyderby.ui.lastRecovered")
						})
					]
				})
			]
		});
	})() : null, de = g.phase === "select" && !A ? /* @__PURE__ */ C("div", {
		className: "wd-actions",
		children: [/* @__PURE__ */ C("div", {
			className: "wd-row",
			children: [
				/* @__PURE__ */ C("div", {
					className: "wd-marble-group",
					children: [/* @__PURE__ */ S("span", {
						className: "wd-group-label",
						children: v("games.whirlyderby.ui.paddock")
					}), /* @__PURE__ */ S("div", {
						className: "wd-marbles",
						role: "group",
						"aria-label": v("games.whirlyderby.ui.yourSelect"),
						children: j === 0 ? /* @__PURE__ */ S("span", {
							className: "wd-empty-note",
							children: v("games.whirlyderby.ui.noMarble")
						}) : Array.from({ length: j }, (e, t) => /* @__PURE__ */ S("button", {
							type: "button",
							className: `wd-marble${t < M ? " is-on" : ""}`,
							"aria-label": v("games.whirlyderby.ui.commit", { n: t + 1 }),
							"aria-pressed": t < M,
							style: { "--wd-marble": k },
							onClick: () => w(M === t + 1 ? Math.max(1, t) : t + 1)
						}, t))
					})]
				}),
				/* @__PURE__ */ C("button", {
					type: "button",
					className: "wd-token wd-token-reload",
					disabled: !_?.canReload,
					onClick: () => o({ type: "reload" }),
					"aria-label": v("games.whirlyderby.ui.reload"),
					title: v("games.whirlyderby.ui.reloadHint", { n: O?.box ?? 0 }),
					children: [/* @__PURE__ */ S("span", {
						className: "wd-token-face",
						children: O?.reloads ?? 0
					}), /* @__PURE__ */ S("span", {
						className: "wd-token-sub",
						children: "↻"
					})]
				}),
				N && /* @__PURE__ */ S("button", {
					type: "button",
					className: `wd-token wd-token-thunder${T && M > 0 ? " is-on" : ""}`,
					"aria-pressed": T && M > 0,
					"aria-label": v("games.whirlyderby.ui.thunderball"),
					title: v("games.whirlyderby.ui.thunderHeld"),
					onClick: () => E((e) => M > 0 && !e),
					children: /* @__PURE__ */ S("span", {
						className: "wd-thunder-orb",
						"aria-hidden": !0
					})
				})
			]
		}), /* @__PURE__ */ C("div", {
			className: "wd-row",
			children: [/* @__PURE__ */ S("span", {
				className: "wd-pour-hint",
				children: v("games.whirlyderby.ui.pourHint")
			}), /* @__PURE__ */ S("button", {
				type: "button",
				className: "wd-commit",
				style: { background: k },
				onClick: ie,
				children: M === 0 ? v("games.whirlyderby.ui.roundEmpty") : v("games.whirlyderby.ui.commit", { n: M })
			})]
		})]
	}) : g.phase === "select" && A ? /* @__PURE__ */ C("div", {
		className: "wd-actions wd-actions-locked",
		children: [
			/* @__PURE__ */ S(u, {
				size: 22,
				strokeWidth: 3,
				"aria-hidden": !0
			}),
			/* @__PURE__ */ C("div", {
				className: "wd-locked-text",
				children: [/* @__PURE__ */ S("b", { children: v("games.whirlyderby.ui.committed") }), /* @__PURE__ */ S("span", { children: v("games.whirlyderby.ui.committedSub") })]
			}),
			/* @__PURE__ */ C("div", {
				className: "wd-locked-stats",
				children: [/* @__PURE__ */ S("span", { children: v("games.whirlyderby.ui.commit", { n: A.count }) }), A.thunderball && /* @__PURE__ */ S("span", { children: v("games.whirlyderby.ui.thunderball") })]
			})
		]
	}) : g.phase === "pick" && g.picks ? /* @__PURE__ */ C("div", {
		className: "wd-actions",
		children: [/* @__PURE__ */ C("div", {
			className: "wd-status",
			children: [/* @__PURE__ */ S("b", { children: F ? v("games.whirlyderby.ui.yourPick") : v("games.whirlyderby.ui.waitPick", { name: P ? I(P) : "" }) }), /* @__PURE__ */ S("span", { children: v("games.whirlyderby.ui.pickOrder") })]
		}), /* @__PURE__ */ S("ol", {
			className: "wd-pick-order",
			children: g.picks.order.map((e, t) => /* @__PURE__ */ C("li", {
				className: t === g.picks?.index ? "is-now" : t < (g.picks?.index ?? 0) ? "is-done" : "",
				children: [/* @__PURE__ */ S("span", {
					className: "wd-result-dot",
					style: { background: L(e) }
				}), I(e)]
			}, `${e}:${t}`))
		})]
	}) : /* @__PURE__ */ S("div", {
		className: "wd-actions wd-actions-status",
		children: /* @__PURE__ */ C("div", {
			className: "wd-status",
			children: [/* @__PURE__ */ S("b", { children: g.phase === "race" ? v("games.whirlyderby.ui.raceBanner") : v("games.whirlyderby.phase.ended") }), /* @__PURE__ */ S("span", { children: g.phase === "race" ? v("games.whirlyderby.ui.raceSub") : v("games.whirlyderby.ui.waiting") })]
		})
	});
	return /* @__PURE__ */ S(f, {
		adaptive: !0,
		className: "wd-game",
		scroll: !1,
		actionsHeight: "wd-actions-h",
		banner: /* @__PURE__ */ C("div", {
			className: "wd-banner",
			children: [se, ce]
		}),
		actions: de,
		overlay: ue,
		children: /* @__PURE__ */ C("div", {
			className: "wd-stage",
			children: [
				b ? /* @__PURE__ */ S(ot, {
					pub: g,
					members: n
				}) : /* @__PURE__ */ S(lt, {}),
				le,
				g.phase === "race" && B > 0 && /* @__PURE__ */ S("div", {
					className: "wd-live",
					"aria-live": "polite",
					children: R.slice(0, Math.min(3, B)).map((e, t) => /* @__PURE__ */ C("span", {
						className: "wd-live-chip",
						children: [
							/* @__PURE__ */ S("span", {
								className: "wd-live-rank",
								children: t + 1
							}),
							/* @__PURE__ */ S("span", {
								className: "wd-result-dot",
								style: { background: L(e.rid) }
							}),
							/* @__PURE__ */ S("span", {
								className: "wd-live-name",
								title: I(e.rid),
								children: I(e.rid)
							})
						]
					}, `${e.rid}:${t}`))
				})
			]
		})
	});
}
//#endregion
//#region src/game/bot.ts
var dt = [
	"donut",
	"cheese",
	"jelly"
];
function ft(e) {
	let t = {
		cactus: 0,
		lamp: 0,
		donut: 0,
		cheese: 0,
		jelly: 0
	};
	for (let n of e) n.icon !== "none" && (t[n.icon] += 1);
	return t;
}
function pt(e) {
	let t = Math.min(e, k.length - 1);
	return k[Math.min(t + 1, k.length - 1)] - k[t];
}
function mt(e, t, n, r) {
	if (!r || e.icon === "none") return e.points;
	let i = ft(t), a = e.points;
	return e.icon === "lamp" && (a += pt(i.lamp)), e.icon === "cactus" ? i.cactus + 1 > n ? a += 15 : i.cactus + 1 === n && (a += 6) : e.icon !== "lamp" && i[e.icon] === 0 && dt.filter((t) => t !== e.icon).every((e) => i[e] > 0) && (a += 30), a;
}
function ht(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n);
	if (!i) return null;
	let a = t?.paddock ?? i.paddock;
	if (a === 0) return t?.canReload ? { type: "reload" } : {
		type: "commit",
		count: 0,
		thunderball: !1
	};
	let o = r === "weak", s = i.score < Math.max(...e.players.map((e) => e.score)), c;
	if (o) c = 1 + Math.floor(Math.random() * a);
	else if (e.round >= 8) c = a;
	else {
		let t = s ? 3 : 2;
		e.round <= 2 && (t = Math.min(t, 2)), 8 - e.round <= 2 && (t = Math.max(t, 3)), c = Math.min(a, t);
	}
	c = Math.max(1, Math.min(a, c));
	let l = !!t?.thunderballHeld && e.advanced;
	return {
		type: "commit",
		count: c,
		thunderball: l
	};
}
var gt = (e, t) => {
	let { public: n, private: r } = e, i = t.rid;
	if (n.phase === "select") {
		if (r?.selection) return null;
		let e = ht(n, r ?? null, i, t.difficulty);
		return e ? { action: e } : null;
	}
	if (n.phase === "pick") {
		if (!n.picks || n.picks.index >= n.picks.order.length || n.picks.order[n.picks.index] !== i || n.prize.length === 0) return null;
		let e = n.players.find((e) => e.rid === i)?.cards ?? [];
		if (t.difficulty === "weak") return { action: {
			type: "pick",
			card: n.prize[Math.floor(Math.random() * n.prize.length)].id
		} };
		let r = Math.max(0, ...n.players.map((e) => ft(e.cards).cactus)), a = n.prize[0];
		for (let t of n.prize) mt(t, e, r, n.advanced) > mt(a, e, r, n.advanced) && (a = t);
		return { action: {
			type: "pick",
			card: a.id
		} };
	}
	return null;
};
//#endregion
//#region src/game/game-over.tsx
function _t(e) {
	let t = l(), n = e.public, r = new Map((n?.players ?? []).map((e) => [e.rid, e])), i = (e) => {
		let n = r.get(e);
		return n ? n.cards.length === 0 ? /* @__PURE__ */ S("div", {
			className: "wd-over-empty",
			children: t("games.whirlyderby.ui.noCards")
		}) : /* @__PURE__ */ S("div", {
			className: "wd-over-cards",
			children: n.cards.map((e) => /* @__PURE__ */ S(ct, {
				card: e,
				size: "sm",
				ariaLabel: t("games.whirlyderby.ui.pickCardAria", {
					points: e.points,
					icon: t(ne[e.icon])
				})
			}, e.id))
		}) : null;
	};
	return /* @__PURE__ */ S("div", {
		className: "wd-over",
		children: /* @__PURE__ */ S(w, {
			...e,
			accent: U.accent,
			renderRowExtra: i
		})
	});
}
//#endregion
//#region src/game/options.tsx
function vt({ value: e, onChange: t }) {
	let n = l(), r = G.safeParse(e), i = r.success ? r.data : G.parse(void 0);
	return /* @__PURE__ */ S(T, {
		title: n("games.whirlyderby.opt.advanced"),
		columns: 2,
		children: /* @__PURE__ */ S("div", {
			className: "col-span-2",
			children: /* @__PURE__ */ S(E, {
				checked: i.advanced,
				label: n("games.whirlyderby.opt.advanced"),
				hint: n("games.whirlyderby.opt.advancedHint"),
				accent: U.accent,
				onChange: () => t({
					...i,
					advanced: !i.advanced
				})
			})
		})
	});
}
//#endregion
//#region src/game/locales/zh.ts
var yt = {
	name: "旋风竞速",
	desc: "秘密投入弹珠，在漏斗赛场里抢进前三，赢取八场比赛的奖杯",
	rules: "目标：进行八场比赛。每场比赛中，你指挥自己颜色的弹珠冲进赛场中央的孔口；名次越靠前，获得的奖杯卡分值越高。八场比赛结束后，总分最高的玩家获胜。\n\n准备：把漏斗赛场放在桌面中央。每位玩家取同色围栏、五颗竞赛弹珠和两枚补给标记，补给标记以“2”面朝上。奖杯卡洗混后背面朝下作为牌堆，翻开三张作为本场奖池。八枚比赛标记以红灯面朝上，第一枚翻到绿灯面表示第一场开始。\n\n每场比赛：\n· 所有玩家同时秘密决定本场投入几颗弹珠。只要围栏中还有弹珠，本场至少投入一颗。\n· 全部玩家提交后，所有弹珠一起放进同一个发射器，从赛场外缘倒入。弹珠在漏斗中相互碰撞、绕圈减速，最终滚向中央孔口。\n· 第一颗落入孔口的弹珠获得第一名，其后依次为第二名和第三名。前三名按名次从奖池中取走一张奖杯卡。\n· 没有落入孔口的弹珠停在赛场中，按最终距离孔口的远近排出后续名次。\n· 每场比赛的最后一名可以从赛场收回一颗自己的弹珠，放回围栏。\n· 其余参赛弹珠收回盒中，在余下的比赛中不能使用。\n· 每场结束后，从牌堆补三张奖杯卡作为下一场的奖池，并翻开下一枚比赛标记。\n\n补给：\n· 整场对局中，每位玩家有两次补给机会。使用一次补给，可以把自己盒中的全部弹珠收回围栏。\n· 第一次使用后，补给标记翻到“1”面；第二次使用后，把补给标记弃掉。\n· 围栏和盒中都没有弹珠，且没有可用补给时，本场只能轮空。\n\n终局：\n· 八场比赛后，累计奖杯卡分值最高的玩家获胜。\n· 最高分并列时，并列者各投入一颗弹珠加赛一场，先落入孔口者获胜。\n\n进阶规则：\n· 前两枚比赛标记为普通标记。其余六枚标记中有两枚雷霆球标记，开局时随机混入。\n· 翻到雷霆球标记时，当前分数最低的玩家获得雷霆球；分数相同时，弹珠总数较少的玩家获得。若原持有者尚未使用，雷霆球转交给新的最低分玩家。\n· 雷霆球持有者可以在任意一场使用一次雷霆球，使用时必须同时投入至少一颗普通弹珠。\n· 雷霆球在比赛中落下，封住中央孔口。它挡下的弹珠越多，持有者从牌堆顶获得的奖杯卡越多，最多三张。\n· 雷霆球比赛中，只有落入孔口的弹珠进入前三名并取走奖杯；这场比赛没有最后一名收回弹珠的奖励。\n· 奖杯卡底部印有图标，按以下方式额外加分：仙人掌图标最多的玩家获得十五分，并列最多者各获得十五分；熔岩灯图标越多，加分越高；甜甜圈、奶酪和果冻图标各至少一张时，额外获得三十分。",
	opt: {
		advanced: "进阶规则",
		advancedHint: "加入雷霆球标记、图标套装加分与熔岩灯加分"
	},
	phase: {
		select: "秘密投珠",
		race: "比赛进行中",
		pick: "领取奖杯",
		ended: "结束"
	},
	ui: {
		round: "第 {{n}} / 8 场",
		yourSelect: "秘密选择本场投入的弹珠",
		waitSelect: "等待 {{name}} 提交",
		selectHint: "点击围栏弹珠选择本场投入数量",
		committed: "本场已提交，等待其他玩家",
		committedSub: "投入数量已锁定",
		raceBanner: "比赛进行中",
		raceSub: "弹珠正在漏斗中竞速",
		yourPick: "轮到你领取奖杯",
		waitPick: "等待 {{name}} 领取奖杯",
		pickHint: "点击一张奖杯卡收入手中",
		prize: "本场奖杯",
		deck: "牌堆 {{n}}",
		paddock: "围栏",
		box: "盒中",
		reloads: "补给",
		reload: "使用补给",
		reloadHint: "收回盒中 {{n}} 颗弹珠",
		pourHint: "全部玩家提交后，所有弹珠一起从赛场边缘倒入",
		thunderball: "雷霆球",
		thunderHeld: "你持有雷霆球",
		thunderOwner: "雷霆球：{{name}}",
		commit: "投入 {{n}} 颗",
		roundEmpty: "本场轮空",
		roundEmptySub: "围栏与盒中都没有弹珠",
		pickOrder: "领杯顺序",
		finished: "落孔",
		stopped: "未落孔",
		lastPlaceBadge: "末位",
		lastRecovered: "收回一颗弹珠",
		thunderDraw: "{{name}} 的雷霆球挡下 {{n}} 颗弹珠，抽取 {{m}} 张奖杯卡",
		thunderNoDraw: "{{name}} 的雷霆球没有挡下弹珠",
		finishSummary: "落孔 {{a}} / {{b}}",
		scoreLine: "{{n}} 分",
		marbleLine: "弹珠 {{n}}",
		tapHint: "拖动平移，双指缩放",
		recenter: "复位视角",
		waiting: "等待其他玩家",
		myTurn: "轮到你",
		submitted: "已提交",
		noMarble: "无弹珠可投",
		lastRoundResult: "本场结果",
		pickCardAria: "{{points}} 分，{{icon}}",
		trophyCount: "奖杯 {{n}} 分",
		cardsCount: "奖杯卡 {{n}} 张",
		noCards: "本局没有获得奖杯卡"
	},
	iconCactus: "仙人掌",
	iconLamp: "熔岩灯",
	iconDonut: "甜甜圈",
	iconCheese: "奶酪",
	iconJelly: "果冻",
	iconNone: "无图标",
	err: {
		phase: "当前阶段不能这样操作",
		notPlayer: "你不在本局中",
		committed: "本场已经提交过了",
		noReload: "没有可用的补给",
		emptyBox: "盒中没有弹珠",
		tooMany: "投入数量超过围栏中的弹珠",
		mustEnter: "本场至少投入一颗弹珠",
		noMarbles: "围栏中没有弹珠",
		thunderNeedsMarble: "使用雷霆球时必须同时投入至少一颗弹珠",
		noThunderball: "你没有可用的雷霆球",
		notTurn: "还没轮到你领取奖杯",
		badPick: "这张奖杯卡不在本场奖池中"
	}
}, bt = {
	name: "Whirly Derby",
	desc: "Secretly commit your marbles, race them into the funnel, and finish in the top three to claim trophies over eight races",
	rules: "Goal: Play eight races. In each race you steer marbles of your own colour towards the hole at the centre of the arena; the higher you finish, the more valuable the trophy cards you win. After eight races, the player with the highest total score wins.\n\nSetup: Place the funnel arena in the middle of the table. Each player takes the fence, five racing marbles and two reload tokens in their own colour, with the reload tokens showing \"2\". Shuffle the trophy cards face down as a deck and turn three of them face up as this race's prize pool. Place the eight race tokens red side up and turn the first one green to show that race one has begun.\n\nEach race:\n· All players simultaneously decide in secret how many marbles to commit this race. As long as marbles remain behind your fence, you must commit at least one.\n· After everyone has committed, all marbles are placed in the same launcher and poured in from the rim of the arena. Inside the funnel they collide, circle and slow down until they roll towards the central hole.\n· The first marble to drop into the hole takes first place, followed by second and third. The top three players each take one trophy card from the prize pool.\n· Marbles that do not drop into the hole come to rest in the arena and are ranked behind the finishers by their final distance from the hole.\n· At the end of each race, the last-place player returns one of their marbles from the arena to behind their fence.\n· All other marbles that took part are returned to the box and cannot be used for the rest of the game.\n· After each race, deal three new trophy cards from the deck as the next race's prize pool and turn the next race token green.\n\nReload:\n· You have two reloads for the whole game. Using one returns every marble in your box to behind your fence.\n· After the first use, flip the reload token to show \"1\"; after the second use, discard the token.\n· If you have no marbles behind your fence and none in your box, and no reload remains, you sit this race out.\n\nEnd of the game:\n· After eight races, the player with the highest total trophy value wins.\n· If the highest score is tied, each tied player commits one marble for an extra sudden-death race, and the first to drop into the hole wins.\n\nAdvanced rules:\n· The first two race tokens are standard. Two of the remaining six tokens are Thunderball tokens and are shuffled in at the start of the game.\n· When a Thunderball token is revealed, the player with the lowest current score receives the Thunderball; if scores are tied, the player with fewer marbles receives it. If the previous holder has not used it yet, the Thunderball passes to the new lowest-scoring player.\n· The holder may use the Thunderball once in any race, and must commit at least one normal marble at the same time.\n· The Thunderball drops during the race and blocks the central hole. The more marbles it stops, the more trophy cards its holder draws from the top of the deck, up to three.\n· In a Thunderball race, only marbles that drop into the hole enter the top three and take trophies; this race has no last-place marble return.\n· The bottom of each trophy card shows an icon that scores extra as follows: the player with the most cactus icons scores fifteen points, and every player tied for the most scores fifteen; the more lava lamp icons you have, the more bonus points you score; and having at least one donut, one cheese and one jelly icon scores thirty extra points.",
	opt: {
		advanced: "Advanced rules",
		advancedHint: "Add Thunderball tokens, icon set bonuses and lava lamp bonuses"
	},
	phase: {
		select: "Secret commitment",
		race: "Race in progress",
		pick: "Claim trophies",
		ended: "Finished"
	},
	ui: {
		round: "Race {{n}} / 8",
		yourSelect: "Choose marbles in secret",
		waitSelect: "Waiting for {{name}}",
		selectHint: "Tap marbles to choose how many to commit",
		committed: "Committed, waiting for others",
		committedSub: "Your marble count is locked in",
		raceBanner: "Race in progress",
		raceSub: "Marbles are racing down the funnel",
		yourPick: "Your turn to claim a trophy",
		waitPick: "Waiting for {{name}} to pick",
		pickHint: "Tap a trophy card to take it",
		prize: "This race’s trophies",
		deck: "Deck {{n}}",
		paddock: "Fence",
		box: "Box",
		reloads: "Reloads",
		reload: "Use a reload",
		reloadHint: "Return {{n}} marbles from your box",
		pourHint: "All marbles are poured in together from the rim once everyone commits",
		thunderball: "Thunderball",
		thunderHeld: "You hold the Thunderball",
		thunderOwner: "Thunderball: {{name}}",
		commit: "Commit {{n}}",
		roundEmpty: "Sit out this race",
		roundEmptySub: "No marbles in your fence or box",
		pickOrder: "Claim order",
		finished: "Dropped in",
		stopped: "Stayed out",
		lastPlaceBadge: "Last",
		lastRecovered: "returns one marble",
		thunderDraw: "{{name}}’s Thunderball stopped {{n}} marbles and drew {{m}} trophy cards",
		thunderNoDraw: "{{name}}’s Thunderball stopped no marbles",
		finishSummary: "Dropped in {{a}} / {{b}}",
		scoreLine: "{{n}} pts",
		marbleLine: "Marbles {{n}}",
		tapHint: "Drag to pan, pinch to zoom",
		recenter: "Recenter view",
		waiting: "Waiting for other players",
		myTurn: "Your turn",
		submitted: "Committed",
		noMarble: "No marbles to commit",
		lastRoundResult: "Race result",
		pickCardAria: "{{points}} points, {{icon}}",
		trophyCount: "Trophies {{n}} pts",
		cardsCount: "Trophy cards {{n}}",
		noCards: "No trophy cards this game"
	},
	iconCactus: "Cactus",
	iconLamp: "Lava lamp",
	iconDonut: "Donut",
	iconCheese: "Cheese",
	iconJelly: "Jelly",
	iconNone: "No icon",
	err: {
		phase: "You cannot do that in this phase",
		notPlayer: "You are not in this game",
		committed: "You have already committed this race",
		noReload: "No reload available",
		emptyBox: "There are no marbles in your box",
		tooMany: "You cannot commit more marbles than your fence holds",
		mustEnter: "You must commit at least one marble this race",
		noMarbles: "No marbles behind your fence",
		thunderNeedsMarble: "You must commit at least one marble to use the Thunderball",
		noThunderball: "You have no usable Thunderball",
		notTurn: "It is not your turn to claim a trophy",
		badPick: "That trophy card is not in this race’s prize pool"
	}
};
//#endregion
//#region src/index.tsx
await ee();
var xt = {
	definition: Ie,
	View: ut,
	bot: gt,
	OverView: _t,
	Options: vt,
	locales: {
		zh: yt,
		en: bt
	}
};
//#endregion
export { xt as default };
