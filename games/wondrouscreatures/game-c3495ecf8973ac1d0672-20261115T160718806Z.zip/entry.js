import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { gameAssetUrl as o } from "@bgparty/sdk/assets";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { DeltaNumber as d } from "@bgparty/sdk/ui";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { AVATARS as _ } from "@bgparty/sdk/avatars";
import { Floater as v, FlySprite as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as x } from "@bgparty/sdk/confirm-button";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/game/domain.ts
var w = [
	"fruit",
	"coral",
	"flower",
	"mushroom"
], T = [
	"crustacean",
	"mammal",
	"bird",
	"reptile",
	"fish",
	"insect",
	"dragon"
];
function ee() {
	return {
		fruit: 1,
		coral: 1,
		flower: 1,
		mushroom: 1
	};
}
function te(e, t) {
	if (!Number.isInteger(e) || e < 0 || e > 3 || t.length !== e || new Set(t).size !== t.length) return null;
	let n = ee();
	for (let e of t) n[e] += 1;
	return n;
}
function E(e) {
	return w.reduce((t, n) => t + e[n], 0);
}
function D(e, t) {
	let n = { ...e }, r = {
		fruit: 0,
		coral: 0,
		flower: 0,
		mushroom: 0
	};
	for (let e of w) {
		let i = t[e] ?? 0;
		r[e] = Math.min(i, 6 - n[e]), n[e] += r[e];
	}
	return {
		resources: n,
		gained: r
	};
}
function O(e, t) {
	if (w.some((n) => (t[n] ?? 0) > e[n])) return null;
	let n = { ...e };
	for (let e of w) n[e] -= t[e] ?? 0;
	return n;
}
function ne(e, t) {
	let n = e + t;
	return {
		nets: Math.min(3, n),
		points: Math.max(0, n - 3)
	};
}
function k(e, t) {
	return e.length >= 12 ? {
		eggs: [...e],
		stored: !1,
		points: 2
	} : {
		eggs: [...e, {
			species: t,
			hatched: !1
		}],
		stored: !0,
		points: 0
	};
}
function re(e) {
	let t = e.trophies * 3, n = Math.floor((E(e.resources) + e.nets) / 4), r = e.beastPoints ?? 0, i = e.immediate + e.endGameAbilities + r + e.printedCards + e.achievements + t + n;
	return {
		immediate: e.immediate,
		endGameAbilities: e.endGameAbilities,
		beastPoints: r,
		printedCards: e.printedCards,
		achievements: e.achievements,
		trophies: t,
		remaining: n,
		total: i
	};
}
function A(e, t) {
	return re(t).total - re(e).total || t.trophies - e.trophies || E(t.resources) - E(e.resources);
}
function j(e, t) {
	let n = e.indexOf(t);
	if (n < 0) throw Error("Final-turn trigger is not a player");
	return {
		trigger: t,
		remaining: [...e.slice(n + 1), ...e.slice(0, n)]
	};
}
function ie(e, t) {
	let n = e.remaining[0] === t ? e.remaining.slice(1) : [...e.remaining];
	return {
		turns: {
			...e,
			remaining: n
		},
		next: n[0] ?? null
	};
}
//#endregion
//#region src/game/random.ts
function M(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; t--) {
		let a = e(n, r++, t + 1);
		[i[t], i[a]] = [i[a], i[t]];
	}
	return {
		items: i,
		cursor: r
	};
}
//#endregion
//#region src/game/achievements.ts
var N = [
	{
		id: 1,
		kind: "main",
		requirement: "fourteenCards"
	},
	{
		id: 2,
		kind: "main",
		requirement: "eightEggs"
	},
	{
		id: 3,
		kind: "main",
		requirement: "sixHabitat"
	},
	{
		id: 4,
		kind: "main",
		requirement: "tenSpecies"
	},
	{
		id: 5,
		kind: "main",
		requirement: "twoTypeSets"
	}
], P = T.map((e, t) => ({
	id: t + 6,
	kind: "single",
	species: e
})), ae = [
	{
		id: 13,
		kind: "multi",
		species: ["crustacean", "bird"]
	},
	{
		id: 14,
		kind: "multi",
		species: ["crustacean", "insect"]
	},
	{
		id: 15,
		kind: "multi",
		species: ["mammal", "fish"]
	},
	{
		id: 16,
		kind: "multi",
		species: ["mammal", "dragon"]
	},
	{
		id: 17,
		kind: "multi",
		species: ["bird", "reptile"]
	},
	{
		id: 18,
		kind: "multi",
		species: ["reptile", "dragon"]
	},
	{
		id: 19,
		kind: "multi",
		species: ["fish", "insect"]
	}
];
function oe(e, t) {
	let n = M(N, e, t), r = M(ae, e, n.cursor), i = r.items[0];
	if (i.kind !== "multi") throw Error("Invalid multi-species achievement");
	let a = r.items.find((e) => e.kind === "multi" && e.id !== i.id && e.species.every((e) => !i.species.includes(e)));
	if (!a || a.kind !== "multi") throw Error("No compatible multi-species achievement");
	let o = [...i.species, ...a.species], s = M(P.filter((e) => e.kind === "single" && !o.includes(e.species)), e, r.cursor);
	return {
		achievements: [
			...n.items.slice(0, 3),
			...s.items.slice(0, 2),
			i,
			a
		],
		cursor: s.cursor
	};
}
function se(e, t) {
	if (e.kind === "main") {
		let n = {
			fourteenCards: 14,
			eightEggs: 8,
			sixHabitat: 6,
			tenSpecies: 10,
			twoTypeSets: 2
		}[e.requirement];
		return (t <= 2 ? [15, 9] : [
			15,
			12,
			9
		]).map((e) => ({
			required: n,
			points: e
		}));
	}
	return e.kind === "single" ? t < 4 ? [{
		required: 6,
		points: 12
	}, {
		required: 3,
		points: 6
	}] : [
		{
			required: 7,
			points: 12
		},
		{
			required: 5,
			points: 9
		},
		{
			required: 3,
			points: 6
		}
	] : t < 4 ? [{
		required: 8,
		points: 12
	}, {
		required: 5,
		points: 6
	}] : [
		{
			required: 8,
			points: 12
		},
		{
			required: 6,
			points: 9
		},
		{
			required: 4,
			points: 6
		}
	];
}
function ce(e, t) {
	return e.cards.reduce((e, n) => e + n.species.filter((e) => t.includes(e)).length, 0) + (e.extraSpecies?.filter((e) => t.includes(e)).length ?? 0);
}
function le(e, t) {
	return ce(e, t) + e.eggs.filter((e) => !e.hatched && t.includes(e.species)).length;
}
function F(e, t, n) {
	if (e.kind === "single") return le(n, [e.species]) >= t;
	if (e.kind === "multi") return le(n, e.species) >= t;
	switch (e.requirement) {
		case "fourteenCards": return n.cards.length >= t;
		case "eightEggs": return n.eggs.filter((e) => !e.hatched).length >= t;
		case "sixHabitat": return w.some((e) => n.cards.filter((t) => t.habitat === e).length >= t);
		case "tenSpecies": return T.some((e) => le(n, [e]) >= t);
		case "twoTypeSets": return [
			"instant",
			"permanent",
			"energy",
			"recharge",
			"endGame"
		].every((e) => n.cards.filter((t) => t.type === e).length >= t);
	}
}
function ue(e, t, n, r) {
	if (new Set(r.eggs).size !== r.eggs.length) return !1;
	let i = r.eggs.map((e) => n.eggs[e]);
	if (i.some((e) => !e || e.hatched)) return !1;
	if (e.kind === "main" && e.requirement === "eightEggs") return i.length === t;
	if (e.kind === "main" && e.requirement === "sixHabitat") return i.length === 0 && r.habitat !== void 0 && n.cards.filter((e) => e.habitat === r.habitat).length >= t;
	if (e.kind === "main" && e.requirement !== "tenSpecies") return i.length === 0 && F(e, t, n);
	let a = e.kind === "single" ? [e.species] : e.kind === "multi" ? e.species : r.species ? [r.species] : [];
	return a.length > 0 && i.length <= t && i.every((e) => a.includes(e.species)) && ce(n, a) + i.length >= t;
}
//#endregion
//#region src/game/rewards.ts
var de = [
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "wildernessCards",
		amount: 1
	},
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "resources",
		amount: 1
	},
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "wildernessCards",
		amount: 1
	},
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "resources",
		amount: 1
	},
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "points",
		amount: 1
	},
	{
		kind: "points",
		amount: 2
	},
	{
		kind: "points",
		amount: 3
	}
], fe = [
	{
		kind: "resources",
		amount: 2
	},
	{
		kind: "wildernessCards",
		amount: 2
	},
	{
		kind: "points",
		amount: 3
	},
	{
		kind: "net",
		amount: 1
	},
	{ kind: "restoreEnergy" },
	{ kind: "activateAllRecharge" }
], pe = [
	{
		at: 5,
		reward: { kind: "discovery" }
	},
	{
		at: 10,
		reward: {
			kind: "net",
			amount: 1
		}
	},
	{
		at: 15,
		reward: {
			kind: "net",
			amount: 1
		}
	},
	{
		at: 20,
		reward: {
			kind: "net",
			amount: 1
		}
	},
	{
		at: 25,
		reward: { kind: "discovery" }
	},
	{
		at: 30,
		reward: { kind: "trophy" }
	},
	{
		at: 35,
		reward: {
			kind: "net",
			amount: 1
		}
	},
	{
		at: 40,
		reward: { kind: "discovery" }
	},
	{
		at: 45,
		reward: {
			kind: "net",
			amount: 1
		}
	},
	{
		at: 50,
		reward: { kind: "trophy" }
	}
];
function me(e, t) {
	return pe.filter((n) => e < n.at && t >= n.at).map((e) => e.reward);
}
//#endregion
//#region src/game/achievement-action.ts
function he(e) {
	let t = e.achievements.find((t) => t.id === e.achievement);
	if (!t || e.advanceBeast && e.useMarkerReward || !Number.isInteger(e.slot) || !Number.isInteger(e.marker) || e.marker < 0 || e.marker >= fe.length) return null;
	let n = se(t, e.playerCount)[e.slot];
	if (!n || e.claims.some((n) => n.achievement === t.id && n.slot === e.slot) || e.claims.some((n) => n.owner === e.owner && (n.achievement === t.id || n.marker === e.marker)) || !ue(t, n.required, e.reserve, e.selection)) return null;
	let r = e.useMarkerReward ? fe[e.marker] : {
		kind: "points",
		amount: 2
	}, i = [];
	return e.selection.eggs.length > 0 && i.push({
		kind: "hatch",
		eggs: [...e.selection.eggs]
	}), e.advanceBeast ? i.push({ kind: "advanceBeast" }) : i.push({
		kind: "reward",
		reward: r
	}), i.push({ kind: "trophy" }), e.claims.some((t) => t.owner === e.owner) || i.push({ kind: "unlockCaptain" }), {
		claim: {
			owner: e.owner,
			achievement: t.id,
			slot: e.slot,
			marker: e.marker,
			points: n.points,
			reward: r,
			usedMarkerReward: e.useMarkerReward,
			...e.advanceBeast ? { advancedBeast: !0 } : {}
		},
		steps: i
	};
}
//#endregion
//#region src/game/achievement-resolution.ts
function ge(e, t, n, r = 0) {
	let i = e.flatMap((e) => e.kind === "reward" ? [{
		kind: "reaction",
		reaction: {
			kind: "reward",
			reward: e.reward
		}
	}, ...n ? [{
		kind: "markAchievementReward",
		marker: t
	}] : []] : e.kind === "hatch" ? [{
		kind: "hatchSelected",
		indices: e.eggs
	}] : e.kind === "trophy" ? [{
		kind: "reaction",
		reaction: {
			kind: "reward",
			reward: { kind: "trophy" }
		}
	}] : e.kind === "advanceBeast" ? [{
		kind: "advanceBeast",
		spaces: 2
	}] : [{ kind: "unlockCaptain" }]);
	return r > 0 && i.splice(+(i[0]?.kind === "hatchSelected"), 0, {
		kind: "reaction",
		reaction: {
			kind: "reward",
			reward: {
				kind: "points",
				amount: r
			}
		}
	}), i;
}
//#endregion
//#region src/game/beasts.ts
var _e = [
	{
		id: 1,
		name: {
			zh: "翼海巨兽",
			en: "Plésioange"
		},
		species: ["bird", "fish"],
		ability: {
			zh: "唤醒时获得两枚不可恢复的能量。每回合可消耗一枚能量和一个网，免费打出一张荒野牌，或查看牌库顶四张并免费打出其中一张、弃掉其余三张。",
			en: "On awakening, gain two energy that cannot be restored. Once per turn, spend one energy and one net to play a wilderness card for free, or look at four cards from the deck, play one for free and discard the rest."
		}
	},
	{
		id: 2,
		name: {
			zh: "幽光巨龙",
			en: "Luxodragon"
		},
		species: ["fish", "dragon"],
		ability: {
			zh: "唤醒时获得两枚不可恢复的能量。每回合可消耗一枚能量，弃掉至多三张手牌，或从牌库抽至手牌有三张；每张弃牌或抽牌使你获得一分和一份任选资源。",
			en: "On awakening, gain two energy that cannot be restored. Once per turn, spend one energy to discard up to three cards, or draw until you have three cards in hand; gain one point and one resource of your choice for each card discarded or drawn."
		}
	},
	{
		id: 3,
		name: {
			zh: "大地蛛母",
			en: "Gaiarachnée"
		},
		species: ["reptile", "insect"],
		ability: {
			zh: "唤醒时，每有一个蛋获得一分。此后获得蛋时，蛋槽奖励结算两次；蛋槽已满时，每个额外蛋改得四分。",
			en: "On awakening, gain one point per egg in your reserve. Afterwards, resolve each egg-slot reward twice and gain four points per extra egg when your slots are full."
		}
	},
	{
		id: 4,
		name: {
			zh: "辉冠巨鸟",
			en: "Magnificondor"
		},
		species: ["mammal", "bird"],
		ability: {
			zh: "每次获得奖杯时，再获得一次你以前获得过的目标标记奖励。",
			en: "Whenever you gain a trophy, gain one previously obtained achievement marker reward again."
		}
	},
	{
		id: 5,
		name: {
			zh: "海渊巨兽",
			en: "Poséidosaure"
		},
		species: ["crustacean", "dragon"],
		ability: {
			zh: "每次打出印刷费用至少为四份资源的幻兽牌时，费用减少一份资源并获得一分。",
			en: "Whenever you play a creature whose printed cost is at least four resources, reduce its cost by one resource and gain one point."
		}
	},
	{
		id: 6,
		name: {
			zh: "熔岩巨兽",
			en: "Volkhan"
		},
		species: ["crustacean", "reptile"],
		ability: {
			zh: "每次完成主要目标时，每有一个你保护区中数量最多的栖地图标，就获得一分。",
			en: "Whenever you complete a main achievement, gain one point for each habitat icon of the type most common in your reserve."
		}
	},
	{
		id: 7,
		name: {
			zh: "雪眠巨兽",
			en: "Yétoisif"
		},
		species: ["mammal", "insect"],
		ability: {
			zh: "地图上有两名自己的探险者时即可充能；充能时，每张充能牌连续激活两次。",
			en: "You may recharge with two of your explorers on the board; during a recharge action, activate each Recharge card twice in succession."
		}
	}
];
function ve(e, t) {
	let n = e?.owned[t];
	return n?.awake ? [..._e.find((e) => e.id === n.id)?.species ?? []] : [];
}
function ye(e, t, n) {
	if (!Number.isInteger(e) || e < 1 || e > 4) throw Error("Invalid beast player count");
	let r = M(_e.map((e) => e.id), t, n);
	return {
		state: {
			supply: r.items.slice(0, e + 1),
			owned: {}
		},
		cursor: r.cursor
	};
}
function be(e, t) {
	return t.length === 4 && new Set(t).size === 4 && t.every((t) => Number.isInteger(t) && t >= 0 && t < e.length && !e[t].hatched);
}
function xe(e, t, n) {
	return e.owned[t] || !e.supply.includes(n) ? null : {
		supply: e.supply.filter((e) => e !== n),
		owned: {
			...e.owned,
			[t]: {
				id: n,
				progress: 0,
				awake: !1,
				energy: 0,
				usedThisTurn: !1
			}
		}
	};
}
function I(e, t, n, r) {
	let i = e.owned[t];
	if (!i || !Number.isInteger(n) || n < 0) return null;
	if (i.awake) return {
		state: e,
		awakened: !1,
		points: 0
	};
	let a = Math.min(4, i.progress + n), o = a === 4, s = {
		...i,
		progress: a,
		awake: o,
		energy: o && (i.id === 1 || i.id === 2) ? 2 : i.energy
	};
	return {
		state: {
			...e,
			owned: {
				...e.owned,
				[t]: s
			}
		},
		awakened: o,
		points: o && i.id === 3 ? r.length : 0
	};
}
function L(e, t) {
	let n = _e.find((t) => t.id === e.id);
	return !e.awake && !!n && t.some((e) => n.species.includes(e));
}
function Se(e, t) {
	return e?.awake && e.id === 5 && t >= 4 ? 1 : 0;
}
function Ce(e, t) {
	return e?.awake && e.id === 6 ? Math.max(...w.map((e) => t.filter((t) => t.habitat === e).length)) : 0;
}
function we(e, t, n) {
	if (!e?.awake) return 0;
	let r = _e.find((t) => t.id === e.id);
	return r ? r.species.length + t.reduce((e, t) => e + t.species.filter((e) => r.species.includes(e)).length, 0) + n.filter((e) => r.species.includes(e.species)).length : 0;
}
//#endregion
//#region src/game/board.ts
function R(e) {
	return `${e.row}:${e.column}`;
}
function Te(e) {
	let { row: t, column: n } = e, r = t % 2 == 0 ? n : n - 1;
	return [
		{
			row: t,
			column: n - 1
		},
		{
			row: t,
			column: n + 1
		},
		{
			row: t - 1,
			column: r
		},
		{
			row: t - 1,
			column: r + 1
		},
		{
			row: t + 1,
			column: r
		},
		{
			row: t + 1,
			column: r + 1
		}
	];
}
function Ee(e, t) {
	let n = new Set(t.map(R)), r = e.filter((e) => (e.terrain === "plain" || e.terrain === "mountain") && !n.has(R(e))), i = new Map(r.map((e) => [R(e), e])), a = [];
	for (let e of r) for (let t of Te(e)) {
		let n = i.get(R(t));
		!n || R(e) >= R(n) || a.push({
			cells: [{
				row: e.row,
				column: e.column
			}, {
				row: n.row,
				column: n.column
			}],
			mountainCost: +(e.terrain === "mountain" || n.terrain === "mountain")
		});
	}
	return a;
}
function De(e, t) {
	let n = new Set(t.flatMap(Te).map(R));
	return e.filter((e) => e.terrain === "habitat" && n.has(R(e)));
}
//#endregion
//#region src/game/placement.ts
function Oe(e, t, n) {
	if (e.habitat === "net") return [{ kind: "net" }];
	let r = e.habitat, i = t.flatMap((e, t) => e !== null && n(e) === r ? [{
		kind: "card",
		slot: t,
		card: e
	}] : []);
	return [{
		kind: "resource",
		resource: r
	}, ...i];
}
function ke(e, t, n, r) {
	let i = new Set(t.flatMap((e) => e.flatMap(Te)).map(R)), a = new Set(r.map(R)), o = n.flatMap((e) => i.has(R(e)) ? [{
		kind: "egg",
		position: {
			row: e.row,
			column: e.column
		},
		species: e.species
	}] : []), s = e.flatMap((e) => e.terrain === "habitat" && e.special && i.has(R(e)) && !a.has(R(e)) ? [{
		kind: "special",
		cell: e
	}] : []);
	return [...o, ...s];
}
//#endregion
//#region src/game/explorer-action.ts
function Ae(e, t) {
	return e.length === 2 && t.length === 2 && new Set(e.map(R)).size === 2 && e.every((e) => t.some((t) => R(e) === R(t)));
}
function je(e) {
	if (e.explorers.some((t) => t.owner === e.owner && t.piece === e.piece)) return null;
	let t = e.explorers.flatMap((e) => e.cells), n = Ee(e.board, t), r = n.find((t) => Ae(t.cells, e.cells));
	if (!r) return null;
	let i = e.piece === "captain" && e.captain === "helena" && e.captainUnlocked, a = E(e.resources) === 0 && n.length === 1, o = r.mountainCost === 1 && !i && !a;
	if (o) {
		if (e.payment === null || !w.includes(e.payment) || e.resources[e.payment] < 1) return null;
	} else if (e.payment !== null) return null;
	let s = { ...e.resources };
	o && e.payment !== null && s[e.payment]--;
	let c = new Set(e.cells.map(R));
	return {
		resources: s,
		boardEggs: e.boardEggs.filter((e) => !c.has(R(e))),
		action: {
			explorer: {
				owner: e.owner,
				piece: e.piece,
				cells: e.cells.map((e) => ({ ...e }))
			},
			coveredEggs: e.boardEggs.filter((e) => c.has(R(e))),
			remainingHabitats: De(e.board, e.cells)
		}
	};
}
function Me(e, t) {
	let n = e.coveredEggs.findIndex((e) => R(e) === R(t));
	return n < 0 ? null : {
		action: {
			...e,
			coveredEggs: e.coveredEggs.filter((e, t) => t !== n)
		},
		egg: e.coveredEggs[n]
	};
}
function z(e, t, n, r, i) {
	if (e.coveredEggs.length > 0) return null;
	let a = e.remainingHabitats.findIndex((e) => R(e) === R(t));
	if (a < 0) return null;
	let o = Oe(e.remainingHabitats[a], r, i).find((e) => e.kind === n.kind && (e.kind === "net" || e.kind === "resource" && n.kind === "resource" && e.resource === n.resource || e.kind === "card" && n.kind === "card" && e.slot === n.slot && e.card === n.card));
	return o ? {
		action: {
			...e,
			remainingHabitats: e.remainingHabitats.filter((e, t) => t !== a)
		},
		reward: o
	} : null;
}
function Ne(e) {
	let [t, n] = e, r = t.column - Math.ceil(t.row / 2), i = n.column - Math.ceil(n.row / 2), a = 2 * n.row - t.row;
	return {
		row: a,
		column: 2 * i - r + Math.ceil(a / 2)
	};
}
function Pe(e, t) {
	if (e.explorer.piece !== "captain") return null;
	let n = R(Ne(e.explorer.cells));
	return t.find((e) => R(e) === n && e.terrain === "habitat" && e.special !== void 0) ?? null;
}
//#endregion
//#region src/game/explorer-pack.ts
var Fe = [
	{
		id: 1,
		cost: 1,
		effect: "freeAchievement",
		name: {
			zh: "云翼蛇",
			en: "Serbusard"
		},
		ability: {
			zh: "每局一次，免费完成一项符合条件的目标，并取得其奖励和奖杯。",
			en: "Once per game, complete an eligible achievement without spending a basic action and gain its reward and trophy."
		}
	},
	{
		id: 2,
		cost: 2,
		effect: "restoreEnergy",
		name: {
			zh: "厚甲兽",
			en: "Pachydosaure"
		},
		ability: {
			zh: "每局一次，将保护区中一张能量牌的能量补至上限。",
			en: "Once per game, fully restore the energy of one Energy card in your reserve."
		}
	},
	{
		id: 3,
		cost: 1,
		effect: "timeResources",
		name: {
			zh: "赤蝎兽",
			en: "Scorpiandre"
		},
		ability: {
			zh: "每局一次，获得一份任选资源；每有一个已揭示的时间标记，再获得一份任选资源。",
			en: "Once per game, gain one resource of your choice, plus one for each revealed time token. You may choose different resources."
		}
	},
	{
		id: 4,
		cost: 1,
		effect: "startingWilderness",
		name: {
			zh: "瀑鳞兽",
			en: "Hippocoque"
		},
		ability: {
			zh: "开局时，从荒野取得两张幻兽牌并补满荒野。",
			en: "At the start of the game, take two cards from the wilderness and refill it."
		}
	},
	{
		id: 5,
		cost: 2,
		effect: "activateRecharge",
		name: {
			zh: "霜鬃兽",
			en: "Féligel"
		},
		ability: {
			zh: "每局一次，按你选择的顺序激活保护区内的所有充能牌。",
			en: "Once per game, activate all Recharge cards in your reserve in an order of your choice."
		}
	},
	{
		id: 6,
		cost: 0,
		effect: "returnExplorer",
		name: {
			zh: "螺壳章鱼",
			en: "Escarpoulpe"
		},
		ability: {
			zh: "每局一次，收回地图上的一名自己的探险者，包括船长。",
			en: "Once per game, retrieve one of your explorers from the board, including your captain."
		}
	},
	{
		id: 7,
		cost: 2,
		effect: "timeEggs",
		name: {
			zh: "赤角龙",
			en: "Béliodonte"
		},
		ability: {
			zh: "每局一次，每有一个已揭示的时间标记，就从库存获得一个任选物种的蛋。",
			en: "Once per game, gain one egg of your choice from the stock for each revealed time token. You may choose different species."
		}
	},
	{
		id: 8,
		cost: 1,
		effect: "startingCaptain",
		name: {
			zh: "澜鳍鲸",
			en: "Cétalame"
		},
		ability: {
			zh: "开局时，立即解锁船长能力。",
			en: "At the start of the game, immediately unlock your captain power."
		}
	},
	{
		id: 9,
		cost: 0,
		effect: "replace",
		name: {
			zh: "蝶翼猫",
			en: "Chapillon"
		},
		ability: {
			zh: "开局时获得两分，将此牌换成随机的未选探险者牌，支付新牌费用并执行其开局能力。",
			en: "At the start of the game, gain two points, replace this card with a random unchosen Explorer card, pay its cost and resolve its start-of-game ability."
		}
	}
];
function Ie(e, t, n, r = "standard") {
	if (e.length < 1 || e.length > 4 || new Set(e).size !== e.length) throw Error("Invalid explorer draft players");
	let i = Fe.map((e) => e.id), a = r === "reverse" ? {
		items: i,
		cursor: n
	} : M(i, t, n);
	return {
		seed: t,
		cursor: a.cursor,
		phase: "selecting",
		mode: r,
		players: e.map((e, t) => ({
			owner: e,
			candidates: r === "reverse" ? [...a.items] : a.items.slice(t * 2, t * 2 + 2),
			selected: null,
			replacementBonus: 0,
			paid: !1
		}))
	};
}
function Le(e, t, n) {
	if (e.phase !== "selecting") return null;
	let r = e.players.find((e) => e.owner === t);
	if (!r || r.selected !== null || !r.candidates.includes(n) || e.mode === "reverse" && [...e.players].reverse().find((e) => e.selected === null)?.owner !== t) return null;
	let i = e.players.map((r) => r.owner === t ? {
		...r,
		selected: n
	} : e.mode === "reverse" ? {
		...r,
		candidates: r.candidates.filter((e) => e !== n)
	} : r);
	if (i.some((e) => e.selected === null)) return {
		...e,
		players: i
	};
	let a = e.cursor, o = i.find((e) => e.selected === 9);
	if (o) {
		let t = new Set(i.map((e) => e.selected)), n = M(Fe.map((e) => e.id).filter((e) => !t.has(e)), e.seed, a);
		a = n.cursor;
		let r = n.items[0];
		if (r === void 0) throw Error("Missing replacement explorer card");
		i = i.map((e) => e.owner === o.owner ? {
			...e,
			selected: r,
			replacementBonus: 2
		} : e);
	}
	return {
		...e,
		players: i.map((e) => ({
			...e,
			candidates: []
		})),
		cursor: a,
		phase: "paying"
	};
}
function Re(e, t, n) {
	if (e.phase !== "paying") return null;
	let r = e.players.find((e) => e.owner === t), i = Fe.find((e) => e.id === r?.selected);
	if (!r || r.paid || !i || w.some((e) => !Number.isInteger(n.payment[e]) || n.payment[e] < 0)) return null;
	let a = n.resources, o;
	if (n.scenarioOneHand) {
		let e = n.removedCards ?? [];
		if (E(n.payment) !== 0 || e.length !== i.cost || new Set(e).size !== e.length || e.some((e) => !n.scenarioOneHand.includes(e))) return null;
		o = n.scenarioOneHand.filter((t) => !e.includes(t));
	} else {
		if (n.removedCards?.length || E(n.payment) !== i.cost) return null;
		let e = O(n.resources, n.payment);
		if (!e) return null;
		a = e;
	}
	let s = e.players.map((e) => e.owner === t ? {
		...e,
		paid: !0
	} : e);
	return {
		draft: {
			...e,
			players: s,
			phase: s.every((e) => e.paid) ? "ready" : "paying"
		},
		resources: a,
		...o ? { hand: o } : {}
	};
}
//#endregion
//#region src/game/explorer-powers.ts
function ze(e, t, n, r) {
	if (e.phase !== "turn" || e.activePlayer !== t) return null;
	let i = e.setup.players.find((e) => e.rid === t), a = e.players.find((e) => e.rid === t);
	if (!i || !a) return null;
	if (n === 1 && r.kind === "achievement") {
		if (r.advanceBeast && !e.beasts?.owned[t]) return null;
		let n = he({
			owner: t,
			achievements: e.setup.achievements,
			claims: e.claims,
			playerCount: e.players.length,
			achievement: r.achievement,
			slot: r.slot,
			marker: r.marker,
			useMarkerReward: r.useMarkerReward,
			advanceBeast: r.advanceBeast,
			selection: r.selection,
			reserve: {
				cards: a.reserve,
				eggs: i.eggs,
				extraSpecies: ve(e.beasts, t)
			}
		});
		return n ? {
			state: {
				...e,
				claims: [...e.claims, {
					...n.claim,
					usedMarkerReward: !1
				}]
			},
			tasks: ge(n.steps, n.claim.marker, n.claim.usedMarkerReward, e.setup.achievements.find((e) => e.id === r.achievement)?.kind === "main" ? Ce(e.beasts?.owned[t], a.reserve) : 0)
		} : null;
	}
	if (n === 6 && r.kind === "returnExplorer") return e.explorers.some((e) => e.owner === t && e.piece === r.piece) ? {
		state: {
			...e,
			explorers: e.explorers.filter((e) => e.owner !== t || e.piece !== r.piece)
		},
		tasks: []
	} : null;
	if (r.kind !== "activate") return null;
	if (n === 2) return a.energy.length ? {
		state: e,
		tasks: [{ kind: "restoreEnergy" }]
	} : null;
	if (n === 3) return {
		state: e,
		tasks: [{
			kind: "resources",
			remaining: 1 + e.revealedTimeTokens.length
		}]
	};
	if (n === 5) return a.reserve.some((e) => e.type === "recharge") ? {
		state: e,
		tasks: [{ kind: "activateAllRecharge" }]
	} : null;
	if (n === 7) {
		let t = e.revealedTimeTokens.length;
		return {
			state: e,
			tasks: Array.from({ length: t }, () => ({
				kind: "chooseEgg",
				species: [...T]
			}))
		};
	}
	return null;
}
//#endregion
//#region src/game/terms.ts
var B = {
	fruit: {
		zh: "果实",
		en: "Fruit"
	},
	coral: {
		zh: "珊瑚",
		en: "Coral"
	},
	flower: {
		zh: "花朵",
		en: "Flower"
	},
	mushroom: {
		zh: "蘑菇",
		en: "Mushroom"
	}
}, V = {
	crustacean: {
		zh: "甲壳类",
		en: "Crustacean"
	},
	mammal: {
		zh: "哺乳类",
		en: "Mammal"
	},
	bird: {
		zh: "鸟类",
		en: "Bird"
	},
	reptile: {
		zh: "爬行类",
		en: "Reptile"
	},
	fish: {
		zh: "鱼类",
		en: "Fish"
	},
	insect: {
		zh: "昆虫",
		en: "Insect"
	},
	dragon: {
		zh: "龙类",
		en: "Dragon"
	}
}, Be = {
	instant: {
		zh: "即时",
		en: "Instant"
	},
	permanent: {
		zh: "持续",
		en: "Permanent"
	},
	energy: {
		zh: "能量",
		en: "Energy"
	},
	recharge: {
		zh: "充能",
		en: "Recharge"
	},
	endGame: {
		zh: "终局",
		en: "End of game"
	}
};
//#endregion
//#region src/game/cards-001-017.ts
function Ve(e) {
	if (e.kind === "scorePerHabitat") {
		let t = B[e.habitat];
		return {
			zh: `保护区中每有一个${t.zh}栖地图标，获得 2 分，包括这张牌的图标。最多获得 10 分。`,
			en: `Gain 2 points for each ${t.en} habitat icon in your reserve, including this card. Gain at most 10 points.`
		};
	}
	if (e.kind === "activateMapSpecial") {
		let t = B[e.habitat];
		return {
			zh: `选择地图上一个${t.zh}栖地，激活其中的一个特殊效果。`,
			en: `Choose a ${t.en} habitat on the map and activate one of its special effects.`
		};
	}
	if (e.kind === "discountAndScore") {
		let t = B[e.habitat];
		return {
			zh: `打出此牌时，保护区中已有的每个${t.zh}栖地图标使费用减少 1 份资源。获得 3 分。`,
			en: `Play this card for one fewer resource for each ${t.en} habitat icon already in your reserve. Gain 3 points.`
		};
	}
	if (e.kind === "drawAndScoreMatchingHabitat") return {
		zh: "充能时，抽一张牌。保护区中每有一个与所抽牌相同的栖地图标，获得 1 分，最多获得 5 分。",
		en: "When recharging, draw one card. Gain 1 point for each matching habitat icon in your reserve, up to 5 points."
	};
	if (e.kind === "scoreMostHabitat") return {
		zh: "选择保护区中数量最多的一种栖地图标，每有一个该图标获得 1 分。",
		en: "Choose a habitat icon you have the most of in your reserve. Gain 1 point for each of those icons."
	};
	if (e.kind === "scoreForExpensiveCard") return {
		zh: "每次打出印刷费用至少为 4 份资源的牌时，获得 2 分，包括打出此牌时。",
		en: "Each time you play a card with a printed cost of at least 4 resources, including this card, gain 2 points."
	};
	if (e.kind === "rechargeMostHabitat") return {
		zh: "充能时，选择保护区中数量最多的一种栖地图标，获得 2 份与其对应的资源。",
		en: "When recharging, choose a habitat icon you have the most of in your reserve and gain 2 matching resources."
	};
	let t = V[e.species];
	return {
		zh: `终局时，保护区中每有一个${t.zh}图标，获得 1 分。已孵化和未孵化的蛋都计入。`,
		en: `At the end of the game, gain 1 point per ${t.en} icon in your reserve, including hatched and unhatched eggs.`
	};
}
var He = [
	{
		id: 1,
		name: {
			zh: "苹壳兽",
			en: "Applet"
		},
		habitat: "fruit",
		species: ["crustacean"],
		type: "instant",
		cost: {
			fruit: 3,
			mushroom: 1
		},
		printedPoints: 1,
		effect: {
			kind: "scorePerHabitat",
			habitat: "fruit",
			pointsPerIcon: 2,
			maximum: 10
		}
	},
	{
		id: 2,
		name: {
			zh: "背刺花甲兽",
			en: "Backactooth"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 2
		},
		printedPoints: 1,
		effect: {
			kind: "scorePerHabitat",
			habitat: "flower",
			pointsPerIcon: 2,
			maximum: 10
		}
	},
	{
		id: 3,
		name: {
			zh: "甲熊",
			en: "Bearmour"
		},
		habitat: "fruit",
		species: ["crustacean"],
		type: "instant",
		cost: { fruit: 2 },
		printedPoints: 2,
		effect: {
			kind: "activateMapSpecial",
			habitat: "fruit"
		}
	},
	{
		id: 4,
		name: {
			zh: "洞栖鳄兽",
			en: "Cavigator"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "instant",
		cost: { mushroom: 4 },
		printedPoints: 2,
		effect: {
			kind: "discountAndScore",
			habitat: "mushroom",
			points: 3
		}
	},
	{
		id: 5,
		name: {
			zh: "卷角螺兽",
			en: "Curechino"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "instant",
		cost: { mushroom: 2 },
		printedPoints: 2,
		effect: {
			kind: "activateMapSpecial",
			habitat: "mushroom"
		}
	},
	{
		id: 6,
		name: {
			zh: "地犬蟹",
			en: "Doground"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "recharge",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "drawAndScoreMatchingHabitat",
			maximum: 5
		}
	},
	{
		id: 7,
		name: {
			zh: "伊甸甲虫",
			en: "Edenborn"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "instant",
		cost: { mushroom: 2 },
		printedPoints: 2,
		effect: { kind: "scoreMostHabitat" }
	},
	{
		id: 8,
		name: {
			zh: "山羊泰坦",
			en: "Goatitan"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "instant",
		cost: { flower: 2 },
		printedPoints: 2,
		effect: {
			kind: "activateMapSpecial",
			habitat: "flower"
		}
	},
	{
		id: 9,
		name: {
			zh: "菇甲穿山兽",
			en: "Pangshroam"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 2
		},
		printedPoints: 1,
		effect: {
			kind: "scorePerHabitat",
			habitat: "mushroom",
			pointsPerIcon: 2,
			maximum: 10
		}
	},
	{
		id: 10,
		name: {
			zh: "泥沼法老蟹",
			en: "Pharabog"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "permanent",
		cost: {
			coral: 1,
			flower: 2,
			mushroom: 1
		},
		printedPoints: 1,
		effect: {
			kind: "scoreForExpensiveCard",
			minimumCost: 4,
			points: 2
		}
	},
	{
		id: 11,
		name: {
			zh: "粉泡蛙",
			en: "Pinkroak"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "recharge",
		cost: {
			coral: 3,
			flower: 1
		},
		printedPoints: 2,
		effect: {
			kind: "rechargeMostHabitat",
			amount: 2
		}
	},
	{
		id: 12,
		name: {
			zh: "沙漠龙",
			en: "Sandraco"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "instant",
		cost: { flower: 4 },
		printedPoints: 2,
		effect: {
			kind: "discountAndScore",
			habitat: "flower",
			points: 3
		}
	},
	{
		id: 13,
		name: {
			zh: "海象枪兽",
			en: "Sealocanth"
		},
		habitat: "coral",
		species: ["crustacean"],
		type: "instant",
		cost: { coral: 2 },
		printedPoints: 2,
		effect: {
			kind: "activateMapSpecial",
			habitat: "coral"
		}
	},
	{
		id: 14,
		name: {
			zh: "寄居盔",
			en: "Shellmit"
		},
		habitat: "coral",
		species: ["crustacean"],
		type: "instant",
		cost: {
			coral: 3,
			mushroom: 1
		},
		printedPoints: 1,
		effect: {
			kind: "scorePerHabitat",
			habitat: "coral",
			pointsPerIcon: 2,
			maximum: 10
		}
	},
	{
		id: 15,
		name: {
			zh: "日矢虾",
			en: "Sunarrow"
		},
		habitat: "coral",
		species: ["crustacean", "crustacean"],
		type: "endGame",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 0,
		effect: {
			kind: "endSpecies",
			species: "crustacean"
		}
	},
	{
		id: 16,
		name: {
			zh: "翠林巨龟",
			en: "Verieberree"
		},
		habitat: "fruit",
		species: ["crustacean"],
		type: "instant",
		cost: { fruit: 4 },
		printedPoints: 2,
		effect: {
			kind: "discountAndScore",
			habitat: "fruit",
			points: 3
		}
	},
	{
		id: 17,
		name: {
			zh: "深海巨口兽",
			en: "Watereo"
		},
		habitat: "coral",
		species: ["crustacean"],
		type: "instant",
		cost: { coral: 4 },
		printedPoints: 2,
		effect: {
			kind: "discountAndScore",
			habitat: "coral",
			points: 3
		}
	}
].map((e) => ({
	...e,
	ability: Ve(e.effect)
}));
//#endregion
//#region src/game/cards-018-034.ts
function Ue(e) {
	switch (e.kind) {
		case "rechargeTrophyResource": {
			let t = B[e.resource];
			return {
				zh: `充能时，获得 1 份${t.zh}；每有 3 个奖杯，再获得 1 份${t.zh}。`,
				en: `When recharging, gain 1 ${t.en}. Gain 1 more ${t.en} for every 3 trophies you have.`
			};
		}
		case "trophyActivatesRecharge": return {
			zh: "每次获得奖杯时，激活保护区中的一张充能牌。",
			en: "Each time you gain a trophy, activate one Recharge card in your reserve."
		};
		case "endMammal": return {
			zh: "终局时，保护区中每有一个哺乳类图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Mammal icon in your reserve, including hatched and unhatched eggs."
		};
		case "energyResourceAndExchange": return {
			zh: "消耗此牌上的 1 枚能量，获得 1 份任选资源。你还可以将任意数量的一种资源按一比一换成另一种资源。",
			en: "Spend 1 energy from this card to gain 1 resource of your choice. You may also exchange any number of one resource type for another at a one-to-one rate."
		};
		case "rechargeLeastTrophyResource": return {
			zh: "充能时，选择你持有最少的一种资源，获得 1 份该资源；每有 3 个奖杯，再获得 1 份同种资源。",
			en: "When recharging, choose a resource you have the least of and gain 1 of it, plus 1 more of the same resource for every 3 trophies you have."
		};
		case "energyFreeRechargeCard": return {
			zh: "消耗此牌上的 1 枚能量，免费打出一张手中的充能牌。这不占用基本行动。",
			en: "Spend 1 energy from this card to play a Recharge card from your hand for free. This does not use a basic action."
		};
		case "activateRechargeAndEgg": return {
			zh: "激活保护区中的一张充能牌，然后可以获得一个与该牌物种相符的蛋。",
			en: "Activate one Recharge card in your reserve, then you may gain an egg matching its species."
		};
		case "energyTrophyResource": return {
			zh: "消耗此牌上的 1 枚能量，获得 1 份任选资源；每有 3 个奖杯，再获得 1 份同种资源。",
			en: "Spend 1 energy from this card to gain 1 resource of your choice, plus 1 more of the same resource for every 3 trophies you have."
		};
		case "energyActivateRecharge": return {
			zh: "消耗此牌上的 1 枚能量，激活保护区中的一张充能牌。",
			en: "Spend 1 energy from this card to activate one Recharge card in your reserve."
		};
		case "activateTwoRecharge": return {
			zh: "选择并激活保护区中至多两张不同的充能牌。",
			en: "Choose and activate up to two different Recharge cards in your reserve."
		};
		case "trophyScore": return {
			zh: "每次获得奖杯时，获得 2 分。",
			en: "Each time you gain a trophy, gain 2 points."
		};
		case "rechargeActivationScore": return {
			zh: "每次激活保护区中的一张充能牌时，获得 1 分。",
			en: "Each time you activate a Recharge card in your reserve, gain 1 point."
		};
		case "rechargeLeastResourceAndScore": return {
			zh: "充能时，选择你持有最少的一种资源，获得 1 份该资源；然后按你现有的这种资源数量，每份获得 1 分。",
			en: "When recharging, choose a resource you have the least of and gain 1 of it. Then gain 1 point for each resource of that type you have."
		};
	}
}
var H = [
	{
		id: 18,
		name: {
			zh: "冰晶豹",
			en: "Cryodon"
		},
		habitat: "coral",
		species: ["mammal"],
		type: "recharge",
		cost: {
			fruit: 2,
			coral: 1
		},
		printedPoints: 3,
		effect: {
			kind: "rechargeTrophyResource",
			resource: "coral"
		}
	},
	{
		id: 19,
		name: {
			zh: "晶岩羊驼",
			en: "Crystalama"
		},
		habitat: "mushroom",
		species: ["mammal"],
		type: "permanent",
		cost: {
			coral: 2,
			flower: 1,
			mushroom: 2
		},
		printedPoints: 1,
		effect: { kind: "trophyActivatesRecharge" }
	},
	{
		id: 20,
		name: {
			zh: "叶甲狮",
			en: "Dracougar"
		},
		habitat: "fruit",
		species: ["mammal", "mammal"],
		type: "endGame",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 0,
		effect: { kind: "endMammal" }
	},
	{
		id: 21,
		name: {
			zh: "森树象",
			en: "Elepharm"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "energy",
		cost: {
			fruit: 1,
			flower: 2
		},
		printedPoints: 2,
		energyCapacity: 2,
		effect: { kind: "energyResourceAndExchange" }
	},
	{
		id: 22,
		name: {
			zh: "桉林领主",
			en: "Eucalord"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "recharge",
		cost: {
			fruit: 3,
			coral: 1
		},
		printedPoints: 4,
		effect: { kind: "rechargeLeastTrophyResource" }
	},
	{
		id: 23,
		name: {
			zh: "绒球犬",
			en: "Globeon"
		},
		habitat: "flower",
		species: ["mammal"],
		type: "energy",
		cost: {
			fruit: 2,
			flower: 2
		},
		printedPoints: 2,
		energyCapacity: 1,
		effect: { kind: "energyFreeRechargeCard" }
	},
	{
		id: 24,
		name: {
			zh: "囤果仓鼠",
			en: "Hamstore"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "recharge",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 3,
		effect: {
			kind: "rechargeTrophyResource",
			resource: "fruit"
		}
	},
	{
		id: 25,
		name: {
			zh: "熔焰猿",
			en: "Magape"
		},
		habitat: "mushroom",
		species: ["mammal"],
		type: "recharge",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 3,
		effect: {
			kind: "rechargeTrophyResource",
			resource: "mushroom"
		}
	},
	{
		id: 26,
		name: {
			zh: "长毛鲸兽",
			en: "Mammothog"
		},
		habitat: "coral",
		species: ["mammal"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "activateRechargeAndEgg" }
	},
	{
		id: 27,
		name: {
			zh: "绒鲸兽",
			en: "Mommhog"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "activateRechargeAndEgg" }
	},
	{
		id: 28,
		name: {
			zh: "坚果獾",
			en: "Nutabi"
		},
		habitat: "mushroom",
		species: ["mammal"],
		type: "energy",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 1,
		energyCapacity: 2,
		effect: { kind: "energyTrophyResource" }
	},
	{
		id: 29,
		name: {
			zh: "紫耳灵狐",
			en: "Pheoxi"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "energy",
		cost: {
			fruit: 2,
			mushroom: 2
		},
		printedPoints: 1,
		energyCapacity: 2,
		effect: { kind: "energyActivateRecharge" }
	},
	{
		id: 30,
		name: {
			zh: "蜜袋骑士",
			en: "Sugarider"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "instant",
		cost: {
			fruit: 2,
			coral: 2
		},
		printedPoints: 3,
		effect: { kind: "activateTwoRecharge" }
	},
	{
		id: 31,
		name: {
			zh: "雷霆巨猩",
			en: "Thunderilla"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "permanent",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: {
			kind: "trophyScore",
			points: 2
		}
	},
	{
		id: 32,
		name: {
			zh: "花冠巨角兽",
			en: "Triumpithon"
		},
		habitat: "flower",
		species: ["mammal"],
		type: "recharge",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 3,
		effect: {
			kind: "rechargeTrophyResource",
			resource: "flower"
		}
	},
	{
		id: 33,
		name: {
			zh: "隐纹狐猴",
			en: "Vikey"
		},
		habitat: "mushroom",
		species: ["mammal"],
		type: "permanent",
		cost: {
			flower: 1,
			mushroom: 2
		},
		printedPoints: 1,
		effect: {
			kind: "rechargeActivationScore",
			points: 1
		}
	},
	{
		id: 34,
		name: {
			zh: "寻路驼鹿",
			en: "Wayfinder"
		},
		habitat: "coral",
		species: ["mammal"],
		type: "recharge",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "rechargeLeastResourceAndScore" }
	}
].map((e) => ({
	...e,
	ability: Ue(e.effect)
}));
//#endregion
//#region src/game/cards-035-051.ts
function We(e) {
	switch (e.kind) {
		case "playWildernessPayCost": return {
			zh: "选择荒野中的一张牌，支付费用并立即打出。这不占用基本行动。",
			en: "Choose a card from the Wilderness, pay its cost and play it immediately. This does not use a basic action."
		};
		case "takeWildernessAndTwoResources": return {
			zh: "从荒野中取得一张牌，然后获得 2 份与该牌栖地对应的资源。",
			en: "Take one card from the Wilderness, then gain 2 resources matching its habitat."
		};
		case "activateEndScore": return {
			zh: "选择保护区中的一张终局牌，立即计算其能力分数，最多获得 10 分；该牌在终局仍正常计分。",
			en: "Choose an End of game card in your reserve and score its ability immediately, up to 10 points. It still scores normally at the end of the game."
		};
		case "energyFreeEndCard": return {
			zh: "消耗此牌上的 1 枚能量，免费打出手牌或荒野中的一张终局牌。这不占用基本行动。",
			en: "Spend 1 energy from this card to play an End of game card from your hand or the Wilderness for free. This does not use a basic action."
		};
		case "rechargeEndCardScore": return {
			zh: "充能时，保护区中每有一张终局牌，获得 1 分，最多获得 5 分。",
			en: "When recharging, gain 1 point for each End of game card in your reserve, up to 5 points."
		};
		case "takeSpeciesCardsAndScore": return {
			zh: "选择一种物种，将荒野中带有该物种图标的所有牌加入手牌，每取得一张牌获得 1 分。",
			en: "Choose a species and take every Wilderness card bearing that species icon. Gain 1 point for each card taken."
		};
		case "sweepAndTake": return {
			zh: "扫荡荒野的一侧，然后从荒野中取得一张牌。",
			en: "Sweep one side of the Wilderness, then take one card from the Wilderness."
		};
		case "takeWildernessAndEgg": return {
			zh: "从荒野中取得一张牌，然后获得一个与该牌物种相符的蛋。若该牌有多个物种，由你选择一种。",
			en: "Take one card from the Wilderness, then gain an egg matching its species. If it has multiple species, choose one."
		};
		case "endBird": return {
			zh: "终局时，保护区中每有一个鸟类图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Bird icon in your reserve, including hatched and unhatched eggs."
		};
		case "freeWildernessCard": return {
			zh: "免费打出荒野中的一张牌。这不占用基本行动。",
			en: "Play one Wilderness card for free. This does not use a basic action."
		};
		case "energyTakeWilderness": return {
			zh: "消耗此牌上的 1 枚能量，从荒野中取得一张牌。",
			en: "Spend 1 energy from this card to take one card from the Wilderness."
		};
	}
}
var Ge = [
	{
		id: 35,
		name: {
			zh: "雪羽林后",
			en: "Arbokueen"
		},
		habitat: "coral",
		species: ["bird"],
		type: "instant",
		cost: { coral: 1 },
		printedPoints: 1,
		effect: { kind: "playWildernessPayCost" }
	},
	{
		id: 36,
		name: {
			zh: "彩羽林王",
			en: "Arboqing"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "instant",
		cost: { fruit: 1 },
		printedPoints: 1,
		effect: { kind: "playWildernessPayCost" }
	},
	{
		id: 37,
		name: {
			zh: "花翎鸟",
			en: "Florarzei"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 3,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "takeWildernessAndTwoResources" }
	},
	{
		id: 38,
		name: {
			zh: "花冠鹦",
			en: "Floratzel"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 3,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "takeWildernessAndTwoResources" }
	},
	{
		id: 39,
		name: {
			zh: "林羽狮鹫",
			en: "Gryffling"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 2
		},
		printedPoints: 2,
		effect: {
			kind: "activateEndScore",
			maximum: 10
		}
	},
	{
		id: 40,
		name: {
			zh: "海羽狮鹫",
			en: "Gryphocean"
		},
		habitat: "coral",
		species: ["bird"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 2
		},
		printedPoints: 2,
		effect: {
			kind: "activateEndScore",
			maximum: 10
		}
	},
	{
		id: 41,
		name: {
			zh: "倒挂羽蝠",
			en: "Hanguine"
		},
		habitat: "coral",
		species: ["bird"],
		type: "energy",
		cost: {
			coral: 2,
			mushroom: 2
		},
		printedPoints: 1,
		energyCapacity: 1,
		effect: { kind: "energyFreeEndCard" }
	},
	{
		id: 42,
		name: {
			zh: "林冠鹰",
			en: "Hawkwaka"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "recharge",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: {
			kind: "rechargeEndCardScore",
			maximum: 5
		}
	},
	{
		id: 43,
		name: {
			zh: "跃羽帝鸟",
			en: "Jumperor"
		},
		habitat: "mushroom",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "takeSpeciesCardsAndScore" }
	},
	{
		id: 44,
		name: {
			zh: "跃羽后鸟",
			en: "Jumpress"
		},
		habitat: "mushroom",
		species: ["bird"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "takeSpeciesCardsAndScore" }
	},
	{
		id: 45,
		name: {
			zh: "夜行鸮",
			en: "Nighthief"
		},
		habitat: "coral",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 1
		},
		printedPoints: 2,
		effect: { kind: "sweepAndTake" }
	},
	{
		id: 46,
		name: {
			zh: "夜影鸮",
			en: "Nightogue"
		},
		habitat: "flower",
		species: ["bird"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "sweepAndTake" }
	},
	{
		id: 47,
		name: {
			zh: "暮羽鸮",
			en: "Owlean"
		},
		habitat: "flower",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "takeWildernessAndEgg" }
	},
	{
		id: 48,
		name: {
			zh: "曙羽鸮",
			en: "Owlite"
		},
		habitat: "flower",
		species: ["bird"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "takeWildernessAndEgg" }
	},
	{
		id: 49,
		name: {
			zh: "苍穹霸鸟",
			en: "Skyrant"
		},
		habitat: "mushroom",
		species: ["bird", "bird"],
		type: "endGame",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 0,
		effect: { kind: "endBird" }
	},
	{
		id: 50,
		name: {
			zh: "星喙鸟",
			en: "Starbeak"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 3
		},
		printedPoints: 2,
		effect: { kind: "freeWildernessCard" }
	},
	{
		id: 51,
		name: {
			zh: "奇羽天鹅",
			en: "Swonder"
		},
		habitat: "coral",
		species: ["bird"],
		type: "energy",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 3,
		energyCapacity: 2,
		effect: { kind: "energyTakeWilderness" }
	}
].map((e) => ({
	...e,
	ability: We(e.effect)
}));
//#endregion
//#region src/game/cards-052-067.ts
function Ke(e) {
	switch (e.kind) {
		case "activateLastInstant": return {
			zh: "立即激活此前最后打出的即时牌。若两张此类牌相互触发形成循环，则不产生效果。",
			en: "Immediately activate the last Instant card played before this one. If two such cards trigger each other in a loop, nothing happens."
		};
		case "trophyResource": return {
			zh: "每次获得奖杯时，获得 1 份任选资源。",
			en: "Each time you gain a trophy, gain 1 resource of your choice."
		};
		case "restoreEnergy": return {
			zh: "选择保护区中的一张能量牌，将其能量补至上限。不能补充船长板上的能量。",
			en: "Choose an Energy card in your reserve and restore it to its energy limit. You cannot restore energy on a captain board."
		};
		case "nextCardDiscount": return {
			zh: "本回合打出的下一张牌少支付 1 份资源；若本回合不再打牌，减免失效。",
			en: "Play your next card this turn for 1 fewer resource. The discount expires if you do not play another card this turn."
		};
		case "eggFromLastInstant": return {
			zh: "获得一个与此前最后打出的即时牌物种相符的未孵化蛋。若该牌有多个物种，由你选择一种。",
			en: "Gain an unhatched egg matching the species of the last Instant card played before this one. If it has multiple species, choose one."
		};
		case "freeSmallHandCard": return {
			zh: "免费打出一张印刷费用不超过 2 份资源的手牌。这不占用基本行动。",
			en: "Play one card from your hand with a printed cost of at most 2 resources for free. This does not use a basic action."
		};
		case "energyAddSpecies": return {
			zh: "消耗此牌上的 1 枚能量，选择一个此牌尚未拥有的物种，将对应的蛋放在此牌上作为额外物种图标。它不作为蛋存储、翻面或孵化。",
			en: "Spend 1 energy from this card to add a species it does not already have, using an egg as an extra species icon. That marker is not stored, flipped or hatched as an egg."
		};
		case "repeatAchievementReward": return {
			zh: "选择一项你已经获得过的目标标记奖励，再次获得该奖励。",
			en: "Choose an achievement marker reward you have already gained and gain it again."
		};
		case "instantCardScore": return {
			zh: "每次打出一张即时牌时，获得 1 分。",
			en: "Each time you play an Instant card, gain 1 point."
		};
		case "endReptile": return {
			zh: "终局时，保护区中每有一个爬行类图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Reptile icon in your reserve, including hatched and unhatched eggs."
		};
	}
}
var qe = [
	{
		id: 52,
		name: {
			zh: "果背蜥",
			en: "Berrong"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 2
		},
		printedPoints: 2,
		effect: { kind: "activateLastInstant" }
	},
	{
		id: 53,
		name: {
			zh: "霜纹蜥",
			en: "Blizard"
		},
		habitat: "coral",
		species: ["reptile"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 2
		},
		printedPoints: 2,
		effect: { kind: "activateLastInstant" }
	},
	{
		id: 54,
		name: {
			zh: "焰角蜥",
			en: "Chactiva"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "permanent",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "trophyResource" }
	},
	{
		id: 55,
		name: {
			zh: "珊瑚蛙王",
			en: "Frogain"
		},
		habitat: "coral",
		species: ["reptile"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 3,
		effect: { kind: "restoreEnergy" }
	},
	{
		id: 56,
		name: {
			zh: "珊瑚泡蛙",
			en: "Frogave"
		},
		habitat: "coral",
		species: ["reptile"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 3,
		effect: { kind: "restoreEnergy" }
	},
	{
		id: 57,
		name: {
			zh: "百合蜥",
			en: "Lilizard"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 1
		},
		printedPoints: 1,
		effect: { kind: "nextCardDiscount" }
	},
	{
		id: 58,
		name: {
			zh: "金翎形龙",
			en: "Metaforma"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 1,
		effect: { kind: "eggFromLastInstant" }
	},
	{
		id: 59,
		name: {
			zh: "墨翎形龙",
			en: "Metamorpha"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 1,
			flower: 1
		},
		printedPoints: 1,
		effect: { kind: "eggFromLastInstant" }
	},
	{
		id: 60,
		name: {
			zh: "菇顶蜥",
			en: "Mushmid"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 1,
		effect: {
			kind: "freeSmallHandCard",
			maximumCost: 2
		}
	},
	{
		id: 61,
		name: {
			zh: "菇灵",
			en: "Mushmidol"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "freeSmallHandCard",
			maximumCost: 2
		}
	},
	{
		id: 62,
		name: {
			zh: "莲叶蜥",
			en: "Nimfizard"
		},
		habitat: "coral",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 1
		},
		printedPoints: 1,
		effect: { kind: "nextCardDiscount" }
	},
	{
		id: 63,
		name: {
			zh: "紫霞甲龙",
			en: "Plataurora"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "energy",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 3,
		energyCapacity: 2,
		effect: { kind: "energyAddSpecies" }
	},
	{
		id: 64,
		name: {
			zh: "蔚蓝甲龙",
			en: "Platazul"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "energy",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 3,
		energyCapacity: 2,
		effect: { kind: "energyAddSpecies" }
	},
	{
		id: 65,
		name: {
			zh: "酬礼蜥",
			en: "Rewardino"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: { fruit: 2 },
		printedPoints: 2,
		effect: { kind: "repeatAchievementReward" }
	},
	{
		id: 66,
		name: {
			zh: "荒漠行龙",
			en: "Stridesert"
		},
		habitat: "flower",
		species: ["reptile"],
		type: "permanent",
		cost: {
			fruit: 2,
			flower: 2
		},
		printedPoints: 2,
		effect: {
			kind: "instantCardScore",
			points: 1
		}
	},
	{
		id: 67,
		name: {
			zh: "林陆巨龟",
			en: "Torterran"
		},
		habitat: "fruit",
		species: ["reptile", "reptile"],
		type: "endGame",
		cost: {
			fruit: 1,
			mushroom: 2
		},
		printedPoints: 0,
		effect: { kind: "endReptile" }
	}
].map((e) => ({
	...e,
	ability: Ke(e.effect)
}));
//#endregion
//#region src/game/cards-068-084.ts
function Je(e) {
	switch (e.kind) {
		case "rechargeDrawHabitat": return {
			zh: "充能时，抽一张牌，然后获得 1 份与该牌栖地对应的资源。",
			en: "When recharging, draw one card, then gain 1 resource matching its habitat."
		};
		case "rechargeDrawEgg": return {
			zh: "充能时，抽一张牌，然后获得一个与该牌物种相符的蛋；若有多个物种，由你选择一种。",
			en: "When recharging, draw one card, then gain an egg matching its species. If it has multiple species, choose one."
		};
		case "drawEgg": return {
			zh: "抽一张牌，然后获得一个与该牌物种相符的蛋；若有多个物种，由你选择一种。",
			en: "Draw one card, then gain an egg matching its species. If it has multiple species, choose one."
		};
		case "gainNets": return {
			zh: `获得 ${e.amount} 个网。`,
			en: `Gain ${e.amount} ${e.amount === 1 ? "net" : "nets"}.`
		};
		case "lookThreeScore": return {
			zh: "查看牌库顶的 3 张牌，选一张加入手牌并弃掉其余牌。立即获得所选牌印刷的终局分。",
			en: "Look at the top 3 cards of the deck, take one into your hand and discard the others. Immediately gain its printed end-game points."
		};
		case "drawThreeDiscard": return {
			zh: "抽 3 张牌加入手牌，然后可以弃掉一张手牌；弃掉的牌不必是刚抽到的牌。",
			en: "Draw 3 cards into your hand, then you may discard one card from your hand. It need not be one of the cards just drawn."
		};
		case "drawTriggerScore": return {
			zh: "每次从牌库抽一张牌时，获得 1 分。查看牌库并选牌的效果不算抽牌。",
			en: "Each time you draw a card from the deck, gain 1 point. Looking at cards and choosing one does not count as drawing."
		};
		case "drawHandScore": return {
			zh: "抽一张牌，然后手牌中每有一张牌获得 1 分，最多获得 10 分。",
			en: "Draw one card, then gain 1 point for each card in your hand, up to 10 points."
		};
		case "drawAndHandNet": return {
			zh: "抽一张牌。若此时手牌至少有 5 张，获得一个网。",
			en: "Draw one card. If you now have at least 5 cards in hand, gain one net."
		};
		case "energyDrawChooseTwo": return {
			zh: "消耗此牌上的 1 枚能量并抽一张牌，然后从以下三项中选择不同的两项：获得一个与该牌物种相符的蛋、获得 1 份与其栖地对应的资源、获得其印刷终局分。",
			en: "Spend 1 energy from this card and draw one card, then choose two different rewards: an egg matching its species, 1 resource matching its habitat, or its printed end-game points."
		};
		case "energyLookThreeResource": return {
			zh: "消耗此牌上的 1 枚能量，查看牌库顶的 3 张牌，选一张加入手牌并弃掉其余牌；获得 1 份与所选牌栖地对应的资源。",
			en: "Spend 1 energy from this card to look at the top 3 cards, take one into your hand and discard the others; gain 1 resource matching the chosen card’s habitat."
		};
		case "endFish": return {
			zh: "终局时，保护区中每有一个鱼类图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Fish icon in your reserve, including hatched and unhatched eggs."
		};
	}
}
var Ye = [
	{
		id: 68,
		name: {
			zh: "香花鳄鱼",
			en: "Aromalli"
		},
		habitat: "fruit",
		species: ["fish"],
		type: "recharge",
		cost: {
			fruit: 2,
			coral: 1
		},
		printedPoints: 2,
		effect: { kind: "rechargeDrawHabitat" }
	},
	{
		id: 69,
		name: {
			zh: "星海鳗",
			en: "Caprieel"
		},
		habitat: "coral",
		species: ["fish"],
		type: "recharge",
		cost: {
			fruit: 1,
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "rechargeDrawEgg" }
	},
	{
		id: 70,
		name: {
			zh: "暖沙袋龟",
			en: "Caregaroo"
		},
		habitat: "flower",
		species: ["fish"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "drawEgg" }
	},
	{
		id: 71,
		name: {
			zh: "碧水袋龟",
			en: "Clairgaroo"
		},
		habitat: "flower",
		species: ["fish"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "drawEgg" }
	},
	{
		id: 72,
		name: {
			zh: "浮光水母",
			en: "Cucunet"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: { coral: 2 },
		printedPoints: 2,
		effect: {
			kind: "gainNets",
			amount: 1
		}
	},
	{
		id: 73,
		name: {
			zh: "深海章鱼",
			en: "Deepus"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: {
			coral: 1,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "lookThreeScore" }
	},
	{
		id: 74,
		name: {
			zh: "幻海鳐",
			en: "Drawanta"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: { coral: 2 },
		printedPoints: 1,
		effect: { kind: "drawThreeDiscard" }
	},
	{
		id: 75,
		name: {
			zh: "幽林鳐",
			en: "Drawight"
		},
		habitat: "fruit",
		species: ["fish"],
		type: "instant",
		cost: { fruit: 2 },
		printedPoints: 1,
		effect: { kind: "drawThreeDiscard" }
	},
	{
		id: 76,
		name: {
			zh: "海角兽",
			en: "Fishorse"
		},
		habitat: "coral",
		species: ["fish"],
		type: "permanent",
		cost: {
			coral: 2,
			mushroom: 2
		},
		printedPoints: 1,
		effect: { kind: "drawTriggerScore" }
	},
	{
		id: 77,
		name: {
			zh: "幽沼独目鱼",
			en: "Gluminor"
		},
		habitat: "mushroom",
		species: ["fish"],
		type: "instant",
		cost: {
			coral: 1,
			mushroom: 2
		},
		printedPoints: 1,
		effect: {
			kind: "drawHandScore",
			maximum: 10
		}
	},
	{
		id: 78,
		name: {
			zh: "黑白海豚",
			en: "Kilphin"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: {
			fruit: 2,
			coral: 1
		},
		printedPoints: 3,
		effect: { kind: "drawAndHandNet" }
	},
	{
		id: 79,
		name: {
			zh: "粉鳍海豚",
			en: "Kilpink"
		},
		habitat: "fruit",
		species: ["fish"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 3,
		effect: { kind: "drawAndHandNet" }
	},
	{
		id: 80,
		name: {
			zh: "熔焰鲤",
			en: "Lavarp"
		},
		habitat: "mushroom",
		species: ["fish"],
		type: "energy",
		cost: {
			coral: 1,
			flower: 3,
			mushroom: 1
		},
		printedPoints: 1,
		energyCapacity: 2,
		effect: { kind: "energyDrawChooseTwo" }
	},
	{
		id: 81,
		name: {
			zh: "网鳍鱼",
			en: "Mernetid"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: {
			fruit: 3,
			flower: 1,
			mushroom: 1
		},
		printedPoints: 4,
		effect: {
			kind: "gainNets",
			amount: 2
		}
	},
	{
		id: 82,
		name: {
			zh: "深潭狼鱼",
			en: "Pondire"
		},
		habitat: "coral",
		species: ["fish"],
		type: "energy",
		cost: {
			fruit: 1,
			coral: 2,
			flower: 1
		},
		printedPoints: 2,
		energyCapacity: 2,
		effect: { kind: "energyLookThreeResource" }
	},
	{
		id: 83,
		name: {
			zh: "沙鳍鲨王",
			en: "Sharkhon"
		},
		habitat: "flower",
		species: ["fish", "fish"],
		type: "endGame",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 0,
		effect: { kind: "endFish" }
	},
	{
		id: 84,
		name: {
			zh: "沼泽章鱼",
			en: "Swampus"
		},
		habitat: "fruit",
		species: ["fish"],
		type: "instant",
		cost: {
			fruit: 1,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "lookThreeScore" }
	}
].map((e) => ({
	...e,
	ability: Je(e.effect)
}));
//#endregion
//#region src/game/cards-085-101.ts
function Xe(e) {
	switch (e.kind) {
		case "energyFlipAndScore": return {
			zh: "消耗此牌上的 1 枚能量，翻转保护区中至多两个不同的蛋，并获得 2 分。",
			en: "Spend 1 energy from this card to flip up to two different eggs in your reserve and gain 2 points."
		};
		case "flipEggsScore": return {
			zh: "翻转保护区中至多两个不同的蛋，每翻转一个蛋获得 2 分。",
			en: "Flip up to two different eggs in your reserve and gain 2 points for each egg flipped."
		};
		case "hatchForAnyEgg": return {
			zh: "孵化保护区中的一个蛋，获得一个任选物种的蛋。",
			en: "Hatch one egg in your reserve to gain an egg of a species of your choice."
		};
		case "endInsect": return {
			zh: "终局时，保护区中每有一个昆虫图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Insect icon in your reserve, including hatched and unhatched eggs."
		};
		case "hatchEggsScore": return {
			zh: "孵化保护区中至多 5 个蛋，每孵化一个蛋获得 2 分。",
			en: "Hatch up to 5 eggs in your reserve and gain 2 points for each egg hatched."
		};
		case "hatchForResources": return {
			zh: "孵化保护区中的一个蛋，选择一种资源并获得 2 份该资源。",
			en: "Hatch one egg in your reserve to gain 2 resources of one type of your choice."
		};
		case "rechargeResourceAndFlip": return {
			zh: "充能时，获得 1 份任选资源，并可翻转保护区中至多两个不同的蛋。",
			en: "When recharging, gain 1 resource of your choice and flip up to two different eggs in your reserve."
		};
		case "flipEventScore": return {
			zh: "每次通过一个行动或效果翻转一个或多个蛋时，获得 1 分。一次翻转多个蛋仍只获得 1 分。",
			en: "Each time one action or effect flips one or more eggs, gain 1 point. Flipping multiple eggs in one occurrence still gives 1 point."
		};
		case "gainInsectEgg": return {
			zh: "获得一个昆虫蛋。",
			en: "Gain one Insect egg."
		};
		case "rechargeHatchedEggScore": return {
			zh: "充能时，保护区中每有两个已孵化的蛋，获得 1 分。",
			en: "When recharging, gain 1 point for every two hatched eggs in your reserve."
		};
		case "gainEggTriggerScore": return {
			zh: "每次获得一个蛋时，获得 1 分。蛋槽已满时，该蛋改为带来共 3 分；用作额外物种图标的标记不触发此能力。",
			en: "Each time you gain an egg, gain 1 point. If your egg storage is full, gain 3 points in total instead; markers used as extra species icons do not trigger this ability."
		};
		case "gainAnyEgg": return {
			zh: "获得一个任选物种的蛋。",
			en: "Gain one egg of a species of your choice."
		};
	}
}
var Ze = [
	{
		id: 85,
		name: {
			zh: "沙脊百足",
			en: "Centom"
		},
		habitat: "flower",
		species: ["insect"],
		type: "energy",
		cost: {
			coral: 2,
			flower: 2
		},
		printedPoints: 2,
		energyCapacity: 2,
		effect: { kind: "energyFlipAndScore" }
	},
	{
		id: 86,
		name: {
			zh: "芽葱幼虫",
			en: "Cocoroch"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 1,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "flipEggsScore",
			maximum: 2,
			pointsPerEgg: 2
		}
	},
	{
		id: 87,
		name: {
			zh: "叶鳍瓢虫",
			en: "Finhead"
		},
		habitat: "coral",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 1,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "hatchForAnyEgg" }
	},
	{
		id: 88,
		name: {
			zh: "焰甲虫",
			en: "Flareetle"
		},
		habitat: "fruit",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 1,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "hatchForAnyEgg" }
	},
	{
		id: 89,
		name: {
			zh: "宝石螳螂",
			en: "Gemantis"
		},
		habitat: "mushroom",
		species: ["insect", "insect"],
		type: "endGame",
		cost: {
			flower: 2,
			mushroom: 1
		},
		printedPoints: 0,
		effect: { kind: "endInsect" }
	},
	{
		id: 90,
		name: {
			zh: "辉光幼龙",
			en: "Glowyrm"
		},
		habitat: "coral",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 2
		},
		printedPoints: 1,
		effect: {
			kind: "hatchEggsScore",
			maximum: 5,
			pointsPerEgg: 2
		}
	},
	{
		id: 91,
		name: {
			zh: "金蕊花虫",
			en: "Hoflora"
		},
		habitat: "fruit",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 2,
			coral: 1
		},
		printedPoints: 3,
		effect: { kind: "hatchForResources" }
	},
	{
		id: 92,
		name: {
			zh: "赤蕊花虫",
			en: "Hofume"
		},
		habitat: "fruit",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 3,
		effect: { kind: "hatchForResources" }
	},
	{
		id: 93,
		name: {
			zh: "悬茧幼蛛",
			en: "Housilk"
		},
		habitat: "flower",
		species: ["insect"],
		type: "recharge",
		cost: {
			fruit: 1,
			flower: 2
		},
		printedPoints: 2,
		effect: { kind: "rechargeResourceAndFlip" }
	},
	{
		id: 94,
		name: {
			zh: "月泡蛛",
			en: "Lunantula"
		},
		habitat: "mushroom",
		species: ["insect"],
		type: "permanent",
		cost: {
			flower: 2,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "flipEventScore" }
	},
	{
		id: 95,
		name: {
			zh: "绒羽法蛾",
			en: "Magicadas"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "gainInsectEgg" }
	},
	{
		id: 96,
		name: {
			zh: "斑翼螳螂",
			en: "Mentimidae"
		},
		habitat: "flower",
		species: ["insect"],
		type: "recharge",
		cost: {
			flower: 2,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "rechargeHatchedEggScore" }
	},
	{
		id: 97,
		name: {
			zh: "玫葱幼虫",
			en: "Rosaroch"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "flipEggsScore",
			maximum: 2,
			pointsPerEgg: 2
		}
	},
	{
		id: 98,
		name: {
			zh: "星灯虫",
			en: "Stellaling"
		},
		habitat: "mushroom",
		species: ["insect"],
		type: "permanent",
		cost: {
			coral: 1,
			flower: 3,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "gainEggTriggerScore" }
	},
	{
		id: 99,
		name: {
			zh: "翠翅幼龙",
			en: "Wallowyrm"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "hatchEggsScore",
			maximum: 5,
			pointsPerEgg: 2
		}
	},
	{
		id: 100,
		name: {
			zh: "雷针蜂",
			en: "Waspike"
		},
		habitat: "mushroom",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 3,
		effect: { kind: "gainAnyEgg" }
	},
	{
		id: 101,
		name: {
			zh: "绒须法蛾",
			en: "Wizadas"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			fruit: 1,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "gainInsectEgg" }
	}
].map((e) => ({
	...e,
	ability: Xe(e.effect)
}));
//#endregion
//#region src/game/cards-102-119.ts
function Qe(e) {
	switch (e.kind) {
		case "discardForPoints": return {
			zh: "弃掉至多两张手牌，每弃掉一张获得 2 分。",
			en: "Discard up to two cards from your hand and gain 2 points for each card discarded."
		};
		case "discardSpeciesScore": return {
			zh: "弃掉一张手牌，选择该牌的一种物种；保护区中每有一个对应物种图标，获得 1 分，包括已孵化和未孵化的蛋。",
			en: "Discard one card and choose one of its species. Gain 1 point per matching species icon in your reserve, including hatched and unhatched eggs."
		};
		case "discardDiscountAndScore": return {
			zh: "打出此牌时，你可以弃掉至多 5 张手牌，每弃一张使费用减少 1 份资源。获得 5 分。",
			en: "When playing this card, you may discard up to 5 cards from your hand to reduce its cost by 1 resource per card. Gain 5 points."
		};
		case "discardForResources": return {
			zh: "弃掉一张手牌，获得 2 份与该牌栖地对应的资源。",
			en: "Discard one card from your hand to gain 2 resources matching its habitat."
		};
		case "discardTriggerScore": return {
			zh: "每次从手牌弃掉一张幻兽牌时，获得 1 分。查看牌库后弃掉未选牌不触发此能力。",
			en: "Each time you discard a Creature card from your hand, gain 1 point. Discarding unchosen cards after looking at the deck does not trigger this ability."
		};
		case "energyEmptyHandDrawFour": return {
			zh: "当你没有手牌时，可以消耗此牌上的 1 枚能量，抽 4 张牌，并分别获得 1 份与每张牌栖地对应的资源。",
			en: "When you have no cards in hand, you may spend 1 energy from this card to draw 4 cards and gain 1 resource matching the habitat of each card."
		};
		case "discardDiscountAndNet": return {
			zh: "打出此牌时，你可以弃掉至多 3 张手牌，每弃一张使费用减少 1 份资源。获得一个网。",
			en: "When playing this card, you may discard up to 3 cards from your hand to reduce its cost by 1 resource per card. Gain one net."
		};
		case "endDragon": return {
			zh: "终局时，保护区中每有一个龙类图标，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per Dragon icon in your reserve, including hatched and unhatched eggs."
		};
		case "discardForTwoEggs": return {
			zh: "弃掉一张手牌，获得两个与该牌物种相符的蛋；若该牌有多个物种，由你选择一种。",
			en: "Discard one card from your hand to gain two eggs matching its species. If it has multiple species, choose one."
		};
		case "discardForTwoWilderness": return {
			zh: "弃掉一张手牌，从荒野中取得两张牌。",
			en: "Discard one card from your hand to take two cards from the Wilderness."
		};
		case "energyPlayInsteadOfDiscard": return {
			zh: "当你需要弃掉印刷费用不超过 3 份资源的牌时，可以消耗此牌上的 1 枚能量，免费打出该牌，代替弃掉它。这不占用基本行动。",
			en: "When you would discard a card with a printed cost of at most 3 resources, you may spend 1 energy from this card to play it for free instead. This does not use a basic action."
		};
		case "energyDiscardForResources": return {
			zh: "消耗此牌上的 1 枚能量并弃掉一张手牌，获得 2 份与该牌栖地对应的资源。",
			en: "Spend 1 energy from this card and discard one card from your hand to gain 2 resources matching its habitat."
		};
	}
}
var $e = [
	{
		id: 102,
		name: {
			zh: "砂猫龙",
			en: "Behewant"
		},
		habitat: "flower",
		species: ["dragon"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 1,
		effect: {
			kind: "discardForPoints",
			maximum: 2,
			pointsPerCard: 2
		}
	},
	{
		id: 103,
		name: {
			zh: "变色龙兽",
			en: "Blankin"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 1,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "discardSpeciesScore" }
	},
	{
		id: 104,
		name: {
			zh: "青羽龙",
			en: "Cyaniu"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "instant",
		cost: {
			coral: 3,
			mushroom: 2
		},
		printedPoints: 4,
		effect: {
			kind: "discardDiscountAndScore",
			maximum: 5,
			points: 5
		}
	},
	{
		id: 105,
		name: {
			zh: "双辉龙",
			en: "Doublagon"
		},
		habitat: "fruit",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 3,
		effect: { kind: "discardForResources" }
	},
	{
		id: 106,
		name: {
			zh: "岩翼龙",
			en: "Draksid"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "permanent",
		cost: {
			coral: 2,
			mushroom: 2
		},
		printedPoints: 2,
		effect: { kind: "discardTriggerScore" }
	},
	{
		id: 107,
		name: {
			zh: "双冠林龙",
			en: "Duplagon"
		},
		habitat: "fruit",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 3,
		effect: { kind: "discardForResources" }
	},
	{
		id: 108,
		name: {
			zh: "峭壁金龙",
			en: "Fafkeen"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "energy",
		cost: {
			fruit: 3,
			coral: 1,
			mushroom: 1
		},
		printedPoints: 4,
		energyCapacity: 1,
		effect: { kind: "energyEmptyHandDrawFour" }
	},
	{
		id: 109,
		name: {
			zh: "金羽龙",
			en: "Goldeniu"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 3,
			mushroom: 2
		},
		printedPoints: 4,
		effect: {
			kind: "discardDiscountAndScore",
			maximum: 5,
			points: 5
		}
	},
	{
		id: 110,
		name: {
			zh: "治愈水龙",
			en: "Healathan"
		},
		habitat: "coral",
		species: ["dragon"],
		type: "instant",
		cost: { coral: 3 },
		printedPoints: 2,
		effect: {
			kind: "discardDiscountAndNet",
			maximum: 3
		}
	},
	{
		id: 111,
		name: {
			zh: "新生暴龙",
			en: "Newtyrant"
		},
		habitat: "mushroom",
		species: ["dragon", "dragon"],
		type: "endGame",
		cost: { mushroom: 2 },
		printedPoints: 0,
		effect: { kind: "endDragon" }
	},
	{
		id: 112,
		name: {
			zh: "黑鳞骑龙",
			en: "Nidknight"
		},
		habitat: "flower",
		species: ["dragon"],
		type: "instant",
		cost: {
			coral: 2,
			flower: 2
		},
		printedPoints: 3,
		effect: { kind: "discardForTwoEggs" }
	},
	{
		id: 113,
		name: {
			zh: "蓝翼骑龙",
			en: "Nidmight"
		},
		habitat: "flower",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 2,
			flower: 2
		},
		printedPoints: 3,
		effect: { kind: "discardForTwoEggs" }
	},
	{
		id: 114,
		name: {
			zh: "铂羽龙",
			en: "Platinodon"
		},
		habitat: "coral",
		species: ["dragon"],
		type: "instant",
		cost: { coral: 2 },
		printedPoints: 2,
		effect: { kind: "discardForTwoWilderness" }
	},
	{
		id: 115,
		name: {
			zh: "复苏林龙",
			en: "Revivathan"
		},
		habitat: "fruit",
		species: ["dragon"],
		type: "instant",
		cost: { fruit: 3 },
		printedPoints: 2,
		effect: {
			kind: "discardDiscountAndNet",
			maximum: 3
		}
	},
	{
		id: 116,
		name: {
			zh: "岩鳞龙",
			en: "Rockin"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "instant",
		cost: {
			coral: 1,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "discardSpeciesScore" }
	},
	{
		id: 117,
		name: {
			zh: "昼绽花龙",
			en: "Throboros"
		},
		habitat: "coral",
		species: ["dragon"],
		type: "energy",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 2,
		energyCapacity: 1,
		effect: {
			kind: "energyPlayInsteadOfDiscard",
			maximumCost: 3
		}
	},
	{
		id: 118,
		name: {
			zh: "夜辉蝶龙",
			en: "Throiamet"
		},
		habitat: "fruit",
		species: ["dragon"],
		type: "energy",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 2,
		energyCapacity: 1,
		effect: {
			kind: "energyPlayInsteadOfDiscard",
			maximumCost: 3
		}
	},
	{
		id: 119,
		name: {
			zh: "海羽飞龙",
			en: "Wyfin"
		},
		habitat: "coral",
		species: ["dragon"],
		type: "energy",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 3,
		energyCapacity: 2,
		effect: { kind: "energyDiscardForResources" }
	}
].map((e) => ({
	...e,
	ability: Qe(e.effect)
}));
//#endregion
//#region src/game/cards-120-126.ts
function et(e) {
	switch (e.kind) {
		case "copyEndScore": return {
			zh: "终局时，选择保护区中另一张终局牌，再次获得其能力分数。",
			en: "At the end of the game, choose another End of game card in your reserve and score its ability once more."
		};
		case "endInstantCards": return {
			zh: "终局时，保护区中每有一张即时牌，获得 1 分，最多获得 12 分。",
			en: "At the end of the game, gain 1 point per Instant card in your reserve, up to 12 points."
		};
		case "endAllEggs": return {
			zh: "终局时，保护区中每有一个蛋，获得 1 分。已孵化和未孵化的蛋都计入。",
			en: "At the end of the game, gain 1 point per egg in your reserve, including hatched and unhatched eggs."
		};
		case "endHabitatSets": return {
			zh: "终局时，保护区中每有一组四种不同的栖地图标，获得 4 分，最多获得 12 分。",
			en: "At the end of the game, gain 4 points for each complete set of the four habitat icons in your reserve, up to 12 points."
		};
		case "endRechargeCards": return {
			zh: "终局时，保护区中每有一张充能牌，获得 3 分，最多获得 12 分。",
			en: "At the end of the game, gain 3 points per Recharge card in your reserve, up to 12 points."
		};
		case "endResourcesAndNets": return {
			zh: "终局时，每剩余 1 份资源或一个网，获得 1 分，最多获得 12 分。",
			en: "At the end of the game, gain 1 point for each remaining resource or net, up to 12 points."
		};
		case "endEnergyCards": return {
			zh: "终局时，保护区中每有一张能量牌，获得 3 分，最多获得 12 分。",
			en: "At the end of the game, gain 3 points per Energy card in your reserve, up to 12 points."
		};
	}
}
var tt = [
	{
		id: 120,
		name: {
			zh: "狂角巨兽",
			en: "Bustosaur"
		},
		habitat: "mushroom",
		species: ["crustacean", "dragon"],
		type: "endGame",
		cost: { mushroom: 3 },
		printedPoints: 0,
		effect: { kind: "copyEndScore" }
	},
	{
		id: 121,
		name: {
			zh: "鸭皇",
			en: "Duckaiser"
		},
		habitat: "mushroom",
		species: ["bird", "fish"],
		type: "endGame",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 0,
		effect: {
			kind: "endInstantCards",
			maximum: 12
		}
	},
	{
		id: 122,
		name: {
			zh: "卵巢巨蛛",
			en: "Eggorgeous"
		},
		habitat: "flower",
		species: ["reptile", "insect"],
		type: "endGame",
		cost: {
			fruit: 2,
			flower: 1
		},
		printedPoints: 0,
		effect: { kind: "endAllEggs" }
	},
	{
		id: 123,
		name: {
			zh: "日辉环兽",
			en: "Solaroller"
		},
		habitat: "mushroom",
		species: ["crustacean", "reptile"],
		type: "endGame",
		cost: {
			fruit: 1,
			coral: 1,
			flower: 1,
			mushroom: 1
		},
		printedPoints: 0,
		effect: {
			kind: "endHabitatSets",
			maximum: 12
		}
	},
	{
		id: 124,
		name: {
			zh: "碧游兽",
			en: "Swimmah"
		},
		habitat: "coral",
		species: ["mammal", "insect"],
		type: "endGame",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 0,
		effect: {
			kind: "endRechargeCards",
			maximum: 12
		}
	},
	{
		id: 125,
		name: {
			zh: "羽林狼",
			en: "Wolture"
		},
		habitat: "fruit",
		species: ["mammal", "bird"],
		type: "endGame",
		cost: {
			fruit: 1,
			coral: 2
		},
		printedPoints: 0,
		effect: {
			kind: "endResourcesAndNets",
			maximum: 12
		}
	},
	{
		id: 126,
		name: {
			zh: "风海翔龙",
			en: "Yormovent"
		},
		habitat: "flower",
		species: ["fish", "dragon"],
		type: "endGame",
		cost: {
			coral: 2,
			flower: 1
		},
		printedPoints: 0,
		effect: {
			kind: "endEnergyCards",
			maximum: 12
		}
	}
].map((e) => ({
	...e,
	ability: et(e.effect)
})), nt = [
	{
		id: 127,
		name: {
			zh: "幽光石灵",
			en: "Fantôpaze"
		},
		habitat: "flower",
		species: ["crustacean"],
		type: "instant",
		cost: {
			flower: 1,
			mushroom: 1
		},
		printedPoints: 1,
		effect: { kind: "supplySpecialAdvance" },
		ability: {
			zh: "你可以依次选择执行以下效果：激活供应区中一块栖地板块的特殊效果；将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: activate the special effect of a habitat tile in the supply; advance your sleeping beast one space."
		}
	},
	{
		id: 128,
		name: {
			zh: "花岩巨像",
			en: "Petraflore"
		},
		habitat: "mushroom",
		species: ["crustacean"],
		type: "instant",
		cost: {
			flower: 2,
			mushroom: 2
		},
		printedPoints: 1,
		effect: { kind: "mostHabitatDiscountAdvance" },
		ability: {
			zh: "打出此牌时，保护区中数量最多的一种栖地图标每有一个，费用减少一份资源。你可以依次选择获得三分、将沉睡巨兽的标记前进一格。",
			en: "Play this card for one fewer resource per icon of the habitat type most common in your reserve. You may resolve either or both effects in order: gain three points; advance your sleeping beast one space."
		}
	},
	{
		id: 129,
		name: {
			zh: "角影豹",
			en: "Onipard"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "instant",
		cost: { fruit: 2 },
		printedPoints: 2,
		effect: { kind: "resourceAdvance" },
		ability: {
			zh: "你可以依次选择获得一份任选资源、将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: gain one resource of your choice; advance your sleeping beast one space."
		}
	},
	{
		id: 130,
		name: {
			zh: "蜜袋考拉",
			en: "Koagourou"
		},
		habitat: "fruit",
		species: ["mammal"],
		type: "instant",
		cost: {
			fruit: 3,
			coral: 2
		},
		printedPoints: 2,
		effect: { kind: "allRechargeScore" },
		ability: {
			zh: "按你选择的顺序激活保护区中的所有充能牌，然后每有一张充能牌获得一分。",
			en: "Activate all Recharge cards in your reserve in an order of your choice, then gain one point per Recharge card in your reserve."
		}
	},
	{
		id: 131,
		name: {
			zh: "林冠鸵鸟",
			en: "Hydrautruche"
		},
		habitat: "fruit",
		species: ["bird"],
		type: "permanent",
		cost: {
			fruit: 2,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "endCardHabitatResource" },
		ability: {
			zh: "每次打出一张终局牌时，获得一份与该牌栖地对应的资源。",
			en: "Whenever you play an End-game card, gain one resource matching its habitat."
		}
	},
	{
		id: 132,
		name: {
			zh: "碧水孔雀",
			en: "Paondeau"
		},
		habitat: "coral",
		species: ["bird"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 2,
		effect: { kind: "wildernessMatchAdvance" },
		ability: {
			zh: "从荒野取得一张幻兽牌；如果它与沉睡巨兽有相同物种，将巨兽标记前进一格。",
			en: "Take one creature card from the wilderness. If it shares a species with your sleeping beast, advance that beast one space."
		}
	},
	{
		id: 133,
		name: {
			zh: "暗鳞蛇",
			en: "Mambaléon"
		},
		habitat: "fruit",
		species: ["reptile"],
		type: "instant",
		cost: {
			fruit: 1,
			coral: 1
		},
		printedPoints: 2,
		effect: { kind: "awakeFreeOtherwiseAdvance" },
		ability: {
			zh: "如果你的巨兽已经唤醒，免费打出此牌；否则将沉睡巨兽的标记前进一格。",
			en: "If your beast is awake, play this card for free. Otherwise, advance your sleeping beast one space."
		}
	},
	{
		id: 134,
		name: {
			zh: "火冠蝾螈",
			en: "Grenaxolotl"
		},
		habitat: "coral",
		species: ["reptile"],
		type: "recharge",
		cost: {
			coral: 1,
			flower: 2
		},
		printedPoints: 1,
		effect: { kind: "rechargeInstantSets" },
		ability: {
			zh: "充能时获得一分；保护区中每有三张即时牌，再获得一分。",
			en: "When recharging, gain one point plus one point for each group of three Instant cards in your reserve."
		}
	},
	{
		id: 135,
		name: {
			zh: "星光水母",
			en: "Médlux"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: { coral: 2 },
		printedPoints: 2,
		effect: { kind: "drawTwoAdvance" },
		ability: {
			zh: "你可以依次选择抽两张牌、将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: draw two cards; advance your sleeping beast one space."
		}
	},
	{
		id: 136,
		name: {
			zh: "海葵鱼",
			en: "Hydranemo"
		},
		habitat: "coral",
		species: ["fish"],
		type: "instant",
		cost: {
			coral: 2,
			mushroom: 1
		},
		printedPoints: 3,
		effect: { kind: "netAdvance" },
		ability: {
			zh: "你可以依次选择获得一个网、将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: gain one net; advance your sleeping beast one space."
		}
	},
	{
		id: 137,
		name: {
			zh: "棘背幼虫",
			en: "Cacnille"
		},
		habitat: "flower",
		species: ["insect"],
		type: "instant",
		cost: {
			coral: 1,
			flower: 1
		},
		printedPoints: 3,
		effect: { kind: "hatchResourceAdvance" },
		ability: {
			zh: "你可以依次选择执行以下效果：孵化一个蛋以获得一份任选资源；将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: hatch an egg to gain one resource of your choice; advance your sleeping beast one space."
		}
	},
	{
		id: 138,
		name: {
			zh: "绒翼蛛",
			en: "Arachnyx"
		},
		habitat: "mushroom",
		species: ["insect"],
		type: "recharge",
		cost: {
			fruit: 3,
			mushroom: 1
		},
		printedPoints: 2,
		effect: { kind: "rechargeHatchOrFlip" },
		ability: {
			zh: "充能时，孵化一个蛋以获得两份任选资源，或翻转一个蛋以获得一份任选资源。",
			en: "When recharging, hatch one egg to gain two resources of your choice, or flip one egg to gain one resource of your choice."
		}
	},
	{
		id: 139,
		name: {
			zh: "岩甲龟龙",
			en: "Hermanailée"
		},
		habitat: "mushroom",
		species: ["dragon"],
		type: "instant",
		cost: {
			fruit: 1,
			mushroom: 1
		},
		printedPoints: 3,
		effect: { kind: "discardHabitatAdvance" },
		ability: {
			zh: "你可以依次选择执行以下效果：弃掉一张手牌以获得一份与该牌栖地对应的资源；将沉睡巨兽的标记前进一格。",
			en: "You may resolve either or both effects in order: discard a card to gain one resource matching its habitat; advance your sleeping beast one space."
		}
	},
	{
		id: 140,
		name: {
			zh: "赤羽隼龙",
			en: "Dragobuse"
		},
		habitat: "flower",
		species: ["dragon"],
		type: "energy",
		cost: {
			fruit: 1,
			coral: 1,
			flower: 2
		},
		printedPoints: 3,
		energyCapacity: 1,
		effect: { kind: "energyEmptyHandDrawEggs" },
		ability: {
			zh: "手牌为空时，可消耗一枚能量抽三张牌，并从库存各获得一个与所抽牌物种对应的蛋。",
			en: "When your hand is empty, spend one energy to draw three cards and gain one egg from the stock matching the species of each drawn card."
		}
	}
], rt = [
	...He,
	...H,
	...Ge,
	...qe,
	...Ye,
	...Ze,
	...$e,
	...tt,
	...nt
], U = new Map(rt.map((e) => [e.id, e]));
//#endregion
//#region src/game/free-actions.ts
function it(e, t, n) {
	let r = U.get(n), i = e.find((e) => e.card === n);
	return !r || r.type !== "energy" || !i || i.energy < 1 || t.includes(n) ? null : {
		cards: e.map((e) => e.card === n ? {
			...e,
			energy: e.energy - 1
		} : e),
		usedThisTurn: [...t, n]
	};
}
function at(e, t) {
	let n = U.get(t);
	if (!n || n.type !== "energy" || !("energyCapacity" in n) || n.energyCapacity === void 0 || !e.some((e) => e.card === t)) return null;
	let r = n.energyCapacity;
	return e.map((e) => e.card === t ? {
		...e,
		energy: r
	} : e);
}
function ot(e) {
	if (e.nets < 1) return null;
	let t = ke(e.board, e.explorers.filter((t) => t.owner === e.owner).map((e) => e.cells), e.boardEggs, e.usedSpecials).find((t) => t.kind === e.target.kind && R(t.kind === "egg" ? t.position : t.cell) === R(e.target.position));
	return t ? {
		nets: e.nets - 1,
		boardEggs: t.kind === "egg" ? e.boardEggs.filter((e) => R(e) !== R(t.position)) : [...e.boardEggs],
		usedSpecials: t.kind === "special" ? [...e.usedSpecials, {
			row: t.cell.row,
			column: t.cell.column
		}] : [...e.usedSpecials],
		target: t
	} : null;
}
//#endregion
//#region src/game/deck.ts
function st(e, t, n) {
	let r = M(e, t, n);
	return {
		deck: {
			drawPile: r.items,
			discard: []
		},
		cursor: r.cursor
	};
}
function ct(e, t, n) {
	let r = [...e.drawPile], i = [...e.discard];
	if (r.length === 0 && i.length > 0) {
		let e = M(i, t, n);
		r = e.items, n = e.cursor, i = [];
	}
	let a = r.pop() ?? null;
	return {
		deck: {
			drawPile: r,
			discard: i
		},
		cursor: n,
		card: a
	};
}
function lt(e, t, n, r, i = [
	0,
	1,
	2,
	3,
	4,
	5
]) {
	let a = e, o = [...t];
	for (let e of i) {
		if (e < 0 || e >= o.length || o[e] !== null) continue;
		let t = ct(a, n, r);
		a = t.deck, r = t.cursor, o[e] = t.card;
	}
	return {
		deck: a,
		cursor: r,
		wilderness: o
	};
}
function ut(e, t, n, r, i) {
	let a = n === "left" ? [
		0,
		1,
		2
	] : n === "right" ? [
		3,
		4,
		5
	] : [
		0,
		1,
		2,
		3,
		4,
		5
	], o = [...t], s = [...e.discard];
	for (let e of a) {
		let t = o[e];
		t !== null && s.push(t), o[e] = null;
	}
	return lt({
		...e,
		discard: s
	}, o, r, i, a);
}
//#endregion
//#region src/game/card-movement.ts
function dt(e, t) {
	let n = ct(e.deck, e.seed, e.cursor);
	return {
		state: {
			...e,
			deck: n.deck,
			cursor: n.cursor
		},
		hand: n.card === null ? [...t] : [...t, n.card],
		drawn: n.card
	};
}
function ft(e, t) {
	let n = e, r = [];
	for (let e = 0; e < t; e++) {
		let e = ct(n.deck, n.seed, n.cursor);
		if (n = {
			...n,
			deck: e.deck,
			cursor: e.cursor
		}, e.card === null) break;
		r.push(e.card);
	}
	return {
		state: n,
		looked: r
	};
}
function pt(e, t, n, r) {
	return n.length === 0 ? r === null ? {
		state: e,
		hand: [...t],
		chosen: null
	} : null : r === null || !n.includes(r) ? null : {
		state: {
			...e,
			deck: {
				...e.deck,
				discard: [...e.deck.discard, ...n.filter((e) => e !== r)]
			}
		},
		hand: [...t, r],
		chosen: r
	};
}
function W(e, t, n) {
	if (!Number.isInteger(n) || n < 0 || n >= e.wilderness.length) return null;
	let r = e.wilderness[n];
	if (r === null) return null;
	let i = [...e.wilderness];
	return i[n] = null, {
		state: {
			...e,
			wilderness: i
		},
		hand: [...t, r],
		taken: r
	};
}
function mt(e, t, n) {
	let r = t.indexOf(n);
	return r < 0 ? null : {
		state: {
			...e,
			deck: {
				...e.deck,
				discard: [...e.deck.discard, n]
			}
		},
		hand: t.filter((e, t) => t !== r),
		discarded: n
	};
}
//#endregion
//#region src/game/eggs.ts
function ht(e, t) {
	let n = M(T.flatMap((e) => Array.from({ length: 5 }, () => e)), e, t);
	return {
		supply: {
			bag: n.items,
			stock: {
				crustacean: 6,
				mammal: 6,
				bird: 6,
				reptile: 6,
				fish: 6,
				insect: 7,
				dragon: 6
			}
		},
		cursor: n.cursor
	};
}
function gt(e) {
	let t = [...e.bag], n = t.pop() ?? null;
	return {
		supply: {
			...e,
			bag: t
		},
		species: n
	};
}
function _t(e, t) {
	return e.stock[t] === 0 ? {
		supply: e,
		acquired: !1
	} : {
		supply: {
			...e,
			stock: {
				...e.stock,
				[t]: e.stock[t] - 1
			}
		},
		acquired: !0
	};
}
function vt(e, t, n, r) {
	if (t.length > r || new Set(t).size !== t.length || t.some((t) => !Number.isInteger(t) || t < 0 || t >= e.length || n === "hatch" && e[t].hatched)) return null;
	let i = new Set(t);
	return {
		eggs: e.map((e, t) => i.has(t) ? {
			...e,
			hatched: !e.hatched
		} : { ...e }),
		flipped: t.length
	};
}
//#endregion
//#region src/game/board-a.ts
var yt = [
	{ 4: "lake" },
	{
		3: "fruit",
		4: "plain",
		5: "plain",
		6: "fruit"
	},
	{
		1: "mushroom",
		2: "mountain",
		3: "mountain",
		4: "fruit",
		5: "plain",
		6: "plain",
		7: "coral",
		10: "mushroom"
	},
	{
		0: "lake",
		1: "mountain",
		2: "plain",
		3: "lake",
		5: "plain",
		6: "lake",
		7: "mountain",
		9: "mushroom",
		10: "plain"
	},
	{
		0: "mountain",
		1: "lake",
		2: "plain",
		4: "lake",
		5: "plain",
		6: "mountain",
		7: "lake",
		8: "plain",
		9: "plain",
		10: "lake"
	},
	{
		0: "fruit",
		1: "plain",
		2: "plain",
		3: "coral",
		4: "mountain",
		5: "mountain",
		6: "flower",
		8: "plain",
		9: "lake",
		10: "mountain"
	},
	{
		1: "coral",
		2: "plain",
		3: "plain",
		4: "coral",
		7: "flower",
		8: "plain",
		9: "mountain",
		10: "net"
	},
	{
		3: "lake",
		8: "plain",
		9: "lake"
	},
	{ 7: "flower" }
], bt = {
	"1:6": "gainHabitatResource",
	"2:1": "flipEgg",
	"2:4": "sweepAndTake",
	"3:9": "gainHabitatResource",
	"5:3": "sweepAndTake",
	"5:6": "flipEgg",
	"6:1": "gainHabitatResource",
	"6:7": "gainHabitatResource",
	"6:10": "gainThreePoints"
}, xt = {
	"0:4": "square",
	"1:5": "v",
	"3:0": "triangle",
	"3:3": "circle",
	"3:5": "cross",
	"3:6": "v",
	"4:1": "v",
	"4:2": "triangle",
	"4:4": "circle",
	"4:7": "triangle",
	"4:9": "square",
	"4:10": "cross",
	"5:9": "triangle",
	"6:2": "v",
	"6:8": "circle",
	"7:3": "square",
	"7:9": "cross"
}, St = yt.flatMap((e, t) => Object.entries(e).map(([e, n]) => {
	let r = {
		row: t,
		column: Number(e)
	}, i = R(r), a = xt[i];
	if (n === "plain" || n === "mountain" || n === "lake") return {
		...r,
		terrain: n,
		...a ? { timeSymbol: a } : {}
	};
	let o = bt[i];
	return {
		...r,
		terrain: "habitat",
		habitat: n,
		...o ? { special: o } : {}
	};
})), Ct = [
	{
		row: 1,
		column: 12,
		terrain: "lake",
		timeSymbol: "triangle"
	},
	{
		row: 2,
		column: 10,
		terrain: "habitat",
		habitat: "fruit"
	},
	{
		row: 2,
		column: 11,
		terrain: "mountain"
	},
	{
		row: 2,
		column: 12,
		terrain: "plain"
	},
	{
		row: 2,
		column: 13,
		terrain: "habitat",
		habitat: "coral"
	},
	{
		row: 3,
		column: 9,
		terrain: "lake",
		timeSymbol: "square"
	},
	{
		row: 3,
		column: 10,
		terrain: "plain"
	},
	{
		row: 3,
		column: 11,
		terrain: "plain",
		timeSymbol: "cross"
	},
	{
		row: 3,
		column: 12,
		terrain: "lake",
		timeSymbol: "triangle"
	},
	{
		row: 3,
		column: 13,
		terrain: "plain",
		timeSymbol: "v"
	},
	{
		row: 4,
		column: 11,
		terrain: "mountain"
	},
	{
		row: 4,
		column: 12,
		terrain: "mountain"
	},
	{
		row: 4,
		column: 13,
		terrain: "habitat",
		habitat: "flower"
	},
	{
		row: 5,
		column: 12,
		terrain: "lake",
		timeSymbol: "circle"
	}
], wt = [...St.map((e) => ({
	...e,
	row: e.row + 2
})), ...Ct], Tt = {
	row: 3,
	column: 12
}, Et = [{
	row: 6,
	column: 0
}, {
	row: 5,
	column: 7
}], Dt = [
	{
		id: "cabot",
		name: {
			zh: "卡博特",
			en: "Cabot"
		},
		ability: {
			zh: "放置船长时，你可以激活保护区中的一张充能牌。",
			en: "When you place your captain, you may activate one Recharge card in your reserve."
		}
	},
	{
		id: "freya",
		name: {
			zh: "芙蕾雅",
			en: "Freya"
		},
		ability: {
			zh: "放置船长时，你可以收取一个与她相邻的蛋，或翻转保护区中至多两个不同的蛋。",
			en: "When you place your captain, you may collect one egg adjacent to her or flip up to two different eggs in your reserve."
		}
	},
	{
		id: "haoa",
		name: {
			zh: "浩阿",
			en: "Haoa"
		},
		ability: {
			zh: "放置船长时，你可以支付费用，将一张手牌打入保护区。这不占用基本行动。",
			en: "When you place your captain, you may pay the cost to play one card from your hand into your reserve. This does not use a basic action."
		}
	},
	{
		id: "helena",
		name: {
			zh: "海伦娜",
			en: "Helena"
		},
		ability: {
			zh: "解锁能力时，获得一个网。此后，将她放在山地上无需支付资源。",
			en: "When you unlock this power, gain one net. Afterwards, you do not pay a resource to place her on mountains."
		}
	},
	{
		id: "macus",
		name: {
			zh: "马库斯",
			en: "Macus"
		},
		ability: {
			zh: "放置船长时，你可以激活他面向的相邻特殊效果。",
			en: "When you place your captain, you may activate the adjacent special effect he faces."
		}
	},
	{
		id: "marie",
		name: {
			zh: "玛丽",
			en: "Marie"
		},
		ability: {
			zh: "放置船长时，你可以选择供应区中的一块栖地板块，并激活它的特殊效果。",
			en: "When you place your captain, you may choose one habitat tile in the supply and activate its special effect."
		}
	},
	{
		id: "octavia",
		name: {
			zh: "奥克塔维娅",
			en: "Octavia"
		},
		ability: {
			zh: "放置船长时，你可以弃掉一张手牌，获得两份与该牌栖地对应的资源。",
			en: "When you place your captain, you may discard one card from your hand to gain two resources matching its habitat."
		}
	},
	{
		id: "samuel",
		name: {
			zh: "塞缪尔",
			en: "Samuel"
		},
		ability: {
			zh: "放置船长时，你可以获得一份你持有最少的资源；每有三个奖杯，再获得一份同种资源。若有并列，由你选择。",
			en: "When you place your captain, you may gain one resource of a type you have the least of, plus one more of the same type for every three trophies. Choose among tied types."
		}
	},
	{
		id: "tingent",
		name: {
			zh: "汀詹特",
			en: "Tingent"
		},
		ability: {
			zh: "解锁能力时，在船长板上放一枚能量。放置船长时，你可以在船长板上增加一枚能量，或将板上的能量分配给保护区中的能量牌，但不能超过各牌的能量上限。",
			en: "When you unlock this power, place one energy on your captain board. When you place your captain, you may add one energy to that board or distribute its energy to Energy cards in your reserve, without exceeding their limits."
		}
	},
	{
		id: "ashe",
		name: {
			zh: "艾什",
			en: "Ashe"
		},
		ability: {
			zh: "解锁能力及放置船长时，分别在船长板上放一枚能量。消耗一枚能量可取得弃牌堆顶牌；消耗两枚能量可取得该牌，并获得一份与其栖地对应的资源。",
			en: "When this power is unlocked and whenever Ashe is placed, add one energy to this captain board. Spend one energy to take the top discard, or two energy to take it and gain one matching habitat resource."
		}
	},
	{
		id: "morgane",
		name: {
			zh: "摩根",
			en: "Morgane"
		},
		ability: {
			zh: "放置船长时，可以复制相邻玩家的船长能力，即使对方尚未解锁该能力。使用自己的资源、卡牌与能量，不复制解锁奖励。",
			en: "When placed adjacent to another player’s explorer, you may copy that player’s captain power, even if it is locked. Use your own resources, cards and energy, and do not copy unlock rewards."
		}
	},
	{
		id: "nathaniel",
		name: {
			zh: "纳撒尼尔",
			en: "Nathaniel"
		},
		ability: {
			zh: "解锁能力及放置船长时，分别在船长板上放一枚能量。消耗一枚能量获得一份任选资源；消耗三枚能量可免费打出一张手牌。",
			en: "When this power is unlocked and whenever Nathaniel is placed, add one energy to this captain board. Spend one energy for one resource of your choice, or three energy to play a card from your hand for free."
		}
	},
	{
		id: "rabell",
		name: {
			zh: "拉贝尔",
			en: "Rabell"
		},
		ability: {
			zh: "放置船长时，选择一名相邻玩家，从库存获得一个与该玩家最后放入蛋槽的蛋相同物种的蛋。",
			en: "When placed adjacent to another player’s explorer, choose one such player and gain an egg from the stock matching the last egg in that player’s reserve."
		}
	}
], Ot = [
	"ashe",
	"morgane",
	"nathaniel",
	"rabell"
], kt = [
	{
		id: "fruit-flip",
		habitat: "fruit",
		special: "flipUpToTwoEggs"
	},
	{
		id: "fruit-play",
		habitat: "fruit",
		special: "playCard"
	},
	{
		id: "fruit-discard",
		habitat: "fruit",
		special: "discardForHabitatResources"
	},
	{
		id: "fruit-egg",
		habitat: "fruit",
		special: "drawRandomEgg"
	},
	{
		id: "flower-take",
		habitat: "flower",
		special: "takeWildernessAndResource"
	},
	{
		id: "flower-egg",
		habitat: "flower",
		special: "drawRandomEgg"
	},
	{
		id: "flower-recharge",
		habitat: "flower",
		special: "activateRechargeCard"
	},
	{
		id: "coral-play",
		habitat: "coral",
		special: "playCard"
	},
	{
		id: "coral-draw",
		habitat: "coral",
		special: "drawTwoCards"
	},
	{
		id: "coral-take",
		habitat: "coral",
		special: "takeWildernessAndResource"
	},
	{
		id: "coral-discard",
		habitat: "coral",
		special: "discardForHabitatResources"
	},
	{
		id: "mushroom-recharge",
		habitat: "mushroom",
		special: "activateRechargeCard"
	},
	{
		id: "mushroom-draw",
		habitat: "mushroom",
		special: "drawTwoCards"
	},
	{
		id: "mushroom-flip",
		habitat: "mushroom",
		special: "flipUpToTwoEggs"
	}
];
function At(e, t) {
	let n = M(kt.map((e) => e.id), e, t), r = [...n.items];
	return {
		supply: {
			drawPile: r,
			display: [
				r.pop() ?? null,
				r.pop() ?? null,
				r.pop() ?? null
			]
		},
		cursor: n.cursor
	};
}
function jt(e, t, n) {
	if (n.terrain !== "lake" || !Number.isInteger(t) || t < 0 || t >= e.display.length) return null;
	let r = kt.find((n) => n.id === e.display[t]);
	if (!r) return null;
	let i = [...e.drawPile], a = [...e.display];
	return a[t] = i.pop() ?? null, {
		supply: {
			drawPile: i,
			display: a
		},
		cell: {
			...n,
			terrain: "habitat",
			habitat: r.habitat,
			special: r.special
		},
		tile: r
	};
}
//#endregion
//#region src/game/time-track.ts
var G = (e = !1) => ({
	timeToken: e,
	effects: ["gainNet"]
}), Mt = () => ({
	timeToken: !1,
	effects: ["gainNet", "sweepAll"]
}), Nt = () => ({
	timeToken: !1,
	effects: ["gainNet", "removeTrophy"]
}), Pt = [
	G(!0),
	Mt(),
	G(!0),
	Mt(),
	G(!0),
	Mt(),
	G(!0),
	Mt(),
	G(!0),
	Mt(),
	Nt()
], Ft = [
	G(!0),
	G(),
	Mt(),
	G(!0),
	G(),
	Mt(),
	G(!0),
	G(),
	Mt(),
	G(!0),
	Nt()
], It = [
	Mt(),
	G(!0),
	G(),
	G(!0),
	Mt(),
	G(!0),
	G(),
	G(!0),
	Mt(),
	G(!0),
	G(),
	Mt(),
	Nt()
];
function Lt(e) {
	return e === 2 ? Pt : e === 3 ? Ft : It;
}
function Rt(e) {
	return Lt(e).flatMap((e, t) => e.timeToken ? [t + 1] : []).slice(-2);
}
function zt(e, t) {
	let n = Lt(t), r = Math.min(e + 1, n.length);
	return {
		position: r,
		space: n[r - 1]
	};
}
//#endregion
//#region src/game/setup.ts
function Bt(e, t, n = !1) {
	if (e.length < 2 || e.length > 4 || new Set(e).size !== e.length) throw Error("Invalid player list");
	let r = e.length, i = 0, a = oe(t, i);
	i = a.cursor;
	let o = At(t, i);
	i = o.cursor;
	let s = o.supply, c = ht(t, i);
	i = c.cursor;
	let l = c.supply, u = (r <= 2 ? St : wt).map((e) => ({ ...e })), d = [], f = (e) => {
		let t = gt(l);
		l = t.supply, t.species && d.push({
			row: e.row,
			column: e.column,
			species: t.species
		});
	};
	if (r === 4) {
		let e = [...s.drawPile], t = e.pop(), n = kt.find((e) => e.id === t);
		if (!n) throw Error("Missing initial habitat tile");
		s = {
			...s,
			drawPile: e
		}, u = u.map((e) => R(e) === R(Tt) ? {
			...e,
			terrain: "habitat",
			habitat: n.habitat,
			special: n.special
		} : e), Et.forEach(f);
	}
	let p = M([
		"circle",
		"square",
		"triangle",
		"v",
		"cross"
	], t, i);
	i = p.cursor;
	let m = p.items.slice(0, 2);
	for (let e of u) e.timeSymbol && e.terrain !== "habitat" && m.includes(e.timeSymbol) && f(e);
	let h = M(m, t, i);
	i = h.cursor;
	let g = Lt(r).flatMap((e, t) => e.timeToken ? [t + 1] : []), _ = new Set(Rt(r)), v = p.items.slice(2), y = 0, b = 0, x = g.map((e) => ({
		position: e,
		symbol: _.has(e) ? h.items[b++] : v[y++]
	})), S = st(Array.from({ length: n ? 140 : 126 }, (e, t) => t + 1), t, i);
	i = S.cursor;
	let C = S.deck, w = lt(C, [
		null,
		null,
		null,
		null,
		null,
		null
	], t, i);
	C = w.deck, i = w.cursor;
	let T = M(Dt.filter((e) => n || !Ot.includes(e.id)).map((e) => e.id), t, i);
	i = T.cursor;
	let te = e.map((e, n) => {
		let r = [];
		for (let e = 0; e < 8; e++) {
			let e = ct(C, t, i);
			if (C = e.deck, i = e.cursor, e.card === null) throw Error("Not enough creature cards");
			r.push(e.card);
		}
		return {
			rid: e,
			seat: n,
			captainOptions: T.items.slice(n * 2, n * 2 + 2),
			draftCards: r,
			captain: null,
			hand: [],
			resources: ee(),
			nets: 1,
			eggs: [],
			drafted: !1
		};
	});
	return {
		seed: t,
		cursor: i,
		players: te,
		board: u,
		boardEggs: d,
		eggSupply: l,
		habitatSupply: s,
		deck: C,
		wilderness: w.wilderness,
		achievements: a.achievements,
		timeTokens: x,
		initialSymbols: m,
		trophies: r === 2 ? 10 : r === 3 ? 14 : 16
	};
}
function Vt(e, t, n) {
	let r = e.players.find((e) => e.rid === t);
	if (!r || r.drafted || !r.captainOptions.includes(n.captain) || n.cards.length !== 4 || new Set(n.cards).size !== 4 || n.cards.some((e) => !r.draftCards.includes(e))) return null;
	let i = te(r.seat, n.bonusResources);
	if (!i) return null;
	let a = new Set(n.cards), o = r.draftCards.filter((e) => !a.has(e));
	return {
		...e,
		players: e.players.map((e) => e.rid === t ? {
			...e,
			captain: n.captain,
			captainOptions: [],
			draftCards: [],
			hand: [...n.cards],
			resources: i,
			drafted: !0
		} : e),
		deck: {
			...e.deck,
			discard: [...e.deck.discard, ...o]
		}
	};
}
//#endregion
//#region src/game/match-state.ts
function Ht(e, t, n = !1) {
	return {
		setup: Bt(e, t, n),
		players: e.map((e) => ({
			rid: e,
			reserve: [],
			energy: [],
			points: 0,
			trophies: 0,
			captainUnlocked: !1,
			captainEnergy: 0
		})),
		explorers: [],
		claims: [],
		phase: "draft",
		activePlayer: null,
		basicAction: null,
		usedEnergy: [],
		usedNetSpecials: [],
		nextCardDiscount: 0,
		timePosition: 0,
		revealedTimeTokens: [],
		finalTurns: null
	};
}
function Ut(e, t, n) {
	if (e.phase !== "draft") return null;
	let r = Vt(e.setup, t, n);
	if (!r) return null;
	let i = r.players.every((e) => e.drafted);
	return {
		...e,
		setup: r,
		phase: i ? "turn" : "draft",
		activePlayer: i ? r.players[0].rid : null
	};
}
function Wt(e, t, n) {
	return e.phase !== "turn" || e.activePlayer !== t || e.basicAction !== null ? null : {
		...e,
		basicAction: {
			kind: n,
			resolved: !1
		}
	};
}
function Gt(e, t) {
	return e.phase !== "turn" || e.activePlayer !== t || !e.basicAction || e.basicAction.resolved ? null : {
		...e,
		basicAction: {
			...e.basicAction,
			resolved: !0
		}
	};
}
function Kt(e, t, n) {
	if (e.phase !== "turn" || e.activePlayer !== t) return null;
	if (e.setup.trophies === 0) return {
		state: e,
		gained: !1
	};
	let r = e.setup.trophies - 1, i = n ? e.players.map((e) => e.rid === t ? {
		...e,
		trophies: e.trophies + 1
	} : e) : e.players;
	return {
		state: {
			...e,
			players: i,
			setup: {
				...e.setup,
				trophies: r
			},
			finalTurns: r === 0 && !e.finalTurns ? j(e.players.map((e) => e.rid), t) : e.finalTurns
		},
		gained: n
	};
}
function qt(e, t) {
	if (e.phase !== "turn" || e.activePlayer !== t || !e.basicAction?.resolved) return null;
	let n = lt(e.setup.deck, e.setup.wilderness, e.setup.seed, e.setup.cursor), r = {
		...e.setup,
		deck: n.deck,
		wilderness: n.wilderness,
		cursor: n.cursor
	}, i, a = e.finalTurns;
	if (a) {
		let e = ie(a, t);
		a = e.turns, i = e.next;
	} else {
		let n = e.players.findIndex((e) => e.rid === t);
		i = e.players[(n + 1) % e.players.length].rid;
	}
	return {
		...e,
		setup: r,
		phase: i === null ? "endGame" : "turn",
		activePlayer: i,
		basicAction: null,
		usedEnergy: [],
		usedNetSpecials: [],
		nextCardDiscount: 0,
		finalTurns: a,
		...e.beasts?.owned[t] ? { beasts: {
			...e.beasts,
			owned: {
				...e.beasts.owned,
				[t]: {
					...e.beasts.owned[t],
					usedThisTurn: !1
				}
			}
		} } : {}
	};
}
//#endregion
//#region src/game/triggered-abilities.ts
function Jt(e, t) {
	let n = e.kind === "playCard" ? U.get(e.card) : void 0, r = n ? Object.values(n.cost).reduce((e, t) => e + t, 0) : 0;
	return t.flatMap((t) => {
		let i = U.get(t.id);
		if (!i || i.type !== "permanent") return [];
		let a = i.effect;
		switch (a.kind) {
			case "scoreForExpensiveCard": return e.kind === "playCard" && r >= a.minimumCost ? [{
				card: t.id,
				kind: "points",
				amount: a.points
			}] : [];
			case "trophyActivatesRecharge": return e.kind === "gainTrophy" ? [{
				card: t.id,
				kind: "activateRecharge"
			}] : [];
			case "trophyScore": return e.kind === "gainTrophy" ? [{
				card: t.id,
				kind: "points",
				amount: a.points
			}] : [];
			case "rechargeActivationScore": return e.kind === "activateRecharge" ? [{
				card: t.id,
				kind: "points",
				amount: a.points
			}] : [];
			case "trophyResource": return e.kind === "gainTrophy" ? [{
				card: t.id,
				kind: "chooseResource"
			}] : [];
			case "instantCardScore": return e.kind === "playCard" && n?.type === "instant" ? [{
				card: t.id,
				kind: "points",
				amount: a.points
			}] : [];
			case "drawTriggerScore": return e.kind === "drawCard" ? [{
				card: t.id,
				kind: "points",
				amount: 1
			}] : [];
			case "flipEventScore": return e.kind === "flipEggs" && e.count > 0 ? [{
				card: t.id,
				kind: "points",
				amount: 1
			}] : [];
			case "gainEggTriggerScore": return e.kind === "gainEgg" ? [{
				card: t.id,
				kind: "points",
				amount: 1
			}] : [];
			case "discardTriggerScore": return e.kind === "discardHandCard" ? [{
				card: t.id,
				kind: "points",
				amount: 1
			}] : [];
			case "endCardHabitatResource": return e.kind === "playCard" && n?.type === "endGame" ? [{
				card: t.id,
				kind: "fixedResource",
				resource: n.habitat
			}] : [];
			default: return [];
		}
	});
}
//#endregion
//#region src/game/match-mutations.ts
function Yt(e, t) {
	let n = e.setup.players.find((e) => e.rid === t), r = e.players.find((e) => e.rid === t);
	return n && r ? {
		setup: n,
		match: r
	} : null;
}
function Xt(e, t, n) {
	let r = Yt(e, t);
	if (!r || !Number.isInteger(n) || n < 0) return null;
	let i = r.match.points + n;
	return {
		state: {
			...e,
			players: e.players.map((e) => e.rid === t ? {
				...e,
				points: i
			} : e)
		},
		reactions: me(r.match.points, i).map((e) => ({
			kind: "reward",
			reward: e
		}))
	};
}
function Zt(e, t, n) {
	let r = Yt(e, t);
	if (!r || Object.values(n).some((e) => !Number.isInteger(e) || e < 0)) return null;
	let i = D(r.setup.resources, n);
	return {
		state: {
			...e,
			setup: {
				...e.setup,
				players: e.setup.players.map((e) => e.rid === t ? {
					...e,
					resources: i.resources
				} : e)
			}
		},
		gained: i.gained
	};
}
function Qt(e, t, n) {
	let r = Yt(e, t);
	if (!r || !Number.isInteger(n) || n < 0) return null;
	let i = ne(r.setup.nets, n);
	return {
		state: {
			...e,
			setup: {
				...e.setup,
				players: e.setup.players.map((e) => e.rid === t ? {
					...e,
					nets: i.nets
				} : e)
			}
		},
		reactions: i.points ? [{
			kind: "reward",
			reward: {
				kind: "points",
				amount: i.points
			}
		}] : []
	};
}
function $t(e, t, n) {
	let r = Yt(e, t);
	if (!r) return null;
	let i = e.setup.eggSupply, a;
	if (n.kind === "bag") {
		let e = gt(i);
		i = e.supply, a = e.species;
	} else if (n.kind === "stock") {
		let e = _t(i, n.species);
		i = e.supply, a = e.acquired ? n.species : null;
	} else a = n.species;
	if (a === null) return {
		state: {
			...e,
			setup: {
				...e.setup,
				eggSupply: i
			}
		},
		species: null,
		stored: !1,
		reactions: []
	};
	let o = k(r.setup.eggs, a);
	o.stored || (i = {
		...i,
		stock: {
			...i.stock,
			[a]: i.stock[a] + 1
		}
	});
	let s = [], c = e.beasts?.owned[t]?.awake && e.beasts.owned[t].id === 3;
	return o.stored && (s.push({
		kind: "reward",
		reward: de[r.setup.eggs.length]
	}), c && s.push({
		kind: "reward",
		reward: de[r.setup.eggs.length]
	})), o.points && s.push({
		kind: "reward",
		reward: {
			kind: "points",
			amount: o.points * (c ? 2 : 1)
		}
	}), s.push(...Jt({ kind: "gainEgg" }, r.match.reserve).map((e) => ({
		kind: "trigger",
		ability: e
	}))), {
		state: {
			...e,
			setup: {
				...e.setup,
				eggSupply: i,
				players: e.setup.players.map((e) => e.rid === t ? {
					...e,
					eggs: o.eggs
				} : e)
			}
		},
		species: a,
		stored: o.stored,
		reactions: s
	};
}
function en(e, t) {
	let n = Yt(e, t);
	if (!n) return null;
	let r = dt(e.setup, n.setup.hand);
	return {
		state: {
			...e,
			setup: {
				...e.setup,
				deck: r.state.deck,
				cursor: r.state.cursor,
				players: e.setup.players.map((e) => e.rid === t ? {
					...e,
					hand: r.hand
				} : e)
			}
		},
		card: r.drawn,
		reactions: r.drawn === null ? [] : Jt({ kind: "drawCard" }, n.match.reserve).map((e) => ({
			kind: "trigger",
			ability: e
		}))
	};
}
function tn(e, t, n) {
	let r = Yt(e, t);
	if (!r) return null;
	let i = Kt(e, t, n);
	return i ? {
		...i,
		reactions: i.gained ? [...Jt({ kind: "gainTrophy" }, r.match.reserve).map((e) => ({
			kind: "trigger",
			ability: e
		})), ...e.beasts?.owned[t]?.awake && e.beasts.owned[t].id === 4 && e.claims.some((e) => e.owner === t && e.usedMarkerReward) ? [{
			kind: "reward",
			reward: { kind: "repeatAchievementReward" }
		}] : []] : []
	} : null;
}
//#endregion
//#region src/game/end-card-scores.ts
var nn = {
	15: "crustacean",
	20: "mammal",
	49: "bird",
	67: "reptile",
	83: "fish",
	89: "insect",
	111: "dragon"
};
function rn(e, t, n) {
	let r = nn[e];
	if (r) return t.cards.reduce((e, t) => e + t.species.filter((e) => e === r).length, 0) + t.eggs.filter((e) => e.species === r).length + (t.extraSpecies?.filter((e) => e === r).length ?? 0);
	switch (e) {
		case 120: {
			if (n === void 0) return 0;
			let e = t.cards.find((e) => e.id === n && e.id !== 120 && e.type === "endGame");
			return e ? rn(e.id, t) : null;
		}
		case 121: return Math.min(12, t.cards.filter((e) => e.type === "instant").length);
		case 122: return t.eggs.length;
		case 123: return Math.min(12, 4 * Math.min(...w.map((e) => t.cards.filter((t) => t.habitat === e).length)));
		case 124: return Math.min(12, 3 * t.cards.filter((e) => e.type === "recharge").length);
		case 125: return Math.min(12, E(t.resources) + t.nets);
		case 126: return Math.min(12, 3 * t.cards.filter((e) => e.type === "energy").length);
		default: return null;
	}
}
function an(e, t) {
	let n = e.cards.filter((e) => e.type === "endGame"), r = n.filter((e) => e.id !== 120).map((e) => e.id);
	if (n.some((e) => e.id === 120) && r.length > 0 && t === void 0) return {
		status: "choice",
		targets: r
	};
	let i = [];
	for (let r of n) {
		let n = rn(r.id, e, r.id === 120 && t !== null ? t : void 0);
		if (n === null) return { status: "invalid" };
		i.push({
			card: r.id,
			points: n
		});
	}
	return {
		status: "ready",
		details: i,
		total: i.reduce((e, t) => e + t.points, 0)
	};
}
//#endregion
//#region src/game/match-scoring.ts
function on(e, t) {
	if (e.phase !== "endGame") return { status: "invalid" };
	let n = [];
	for (let r of e.players) {
		let i = e.setup.players.find((e) => e.rid === r.rid);
		if (!i) return { status: "invalid" };
		let a = an({
			cards: r.reserve,
			eggs: i.eggs,
			resources: i.resources,
			nets: i.nets,
			extraSpecies: ve(e.beasts, r.rid)
		}, t[r.rid]);
		if (a.status === "choice") return {
			...a,
			owner: r.rid
		};
		if (a.status === "invalid") return a;
		let o = 0;
		for (let e of r.reserve) {
			let t = U.get(e.id);
			if (!t) return { status: "invalid" };
			o += t.printedPoints;
		}
		n.push({
			rid: r.rid,
			input: {
				immediate: r.points,
				endGameAbilities: a.total,
				beastPoints: we(e.beasts?.owned[r.rid], r.reserve, i.eggs),
				printedCards: o,
				achievements: e.claims.filter((e) => e.owner === r.rid).reduce((e, t) => e + t.points, 0),
				trophies: r.trophies,
				resources: i.resources,
				nets: i.nets
			},
			endCards: a.details
		});
	}
	n.sort((e, t) => A(e.input, t.input));
	let r = 0;
	return {
		status: "ready",
		players: n.map((e, t) => ((t === 0 || A(n[t - 1].input, e.input) !== 0) && (r = t + 1), {
			rid: e.rid,
			rank: r,
			score: re(e.input),
			endCards: e.endCards
		}))
	};
}
//#endregion
//#region src/game/solo-rules.ts
var sn = {
	1: {
		firstBrown: 16,
		spaces: [
			"none",
			"none",
			"discovery",
			"time",
			"none",
			"none",
			"discovery",
			"time",
			"multi",
			"none",
			"none",
			"discovery",
			"time",
			"single",
			"none",
			"none",
			"main",
			"multi",
			"time",
			"main",
			"single",
			"time",
			"main",
			"time"
		]
	},
	2: {
		firstBrown: 13,
		spaces: [
			"none",
			"none",
			"discovery",
			"time",
			"none",
			"none",
			"multi",
			"time",
			"discovery",
			"none",
			"none",
			"single",
			"time",
			"discovery",
			"main",
			"multi",
			"none",
			"main",
			"time",
			"single",
			"main",
			"time",
			"time",
			"time"
		]
	},
	3: {
		firstBrown: 12,
		spaces: [
			"none",
			"none",
			"discovery",
			"time",
			"none",
			"none",
			"multi",
			"time",
			"discovery",
			"none",
			"single",
			"time",
			"discovery",
			"main",
			"multi",
			"time",
			"main",
			"none",
			"single",
			"main",
			"time",
			"time",
			"time",
			"time"
		]
	},
	4: {
		firstBrown: 10,
		spaces: [
			"none",
			"none",
			"discovery",
			"time",
			"none",
			"multi",
			"discovery",
			"time",
			"single",
			"none",
			"discovery",
			"time",
			"main",
			"multi",
			"none",
			"time",
			"main",
			"single",
			"main",
			"time",
			"time",
			"time",
			"time",
			"time"
		]
	}
}, cn = [
	{
		id: 1,
		advance: !0,
		yellow: {
			kind: "place",
			piece: "explorer",
			habitat: "fruit",
			hiddenCards: 0
		},
		brown: {
			kind: "place",
			piece: "explorer",
			habitat: "coral",
			hiddenCards: 1
		}
	},
	{
		id: 2,
		advance: !0,
		yellow: {
			kind: "place",
			piece: "explorer",
			habitat: "coral",
			hiddenCards: 0
		},
		brown: {
			kind: "place",
			piece: "explorer",
			habitat: "fruit",
			hiddenCards: 1
		}
	},
	{
		id: 3,
		advance: !1,
		yellow: {
			kind: "place",
			piece: "explorer",
			habitat: "flower",
			hiddenCards: 1
		},
		brown: {
			kind: "takeTarget",
			target: "single",
			egg: !1
		}
	},
	{
		id: 4,
		advance: !1,
		yellow: {
			kind: "takeTarget",
			target: "single",
			egg: !0
		},
		brown: {
			kind: "takeTarget",
			target: "multi",
			egg: !0
		}
	},
	{
		id: 5,
		advance: !0,
		yellow: {
			kind: "place",
			piece: "captain",
			habitat: "fruit",
			hiddenCards: 0
		},
		brown: {
			kind: "place",
			piece: "captain",
			habitat: "coral",
			hiddenCards: 1
		}
	},
	{
		id: 6,
		advance: !0,
		yellow: {
			kind: "place",
			piece: "captain",
			habitat: "coral",
			hiddenCards: 0
		},
		brown: {
			kind: "place",
			piece: "captain",
			habitat: "fruit",
			hiddenCards: 1
		}
	},
	{
		id: 7,
		advance: !1,
		yellow: {
			kind: "place",
			piece: "captain",
			habitat: "mushroom",
			hiddenCards: 1
		},
		brown: {
			kind: "takeTarget",
			target: "single",
			egg: !1
		}
	},
	{
		id: 8,
		advance: !1,
		yellow: {
			kind: "takeTarget",
			target: "multi",
			egg: !1
		},
		brown: {
			kind: "takeTarget",
			target: "multi",
			egg: !1
		}
	},
	{
		id: 9,
		advance: !0,
		yellow: {
			kind: "takeTarget",
			target: "multi",
			egg: !1
		},
		brown: {
			kind: "place",
			piece: "explorer",
			habitat: "flower",
			hiddenCards: 1
		}
	},
	{
		id: 10,
		advance: !0,
		yellow: {
			kind: "takeTarget",
			target: "multi",
			egg: !1
		},
		brown: {
			kind: "place",
			piece: "captain",
			habitat: "mushroom",
			hiddenCards: 1
		}
	},
	{
		id: 11,
		advance: !0,
		yellow: {
			kind: "takeTarget",
			target: "single",
			egg: !0
		},
		brown: {
			kind: "takeTarget",
			target: "single",
			egg: !0
		}
	},
	{
		id: 12,
		advance: !0,
		yellow: {
			kind: "takeTarget",
			target: "single",
			egg: !1
		},
		brown: {
			kind: "hiddenCards",
			count: 2
		}
	}
];
function ln(e) {
	let t = 0;
	for (let n of e.visibleCards) {
		let e = U.get(n);
		if (!e) return null;
		t += e.printedPoints + (e.type === "endGame" ? 5 : 0);
	}
	return e.immediate + t + e.achievementPoints + 3 * e.trophies + e.eggs.length + e.hiddenCards * Math.min(e.difficulty, 3);
}
function un(e, t, n) {
	let r = se(e, 2);
	return e.kind === "main" ? n.includes(0) ? n.includes(1) ? null : 1 : 0 : t > r[1].required && !n.includes(0) ? 0 : n.includes(1) ? null : 1;
}
function dn(e, t, n, r) {
	return e > t || e === t && n > r;
}
//#endregion
//#region src/game/solo-setup.ts
var fn = "$tingent";
function pn(e, t, n, r = !1) {
	let i = Ht([e, fn], t, r), a = i.setup.players[1], o = M([...i.setup.deck.drawPile, ...a.draftCards], t, i.setup.cursor), s = M(cn.map((e) => e.id), t, o.cursor), c = Object.fromEntries([
		"main",
		"single",
		"multi"
	].map((e) => {
		let t = i.setup.achievements.find((t) => t.kind === e);
		if (!t) throw Error("Missing solo achievement");
		return [e, t.id];
	}));
	return {
		match: {
			...i,
			setup: {
				...i.setup,
				cursor: s.cursor,
				trophies: 8,
				deck: {
					...i.setup.deck,
					drawPile: o.items
				},
				players: i.setup.players.map((t) => t.rid === e ? {
					...t,
					captainOptions: Dt.filter((e) => r || !Ot.includes(e.id)).map((e) => e.id)
				} : {
					...t,
					captainOptions: [],
					draftCards: [],
					drafted: !0
				})
			}
		},
		tingent: {
			difficulty: n,
			position: 1,
			brown: !1,
			drawPile: s.items,
			discard: [],
			targets: c,
			visibleCards: [],
			hiddenCards: [],
			eggs: [],
			points: 0,
			trophies: 0,
			steps: []
		}
	};
}
//#endregion
//#region src/game/gameplay-scoring.ts
function mn(e) {
	let t = on(e.match, e.endChoices);
	if (!e.solo || t.status !== "ready") return t;
	let n = t.players.find((e) => e.rid !== fn);
	if (!n) return { status: "invalid" };
	let r = e.solo, i = e.match.claims.filter((e) => e.owner === fn).reduce((e, t) => e + t.points, 0), a = ln({
		immediate: r.points,
		visibleCards: r.visibleCards,
		hiddenCards: r.hiddenCards.length,
		eggs: r.eggs.map((e) => ({
			species: e,
			hatched: !1
		})),
		achievementPoints: i,
		trophies: r.trophies,
		difficulty: r.difficulty
	});
	if (a === null) return { status: "invalid" };
	let o = r.visibleCards.reduce((e, t) => e + (U.get(t)?.printedPoints ?? 0), 0), s = r.visibleCards.filter((e) => U.get(e)?.type === "endGame").length * 5, c = {
		immediate: r.points,
		endGameAbilities: s,
		beastPoints: 0,
		printedCards: o,
		achievements: i,
		trophies: r.trophies * 3,
		remaining: r.eggs.length + r.hiddenCards.length * Math.min(r.difficulty, 3),
		total: a
	}, l = e.match.players.find((e) => e.rid === n.rid)?.trophies ?? 0, u = dn(n.score.total, a, l, r.trophies), d = {
		...n,
		rank: u ? 1 : 2
	}, f = {
		rid: fn,
		rank: u ? 2 : 1,
		score: c,
		endCards: []
	};
	return {
		status: "ready",
		players: u ? [d, f] : [f, d]
	};
}
//#endregion
//#region src/game/recharge-action.ts
function hn(e, t, n, r, i, a = 3) {
	let o = t.filter((t) => t.owner === e);
	if (o.length < a || o.length > 3 || new Set(o.map((e) => e.piece)).size !== o.length || !Number.isInteger(n) || n < 0 || n > Lt(r).length) return null;
	let s = zt(n, r), c = i.find((e) => e.position === s.position) ?? null;
	return {
		explorers: t.filter((t) => t.owner !== e),
		position: s.position,
		timeTokens: c ? i.filter((e) => e.position !== s.position) : [...i],
		revealed: c,
		effects: s.space.effects
	};
}
function gn(e, t, n, r, i) {
	if (i.bag.length === 0) return [];
	let a = new Set([...n, ...r.flatMap((e) => e.cells)].map(R));
	return t.filter((t) => t.timeSymbol === e && t.terrain !== "habitat" && !a.has(R(t))).map(({ row: e, column: t }) => ({
		row: e,
		column: t
	}));
}
function _n(e, t, n, r, i, a) {
	if (!gn(e, n, r, i, a).some((e) => R(e) === R(t))) return null;
	let o = gt(a);
	if (!o.species) return null;
	let s = {
		...t,
		species: o.species
	};
	return {
		eggs: [...r, s],
		supply: o.supply,
		egg: s
	};
}
//#endregion
//#region src/game/captain-copy.ts
function vn(e, t, n) {
	let r = new Set(n.flatMap(Te).map(R));
	return [...new Set(e.explorers.filter((e) => e.owner !== t && e.cells.some((e) => r.has(R(e)))).map((e) => e.owner))];
}
function yn(e, t, n) {
	return vn(e, t, n).flatMap((t) => {
		if (t === "$tingent" && e.soloCaptainOptions) return e.soloCaptainOptions.map((e) => ({
			owner: t,
			captain: e
		}));
		let n = e.setup.players.find((e) => e.rid === t)?.captain;
		return n ? [{
			owner: t,
			captain: n
		}] : [];
	});
}
function bn(e, t, n) {
	let r = new Set(vn(e, t, n)), i = e.setup.players.flatMap((e) => r.has(e.rid) ? e.rid === "$tingent" ? e.eggs.map((e) => e.species) : e.eggs.length ? [e.eggs[e.eggs.length - 1].species] : [] : []);
	return [...new Set(i)].filter((t) => e.setup.eggSupply.stock[t] > 0);
}
//#endregion
//#region src/game/payment.ts
function xn(e, t) {
	return Math.max(0, E(e) - t);
}
function Sn(e, t, n) {
	return w.reduce((n, r) => n + Math.min(e[r], t[r]), 0) >= xn(e, n);
}
function Cn(e, t, n, r) {
	return !Number.isInteger(n) || n < 0 || w.some((n) => !Number.isInteger(r[n]) || r[n] < 0 || r[n] > e[n] || r[n] > t[n]) ? !1 : E(r) === xn(e, n);
}
//#endregion
//#region src/game/card-play.ts
function wn(e) {
	return Object.fromEntries(w.map((t) => [t, e.cost[t] ?? 0]));
}
function Tn(e, t) {
	if (e.effect.kind === "mostHabitatDiscountAdvance") return Math.max(...w.map((e) => t.filter((t) => t.habitat === e).length));
	if (e.effect.kind !== "discountAndScore") return 0;
	let n = e.effect.habitat;
	return t.filter((e) => e.habitat === n).length;
}
function En(e) {
	let t = U.get(e.card);
	if (!t || e.reserve.some((t) => t.id === e.card) || e.source.kind === "hand" && !e.hand.includes(e.card) || e.source.kind === "wilderness" && (!Number.isInteger(e.source.slot) || e.source.slot < 0 || e.source.slot >= e.wilderness.length || e.wilderness[e.source.slot] !== e.card) || !Number.isInteger(e.otherDiscount) || e.otherDiscount < 0 || !Number.isInteger(e.discardedForDiscount) || e.discardedForDiscount < 0) return null;
	let n = t.effect.kind === "discardDiscountAndScore" || t.effect.kind === "discardDiscountAndNet" ? t.effect.maximum : 0;
	if (e.discardedForDiscount > n) return null;
	let r = wn(t), i = e.free ? w.reduce((e, t) => e + r[t], 0) : Tn(t, e.reserve) + e.otherDiscount + e.discardedForDiscount;
	if (!Cn(r, e.resources, i, e.payment)) return null;
	let a = O(e.resources, e.payment);
	if (!a) return null;
	let o = [...e.hand], s = [...e.wilderness];
	e.source.kind === "hand" ? o.splice(o.indexOf(e.card), 1) : s[e.source.slot] = null;
	let c = [...e.reserve].reverse().find((e) => e.type === "instant")?.id ?? null, l = [...e.reserve, {
		id: t.id,
		habitat: t.habitat,
		species: [...t.species],
		type: t.type
	}], u = [...e.energy];
	return t.type === "energy" && "energyCapacity" in t && t.energyCapacity !== void 0 && u.push({
		card: t.id,
		energy: t.energyCapacity
	}), {
		hand: o,
		wilderness: s,
		resources: a,
		reserve: l,
		energy: u,
		card: t,
		previousInstant: c,
		triggers: Jt({
			kind: "playCard",
			card: t.id
		}, l)
	};
}
//#endregion
//#region src/game/card-effect-choices.ts
function Dn(e) {
	return Object.values(e.cost).reduce((e, t) => e + t, 0);
}
//#endregion
//#region src/game/discovery-action.ts
function On(e) {
	let t = R(e.position), n = e.board.find((e) => R(e) === t);
	if (!n) return null;
	let r = jt(e.supply, e.slot, n);
	if (!r) return null;
	let i = e.boardEggs.find((e) => R(e) === t) ?? null;
	return {
		board: e.board.map((e) => R(e) === t ? r.cell : e),
		boardEggs: e.boardEggs.filter((e) => R(e) !== t),
		supply: r.supply,
		tile: r.tile,
		egg: i
	};
}
//#endregion
//#region src/game/card-activation.ts
function kn(e, t, n) {
	let r = U.get(n.card), i = e.players.find((e) => e.rid === t), a = e.setup.players.find((e) => e.rid === t);
	if (!r || !i || !a || r.type !== n.activation || !i.reserve.some((e) => e.id === n.card)) return null;
	let o = r.effect, s = (e) => [{
		kind: "reaction",
		reaction: {
			kind: "reward",
			reward: {
				kind: "points",
				amount: e
			}
		}
	}], c = (e) => [{
		kind: "reaction",
		reaction: {
			kind: "reward",
			reward: {
				kind: "net",
				amount: e
			}
		}
	}];
	switch (o.kind) {
		case "scorePerHabitat": return s(Math.min(o.maximum, o.pointsPerIcon * i.reserve.filter((e) => e.habitat === o.habitat).length));
		case "activateMapSpecial": return [{
			kind: "chooseMapSpecial",
			habitat: o.habitat
		}];
		case "discountAndScore": return s(o.points);
		case "drawAndScoreMatchingHabitat": return [{
			kind: "draw",
			remaining: 1,
			after: "matchingHabitatPoints"
		}];
		case "scoreMostHabitat": return s(Math.max(...w.map((e) => i.reserve.filter((t) => t.habitat === e).length)));
		case "rechargeMostHabitat": return [{
			kind: "resources",
			remaining: o.amount,
			same: !0,
			restrict: "mostHabitat"
		}];
		case "rechargeTrophyResource": return [{
			kind: "fixedResources",
			resource: o.resource,
			amount: 1 + Math.floor(i.trophies / 3)
		}];
		case "rechargeLeastTrophyResource": return [{
			kind: "resources",
			remaining: 1 + Math.floor(i.trophies / 3),
			same: !0,
			restrict: "least"
		}];
		case "energyTrophyResource": return [{
			kind: "resources",
			remaining: 1 + Math.floor(i.trophies / 3),
			same: !0,
			optional: !0
		}];
		case "energyResourceAndExchange": return [{
			kind: "resources",
			remaining: 1,
			optional: !0
		}, { kind: "exchange" }];
		case "energyFreeRechargeCard": return [{
			kind: "playSelection",
			sources: "hand",
			filter: "recharge",
			free: !0,
			optional: !0
		}];
		case "energyActivateRecharge": return [{
			kind: "chooseRecharge",
			all: !1,
			optional: !0,
			cards: i.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
		}];
		case "activateRechargeAndEgg": return [{
			kind: "chooseRecharge",
			all: !1,
			thenEgg: !0,
			cards: i.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
		}];
		case "activateTwoRecharge": return [{
			kind: "chooseRecharge",
			all: !1,
			remaining: 2,
			cards: i.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
		}];
		case "rechargeLeastResourceAndScore": return [{
			kind: "resources",
			remaining: 1,
			same: !0,
			restrict: "least",
			after: "scoreResource"
		}];
		case "rechargeEndCardScore": return s(Math.min(o.maximum, i.reserve.filter((e) => e.type === "endGame").length));
		case "activateEndScore": return [{
			kind: "chooseEndScore",
			maximum: o.maximum
		}];
		case "restoreEnergy": return [{ kind: "restoreEnergy" }];
		case "nextCardDiscount": return [{
			kind: "nextCardDiscount",
			amount: 1
		}];
		case "activateLastInstant": {
			let e = n.previousInstant === void 0 ? [...i.reserve].reverse().find((e) => e.type === "instant" && e.id !== n.card) : i.reserve.find((e) => e.id === n.previousInstant);
			return !e || e.id === 52 || e.id === 53 ? [] : [{
				kind: "cardEffect",
				card: e.id,
				activation: "instant"
			}];
		}
		case "eggFromLastInstant": {
			let e = n.previousInstant === void 0 ? [...i.reserve].reverse().find((e) => e.type === "instant" && e.id !== n.card) : i.reserve.find((e) => e.id === n.previousInstant);
			return e ? [{
				kind: "chooseEgg",
				species: [...new Set(e.species)]
			}] : [];
		}
		case "takeWildernessAndTwoResources": return [{
			kind: "wilderness",
			remaining: 1,
			after: "twoResources"
		}];
		case "playWildernessPayCost": return [{
			kind: "playSelection",
			sources: "wilderness",
			filter: "any",
			free: !1,
			optional: !0
		}];
		case "energyFreeEndCard": return [{
			kind: "playSelection",
			sources: "either",
			filter: "endGame",
			free: !0,
			optional: !0
		}];
		case "takeWildernessAndEgg": return [{
			kind: "wilderness",
			remaining: 1,
			after: "speciesEgg"
		}];
		case "takeSpeciesCardsAndScore": return [{ kind: "takeSpecies" }];
		case "sweepAndTake": return [{
			kind: "sweep",
			thenTake: !0
		}];
		case "energyTakeWilderness": return [{
			kind: "wilderness",
			remaining: 1,
			optional: !0
		}];
		case "freeWildernessCard": return [{
			kind: "playSelection",
			sources: "wilderness",
			filter: "any",
			free: !0,
			optional: !0
		}];
		case "freeSmallHandCard": return [{
			kind: "playSelection",
			sources: "hand",
			filter: "small",
			free: !0,
			optional: !0
		}];
		case "energyAddSpecies": return [{
			kind: "addSpecies",
			card: n.card,
			optional: !0
		}];
		case "repeatAchievementReward": return [{ kind: "chooseAchievementReward" }];
		case "rechargeDrawHabitat": return [{
			kind: "draw",
			remaining: 1,
			after: "habitatResource"
		}];
		case "rechargeDrawEgg":
		case "drawEgg": return [{
			kind: "draw",
			remaining: 1,
			after: "speciesEgg"
		}];
		case "drawHandScore": return [{
			kind: "draw",
			remaining: 1,
			after: "handPoints"
		}];
		case "drawAndHandNet": return [{
			kind: "draw",
			remaining: 1,
			after: "handNet"
		}];
		case "drawThreeDiscard": return [{
			kind: "draw",
			remaining: 3,
			after: "none"
		}, {
			kind: "discard",
			remaining: 1,
			optional: !0,
			after: "none"
		}];
		case "lookThreeScore": return [{
			kind: "look",
			count: 3,
			after: "printedPoints"
		}];
		case "energyLookThreeResource": return [{
			kind: "chooseLook",
			count: 3,
			after: "habitatResource"
		}];
		case "energyEmptyHandDrawFour": return a.hand.length === 0 ? [{
			kind: "chooseDrawCount",
			maximum: 4,
			after: "habitatResourceDeferred"
		}] : null;
		case "energyDrawChooseTwo": return [{
			kind: "chooseDrawCount",
			maximum: 1,
			after: "chooseTwo"
		}];
		case "gainNets": return c(o.amount);
		case "energyFlipAndScore": return [{
			kind: "flipEggs",
			mode: "flip",
			minimum: 0,
			maximum: 2,
			flatPoints: 2
		}];
		case "flipEggsScore": return [{
			kind: "flipEggs",
			mode: "flip",
			minimum: 0,
			maximum: o.maximum,
			pointsPerEgg: o.pointsPerEgg
		}];
		case "hatchForAnyEgg": return [{
			kind: "flipEggs",
			mode: "hatch",
			minimum: 1,
			maximum: 1,
			after: "anyEgg"
		}];
		case "hatchEggsScore": return [{
			kind: "flipEggs",
			mode: "hatch",
			minimum: 0,
			maximum: o.maximum,
			pointsPerEgg: o.pointsPerEgg
		}];
		case "hatchForResources": return [{
			kind: "flipEggs",
			mode: "hatch",
			minimum: 1,
			maximum: 1,
			after: "twoResources"
		}];
		case "rechargeResourceAndFlip": return [{
			kind: "resources",
			remaining: 1,
			optional: !0
		}, {
			kind: "flipEggs",
			mode: "flip",
			minimum: 0,
			maximum: 2
		}];
		case "gainInsectEgg": return [{
			kind: "egg",
			species: "insect"
		}];
		case "gainAnyEgg": return [{
			kind: "chooseEgg",
			species: [...T]
		}];
		case "rechargeHatchedEggScore": return s(Math.floor(a.eggs.filter((e) => e.hatched).length / 2));
		case "discardDiscountAndScore": return s(o.points);
		case "discardDiscountAndNet": return c(1);
		case "discardForPoints": return [{
			kind: "discard",
			remaining: o.maximum,
			optional: !0,
			after: "twoPoints"
		}];
		case "discardSpeciesScore": return [{
			kind: "discard",
			remaining: 1,
			optional: !1,
			after: "speciesPoints"
		}];
		case "discardForResources":
		case "energyDiscardForResources": return [{
			kind: "discard",
			remaining: 1,
			optional: !1,
			after: "twoResources"
		}];
		case "discardForTwoEggs": return [{
			kind: "discard",
			remaining: 1,
			optional: !1,
			after: "twoEggs"
		}];
		case "discardForTwoWilderness": return [{
			kind: "discard",
			remaining: 1,
			optional: !1,
			after: "twoWilderness"
		}];
		case "supplySpecialAdvance": return [{
			kind: "chooseParts",
			parts: ["supplySpecial", "advanceBeast"]
		}];
		case "mostHabitatDiscountAdvance": return [{
			kind: "chooseParts",
			parts: ["threePoints", "advanceBeast"]
		}];
		case "resourceAdvance": return [{
			kind: "chooseParts",
			parts: ["resource", "advanceBeast"]
		}];
		case "allRechargeScore": return [{ kind: "activateAllRecharge" }, { kind: "scoreRechargeCards" }];
		case "wildernessMatchAdvance": return [{
			kind: "wilderness",
			remaining: 1,
			after: "beastMatch"
		}];
		case "awakeFreeOtherwiseAdvance": return e.beasts?.owned[t]?.awake ? [] : [{
			kind: "advanceBeast",
			spaces: 1
		}];
		case "rechargeInstantSets": return [{
			kind: "chooseGain",
			gain: { kind: "points" },
			maximum: 1 + Math.floor(i.reserve.filter((e) => e.type === "instant").length / 3)
		}];
		case "drawTwoAdvance": return [{
			kind: "chooseParts",
			parts: ["drawTwo", "advanceBeast"]
		}];
		case "netAdvance": return [{
			kind: "chooseParts",
			parts: ["net", "advanceBeast"]
		}];
		case "hatchResourceAdvance": return [{
			kind: "chooseParts",
			parts: ["hatchResource", "advanceBeast"]
		}];
		case "rechargeHatchOrFlip": return [{ kind: "chooseHatchOrFlip" }];
		case "discardHabitatAdvance": return [{
			kind: "chooseParts",
			parts: ["discardHabitat", "advanceBeast"]
		}];
		case "energyEmptyHandDrawEggs": return a.hand.length === 0 ? [{
			kind: "chooseDrawCount",
			maximum: 3,
			after: "speciesEggDeferred"
		}] : null;
		default: return null;
	}
}
//#endregion
//#region src/game/special-effects.ts
function An(e, t, n, r) {
	switch (n) {
		case "gainHabitatResource": return r === "net" ? null : [{
			kind: "fixedResources",
			resource: r,
			amount: 1
		}];
		case "flipEgg": return [{
			kind: "flipEggs",
			mode: "flip",
			minimum: 0,
			maximum: 1
		}];
		case "sweepAndTake": return [{
			kind: "sweep",
			thenTake: !0
		}];
		case "gainThreePoints": return [{
			kind: "reaction",
			reaction: {
				kind: "reward",
				reward: {
					kind: "points",
					amount: 3
				}
			}
		}];
		case "flipUpToTwoEggs": return [{
			kind: "flipEggs",
			mode: "flip",
			minimum: 0,
			maximum: 2
		}];
		case "playCard": return [{
			kind: "playSelection",
			sources: "hand",
			filter: "any",
			free: !1,
			optional: !0
		}];
		case "discardForHabitatResources": return [{
			kind: "discard",
			remaining: 1,
			optional: !1,
			after: "twoResources"
		}];
		case "drawRandomEgg": return [{ kind: "eggBag" }];
		case "takeWildernessAndResource": return [{
			kind: "wilderness",
			remaining: 1,
			after: "oneResource"
		}];
		case "activateRechargeCard": return [{
			kind: "chooseRecharge",
			all: !1,
			cards: e.players.find((e) => e.rid === t)?.reserve.filter((e) => e.type === "recharge").map((e) => e.id) ?? []
		}];
		case "drawTwoCards": return [{
			kind: "draw",
			remaining: 2,
			after: "none"
		}];
	}
}
//#endregion
//#region src/game/resolution.ts
function K(e, t) {
	return t && e.length > 1 ? [{
		kind: "reactionOrder",
		reactions: [...e]
	}] : e.map((e) => ({
		kind: "reaction",
		reaction: e
	}));
}
function jn(e) {
	return e.length > 1 ? [{
		kind: "activationOrder",
		tasks: [...e]
	}] : [...e];
}
function Mn(e, t, n) {
	let r = e.setup.players.find((e) => e.rid === t), i = e.players.find((e) => e.rid === t);
	if (!r || !i) return [];
	if (n.restrict === "least") {
		let e = Math.min(...w.map((e) => r.resources[e]));
		return w.filter((t) => r.resources[t] === e);
	}
	if (n.restrict === "mostHabitat") {
		let e = w.map((e) => i.reserve.filter((t) => t.habitat === e).length), t = Math.max(...e);
		return w.filter((n, r) => e[r] === t);
	}
	return [...w];
}
function Nn(e, t, n, r = []) {
	let i = e.setup.players.find((e) => e.rid === t), a = e.players.find((e) => e.rid === t);
	if (!i || !a) return [];
	let o = [];
	return n.sources !== "wilderness" && o.push(...i.hand.map((e) => ({
		card: e,
		source: { kind: "hand" }
	}))), n.sources !== "hand" && o.push(...e.setup.wilderness.flatMap((e, t) => e === null ? [] : [{
		card: e,
		source: {
			kind: "wilderness",
			slot: t
		}
	}])), o.filter((o) => {
		let s = U.get(o.card);
		if (!s || r.includes(s.id) || a.reserve.some((e) => e.id === s.id) || n.filter === "recharge" && s.type !== "recharge" || n.filter === "endGame" && s.type !== "endGame" || n.filter === "small" && Dn(s) > 2) return !1;
		if (n.free || s.effect.kind === "awakeFreeOtherwiseAdvance" && e.beasts?.owned[t]?.awake) return !0;
		let c = s.effect.kind === "discardDiscountAndScore" || s.effect.kind === "discardDiscountAndNet" ? s.effect.maximum : 0, l = Math.min(c, i.hand.filter((e) => !r.includes(e) && (o.source.kind !== "hand" || e !== o.card)).length);
		return Sn(wn(s), i.resources, Tn(s, a.reserve) + e.nextCardDiscount + l + Se(e.beasts?.owned[t], Dn(s)));
	});
}
function Pn(e, t, n) {
	switch (e.kind) {
		case "resources": return [{
			kind: "resources",
			remaining: e.amount
		}];
		case "wildernessCards": return [{
			kind: "wilderness",
			remaining: e.amount
		}];
		case "restoreEnergy": return [{ kind: "restoreEnergy" }];
		case "discovery": return [{ kind: "discovery" }];
		case "activateAllRecharge": return [{
			kind: "chooseRecharge",
			all: !0,
			cards: t.players.find((e) => e.rid === n)?.reserve.filter((e) => e.type === "recharge").map((e) => e.id) ?? []
		}];
		case "repeatAchievementReward": return [{ kind: "chooseAchievementReward" }];
		default: return [];
	}
}
function Fn(e, t, n = !1) {
	t = {
		owner: t.owner,
		tasks: t.tasks
	};
	let r = e, i = [...t.tasks];
	for (; i.length > 0;) {
		if (n && r !== e) return {
			status: "beat",
			state: r,
			resolution: {
				owner: t.owner,
				tasks: i,
				pendingBeat: !0
			}
		};
		let a = i[0];
		if (a.kind !== "reaction") {
			if (a.kind === "finishBasic") {
				i.shift();
				let e = Gt(r, t.owner);
				if (!e) return { status: "invalid" };
				r = e;
				continue;
			}
			if (a.kind === "discardToFive") {
				i.shift();
				let e = r.setup.players.find((e) => e.rid === t.owner);
				if (!e) return { status: "invalid" };
				e.hand.length > 5 && i.unshift({
					kind: "discard",
					remaining: 1,
					optional: !1,
					after: "none"
				}, a);
				continue;
			}
			if (a.kind === "sweepAll") {
				i.shift();
				let e = ut(r.setup.deck, r.setup.wilderness, "all", r.setup.seed, r.setup.cursor);
				r = {
					...r,
					setup: {
						...r.setup,
						deck: e.deck,
						wilderness: e.wilderness,
						cursor: e.cursor
					}
				};
				continue;
			}
			if (a.kind === "refillWilderness") {
				i.shift();
				let e = lt(r.setup.deck, r.setup.wilderness, r.setup.seed, r.setup.cursor);
				r = {
					...r,
					setup: {
						...r.setup,
						deck: e.deck,
						wilderness: e.wilderness,
						cursor: e.cursor
					}
				};
				continue;
			}
			if (a.kind === "claimBeast") {
				i.shift();
				let e = r.beasts && xe(r.beasts, t.owner, a.beast);
				if (!e) return { status: "invalid" };
				r = {
					...r,
					beasts: e
				};
				continue;
			}
			if (a.kind === "advanceBeast") {
				i.shift();
				let e = r.setup.players.find((e) => e.rid === t.owner);
				if (!e) return { status: "invalid" };
				let n = r.beasts && I(r.beasts, t.owner, a.spaces, e.eggs);
				n && (r = {
					...r,
					beasts: n.state
				}, n.points && i.unshift({
					kind: "reaction",
					reaction: {
						kind: "reward",
						reward: {
							kind: "points",
							amount: n.points
						}
					}
				}));
				continue;
			}
			if (a.kind === "removeTrophy") {
				i.shift();
				let e = tn(r, t.owner, !1);
				if (!e) return { status: "invalid" };
				r = e.state;
				continue;
			}
			if (a.kind === "activateAllRecharge" || a.kind === "activateAllRechargeTwice") {
				i.shift();
				let e = r.players.find((e) => e.rid === t.owner);
				if (!e) return { status: "invalid" };
				let n = r.beasts?.owned[t.owner];
				i.unshift({
					kind: "chooseRecharge",
					all: !0,
					twice: a.kind === "activateAllRechargeTwice" || a.duringRecharge === !0 && n?.id === 7 && n.awake,
					cards: e.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
				});
				continue;
			}
			if (a.kind === "repeatRecharge") {
				i.shift();
				let e = r.players.find((e) => e.rid === t.owner);
				if (!e || !e.reserve.some((e) => e.id === a.card && e.type === "recharge")) return { status: "invalid" };
				let n = Jt({ kind: "activateRecharge" }, e.reserve).map((e) => ({
					kind: "reaction",
					reaction: {
						kind: "trigger",
						ability: e
					}
				}));
				n.push({
					kind: "cardEffect",
					card: a.card,
					activation: "recharge"
				}), i.unshift(...jn(n));
				continue;
			}
			if (a.kind === "scoreRechargeCards") {
				i.shift();
				let e = r.players.find((e) => e.rid === t.owner);
				if (!e) return { status: "invalid" };
				i.unshift({
					kind: "chooseGain",
					gain: { kind: "points" },
					maximum: e.reserve.filter((e) => e.type === "recharge").length
				});
				continue;
			}
			if (a.kind === "hatchSelected") {
				i.shift();
				let e = r.setup.players.find((e) => e.rid === t.owner), n = r.players.find((e) => e.rid === t.owner);
				if (!e || !n || a.indices.some((t) => !Number.isInteger(t) || t < 0 || t >= e.eggs.length)) return { status: "invalid" };
				let o = a.indices.filter((t) => !e.eggs[t].hatched), s = vt(e.eggs, o, "hatch", o.length);
				if (!s) return { status: "invalid" };
				r = {
					...r,
					setup: {
						...r.setup,
						players: r.setup.players.map((e) => e.rid === t.owner ? {
							...e,
							eggs: s.eggs
						} : e)
					}
				};
				let c = Jt({
					kind: "flipEggs",
					count: s.flipped
				}, n.reserve).map((e) => ({
					kind: "trigger",
					ability: e
				}));
				i.unshift(...K(c, !0));
				continue;
			}
			if (a.kind === "markAchievementReward") {
				i.shift();
				let e = r.claims.find((e) => e.owner === t.owner && e.marker === a.marker);
				if (!e) return { status: "invalid" };
				r = {
					...r,
					claims: r.claims.map((t) => t === e ? {
						...t,
						usedMarkerReward: !0
					} : t)
				};
				continue;
			}
			if (a.kind === "unlockCaptain") {
				i.shift();
				let e = r.setup.players.find((e) => e.rid === t.owner), n = r.players.find((e) => e.rid === t.owner);
				if (!e || !n) return { status: "invalid" };
				n.captainUnlocked || (r = {
					...r,
					players: r.players.map((n) => n.rid === t.owner ? {
						...n,
						captainUnlocked: !0,
						captainEnergy: n.captainEnergy + +(e.captain === "tingent" || e.captain === "ashe" || e.captain === "nathaniel")
					} : n)
				}, e.captain === "helena" && i.unshift({
					kind: "reaction",
					reaction: {
						kind: "reward",
						reward: {
							kind: "net",
							amount: 1
						}
					}
				}));
				continue;
			}
			if (a.kind === "specialEffect") {
				i.shift();
				let e = An(r, t.owner, a.effect, a.habitat);
				if (!e) return { status: "invalid" };
				i.unshift(...e);
				continue;
			}
			if (a.kind === "eggBag") {
				i.shift();
				let e = $t(r, t.owner, { kind: "bag" });
				if (!e) return { status: "invalid" };
				r = e.state, i.unshift(...K(e.reactions, !0));
				continue;
			}
			if (a.kind === "look") {
				i.shift();
				let e = ft(r.setup, a.count);
				r = {
					...r,
					setup: {
						...r.setup,
						deck: e.state.deck,
						cursor: e.state.cursor
					}
				}, e.looked.length > 0 && i.unshift({
					kind: "lookChoice",
					cards: e.looked,
					after: a.after
				});
				continue;
			}
			if (a.kind === "draw") {
				i.shift();
				let e = en(r, t.owner);
				if (!e) return { status: "invalid" };
				if (r = e.state, a.after === "speciesEggDeferred" || a.after === "habitatResourceDeferred") {
					let t = e.card === null ? a.drawn ?? [] : [...a.drawn ?? [], e.card];
					e.card !== null && a.remaining > 1 ? i.unshift({
						...a,
						remaining: a.remaining - 1,
						drawn: t
					}) : i.unshift(...t.map((e) => ({
						kind: "afterDraw",
						card: e,
						after: a.after === "speciesEggDeferred" ? "speciesEggOptional" : "habitatResource"
					}))), e.card !== null && i.unshift(...K(e.reactions, !0));
				} else e.card !== null && (a.remaining > 1 && i.unshift({
					...a,
					remaining: a.remaining - 1
				}), a.after !== "none" && i.unshift({
					kind: "afterDraw",
					card: e.card,
					after: a.after
				}), i.unshift(...K(e.reactions, !0)));
				continue;
			}
			if (a.kind === "afterDraw") {
				i.shift();
				let e = U.get(a.card), n = r.setup.players.find((e) => e.rid === t.owner), o = r.players.find((e) => e.rid === t.owner);
				if (!e || !n || !o) return { status: "invalid" };
				a.after === "habitatResource" && i.unshift({
					kind: "chooseGain",
					gain: {
						kind: "resource",
						resource: e.habitat
					},
					maximum: 1
				}), a.after === "speciesEgg" && i.unshift({
					kind: "chooseEgg",
					species: [...new Set(e.species)],
					optional: !0
				}), a.after === "speciesEggOptional" && i.unshift({
					kind: "chooseEgg",
					species: [...new Set(e.species)],
					optional: !0
				}), a.after === "matchingHabitatPoints" && i.unshift({
					kind: "chooseGain",
					gain: { kind: "points" },
					maximum: Math.min(5, o.reserve.filter((t) => t.habitat === e.habitat).length)
				}), a.after === "handPoints" && i.unshift({
					kind: "chooseGain",
					gain: { kind: "points" },
					maximum: Math.min(10, n.hand.length)
				}), a.after === "handNet" && n.hand.length >= 5 && i.unshift({
					kind: "chooseGain",
					gain: { kind: "net" },
					maximum: 1
				}), a.after === "chooseTwo" && i.unshift({
					kind: "drawRewards",
					card: e.id,
					remaining: 2,
					options: [
						"egg",
						"resource",
						"points"
					]
				}), a.after === "beastReward" && i.unshift({
					kind: "resources",
					remaining: 1
				}, {
					kind: "reaction",
					reaction: {
						kind: "reward",
						reward: {
							kind: "points",
							amount: 1
						}
					}
				});
				continue;
			}
			if (a.kind === "fixedResources") {
				i.shift();
				let e = Zt(r, t.owner, { [a.resource]: a.amount });
				if (!e) return { status: "invalid" };
				r = e.state;
				continue;
			}
			if (a.kind === "nextCardDiscount") {
				i.shift(), r = {
					...r,
					nextCardDiscount: r.nextCardDiscount + a.amount
				};
				continue;
			}
			if (a.kind === "increaseDiscount") {
				i.shift();
				let e = i.findIndex((e) => e.kind === "payCard" && e.card === a.card), t = i[e];
				if (e < 0 || t.kind !== "payCard") return { status: "invalid" };
				i[e] = {
					...t,
					discountDiscards: t.discountDiscards + 1
				};
				continue;
			}
			if (a.kind === "egg") {
				i.shift();
				let e = $t(r, t.owner, {
					kind: "stock",
					species: a.species
				});
				if (!e) return { status: "invalid" };
				r = e.state, i.unshift(...K(e.reactions, !0));
				continue;
			}
			if (a.kind === "reactionOrder" && a.reactions.length === 1) {
				i.splice(0, 1, {
					kind: "reaction",
					reaction: a.reactions[0]
				});
				continue;
			}
			if (a.kind === "activationOrder" && a.tasks.length === 1) {
				i.splice(0, 1, a.tasks[0]);
				continue;
			}
			if (a.kind === "discardConfirm" && !r.setup.players.find((e) => e.rid === t.owner)?.hand.includes(a.card)) {
				i.splice(0, 1, a.origin);
				continue;
			}
			if (a.kind === "chooseRecharge" && a.cards.length === 0 || a.kind === "wilderness" && (a.remaining <= 0 || r.setup.wilderness.every((e) => e === null)) || a.kind === "resources" && a.remaining <= 0 || a.kind === "chooseGain" && a.maximum <= 0 || a.kind === "chooseEgg" && !a.species.some((e) => r.setup.eggSupply.stock[e] > 0) || a.kind === "discard" && (a.remaining <= 0 || !r.setup.players.find((e) => e.rid === t.owner)?.hand.some((e) => e !== a.excluded && !i.some((t) => t.kind === "payCard" && t.card === e))) || a.kind === "chooseEndScore" && !r.players.find((e) => e.rid === t.owner)?.reserve.some((e) => e.type === "endGame") || a.kind === "chooseMapSpecial" && !r.setup.board.some((e) => e.terrain === "habitat" && e.habitat === a.habitat && e.special !== void 0) || a.kind === "chooseAchievementReward" && !r.claims.some((e) => e.owner === t.owner && e.usedMarkerReward) || a.kind === "chooseHatchOrFlip" && !r.setup.players.find((e) => e.rid === t.owner)?.eggs.length || a.kind === "timeEggs" && gn(a.symbol, r.setup.board, r.setup.boardEggs, r.explorers, r.setup.eggSupply).length === 0 || a.kind === "basicPlay" && a.remaining <= 0 || a.kind === "basicPlay" && !a.first && Nn(r, t.owner, {
				kind: "playSelection",
				sources: "hand",
				filter: "any",
				free: !1,
				optional: !0
			}).length === 0 || a.kind === "captainMarie" && r.setup.habitatSupply.display.every((e) => e === null) || a.kind === "playSelection" && a.basic !== "first" && Nn(r, t.owner, a, i.flatMap((e) => e.kind === "payCard" ? [e.card] : [])).length === 0 || a.kind === "addSpecies" && !T.some((e) => r.setup.eggSupply.stock[e] > 0 && !r.players.find((e) => e.rid === t.owner)?.reserve.find((e) => e.id === a.card)?.species.includes(e)) || a.kind === "flipEggs" && a.minimum > 0 && !r.setup.players.find((e) => e.rid === t.owner)?.eggs.some((e) => a.mode === "flip" || !e.hatched) || a.kind === "restoreEnergy" && !r.players.find((e) => e.rid === t.owner)?.energy.length || a.kind === "discovery" && (!r.setup.board.some((e) => e.terrain === "lake") || r.setup.habitatSupply.display.every((e) => e === null))) {
				i.shift();
				continue;
			}
			return {
				status: "choice",
				state: r,
				resolution: {
					...t,
					tasks: i
				},
				task: a
			};
		}
		i.shift();
		let o = a.reaction;
		if (o.kind === "trigger") {
			let e = o.ability;
			e.kind === "points" && i.unshift({
				kind: "reaction",
				reaction: {
					kind: "reward",
					reward: {
						kind: "points",
						amount: e.amount
					}
				}
			}), e.kind === "chooseResource" && i.unshift({
				kind: "resources",
				remaining: 1
			}), e.kind === "fixedResource" && i.unshift({
				kind: "fixedResources",
				resource: e.resource,
				amount: 1
			}), e.kind === "activateRecharge" && i.unshift({
				kind: "chooseRecharge",
				all: !1,
				cards: r.players.find((e) => e.rid === t.owner)?.reserve.filter((e) => e.type === "recharge").map((e) => e.id) ?? []
			});
			continue;
		}
		let s = o.reward;
		if (s.kind === "points") {
			let e = Xt(r, t.owner, s.amount);
			if (!e) return { status: "invalid" };
			r = e.state, i.unshift(...K(e.reactions, !1));
		} else if (s.kind === "net") {
			let e = Qt(r, t.owner, s.amount);
			if (!e) return { status: "invalid" };
			r = e.state, i.unshift(...K(e.reactions, !1));
		} else if (s.kind === "trophy") {
			let e = tn(r, t.owner, !0);
			if (!e) return { status: "invalid" };
			r = e.state, i.unshift(...K(e.reactions, !0));
		} else i.unshift(...Pn(s, r, t.owner));
	}
	return {
		status: "ready",
		state: r,
		resolution: {
			...t,
			tasks: i
		}
	};
}
function In(e, t, n, r = !1) {
	let i = Fn(e, t);
	if (i.status !== "choice") return { status: "invalid" };
	let a = i.state, o = [...i.resolution.tasks], s = o.shift(), c = t.owner;
	if (s.kind === "reactionOrder" && n.kind === "reaction") {
		if (!Number.isInteger(n.index) || n.index < 0 || n.index >= s.reactions.length) return { status: "invalid" };
		let e = s.reactions[n.index], t = s.reactions.filter((e, t) => t !== n.index);
		o.unshift({
			kind: "reaction",
			reaction: e
		}, ...K(t, !0));
	} else if (s.kind === "chooseParts" && n.kind === "effectParts") {
		if (new Set(n.indices).size !== n.indices.length || n.indices.some((e) => !Number.isInteger(e) || e < 0 || e >= s.parts.length)) return { status: "invalid" };
		let e = new Set(n.indices), t = {
			supplySpecial: [{
				kind: "captainMarie",
				mandatory: !0
			}],
			threePoints: [{
				kind: "chooseGain",
				gain: { kind: "points" },
				maximum: 3
			}],
			resource: [{
				kind: "resources",
				remaining: 1
			}],
			drawTwo: [{
				kind: "chooseDrawCount",
				maximum: 2,
				after: "none"
			}],
			net: [{
				kind: "reaction",
				reaction: {
					kind: "reward",
					reward: {
						kind: "net",
						amount: 1
					}
				}
			}],
			hatchResource: [{
				kind: "flipEggs",
				mode: "hatch",
				minimum: 1,
				maximum: 1,
				after: "oneResource"
			}],
			discardHabitat: [{
				kind: "discard",
				remaining: 1,
				optional: !1,
				after: "habitatResource"
			}],
			advanceBeast: [{
				kind: "advanceBeast",
				spaces: 1
			}]
		};
		o.unshift(...s.parts.flatMap((n, r) => e.has(r) ? t[n] : []));
	} else if (s.kind === "chooseDrawCount" && n.kind === "drawCount") {
		if (!Number.isInteger(n.count) || n.count < 0 || n.count > s.maximum) return { status: "invalid" };
		n.count > 0 && o.unshift({
			kind: "draw",
			remaining: n.count,
			after: s.after
		});
	} else if (s.kind === "chooseGain" && n.kind === "gainCount") {
		if (!Number.isInteger(n.count) || n.count < 0 || n.count > s.maximum) return { status: "invalid" };
		if (n.count > 0) {
			if (s.gain.kind === "points") o.unshift({
				kind: "reaction",
				reaction: {
					kind: "reward",
					reward: {
						kind: "points",
						amount: n.count
					}
				}
			});
			else if (s.gain.kind === "net") o.unshift({
				kind: "reaction",
				reaction: {
					kind: "reward",
					reward: {
						kind: "net",
						amount: n.count
					}
				}
			});
			else if (s.gain.kind === "resource") o.unshift({
				kind: "fixedResources",
				resource: s.gain.resource,
				amount: n.count
			});
			else {
				let e = s.gain.species;
				o.unshift(...Array.from({ length: n.count }, () => ({
					kind: "egg",
					species: e
				})));
			}
		}
	} else if (s.kind === "activationOrder" && n.kind === "activation") {
		if (!Number.isInteger(n.index) || n.index < 0 || n.index >= s.tasks.length) return { status: "invalid" };
		let e = s.tasks[n.index];
		o.unshift(e, ...jn(s.tasks.filter((e, t) => t !== n.index)));
	} else if (s.kind === "explorer" && n.kind === "explorerEgg") {
		let e = Me(s.action, n.position);
		if (!e) return { status: "invalid" };
		let t = $t(a, c, {
			kind: "collected",
			species: e.egg.species
		});
		if (!t) return { status: "invalid" };
		a = t.state, o.unshift({
			...s,
			action: e.action
		}), o.unshift(...K(t.reactions, !0));
	} else if (s.kind === "explorer" && n.kind === "explorerHabitat") {
		let e = z(s.action, n.position, n.reward, a.setup.wilderness, (e) => U.get(e).habitat);
		if (!e) return { status: "invalid" };
		if (o.unshift({
			...s,
			action: e.action
		}), e.reward.kind === "resource") {
			let t = Zt(a, c, { [e.reward.resource]: 1 });
			if (!t) return { status: "invalid" };
			a = t.state;
		} else if (e.reward.kind === "net") {
			let e = Qt(a, c, 1);
			if (!e) return { status: "invalid" };
			a = e.state, o.unshift(...K(e.reactions, !1));
		} else {
			let t = a.setup.players.find((e) => e.rid === c), n = t && W(a.setup, t.hand, e.reward.slot);
			if (!n || n.taken !== e.reward.card) return { status: "invalid" };
			a = {
				...a,
				setup: {
					...a.setup,
					wilderness: n.state.wilderness,
					players: a.setup.players.map((e) => e.rid === c ? {
						...e,
						hand: n.hand
					} : e)
				}
			};
		}
	} else if (s.kind === "explorer" && n.kind === "captain") {
		let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c);
		if (!e || !t || !t.captainUnlocked || s.captainUsed || s.action.explorer.piece !== "captain") return { status: "invalid" };
		switch (o.unshift({
			...s,
			captainUsed: !0
		}), e.captain) {
			case "cabot":
				o.unshift({
					kind: "chooseRecharge",
					all: !1,
					cards: t.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
				});
				break;
			case "freya":
				o.unshift({
					kind: "captainFreya",
					cells: s.action.explorer.cells
				});
				break;
			case "haoa":
				o.unshift({
					kind: "playSelection",
					sources: "hand",
					filter: "any",
					free: !1,
					optional: !0
				});
				break;
			case "macus": {
				let e = Pe(s.action, a.setup.board);
				e?.special && o.unshift({
					kind: "specialEffect",
					effect: e.special,
					habitat: e.habitat
				});
				break;
			}
			case "marie":
				o.unshift({ kind: "captainMarie" });
				break;
			case "octavia":
				o.unshift({
					kind: "discard",
					remaining: 1,
					optional: !1,
					after: "twoResources"
				});
				break;
			case "samuel":
				o.unshift({
					kind: "resources",
					remaining: 1 + Math.floor(t.trophies / 3),
					same: !0,
					restrict: "least"
				});
				break;
			case "tingent":
				o.unshift({ kind: "captainTingent" });
				break;
			case "ashe":
			case "nathaniel":
				a = {
					...a,
					players: a.players.map((e) => e.rid === c ? {
						...e,
						captainEnergy: e.captainEnergy + 1
					} : e)
				};
				break;
			case "rabell": {
				let e = bn(a, c, s.action.explorer.cells);
				e.length && o.unshift({
					kind: "captainRabell",
					species: e
				});
				break;
			}
			case "morgane":
				o.unshift({
					kind: "captainMorgane",
					cells: s.action.explorer.cells,
					paidMountain: !!s.paidMountain
				});
				break;
			case "helena": break;
			default: return { status: "invalid" };
		}
	} else if (s.kind === "explorer" && n.kind === "finishExplorer") {
		if (s.action.coveredEggs.length || s.action.remainingHabitats.length) return { status: "invalid" };
	} else if (s.kind !== "captainFreya" || n.kind !== "skip") {
		if (s.kind === "captainFreya" && n.kind === "freya") {
			if (n.mode === "flip") o.unshift({
				kind: "flipEggs",
				mode: "flip",
				minimum: 0,
				maximum: 2
			});
			else if (n.mode === "egg" && n.position) {
				let e = new Set(s.cells.flatMap(Te).map(R)), t = a.setup.boardEggs.find((e) => R(e) === R(n.position));
				if (!t || !e.has(R(t))) return { status: "invalid" };
				a = {
					...a,
					setup: {
						...a.setup,
						boardEggs: a.setup.boardEggs.filter((e) => R(e) !== R(t))
					}
				};
				let r = $t(a, c, {
					kind: "collected",
					species: t.species
				});
				if (!r) return { status: "invalid" };
				a = r.state, o.unshift(...K(r.reactions, !0));
			} else return { status: "invalid" };
		} else if (s.kind === "captainMarie" && n.kind === "marie") {
			if (!Number.isInteger(n.slot) || n.slot < 0 || n.slot >= a.setup.habitatSupply.display.length) return { status: "invalid" };
			let e = kt.find((e) => e.id === a.setup.habitatSupply.display[n.slot]);
			if (!e) return { status: "invalid" };
			o.unshift({
				kind: "specialEffect",
				effect: e.special,
				habitat: e.habitat
			});
		} else if (s.kind !== "captainMarie" || s.mandatory || n.kind !== "skip") {
			if (s.kind === "captainTingent" && n.kind === "tingent") {
				let e = a.players.find((e) => e.rid === c);
				if (!e) return { status: "invalid" };
				if (n.mode === "gain" && s.gainAllowed !== !1) a = {
					...a,
					players: a.players.map((e) => e.rid === c ? {
						...e,
						captainEnergy: e.captainEnergy + 1
					} : e)
				};
				else if (n.mode === "distribute") {
					let t = n.allocations ?? [];
					if (new Set(t.map((e) => e.card)).size !== t.length || t.some((e) => !Number.isInteger(e.amount) || e.amount < 1) || t.reduce((e, t) => e + t.amount, 0) > e.captainEnergy) return { status: "invalid" };
					let r = e.energy.map((e) => {
						let n = t.find((t) => t.card === e.card)?.amount ?? 0;
						return {
							...e,
							energy: e.energy + n
						};
					});
					if (t.some((t) => !e.energy.some((e) => e.card === t.card)) || r.some((e) => {
						let t = U.get(e.card);
						return !t || !("energyCapacity" in t) || t.energyCapacity === void 0 || e.energy > t.energyCapacity;
					})) return { status: "invalid" };
					let i = t.reduce((e, t) => e + t.amount, 0);
					a = {
						...a,
						players: a.players.map((e) => e.rid === c ? {
							...e,
							captainEnergy: e.captainEnergy - i,
							energy: r
						} : e)
					};
				} else return { status: "invalid" };
			} else if (s.kind !== "captainTingent" || n.kind !== "skip") {
				if (s.kind === "captainRabell" && n.kind === "egg" && s.species.includes(n.species)) {
					let e = $t(a, c, {
						kind: "stock",
						species: n.species
					});
					if (!e?.species) return { status: "invalid" };
					a = e.state, o.unshift(...K(e.reactions, !0));
				} else if (s.kind !== "captainMorgane" || n.kind !== "skip") {
					if (s.kind === "captainMorgane" && n.kind === "captainCopy") {
						let e = yn(a, c, s.cells).some((e) => e.owner === n.owner && e.captain === n.captain), t = a.players.find((e) => e.rid === c);
						if (!e || !t || n.captain === "morgane" || n.captain === "helena" && s.paidMountain) return { status: "invalid" };
						switch (n.captain) {
							case "cabot":
								o.unshift({
									kind: "chooseRecharge",
									all: !1,
									cards: t.reserve.filter((e) => e.type === "recharge").map((e) => e.id)
								});
								break;
							case "freya":
								o.unshift({
									kind: "captainFreya",
									cells: s.cells
								});
								break;
							case "haoa":
								o.unshift({
									kind: "playSelection",
									sources: "hand",
									filter: "any",
									free: !1,
									optional: !0
								});
								break;
							case "macus": {
								let e = Pe({
									explorer: {
										owner: c,
										piece: "captain",
										cells: s.cells
									},
									coveredEggs: [],
									remainingHabitats: []
								}, a.setup.board);
								e?.special && o.unshift({
									kind: "specialEffect",
									effect: e.special,
									habitat: e.habitat
								});
								break;
							}
							case "marie":
								o.unshift({ kind: "captainMarie" });
								break;
							case "octavia":
								o.unshift({
									kind: "discard",
									remaining: 1,
									optional: !1,
									after: "twoResources"
								});
								break;
							case "samuel":
								o.unshift({
									kind: "resources",
									remaining: 1 + Math.floor(t.trophies / 3),
									same: !0,
									restrict: "least"
								});
								break;
							case "rabell": {
								let e = bn(a, c, s.cells);
								e.length && o.unshift({
									kind: "captainRabell",
									species: e
								});
								break;
							}
							case "ashe":
							case "nathaniel":
							case "tingent": a = {
								...a,
								players: a.players.map((e) => e.rid === c ? {
									...e,
									captainEnergy: e.captainEnergy + 1
								} : e)
							}, n.captain === "tingent" && o.unshift({
								kind: "captainTingent",
								gainAllowed: !1
							});
						}
					} else if (s.kind === "timeEggs" && n.kind === "timeEgg") {
						let e = _n(s.symbol, n.position, a.setup.board, a.setup.boardEggs, a.explorers, a.setup.eggSupply);
						if (!e) return { status: "invalid" };
						a = {
							...a,
							setup: {
								...a.setup,
								boardEggs: e.eggs,
								eggSupply: e.supply
							}
						}, o.unshift(s);
					} else if (s.kind === "basicPlay" && n.kind === "basicPlay") {
						if (!n.play && s.first) return { status: "invalid" };
						n.play && o.unshift({
							kind: "playSelection",
							sources: "hand",
							filter: "any",
							free: !1,
							optional: !1,
							basic: s.first ? "first" : "later"
						}, {
							...s,
							remaining: s.remaining - 1,
							first: !1
						});
					} else if (s.kind === "resources" && n.kind === "resource" && Mn(a, c, s).includes(n.resource)) {
						if (s.same && s.optional) return o.unshift({
							kind: "chooseGain",
							gain: {
								kind: "resource",
								resource: n.resource
							},
							maximum: s.remaining
						}), Fn(a, {
							owner: c,
							tasks: o
						}, r);
						let e = Zt(a, c, { [n.resource]: s.same ? s.remaining : 1 });
						if (!e) return { status: "invalid" };
						if (a = e.state, s.after === "scoreResource") {
							let e = a.setup.players.find((e) => e.rid === c)?.resources[n.resource];
							if (e === void 0) return { status: "invalid" };
							o.unshift({
								kind: "chooseGain",
								gain: { kind: "points" },
								maximum: e
							});
						}
						!s.same && s.remaining > 1 && o.unshift({
							...s,
							remaining: s.remaining - 1
						});
					} else if (!(s.kind === "resources" && s.optional && n.kind === "skip") && !(s.kind === "chooseEgg" && s.optional && n.kind === "skip")) {
						if (s.kind === "chooseEgg" && n.kind === "egg" && s.species.includes(n.species) && a.setup.eggSupply.stock[n.species] > 0) s.optional && (s.count ?? 1) > 1 ? o.unshift({
							kind: "chooseGain",
							gain: {
								kind: "egg",
								species: n.species
							},
							maximum: Math.min(s.count, a.setup.eggSupply.stock[n.species])
						}) : o.unshift(...Array.from({ length: s.count ?? 1 }, () => ({
							kind: "egg",
							species: n.species
						})));
						else if (!(s.kind === "discard" && n.kind === "skip" && s.optional)) {
							if (s.kind === "discard" && n.kind === "discard") {
								let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c), r = U.get(n.card), i = o.some((e) => e.kind === "payCard" && e.card === n.card);
								if (!e || !t || !r || !e.hand.includes(n.card) || s.excluded === n.card || i) return { status: "invalid" };
								let l = t.energy.flatMap((e) => {
									let t = U.get(e.card);
									return t && t.effect.kind === "energyPlayInsteadOfDiscard" && e.energy > 0 && !a.usedEnergy.includes(t.id) && Dn(r) <= t.effect.maximumCost ? [t.id] : [];
								});
								o.unshift({
									kind: "discardConfirm",
									card: n.card,
									candidates: l,
									origin: s
								});
							} else if (s.kind === "discardConfirm" && n.kind === "discardConfirm") {
								let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c), r = U.get(s.card);
								if (!e || !t || !r || !e.hand.includes(s.card)) return { status: "invalid" };
								if (n.replacement === null) {
									let n = mt(a.setup, e.hand, s.card);
									if (!n) return { status: "invalid" };
									a = {
										...a,
										setup: {
											...a.setup,
											deck: n.state.deck,
											players: a.setup.players.map((e) => e.rid === c ? {
												...e,
												hand: n.hand
											} : e)
										}
									}, s.origin.remaining > 1 && o.unshift({
										...s.origin,
										remaining: s.origin.remaining - 1
									}), s.origin.after === "twoPoints" && o.unshift({
										kind: "chooseGain",
										gain: { kind: "points" },
										maximum: 2
									}), s.origin.after === "twoResources" && o.unshift({
										kind: "chooseGain",
										gain: {
											kind: "resource",
											resource: r.habitat
										},
										maximum: 2
									}), s.origin.after === "twoEggs" && o.unshift({
										kind: "chooseEgg",
										species: [...new Set(r.species)],
										count: 2,
										optional: !0
									}), s.origin.after === "twoWilderness" && o.unshift({
										kind: "wilderness",
										remaining: 2,
										optional: !0
									}), s.origin.after === "speciesPoints" && o.unshift({
										kind: "scoreSpecies",
										card: r.id
									}), s.origin.after === "discount" && s.origin.discountTarget !== void 0 && o.unshift({
										kind: "increaseDiscount",
										card: s.origin.discountTarget
									}), s.origin.after === "beastReward" && o.unshift({
										kind: "resources",
										remaining: 1
									}, {
										kind: "reaction",
										reaction: {
											kind: "reward",
											reward: {
												kind: "points",
												amount: 1
											}
										}
									}), s.origin.after === "habitatAdvance" && o.unshift({
										kind: "fixedResources",
										resource: r.habitat,
										amount: 1
									}, {
										kind: "advanceBeast",
										spaces: 1
									}), s.origin.after === "habitatResource" && o.unshift({
										kind: "chooseGain",
										gain: {
											kind: "resource",
											resource: r.habitat
										},
										maximum: 1
									});
									let i = Jt({ kind: "discardHandCard" }, t.reserve).map((e) => ({
										kind: "trigger",
										ability: e
									}));
									o.unshift(...K(i, !0));
								} else {
									if (!s.candidates.includes(n.replacement)) return { status: "invalid" };
									let r = it(t.energy, a.usedEnergy, n.replacement);
									if (!r) return { status: "invalid" };
									let i = En({
										card: s.card,
										source: { kind: "hand" },
										hand: e.hand,
										wilderness: a.setup.wilderness,
										resources: e.resources,
										payment: {
											fruit: 0,
											coral: 0,
											flower: 0,
											mushroom: 0
										},
										reserve: t.reserve,
										energy: r.cards,
										free: !0,
										otherDiscount: 0,
										discardedForDiscount: 0
									});
									if (!i) return { status: "invalid" };
									a = {
										...a,
										usedEnergy: r.usedThisTurn,
										nextCardDiscount: 0,
										players: a.players.map((e) => e.rid === c ? {
											...e,
											reserve: i.reserve,
											energy: i.energy
										} : e),
										setup: {
											...a.setup,
											wilderness: i.wilderness,
											players: a.setup.players.map((e) => e.rid === c ? {
												...e,
												hand: i.hand,
												resources: i.resources
											} : e)
										}
									}, s.origin.optional && o.unshift(s.origin);
									let l = i.triggers.map((e) => ({
										kind: "reaction",
										reaction: {
											kind: "trigger",
											ability: e
										}
									}));
									Se(a.beasts?.owned[c], Dn(i.card)) && l.push({
										kind: "reaction",
										reaction: {
											kind: "reward",
											reward: {
												kind: "points",
												amount: 1
											}
										}
									}), i.card.type === "instant" && l.push({
										kind: "cardEffect",
										card: i.card.id,
										activation: "instant",
										previousInstant: i.previousInstant
									});
									let u = a.beasts?.owned[c];
									o.unshift(...u && L(u, i.card.species) ? [{
										kind: "advanceBeast",
										spaces: 1
									}] : [], ...jn(l));
								}
							} else if (s.kind === "scoreSpecies" && n.kind === "species") {
								let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c), r = U.get(s.card);
								if (!e || !t || !r?.species.includes(n.species)) return { status: "invalid" };
								let i = t.reserve.reduce((e, t) => e + t.species.filter((e) => e === n.species).length, 0) + e.eggs.filter((e) => e.species === n.species).length + ve(a.beasts, c).filter((e) => e === n.species).length;
								o.unshift({
									kind: "chooseGain",
									gain: { kind: "points" },
									maximum: i
								});
							} else if (!(s.kind === "playSelection" && n.kind === "skip" && s.optional)) {
								if (s.kind === "playSelection" && n.kind === "cancelPlay" && s.basic) {
									if (s.basic === "first") {
										if (a.basicAction?.kind !== "playCards" || a.basicAction.resolved || o.length !== 2 || o[0].kind !== "basicPlay" || o[1].kind !== "finishBasic") return { status: "invalid" };
										o.splice(0, 2), a = {
											...a,
											basicAction: null
										};
									}
								} else if (s.kind === "playSelection" && n.kind === "selectPlay") {
									if (!Nn(a, c, s, o.flatMap((e) => e.kind === "payCard" ? [e.card] : [])).some((e) => e.card === n.card && e.source.kind === n.source.kind && (e.source.kind === "hand" || n.source.kind === "wilderness" && e.source.slot === n.source.slot)) || o.some((e) => e.kind === "payCard" && e.card === n.card)) return { status: "invalid" };
									o.unshift({
										kind: "payCard",
										card: n.card,
										source: n.source,
										free: s.free,
										discountDiscards: 0,
										optional: s.optional,
										origin: s
									});
								} else if (s.kind === "payCard" && n.kind === "cancelPlay" && s.origin && s.discountDiscards === 0) o.unshift(s.origin);
								else if (!(s.kind === "payCard" && n.kind === "skip" && s.optional && s.discountDiscards === 0)) {
									if (s.kind === "payCard" && n.kind === "discount") {
										let e = U.get(s.card), t = a.setup.players.find((e) => e.rid === c), n = e?.effect.kind === "discardDiscountAndScore" || e?.effect.kind === "discardDiscountAndNet" ? e.effect.maximum : 0;
										if (s.free || !t || s.discountDiscards >= n || !t.hand.some((e) => e !== s.card && !o.some((t) => t.kind === "payCard" && t.card === e))) return { status: "invalid" };
										o.unshift({
											kind: "discard",
											remaining: 1,
											optional: !1,
											after: "discount",
											excluded: s.source.kind === "hand" ? s.card : void 0,
											discountTarget: s.card
										}, s);
									} else if (s.kind === "payCard" && n.kind === "payment") {
										let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c);
										if (!e || !t) return { status: "invalid" };
										let r = U.get(s.card);
										if (!r) return { status: "invalid" };
										let i = s.free || r.effect.kind === "awakeFreeOtherwiseAdvance" && !!a.beasts?.owned[c]?.awake, l = En({
											card: s.card,
											source: s.source,
											hand: e.hand,
											wilderness: a.setup.wilderness,
											resources: e.resources,
											payment: n.payment,
											reserve: t.reserve,
											energy: t.energy,
											free: i,
											otherDiscount: a.nextCardDiscount + Se(a.beasts?.owned[c], Dn(r)),
											discardedForDiscount: s.discountDiscards
										});
										if (!l) return { status: "invalid" };
										a = {
											...a,
											nextCardDiscount: 0,
											players: a.players.map((e) => e.rid === c ? {
												...e,
												reserve: l.reserve,
												energy: l.energy
											} : e),
											setup: {
												...a.setup,
												wilderness: l.wilderness,
												players: a.setup.players.map((e) => e.rid === c ? {
													...e,
													hand: l.hand,
													resources: l.resources
												} : e)
											}
										};
										let u = l.triggers.map((e) => ({
											kind: "reaction",
											reaction: {
												kind: "trigger",
												ability: e
											}
										}));
										Se(a.beasts?.owned[c], Dn(l.card)) && u.push({
											kind: "reaction",
											reaction: {
												kind: "reward",
												reward: {
													kind: "points",
													amount: 1
												}
											}
										}), l.card.type === "instant" && u.push({
											kind: "cardEffect",
											card: l.card.id,
											activation: "instant",
											previousInstant: l.previousInstant
										});
										let d = a.beasts?.owned[c];
										o.unshift(...d && L(d, l.card.species) ? [{
											kind: "advanceBeast",
											spaces: 1
										}] : [], ...jn(u));
									} else if (!(s.kind === "addSpecies" && n.kind === "skip" && s.optional)) {
										if (s.kind === "addSpecies" && n.kind === "egg") {
											let e = a.players.find((e) => e.rid === c), t = e?.reserve.find((e) => e.id === s.card);
											if (!e || !t || t.species.includes(n.species)) return { status: "invalid" };
											let r = _t(a.setup.eggSupply, n.species);
											if (!r.acquired) return { status: "invalid" };
											a = {
												...a,
												setup: {
													...a.setup,
													eggSupply: r.supply
												},
												players: a.players.map((e) => e.rid === c ? {
													...e,
													reserve: e.reserve.map((e) => e.id === s.card ? {
														...e,
														species: [...e.species, n.species]
													} : e)
												} : e)
											};
										} else if (s.kind !== "exchange" || n.kind !== "skip") {
											if (s.kind === "exchange" && n.kind === "exchange") {
												let e = a.setup.players.find((e) => e.rid === c);
												if (!e || !w.includes(n.from) || !w.includes(n.to) || n.from === n.to || !Number.isInteger(n.amount) || n.amount < 1 || n.amount > e.resources[n.from]) return { status: "invalid" };
												let t = {
													...e.resources,
													[n.from]: e.resources[n.from] - n.amount
												};
												a = {
													...a,
													setup: {
														...a.setup,
														players: a.setup.players.map((e) => e.rid === c ? {
															...e,
															resources: t
														} : e)
													}
												};
												let r = Zt(a, c, { [n.to]: n.amount });
												if (!r) return { status: "invalid" };
												a = r.state;
											} else if (s.kind === "chooseMapSpecial" && n.kind === "mapSpecial") {
												let e = a.setup.board.find((e) => e.row === n.position.row && e.column === n.position.column);
												if (!e || e.terrain !== "habitat" || e.habitat !== s.habitat || !e.special) return { status: "invalid" };
												o.unshift({
													kind: "specialEffect",
													effect: e.special,
													habitat: e.habitat
												});
											} else if ((s.kind === "chooseEndScore" || s.kind === "chooseEndCopy") && n.kind === "endCard") {
												let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c);
												if (!e || !t) return { status: "invalid" };
												let r = {
													cards: t.reserve,
													eggs: e.eggs,
													resources: e.resources,
													nets: e.nets,
													extraSpecies: ve(a.beasts, c)
												};
												if (!t.reserve.some((e) => e.id === n.card && e.type === "endGame") || s.kind === "chooseEndCopy" && !s.targets.includes(n.card)) return { status: "invalid" };
												if (s.kind === "chooseEndScore" && n.card === 120) {
													let e = t.reserve.filter((e) => e.type === "endGame" && e.id !== 120).map((e) => e.id);
													e.length > 0 && o.unshift({
														kind: "chooseEndCopy",
														maximum: s.maximum,
														targets: e
													});
												} else {
													let e = rn(s.kind === "chooseEndCopy" ? 120 : n.card, r, s.kind === "chooseEndCopy" ? n.card : void 0);
													if (e === null) return { status: "invalid" };
													o.unshift({
														kind: "reaction",
														reaction: {
															kind: "reward",
															reward: {
																kind: "points",
																amount: Math.min(s.maximum, e)
															}
														}
													});
												}
											} else if (s.kind === "chooseAchievementReward" && n.kind === "achievementReward") {
												let e = a.claims.find((e) => e.owner === c && e.marker === n.marker && e.usedMarkerReward);
												if (!e) return { status: "invalid" };
												o.unshift({
													kind: "reaction",
													reaction: {
														kind: "reward",
														reward: e.reward
													}
												});
											} else if (s.kind !== "chooseLook" || n.kind !== "skip") {
												if (s.kind === "chooseLook" && n.kind === "lookNow") o.unshift({
													kind: "look",
													count: s.count,
													after: s.after
												});
												else if (s.kind === "lookChoice" && n.kind === "lookCard") {
													let e = a.setup.players.find((e) => e.rid === c), t = U.get(n.card);
													if (!e || !t) return { status: "invalid" };
													let r = pt(a.setup, e.hand, s.cards, n.card);
													if (!r) return { status: "invalid" };
													a = {
														...a,
														setup: {
															...a.setup,
															deck: r.state.deck,
															players: a.setup.players.map((e) => e.rid === c ? {
																...e,
																hand: r.hand
															} : e)
														}
													}, s.after === "printedPoints" ? o.unshift({
														kind: "chooseGain",
														gain: { kind: "points" },
														maximum: t.printedPoints
													}) : s.after === "habitatResource" ? o.unshift({
														kind: "chooseGain",
														gain: {
															kind: "resource",
															resource: t.habitat
														},
														maximum: 1
													}) : o.unshift({
														kind: "payCard",
														card: t.id,
														source: { kind: "hand" },
														free: !0,
														discountDiscards: 0,
														optional: !1
													});
												} else if (s.kind !== "drawRewards" || n.kind !== "skip") {
													if (s.kind === "drawRewards" && n.kind === "drawReward") {
														let e = U.get(s.card);
														if (!e || !s.options.includes(n.reward)) return { status: "invalid" };
														s.remaining > 1 && o.unshift({
															...s,
															remaining: s.remaining - 1,
															options: s.options.filter((e) => e !== n.reward)
														}), n.reward === "egg" && o.unshift({
															kind: "chooseEgg",
															species: [...new Set(e.species)]
														}), n.reward === "resource" && o.unshift({
															kind: "fixedResources",
															resource: e.habitat,
															amount: 1
														}), n.reward === "points" && o.unshift({
															kind: "chooseGain",
															gain: { kind: "points" },
															maximum: e.printedPoints
														});
													} else if (s.kind === "flipEggs" && n.kind === "eggs") {
														let e = a.setup.players.find((e) => e.rid === c), t = a.players.find((e) => e.rid === c);
														if (!e || !t || n.indices.length < s.minimum) return { status: "invalid" };
														let r = vt(e.eggs, n.indices, s.mode, s.maximum);
														if (!r) return { status: "invalid" };
														a = {
															...a,
															setup: {
																...a.setup,
																players: a.setup.players.map((e) => e.rid === c ? {
																	...e,
																	eggs: r.eggs
																} : e)
															}
														}, s.after === "anyEgg" && r.flipped > 0 && o.unshift({
															kind: "chooseEgg",
															species: [...T],
															optional: !0
														}), s.after === "twoResources" && r.flipped > 0 && o.unshift({
															kind: "resources",
															remaining: 2,
															same: !0,
															optional: !0
														}), s.after === "mixedResources" && r.flipped > 0 && o.unshift({
															kind: "resources",
															remaining: 2,
															optional: !0
														}), s.after === "oneResource" && r.flipped > 0 && o.unshift({
															kind: "resources",
															remaining: 1,
															optional: !0
														}), s.after === "oneResourceAdvance" && r.flipped > 0 && o.unshift({
															kind: "resources",
															remaining: 1
														}, {
															kind: "advanceBeast",
															spaces: 1
														});
														let i = (s.flatPoints ?? 0) + (s.pointsPerEgg ?? 0) * r.flipped;
														i && o.unshift({
															kind: "chooseGain",
															gain: { kind: "points" },
															maximum: i
														});
														let l = Jt({
															kind: "flipEggs",
															count: r.flipped
														}, t.reserve).map((e) => ({
															kind: "trigger",
															ability: e
														}));
														o.unshift(...K(l, !0));
													} else if (!(s.kind === "wilderness" && s.optional && n.kind === "skip")) {
														if (s.kind === "wilderness" && n.kind === "wilderness") {
															let e = a.setup.players.find((e) => e.rid === c);
															if (!e) return { status: "invalid" };
															let t = W(a.setup, e.hand, n.slot);
															if (!t) return { status: "invalid" };
															a = {
																...a,
																setup: {
																	...a.setup,
																	wilderness: t.state.wilderness,
																	players: a.setup.players.map((e) => e.rid === c ? {
																		...e,
																		hand: t.hand
																	} : e)
																}
															}, s.remaining > 1 && o.unshift({
																...s,
																remaining: s.remaining - 1
															});
															let r = U.get(t.taken);
															if (!r) return { status: "invalid" };
															if (s.after === "oneResource" && o.unshift({
																kind: "chooseGain",
																gain: {
																	kind: "resource",
																	resource: r.habitat
																},
																maximum: 1
															}), s.after === "twoResources" && o.unshift({
																kind: "chooseGain",
																gain: {
																	kind: "resource",
																	resource: r.habitat
																},
																maximum: 2
															}), s.after === "speciesEgg" && o.unshift({
																kind: "chooseEgg",
																species: [...new Set(r.species)],
																optional: !0
															}), s.after === "beastMatch") {
																let e = a.beasts?.owned[c];
																e && L(e, r.species) && o.unshift({
																	kind: "chooseParts",
																	parts: ["advanceBeast"]
																});
															}
														} else if (s.kind === "chooseHatchOrFlip" && n.kind === "hatchOrFlip") {
															let e = a.setup.players.find((e) => e.rid === c);
															if (!e || n.mode === "hatch" && !e.eggs.some((e) => !e.hatched) || n.mode === "flip" && e.eggs.length === 0) return { status: "invalid" };
															o.unshift({
																kind: "flipEggs",
																mode: n.mode,
																minimum: 1,
																maximum: 1,
																after: n.mode === "hatch" ? "mixedResources" : "oneResource"
															});
														} else if (s.kind === "takeSpecies" && n.kind === "species" && T.includes(n.species)) {
															let e = a.setup.players.find((e) => e.rid === c);
															if (!e) return { status: "invalid" };
															let t = a.setup, r = [...e.hand], i = 0;
															for (let e = 0; e < t.wilderness.length; e++) {
																let a = t.wilderness[e];
																if (a === null || !U.get(a)?.species.includes(n.species)) continue;
																let o = W(t, r, e);
																if (!o) return { status: "invalid" };
																t = {
																	...t,
																	wilderness: o.state.wilderness
																}, r = o.hand, i++;
															}
															a = {
																...a,
																setup: {
																	...t,
																	players: t.players.map((e) => e.rid === c ? {
																		...e,
																		hand: r
																	} : e)
																}
															}, i && o.unshift({
																kind: "chooseGain",
																gain: { kind: "points" },
																maximum: i
															});
														} else if (s.kind === "sweep" && n.kind === "sweep" && (n.area === "left" || n.area === "right")) {
															let e = ut(a.setup.deck, a.setup.wilderness, n.area, a.setup.seed, a.setup.cursor);
															a = {
																...a,
																setup: {
																	...a.setup,
																	deck: e.deck,
																	wilderness: e.wilderness,
																	cursor: e.cursor
																}
															}, s.thenTake && o.unshift({
																kind: "wilderness",
																remaining: 1,
																optional: !0
															});
														} else if (s.kind === "restoreEnergy" && n.kind === "energy") {
															let e = a.players.find((e) => e.rid === c), t = e && at(e.energy, n.card);
															if (!t) return { status: "invalid" };
															a = {
																...a,
																players: a.players.map((e) => e.rid === c ? {
																	...e,
																	energy: t
																} : e)
															};
														} else if (s.kind === "discovery" && n.kind === "discovery") {
															let e = On({
																board: a.setup.board,
																boardEggs: a.setup.boardEggs,
																supply: a.setup.habitatSupply,
																slot: n.slot,
																position: n.position
															});
															if (!e) return { status: "invalid" };
															if (a = {
																...a,
																setup: {
																	...a.setup,
																	board: e.board,
																	boardEggs: e.boardEggs,
																	habitatSupply: e.supply
																}
															}, e.egg) {
																let t = $t(a, c, {
																	kind: "collected",
																	species: e.egg.species
																});
																if (!t) return { status: "invalid" };
																a = t.state, o.unshift(...K(t.reactions, !0));
															}
														} else if (!(s.kind === "chooseRecharge" && n.kind === "skip" && s.optional)) {
															if (s.kind === "chooseRecharge" && n.kind === "recharge") {
																if (!s.cards.includes(n.card) || U.get(n.card)?.type !== "recharge") return { status: "invalid" };
																let e = a.players.find((e) => e.rid === c);
																if (!e || !e.reserve.some((e) => e.id === n.card && e.type === "recharge")) return { status: "invalid" };
																if ((s.all || (s.remaining ?? 1) > 1) && o.unshift({
																	...s,
																	cards: s.cards.filter((e) => e !== n.card),
																	remaining: s.all ? s.remaining : (s.remaining ?? 1) - 1
																}), s.twice && o.unshift({
																	kind: "repeatRecharge",
																	card: n.card
																}), s.thenEgg) {
																	let t = e.reserve.find((e) => e.id === n.card);
																	o.unshift({
																		kind: "chooseEgg",
																		species: [...new Set(t.species)],
																		optional: !0
																	});
																}
																let t = Jt({ kind: "activateRecharge" }, e.reserve).map((e) => ({
																	kind: "reaction",
																	reaction: {
																		kind: "trigger",
																		ability: e
																	}
																}));
																t.push({
																	kind: "cardEffect",
																	card: n.card,
																	activation: "recharge"
																}), o.unshift(...jn(t));
															} else if (s.kind === "cardEffect" && n.kind === "cardEffect") {
																if (n.use) {
																	let e = kn(a, c, s);
																	if (!e) return { status: "invalid" };
																	if (s.activation === "energy") {
																		let t = a.players.find((e) => e.rid === c), n = a.setup.players.find((e) => e.rid === c), r = e[0];
																		if (!t || !n || r?.kind === "playSelection" && Nn(a, c, r, o.flatMap((e) => e.kind === "payCard" ? [e.card] : [])).length === 0 || r?.kind === "chooseRecharge" && r.cards.length === 0 || r?.kind === "wilderness" && a.setup.wilderness.every((e) => e === null) || r?.kind === "discard" && n.hand.length === 0 || (r?.kind === "draw" || r?.kind === "look" || r?.kind === "chooseLook") && a.setup.deck.drawPile.length + a.setup.deck.discard.length === 0 || r?.kind === "addSpecies" && !T.some((e) => a.setup.eggSupply.stock[e] > 0 && !t.reserve.find((e) => e.id === r.card)?.species.includes(e))) return { status: "invalid" };
																		let i = t && it(t.energy, a.usedEnergy, s.card);
																		if (!i) return { status: "invalid" };
																		a = {
																			...a,
																			usedEnergy: i.usedThisTurn,
																			players: a.players.map((e) => e.rid === c ? {
																				...e,
																				energy: i.cards
																			} : e)
																		};
																	}
																	o.unshift(...e);
																}
															} else return { status: "invalid" };
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return r && a !== e && o.length ? {
		status: "beat",
		state: a,
		resolution: {
			owner: c,
			tasks: o,
			pendingBeat: !0
		}
	} : Fn(a, {
		owner: c,
		tasks: o
	}, r);
}
//#endregion
//#region src/game/solo-placement.ts
function Ln(e) {
	let t = Ee(e.board, e.explorers.flatMap((e) => e.cells)).filter((e) => e.mountainCost === 0).map((t) => {
		let n = De(e.board, t.cells), r = new Set([...t.cells, ...t.cells.flatMap(Te)].map(R)), i = [
			n.filter((t) => t.habitat === e.habitat).length,
			n.length,
			n.filter((e) => e.special !== void 0).length,
			e.eggs.filter((e) => r.has(R(e))).length
		];
		return {
			cells: t.cells,
			score: i
		};
	});
	if (!t.length) return [];
	let n = (e, t) => {
		for (let n = 0; n < e.length; n++) if (e[n] !== t[n]) return t[n] - e[n];
		return 0;
	};
	return t.sort((e, t) => n(e.score, t.score)), t.filter((e) => n(e.score, t[0].score) === 0).map((e) => e.cells);
}
//#endregion
//#region src/game/solo-engine.ts
function Rn(e, t, n) {
	let r = e.setup, i = [...t.hiddenCards];
	for (let e = 0; e < n; e++) {
		let e = ct(r.deck, r.seed, r.cursor);
		r = {
			...r,
			deck: e.deck,
			cursor: e.cursor
		}, e.card !== null && i.push(e.card);
	}
	return {
		match: {
			...e,
			setup: r
		},
		tingent: {
			...t,
			hiddenCards: i
		}
	};
}
function zn(e, t) {
	let n = e.setup, r = [...t.drawPile], i = [...t.discard];
	if (!r.length) {
		let e = M(i, n.seed, n.cursor);
		r = e.items, i = [], n = {
			...n,
			cursor: e.cursor
		};
	}
	let a = r.pop(), o = cn.find((e) => e.id === a);
	if (!o) return null;
	let s = [
		t.brown ? o.brown : o.yellow,
		...o.advance ? [{ kind: "track" }] : [],
		{ kind: "finish" }
	];
	return {
		match: {
			...e,
			setup: n
		},
		tingent: {
			...t,
			drawPile: r,
			discard: [...i, o.id],
			steps: s
		}
	};
}
function Bn(e, t, n = !1) {
	if (e.phase !== "turn" || e.activePlayer !== "$tingent" || t.steps.length) return { status: "invalid" };
	let r = zn(e, t);
	return r ? n ? {
		status: "beat",
		...r
	} : Gn(r.match, r.tingent) : { status: "invalid" };
}
function Vn(e, t, n) {
	let r = e.setup.achievements.filter((t) => t.kind === n && !e.claims.some((e) => e.owner === "$tingent" && e.achievement === t.id));
	if (!r.length) return t;
	let i = e.setup.achievements.findIndex((e) => e.id === t.targets[n]), a = r.find((t) => e.setup.achievements.findIndex((e) => e.id === t.id) > i) ?? r[0];
	return {
		...t,
		targets: {
			...t.targets,
			[n]: a.id
		}
	};
}
function Hn(e, t, n) {
	let r = e.setup.achievements.find((e) => e.id === t.targets[n]);
	if (!r || e.claims.filter((e) => e.owner === "$tingent").length >= 6 || e.claims.some((e) => e.owner === "$tingent" && e.achievement === r.id)) return {
		match: e,
		tingent: t
	};
	let i = r.kind === "single" ? [r.species] : r.kind === "multi" ? r.species : [], a = un(r, t.visibleCards.reduce((e, t) => e + (U.get(t)?.species.filter((e) => i.includes(e)).length ?? 0), 0) + t.eggs.filter((e) => i.includes(e)).length, e.claims.filter((e) => e.achievement === r.id).map((e) => e.slot));
	if (a === null) return {
		match: e,
		tingent: t
	};
	let o = se(r, 2)[a].points, s = e.claims.filter((e) => e.owner === fn).length, c = Math.max(0, e.setup.trophies - 1), l = {
		...e,
		setup: {
			...e.setup,
			trophies: c
		},
		claims: [...e.claims, {
			owner: fn,
			achievement: r.id,
			slot: a,
			marker: s,
			points: o,
			reward: {
				kind: "points",
				amount: 0
			},
			usedMarkerReward: !1
		}]
	};
	return {
		match: l,
		tingent: Vn(l, {
			...t,
			trophies: t.trophies + +(e.setup.trophies > 0)
		}, n)
	};
}
function Un(e, t, n, r) {
	let i = e.setup.achievements.find((e) => e.id === t.targets[n]);
	if (!i || i.kind === "main") return {
		match: e,
		tingent: t
	};
	let a = i.kind === "single" ? [i.species] : i.species, o = e.setup.wilderness.flatMap((e, t) => e && U.get(e)?.species.some((e) => a.includes(e)) ? [{
		id: e,
		slot: t
	}] : []).sort((e, t) => U.get(t.id).printedPoints - U.get(e.id).printedPoints || e.slot - t.slot)[0], s = o ? {
		match: e,
		tingent: {
			...t,
			visibleCards: [...t.visibleCards, o.id]
		}
	} : Rn(e, t, 1);
	if (o) {
		let e = [...s.match.setup.wilderness];
		e[o.slot] = null, s.match = {
			...s.match,
			setup: {
				...s.match.setup,
				wilderness: e
			}
		};
	}
	if (r) {
		let e = o ? U.get(o.id).species.find((e) => a.includes(e)) ?? a[0] : a[0], t = _t(s.match.setup.eggSupply, e);
		t.acquired && (s.match = {
			...s.match,
			setup: {
				...s.match.setup,
				eggSupply: t.supply
			}
		}, s.tingent = {
			...s.tingent,
			eggs: [...s.tingent.eggs, e]
		});
	}
	return s;
}
function Wn(e, t) {
	let n = new Set(e.map(R));
	return t.length === 2 && t.every((e) => n.has(R(e)));
}
function Gn(e, t, n, r = !1) {
	let i = e, a = t, o = n;
	for (let n = 0; n < 300; n++) {
		let [n, ...s] = a.steps;
		if (!n) return {
			status: "ready",
			match: i,
			tingent: a
		};
		if (r && !o && (i !== e || a !== t)) return {
			status: "beat",
			match: i,
			tingent: a
		};
		if (n.kind === "place") {
			let e = Ln({
				board: i.setup.board,
				explorers: i.explorers,
				eggs: i.setup.boardEggs,
				habitat: n.habitat
			});
			if (!e.length) {
				let e = zn(i, {
					...a,
					steps: []
				});
				if (!e) return { status: "invalid" };
				i = e.match, a = e.tingent;
				continue;
			}
			let t = o?.kind === "placement" ? e.find((e) => Wn(e, o.kind === "placement" ? o.cells : [])) : e.length === 1 ? e[0] : void 0;
			if (!t) return o ? { status: "invalid" } : {
				status: "choice",
				match: i,
				tingent: a,
				choices: e.map((e) => ({
					kind: "placement",
					cells: e
				}))
			};
			o = void 0;
			let r = new Set(t.map(R)), c = i.setup.boardEggs.filter((e) => r.has(R(e))), l = De(i.setup.board, t).filter((e) => e.habitat === n.habitat).length;
			i = {
				...i,
				explorers: [...i.explorers.filter((e) => e.owner !== "$tingent" || e.piece !== (n.piece === "captain" ? "captain" : "explorerA")), {
					owner: fn,
					piece: n.piece === "captain" ? "captain" : "explorerA",
					cells: t
				}],
				setup: {
					...i.setup,
					boardEggs: i.setup.boardEggs.filter((e) => !r.has(R(e)))
				}
			}, a = {
				...a,
				points: a.points + (n.piece === "captain" ? l : 0),
				eggs: [...a.eggs, ...c.map((e) => e.species)],
				steps: [...n.hiddenCards ? [{
					kind: "hiddenCards",
					count: n.hiddenCards
				}] : [], ...s]
			};
			continue;
		}
		if (n.kind === "timeEggs") {
			let e = gn(n.symbol, i.setup.board, i.setup.boardEggs, i.explorers, i.setup.eggSupply);
			if (!e.length) {
				a = {
					...a,
					steps: s
				};
				continue;
			}
			let t = o?.kind === "timeEgg" ? e.find((e) => R(e) === R(o.kind === "timeEgg" ? o.position : e)) : e.length === 1 ? e[0] : void 0;
			if (!t) return o ? { status: "invalid" } : {
				status: "choice",
				match: i,
				tingent: a,
				choices: e.map((e) => ({
					kind: "timeEgg",
					position: e
				}))
			};
			o = void 0;
			let r = _n(n.symbol, t, i.setup.board, i.setup.boardEggs, i.explorers, i.setup.eggSupply);
			if (!r) return { status: "invalid" };
			i = {
				...i,
				setup: {
					...i.setup,
					boardEggs: r.eggs,
					eggSupply: r.supply
				}
			};
			continue;
		}
		if (o) return { status: "invalid" };
		if (a = {
			...a,
			steps: s
		}, n.kind === "hiddenCards") {
			let e = Rn(i, a, n.count);
			i = e.match, a = e.tingent;
			continue;
		}
		if (n.kind === "takeTarget") {
			let e = Un(i, a, n.target, n.egg);
			i = e.match, a = e.tingent;
			continue;
		}
		if (n.kind === "track") {
			let e = sn[a.difficulty], t = Math.min(e.spaces.length, a.position + 1);
			if (!a.brown && t >= e.firstBrown) {
				let e = M([...a.drawPile, ...a.discard], i.setup.seed, i.setup.cursor);
				i = {
					...i,
					setup: {
						...i.setup,
						cursor: e.cursor
					}
				}, a = {
					...a,
					brown: !0,
					drawPile: e.items,
					discard: []
				};
			}
			a = {
				...a,
				position: t,
				steps: [{
					kind: "trackEffect",
					effect: e.spaces[t - 1]
				}, ...a.steps]
			};
			continue;
		}
		if (n.kind === "trackEffect") {
			if (n.effect === "main" || n.effect === "single" || n.effect === "multi") {
				let e = Hn(i, a, n.effect);
				i = e.match, a = e.tingent;
				continue;
			}
			if (n.effect === "discovery") {
				let e = i.setup.board.filter((e) => e.terrain === "lake").sort((e, t) => e.column - t.column || e.row - t.row), t = e.find((e) => i.setup.boardEggs.some((t) => R(t) === R(e))) ?? [...e].sort((e, t) => e.row - t.row || e.column - t.column)[0], n = [...i.setup.habitatSupply.drawPile], r = kt.find((e) => e.id === n.pop());
				if (t && r) {
					let e = i.setup.boardEggs.find((e) => R(e) === R(t));
					i = {
						...i,
						setup: {
							...i.setup,
							habitatSupply: {
								...i.setup.habitatSupply,
								drawPile: n
							},
							board: i.setup.board.map((e) => R(e) === R(t) ? {
								...e,
								terrain: "habitat",
								habitat: r.habitat,
								special: r.special
							} : e),
							boardEggs: i.setup.boardEggs.filter((e) => R(e) !== R(t))
						}
					}, e && (a = {
						...a,
						eggs: [...a.eggs, e.species]
					});
				}
			}
			if (n.effect === "time") {
				let e = zt(i.timePosition, 2), t = i.setup.timeTokens.find((t) => t.position === e.position), n = {
					...i.setup,
					timeTokens: i.setup.timeTokens.filter((t) => t.position !== e.position)
				};
				i = {
					...i,
					timePosition: e.position,
					revealedTimeTokens: t ? [...i.revealedTimeTokens, t] : i.revealedTimeTokens,
					setup: n
				}, a = {
					...a,
					steps: [
						...t ? [{
							kind: "timeEggs",
							symbol: t.symbol
						}] : [],
						{
							kind: "timeEffects",
							effects: e.space.effects
						},
						...a.steps
					]
				};
			}
			continue;
		}
		if (n.kind === "timeEffects") {
			let e = i.setup;
			if (n.effects.includes("sweepAll")) {
				let t = ut(e.deck, e.wilderness, "all", e.seed, e.cursor);
				e = {
					...e,
					...t
				};
			}
			n.effects.includes("removeTrophy") && (e = {
				...e,
				trophies: Math.max(0, e.trophies - 1)
			}), i = {
				...i,
				setup: e
			};
			continue;
		}
		if (n.kind === "finish") {
			let e = lt(i.setup.deck, i.setup.wilderness, i.setup.seed, i.setup.cursor), t = i.setup.trophies === 0 || !!i.finalTurns;
			i = {
				...i,
				setup: {
					...i.setup,
					...e
				},
				phase: t ? "endGame" : "turn",
				activePlayer: t ? null : i.players.find((e) => e.rid !== "$tingent")?.rid ?? null,
				basicAction: null,
				finalTurns: null
			};
		}
	}
	return { status: "invalid" };
}
//#endregion
//#region src/game/payment-reservations.ts
function Kn(e) {
	let t = e.resolution;
	if (!t) return !0;
	let n = t.tasks.filter((e) => e.kind === "payCard"), r = n.flatMap((e) => {
		let n = t.tasks.filter((t) => t.kind === "increaseDiscount" && t.card === e.card).length;
		return e.discountDiscards > 0 || n > 0 ? [{
			task: e,
			pending: n
		}] : [];
	});
	if (!r.length) return !0;
	let i = e.match.setup.players.find((e) => e.rid === t.owner), a = e.match.players.find((e) => e.rid === t.owner);
	if (!i || !a) return !1;
	let o = new Set(n.map((e) => e.card)), s = i.hand.filter((e) => !o.has(e)).length, c = (n, o, s, l) => {
		if (n === r.length) return !0;
		let { task: u, pending: d } = r[n], f = U.get(u.card);
		if (!f || u.source.kind === "hand" && !i.hand.includes(u.card) || u.source.kind === "wilderness" && e.match.setup.wilderness[u.source.slot] !== u.card) return !1;
		let p = wn(f), m = f.effect.kind === "discardDiscountAndScore" || f.effect.kind === "discardDiscountAndNet" ? f.effect.maximum : 0, h = Math.max(0, m - u.discountDiscards - d), g = u.free || f.effect.kind === "awakeFreeOtherwiseAdvance" && e.match.beasts?.owned[t.owner]?.awake ? E(p) : Tn(f, a.reserve) + l + Se(e.match.beasts?.owned[t.owner], Dn(f)) + u.discountDiscards + d;
		for (let e = 0; e <= Math.min(h, s); e++) {
			let t = Math.max(0, E(p) - g - e);
			for (let r = 0; r <= Math.min(p.fruit, o.fruit, t); r++) for (let i = 0; i <= Math.min(p.coral, o.coral, t - r); i++) for (let a = 0; a <= Math.min(p.flower, o.flower, t - r - i); a++) {
				let l = t - r - i - a;
				if (l < 0 || l > p.mushroom || l > o.mushroom) continue;
				let u = {
					fruit: r,
					coral: i,
					flower: a,
					mushroom: l
				}, d = Object.fromEntries(w.map((e) => [e, o[e] - u[e]]));
				if (c(n + 1, d, s - e, 0)) return !0;
			}
		}
		return !1;
	}, l = [{
		resources: i.resources,
		discards: s
	}], u = (e) => [...new Map(e.map((e) => [w.map((t) => e.resources[t]).join(",") + ":" + e.discards, e])).values()], d = (e, t = !1, n = !0, r = !1) => {
		l = l.flatMap((i) => [...n || e.length === 0 ? [i] : [], ...e.flatMap((e) => t && i.discards < 1 ? [] : [{
			resources: {
				...i.resources,
				[e.resource]: Math.min(6, i.resources[e.resource] + e.amount)
			},
			discards: i.discards - +!!t + +!!r
		}])]), l = u(l);
	}, f = (e) => {
		let t = e.same ? 1 : e.remaining;
		for (let n = 0; n < t; n++) l = u(l.flatMap((t) => {
			let n = w.map((e) => a.reserve.filter((t) => t.habitat === e).length), r = Math.min(...w.map((e) => t.resources[e])), i = Math.max(...n);
			return [t, ...w.filter((a, o) => e.restrict === "least" ? t.resources[a] === r : e.restrict !== "mostHabitat" || n[o] === i).map((n) => ({
				...t,
				resources: {
					...t.resources,
					[n]: Math.min(6, t.resources[n] + (e.same ? e.remaining : 1))
				}
			}))];
		}));
	}, p = (e, t, n) => {
		l = u(l.flatMap((r) => {
			if (t && r.discards < 1) return [r];
			let i = {
				...r,
				discards: r.discards - +!!t + e
			};
			return n ? [r, i] : [i];
		}));
	}, m = e.match.setup.wilderness.filter((e) => e !== null && !o.has(e)).length, h = e.match.setup.deck.drawPile.length + e.match.setup.deck.discard.length, g = (n) => {
		let r = l, a = [];
		for (let o of n) {
			l = r;
			let n = kn(e.match, t.owner, {
				kind: "cardEffect",
				card: o,
				activation: "recharge"
			}) ?? [];
			for (let e of n) e.kind === "resources" && f(e), e.kind === "fixedResources" && d([{
				resource: e.resource,
				amount: e.amount
			}]), e.kind === "chooseGain" && e.gain.kind === "resource" && d([{
				resource: e.gain.resource,
				amount: e.maximum
			}]), e.kind === "chooseHatchOrFlip" && i.eggs.length && (d(w.map((e) => ({
				resource: e,
				amount: 1
			}))), i.eggs.some((e) => !e.hatched) && d(w.map((e) => ({
				resource: e,
				amount: 1
			}))));
			a.push(...l);
		}
		l = u(a.length ? a : r);
	}, _ = () => {
		let t = l, n = [];
		for (let r of e.match.setup.habitatSupply.display) {
			let s = kt.find((e) => e.id === r);
			s && (l = t, s.special === "takeWildernessAndResource" && d(e.match.setup.wilderness.flatMap((e) => {
				let t = e === null || o.has(e) ? void 0 : U.get(e);
				return t ? [{
					resource: t.habitat,
					amount: 1
				}] : [];
			}), !1, !0, !0), s.special === "discardForHabitatResources" && d(i.hand.filter((e) => !o.has(e)).flatMap((e) => {
				let t = U.get(e);
				return t ? [{
					resource: t.habitat,
					amount: 2
				}] : [];
			}), !0), s.special === "activateRechargeCard" && g(a.reserve.filter((e) => e.type === "recharge").map((e) => e.id)), n.push(...l));
		}
		l = u(n.length ? n : t);
	}, v = [...t.tasks];
	for (let n = 0; v.length && n < 100; n++) {
		let n = v.shift();
		if (n.kind === "projectionAlternative") {
			l = u([...l, ...n.projections]);
			continue;
		}
		if (n.kind === "payCard" && r.some((e) => e.task === n)) break;
		if (n.kind === "fixedResources" && d([{
			resource: n.resource,
			amount: n.amount
		}]), n.kind === "chooseGain" && n.gain.kind === "resource" && d([{
			resource: n.gain.resource,
			amount: n.maximum
		}]), n.kind === "resources" && f(n), n.kind === "chooseRecharge" && g(n.cards), n.kind === "chooseHatchOrFlip" && i.eggs.length && (d(w.map((e) => ({
			resource: e,
			amount: 1
		}))), i.eggs.some((e) => !e.hatched) && d(w.map((e) => ({
			resource: e,
			amount: 1
		})))), n.kind === "chooseParts" && n.parts.includes("resource") && d(w.map((e) => ({
			resource: e,
			amount: 1
		}))), n.kind === "chooseParts" && n.parts.includes("drawTwo") && h && p(Math.min(2, h), !1, !0), n.kind === "chooseDrawCount" && h && p(Math.min(n.maximum, h), !1, !0), n.kind === "draw" && h && p(Math.min(n.remaining, h), !1, !0), n.kind === "chooseParts" && n.parts.includes("hatchResource") && i.eggs.some((e) => !e.hatched) && d(w.map((e) => ({
			resource: e,
			amount: 1
		}))), n.kind === "chooseParts" && n.parts.includes("discardHabitat") && d(i.hand.filter((e) => !o.has(e)).flatMap((e) => {
			let t = U.get(e);
			return t ? [{
				resource: t.habitat,
				amount: 1
			}] : [];
		}), !0), (n.kind === "chooseParts" && n.parts.includes("supplySpecial") || n.kind === "captainMarie") && _(), n.kind === "reactionOrder" && v.unshift(...n.reactions.map((e) => ({
			kind: "reaction",
			reaction: e
		}))), n.kind === "activationOrder" && v.unshift(...n.tasks), n.kind === "reaction") {
			let e = n.reaction;
			if (e.kind === "trigger" && e.ability.kind === "fixedResource" && d([{
				resource: e.ability.resource,
				amount: 1
			}]), e.kind === "trigger" && e.ability.kind === "chooseResource" && d(w.map((e) => ({
				resource: e,
				amount: 1
			}))), e.kind === "reward" && e.reward.kind === "resources") for (let t = 0; t < e.reward.amount; t++) d(w.map((e) => ({
				resource: e,
				amount: 1
			})));
		}
		if (n.kind === "afterDraw" && (n.after === "habitatResource" || n.after === "chooseTwo")) {
			let e = U.get(n.card);
			e && d([{
				resource: e.habitat,
				amount: 1
			}]);
		}
		if (n.kind === "drawRewards" && n.options.includes("resource")) {
			let e = U.get(n.card);
			e && d([{
				resource: e.habitat,
				amount: 1
			}]);
		}
		if (n.kind === "lookChoice" && n.after === "habitatResource" && d(n.cards.flatMap((e) => {
			let t = U.get(e);
			return t ? [{
				resource: t.habitat,
				amount: 1
			}] : [];
		}), !1, !0, !0), (n.kind === "chooseLook" || n.kind === "look") && h && p(1, !1, !0), n.kind === "lookChoice" && n.after !== "habitatResource" && n.cards.length && p(1, !1, !0), n.kind === "flipEggs" && n.after && i.eggs.length && (n.mode === "flip" || i.eggs.some((e) => !e.hatched))) {
			let e = n.after === "twoResources" || n.after === "mixedResources" ? 2 : +(n.after === "oneResource" || n.after === "oneResourceAdvance");
			e && d(w.map((t) => ({
				resource: t,
				amount: e
			})));
		}
		if (n.kind === "specialEffect" && v.unshift(...An(e.match, t.owner, n.effect, n.habitat) ?? []), n.kind === "chooseMapSpecial" && e.match.setup.board.some((e) => e.terrain === "habitat" && e.habitat === n.habitat && e.special === "gainHabitatResource") && d([{
			resource: n.habitat,
			amount: 1
		}]), n.kind === "cardEffect") {
			let r = kn(e.match, t.owner, n);
			r && v.unshift(...r, {
				kind: "projectionAlternative",
				projections: l
			});
		}
		if (n.kind === "wilderness" && (n.after === "oneResource" || n.after === "twoResources") && d(e.match.setup.wilderness.flatMap((e) => {
			let t = e === null || o.has(e) ? void 0 : U.get(e);
			return t ? [{
				resource: t.habitat,
				amount: n.after === "twoResources" ? 2 : 1
			}] : [];
		}), !1, !0, !0), n.kind === "wilderness" && !n.after && m && p(Math.min(n.remaining, m), !1, !0), n.kind === "discard" && n.after === "twoWilderness" && p(Math.min(2, m), !0, n.optional), n.kind === "discardConfirm" && n.origin.after === "twoWilderness" && p(Math.min(2, m), !0, !1), n.kind === "discard" && [
			"none",
			"twoPoints",
			"twoEggs",
			"speciesPoints"
		].includes(n.after) && p(0, !0, n.optional), n.kind === "discardConfirm" && [
			"none",
			"twoPoints",
			"twoEggs",
			"speciesPoints"
		].includes(n.origin.after) && p(0, !0, !1), n.kind === "discard" && [
			"twoResources",
			"habitatResource",
			"habitatAdvance",
			"beastReward"
		].includes(n.after)) {
			let e = i.hand.filter((e) => e !== n.excluded && !o.has(e));
			d(n.after === "beastReward" && e.length ? w.map((e) => ({
				resource: e,
				amount: 1
			})) : e.flatMap((e) => {
				let t = U.get(e);
				return t ? [{
					resource: t.habitat,
					amount: n.after === "twoResources" ? 2 : 1
				}] : [];
			}), !0, n.optional);
		}
		if (n.kind === "discardConfirm" && [
			"twoResources",
			"habitatResource",
			"habitatAdvance",
			"beastReward"
		].includes(n.origin.after)) {
			let e = U.get(n.card);
			e && d(n.origin.after === "beastReward" ? w.map((e) => ({
				resource: e,
				amount: 1
			})) : [{
				resource: e.habitat,
				amount: n.origin.after === "twoResources" ? 2 : 1
			}], !0, !1);
		}
	}
	return l.some((t) => c(0, t.resources, t.discards, e.match.nextCardDiscount));
}
//#endregion
//#region src/game/gameplay.ts
function qn(e, t, n = !1, r = "standard", i = !1) {
	return Xn(Yn({
		match: Ht(e, t, i),
		resolution: null,
		endChoices: {},
		solo: null,
		soloChoices: []
	}, e.length, i), e, n, r);
}
function Jn(e, t, n, r = !1, i = "standard", a = !1) {
	let { match: o, tingent: s } = pn(e, t, n, a);
	return Xn(Yn({
		match: o,
		resolution: null,
		endChoices: {},
		solo: s,
		soloChoices: []
	}, 1, a), [e], r, i);
}
function Yn(e, t, n) {
	if (!n) return e;
	let r = ye(t, e.match.setup.seed, e.match.setup.cursor);
	return {
		...e,
		match: {
			...e.match,
			beasts: r.state,
			setup: {
				...e.match.setup,
				cursor: r.cursor
			}
		}
	};
}
function Xn(e, t, n, r) {
	if (!n) return e;
	let i = Ie(t, e.match.setup.seed, e.match.setup.cursor, r);
	return {
		...e,
		match: {
			...e.match,
			setup: {
				...e.match.setup,
				cursor: i.cursor
			}
		},
		explorerPack: {
			draft: i,
			nextSetup: 0,
			setupComplete: !1,
			used: []
		}
	};
}
function Zn(e, t) {
	return {
		...e,
		setup: {
			...e.setup,
			players: e.setup.players.map((e) => e.rid === "$tingent" ? {
				...e,
				eggs: t.eggs.map((e) => ({
					species: e,
					hatched: !1
				}))
			} : e)
		}
	};
}
function Qn(e) {
	let t = e, n = t.explorerPack;
	if (!n || n.setupComplete || n.draft.phase !== "ready" || !t.match.setup.players.every((e) => e.drafted)) return t;
	for (; n.nextSetup < n.draft.players.length;) {
		let e = n.draft.players[n.nextSetup], r = [];
		e.replacementBonus && r.push({
			kind: "reaction",
			reaction: {
				kind: "reward",
				reward: {
					kind: "points",
					amount: e.replacementBonus
				}
			}
		}), e.selected === 4 && r.push({
			kind: "wilderness",
			remaining: 2
		}, { kind: "refillWilderness" }), e.selected === 8 && r.push({ kind: "unlockCaptain" }), n = {
			...n,
			nextSetup: n.nextSetup + 1,
			used: e.selected === 4 || e.selected === 8 ? [...n.used, e.owner] : n.used
		}, t = {
			...t,
			explorerPack: n
		};
		let i = $n(Fn(t.match, {
			owner: e.owner,
			tasks: r
		}, !0), t);
		if (!i) return null;
		if (t = i, t.resolution) return t;
	}
	return {
		...t,
		explorerPack: {
			...n,
			setupComplete: !0
		},
		match: {
			...t.match,
			phase: "turn",
			activePlayer: t.match.setup.players[0].rid
		}
	};
}
function $n(e, t) {
	return e.status === "invalid" ? null : {
		...t,
		match: e.state,
		resolution: e.status === "ready" ? null : e.resolution
	};
}
function er(e, t, n, r, i) {
	if (r && r.owner !== t) return null;
	let a = {
		owner: t,
		tasks: [...n, ...r?.tasks ?? []]
	};
	return e !== i.match && a.tasks.length ? {
		...i,
		match: e,
		resolution: {
			...a,
			pendingBeat: !0
		}
	} : $n(Fn(e, a, !0), i);
}
function tr(e) {
	if (e.resolution?.pendingBeat) {
		let t = $n(Fn(e.match, e.resolution, !0), e);
		return t && !t.resolution && t.match.phase === "draft" ? Qn(t) : t;
	}
	if (e.soloPending && e.solo) {
		let t = Gn(e.match, e.solo, void 0, !0);
		return t.status === "invalid" ? null : {
			...e,
			match: Zn(t.match, t.tingent),
			solo: t.tingent,
			soloPending: t.status === "beat",
			soloChoices: t.status === "choice" ? t.choices : []
		};
	}
	return null;
}
function nr(e, t, n) {
	if (e.resolution?.pendingBeat || e.soloPending) return null;
	let r = e.match, i = e.explorerPack;
	if (r.phase === "draft" && i && !i.setupComplete) {
		if (n.kind === "explorerCard") {
			let a = Le({
				...i.draft,
				cursor: r.setup.cursor
			}, t, n.card);
			return a ? {
				...e,
				match: {
					...r,
					setup: {
						...r.setup,
						cursor: a.cursor
					}
				},
				explorerPack: {
					...i,
					draft: a
				}
			} : null;
		}
		if (n.kind === "explorerPayment") {
			let a = r.setup.players.find((e) => e.rid === t);
			if (!a?.drafted || e.resolution) return null;
			let o = Re(i.draft, t, {
				resources: a.resources,
				payment: n.payment
			});
			return o ? Qn({
				...e,
				match: {
					...r,
					setup: {
						...r.setup,
						players: r.setup.players.map((e) => e.rid === t ? {
							...e,
							resources: o.resources
						} : e)
					}
				},
				explorerPack: {
					...i,
					draft: o.draft
				}
			}) : null;
		}
		if (n.kind === "choose" && e.resolution?.owner === t) {
			let t = $n(In(r, e.resolution, n.choice, !0), e);
			return t && !t.resolution ? Qn(t) : t;
		}
	}
	if (n.kind === "draft") {
		if (e.resolution || i?.draft.phase === "selecting" && i.draft.mode !== "simultaneous") return null;
		let a = r;
		if (e.solo && n.selection.captain === "morgane" && !r.soloCaptainOptions) {
			let e = M(Dt.filter((e) => e.id !== "morgane").map((e) => e.id), r.setup.seed, r.setup.cursor);
			a = {
				...r,
				soloCaptainOptions: e.items.slice(0, 2),
				setup: {
					...r.setup,
					cursor: e.cursor
				}
			};
		}
		let o = Ut(a, t, n.selection);
		if (!o) return null;
		let s = i && !i.setupComplete;
		return Qn({
			...e,
			match: s ? {
				...o,
				phase: "draft",
				activePlayer: null
			} : o
		});
	}
	if (r.phase === "endGame" && n.kind === "scoreCopy") {
		let r = mn(e);
		if (r.status !== "choice" || r.owner !== t || n.target !== null && !r.targets.includes(n.target)) return null;
		let i = {
			...e.endChoices,
			[t]: n.target
		};
		return mn({
			...e,
			endChoices: i
		}).status === "invalid" ? null : {
			...e,
			endChoices: i
		};
	}
	if (n.kind === "soloChoose" && e.solo && r.phase === "turn" && r.activePlayer === "$tingent" && r.players.some((e) => e.rid === t && t !== "$tingent")) {
		let t = Gn(r, e.solo, n.choice, !0);
		return t.status === "invalid" ? null : {
			...e,
			match: Zn(t.match, t.tingent),
			solo: t.tingent,
			soloPending: t.status === "beat",
			soloChoices: t.status === "choice" ? t.choices : []
		};
	}
	if (r.phase !== "turn" || r.activePlayer !== t) return null;
	if (n.kind === "explorerPower") {
		let a = i?.setupComplete && i.draft.players.find((e) => e.owner === t)?.selected;
		if (!i || !a || i.used.includes(t)) return null;
		let o = ze(r, t, a, n.choice);
		return o ? er(o.state, t, o.tasks, e.resolution, {
			...e,
			explorerPack: {
				...i,
				used: [...i.used, t]
			}
		}) : null;
	}
	if (n.kind === "beastPower") {
		let i = r.beasts, a = i?.owned[t], o = r.setup.players.find((e) => e.rid === t);
		if (!i || !a?.awake || a.energy < 1 || a.usedThisTurn || !o) return null;
		let s, c = o.nets;
		if (a.id === 1 && (n.mode === "wilderness" || n.mode === "look")) {
			let i = e.resolution?.tasks.flatMap((e) => e.kind === "payCard" ? [e.card] : []) ?? [];
			if (c < 1 || n.mode === "wilderness" && Nn(r, t, {
				kind: "playSelection",
				sources: "wilderness",
				filter: "any",
				free: !0,
				optional: !1
			}, i).length === 0 || n.mode === "look" && r.setup.deck.drawPile.length + r.setup.deck.discard.length === 0) return null;
			c--, s = n.mode === "wilderness" ? [{
				kind: "playSelection",
				sources: "wilderness",
				filter: "any",
				free: !0,
				optional: !1
			}] : [{
				kind: "look",
				count: 4,
				after: "freePlay"
			}];
		} else if (a.id === 2 && n.mode === "discard" && o.hand.length > 0) s = [{
			kind: "discard",
			remaining: Math.min(3, o.hand.length),
			optional: !0,
			after: "beastReward"
		}];
		else if (a.id === 2 && n.mode === "draw" && o.hand.length < 3 && r.setup.deck.drawPile.length + r.setup.deck.discard.length > 0) s = [{
			kind: "draw",
			remaining: 3 - o.hand.length,
			after: "beastReward"
		}];
		else return null;
		return er({
			...r,
			beasts: {
				...i,
				owned: {
					...i.owned,
					[t]: {
						...a,
						energy: a.energy - 1,
						usedThisTurn: !0
					}
				}
			},
			setup: {
				...r.setup,
				players: r.setup.players.map((e) => e.rid === t ? {
					...e,
					nets: c
				} : e)
			}
		}, t, s, e.resolution, e);
	}
	if (n.kind === "captainPower") {
		let i = r.setup.players.find((e) => e.rid === t), a = r.players.find((e) => e.rid === t);
		if (!i || !a?.captainUnlocked) return null;
		let o = i.captain;
		if (i.captain === "morgane") {
			let e = r.explorers.find((e) => e.owner === t && e.piece === "captain");
			if (!e || !n.copyCaptain || !yn(r, t, e.cells).some((e) => e.captain === n.copyCaptain)) return null;
			o = n.copyCaptain;
		} else if (n.copyCaptain) return null;
		let s, c = [], l = r;
		if (o === "ashe" && (n.mode === "takeDiscard" || n.mode === "takeDiscardResource")) {
			s = n.mode === "takeDiscard" ? 1 : 2;
			let e = r.setup.deck.discard.at(-1), i = e === void 0 ? void 0 : U.get(e);
			if (!i || a.captainEnergy < s) return null;
			l = {
				...r,
				setup: {
					...r.setup,
					deck: {
						...r.setup.deck,
						discard: r.setup.deck.discard.slice(0, -1)
					},
					players: r.setup.players.map((e) => e.rid === t ? {
						...e,
						hand: [...e.hand, i.id]
					} : e)
				}
			}, n.mode === "takeDiscardResource" && (c = [{
				kind: "fixedResources",
				resource: i.habitat,
				amount: 1
			}]);
		} else if (o === "nathaniel" && n.mode === "resource") {
			if (s = 1, a.captainEnergy < s) return null;
			c = [{
				kind: "resources",
				remaining: 1
			}];
		} else if (o === "nathaniel" && n.mode === "play") {
			s = 3;
			let n = e.resolution?.tasks.flatMap((e) => e.kind === "payCard" ? [e.card] : []) ?? [];
			if (a.captainEnergy < s || !Nn(r, t, {
				kind: "playSelection",
				sources: "hand",
				filter: "any",
				free: !0,
				optional: !1
			}, n).length) return null;
			c = [{
				kind: "playSelection",
				sources: "hand",
				filter: "any",
				free: !0,
				optional: !1
			}];
		} else return null;
		return l = {
			...l,
			players: l.players.map((e) => e.rid === t ? {
				...e,
				captainEnergy: e.captainEnergy - s
			} : e)
		}, er(l, t, c, e.resolution, e);
	}
	if (n.kind === "choose") return e.resolution ? $n(In(r, e.resolution, n.choice, !0), e) : null;
	if (n.kind === "finishTurn") {
		if (e.resolution) return null;
		let n = qt(r, t);
		if (!n) return null;
		if (e.solo && n.activePlayer === "$tingent") {
			let t = Bn(n, e.solo, !0);
			return t.status === "invalid" ? null : {
				...e,
				match: Zn(t.match, t.tingent),
				resolution: null,
				solo: t.tingent,
				soloPending: t.status === "beat",
				soloChoices: t.status === "choice" ? t.choices : []
			};
		}
		return {
			...e,
			match: n,
			resolution: null
		};
	}
	if (n.kind === "net") {
		let i = r.setup.players.find((e) => e.rid === t);
		if (!i) return null;
		let a = ot({
			owner: t,
			nets: i.nets,
			board: r.setup.board,
			boardEggs: r.setup.boardEggs,
			explorers: r.explorers,
			usedSpecials: r.usedNetSpecials,
			target: n.target
		});
		if (!a) return null;
		let o = {
			...r,
			usedNetSpecials: a.usedSpecials,
			setup: {
				...r.setup,
				boardEggs: a.boardEggs,
				players: r.setup.players.map((e) => e.rid === t ? {
					...e,
					nets: a.nets
				} : e)
			}
		}, s;
		if (a.target.kind === "egg") {
			let e = $t(o, t, {
				kind: "collected",
				species: a.target.species
			});
			if (!e) return null;
			o = e.state, s = K(e.reactions, !0);
		} else {
			if (!a.target.cell.special) return null;
			s = [{
				kind: "specialEffect",
				effect: a.target.cell.special,
				habitat: a.target.cell.habitat
			}];
		}
		return er(o, t, s, e.resolution, e);
	}
	if (n.kind === "energy") {
		let i = r.players.find((e) => e.rid === t), a = U.get(n.card);
		return !i || !a || a.type !== "energy" || a.effect.kind === "energyPlayInsteadOfDiscard" || !i.energy.some((e) => e.card === n.card && e.energy > 0) || r.usedEnergy.includes(n.card) ? null : er(r, t, [{
			kind: "cardEffect",
			card: n.card,
			activation: "energy"
		}], e.resolution, e);
	}
	if (e.resolution || r.basicAction) return null;
	if (n.kind === "beast") {
		let i = r.setup.players.find((e) => e.rid === t);
		if (!i || !r.beasts || r.beasts.owned[t] || !r.beasts.supply.includes(n.beast) || !be(i.eggs, n.eggs)) return null;
		let a = Wt(r, t, "beast");
		return a ? er(a, t, [
			{
				kind: "hatchSelected",
				indices: n.eggs
			},
			{
				kind: "claimBeast",
				beast: n.beast
			},
			{ kind: "unlockCaptain" },
			{ kind: "finishBasic" }
		], null, e) : null;
	}
	if (n.kind === "explore") {
		let i = r.setup.players.find((e) => e.rid === t), a = r.players.find((e) => e.rid === t);
		if (!i?.captain || !a) return null;
		let o = !!n.copyHelenaOwner;
		if (o && (i.captain !== "morgane" || n.piece !== "captain" || !a.captainUnlocked || !yn(r, t, n.cells).some((e) => e.owner === n.copyHelenaOwner && e.captain === "helena"))) return null;
		let s = je({
			owner: t,
			piece: n.piece,
			cells: n.cells,
			payment: n.payment,
			captain: o ? "helena" : i.captain,
			captainUnlocked: a.captainUnlocked,
			resources: i.resources,
			board: r.setup.board,
			boardEggs: r.setup.boardEggs,
			explorers: r.explorers
		}), c = Wt(r, t, "explore");
		if (!s || !c) return null;
		let l = n.piece === "captain" && a.captainUnlocked && (i.captain === "ashe" || i.captain === "nathaniel");
		return er({
			...c,
			explorers: [...c.explorers, s.action.explorer],
			players: l ? c.players.map((e) => e.rid === t ? {
				...e,
				captainEnergy: e.captainEnergy + 1
			} : e) : c.players,
			setup: {
				...c.setup,
				boardEggs: s.boardEggs,
				players: c.setup.players.map((e) => e.rid === t ? {
					...e,
					resources: s.resources
				} : e)
			}
		}, t, [{
			kind: "explorer",
			action: s.action,
			captainUsed: l || o,
			paidMountain: n.payment !== null
		}, { kind: "finishBasic" }], null, e);
	}
	if (n.kind === "playCards") {
		if (Nn(r, t, {
			kind: "playSelection",
			sources: "hand",
			filter: "any",
			free: !1,
			optional: !1
		}).length === 0) return null;
		let n = Wt(r, t, "playCards");
		return n ? er(n, t, [{
			kind: "basicPlay",
			remaining: 2,
			first: !0
		}, { kind: "finishBasic" }], null, e) : null;
	}
	if (n.kind === "achievement") {
		let i = r.setup.players.find((e) => e.rid === t), a = r.players.find((e) => e.rid === t);
		if (!i || !a || n.advanceBeast && !r.beasts?.owned[t]) return null;
		let o = he({
			owner: t,
			achievements: r.setup.achievements,
			claims: r.claims,
			playerCount: r.players.length,
			achievement: n.achievement,
			slot: n.slot,
			marker: n.marker,
			useMarkerReward: n.useMarkerReward,
			advanceBeast: n.advanceBeast,
			selection: n.selection,
			reserve: {
				cards: a.reserve,
				eggs: i.eggs,
				extraSpecies: ve(r.beasts, t)
			}
		}), s = Wt(r, t, "achievement");
		if (!o || !s) return null;
		let c = {
			...s,
			claims: [...s.claims, {
				...o.claim,
				usedMarkerReward: !1
			}]
		}, l = r.setup.achievements.find((e) => e.id === n.achievement)?.kind === "main" ? Ce(r.beasts?.owned[t], a.reserve) : 0;
		return er(c, t, [...ge(o.steps, o.claim.marker, o.claim.usedMarkerReward, l), { kind: "finishBasic" }], null, e);
	}
	if (n.kind === "recharge") {
		let n = r.beasts?.owned[t], i = n?.awake && n.id === 7, a = hn(t, r.explorers, r.timePosition, r.players.length, r.setup.timeTokens, i ? 2 : 3), o = Wt(r, t, "recharge");
		if (!a || !o) return null;
		let s = {
			...o,
			explorers: a.explorers,
			timePosition: a.position,
			revealedTimeTokens: a.revealed ? [...o.revealedTimeTokens, a.revealed] : o.revealedTimeTokens,
			setup: {
				...o.setup,
				timeTokens: a.timeTokens
			}
		}, c = [];
		a.revealed && c.push({
			kind: "timeEggs",
			symbol: a.revealed.symbol
		});
		for (let e of a.effects) e === "gainNet" && c.push({
			kind: "reaction",
			reaction: {
				kind: "reward",
				reward: {
					kind: "net",
					amount: 1
				}
			}
		}), e === "sweepAll" && c.push({ kind: "sweepAll" }), e === "removeTrophy" && c.push({ kind: "removeTrophy" });
		return c.push({ kind: "discardToFive" }, {
			kind: "activateAllRecharge",
			duringRecharge: !0
		}, { kind: "finishBasic" }), er(s, t, c, null, e);
	}
	return null;
}
function q(e, t, n) {
	let r = nr(e, t, n);
	return r && Kn(r) ? r : null;
}
//#endregion
//#region src/game/setup-view.ts
function rr(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			players: e.players.map((e) => ({
				rid: e.rid,
				seat: e.seat,
				captain: e.captain,
				resources: e.resources,
				nets: e.nets,
				eggs: e.eggs,
				handCount: e.drafted ? e.hand.length : e.draftCards.length,
				drafted: e.drafted
			})),
			board: e.board,
			boardEggs: e.boardEggs,
			eggBagCount: e.eggSupply.bag.length,
			eggStock: e.eggSupply.stock,
			habitatDisplay: e.habitatSupply.display,
			habitatPileCount: e.habitatSupply.drawPile.length,
			deckCount: e.deck.drawPile.length,
			discard: e.deck.discard,
			wilderness: e.wilderness,
			achievements: e.achievements,
			timeTokenPositions: e.timeTokens.map((e) => e.position),
			initialSymbols: e.initialSymbols,
			trophies: e.trophies
		},
		private: n ? {
			captainOptions: n.captainOptions,
			draftCards: n.draftCards,
			hand: n.hand
		} : null
	};
}
//#endregion
//#region src/game/match-view.ts
function ir(e, t) {
	let n = rr(e.setup, t);
	return {
		public: {
			...n.public,
			players: n.public.players.map((t) => {
				let n = e.players.find((e) => e.rid === t.rid);
				return {
					...t,
					reserve: n.reserve,
					energy: n.energy,
					points: n.points,
					trophies: n.trophies,
					captainUnlocked: n.captainUnlocked,
					captainEnergy: n.captainEnergy
				};
			}),
			explorers: e.explorers,
			claims: e.claims,
			phase: e.phase,
			activePlayer: e.activePlayer,
			basicAction: e.basicAction,
			usedEnergy: e.usedEnergy,
			usedNetSpecials: e.usedNetSpecials,
			finalTurns: e.finalTurns,
			timePosition: e.timePosition,
			revealedTimeTokens: e.revealedTimeTokens,
			beasts: e.beasts ? {
				supply: e.beasts.supply,
				players: Object.entries(e.beasts.owned).map(([e, t]) => ({
					owner: e,
					...t
				}))
			} : null,
			soloCaptainOptions: e.soloCaptainOptions ?? []
		},
		private: n.private
	};
}
//#endregion
//#region src/game/resolution-view.ts
function ar(e, t) {
	return !e || e.tasks.length === 0 ? {
		public: null,
		private: null
	} : {
		public: {
			owner: e.owner,
			waiting: e.tasks[0].kind
		},
		private: t === e.owner && !e.pendingBeat ? { task: e.tasks[0] } : null
	};
}
//#endregion
//#region src/game/gameplay-view.ts
function or(e, t) {
	let n = ir(e.match, t), r = ar(e.resolution, t), i = r.private?.task ?? null, a = e.resolution?.tasks.flatMap((e) => e.kind === "payCard" ? [e.card] : []) ?? [], o = e.match.phase === "endGame" ? mn(e) : null, s = e.explorerPack, c = s?.draft.players.find((e) => e.owner === t), l = e.soloChoices[0]?.kind === "placement" ? e.solo?.steps[0] : void 0, u = s?.draft.mode === "reverse" ? [...s.draft.players].reverse().find((e) => e.selected === null)?.owner : t, d = [];
	if (i?.kind === "payCard") {
		let n = U.get(i.card), r = e.match.setup.players.find((e) => e.rid === t), a = e.match.players.find((e) => e.rid === t);
		if (n && r && a) {
			let o = wn(n), s = i.free || n.effect.kind === "awakeFreeOtherwiseAdvance" && e.match.beasts?.owned[t]?.awake ? w.reduce((e, t) => e + o[t], 0) : Tn(n, a.reserve) + e.match.nextCardDiscount + i.discountDiscards + Se(e.match.beasts?.owned[t], Dn(n));
			for (let n = 0; n <= Math.min(o.fruit, r.resources.fruit); n++) for (let i = 0; i <= Math.min(o.coral, r.resources.coral); i++) for (let a = 0; a <= Math.min(o.flower, r.resources.flower); a++) for (let c = 0; c <= Math.min(o.mushroom, r.resources.mushroom); c++) {
				let l = {
					fruit: n,
					coral: i,
					flower: a,
					mushroom: c
				};
				Cn(o, r.resources, s, l) && q(e, t, {
					kind: "choose",
					choice: {
						kind: "payment",
						payment: l
					}
				}) && d.push(l);
			}
		}
	}
	return {
		public: {
			...n.public,
			resolution: r.public,
			final: o?.status === "ready" ? o.players : null,
			finalChoice: o?.status === "choice" ? {
				owner: o.owner,
				targets: o.targets
			} : null,
			solo: e.solo ? {
				difficulty: e.solo.difficulty,
				position: e.solo.position,
				brown: e.solo.brown,
				targets: e.solo.targets,
				visibleCards: e.solo.visibleCards,
				hiddenCount: e.solo.hiddenCards.length,
				eggs: e.solo.eggs,
				points: e.solo.points,
				trophies: e.solo.trophies,
				pendingPlacement: l?.kind === "place" ? {
					piece: l.piece,
					habitat: l.habitat
				} : null
			} : null,
			explorerPack: s ? {
				phase: s.draft.phase,
				mode: s.draft.mode,
				setupComplete: s.setupComplete,
				players: s.draft.players.map((e) => ({
					owner: e.owner,
					selected: s.draft.phase === "selecting" ? null : e.selected,
					paid: e.paid,
					used: s.used.includes(e.owner)
				}))
			} : null
		},
		private: {
			captainOptions: n.private?.captainOptions ?? [],
			draftCards: n.private?.draftCards ?? [],
			hand: n.private?.hand ?? [],
			task: i,
			playOptions: i?.kind === "playSelection" ? Nn(e.match, t, i, a) : [],
			discardOptions: i?.kind === "discard" ? (n.private?.hand ?? []).filter((n) => n !== i.excluded && !a.includes(n) && q(e, t, {
				kind: "choose",
				choice: {
					kind: "discard",
					card: n
				}
			})) : [],
			discardConfirmOptions: i?.kind === "discardConfirm" ? [null, ...i.candidates].filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "discardConfirm",
					replacement: n
				}
			})) : [],
			wildernessOptions: i?.kind === "wilderness" ? e.match.setup.wilderness.flatMap((n, r) => n !== null && q(e, t, {
				kind: "choose",
				choice: {
					kind: "wilderness",
					slot: r
				}
			}) ? [r] : []) : [],
			canSkip: !!i && !!q(e, t, {
				kind: "choose",
				choice: { kind: "skip" }
			}),
			canLook: i?.kind === "chooseLook" && !!q(e, t, {
				kind: "choose",
				choice: { kind: "lookNow" }
			}),
			rechargeOptions: i?.kind === "chooseRecharge" ? i.cards.filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "recharge",
					card: n
				}
			})) : [],
			hatchOrFlipOptions: i?.kind === "chooseHatchOrFlip" ? ["hatch", "flip"].filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "hatchOrFlip",
					mode: n
				}
			})) : [],
			habitatSpecialOptions: i?.kind === "captainMarie" ? e.match.setup.habitatSupply.display.flatMap((n, r) => n && q(e, t, {
				kind: "choose",
				choice: {
					kind: "marie",
					slot: r
				}
			}) ? [r] : []) : [],
			canDiscount: i?.kind === "payCard" && !i.free && (() => {
				let e = U.get(i.card);
				return !!e && (e.effect.kind === "discardDiscountAndScore" || e.effect.kind === "discardDiscountAndNet") && i.discountDiscards < e.effect.maximum && (n.private?.hand ?? []).some((e) => !a.includes(e));
			})(),
			mapSpecialOptions: i?.kind === "chooseMapSpecial" ? e.match.setup.board.filter((n) => n.terrain === "habitat" && n.habitat === i.habitat && n.special && q(e, t, {
				kind: "choose",
				choice: {
					kind: "mapSpecial",
					position: n
				}
			})).map(({ row: e, column: t }) => ({
				row: e,
				column: t
			})) : [],
			effectOptions: i?.kind === "cardEffect" ? [!0, !1].filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "cardEffect",
					use: n
				}
			})) : [],
			gainCountOptions: i?.kind === "chooseGain" ? Array.from({ length: i.maximum + 1 }, (e, t) => t).filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "gainCount",
					count: n
				}
			})) : [],
			drawCountOptions: i?.kind === "chooseDrawCount" ? Array.from({ length: i.maximum + 1 }, (e, t) => t).filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "drawCount",
					count: n
				}
			})) : [],
			effectPartsOptions: i?.kind === "chooseParts" ? Array.from({ length: 2 ** i.parts.length }, (e, t) => i.parts.flatMap((e, n) => t & 1 << n ? [n] : [])).filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "effectParts",
					indices: n
				}
			})) : [],
			resourceOptions: i?.kind === "resources" ? Mn(e.match, t, i).filter((n) => q(e, t, {
				kind: "choose",
				choice: {
					kind: "resource",
					resource: n
				}
			})) : [],
			paymentOptions: d,
			soloChoices: e.match.players.some((e) => e.rid === t && e.rid !== "$tingent") ? e.soloChoices : [],
			explorerPack: c ? {
				candidates: c.candidates,
				selected: c.selected,
				paid: c.paid,
				canSelect: s?.draft.phase === "selecting" && c.selected === null && u === t
			} : null
		}
	};
}
//#endregion
//#region src/game/meta.ts
var sr = {
	id: "wondrouscreatures",
	uuid: "c09eb4cd-cca4-4e65-87f4-cd84c3645d10",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"hand-management",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.wondrouscreatures.name",
	descKey: "games.wondrouscreatures.desc",
	rulesKey: "games.wondrouscreatures.rules",
	rulesUrl: { fr: "https://steamusercontent-a.akamaihd.net/ugc/11975398495653674630/16E606F6E10097E2AF6A9A3D021BBA6AE04D8A2A/" },
	icon: "🦕",
	iconImg: "games/wondrouscreatures.webp",
	minPlayers: 1,
	maxPlayers: 4,
	accent: "#46776b",
	releasedAt: "2026-11-15T02:02:18+08:00",
	search: {
		py: "huan shou qi lv",
		init: "hsql"
	},
	hotseat: "cover"
}, J = t.int().min(1).max(140), Y = t.int().nonnegative(), X = t.int().nonnegative(), cr = t.string().min(1), Z = t.enum([
	"fruit",
	"coral",
	"flower",
	"mushroom"
]), Q = t.enum([
	"crustacean",
	"mammal",
	"bird",
	"reptile",
	"fish",
	"insect",
	"dragon"
]), lr = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3),
	t.literal(4),
	t.literal(5),
	t.literal(6),
	t.literal(7),
	t.literal(8),
	t.literal(9)
]), ur = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3),
	t.literal(4),
	t.literal(5),
	t.literal(6),
	t.literal(7)
]), dr = t.enum([
	"cabot",
	"freya",
	"haoa",
	"helena",
	"macus",
	"marie",
	"octavia",
	"samuel",
	"tingent",
	"ashe",
	"morgane",
	"nathaniel",
	"rabell"
]), fr = t.enum([
	"instant",
	"permanent",
	"energy",
	"recharge",
	"endGame"
]), pr = t.enum([
	"circle",
	"square",
	"triangle",
	"v",
	"cross"
]), mr = t.enum([
	"gainHabitatResource",
	"flipEgg",
	"sweepAndTake",
	"gainThreePoints",
	"flipUpToTwoEggs",
	"playCard",
	"discardForHabitatResources",
	"drawRandomEgg",
	"takeWildernessAndResource",
	"activateRechargeCard",
	"drawTwoCards"
]), $ = t.object({
	row: t.int(),
	column: t.int()
}), hr = t.tuple([$, $]), gr = t.object({
	fruit: Y,
	coral: Y,
	flower: Y,
	mushroom: Y
}), _r = t.object({
	species: Q,
	hatched: t.boolean()
}), vr = $.extend({ species: Q }), yr = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("resource"),
		resource: Z
	}),
	t.object({
		kind: t.literal("card"),
		slot: X,
		card: J
	}),
	t.object({ kind: t.literal("net") })
]), br = $.extend({
	terrain: t.literal("habitat"),
	habitat: t.union([Z, t.literal("net")]),
	special: mr.optional(),
	timeSymbol: pr.optional()
}), xr = t.union([$.extend({
	terrain: t.enum([
		"plain",
		"mountain",
		"lake"
	]),
	timeSymbol: pr.optional()
}), br]), Sr = t.object({
	owner: cr,
	piece: t.enum([
		"captain",
		"explorerA",
		"explorerB"
	]),
	cells: hr
}), Cr = t.object({
	id: J,
	habitat: Z,
	species: t.array(Q),
	type: fr
}), wr = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("points"),
		amount: Y
	}),
	t.object({
		kind: t.literal("resources"),
		amount: Y
	}),
	t.object({
		kind: t.literal("wildernessCards"),
		amount: Y
	}),
	t.object({
		kind: t.literal("net"),
		amount: Y
	}),
	t.object({ kind: t.literal("restoreEnergy") }),
	t.object({ kind: t.literal("activateAllRecharge") }),
	t.object({ kind: t.literal("repeatAchievementReward") }),
	t.object({ kind: t.literal("discovery") }),
	t.object({ kind: t.literal("trophy") })
]), Tr = t.discriminatedUnion("kind", [
	t.object({
		card: J,
		kind: t.literal("points"),
		amount: Y
	}),
	t.object({
		card: J,
		kind: t.literal("chooseResource")
	}),
	t.object({
		card: J,
		kind: t.literal("activateRecharge")
	}),
	t.object({
		card: J,
		kind: t.literal("fixedResource"),
		resource: Z
	})
]), Er = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("reward"),
	reward: wr
}), t.object({
	kind: t.literal("trigger"),
	ability: Tr
})]), Dr = t.discriminatedUnion("kind", [t.object({ kind: t.literal("hand") }), t.object({
	kind: t.literal("wilderness"),
	slot: X
})]), Or = t.enum([
	"none",
	"twoPoints",
	"twoResources",
	"twoEggs",
	"twoWilderness",
	"speciesPoints",
	"discount",
	"beastReward",
	"habitatAdvance",
	"habitatResource"
]), kr = t.enum([
	"supplySpecial",
	"threePoints",
	"resource",
	"drawTwo",
	"net",
	"hatchResource",
	"discardHabitat",
	"advanceBeast"
]), Ar = t.object({
	kind: t.literal("discard"),
	remaining: Y,
	optional: t.boolean(),
	after: Or,
	excluded: J.optional(),
	discountTarget: J.optional()
}), jr = t.object({
	kind: t.literal("cardEffect"),
	card: J,
	activation: t.enum([
		"instant",
		"recharge",
		"energy"
	]),
	previousInstant: J.nullable().optional()
}), Mr = t.object({
	kind: t.literal("reaction"),
	reaction: Er
}), Nr = t.union([Mr, jr]), Pr = t.enum([
	"any",
	"recharge",
	"endGame",
	"small"
]), Fr = t.enum([
	"none",
	"habitatResource",
	"habitatResourceDeferred",
	"speciesEgg",
	"speciesEggDeferred",
	"speciesEggOptional",
	"matchingHabitatPoints",
	"handPoints",
	"handNet",
	"chooseTwo",
	"beastReward"
]), Ir = t.enum([
	"egg",
	"resource",
	"points"
]), Lr = t.discriminatedUnion("kind", [
	Mr,
	t.object({
		kind: t.literal("reactionOrder"),
		reactions: t.array(Er)
	}),
	t.object({
		kind: t.literal("activationOrder"),
		tasks: t.array(Nr)
	}),
	t.object({
		kind: t.literal("chooseParts"),
		parts: t.array(kr)
	}),
	t.object({
		kind: t.literal("resources"),
		remaining: Y,
		same: t.boolean().optional(),
		restrict: t.enum(["least", "mostHabitat"]).optional(),
		after: t.literal("scoreResource").optional(),
		optional: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("fixedResources"),
		resource: Z,
		amount: Y
	}),
	t.object({
		kind: t.literal("wilderness"),
		remaining: Y,
		after: t.enum([
			"oneResource",
			"twoResources",
			"speciesEgg",
			"beastMatch"
		]).optional(),
		optional: t.boolean().optional()
	}),
	t.object({ kind: t.literal("takeSpecies") }),
	t.object({
		kind: t.literal("sweep"),
		thenTake: t.boolean()
	}),
	t.object({
		kind: t.literal("egg"),
		species: Q
	}),
	t.object({ kind: t.literal("eggBag") }),
	t.object({
		kind: t.literal("chooseEgg"),
		species: t.array(Q),
		count: Y.optional(),
		optional: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("chooseDrawCount"),
		maximum: Y,
		after: Fr
	}),
	t.object({
		kind: t.literal("chooseGain"),
		gain: t.discriminatedUnion("kind", [
			t.object({ kind: t.literal("points") }),
			t.object({ kind: t.literal("net") }),
			t.object({
				kind: t.literal("resource"),
				resource: Z
			}),
			t.object({
				kind: t.literal("egg"),
				species: Q
			})
		]),
		maximum: Y
	}),
	t.object({
		kind: t.literal("draw"),
		remaining: Y,
		after: Fr,
		drawn: t.array(J).optional()
	}),
	t.object({
		kind: t.literal("afterDraw"),
		card: J,
		after: Fr
	}),
	t.object({
		kind: t.literal("drawRewards"),
		card: J,
		remaining: Y,
		options: t.array(Ir)
	}),
	t.object({
		kind: t.literal("look"),
		count: Y,
		after: t.enum([
			"printedPoints",
			"habitatResource",
			"freePlay"
		])
	}),
	t.object({
		kind: t.literal("chooseLook"),
		count: Y,
		after: t.enum([
			"printedPoints",
			"habitatResource",
			"freePlay"
		])
	}),
	t.object({
		kind: t.literal("lookChoice"),
		cards: t.array(J),
		after: t.enum([
			"printedPoints",
			"habitatResource",
			"freePlay"
		])
	}),
	t.object({
		kind: t.literal("flipEggs"),
		mode: t.enum(["flip", "hatch"]),
		minimum: Y,
		maximum: Y,
		pointsPerEgg: Y.optional(),
		flatPoints: Y.optional(),
		after: t.enum([
			"anyEgg",
			"twoResources",
			"mixedResources",
			"oneResource",
			"oneResourceAdvance"
		]).optional()
	}),
	Ar,
	t.object({
		kind: t.literal("discardConfirm"),
		card: J,
		candidates: t.array(J),
		origin: Ar
	}),
	t.object({
		kind: t.literal("scoreSpecies"),
		card: J
	}),
	t.object({
		kind: t.literal("playSelection"),
		sources: t.enum([
			"hand",
			"wilderness",
			"either"
		]),
		filter: Pr,
		free: t.boolean(),
		optional: t.boolean(),
		basic: t.enum(["first", "later"]).optional()
	}),
	t.object({
		kind: t.literal("payCard"),
		card: J,
		source: Dr,
		free: t.boolean(),
		discountDiscards: Y,
		optional: t.boolean(),
		origin: t.object({
			kind: t.literal("playSelection"),
			sources: t.enum([
				"hand",
				"wilderness",
				"either"
			]),
			filter: Pr,
			free: t.boolean(),
			optional: t.boolean(),
			basic: t.enum(["first", "later"]).optional()
		}).optional()
	}),
	t.object({
		kind: t.literal("increaseDiscount"),
		card: J
	}),
	t.object({
		kind: t.literal("addSpecies"),
		card: J,
		optional: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("chooseMapSpecial"),
		habitat: Z
	}),
	t.object({
		kind: t.literal("specialEffect"),
		effect: mr,
		habitat: t.union([Z, t.literal("net")])
	}),
	t.object({
		kind: t.literal("explorer"),
		action: t.object({
			explorer: Sr,
			coveredEggs: t.array(vr),
			remainingHabitats: t.array(br)
		}),
		captainUsed: t.boolean(),
		paidMountain: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("captainFreya"),
		cells: hr
	}),
	t.object({
		kind: t.literal("captainMarie"),
		mandatory: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("captainTingent"),
		gainAllowed: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("captainRabell"),
		species: t.array(Q)
	}),
	t.object({
		kind: t.literal("captainMorgane"),
		cells: hr,
		paidMountain: t.boolean()
	}),
	t.object({
		kind: t.literal("timeEggs"),
		symbol: pr
	}),
	t.object({ kind: t.literal("discardToFive") }),
	t.object({ kind: t.literal("sweepAll") }),
	t.object({ kind: t.literal("refillWilderness") }),
	t.object({
		kind: t.literal("claimBeast"),
		beast: ur
	}),
	t.object({
		kind: t.literal("advanceBeast"),
		spaces: Y
	}),
	t.object({ kind: t.literal("removeTrophy") }),
	t.object({
		kind: t.literal("activateAllRecharge"),
		duringRecharge: t.boolean().optional()
	}),
	t.object({ kind: t.literal("activateAllRechargeTwice") }),
	t.object({
		kind: t.literal("repeatRecharge"),
		card: J
	}),
	t.object({ kind: t.literal("scoreRechargeCards") }),
	t.object({ kind: t.literal("chooseHatchOrFlip") }),
	t.object({
		kind: t.literal("hatchSelected"),
		indices: t.array(X)
	}),
	t.object({
		kind: t.literal("markAchievementReward"),
		marker: X
	}),
	t.object({ kind: t.literal("unlockCaptain") }),
	t.object({
		kind: t.literal("basicPlay"),
		remaining: Y,
		first: t.boolean()
	}),
	t.object({ kind: t.literal("finishBasic") }),
	t.object({ kind: t.literal("exchange") }),
	t.object({
		kind: t.literal("nextCardDiscount"),
		amount: Y
	}),
	t.object({
		kind: t.literal("chooseEndScore"),
		maximum: Y
	}),
	t.object({
		kind: t.literal("chooseEndCopy"),
		maximum: Y,
		targets: t.array(J)
	}),
	t.object({ kind: t.literal("chooseAchievementReward") }),
	t.object({ kind: t.literal("restoreEnergy") }),
	t.object({ kind: t.literal("discovery") }),
	t.object({
		kind: t.literal("chooseRecharge"),
		cards: t.array(J),
		all: t.boolean(),
		optional: t.boolean().optional(),
		remaining: Y.optional(),
		thenEgg: t.boolean().optional(),
		twice: t.boolean().optional()
	}),
	jr
]), Rr = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("reaction"),
		index: X
	}),
	t.object({
		kind: t.literal("activation"),
		index: X
	}),
	t.object({
		kind: t.literal("effectParts"),
		indices: t.array(X).max(8)
	}),
	t.object({
		kind: t.literal("drawCount"),
		count: Y
	}),
	t.object({
		kind: t.literal("gainCount"),
		count: Y
	}),
	t.object({
		kind: t.literal("resource"),
		resource: Z
	}),
	t.object({
		kind: t.literal("egg"),
		species: Q
	}),
	t.object({
		kind: t.literal("eggs"),
		indices: t.array(X).max(12)
	}),
	t.object({
		kind: t.literal("lookCard"),
		card: J
	}),
	t.object({ kind: t.literal("lookNow") }),
	t.object({
		kind: t.literal("drawReward"),
		reward: Ir
	}),
	t.object({
		kind: t.literal("discard"),
		card: J
	}),
	t.object({
		kind: t.literal("discardConfirm"),
		replacement: J.nullable()
	}),
	t.object({
		kind: t.literal("selectPlay"),
		card: J,
		source: Dr
	}),
	t.object({ kind: t.literal("cancelPlay") }),
	t.object({
		kind: t.literal("payment"),
		payment: gr
	}),
	t.object({ kind: t.literal("discount") }),
	t.object({
		kind: t.literal("exchange"),
		from: Z,
		to: Z,
		amount: Y
	}),
	t.object({
		kind: t.literal("mapSpecial"),
		position: $
	}),
	t.object({
		kind: t.literal("explorerEgg"),
		position: $
	}),
	t.object({
		kind: t.literal("explorerHabitat"),
		position: $,
		reward: yr
	}),
	t.object({ kind: t.literal("captain") }),
	t.object({ kind: t.literal("finishExplorer") }),
	t.object({
		kind: t.literal("freya"),
		mode: t.enum(["egg", "flip"]),
		position: $.optional()
	}),
	t.object({
		kind: t.literal("marie"),
		slot: X
	}),
	t.object({
		kind: t.literal("tingent"),
		mode: t.enum(["gain", "distribute"]),
		allocations: t.array(t.object({
			card: J,
			amount: Y
		})).max(126).optional()
	}),
	t.object({
		kind: t.literal("timeEgg"),
		position: $
	}),
	t.object({
		kind: t.literal("basicPlay"),
		play: t.boolean()
	}),
	t.object({
		kind: t.literal("endCard"),
		card: J
	}),
	t.object({
		kind: t.literal("achievementReward"),
		marker: X
	}),
	t.object({
		kind: t.literal("wilderness"),
		slot: X
	}),
	t.object({
		kind: t.literal("species"),
		species: Q
	}),
	t.object({
		kind: t.literal("sweep"),
		area: t.enum(["left", "right"])
	}),
	t.object({
		kind: t.literal("energy"),
		card: J
	}),
	t.object({
		kind: t.literal("discovery"),
		slot: X,
		position: $
	}),
	t.object({
		kind: t.literal("recharge"),
		card: J
	}),
	t.object({
		kind: t.literal("cardEffect"),
		use: t.boolean()
	}),
	t.object({ kind: t.literal("skip") }),
	t.object({
		kind: t.literal("hatchOrFlip"),
		mode: t.enum(["hatch", "flip"])
	}),
	t.object({
		kind: t.literal("captainCopy"),
		owner: cr,
		captain: dr
	})
]), zr = t.discriminatedUnion("kind", [t.object({
	kind: t.literal("placement"),
	cells: hr
}), t.object({
	kind: t.literal("timeEgg"),
	position: $
})]), Br = t.object({
	eggs: t.array(X).max(12),
	species: Q.optional(),
	habitat: Z.optional()
}), Vr = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("achievement"),
		achievement: X,
		slot: X,
		marker: X,
		useMarkerReward: t.boolean(),
		advanceBeast: t.boolean().optional(),
		selection: Br
	}),
	t.object({
		kind: t.literal("returnExplorer"),
		piece: t.enum([
			"captain",
			"explorerA",
			"explorerB"
		])
	}),
	t.object({ kind: t.literal("activate") })
]), Hr = t.object({
	soloDifficulty: t.int().min(1).max(4).default(1),
	explorerDraft: t.enum([
		"none",
		"standard",
		"simultaneous",
		"reverse"
	]).default("none"),
	beasts: t.boolean().default(!1)
}).default({
	soloDifficulty: 1,
	explorerDraft: "none",
	beasts: !1
}), Ur = t.union([t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("draft"),
		selection: t.object({
			captain: dr,
			cards: t.array(J).length(4),
			bonusResources: t.array(Z).max(3)
		})
	}),
	t.object({
		kind: t.literal("explorerCard"),
		card: lr
	}),
	t.object({
		kind: t.literal("explorerPayment"),
		payment: gr
	}),
	t.object({
		kind: t.literal("explorerPower"),
		choice: Vr
	}),
	t.object({
		kind: t.literal("beast"),
		beast: ur,
		eggs: t.array(X).length(4)
	}),
	t.object({
		kind: t.literal("beastPower"),
		mode: t.enum([
			"wilderness",
			"look",
			"discard",
			"draw"
		])
	}),
	t.object({
		kind: t.literal("captainPower"),
		mode: t.enum([
			"takeDiscard",
			"takeDiscardResource",
			"resource",
			"play"
		]),
		copyCaptain: t.enum(["ashe", "nathaniel"]).optional()
	}),
	t.object({
		kind: t.literal("explore"),
		piece: t.enum([
			"captain",
			"explorerA",
			"explorerB"
		]),
		cells: hr,
		payment: Z.nullable(),
		copyHelenaOwner: cr.optional()
	}),
	t.object({ kind: t.literal("playCards") }),
	t.object({
		kind: t.literal("achievement"),
		achievement: X,
		slot: X,
		marker: X,
		useMarkerReward: t.boolean(),
		advanceBeast: t.boolean().optional(),
		selection: Br
	}),
	t.object({ kind: t.literal("recharge") }),
	t.object({
		kind: t.literal("net"),
		target: t.object({
			kind: t.enum(["egg", "special"]),
			position: $
		})
	}),
	t.object({
		kind: t.literal("energy"),
		card: J
	}),
	t.object({
		kind: t.literal("choose"),
		choice: Rr
	}),
	t.object({ kind: t.literal("finishTurn") }),
	t.object({
		kind: t.literal("scoreCopy"),
		target: J.nullable()
	}),
	t.object({
		kind: t.literal("soloChoose"),
		choice: zr
	})
]), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), Wr = t.discriminatedUnion("kind", [
	t.object({
		id: X,
		kind: t.literal("main"),
		requirement: t.enum([
			"fourteenCards",
			"eightEggs",
			"sixHabitat",
			"tenSpecies",
			"twoTypeSets"
		])
	}),
	t.object({
		id: X,
		kind: t.literal("single"),
		species: Q
	}),
	t.object({
		id: X,
		kind: t.literal("multi"),
		species: t.tuple([Q, Q])
	})
]), Gr = t.object({
	owner: cr,
	achievement: X,
	slot: X,
	marker: X,
	points: Y,
	reward: wr,
	usedMarkerReward: t.boolean(),
	advancedBeast: t.boolean().optional()
}), Kr = t.object({
	immediate: Y,
	endGameAbilities: Y,
	beastPoints: Y,
	printedCards: Y,
	achievements: Y,
	trophies: Y,
	remaining: Y,
	total: Y
}), qr = t.object({
	rid: cr,
	rank: X,
	score: Kr,
	endCards: t.array(t.object({
		card: J,
		points: Y
	}))
}), Jr = t.object({
	players: t.array(t.object({
		rid: cr,
		seat: X,
		captain: dr.nullable(),
		resources: gr,
		nets: Y,
		eggs: t.array(_r),
		handCount: Y,
		drafted: t.boolean(),
		reserve: t.array(Cr),
		energy: t.array(t.object({
			card: J,
			energy: Y
		})),
		points: Y,
		trophies: Y,
		captainUnlocked: t.boolean(),
		captainEnergy: Y
	})),
	board: t.array(xr),
	boardEggs: t.array(vr),
	eggBagCount: Y,
	eggStock: t.record(Q, Y),
	habitatDisplay: t.tuple([
		t.string().nullable(),
		t.string().nullable(),
		t.string().nullable()
	]),
	habitatPileCount: Y,
	deckCount: Y,
	discard: t.array(J),
	wilderness: t.tuple([
		J.nullable(),
		J.nullable(),
		J.nullable(),
		J.nullable(),
		J.nullable(),
		J.nullable()
	]),
	achievements: t.array(Wr),
	timeTokenPositions: t.array(Y),
	initialSymbols: t.array(pr),
	trophies: Y,
	explorers: t.array(Sr),
	claims: t.array(Gr),
	phase: t.enum([
		"draft",
		"turn",
		"endGame"
	]),
	activePlayer: cr.nullable(),
	basicAction: t.object({
		kind: t.enum([
			"explore",
			"playCards",
			"achievement",
			"recharge",
			"beast"
		]),
		resolved: t.boolean()
	}).nullable(),
	usedEnergy: t.array(J),
	usedNetSpecials: t.array($),
	finalTurns: t.object({
		trigger: cr,
		remaining: t.array(cr)
	}).nullable(),
	timePosition: Y,
	revealedTimeTokens: t.array(t.object({
		position: Y,
		symbol: pr
	})),
	resolution: t.object({
		owner: cr,
		waiting: t.string()
	}).nullable(),
	solo: t.object({
		difficulty: t.int().min(1).max(4),
		position: Y,
		brown: t.boolean(),
		targets: t.object({
			main: X,
			single: X,
			multi: X
		}),
		visibleCards: t.array(J),
		hiddenCount: Y,
		eggs: t.array(Q),
		points: Y,
		trophies: Y,
		pendingPlacement: t.object({
			piece: t.enum(["captain", "explorer"]),
			habitat: Z
		}).nullable()
	}).nullable(),
	explorerPack: t.object({
		phase: t.enum([
			"selecting",
			"paying",
			"ready"
		]),
		mode: t.enum([
			"standard",
			"simultaneous",
			"reverse"
		]),
		setupComplete: t.boolean(),
		players: t.array(t.object({
			owner: cr,
			selected: lr.nullable(),
			paid: t.boolean(),
			used: t.boolean()
		}))
	}).nullable(),
	beasts: t.object({
		supply: t.array(ur),
		players: t.array(t.object({
			owner: cr,
			id: ur,
			progress: t.int().min(0).max(4),
			awake: t.boolean(),
			energy: Y,
			usedThisTurn: t.boolean()
		}))
	}).nullable(),
	soloCaptainOptions: t.array(dr),
	final: t.array(qr).nullable(),
	finalChoice: t.object({
		owner: cr,
		targets: t.array(J)
	}).nullable()
}), Yr = t.object({
	captainOptions: t.array(dr),
	draftCards: t.array(J),
	hand: t.array(J),
	task: Lr.nullable(),
	playOptions: t.array(t.object({
		card: J,
		source: Dr
	})),
	discardOptions: t.array(J),
	discardConfirmOptions: t.array(J.nullable()),
	wildernessOptions: t.array(X),
	canSkip: t.boolean(),
	canLook: t.boolean(),
	rechargeOptions: t.array(J),
	hatchOrFlipOptions: t.array(t.enum(["hatch", "flip"])),
	habitatSpecialOptions: t.array(X),
	canDiscount: t.boolean(),
	mapSpecialOptions: t.array($),
	effectOptions: t.array(t.boolean()),
	gainCountOptions: t.array(Y),
	drawCountOptions: t.array(Y),
	effectPartsOptions: t.array(t.array(X)),
	resourceOptions: t.array(Z),
	paymentOptions: t.array(gr),
	soloChoices: t.array(zr),
	explorerPack: t.object({
		candidates: t.array(lr),
		selected: lr.nullable(),
		paid: t.boolean(),
		canSelect: t.boolean()
	}).nullable()
});
//#endregion
//#region src/game/rules.ts
function Xr(e, t, n) {
	let r = [];
	if (n) {
		let i = e.match.setup.players.find((e) => e.rid === n)?.eggs ?? [], a = t.match.setup.players.find((e) => e.rid === n)?.eggs ?? [], o = i.flatMap((e, t) => a[t]?.species === e.species && a[t].hatched !== e.hatched ? [{
			index: t,
			species: e.species,
			hatched: a[t].hatched
		}] : []);
		o.length && r.push({
			kind: "eggFlip",
			rid: n,
			data: { eggs: o }
		});
	}
	for (let n of t.match.claims) e.match.claims.some((e) => e.achievement === n.achievement && e.slot === n.slot) || r.push({
		kind: "goalClaim",
		rid: n.owner,
		data: {
			goal: n.achievement,
			slot: n.slot
		},
		...r.length ? { with: !0 } : {}
	});
	return r;
}
function Zr(e, t, n) {
	let r = Hr.parse(e), i = r.explorerDraft !== "none", a = r.explorerDraft === "none" ? "standard" : r.explorerDraft;
	return {
		state: t.length === 1 ? Jn(t[0], n, r.soloDifficulty, i, a, r.beasts) : qn(t, n, i, a, r.beasts),
		fx: []
	};
}
function Qr(e, t, n) {
	if ("type" in t) {
		if (n.by !== "$engine") return { code: "games.wondrouscreatures.ui.invalid" };
		let t = tr(e);
		if (!t) return {
			state: e,
			fx: []
		};
		let r = e.resolution?.owner, i = r ? e.match.beasts?.owned[r] : void 0, a = r ? t.match.beasts?.owned[r] : void 0, o = Xr(e, t, r);
		return r && i && a && i.id === a.id && a.progress > i.progress && o.push({
			kind: "beastProgress",
			rid: r,
			data: {
				amount: a.progress - i.progress,
				awake: a.awake
			},
			...o.length ? { with: !0 } : {}
		}), {
			state: t,
			fx: o
		};
	}
	let r = q(e, n.by, t);
	if (!r) return { code: "games.wondrouscreatures.ui.invalid" };
	let i = t.kind === "explore" ? [{
		kind: "explorerPlace",
		rid: n.by,
		data: {
			piece: t.piece,
			cells: t.cells
		}
	}] : [];
	for (let t of Xr(e, r, n.by)) i.push({
		...t,
		...i.length ? { with: !0 } : {}
	});
	let a = e.resolution?.tasks[0];
	if (t.kind === "choose" && t.choice.kind === "payment" && a?.kind === "payCard" ? i.push({
		kind: "cardPlay",
		rid: n.by,
		data: {
			card: a.card,
			source: a.source.kind
		}
	}) : t.kind === "choose" && t.choice.kind === "discardConfirm" && t.choice.replacement !== null && a?.kind === "discardConfirm" && i.push({
		kind: "cardPlay",
		rid: n.by,
		data: {
			card: a.card,
			source: "hand"
		}
	}), t.kind === "choose" && t.choice.kind === "explorerHabitat" && a?.kind === "explorer" && t.choice.reward.kind === "card") i.push({
		kind: "takeWilderness",
		for: [n.by],
		secret: {
			card: t.choice.reward.card,
			slot: t.choice.reward.slot
		}
	});
	else if (t.kind === "choose" && t.choice.kind === "wilderness" && a?.kind === "wilderness") {
		let r = e.match.setup.wilderness[t.choice.slot];
		r != null && i.push({
			kind: "takeWilderness",
			for: [n.by],
			secret: {
				card: r,
				slot: t.choice.slot
			}
		});
	}
	let o = e.match.beasts?.owned[n.by], s = r.match.beasts?.owned[n.by];
	return o && s && o.id === s.id && s.progress > o.progress && i.push({
		kind: "beastProgress",
		rid: n.by,
		data: {
			amount: s.progress - o.progress,
			awake: s.awake
		},
		...i.length ? { with: !0 } : {}
	}), {
		state: r,
		fx: i
	};
}
function $r(e, t) {
	return or(e, t);
}
function ei(e) {
	if (e.match.phase !== "endGame") return { phase: e.match.phase };
	let t = mn(e);
	return t.status === "ready" ? {
		phase: "done",
		winner: t.players.filter((e) => e.rank === 1).map((e) => e.rid),
		ranking: t.players.map((e) => e.rid),
		scores: Object.fromEntries(t.players.map((e) => [e.rid, e.score.total]))
	} : { phase: "endGameChoice" };
}
function ti(e) {
	let t = e.resolution, n = t?.tasks[0];
	if (!t || t.pendingBeat || n?.kind !== "chooseParts" || n.parts.length !== 1 || n.parts[0] !== "advanceBeast") return;
	let r = {
		kind: "choose",
		choice: {
			kind: "effectParts",
			indices: [0]
		}
	}, i = Qr(e, r, { by: t.owner });
	return "state" in i ? {
		state: i.state,
		entry: {
			by: t.owner,
			action: r
		}
	} : null;
}
function ni(e) {
	let t = e[0];
	if (!t || t.type !== "$setup" || !Array.isArray(t.players) || !t.players.length || !t.players.every((e) => typeof e == "string") || new Set(t.players).size !== t.players.length || typeof t.seed != "number" || !Number.isFinite(t.seed)) return null;
	let n = Hr.safeParse(t.config);
	if (!n.success) return null;
	let r = Zr(n.data, t.players, t.seed).state, i = [{
		...t,
		saveVersion: "4"
	}];
	for (let n of e.slice(1)) {
		let e = n;
		if (!e || typeof e.by != "string" || e.by !== "$engine" && !t.players.includes(e.by)) return null;
		let a = Ur.safeParse(e.action);
		if (!a.success || "type" in a.data && e.by !== "$engine") return null;
		let o = Qr(r, a.data, { by: e.by });
		if (!("state" in o)) return null;
		r = o.state, i.push(n);
		let s = ti(r);
		if (s === null) return null;
		s && (r = s.state, i.push(s.entry));
	}
	return i;
}
function ri(e) {
	let t = e[0];
	if (!t || t.type !== "$setup" || !Array.isArray(t.players) || !t.players.length || !t.players.every((e) => typeof e == "string") || new Set(t.players).size !== t.players.length || typeof t.seed != "number" || !Number.isFinite(t.seed)) return null;
	let n = Hr.safeParse(t.config);
	if (!n.success) return null;
	let r = Zr(n.data, t.players, t.seed).state, i = [{
		...t,
		saveVersion: "4"
	}], a = null, o = () => {
		for (let e = 0; r.resolution?.pendingBeat || r.soloPending; e++) {
			if (e >= 300) return !1;
			let t = {
				type: "tick",
				now: 0
			}, n = Qr(r, t, { by: "$engine" });
			if (!("state" in n) || n.state === r) return !1;
			r = n.state, i.push({
				by: "$engine",
				action: t
			});
			let a = ti(r);
			if (a === null) return !1;
			a && (r = a.state, i.push(a.entry));
		}
		return !0;
	};
	for (let n of e.slice(1)) {
		let e = n;
		if (!e || typeof e.by != "string" || e.by !== "$engine" && !t.players.includes(e.by)) return null;
		let s = Ur.safeParse(e.action);
		if (!s.success || !("type" in s.data) && !o() || "type" in s.data && e.by !== "$engine") return null;
		let c = r.resolution?.tasks[0], l = Qr(r, s.data, { by: e.by });
		for (let t = 0; !("state" in l) && t < 100; t++) {
			let t = r.resolution, n = t?.tasks[0];
			if (!t || t.pendingBeat || !n) return null;
			let a = n.kind === "chooseGain" ? {
				kind: "gainCount",
				count: n.maximum
			} : n.kind === "chooseParts" ? {
				kind: "effectParts",
				indices: n.parts.map((e, t) => t)
			} : n.kind === "chooseLook" ? { kind: "lookNow" } : n.kind === "chooseDrawCount" ? {
				kind: "drawCount",
				count: n.maximum
			} : null;
			if (!a) return null;
			let u = {
				kind: "choose",
				choice: a
			}, d = Qr(r, u, { by: t.owner });
			if (!("state" in d) || (r = d.state, i.push({
				by: t.owner,
				action: u
			}), !o())) return null;
			c = r.resolution?.tasks[0], l = Qr(r, s.data, { by: e.by });
		}
		if (!("state" in l)) return null;
		r = l.state, i.push(n);
		let u = ti(r);
		if (u === null) return null;
		u && (r = u.state, i.push(u.entry));
		let d = !("type" in s.data) && s.data.kind === "choose" ? s.data.choice : null, f = c?.kind === "cardEffect" && c.activation === "energy" && d?.kind === "cardEffect" && d.use ? c.card : null;
		if (f === 28 || f === 80 || f === 82 || c?.kind === "takeSpecies" && d?.kind === "species" || c === a && d?.kind === "resource") {
			if (!o()) return null;
			let t = r.resolution?.tasks[0];
			f === 28 && t?.kind === "resources" && (a = t);
			let n = f === 80 && t?.kind === "chooseDrawCount" ? {
				kind: "drawCount",
				count: 1
			} : f === 82 && t?.kind === "chooseLook" ? { kind: "lookNow" } : (c?.kind === "takeSpecies" || c === a) && t?.kind === "chooseGain" ? {
				kind: "gainCount",
				count: t.maximum
			} : null;
			if (c === a && (a = null), n && r.resolution) {
				let t = {
					kind: "choose",
					choice: n
				}, a = Qr(r, t, { by: r.resolution.owner });
				if (!("state" in a)) return null;
				r = a.state, i.push({
					by: e.by,
					action: t
				});
			}
		}
	}
	return o() ? i : null;
}
var ii = {
	meta: sr,
	saveCompatibility: {
		version: "4",
		migrate: ({ version: e, log: t }) => e === "3" ? ni(t) : e === "1" || e === "2" || e === void 0 ? ri(t) : null
	},
	schemas: {
		action: Ur,
		publicView: Jr,
		privateView: Yr,
		config: Hr
	},
	setup: Zr,
	reduce: Qr,
	viewFor: $r,
	status: ei,
	nextTickIn: (e) => e.resolution?.pendingBeat || e.soloPending ? 700 : null
}, ai = {
	name: "Wondrous Creatures",
	desc: "Explore a mysterious island, discover creatures, and build your reserve.",
	rules: "Goal:\nExplore the island, collect creatures, and accomplish achievements. The player with the most points at the end wins.\n\nSetup:\nChoose one of two captains and keep four of eight Creature cards. Begin with one of each resource and one net. Depending on your seat, choose zero, one, two, or three different resource types and gain one of each. Each player has three explorers, one carrying the captain. The public area contains six Wilderness cards, a habitat supply, the time track, and seven achievements.\n\nTurns:\nPerform one basic action each turn. You may perform free actions before, after, or during it. Once your basic action and its effects are resolved, end your turn and refill empty Wilderness spaces.\n· Place an explorer: Place an available explorer across two adjacent unoccupied plains or mountains, never on a lake or habitat. Pay one resource of your choice if either space is a mountain; if the only available placement includes a mountain and you cannot pay, you may still place it. Collect covered eggs, then for each adjacent habitat choose one matching resource or a matching Creature card from the Wilderness. The net habitat gives one net.\n· Play creatures: Pay for and play one or two cards from your hand, one at a time, into your reserve. Instant, Permanent, Energy, Recharge, and End of game cards work as described on each card; fill an Energy card to its energy limit when played. You may decline a card's ability. Resolve multiple effects on a card in printed order; effects without an arrow may be resolved in full, in part, or not at all. An effect to the left of an arrow is required for the effect to its right, but you may still forgo all or part of the latter. You choose the order of abilities triggered simultaneously on different cards.\n· Accomplish an achievement: Choose an achievement you have not completed, an empty space whose condition you meet, and an unused achievement marker. First hatch the eggs used for the achievement, then gain the marker reward or two immediate points instead, and finally gain a trophy. Your first achievement unlocks your captain's power. Each player may occupy only one space per achievement and complete at most six achievements. You can still complete achievements after the trophies run out, but gain no trophy.\n· Recharge: You can recharge only when all three of your explorers are on the map. Retrieve them and advance the time track. Reveal a time token on the destination if there is one, place an egg from the bag on each empty space bearing its symbol, and resolve the destination effects. Discard down to five cards, then activate your Recharge cards in an order of your choice. Once the time marker reaches the last space, resolve that space again on each later recharge.\n\nFree actions:\n· Spend a net to collect one egg adjacent to any of your explorers or activate one adjacent special effect. Each special effect can be activated with a net only once per turn; card and captain effects are not subject to this limit.\n· Spend one energy from an Energy card in your reserve to use its ability. You may use at most one energy from each Energy card per turn.\n\nAchievements and eggs:\nSingle-species achievements require a number of icons of that species; multi-species achievements count the two indicated species together. Creature icons in your reserve and unhatched eggs can meet the condition. Hatch the eggs you choose to use; hatched eggs cannot be used for achievements unless flipped back. The main achievements require fourteen Creature cards, hatching eight unhatched eggs, six matching habitat icons, ten matching species icons, or two cards of each of the five Creature types. Three are used in each game.\n\nYou may hold at most six of each resource and three nets; each excess net gives one immediate point. Store eggs from left to right and gain each covered reward immediately. An egg gained with all twelve spaces full gives two immediate points instead. If the public stock of a specified species is empty, you cannot gain an egg of that species.\n\nDiscovery and the score track:\nWhen immediate points reach or pass a reward space on the score track, gain that reward immediately. A discovery lets you choose a habitat tile from the public supply and place it on a lake. Collect any egg on that lake and immediately refill the habitat supply. You no longer receive score-track rewards after exceeding fifty points; final scoring does not trigger them either.\n\nEnd of game:\nWhen the last trophy is taken or removed, the active player finishes their turn and every other player takes one final turn. Add immediate points, End of game card abilities, printed Creature card points, achievement points, three points per trophy, and one point per four remaining resources and nets. Break ties by trophies, then resources; remaining ties are shared.\n\nSolo mode:\nYou and the automa Tingent take alternating turns, beginning with yours. Use the two-player board with eight public trophies, and choose any captain. Setup offers Novice, Experienced, Expert, and Legend difficulty.\n· Each turn Tingent reveals an action card and resolves the section matching its track position, then advances its track when the card indicates. On reaching the brown section, shuffle the action cards and use their brown sections from the next turn. Track spaces may discover a habitat, advance time, or accomplish an achievement. For discovery, choose the leftmost lake containing an egg, breaking ties by the uppermost lake. If no lake contains an egg, choose the uppermost lake, breaking ties by the leftmost lake.\n· Tingent uses two explorers and places them only on plains. It prioritizes placements adjacent to the most habitats of the indicated type, then the most habitats overall, the most special effects, and the most adjacent or covered eggs. Choose between any remaining ties. Tingent collects covered eggs, and its captain scores for adjacent habitats of the indicated type. If the indicated explorer cannot move, reveal another action card instead.\n· Tingent pays no resources and does not use Creature abilities. It takes a Wilderness card matching the targeted achievement species, choosing the highest printed score and then the leftmost card on a tie; if none matches, it draws a face-down card instead. Its eggs never hatch or grant storage rewards.\n· Tingent can occupy an empty lower species-achievement space without meeting a condition. It may occupy the higher space when its matching icons exceed the lower requirement. For a main achievement it takes the higher space if available. It takes a trophy and moves its target to the next achievement of that type.\n· If you take the last trophy, Tingent takes one final turn; if Tingent takes or removes it, the game ends. Add Tingent's immediate points, printed points on face-up cards, achievement points, five points for each face-up End of game card, three points per trophy, and one point per egg. Each face-down card scores one, two, or three points according to difficulty. On a score tie, you win only if you have more trophies.\n\nGargantuan Beasts:\nWhen enabled, shuffle the fourteen expansion Creature cards and four expansion captains into the base game, and display one more beast than the number of human players. The solo opponent does not use a beast. Each player may own at most one beast, and the supply is not refilled.\n· Gaining a beast is a basic action. Hatch four unhatched eggs in your reserve and resolve any resulting abilities, then choose a beast from the supply, place it sleeping in your reserve, and unlock your captain power.\n· When you play a Creature card matching either species on your sleeping beast, advance its marker one space, even if the card has multiple matching icons. Some expansion cards advance it further. When completing an achievement, you may forgo its marker reward to advance your beast two spaces instead.\n· On reaching the final space, the beast awakens immediately. Apply its printed power and count its two species icons for achievements and abilities that count species; a beast is not a Creature card. Its energy cannot be restored, and at most one of its energy tokens may be used per turn. At the end, an awakened beast scores for its indicated species icons, including its own icons and both hatched and unhatched eggs.\n· Ashe and Nathaniel each gain one captain energy on unlocking and whenever placed; see their captain boards for how to spend it. Rabell can gain an egg matching the last egg stored by an adjacent player; in solo play, choose any species Tingent has collected. Morgane may copy an adjacent player's captain power without copying unlock rewards or using that player's resources or cards; in solo play choose from two random captains.\n\nExplorer Pack:\nWhen enabled, each human player takes two random Explorer cards, chooses one, and pays the specified number of starting resources of their choice. In setup you may instead choose alongside your starting cards and captain, or choose freely in reverse seat order. Resolve start-of-game abilities after everyone has chosen and before the first turn; Tingent does not use an Explorer card.\n· A once-per-game ability is a free action that you may use once on your turn and cannot restore. Each card describes its conditions and result.\n· If you choose Chapillon, gain two points, then replace it with a random unchosen Explorer card after everyone has chosen. Pay the new card's cost and resolve its start-of-game ability if it has one.",
	ui: {
		turn: "Current turn",
		waiting: "Waiting for another player",
		draft: "Prepare your expedition",
		chooseCaptain: "Choose a captain",
		chooseFour: "Keep four starting cards",
		bonusResources: "Choose extra resources",
		confirm: "Confirm",
		cancel: "Cancel",
		island: "Mysterious island",
		mapOverview: "Show whole island",
		mapEnlarge: "Enlarge island",
		wilderness: "Wilderness",
		reserve: "Reserve",
		hand: "Hand",
		captain: "Captain",
		eggs: "Egg storage",
		achievements: "Achievements",
		trophies: "Trophies",
		deck: "Deck",
		discard: "Discard",
		time: "Time track",
		timeDetails: "View time track",
		initialSymbols: "Symbols revealed during setup:",
		timeGainNet: "Gain a net",
		timeSweep: "Sweep the Wilderness",
		timeRemoveTrophy: "Remove a trophy",
		timeHidden: "Time token hidden",
		timeRevealed: "Token revealed",
		points: "points",
		resources: "Resources",
		nets: "Nets",
		explore: "Place an explorer",
		playCards: "Play creatures",
		achievement: "Accomplish achievement",
		recharge: "Recharge",
		finishTurn: "End turn",
		freeActions: "Free actions",
		useNet: "Use a net",
		useEnergy: "Use energy",
		choosePiece: "Choose an explorer",
		captainPiece: "Captain",
		explorerA: "Explorer A",
		explorerB: "Explorer B",
		chooseCells: "Choose two adjacent spaces",
		macusDirection: "Choose the tail first, then the head. The captain may activate the adjacent special effect in front.",
		mountainPayment: "Choose mountain payment",
		noPayment: "No payment",
		place: "Place",
		chooseEgg: "Choose an egg",
		chooseHabitat: "Choose a habitat reward",
		useCaptain: "Use captain power",
		finishExplorer: "Finish placement",
		chooseResource: "Choose a resource",
		chooseSpecies: "Choose a species",
		chooseCard: "Choose a creature",
		chooseSlot: "Choose a Wilderness card",
		chooseTile: "Choose a habitat tile and lake",
		chooseSpecial: "Choose a special effect",
		takeResource: "Gain resource",
		takeCard: "Take creature",
		gainNet: "Gain net",
		use: "Use",
		skip: "Skip",
		yes: "Continue",
		no: "Finish",
		pay: "Pay",
		free: "Free",
		select: "Select",
		drawChoice: "Choose two different rewards",
		eggReward: "Gain an egg",
		resourceReward: "Gain a resource",
		pointReward: "Gain printed points",
		flipEggs: "Choose eggs to flip",
		hatchEggs: "Choose eggs to hatch",
		confirmEggs: "Confirm selection",
		selectOrder: "Choose the next ability to resolve",
		activate: "Activate ability",
		decline: "Do not use",
		chooseRecharge: "Choose a Recharge card",
		restore: "Choose an Energy card to restore",
		chooseDiscard: "Choose a card to discard",
		confirmDiscard: "Confirm discard",
		replaceDiscard: "Play for free instead",
		choosePlay: "Choose a card to play",
		choosePayment: "Choose the actual payment",
		discardDiscount: "Discard to reduce the cost",
		chooseExchange: "Choose resources to exchange",
		exchange: "Exchange",
		from: "Give",
		to: "Gain",
		amount: "Amount",
		chooseLook: "Choose one card to keep",
		chooseSweep: "Choose a side to sweep",
		left: "Left",
		right: "Right",
		chooseEndCard: "Choose an End of game card",
		chooseCopy: "Choose an End of game card to score again",
		chooseReward: "Choose an earned achievement marker reward",
		freyaEgg: "Collect an adjacent egg",
		freyaFlip: "Flip eggs in your reserve",
		tingentGain: "Gain one captain energy",
		tingentDistribute: "Distribute captain energy",
		timeEgg: "Choose where to place an egg",
		playAnother: "Play another card?",
		target: "Achievement",
		condition: "Condition",
		reward: "Reward",
		occupied: "Occupied",
		available: "Available",
		vacant: "Open",
		marker: "Achievement marker",
		substitutePoints: "Gain two points instead",
		selected: "Selected",
		complete: "Accomplish",
		details: "Details",
		close: "Close",
		back: "Back",
		myReserve: "My reserve",
		otherReserve: "Player's reserve",
		empty: "None",
		hatched: "Hatched",
		unhatched: "Unhatched",
		energy: "Energy",
		locked: "Locked",
		unlocked: "Unlocked",
		captainEnergy: "Captain energy",
		supplyDetails: "View public supply",
		habitatSupply: "Habitat tiles",
		remainingTiles: "Tiles remaining",
		eggSupply: "Egg stock",
		eggBag: "In the bag",
		final: "Expedition results",
		scoreItems: "Scoring",
		finalAbilities: "End of game abilities",
		printedPoints: "Printed creature points",
		achievementPoints: "Achievement points",
		trophyPoints: "Trophy points",
		remainingPoints: "Remaining resources and nets",
		soloEggPoints: "Tingent's eggs",
		soloHiddenPoints: "Tingent's face-down cards",
		immediatePoints: "Immediate points",
		total: "Total",
		winner: "Winner",
		tied: "Tied",
		reviewBoard: "Review the board",
		returnResult: "Return to results",
		confirmAgain: "Confirm new game",
		confirmLobby: "Confirm return to lobby",
		invalid: "That action is not available. Please choose again.",
		noTargets: "No available targets",
		pending: "Complete the current choice"
	}
}, oi = {
	name: "幻兽奇旅",
	desc: "探索神秘岛屿，发现幻兽并建设自己的保护区。",
	rules: "目标:\n探索岛屿、收集幻兽并完成目标。游戏结束后，分数最高的玩家获胜。\n\n准备:\n每位玩家从两名船长中选择一名，并从八张幻兽牌中保留四张。每种资源各获得一份，并获得一个网；按座次依次额外选择零、一、二或三种不同的资源，各获得一份。每名玩家有三名探险者，其中一名搭载船长。公共区域包括荒野中的六张牌、栖地供应、时间轨和七项目标。\n\n回合:\n每回合必须执行一项基本行动。你可以在基本行动之前、之后或过程中执行免费行动。基本行动及其连锁结束后，结束回合并补满荒野中的空位。\n· 放置探险者：将一名尚未放置的探险者横跨两个相邻的空置平原或山地，不能放在湖泊或栖地上。如果任一格是山地，支付一份任选资源；如果唯一可用位置包含山地且你没有资源，仍可放置。收取棋子覆盖的蛋，然后对每个相邻栖地分别选择获得一份对应资源，或从荒野中取得一张对应栖地的牌。相邻的网栖地提供一个网。\n· 打出幻兽：从手牌逐张支付费用，打出一张或两张幻兽牌并放入保护区。每张牌有即时、持续、能量、充能或终局类型，按其说明生效；能量牌入场时放满能量。你可以选择不使用一张牌的能力。同一张牌的多个效果依牌面顺序结算；没有箭头连接的效果可以全部、部分或不执行。箭头左侧是右侧效果的前提，完成前提后仍可放弃右侧效果的全部或一部分。同时触发的多张牌能力可由你选择结算顺序。\n· 完成目标：选择一张自己尚未完成的目标、一个空置且满足条件的格位和一个未使用的目标标记。先孵化用于达成条件的蛋，再取得该标记的奖励，或改得两即时分；然后取得一个奖杯。第一次完成目标时解锁船长能力。每张目标每人只能占一个格位，每人最多完成六项目标；奖杯耗尽后仍可完成目标，但不再获得奖杯。\n· 充能：只有自己的三名探险者都在地图上时才能充能。先收回探险者并推进时间轨；揭示落点的时间标记，在带有该符号的空格上从袋中各放一个蛋，再结算落点效果。将手牌弃至最多五张，然后按自选顺序激活保护区中的充能牌。达到时间轨末格后，之后每次充能仍结算该末格。\n\n免费行动:\n· 花费一个网，收取与自己任一探险者相邻的一个蛋，或激活相邻栖地的一个特殊效果。同一个特殊效果每回合只能通过网激活一次；卡牌或船长的其他效果不受此限制。\n· 消耗保护区中能量牌的一枚能量，执行其能力。每张能量牌每回合最多使用一枚自身能量。\n\n目标与蛋:\n单物种目标要求一定数量的该物种图标；双物种目标将指定两种物种的图标合计。保护区中的幻兽图标和未孵化蛋可用于满足条件，选作目标的蛋会孵化；已孵化蛋不能用于目标，除非再次翻面。主要目标要求保护区拥有十四张幻兽牌、孵化八个未孵化蛋、拥有六个相同栖地图标、拥有十个相同物种图标，或五种类型的幻兽牌各拥有两张。每局使用其中三项。\n\n每种资源最多持有六份，网最多三个；每个超出上限的网改得一即时分。蛋从左到右放入十二个蛋槽，并立即取得槽位奖励；满槽后每获得一个蛋改得两即时分。指定物种的公共蛋库存耗尽时，不能获得该物种的蛋。\n\n发现与计分轨:\n即时分到达或越过计分轨的奖励格时，立即取得该奖励。发现奖励让你从公开供应中选择一块栖地板块，放在一个湖泊上；如果湖泊有蛋，收取该蛋，并立即补充栖地供应。计分超过五十分后不再获得计分轨奖励。终局计分也不触发这些奖励。\n\n游戏结束:\n最后一个奖杯被取走或移除后，当前玩家完成回合，其余玩家各进行最后一回合。将即时分、终局牌能力分、幻兽牌印刷分、目标分、每个奖杯三分，以及每四份剩余资源和网一分相加。平分时先比较奖杯数，再比较资源数；仍相同则并列。\n\n单人模式:\n你与自动对手汀詹特轮流行动，你先行动。使用两人棋盘，但公共奖杯改为八个；你可以从全部船长中选择一名。开局选项提供新手、熟练、专家和传奇四种对手难度。\n· 汀詹特每回合翻开一张行动牌，按其轨道当前位置结算对应区域，再在牌面指示时推进轨道。进入棕色区域后，洗混行动牌，从下一回合起使用棕色区域。轨道可能让它发现栖地、推进时间或完成目标。发现时，优先选择有蛋的最左侧湖泊，若并列则选择其中最上方的湖泊；没有湖泊有蛋时，选择最上方湖泊，若并列则选择其中最左侧的湖泊。\n· 汀詹特使用两名探险者，只能放在平原。它优先选择相邻的指定栖地数量最多的位置，再依次比较相邻栖地总数、相邻特殊效果数和相邻或覆盖的蛋数；仍有并列时由你选择位置。它收取覆盖的蛋，船长还会按指定栖地数量得分。无法移动指定探险者时，改翻一张行动牌。\n· 汀詹特不支付资源，也不使用幻兽能力。它按目标标记取得对应物种的荒野牌；如果有多张可选，取得印刷分最高的一张，平分时取最左侧的一张；没有可选牌时改为暗置一张牌。它的蛋不孵化，也不触发蛋槽奖励。\n· 完成单人物种目标时，汀詹特可无条件占用空置的低档格；若对应图标数量超过低档要求，则可以占用高档格。完成主要目标时优先占高档格。它取得奖杯并将目标标记移至下一张同类目标。\n· 你取走最后一个奖杯后，汀詹特再行动一次；汀詹特取走或移除最后一个奖杯后，游戏结束。汀詹特将即时分、明置牌印刷分、目标分、每张明置终局牌五分、每个奖杯三分及每个蛋一分相加；每张暗置牌按难度获得一、二或三分。双方平分时，只有你的奖杯更多才获胜。\n\n巨兽扩展:\n启用后，将十四张扩展幻兽牌和四名扩展船长加入基础版，并随机展示比真人玩家人数多一只的巨兽。单人对手不使用巨兽。每位玩家最多拥有一只巨兽，公共巨兽被取走后不再补充。\n· 获得巨兽是一项基本行动。先孵化保护区中的四个未孵化蛋，结算翻蛋触发的能力，再选择一只公共巨兽放入保护区的沉睡区，并解锁船长能力。\n· 打出与沉睡巨兽任一物种相同的幻兽牌时，将巨兽标记前进一格；即使一张牌有多个匹配图标，也只因此前进一格。部分扩展牌还能额外推进巨兽。完成目标时，也可以放弃目标标记奖励，改为将自己的巨兽前进两格。\n· 标记到达轨道末端时，巨兽立即唤醒。唤醒后使用牌面所述能力，并将巨兽的两个物种图标计入目标和有关物种图标的能力；巨兽本身不算幻兽牌。巨兽的能量不能恢复，每回合最多使用一枚。终局时，唤醒的巨兽按其指定物种图标计分，包括自身图标和已孵化、未孵化的蛋。\n· 艾什与纳撒尼尔解锁或放置时各获得一枚船长能量，能量的使用方法见船长板。拉贝尔可以从库存取得与相邻玩家最后储存的蛋同物种的蛋；单人局中可选择汀詹特已经收集的任一物种。摩根可以复制相邻玩家的船长能力，不能复制其解锁奖励，也不能使用对方的资源或卡牌；单人局中从两名随机船长中选择要复制的能力。\n\n探险者扩展:\n启用后，每位真人随机取得两张探险者牌并选择一张，按牌面支付对应数量的任选初始资源。也可以在创建对局时选择同时查看起始手牌与船长，或从末席开始按逆序自由选择。所有人选完后才处理开局能力，汀詹特不使用探险者牌。\n· 开局能力在首位玩家开始回合前依次结算；每局一次的能力作为免费行动，可在自己的回合中使用一次，使用后不能恢复。牌面说明每项能力的条件与结果。\n· 选择蝶翼猫时，先获得两分，再从其他玩家都已选完的未选探险者牌中随机替换一张，支付新牌费用；如果新牌有开局能力，立即结算。",
	ui: {
		turn: "当前回合",
		waiting: "等待其他玩家",
		draft: "准备探险",
		chooseCaptain: "选择船长",
		chooseFour: "选择四张起始手牌",
		bonusResources: "选择额外资源",
		confirm: "确认",
		cancel: "取消",
		island: "神秘岛屿",
		mapOverview: "查看全图",
		mapEnlarge: "放大地图",
		wilderness: "荒野",
		reserve: "保护区",
		hand: "手牌",
		captain: "船长",
		eggs: "蛋槽",
		achievements: "公开目标",
		trophies: "奖杯",
		deck: "牌库",
		discard: "弃牌",
		time: "时间轨",
		timeDetails: "查看时间轨",
		initialSymbols: "开局揭示的标记：",
		timeGainNet: "获得网",
		timeSweep: "扫荡全部荒野牌",
		timeRemoveTrophy: "移除奖杯",
		timeHidden: "时间标记未揭示",
		timeRevealed: "标记已揭示",
		points: "分",
		resources: "资源",
		nets: "网",
		explore: "放置探险者",
		playCards: "打出幻兽",
		achievement: "完成目标",
		recharge: "充能",
		finishTurn: "结束回合",
		freeActions: "免费行动",
		useNet: "使用网",
		useEnergy: "使用能量",
		choosePiece: "选择探险者",
		captainPiece: "船长",
		explorerA: "探险者甲",
		explorerB: "探险者乙",
		chooseCells: "选择两个相邻地块",
		macusDirection: "先选尾端，再选朝向端；前方的相邻特殊效果可由船长激活。",
		mountainPayment: "选择山地费用",
		noPayment: "无需支付",
		place: "放置",
		chooseEgg: "选择蛋",
		chooseHabitat: "选择栖地收益",
		useCaptain: "使用船长能力",
		finishExplorer: "完成放置",
		chooseResource: "选择资源",
		chooseSpecies: "选择物种",
		chooseCard: "选择幻兽牌",
		chooseSlot: "选择荒野牌",
		chooseTile: "选择栖地板块与湖泊",
		chooseSpecial: "选择特殊效果",
		takeResource: "取得资源",
		takeCard: "取得幻兽",
		gainNet: "获得网",
		use: "使用",
		skip: "跳过",
		yes: "继续",
		no: "结束",
		pay: "支付",
		free: "免费",
		select: "选择",
		drawChoice: "选择两项不同的奖励",
		eggReward: "获得蛋",
		resourceReward: "获得资源",
		pointReward: "获得印刷分",
		flipEggs: "选择要翻转的蛋",
		hatchEggs: "选择要孵化的蛋",
		confirmEggs: "确认选择",
		selectOrder: "选择先结算的能力",
		activate: "激活能力",
		decline: "不使用",
		chooseRecharge: "选择充能牌",
		restore: "选择要补充能量的牌",
		chooseDiscard: "选择要弃掉的手牌",
		confirmDiscard: "确认弃牌",
		replaceDiscard: "免费打出代替弃牌",
		choosePlay: "选择要打出的牌",
		choosePayment: "选择实际支付",
		discardDiscount: "弃牌以减少费用",
		chooseExchange: "选择交换资源",
		exchange: "交换",
		from: "交出",
		to: "获得",
		amount: "数量",
		chooseLook: "选择一张牌加入手牌",
		chooseSweep: "选择扫荡的一侧",
		left: "左侧",
		right: "右侧",
		chooseEndCard: "选择终局牌",
		chooseCopy: "选择要重复计分的终局牌",
		chooseReward: "选择已获得的目标标记奖励",
		freyaEgg: "收取相邻的蛋",
		freyaFlip: "翻转保护区的蛋",
		tingentGain: "获得一枚船长能量",
		tingentDistribute: "分配船长能量",
		timeEgg: "选择放蛋的位置",
		playAnother: "再打出一张牌？",
		target: "目标",
		condition: "条件",
		reward: "奖励",
		occupied: "已占用",
		available: "可选择",
		vacant: "空位",
		marker: "目标标记",
		substitutePoints: "改得两分",
		selected: "已选择",
		complete: "完成目标",
		details: "详情",
		close: "关闭",
		back: "返回",
		myReserve: "我的保护区",
		otherReserve: "玩家保护区",
		empty: "暂无",
		hatched: "已孵化",
		unhatched: "未孵化",
		energy: "能量",
		locked: "未解锁",
		unlocked: "已解锁",
		captainEnergy: "船长能量",
		supplyDetails: "查看公共供应",
		habitatSupply: "栖地板块",
		remainingTiles: "剩余板块",
		eggSupply: "蛋库存",
		eggBag: "袋中剩余",
		final: "航行结算",
		scoreItems: "计分项目",
		finalAbilities: "终局能力",
		printedPoints: "幻兽印刷分",
		achievementPoints: "目标分",
		trophyPoints: "奖杯分",
		remainingPoints: "剩余资源与网",
		soloEggPoints: "汀詹特的蛋",
		soloHiddenPoints: "汀詹特的暗置牌",
		immediatePoints: "即时分",
		total: "总分",
		winner: "获胜",
		tied: "并列",
		reviewBoard: "回看局面",
		returnResult: "返回结算",
		confirmAgain: "确认再来一局",
		confirmLobby: "确认返回大厅",
		invalid: "当前不能执行该操作，请重新选择。",
		noTargets: "没有可用目标",
		pending: "请完成当前选择"
	}
};
//#endregion
//#region src/game/achievement-panel.tsx
function si(e, t) {
	return e.kind === "single" ? V[e.species][t] : e.kind === "multi" ? e.species.map((e) => V[e][t]).join(" + ") : {
		fourteenCards: {
			zh: "保护区有十四张幻兽牌",
			en: "Fourteen creatures in your reserve"
		},
		eightEggs: {
			zh: "孵化八个未孵化的蛋",
			en: "Hatch eight unhatched eggs"
		},
		sixHabitat: {
			zh: "保护区有六个相同的栖地图标",
			en: "Six matching habitat icons in your reserve"
		},
		tenSpecies: {
			zh: "保护区有十个相同的物种图标",
			en: "Ten matching species icons in your reserve"
		},
		twoTypeSets: {
			zh: "保护区有两组各含五种类型的幻兽牌",
			en: "Two sets of all five creature types"
		}
	}[e.requirement][t];
}
function ci(e, t) {
	let n = (t === "zh" ? oi : ai).ui;
	return e.kind === "points" ? `${e.amount} ${n.points}` : e.kind === "resources" ? `${e.amount} ${n.resources}` : e.kind === "wildernessCards" ? `${e.amount} ${n.wilderness}` : e.kind === "net" ? `${e.amount} ${n.nets}` : e.kind === "restoreEnergy" ? n.restore : e.kind === "activateAllRecharge" ? n.recharge : e.kind === "discovery" ? n.chooseTile : n.trophies;
}
function li({ pub: e, myRid: t, lang: n, send: r, close: i, freeExplorer: o = !1 }) {
	let s = (n === "zh" ? oi : ai).ui, [c, l] = a(null), [u, d] = a(null), [f, p] = a(null), [_, v] = a(!0), [y, b] = a(!1), [x, S] = a([]), [C, ee] = a("crustacean"), [te, E] = a("fruit"), D = e.achievements.find((e) => e.id === c), O = e.players.find((e) => e.rid === t);
	if (!O) return null;
	let ne = e.beasts?.players.find((e) => e.owner === t && e.awake), k = ne ? _e.find((e) => e.id === ne.id)?.species : void 0, re = D && u !== null ? se(D, e.players.length)[u] : void 0, A = {
		eggs: x,
		species: C,
		habitat: te
	}, j = !!D && !!re && f !== null && !e.claims.some((e) => e.owner === t && (e.achievement === D.id || e.marker === f) || e.achievement === D.id && e.slot === u) && ue(D, re.required, {
		cards: O.reserve,
		eggs: O.eggs,
		extraSpecies: k
	}, A), ie = D?.kind !== "main" || D.requirement === "eightEggs" || D.requirement === "tenSpecies";
	return /* @__PURE__ */ g("section", {
		className: "wc-decision wc-goal-panel",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": s.achievements,
		children: [
			/* @__PURE__ */ g("div", {
				className: "wc-section-title",
				children: [/* @__PURE__ */ h("h3", { children: s.achievement }), /* @__PURE__ */ h("button", {
					type: "button",
					onClick: i,
					children: s.close
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "wc-choice-row",
				children: e.achievements.map((r) => /* @__PURE__ */ h("button", {
					type: "button",
					disabled: e.claims.some((e) => e.owner === t && e.achievement === r.id),
					className: c === r.id ? "is-selected" : "",
					onClick: () => {
						l(r.id), d(null), S([]);
					},
					children: si(r, n)
				}, r.id))
			}),
			D && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("h4", { children: s.target }),
				/* @__PURE__ */ h("div", {
					className: "wc-choice-row",
					children: se(D, e.players.length).map((t, n) => /* @__PURE__ */ g("button", {
						type: "button",
						disabled: e.claims.some((e) => e.achievement === D.id && e.slot === n),
						className: u === n ? "is-selected" : "",
						onClick: () => d(n),
						children: [
							t.required,
							" · ",
							t.points,
							" ",
							s.points
						]
					}, n))
				}),
				D.kind === "main" && D.requirement === "tenSpecies" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h4", { children: s.chooseSpecies }), /* @__PURE__ */ h("div", {
					className: "wc-choice-row",
					children: T.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: C === e ? "is-selected" : "",
						onClick: () => {
							ee(e), S([]);
						},
						children: V[e][n]
					}, e))
				})] }),
				D.kind === "main" && D.requirement === "sixHabitat" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h4", { children: s.chooseHabitat }), /* @__PURE__ */ h("div", {
					className: "wc-choice-row",
					children: w.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: te === e ? "is-selected" : "",
						onClick: () => E(e),
						children: B[e][n]
					}, e))
				})] }),
				ie && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h4", { children: s.chooseEgg }), /* @__PURE__ */ h("div", {
					className: "wc-choice-row",
					children: O.eggs.map((e, t) => /* @__PURE__ */ g("button", {
						type: "button",
						disabled: e.hatched,
						className: x.includes(t) ? "is-selected" : "",
						onClick: () => S((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]),
						children: [
							V[e.species][n],
							" · ",
							e.hatched ? s.hatched : s.unhatched
						]
					}, t))
				})] }),
				/* @__PURE__ */ h("h4", { children: s.marker }),
				/* @__PURE__ */ h("div", {
					className: "wc-choice-row",
					children: fe.map((r, i) => /* @__PURE__ */ h("button", {
						type: "button",
						disabled: e.claims.some((e) => e.owner === t && e.marker === i),
						className: f === i ? "is-selected" : "",
						onClick: () => p(i),
						children: ci(r, n)
					}, i))
				}),
				/* @__PURE__ */ g("div", {
					className: "wc-choice-row",
					children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							className: _ ? "is-selected" : "",
							onClick: () => {
								v(!0), b(!1);
							},
							children: s.reward
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: !_ && !y ? "is-selected" : "",
							onClick: () => {
								v(!1), b(!1);
							},
							children: s.substitutePoints
						}),
						e.beasts?.players.some((e) => e.owner === t) && /* @__PURE__ */ h("button", {
							type: "button",
							className: y ? "is-selected" : "",
							onClick: () => {
								v(!1), b(!0);
							},
							children: n === "zh" ? "巨兽前进两格" : "Advance your beast two spaces"
						})
					]
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "wc-primary",
					disabled: !j,
					onClick: () => {
						if (D && u !== null && f !== null) {
							let e = {
								kind: "achievement",
								achievement: D.id,
								slot: u,
								marker: f,
								useMarkerReward: _,
								advanceBeast: y,
								selection: A
							};
							r(o ? {
								kind: "explorerPower",
								choice: e
							} : e), i();
						}
					},
					children: s.complete
				})
			] })
		]
	});
}
//#endregion
//#region src/game/beast-panel.tsx
function ui({ id: e, lang: t }) {
	let n = _e.find((t) => t.id === e);
	return n ? /* @__PURE__ */ g("span", {
		className: "wc-beast-card",
		children: [/* @__PURE__ */ h("img", {
			src: o(`games/wondrouscreatures/beasts/${String(e).padStart(2, "0")}.webp`),
			alt: "",
			draggable: !1,
			loading: "lazy"
		}), /* @__PURE__ */ g("span", { children: [
			/* @__PURE__ */ h("strong", { children: n.name[t] }),
			/* @__PURE__ */ h("span", { children: n.species.map((e) => V[e][t]).join(" · ") }),
			/* @__PURE__ */ h("span", { children: n.ability[t] })
		] })]
	}) : null;
}
function di({ pub: e, owner: t, lang: n, send: r, close: i }) {
	let [o, s] = a(null), [c, l] = a([]), u = e.players.find((e) => e.rid === t);
	if (!u || !e.beasts) return null;
	let d = n === "zh" ? {
		title: "获得巨兽",
		close: "关闭",
		choose: "选择一只巨兽",
		hatch: "选择四个未孵化的蛋",
		confirm: "孵化并获得巨兽",
		hatched: "已孵化"
	} : {
		title: "Gain a beast",
		close: "Close",
		choose: "Choose a beast",
		hatch: "Choose four unhatched eggs",
		confirm: "Hatch eggs and gain the beast",
		hatched: "Hatched"
	};
	return /* @__PURE__ */ g("section", {
		className: "wc-decision wc-beast-panel",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": d.title,
		children: [
			/* @__PURE__ */ g("div", {
				className: "wc-section-title",
				children: [/* @__PURE__ */ h("h3", { children: d.title }), /* @__PURE__ */ h("button", {
					type: "button",
					onClick: i,
					children: d.close
				})]
			}),
			/* @__PURE__ */ h("h4", { children: d.choose }),
			/* @__PURE__ */ h("div", {
				className: "wc-beast-options",
				children: e.beasts.supply.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					"aria-pressed": o === e,
					className: o === e ? "is-selected" : "",
					onClick: () => s(e),
					children: /* @__PURE__ */ h(ui, {
						id: e,
						lang: n
					})
				}, e))
			}),
			/* @__PURE__ */ g("h4", { children: [
				d.hatch,
				" · ",
				c.length,
				"/4"
			] }),
			/* @__PURE__ */ h("div", {
				className: "wc-choice-row",
				children: u.eggs.map((e, t) => /* @__PURE__ */ g("button", {
					type: "button",
					disabled: e.hatched,
					"aria-pressed": c.includes(t),
					className: c.includes(t) ? "is-selected" : "",
					onClick: () => l((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < 4 ? [...e, t] : e),
					children: [V[e.species][n], e.hatched ? ` · ${d.hatched}` : ""]
				}, t))
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-primary",
				disabled: !o || c.length !== 4,
				onClick: () => {
					o && (r({
						kind: "beast",
						beast: o,
						eggs: c
					}), i());
				},
				children: d.confirm
			})
		]
	});
}
//#endregion
//#region src/game/game-icon.tsx
function fi({ name: e }) {
	return /* @__PURE__ */ h("img", {
		className: "wc-icon",
		src: o(`games/wondrouscreatures/icons/${e}.webp`),
		alt: "",
		draggable: !1
	});
}
//#endregion
//#region src/game/card-face.tsx
function pi({ id: e, lang: t, compact: n = !1, species: r, currentEnergy: i }) {
	let a = U.get(e);
	if (!a) return null;
	let s = w.flatMap((e) => a.cost[e] ? [{
		resource: e,
		amount: a.cost[e]
	}] : []), c = "energyCapacity" in a ? a.energyCapacity : void 0, l = r ?? a.species, u = o(`games/wondrouscreatures/art/${String(e).padStart(3, "0")}.webp`), d = t === "zh" ? {
		cost: "费用",
		habitat: "栖地",
		species: "物种",
		points: "印刷分",
		energy: "能量上限",
		free: "免费"
	} : {
		cost: "Cost",
		habitat: "Habitat",
		species: "Species",
		points: "Printed points",
		energy: "Energy capacity",
		free: "Free"
	};
	return /* @__PURE__ */ g("span", {
		className: `wc-card wc-card--${a.habitat}${n ? " wc-card--compact" : ""}`,
		children: [
			/* @__PURE__ */ g("span", {
				className: "wc-card-art",
				children: [
					/* @__PURE__ */ h("img", {
						className: "wc-illustration",
						src: u,
						alt: "",
						draggable: !1,
						loading: "lazy"
					}),
					/* @__PURE__ */ h("span", {
						className: "wc-art-species",
						children: l.map((e, t) => /* @__PURE__ */ h(fi, { name: e }, `${e}-${t}`))
					}),
					/* @__PURE__ */ h("span", {
						className: "wc-art-habitat",
						children: /* @__PURE__ */ h(fi, { name: `habitat-${a.habitat}` })
					})
				]
			}),
			/* @__PURE__ */ g("span", {
				className: "wc-card-header",
				children: [/* @__PURE__ */ h("strong", {
					className: "wc-card-name",
					children: a.name[t]
				}), /* @__PURE__ */ g("span", {
					className: "wc-card-type",
					children: [/* @__PURE__ */ h(fi, { name: a.type === "endGame" ? "end-game" : a.type }), Be[a.type][t]]
				})]
			}),
			/* @__PURE__ */ g("span", {
				className: "wc-card-traits",
				children: [/* @__PURE__ */ g("span", {
					title: d.habitat,
					children: [/* @__PURE__ */ h(fi, { name: `habitat-${a.habitat}` }), B[a.habitat][t]]
				}), /* @__PURE__ */ h("span", {
					title: d.species,
					children: l.map((e, n) => /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(fi, { name: e }), V[e][t]] }, `${e}-${n}`))
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "wc-card-cost",
				"aria-label": d.cost,
				children: s.length ? s.map(({ resource: e, amount: n }) => /* @__PURE__ */ g("span", {
					className: `wc-resource wc-resource--${e}`,
					children: [
						/* @__PURE__ */ h(fi, { name: e }),
						B[e][t],
						" ",
						n
					]
				}, e)) : d.free
			}),
			/* @__PURE__ */ h("span", {
				className: "wc-card-ability",
				children: a.ability[t]
			}),
			/* @__PURE__ */ g("span", {
				className: "wc-card-footer",
				children: [c !== void 0 && /* @__PURE__ */ h("span", { children: i === void 0 ? `${d.energy} ${c}` : `${t === "zh" ? "能量" : "Energy"} ${i}/${c}` }), /* @__PURE__ */ g("span", { children: [
					d.points,
					" ",
					a.printedPoints
				] })]
			})
		]
	});
}
//#endregion
//#region src/game/draft.tsx
function mi({ priv: e, seat: t, lang: n, send: r }) {
	let [i, o] = a(null), [s, c] = a([]), [l, u] = a([]), d = (n === "zh" ? oi : ai).ui, f = (e) => c((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 4 ? [...t, e] : t), p = (e) => u((n) => n.includes(e) ? n.filter((t) => t !== e) : n.length < t ? [...n, e] : n);
	return /* @__PURE__ */ g("section", {
		className: "wc-draft",
		children: [
			/* @__PURE__ */ h("h2", { children: d.draft }),
			/* @__PURE__ */ h("h3", { children: d.chooseCaptain }),
			/* @__PURE__ */ h("div", {
				className: "wc-draft-captains",
				children: e.captainOptions.map((e) => {
					let t = Dt.find((t) => t.id === e);
					return /* @__PURE__ */ g("button", {
						type: "button",
						className: i === e ? "is-selected" : "",
						"aria-pressed": i === e,
						onClick: () => o(e),
						children: [/* @__PURE__ */ h("strong", { children: t.name[n] }), /* @__PURE__ */ h("span", { children: t.ability[n] })]
					}, e);
				})
			}),
			/* @__PURE__ */ g("h3", { children: [
				d.chooseFour,
				" (",
				s.length,
				"/4)"
			] }),
			/* @__PURE__ */ h("div", {
				className: "wc-card-row",
				children: e.draftCards.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: `wc-card-button${s.includes(e) ? " is-selected" : ""}`,
					"aria-pressed": s.includes(e),
					onClick: () => f(e),
					children: /* @__PURE__ */ h(pi, {
						id: e,
						lang: n,
						compact: !0
					})
				}, e))
			}),
			t > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("h3", { children: [
				d.bonusResources,
				" (",
				l.length,
				"/",
				t,
				")"
			] }), /* @__PURE__ */ h("div", {
				className: "wc-choice-row",
				children: w.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: l.includes(e) ? "is-selected" : "",
					"aria-pressed": l.includes(e),
					onClick: () => p(e),
					children: B[e][n]
				}, e))
			})] }),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-primary",
				disabled: !i || s.length !== 4 || l.length !== t,
				onClick: () => i && r({
					kind: "draft",
					selection: {
						captain: i,
						cards: s,
						bonusResources: l
					}
				}),
				children: d.confirm
			})
		]
	});
}
//#endregion
//#region src/game/egg-marker.tsx
function hi({ egg: e, owner: t, index: n, lang: r, hatched: i, unhatched: a }) {
	let { ref: o, hidden: s } = l(`wc-egg:${t}:${n}`), c = V[e.species][r];
	return /* @__PURE__ */ h("span", {
		ref: o,
		style: { visibility: s ? "hidden" : void 0 },
		className: "wc-egg-marker",
		"aria-label": `${c} · ${e.hatched ? i : a}`,
		children: /* @__PURE__ */ g("span", {
			className: `wc-egg-face${e.hatched ? " is-hatched" : ""}`,
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ h(fi, { name: e.species }),
				c,
				" · ",
				e.hatched ? i : a
			]
		})
	});
}
//#endregion
//#region src/game/explorer-card-face.tsx
function gi({ id: e, lang: t }) {
	let n = Fe.find((t) => t.id === e);
	return n ? /* @__PURE__ */ g("span", {
		className: "wc-explorer-card",
		children: [/* @__PURE__ */ h("img", {
			src: o(`games/wondrouscreatures/explorers/${String(e).padStart(2, "0")}.webp`),
			alt: "",
			draggable: !1,
			loading: "lazy"
		}), /* @__PURE__ */ g("span", {
			className: "wc-explorer-card-copy",
			children: [
				/* @__PURE__ */ h("strong", { children: n.name[t] }),
				/* @__PURE__ */ h("span", { children: t === "zh" ? `开局费用：${n.cost} 份任选资源` : `Starting cost: ${n.cost} resources of your choice` }),
				/* @__PURE__ */ h("span", { children: n.ability[t] })
			]
		})]
	}) : null;
}
//#endregion
//#region src/game/explorer-draft.tsx
function _i({ pub: e, priv: t, owner: n, lang: r, send: i }) {
	let o = e.explorerPack, s = t.explorerPack, c = e.players.find((e) => e.rid === n), [l, u] = a({
		fruit: 0,
		coral: 0,
		flower: 0,
		mushroom: 0
	});
	if (!o || !s || !c || o.setupComplete) return null;
	let d = r === "zh" ? {
		choose: "选择探险者",
		waiting: "等待其他玩家选择探险者。",
		pay: "支付探险者费用",
		confirm: "确认支付",
		decrease: "减少",
		increase: "增加",
		cost: "需要支付",
		resources: "份资源"
	} : {
		choose: "Choose an explorer",
		waiting: "Waiting for the other players to choose explorers.",
		pay: "Pay the explorer cost",
		confirm: "Confirm payment",
		decrease: "Decrease",
		increase: "Increase",
		cost: "Pay",
		resources: "resources"
	};
	if (o.phase === "selecting") return s.canSelect ? /* @__PURE__ */ g("section", {
		className: "wc-draft wc-explorer-draft",
		children: [/* @__PURE__ */ h("h2", { children: d.choose }), /* @__PURE__ */ h("div", {
			className: "wc-explorer-row",
			children: s.candidates.map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => i({
					kind: "explorerCard",
					card: e
				}),
				children: /* @__PURE__ */ h(gi, {
					id: e,
					lang: r
				})
			}, e))
		})]
	}) : /* @__PURE__ */ h("p", {
		className: "wc-note",
		children: d.waiting
	});
	if (!c.drafted || s.paid || !s.selected) return null;
	let f = Fe.find((e) => e.id === s.selected);
	if (!f) return null;
	let p = (e, t) => u((n) => ({
		...n,
		[e]: n[e] + t
	}));
	return /* @__PURE__ */ g("section", {
		className: "wc-draft wc-explorer-draft",
		children: [
			/* @__PURE__ */ h("h2", { children: d.pay }),
			/* @__PURE__ */ h(gi, {
				id: f.id,
				lang: r
			}),
			/* @__PURE__ */ g("p", { children: [
				d.cost,
				" ",
				f.cost,
				" ",
				d.resources,
				" · ",
				E(l),
				"/",
				f.cost
			] }),
			/* @__PURE__ */ h("div", {
				className: "wc-explorer-payment",
				children: w.map((e) => /* @__PURE__ */ g("div", { children: [
					/* @__PURE__ */ h("strong", { children: B[e][r] }),
					/* @__PURE__ */ h("button", {
						type: "button",
						"aria-label": `${d.decrease}${B[e][r]}`,
						disabled: l[e] === 0,
						onClick: () => p(e, -1),
						children: "−"
					}),
					/* @__PURE__ */ h("span", { children: l[e] }),
					/* @__PURE__ */ h("button", {
						type: "button",
						"aria-label": `${d.increase}${B[e][r]}`,
						disabled: l[e] >= c.resources[e] || E(l) >= f.cost,
						onClick: () => p(e, 1),
						children: "+"
					})
				] }, e))
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-primary",
				disabled: E(l) !== f.cost,
				onClick: () => i({
					kind: "explorerPayment",
					payment: l
				}),
				children: d.confirm
			})
		]
	});
}
//#endregion
//#region src/game/explorer-art.tsx
function vi(e) {
	return {
		x: 57 + 90 * e.column - (e.row % 2 ? 45 : 0),
		y: 53 + 78 * e.row
	};
}
function yi(e) {
	let t = vi(e[0]), n = vi(e[1]), r = Math.min(t.x, n.x) - 40, i = Math.min(t.y, n.y) - 40;
	return {
		x: r,
		y: i,
		width: Math.abs(n.x - t.x) + 80,
		height: Math.abs(n.y - t.y) + 80,
		tail: {
			x: t.x - r,
			y: t.y - i
		},
		tip: {
			x: n.x - r,
			y: n.y - i
		}
	};
}
function bi({ cells: e, color: t, avatar: n, captain: r }) {
	let { width: i, height: a, tail: o, tip: s } = yi(e), c = s.x - o.x, l = s.y - o.y, u = Math.hypot(c, l), d = c / u, f = l / u, p = `${s.x + d * 36},${s.y + f * 36} ${s.x + d * 15 - f * 9},${s.y + f * 15 + d * 9} ${s.x + d * 15 + f * 9},${s.y + f * 15 - d * 9}`;
	return /* @__PURE__ */ g("svg", {
		width: "100%",
		height: "100%",
		viewBox: `0 0 ${i} ${a}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("line", {
				x1: o.x,
				y1: o.y,
				x2: s.x,
				y2: s.y,
				stroke: "#f9e5b9",
				strokeWidth: "55",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("line", {
				x1: o.x,
				y1: o.y,
				x2: s.x,
				y2: s.y,
				stroke: t,
				strokeWidth: "47",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("circle", {
				cx: s.x,
				cy: s.y,
				r: "20",
				fill: t,
				stroke: "#fff6d8",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("image", {
				href: _[n % _.length],
				x: s.x - 17,
				y: s.y - 17,
				width: "34",
				height: "34"
			}),
			/* @__PURE__ */ h("polygon", {
				points: p,
				fill: "#fff6d8"
			}),
			r && /* @__PURE__ */ h("text", {
				x: o.x,
				y: o.y + 7,
				className: "wc-explorer-captain",
				children: "★"
			})
		]
	});
}
function xi({ explorer: e, color: t, avatar: n, label: r }) {
	let { x: i, y: a, width: o, height: s } = yi(e.cells), { ref: c, hidden: u } = l(`wc-explorer:${e.owner}:${e.piece}`);
	return /* @__PURE__ */ h("foreignObject", {
		x: i,
		y: a,
		width: o,
		height: s,
		className: "wc-explorer",
		role: "img",
		"aria-label": r,
		children: /* @__PURE__ */ h("div", {
			ref: c,
			style: {
				width: "100%",
				height: "100%",
				visibility: u ? "hidden" : void 0
			},
			children: /* @__PURE__ */ h(bi, {
				cells: e.cells,
				color: t,
				avatar: n,
				captain: e.piece === "captain"
			})
		})
	});
}
//#endregion
//#region src/game/island-board.tsx
var Si = {
	plain: {
		zh: "平原",
		en: "Plain"
	},
	mountain: {
		zh: "山地",
		en: "Mountain"
	},
	lake: {
		zh: "湖泊",
		en: "Lake"
	},
	net: {
		zh: "网栖地",
		en: "Net habitat"
	}
}, Ci = {
	circle: "○",
	square: "□",
	triangle: "△",
	v: "∨",
	cross: "×"
}, wi = {
	gainHabitatResource: {
		zh: "获得栖地资源",
		en: "Gain a habitat resource"
	},
	flipEgg: {
		zh: "翻转一个蛋",
		en: "Flip one egg"
	},
	sweepAndTake: {
		zh: "扫荡并取得一张荒野牌",
		en: "Sweep and take a Wilderness card"
	},
	gainThreePoints: {
		zh: "获得三分",
		en: "Gain three points"
	},
	flipUpToTwoEggs: {
		zh: "翻转至多两个蛋",
		en: "Flip up to two eggs"
	},
	playCard: {
		zh: "打出一张幻兽牌",
		en: "Play a Creature card"
	},
	discardForHabitatResources: {
		zh: "弃牌并获得对应栖地资源",
		en: "Discard a card for matching resources"
	},
	drawRandomEgg: {
		zh: "从蛋袋中抽取一个蛋",
		en: "Draw an egg from the bag"
	},
	takeWildernessAndResource: {
		zh: "取得荒野牌及其栖地资源",
		en: "Take a Wilderness card and its habitat resource"
	},
	activateRechargeCard: {
		zh: "激活一张充能牌",
		en: "Activate a Recharge card"
	},
	drawTwoCards: {
		zh: "抽取两张幻兽牌",
		en: "Draw two Creature cards"
	}
}, Ti = {
	gainHabitatResource: {
		zh: "资源",
		en: "Gain"
	},
	flipEgg: {
		zh: "翻蛋",
		en: "Flip"
	},
	sweepAndTake: {
		zh: "扫荡",
		en: "Sweep"
	},
	gainThreePoints: {
		zh: "3分",
		en: "3 pts"
	},
	flipUpToTwoEggs: {
		zh: "翻蛋",
		en: "Flip"
	},
	playCard: {
		zh: "打牌",
		en: "Play"
	},
	discardForHabitatResources: {
		zh: "弃牌",
		en: "Discard"
	},
	drawRandomEgg: {
		zh: "抽蛋",
		en: "Egg"
	},
	takeWildernessAndResource: {
		zh: "荒野",
		en: "Take"
	},
	activateRechargeCard: {
		zh: "充能",
		en: "Recharge"
	},
	drawTwoCards: {
		zh: "抽牌",
		en: "Draw"
	}
};
function Ei({ board: e, eggs: t, explorers: n, members: r, lang: i, legal: a, selected: s, zoomed: c, head: l, facing: d, onSelect: f, onInspect: p, nameOf: _ }) {
	let v = new Map(t.map((e) => [R(e), e])), y = new Map(n.flatMap((e) => e.cells.map((t) => [R(t), e]))), b = Math.max(...e.map((e) => e.column)), x = Math.max(...e.map((e) => e.row)), S = 90 * (b + 1) + 54, C = 78 * (x + 1) + 36;
	return /* @__PURE__ */ h("div", {
		className: `wc-island-scroll${c ? " wc-island-scroll--zoomed" : ""}`,
		children: /* @__PURE__ */ g("svg", {
			className: "wc-island",
			viewBox: `-45 0 ${S + 45} ${C}`,
			role: "group",
			"aria-label": i === "zh" ? "神秘岛屿" : "Mysterious island",
			children: [
				/* @__PURE__ */ g("defs", { children: [/* @__PURE__ */ g("radialGradient", {
					id: "wc-sea",
					children: [/* @__PURE__ */ h("stop", { stopColor: "#4c8b88" }), /* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: "#123d4a"
					})]
				}), /* @__PURE__ */ h("filter", {
					id: "wc-land-shadow",
					children: /* @__PURE__ */ h("feDropShadow", {
						dx: "1",
						dy: "5",
						stdDeviation: "4",
						floodColor: "#071d24",
						floodOpacity: ".45"
					})
				})] }),
				/* @__PURE__ */ h("rect", {
					x: "-45",
					width: S + 45,
					height: C,
					rx: "30",
					fill: "url(#wc-sea)"
				}),
				/* @__PURE__ */ h("path", {
					d: `M 0 ${C * .22} Q ${S * .3} ${C * .1} ${S} ${C * .27} M 0 ${C * .75} Q ${S * .48} ${C * .62} ${S} ${C * .8}`,
					fill: "none",
					stroke: "#acd1c4",
					strokeOpacity: ".18",
					strokeWidth: "3"
				}),
				e.map((e) => {
					let t = R(e), n = v.get(t), r = y.get(t), c = 57 + 90 * e.column - (e.row % 2 ? 45 : 0), u = 53 + 78 * e.row, b = e.terrain === "habitat" ? e.habitat : e.terrain, x = e.terrain === "habitat" && e.habitat !== "net" ? B[e.habitat][i] : Si[b][i], S = a.has(t), C = s.has(t), w = [
						i === "zh" ? `第 ${e.row + 1} 行，第 ${e.column + 1} 列` : `Row ${e.row + 1}, column ${e.column + 1}`,
						x,
						e.terrain === "habitat" && e.special && wi[e.special][i],
						n && `${V[n.species][i]}${i === "zh" ? "的蛋" : " egg"}`,
						r && _(r.owner)
					].filter(Boolean).join(i === "zh" ? "，" : ", "), T = () => {
						S ? f({
							row: e.row,
							column: e.column
						}) : p(w);
					};
					return /* @__PURE__ */ g("g", {
						transform: `translate(${c} ${u})`,
						className: `wc-hex wc-hex--${b}${S ? " is-legal" : ""}${C ? " is-selected" : ""}${t === d ? " is-facing" : ""}`,
						role: "button",
						tabIndex: 0,
						"aria-label": w,
						"aria-pressed": S ? C : void 0,
						onClick: T,
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), T());
						},
						children: [
							/* @__PURE__ */ h("title", { children: w }),
							/* @__PURE__ */ h("path", {
								className: "wc-hex-shadow",
								d: "M0 -49 L43 -25 L43 25 L0 49 L-43 25 L-43 -25 Z"
							}),
							/* @__PURE__ */ h("path", {
								className: "wc-hex-fill",
								d: "M0 -46 L40 -23 L40 23 L0 46 L-40 23 L-40 -23 Z"
							}),
							/* @__PURE__ */ h("path", {
								className: "wc-hex-line",
								d: "M0 -46 L40 -23 L40 23 L0 46 L-40 23 L-40 -23 Z"
							}),
							e.terrain === "mountain" && /* @__PURE__ */ h("path", {
								d: "M-24 7 l8 -10 l8 10 m2 0 l8 -10 l8 10 m2 0 l8 -10 l8 10 M-24 17 l8 -10 l8 10 m2 0 l8 -10 l8 10 m2 0 l8 -10 l8 10",
								fill: "none",
								stroke: "#5f724e",
								strokeWidth: "2"
							}),
							e.terrain === "lake" && /* @__PURE__ */ h("path", {
								d: "M-23 -4 q11 6 23 0 q11 6 23 0 M-23 5 q11 6 23 0 q11 6 23 0 M-23 14 q11 6 23 0 q11 6 23 0",
								fill: "none",
								stroke: "#cde0c8",
								strokeWidth: "2"
							}),
							e.timeSymbol && e.terrain !== "habitat" && /* @__PURE__ */ h("text", {
								className: "wc-hex-symbol",
								x: "0",
								y: "-18",
								children: Ci[e.timeSymbol]
							}),
							e.terrain === "habitat" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("image", {
								href: o(`games/wondrouscreatures/icons/habitat-${e.habitat}.webp`),
								x: "-18",
								y: "-20",
								width: "36",
								height: "36"
							}), /* @__PURE__ */ h("text", {
								className: "wc-hex-label",
								x: "0",
								y: "24",
								children: x
							})] }),
							e.terrain === "habitat" && e.special && /* @__PURE__ */ h("text", {
								className: "wc-hex-special",
								x: "0",
								y: "-27",
								children: Ti[e.special][i]
							}),
							/* @__PURE__ */ g("text", {
								className: "wc-hex-coordinate",
								x: "0",
								y: "39",
								children: [
									e.row + 1,
									" · ",
									e.column + 1
								]
							}),
							n && /* @__PURE__ */ g("g", {
								transform: "translate(0 12)",
								children: [/* @__PURE__ */ h("ellipse", {
									rx: "12",
									ry: "15",
									fill: "#fff1cf",
									stroke: "#7a705a",
									strokeWidth: "2"
								}), /* @__PURE__ */ h("text", {
									className: "wc-egg-label",
									y: "4",
									children: V[n.species][i]
								})]
							}),
							t === l && /* @__PURE__ */ h("text", {
								className: "wc-hex-head",
								y: "8",
								children: i === "zh" ? "朝向端" : "Head"
							})
						]
					}, t);
				}),
				n.map((e) => {
					let t = r.find((t) => t.rid === e.owner), n = t?.colorIndex ?? (r[0]?.colorIndex ?? 0) + 1, a = u[n % u.length].hex, o = e.piece === "captain" ? i === "zh" ? "船长" : "Captain" : i === "zh" ? "探险者" : "Explorer";
					return /* @__PURE__ */ h(xi, {
						explorer: e,
						color: a,
						avatar: t?.avatar ?? 0,
						label: `${_(e.owner)} · ${o}`
					}, `${e.owner}-${e.piece}`);
				})
			]
		})
	});
}
//#endregion
//#region src/game/resolution-panel.tsx
function Di({ pub: e, priv: t, myRid: n, lang: r, send: i, selectedHabitat: o, selectedEggs: s = [], discoverySlot: c = null, selectDiscoverySlot: l, direct: u = !1 }) {
	let d = t.task, [f, p] = a([]), [_, v] = a("fruit"), [y, b] = a("coral"), [x, S] = a(1), [C, ee] = a({}), [te, E] = a(null), D = (r === "zh" ? oi : ai).ui, O = e.players.find((e) => e.rid === n);
	if (!d || !O) return null;
	let ne = (e) => {
		i({
			kind: "choose",
			choice: e
		}), p([]);
	}, k = (e) => U.get(e)?.name[r] ?? "", re = (e) => r === "zh" ? `第 ${e.row + 1} 行，第 ${e.column + 1} 列` : `Row ${e.row + 1}, column ${e.column + 1}`, A = (e, t, n = e) => /* @__PURE__ */ h("button", {
		type: "button",
		onClick: () => ne(t),
		children: e
	}, n), j = () => t.canSkip ? A(D.skip, { kind: "skip" }) : null, ie = (e) => {
		if (e.kind === "trigger") return k(e.ability.card);
		let t = e.reward;
		return t.kind === "points" ? `${t.amount} ${D.points}` : t.kind === "resources" ? `${t.amount} ${D.resources}` : t.kind === "wildernessCards" ? `${D.wilderness} ${t.amount}` : t.kind === "net" ? `${D.nets} ${t.amount}` : t.kind === "restoreEnergy" ? D.restore : t.kind === "activateAllRecharge" ? D.recharge : t.kind === "repeatAchievementReward" ? D.chooseReward : t.kind === "discovery" ? D.chooseTile : D.trophies;
	}, M = (e, t) => e.map((e) => A(k(e), t(e), e)), N = D.pending, P = null;
	switch (d.kind) {
		case "reactionOrder":
			N = D.selectOrder, P = d.reactions.map((e, t) => A(ie(e), {
				kind: "reaction",
				index: t
			}, t));
			break;
		case "activationOrder":
			N = D.selectOrder, P = d.tasks.map((e, t) => A(e.kind === "reaction" ? ie(e.reaction) : k(e.card), {
				kind: "activation",
				index: t
			}, t));
			break;
		case "chooseParts": {
			N = r === "zh" ? "选择要执行的效果" : "Choose effects to resolve";
			let e = r === "zh" ? {
				supplySpecial: "激活供应区栖地的特殊效果",
				threePoints: "获得三分",
				resource: "获得一份任选资源",
				drawTwo: "抽两张牌",
				net: "获得一个网",
				hatchResource: "孵化一个蛋并获得一份任选资源",
				discardHabitat: "弃掉一张手牌并获得对应栖地资源",
				advanceBeast: "巨兽前进一格"
			} : {
				supplySpecial: "Activate a supply habitat special effect",
				threePoints: "Gain three points",
				resource: "Gain one resource of your choice",
				drawTwo: "Draw two cards",
				net: "Gain one net",
				hatchResource: "Hatch an egg and gain a resource",
				discardHabitat: "Discard a card and gain its habitat resource",
				advanceBeast: "Advance your beast one space"
			}, n = te ?? d.parts.map((e, t) => t), i = t.effectPartsOptions.some((e) => e.length === n.length && e.every((e) => n.includes(e)));
			P = /* @__PURE__ */ g(m, { children: [d.parts.map((t, r) => /* @__PURE__ */ h("button", {
				type: "button",
				"aria-pressed": n.includes(r),
				className: n.includes(r) ? "is-selected" : "",
				onClick: () => E(n.includes(r) ? n.filter((e) => e !== r) : [...n, r]),
				children: e[t]
			}, r)), /* @__PURE__ */ h("button", {
				type: "button",
				disabled: !i,
				onClick: () => ne({
					kind: "effectParts",
					indices: n
				}),
				children: r === "zh" ? "确认" : "Confirm"
			})] });
			break;
		}
		case "resources":
			N = `${D.chooseResource} · ${d.remaining}`, P = /* @__PURE__ */ g(m, { children: [t.resourceOptions.map((e) => A(B[e][r], {
				kind: "resource",
				resource: e
			}, e)), d.optional && j()] });
			break;
		case "chooseEgg":
			N = D.chooseEgg, P = /* @__PURE__ */ g(m, { children: [d.species.filter((t) => e.eggStock[t] > 0).map((e) => A(V[e][r], {
				kind: "egg",
				species: e
			}, e)), d.optional && j()] });
			break;
		case "chooseDrawCount":
			N = r === "zh" ? "选择要抽取的牌数" : "Choose how many cards to draw", P = t.drawCountOptions.map((e) => A(r === "zh" ? `${e} 张` : `${e} cards`, {
				kind: "drawCount",
				count: e
			}, e));
			break;
		case "chooseGain": {
			let e = d.gain.kind === "points" ? D.points : d.gain.kind === "net" ? D.nets : d.gain.kind === "resource" ? B[d.gain.resource][r] : V[d.gain.species][r];
			N = r === "zh" ? d.gain.kind === "points" ? "选择获得的分数" : d.gain.kind === "egg" ? `选择获得的${e}蛋数量` : `选择获得的${e}数量` : `Choose how much ${e} to gain`;
			let n = r === "zh" ? d.gain.kind === "points" ? "分" : d.gain.kind === "resource" ? "份" : "个" : "";
			P = t.gainCountOptions.map((e) => A(`${e}${n}`, {
				kind: "gainCount",
				count: e
			}, e));
			break;
		}
		case "captainRabell":
			N = D.chooseEgg, P = d.species.filter((t) => e.eggStock[t] > 0).map((e) => A(V[e][r], {
				kind: "egg",
				species: e
			}, e));
			break;
		case "addSpecies":
			N = D.chooseSpecies, P = /* @__PURE__ */ g(m, { children: [T.filter((t) => e.eggStock[t] > 0 && !O.reserve.find((e) => e.id === d.card)?.species.includes(t)).map((e) => A(V[e][r], {
				kind: "egg",
				species: e
			}, e)), d.optional && j()] });
			break;
		case "takeSpecies":
			N = D.chooseSpecies, P = T.map((e) => A(V[e][r], {
				kind: "species",
				species: e
			}, e));
			break;
		case "scoreSpecies":
			N = D.chooseSpecies, P = U.get(d.card)?.species.map((e) => A(V[e][r], {
				kind: "species",
				species: e
			}, e));
			break;
		case "wilderness":
			N = D.chooseSlot, P = /* @__PURE__ */ g(m, { children: [u ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择荒野中高亮的牌。" : "Choose a highlighted card in the wilderness." }) : e.wilderness.flatMap((e, n) => e && t.wildernessOptions.includes(n) ? [A(k(e), {
				kind: "wilderness",
				slot: n
			}, n)] : []), d.optional && j()] });
			break;
		case "sweep":
			N = D.chooseSweep, P = /* @__PURE__ */ g(m, { children: [A(D.left, {
				kind: "sweep",
				area: "left"
			}), A(D.right, {
				kind: "sweep",
				area: "right"
			})] });
			break;
		case "lookChoice":
			N = D.chooseLook, P = /* @__PURE__ */ h("div", {
				className: "wc-look-row",
				children: d.cards.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => ne({
						kind: "lookCard",
						card: e
					}),
					children: /* @__PURE__ */ h(pi, {
						id: e,
						lang: r
					})
				}, e))
			});
			break;
		case "chooseLook":
			N = r === "zh" ? "查看牌库" : "Look at the deck", P = /* @__PURE__ */ g(m, { children: [t.canLook && A(r === "zh" ? "查看牌库顶的牌" : "Look at the top cards", { kind: "lookNow" }), j()] });
			break;
		case "drawRewards":
			N = D.drawChoice, P = /* @__PURE__ */ g(m, { children: [d.options.map((e) => A(e === "egg" ? D.eggReward : e === "resource" ? D.resourceReward : D.pointReward, {
				kind: "drawReward",
				reward: e
			}, e)), j()] });
			break;
		case "discard":
			N = D.chooseDiscard, P = /* @__PURE__ */ g(m, { children: [u ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择手牌中高亮的牌。" : "Choose a highlighted card in your hand." }) : M(t.discardOptions, (e) => ({
				kind: "discard",
				card: e
			})), d.optional && j()] });
			break;
		case "discardConfirm":
			N = `${D.confirmDiscard} · ${k(d.card)}`, P = /* @__PURE__ */ g(m, { children: [t.discardConfirmOptions.includes(null) && A(D.confirmDiscard, {
				kind: "discardConfirm",
				replacement: null
			}), d.candidates.filter((e) => t.discardConfirmOptions.includes(e)).map((e) => A(`${D.replaceDiscard} · ${k(e)}`, {
				kind: "discardConfirm",
				replacement: e
			}, e))] });
			break;
		case "playSelection":
			N = D.choosePlay, P = /* @__PURE__ */ g(m, { children: [
				u ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择高亮的幻兽牌。" : "Choose a highlighted creature card." }) : t.playOptions.map((e, t) => A(`${k(e.card)} · ${e.source.kind === "hand" ? D.hand : D.wilderness}`, {
					kind: "selectPlay",
					...e
				}, t)),
				d.optional && j(),
				d.basic && A(d.basic === "first" ? r === "zh" ? "取消打牌" : "Cancel playing" : r === "zh" ? "不再打牌" : "Finish playing", { kind: "cancelPlay" })
			] });
			break;
		case "payCard":
			N = `${D.choosePayment} · ${k(d.card)}`, P = /* @__PURE__ */ g(m, { children: [
				t.paymentOptions.length === 0 && /* @__PURE__ */ h("span", { children: r === "zh" ? "当前没有可用的支付方式。你可以使用免费行动获得资源，或使用下方可用的选项。" : "No payment is available now. You may use a free action to gain resources or use an available option below." }),
				t.paymentOptions.map((e, t) => A(w.filter((t) => e[t]).map((t) => `${B[t][r]} ${e[t]}`).join(" · ") || D.free, {
					kind: "payment",
					payment: e
				}, t)),
				t.canDiscount && A(D.discardDiscount, { kind: "discount" }),
				d.origin && d.discountDiscards === 0 && A(r === "zh" ? "重新选择牌" : "Choose another card", { kind: "cancelPlay" }),
				d.optional && d.discountDiscards === 0 && j()
			] });
			break;
		case "flipEggs": {
			N = d.mode === "flip" ? D.flipEggs : D.hatchEggs;
			let e = u ? s : f;
			P = /* @__PURE__ */ g(m, { children: [u ? /* @__PURE__ */ h("span", { children: O.eggs.some((e) => d.mode === "flip" || !e.hatched) ? r === "zh" ? "请选择蛋槽中高亮的蛋。" : "Choose highlighted eggs in your reserve." : r === "zh" ? "没有可选择的蛋，可直接确认。" : "No eggs are available; confirm to continue." }) : O.eggs.map((e, t) => /* @__PURE__ */ g("button", {
				type: "button",
				disabled: d.mode === "hatch" && e.hatched,
				className: f.includes(t) ? "is-selected" : "",
				onClick: () => p((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < d.maximum ? [...e, t] : e),
				children: [
					V[e.species][r],
					" · ",
					e.hatched ? D.hatched : D.unhatched
				]
			}, t)), /* @__PURE__ */ g("button", {
				type: "button",
				disabled: e.length < d.minimum || e.length > d.maximum,
				onClick: () => ne({
					kind: "eggs",
					indices: e
				}),
				children: [
					D.confirmEggs,
					" · ",
					e.length
				]
			})] });
			break;
		}
		case "explorer": {
			N = d.action.coveredEggs.length ? D.chooseEgg : D.chooseHabitat;
			let t = d.action.coveredEggs.map((e) => A(`${V[e.species][r]} · ${re(e)}`, {
				kind: "explorerEgg",
				position: e
			}, R(e))), n = d.action.coveredEggs.length ? [] : d.action.remainingHabitats.flatMap((t) => Oe(t, e.wilderness, (e) => U.get(e).habitat).map((e, n) => A(`${re(t)} · ${e.kind === "net" ? D.gainNet : e.kind === "resource" ? `${D.takeResource} ${B[e.resource][r]}` : `${D.takeCard} ${k(e.card)}`}`, {
				kind: "explorerHabitat",
				position: t,
				reward: e
			}, `${R(t)}-${n}`))), i = d.action.remainingHabitats.find((e) => o && R(e) === R(o)), a = i ? Oe(i, e.wilderness, (e) => U.get(e).habitat) : [], s = d.action.coveredEggs.length ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择地图上高亮的蛋。" : "Choose a highlighted egg on the map." }) : i ? /* @__PURE__ */ g(m, { children: [a.filter((e) => e.kind !== "card").map((e, t) => A(e.kind === "net" ? D.gainNet : `${D.takeResource} ${B[e.resource][r]}`, {
				kind: "explorerHabitat",
				position: i,
				reward: e
			}, t)), a.some((e) => e.kind === "card") && /* @__PURE__ */ h("span", { children: r === "zh" ? "也可选择荒野中高亮的牌。" : "You may also choose a highlighted wilderness card." })] }) : d.action.remainingHabitats.length ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择地图上高亮的栖地。" : "Choose a highlighted habitat on the map." }) : null;
			P = /* @__PURE__ */ g(m, { children: [
				u ? s : /* @__PURE__ */ g(m, { children: [t, n] }),
				O.captainUnlocked && d.action.explorer.piece === "captain" && !d.captainUsed && A(D.useCaptain, { kind: "captain" }),
				!d.action.coveredEggs.length && !d.action.remainingHabitats.length && A(D.finishExplorer, { kind: "finishExplorer" })
			] });
			break;
		}
		case "captainFreya": {
			N = D.useCaptain;
			let t = new Set(d.cells.flatMap(Te).map(R));
			P = /* @__PURE__ */ g(m, { children: [
				e.boardEggs.filter((e) => t.has(R(e))).map((e) => A(`${D.freyaEgg} · ${re(e)} · ${V[e.species][r]}`, {
					kind: "freya",
					mode: "egg",
					position: e
				}, R(e))),
				A(D.freyaFlip, {
					kind: "freya",
					mode: "flip"
				}),
				j()
			] });
			break;
		}
		case "captainMarie":
			N = d.mandatory ? D.chooseSpecial : D.useCaptain, P = /* @__PURE__ */ g(m, { children: [e.habitatDisplay.map((e, n) => {
				let i = kt.find((t) => t.id === e);
				return i && t.habitatSpecialOptions.includes(n) ? A(`${B[i.habitat][r]} · ${wi[i.special][r]}`, {
					kind: "marie",
					slot: n
				}, n) : null;
			}), !d.mandatory && j()] });
			break;
		case "chooseHatchOrFlip":
			N = r === "zh" ? "选择孵化或翻转一个蛋" : "Choose whether to hatch or flip an egg", P = /* @__PURE__ */ g(m, { children: [t.hatchOrFlipOptions.includes("hatch") && A(r === "zh" ? "孵化一个蛋，获得两份资源" : "Hatch an egg for two resources", {
				kind: "hatchOrFlip",
				mode: "hatch"
			}), t.hatchOrFlipOptions.includes("flip") && A(r === "zh" ? "翻转一个蛋，获得一份资源" : "Flip an egg for one resource", {
				kind: "hatchOrFlip",
				mode: "flip"
			})] });
			break;
		case "captainTingent":
			N = D.useCaptain, P = /* @__PURE__ */ g(m, { children: [
				d.gainAllowed !== !1 && A(D.tingentGain, {
					kind: "tingent",
					mode: "gain"
				}),
				O.energy.map((e) => {
					let t = U.get(e.card), n = t && "energyCapacity" in t ? t.energyCapacity ?? 0 : 0;
					return /* @__PURE__ */ g("label", { children: [
						k(e.card),
						" ",
						/* @__PURE__ */ h("input", {
							type: "number",
							min: "0",
							max: Math.min(O.captainEnergy, n - e.energy),
							value: C[e.card] ?? 0,
							onChange: (t) => ee({
								...C,
								[e.card]: Number(t.target.value)
							})
						})
					] }, e.card);
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					disabled: Object.values(C).reduce((e, t) => e + t, 0) > O.captainEnergy,
					onClick: () => ne({
						kind: "tingent",
						mode: "distribute",
						allocations: Object.entries(C).filter(([, e]) => e > 0).map(([e, t]) => ({
							card: Number(e),
							amount: t
						}))
					}),
					children: D.tingentDistribute
				}),
				j()
			] });
			break;
		case "captainMorgane": {
			N = r === "zh" ? "选择要复制的船长能力" : "Choose a captain power to copy";
			let t = new Set(d.cells.flatMap(Te).map(R)), i = [...new Set(e.explorers.filter((e) => e.owner !== n && e.cells.some((e) => t.has(R(e)))).map((e) => e.owner))].flatMap((t) => t === "$tingent" ? e.soloCaptainOptions.map((e) => ({
				owner: t,
				captain: e
			})) : e.players.flatMap((e) => e.rid === t && e.captain ? [{
				owner: t,
				captain: e.captain
			}] : []));
			P = /* @__PURE__ */ g(m, { children: [i.filter((e) => e.captain !== "morgane" && (e.captain !== "helena" || !d.paidMountain)).map((e) => A(Dt.find((t) => t.id === e.captain)?.name[r] ?? "", {
				kind: "captainCopy",
				...e
			}, `${e.owner}-${e.captain}`)), j()] });
			break;
		}
		case "timeEggs": {
			N = D.timeEgg;
			let t = new Set([...e.boardEggs, ...e.explorers.flatMap((e) => e.cells)].map(R));
			P = u ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择地图上高亮的位置。" : "Choose a highlighted position on the map." }) : e.board.filter((e) => e.timeSymbol === d.symbol && e.terrain !== "habitat" && !t.has(R(e))).map((e) => A(re(e), {
				kind: "timeEgg",
				position: e
			}, R(e)));
			break;
		}
		case "basicPlay":
			N = d.first ? D.choosePlay : D.playAnother, P = /* @__PURE__ */ g(m, { children: [A(D.yes, {
				kind: "basicPlay",
				play: !0
			}), !d.first && A(D.no, {
				kind: "basicPlay",
				play: !1
			})] });
			break;
		case "chooseMapSpecial":
			N = D.chooseSpecial, P = u ? /* @__PURE__ */ h("span", { children: r === "zh" ? "请选择地图上高亮的栖地。" : "Choose a highlighted habitat on the map." }) : e.board.flatMap((e) => e.terrain === "habitat" && e.special && t.mapSpecialOptions.some((t) => R(t) === R(e)) ? [A(`${re(e)} · ${wi[e.special][r]}`, {
				kind: "mapSpecial",
				position: e
			}, R(e))] : []);
			break;
		case "chooseEndScore":
			N = D.chooseEndCard, P = M(O.reserve.filter((e) => e.type === "endGame").map((e) => e.id), (e) => ({
				kind: "endCard",
				card: e
			}));
			break;
		case "chooseEndCopy":
			N = D.chooseCopy, P = M(d.targets, (e) => ({
				kind: "endCard",
				card: e
			}));
			break;
		case "chooseAchievementReward":
			N = D.chooseReward, P = e.claims.filter((e) => e.owner === n && e.usedMarkerReward).map((e) => A(ie({
				kind: "reward",
				reward: e.reward
			}), {
				kind: "achievementReward",
				marker: e.marker
			}, e.marker));
			break;
		case "restoreEnergy":
			N = D.restore, P = M(O.energy.map((e) => e.card), (e) => ({
				kind: "energy",
				card: e
			}));
			break;
		case "chooseRecharge":
			N = D.chooseRecharge, P = /* @__PURE__ */ g(m, { children: [M(t.rechargeOptions, (e) => ({
				kind: "recharge",
				card: e
			})), d.optional && j()] });
			break;
		case "cardEffect":
			N = `${D.activate} · ${k(d.card)}`, P = /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("p", { children: U.get(d.card)?.ability[r] }),
				t.effectOptions.includes(!0) && A(D.use, {
					kind: "cardEffect",
					use: !0
				}),
				t.effectOptions.includes(!1) && A(D.decline, {
					kind: "cardEffect",
					use: !1
				})
			] });
			break;
		case "discovery":
			N = D.chooseTile, P = u ? /* @__PURE__ */ g(m, { children: [e.habitatDisplay.map((e, t) => {
				let n = kt.find((t) => t.id === e);
				return n ? /* @__PURE__ */ g("button", {
					type: "button",
					className: t === c ? "is-selected" : "",
					"aria-pressed": t === c,
					onClick: () => l?.(t),
					children: [
						B[n.habitat][r],
						" · ",
						wi[n.special][r]
					]
				}, t) : null;
			}), /* @__PURE__ */ h("span", { children: r === "zh" ? "选择板块后，在地图上选择湖泊。" : "Choose a tile, then a lake on the map." })] }) : e.habitatDisplay.flatMap((t, n) => {
				let i = kt.find((e) => e.id === t);
				return i ? e.board.filter((e) => e.terrain === "lake").map((e) => A(`${B[i.habitat][r]} · ${wi[i.special][r]} · ${re(e)}`, {
					kind: "discovery",
					slot: n,
					position: e
				}, `${n}-${R(e)}`)) : [];
			});
			break;
		case "exchange": N = D.chooseExchange, P = /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ g("label", { children: [D.from, /* @__PURE__ */ h("select", {
				value: _,
				onChange: (e) => v(e.target.value),
				children: w.map((e) => /* @__PURE__ */ h("option", {
					value: e,
					children: B[e][r]
				}, e))
			})] }),
			/* @__PURE__ */ g("label", { children: [D.to, /* @__PURE__ */ h("select", {
				value: y,
				onChange: (e) => b(e.target.value),
				children: w.map((e) => /* @__PURE__ */ h("option", {
					value: e,
					children: B[e][r]
				}, e))
			})] }),
			/* @__PURE__ */ g("label", { children: [D.amount, /* @__PURE__ */ h("input", {
				type: "number",
				min: "1",
				max: O.resources[_],
				value: x,
				onChange: (e) => S(Number(e.target.value))
			})] }),
			/* @__PURE__ */ h("button", {
				type: "button",
				disabled: _ === y || x < 1 || x > O.resources[_],
				onClick: () => ne({
					kind: "exchange",
					from: _,
					to: y,
					amount: x
				}),
				children: D.exchange
			}),
			j()
		] });
	}
	return /* @__PURE__ */ g("section", {
		className: `wc-decision${u ? " wc-decision--direct" : ""}${d.kind === "lookChoice" ? " wc-decision--look" : ""}`,
		role: "region",
		"aria-label": N,
		children: [/* @__PURE__ */ h("h3", { children: N }), /* @__PURE__ */ h("div", {
			className: "wc-choice-row",
			children: P
		})]
	});
}
//#endregion
//#region src/game/view-player.tsx
function Oi(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(Li, {
		...e,
		pub: t,
		priv: n
	});
}
function ki({ owner: e, id: t, species: n, energy: r, lang: i, inspect: a }) {
	let { ref: o, hidden: s } = l(`wc-reserve:${e}:${t}`);
	return /* @__PURE__ */ h("button", {
		type: "button",
		ref: o,
		style: { visibility: s ? "hidden" : void 0 },
		onClick: a,
		children: /* @__PURE__ */ h(pi, {
			id: t,
			lang: i,
			compact: !0,
			species: n,
			currentEnergy: r
		})
	});
}
function Ai({ owner: e, id: t, lang: n, choice: r, inspect: i }) {
	let { ref: a, hidden: o } = l(`wc-hand-card:${e}:${t}`);
	return /* @__PURE__ */ g("button", {
		type: "button",
		ref: a,
		style: { visibility: o ? "hidden" : void 0 },
		className: r ? "wc-card-choice" : void 0,
		onClick: i,
		children: [/* @__PURE__ */ h(pi, {
			id: t,
			lang: n,
			compact: !0
		}), r && /* @__PURE__ */ h(Pi, {})]
	});
}
function ji({ slot: e, id: t, lang: n, choice: r, inspect: i }) {
	let { ref: a } = l(`wc-wilderness-slot:${e}`);
	return t === null ? /* @__PURE__ */ h("span", {
		ref: a,
		className: "wc-empty-card"
	}) : /* @__PURE__ */ g("button", {
		type: "button",
		ref: a,
		className: r ? "wc-card-choice" : void 0,
		onClick: i,
		children: [/* @__PURE__ */ h(pi, {
			id: t,
			lang: n,
			compact: !0
		}), r && /* @__PURE__ */ h(Pi, {})]
	});
}
function Mi({ beast: e, lang: t, energyLabel: n }) {
	let { ref: r } = l(`wc-beast:${e.owner}`);
	return /* @__PURE__ */ g("div", {
		ref: r,
		children: [
			/* @__PURE__ */ h("h3", { children: t === "zh" ? "巨兽" : "Beast" }),
			/* @__PURE__ */ h(ui, {
				id: e.id,
				lang: t
			}),
			/* @__PURE__ */ g("p", { children: [e.awake ? t === "zh" ? "已唤醒" : "Awakened" : /* @__PURE__ */ g(m, { children: [
				t === "zh" ? "沉睡 · 进度 " : "Sleeping · ",
				/* @__PURE__ */ h(d, { value: e.progress }),
				"/4"
			] }), e.awake && (e.id === 1 || e.id === 2) ? ` · ${n} ${e.energy}` : ""] })
		]
	});
}
function Ni({ rid: e, label: t, open: n }) {
	let { ref: r } = l(`wc-reserve-entry:${e}`);
	return /* @__PURE__ */ h("button", {
		type: "button",
		ref: r,
		className: "wc-reserve-entry",
		onClick: n,
		children: t
	});
}
function Pi() {
	return /* @__PURE__ */ h("svg", {
		className: "wc-choice-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5"
		})
	});
}
function Fi(e, t) {
	return e.kind === "points" ? t === "zh" ? `${e.amount} 分` : `${e.amount} ${e.amount === 1 ? "point" : "points"}` : e.kind === "resources" ? t === "zh" ? `${e.amount} 份资源` : `${e.amount} ${e.amount === 1 ? "resource" : "resources"}` : e.kind === "wildernessCards" ? t === "zh" ? `${e.amount} 张荒野牌` : `${e.amount} wilderness ${e.amount === 1 ? "card" : "cards"}` : "";
}
function Ii({ owner: e, goal: t, slot: n }) {
	let { ref: r } = l(`wc-goal:${t}:${n}`);
	return /* @__PURE__ */ h("span", {
		ref: r,
		className: "wc-claim-name",
		children: e
	});
}
function Li({ pub: e, priv: t, members: r, myRid: _, send: v }) {
	let y = s((e) => e.locale), b = c(), x = y === "zh" ? "zh" : "en", S = (x === "zh" ? oi : ai).ui, { ref: C } = l("wc-banner"), { ref: ee } = l("wc-hand"), { ref: te } = l("wc-wilderness"), D = i(null), O = {
		gainNet: S.timeGainNet,
		sweepAll: S.timeSweep,
		removeTrophy: S.timeRemoveTrophy
	}, ne = {
		circle: "○",
		square: "□",
		triangle: "△",
		v: "∨",
		cross: "×"
	}, [k, re] = a({
		observer: _,
		target: _
	}), A = k.observer === _ ? k.target : _, j = (e) => re({
		observer: _,
		target: e
	}), [ie, M] = a(!1), [N, P] = a(null), [ae, oe] = a(null), ce = ae?.owner === _ ? ae.card : null, [le, F] = a(null), [ue, fe] = a(null), [pe, me] = a(null), [he, ge] = a(null), [ve, ye] = a(null), [be, xe] = a(null);
	n(() => () => {
		oe(null), F(null), fe(null);
	}, [_]);
	let I = e.players.find((e) => e.rid === _), L = e.resolution?.owner === _ && t?.task?.kind === "flipEggs" ? I : e.players.find((e) => e.rid === A) ?? I, Se = e.beasts?.players.find((e) => e.owner === L?.rid && e.awake), Ce = Se ? _e.find((e) => e.id === Se.id)?.species ?? [] : [], we = ce === null ? void 0 : e.players.flatMap((e) => e.reserve.map((t) => ({
		card: t,
		energy: e.energy.find((e) => e.card === t.id)?.energy
	}))).find((e) => e.card.id === ce), De = (t) => {
		if (t === "$tingent") return x === "zh" ? "汀詹特" : "Tingent";
		let n = r.find((e) => e.rid === t);
		if (n) return p(n, y);
		let i = e.players.find((e) => e.rid === t)?.seat ?? 0;
		return b(u[i % u.length].nameKey);
	}, Ae = e.phase === "turn" && e.activePlayer === _, je = e.resolution?.owner === _ && !t?.task, Me = Ae && !e.resolution && !e.basicAction;
	n(() => () => {
		Me && fe(null);
	}, [Me]), n(() => () => {
		Ae && F(null);
	}, [Ae]);
	let z = ue?.owner === _ && Me ? ue : null, Pe = le?.owner === _ && Ae ? le.kind : null, Fe = Ee(e.board, e.explorers.flatMap((e) => e.cells)), Ie = z?.cells[0], Le = Ie ? Fe.filter((e) => e.cells.some((e) => R(e) === R(Ie))) : Fe, Re = t?.soloChoices ?? [], ze = JSON.stringify(Re), Be = be?.owner === _ && be.key === ze ? be.cells : [], Ve = Be[0], He = Re.filter((e) => e.kind === "placement" && (!Ve || e.cells.some((e) => R(e) === R(Ve)))), Ue = Re.find((e) => e.kind === "placement" ? Be.length === 2 && e.cells.every((e) => Be.some((t) => R(t) === R(e))) : Be.length === 1 && R(e.position) === R(Be[0])), H = e.resolution?.owner === _ ? t?.task : null, We = H && [
		"explorer",
		"wilderness",
		"playSelection",
		"discard",
		"flipEggs",
		"timeEggs",
		"chooseMapSpecial",
		"discovery",
		"lookChoice"
	].includes(H.kind), Ge = JSON.stringify(H ?? null), Ke = H?.kind === "flipEggs" && he?.owner === _ && he.task === Ge ? he.indices : [], qe = H?.kind === "discovery" && ve?.owner === _ && e.habitatDisplay[ve.slot] != null ? ve.slot : null, Je = H?.kind === "explorer" && pe?.owner === _ ? H.action.remainingHabitats.find((e) => R(e) === R(pe.position)) : void 0, Ye = new Set([...e.boardEggs, ...e.explorers.flatMap((e) => e.cells)].map(R)), Xe = new Set(Re.length ? Re[0].kind === "placement" ? He.flatMap((e) => e.kind === "placement" ? e.cells.map(R) : []) : Re.flatMap((e) => e.kind === "timeEgg" ? [R(e.position)] : []) : z ? Le.flatMap((e) => e.cells.map(R)) : H?.kind === "explorer" ? (H.action.coveredEggs.length ? H.action.coveredEggs : H.action.remainingHabitats).map(R) : H?.kind === "timeEggs" ? e.board.filter((e) => e.timeSymbol === H.symbol && e.terrain !== "habitat" && !Ye.has(R(e))).map(R) : H?.kind === "chooseMapSpecial" ? (t?.mapSpecialOptions ?? []).map(R) : H?.kind === "discovery" && qe !== null ? e.board.filter((e) => e.terrain === "lake").map(R) : []), Ze = new Set(Re.length ? Be.map(R) : z?.cells.map(R) ?? (Je ? [R(Je)] : [])), Qe = z?.cells.length === 2 ? Fe.find((e) => e.cells.every((e) => Ze.has(R(e)))) : void 0, $e = new Set(z?.cells.flatMap(Te).map(R) ?? []), et = z?.piece === "captain" && I?.captain === "morgane" && I.captainUnlocked ? e.explorers.find((t) => t.owner !== _ && t.cells.some((e) => $e.has(R(e))) && (t.owner === "$tingent" ? e.soloCaptainOptions.includes("helena") : e.players.some((e) => e.rid === t.owner && e.captain === "helena")))?.owner : void 0, tt = z?.piece === "captain" && I?.captain === "macus" && I.captainUnlocked, nt = tt && z?.cells.length === 2 ? R(Ne(z.cells)) : void 0, rt = !!I && (I.captain === "helena" && I.captainUnlocked && z?.piece === "captain" || !!et && z?.copyHelenaOwner === et || E(I.resources) === 0 && Fe.length === 1), it = !!Qe?.mountainCost && !rt, at = (e) => {
		if (Re.length) {
			let t = R(e), n = Re[0].kind === "timeEgg" ? [e] : Ze.has(t) ? Be.filter((e) => R(e) !== t) : Be.length >= 2 ? [e] : [...Be, e];
			xe({
				owner: _,
				key: ze,
				cells: n
			});
			return;
		}
		if (!z) {
			H?.kind === "explorer" ? H.action.coveredEggs.some((t) => R(t) === R(e)) ? v({
				kind: "choose",
				choice: {
					kind: "explorerEgg",
					position: e
				}
			}) : !H.action.coveredEggs.length && H.action.remainingHabitats.some((t) => R(t) === R(e)) && me({
				owner: _,
				position: e
			}) : H?.kind === "timeEggs" ? v({
				kind: "choose",
				choice: {
					kind: "timeEgg",
					position: e
				}
			}) : H?.kind === "chooseMapSpecial" ? v({
				kind: "choose",
				choice: {
					kind: "mapSpecial",
					position: e
				}
			}) : H?.kind === "discovery" && qe !== null && (ye(null), v({
				kind: "choose",
				choice: {
					kind: "discovery",
					slot: qe,
					position: e
				}
			}));
			return;
		}
		let t = R(e), n = Ze.has(t) ? z.cells.filter((e) => R(e) !== t) : z.cells.length >= 2 ? [e] : [...z.cells, e];
		fe({
			...z,
			cells: n,
			payment: null,
			copyHelenaOwner: null
		});
	}, ot = (e) => H?.kind === "discard" && t?.discardOptions.includes(e) ? {
		kind: "discard",
		card: e
	} : H?.kind === "playSelection" ? (() => {
		let n = t?.playOptions.find((t) => t.card === e && t.source.kind === "hand");
		return n ? {
			kind: "selectPlay",
			...n
		} : null;
	})() : null, st = (n, r) => {
		if (H?.kind === "wilderness" && t?.wildernessOptions.includes(r)) return {
			kind: "wilderness",
			slot: r
		};
		if (H?.kind === "playSelection") {
			let e = t?.playOptions.find((e) => e.card === n && e.source.kind === "wilderness" && e.source.slot === r);
			return e ? {
				kind: "selectPlay",
				...e
			} : null;
		}
		if (H?.kind === "explorer" && Je) {
			let t = Oe(Je, e.wilderness, (e) => U.get(e).habitat).find((e) => e.kind === "card" && e.slot === r && e.card === n);
			return t ? {
				kind: "explorerHabitat",
				position: Je,
				reward: t
			} : null;
		}
		return null;
	}, ct = (e) => {
		H?.kind === "flipEggs" && j(_), me(null), ge(null), ye(null), v(e);
	}, lt = ce === null ? null : ae?.source === "hand" ? ot(ce) : ae?.source === "wilderness" && ae.slot !== void 0 ? st(ce, ae.slot) : null, ut = We && t ? /* @__PURE__ */ h(Di, {
		pub: e,
		priv: t,
		myRid: _,
		lang: x,
		send: ct,
		selectedHabitat: Je,
		selectedEggs: Ke,
		discoverySlot: qe,
		selectDiscoverySlot: (e) => ye({
			owner: _,
			slot: e
		}),
		direct: !0
	}, `${_}-${JSON.stringify(t.task)}`) : null, dt = e.phase === "draft" ? S.draft : e.phase === "endGame" ? S.final : Ae ? S.turn : e.solo && t?.soloChoices.length ? S.pending : S.waiting, ft = I ? ke(e.board, e.explorers.filter((e) => e.owner === _).map((e) => e.cells), e.boardEggs, e.usedNetSpecials) : [], pt = I?.energy.filter((n) => {
		let r = U.get(n.card);
		return n.energy > 0 && !e.usedEnergy.includes(n.card) && r?.effect.kind !== "energyPlayInsteadOfDiscard" && (r?.effect.kind !== "energyEmptyHandDrawFour" && r?.effect.kind !== "energyEmptyHandDrawEggs" || !t?.hand.length);
	}) ?? [], W = e.explorerPack?.players.find((e) => e.owner === _), mt = !!W?.selected && !W.used && !!e.explorerPack?.setupComplete, ht = e.explorers.filter((e) => e.owner === _), gt = e.beasts?.players.find((e) => e.owner === _), _t = !!gt?.awake && gt.energy > 0 && !gt.usedThisTurn, vt = _t && (gt.id === 1 && !!I?.nets && (e.wilderness.some((e) => e !== null) || e.deckCount + e.discard.length > 0) || gt.id === 2 && (!!t?.hand.length || (t?.hand.length ?? 0) < 3 && e.deckCount + e.discard.length > 0)), yt = ht.find((e) => e.piece === "captain"), bt = new Set(yt?.cells.flatMap(Te).map(R) ?? []), xt = [...new Set(e.explorers.filter((e) => e.owner !== _ && e.cells.some((e) => bt.has(R(e)))).map((e) => e.owner))].flatMap((t) => t === "$tingent" ? e.soloCaptainOptions : e.players.flatMap((e) => e.rid === t && e.captain ? [e.captain] : [])), St = I?.captain === "ashe" || I?.captain === "morgane" && xt.includes("ashe"), Ct = I?.captain === "nathaniel" || I?.captain === "morgane" && xt.includes("nathaniel"), wt = !!I?.captainUnlocked && (St && I.captainEnergy >= 1 && e.discard.length > 0 || Ct && I.captainEnergy >= 1), Tt = (e, t) => {
		v({
			kind: "captainPower",
			mode: e,
			...I?.captain === "morgane" ? { copyCaptain: t } : {}
		}), F(null);
	}, Et = mt && (W.selected === 1 || W.selected === 3 || W.selected === 7 || W.selected === 2 && !!I?.energy.length || W.selected === 5 && !!I?.reserve.some((e) => e.type === "recharge") || W.selected === 6 && ht.length > 0), Ot = e.finalChoice?.owner === _ ? /* @__PURE__ */ g("section", {
		className: "wc-decision",
		children: [/* @__PURE__ */ h("h3", { children: S.chooseCopy }), /* @__PURE__ */ h("div", {
			className: "wc-choice-row",
			children: e.finalChoice.targets.map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => v({
					kind: "scoreCopy",
					target: e
				}),
				children: U.get(e)?.name[x]
			}, e))
		})]
	}) : Pe === "goals" && Me ? /* @__PURE__ */ h(li, {
		pub: e,
		myRid: _,
		lang: x,
		send: v,
		close: () => F(null)
	}, _) : Pe === "beast" && Me ? /* @__PURE__ */ h(di, {
		pub: e,
		owner: _,
		lang: x,
		send: v,
		close: () => F(null)
	}, `${_}-beast`) : Pe === "explorerGoal" && mt && W?.selected === 1 ? /* @__PURE__ */ h(li, {
		pub: e,
		myRid: _,
		lang: x,
		send: v,
		close: () => F(null),
		freeExplorer: !0
	}, `${_}-explorer`) : Pe === "free" && I && !je ? /* @__PURE__ */ g("section", {
		className: "wc-decision",
		"aria-label": S.freeActions,
		children: [/* @__PURE__ */ g("div", {
			className: "wc-section-title",
			children: [/* @__PURE__ */ h("h3", { children: S.freeActions }), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => F(null),
				children: S.close
			})]
		}), /* @__PURE__ */ g("div", {
			className: "wc-choice-row",
			children: [
				I.nets > 0 && ft.map((e, t) => {
					let n = e.kind === "egg" ? e.position : e.cell, r = e.kind === "egg" ? `${S.chooseEgg} · ${V[e.species][x]}` : e.cell.special ? wi[e.cell.special][x] : S.chooseSpecial;
					return /* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => {
							v({
								kind: "net",
								target: {
									kind: e.kind,
									position: {
										row: n.row,
										column: n.column
									}
								}
							}), F(null);
						},
						children: [
							S.useNet,
							" · ",
							r,
							" · ",
							n.row + 1,
							" / ",
							n.column + 1
						]
					}, t);
				}),
				pt.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "energy",
							card: e.card
						}), F(null);
					},
					children: [
						S.useEnergy,
						" · ",
						U.get(e.card)?.name[x]
					]
				}, e.card)),
				Et && W?.selected === 1 && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => F({
						owner: _,
						kind: "explorerGoal"
					}),
					children: x === "zh" ? "使用探险者能力：完成目标" : "Use explorer power: complete an achievement"
				}),
				Et && W?.selected === 6 && ht.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "explorerPower",
							choice: {
								kind: "returnExplorer",
								piece: e.piece
							}
						}), F(null);
					},
					children: [
						x === "zh" ? "收回" : "Retrieve",
						" · ",
						e.piece === "captain" ? S.captainPiece : S[e.piece]
					]
				}, e.piece)),
				Et && W?.selected !== 1 && W?.selected !== 6 && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "explorerPower",
							choice: { kind: "activate" }
						}), F(null);
					},
					children: x === "zh" ? "使用探险者能力" : "Use explorer power"
				}),
				_t && gt?.id === 1 && I.nets > 0 && e.wilderness.some((e) => e !== null) && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "beastPower",
							mode: "wilderness"
						}), F(null);
					},
					children: x === "zh" ? "巨兽能力：免费打出荒野牌" : "Beast power: play from the wilderness for free"
				}),
				_t && gt?.id === 1 && I.nets > 0 && e.deckCount + e.discard.length > 0 && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "beastPower",
							mode: "look"
						}), F(null);
					},
					children: x === "zh" ? "巨兽能力：查看四张牌并免费打出" : "Beast power: look at four cards and play one for free"
				}),
				_t && gt?.id === 2 && !!t?.hand.length && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "beastPower",
							mode: "discard"
						}), F(null);
					},
					children: x === "zh" ? "巨兽能力：弃掉手牌" : "Beast power: discard cards"
				}),
				_t && gt?.id === 2 && (t?.hand.length ?? 0) < 3 && e.deckCount + e.discard.length > 0 && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => {
						v({
							kind: "beastPower",
							mode: "draw"
						}), F(null);
					},
					children: x === "zh" ? "巨兽能力：抽牌至三张" : "Beast power: draw up to three cards"
				}),
				wt && St && e.discard.length > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => Tt("takeDiscard", "ashe"),
					children: x === "zh" ? "消耗一枚船长能量，取得弃牌堆顶牌" : "Spend one captain energy to take the top discard"
				}), I.captainEnergy >= 2 && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => Tt("takeDiscardResource", "ashe"),
					children: x === "zh" ? "消耗两枚船长能量，取得弃牌并获得对应资源" : "Spend two captain energy to take the discard and a matching resource"
				})] }),
				wt && Ct && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => Tt("resource", "nathaniel"),
					children: x === "zh" ? "消耗一枚船长能量，获得资源" : "Spend one captain energy to gain a resource"
				}), I.captainEnergy >= 3 && !!t?.hand.length && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => Tt("play", "nathaniel"),
					children: x === "zh" ? "消耗三枚船长能量，免费打出手牌" : "Spend three captain energy to play a hand card for free"
				})] }),
				(I.nets === 0 || ft.length === 0) && pt.length === 0 && !Et && !vt && !wt && /* @__PURE__ */ h("span", { children: S.noTargets })
			]
		})]
	}) : e.resolution?.owner === _ && t && !We ? /* @__PURE__ */ h(Di, {
		pub: e,
		priv: t,
		myRid: _,
		lang: x,
		send: v
	}, `${_}-${JSON.stringify(t.task)}`) : null, At = z && /* @__PURE__ */ g("section", {
		className: "wc-placement",
		"aria-label": S.choosePiece,
		children: [
			/* @__PURE__ */ h("strong", { children: S.choosePiece }),
			[
				"captain",
				"explorerA",
				"explorerB"
			].map((t) => /* @__PURE__ */ h("button", {
				type: "button",
				disabled: e.explorers.some((e) => e.owner === _ && e.piece === t),
				className: t === z.piece ? "is-selected" : "",
				onClick: () => fe({
					...z,
					piece: t,
					copyHelenaOwner: null
				}),
				children: t === "captain" ? S.captainPiece : S[t]
			}, t)),
			/* @__PURE__ */ h("span", { children: S.chooseCells }),
			tt && /* @__PURE__ */ h("span", { children: S.macusDirection }),
			Qe?.mountainCost && et && /* @__PURE__ */ h("button", {
				type: "button",
				"aria-pressed": z.copyHelenaOwner === et,
				className: z.copyHelenaOwner === et ? "is-selected" : "",
				onClick: () => fe({
					...z,
					payment: null,
					copyHelenaOwner: z.copyHelenaOwner ? null : et
				}),
				children: x === "zh" ? "复制海伦娜，免付山地费用" : "Copy Helena to waive the mountain cost"
			}),
			it && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: S.mountainPayment }), w.map((e) => /* @__PURE__ */ h("button", {
				type: "button",
				disabled: !I?.resources[e],
				className: z.payment === e ? "is-selected" : "",
				onClick: () => fe({
					...z,
					payment: e
				}),
				children: B[e][x]
			}, e))] }),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-primary",
				disabled: !Qe || it && !z.payment || e.explorers.some((e) => e.owner === _ && e.piece === z.piece),
				onClick: () => {
					z.cells.length === 2 && (v({
						kind: "explore",
						piece: z.piece,
						cells: z.cells,
						payment: it ? z.payment : null,
						...z.copyHelenaOwner ? { copyHelenaOwner: z.copyHelenaOwner } : {}
					}), fe(null));
				},
				children: S.place
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => fe(null),
				children: S.cancel
			})
		]
	}), jt = Re.length > 0 && /* @__PURE__ */ g("section", {
		className: "wc-placement",
		"aria-label": x === "zh" ? "为汀詹特选择位置" : "Choose a position for Tingent",
		children: [
			/* @__PURE__ */ h("strong", { children: x === "zh" ? "为汀詹特选择位置" : "Choose a position for Tingent" }),
			e.solo?.pendingPlacement && /* @__PURE__ */ g("span", { children: [
				e.solo.pendingPlacement.piece === "captain" ? S.captainPiece : x === "zh" ? "探险者" : "Explorer",
				" · ",
				B[e.solo.pendingPlacement.habitat][x],
				x === "zh" ? "栖地" : " habitat"
			] }),
			/* @__PURE__ */ h("span", { children: Re[0].kind === "placement" ? S.chooseCells : S.timeEgg }),
			Be.length > 0 && /* @__PURE__ */ h("span", { children: Be.map((e) => `${e.row + 1} / ${e.column + 1}`).join(" + ") }),
			/* @__PURE__ */ h("button", {
				type: "button",
				disabled: !Be.length,
				onClick: () => xe(null),
				children: x === "zh" ? "清除选择" : "Clear selection"
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-primary",
				disabled: !Ue,
				onClick: () => {
					Ue && (v({
						kind: "soloChoose",
						choice: Ue
					}), xe(null));
				},
				children: S.confirm
			})
		]
	});
	return /* @__PURE__ */ g(f, {
		adaptive: !0,
		className: "wc-game",
		actionsHeight: "wc-bottom",
		overlay: Ot,
		banner: /* @__PURE__ */ g("div", {
			className: "wc-banner",
			ref: C,
			children: [/* @__PURE__ */ g("div", {
				className: "wc-heading",
				children: [/* @__PURE__ */ h("strong", { children: x === "zh" ? oi.name : ai.name }), /* @__PURE__ */ g("span", { children: [dt, e.activePlayer ? ` · ${De(e.activePlayer)}` : ""] })]
			}), I && /* @__PURE__ */ g("div", {
				className: "wc-mobile-resources",
				"aria-label": S.resources,
				children: [w.map((e) => /* @__PURE__ */ g("span", {
					"aria-label": `${B[e][x]} ${I.resources[e]}`,
					children: [/* @__PURE__ */ h(fi, { name: e }), /* @__PURE__ */ h(d, { value: I.resources[e] }, `${_}-${e}`)]
				}, e)), /* @__PURE__ */ g("span", {
					"aria-label": `${S.nets} ${I.nets}`,
					children: [/* @__PURE__ */ h(fi, { name: "net" }), /* @__PURE__ */ h(d, { value: I.nets }, `${_}-nets`)]
				})]
			})]
		}),
		actions: /* @__PURE__ */ h("div", {
			className: "wc-action-bar",
			children: jt || At || /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
				className: "wc-actions",
				children: [
					Me && /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => fe({
								owner: _,
								piece: "captain",
								cells: [],
								payment: null,
								copyHelenaOwner: null
							}),
							children: S.explore
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => v({ kind: "playCards" }),
							children: S.playCards
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => F({
								owner: _,
								kind: "goals"
							}),
							children: S.achievement
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => v({ kind: "recharge" }),
							disabled: ht.length < (e.beasts?.players.some((e) => e.owner === _ && e.id === 7 && e.awake) ? 2 : 3),
							children: S.recharge
						}),
						e.beasts && !gt && /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !e.beasts.supply.length || (I?.eggs.filter((e) => !e.hatched).length ?? 0) < 4,
							onClick: () => F({
								owner: _,
								kind: "beast"
							}),
							children: x === "zh" ? "获得巨兽" : "Gain a beast"
						})
					] }),
					Ae && /* @__PURE__ */ h("button", {
						type: "button",
						disabled: je,
						onClick: () => F({
							owner: _,
							kind: "free"
						}),
						children: S.freeActions
					}),
					Ae && !e.resolution && e.basicAction?.resolved && /* @__PURE__ */ h("button", {
						type: "button",
						className: "wc-primary",
						onClick: () => v({ kind: "finishTurn" }),
						children: S.finishTurn
					}),
					!Ae && e.phase === "turn" && /* @__PURE__ */ h("span", { children: S.waiting })
				]
			}), /* @__PURE__ */ g("div", {
				className: "wc-hand",
				ref: ee,
				children: [/* @__PURE__ */ g("div", {
					className: "wc-hand-heading",
					children: [/* @__PURE__ */ g("strong", { children: [
						S.hand,
						" · ",
						t?.hand.length ?? 0
					] }), /* @__PURE__ */ h(Ni, {
						rid: _,
						label: S.myReserve,
						open: () => {
							j(_), D.current?.scrollIntoView({
								block: "start",
								behavior: "auto"
							});
						}
					})]
				}), /* @__PURE__ */ h("div", {
					className: "wc-hand-row",
					children: t?.hand.map((e) => {
						let t = ot(e);
						return /* @__PURE__ */ h(Ai, {
							owner: _,
							id: e,
							lang: x,
							choice: !!t,
							inspect: () => oe({
								owner: _,
								card: e,
								...t ? { source: "hand" } : {}
							})
						}, e);
					})
				})]
			})] })
		}),
		children: [
			/* @__PURE__ */ g("div", {
				className: "wc-table",
				style: { "--wc-scenery": `url("${o("games/wondrouscreatures/art/024.webp")}")` },
				children: [
					H?.kind !== "flipEggs" && ut,
					e.phase === "draft" && t?.explorerPack && /* @__PURE__ */ h(_i, {
						pub: e,
						priv: t,
						owner: _,
						lang: x,
						send: v
					}, `${_}-explorer`),
					e.phase === "draft" && I && !I.drafted && t && (!e.explorerPack || e.explorerPack.phase !== "selecting" || e.explorerPack.mode === "simultaneous") && /* @__PURE__ */ h(mi, {
						priv: t,
						seat: I.seat,
						lang: x,
						send: v
					}, _),
					e.phase === "draft" && I?.drafted && (!t?.explorerPack || t.explorerPack.paid) && !e.resolution && /* @__PURE__ */ h("div", {
						className: "wc-note",
						children: S.waiting
					}),
					/* @__PURE__ */ g("section", {
						className: "wc-goals",
						children: [/* @__PURE__ */ h("h2", { children: S.achievements }), /* @__PURE__ */ h("div", {
							className: "wc-goal-list",
							children: e.achievements.map((t) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: si(t, x) }), /* @__PURE__ */ h("ul", { children: se(t, e.players.length).map((n, r) => {
								let i = e.claims.find((e) => e.achievement === t.id && e.slot === r);
								return /* @__PURE__ */ g("li", { children: [
									/* @__PURE__ */ g("span", { children: [
										t.kind !== "main" && `≥ ${n.required} · `,
										n.points,
										" ",
										S.points
									] }),
									/* @__PURE__ */ h(Ii, {
										goal: t.id,
										slot: r,
										owner: i ? De(i.owner) : null
									}),
									!i && /* @__PURE__ */ h("span", { children: S.vacant })
								] }, r);
							}) })] }, t.id))
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "wc-layout",
						children: [
							/* @__PURE__ */ g("aside", {
								className: "wc-crew",
								children: [
									/* @__PURE__ */ h("div", {
										className: "wc-section-title",
										children: /* @__PURE__ */ h("h2", { children: x === "zh" ? "探险队" : "Expedition" })
									}),
									/* @__PURE__ */ h("div", {
										className: "wc-seats",
										children: e.players.map((t) => /* @__PURE__ */ g("button", {
											type: "button",
											className: t.rid === e.activePlayer ? "is-active" : "",
											onClick: () => j(t.rid),
											children: [/* @__PURE__ */ h("strong", { children: De(t.rid) }), /* @__PURE__ */ g("span", { children: [
												/* @__PURE__ */ h(d, { value: t.rid === "$tingent" && e.solo ? e.solo.points : t.points }),
												" ",
												S.points,
												" · ",
												/* @__PURE__ */ h(d, { value: t.rid === "$tingent" && e.solo ? e.solo.trophies : t.trophies }),
												" ",
												S.trophies
											] })]
										}, t.rid))
									}),
									L?.rid === "$tingent" && e.solo ? /* @__PURE__ */ g(m, { children: [
										/* @__PURE__ */ h("h3", { children: De(fn) }),
										/* @__PURE__ */ g("p", { children: [
											S.time,
											" ",
											e.solo.position,
											" · ",
											S.points,
											" ",
											e.solo.points,
											" · ",
											S.trophies,
											" ",
											e.solo.trophies
										] }),
										/* @__PURE__ */ g("p", { children: [
											S.eggs,
											" ",
											e.solo.eggs.length,
											" · ",
											S.hand,
											" ",
											e.solo.hiddenCount
										] })
									] }) : L && /* @__PURE__ */ g(m, { children: [
										/* @__PURE__ */ h("h3", { children: S.captain }),
										/* @__PURE__ */ h("p", { children: L.captain ? /* @__PURE__ */ g(m, { children: [
											/* @__PURE__ */ h("strong", { children: Dt.find((e) => e.id === L.captain)?.name[x] }),
											" · ",
											L.captainUnlocked ? S.unlocked : S.locked,
											[
												"tingent",
												"ashe",
												"nathaniel",
												"morgane"
											].includes(L.captain) && ` · ${S.captainEnergy} ${L.captainEnergy}`,
											/* @__PURE__ */ h("br", {}),
											Dt.find((e) => e.id === L.captain)?.ability[x]
										] }) : S.empty }),
										e.explorerPack?.players.find((e) => e.owner === L.rid)?.selected && /* @__PURE__ */ g(m, { children: [
											/* @__PURE__ */ h("h3", { children: x === "zh" ? "探险者能力" : "Explorer power" }),
											/* @__PURE__ */ h(gi, {
												id: e.explorerPack.players.find((e) => e.owner === L.rid).selected,
												lang: x
											}),
											/* @__PURE__ */ h("p", { children: e.explorerPack.players.find((e) => e.owner === L.rid)?.used ? x === "zh" ? "本局已使用" : "Used this game" : x === "zh" ? "本局尚未使用" : "Available this game" })
										] }),
										e.beasts?.players.filter((e) => e.owner === L.rid).map((e) => /* @__PURE__ */ h(Mi, {
											beast: e,
											lang: x,
											energyLabel: S.energy
										}, e.id)),
										/* @__PURE__ */ h("h3", { children: S.resources }),
										/* @__PURE__ */ g("div", {
											className: "wc-resource-grid",
											children: [w.map((e) => /* @__PURE__ */ g("span", { children: [
												B[e][x],
												" ",
												/* @__PURE__ */ h("strong", { children: /* @__PURE__ */ h(d, { value: L.resources[e] }, `${L.rid}-${e}`) })
											] }, e)), /* @__PURE__ */ g("span", { children: [
												S.nets,
												" ",
												/* @__PURE__ */ h("strong", { children: /* @__PURE__ */ h(d, { value: L.nets }, `${L.rid}-nets`) })
											] })]
										}),
										/* @__PURE__ */ h("h3", { children: x === "zh" ? "物种图标" : "Species icons" }),
										/* @__PURE__ */ h("p", { children: x === "zh" ? "包含幻兽牌、已唤醒的巨兽和全部蛋；完成目标只能使用未孵化蛋。" : "Includes creatures, awakened beasts and all eggs; only unhatched eggs can be used for achievements." }),
										/* @__PURE__ */ h("div", {
											className: "wc-species-counts",
											children: T.map((e) => {
												let t = L.reserve.reduce((t, n) => t + n.species.filter((t) => t === e).length, 0) + Ce.filter((t) => t === e).length + L.eggs.filter((t) => !t.hatched && t.species === e).length, n = L.eggs.filter((t) => t.hatched && t.species === e).length;
												return /* @__PURE__ */ g("div", { children: [
													/* @__PURE__ */ h(fi, { name: e }),
													/* @__PURE__ */ h("span", { children: V[e][x] }),
													/* @__PURE__ */ h("strong", { children: t + n }),
													n > 0 && /* @__PURE__ */ h("small", { children: x === "zh" ? `目标可用 ${t}` : `Available for achievements ${t}` })
												] }, e);
											})
										}),
										/* @__PURE__ */ g("h3", { children: [
											S.eggs,
											" · ",
											L.eggs.length,
											"/12"
										] }),
										/* @__PURE__ */ h("p", { children: Se?.id === 3 ? x === "zh" ? "蛋槽奖励结算两次；满槽后每个额外蛋得 4 分。" : "Resolve each slot reward twice; each extra egg scores 4 points when full." : x === "zh" ? "按顺序放蛋并获得对应奖励；满槽后每个额外蛋得 2 分。" : "Fill slots in order and gain their rewards; each extra egg scores 2 points when full." }),
										H?.kind === "flipEggs" && /* @__PURE__ */ h("div", {
											className: "wc-egg-decision",
											children: ut
										}),
										/* @__PURE__ */ h("div", {
											className: "wc-egg-track",
											children: de.map((e, t) => {
												let n = L.eggs[t], r = !!n && H?.kind === "flipEggs" && L.rid === _ && (H.mode === "flip" || !n.hatched);
												return /* @__PURE__ */ g("div", {
													className: `wc-egg-slot${t === L.eggs.length ? " is-next" : ""}`,
													children: [/* @__PURE__ */ g("span", {
														className: "wc-egg-slot-reward",
														children: [
															t + 1,
															" · ",
															Fi(e, x)
														]
													}), n ? /* @__PURE__ */ h("button", {
														type: "button",
														className: `wc-egg-choice${r ? " is-eligible" : ""}${Ke.includes(t) && r ? " is-selected" : ""}`,
														"aria-pressed": r ? Ke.includes(t) : void 0,
														disabled: !r,
														onClick: () => {
															if (H?.kind !== "flipEggs") return;
															let e = Ke.includes(t) ? Ke.filter((e) => e !== t) : Ke.length < H.maximum ? [...Ke, t] : Ke;
															ge({
																owner: _,
																task: Ge,
																indices: e
															});
														},
														children: /* @__PURE__ */ h(hi, {
															egg: n,
															owner: L.rid,
															index: t,
															lang: x,
															hatched: S.hatched,
															unhatched: S.unhatched
														})
													}) : /* @__PURE__ */ h("span", {
														className: "wc-egg-slot-empty",
														children: t === L.eggs.length ? x === "zh" ? "下一个" : "Next" : x === "zh" ? "空" : "Empty"
													})]
												}, `${L.rid}-${t}`);
											})
										})
									] })
								]
							}),
							/* @__PURE__ */ g("section", {
								className: "wc-board-section",
								children: [
									/* @__PURE__ */ g("div", {
										className: "wc-section-title",
										children: [
											/* @__PURE__ */ h("h2", { children: S.island }),
											/* @__PURE__ */ g("span", { children: [
												S.time,
												" ",
												e.timePosition,
												" · ",
												S.trophies,
												" ",
												e.trophies
											] }),
											/* @__PURE__ */ h("button", {
												type: "button",
												className: "wc-map-zoom",
												onClick: () => M((e) => !e),
												children: ie ? S.mapOverview : S.mapEnlarge
											})
										]
									}),
									/* @__PURE__ */ g("details", {
										className: "wc-time",
										children: [
											/* @__PURE__ */ h("summary", { children: S.timeDetails }),
											/* @__PURE__ */ g("p", { children: [
												S.initialSymbols,
												" ",
												e.initialSymbols.map((e) => ne[e]).join(" · ")
											] }),
											/* @__PURE__ */ h("ol", { children: Lt(e.players.length).map((t, n) => {
												let r = n + 1, i = e.revealedTimeTokens.find((e) => e.position === r);
												return /* @__PURE__ */ g("li", {
													className: r === e.timePosition ? "is-current" : "",
													children: [
														/* @__PURE__ */ h("strong", { children: r }),
														/* @__PURE__ */ h("span", { children: t.effects.map((e) => O[e]).join(" · ") }),
														t.timeToken && /* @__PURE__ */ h("span", { children: i ? `${S.timeRevealed} ${ne[i.symbol]}` : e.timeTokenPositions.includes(r) ? S.timeHidden : S.timeRevealed })
													]
												}, r);
											}) })
										]
									}),
									/* @__PURE__ */ h(Ei, {
										board: e.board,
										eggs: e.boardEggs,
										explorers: e.explorers,
										members: r,
										lang: x,
										legal: Xe,
										selected: Ze,
										zoomed: ie,
										head: tt && z?.cells[1] ? R(z.cells[1]) : void 0,
										facing: nt,
										onSelect: at,
										onInspect: P,
										nameOf: De
									})
								]
							}),
							/* @__PURE__ */ g("aside", {
								className: "wc-wilderness",
								ref: te,
								children: [
									/* @__PURE__ */ g("div", {
										className: "wc-section-title",
										children: [/* @__PURE__ */ h("h2", { children: S.wilderness }), /* @__PURE__ */ g("span", { children: [
											S.deck,
											" ",
											e.deckCount
										] })]
									}),
									/* @__PURE__ */ h("div", {
										className: "wc-wilderness-grid",
										children: e.wilderness.map((e, t) => {
											let n = e === null ? null : st(e, t);
											return /* @__PURE__ */ h(ji, {
												slot: t,
												id: e,
												lang: x,
												choice: !!n,
												inspect: () => {
													e !== null && oe({
														owner: _,
														card: e,
														...n ? {
															source: "wilderness",
															slot: t
														} : {}
													});
												}
											}, t);
										})
									}),
									/* @__PURE__ */ g("details", {
										className: "wc-supply",
										children: [
											/* @__PURE__ */ h("summary", { children: S.supplyDetails }),
											/* @__PURE__ */ g("h3", { children: [
												S.habitatSupply,
												" · ",
												S.remainingTiles,
												" ",
												e.habitatPileCount
											] }),
											/* @__PURE__ */ h("ul", { children: e.habitatDisplay.map((e, t) => {
												let n = kt.find((t) => t.id === e);
												return /* @__PURE__ */ h("li", { children: n ? `${B[n.habitat][x]} · ${wi[n.special][x]}` : S.empty }, t);
											}) }),
											/* @__PURE__ */ g("h3", { children: [
												S.eggSupply,
												" · ",
												S.eggBag,
												" ",
												e.eggBagCount
											] }),
											/* @__PURE__ */ h("ul", { children: T.map((t) => /* @__PURE__ */ g("li", { children: [
												V[t][x],
												" · ",
												e.eggStock[t]
											] }, t)) }),
											/* @__PURE__ */ g("h3", { children: [
												S.discard,
												" · ",
												e.discard.length
											] }),
											/* @__PURE__ */ h("div", {
												className: "wc-choice-row",
												children: e.discard.map((e) => /* @__PURE__ */ h("button", {
													type: "button",
													onClick: () => oe({
														owner: _,
														card: e
													}),
													children: U.get(e)?.name[x]
												}, e))
											})
										]
									})
								]
							})
						]
					}),
					L && /* @__PURE__ */ g("section", {
						className: "wc-reserve",
						ref: D,
						children: [/* @__PURE__ */ g("div", {
							className: "wc-section-title",
							children: [/* @__PURE__ */ g("h2", { children: [
								De(L.rid),
								" · ",
								S.reserve
							] }), /* @__PURE__ */ g("span", { children: [
								S.eggs,
								" ",
								L.rid === "$tingent" && e.solo ? e.solo.eggs.length : `${L.eggs.length}/12`
							] })]
						}), /* @__PURE__ */ h("div", {
							className: "wc-card-row",
							children: (L.rid === "$tingent" && e.solo ? e.solo.visibleCards.map((e) => ({
								id: e,
								species: void 0,
								energy: void 0
							})) : L.reserve.map((e) => ({
								id: e.id,
								species: e.species,
								energy: L.energy.find((t) => t.card === e.id)?.energy
							}))).map((e) => /* @__PURE__ */ h(ki, {
								owner: L.rid,
								id: e.id,
								species: e.species,
								energy: e.energy,
								lang: x,
								inspect: () => oe({
									owner: _,
									card: e.id
								})
							}, e.id))
						})]
					})
				]
			}),
			ce !== null && /* @__PURE__ */ h("div", {
				className: "wc-inspect",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": S.details,
				onClick: () => oe(null),
				children: /* @__PURE__ */ g("div", {
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => oe(null),
							children: S.close
						}),
						/* @__PURE__ */ h(pi, {
							id: ce,
							lang: x,
							species: we?.card.species,
							currentEnergy: we?.energy
						}),
						lt && /* @__PURE__ */ h("button", {
							type: "button",
							className: "wc-primary",
							onClick: () => {
								ct({
									kind: "choose",
									choice: lt
								}), oe(null);
							},
							children: x === "zh" ? "选择这张牌" : "Choose this card"
						})
					]
				})
			}),
			N !== null && /* @__PURE__ */ h("div", {
				className: "wc-inspect",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": S.details,
				onClick: () => P(null),
				children: /* @__PURE__ */ g("div", {
					className: "wc-cell-detail",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ h("strong", { children: S.details }),
						/* @__PURE__ */ h("p", { children: N }),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => P(null),
							children: S.close
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
function Ri(e = !0) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i) return null;
		let o = (e) => ({ action: e }), s = (e) => o({
			kind: "choose",
			choice: e
		});
		if (r.resolution && !i.task) return null;
		if (r.phase === "draft") {
			if (r.resolution?.owner === n.rid && i.task?.kind === "wilderness") {
				let e = r.wilderness.findIndex((e) => e !== null);
				return e >= 0 ? s({
					kind: "wilderness",
					slot: e
				}) : null;
			}
			if (i.explorerPack?.canSelect && i.explorerPack.candidates.length) return o({
				kind: "explorerCard",
				card: i.explorerPack.candidates[0]
			});
			if (r.explorerPack?.phase === "selecting" && r.explorerPack.mode !== "simultaneous") return null;
			if (a.drafted && r.explorerPack?.phase === "paying" && i.explorerPack?.selected && !i.explorerPack.paid) {
				let e = Fe.find((e) => e.id === i.explorerPack.selected);
				if (!e) return null;
				let t = e.cost, n = {
					fruit: 0,
					coral: 0,
					flower: 0,
					mushroom: 0
				};
				for (let e of w) n[e] = Math.min(a.resources[e], t), t -= n[e];
				return t === 0 ? o({
					kind: "explorerPayment",
					payment: n
				}) : null;
			}
			if (a.drafted || !i.captainOptions.length || i.draftCards.length < 4) return null;
			let e = [...i.draftCards].sort((e, t) => {
				let n = U.get(e), r = U.get(t);
				return E(wn(n)) - E(wn(r)) || r.printedPoints - n.printedPoints;
			}).slice(0, 4);
			return o({
				kind: "draft",
				selection: {
					captain: i.captainOptions[0],
					cards: e,
					bonusResources: w.slice(0, a.seat)
				}
			});
		}
		if (r.finalChoice?.owner === n.rid) return o({
			kind: "scoreCopy",
			target: r.finalChoice.targets[0] ?? null
		});
		if (r.solo && r.activePlayer === "$tingent" && i.soloChoices.length) return o({
			kind: "soloChoose",
			choice: i.soloChoices[0]
		});
		if (r.phase !== "turn" || r.activePlayer !== n.rid) return null;
		let c = i.task;
		if (c) switch (c.kind) {
			case "reactionOrder": return s({
				kind: "reaction",
				index: 0
			});
			case "activationOrder": return s({
				kind: "activation",
				index: 0
			});
			case "chooseParts": {
				let e = [...i.effectPartsOptions].sort((e, t) => t.length - e.length)[0];
				return e ? s({
					kind: "effectParts",
					indices: e
				}) : null;
			}
			case "chooseDrawCount": return i.drawCountOptions.length ? s({
				kind: "drawCount",
				count: i.drawCountOptions[i.drawCountOptions.length - 1]
			}) : null;
			case "chooseGain": return i.gainCountOptions.length ? s({
				kind: "gainCount",
				count: i.gainCountOptions[i.gainCountOptions.length - 1]
			}) : null;
			case "resources": return i.resourceOptions[0] ? s({
				kind: "resource",
				resource: i.resourceOptions[0]
			}) : c.optional ? s({ kind: "skip" }) : null;
			case "chooseEgg": {
				let e = c.species.find((e) => r.eggStock[e] > 0);
				return e ? s({
					kind: "egg",
					species: e
				}) : null;
			}
			case "captainRabell": {
				let e = c.species.find((e) => r.eggStock[e] > 0);
				return e ? s({
					kind: "egg",
					species: e
				}) : null;
			}
			case "addSpecies": {
				let e = T.find((e) => r.eggStock[e] > 0 && !a.reserve.find((e) => e.id === c.card)?.species.includes(e));
				return e ? s({
					kind: "egg",
					species: e
				}) : null;
			}
			case "takeSpecies": return s({
				kind: "species",
				species: T.reduce((e, t) => r.wilderness.filter((e) => e && U.get(e)?.species.includes(t)).length > r.wilderness.filter((t) => t && U.get(t)?.species.includes(e)).length ? t : e, T[0])
			});
			case "scoreSpecies": {
				let e = U.get(c.card)?.species[0];
				return e ? s({
					kind: "species",
					species: e
				}) : null;
			}
			case "wilderness": {
				let e = i.wildernessOptions[0];
				return e === void 0 ? null : s({
					kind: "wilderness",
					slot: e
				});
			}
			case "sweep": return s({
				kind: "sweep",
				area: "left"
			});
			case "lookChoice": return c.cards.length ? s({
				kind: "lookCard",
				card: c.cards[0]
			}) : null;
			case "chooseLook": return i.canLook ? s({ kind: "lookNow" }) : i.canSkip ? s({ kind: "skip" }) : null;
			case "drawRewards": return c.options.length ? s({
				kind: "drawReward",
				reward: c.options[0]
			}) : null;
			case "discard": {
				let e = i.discardOptions[0];
				return e ? s({
					kind: "discard",
					card: e
				}) : c.optional ? s({ kind: "skip" }) : null;
			}
			case "discardConfirm": return i.discardConfirmOptions.length ? s({
				kind: "discardConfirm",
				replacement: i.discardConfirmOptions[0]
			}) : null;
			case "playSelection": {
				let e = [...i.playOptions].sort((e, t) => Bi(t.card) - Bi(e.card));
				return e.length ? s({
					kind: "selectPlay",
					...e[0]
				}) : c.basic ? s({ kind: "cancelPlay" }) : c.optional ? s({ kind: "skip" }) : null;
			}
			case "payCard": return i.paymentOptions.length ? s({
				kind: "payment",
				payment: i.paymentOptions[0]
			}) : i.canDiscount ? s({ kind: "discount" }) : c.origin && c.discountDiscards === 0 ? s({ kind: "cancelPlay" }) : c.optional && c.discountDiscards === 0 ? s({ kind: "skip" }) : null;
			case "flipEggs": return s({
				kind: "eggs",
				indices: a.eggs.flatMap((e, t) => c.mode === "flip" || !e.hatched ? [t] : []).slice(0, c.minimum)
			});
			case "explorer": {
				let e = c.action.coveredEggs[0];
				if (e) return s({
					kind: "explorerEgg",
					position: e
				});
				let t = c.action.remainingHabitats[0];
				if (t) {
					let e = Oe(t, r.wilderness, (e) => U.get(e).habitat), n = i.hand.length < 3 ? e.find((e) => e.kind === "card") ?? e[0] : e[0];
					return n ? s({
						kind: "explorerHabitat",
						position: t,
						reward: n
					}) : null;
				}
				return c.action.explorer.piece === "captain" && a.captainUnlocked && !c.captainUsed ? s({ kind: "captain" }) : s({ kind: "finishExplorer" });
			}
			case "captainFreya": return s({ kind: "skip" });
			case "captainTingent": return c.gainAllowed === !1 ? s({ kind: "skip" }) : s({
				kind: "tingent",
				mode: "gain"
			});
			case "captainMorgane": {
				let e = new Set(c.cells.flatMap(Te).map(R)), t = [...new Set(r.explorers.filter((t) => t.owner !== n.rid && t.cells.some((t) => e.has(R(t)))).map((e) => e.owner))].flatMap((e) => e === "$tingent" ? r.soloCaptainOptions.map((t) => ({
					owner: e,
					captain: t
				})) : r.players.flatMap((t) => t.rid === e && t.captain ? [{
					owner: e,
					captain: t.captain
				}] : [])).find((e) => e.captain !== "morgane" && (e.captain !== "helena" || !c.paidMountain));
				return s(t ? {
					kind: "captainCopy",
					...t
				} : { kind: "skip" });
			}
			case "captainMarie": {
				let e = i.habitatSpecialOptions[0];
				return i.canSkip && !c.mandatory ? s({ kind: "skip" }) : e === void 0 ? null : s({
					kind: "marie",
					slot: e
				});
			}
			case "chooseHatchOrFlip": return i.hatchOrFlipOptions.length ? s({
				kind: "hatchOrFlip",
				mode: i.hatchOrFlipOptions[0]
			}) : null;
			case "timeEggs": {
				let e = new Set([...r.boardEggs, ...r.explorers.flatMap((e) => e.cells)].map(R)), t = r.board.find((t) => t.timeSymbol === c.symbol && t.terrain !== "habitat" && !e.has(R(t)));
				return t ? s({
					kind: "timeEgg",
					position: t
				}) : null;
			}
			case "basicPlay": return s({
				kind: "basicPlay",
				play: c.first
			});
			case "chooseMapSpecial": {
				let e = i.mapSpecialOptions[0];
				return e ? s({
					kind: "mapSpecial",
					position: e
				}) : null;
			}
			case "chooseEndScore": {
				let e = a.reserve.find((e) => e.type === "endGame");
				return e ? s({
					kind: "endCard",
					card: e.id
				}) : null;
			}
			case "chooseEndCopy": return c.targets.length ? s({
				kind: "endCard",
				card: c.targets[0]
			}) : null;
			case "chooseAchievementReward": {
				let e = r.claims.find((e) => e.owner === n.rid && e.usedMarkerReward);
				return e ? s({
					kind: "achievementReward",
					marker: e.marker
				}) : null;
			}
			case "restoreEnergy": return a.energy.length ? s({
				kind: "energy",
				card: a.energy[0].card
			}) : null;
			case "chooseRecharge": return i.rechargeOptions.length ? s({
				kind: "recharge",
				card: i.rechargeOptions[0]
			}) : c.optional && i.canSkip ? s({ kind: "skip" }) : null;
			case "cardEffect": return i.effectOptions.length ? s({
				kind: "cardEffect",
				use: i.effectOptions[0]
			}) : null;
			case "discovery": {
				let e = r.habitatDisplay.findIndex(Boolean), t = r.board.find((e) => e.terrain === "lake");
				return e >= 0 && t ? s({
					kind: "discovery",
					slot: e,
					position: t
				}) : null;
			}
			case "exchange": return s({ kind: "skip" });
			default: return null;
		}
		let l = r.explorerPack?.setupComplete && r.explorerPack.players.find((e) => e.owner === n.rid && !e.used)?.selected, u = r.beasts?.players.find((e) => e.owner === n.rid);
		if (a.captainUnlocked && a.captain === "ashe" && a.captainEnergy > 0 && r.discard.length) return o({
			kind: "captainPower",
			mode: a.captainEnergy >= 2 ? "takeDiscardResource" : "takeDiscard"
		});
		if (a.captainUnlocked && a.captain === "nathaniel" && a.captainEnergy >= 3 && i.hand.length) return o({
			kind: "captainPower",
			mode: "play"
		});
		if (a.captainUnlocked && a.captain === "nathaniel" && a.captainEnergy > 0 && E(a.resources) < 22) return o({
			kind: "captainPower",
			mode: "resource"
		});
		if (u?.awake && u.energy > 0 && !u.usedThisTurn) {
			if (u.id === 1 && a.nets > 0 && r.wilderness.some((e) => e !== null)) return o({
				kind: "beastPower",
				mode: "wilderness"
			});
			if (u.id === 2 && i.hand.length >= 4) return o({
				kind: "beastPower",
				mode: "discard"
			});
			if (u.id === 2 && i.hand.length < 3 && r.deckCount + r.discard.length > 0) return o({
				kind: "beastPower",
				mode: "draw"
			});
		}
		if (l === 1) {
			let e = Vi(r, a);
			if (e && "kind" in e && e.kind === "achievement") return o({
				kind: "explorerPower",
				choice: e
			});
		}
		if (l === 2 && a.energy.some((e) => {
			let t = U.get(e.card);
			return t && "energyCapacity" in t && e.energy < (t.energyCapacity ?? 0);
		}) || l === 3 && r.revealedTimeTokens.length > 0 && E(a.resources) < 20 || l === 5 && a.reserve.some((e) => e.type === "recharge") || l === 7 && r.revealedTimeTokens.length > 0 && T.some((e) => r.eggStock[e] > 0)) return o({
			kind: "explorerPower",
			choice: { kind: "activate" }
		});
		if (l === 6 && r.explorers.filter((e) => e.owner === n.rid).length === 3) return o({
			kind: "explorerPower",
			choice: {
				kind: "returnExplorer",
				piece: "explorerA"
			}
		});
		if (r.basicAction?.resolved) return o({ kind: "finishTurn" });
		if (r.basicAction) return null;
		let d = Vi(r, a);
		if (d) return o(d);
		let f = a.eggs.flatMap((e, t) => e.hatched ? [] : [t]).slice(0, 4);
		if (!u && r.beasts?.supply.length && f.length === 4) return o({
			kind: "beast",
			beast: r.beasts.supply[0],
			eggs: f
		});
		let p = i.hand.some((e) => {
			let t = U.get(e);
			return t && (t.effect.kind === "awakeFreeOtherwiseAdvance" && u?.awake || Sn(wn(t), a.resources, Tn(t, a.reserve) + Se(u, E(wn(t)))));
		});
		if (e && p && a.reserve.length < 14) return o({ kind: "playCards" });
		let m = r.explorers.filter((e) => e.owner === n.rid), h = [
			"captain",
			"explorerA",
			"explorerB"
		].find((e) => !m.some((t) => t.piece === e));
		if (!h && m.length === 3) return o({ kind: "recharge" });
		let g = r.explorers.flatMap((e) => e.cells), _ = Ee(r.board, g);
		if (h) {
			let e = [..._].sort((e, t) => De(r.board, t.cells).length - De(r.board, e.cells).length || e.mountainCost - t.mountainCost);
			for (let t of e) {
				let e = !t.mountainCost || h === "captain" && a.captain === "helena" && a.captainUnlocked || E(a.resources) === 0 && _.length === 1, n = e ? null : w.find((e) => a.resources[e] > 0) ?? null;
				if (e || n) return o({
					kind: "explore",
					piece: h,
					cells: t.cells,
					payment: n
				});
			}
		}
		if (p) return o({ kind: "playCards" });
		if (a.nets > 0) {
			let e = ke(r.board, m.map((e) => e.cells), r.boardEggs, r.usedNetSpecials)[0];
			if (e) return o({
				kind: "net",
				target: {
					kind: e.kind,
					position: e.kind === "egg" ? e.position : e.cell
				}
			});
		}
		return null;
	};
}
var zi = Ri();
function Bi(e) {
	let t = U.get(e);
	return t ? t.printedPoints + (t.type === "recharge" || t.type === "permanent" ? 2 : 1) - .35 * E(wn(t)) : -Infinity;
}
function Vi(e, t) {
	let n = [
		2,
		0,
		1,
		3,
		4,
		5
	].find((n) => !e.claims.some((e) => e.owner === t.rid && e.marker === n));
	if (n === void 0) return null;
	let r = t.eggs.flatMap((e, t) => e.hatched ? [] : [t]), i = e.beasts?.players.find((e) => e.owner === t.rid && e.awake), a = i ? _e.find((e) => e.id === i.id)?.species : void 0;
	for (let i of e.achievements) {
		if (e.claims.some((e) => e.owner === t.rid && e.achievement === i.id)) continue;
		let o = se(i, e.players.length);
		for (let s = 0; s < o.length; s++) if (!e.claims.some((e) => e.achievement === i.id && e.slot === s)) for (let e of T) for (let c of w) {
			let l = r.filter((n) => i.kind === "single" ? t.eggs[n].species === i.species : i.kind === "multi" ? i.species.includes(t.eggs[n].species) : i.requirement === "tenSpecies" ? t.eggs[n].species === e : i.requirement === "eightEggs");
			for (let r = 0; r <= l.length; r++) {
				let u = {
					eggs: l.slice(0, r),
					species: e,
					habitat: c
				};
				if (ue(i, o[s].required, {
					cards: t.reserve,
					eggs: t.eggs,
					extraSpecies: a
				}, u)) return {
					kind: "achievement",
					achievement: i.id,
					slot: s,
					marker: n,
					useMarkerReward: n === 2,
					selection: u
				};
			}
		}
	}
	return null;
}
//#endregion
//#region src/game/fx.tsx
var Hi = 700;
function Ui({ id: e }) {
	let t = s((e) => e.locale), n = U.get(e), r = n && "energyCapacity" in n ? n.energyCapacity : void 0;
	return /* @__PURE__ */ h(pi, {
		id: e,
		lang: t === "zh" ? "zh" : "en",
		compact: !0,
		currentEnergy: r
	});
}
function Wi({ amount: e, awake: t }) {
	let n = s((e) => e.locale);
	return /* @__PURE__ */ h("span", {
		className: "wc-beast-fx-label",
		children: t ? n === "zh" ? "巨兽唤醒" : "Beast awakened" : `+${e}`
	});
}
function Gi({ at: e, species: t, hatched: n }) {
	let a = i(null), o = i(null), c = s((e) => e.locale) === "zh" ? "zh" : "en";
	r(() => {
		let e = {
			duration: 700,
			easing: "ease-in-out",
			fill: "both"
		}, t = a.current?.animate([
			{
				opacity: 1,
				transform: "rotateY(0deg)"
			},
			{
				opacity: 1,
				transform: "rotateY(90deg)",
				offset: .49
			},
			{
				opacity: 0,
				transform: "rotateY(90deg)",
				offset: .5
			},
			{
				opacity: 0,
				transform: "rotateY(90deg)"
			}
		], e), n = o.current?.animate([
			{
				opacity: 0,
				transform: "rotateY(-90deg)"
			},
			{
				opacity: 0,
				transform: "rotateY(-90deg)",
				offset: .49
			},
			{
				opacity: 1,
				transform: "rotateY(-90deg)",
				offset: .5
			},
			{
				opacity: 1,
				transform: "rotateY(0deg)"
			}
		], e);
		return () => {
			t?.cancel(), n?.cancel();
		};
	}, []);
	let l = (e) => /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h(fi, { name: t }),
		V[t][c],
		" · ",
		c === "zh" ? e ? "已孵化" : "未孵化" : e ? "Hatched" : "Unhatched"
	] });
	return /* @__PURE__ */ g("span", {
		className: "wc-egg-marker",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: [/* @__PURE__ */ h("span", {
			ref: o,
			className: `wc-egg-face${n ? " is-hatched" : ""}`,
			children: l(n)
		}), /* @__PURE__ */ h("span", {
			ref: a,
			className: `wc-egg-face wc-egg-previous${n ? "" : " is-hatched"}`,
			children: l(!n)
		})]
	});
}
var Ki = {
	eggFlip(e, t) {
		if (!e.rid || t.queued) return null;
		let n = e.data.eggs, r = t.anchor("wc-banner"), i = t.anchor("wc-hand");
		if (!r || !i) return null;
		let a = n.flatMap((n) => {
			let a = `wc-egg:${e.rid}:${n.index}`, o = t.anchor(a);
			return o && o.w > 0 && o.h > 0 && o.y >= r.y + r.h && o.y + o.h <= i.y ? [{
				...n,
				name: a,
				at: o
			}] : [];
		});
		return a.length ? {
			ms: 700,
			hide: a.map((e) => e.name),
			node: /* @__PURE__ */ h(m, { children: a.map((e) => /* @__PURE__ */ h(Gi, {
				at: e.at,
				species: e.species,
				hatched: e.hatched
			}, e.index)) })
		} : null;
	},
	goalClaim(e, t) {
		if (t.queued) return null;
		let { goal: n, slot: r } = e.data, i = t.anchor(`wc-goal:${n}:${r}`);
		return i && i.w > 0 && i.h > 0 ? {
			ms: 700,
			node: /* @__PURE__ */ h(b, {
				at: i,
				ms: 700
			})
		} : null;
	},
	explorerPlace(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = `wc-explorer:${e.rid}:${n.piece}`, i = t.anchor("wc-banner"), a = t.anchor(r), o = t.member(e.rid);
		if (!i || !a || !o || t.queued || i.w <= 0 || a.w <= 0 || a.h <= 0) return null;
		let s = u[o.colorIndex % u.length].hex;
		return {
			ms: Hi,
			hide: [r],
			node: /* @__PURE__ */ h(y, {
				from: i,
				to: a,
				ms: Hi,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ h(bi, {
						cells: n.cells,
						color: s,
						avatar: o.avatar,
						captain: n.piece === "captain"
					})
				})
			})
		};
	},
	cardPlay(e, t) {
		if (!e.rid || t.queued) return null;
		let n = e.data, r = `wc-reserve:${e.rid}:${n.card}`, i = t.anchor(n.source === "wilderness" ? "wc-wilderness" : e.rid === t.myRid ? "wc-hand" : "wc-banner"), a = t.anchor(r), o = t.anchor("wc-hand"), s = t.anchor("wc-banner");
		if (!i || !o || !s || i.w <= 0 || i.h <= 0) return null;
		let c = a && a.w > 0 && a.h > 0 && a.y >= s.y && a.y + a.h <= o.y, l = c ? a : e.rid === t.myRid ? t.anchor(`wc-reserve-entry:${e.rid}`) : null;
		return !l || l.w <= 0 || l.h <= 0 ? null : {
			ms: 700,
			...c ? { hide: [r] } : {},
			node: /* @__PURE__ */ h(y, {
				from: i,
				to: l,
				ms: 700,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: a?.w || 144,
						height: a?.h || 240
					},
					children: /* @__PURE__ */ h(Ui, { id: n.card })
				})
			})
		};
	},
	takeWilderness(e, t) {
		let n = e.secret, r = n?.card, i = n?.slot;
		if (r === void 0 || i === void 0 || t.queued) return null;
		let a = t.anchor(`wc-wilderness-slot:${i}`), o = t.anchor("wc-hand"), s = `wc-hand-card:${t.myRid}:${r}`, c = t.anchor(s);
		return !a || !o || !c || a.w <= 0 || a.h <= 0 || c.w <= 0 || c.h <= 0 || c.x < o.x || c.x + c.w > o.x + o.w ? null : {
			ms: 700,
			hide: [s],
			node: /* @__PURE__ */ h(y, {
				from: a,
				to: c,
				ms: 700,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: "9rem",
						height: "15rem"
					},
					children: /* @__PURE__ */ h(Ui, { id: r })
				})
			})
		};
	},
	beastProgress(e, t) {
		if (!e.rid || t.queued) return null;
		let n = t.anchor(`wc-beast:${e.rid}`);
		if (!n || n.w <= 0 || n.h <= 0) return null;
		let r = e.data;
		return {
			ms: 700,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(b, {
				at: n,
				ms: 700
			}), /* @__PURE__ */ h(v, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ h(Wi, {
					amount: r.amount,
					awake: r.awake
				})
			})] })
		};
	}
};
//#endregion
//#region src/game/game-over.tsx
function qi({ public: e, private: t, result: n, members: r, myRid: i, hintCount: l, onPlayAgain: d, onBackToLobby: f }) {
	let v = e, y = s((e) => e.locale), b = c(), S = y === "zh" ? "zh" : "en", C = (S === "zh" ? oi : ai).ui, [w, T] = a(!1), ee = (e) => {
		if (e === "$tingent") return S === "zh" ? "汀詹特" : "Tingent";
		let t = r.find((t) => t.rid === e);
		if (t) return p(t, y);
		let n = v.players.find((t) => t.rid === e)?.seat ?? 0;
		return b(u[n % u.length].nameKey);
	}, te = [
		[C.immediatePoints, "immediate"],
		[C.finalAbilities, "endGameAbilities"],
		[C.printedPoints, "printedCards"],
		[C.achievementPoints, "achievements"],
		[C.trophyPoints, "trophies"]
	], E = [.../* @__PURE__ */ new Set([...v.players.flatMap((e) => e.reserve.map((e) => e.id)), ...v.solo?.visibleCards ?? []])].slice(0, 4);
	return /* @__PURE__ */ g("div", {
		className: "wc-result-stage",
		children: [
			/* @__PURE__ */ h("div", {
				className: "wc-result-board",
				"aria-hidden": !w,
				inert: !w,
				children: /* @__PURE__ */ h(Oi, {
					public: v,
					private: t,
					members: r,
					myRid: i,
					send: () => {}
				})
			}),
			w && /* @__PURE__ */ h("button", {
				type: "button",
				className: "wc-return-result",
				onClick: () => T(!1),
				children: C.returnResult
			}),
			/* @__PURE__ */ h("div", {
				className: "wc-result-overlay",
				hidden: w,
				children: /* @__PURE__ */ h("div", {
					className: "wc-result",
					children: /* @__PURE__ */ g("section", {
						className: "wc-result-card",
						children: [/* @__PURE__ */ g("div", {
							className: "wc-result-body",
							tabIndex: 0,
							"aria-label": C.scoreItems,
							children: [
								/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h1", { children: C.final }), /* @__PURE__ */ g("p", { children: [
									n.winner.map(ee).join(" · "),
									" · ",
									n.winner.length > 1 ? C.tied : C.winner
								] })] }),
								/* @__PURE__ */ h("div", {
									className: "wc-result-players",
									children: v.final?.map((e) => {
										let t = r.find((t) => t.rid === e.rid), n = v.players.find((t) => t.rid === e.rid)?.seat ?? v.players.length, i = u[(t?.colorIndex ?? n) % u.length].hex, a = e.rid === "$tingent" ? v.solo?.trophies ?? 0 : v.players.find((t) => t.rid === e.rid)?.trophies ?? 0;
										return /* @__PURE__ */ g("div", {
											className: "wc-result-player",
											style: { borderColor: i },
											children: [
												/* @__PURE__ */ h("span", {
													className: "wc-result-avatar",
													style: { backgroundColor: i },
													children: /* @__PURE__ */ h("img", {
														src: _[(t?.avatar ?? 0) % _.length],
														alt: ""
													})
												}),
												/* @__PURE__ */ g("span", {
													className: "wc-result-identity",
													children: [/* @__PURE__ */ h("strong", { children: ee(e.rid) }), /* @__PURE__ */ g("span", { children: [
														/* @__PURE__ */ h(fi, { name: "trophy" }),
														" ",
														C.trophies,
														" ",
														a
													] })]
												}),
												/* @__PURE__ */ g("span", {
													className: "wc-result-total",
													children: [/* @__PURE__ */ h("strong", { children: e.score.total }), /* @__PURE__ */ h("small", { children: C.total })]
												})
											]
										}, e.rid);
									})
								}),
								E.length > 0 && /* @__PURE__ */ h("div", {
									className: "wc-result-gallery",
									"aria-label": C.reserve,
									children: E.map((e) => {
										let t = U.get(e);
										return t && /* @__PURE__ */ g("figure", { children: [/* @__PURE__ */ h("img", {
											src: o(`games/wondrouscreatures/art/${String(e).padStart(3, "0")}.webp`),
											alt: ""
										}), /* @__PURE__ */ h("figcaption", { children: t.name[S] })] }, e);
									})
								}),
								/* @__PURE__ */ h("div", {
									className: "wc-result-scroll",
									children: /* @__PURE__ */ g("table", { children: [
										/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: C.scoreItems }), v.final?.map((e) => /* @__PURE__ */ h("th", {
											scope: "col",
											children: ee(e.rid)
										}, e.rid))] }) }),
										/* @__PURE__ */ g("tbody", { children: [
											te.map(([e, t]) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: e
											}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: e.score[t] }, e.rid))] }, t)),
											v.beasts && /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: S === "zh" ? "巨兽分" : "Beast points"
											}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: e.score.beastPoints }, e.rid))] }),
											/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: C.remainingPoints
											}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: v.solo && e.rid === "$tingent" ? "—" : e.score.remaining }, e.rid))] }),
											v.solo && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: C.soloEggPoints
											}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: e.rid === "$tingent" ? v.solo.eggs.length : "—" }, e.rid))] }), /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: C.soloHiddenPoints
											}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: e.rid === "$tingent" ? v.solo.hiddenCount * Math.min(v.solo.difficulty, 3) : "—" }, e.rid))] })] })
										] }),
										/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: C.total
										}), v.final?.map((e) => /* @__PURE__ */ h("td", { children: e.score.total }, e.rid))] }) })
									] })
								}),
								l !== void 0 && l > 0 && /* @__PURE__ */ h("p", { children: b("session.hint.usedCount", { n: l }) }),
								n.ranking.filter((e) => (n.autopilot?.[e] ?? 0) > 0).map((e) => /* @__PURE__ */ g("p", { children: [
									ee(e),
									" · ",
									b("session.autopilot.share", { n: Math.round((n.autopilot?.[e] ?? 0) * 100) })
								] }, e))
							]
						}), /* @__PURE__ */ g("div", {
							className: "wc-result-controls",
							children: [
								/* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => T(!0),
									children: C.reviewBoard
								}),
								d && /* @__PURE__ */ h(x, {
									label: b("session.result.playAgain"),
									confirmLabel: C.confirmAgain,
									onConfirm: d
								}),
								f && /* @__PURE__ */ h(x, {
									label: b("session.result.backToLobby"),
									confirmLabel: C.confirmLobby,
									onConfirm: f
								}),
								!d && !f && /* @__PURE__ */ h("span", { children: b("session.result.waitHost") })
							]
						})]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function Ji({ value: e, onChange: t }) {
	let n = s((e) => e.locale), r = Hr.safeParse(e), i = r.success ? r.data : Hr.parse(void 0), a = n === "zh" ? [
		"新手",
		"熟练",
		"专家",
		"传奇"
	] : [
		"Novice",
		"Experienced",
		"Expert",
		"Legend"
	], o = n === "zh" ? [
		"不使用",
		"随机选二留一",
		"同时选择开局牌",
		"按逆序自由选择"
	] : [
		"Not used",
		"Random: choose one of two",
		"Choose alongside starting cards",
		"Choose freely in reverse order"
	];
	return /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h(C, {
			title: n === "zh" ? "单人对手难度" : "Solo opponent difficulty",
			columns: 2,
			children: [
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ h(S, {
				name: "wondrouscreatures-solo-difficulty",
				value: String(e),
				checked: i.soloDifficulty === e,
				label: a[e - 1],
				accent: sr.accent,
				onChange: () => t({
					...i,
					soloDifficulty: e
				})
			}, e))
		}),
		/* @__PURE__ */ h(C, {
			title: n === "zh" ? "巨兽扩展" : "Gargantuan Beasts",
			columns: 2,
			children: [!1, !0].map((e) => /* @__PURE__ */ h(S, {
				name: "wondrouscreatures-beasts",
				value: String(e),
				checked: i.beasts === e,
				label: n === "zh" ? e ? "使用" : "不使用" : e ? "Use" : "Not used",
				accent: sr.accent,
				onChange: () => t({
					...i,
					beasts: e
				})
			}, String(e)))
		}),
		/* @__PURE__ */ h(C, {
			title: n === "zh" ? "探险者扩展" : "Explorer Pack",
			columns: 2,
			children: [
				"none",
				"standard",
				"simultaneous",
				"reverse"
			].map((e, n) => /* @__PURE__ */ h(S, {
				name: "wondrouscreatures-explorers",
				value: e,
				checked: i.explorerDraft === e,
				label: o[n],
				accent: sr.accent,
				onChange: () => t({
					...i,
					explorerDraft: e
				})
			}, e))
		})
	] });
}
//#endregion
//#region src/index.tsx
var Yi = {
	definition: ii,
	View: Oi,
	bot: zi,
	fx: Ki,
	OverView: qi,
	Options: Ji,
	locales: {
		zh: oi,
		en: ai
	}
};
//#endregion
export { Yi as default };
