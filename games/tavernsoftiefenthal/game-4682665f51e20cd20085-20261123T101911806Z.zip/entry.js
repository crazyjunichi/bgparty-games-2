import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as a } from "@bgparty/sdk/player-colors";
import { useWakeLock as o } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as l, seatName as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { ConfirmButton as m } from "@bgparty/sdk/confirm-button";
//#region src/game/data.ts
var ee = {
	barback: 2,
	dishwasher: 3,
	server: 4,
	table: 5,
	brewer: 6
}, te = {
	barback: 1,
	dishwasher: 1,
	server: 1,
	table: 2,
	brewer: 1
}, h = (e) => ({
	key: "tavern-" + e,
	kind: "tavern",
	tavern: e,
	cost: 0,
	vp: te[e],
	die: 0,
	coins: 0,
	bonus: "none"
}), g = {
	dishwasher: {
		cost: 9,
		discount: 3,
		nameKey: "games.tavernsoftiefenthal.up.dishwasher",
		benefitKey: "games.tavernsoftiefenthal.up.dishwasher.benefit"
	},
	server: {
		cost: 12,
		discount: 4,
		nameKey: "games.tavernsoftiefenthal.up.server",
		benefitKey: "games.tavernsoftiefenthal.up.server.benefit"
	},
	cashbox: {
		cost: 10,
		discount: 0,
		nameKey: "games.tavernsoftiefenthal.up.cashbox",
		benefitKey: "games.tavernsoftiefenthal.up.cashbox.benefit"
	},
	monk: {
		cost: 12,
		discount: 0,
		nameKey: "games.tavernsoftiefenthal.up.monk",
		benefitKey: "games.tavernsoftiefenthal.up.monk.benefit"
	},
	table: {
		cost: 15,
		discount: 5,
		nameKey: "games.tavernsoftiefenthal.up.table",
		benefitKey: "games.tavernsoftiefenthal.up.table.benefit"
	},
	barrel: {
		cost: 9,
		discount: 0,
		nameKey: "games.tavernsoftiefenthal.up.barrel",
		benefitKey: "games.tavernsoftiefenthal.up.barrel.benefit"
	},
	safe: {
		cost: 6,
		discount: 0,
		nameKey: "games.tavernsoftiefenthal.up.safe",
		benefitKey: "games.tavernsoftiefenthal.up.safe.benefit"
	},
	storage: {
		cost: 9,
		discount: 0,
		nameKey: "games.tavernsoftiefenthal.up.storage",
		benefitKey: "games.tavernsoftiefenthal.up.storage.benefit"
	},
	brewer: {
		cost: 18,
		discount: 6,
		nameKey: "games.tavernsoftiefenthal.up.brewer",
		benefitKey: "games.tavernsoftiefenthal.up.brewer.benefit"
	}
}, ne = [
	"brewer",
	"cashbox",
	"monk",
	"barrel",
	"dishwasher",
	"server",
	"table",
	"safe",
	"storage"
], _ = (e, t, n, r, i, a = "none") => ({
	key: e,
	kind: "guest",
	cost: t,
	vp: n,
	die: r,
	coins: i,
	bonus: a
}), v = [
	_("g3a", 3, 1, 2, 3),
	_("g3b", 3, 1, 1, 2),
	_("g3c", 3, 2, 3, 3),
	_("g3d", 3, 1, 2, 2),
	_("g3e", 3, 2, 3, 4),
	_("g3f", 3, 1, 1, 3),
	_("g3g", 3, 2, 2, 4),
	_("g3h", 3, 1, 3, 3),
	_("g3000", 4, 2, 3, 4),
	_("g3001", 4, 2, 3, 3, "beer1"),
	_("g3002", 4, 3, 3, 3, "monastery1"),
	_("g3003", 4, 1, 3, 3, "beer1"),
	_("g3000b", 4, 2, 3, 4),
	_("g3001b", 4, 2, 3, 3, "beer1"),
	_("g3003b", 4, 1, 3, 3, "beer1"),
	_("g3004", 5, 3, 5, 5),
	_("g3005", 5, 2, 5, 3, "coins2"),
	_("g3006", 5, 3, 5, 4, "beer1"),
	_("g3007", 5, 4, 5, 4, "guest3"),
	_("g3008", 5, 1, 5, 4, "monastery1"),
	_("g3009", 5, 4, 5, 6),
	_("g3004b", 5, 3, 5, 5),
	_("g3006b", 5, 3, 5, 4, "beer1"),
	_("g3010", 6, 3, 5, 4, "coins3"),
	_("g3011", 6, 1, 5, 3, "beer2"),
	_("g3012", 6, 3, 5, 3, "noble"),
	_("g3013", 6, 4, 5, 3, "serviceDenied"),
	_("g3014", 6, 2, 5, 4, "tableCard"),
	_("g3015", 6, 2, 6, 5),
	_("g3010b", 6, 3, 5, 4, "coins3"),
	_("g3016", 7, 4, 6, 4, "coins4"),
	_("g3017", 7, 1, 6, 4, "beer2"),
	_("g3018", 7, 4, 6, 6, "monastery1"),
	_("g3019", 7, 4, 6, 5, "coins3"),
	_("g3022", 8, 4, 6, 5, "beer2"),
	_("g3023", 8, 4, 6, 5, "coins4"),
	_("g3024", 8, 4, 6, 5, "serviceDenied"),
	_("g3025", 8, 1, 6, 4, "beer2")
], re = [
	{
		key: "reg1",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 1,
		coins: 1,
		bonus: "none"
	},
	{
		key: "reg1",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 1,
		coins: 1,
		bonus: "none"
	},
	{
		key: "reg1",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 1,
		coins: 1,
		bonus: "none"
	},
	{
		key: "reg2",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 2,
		coins: 2,
		bonus: "none"
	},
	{
		key: "reg2",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 2,
		coins: 2,
		bonus: "none"
	},
	{
		key: "reg2",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 2,
		coins: 2,
		bonus: "none"
	},
	{
		key: "reg2",
		kind: "regular",
		cost: 0,
		vp: 0,
		die: 2,
		coins: 2,
		bonus: "none"
	}
], y = {
	key: "noble",
	kind: "noble",
	cost: 0,
	vp: 10,
	die: 2,
	coins: 2,
	bonus: "none"
}, ie = {
	2: { kind: "guest3" },
	3: {
		kind: "tavern",
		card: "dishwasher"
	},
	4: { kind: "serviceDenied" },
	6: {
		kind: "tavern",
		card: "barback"
	},
	8: { kind: "noble" },
	10: { kind: "guest3" },
	12: {
		kind: "beer",
		n: 1
	},
	14: {
		kind: "tavern",
		card: "table"
	},
	16: { kind: "noble" },
	18: {
		kind: "coins",
		n: 2
	},
	20: {
		kind: "coins",
		n: 3
	},
	22: { kind: "noble" }
}, b = {
	1: { kind: "counter" },
	2: {
		kind: "choice",
		options: ["guest3", "barback"]
	},
	3: {
		kind: "choice",
		options: ["die", "dishwasher"]
	},
	4: { kind: "counter" },
	5: {
		kind: "choice",
		options: ["table", "brewer"]
	},
	6: { kind: "counter" },
	7: {
		kind: "choice",
		options: ["die", "barback"]
	},
	8: { kind: "freeUpgrade" }
}, ae = [
	9,
	14,
	18
], x = {
	id: "tavernsoftiefenthal",
	uuid: "0f5e3a64-3f0f-4f8f-9e3a-6f3f2f0b8a11",
	tier: "alpha",
	mechanics: [
		"deck-bag-building",
		"dice-rolling",
		"drafting",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.tavernsoftiefenthal.name",
	descKey: "games.tavernsoftiefenthal.desc",
	rulesKey: "games.tavernsoftiefenthal.rules",
	icon: "🍺",
	iconImg: "games/tavernsoftiefenthal.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#b45309",
	releasedAt: "2026-11-23T09:50:44+08:00",
	search: {
		py: "shen gu jiu guan",
		init: "sgjg"
	},
	hotseat: "cover"
}, S = t.enum([
	"barback",
	"dishwasher",
	"server",
	"table",
	"brewer"
]), oe = t.enum([
	"dishwasher",
	"server",
	"cashbox",
	"monk",
	"table",
	"barrel",
	"safe",
	"storage",
	"brewer"
]), C = t.enum([
	"none",
	"beer1",
	"beer2",
	"coins2",
	"coins3",
	"coins4",
	"monastery1",
	"noble",
	"guest3",
	"tableCard",
	"serviceDenied"
]), w = t.object({
	uid: t.string(),
	key: t.string(),
	kind: t.enum([
		"regular",
		"guest",
		"noble",
		"tavern"
	]),
	tavern: S.optional(),
	cost: t.int().nonnegative(),
	vp: t.int().nonnegative(),
	die: t.int().min(0).max(6),
	coins: t.int().nonnegative(),
	bonus: C
}), T = t.object({
	card: w.nullable(),
	extraNobles: t.int().nonnegative()
}), E = t.object({
	kind: t.enum([
		"seat",
		"cashbox",
		"brewer",
		"barrel",
		"monk"
	]),
	seat: t.int().nonnegative().optional()
}), se = t.object({
	id: t.string(),
	value: t.int().min(1).max(6),
	color: t.enum(["white", "player"]),
	slot: E.nullable(),
	boost: t.int().nonnegative(),
	used: t.boolean()
}), ce = t.object({
	barback: t.int().nonnegative(),
	dishwasher: t.int().nonnegative(),
	server: t.int().nonnegative(),
	table: t.int().nonnegative(),
	brewer: t.int().nonnegative()
}), le = t.object({
	dishwasher: t.boolean(),
	server: t.boolean(),
	cashbox: t.boolean(),
	monk: t.boolean(),
	table: t.boolean(),
	barrel: t.boolean(),
	safe: t.boolean(),
	storage: t.boolean(),
	brewer: t.boolean()
}), D = t.object({
	server: t.int().nonnegative(),
	dishwasher: t.int().nonnegative(),
	table: t.int().nonnegative()
}), O = t.object({
	rid: t.string(),
	coins: t.int().nonnegative(),
	beer: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	seats: t.array(T),
	zones: ce,
	upgrades: le,
	upgradeReady: D,
	monastery: t.int().min(0).max(22),
	counters: t.int().nonnegative(),
	dice: t.array(se),
	ready: t.boolean(),
	dishesUsed: t.int().nonnegative(),
	coaster: t.array(t.int().min(1).max(6)),
	bought: t.array(S),
	guestBought: t.boolean(),
	pendingRemove: t.boolean(),
	bonusDone: t.boolean()
}), k = t.object({
	turn: t.int().min(1).max(8),
	phase: t.enum([
		"bonus",
		"draft",
		"plan",
		"serve",
		"done"
	]),
	startIndex: t.int().nonnegative(),
	activeIndex: t.int().nonnegative(),
	draftRound: t.int().min(0).max(4),
	draftIndex: t.int().nonnegative(),
	bonusOptions: t.array(t.string()),
	guestDisplay: t.array(w),
	guest3Count: t.int().nonnegative(),
	guest3Top: w.nullable(),
	guestDeckCount: t.int().nonnegative(),
	players: t.array(O),
	winner: t.array(t.string()).nullable(),
	ranking: t.array(t.string()).nullable(),
	scores: t.record(t.string(), t.int()).nullable()
}), ue = t.object({
	deck: t.array(w),
	discard: t.array(w),
	vp: t.int().nonnegative().optional()
}), A = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bonus"),
		pick: t.string()
	}),
	t.object({
		type: t.literal("draftPick"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("placeDie"),
		dieId: t.string(),
		slot: E,
		boost: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("unplace"),
		dieId: t.string()
	}),
	t.object({ type: t.literal("readyPlan") }),
	t.object({
		type: t.literal("takeDie"),
		dieId: t.string()
	}),
	t.object({
		type: t.literal("buyTavern"),
		kind: S
	}),
	t.object({
		type: t.literal("upgrade"),
		area: oe,
		returns: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("recruitGuest"),
		source: t.enum(["display", "three"]),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("recruitNoble"),
		tier: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("useCounter"),
		mode: t.enum(["redraw", "monastery"])
	}),
	t.object({
		type: t.literal("removeGuest"),
		seat: t.int().nonnegative()
	}),
	t.object({ type: t.literal("skipRemove") }),
	t.object({ type: t.literal("endServing") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = (e) => ({ code: `games.tavernsoftiefenthal.${e}` }), M = () => ({
	barback: 0,
	dishwasher: 0,
	server: 0,
	table: 0,
	brewer: 0
}), de = () => ({
	dishwasher: !1,
	server: !1,
	cashbox: !1,
	monk: !1,
	table: !1,
	barrel: !1,
	safe: !1,
	storage: !1,
	brewer: !1
}), fe = () => ({
	server: 0,
	dishwasher: 0,
	table: 0
});
function N(t, n) {
	for (let r = t.length - 1; r > 0; --r) {
		let i = e(n.seed, n.rngCursor, r + 1);
		n.rngCursor += 1, [t[r], t[i]] = [t[i], t[r]];
	}
	return t;
}
function P(t, n = 6) {
	let r = e(t.seed, t.rngCursor, n) + 1;
	return t.rngCursor += 1, r;
}
function F(e, t) {
	return e.serial += 1, {
		...t,
		uid: `c${e.serial}`
	};
}
function I(e, t, n) {
	t.deck.push(F(e, n));
}
function L(e, t, n = 1) {
	for (let r = 0; r < n; r += 1) I(e, t, y);
}
function R(e, t) {
	return t.deck.length === 0 && t.discard.length > 0 && (t.deck = N(t.discard, e), t.discard = []), t.deck.pop() ?? null;
}
function pe(e, t) {
	return 3 + (t.upgrades.table && e.turn >= t.upgradeReady.table ? 1 : 0);
}
function me(e, t) {
	let n = pe(e, t);
	for (; t.seats.length < n;) t.seats.push({
		card: null,
		extraNobles: 0
	});
	for (; t.seats.length > n;) {
		let e = t.seats.pop();
		e?.card && t.discard.push(e.card);
	}
}
function he(e, t) {
	me(e, t);
	for (let n = 0; n < 80; n += 1) {
		if (t.seats.every((e) => e.card)) return;
		let n = R(e, t);
		if (!n) return;
		if (n.kind === "tavern") {
			t.zones[n.tavern] += 1, n.tavern === "table" && t.seats.push({
				card: null,
				extraNobles: 0
			});
			continue;
		}
		if (n.kind === "noble") {
			let e = t.seats.find((e) => e.card && e.card.kind === "noble");
			if (e) {
				e.extraNobles += 1;
				continue;
			}
		}
		let r = t.seats.find((e) => !e.card);
		r ? r.card = n : t.discard.push(n);
	}
}
function ge(e, t) {
	for (let n of t.seats) {
		n.card && t.discard.push(n.card);
		for (let r = 0; r < n.extraNobles; r += 1) t.discard.push(F(e, y));
		n.card = null, n.extraNobles = 0;
	}
	t.zones = M(), t.dice = [], t.coaster = [], t.ready = !1, t.dishesUsed = 0, t.bought = [], t.guestBought = !1, t.pendingRemove = !1, t.bonusDiceIds = [];
}
function z(e, t, n, r = !1) {
	let i = t.dice.filter((e) => e.color === "player").length, a = Math.max(0, 3 - i);
	for (let i = 0; i < Math.min(n, a); i += 1) {
		e.serial += 1;
		let n = {
			id: `d${e.serial}`,
			value: P(e),
			color: "player",
			slot: null,
			boost: 0,
			used: !1
		};
		t.dice.push(n), r && t.bonusDiceIds.push(n.id);
	}
}
function _e(e, t) {
	let n = e.guest3.pop();
	n && I(e, t, n), n && e.guest3.length === 0 && e.guestDeck.length > 0 && e.guestDisplay.push(e.guestDeck.pop());
}
function B(e, t, n, r) {
	switch (n) {
		case "beer1":
			t.beer += 1;
			break;
		case "beer2":
			t.beer += 2;
			break;
		case "coins2":
			t.coins += 2;
			break;
		case "coins3":
			t.coins += 3;
			break;
		case "coins4":
			t.coins += 4;
			break;
		case "monastery1":
			V(e, t, 1);
			break;
		case "noble":
			L(e, t);
			break;
		case "guest3":
			_e(e, t);
			break;
		case "tableCard":
			I(e, t, h("table"));
			break;
		case "serviceDenied": t.seats.some((e) => e.card && e.card.kind !== "noble") && (t.pendingRemove = !0);
	}
}
function V(e, t, n) {
	for (let r = 0; r < n; r += 1) {
		t.monastery = t.monastery >= 22 ? 0 : t.monastery + 1;
		let n = ie[t.monastery];
		n && (n.kind === "tavern" ? I(e, t, h(n.card)) : n.kind === "noble" ? L(e, t) : n.kind === "guest3" ? _e(e, t) : n.kind === "coins" ? t.coins += n.n : n.kind === "beer" ? t.beer += n.n : n.kind === "serviceDenied" ? t.seats.some((e) => e.card && e.card.kind !== "noble") && (t.pendingRemove = !0) : n.kind === "monastery" && V(e, t, n.n));
	}
}
function ve(e) {
	let t = b[e.turn];
	e.bonusOptions = [];
	for (let n of Object.values(e.ps)) n.bonusDone = !1, t.kind === "counter" ? (n.counters += 1, n.bonusDone = !0) : e.bonusOptions = t.kind === "choice" ? [...t.options] : ["freeUpgrade"];
	Object.values(e.ps).every((e) => e.bonusDone) ? xe(e) : e.phase = "bonus";
}
function ye(e, t, n) {
	let r = b[e.turn];
	if (r.kind === "choice") return r.options.includes(n) ? (n === "die" ? z(e, t, 1, !0) : n === "guest3" ? _e(e, t) : I(e, t, h(n)), !0) : !1;
	if (r.kind === "freeUpgrade") {
		if (n === "skip") return !0;
		let r = n;
		return !(r in g) || t.upgrades[r] ? !1 : (t.upgrades[r] = !0, (r === "server" || r === "dishwasher" || r === "table") && (t.upgradeReady[r] = e.turn), !0);
	}
	return !1;
}
function be(e, t) {
	return t.zones.server + (t.upgrades.server && e.turn >= t.upgradeReady.server ? 1 : 0);
}
function xe(e) {
	for (let t of Object.values(e.ps)) he(e, t), z(e, t, be(e, t));
	for (let t of Object.values(e.ps)) t.coaster = [
		P(e),
		P(e),
		P(e),
		P(e)
	];
	e.phase = "draft", e.draftRound = 0, e.draftIndex = e.startIndex;
}
function Se(e, t, n) {
	let r = t.upgrades.dishwasher && e.turn >= t.upgradeReady.dishwasher ? 1 : 0, i = t.zones.dishwasher + r - t.dishesUsed;
	return Math.max(0, Math.min(n, i));
}
function Ce(e, t, n) {
	let r = t.value + t.boost;
	if (n.kind === "seat") {
		let i = e.seats[n.seat ?? -1];
		return !i?.card || e.dice.some((e) => e !== t && e.slot?.kind === "seat" && e.slot.seat === n.seat) ? !1 : i.card.die === r;
	}
	return n.kind === "monk" ? r === 5 : n.kind === "brewer" ? r === 1 || r === 6 : n.kind === "cashbox" || n.kind === "barrel";
}
function we(e) {
	for (let t of Object.values(e.ps)) t.zones.barback > 0 && (t.beer += t.zones.barback);
	e.phase = "serve", e.activeIndex = e.startIndex;
}
function Te(e) {
	let t = {};
	for (let n of Object.values(e.ps)) t[n.rid] = [...n.deck, ...n.discard].reduce((e, t) => e + t.vp, 0), n.discard = [...n.deck, ...n.discard], n.deck = [];
	let n = [...e.players].sort((n, r) => {
		let i = (t[r] ?? 0) - (t[n] ?? 0);
		if (i !== 0) return i;
		let a = e.ps[n], o = e.ps[r];
		return o.coins + o.beer - (a.coins + a.beer);
	}), r = t[n[0]] ?? 0;
	e.winner = n.filter((i) => t[i] === r && e.ps[i].coins + e.ps[i].beer === e.ps[n[0]].coins + e.ps[n[0]].beer), e.ranking = n, e.scores = t, e.phase = "done";
}
function H(e) {
	if (e.turn += 1, e.turn > 8) {
		Te(e);
		return;
	}
	e.startIndex = (e.startIndex + 1) % e.players.length, e.activeIndex = e.startIndex, ve(e);
}
function U(t, n, r) {
	let i = {
		players: n,
		seed: r,
		rngCursor: 0,
		serial: 0,
		turn: 1,
		phase: "bonus",
		startIndex: e(r, 0, n.length),
		activeIndex: 0,
		draftRound: 0,
		draftIndex: 0,
		bonusOptions: [],
		guestDeck: [],
		guest3: [],
		guestDisplay: [],
		ps: {},
		winner: null,
		ranking: null,
		scores: null
	};
	i.rngCursor = 1;
	let a = v.map((e) => F(i, e));
	i.guest3 = a.filter((e) => e.cost === 3), i.guestDeck = N(a.filter((e) => e.cost !== 3), i), i.guestDisplay = i.guestDeck.splice(0, 4);
	for (let e of n) {
		let t = {
			rid: e,
			coins: 0,
			beer: 0,
			deck: [],
			discard: [],
			seats: Array.from({ length: 3 }, () => ({
				card: null,
				extraNobles: 0
			})),
			zones: M(),
			upgrades: de(),
			upgradeReady: fe(),
			monastery: 0,
			counters: 0,
			dice: [],
			coaster: [],
			ready: !1,
			dishesUsed: 0,
			bought: [],
			guestBought: !1,
			pendingRemove: !1,
			bonusDone: !1,
			bonusDiceIds: []
		};
		for (let e of re) I(i, t, e);
		I(i, t, h("server")), I(i, t, h("table")), I(i, t, h("brewer")), t.deck = N(t.deck, i), i.ps[e] = t;
	}
	return i.activeIndex = i.startIndex, ve(i), {
		state: i,
		fx: []
	};
}
function Ee(e) {
	return {
		turn: Math.min(e.turn, 8),
		phase: e.phase,
		startIndex: e.startIndex,
		activeIndex: e.activeIndex,
		draftRound: e.draftRound,
		draftIndex: e.draftIndex,
		bonusOptions: [...e.bonusOptions],
		guestDisplay: e.guestDisplay.map((e) => ({ ...e })),
		guest3Count: e.guest3.length,
		guest3Top: e.guest3.at(-1) ?? null,
		guestDeckCount: e.guestDeck.length,
		players: e.players.map((t) => {
			let n = e.ps[t];
			return {
				rid: t,
				coins: n.coins,
				beer: n.beer,
				deckCount: n.deck.length,
				discardCount: n.discard.length,
				seats: n.seats.map((e) => ({
					card: e.card,
					extraNobles: e.extraNobles
				})),
				zones: { ...n.zones },
				upgrades: { ...n.upgrades },
				upgradeReady: { ...n.upgradeReady },
				monastery: n.monastery,
				counters: n.counters,
				dice: n.dice.map((e) => ({
					...e,
					slot: e.slot ? { ...e.slot } : null
				})),
				ready: n.ready,
				dishesUsed: n.dishesUsed,
				bought: [...n.bought],
				guestBought: n.guestBought,
				pendingRemove: n.pendingRemove,
				bonusDone: n.bonusDone,
				coaster: [...n.coaster]
			};
		}),
		winner: e.winner,
		ranking: e.ranking,
		scores: e.scores
	};
}
function W(e, t, n) {
	if (t.type === "tick") return { state: e };
	if (e.phase === "done") return j("err.done");
	let r = structuredClone(e), i = n.by, a = r.ps[i];
	if (!a) return j("err.player");
	if (t.type === "bonus") return r.phase !== "bonus" || a.bonusDone ? j("err.turn") : ye(r, a, t.pick) ? (a.bonusDone = !0, Object.values(r.ps).every((e) => e.bonusDone) && xe(r), { state: r }) : j("err.target");
	if (t.type === "useCounter" && t.mode === "redraw") {
		if (r.phase !== "draft" || a.counters <= 0 || a.dice.some((e) => e.color === "white")) return j("err.turn");
		--a.counters;
		for (let e of a.seats) {
			e.card && a.discard.push(e.card), e.card = null;
			for (let t = 0; t < e.extraNobles; t += 1) a.discard.push(F(r, y));
			e.extraNobles = 0;
		}
		return a.zones = M(), a.dice = a.dice.filter((e) => a.bonusDiceIds.includes(e.id)), me(r, a), he(r, a), z(r, a, be(r, a)), a.coaster = [
			P(r),
			P(r),
			P(r),
			P(r)
		], { state: r };
	}
	if (t.type === "draftPick") {
		if (r.phase !== "draft" || r.players[r.draftIndex] !== i) return j("err.turn");
		let e = r.players.length, n = r.players[((r.draftIndex - r.draftRound) % e + e) % e], o = r.ps[n].coaster;
		if (t.index >= o.length) return j("err.target");
		let s = o.splice(t.index, 1)[0];
		if (r.serial += 1, a.dice.push({
			id: `d${r.serial}`,
			value: s,
			color: "white",
			slot: null,
			boost: 0,
			used: !1
		}), r.draftIndex = (r.draftIndex + 1) % r.players.length, r.draftIndex === r.startIndex && (r.draftRound += 1, r.draftRound >= 4)) {
			r.phase = "plan";
			for (let e of Object.values(r.ps)) e.ready = !1;
		}
		return { state: r };
	}
	if (t.type === "placeDie") {
		if (r.phase !== "plan" || a.ready) return j("err.turn");
		let e = a.dice.find((e) => e.id === t.dieId);
		if (!e || e.used || e.slot || t.slot.kind === "seat" && (t.slot.seat ?? -1) < 0) return j("err.target");
		let n = Se(r, a, t.boost);
		return n === t.boost ? (e.boost = n, a.dishesUsed += n, Ce(a, e, t.slot) ? (e.slot = t.slot.kind === "seat" ? {
			kind: "seat",
			seat: t.slot.seat
		} : { kind: t.slot.kind }, { state: r }) : (a.dishesUsed -= n, e.boost = 0, j("err.target"))) : j("err.dishwasher");
	}
	if (t.type === "unplace") {
		if (r.phase !== "plan" || a.ready) return j("err.turn");
		let e = a.dice.find((e) => e.id === t.dieId);
		return !e || !e.slot ? j("err.target") : (a.dishesUsed = Math.max(0, a.dishesUsed - e.boost), e.boost = 0, e.slot = null, { state: r });
	}
	if (t.type === "readyPlan") return r.phase === "plan" ? (a.ready = !0, Object.values(r.ps).every((e) => e.ready) && we(r), { state: r }) : j("err.turn");
	if (t.type === "useCounter" && t.mode === "monastery") return a.counters <= 0 ? j("err.turn") : (--a.counters, V(r, a, 1), { state: r });
	if (r.phase !== "serve" || r.players[r.activeIndex] !== i) return j("err.turn");
	if (t.type === "takeDie") {
		let e = a.dice.find((e) => e.id === t.dieId);
		if (!e || !e.slot || e.used) return j("err.target");
		let n = e.slot;
		if (e.used = !0, n.kind === "seat") {
			let e = a.seats[n.seat ?? -1];
			if (!e?.card) return j("err.target");
			a.coins += e.card.coins;
		} else n.kind === "cashbox" ? a.coins += a.upgrades.cashbox ? 3 : 1 : n.kind === "brewer" ? a.beer += (a.upgrades.brewer ? 2 : 1) + a.zones.brewer : n.kind === "barrel" ? a.beer += a.upgrades.barrel ? 2 : 1 : n.kind === "monk" && V(r, a, a.upgrades.monk ? 2 : 1);
		return { state: r };
	}
	if (t.type === "buyTavern") {
		if (a.bought.includes(t.kind)) return j("err.bought");
		let e = ee[t.kind];
		return a.coins < e ? j("err.money") : (a.coins -= e, a.bought.push(t.kind), I(r, a, h(t.kind)), { state: r });
	}
	if (t.type === "upgrade") {
		if (a.upgrades[t.area]) return j("err.upgraded");
		let e = g[t.area], n = t.area in a.zones ? a.zones[t.area] : 0;
		if (t.returns > n) return j("err.target");
		let i = Math.max(0, e.cost - t.returns * e.discount);
		return a.coins < i ? j("err.money") : (a.coins -= i, t.returns > 0 && (a.zones[t.area] -= t.returns), a.upgrades[t.area] = !0, (t.area === "server" || t.area === "dishwasher" || t.area === "table") && (a.upgradeReady[t.area] = r.turn + 1), L(r, a), { state: r });
	}
	if (t.type === "recruitGuest") {
		if (a.guestBought) return j("err.guest");
		let e;
		return e = t.source === "three" ? r.guest3.pop() : r.guestDisplay[t.index], e ? a.beer < e.cost ? j("err.beer") : (a.beer -= e.cost, a.guestBought = !0, t.source === "three" ? r.guest3.length === 0 && r.guestDeck.length > 0 && r.guestDisplay.push(r.guestDeck.pop()) : (r.guestDisplay[t.index] = r.guestDeck.pop() ?? null, r.guestDisplay = r.guestDisplay.filter((e) => !!e)), I(r, a, e), B(r, a, e.bonus, "guest"), { state: r }) : j("err.target");
	}
	if (t.type === "recruitNoble") {
		let e = ae[t.tier];
		return a.beer < e ? j("err.beer") : (a.beer -= e, L(r, a, t.tier + 1), { state: r });
	}
	if (t.type === "removeGuest") {
		if (!a.pendingRemove) return j("err.turn");
		let e = a.seats[t.seat];
		return !e?.card || e.card.kind === "noble" || a.dice.some((e) => !e.used && e.slot?.kind === "seat" && e.slot.seat === t.seat) ? j("err.target") : (e.card = null, a.pendingRemove = !1, { state: r });
	}
	if (t.type === "skipRemove") return a.pendingRemove = !1, { state: r };
	if (t.type === "endServing") {
		if (a.pendingRemove) return j("err.pending");
		let e = a.upgrades.safe ? 5 : 2;
		return a.coins = Math.min(a.coins, e), a.beer = Math.min(a.beer, a.upgrades.storage ? 5 : 2), ge(r, a), (r.activeIndex - r.startIndex + r.players.length) % r.players.length >= r.players.length - 1 ? H(r) : r.activeIndex = (r.activeIndex + 1) % r.players.length, { state: r };
	}
	return j("err.target");
}
var G = {
	meta: x,
	saveCompatibility: { version: "1" },
	schemas: {
		action: A,
		publicView: k,
		privateView: ue
	},
	setup: U,
	reduce(e, t, n) {
		return W(e, t, n);
	},
	viewFor(e, t) {
		let n = e.ps[t];
		return {
			public: Ee(e),
			private: n ? {
				deck: n.deck.map((e) => ({ ...e })),
				discard: n.discard.map((e) => ({ ...e }))
			} : {
				deck: [],
				discard: []
			}
		};
	},
	status(e) {
		return e.phase !== "done" || !e.winner || !e.ranking ? { phase: e.phase } : {
			phase: "done",
			winner: e.winner,
			ranking: e.ranking,
			scores: e.scores ?? void 0
		};
	}
}, K = (e) => e.charAt(0).toUpperCase() + e.slice(1), De = {
	cashbox: "slotCashbox",
	brewer: "slotBrewer",
	barrel: "slotBarrel",
	monk: "slotMonk"
}, Oe = [
	"barback",
	"dishwasher",
	"server",
	"table",
	"brewer"
], ke = [
	"cashbox",
	"brewer",
	"barrel",
	"monk"
], Ae = Array.from({ length: 22 }, (e, t) => t + 1);
function q({ size: e = 14, children: t }) {
	return /* @__PURE__ */ f("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "tt-ico",
		children: t
	});
}
var J = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "8.6",
			fill: "#f0c35a",
			stroke: "#8a5a12",
			strokeWidth: "1.8"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "5",
			fill: "none",
			stroke: "#a8741c",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M9.4 9.8c.8-.6 1.8-.8 2.9-.6",
			stroke: "#fff2c2",
			strokeWidth: "1.3",
			strokeLinecap: "round"
		})
	]
}), Y = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M5.5 7.6h8.6v12.1c0 .8-.6 1.3-1.4 1.3H6.9c-.8 0-1.4-.5-1.4-1.3Z",
			fill: "#d8892c",
			stroke: "#5f3510",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ f("path", {
			d: "M14.1 10.2h2.7c1.3 0 2.2 1 2.2 2.2v2.9c0 1.2-.9 2.2-2.2 2.2h-2.7",
			fill: "none",
			stroke: "#5f3510",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ f("path", {
			d: "M5.2 7.7c0-2.2 2.2-3.5 4.6-3.5s4.6 1.3 4.6 3.5",
			fill: "#fff6dc",
			stroke: "#5f3510",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ f("path", {
			d: "M7 7.4c.5-.7 1.3-1 2.3-1",
			stroke: "#fff",
			strokeWidth: "1",
			strokeLinecap: "round"
		})
	]
}), X = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M12 1.8v5.2M9.6 4.2h4.8",
			stroke: "#f0c35a",
			strokeWidth: "1.7",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "M5.6 21.5V10.6L12 7l6.4 3.6v10.9Z",
			fill: "#5c4630",
			stroke: "#c9a24a",
			strokeWidth: "1.5",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "M10.2 21.5v-5.2a1.8 1.8 0 0 1 3.6 0v5.2",
			fill: "#241708",
			stroke: "#c9a24a",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "9.4",
			r: "1",
			fill: "#f7d97e"
		})
	]
}), je = ({ size: e }) => /* @__PURE__ */ f(q, {
	size: e,
	children: /* @__PURE__ */ f("path", {
		d: "M15.4 3a8.7 8.7 0 1 0 5.4 12.8A7 7 0 0 1 15.4 3Z",
		fill: "#f4d98a",
		stroke: "#8a5a12",
		strokeWidth: "1.3",
		strokeLinejoin: "round"
	})
}), Z = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M4 8.4 6.6 15h10.8L20 8.4l-4.2 2.6L12 5.6 8.2 11Z",
			fill: "#e9c25c",
			stroke: "#7a4a12",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.6 16.6h10.8v1.6H6.6Z",
			fill: "#c99a35",
			stroke: "#7a4a12",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "4",
			cy: "8",
			r: "1.2",
			fill: "#fff0b8"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "20",
			cy: "8",
			r: "1.2",
			fill: "#fff0b8"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "5.2",
			r: "1.2",
			fill: "#fff0b8"
		})
	]
}), Me = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("rect", {
			x: "3",
			y: "8.2",
			width: "18",
			height: "11",
			rx: "1.6",
			fill: "#7a4a24",
			stroke: "#3a2110",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("path", {
			d: "M3 11.4c2.6-2.2 15.4-2.2 18 0",
			stroke: "#c99a35",
			strokeWidth: "1.6",
			fill: "none"
		}),
		/* @__PURE__ */ f("rect", {
			x: "3",
			y: "6.8",
			width: "18",
			height: "4.2",
			rx: "1.6",
			fill: "#8a5628",
			stroke: "#3a2110",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("rect", {
			x: "9.4",
			y: "9.6",
			width: "5.2",
			height: "5.6",
			rx: "1",
			fill: "#e9c25c",
			stroke: "#3a2110",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "0.9",
			fill: "#3a2110"
		})
	]
}), Ne = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [/* @__PURE__ */ f("path", {
		d: "M12 2.6c3.2 0 5.4 2.6 5.4 6.1 0 2.2-.8 3.9-2 5v2.1c2.6 1 4.4 3.3 4.4 6.2H4.2c0-2.9 1.8-5.2 4.4-6.2v-2.1c-1.2-1.1-2-2.8-2-5 0-3.5 2.2-6.1 5.4-6.1Z",
		fill: "#7d7a72",
		stroke: "#3c3a34",
		strokeWidth: "1.3",
		strokeLinejoin: "round"
	}), /* @__PURE__ */ f("path", {
		d: "M9.2 9.4c.8-.9 1.7-1.3 2.8-1.3s2 .4 2.8 1.3c-.2 1.6-1.2 2.6-2.8 2.9-1.6-.3-2.6-1.3-2.8-2.9Z",
		fill: "#2b2924"
	})]
}), Pe = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M8 4h8c1.6 2 2.4 4.6 2.4 8s-.8 6-2.4 8H8c-1.6-2-2.4-4.6-2.4-8S6.4 6 8 4Z",
			fill: "#9a6231",
			stroke: "#4a2a13",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.2 8.4h11.6M5.6 12h12.8M6.2 15.6h11.6",
			stroke: "#3d220f",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ f("path", {
			d: "M8.3 4.2c-.9 2-1.4 4.8-1.4 7.8s.5 5.8 1.4 7.8",
			stroke: "#d9a45e",
			strokeWidth: "1.1",
			fill: "none"
		})
	]
}), Fe = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M6 8h12l-1.2 11.2c-.1 1-1 1.8-2 1.8H9.2c-1 0-1.9-.8-2-1.8Z",
			fill: "#b46a34",
			stroke: "#5a2e13",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.4 8c-.6-1.6.4-3 2-3h7.2c1.6 0 2.6 1.4 2 3",
			fill: "#cf8244",
			stroke: "#5a2e13",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M17.6 10.4c1.8 0 3 1.3 3 3s-1.2 3-3 3",
			fill: "none",
			stroke: "#5a2e13",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ f("path", {
			d: "M5.6 11.2C4.2 11.6 3.4 12.8 3.4 14.2",
			fill: "none",
			stroke: "#5a2e13",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("path", {
			d: "M10 5V2.8h4V5",
			fill: "none",
			stroke: "#5a2e13",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M10.6 11.8c1-.8 2.8-.8 3.8 0",
			stroke: "#f0c089",
			strokeWidth: "1.1",
			strokeLinecap: "round",
			fill: "none"
		}),
		/* @__PURE__ */ f("path", {
			d: "M15.4 2.2c1 .5 1 1.5 0 2M17.2 1.2c1.4.8 1.4 2.4 0 3.2",
			stroke: "#c9b79b",
			strokeWidth: "1",
			fill: "none",
			strokeLinecap: "round"
		})
	]
}), Q = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("ellipse", {
			cx: "12",
			cy: "8.4",
			rx: "8.2",
			ry: "3.4",
			fill: "#9a6231",
			stroke: "#4a2a13",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.6 10.8 5.4 21M17.4 10.8 18.6 21M12 11.8V21",
			stroke: "#5a3618",
			strokeWidth: "1.7",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ f("ellipse", {
			cx: "12",
			cy: "8",
			rx: "6.4",
			ry: "2.2",
			fill: "none",
			stroke: "#d9a45e",
			strokeWidth: "1"
		})
	]
}), Ie = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("ellipse", {
			cx: "12",
			cy: "14",
			rx: "9",
			ry: "3.4",
			fill: "#cfd6d8",
			stroke: "#5b6467",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("ellipse", {
			cx: "12",
			cy: "13.2",
			rx: "6.2",
			ry: "2",
			fill: "#eef3f4",
			stroke: "#8a9598",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "8.4",
			cy: "7.4",
			r: "1.6",
			fill: "#fff",
			stroke: "#8a9598",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12.6",
			cy: "5.2",
			r: "2",
			fill: "none",
			stroke: "#8a9598",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "16",
			cy: "8",
			r: "1.3",
			fill: "#fff",
			stroke: "#8a9598",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("path", {
			d: "M18.4 4.4v3M16.9 5.9h3",
			stroke: "#e9c25c",
			strokeWidth: "1.1",
			strokeLinecap: "round"
		})
	]
}), Le = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("ellipse", {
			cx: "12",
			cy: "16.4",
			rx: "9.4",
			ry: "2.6",
			fill: "#b98a4c",
			stroke: "#5a3a16",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M3 16.2c0-1.2 4-2.2 9-2.2s9 1 9 2.2",
			fill: "#d6a765"
		}),
		/* @__PURE__ */ f("path", {
			d: "M10.4 13.6V9.4h3.4v4.2",
			fill: "#f0d9ab",
			stroke: "#5a3a16",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ f("path", {
			d: "M13.8 10.2h1.6c.7 0 1.2.5 1.2 1.2s-.5 1.2-1.2 1.2h-1.6",
			fill: "none",
			stroke: "#5a3a16",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("path", {
			d: "M9.6 4.8c.9-.9 2-.9 2.9 0M13.4 3.2c.9-.9 2-.9 2.9 0",
			stroke: "#e9dcbf",
			strokeWidth: "1",
			fill: "none",
			strokeLinecap: "round"
		})
	]
}), Re = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("rect", {
			x: "3.6",
			y: "4.4",
			width: "16.8",
			height: "15.2",
			rx: "2",
			fill: "#6d6a63",
			stroke: "#2f2d29",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("rect", {
			x: "6.2",
			y: "7",
			width: "11.6",
			height: "10",
			rx: "1.2",
			fill: "none",
			stroke: "#a8a49b",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "12",
			r: "2.6",
			fill: "#d8d2c4",
			stroke: "#2f2d29",
			strokeWidth: "1.2"
		}),
		/* @__PURE__ */ f("path", {
			d: "M12 9.8v2.2l1.4 1.2",
			stroke: "#2f2d29",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("path", {
			d: "M18 13.4h1",
			stroke: "#c9a24a",
			strokeWidth: "1.6"
		})
	]
}), ze = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M4 14.4h16V20H4Z",
			fill: "#6b4423",
			stroke: "#3a2110",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.6 9.8h2.2v4.6H6.6Zm4.3-3.2h2.2v7.8h-2.2Zm4.3 1.6h2.2v6.2h-2.2Z",
			fill: "#3f6d5f",
			stroke: "#24443a",
			strokeWidth: "1.1"
		}),
		/* @__PURE__ */ f("path", {
			d: "M7.7 6.8v3M12 3.6v3M16.6 5.4v2.8",
			stroke: "#a9c9bf",
			strokeWidth: "1.6",
			strokeLinecap: "round"
		})
	]
}), Be = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M7 8h10l.8 9.4c.1 1.2-.8 2.1-2 2.1H8.2c-1.2 0-2.1-.9-2-2.1Z",
			fill: "#a06a34",
			stroke: "#4a2a13",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M6.8 11h10.4M6.6 15.4h10.8",
			stroke: "#3d220f",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M12 5.2V8M9.8 5.2h4.4",
			stroke: "#d9a45e",
			strokeWidth: "1.3",
			strokeLinecap: "round"
		})
	]
}), Ve = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("path", {
			d: "M4.6 21.4v-2.2c0-3 2.4-5.2 5.4-5.2h4c3 0 5.4 2.2 5.4 5.2v2.2Z",
			fill: "#8a5a2b",
			stroke: "#42260f",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "8.2",
			r: "4.4",
			fill: "#c99a6a",
			stroke: "#42260f",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M7.8 6.4c.6-2.2 2.2-3.4 4.2-3.4s3.6 1.2 4.2 3.4c-1-.6-2.2-1-4.2-1s-3.2.4-4.2 1Z",
			fill: "#5b3a1c"
		})
	]
}), He = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [/* @__PURE__ */ p("g", {
		opacity: ".85",
		children: [/* @__PURE__ */ f("path", {
			d: "M5.6 21.4v-1.8c0-2.6 2-4.4 4.6-4.4h3.6c2.6 0 4.6 1.8 4.6 4.4v1.8Z",
			fill: "#8a5a2b",
			stroke: "#42260f",
			strokeWidth: "1.2"
		}), /* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "9",
			r: "3.8",
			fill: "#c99a6a",
			stroke: "#42260f",
			strokeWidth: "1.2"
		})]
	}), /* @__PURE__ */ f("path", {
		d: "M4.4 20.2 19.6 3.8",
		stroke: "#c2452f",
		strokeWidth: "2.4",
		strokeLinecap: "round"
	})]
}), Ue = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("rect", {
			x: "7",
			y: "4",
			width: "11",
			height: "14",
			rx: "1.4",
			fill: "#e6d2a8",
			stroke: "#8a5a2b",
			strokeWidth: "1.2",
			transform: "rotate(6 12 11)"
		}),
		/* @__PURE__ */ f("rect", {
			x: "4.6",
			y: "6.2",
			width: "11",
			height: "14",
			rx: "1.4",
			fill: "#f4e4c0",
			stroke: "#8a5a2b",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ f("path", {
			d: "M7.4 10h5.4M7.4 12.6h5.4M7.4 15.2h3.6",
			stroke: "#b08a52",
			strokeWidth: "1"
		})
	]
}), We = ({ size: e }) => /* @__PURE__ */ p(q, {
	size: e,
	children: [
		/* @__PURE__ */ f("rect", {
			x: "4.4",
			y: "3.6",
			width: "15.2",
			height: "16.8",
			rx: "1.8",
			fill: "#6e4a24",
			stroke: "#331d0c",
			strokeWidth: "1.4"
		}),
		/* @__PURE__ */ f("rect", {
			x: "6.8",
			y: "6",
			width: "10.4",
			height: "12",
			rx: "1",
			fill: "none",
			stroke: "#c9a24a",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ f("path", {
			d: "M12 8.6v6.8M8.6 12h6.8",
			stroke: "#c9a24a",
			strokeWidth: ".9",
			opacity: ".55"
		})
	]
}), Ge = {
	barback: Be,
	dishwasher: Ie,
	server: Le,
	table: Q,
	brewer: Fe
}, Ke = {
	dishwasher: Ie,
	server: Le,
	cashbox: Me,
	monk: Ne,
	table: Q,
	barrel: Pe,
	safe: Re,
	storage: ze,
	brewer: Fe
}, qe = {
	beer1: {
		Icon: Y,
		n: 1
	},
	beer2: {
		Icon: Y,
		n: 2
	},
	coins2: {
		Icon: J,
		n: 2
	},
	coins3: {
		Icon: J,
		n: 3
	},
	coins4: {
		Icon: J,
		n: 4
	},
	monastery1: {
		Icon: X,
		n: 1
	},
	noble: { Icon: Z },
	guest3: {
		Icon: Ve,
		n: 3
	},
	tableCard: { Icon: Q },
	serviceDenied: { Icon: He }
}, Je = {
	none: void 0,
	guest3: Ve,
	noble: Z,
	coins: J,
	beer: Y,
	serviceDenied: He,
	monastery: X,
	tavern: void 0
};
function Ye({ reward: e }) {
	if (!e) return null;
	let t = e.kind === "tavern" ? Ge[e.card] : Je[e.kind];
	return t ? /* @__PURE__ */ f(t, { size: 11 }) : null;
}
var Xe = {
	1: [[50, 50]],
	2: [[30, 30], [70, 70]],
	3: [
		[26, 26],
		[50, 50],
		[74, 74]
	],
	4: [
		[30, 30],
		[70, 30],
		[30, 70],
		[70, 70]
	],
	5: [
		[28, 28],
		[72, 28],
		[50, 50],
		[28, 72],
		[72, 72]
	],
	6: [
		[30, 26],
		[70, 26],
		[30, 50],
		[70, 50],
		[30, 74],
		[70, 74]
	]
};
function Ze({ value: e, color: t, boost: n, size: r = 26 }) {
	return /* @__PURE__ */ p("span", {
		className: `tt-die tt-die--${t}`,
		style: {
			width: r,
			height: r
		},
		"aria-hidden": !0,
		children: [(Xe[e] ?? []).map(([e, t], n) => /* @__PURE__ */ f("i", { style: {
			left: `${e}%`,
			top: `${t}%`
		} }, n)), n ? /* @__PURE__ */ p("b", {
			className: "tt-die-boost",
			children: ["+", n]
		}) : null]
	});
}
function Qe({ show: e }) {
	return e ? /* @__PURE__ */ f("svg", {
		className: "tt-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "1",
			y: "1",
			width: "98",
			height: "98",
			vectorEffect: "non-scaling-stroke"
		})
	}) : null;
}
function $e({ variant: e, onClick: t, disabled: n, label: r, title: i, className: a, children: o }) {
	let s = `tt-card tt-card--${e}${a ? ` ${a}` : ""}`;
	return t ? /* @__PURE__ */ f("button", {
		type: "button",
		className: s,
		onClick: t,
		disabled: n,
		"aria-label": r,
		title: i,
		children: o
	}) : /* @__PURE__ */ f("span", {
		className: s,
		title: i,
		children: o
	});
}
function et(e) {
	return {
		none: "none",
		beer1: "guestBonusBeer1",
		beer2: "guestBonusBeer2",
		coins2: "guestBonusCoins2",
		coins3: "guestBonusCoins3",
		coins4: "guestBonusCoins4",
		monastery1: "guestBonusMonastery",
		noble: "guestBonusNoble",
		guest3: "guestBonusGuest3",
		tableCard: "guestBonusTable",
		serviceDenied: "guestBonusService"
	}[e];
}
function $(e, t) {
	return t.kind === "regular" ? e("games.tavernsoftiefenthal.cardRegular") : t.kind === "noble" ? e("games.tavernsoftiefenthal.cardNoble") : t.kind === "tavern" ? e(`games.tavernsoftiefenthal.card${K(t.tavern)}`) : e("games.tavernsoftiefenthal.cardGuest");
}
var tt = (e, t) => e(`games.tavernsoftiefenthal.up${K(t)}`), nt = (e, t) => e(`games.tavernsoftiefenthal.card${K(t)}`);
function rt({ card: e, extra: t = 0 }) {
	let n = i(), r = e.kind === "guest" ? /* @__PURE__ */ f(Ve, { size: 26 }) : e.kind === "noble" ? /* @__PURE__ */ f(Z, { size: 24 }) : e.kind === "regular" ? /* @__PURE__ */ f(Y, { size: 24 }) : (() => {
		let t = Ge[e.tavern];
		return /* @__PURE__ */ f(t, { size: 24 });
	})(), a = e.bonus === "none" ? void 0 : qe[e.bonus];
	return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ p("span", {
			className: "tt-card-top",
			children: [/* @__PURE__ */ f("span", {
				className: "tt-card-tl",
				children: e.kind === "guest" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Y, { size: 10 }), e.cost] }) : e.kind === "noble" ? /* @__PURE__ */ f(Z, { size: 11 }) : /* @__PURE__ */ f("span", {
					className: "tt-card-kind",
					children: $(n, e)
				})
			}), e.vp > 0 ? /* @__PURE__ */ f("span", {
				className: "tt-card-vp",
				"aria-label": `${n("games.tavernsoftiefenthal.vp")} ${e.vp}`,
				children: e.vp
			}) : null]
		}),
		/* @__PURE__ */ f("span", {
			className: `tt-card-art${e.kind === "guest" ? ` tt-tier-${e.cost}` : ""}`,
			children: r
		}),
		a ? /* @__PURE__ */ p("span", {
			className: "tt-card-bonus",
			title: n(`games.tavernsoftiefenthal.${et(e.bonus)}`),
			children: [/* @__PURE__ */ f(a.Icon, { size: 10 }), a.n ?? ""]
		}) : /* @__PURE__ */ f("span", { className: "tt-card-bonus tt-card-bonus--none" }),
		/* @__PURE__ */ p("span", {
			className: "tt-card-bottom",
			children: [e.die > 0 ? /* @__PURE__ */ p("span", {
				className: "tt-card-req",
				children: [/* @__PURE__ */ f(it, {}), e.die]
			}) : /* @__PURE__ */ f("span", {}), e.coins > 0 ? /* @__PURE__ */ p("span", {
				className: "tt-card-earn",
				children: [/* @__PURE__ */ f(J, { size: 10 }), e.coins]
			}) : null]
		}),
		t > 0 ? /* @__PURE__ */ p("span", {
			className: "tt-card-extra",
			children: ["+", t]
		}) : null
	] });
}
function it() {
	return /* @__PURE__ */ p("svg", {
		className: "tt-mini-die",
		width: "9",
		height: "9",
		viewBox: "0 0 10 10",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("rect", {
			x: "1",
			y: "1",
			width: "8",
			height: "8",
			rx: "2",
			fill: "#f6ecd4",
			stroke: "#7a5a2a"
		}), /* @__PURE__ */ f("circle", {
			cx: "5",
			cy: "5",
			r: "1.2",
			fill: "#2f2417"
		})]
	});
}
function at({ card: e, extra: t, onClick: n, disabled: r, label: i }) {
	return /* @__PURE__ */ f($e, {
		variant: e.kind,
		onClick: n,
		disabled: r,
		label: i,
		children: /* @__PURE__ */ f(rt, {
			card: e,
			extra: t
		})
	});
}
function ot({ area: e, zoneCount: t, upgraded: n, pending: r, selected: a, onClick: o }) {
	let s = i(), c = g[e], l = Ke[e], u = tt(s, e), d = s(`games.tavernsoftiefenthal.benefit${K(e)}`), m = s(n ? r ? "games.tavernsoftiefenthal.upgradeNextTurn" : "games.tavernsoftiefenthal.upgraded" : "games.tavernsoftiefenthal.notUpgraded");
	return /* @__PURE__ */ p($e, {
		variant: "facility",
		onClick: o,
		label: `${u} · ${d} · ${m}`,
		title: d,
		className: `${n ? "is-done" : ""}${a ? " is-sel" : ""}`,
		children: [
			/* @__PURE__ */ p("span", {
				className: "tt-card-top",
				children: [/* @__PURE__ */ p("span", {
					className: "tt-card-fee",
					children: [/* @__PURE__ */ f(J, { size: 10 }), c.cost]
				}), c.discount > 0 ? /* @__PURE__ */ p("span", {
					className: "tt-card-disc",
					children: ["−", c.discount]
				}) : null]
			}),
			/* @__PURE__ */ f("span", {
				className: "tt-card-art",
				children: /* @__PURE__ */ f(l, { size: 24 })
			}),
			/* @__PURE__ */ f("span", {
				className: "tt-card-kind tt-card-kind--fac",
				children: u
			}),
			/* @__PURE__ */ p("span", {
				className: "tt-card-bottom",
				children: [/* @__PURE__ */ f("span", {
					className: `tt-fac-state${n ? " is-on" : ""}`,
					children: m
				}), t > 0 ? /* @__PURE__ */ p("span", {
					className: "tt-fac-zone",
					children: ["×", t]
				}) : null]
			})
		]
	});
}
function st({ public: e, private: t, members: m, myRid: h, send: _ }) {
	let v = e, re = t, b = i(), x = r((e) => e.locale);
	o();
	let S = v.players.find((e) => e.rid === h), oe = v.players.findIndex((e) => e.rid === h), C = v.players[v.activeIndex], w = v.phase === "serve" && C?.rid === h, T = `${v.phase}|${v.turn}|${v.activeIndex}`, [E, se] = n({
		key: T,
		die: null,
		boost: 0
	}), [ce, le] = n({
		key: T,
		focus: null
	}), D = E.key === T ? E.die : null, O = E.key === T ? E.boost : 0, k = ce.key === T ? ce.focus : null, ue = (e) => se((t) => ({
		key: T,
		die: e,
		boost: e === null ? 0 : t.key === T ? t.boost : 0
	})), A = (e) => se((t) => ({
		key: T,
		die: t.key === T ? t.die : null,
		boost: e
	})), j = (e) => le({
		key: T,
		focus: e
	});
	if (!S) return /* @__PURE__ */ f(s, {
		className: "tt-screen",
		children: /* @__PURE__ */ f("p", { children: b("games.tavernsoftiefenthal.errPlayer") })
	});
	let M = (e) => m.find((t) => t.rid === e), de = (e) => {
		let t = M(e);
		return t ? u(t, x) : b("games.tavernsoftiefenthal.name");
	}, fe = M(h), N = a[(fe?.colorIndex ?? 0) % a.length].hex, P = v.phase === "bonus" && !S.bonusDone, F = v.phase === "draft" && v.draftIndex === oe, I = v.phase === "plan" && !S.ready, L = S.upgrades.dishwasher && v.turn >= S.upgradeReady.dishwasher ? 1 : 0, R = Math.max(0, S.zones.dishwasher + L - S.dishesUsed), pe = v.players[((oe - v.draftRound) % v.players.length + v.players.length) % v.players.length], me = pe?.coaster ?? [], he = S.dice.some((e) => e.color === "white"), ge = v.phase === "draft" && S.counters > 0 && !he, z = S.dice.filter((e) => !e.slot), _e = S.dice.filter((e) => e.slot).length, B = D ? S.dice.find((e) => e.id === D) : void 0, V = B ? B.value + O : 0, ve = S.dice.filter((e) => e.slot && !e.used).length, ye = (e) => S.dice.some((t) => t.slot?.kind === "seat" && t.slot.seat === e), be = (e) => {
		let t = S.seats[e]?.card;
		return !!(I && B && !B.slot && t && t.die === V && !ye(e));
	}, xe = (e) => !I || !B || B.slot ? !1 : e === "cashbox" || e === "barrel" ? !0 : e === "monk" ? V === 5 : V === 1 || V === 6, Se = (e) => {
		D && (_({
			type: "placeDie",
			dieId: D,
			slot: e,
			boost: O
		}), ue(null), A(0));
	}, Ce = (e) => {
		let t = S.dice.find((t) => t.id === e);
		t && (ue(e), A(t.slot ? t.boost : 0));
	}, we = (e) => {
		if (v.phase === "serve" && w && S.pendingRemove) {
			let t = S.seats[e]?.card, n = S.dice.some((t) => !t.used && t.slot?.kind === "seat" && t.slot.seat === e);
			t && t.kind !== "noble" && !n && _({
				type: "removeGuest",
				seat: e
			});
			return;
		}
		if (!I) return;
		if (be(e)) {
			Se({
				kind: "seat",
				seat: e
			});
			return;
		}
		let t = S.dice.find((t) => t.slot?.kind === "seat" && t.slot.seat === e);
		t && Ce(t.id);
	}, Te = (e) => {
		if (I) {
			if (xe(e)) {
				Se({ kind: e });
				return;
			}
			let t = S.dice.find((t) => t.slot?.kind === e);
			t && Ce(t.id);
			return;
		}
		if (v.phase === "serve" && w) {
			let t = S.dice.find((t) => t.slot?.kind === e && !t.used);
			t && _({
				type: "takeDie",
				dieId: t.id
			});
		}
	}, H = "info", U = "";
	v.phase === "bonus" ? (H = P ? "accent" : "info", U = b(P ? "games.tavernsoftiefenthal.chooseBonus" : "games.tavernsoftiefenthal.planWaiting")) : v.phase === "draft" ? (H = F ? "accent" : "info", U = F ? b("games.tavernsoftiefenthal.draftPrompt") : b("games.tavernsoftiefenthal.draftWaiting", { name: de(v.players[v.draftIndex]?.rid ?? "") })) : v.phase === "plan" ? (H = I ? "accent" : "info", U = b(I ? "games.tavernsoftiefenthal.planPrompt" : "games.tavernsoftiefenthal.readyWaiting")) : v.phase === "serve" && (H = w ? "accent" : "info", U = w ? b("games.tavernsoftiefenthal.servePrompt") : b("games.tavernsoftiefenthal.serveWaiting", { name: C ? de(C.rid) : "" }));
	let Ee = v.phase === "bonus" ? v.bonusOptions.includes("freeUpgrade") ? [...ne.filter((e) => !S.upgrades[e]).map((e) => ({
		key: e,
		label: `${b("games.tavernsoftiefenthal.bonusFreeUpgrade")} · ${tt(b, e)}`,
		pick: e
	})), {
		key: "skip",
		label: b("games.tavernsoftiefenthal.bonusSkip"),
		pick: "skip"
	}] : v.bonusOptions.map((e) => ({
		key: e,
		label: b(`games.tavernsoftiefenthal.bonus${K(e)}`),
		pick: e
	})) : [], W = k ? g[k.area] : null, G = k && k.area in S.zones ? S.zones[k.area] ?? 0 : 0, q = k ? Math.min(k.returns, G) : 0, Z = W ? Math.max(0, W.cost - q * W.discount) : 0, Me = /* @__PURE__ */ p("div", {
		className: "tt-actions",
		children: [
			v.phase === "bonus" && (P ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
				className: "tt-act-label",
				children: b("games.tavernsoftiefenthal.chooseBonus")
			}), /* @__PURE__ */ f("span", {
				className: "tt-act-chips",
				children: Ee.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-chip",
					onClick: () => _({
						type: "bonus",
						pick: e.pick
					}),
					children: e.label
				}, e.key))
			})] }) : /* @__PURE__ */ f("span", {
				className: "tt-act-label",
				children: b("games.tavernsoftiefenthal.planWaiting")
			})),
			v.phase === "draft" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("span", {
					className: "tt-act-label",
					children: F ? b("games.tavernsoftiefenthal.draftPrompt") : U
				}),
				/* @__PURE__ */ f("span", {
					className: "tt-act-sub",
					children: b("games.tavernsoftiefenthal.draftRound", { n: v.draftRound + 1 })
				}),
				ge && /* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn",
					onClick: () => _({
						type: "useCounter",
						mode: "redraw"
					}),
					children: b("games.tavernsoftiefenthal.useCounterRedraw")
				})
			] }),
			v.phase === "plan" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("span", {
					className: "tt-act-label",
					children: D ? B?.slot ? b("games.tavernsoftiefenthal.hintUnplace") : b("games.tavernsoftiefenthal.tapTargetHint") : z.length > 0 ? b("games.tavernsoftiefenthal.selectDieHint") : b("games.tavernsoftiefenthal.planPrompt")
				}),
				B?.slot && /* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn",
					onClick: () => {
						_({
							type: "unplace",
							dieId: B.id
						}), ue(null), A(0);
					},
					children: b("games.tavernsoftiefenthal.unplace")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn tt-btn--primary",
					disabled: z.length > 0,
					onClick: () => _({ type: "readyPlan" }),
					title: z.length > 0 ? b("games.tavernsoftiefenthal.needPlace") : void 0,
					children: b("games.tavernsoftiefenthal.readyPlan")
				})
			] }),
			v.phase === "serve" && (k && W ? /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("span", {
					className: "tt-act-label",
					children: tt(b, k.area)
				}),
				W.discount > 0 && G > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
					className: "tt-act-sub",
					children: b("games.tavernsoftiefenthal.returnsHint")
				}), /* @__PURE__ */ p("span", {
					className: "tt-stepper",
					children: [
						/* @__PURE__ */ f("button", {
							type: "button",
							"aria-label": b("games.tavernsoftiefenthal.returns"),
							onClick: () => j({
								...k,
								returns: Math.max(0, q - 1)
							}),
							children: "−"
						}),
						/* @__PURE__ */ p("b", { children: [
							b("games.tavernsoftiefenthal.returns"),
							" ",
							q,
							"/",
							G
						] }),
						/* @__PURE__ */ f("button", {
							type: "button",
							"aria-label": b("games.tavernsoftiefenthal.returns"),
							onClick: () => j({
								...k,
								returns: Math.min(G, q + 1)
							}),
							children: "＋"
						})
					]
				})] }),
				/* @__PURE__ */ p("span", {
					className: "tt-act-cost",
					children: [/* @__PURE__ */ f(J, { size: 12 }), Z]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn tt-btn--primary",
					disabled: S.coins < Z,
					onClick: () => {
						_({
							type: "upgrade",
							area: k.area,
							returns: q
						}), j(null);
					},
					children: b("games.tavernsoftiefenthal.upgrade")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn",
					onClick: () => j(null),
					children: b("games.tavernsoftiefenthal.cancel")
				})
			] }) : w ? /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("span", {
					className: "tt-act-label",
					children: S.pendingRemove ? b("games.tavernsoftiefenthal.removeGuestPrompt") : b("games.tavernsoftiefenthal.serveTapHint")
				}),
				S.counters > 0 && /* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn",
					onClick: () => _({
						type: "useCounter",
						mode: "monastery"
					}),
					children: b("games.tavernsoftiefenthal.useCounterMonastery")
				}),
				S.pendingRemove && /* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn",
					onClick: () => _({ type: "skipRemove" }),
					children: b("games.tavernsoftiefenthal.skipRemove")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "tt-btn tt-btn--primary",
					disabled: S.pendingRemove,
					onClick: () => _({ type: "endServing" }),
					children: b("games.tavernsoftiefenthal.endServing")
				})
			] }) : /* @__PURE__ */ f("span", {
				className: "tt-act-label",
				children: U
			}))
		]
	}), Ne = v.phase === "draft" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("span", {
			className: "tt-tray-label",
			children: b("games.tavernsoftiefenthal.coaster")
		}),
		/* @__PURE__ */ p("span", {
			className: `tt-coaster${F ? "" : " is-idle"}`,
			children: [me.map((e, t) => /* @__PURE__ */ f("button", {
				type: "button",
				className: "tt-coaster-die",
				disabled: !F,
				onClick: () => _({
					type: "draftPick",
					index: t
				}),
				"aria-label": b("games.tavernsoftiefenthal.hintDraft", { n: e }),
				children: /* @__PURE__ */ f(Ze, {
					value: e,
					color: "white",
					size: 32
				})
			}, `${e}-${t}`)), me.length === 0 && /* @__PURE__ */ f("span", {
				className: "tt-tray-note",
				children: b("games.tavernsoftiefenthal.none")
			})]
		}),
		/* @__PURE__ */ p("span", {
			className: "tt-tray-side",
			children: [/* @__PURE__ */ f("b", { children: b("games.tavernsoftiefenthal.draftRound", { n: v.draftRound + 1 }) }), /* @__PURE__ */ f("small", { children: pe ? b("games.tavernsoftiefenthal.coasterOwner", { name: de(pe.rid) }) : "" })]
		})
	] }) : v.phase === "plan" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("span", {
			className: "tt-tray-label",
			children: b("games.tavernsoftiefenthal.diceTray")
		}),
		/* @__PURE__ */ p("span", {
			className: "tt-tray-dice",
			children: [z.map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				className: `tt-tray-die${D === e.id ? " is-sel" : ""}`,
				onClick: () => Ce(e.id),
				"aria-label": b("games.tavernsoftiefenthal.dieValue", { n: e.value }),
				"aria-pressed": D === e.id,
				children: /* @__PURE__ */ f(Ze, {
					value: e.value,
					color: e.color,
					size: 30
				})
			}, e.id)), z.length === 0 && /* @__PURE__ */ f("span", {
				className: "tt-tray-note",
				children: b("games.tavernsoftiefenthal.placedDice", { n: _e })
			})]
		}),
		/* @__PURE__ */ f("span", {
			className: "tt-tray-side",
			children: B && !B.slot ? /* @__PURE__ */ p("span", {
				className: "tt-boost",
				children: [
					/* @__PURE__ */ f("span", {
						className: "tt-boost-label",
						children: b("games.tavernsoftiefenthal.boostTitle")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": b("games.tavernsoftiefenthal.dishwasherUses", { n: R }),
						onClick: () => A(Math.max(0, O - 1)),
						children: "−"
					}),
					/* @__PURE__ */ f("b", { children: O }),
					/* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": b("games.tavernsoftiefenthal.dishwasherUses", { n: R }),
						onClick: () => A(Math.min(R, O + 1)),
						children: "＋"
					}),
					/* @__PURE__ */ f("small", { children: b("games.tavernsoftiefenthal.dishwasherUses", { n: R }) })
				]
			}) : /* @__PURE__ */ f("span", {
				className: "tt-tray-note",
				children: B?.slot ? b("games.tavernsoftiefenthal.hintUnplace") : z.length > 0 ? b("games.tavernsoftiefenthal.selectDieHint") : b("games.tavernsoftiefenthal.readyPlan")
			})
		})
	] }) : v.phase === "serve" ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("span", {
			className: "tt-tray-label",
			children: b("games.tavernsoftiefenthal.phaseServe")
		}),
		/* @__PURE__ */ f("span", {
			className: "tt-tray-note",
			children: w ? b("games.tavernsoftiefenthal.serveTapHint") : U
		}),
		/* @__PURE__ */ p("span", {
			className: "tt-tray-side",
			children: [/* @__PURE__ */ f("b", { children: b("games.tavernsoftiefenthal.pendingDice", { n: ve }) }), S.counters > 0 && /* @__PURE__ */ p("small", { children: [
				b("games.tavernsoftiefenthal.counters"),
				" ",
				S.counters
			] })]
		})
	] }) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
		className: "tt-tray-label",
		children: b("games.tavernsoftiefenthal.phaseBonus")
	}), /* @__PURE__ */ f("span", {
		className: "tt-tray-note",
		children: P ? b("games.tavernsoftiefenthal.chooseBonus") : U
	})] }), Pe = (e) => {
		if (e && e.kind !== "none") return e.kind === "guest3" ? b("games.tavernsoftiefenthal.guestBonusGuest3") : e.kind === "noble" ? b("games.tavernsoftiefenthal.guestBonusNoble") : e.kind === "coins" ? b(e.n === 3 ? "games.tavernsoftiefenthal.guestBonusCoins3" : "games.tavernsoftiefenthal.guestBonusCoins2") : e.kind === "beer" ? b("games.tavernsoftiefenthal.guestBonusBeer1") : e.kind === "serviceDenied" ? b("games.tavernsoftiefenthal.guestBonusService") : e.kind === "monastery" ? b("games.tavernsoftiefenthal.guestBonusMonastery") : b("games.tavernsoftiefenthal.gainCard", { card: nt(b, e.card) });
	}, Fe = (e) => e === h, Q = v.phase === "serve" ? C?.rid : void 0, Ie = v.players[v.startIndex]?.rid;
	return /* @__PURE__ */ f(s, {
		adaptive: !0,
		scroll: !0,
		className: "tt-screen",
		actionsHeight: "tt-action-slot",
		actions: Me,
		banner: /* @__PURE__ */ p("header", {
			className: "tt-head",
			style: { "--tt-pd": N },
			children: [/* @__PURE__ */ p("div", {
				className: "tt-head-top",
				children: [
					/* @__PURE__ */ p("div", {
						className: "tt-sign",
						"aria-hidden": !0,
						children: [/* @__PURE__ */ f("span", {
							className: "tt-sign-lamp",
							children: v.turn
						}), /* @__PURE__ */ p("span", {
							className: "tt-sign-text",
							children: [/* @__PURE__ */ f("b", { children: b("games.tavernsoftiefenthal.name") }), /* @__PURE__ */ f("small", { children: "TIEFENTHAL" })]
						})]
					}),
					/* @__PURE__ */ f("div", {
						className: "tt-phasebox",
						children: /* @__PURE__ */ f(c, {
							tone: H,
							text: U,
							chip: `${b("games.tavernsoftiefenthal.turn")} ${v.turn} / 8`
						})
					}),
					/* @__PURE__ */ p("div", {
						className: "tt-purse",
						children: [
							/* @__PURE__ */ p("span", {
								className: "tt-purse-chip",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.coins")} ${S.coins}`,
								children: [/* @__PURE__ */ f(J, { size: 13 }), S.coins]
							}),
							/* @__PURE__ */ p("span", {
								className: "tt-purse-chip",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.beer")} ${S.beer}`,
								children: [/* @__PURE__ */ f(Y, { size: 13 }), S.beer]
							}),
							/* @__PURE__ */ p("span", {
								className: "tt-purse-chip",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.monastery")} ${S.monastery}`,
								children: [/* @__PURE__ */ f(X, { size: 13 }), S.monastery]
							}),
							/* @__PURE__ */ p("span", {
								className: "tt-purse-chip",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.counters")} ${S.counters}`,
								children: [/* @__PURE__ */ f(Ve, { size: 13 }), S.counters]
							})
						]
					})
				]
			}), /* @__PURE__ */ f("div", {
				className: "tt-players",
				children: v.players.map((e) => {
					let t = M(e.rid);
					if (!t) return null;
					let n = a[t.colorIndex % a.length].hex, r = Q === e.rid ? "pending" : v.phase === "plan" && e.ready ? "done" : null;
					return /* @__PURE__ */ p("span", {
						className: `tt-player${Fe(e.rid) ? " is-me" : ""}${Q === e.rid ? " is-active" : ""}`,
						style: { "--tt-pc": n },
						children: [
							/* @__PURE__ */ f(l, {
								m: t,
								myRid: h,
								action: r,
								anchorName: null,
								box: "size-8",
								img: "size-7"
							}),
							/* @__PURE__ */ p("span", {
								className: "tt-player-text",
								children: [/* @__PURE__ */ f("span", {
									className: "tt-player-name",
									children: u(t, x)
								}), /* @__PURE__ */ p("span", {
									className: "tt-player-stat",
									children: [
										/* @__PURE__ */ f(J, { size: 10 }),
										e.coins,
										/* @__PURE__ */ f(Y, { size: 10 }),
										e.beer,
										/* @__PURE__ */ f(X, { size: 10 }),
										e.monastery
									]
								})]
							}),
							Ie === e.rid && /* @__PURE__ */ f("span", {
								className: "tt-player-start",
								role: "img",
								"aria-label": b("games.tavernsoftiefenthal.startPlayer"),
								children: /* @__PURE__ */ f(je, { size: 11 })
							})
						]
					}, e.rid);
				})
			})]
		}),
		children: /* @__PURE__ */ p("div", {
			className: "tt-main",
			style: { "--tt-pd": N },
			children: [/* @__PURE__ */ p("section", {
				className: "tt-tavern",
				"aria-label": b("games.tavernsoftiefenthal.yourTavern"),
				children: [
					/* @__PURE__ */ p("div", {
						className: "tt-tavern-head",
						children: [/* @__PURE__ */ f("span", {
							className: "tt-tavern-plaque",
							children: b("games.tavernsoftiefenthal.yourTavern")
						}), /* @__PURE__ */ p("span", {
							className: "tt-piles",
							children: [/* @__PURE__ */ p("span", {
								className: "tt-pile",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.deck")} ${S.deckCount}`,
								children: [/* @__PURE__ */ f(Ue, { size: 18 }), /* @__PURE__ */ f("b", { children: S.deckCount })]
							}), /* @__PURE__ */ p("span", {
								className: "tt-pile",
								role: "img",
								"aria-label": `${b("games.tavernsoftiefenthal.discard")} ${S.discardCount}`,
								children: [/* @__PURE__ */ f(We, { size: 18 }), /* @__PURE__ */ f("b", { children: S.discardCount })]
							})]
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "tt-upper",
						children: [
							/* @__PURE__ */ p("div", {
								className: "tt-upper-decor",
								"aria-hidden": !0,
								children: [
									/* @__PURE__ */ f("span", { className: "tt-window" }),
									/* @__PURE__ */ f("span", { className: "tt-lamp" }),
									/* @__PURE__ */ f("span", { className: "tt-window" }),
									/* @__PURE__ */ f("span", { className: "tt-lamp" }),
									/* @__PURE__ */ f("span", { className: "tt-window" }),
									/* @__PURE__ */ f("span", { className: "tt-lamp" }),
									/* @__PURE__ */ f("span", { className: "tt-window" }),
									/* @__PURE__ */ f("span", { className: "tt-shelf" })
								]
							}),
							/* @__PURE__ */ p("div", {
								className: "tt-rowsign",
								children: [/* @__PURE__ */ f("span", { children: b("games.tavernsoftiefenthal.guestRow") }), /* @__PURE__ */ f("i", { "aria-hidden": !0 })]
							}),
							/* @__PURE__ */ f("div", {
								className: "tt-tables",
								children: S.seats.map((e, t) => {
									let n = S.dice.find((e) => e.slot?.kind === "seat" && e.slot.seat === t), r = be(t), i = v.phase === "serve" && w && S.pendingRemove && e.card && e.card.kind !== "noble" && !(n && !n.used), a = e.card ? i ? `${b("games.tavernsoftiefenthal.seatAria", {
										n: t + 1,
										card: $(b, e.card)
									})} · ${b("games.tavernsoftiefenthal.removeGuest")}` : b("games.tavernsoftiefenthal.seatAria", {
										n: t + 1,
										card: $(b, e.card)
									}) : b("games.tavernsoftiefenthal.seatAria", {
										n: t + 1,
										card: b("games.tavernsoftiefenthal.emptySeat")
									});
									return /* @__PURE__ */ p("button", {
										type: "button",
										className: `tt-table${e.card ? "" : " is-empty"}${r ? " is-target" : ""}${i ? " is-remove" : ""}${n && !n.used && v.phase === "serve" && w ? " is-live" : ""}`,
										onClick: () => we(t),
										"aria-label": a,
										children: [
											/* @__PURE__ */ f("span", {
												className: "tt-booth",
												"aria-hidden": !0
											}),
											/* @__PURE__ */ f("span", {
												className: "tt-tabletop",
												"aria-hidden": !0
											}),
											e.card ? /* @__PURE__ */ f(at, {
												card: e.card,
												extra: e.extraNobles
											}) : /* @__PURE__ */ f("span", {
												className: "tt-empty-card",
												children: /* @__PURE__ */ f("span", { children: b("games.tavernsoftiefenthal.emptySeat") })
											}),
											/* @__PURE__ */ f("span", {
												className: "tt-table-dice",
												children: n ? /* @__PURE__ */ f("span", {
													className: n.used ? "is-used" : "",
													children: /* @__PURE__ */ f(Ze, {
														value: n.value,
														color: n.color,
														boost: n.boost,
														size: 22
													})
												}) : null
											}),
											/* @__PURE__ */ f(Qe, { show: r })
										]
									}, t);
								})
							})
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "tt-bar",
						children: [/* @__PURE__ */ p("div", {
							className: "tt-bar-top",
							children: [/* @__PURE__ */ f("span", {
								className: "tt-bar-label",
								children: b("games.tavernsoftiefenthal.barTitle")
							}), /* @__PURE__ */ p("span", {
								className: "tt-barback",
								children: [
									/* @__PURE__ */ f(Be, { size: 13 }),
									b("games.tavernsoftiefenthal.cardBarback"),
									" ×",
									S.zones.barback
								]
							})]
						}), /* @__PURE__ */ f("div", {
							className: "tt-stations",
							children: ke.map((e) => {
								let t = S.dice.filter((t) => t.slot?.kind === e), n = xe(e), r = S.upgrades[e], i = b(`games.tavernsoftiefenthal.${De[e]}`), a = n ? b("games.tavernsoftiefenthal.hintPlace", { slot: i }) : v.phase === "serve" && w && t.some((e) => !e.used) ? b("games.tavernsoftiefenthal.hintTake", { slot: i }) : i, o = Ke[e];
								return /* @__PURE__ */ p("button", {
									type: "button",
									className: `tt-station tt-station--${e}${n ? " is-target" : ""}${r ? " is-up" : ""}${v.phase === "serve" && w && t.some((e) => !e.used) ? " is-live" : ""}`,
									onClick: () => Te(e),
									"aria-label": a,
									children: [
										/* @__PURE__ */ f("span", {
											className: "tt-station-ico",
											children: /* @__PURE__ */ f(o, { size: 30 })
										}),
										/* @__PURE__ */ p("span", {
											className: "tt-station-name",
											children: [i, r ? /* @__PURE__ */ f("i", {
												"aria-hidden": !0,
												children: "★"
											}) : null]
										}),
										/* @__PURE__ */ f("span", {
											className: "tt-station-yield",
											children: e === "cashbox" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("b", { children: ["+", r ? 3 : 1] }), /* @__PURE__ */ f(J, { size: 10 })] }) : e === "barrel" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("b", { children: ["+", r ? 2 : 1] }), /* @__PURE__ */ f(Y, { size: 10 })] }) : e === "brewer" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("b", { children: ["+", (r ? 2 : 1) + S.zones.brewer] }), /* @__PURE__ */ f(Y, { size: 10 })] }) : /* @__PURE__ */ p(d, { children: ["5→", r ? 2 : 1] })
										}),
										/* @__PURE__ */ f("span", {
											className: "tt-station-dice",
											children: t.map((e) => /* @__PURE__ */ f("span", {
												className: e.used ? "is-used" : "",
												children: /* @__PURE__ */ f(Ze, {
													value: e.value,
													color: e.color,
													boost: e.boost,
													size: 22
												})
											}, e.id))
										}),
										/* @__PURE__ */ f(Qe, { show: n })
									]
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "tt-fac",
						children: [/* @__PURE__ */ f("div", {
							className: "tt-sec-label",
							children: b("games.tavernsoftiefenthal.facilityTitle")
						}), /* @__PURE__ */ f("div", {
							className: "tt-fac-row",
							children: ne.map((e) => {
								let t = S.zones[e] ?? 0, n = S.upgrades[e], r = (e === "server" || e === "dishwasher" || e === "table") && n && v.turn < S.upgradeReady[e], i = w && !n;
								return /* @__PURE__ */ f(ot, {
									area: e,
									zoneCount: t,
									upgraded: n,
									pending: r,
									selected: k?.area === e,
									onClick: i ? () => j(k?.area === e ? null : {
										area: e,
										returns: 0
									}) : void 0
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ p("div", {
						className: "tt-monastery",
						children: [/* @__PURE__ */ p("div", {
							className: "tt-monastery-head",
							children: [/* @__PURE__ */ f("span", { children: b("games.tavernsoftiefenthal.monastery") }), /* @__PURE__ */ p("span", { children: [S.monastery, " / 22"] })]
						}), /* @__PURE__ */ f("div", {
							className: "tt-track",
							role: "img",
							"aria-label": `${b("games.tavernsoftiefenthal.monastery")} ${S.monastery} / 22`,
							children: Ae.map((e) => {
								let t = ie[e];
								return /* @__PURE__ */ p("span", {
									className: `tt-node${t ? " is-reward" : ""}${S.monastery === e ? " is-on" : ""}`,
									title: Pe(t),
									children: [/* @__PURE__ */ f("span", {
										className: "tt-node-n",
										children: e
									}), t && t.kind !== "none" ? /* @__PURE__ */ f("span", {
										className: "tt-node-r",
										children: /* @__PURE__ */ f(Ye, { reward: t })
									}) : null]
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ f("div", {
						className: "tt-tray",
						"aria-live": "polite",
						children: Ne
					})
				]
			}), /* @__PURE__ */ p("aside", {
				className: "tt-rail",
				children: [
					/* @__PURE__ */ p("section", {
						className: "tt-panel tt-panel--menu",
						children: [
							/* @__PURE__ */ p("div", {
								className: "tt-panel-head",
								children: [/* @__PURE__ */ f("h3", { children: b("games.tavernsoftiefenthal.menuTitle") }), /* @__PURE__ */ f("small", { children: b("games.tavernsoftiefenthal.guestDisplay") })]
							}),
							/* @__PURE__ */ f("div", {
								className: "tt-display",
								children: v.guestDisplay.map((e, t) => {
									let n = !!(w && !S.guestBought && S.beer >= e.cost);
									return /* @__PURE__ */ f(at, {
										card: e,
										onClick: n ? () => _({
											type: "recruitGuest",
											source: "display",
											index: t
										}) : void 0,
										disabled: !n,
										label: b("games.tavernsoftiefenthal.hintGuest", { card: $(b, e) })
									}, e.uid);
								})
							}),
							/* @__PURE__ */ p("div", {
								className: "tt-stackrow",
								children: [/* @__PURE__ */ p("button", {
									type: "button",
									className: `tt-stack${w && !S.guestBought && v.guest3Top && S.beer >= v.guest3Top.cost ? " is-buy" : ""}`,
									disabled: !(w && !S.guestBought && v.guest3Top && S.beer >= v.guest3Top.cost),
									onClick: () => _({
										type: "recruitGuest",
										source: "three",
										index: 0
									}),
									"aria-label": v.guest3Top ? b("games.tavernsoftiefenthal.hintGuest", { card: $(b, v.guest3Top) }) : b("games.tavernsoftiefenthal.threeBeerStack"),
									children: [
										/* @__PURE__ */ f("span", {
											className: "tt-stack-cards",
											children: v.guest3Top ? /* @__PURE__ */ f(at, { card: v.guest3Top }) : /* @__PURE__ */ f("span", { className: "tt-empty-card tt-empty-card--mini" })
										}),
										/* @__PURE__ */ p("span", {
											className: "tt-stack-count",
											children: ["×", v.guest3Count]
										}),
										v.guest3Top ? /* @__PURE__ */ p("span", {
											className: "tt-price",
											children: [/* @__PURE__ */ f(Y, { size: 10 }), v.guest3Top.cost]
										}) : null
									]
								}), /* @__PURE__ */ p("span", {
									className: "tt-stack-meta",
									children: [/* @__PURE__ */ f("b", { children: b("games.tavernsoftiefenthal.threeBeerStack") }), /* @__PURE__ */ f("small", { children: b("games.tavernsoftiefenthal.guestDeckCount", { n: v.guestDeckCount }) })]
								})]
							})
						]
					}),
					v.phase !== "done" && /* @__PURE__ */ p("section", {
						className: "tt-panel",
						children: [/* @__PURE__ */ p("div", {
							className: "tt-panel-head",
							children: [/* @__PURE__ */ f("h3", { children: b("games.tavernsoftiefenthal.tavernSupply") }), /* @__PURE__ */ f("small", { children: b("games.tavernsoftiefenthal.coins") })]
						}), /* @__PURE__ */ f("div", {
							className: "tt-supply",
							children: Oe.map((e) => {
								let t = {
									...y,
									key: `tavern-${e}`,
									kind: "tavern",
									tavern: e,
									cost: 0,
									vp: te[e],
									die: 0,
									coins: 0,
									bonus: "none",
									uid: `supply-${e}`
								}, n = !!(w && !S.bought.includes(e) && S.coins >= ee[e]);
								return /* @__PURE__ */ p("span", {
									className: "tt-supply-item",
									children: [/* @__PURE__ */ p($e, {
										variant: "tavern",
										onClick: n ? () => _({
											type: "buyTavern",
											kind: e
										}) : void 0,
										disabled: !n,
										label: b("games.tavernsoftiefenthal.hintBuy", { card: nt(b, e) }),
										className: S.bought.includes(e) ? "is-bought" : "",
										children: [/* @__PURE__ */ f(rt, { card: t }), S.bought.includes(e) ? /* @__PURE__ */ f("span", {
											className: "tt-bought",
											"aria-hidden": !0,
											children: "✓"
										}) : null]
									}), /* @__PURE__ */ p("span", {
										className: "tt-price",
										children: [/* @__PURE__ */ f(J, { size: 10 }), ee[e]]
									})]
								}, e);
							})
						})]
					}),
					v.phase !== "done" && /* @__PURE__ */ p("section", {
						className: "tt-panel",
						children: [/* @__PURE__ */ p("div", {
							className: "tt-panel-head",
							children: [/* @__PURE__ */ f("h3", { children: b("games.tavernsoftiefenthal.nobleSupply") }), /* @__PURE__ */ f("small", { children: b("games.tavernsoftiefenthal.recruitNoble") })]
						}), /* @__PURE__ */ f("div", {
							className: "tt-supply tt-supply--noble",
							children: ae.map((e, t) => {
								let n = {
									...y,
									uid: `noble-${t}`
								}, r = !!(w && S.beer >= e);
								return /* @__PURE__ */ p("span", {
									className: "tt-supply-item",
									children: [
										/* @__PURE__ */ f($e, {
											variant: "noble",
											onClick: r ? () => _({
												type: "recruitNoble",
												tier: t
											}) : void 0,
											disabled: !r,
											label: b("games.tavernsoftiefenthal.hintNoble", { n: t + 1 }),
											children: /* @__PURE__ */ f(rt, { card: n })
										}),
										/* @__PURE__ */ p("span", {
											className: "tt-price",
											children: [/* @__PURE__ */ f(Y, { size: 10 }), e]
										}),
										/* @__PURE__ */ p("span", {
											className: "tt-noble-count",
											children: ["×", t + 1]
										})
									]
								}, t);
							})
						})]
					}),
					/* @__PURE__ */ p("section", {
						className: "tt-panel",
						children: [/* @__PURE__ */ f("div", {
							className: "tt-panel-head",
							children: /* @__PURE__ */ f("h3", { children: b("games.tavernsoftiefenthal.opponentTitle") })
						}), /* @__PURE__ */ f("div", {
							className: "tt-opps",
							children: v.players.filter((e) => e.rid !== h).map((e) => {
								let t = M(e.rid);
								return t ? /* @__PURE__ */ p("span", {
									className: `tt-opp${Q === e.rid ? " is-active" : ""}`,
									children: [/* @__PURE__ */ f(l, {
										m: t,
										myRid: h,
										action: Q === e.rid ? "pending" : null,
										anchorName: null,
										box: "size-7",
										img: "size-6"
									}), /* @__PURE__ */ p("span", {
										className: "tt-opp-main",
										children: [
											/* @__PURE__ */ f("span", {
												className: "tt-opp-name",
												children: u(t, x)
											}),
											/* @__PURE__ */ p("span", {
												className: "tt-opp-stats",
												children: [
													/* @__PURE__ */ f(J, { size: 10 }),
													e.coins,
													/* @__PURE__ */ f(Y, { size: 10 }),
													e.beer,
													/* @__PURE__ */ f(X, { size: 10 }),
													e.monastery,
													/* @__PURE__ */ p("span", {
														className: "tt-opp-seat",
														children: [
															b("games.tavernsoftiefenthal.seat"),
															" ",
															e.seats.filter((e) => e.card).length,
															"/",
															e.seats.length
														]
													})
												]
											}),
											/* @__PURE__ */ p("span", {
												className: "tt-opp-sub",
												children: [
													b("games.tavernsoftiefenthal.deck"),
													" ",
													e.deckCount,
													" · ",
													b("games.tavernsoftiefenthal.discard"),
													" ",
													e.discardCount,
													" · ",
													b("games.tavernsoftiefenthal.counters"),
													" ",
													e.counters
												]
											})
										]
									})]
								}, e.rid) : null;
							})
						})]
					}),
					re && /* @__PURE__ */ p("details", {
						className: "tt-private",
						children: [
							/* @__PURE__ */ p("summary", { children: [
								b("games.tavernsoftiefenthal.deck"),
								" / ",
								b("games.tavernsoftiefenthal.discard")
							] }),
							/* @__PURE__ */ p("p", { children: [
								b("games.tavernsoftiefenthal.deck"),
								": ",
								re.deck.map((e) => $(b, e)).join(x === "zh" ? "、" : ", ") || b("games.tavernsoftiefenthal.none")
							] }),
							/* @__PURE__ */ p("p", { children: [
								b("games.tavernsoftiefenthal.discard"),
								": ",
								re.discard.map((e) => $(b, e)).join(x === "zh" ? "、" : ", ") || b("games.tavernsoftiefenthal.none")
							] })
						]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/game/bot.ts
var ct = (e) => e[Math.floor(Math.random() * e.length)], lt = (e, t) => e.dice.some((e) => e.slot?.kind === "seat" && e.slot.seat === t);
function ut(e, t, n) {
	let r = e.dice.find((e) => !e.slot);
	if (!r) return null;
	let i = e.upgrades.dishwasher && n >= e.upgradeReady.dishwasher ? 1 : 0, a = e.zones.dishwasher + i - e.dishesUsed, o = [];
	e.seats.forEach((t, n) => {
		if (t.card && !lt(e, n)) for (let e = 0; e <= Math.min(1, a); e += 1) r.value + e === t.card.die && o.push({
			slot: {
				kind: "seat",
				seat: n
			},
			boost: e,
			score: t.card.coins + t.card.vp * 2
		});
	});
	for (let t = 0; t <= Math.min(1, a); t += 1) r.value + t === 5 && o.push({
		slot: { kind: "monk" },
		boost: t,
		score: 9
	}), (r.value + t === 1 || r.value + t === 6) && o.push({
		slot: { kind: "brewer" },
		boost: t,
		score: e.upgrades.brewer ? 28 : 20
	});
	if (o.push({
		slot: { kind: "cashbox" },
		boost: 0,
		score: e.upgrades.cashbox ? 24 : 12
	}), o.push({
		slot: { kind: "barrel" },
		boost: 0,
		score: e.upgrades.barrel ? 16 : 9
	}), t === "weak") {
		let e = ct(o);
		return {
			type: "placeDie",
			dieId: r.id,
			slot: e.slot,
			boost: e.boost
		};
	}
	o.sort((e, t) => t.score - e.score);
	let s = o[0];
	return {
		type: "placeDie",
		dieId: r.id,
		slot: s.slot,
		boost: s.boost
	};
}
function dt(e, t) {
	for (let e of [
		"brewer",
		"dishwasher",
		"cashbox",
		"table",
		"server",
		"barrel",
		"storage",
		"safe",
		"monk"
	]) {
		if (t.upgrades[e]) continue;
		let n = g[e], r = e in t.zones ? t.zones[e] : 0;
		for (let i = 0; i <= r; i += 1) if (Math.max(0, n.cost - i * n.discount) <= t.coins) return {
			area: e,
			returns: i
		};
	}
	return null;
}
function ft(e) {
	for (let t of [
		"brewer",
		"table",
		"server",
		"dishwasher",
		"barback"
	]) if (!e.bought.includes(t) && e.coins >= ee[t]) return t;
	return null;
}
function pt(e, t) {
	if (t.guestBought) return null;
	let n = -1, r = -1;
	for (let i = 0; i < e.guestDisplay.length; i += 1) {
		let a = e.guestDisplay[i];
		t.beer < a.cost || a.vp > r && (r = a.vp, n = i);
	}
	return n >= 0 ? {
		type: "recruitGuest",
		source: "display",
		index: n
	} : e.guest3Top && t.beer >= e.guest3Top.cost ? {
		type: "recruitGuest",
		source: "three",
		index: 0
	} : null;
}
var mt = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = n.players.findIndex((e) => e.rid === t.rid), a = t.difficulty === "weak";
	if (n.phase === "bonus") {
		if (r.bonusDone) return null;
		let e = n.bonusOptions;
		return e.includes("freeUpgrade") ? { action: {
			type: "bonus",
			pick: ne.filter((e) => !r.upgrades[e]).sort((e, t) => g[e].cost - g[t].cost)[0] ?? "skip"
		} } : { action: {
			type: "bonus",
			pick: a ? ct(e) : e.includes("die") ? "die" : e.includes("guest3") ? "guest3" : e[0]
		} };
	}
	if (n.phase === "draft") {
		if (n.draftIndex !== i) return null;
		let e = n.players.length, t = n.players[((i - n.draftRound) % e + e) % e].coaster;
		if (t.length === 0) return null;
		let r = t.indexOf(Math.max(...t));
		return { action: {
			type: "draftPick",
			index: a ? Math.floor(Math.random() * t.length) : r
		} };
	}
	if (n.phase === "plan") return r.ready ? null : r.dice.some((e) => !e.slot) ? { action: ut(r, t.difficulty, n.turn) } : { action: { type: "readyPlan" } };
	if (n.phase !== "serve" || n.players[n.activeIndex]?.rid !== t.rid) return null;
	if (r.pendingRemove) {
		let e = r.seats.findIndex((e, t) => e.card && e.card.kind !== "noble" && !lt(r, t));
		return { action: e >= 0 ? {
			type: "removeGuest",
			seat: e
		} : { type: "skipRemove" } };
	}
	let o = r.dice.find((e) => e.slot && !e.used);
	if (o) return a ? { action: {
		type: "takeDie",
		dieId: ct(r.dice.filter((e) => e.slot && !e.used)).id
	} } : { action: {
		type: "takeDie",
		dieId: o.id
	} };
	if (!a && r.counters > 0 && r.monastery < 14) return { action: {
		type: "useCounter",
		mode: "monastery"
	} };
	let s = a ? null : dt(n, r);
	if (s) return { action: {
		type: "upgrade",
		area: s.area,
		returns: s.returns
	} };
	let c = a ? null : ft(r);
	if (c) return { action: {
		type: "buyTavern",
		kind: c
	} };
	let l = a ? null : pt(n, r);
	if (l) return { action: l };
	if (!a) {
		for (let e = 2; e >= 0; --e) if (r.beer >= ae[e]) return { action: {
			type: "recruitNoble",
			tier: e
		} };
	}
	return { action: { type: "endServing" } };
}, ht = (e, t, n) => e.type === "draftPick" ? n("games.tavernsoftiefenthal.hintDraft", { n: e.index + 1 }) : e.type === "placeDie" ? n("games.tavernsoftiefenthal.hintPlace", { slot: e.slot.kind }) : e.type === "readyPlan" ? n("games.tavernsoftiefenthal.hintReady") : e.type === "takeDie" ? n("games.tavernsoftiefenthal.hintTake", { slot: n("games.tavernsoftiefenthal.slotCashbox") }) : e.type === "buyTavern" ? n("games.tavernsoftiefenthal.hintBuy", { card: e.kind }) : e.type === "upgrade" ? n("games.tavernsoftiefenthal.hintUpgrade", { area: e.area }) : e.type === "recruitGuest" ? n("games.tavernsoftiefenthal.hintGuest", { card: e.source === "three" ? "3" : String(e.index + 1) }) : e.type === "recruitNoble" ? n("games.tavernsoftiefenthal.hintNoble", { n: e.tier + 1 }) : e.type === "useCounter" ? n("games.tavernsoftiefenthal.hintCounter") : e.type === "removeGuest" ? n("games.tavernsoftiefenthal.hintRemove", { n: e.seat + 1 }) : e.type === "endServing" ? n("games.tavernsoftiefenthal.hintEnd") : "";
//#endregion
//#region src/game/game-over.tsx
function gt({ public: e, result: t, members: n, myRid: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = e, d = i(), ee = r((e) => e.locale), te = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, ee) : d("games.tavernsoftiefenthal.name");
	}, h = t.scores ?? c.scores ?? {}, g = t.winner.length > 1, ne = g ? d("games.tavernsoftiefenthal.draw") : d("games.tavernsoftiefenthal.won", { name: te(t.winner[0]) });
	return /* @__PURE__ */ f("div", {
		className: "tt-over",
		children: /* @__PURE__ */ p("section", {
			className: "tt-over-board",
			"aria-labelledby": "tt-result-title",
			children: [
				/* @__PURE__ */ p("header", {
					className: "tt-over-head",
					children: [
						/* @__PURE__ */ f("span", {
							className: "tt-over-lamp",
							"aria-hidden": !0,
							children: /* @__PURE__ */ f(je, { size: 20 })
						}),
						/* @__PURE__ */ p("span", {
							className: "tt-over-kicker",
							children: ["TIEFENTHAL · ", d("games.tavernsoftiefenthal.final")]
						}),
						/* @__PURE__ */ f("h1", {
							id: "tt-result-title",
							className: "tt-over-title",
							children: ne
						}),
						g && /* @__PURE__ */ f("p", {
							className: "tt-over-tie",
							children: d("games.tavernsoftiefenthal.tieNote")
						})
					]
				}),
				/* @__PURE__ */ f("ol", {
					className: "tt-over-list",
					children: t.ranking.map((e, r) => {
						let i = n.find((t) => t.rid === e), o = c.players.find((t) => t.rid === e), s = o ? Object.values(o.upgrades).filter(Boolean).length : 0;
						return /* @__PURE__ */ p("li", {
							className: `tt-over-row${t.winner.includes(e) ? " is-win" : ""}`,
							children: [
								/* @__PURE__ */ f("span", {
									className: "tt-over-rank",
									children: r + 1
								}),
								i ? /* @__PURE__ */ f(l, {
									m: i,
									myRid: a,
									action: null,
									anchorName: null,
									box: "tt-over-avatar",
									img: "tt-over-avatar-img"
								}) : /* @__PURE__ */ f("span", {
									className: "tt-over-avatar",
									"aria-hidden": !0
								}),
								/* @__PURE__ */ f("span", {
									className: "tt-over-id",
									children: /* @__PURE__ */ p("span", {
										className: "tt-over-name",
										children: [te(e), t.winner.includes(e) && /* @__PURE__ */ f(Z, { size: 13 })]
									})
								}),
								/* @__PURE__ */ p("span", {
									className: "tt-over-vp",
									children: [/* @__PURE__ */ f("b", { children: h[e] ?? 0 }), /* @__PURE__ */ f("small", { children: d("games.tavernsoftiefenthal.vp") })]
								}),
								o && /* @__PURE__ */ p("span", {
									className: "tt-over-detail",
									children: [
										/* @__PURE__ */ f("span", {
											className: "tt-over-chip",
											children: d("games.tavernsoftiefenthal.overFacilities", { n: s })
										}),
										/* @__PURE__ */ f("span", {
											className: "tt-over-chip",
											children: d("games.tavernsoftiefenthal.overMonastery", { n: o.monastery })
										}),
										/* @__PURE__ */ f("span", {
											className: "tt-over-chip",
											children: d("games.tavernsoftiefenthal.overStored", { n: o.coins + o.beer })
										}),
										/* @__PURE__ */ f("span", {
											className: "tt-over-chip",
											children: d("games.tavernsoftiefenthal.overCards", { n: o.deckCount + o.discardCount })
										})
									]
								})
							]
						}, e);
					})
				}),
				/* @__PURE__ */ p("footer", {
					className: "tt-over-buttons",
					children: [
						o && /* @__PURE__ */ f(m, {
							label: d("session.result.playAgain"),
							confirmLabel: d("games.tavernsoftiefenthal.confirmAgain"),
							onConfirm: o
						}),
						s && /* @__PURE__ */ f(m, {
							label: d("session.result.backToLobby"),
							confirmLabel: d("games.tavernsoftiefenthal.confirmLeave"),
							onConfirm: s
						}),
						!o && !s && /* @__PURE__ */ f("p", {
							className: "tt-over-wait",
							children: d("session.result.waitHost")
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/index.tsx
var _t = {
	definition: G,
	View: st,
	bot: mt,
	describe: ht,
	OverView: gt,
	locales: {
		zh: {
			name: "深谷酒馆",
			desc: "掷骰服务客人，购牌扩建酒馆",
			rules: "目标：\n在八个回合中经营自己的酒馆，服务客人、赚取塔勒与啤酒，并用它们购买酒馆牌和升级酒馆设施。八个回合结束后，牌库与弃牌堆中所有卡牌右上角的胜利点合计最高的玩家获胜。\n\n准备：\n每位玩家拿取一块酒馆板、四枚白色骰子和一套起始牌组。起始牌组由七张常客牌、一张侍者牌、一张桌子牌和一张酿酒师牌组成，洗混后作为抽牌堆。公共区域按类型摆放酒馆牌，另有八张需要三杯啤酒的客人牌、洗混的客人牌堆、四张翻开的客人牌和贵族牌堆。修道院标记放在修道院轨的起点，月亮标记放在回合轨第一格之前。\n\n回合流程：\n一局共进行八个回合。每个回合依次经历以下七个阶段：新夜晚、客人到来、侍者、点单、规划、服务和打烊。其中客人到来、侍者、规划与打烊由所有玩家同时进行；点单与服务按回合顺序，从起始玩家开始依次进行。\n\n新夜晚：\n起始玩家把月亮标记向前移动一格，所有玩家立刻获得该格显示的奖励。第一、第四和第六回合，每位玩家获得一名柜台客人。第二回合，每位玩家选择获得一张三杯啤酒的客人牌或一张帮手牌。第三回合，每位玩家选择获得一枚自己颜色的骰子或一张洗碗工牌。第五回合，每位玩家选择获得一张桌子牌或一张酿酒师牌。第七回合，每位玩家选择获得一枚自己颜色的骰子或一张帮手牌。第八回合，每位玩家可以免费升级一处尚未升级的设施，但这次升级不获得贵族牌。\n\n客人到来：\n玩家从自己的抽牌堆顶逐张翻牌，并把牌放到酒馆板上对应的位置。常客、客人与贵族放在空桌上；贵族全部叠放在同一张桌子上，后续贵族叠在最先翻开的贵族之上。帮手牌放在啤酒储藏旁；洗碗工牌放在洗碗区旁；侍者牌放在侍者区旁；桌子牌放在印刷桌子右侧，并立刻增加一张本回合可用的桌子；酿酒师牌放在酿酒师区旁。持续翻牌，直到所有桌子都坐满客人为止。若抽牌堆耗尽，则将弃牌堆洗混后作为新的抽牌堆。\n\n侍者：\n每位玩家按照本回合翻出的侍者牌数量，各拿取一枚自己颜色的骰子并掷出；如果已经升级侍者区，则额外拿取一枚。每位玩家最多拥有三枚自己颜色的骰子，超出的侍者牌不再提供骰子。\n\n点单：\n所有玩家同时掷四枚白色骰子，放在自己的杯垫上。从起始玩家开始，按回合顺序，每位玩家从自己面前的杯垫中选择一枚白色骰子放到酒馆板下方，然后把杯垫传给左手边的玩家。重复四轮，直到每位玩家都拿到四枚白色骰子。\n\n规划：\n所有玩家同时把自己拥有的全部白色骰子和自己颜色的骰子放到酒馆板上的行动格。客人、常客和贵族各自只允许放置一枚骰子，骰子的点数必须与卡牌左下角显示的点数相同；多张贵族叠放在同一张桌子时，只在最上面的贵族牌上放置一枚骰子。钱箱、酿酒师和酒桶可以放置任意数量的骰子；酿酒师只接受点数为一点或六点的骰子；修士只接受点数为五点的骰子。每张本轮翻出的洗碗工牌，以及已经升级的洗碗区，各允许玩家在本回合把一枚骰子的点数视为提高一点，但骰子实际显示的点数不变，且六点不能因此变为一点。规划完成后，所有玩家确认准备。\n\n服务：\n从起始玩家开始，按回合顺序，每位玩家依次取回自己放置的骰子并结算对应的行动。从客人、常客或贵族处取回骰子时，获得该卡牌右下角显示的塔勒。从钱箱取回骰子时获得一枚塔勒；升级钱箱后改为获得三枚塔勒。从酿酒师处取回骰子时获得一杯啤酒，并额外获得与本回合酿酒师牌数量相等的啤酒；升级酿酒师后，每枚骰子的基础啤酒改为两杯。从酒桶处取回骰子时获得一杯啤酒；升级酒桶后改为获得两杯啤酒。从修士处取回点数为五点的骰子时，修道院标记前进一格；升级修士后改为前进两格。\n\n塔勒行动：\n玩家可以支付塔勒，从公共区域购买一张酒馆牌并面朝下放到自己抽牌堆顶。每种酒馆牌在每个回合最多购买一张。玩家也可以支付塔勒升级一处设施，升级费用标在设施牌左上角；若要升级洗碗区、侍者区、桌子和酿酒师，可以先把本轮翻出的对应酒馆牌退回公共区域，每退回一张便按设施牌上标注的折扣减少费用，费用最低降至零。每次升级后，玩家立刻获得一张贵族牌并放到抽牌堆顶。\n\n啤酒行动：\n玩家可以支付啤酒，从公共区域招募一张客人牌，或从三杯啤酒客人牌堆顶招募一张，并面朝下放到抽牌堆顶。每个回合最多招募一张客人牌。招募时立刻结算卡牌中央显示的即时奖励。玩家也可以支付九杯、十四杯或十八杯啤酒，分别获得一张、两张或三张贵族牌；招募贵族不计入每回合一张客人牌的限制。\n\n柜台客人：\n柜台客人放在柜台座位上，每名柜台客人只能使用一次。客人到来阶段坐满桌子后，玩家可以弃置一名柜台客人，并把本阶段翻出的所有牌放入弃牌堆，然后重新开始客人到来阶段。服务阶段，玩家可以弃置一名柜台客人，使修道院标记前进一格。\n\n打烊：\n所有玩家完成服务后，把本回合翻出并放在酒馆板上的所有卡牌放入弃牌堆，然后由左手边的玩家成为新的起始玩家。第八回合打烊后游戏结束。\n\n修道院轨：\n修道院标记沿修道院轨前进，经过或停在带有奖励的格子上时立刻获得该奖励。标记越过第二十二格后回到起点并继续前进。修道院轨可以提供塔勒、啤酒、客人牌、酒馆牌、贵族牌，或允许玩家移除一名已经坐在桌旁且没有放置骰子的客人。\n\n终局：\n八个回合结束后，玩家统计自己抽牌堆与弃牌堆中所有卡牌的胜利点。胜利点最高的玩家获胜。若并列，则塔勒与啤酒存量合计较多的玩家获胜；若仍然并列，则并列玩家共享胜利。",
			phaseBonus: "新夜晚",
			phaseDraft: "点单",
			phasePlan: "规划",
			phaseServe: "服务",
			phaseDone: "结算",
			turn: "回合",
			of: "共",
			startPlayer: "起始玩家",
			activePlayer: "当前行动",
			coins: "塔勒",
			beer: "啤酒",
			deck: "抽牌堆",
			discard: "弃牌堆",
			monastery: "修道院",
			counters: "柜台客人",
			vp: "胜利点",
			seat: "桌子",
			emptySeat: "空桌",
			tavern: "酒馆",
			upgrades: "设施",
			guests: "客人",
			cardRegular: "常客",
			cardGuest: "客人",
			cardNoble: "贵族",
			cardBarback: "帮手",
			cardDishwasher: "洗碗工",
			cardServer: "侍者",
			cardTable: "桌子",
			cardBrewer: "酿酒师",
			upDishwasher: "洗碗区",
			upServer: "侍者区",
			upCashbox: "钱箱",
			upMonk: "修士",
			upTable: "桌子",
			upBarrel: "酒桶",
			upSafe: "保险箱",
			upStorage: "啤酒储藏",
			upBrewer: "酿酒师",
			benefitDishwasher: "每回合可让一枚骰子的点数视为提高一点",
			benefitServer: "每回合额外获得一枚自己颜色的骰子",
			benefitCashbox: "每枚骰子提供三枚塔勒",
			benefitMonk: "每枚五点骰子前进两格",
			benefitTable: "增加一张永久桌子",
			benefitBarrel: "每枚骰子提供两杯啤酒",
			benefitSafe: "最多保存五枚塔勒",
			benefitStorage: "最多保存五杯啤酒",
			benefitBrewer: "每枚骰子提供两杯基础啤酒",
			cost: "费用",
			discount: "折扣",
			returns: "退回",
			upgraded: "已升级",
			upgradeNextTurn: "次回合生效",
			notUpgraded: "未升级",
			upgrade: "升级",
			buy: "购买",
			chooseBonus: "选择本回合奖励",
			bonusCounter: "获得一名柜台客人",
			bonusGuest3: "获得一张三杯啤酒客人牌",
			bonusBarback: "获得一张帮手牌",
			bonusDie: "获得一枚自己颜色的骰子",
			bonusDishwasher: "获得一张洗碗工牌",
			bonusTable: "获得一张桌子牌",
			bonusBrewer: "获得一张酿酒师牌",
			bonusFreeUpgrade: "免费升级一处设施",
			bonusSkip: "不升级",
			draftPrompt: "从杯垫中选择一枚白色骰子",
			draftWaiting: "等待{{name}}选择骰子",
			draftRound: "第{{n}}轮",
			pickDie: "选择这枚骰子",
			planPrompt: "把骰子放到行动格上",
			planWaiting: "等待其他玩家规划",
			place: "放置",
			unplace: "取回",
			readyPlan: "确认准备",
			readyWaiting: "已准备，等待其他玩家",
			dishwasherUses: "洗碗工可用 {{n}} 次",
			needPlace: "还有骰子没有放置",
			servePrompt: "取回骰子结算行动，然后购买或升级",
			serveWaiting: "等待{{name}}服务客人",
			takeDie: "结算这枚骰子",
			endServing: "结束服务",
			buyTavern: "购买酒馆牌",
			recruitGuest: "招募客人",
			recruitNoble: "招募贵族",
			nobleTier: "{{n}} 张贵族",
			useCounterMonastery: "弃置柜台客人，修道院前进一格",
			useCounterRedraw: "弃置柜台客人，重新抽取客人",
			removeGuestPrompt: "选择一名没有放置骰子的客人移除",
			removeGuest: "移除这位客人",
			skipRemove: "不移除",
			pendingRemove: "需要处理移除客人的奖励",
			guestDisplay: "客人牌展示区",
			threeBeerStack: "三杯啤酒客人牌",
			guestDeckCount: "剩余客人牌 {{n}} 张",
			seatAria: "第{{n}}张桌子：{{card}}",
			slotCashbox: "钱箱",
			slotBrewer: "酿酒师",
			slotBarrel: "酒桶",
			slotMonk: "修士",
			dieValue: "点数 {{n}}",
			dieBoost: "（视为 {{n}} 点）",
			used: "已结算",
			errPlayer: "你不是本局玩家。",
			errDone: "对局已经结束。",
			errTurn: "现在不能执行这个动作。",
			errTarget: "请选择有效目标。",
			errDishwasher: "洗碗工使用次数不足。",
			errBought: "本回合已经购买过这类酒馆牌。",
			errMoney: "塔勒不足。",
			errUpgraded: "这处设施已经升级。",
			errGuest: "本回合已经招募过客人。",
			errBeer: "啤酒不足。",
			errPending: "请先处理移除客人的奖励。",
			final: "对局结束",
			won: "{{name}}获胜",
			draw: "并列胜利",
			review: "回看酒馆",
			showResult: "查看结果",
			vpDetail: "胜利点 {{n}}",
			tiebreak: "存量 {{n}}",
			confirmAgain: "确认再来一局",
			confirmLeave: "确认返回大厅",
			hintBonus: "选择本回合奖励。",
			hintDraft: "选择点数 {{n}} 的白色骰子。",
			hintPlace: "把骰子放到{{slot}}。",
			hintUnplace: "取回这枚骰子。",
			hintReady: "确认准备。",
			hintTake: "结算{{slot}}上的骰子。",
			hintBuy: "购买{{card}}。",
			hintUpgrade: "升级{{area}}。",
			hintGuest: "招募{{card}}。",
			hintNoble: "招募{{n}}张贵族。",
			hintCounter: "使用柜台客人。",
			hintRemove: "移除第{{n}}张桌子上的客人。",
			hintEnd: "结束服务。",
			hintPass: "跳过。",
			guestBonusBeer1: "获得一杯啤酒",
			guestBonusBeer2: "获得两杯啤酒",
			guestBonusCoins2: "获得两枚塔勒",
			guestBonusCoins3: "获得三枚塔勒",
			guestBonusCoins4: "获得四枚塔勒",
			guestBonusMonastery: "修道院前进一格",
			guestBonusNoble: "获得一张贵族牌",
			guestBonusGuest3: "获得一张三杯啤酒客人牌",
			guestBonusTable: "获得一张桌子牌",
			guestBonusService: "可以移除一名客人",
			pendingBonus: "待领奖励",
			none: "无",
			confirm: "确认",
			cancel: "取消",
			close: "关闭",
			yourTavern: "你的酒馆",
			menuTitle: "公共客栈",
			guestRow: "客人席",
			barTitle: "吧台",
			facilityTitle: "酒馆设施",
			diceTray: "骰子托盘",
			coaster: "杯垫",
			opponentTitle: "其他酒馆",
			tavernSupply: "酒馆牌",
			nobleSupply: "贵族",
			tapTargetHint: "点击桌子或吧台上的目标放置骰子",
			serveTapHint: "点击带骰子的桌子或吧台结算",
			selectDieHint: "先点选托盘中的一枚骰子",
			boostTitle: "提高点数",
			returnsHint: "退回同类酒馆牌可抵费用",
			pendingDice: "待结算 {{n}} 枚骰子",
			placedDice: "本回合已放置 {{n}} 枚骰子",
			coasterOwner: "杯垫来自{{name}}",
			gainCard: "获得一张{{card}}牌",
			overFacilities: "设施 {{n}} / 9",
			overMonastery: "修道院 {{n}} / 22",
			overStored: "塔勒与啤酒 {{n}}",
			overCards: "卡牌 {{n}} 张",
			tieNote: "胜利点与存量相同，并列者共享胜利"
		},
		en: {
			name: "The Taverns of Tiefenthal",
			desc: "Roll dice to serve guests and build up your tavern",
			rules: "Objective:\nRun your tavern over eight turns. Serve guests to earn Thalers and Beer, then spend them on Tavern cards and upgrades. After eight turns, the player with the most victory points on all cards in their draw deck and discard pile wins.\n\nSetup:\nEach player takes a Tavern board, four white dice, and a starting deck. The starting deck contains seven Regulars, one Server, one Table, and one Brewer; shuffle it as your draw deck. Sort the Tavern cards by type in the supply. Place the eight Guests that cost 3 Beer face up as a stack, shuffle the remaining Guest cards face down, reveal four of them in a row, and place the Nobles face up nearby. Place each Monastery marker on the start of the Monastery track and the Moon above the first space of the Turn track.\n\nTurn sequence:\nThe game lasts eight turns. Each turn has seven phases in this order: A New Evening in the Tavern, The Guests Arrive, Here Comes the Server, Can I Take Your Order?, Plan Your Actions, Serve the Guests!, and Closing Time! The Guests Arrive, Here Comes the Server, Plan Your Actions, and Closing Time! are played by all players simultaneously. Can I Take Your Order? and Serve the Guests! are played in turn order, beginning with the Start Player.\n\nA New Evening in the Tavern:\nThe Start Player moves the Moon one space forward on the Turn track, and every player immediately receives the bonus shown there. On turns 1, 4, and 6, each player receives one Counter Guest. On turn 2, each player chooses either a Guest card that costs 3 Beer or a Barback card. On turn 3, each player chooses either a die in their color or a Dishwasher card. On turn 5, each player chooses either a Table card or a Brewer card. On turn 7, each player chooses either a die in their color or a Barback card. On turn 8, each player may upgrade one area of their tavern for free, but this upgrade does not provide a Noble.\n\nThe Guests Arrive:\nReveal cards from the top of your draw deck one at a time and place each in its proper area on your Tavern board. Place Regulars, Guests, and Nobles at empty Tables; place every Noble after the first on top of the Noble already at a Table. Place Barbacks beside the Beer Storage, Dishwashers beside the Dishwashing Area, Servers beside the Server area, Tables to the right of the printed Tables, and Brewers beside the Brewer. A Table drawn this way immediately adds a Table you may use this turn. Keep drawing until every Table is occupied. If your draw deck runs out, shuffle your discard pile to form a new draw deck.\n\nHere Comes the Server:\nFor each Server card you revealed this turn, take one die in your color and roll it. If you have upgraded the Server area, take one additional die. You may have at most three dice in your color; additional Servers provide no further dice.\n\nCan I Take Your Order?:\nAll players roll four white dice and place them on their Dice Coasters. Beginning with the Start Player and proceeding in turn order, each player takes one white die from the Coaster in front of them and places it below their Tavern board, then passes that Coaster to the player on their left. Repeat for four rounds, until every player has four white dice.\n\nPlan Your Actions:\nAll players simultaneously place all of their white dice and dice in their color onto action spaces. Each Regular, Guest, and Noble accepts only one die, and that die must show the value printed in the lower-left corner of the card. When several Nobles are stacked at one Table, place only one die on the topmost Noble. The Cashbox, Brewer, and Barrel accept any number of dice. The Brewer accepts only dice showing 1 or 6, and the Monk accepts only dice showing 5. Each Dishwasher revealed this turn, and an upgraded Dishwashing Area, allows you to treat one die as one value higher during this turn. The die still shows its actual value, and a 6 can never become a 1. After placing their dice, all players confirm that they are ready.\n\nServe the Guests!:\nBeginning with the Start Player and proceeding in turn order, each player removes their placed dice and resolves the corresponding actions. Removing a die from a Regular, Guest, or Noble earns the number of Thalers printed in the card's lower-right corner. Removing a die from the Cashbox earns one Thaler, or three Thalers if the Cashbox is upgraded. Removing a die from the Brewer earns one Beer plus one Beer for each Brewer card revealed this turn; an upgraded Brewer earns two base Beer per die instead. Removing a die from the Barrel earns one Beer, or two Beer if the Barrel is upgraded. Removing a 5 from the Monk advances your Monastery marker one space, or two spaces if the Monk is upgraded.\n\nThaler actions:\nYou may pay Thalers to take one Tavern card from the supply and place it face down on top of your draw deck. You may buy at most one card of each type per turn. You may also pay Thalers to upgrade one area of your tavern. The base cost is printed in the upper-left corner of the tile. When upgrading the Dishwashing Area, Server area, Table, or Brewer, you may first return any corresponding Tavern cards revealed this turn to the supply; each returned card reduces the cost by the discount printed on the tile, to a minimum of zero. Each upgrade immediately provides one Noble, placed face down on top of your draw deck.\n\nBeer actions:\nYou may pay Beer to recruit one Guest card from the display, or the top card of the 3-Beer stack, and place it face down on top of your draw deck. You may recruit at most one Guest per turn. Resolve the immediate bonus printed in the center of the card when you recruit it. You may also pay 9, 14, or 18 Beer to take one, two, or three Nobles. Recruiting Nobles does not count against the one-Guest limit.\n\nCounter Guests:\nEach Counter Guest sits at the counter and can be used only once. After filling all of your Tables during The Guests Arrive, you may discard a Counter Guest, discard every card revealed during that phase, and restart the phase. During Serve the Guests!, you may discard a Counter Guest to advance your Monastery marker one space.\n\nClosing Time!:\nAfter all players have finished serving, place every card revealed and placed in your tavern this turn into your discard pile. The player to the left becomes the new Start Player. The game ends after Closing Time! of turn 8.\n\nMonastery track:\nAdvance your Monastery marker along the track and immediately receive the bonus of each space you pass or land on. If the marker moves beyond space 22, return it to the start and continue moving. The track can provide Thalers, Beer, Guest cards, Tavern cards, Nobles, or permission to remove one Guest seated at a Table that has no die on it.\n\nGame end:\nAfter eight turns, count the victory points printed in the upper-right corner of every card in your draw deck and discard pile. The player with the most victory points wins. If tied, the tied player with the most stored Thalers and Beer wins. If still tied, the tied players share the victory.",
			phaseBonus: "New Evening",
			phaseDraft: "Take Your Order",
			phasePlan: "Plan Actions",
			phaseServe: "Serve Guests",
			phaseDone: "Results",
			turn: "Turn",
			of: "of",
			startPlayer: "Start Player",
			activePlayer: "Acting",
			coins: "Thalers",
			beer: "Beer",
			deck: "Draw deck",
			discard: "Discard pile",
			monastery: "Monastery",
			counters: "Counter Guests",
			vp: "Victory points",
			seat: "Table",
			emptySeat: "Empty table",
			tavern: "Tavern",
			upgrades: "Upgrades",
			guests: "Guests",
			cardRegular: "Regular",
			cardGuest: "Guest",
			cardNoble: "Noble",
			cardBarback: "Barback",
			cardDishwasher: "Dishwasher",
			cardServer: "Server",
			cardTable: "Table",
			cardBrewer: "Brewer",
			upDishwasher: "Dishwashing Area",
			upServer: "Server",
			upCashbox: "Cashbox",
			upMonk: "Monk",
			upTable: "Table",
			upBarrel: "Barrel",
			upSafe: "Safe",
			upStorage: "Beer Storage",
			upBrewer: "Brewer",
			benefitDishwasher: "Treat one die as one value higher each turn",
			benefitServer: "Gain one extra die in your color each turn",
			benefitCashbox: "Each die provides three Thalers",
			benefitMonk: "Each 5 advances two spaces",
			benefitTable: "Add one permanent Table",
			benefitBarrel: "Each die provides two Beer",
			benefitSafe: "Store up to five Thalers",
			benefitStorage: "Store up to five Beer",
			benefitBrewer: "Each die provides two base Beer",
			cost: "Cost",
			discount: "Discount",
			returns: "Return",
			upgraded: "Upgraded",
			upgradeNextTurn: "Starts next turn",
			notUpgraded: "Not upgraded",
			upgrade: "Upgrade",
			buy: "Buy",
			chooseBonus: "Choose this turn's bonus",
			bonusCounter: "Take one Counter Guest",
			bonusGuest3: "Take a Guest card that costs 3 Beer",
			bonusBarback: "Take one Barback card",
			bonusDie: "Take one die in your color",
			bonusDishwasher: "Take one Dishwasher card",
			bonusTable: "Take one Table card",
			bonusBrewer: "Take one Brewer card",
			bonusFreeUpgrade: "Upgrade one area for free",
			bonusSkip: "Do not upgrade",
			draftPrompt: "Choose one white die from your Coaster",
			draftWaiting: "Waiting for {{name}} to choose a die",
			draftRound: "Round {{n}}",
			pickDie: "Choose this die",
			planPrompt: "Place your dice on action spaces",
			planWaiting: "Waiting for the other players to plan",
			place: "Place",
			unplace: "Take back",
			readyPlan: "Confirm ready",
			readyWaiting: "Ready; waiting for the other players",
			dishwasherUses: "Dishwashers available: {{n}}",
			needPlace: "Some dice are not placed yet",
			servePrompt: "Remove dice to resolve actions, then buy or upgrade",
			serveWaiting: "Waiting for {{name}} to serve guests",
			takeDie: "Resolve this die",
			endServing: "End serving",
			buyTavern: "Buy Tavern cards",
			recruitGuest: "Recruit a Guest",
			recruitNoble: "Recruit Nobles",
			nobleTier: "{{n}} Nobles",
			useCounterMonastery: "Discard a Counter Guest to advance the Monastery one space",
			useCounterRedraw: "Discard a Counter Guest to draw Guests again",
			removeGuestPrompt: "Choose a Guest with no die to remove",
			removeGuest: "Remove this Guest",
			skipRemove: "Do not remove",
			pendingRemove: "Resolve the Guest removal bonus",
			guestDisplay: "Guest display",
			threeBeerStack: "3-Beer Guests",
			guestDeckCount: "Guest cards left: {{n}}",
			seatAria: "Table {{n}}: {{card}}",
			slotCashbox: "Cashbox",
			slotBrewer: "Brewer",
			slotBarrel: "Barrel",
			slotMonk: "Monk",
			dieValue: "Value {{n}}",
			dieBoost: "(treated as {{n}})",
			used: "Resolved",
			errPlayer: "You are not a player in this game.",
			errDone: "The game is over.",
			errTurn: "You cannot do that now.",
			errTarget: "Choose a valid target.",
			errDishwasher: "Not enough Dishwasher uses remain.",
			errBought: "You already bought this type of Tavern card this turn.",
			errMoney: "You do not have enough Thalers.",
			errUpgraded: "This area is already upgraded.",
			errGuest: "You already recruited a Guest this turn.",
			errBeer: "You do not have enough Beer.",
			errPending: "Resolve the Guest removal bonus first.",
			final: "Game over",
			won: "{{name}} wins",
			draw: "Shared victory",
			review: "Review the tavern",
			showResult: "View result",
			vpDetail: "Victory points {{n}}",
			tiebreak: "Stored {{n}}",
			confirmAgain: "Confirm another game",
			confirmLeave: "Confirm return to lobby",
			hintBonus: "Choose this turn's bonus.",
			hintDraft: "Choose the white die showing {{n}}.",
			hintPlace: "Place the die on {{slot}}.",
			hintUnplace: "Take back this die.",
			hintReady: "Confirm ready.",
			hintTake: "Resolve the die on {{slot}}.",
			hintBuy: "Buy {{card}}.",
			hintUpgrade: "Upgrade {{area}}.",
			hintGuest: "Recruit {{card}}.",
			hintNoble: "Recruit {{n}} Nobles.",
			hintCounter: "Use a Counter Guest.",
			hintRemove: "Remove the Guest at Table {{n}}.",
			hintEnd: "End serving.",
			hintPass: "Pass.",
			guestBonusBeer1: "Gain one Beer",
			guestBonusBeer2: "Gain two Beer",
			guestBonusCoins2: "Gain two Thalers",
			guestBonusCoins3: "Gain three Thalers",
			guestBonusCoins4: "Gain four Thalers",
			guestBonusMonastery: "Advance the Monastery one space",
			guestBonusNoble: "Gain one Noble",
			guestBonusGuest3: "Gain a Guest card that costs 3 Beer",
			guestBonusTable: "Gain one Table card",
			guestBonusService: "You may remove one Guest",
			pendingBonus: "Pending bonus",
			none: "None",
			confirm: "Confirm",
			cancel: "Cancel",
			close: "Close",
			yourTavern: "Your tavern",
			menuTitle: "Public house",
			guestRow: "Guest row",
			barTitle: "Bar",
			facilityTitle: "Tavern facilities",
			diceTray: "Dice tray",
			coaster: "Coaster",
			opponentTitle: "Other taverns",
			tavernSupply: "Tavern cards",
			nobleSupply: "Nobles",
			tapTargetHint: "Click a target at a table or the bar to place the die",
			serveTapHint: "Click a table or bar spot with a die to resolve it",
			selectDieHint: "First pick a die in the tray",
			boostTitle: "Raise value",
			returnsHint: "Return matching Tavern cards to reduce the cost",
			pendingDice: "Dice to resolve: {{n}}",
			placedDice: "Dice placed this turn: {{n}}",
			coasterOwner: "Coaster passed from {{name}}",
			gainCard: "Gain one {{card}} card",
			overFacilities: "Facilities {{n}} / 9",
			overMonastery: "Monastery {{n}} / 22",
			overStored: "Thalers and Beer {{n}}",
			overCards: "Cards {{n}}",
			tieNote: "Equal victory points and supplies; the tied players share the victory"
		}
	}
};
//#endregion
export { _t as default };
