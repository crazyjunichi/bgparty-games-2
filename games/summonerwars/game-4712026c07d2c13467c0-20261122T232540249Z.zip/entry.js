import { z as e } from "zod";
import { useState as t } from "react";
import { BottomSheet as n } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as a } from "@bgparty/sdk/player-colors";
import { useWakeLock as o } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as c } from "@bgparty/sdk/ui/log-sheet";
import { SeatBadgedAvatar as l, seatName as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
//#region src/game/data.ts
var m = Object.fromEntries([
	{
		key: "ret_talus",
		name: "Ret-Talus",
		faction: "fallen-kingdom",
		type: "summoner",
		cost: 0,
		life: 14,
		strength: 2,
		atk: "ranged",
		tags: ["raiseDead"],
		text: {
			zh: "复活亡者：每回合一次，在你的召唤阶段，你可以对此单位造成 2 点伤害，从弃牌堆取回一个亡灵普通单位并放置在相邻空格。",
			en: "Raise the Dead: Once per turn, during your Summon Phase, you may add 2 damage to this unit to retrieve an Undead common from your discard pile and place it adjacent to this unit."
		}
	},
	{
		key: "dragos",
		name: "Dragos",
		faction: "fallen-kingdom",
		type: "champion",
		cost: 6,
		life: 8,
		strength: 4,
		atk: "melee",
		tags: ["lifeDrain"],
		text: {
			zh: "生命汲取：此单位攻击前，可以消灭 2 格内一个友方单位。若如此做，本次攻击中特殊符号视为近战命中。",
			en: "Life Drain: Before this unit attacks, it may destroy a friendly unit within 2 spaces. If it does, during that attack, special results count as melee hits."
		}
	},
	{
		key: "gul_dass",
		name: "Gul-Dass",
		faction: "fallen-kingdom",
		type: "champion",
		cost: 6,
		life: 9,
		strength: 2,
		atk: "melee",
		tags: ["spawn", "wraith"],
		text: {
			zh: "孵化：你可以将普通单位召唤在此单位相邻的空格。之后对此单位造成 1 点伤害。\n暴怒：此单位每有 1 点伤害，便获得 +1 力量。",
			en: "Spawn: You may summon commons adjacent to this unit. After summoning a common adjacent to this unit, add 1 damage to this unit.\nWrath: This unit has +1 strength for each damage it has."
		}
	},
	{
		key: "elut_bal",
		name: "Elut-Bal",
		faction: "fallen-kingdom",
		type: "champion",
		cost: 6,
		life: 6,
		strength: 6,
		atk: "melee",
		tags: ["summonedByFire"],
		text: {
			zh: "烈焰召来：支付费用召唤此单位时，你还必须消灭一个友方单位，并用此单位替换它。",
			en: "Summoned by Fire: When paying costs to summon this unit, you must also destroy a friendly unit. Replace the destroyed unit with this unit."
		}
	},
	{
		key: "undead_warrior",
		name: "Undead Warrior",
		faction: "fallen-kingdom",
		type: "common",
		cost: 2,
		life: 4,
		strength: 2,
		atk: "melee",
		token: "Undead",
		tags: ["bloodFury", "imbued"],
		text: {
			zh: "血怒：你的回合中每有一个单位被消灭，便强化此单位。你的回合结束时移去 2 个强化。\n灌注力量：每有 1 个强化获得 +1 力量，最多 +5。",
			en: "Blood Fury: Each time a unit is destroyed on your turn, boost this unit. At the end of your turn, remove 2 boost from this unit.\nImbued Strength: +1 strength per boost, to a maximum of +5."
		}
	},
	{
		key: "undead_archer",
		name: "Undead Archer",
		faction: "fallen-kingdom",
		type: "common",
		cost: 3,
		life: 2,
		strength: 2,
		atk: "ranged",
		token: "Undead",
		tags: ["soulShift"],
		text: {
			zh: "灵魂转移：你的回合中，3 格内一个单位被消灭后，你可以用此单位替换它。",
			en: "Soul Shift: After a unit within 3 spaces of this unit is destroyed during your turn, you may replace the destroyed unit with this unit."
		}
	},
	{
		key: "undead_carrier",
		name: "Undead Carrier",
		faction: "fallen-kingdom",
		type: "common",
		cost: 2,
		life: 3,
		strength: 1,
		atk: "melee",
		token: "Undead",
		tags: ["soulless", "infect"],
		text: {
			zh: "无魂：此单位消灭敌方单位时不获得魔力。\n感染：此单位消灭一个单位后，你可以从弃牌堆取回一个搬运者替换它。",
			en: "Soulless: Do not gain magic when this unit destroys an enemy unit.\nInfect: After this unit destroys a unit, you may replace it with a Carrier from your discard pile."
		}
	},
	{
		key: "hellfire_cultist",
		name: "Hellfire Cultist",
		faction: "fallen-kingdom",
		type: "common",
		cost: 2,
		life: 2,
		strength: 0,
		atk: "melee",
		token: "Cultist",
		tags: ["immolate"],
		text: {
			zh: "自焚：此单位被消灭后，对每个原本与其相邻的敌方单位造成 1 点伤害。",
			en: "Immolate: After this unit is destroyed, add 1 damage to each enemy unit that was adjacent to it."
		}
	},
	{
		key: "sacrificial_pyre",
		name: "Sacrificial Pyre",
		faction: "fallen-kingdom",
		type: "event",
		cost: 1,
		epic: !0,
		phase: "summon",
		active: !0,
		tags: ["pyre"],
		text: {
			zh: "持续：你的回合中每有一个单位被消灭，便强化此牌。此牌被弃置时，指定一个单位，按其上的强化数量移去等量伤害。",
			en: "ACTIVE: Each time a unit is destroyed, boost this card. When this card is discarded, target a unit. Remove 1 damage from the target for each boost on this card."
		}
	},
	{
		key: "purge",
		name: "Purge",
		faction: "fallen-kingdom",
		type: "event",
		cost: 0,
		phase: "move",
		tags: ["purge"],
		text: {
			zh: "指定任意数量的友方单位。对每个目标，你可以对一个与其相邻的单位造成 2 点伤害。然后消灭每个目标。",
			en: "Target any number of friendly units. For each target, you may add 2 damage to an adjacent unit. Destroy each target."
		}
	},
	{
		key: "blood_summon",
		name: "Blood Summon",
		faction: "fallen-kingdom",
		type: "event",
		cost: 0,
		phase: "summon",
		tags: ["bloodSummon"],
		text: {
			zh: "结算以下效果至多 3 次：指定一个友方单位。从手牌选择一个亡灵或邪教徒普通单位放置在目标相邻空格。若如此做，对目标造成 2 点伤害。",
			en: "Resolve the following effect up to 3 times: Target a friendly unit. Choose an Undead or Cultist common in your hand and place it adjacent to the target. If you do, add 2 damage to the target."
		}
	},
	{
		key: "hellforged_weapon",
		name: "Hellforged Weapon",
		faction: "fallen-kingdom",
		type: "event",
		cost: 0,
		phase: "event",
		tags: ["hellforged"],
		text: {
			zh: "将此牌放置在一个友方普通单位下方。该单位获得 +2 力量与「诅咒」：攻击后对其造成等于掷出特殊符号数量的伤害。",
			en: "Place this card under a friendly common. It has +2 strength and Cursed: after it attacks, add damage equal to special results rolled."
		}
	},
	{
		key: "sneeks",
		name: "Sneeks",
		faction: "cave-goblins",
		type: "summoner",
		cost: 0,
		life: 11,
		strength: 3,
		atk: "melee",
		tags: ["sly"],
		text: {
			zh: "狡诈：每回合一次，在你的攻击阶段，此单位可以与一个友方 0 费单位交换位置。",
			en: "Sly: Once per turn, during your Attack Phase, this unit may exchange places with a friendly 0 cost unit."
		}
	},
	{
		key: "blarf",
		name: "Blarf",
		faction: "cave-goblins",
		type: "champion",
		cost: 0,
		life: 6,
		strength: 0,
		atk: "melee",
		tags: ["bloodRunes", "imbued"],
		text: {
			zh: "血符文：在你的攻击阶段开始时，花费 1 点魔力强化此单位，或对此单位造成 1 点伤害。\n灌注力量：每有 1 个强化获得 +1 力量，最多 +5。",
			en: "Blood Runes: At the start of your Attack Phase, either spend 1 magic to boost this unit or add 1 damage to this unit.\nImbued Strength: +1 strength per boost, to a maximum of +5."
		}
	},
	{
		key: "smeg",
		name: "Smeg",
		faction: "cave-goblins",
		type: "champion",
		cost: 0,
		life: 4,
		strength: 2,
		atk: "ranged",
		tags: ["magicJunkie", "relentless"],
		text: {
			zh: "魔力瘾：在你的回合结束时，花费 1 点魔力，否则弃置此单位。\n无情：你可以选择此单位作为额外攻击单位。",
			en: "Magic Junkie: At the end of your turn, either spend 1 magic or discard this unit.\nRelentless: You may choose this unit as an extra attacking unit."
		}
	},
	{
		key: "the_eater",
		name: "The Eater",
		faction: "cave-goblins",
		type: "champion",
		cost: 6,
		life: 9,
		strength: 5,
		atk: "melee",
		tags: ["feedEater"],
		text: {
			zh: "喂养吞噬者：在你的攻击阶段结束时，若此单位本回合没有消灭单位，则弃置一个相邻的友方单位或弃置此单位。",
			en: "Feed the Eater: At the end of your Attack Phase, if this unit did not destroy a unit this turn, either discard a friendly adjacent unit or discard this unit."
		}
	},
	{
		key: "beast_rider",
		name: "Beast Rider",
		faction: "cave-goblins",
		type: "common",
		cost: 2,
		life: 3,
		strength: 3,
		atk: "melee",
		tags: ["charge"],
		text: {
			zh: "冲锋：此单位移动时，可以改为沿直线移动至多 4 格。若同一方向移动 3 格或更多，则直到回合结束获得 +1 力量。",
			en: "Charge: Instead of moving normally, this unit may move 1 to 4 clear straight spaces. If it moves 3 or more spaces in one direction, it has +1 strength until the end of your turn."
		}
	},
	{
		key: "horde_climber",
		name: "Horde Climber",
		faction: "cave-goblins",
		type: "common",
		cost: 0,
		life: 3,
		strength: 1,
		atk: "melee",
		tags: ["climb"],
		text: {
			zh: "攀爬：此单位移动时，可以额外移动 1 格，并可穿过建筑。",
			en: "Climb: When this unit moves, it may move 1 extra space and through structures."
		}
	},
	{
		key: "horde_clinger",
		name: "Horde Clinger",
		faction: "cave-goblins",
		type: "common",
		cost: 0,
		life: 2,
		strength: 2,
		atk: "melee",
		tags: ["immobile", "cling"],
		text: {
			zh: "无法移动：此单位不能移动。\n攀附：一个友方单位从其相邻处开始移动时，该次移动结束后，你可以将此单位放置到该单位相邻的空格。",
			en: "Immobile: This unit cannot move.\nCling: When a friendly unit starts its move adjacent to this unit, after that move, you may place this unit adjacent to that unit."
		}
	},
	{
		key: "horde_slinger",
		name: "Horde Slinger",
		faction: "cave-goblins",
		type: "common",
		cost: 0,
		life: 1,
		strength: 2,
		atk: "ranged",
		tags: ["relentless"],
		text: {
			zh: "无情：你可以选择此单位作为额外攻击单位。",
			en: "Relentless: You may choose this unit as an extra attacking unit."
		}
	},
	{
		key: "enrage_the_horde",
		name: "Enrage the Horde",
		faction: "cave-goblins",
		type: "event",
		cost: 1,
		epic: !0,
		phase: "magic",
		tags: ["enrage"],
		text: {
			zh: "指定所有友方 0 费单位。每个目标可以进行一次额外攻击。",
			en: "Target all friendly 0 cost units. Each target may resolve an extra attack."
		}
	},
	{
		key: "pile_on",
		name: "Pile On",
		faction: "cave-goblins",
		type: "event",
		cost: 0,
		phase: "attack",
		active: !0,
		tags: ["pileOn"],
		text: {
			zh: "持续：友方单位获得「群殴」：攻击时，目标每有一个其他友方单位与其相邻，便获得 +1 力量。",
			en: "ACTIVE: Friendly units have Gang Up: when this unit attacks, it has +1 strength for each other friendly unit adjacent to its target."
		}
	},
	{
		key: "sneak",
		name: "Sneak",
		faction: "cave-goblins",
		type: "event",
		cost: 0,
		phase: "move",
		tags: ["sneak"],
		text: {
			zh: "指定任意数量的友方 0 费单位。将每个目标推开 1 格。",
			en: "Target any number of friendly 0 cost units. Force each target 1 space."
		}
	},
	{
		key: "unrelenting",
		name: "Unrelenting",
		faction: "cave-goblins",
		type: "event",
		cost: 1,
		phase: "magic",
		active: !0,
		tags: ["unrelenting"],
		text: {
			zh: "持续：每当一个友方普通单位将被消灭时，改为将其返回你的手牌。",
			en: "ACTIVE: Each time a friendly common would be destroyed, instead of destroying it, return it to your hand."
		}
	},
	{
		key: "oldin",
		name: "Oldin",
		faction: "guild-dwarves",
		type: "summoner",
		cost: 0,
		life: 12,
		strength: 3,
		atk: "ranged",
		tags: ["redeploy", "masterPlan"],
		text: {
			zh: "重新部署：此单位移动后，可以指定一个基础生命值为 5 或更少的相邻友方建筑，将其放置到拥有者牌堆底部。\n总体规划：在你的建造阶段开始时，你可以从牌堆底部抽 1 张牌。",
			en: "Redeploy: After this unit moves, it may target a friendly adjacent structure with 5 or fewer base life. Place it on the bottom of its owner’s draw pile.\nMaster Plan: At the start of your Build Phase, you may draw 1 card from the bottom of your draw pile."
		}
	},
	{
		key: "dwaf",
		name: "Dwar",
		faction: "guild-dwarves",
		type: "champion",
		cost: 5,
		life: 6,
		strength: 3,
		atk: "melee",
		tags: ["leverage"],
		text: {
			zh: "杠杆：当此单位与一个友方建筑相邻时，它可以攻击与该建筑相邻的其他牌。",
			en: "Leverage: While this unit is adjacent to a friendly structure, it may attack other cards that are adjacent to that structure."
		}
	},
	{
		key: "grundor",
		name: "Grundor",
		faction: "guild-dwarves",
		type: "champion",
		cost: 3,
		life: 5,
		strength: 2,
		atk: "melee",
		tags: ["design", "masterBuilder"],
		text: {
			zh: "设计：召唤此单位后，你可以从牌堆或弃牌堆取回一张建筑牌或升级事件牌加入手牌。\n建筑大师：你可以在与此单位对角相邻的空格建造建筑。",
			en: "Design: After summoning this unit, you may retrieve a structure or Upgrade event from your draw or discard pile and add it to your hand.\nMaster Builder: You may build structures diagonal to this unit."
		}
	},
	{
		key: "grundors_tower",
		name: "Grundor's Tower",
		faction: "guild-dwarves",
		type: "champion",
		structure: !0,
		cost: 4,
		life: 5,
		strength: 4,
		atk: "ranged",
		tags: ["compound", "expand"],
		text: {
			zh: "复合：相邻的友方建筑获得「复合」。\n扩建：每回合一次，在你的建造阶段，你可以强化此牌。建造建筑时，你可以花费 1 个强化，将建筑建造在与一个具有「复合」的友方牌相邻的空格。",
			en: "Compound: Friendly adjacent structures have Compound.\nExpand: Once per turn, during your Build Phase, you may boost this card. When building a structure, you may spend 1 boost to build it adjacent to a friendly card with Compound."
		}
	},
	{
		key: "ballista",
		name: "Ballista",
		faction: "guild-dwarves",
		type: "common",
		structure: !0,
		cost: 1,
		life: 3,
		strength: 2,
		atk: "ranged",
		tags: ["primed", "forcefulShot"],
		text: {
			zh: "蓄势：此单位在被建造或召唤的回合中第一次攻击时获得 +1 力量。\n强弩之射：此单位攻击敌方普通单位或英雄后，可以将该敌人推开 1 格。",
			en: "Primed: +1 strength the first time it attacks during the turn it was built or summoned.\nForceful Shot: After attacking an enemy common or champion, you may force that enemy 1 space away."
		}
	},
	{
		key: "catapult",
		name: "Catapult",
		faction: "guild-dwarves",
		type: "common",
		structure: !0,
		cost: 1,
		life: 3,
		strength: 2,
		atk: "ranged",
		tags: ["launch"],
		text: {
			zh: "发射：建造或召唤此建筑后，你可以指定 3 格内的一个非召唤师单位，对其造成 1 点伤害。",
			en: "Launch: After building or summoning this structure, you may target a non-summoner within 3 spaces of it. Add 1 damage to the target."
		}
	},
	{
		key: "guild_defender",
		name: "Guild Defender",
		faction: "guild-dwarves",
		type: "common",
		cost: 2,
		life: 5,
		strength: 2,
		atk: "melee",
		tags: ["engage2"],
		text: {
			zh: "强力缠斗：每当一个相邻的敌方单位移动或被推离此单位时，对该敌人造成 2 点伤害。",
			en: "Greater Engage: Each time an adjacent enemy unit moves or is forced away from this unit, add 2 damage to that enemy."
		}
	},
	{
		key: "guild_engineer",
		name: "Guild Engineer",
		faction: "guild-dwarves",
		type: "common",
		cost: 1,
		life: 3,
		strength: 2,
		atk: "ranged",
		tags: ["recalibrate"],
		text: {
			zh: "校准：此单位移动后，可以指定一个相邻的友方建筑，将其推开 1 格。",
			en: "Recalibrate: After this unit moves, it may target a friendly adjacent structure. Force the target 1 space."
		}
	},
	{
		key: "baldars_gate",
		name: "Baldar's Gate",
		faction: "guild-dwarves",
		type: "event",
		structure: !0,
		cost: 1,
		life: 3,
		phase: "event",
		tags: ["gate", "baldarsGate"],
		text: {
			zh: "建造此城门后，你可以召唤一个普通单位至其相邻空格。若如此做，你可以立即让该普通单位进行一次额外攻击。",
			en: "After building this gate, you may summon a common adjacent to it. If you do, you may immediately resolve an extra attack with that common."
		}
	},
	{
		key: "battering_ram",
		name: "Battering Ram",
		faction: "guild-dwarves",
		type: "event",
		structure: !0,
		cost: 2,
		life: 5,
		phase: "event",
		tags: ["batteringRam"],
		text: {
			zh: "每回合一次，在你的攻击阶段，此牌可以指定一个相邻的敌方牌。将目标推开 1 格；若如此做，对其造成 2 点伤害。",
			en: "Once per turn, during your Attack Phase, this card may target an adjacent enemy card. Force the target 1 space. If you do, add 2 damage to it."
		}
	},
	{
		key: "supply_cache",
		name: "Supply Cache",
		faction: "guild-dwarves",
		type: "event",
		structure: !0,
		cost: 0,
		life: 2,
		phase: "event",
		tags: ["supplyCache"],
		text: {
			zh: "建造此牌后，其上放置 2 个强化。一个相邻的友方单位攻击前，你可以花费 1 个强化：抽 1 张牌，且该单位本次攻击获得 +1 力量。",
			en: "After building this card, add 2 boost to it. Before a friendly adjacent unit attacks, you may spend 1 boost: draw 1 card and that unit has +1 strength during that attack."
		}
	},
	{
		key: "blueprints",
		name: "Blueprints",
		faction: "guild-dwarves",
		type: "event",
		cost: 0,
		epic: !0,
		phase: "magic",
		active: !0,
		tags: ["blueprints"],
		text: {
			zh: "将手牌中至多 2 张建筑牌放置于此牌下方。持续：这些建筑费用减少 1，且可以在移动、建造或攻击阶段建造。若下方仍有建筑，在你的回合开始时不要弃置此牌。",
			en: "Place up to 2 structures from your hand under this card. ACTIVE: Structures under this card cost 1 less and can be built during your Move, Build, or Attack Phase. Do not discard this card at the start of your turn if there are structures under it."
		}
	},
	{
		key: "queen_maldaria",
		name: "Queen Maldaria",
		faction: "phoenix-elves",
		type: "summoner",
		cost: 0,
		life: 9,
		strength: 4,
		atk: "ranged",
		tags: ["callProtection", "saveTheQueen"],
		text: {
			zh: "召唤守护：在你的攻击阶段结束时，若此单位本回合攻击过敌方牌，它可以指定一个友方单位并放置到相邻空格。\n守卫女王：相邻的友方单位不能被穿过攻击，也不能被推开。",
			en: "Call Protection: At the end of your Attack Phase, if this unit attacked an enemy card this turn, it may target a friendly unit. Place it adjacent to this unit.\nSave the Queen: Friendly adjacent units cannot be attacked through or forced."
		}
	},
	{
		key: "fanessa",
		name: "Fanessa",
		faction: "phoenix-elves",
		type: "champion",
		cost: 5,
		life: 9,
		strength: 3,
		atk: "melee",
		tags: ["riposte"],
		text: {
			zh: "反击：此单位被一个相邻敌方单位攻击后，若它仍在场上，对该敌人造成 1 点伤害。",
			en: "Riposte: After this unit is attacked by an adjacent enemy unit, if this unit is still in play, add 1 damage to that enemy."
		}
	},
	{
		key: "holleas",
		name: "Holleas",
		faction: "phoenix-elves",
		type: "champion",
		cost: 5,
		life: 7,
		strength: 3,
		atk: "ranged",
		tags: ["fierySummon", "ignite"],
		text: {
			zh: "烈焰召唤：你可以将余烬单位召唤在此单位相邻的空格。\n点燃：相邻的友方余烬单位获得 +1 力量。",
			en: "Fiery Summon: You may summon Ember units adjacent to this unit.\nIgnite: Friendly adjacent Ember units have +1 strength."
		}
	},
	{
		key: "fire_drake",
		name: "Fire Drake",
		faction: "phoenix-elves",
		type: "champion",
		cost: 8,
		life: 10,
		strength: 4,
		atk: "ranged",
		tags: ["protector", "fireBreath"],
		text: {
			zh: "守护者：此单位可以被召唤在你的召唤师相邻的空格。\n火焰吐息：此单位可以穿过单位攻击。若如此做，每个特殊符号对位于此单位与目标之间的每个单位造成 1 点伤害。",
			en: "Protector: This unit may be summoned adjacent to your summoner.\nFire Breath: This unit may attack through units. When it does, each special result adds 1 damage to each unit between this unit and its target."
		}
	},
	{
		key: "ember_archer",
		name: "Ember Archer",
		faction: "phoenix-elves",
		type: "common",
		cost: 1,
		life: 2,
		strength: 2,
		atk: "ranged",
		token: "Ember",
		tags: ["quickShot"],
		text: {
			zh: "速射：此单位移动后，可以指定 3 格直线内的一个单位，对其造成 1 点伤害。",
			en: "Quick Shot: After this unit moves, it may target a unit within 3 clear straight spaces. Add 1 damage to the target."
		}
	},
	{
		key: "ember_beast",
		name: "Ember Beast",
		faction: "phoenix-elves",
		type: "common",
		cost: 2,
		life: 3,
		strength: 3,
		atk: "melee",
		token: "Ember",
		tags: ["bornOfFire", "wildfire"],
		text: {
			zh: "火中生：此单位可以被召唤在一个友方余烬单位相邻的空格。\n野火：在你的移动阶段开始时，对每个相邻敌方单位造成 1 点伤害。",
			en: "Born of Fire: This unit may be summoned adjacent to a friendly Ember unit.\nWildfire: At the start of your Move Phase, add 1 damage to each adjacent enemy unit."
		}
	},
	{
		key: "ember_mage",
		name: "Ember Mage",
		faction: "phoenix-elves",
		type: "common",
		cost: 1,
		life: 2,
		strength: 2,
		atk: "ranged",
		token: "Ember",
		tags: ["guarded"],
		text: {
			zh: "守护：每回合此单位第一次被攻击时，该次攻击对其造成的伤害不能超过 1 点。",
			en: "Guarded: The first time this unit is attacked on a turn, do not add more than 1 damage to it for that attack."
		}
	},
	{
		key: "royal_guardian",
		name: "Royal Guardian",
		faction: "phoenix-elves",
		type: "common",
		cost: 2,
		life: 4,
		strength: 1,
		atk: "melee",
		tags: ["engage1", "shove"],
		text: {
			zh: "缠斗：每当一个相邻的敌方单位移动或被推离此单位时，对该敌人造成 1 点伤害。\n推撞：此单位攻击一个相邻敌方普通单位或英雄后，可以将该敌人推开 1 格。",
			en: "Engage: Each time an adjacent enemy unit moves or is forced away from this unit, add 1 damage to that enemy.\nShove: After this unit attacks an adjacent enemy common or champion, you may force that enemy 1 space."
		}
	},
	{
		key: "blinding_flare",
		name: "Blinding Flare",
		faction: "phoenix-elves",
		type: "event",
		cost: 1,
		phase: "magic",
		active: !0,
		tags: ["blindingFlare"],
		text: {
			zh: "持续：当你的召唤师或与其相邻的友方单位被攻击时，改为以掷出的近战符号数量计算伤害，而不按远程命中或特殊符号计算。",
			en: "ACTIVE: When your summoner or a friendly unit adjacent to your summoner is being attacked, add 1 damage to it for each melee hit rolled instead of each ranged hit or special result."
		}
	},
	{
		key: "burn",
		name: "Burn",
		faction: "phoenix-elves",
		type: "event",
		cost: 0,
		phase: "move",
		tags: ["burn"],
		text: {
			zh: "指定你召唤师 2 格内的一个普通单位或英雄，对其造成 2 点伤害。",
			en: "Target a common or champion within 2 spaces of your summoner. Add 2 damage to the target."
		}
	},
	{
		key: "divine_retribution",
		name: "Divine Retribution",
		faction: "phoenix-elves",
		type: "event",
		cost: 0,
		phase: "magic",
		active: !0,
		tags: ["divineRetribution"],
		text: {
			zh: "持续：你的召唤师获得「凤凰光环」：它或 3 格内的友方单位被敌方单位攻击后，对该敌人造成 1 点伤害。",
			en: "ACTIVE: Your summoner has Aura of the Phoenix: after it or a friendly unit within 3 spaces is attacked by an enemy unit, add 1 damage to that enemy."
		}
	},
	{
		key: "spirit_of_the_phoenix",
		name: "Spirit of the Phoenix",
		faction: "phoenix-elves",
		type: "event",
		cost: 0,
		epic: !0,
		phase: "summon",
		active: !0,
		tags: ["spiritOfPhoenix"],
		text: {
			zh: "持续：当一个友方单位的能力在不进行攻击的情况下对敌方单位造成伤害时，该能力额外造成 1 点伤害。",
			en: "ACTIVE: When the ability of a friendly unit adds damage to an enemy unit without attacking it, the ability adds 1 more damage."
		}
	},
	{
		key: "selundar",
		name: "Selundar",
		faction: "shadow-elves",
		type: "summoner",
		cost: 0,
		life: 11,
		strength: 5,
		atk: "ranged",
		tags: ["bloodMagic", "returnToShadow"],
		text: {
			zh: "血魔法：你的回合中，每当 3 格内的一个友方牌被添加 1 点或更多伤害后，强化此单位。\n回归暗影：你的回合中，你可以花费 2 个强化，指定 3 格内的一个友方单位并返回手牌。",
			en: "Blood Magic: During your turn, after each time 1 or more damage is added to a friendly card within 3 spaces, boost this unit.\nReturn to Shadow: During your turn, you may spend 2 boost to target a friendly unit within 3 spaces and return it to your hand."
		}
	},
	{
		key: "lucian",
		name: "Lucian",
		faction: "shadow-elves",
		type: "champion",
		cost: 5,
		life: 8,
		strength: 3,
		atk: "ranged",
		tags: ["darkProphecy", "judgment"],
		text: {
			zh: "黑暗预言：每当一个友方单位离开战场时，强化此单位。\n审判：此单位移动后，你可以花费任意数量的强化，对一个相邻普通单位或英雄造成等量伤害。",
			en: "Dark Prophecy: Each time a friendly unit leaves the battlefield, boost this unit.\nJudgment: After this unit moves, you may spend any number of boost to add that much damage to an adjacent common or champion."
		}
	},
	{
		key: "samara",
		name: "Samara",
		faction: "shadow-elves",
		type: "champion",
		cost: 5,
		life: 7,
		strength: 4,
		atk: "melee",
		tags: ["inevitableDoom"],
		text: {
			zh: "必然厄运：在你的攻击阶段结束时，若此单位本回合消灭过敌方单位，对敌方召唤师造成 1 点伤害；否则对你的召唤师造成 1 点伤害。",
			en: "Inevitable Doom: At the end of your Attack Phase, if this unit destroyed an enemy unit this turn, add 1 damage to the enemy summoner. Otherwise, add 1 damage to your summoner."
		}
	},
	{
		key: "taliya",
		name: "Taliya",
		faction: "shadow-elves",
		type: "champion",
		cost: 5,
		life: 7,
		strength: 3,
		atk: "melee",
		tags: ["rendTheVeil"],
		text: {
			zh: "撕裂帷幕：每回合一次，此单位移动后，若它与一个受伤的敌方城门相邻，你可以将一个友方普通单位放置到该城门相邻的空格。",
			en: "Rend the Veil: Once per turn, after this unit moves, if it is adjacent to a damaged enemy gate, you may place a friendly common adjacent to that gate."
		}
	},
	{
		key: "sage_ranger",
		name: "Sage Ranger",
		faction: "shadow-elves",
		type: "common",
		cost: 1,
		life: 3,
		strength: 2,
		atk: "ranged",
		tags: ["piercingLight", "rush"],
		text: {
			zh: "穿刺之光：此单位在被召唤的回合中可以穿过单位攻击。\n突进：召唤此单位后，你可以将其推开 1 格。",
			en: "Piercing Light: This unit may attack through units during the turn it was summoned.\nRush: After summoning this unit, you may force it 1 space."
		}
	},
	{
		key: "shadow_knight",
		name: "Shadow Knight",
		faction: "shadow-elves",
		type: "common",
		cost: 1,
		life: 5,
		strength: 2,
		atk: "melee",
		tags: ["shadowSummon", "deathPact"],
		text: {
			zh: "暗影召唤：召唤此单位时，指定一个不具有「暗影召唤」的友方牌。将此单位放置在目标相邻空格，并对目标造成 1 点伤害。\n死亡契约：此单位被消灭后，对你的召唤师造成 1 点伤害。",
			en: "Shadow Summon: When summoning this unit, target a friendly card without Shadow Summon. Place this unit adjacent to it and add 1 damage to it.\nDeath Pact: After this unit is destroyed, add 1 damage to your summoner."
		}
	},
	{
		key: "shadow_mage",
		name: "Shadow Mage",
		faction: "shadow-elves",
		type: "common",
		cost: 2,
		life: 4,
		strength: 3,
		atk: "ranged",
		tags: ["forbiddenKnowledge"],
		text: {
			zh: "禁忌知识：此单位移动后，你可以对此单位或一个相邻城门造成 1 点伤害，以抽 1 张牌。",
			en: "Forbidden Knowledge: After this unit moves, you may add 1 damage to either this unit or an adjacent gate to draw 1 card."
		}
	},
	{
		key: "true_seeker",
		name: "True Seeker",
		faction: "shadow-elves",
		type: "common",
		cost: 1,
		life: 3,
		strength: 1,
		atk: "melee",
		tags: ["aggressiveAttack", "feint"],
		text: {
			zh: "强袭：此单位在被召唤的回合中获得 +2 力量。\n佯攻：此单位攻击后，你可以将其推开 1 或 2 格。",
			en: "Aggressive Attack: This unit has +2 strength during the turn it was summoned.\nFeint: After this unit attacks, you may force it 1 or 2 spaces."
		}
	},
	{
		key: "glinting_speed",
		name: "Glinting Speed",
		faction: "shadow-elves",
		type: "event",
		cost: 0,
		phase: "attack",
		active: !0,
		tags: ["glintingSpeed"],
		text: {
			zh: "持续：你的召唤师获得「闪现」：你的回合中，它 3 格内的一个单位离开战场后，你可以用该单位替换它。",
			en: "ACTIVE: Your summoner has Flash Step: after a unit within 3 spaces of it leaves the battlefield during your turn, you may replace that unit with it."
		}
	},
	{
		key: "into_darkness",
		name: "Into Darkness",
		faction: "shadow-elves",
		type: "event",
		cost: 0,
		epic: !0,
		phase: "event",
		tags: ["intoDarkness"],
		text: {
			zh: "指定你召唤师 3 格内的一个剩余生命值为 5 或更少的城门或普通牌。将该牌及其下方的所有牌加入各自拥有者的手牌。",
			en: "Target a gate or common card with 5 or fewer remaining life within 3 spaces of your summoner. Add it and any cards under it to each card's owner's hand."
		}
	},
	{
		key: "onyx_tome",
		name: "Onyx Tome",
		faction: "shadow-elves",
		type: "event",
		cost: 1,
		phase: "summon",
		tags: ["onyxTome"],
		text: {
			zh: "从弃牌堆取回一张除「玛瑙典籍」或史诗事件以外的牌加入手牌。结算以下效果 2 次：对一个友方单位造成 1 点伤害。",
			en: "Retrieve a card other than Onyx Tome or an epic event from your discard pile and add it to your hand.\nResolve the following effect 2 times: Add 1 damage to a friendly unit."
		}
	},
	{
		key: "shadow_pulse",
		name: "Shadow Pulse",
		faction: "shadow-elves",
		type: "event",
		cost: 0,
		phase: "attack",
		tags: ["shadowPulse"],
		text: {
			zh: "指定任意数量的、与 1 个或更多受伤城门相邻的单位。对每个目标造成 1 点伤害。",
			en: "Target any number of units that are adjacent to 1 or more damaged gates. Add 1 damage to each target."
		}
	},
	{
		key: "sera_eldwyn",
		name: "Sera Eldwyn",
		faction: "vanguards",
		type: "summoner",
		cost: 0,
		life: 12,
		strength: 3,
		atk: "ranged",
		tags: ["citadelsMight"],
		text: {
			zh: "堡垒之力：此单位攻击一个敌方单位后，若战场上有 1 个或更多友方堡垒单位，你可以从弃牌堆取回一个堡垒单位加入手牌。",
			en: "The Citadel's Might: After this unit attacks an enemy unit, if there are 1 or more friendly Citadel units on the battlefield, you may retrieve a Citadel unit from your discard pile and add it to your hand."
		}
	},
	{
		key: "colleen_brighton",
		name: "Colleen Brighton",
		faction: "vanguards",
		type: "champion",
		cost: 6,
		life: 8,
		strength: 3,
		atk: "melee",
		tags: ["divineShield"],
		text: {
			zh: "神圣护盾：每当 3 格内的一个友方堡垒单位被敌人攻击指定为目标时，掷 2 枚骰子。每掷出一个近战命中，本次攻击中攻击单位力量 -1，最低为 1。",
			en: "Divine Shield: Each time a friendly Citadel unit within 3 spaces of this unit is targeted by an enemy attack, roll 2 dice. For each melee hit rolled, reduce the attacker's strength by 1 during that attack, to a minimum of 1."
		}
	},
	{
		key: "jacob_eldwyn",
		name: "Jacob Eldwyn",
		faction: "vanguards",
		type: "champion",
		cost: 3,
		life: 5,
		strength: 2,
		atk: "ranged",
		tags: ["radiantShot", "bowCaptain"],
		text: {
			zh: "光辉射击：你每有 2 点魔力，此单位便获得 +1 力量。\n弓术队长：此单位攻击一个敌方单位后，本回合下一个攻击的远程普通单位在本次攻击中获得 +1 力量。",
			en: "Radiant Shot: This unit has +1 strength for every 2 magic you have.\nBow Captain: After this unit attacks an enemy unit, the next ranged common that attacks this turn has +1 strength during that attack."
		}
	},
	{
		key: "valna_stoutheart",
		name: "Valna Stoutheart",
		faction: "vanguards",
		type: "champion",
		cost: 6,
		life: 9,
		strength: 2,
		atk: "melee",
		tags: ["guidance", "citadelChampion"],
		text: {
			zh: "指引：在你的召唤阶段开始时，抽 2 张牌。\n堡垒勇士：此单位每有一个 2 格内的友方堡垒单位，便获得 +1 力量。",
			en: "Guidance: At the start of your Summon Phase, draw 2 cards.\nCitadel Champion: This unit has +1 strength for each friendly Citadel unit within 2 spaces."
		}
	},
	{
		key: "citadel_archer",
		name: "Citadel Archer",
		faction: "vanguards",
		type: "common",
		cost: 2,
		life: 5,
		strength: 1,
		atk: "ranged",
		token: "Citadel",
		tags: ["arrowOfLight"],
		text: {
			zh: "光之箭：此单位攻击前，展示并弃置手牌中任意数量的不同单位。每弃置 1 个，获得 1 点魔力，且此单位本次攻击获得 +1 力量。",
			en: "Arrow of Light: Before this unit attacks, reveal and discard any number of distinct units from your hand. Gain 1 magic for each. This unit has +1 strength during that attack for each."
		}
	},
	{
		key: "citadel_knight",
		name: "Citadel Knight",
		faction: "vanguards",
		type: "common",
		cost: 2,
		life: 5,
		strength: 2,
		atk: "melee",
		token: "Citadel",
		tags: ["engage1", "protect"],
		text: {
			zh: "缠斗：每当一个相邻的敌方单位移动或被推离此单位时，对该敌人造成 1 点伤害。\n保护：当相邻的敌人攻击时，该次攻击的目标必须是一个具有「保护」能力的单位。",
			en: "Engage: Each time an adjacent enemy unit moves or is forced away from this unit, add 1 damage to that enemy.\nProtect: When an adjacent enemy attacks, the target must be a unit with Protect."
		}
	},
	{
		key: "citadel_paladin",
		name: "Citadel Paladin",
		faction: "vanguards",
		type: "common",
		cost: 2,
		life: 4,
		strength: 3,
		atk: "melee",
		token: "Citadel",
		tags: ["intercession"],
		text: {
			zh: "代祷：此单位攻击一个敌方单位后，按掷出的近战命中数量抽牌。",
			en: "Intercession: After this unit attacks an enemy unit, draw cards equal to the number of melee hits rolled."
		}
	},
	{
		key: "temple_priest",
		name: "Temple Priest",
		faction: "vanguards",
		type: "common",
		cost: 0,
		life: 2,
		strength: 2,
		atk: "melee",
		tags: ["heal"],
		text: {
			zh: "治疗：此单位攻击一个友方普通单位或英雄前，你可以弃置 1 张手牌。若如此做，改为按掷出的近战与远程命中数量移去伤害。",
			en: "Heal: Before this unit attacks a friendly common or champion, you may discard 1 card from your hand. If you do, instead of adding damage, remove damage equal to melee and ranged hits rolled."
		}
	},
	{
		key: "guarding_spirits",
		name: "Guarding Spirits",
		faction: "vanguards",
		type: "event",
		cost: 0,
		phase: "magic",
		active: !0,
		tags: ["guardingSpirits"],
		text: {
			zh: "持续：你召唤师 3 格内的友方普通单位获得「守护」：每回合第一次被攻击时，该次攻击对其造成的伤害不能超过 1 点。",
			en: "ACTIVE: Friendly commons within 3 spaces of your summoner have Guarded: the first time this unit is attacked on a turn, do not add more than 1 damage to it for that attack."
		}
	},
	{
		key: "holy_judgment",
		name: "Holy Judgment",
		faction: "vanguards",
		type: "event",
		cost: 0,
		epic: !0,
		phase: "attack",
		active: !0,
		tags: ["holyJudgment"],
		text: {
			zh: "在此牌上放置 2 个强化。持续：友方普通单位 +1 力量。在你的回合开始时，你可以花费 1 个强化以代替弃置此牌。每当一个友方单位被消灭时，从此牌移去 1 个强化（若可能）。",
			en: "Add 2 boost to this card. ACTIVE: Friendly commons have +1 strength. At the start of your turn, you may spend 1 boost instead of discarding this event. Each time a friendly unit is destroyed, remove 1 boost from this card, if able."
		}
	},
	{
		key: "mass_heal",
		name: "Mass Heal",
		faction: "vanguards",
		type: "event",
		cost: 0,
		phase: "any",
		tags: ["massHeal"],
		text: {
			zh: "从你召唤师 2 格内的每个友方普通单位与英雄上移去 2 点伤害。",
			en: "Remove 2 damage from each friendly common and champion within 2 spaces of your summoner."
		}
	},
	{
		key: "renewed_hope",
		name: "Renewed Hope",
		faction: "vanguards",
		type: "event",
		cost: 0,
		phase: "summon",
		active: !0,
		tags: ["renewedHope"],
		text: {
			zh: "持续：你可以在任意阶段召唤单位。单位可以被召唤在你召唤师相邻的空格。",
			en: "ACTIVE: You may summon units during any phase of your turn. Units may be summoned adjacent to your summoner."
		}
	},
	...Object.values({
		gate10: {
			key: "gate10",
			name: "Gate",
			faction: "fallen-kingdom",
			type: "common",
			structure: !0,
			cost: 0,
			life: 10,
			strength: 0,
			tags: ["gate"],
			text: {
				zh: "这是一道生命值为 10 的城门。",
				en: "This card is a gate with 10 life."
			}
		},
		gate5: {
			key: "gate5",
			name: "Gate",
			faction: "fallen-kingdom",
			type: "common",
			structure: !0,
			cost: 0,
			life: 5,
			strength: 0,
			tags: ["gate"],
			text: {
				zh: "这是一道生命值为 5 的城门。",
				en: "This card is a gate with 5 life."
			}
		}
	})
].map((e) => [e.key, e])), h = [
	{
		id: "fallen-kingdom",
		name: "Fallen Kingdom",
		zh: "堕落王国",
		accent: "#8f3d6b",
		summoner: "ret_talus",
		champs: [
			"dragos",
			"gul_dass",
			"elut_bal"
		],
		commons: [
			"undead_warrior",
			"undead_archer",
			"undead_carrier",
			"hellfire_cultist"
		],
		events: [
			"sacrificial_pyre",
			"purge",
			"blood_summon",
			"hellforged_weapon"
		],
		setup: [
			{
				key: "undead_carrier",
				col: 2,
				row: 1
			},
			{
				key: "gate10",
				col: 3,
				row: 1
			},
			{
				key: "undead_archer",
				col: 2,
				row: 2
			},
			{
				key: "ret_talus",
				col: 3,
				row: 3
			}
		],
		starting: ["undead_carrier", "undead_archer"]
	},
	{
		id: "cave-goblins",
		name: "Cave Goblins",
		zh: "洞穴地精",
		accent: "#7a8f2f",
		summoner: "sneeks",
		champs: [
			"blarf",
			"smeg",
			"the_eater"
		],
		commons: [
			"beast_rider",
			"horde_climber",
			"horde_clinger",
			"horde_slinger"
		],
		events: [
			"enrage_the_horde",
			"pile_on",
			"sneak",
			"unrelenting"
		],
		setup: [
			{
				key: "beast_rider",
				col: 2,
				row: 1
			},
			{
				key: "gate10",
				col: 3,
				row: 2
			},
			{
				key: "horde_slinger",
				col: 4,
				row: 2
			},
			{
				key: "sneeks",
				col: 4,
				row: 3
			}
		],
		starting: ["beast_rider", "horde_slinger"]
	},
	{
		id: "guild-dwarves",
		name: "Guild Dwarves",
		zh: "工会矮人",
		accent: "#b4622a",
		summoner: "oldin",
		champs: [
			"dwaf",
			"grundor",
			"grundors_tower"
		],
		commons: [
			"ballista",
			"catapult",
			"guild_defender",
			"guild_engineer"
		],
		events: [
			"blueprints",
			"baldars_gate",
			"battering_ram",
			"supply_cache"
		],
		setup: [
			{
				key: "catapult",
				col: 2,
				row: 1
			},
			{
				key: "guild_defender",
				col: 3,
				row: 1
			},
			{
				key: "gate10",
				col: 2,
				row: 2
			},
			{
				key: "oldin",
				col: 3,
				row: 2
			}
		],
		starting: ["catapult", "guild_defender"]
	},
	{
		id: "phoenix-elves",
		name: "Phoenix Elves",
		zh: "凤凰精灵",
		accent: "#c8402c",
		summoner: "queen_maldaria",
		champs: [
			"fanessa",
			"holleas",
			"fire_drake"
		],
		commons: [
			"ember_archer",
			"ember_beast",
			"ember_mage",
			"royal_guardian"
		],
		events: [
			"blinding_flare",
			"burn",
			"divine_retribution",
			"spirit_of_the_phoenix"
		],
		setup: [
			{
				key: "royal_guardian",
				col: 2,
				row: 1
			},
			{
				key: "gate10",
				col: 3,
				row: 1
			},
			{
				key: "ember_archer",
				col: 4,
				row: 1
			},
			{
				key: "queen_maldaria",
				col: 3,
				row: 3
			}
		],
		starting: ["royal_guardian", "ember_archer"]
	},
	{
		id: "shadow-elves",
		name: "Shadow Elves",
		zh: "暗影精灵",
		accent: "#5b4a9a",
		summoner: "selundar",
		champs: [
			"lucian",
			"samara",
			"taliya"
		],
		commons: [
			"sage_ranger",
			"shadow_knight",
			"shadow_mage",
			"true_seeker"
		],
		events: [
			"glinting_speed",
			"into_darkness",
			"onyx_tome",
			"shadow_pulse"
		],
		setup: [
			{
				key: "sage_ranger",
				col: 3,
				row: 0
			},
			{
				key: "gate10",
				col: 3,
				row: 1
			},
			{
				key: "shadow_mage",
				col: 2,
				row: 2
			},
			{
				key: "selundar",
				col: 3,
				row: 2
			}
		],
		starting: ["sage_ranger", "shadow_mage"]
	},
	{
		id: "vanguards",
		name: "Vanguards",
		zh: "先锋军",
		accent: "#b9892f",
		summoner: "sera_eldwyn",
		champs: [
			"colleen_brighton",
			"jacob_eldwyn",
			"valna_stoutheart"
		],
		commons: [
			"citadel_archer",
			"citadel_knight",
			"citadel_paladin",
			"temple_priest"
		],
		events: [
			"guarding_spirits",
			"holy_judgment",
			"mass_heal",
			"renewed_hope"
		],
		setup: [
			{
				key: "citadel_knight",
				col: 2,
				row: 0
			},
			{
				key: "gate10",
				col: 3,
				row: 2
			},
			{
				key: "temple_priest",
				col: 4,
				row: 2
			},
			{
				key: "sera_eldwyn",
				col: 3,
				row: 3
			}
		],
		starting: ["citadel_knight", "temple_priest"]
	}
], g = Object.fromEntries(h.map((e) => [e.id, e]));
function _(e, t, n) {
	return (e === 0 ? 7 - n : n) * 6 + t;
}
function v(e) {
	let t = [];
	t.push("gate5", "gate5", "gate5");
	for (let n of e.champs) t.push(n);
	for (let n of e.commons) for (let e = 0; e < 4; e++) t.push(n);
	for (let n of e.events) m[n].epic, t.push(n, n);
	return t;
}
//#endregion
//#region src/game/engine.ts
function y(e) {
	return e.cursor = (e.cursor * 1664525 + 1013904223) % 4294967296, e.cursor / 4294967296;
}
function b(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = Math.floor(y(e) * (n + 1)), i = t[n];
		t[n] = t[r], t[r] = i;
	}
	return t;
}
function x(e, t) {
	let n = [];
	for (let r = 0; r < t; r++) {
		let t = y(e);
		n.push(t < .5 ? "melee" : t < .8333 ? "ranged" : "special");
	}
	return {
		faces: n,
		hits: n.filter((e) => e !== "special").length,
		specials: n.filter((e) => e === "special").length
	};
}
var S = (e) => e % 6, C = (e) => Math.floor(e / 6);
function w(e, t) {
	return Math.abs(S(e) - S(t)) + Math.abs(C(e) - C(t));
}
function T(e) {
	let t = S(e), n = C(e), r = [];
	return t > 0 && r.push(e - 1), t < 5 && r.push(e + 1), n > 0 && r.push(e - 6), n < 7 && r.push(e + 6), r;
}
function E(e, t) {
	return w(e, t) === 1;
}
function D(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) throw Error("no player " + t);
	return n;
}
function O(e, t) {
	return D(e, e.units[t].owner);
}
function k(e) {
	return e.board.filter((e) => !!e).map((t) => e.units[t]);
}
function A(e, t) {
	return e.players.find((e) => e.rid !== t);
}
function j(e, t) {
	return k(e).filter((e) => e.owner === t);
}
function ee(e, t) {
	return j(e, t).filter((e) => m[e.card].tags.includes("gate"));
}
function M(e, t) {
	let n = D(e, t).summoner, r = e.units[n];
	if (!r) throw Error(`summonerwars: no summoner for ${t}`);
	return r;
}
function N(e, t, n) {
	return D(e, t).active.some((t) => e.units[t] && m[e.units[t].card].tags.includes(n));
}
function P(e, t) {
	let n = m[t.card], r = n.strength ?? 0, i = n.tags;
	return i.includes("imbued") && (r += Math.min(5, t.boosts)), i.includes("wraith") && (r += t.damage), i.includes("aggressiveAttack") && t.entered === e.turnNumber && (r += 2), i.includes("primed") && t.entered === e.turnNumber && !t.attackedOnce && (r += 1), i.includes("radiantShot") && (r += Math.floor(D(e, t.owner).magic / 2)), i.includes("citadelChampion") && (r += j(e, t.owner).filter((e) => m[e.card].token === "Citadel" && e.uid !== t.uid && w(e.slot, t.slot) <= 2).length), N(e, t.owner, "holyJudgment") && n.type === "common" && (r += 1), t.under.some((e) => e === "hellforged_weapon") && (r += 2), i.includes("ignite"), j(e, t.owner).some((e) => m[e.card].tags.includes("ignite") && E(e.slot, t.slot)) && n.token === "Ember" && (r += 1), Math.max(0, r);
}
function F(e, t) {
	let n = m[t.card].life ?? 0;
	return Math.max(0, n - t.damage);
}
function I(e, t) {
	let n = m[t.card].tags;
	if (n.includes("immobile")) return 0;
	let r = 2;
	return n.includes("climb") && (r += 1), r;
}
function L(e, t) {
	let n = m[t.card];
	return n.structure && !n.tags.includes("expand") ? !1 : I(e, t) > 0;
}
function R(e, t, n, r, i) {
	e.log.push({
		key: t,
		who: n,
		card: r,
		n: i
	}), e.log.length > 80 && e.log.shift();
}
function z(e, t, n, r = !1) {
	let i = 0;
	for (let e = 0; e < n && t.draw.length; e++) {
		let e = r ? t.draw.shift() : t.draw.pop();
		t.hand.push(e), i++;
	}
	return i;
}
function B(e, t, n) {
	t.boosts = Math.max(0, t.boosts + n);
}
function V(e, t, n, r = {}) {
	let i = e.units[t];
	if (!i || e.board[i.slot] !== t) return 0;
	let a = m[i.card], o = n;
	if (r.ability && N(e, i.owner, "spiritOfPhoenix") && e.players.some((e) => e.rid !== i.owner) && (o += 1), r.ignoreGuarded || (a.tags.includes("guarded") || a.type === "common" && N(e, i.owner, "guardingSpirits") && w(i.slot, M(e, i.owner).slot) <= 3) && !i.flags["guarded:" + e.turnNumber] && (o = Math.min(o, 1), i.flags["guarded:" + e.turnNumber] = 1), r.attacker && N(e, i.owner, "blindingFlare")) {
		let t = M(e, i.owner);
		(i.uid === t.uid || E(i.slot, t.slot)) && r.attackRoll && (o = r.attackRoll.faces.filter((e) => e === "melee").length);
	}
	if (o <= 0) return 0;
	i.damage += o, R(e, "damage", i.owner, i.uid, o);
	for (let t of e.players) {
		let n = t.summoner && e.units[t.summoner];
		n && m[n.card].tags.includes("bloodMagic") && e.board[n.slot] === n.uid && t.rid === i.owner && w(n.slot, i.slot) <= 3 && B(e, n, 1);
		for (let n of t.active) {
			let t = e.units[n];
			t && m[t.card].tags.includes("pyre") && B(e, t, 1);
		}
	}
	if (r.attacker) {
		let n = e.units[r.attacker];
		if (n && m[n.card].tags.includes("riposte") && E(n.slot, i.slot) && e.board[i.slot] === t && V(e, r.attacker, 1, { ability: !0 }), N(e, i.owner, "divineRetribution")) {
			let t = M(e, i.owner);
			e.board[t.slot] === t.uid && (i.uid === t.uid || w(t.slot, i.slot) <= 3) && e.units[r.attacker] && e.units[r.attacker].slot >= 0 && V(e, r.attacker, 1, { ability: !0 });
		}
	}
	return i.damage >= (a.life ?? 0) && U(e, t, { attacker: r.attacker }), o;
}
function H(e, t, n) {
	let r = e.units[t];
	r && (r.damage = Math.max(0, r.damage - n));
}
function U(e, t, n = {}) {
	let r = e.units[t];
	if (!r || e.board[r.slot] !== t) return;
	let i = m[r.card], a = O(e, t), o = r.slot;
	e.board[r.slot] = null, r.slot = -1;
	let s = r.under;
	r.damage = 0, r.boosts = 0, r.under = [], a.discard.push(r.card);
	for (let e of s) a.discard.push(e);
	if (R(e, "destroyed", a.rid, r.uid, 1), i.type === "summoner") {
		e.winner = e.players.find((e) => e.rid !== a.rid).rid;
		return;
	}
	let c = n.attacker ? e.units[n.attacker]?.owner : void 0;
	if (c && c !== a.rid && !i.tags.includes("soulless")) {
		let t = D(e, c);
		t.magic += 1;
		let r = n.attacker ? e.units[n.attacker] : null;
		r && (r.killCount += 1);
	}
	if (!e.winner) {
		let t = k(e).find((t) => t.owner === e.turn && m[t.card].tags.includes("soulShift") && w(t.slot, o) <= 3);
		t && !e.board[o] && (e.board[t.slot] = null, t.slot = o, e.board[o] = t.uid, t.flags.shifted = 1, R(e, "moved", t.owner, t.uid));
	}
	if (i.tags.includes("immolate")) for (let t of T(o)) {
		let n = e.units[e.board[t] ?? ""];
		n && n.owner !== r.owner && V(e, n.uid, 1, { ability: !0 });
	}
	if (i.tags.includes("deathPact")) {
		let t = M(e, r.owner);
		e.board[t.slot] === t.uid && V(e, t.uid, 1, { ability: !0 });
	}
	if (N(e, a.rid, "unrelenting") && i.type === "common" && a.hand.push(r.card), N(e, a.rid, "holyJudgment")) {
		let t = a.active.map((t) => e.units[t]).find((e) => e && m[e.card].tags.includes("holyJudgment"));
		t && B(e, t, -1);
	}
	for (let t of j(e, a.rid)) m[t.card].tags.includes("darkProphecy") && B(e, t, 1);
	for (let t of j(e, a.rid)) m[t.card].tags.includes("bloodFury") && B(e, t, 1);
	if (n.attacker) {
		let t = e.units[n.attacker];
		if (t && m[t.card].tags.includes("infect")) {
			let n = D(e, t.owner), r = n.discard.lastIndexOf("undead_carrier");
			r >= 0 && !e.board[o] && (n.discard.splice(r, 1), W(e, n.rid, "undead_carrier", o, !1));
		}
	}
}
function W(e, t, n, r, i, a = {}) {
	let o = D(e, t), s = m[n];
	if (e.board[r] || i && o.magic < s.cost) return null;
	i && (o.magic -= s.cost), e.seq += 1;
	let c = {
		uid: `${n}#${e.seq}`,
		card: n,
		owner: t,
		slot: r,
		damage: 0,
		boosts: 0,
		under: [],
		entered: e.turnNumber,
		moved: !1,
		attacked: !1,
		attackedOnce: !1,
		killCount: 0,
		flags: {}
	};
	return e.units[c.uid] = c, e.board[r] = c.uid, a.enters && R(e, "summoned", t, n), c;
}
function G(e, t, n) {
	let r = D(e, t);
	e.seq += 1;
	let i = {
		uid: `event#${e.seq}`,
		card: n,
		owner: t,
		slot: -1,
		damage: 0,
		boosts: 0,
		under: [],
		entered: e.turnNumber,
		moved: !1,
		attacked: !1,
		attackedOnce: !1,
		killCount: 0,
		flags: {}
	};
	return e.units[i.uid] = i, r.active.push(i.uid), m[n].tags.includes("holyJudgment") && (i.boosts = 2), i;
}
//#endregion
//#region src/game/schema.ts
var K = e.discriminatedUnion("type", [
	e.object({ type: e.literal("next") }),
	e.object({
		type: e.literal("summon"),
		card: e.string(),
		slot: e.number().int(),
		source: e.string().optional(),
		extra: e.string().optional()
	}),
	e.object({
		type: e.literal("build"),
		card: e.string(),
		slot: e.number().int()
	}),
	e.object({
		type: e.literal("move"),
		uid: e.string(),
		to: e.number().int()
	}),
	e.object({
		type: e.literal("attack"),
		uid: e.string(),
		target: e.string(),
		via: e.string().optional()
	}),
	e.object({
		type: e.literal("event"),
		card: e.string(),
		targets: e.array(e.string()).default([]),
		picks: e.array(e.string()).default([])
	}),
	e.object({
		type: e.literal("ability"),
		uid: e.string(),
		target: e.string().optional(),
		value: e.number().optional()
	}),
	e.object({
		type: e.literal("discard"),
		cards: e.array(e.string()).min(1)
	}),
	e.object({
		type: e.literal("choose"),
		id: e.string()
	}),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), q = e.object({
	factionA: e.enum([
		"fallen-kingdom",
		"cave-goblins",
		"guild-dwarves",
		"phoenix-elves",
		"shadow-elves",
		"vanguards"
	]).default("fallen-kingdom"),
	factionB: e.enum([
		"fallen-kingdom",
		"cave-goblins",
		"guild-dwarves",
		"phoenix-elves",
		"shadow-elves",
		"vanguards"
	]).default("vanguards")
}).default({
	factionA: "fallen-kingdom",
	factionB: "vanguards"
}), te = e.object({
	uid: e.string(),
	card: e.string(),
	owner: e.string(),
	slot: e.number().int(),
	damage: e.number().int(),
	boosts: e.number().int(),
	strength: e.number().int(),
	life: e.number().int(),
	maxLife: e.number().int(),
	atk: e.enum(["melee", "ranged"]).nullable(),
	structure: e.boolean(),
	attached: e.array(e.string()),
	canAct: e.boolean()
}), J = e.object({
	phase: e.enum([
		"summon",
		"event",
		"move",
		"attack",
		"magic"
	]),
	turn: e.string(),
	turnNumber: e.number().int(),
	board: e.array(e.string().nullable()),
	units: e.array(te),
	players: e.array(e.object({
		rid: e.string(),
		faction: e.string(),
		magic: e.number().int(),
		handCount: e.number().int(),
		drawCount: e.number().int(),
		discardCount: e.number().int(),
		discardCards: e.array(e.string()),
		summoner: e.string(),
		moved: e.number().int(),
		attacked: e.number().int(),
		active: e.array(e.string())
	})),
	pending: e.object({
		rid: e.string(),
		kind: e.string(),
		prompt: e.string(),
		count: e.number().int()
	}).nullable(),
	winner: e.string().nullable(),
	log: e.array(e.object({
		key: e.string(),
		who: e.string(),
		card: e.string().optional(),
		n: e.number().optional()
	}))
}), ne = e.object({
	hand: e.array(e.string()),
	options: e.array(e.object({
		id: e.string(),
		card: e.string().optional(),
		uid: e.string().optional(),
		n: e.number().optional()
	})),
	moves: e.array(K)
}), re = {
	id: "summonerwars",
	uuid: "2f9c1a44-6d1e-4c7b-9f0a-8a1b6c3d5e21",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"dice-rolling",
		"grid-movement",
		"deck-bag-building"
	],
	interactionTags: [],
	nameKey: "games.summonerwars.name",
	descKey: "games.summonerwars.desc",
	rulesKey: "games.summonerwars.rules",
	icon: "🔮",
	iconImg: "games/summonerwars.webp",
	rulesUrl: { en: "https://www.ultraboardgames.com/summoner-wars/game-rules.php" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#7c5cd6",
	releasedAt: "2026-11-22T22:52:00+08:00",
	search: {
		py: "zhao huan shi zhan zheng",
		init: "zhszz"
	},
	hotseat: "cover"
};
//#endregion
//#region src/game/rules.ts
function ie(e, t, n) {
	e = q.parse(e);
	let r = {
		seed: n,
		cursor: n >>> 0,
		turnNumber: 1,
		board: Array(48).fill(null),
		units: {},
		players: [],
		turn: t[0],
		phase: "move",
		winner: null,
		pending: null,
		log: [],
		seq: 0
	}, i = [e.factionA, e.factionB];
	return t.forEach((e, t) => {
		let n = g[i[t]], a = {
			rid: e,
			faction: n.id,
			magic: 0,
			hand: [],
			draw: [],
			discard: [],
			active: [],
			summoner: "",
			moved: [],
			attacked: [],
			extraAttacks: 0,
			extraMoves: 0
		};
		r.players.push(a);
		for (let i of n.setup) {
			let o = W(r, e, i.key, _(t, i.col, i.row), !1);
			if (!o) throw Error(`summonerwars setup failed: ${n.id} ${i.key} at ${i.col},${i.row}`);
			i.key === n.summoner && (a.summoner = o.uid);
		}
		if (!a.summoner) throw Error(`summonerwars setup failed: ${n.id} has no summoner`);
		let o = v(n);
		for (let e of n.starting) {
			let t = o.indexOf(e);
			t >= 0 && o.splice(t, 1);
		}
		for (let e of b(r, o)) a.draw.push(e);
	}), r.players.length && (r.players[0].extraMoves = -1), le(r), R(r, "setup", t[0]), { state: r };
}
function Y(e) {
	return { code: e };
}
function ae(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = X(e, t, "renewedHope");
	for (let n of ee(e, t)) for (let t of T(n.slot)) e.board[t] || r.add(t);
	for (let n of j(e, t)) {
		if (m[n.card].tags.includes("spawn")) for (let t of T(n.slot)) e.board[t] || r.add(t);
		if (i && n.card === m[g[D(e, t).faction].summoner].key) for (let t of T(n.slot)) e.board[t] || r.add(t);
	}
	let a = n ? m[n] : null;
	if (a?.tags.includes("protector")) {
		let n = M(e, t);
		for (let t of T(n.slot)) e.board[t] || r.add(t);
	}
	if (a?.tags.includes("shadowSummon")) {
		for (let n of j(e, t)) if (!m[n.card].tags.includes("shadowSummon")) for (let t of T(n.slot)) e.board[t] || r.add(t);
	}
	if (a?.token === "Ember") {
		for (let n of j(e, t)) if (m[n.card].tags.includes("fierySummon") || m[n.card].token === "Ember") for (let t of T(n.slot)) e.board[t] || r.add(t);
	}
	return [...r];
}
function X(e, t, n) {
	return D(e, t).active.some((t) => e.units[t] && m[e.units[t].card].tags.includes(n));
}
function oe(e, t) {
	let n = /* @__PURE__ */ new Set(), r = M(e, t);
	for (let t of T(r.slot)) e.board[t] || n.add(t);
	let i = t === e.players[0].rid ? [
		7,
		6,
		5,
		4
	] : [
		0,
		1,
		2,
		3
	];
	for (let t = 0; t < 8; t++) if (i.includes(t)) for (let r = 0; r < 6; r++) e.board[t * 6 + r] || n.add(t * 6 + r);
	for (let r of j(e, t)) {
		if (m[r.card].tags.includes("masterBuilder")) {
			let t = r.slot % 6, i = Math.floor(r.slot / 6);
			for (let [r, a] of [
				[1, 1],
				[1, -1],
				[-1, 1],
				[-1, -1]
			]) {
				let o = t + r, s = i + a;
				if (o >= 0 && o < 6 && s >= 0 && s < 8) {
					let t = s * 6 + o;
					e.board[t] || n.add(t);
				}
			}
		}
		if (m[r.card].tags.includes("compound") && r.boosts > 0) for (let t of T(r.slot)) e.board[t] || n.add(t);
	}
	return [...n];
}
function se(e, t, n) {
	if (t === n) return !1;
	let r = t % 6, i = Math.floor(t / 6), a = n % 6, o = Math.floor(n / 6);
	if (r !== a && i !== o) return !1;
	let s = Math.sign(a - r), c = Math.sign(o - i);
	for (; r !== a || i !== o;) {
		r += s, i += c;
		let t = i * 6 + r;
		if (t !== n && e.board[t]) return !1;
	}
	return !0;
}
function Z(e, t) {
	let n = [], r = e % 6, i = Math.floor(e / 6), a = t % 6, o = Math.floor(t / 6);
	if (r !== a && i !== o) return n;
	let s = Math.sign(a - r), c = Math.sign(o - i);
	for (; (r !== a || i !== o) && (r += s, i += c, r !== a || i !== o);) n.push(i * 6 + r);
	return n;
}
function ce(e, t, n) {
	let r = m[t.card], i = w(t.slot, n.slot);
	if (r.atk === "melee") {
		if (E(t.slot, n.slot)) return !0;
		if (r.tags.includes("leverage")) for (let r of T(t.slot)) {
			let i = e.units[e.board[r] ?? ""];
			if (i && i.owner === t.owner && m[i.card].structure && E(i.slot, n.slot)) return !0;
		}
		return !1;
	}
	if (i > 3) return !1;
	let a = Z(t.slot, n.slot);
	return a.length ? r.tags.includes("fireBreath") || r.tags.includes("piercingLight") && t.entered === e.turnNumber ? !0 : a.every((t) => !e.board[t]) : !1;
}
function le(e) {
	let t = D(e, e.turn);
	for (let n of j(e, t.rid)) if (m[n.card].tags.includes("wildfire")) for (let t of T(n.slot)) {
		let r = e.units[e.board[t] ?? ""];
		r && r.owner !== n.owner && V(e, r.uid, 1, { ability: !0 });
	}
}
function ue(e) {
	let t = D(e, e.turn);
	for (let n of j(e, t.rid)) m[n.card].tags.includes("bloodRunes") && (t.magic >= 1 ? (--t.magic, B(e, n, 1)) : V(e, n.uid, 1, { ability: !0 }));
	for (let n of j(e, t.rid)) (m[n.card].tags.includes("masterPlan") || m[n.card].tags.includes("expand")) && m[n.card].tags.includes("expand") && B(e, n, 1);
}
function de(e) {
	let t = D(e, e.turn);
	for (let n of j(e, t.rid)) {
		let r = m[n.card].tags;
		if (r.includes("inevitableDoom")) {
			let r = M(e, A(e, t.rid).rid), i = M(e, t.rid);
			n.killCount > 0 ? e.board[r.slot] === r.uid && V(e, r.uid, 1, { ability: !0 }) : e.board[i.slot] === i.uid && V(e, i.uid, 1, { ability: !0 });
		}
		if (r.includes("feedEater") && n.killCount === 0) {
			let r = j(e, t.rid).filter((e) => e.uid !== n.uid && E(e.slot, n.slot));
			if (r.length) {
				let n = r[0];
				e.board[n.slot] = null, n.slot = -1, t.discard.push(n.card), R(e, "discarded", t.rid, n.uid);
			} else e.board[n.slot] = null, n.slot = -1, t.discard.push(n.card), R(e, "discarded", t.rid, n.uid);
		}
		if (r.includes("callProtection") && n.flags["attackedEnemy:" + e.turnNumber]) {
			let r = j(e, t.rid).find((t) => t.uid !== n.uid && t.card !== "gate5" && t.card !== "gate10" && T(n.slot).some((t) => !e.board[t]));
			if (r) {
				let i = T(n.slot).find((t) => !e.board[t]);
				i != null && (e.board[r.slot] = null, r.slot = i, e.board[i] = r.uid, R(e, "moved", t.rid, r.uid));
			}
		}
	}
}
function fe(e) {
	for (let t of k(e)) t.moved = !1, t.attacked = !1, t.killCount = 0, t.flags = {};
}
function pe(e) {
	let t = D(e, e.turn);
	for (let n of j(e, t.rid)) m[n.card].tags.includes("magicJunkie") && (t.magic >= 1 ? --t.magic : (e.board[n.slot] = null, n.slot = -1, t.discard.push(n.card), R(e, "discarded", t.rid, n.uid))), m[n.card].tags.includes("bloodFury") && B(e, n, -2);
	let n = e.players.findIndex((e) => e.rid === t.rid), r = e.players[(n + 1) % e.players.length];
	e.turn = r.rid, e.turnNumber += 1, e.phase = "summon", t.moved = [], t.attacked = [], t.extraAttacks = 0, t.extraMoves = 0, r.extraMoves = 0, z(e, r, Math.max(0, 5 - r.hand.length)), fe(e);
	for (let t of [...r.active]) {
		let n = e.units[t];
		if (!n) {
			r.active = r.active.filter((e) => e !== t);
			continue;
		}
		let i = m[n.card].tags;
		if (!(i.includes("blueprints") && n.under.length)) {
			if (i.includes("holyJudgment") && n.boosts > 0) {
				--n.boosts;
				continue;
			}
			if (r.active = r.active.filter((e) => e !== t), r.discard.push(n.card), i.includes("pyre") && n.boosts > 0) {
				let t = j(e, r.rid).sort((e, t) => t.damage - e.damage)[0];
				t && H(e, t.uid, n.boosts);
			}
		}
	}
	for (let t of j(e, r.rid)) m[t.card].tags.includes("guidance") && z(e, r, 2), m[t.card].tags.includes("masterPlan") && z(e, r, 1, !0);
	R(e, "turn", e.turn, void 0, e.turnNumber);
}
function me(e) {
	if (e.phase === "summon") {
		e.phase = "event";
		return;
	}
	if (e.phase === "event") {
		e.phase = "move", le(e);
		return;
	}
	if (e.phase === "move") {
		e.phase = "attack", ue(e);
		return;
	}
	if (e.phase === "attack") {
		de(e), e.winner || (e.phase = "magic");
		return;
	}
	pe(e);
}
function he(e, t, n) {
	if (e.board[n] || !L(e, t)) return !1;
	let r = m[t.card];
	if (r.tags.includes("charge")) return Z(t.slot, n).length > 3 || w(t.slot, n) < 1 || w(t.slot, n) > 4 ? !1 : se(e, t.slot, n);
	if (w(t.slot, n) > I(e, t)) return !1;
	let i = r.tags.includes("climb"), a = /* @__PURE__ */ new Set([t.slot]), o = [t.slot];
	for (let r = 1; r <= I(e, t); r++) {
		let t = [];
		for (let r of o) for (let o of T(r)) {
			if (a.has(o)) continue;
			let r = e.board[o];
			if (o === n) {
				if (!r) return !0;
				continue;
			}
			if (r) {
				let n = e.units[r];
				if (i && m[n.card].structure) {
					a.add(o), t.push(o);
					continue;
				}
				continue;
			}
			a.add(o), t.push(o);
		}
		o = t;
	}
	return !1;
}
function ge(e, t, n) {
	let r = k(e).filter((e) => e.owner !== t.owner);
	for (let i of r) {
		let r = m[i.card].tags, a = r.includes("engage2") ? 2 : +!!r.includes("engage1");
		if (a && E(i.slot, n) && !E(i.slot, t.slot)) {
			let t = e.units[i.owner] ? M(e, i.owner) : null;
			if (t && m[t.card].tags.includes("saveTheQueen") && E(t.slot, i.slot)) continue;
			V(e, i.uid, a, { ability: !0 });
		}
	}
}
function _e(e, t, n) {
	let r = t.slot, i = j(e, t.owner).filter((e) => e.uid !== t.uid && m[e.card].tags.includes("cling") && E(e.slot, r));
	e.board[r] = null, e.board[n] = t.uid, t.slot = n, t.moved = !0, R(e, "moved", t.owner, t.uid);
	for (let n of i) {
		let r = T(t.slot).find((t) => !e.board[t]);
		r != null && (e.board[n.slot] = null, n.slot = r, e.board[r] = n.uid, R(e, "moved", n.owner, n.uid));
	}
	ge(e, t, r);
	let a = m[t.card].tags;
	if (a.includes("charge") && w(r, n) >= 3 && (t.flags.chargeBonus = 1), a.includes("quickShot")) {
		let n = k(e).filter((e) => e.owner !== t.owner).filter((n) => w(n.slot, t.slot) > 3 ? !1 : Z(t.slot, n.slot).length > 0 && Z(t.slot, n.slot).every((t) => !e.board[t])).sort((t, n) => F(e, t) - F(e, n))[0];
		n && V(e, n.uid, 1, { ability: !0 });
	}
	if (a.includes("recalibrate")) {
		let n = j(e, t.owner).find((e) => m[e.card].structure && E(e.slot, t.slot));
		if (n) {
			let t = T(n.slot).find((t) => !e.board[t]);
			t != null && (e.board[n.slot] = null, n.slot = t, e.board[t] = n.uid);
		}
	}
	if (a.includes("judgment") && t.boosts > 0) {
		let n = j(e, t.owner === D(e, t.owner).rid ? A(e, t.owner).rid : "").filter((e) => E(e.slot, t.slot) && (m[e.card].type === "common" || m[e.card].type === "champion"))[0];
		if (n) {
			let r = t.boosts;
			t.boosts = 0, V(e, n.uid, r, { ability: !0 });
		}
	}
	if (a.includes("rendTheVeil") && !t.flags.rend) {
		let n = k(e).find((e) => e.owner !== t.owner && m[e.card].tags.includes("gate") && e.damage > 0 && E(e.slot, t.slot));
		if (n) {
			let r = D(e, t.owner).hand.find((e) => m[e].type === "common"), i = T(n.slot).find((t) => !e.board[t]);
			r && i != null && (D(e, t.owner).hand.splice(D(e, t.owner).hand.indexOf(r), 1), W(e, t.owner, r, i, !1), t.flags.rend = 1);
		}
	}
	if (a.includes("forbiddenKnowledge") && !t.flags.fk) {
		let n = j(e, t.owner).find((e) => m[e.card].tags.includes("gate") && E(e.slot, t.slot));
		n && (V(e, n.uid, 1, { ability: !0 }), z(e, D(e, t.owner), 1), t.flags.fk = 1);
	}
	if (a.includes("redeploy")) {
		let n = j(e, t.owner).find((e) => m[e.card].structure && (m[e.card].life ?? 0) <= 5 && E(e.slot, t.slot));
		n && (e.board[n.slot] = null, n.slot = -1, D(e, t.owner).draw.unshift(n.card), R(e, "redeploy", t.owner, n.uid));
	}
}
function ve(e, t, n) {
	let r = e.units[n];
	if (!r) return !1;
	let i = T(t.slot).filter((n) => !e.board[n] && w(n, r.slot) > w(t.slot, r.slot));
	return i.length ? (e.board[t.slot] = null, t.slot = i[0], e.board[i[0]] = t.uid, !0) : !1;
}
function ye(e, t, n) {
	let r = D(e, t.owner), i = e.units[n];
	if (!i || e.board[i.slot] !== n) return Y("errBadTarget");
	if (i.owner === t.owner) {
		if (!m[t.card].tags.includes("heal")) return Y("errBadTarget");
	} else if (!ce(e, t, i)) return Y("errNoLine");
	if (i.owner !== t.owner && j(e, i.owner).find((e) => m[e.card].tags.includes("protect") && E(e.slot, t.slot)) && !m[i.card].tags.includes("protect")) return Y("errProtect");
	let a = m[t.card], o = P(e, t);
	if (i.owner !== t.owner && m[i.card].token === "Citadel" && j(e, i.owner).find((t) => m[t.card].tags.includes("divineShield") && e.board[t.slot] === t.uid && w(t.slot, i.slot) <= 3)) {
		let t = x(e, 2);
		o = Math.max(1, o - t.faces.filter((e) => e === "melee").length);
	}
	t.flags.chargeBonus && (o += 1), X(e, t.owner, "pileOn") && (o += j(e, t.owner).filter((e) => e.uid !== t.uid && E(e.slot, i.slot)).length), t.flags.arrowBonus && (o += t.flags.arrowBonus), r.magic >= 0 && r.flags, t.flags.bowCaptain && (o += 1);
	let s = j(e, t.owner).find((e) => m[e.card].tags.includes("supplyCache") && e.boosts > 0 && E(e.slot, t.slot));
	s && (B(e, s, -1), z(e, r, 1), o += 1);
	let c = x(e, Math.max(0, o)), l = t.flags.lifeDrain ? "melee" : a.atk, u = c.faces.filter((e) => e === l).length;
	if (a.tags.includes("heal") && i.owner === t.owner) {
		if (r.hand.length) {
			r.hand.pop();
			let i = c.faces.filter((e) => e !== "special").length;
			H(e, n, i), R(e, "heal", t.owner, n, i);
		}
	} else V(e, n, u, {
		attacker: t.uid,
		attackRoll: c,
		ignoreGuarded: !1
	});
	if (R(e, "attack", t.owner, t.uid, u), t.attacked = !0, t.attackedOnce = !0, i.owner !== t.owner && (t.flags["attackedEnemy:" + e.turnNumber] = 1), a.tags.includes("fireBreath") && c.specials > 0) for (let n of Z(t.slot, i.slot)) {
		let r = e.units[e.board[n] ?? ""];
		r && V(e, r.uid, c.specials, {
			ability: !0,
			attacker: t.uid
		});
	}
	if (t.under.includes("hellforged_weapon") && c.specials > 0 && V(e, t.uid, c.specials, { ability: !0 }), a.tags.includes("intercession")) {
		let t = c.faces.filter((e) => e === "melee").length;
		t > 0 && z(e, r, t);
	}
	if (a.tags.includes("forcefulShot") && i.owner !== t.owner && (m[i.card].type === "common" || m[i.card].type === "champion") && e.board[i.slot] === i.uid && ve(e, i, t.uid), a.tags.includes("shove") && i.owner !== t.owner && E(t.slot, i.slot) && e.board[i.slot] === i.uid && ve(e, i, t.uid), a.tags.includes("citadelsMight") && i.owner !== t.owner && j(e, t.owner).filter((t) => m[t.card].token === "Citadel" && e.board[t.slot] === t.uid).length) {
		let e = r.discard.find((e) => m[e].token === "Citadel");
		e && (r.discard.splice(r.discard.indexOf(e), 1), r.hand.push(e));
	}
	if (a.tags.includes("bowCaptain") && i.owner !== t.owner && (r.flags = {
		...r.flags ?? {},
		bowCaptain: 1
	}), a.tags.includes("feint") && e.board[t.slot] === t.uid) {
		let n = T(t.slot).find((t) => !e.board[t]);
		n != null && (e.board[t.slot] = null, t.slot = n, e.board[n] = t.uid);
	}
	return null;
}
function be(e, t, n) {
	let r = structuredClone(e);
	if (t.type === "tick") return { state: e };
	if (r.winner) return Y("errOver");
	if (r.pending) {
		if (t.type !== "choose" || t.id == null) return Y("errPending");
		let e = r.pending;
		if (e.rid !== n.by) return Y("errNotYou");
		let i = e.options.find((e) => e.id === t.id);
		if (!i) return Y("errBadChoice");
		if (r.pending = null, e.kind === "pyreTarget") {
			let e = i.uid ? r.units[i.uid] : null;
			e && i.n && H(r, e.uid, i.n);
		}
		return { state: r };
	}
	if (r.turn !== n.by) return Y("errNotYourTurn");
	let i = D(r, n.by);
	if (t.type === "event") return xe(r, i, t) || { state: r };
	if (t.type === "ability") return Se(r, i, t) || { state: r };
	switch (t.type) {
		case "next": return r.phase === "magic" ? (pe(r), { state: r }) : (me(r), { state: r });
		case "discard":
			if (r.phase !== "magic") return Y("errPhase");
			for (let e of t.cards) {
				let t = i.hand.indexOf(e);
				if (t < 0) return Y("errBadCard");
				i.hand.splice(t, 1), i.discard.push(e), i.magic += 1;
			}
			return R(r, "magic", i.rid, void 0, t.cards.length), { state: r };
		case "summon": {
			if (r.phase !== "summon" && !X(r, i.rid, "renewedHope")) return Y("errPhase");
			let e = i.hand.indexOf(t.card);
			if (e < 0) return Y("errBadCard");
			let n = m[t.card];
			if (!n || n.type !== "common" && n.type !== "champion") return Y("errBadCard");
			if (i.magic < n.cost) return Y("errNoMagic");
			if (!ae(r, i.rid, t.card).includes(t.slot)) return Y("errBadSlot");
			if (n.tags.includes("summonedByFire")) {
				let n = j(r, i.rid).find((e) => e.uid !== i.summoner && w(e.slot, t.slot) <= 3);
				if (!n) return Y("errNeedVictim");
				i.hand.splice(e, 1), r.board[n.slot] = null, n.slot = -1, i.discard.push(n.card);
				let a = W(r, i.rid, t.card, t.slot, !0);
				if (a) {
					if (m[a.card].tags.includes("rush")) {
						let e = T(a.slot).find((e) => !r.board[e]);
						e != null && (r.board[a.slot] = null, a.slot = e, r.board[e] = a.uid);
					}
					if (m[a.card].tags.includes("launch")) {
						let e = k(r).filter((e) => e.owner !== a.owner && m[e.card].type !== "summoner" && w(e.slot, a.slot) <= 3).sort((e, t) => F(r, e) - F(r, t))[0];
						e && V(r, e.uid, 1, { ability: !0 });
					}
					if (m[a.card].tags.includes("design")) {
						let e = [...i.draw, ...i.discard].find((e) => m[e].structure);
						if (e) {
							let t = i.draw.indexOf(e);
							t >= 0 ? i.draw.splice(t, 1) : i.discard.splice(i.discard.indexOf(e), 1), i.hand.push(e);
						}
					}
				}
				return { state: r };
			}
			i.hand.splice(e, 1);
			let a = j(r, i.rid).some((e) => m[e.card].tags.includes("spawn") && E(e.slot, t.slot)), o = W(r, i.rid, t.card, t.slot, !0);
			if (!o) return Y("errBadSlot");
			if (a) {
				let e = j(r, i.rid).find((e) => m[e.card].tags.includes("spawn") && E(e.slot, t.slot));
				e && V(r, e.uid, 1, { ability: !1 });
			}
			let s = m[o.card].tags;
			if (s.includes("shadowSummon")) {
				let e = j(r, i.rid).filter((e) => e.uid !== o.uid && !m[e.card].tags.includes("shadowSummon") && E(e.slot, o.slot)).sort((e, t) => F(r, t) - F(r, e))[0];
				e && V(r, e.uid, 1, { ability: !0 });
			}
			if (s.includes("rush")) {
				let e = T(o.slot).find((e) => !r.board[e]);
				e != null && (r.board[o.slot] = null, o.slot = e, r.board[e] = o.uid);
			}
			if (s.includes("launch")) {
				let e = k(r).filter((e) => e.owner !== o.owner && m[e.card].type !== "summoner" && w(e.slot, o.slot) <= 3).sort((e, t) => F(r, e) - F(r, t))[0];
				e && V(r, e.uid, 1, { ability: !0 });
			}
			if (s.includes("design")) {
				let e = [...i.draw, ...i.discard].find((e) => m[e].structure);
				if (e) {
					let t = i.draw.indexOf(e);
					t >= 0 ? i.draw.splice(t, 1) : i.discard.splice(i.discard.indexOf(e), 1), i.hand.push(e);
				}
			}
			return { state: r };
		}
		case "build": {
			if (r.phase !== "event" && !X(r, i.rid, "renewedHope")) return Y("errPhase");
			let e = i.hand.indexOf(t.card);
			if (e < 0) return Y("errBadCard");
			let n = m[t.card];
			if (!n.structure) return Y("errBadCard");
			if (i.magic < n.cost) return Y("errNoMagic");
			if (!oe(r, i.rid).includes(t.slot)) return Y("errBadSlot");
			i.hand.splice(e, 1), i.magic -= n.cost;
			let a = W(r, i.rid, t.card, t.slot, !1);
			return a ? (R(r, "built", i.rid, t.card), n.tags.includes("supplyCache") && (a.boosts = 2), { state: r }) : Y("errBadSlot");
		}
		case "move": {
			if (r.phase !== "move") return Y("errPhase");
			let e = r.units[t.uid];
			return !e || e.owner !== i.rid || r.board[e.slot] !== e.uid ? Y("errBadUnit") : i.moved.includes(e.uid) ? Y("errMoved") : i.moved.length >= 3 + i.extraMoves ? Y("errMoveLimit") : he(r, e, t.to) ? (_e(r, e, t.to), i.moved.push(e.uid), { state: r }) : Y("errBadSlot");
		}
		case "attack": {
			if (r.phase !== "attack") return Y("errPhase");
			let e = r.units[t.uid];
			if (!e || e.owner !== i.rid || r.board[e.slot] !== e.uid) return Y("errBadUnit");
			let n = m[e.card].tags.includes("relentless");
			return i.attacked.includes(e.uid) ? Y("errAttacked") : !n && i.attacked.filter((e) => !m[r.units[e]?.card]?.tags.includes("relentless")).length >= 3 || i.attacked.length >= 3 + i.extraAttacks + 2 ? Y("errAttackLimit") : ye(r, e, t.target) || (i.attacked.push(e.uid), { state: r });
		}
		default: return Y("errUnknown");
	}
}
function xe(e, t, n) {
	let r = t.hand.indexOf(n.card);
	if (r < 0) return Y("errBadCard");
	let i = m[n.card];
	if (i.type !== "event") return Y("errBadCard");
	if (i.phase !== "any" && i.phase !== e.phase && e.phase !== "event") return Y("errPhase");
	if (t.magic < i.cost) return Y("errNoMagic");
	if (i.active && t.active.some((t) => e.units[t] && e.units[t].card === n.card)) return Y("errActive");
	t.hand.splice(r, 1), t.magic -= i.cost, R(e, "event", t.rid, n.card);
	let a = i.tags;
	if (i.active) {
		let r = G(e, t.rid, n.card);
		if (a.includes("blueprints") && r) for (let e of n.picks.slice(0, 2)) m[e]?.structure && t.hand.includes(e) && (t.hand.splice(t.hand.indexOf(e), 1), r.under.push(e));
		return null;
	}
	if (a.includes("purge")) {
		for (let r of n.targets) {
			let n = e.units[r];
			if (!n || n.owner !== t.rid || e.board[n.slot] !== r) continue;
			let i = k(e).filter((e) => e.uid !== r && E(e.slot, n.slot)).sort((e, n) => Number(e.owner === t.rid) - Number(n.owner === t.rid))[0];
			i && V(e, i.uid, 2, { ability: !0 }), e.board[n.slot] === r && U(e, r);
		}
		return t.discard.push(n.card), null;
	}
	if (a.includes("bloodSummon")) {
		for (let r = 0; r < n.picks.length; r++) {
			let i = e.units[n.targets[r] ?? n.targets[0] ?? ""], a = n.picks[r];
			if (!i || !a || !t.hand.includes(a)) continue;
			let o = m[a];
			if (o.token !== "Undead" && o.token !== "Cultist" || o.type !== "common") continue;
			let s = T(i.slot).find((t) => !e.board[t]);
			s != null && (t.hand.splice(t.hand.indexOf(a), 1), W(e, t.rid, a, s, !1), e.board[i.slot] === i.uid && V(e, i.uid, 2, { ability: !1 }));
		}
		return t.discard.push(n.card), null;
	}
	if (a.includes("hellforged")) {
		let r = e.units[n.targets[0] ?? ""];
		return r && r.owner === t.rid && m[r.card].type === "common" ? r.under.push(n.card) : t.discard.push(n.card), null;
	}
	if (a.includes("enrage")) {
		let r = j(e, t.rid).filter((e) => m[e.card].cost === 0).length;
		return t.extraAttacks += r, t.discard.push(n.card), null;
	}
	if (a.includes("sneak")) {
		let r = M(e, A(e, t.rid).rid);
		for (let i of n.targets) {
			let n = e.units[i];
			if (!n || n.owner !== t.rid || m[n.card].cost !== 0) continue;
			let a = T(n.slot).filter((t) => !e.board[t]).sort((e, t) => w(e, r.slot) - w(t, r.slot));
			a.length && (e.board[n.slot] = null, n.slot = a[0], e.board[a[0]] = n.uid);
		}
		return t.discard.push(n.card), null;
	}
	if (a.includes("burn")) {
		let r = e.units[n.targets[0] ?? ""], i = M(e, t.rid);
		return r && r.owner !== t.rid && (m[r.card].type === "common" || m[r.card].type === "champion") && w(r.slot, i.slot) <= 2 && V(e, r.uid, 2, { ability: !0 }), t.discard.push(n.card), null;
	}
	if (a.includes("massHeal")) {
		let r = M(e, t.rid);
		for (let n of j(e, t.rid)) (m[n.card].type === "common" || m[n.card].type === "champion") && w(n.slot, r.slot) <= 2 && H(e, n.uid, 2);
		return t.discard.push(n.card), null;
	}
	if (a.includes("intoDarkness")) {
		let r = e.units[n.targets[0] ?? ""], i = M(e, t.rid);
		return r && r.owner !== t.rid && F(e, r) <= 5 && F(e, r) > 0 && w(r.slot, i.slot) <= 3 && (e.board[r.slot] = null, r.slot = -1, O(e, r.uid).hand.push(r.card)), t.discard.push(n.card), null;
	}
	if (a.includes("onyxTome")) {
		let r = n.targets.map((t) => e.units[t]).find((e) => e && t.discard.includes(e.card));
		r && (t.discard.splice(t.discard.indexOf(r.card), 1), t.hand.push(r.card));
		for (let n = 0; n < 2; n++) {
			let n = j(e, t.rid).sort((e, t) => t.damage - e.damage)[0];
			n && V(e, n.uid, 1, { ability: !0 });
		}
		return t.discard.push(n.card), null;
	}
	if (a.includes("shadowPulse")) {
		let r = k(e).filter((e) => m[e.card].tags.includes("gate") && e.damage > 0);
		for (let t of k(e)) r.some((e) => E(e.slot, t.slot)) && V(e, t.uid, 1, { ability: !0 });
		return t.discard.push(n.card), null;
	}
	return a.includes("baldarsGate") ? (W(e, t.rid, n.card, n.targets.length ? Number(n.targets[0]) : -1, !1) || t.discard.push(n.card), null) : (t.discard.push(n.card), null);
}
function Se(e, t, n) {
	let r = e.units[n.uid];
	if (!r || r.owner !== t.rid || e.board[r.slot] !== r.uid) return Y("errBadUnit");
	let i = m[r.card].tags;
	if (i.includes("raiseDead")) {
		if (r.flags.raised) return Y("errUsed");
		let i = n.target ?? "";
		if (!t.discard.includes(i) || m[i].token !== "Undead" || m[i].type !== "common") return Y("errBadTarget");
		let a = T(r.slot).find((t) => !e.board[t]);
		return a == null ? Y("errBadSlot") : (t.discard.splice(t.discard.indexOf(i), 1), V(e, r.uid, 2, { ability: !0 }), W(e, t.rid, i, a, !1), r.flags.raised = 1, null);
	}
	if (i.includes("sly")) {
		if (r.flags.sly) return Y("errUsed");
		let i = e.units[n.target ?? ""];
		if (!i || i.owner !== t.rid || m[i.card].cost !== 0 || e.board[i.slot] !== i.uid) return Y("errBadTarget");
		let a = r.slot, o = i.slot;
		return e.board[a] = i.uid, e.board[o] = r.uid, r.slot = o, i.slot = a, r.flags.sly = 1, R(e, "sly", t.rid, r.uid), null;
	}
	if (i.includes("returnToShadow")) {
		if (r.boosts < 2 || !n.target) return Y("errBadTarget");
		let i = e.units[n.target];
		return !i || i.owner !== t.rid || e.board[i.slot] !== i.uid || i.uid === r.uid ? Y("errBadTarget") : w(i.slot, r.slot) > 3 ? Y("errRange") : (r.boosts -= 2, e.board[i.slot] = null, i.slot = -1, t.hand.push(i.card), null);
	}
	if (i.includes("lifeDrain")) {
		if (r.flags.drain) return Y("errUsed");
		let i = e.units[n.target ?? ""];
		return !i || i.owner !== t.rid || i.uid === r.uid || w(i.slot, r.slot) > 2 ? Y("errBadTarget") : (U(e, i.uid), r.flags.lifeDrain = 1, r.flags.drain = 1, null);
	}
	if (i.includes("judgment")) {
		let i = e.units[n.target ?? ""];
		if (!i || i.owner === t.rid || !E(r.slot, i.slot) || m[i.card].type !== "common" && m[i.card].type !== "champion") return Y("errBadTarget");
		let a = Math.min(n.value ?? r.boosts, r.boosts);
		return a <= 0 ? Y("errBadTarget") : (r.boosts -= a, V(e, i.uid, a, { ability: !0 }), null);
	}
	if (i.includes("batteringRam")) {
		if (e.phase !== "attack") return Y("errPhase");
		if (r.flags.rammed) return Y("errUsed");
		let i = e.units[n.target ?? ""];
		return !i || i.owner === t.rid || e.board[i.slot] !== i.uid || !E(r.slot, i.slot) ? Y("errBadTarget") : (r.flags.rammed = 1, ve(e, i, r.uid) && V(e, i.uid, 2, { ability: !0 }), R(e, "attack", t.rid, r.uid, 2), null);
	}
	if (i.includes("arrowOfLight")) {
		if (e.phase !== "attack") return Y("errPhase");
		if (r.attacked || r.attackedOnce) return Y("errUsed");
		let i = n.target ?? "", a = t.hand.indexOf(i);
		if (a < 0) return Y("errBadCard");
		let o = m[i];
		return !o || o.type !== "common" && o.type !== "champion" ? Y("errBadCard") : r.flags["aol:" + i] ? Y("errUsed") : (t.hand.splice(a, 1), t.discard.push(i), t.magic += 1, r.flags.arrowBonus = (r.flags.arrowBonus ?? 0) + 1, r.flags["aol:" + i] = 1, R(e, "magic", t.rid, i, 1), null);
	}
	return Y("errUnknown");
}
function Ce(e, t) {
	let n = m[t.card];
	return {
		uid: t.uid,
		card: t.card,
		owner: t.owner,
		slot: t.slot,
		damage: t.damage,
		boosts: t.boosts,
		strength: Math.max(0, P(e, t)),
		life: F(e, t),
		maxLife: n.life ?? 0,
		atk: n.atk ?? null,
		structure: !!n.structure,
		attached: t.under,
		canAct: e.turn === t.owner && !e.winner
	};
}
function we(e, t) {
	let n = e, r = D(n, t);
	return {
		public: {
			phase: n.phase,
			turn: n.turn,
			turnNumber: n.turnNumber,
			board: n.board,
			units: k(n).map((e) => Ce(n, e)),
			players: n.players.map((e) => ({
				rid: e.rid,
				faction: e.faction,
				magic: e.magic,
				handCount: e.hand.length,
				drawCount: e.draw.length,
				discardCount: e.discard.length,
				discardCards: e.discard,
				summoner: e.summoner,
				moved: e.moved.length,
				attacked: e.attacked.length,
				active: e.active.map((e) => n.units[e]?.card ?? e)
			})),
			pending: n.pending ? {
				rid: n.pending.rid,
				kind: n.pending.kind,
				prompt: n.pending.prompt,
				count: n.pending.options.length
			} : null,
			winner: n.winner,
			log: n.log.slice(-30)
		},
		private: {
			hand: r.hand,
			options: n.pending && n.pending.rid === t ? n.pending.options : [],
			moves: n.pending ? n.pending.rid === t ? n.pending.options.map((e) => ({
				type: "choose",
				id: e.id
			})) : [] : Te(n, t)
		}
	};
}
function Te(e, t) {
	let n = D(e, t), r = [];
	if (e.turn !== t || e.winner) return r;
	if (e.pending) return e.pending.rid === t ? e.pending.options.map((e) => ({
		type: "choose",
		id: e.id
	})) : [];
	if (e.phase === "magic") {
		if (r.push({ type: "next" }), n.hand.length) {
			let e = [...n.hand].sort((e, t) => m[e].cost - m[t].cost)[0];
			r.push({
				type: "discard",
				cards: [e]
			});
		}
		return r;
	}
	if (r.push({ type: "next" }), e.phase === "summon" || X(e, t, "renewedHope")) for (let i of n.hand) {
		let a = m[i];
		if ((a.type === "common" || a.type === "champion") && n.magic >= a.cost) for (let n of ae(e, t, i).slice(0, 4)) r.push({
			type: "summon",
			card: i,
			slot: n
		});
	}
	if (e.phase === "event") for (let i of n.hand) {
		let a = m[i];
		if (a.structure && n.magic >= a.cost) for (let n of oe(e, t).slice(0, 6)) r.push({
			type: "build",
			card: i,
			slot: n
		});
	}
	if (e.phase === "move" && n.moved.length < 3 + n.extraMoves) {
		for (let i of j(e, t)) if (!n.moved.includes(i.uid) && L(e, i)) for (let t = 0; t < e.board.length; t++) he(e, i, t) && r.push({
			type: "move",
			uid: i.uid,
			to: t
		});
	}
	if (e.phase === "attack") for (let i of j(e, t)) {
		let a = m[i.card].tags.includes("relentless");
		if (!n.attacked.includes(i.uid) && !(!a && n.attacked.filter((t) => !m[e.units[t]?.card]?.tags.includes("relentless")).length >= 3) && !(P(e, i) <= 0 && !m[i.card].tags.includes("heal"))) for (let n of k(e)) (n.owner !== t || m[i.card].tags.includes("heal")) && ce(e, i, n) && (n.owner === t || !j(e, n.owner).find((e) => m[e.card].tags.includes("protect") && E(e.slot, i.slot)) || m[n.card].tags.includes("protect")) && r.push({
			type: "attack",
			uid: i.uid,
			target: n.uid
		});
	}
	for (let t of n.hand) {
		let i = m[t];
		i.type === "event" && (i.phase === "any" || i.phase === e.phase || e.phase === "event") && (n.magic < i.cost || i.active && n.active.some((n) => e.units[n]?.card === t) || r.push({
			type: "event",
			card: t,
			targets: [],
			picks: []
		}));
	}
	return r;
}
var Ee = {
	meta: re,
	schemas: {
		action: K,
		publicView: J,
		privateView: ne
	},
	setup(e, t) {
		return ie(e, t, 1);
	},
	reduce: be,
	viewFor: we,
	status(e) {
		let t = e;
		return t.winner ? {
			phase: "done",
			winner: [t.winner],
			ranking: [t.winner, t.players.find((e) => e.rid !== t.winner).rid]
		} : { phase: t.phase };
	}
};
//#endregion
//#region src/game/art.ts
function De(e) {
	if (e === "gate5" || e === "gate10") return null;
	let t = m[e];
	return t ? `games/summonerwars/cards/${t.faction}/${e}.webp` : null;
}
function Oe(e) {
	return h.find((t) => t.id === m[e].faction)?.accent ?? "#7c5cd6";
}
function ke(e) {
	return h.find((t) => t.id === e)?.accent ?? "#b9892f";
}
//#endregion
//#region src/game/view-player.tsx
var Ae = 6, je = {
	summon: "games.summonerwars.summonPhase",
	event: "games.summonerwars.eventPhase",
	move: "games.summonerwars.movePhase",
	attack: "games.summonerwars.attackPhase",
	magic: "games.summonerwars.magicPhase"
}, Me = [
	"summon",
	"event",
	"move",
	"attack",
	"magic"
], Ne = {
	setup: "games.summonerwars.logSetup",
	summoned: "games.summonerwars.logSummoned",
	built: "games.summonerwars.logBuilt",
	moved: "games.summonerwars.logMoved",
	attack: "games.summonerwars.logAttack",
	destroyed: "games.summonerwars.logDestroyed",
	damage: "games.summonerwars.logDamage",
	heal: "games.summonerwars.logHeal",
	event: "games.summonerwars.logEventLog",
	magic: "games.summonerwars.logMagic",
	discarded: "games.summonerwars.logDiscarded",
	turn: "games.summonerwars.logTurn",
	sly: "games.summonerwars.logSly",
	redeploy: "games.summonerwars.logRedeploy"
};
function Pe(e, t) {
	return Math.abs(e % Ae - t % Ae) + Math.abs(Math.floor(e / Ae) - Math.floor(t / Ae));
}
function Fe(e) {
	return e.structure ? "games.summonerwars.structure" : e.type === "summoner" ? "games.summonerwars.summonerType" : e.type === "champion" ? "games.summonerwars.championType" : e.type === "event" ? "games.summonerwars.eventType" : "games.summonerwars.commonType";
}
function Ie(e) {
	if (e.type === "event") return "";
	let t = e.text.zh.split(/[：:]/)[0]?.trim() ?? "";
	return t && t.length <= 8 ? t : "";
}
function Le(e) {
	o();
	let t = e.public, n = e.private;
	return n ? /* @__PURE__ */ f(Re, {
		...e,
		pub: t,
		priv: n
	}, e.myRid) : null;
}
function Re({ pub: e, priv: o, members: h, myRid: _, send: v }) {
	let y = i(), b = r((e) => e.locale), [x, S] = t(null), [C, w] = t(null), [T, E] = t(!1), [D, O] = t(!1), [k, A] = t(!1), [j, ee] = t(`${e.turnNumber}:${e.phase}:${e.turn}:${e.winner ?? ""}`), M = `${e.turnNumber}:${e.phase}:${e.turn}:${e.winner ?? ""}`;
	j !== M && (ee(M), S(null), T && E(!1), D && O(!1), k && A(!1));
	let N = (t) => e.units.find((e) => e.uid === t), P = (e) => {
		let t = h.find((t) => t.rid === e);
		return t ? u(t, b) : e;
	}, F = (e) => {
		let t = e.split("#")[0];
		return m[t]?.name ?? t;
	}, I = e.turn === _ && !e.winner, L = e.players.find((e) => e.rid === _), R = e.players.find((e) => e.rid !== _), z = L ? N(L.summoner)?.card ?? null : null, B = R ? N(R.summoner)?.card ?? null : null, V = o.moves, H = e.pending?.rid === _, U = x?.kind === "unit" ? N(x.uid) : void 0, W = x?.kind === "event" || x?.kind === "eventSlot" ? x.card : null, G = /* @__PURE__ */ new Set(), K = /* @__PURE__ */ new Set(), q = /* @__PURE__ */ new Set(), te = /* @__PURE__ */ new Set(), J = /* @__PURE__ */ new Set();
	if (U) for (let e of V) e.type === "move" && e.uid === U.uid && G.add(e.to), e.type === "attack" && e.uid === U.uid && K.add(e.target);
	if (x?.kind === "hand") for (let e of V) (e.type === "summon" || e.type === "build") && e.card === x.card && q.add(e.slot);
	if (W) {
		let t = m[W].tags;
		if (t.includes("baldarsGate")) for (let t = 0; t < 48; t++) e.board[t] || te.add(t);
		else if (t.includes("purge") || t.includes("bloodSummon") || t.includes("hellforged") || t.includes("onyxTome")) for (let t of e.units) t.owner === _ && t.slot >= 0 && J.add(t.uid);
		else if (t.includes("burn") || t.includes("intoDarkness")) for (let t of e.units) t.owner !== _ && t.slot >= 0 && J.add(t.uid);
	}
	let ne = (e, t) => {
		let n = (o.hand ?? []).filter((t) => t !== e && (m[t]?.token === "Undead" || m[t]?.token === "Cultist") && m[t]?.type === "common");
		v({
			type: "event",
			card: e,
			targets: t,
			picks: t.length ? n.slice(0, t.length) : []
		}), S(null);
	}, re = (t) => {
		let n = m[t.card].tags;
		if (n.includes("raiseDead")) {
			let e = L?.discardCards.find((e) => m[e]?.token === "Undead" && m[e]?.type === "common");
			return e ? {
				type: "ability",
				uid: t.uid,
				target: e
			} : null;
		}
		if (n.includes("lifeDrain")) {
			let n = e.units.find((e) => e.owner === _ && e.uid !== t.uid && e.slot >= 0 && Pe(e.slot, t.slot) <= 2);
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n.uid
			} : null;
		}
		if (n.includes("sly")) {
			let n = e.units.find((e) => e.owner === _ && e.uid !== t.uid && e.slot >= 0 && m[e.card].cost === 0);
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n.uid
			} : null;
		}
		if (n.includes("returnToShadow")) {
			let n = t.boosts >= 2 ? e.units.find((e) => e.owner === _ && e.uid !== t.uid && e.slot >= 0 && Pe(e.slot, t.slot) <= 3) : void 0;
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n.uid
			} : null;
		}
		if (n.includes("batteringRam")) {
			let n = e.phase === "attack" ? e.units.find((e) => e.owner !== _ && e.slot >= 0 && Pe(e.slot, t.slot) === 1) : void 0;
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n.uid
			} : null;
		}
		if (n.includes("arrowOfLight")) {
			let n = e.phase === "attack" ? o.hand.find((e) => m[e]?.type === "common" || m[e]?.type === "champion") : void 0;
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n
			} : null;
		}
		if (n.includes("judgment")) {
			let n = t.boosts > 0 ? e.units.find((e) => e.owner !== _ && e.slot >= 0 && Pe(e.slot, t.slot) === 1 && !m[e.card].structure) : void 0;
			return n ? {
				type: "ability",
				uid: t.uid,
				target: n.uid,
				value: t.boosts
			} : null;
		}
		return null;
	}, ie = (t) => {
		if (e.winner || e.pending) return;
		let n = e.units.find((e) => e.slot === t);
		if (x?.kind === "event") {
			n && J.has(n.uid) && ne(x.card, [n.uid]);
			return;
		}
		if (x?.kind === "eventSlot") {
			n || (v({
				type: "event",
				card: x.card,
				targets: [String(t)]
			}), S(null));
			return;
		}
		if (x?.kind === "hand") {
			let e = m[x.card];
			q.has(t) && v({
				type: e.structure ? "build" : "summon",
				card: x.card,
				slot: t
			});
			return;
		}
		if (x?.kind === "unit") {
			if (G.has(t)) {
				v({
					type: "move",
					uid: x.uid,
					to: t
				}), S(null);
				return;
			}
			if (n && K.has(n.uid)) {
				v({
					type: "attack",
					uid: x.uid,
					target: n.uid
				}), S(null);
				return;
			}
			if (n && n.owner === _) {
				S({
					kind: "unit",
					uid: n.uid
				});
				return;
			}
			S(null);
			return;
		}
		n && n.owner === _ && I && S({
			kind: "unit",
			uid: n.uid
		});
	}, Y = (t) => {
		if (!I) {
			w(t);
			return;
		}
		let n = m[t];
		if (e.phase === "magic") {
			v({
				type: "discard",
				cards: [t]
			});
			return;
		}
		if (n.type === "event") {
			if (!V.some((e) => e.type === "event" && e.card === t)) return;
			let e = n.tags;
			[
				"purge",
				"bloodSummon",
				"hellforged",
				"burn",
				"intoDarkness"
			].some((t) => e.includes(t)) ? S({
				kind: "event",
				card: t
			}) : e.includes("baldarsGate") ? S({
				kind: "eventSlot",
				card: t
			}) : ne(t, []);
			return;
		}
		V.some((e) => (e.type === "summon" || e.type === "build") && e.card === t) ? S({
			kind: "hand",
			card: t
		}) : w(t);
	}, ae = e.winner ? y("games.summonerwars.winnerLine", { name: P(e.winner) }) : I ? y(je[e.phase]) : y("games.summonerwars.waiting", { name: P(e.turn) }), X = H ? y("games.summonerwars.chooseOption") : x?.kind === "event" || x?.kind === "eventSlot" ? y("games.summonerwars.selectEventTarget") : x?.kind === "unit" ? K.size ? y("games.summonerwars.selectTarget") : G.size ? y("games.summonerwars.selectSlot") : "" : x?.kind === "hand" ? y("games.summonerwars.selectSlot") : I ? y("games.summonerwars.pickUnitFirst") : "", oe = U && I ? re(U) : null, se = U ? U.card : x && x.kind !== "unit" ? x.card : null, Z = (L?.active.length ?? 0) + (e.players.find((e) => e.rid !== _)?.active.length ?? 0), ce = (e) => {
		let t = [P(e.who)], n = Ne[e.key];
		return n && t.push(y(n)), e.card && t.push(F(e.card)), e.n && t.push(String(e.n)), t.join(" · ");
	};
	return /* @__PURE__ */ p("div", {
		className: "sw-root",
		children: [
			/* @__PURE__ */ f(s, {
				className: "sw-screen",
				scroll: !1,
				actionsHeight: "sw-actions-height",
				banner: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
					className: "sw-command",
					children: [
						/* @__PURE__ */ p("span", {
							className: "sw-turn-seal",
							title: y("games.summonerwars.turnNo", { n: e.turnNumber }),
							children: [/* @__PURE__ */ f("b", { children: e.turnNumber }), /* @__PURE__ */ f("small", { children: y("games.summonerwars.turnWord") })]
						}),
						/* @__PURE__ */ f("div", {
							className: "sw-phase-track",
							role: "list",
							"aria-label": y("games.summonerwars.phaseTrack"),
							children: Me.map((t) => /* @__PURE__ */ f("span", {
								className: "sw-phase",
								role: "listitem",
								"data-now": !e.winner && e.phase === t ? "true" : void 0,
								children: y(je[t])
							}, t))
						}),
						/* @__PURE__ */ f("button", {
							className: "sw-ghost-btn",
							onClick: () => E(!0),
							children: y("games.summonerwars.log")
						})
					]
				}), /* @__PURE__ */ f("div", {
					className: "sw-seats",
					children: e.players.map((t, n) => {
						let r = h.find((e) => e.rid === t.rid), i = a[(r?.colorIndex ?? n) % a.length].hex, o = t.rid === e.turn && !e.winner;
						return /* @__PURE__ */ p("div", {
							className: "sw-seat",
							"data-active": o,
							"data-mine": t.rid === _,
							style: { "--seat": i },
							children: [
								r && /* @__PURE__ */ f("span", {
									className: "sw-seat-avatar",
									children: /* @__PURE__ */ f(l, {
										m: r,
										myRid: _,
										action: o ? "pending" : null,
										anchorName: null,
										box: "size-7",
										img: "size-7"
									})
								}),
								/* @__PURE__ */ f(He, {
									faction: t.faction,
									className: "sw-seat-sigil"
								}),
								/* @__PURE__ */ p("span", {
									className: "sw-seat-name",
									children: [/* @__PURE__ */ f("b", { children: b === "zh" ? g[t.faction]?.zh : g[t.faction]?.name }), /* @__PURE__ */ f("small", { children: t.rid === _ ? y("games.summonerwars.you") : y("games.summonerwars.enemy") })]
								}),
								/* @__PURE__ */ p("span", {
									className: "sw-seat-stats",
									children: [
										/* @__PURE__ */ f("span", {
											className: "sw-dial",
											title: y("games.summonerwars.magic", { n: t.magic }),
											"aria-label": y("games.summonerwars.magic", { n: t.magic }),
											children: t.magic
										}),
										/* @__PURE__ */ p("span", {
											className: "sw-count",
											children: [/* @__PURE__ */ f("b", { children: t.handCount }), y("games.summonerwars.hand")]
										}),
										/* @__PURE__ */ p("span", {
											className: "sw-count",
											children: [/* @__PURE__ */ f("b", { children: t.drawCount }), y("games.summonerwars.drawPileShort")]
										})
									]
								})
							]
						}, t.rid);
					})
				})] }),
				actions: /* @__PURE__ */ f("div", {
					className: "sw-actions",
					children: H ? /* @__PURE__ */ f("div", {
						className: "sw-options",
						children: o.options.map((e) => {
							let t = e.uid ? N(e.uid) : void 0, n = e.card ? F(e.card) : t ? F(t.card) : e.n ? `+${e.n}` : e.id;
							return /* @__PURE__ */ f("button", {
								onClick: () => v({
									type: "choose",
									id: e.id
								}),
								children: n
							}, e.id);
						})
					}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
						className: "sw-action-status",
						children: [/* @__PURE__ */ f("b", { children: U ? F(U.card) : x?.kind === "hand" || x?.kind === "event" || x?.kind === "eventSlot" ? F(x.card) : ae }), /* @__PURE__ */ f("span", { children: X })]
					}), /* @__PURE__ */ p("div", {
						className: "sw-action-buttons",
						children: [
							x && /* @__PURE__ */ f("button", {
								onClick: () => S(null),
								children: y("games.summonerwars.cancel")
							}),
							se && /* @__PURE__ */ f("button", {
								onClick: () => w(se),
								children: y("games.summonerwars.detail")
							}),
							oe && /* @__PURE__ */ f("button", {
								className: "sw-ability",
								onClick: () => {
									v(oe), S(null);
								},
								children: y("games.summonerwars.useAbility")
							}),
							I && /* @__PURE__ */ f("button", {
								className: "sw-primary",
								onClick: () => {
									v({ type: "next" }), S(null);
								},
								children: e.phase === "magic" ? y("games.summonerwars.endTurn") : y("games.summonerwars.next")
							}),
							/* @__PURE__ */ f("button", {
								onClick: () => E(!0),
								children: y("games.summonerwars.log")
							})
						]
					})] })
				}),
				children: /* @__PURE__ */ p("div", {
					className: "sw-stage",
					children: [
						/* @__PURE__ */ p("div", {
							className: "sw-table-props",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ p("span", {
								className: "sw-prop-tokens",
								children: [
									/* @__PURE__ */ f("i", { children: "♥" }),
									/* @__PURE__ */ f("i", { children: "♥" }),
									/* @__PURE__ */ f("i", { children: "♥" })
								]
							}), /* @__PURE__ */ p("span", {
								className: "sw-prop-dice",
								children: [/* @__PURE__ */ f("i", { children: "⚔" }), /* @__PURE__ */ f("i", { children: "➶" })]
							})]
						}),
						/* @__PURE__ */ p("aside", {
							className: "sw-rail sw-rail-left",
							style: { "--sw-faction": ke(L?.faction) },
							children: [
								L && /* @__PURE__ */ f("span", {
									className: "sw-rail-watermark",
									"aria-hidden": !0,
									children: /* @__PURE__ */ f(He, { faction: L.faction })
								}),
								/* @__PURE__ */ f("span", {
									className: "sw-rail-title",
									children: y("games.summonerwars.table")
								}),
								z && /* @__PURE__ */ p("button", {
									className: "sw-rail-summoner",
									onClick: () => w(z),
									children: [/* @__PURE__ */ f("span", {
										className: "sw-rail-label",
										children: y("games.summonerwars.yourSummoner")
									}), /* @__PURE__ */ f(Q, { card: z })]
								}),
								/* @__PURE__ */ p("span", {
									className: "sw-pile",
									title: y("games.summonerwars.drawPile", { n: L?.drawCount ?? 0 }),
									children: [/* @__PURE__ */ f("span", {
										className: "sw-cardback sw-cardback-lg",
										"aria-hidden": !0
									}), /* @__PURE__ */ p("span", { children: [
										y("games.summonerwars.drawPileShort"),
										" ",
										/* @__PURE__ */ f("b", { children: L?.drawCount ?? 0 })
									] })]
								}),
								/* @__PURE__ */ p("button", {
									className: "sw-pile",
									onClick: () => O(!0),
									title: y("games.summonerwars.discardPile"),
									children: [/* @__PURE__ */ f("span", {
										className: "sw-cardback sw-cardback-lg",
										"aria-hidden": !0
									}), /* @__PURE__ */ p("span", { children: [
										y("games.summonerwars.discardPile"),
										" ",
										/* @__PURE__ */ f("b", { children: L?.discardCount ?? 0 })
									] })]
								}),
								/* @__PURE__ */ p("button", {
									className: "sw-active-chip",
									"data-empty": Z === 0 ? "true" : void 0,
									onClick: () => A(!0),
									children: [
										y("games.summonerwars.activeEvents"),
										" ",
										/* @__PURE__ */ f("b", { children: Z })
									]
								})
							]
						}),
						/* @__PURE__ */ f("div", {
							className: "sw-table-wrap",
							children: /* @__PURE__ */ p("div", {
								className: "sw-frame",
								children: [
									/* @__PURE__ */ f(Ve, { pos: "tl" }),
									/* @__PURE__ */ f(Ve, { pos: "tr" }),
									/* @__PURE__ */ f(Ve, { pos: "br" }),
									/* @__PURE__ */ f(Ve, { pos: "bl" }),
									/* @__PURE__ */ f("div", {
										className: "sw-board",
										role: "grid",
										"aria-label": y("games.summonerwars.board"),
										style: {
											"--sw-top": ke(R?.faction),
											"--sw-bottom": ke(L?.faction)
										},
										children: Array.from({ length: 48 }, (t, n) => {
											let r = e.units.find((e) => e.slot === n), i = G.has(n) || q.has(n) || te.has(n), a = !!r && (K.has(r.uid) || J.has(r.uid)), o = !!r && U?.uid === r.uid, s = x?.kind === "hand" && q.has(n) ? x.card : null, c = (x?.kind === "eventSlot" || x?.kind === "event") && te.has(n) ? x.card : null;
											return /* @__PURE__ */ p("div", {
												role: "gridcell",
												tabIndex: 0,
												className: "sw-cell",
												"data-dest": i || void 0,
												"data-target": a || void 0,
												"data-selected": o || void 0,
												style: o && r ? { "--sel": Oe(r.card) } : void 0,
												onClick: () => ie(n),
												onKeyDown: (e) => {
													(e.key === "Enter" || e.key === " ") && (e.preventDefault(), ie(n));
												},
												children: [
													r ? /* @__PURE__ */ f(ze, {
														unit: r,
														mine: r.owner === _,
														onDetail: () => w(r.card)
													}) : null,
													!r && s ? /* @__PURE__ */ p("span", {
														className: "sw-ghost",
														"aria-hidden": !0,
														children: [/* @__PURE__ */ f("span", {
															className: "sw-ghost-art",
															style: { backgroundImage: `url(${De(s) ?? ""})` }
														}), /* @__PURE__ */ f("span", {
															className: "sw-ghost-cost",
															children: m[s].cost
														})]
													}) : null,
													!r && c ? /* @__PURE__ */ f("span", {
														className: "sw-ghost",
														"data-spell": !0,
														"aria-hidden": !0,
														children: /* @__PURE__ */ f("span", {
															className: "sw-ghost-cost",
															children: "✦"
														})
													}) : null
												]
											}, n);
										})
									}),
									/* @__PURE__ */ p("div", {
										className: "sw-ledge",
										children: [
											/* @__PURE__ */ p("span", {
												className: "sw-pile",
												title: y("games.summonerwars.drawPile", { n: L?.drawCount ?? 0 }),
												children: [/* @__PURE__ */ f("span", {
													className: "sw-cardback",
													"aria-hidden": !0
												}), /* @__PURE__ */ p("span", { children: [
													y("games.summonerwars.drawPileShort"),
													" ",
													/* @__PURE__ */ f("b", { children: L?.drawCount ?? 0 })
												] })]
											}),
											/* @__PURE__ */ p("button", {
												className: "sw-pile",
												onClick: () => O(!0),
												title: y("games.summonerwars.discardPile"),
												children: [/* @__PURE__ */ f("span", {
													className: "sw-cardback",
													"aria-hidden": !0
												}), /* @__PURE__ */ p("span", { children: [
													y("games.summonerwars.discardPile"),
													" ",
													/* @__PURE__ */ f("b", { children: L?.discardCount ?? 0 })
												] })]
											}),
											/* @__PURE__ */ f("span", { className: "sw-ledge-spacer" }),
											/* @__PURE__ */ p("button", {
												className: "sw-active-chip",
												"data-empty": Z === 0 ? "true" : void 0,
												onClick: () => A(!0),
												children: [
													y("games.summonerwars.activeEvents"),
													" ",
													/* @__PURE__ */ f("b", { children: Z })
												]
											})
										]
									})
								]
							})
						}),
						/* @__PURE__ */ p("aside", {
							className: "sw-rail sw-rail-right",
							style: { "--sw-faction": ke(R?.faction) },
							children: [
								R && /* @__PURE__ */ f("span", {
									className: "sw-rail-watermark",
									"aria-hidden": !0,
									children: /* @__PURE__ */ f(He, { faction: R.faction })
								}),
								/* @__PURE__ */ f("span", {
									className: "sw-rail-title",
									children: y("games.summonerwars.log")
								}),
								B && /* @__PURE__ */ p("button", {
									className: "sw-rail-summoner",
									onClick: () => w(B),
									children: [/* @__PURE__ */ f("span", {
										className: "sw-rail-label",
										children: y("games.summonerwars.enemySummoner")
									}), /* @__PURE__ */ f(Q, { card: B })]
								}),
								/* @__PURE__ */ f("ul", {
									className: "sw-rail-log",
									children: e.log.slice(-30).map((e, t) => /* @__PURE__ */ f("li", { children: ce(e) }, t))
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							className: "sw-hand-bar",
							children: [/* @__PURE__ */ p("div", {
								className: "sw-hand-head",
								children: [/* @__PURE__ */ f("b", { children: y("games.summonerwars.hand") }), /* @__PURE__ */ f("span", { children: e.phase === "magic" ? y("games.summonerwars.magicHint") : I ? y("games.summonerwars.discardHint") : "" })]
							}), /* @__PURE__ */ p("div", {
								className: "sw-hand",
								"data-empty": o.hand.length === 0 ? "true" : void 0,
								children: [o.hand.length === 0 && /* @__PURE__ */ f("span", {
									className: "sw-hand-empty",
									children: y("games.summonerwars.handEmpty")
								}), o.hand.map((t, n) => {
									let r = m[t], i = (x?.kind === "hand" || x?.kind === "event" || x?.kind === "eventSlot") && x.card === t, a = I && (e.phase === "magic" || V.some((e) => (e.type === "summon" || e.type === "build" || e.type === "event") && e.card === t));
									return /* @__PURE__ */ f("button", {
										className: "sw-card-slot",
										"data-selected": i || void 0,
										"data-dim": !a || void 0,
										style: { "--sw-accent": Oe(t) },
										onClick: () => Y(t),
										onDoubleClick: () => w(t),
										"aria-label": `${r.name} · ${y(Fe(r))}`,
										children: /* @__PURE__ */ f(Q, { card: t })
									}, `${t}:${n}`);
								})]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f(n, {
				open: C !== null,
				onClose: () => w(null),
				title: y("games.summonerwars.detail"),
				label: y("games.summonerwars.detail"),
				tall: !0,
				children: C && /* @__PURE__ */ f(Be, { card: C })
			}),
			/* @__PURE__ */ f(n, {
				open: D,
				onClose: () => O(!1),
				title: y("games.summonerwars.discardPile"),
				label: y("games.summonerwars.discardPile"),
				tall: !0,
				children: /* @__PURE__ */ f("div", {
					className: "sw-sheet-body",
					children: /* @__PURE__ */ f("div", {
						className: "sw-sheet-grid",
						children: e.players.map((e) => /* @__PURE__ */ p("div", {
							className: "sw-sheet-grid",
							style: { width: "100%" },
							children: [
								/* @__PURE__ */ p("span", {
									className: "sw-sheet-label",
									children: [
										P(e.rid),
										" · ",
										y("games.summonerwars.discardCountShort", { n: e.discardCount })
									]
								}),
								e.discardCards.length === 0 && /* @__PURE__ */ f("span", {
									className: "sw-sheet-empty",
									children: y("games.summonerwars.discardEmpty")
								}),
								e.discardCards.map((e, t) => /* @__PURE__ */ f(Q, { card: e }, `${e}:${t}`))
							]
						}, e.rid))
					})
				})
			}),
			/* @__PURE__ */ f(n, {
				open: k,
				onClose: () => A(!1),
				title: y("games.summonerwars.table"),
				label: y("games.summonerwars.table"),
				tall: !0,
				children: /* @__PURE__ */ f("div", {
					className: "sw-sheet-body",
					children: /* @__PURE__ */ f("div", {
						className: "sw-sheet-grid",
						children: e.players.map((e) => /* @__PURE__ */ p("div", {
							className: "sw-sheet-grid",
							style: { width: "100%" },
							children: [
								/* @__PURE__ */ p("span", {
									className: "sw-sheet-label",
									children: [
										P(e.rid),
										" · ",
										y("games.summonerwars.activeEvents")
									]
								}),
								e.active.length === 0 && /* @__PURE__ */ f("span", {
									className: "sw-sheet-empty",
									children: y("games.summonerwars.noActiveEvents")
								}),
								e.active.map((e, t) => /* @__PURE__ */ f(Q, { card: e }, `${e}:${t}`))
							]
						}, e.rid))
					})
				})
			}),
			T && /* @__PURE__ */ f(c, {
				log: e.log,
				line: ce,
				onClose: () => E(!1)
			})
		]
	});
}
function Q({ card: e }) {
	let t = i(), n = r((e) => e.locale), a = m[e];
	if (!a) return null;
	let o = De(e), s = !!a.structure && a.tags.includes("gate");
	return /* @__PURE__ */ p("span", {
		className: "sw-card",
		"data-card-face": "",
		"data-card": e,
		"data-structure": a.structure || void 0,
		style: { "--sw-accent": Oe(e) },
		children: [
			/* @__PURE__ */ f("span", {
				className: "sw-card-art",
				style: o ? { backgroundImage: `url(${o})` } : void 0,
				"data-gate": s || void 0,
				"aria-hidden": !0
			}),
			/* @__PURE__ */ p("span", {
				className: "sw-card-body",
				children: [
					/* @__PURE__ */ f("span", {
						className: "sw-card-name",
						children: a.name
					}),
					/* @__PURE__ */ p("span", {
						className: "sw-card-type",
						children: [
							t(Fe(a)),
							" · ",
							n === "zh" ? g[a.faction]?.zh : g[a.faction]?.name
						]
					}),
					/* @__PURE__ */ p("span", {
						className: "sw-card-pips",
						children: [
							a.cost > 0 && /* @__PURE__ */ f("span", {
								className: "sw-pip sw-pip-cost",
								children: a.cost
							}),
							a.life ? /* @__PURE__ */ f("span", {
								className: "sw-pip sw-pip-life",
								children: a.life
							}) : null,
							a.strength !== void 0 && a.atk ? /* @__PURE__ */ p("span", {
								className: "sw-pip sw-pip-atk",
								children: [
									a.atk === "ranged" ? "➶" : "⚔",
									" ",
									a.strength
								]
							}) : null
						]
					}),
					Ie(a) && /* @__PURE__ */ f("span", {
						className: "sw-card-keyword",
						children: Ie(a)
					})
				]
			}),
			/* @__PURE__ */ f("span", {
				className: "sw-card-shade",
				"aria-hidden": !0
			})
		]
	});
}
function ze({ unit: e, mine: t, onDetail: n }) {
	let r = m[e.card], i = De(e.card), a = r?.structure && r.tags.includes("gate");
	return /* @__PURE__ */ p("div", {
		className: "sw-unit",
		"data-enemy": !t || void 0,
		"data-gate": a || void 0,
		"data-acted": t && !e.canAct || void 0,
		style: { "--sw-accent": Oe(e.card) },
		onDoubleClick: (e) => {
			e.stopPropagation(), n();
		},
		title: r?.name,
		children: [
			i && /* @__PURE__ */ f("span", {
				className: "sw-unit-art",
				style: { backgroundImage: `url(${i})` },
				"aria-hidden": !0
			}),
			/* @__PURE__ */ f("span", {
				className: "sw-unit-base",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ f("span", {
				className: "sw-unit-name",
				children: r?.name
			}),
			/* @__PURE__ */ p("span", {
				className: "sw-unit-stats",
				children: [/* @__PURE__ */ p("b", {
					className: "sw-life",
					children: ["♥ ", e.life]
				}), /* @__PURE__ */ p("b", {
					className: "sw-str",
					children: [
						r?.atk === "ranged" ? "➶" : "⚔",
						" ",
						e.strength
					]
				})]
			}),
			e.damage > 0 && /* @__PURE__ */ f("span", {
				className: "sw-unit-dmg",
				children: e.damage
			}),
			e.boosts > 0 && /* @__PURE__ */ p("span", {
				className: "sw-unit-boost",
				children: ["+", e.boosts]
			})
		]
	});
}
function Be({ card: e }) {
	let t = i(), n = r((e) => e.locale), a = m[e];
	return a ? /* @__PURE__ */ p("div", {
		className: "sw-detail",
		children: [/* @__PURE__ */ f(Q, { card: e }), /* @__PURE__ */ p("div", {
			className: "sw-detail-copy",
			children: [
				/* @__PURE__ */ p("div", {
					className: "sw-detail-head",
					children: [/* @__PURE__ */ f("b", { children: a.name }), /* @__PURE__ */ p("span", { children: [
						t(Fe(a)),
						" · ",
						n === "zh" ? g[a.faction]?.zh : g[a.faction]?.name
					] })]
				}),
				/* @__PURE__ */ p("div", {
					className: "sw-detail-stats",
					children: [
						a.cost > 0 && /* @__PURE__ */ p("span", { children: [
							t("games.summonerwars.cost"),
							" ",
							a.cost
						] }),
						a.life ? /* @__PURE__ */ p("span", { children: [
							t("games.summonerwars.life"),
							" ",
							a.life
						] }) : null,
						a.strength === void 0 ? null : /* @__PURE__ */ p("span", { children: [
							t("games.summonerwars.strength"),
							" ",
							a.strength
						] }),
						a.atk && /* @__PURE__ */ f("span", { children: a.atk === "ranged" ? "➶" : "⚔" })
					]
				}),
				/* @__PURE__ */ f("p", {
					className: "sw-detail-text",
					children: n === "zh" ? a.text.zh : a.text.en
				})
			]
		})]
	}) : null;
}
function Ve({ pos: e }) {
	return /* @__PURE__ */ p("svg", {
		className: "sw-corner",
		"data-pos": e,
		viewBox: "0 0 30 30",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("path", {
				d: "M2 12 V4 a2 2 0 0 1 2-2 h8",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M6 9 V7 a1 1 0 0 1 1-1 h2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1",
				opacity: ".7"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "6.5",
				cy: "6.5",
				r: "1.4",
				fill: "currentColor",
				opacity: ".9"
			})
		]
	});
}
function He({ faction: e, className: t }) {
	let n = Ue[e] ?? Ue["fallen-kingdom"];
	return /* @__PURE__ */ f("svg", {
		className: t,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: n
	});
}
var Ue = {
	"fallen-kingdom": /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M5 18 V9 l3 2 4-5 4 5 3-2 v9 Z" }),
		/* @__PURE__ */ f("path", { d: "M9 18 v-3 h6 v3" }),
		/* @__PURE__ */ f("circle", {
			cx: "12",
			cy: "8",
			r: "1.2"
		})
	] }),
	"cave-goblins": /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M7 18 c-2-5 1-11 5-11 s7 6 5 11" }),
		/* @__PURE__ */ f("path", { d: "M9 14 l2-3 1 3 1-3 2 3" }),
		/* @__PURE__ */ f("path", { d: "M8 9 l-2-3 3 1M16 9 l2-3-3 1" })
	] }),
	"guild-dwarves": /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("path", { d: "M6 10 h12 v4 l-3 4 h-6 l-3-4 Z" }),
		/* @__PURE__ */ f("path", { d: "M9 10 V7 h6 v3" }),
		/* @__PURE__ */ f("path", { d: "M10 14 h4" })
	] }),
	"phoenix-elves": /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M12 20 c-4-2-6-6-5-10 2 2 3 3 4 5 0-4 1-7 1-7 s1 3 1 7 c1-2 2-3 4-5 1 4-1 8-5 10Z" }), /* @__PURE__ */ f("path", { d: "M12 11 v6" })] }),
	"shadow-elves": /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M15 4 a8 8 0 1 0 0 16 a6 6 0 1 1 0-16Z" }), /* @__PURE__ */ f("circle", {
		cx: "17",
		cy: "12",
		r: "1"
	})] }),
	vanguards: /* @__PURE__ */ f(d, { children: /* @__PURE__ */ f("path", { d: "M12 3 l2.4 5.3 5.6.7-4.2 4 1.2 5.8L12 16l-5 2.8 1.2-5.8-4.2-4 5.6-.7Z" }) })
}, We = 6;
function $(e, t) {
	return Math.abs(e % We - t % We) + Math.abs(Math.floor(e / We) - Math.floor(t / We));
}
var Ge = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	if (n.pending) return n.pending.rid !== t.rid || !r.options.length ? null : { action: {
		type: "choose",
		id: [...r.options].sort((e, t) => (t.n ?? 0) - (e.n ?? 0))[0].id
	} };
	if (n.winner || n.turn !== t.rid) return null;
	let i = r.moves;
	if (!i.length) return null;
	let a = (e) => n.units.find((t) => t.uid === e), o = n.players.find((e) => e.rid === t.rid)?.summoner, s = n.players.find((e) => e.rid !== t.rid)?.summoner, c = i.filter((e) => e.type === "attack");
	if (c.length) {
		let e = (e) => {
			let n = a(e.target);
			if (!n || n.owner === t.rid) return -100;
			let r = n.uid === s ? 500 : n.life * 2 + (n.structure ? 2 : 0);
			n.life <= 3 && (r += 6);
			let i = a(e.uid);
			return i && i.life <= 2 && !n.structure && (r -= 2), r;
		}, n = [...c].sort((t, n) => e(n) - e(t))[0];
		if (e(n) > 0) return { action: n };
	}
	let l = i.filter((e) => e.type === "summon");
	if (l.length) {
		let e = n.players.find((e) => e.rid === t.rid)?.magic ?? 0, r = [...l].sort((e, t) => (m[t.card]?.cost ?? 0) - (m[e.card]?.cost ?? 0))[0];
		if (e - (m[r.card]?.cost ?? 0) >= 0) return { action: r };
	}
	let u = i.filter((e) => e.type === "build");
	if (u.length) {
		let e = n.units.filter((e) => e.owner === t.rid && m[e.card]?.tags.includes("gate")).length;
		return { action: u.find(() => e < 2) ?? u[0] };
	}
	let d = i.filter((e) => e.type === "move");
	if (d.length) {
		let e = s ? a(s)?.slot : void 0, t = [...d].sort((t, n) => {
			let r = a(t.uid), i = a(n.uid), s = e === void 0 || !r ? 99 : $(t.to, e), c = e === void 0 || !i ? 99 : $(n.to, e);
			if (s !== c) return s - c;
			let l = o ? a(o)?.slot : void 0;
			return (l === void 0 || !i ? 0 : $(n.to, l)) - (l === void 0 || !r ? 0 : $(t.to, l));
		})[0], n = e === void 0 ? 99 : $(a(t.uid)?.slot ?? 0, e);
		if ((e === void 0 ? 99 : $(t.to, e)) <= n) return { action: t };
	}
	return { action: { type: "next" } };
};
//#endregion
//#region src/game/game-over.tsx
function Ke({ result: e, public: t, members: n, onPlayAgain: a, onBackToLobby: o }) {
	let s = i(), c = r((e) => e.locale), l = t, d = e.winner[0] ?? l.winner ?? "", m = l.players.find((e) => e.rid !== d)?.rid ?? "", h = l.players.find((e) => e.rid === d), _ = l.players.find((e) => e.rid === m), v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, c) : e;
	}, y = (e) => l.units.filter((t) => t.owner === e && t.slot >= 0).length, b = (e) => e ? e.split("#")[0] : "", x = (e) => e ? (c === "zh" ? g[e]?.zh : g[e]?.name) ?? e : "", S = a ?? o;
	return /* @__PURE__ */ p("div", {
		className: "sw-end",
		children: [/* @__PURE__ */ f("div", {
			className: "sw-end-bg",
			"aria-hidden": !0
		}), /* @__PURE__ */ p("div", {
			className: "sw-end-sheet",
			children: [
				/* @__PURE__ */ f("div", {
					className: "sw-end-seal",
					children: s("games.summonerwars.victorySeal")
				}),
				/* @__PURE__ */ f("div", {
					className: "sw-end-title",
					children: s("games.summonerwars.aftermath")
				}),
				d && /* @__PURE__ */ f("div", {
					className: "sw-end-sub",
					children: s("games.summonerwars.winnerLine", { name: v(d) })
				}),
				/* @__PURE__ */ p("div", {
					className: "sw-end-duel",
					children: [h && /* @__PURE__ */ p("div", {
						className: "sw-end-card",
						children: [
							/* @__PURE__ */ p("small", { children: [
								s("games.summonerwars.victor"),
								" · ",
								v(d)
							] }),
							/* @__PURE__ */ f(Q, { card: b(h.summoner) }),
							/* @__PURE__ */ p("span", {
								className: "sw-end-faction",
								children: [/* @__PURE__ */ f(He, {
									faction: h.faction,
									className: "sw-seat-sigil"
								}), x(h.faction)]
							})
						]
					}), _ && /* @__PURE__ */ p("div", {
						className: "sw-end-card",
						"data-fallen": "true",
						children: [
							/* @__PURE__ */ p("small", { children: [
								s("games.summonerwars.fallenSummoner"),
								" · ",
								v(m)
							] }),
							/* @__PURE__ */ f(Q, { card: b(_.summoner) }),
							/* @__PURE__ */ p("span", {
								className: "sw-end-faction",
								children: [/* @__PURE__ */ f(He, {
									faction: _.faction,
									className: "sw-seat-sigil"
								}), x(_.faction)]
							})
						]
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: "sw-end-stats",
					children: [
						/* @__PURE__ */ f("span", { children: s("games.summonerwars.turns", { n: l.turnNumber }) }),
						h && /* @__PURE__ */ p("span", { children: [
							v(d),
							" · ",
							s("games.summonerwars.survivors", { n: y(d) })
						] }),
						_ && /* @__PURE__ */ p("span", { children: [
							v(m),
							" · ",
							s("games.summonerwars.survivors", { n: y(m) })
						] }),
						h && /* @__PURE__ */ f("span", { children: s("games.summonerwars.finalMagic", { n: h.magic }) })
					]
				}),
				S ? /* @__PURE__ */ p("div", {
					className: "sw-end-controls",
					children: [a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "sw-primary",
						onClick: a,
						children: s("session.result.playAgain")
					}), o && /* @__PURE__ */ f("button", {
						type: "button",
						onClick: o,
						children: s("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ f("p", {
					className: "sw-end-wait",
					children: s("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region src/index.tsx
var qe = {
	definition: Ee,
	View: Le,
	bot: Ge,
	OverView: Ke,
	locales: {
		zh: {
			name: "召唤师战争",
			desc: "两位召唤师在 6×8 战场上召唤军队、掷骰攻击，先摧毁对方召唤师者获胜",
			rules: "目标：消灭对方的召唤师。\n准备：双方各选一个阵营，按召唤师卡背的起始布阵图，在自己一侧放置召唤师、2 个起始单位与起始城门（10 点生命）。将其余牌洗混后作为牌堆。游戏开始时没有手牌，也没有魔力。\n每回合按六个阶段依次进行：\n一、抽牌：抽牌至手牌达到 5 张。牌堆耗尽后不能再抽牌。\n二、召唤：支付单位费用，将其放在你控制的城门相邻的空格。没有可用空格或魔力不足时不能召唤。\n三、事件：打出事件牌，包括城墙牌。事件牌结算后进入弃牌堆；带有「持续」的事件牌留在持续区，在你的下个回合开始时弃置。\n四、移动：最多移动 3 个不同的单位，每个单位最多移动 2 格。单位只能进入空格，不能穿过其他牌，也不能斜向移动。\n五、攻击：最多用 3 个不同的单位各攻击一次。近战单位攻击相邻的牌；远程单位攻击至多 3 格直线内、路径上没有其他牌的牌。掷与力量等量的骰子，每枚骰子有 3 面近战命中、2 面远程命中与 1 面特殊符号。近战单位只计近战命中，远程单位只计远程命中，每个相符的命中对目标造成 1 点伤害。特殊符号本身不造成伤害，只有当牌面说明允许时才会生效。\n六、建造魔力：从手牌中任意选择若干张牌面朝下放入魔力堆，每张获得 1 点魔力。你可以查看自己的魔力堆，但不能改变其中牌的顺序。\n先手玩家的第一个回合跳过抽牌、召唤与事件阶段，直接从移动阶段开始，并且该阶段最多只能移动 2 个单位。\n其他规则：\n· 你控制的牌消灭敌方牌时，被消灭的牌进入你的魔力堆，可在之后的召唤中作为魔力使用。\n· 牌的伤害达到其生命值时即被消灭，进入弃牌堆。\n· 牌堆耗尽时不洗回弃牌堆。\n胜利：对方召唤师被消灭时，你立即获胜。",
			summonPhase: "召唤阶段",
			eventPhase: "事件阶段",
			movePhase: "移动阶段",
			attackPhase: "攻击阶段",
			magicPhase: "魔力阶段",
			next: "进入下一阶段",
			endTurn: "结束回合",
			yourTurn: "你的回合",
			waiting: "等待 {{name}}…",
			hand: "手牌",
			magic: "魔力 {{n}}",
			drawPile: "牌堆 {{n}}",
			discard: "弃牌堆 {{n}}",
			units: "单位",
			log: "战报",
			faction: "阵营",
			chooseFaction: "选择阵营",
			start: "开始对局",
			selectUnit: "选择单位",
			selectTarget: "选择目标",
			selectSlot: "选择空格",
			cancel: "取消",
			attack: "攻击",
			move: "移动",
			summon: "召唤",
			build: "建造",
			play: "打出",
			pass: "跳过",
			guard: "守护",
			damage: "伤害",
			boost: "强化",
			strength: "力量",
			life: "生命",
			cost: "费用",
			errNotYourTurn: "现在轮不到你",
			errPhase: "当前阶段不能这样做",
			errBadCard: "这张牌不能这样使用",
			errBadSlot: "这个位置不合法",
			errBadUnit: "这不是你的单位",
			errBadTarget: "目标不合法",
			errNoMagic: "魔力不足",
			errMoved: "这个单位本回合已经移动过",
			errMoveLimit: "本回合移动单位数已达上限",
			errAttacked: "这个单位本回合已经攻击过",
			errAttackLimit: "本回合攻击单位数已达上限",
			errNoLine: "目标不在攻击范围内，或路径被阻挡",
			errProtect: "必须优先攻击具有「保护」能力的单位",
			errPending: "请先完成当前选择",
			errNotYou: "现在不是你选择",
			errBadChoice: "无效的选择",
			errUsed: "本回合已经使用过",
			errRange: "超出范围",
			errNeedVictim: "需要先选择一个相邻的友方单位来替换",
			errActive: "同名持续事件已在场",
			errOver: "对局已结束",
			errUnknown: "无法执行该动作",
			winnerLine: "{{name}} 获胜",
			discardForMagic: "弃牌换魔力",
			chooseOne: "请选择",
			options: "可选动作",
			noMoves: "没有可用动作",
			hintAttack: "攻击 {{card}}",
			hintMove: "移动 {{card}}",
			hintSummon: "召唤 {{card}}",
			hintBuild: "建造 {{card}}",
			hintEvent: "打出 {{card}}",
			hintNext: "进入下一阶段",
			hintChoose: "选择 {{choice}}",
			hp: "{{n}} 生命",
			board: "战场",
			handEmpty: "手牌为空",
			playEvent: "打出事件",
			useAbility: "使用能力",
			chooseOption: "请选择结算方式",
			pickUnitFirst: "先选择一个单位",
			magicHint: "点击手牌弃置换取魔力",
			discardHint: "每次弃置 1 张牌获得 1 点魔力",
			detail: "卡牌详情",
			close: "关闭",
			turnNo: "第 {{n}} 回合",
			turnWord: "回合",
			phaseTrack: "行动阶段",
			drawPileShort: "牌堆",
			discardPile: "弃牌堆",
			discardCountShort: "弃牌 {{n}} 张",
			discardEmpty: "弃牌堆为空",
			activeEvents: "持续事件",
			noActiveEvents: "没有持续事件",
			table: "桌面",
			yourSummoner: "你的召唤师",
			enemySummoner: "对手召唤师",
			aftermath: "战局已定",
			turns: "共 {{n}} 回合",
			survivors: "存活单位 {{n}}",
			finalMagic: "终局魔力 {{n}}",
			victor: "胜者",
			fallenSummoner: "陨落的召唤师",
			victorySeal: "胜利",
			you: "你",
			enemy: "对手",
			gate: "城门",
			structure: "建筑",
			eventType: "事件",
			championType: "英雄",
			commonType: "普通单位",
			summonerType: "召唤师",
			selectEventTarget: "选择事件的目标",
			attackedCount: "已攻击 {{n}}",
			movedCount: "已移动 {{n}}",
			logSetup: "整军备战",
			logSummoned: "召唤",
			logBuilt: "建造",
			logMoved: "移动",
			logAttack: "发起攻击",
			logDestroyed: "被消灭",
			logDamage: "受到伤害",
			logHeal: "恢复生命",
			logEventLog: "打出事件",
			logMagic: "弃牌换取魔力",
			logDiscarded: "弃置卡牌",
			logTurn: "回合结束",
			logSly: "灵巧换位",
			logRedeploy: "重新部署"
		},
		en: {
			name: "Summoner Wars",
			desc: "Two summoners wage war on a 6x8 battlefield: summon, roll dice, and destroy the enemy summoner",
			rules: "Object: Destroy the opposing summoner.\nSetup: Each player chooses a faction and places their summoner, 2 starting units, and starting gate (10 life) on their own side as shown on the back of the summoner card. Shuffle the rest of your cards into your draw pile. You begin with no cards in hand and no magic.\nEach turn has six phases in order:\n1. Draw: Draw until you have 5 cards in hand. If your draw pile is empty, you cannot draw.\n2. Summon: Pay a unit's cost to place it on an empty space adjacent to a gate you control. You cannot summon without magic or a free adjacent space.\n3. Event: Play event cards, including wall cards. Resolve each event, then discard it; ACTIVE events stay in your active area and are discarded at the start of your next turn.\n4. Move: Move up to 3 different units, each up to 2 spaces. Units may only enter empty spaces, cannot move through other cards, and cannot move diagonally.\n5. Attack: Up to 3 different units each attack once. Melee units attack adjacent cards; ranged units attack cards up to 3 clear straight spaces away. Roll dice equal to the unit's strength. Each die has 3 melee-hit faces, 2 ranged-hit faces and 1 special face. Melee units count only melee hits and ranged units only ranged hits, and each matching hit deals 1 damage to the target. Special faces deal no damage on their own and take effect only when a card says so.\n6. Build Magic: Put any number of cards from your hand face down on top of your magic pile, gaining 1 magic each. You may look at your magic pile but cannot reorder it.\nThe first player skips the Draw, Summon, and Event phases on their first turn, begins with the Move Phase, and may move at most 2 units that turn.\nOther rules:\n- When a card you control destroys an enemy card, that card goes to your magic pile and can be spent as magic.\n- A card is destroyed when its damage reaches its life and is discarded.\n- Do not reshuffle the discard pile when the draw pile is empty.\nVictory: Destroy the opposing summoner.",
			summonPhase: "Summon Phase",
			eventPhase: "Event Phase",
			movePhase: "Move Phase",
			attackPhase: "Attack Phase",
			magicPhase: "Build Magic Phase",
			next: "Next phase",
			endTurn: "End turn",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}…",
			hand: "Hand",
			magic: "Magic {{n}}",
			drawPile: "Draw pile {{n}}",
			discard: "Discard {{n}}",
			units: "Units",
			log: "Battle log",
			faction: "Faction",
			chooseFaction: "Choose a faction",
			start: "Start game",
			selectUnit: "Select a unit",
			selectTarget: "Select a target",
			selectSlot: "Select an empty space",
			cancel: "Cancel",
			attack: "Attack",
			move: "Move",
			summon: "Summon",
			build: "Build",
			play: "Play",
			pass: "Pass",
			guard: "Guard",
			damage: "Damage",
			boost: "Boost",
			strength: "Strength",
			life: "Life",
			cost: "Cost",
			errNotYourTurn: "It is not your turn",
			errPhase: "You cannot do that in this phase",
			errBadCard: "That card cannot be used this way",
			errBadSlot: "That space is not legal",
			errBadUnit: "That is not your unit",
			errBadTarget: "Invalid target",
			errNoMagic: "Not enough magic",
			errMoved: "That unit already moved this turn",
			errMoveLimit: "You have moved the maximum number of units",
			errAttacked: "That unit already attacked this turn",
			errAttackLimit: "You have attacked with the maximum number of units",
			errNoLine: "The target is out of range or the path is blocked",
			errProtect: "You must attack a unit with Protect first",
			errPending: "Finish the current choice first",
			errNotYou: "It is not your choice",
			errBadChoice: "Invalid choice",
			errUsed: "Already used this turn",
			errRange: "Out of range",
			errNeedVictim: "Choose an adjacent friendly unit to replace",
			errActive: "That active event is already in play",
			errOver: "The game is over",
			errUnknown: "That action is not available",
			winnerLine: "{{name}} wins",
			discardForMagic: "Discard for magic",
			chooseOne: "Choose",
			options: "Actions",
			noMoves: "No actions available",
			hintAttack: "Attack with {{card}}",
			hintMove: "Move {{card}}",
			hintSummon: "Summon {{card}}",
			hintBuild: "Build {{card}}",
			hintEvent: "Play {{card}}",
			hintNext: "Next phase",
			hintChoose: "Choose {{choice}}",
			hp: "{{n}} life",
			board: "Battlefield",
			handEmpty: "Your hand is empty",
			playEvent: "Play event",
			useAbility: "Use ability",
			chooseOption: "Choose how to resolve",
			pickUnitFirst: "Select a unit first",
			magicHint: "Discard a card to gain magic",
			discardHint: "Gain 1 magic for each card discarded",
			detail: "Card details",
			close: "Close",
			turnNo: "Turn {{n}}",
			you: "You",
			enemy: "Opponent",
			gate: "Gate",
			structure: "Structure",
			eventType: "Event",
			turnWord: "Turn",
			phaseTrack: "Phases",
			drawPileShort: "Draw",
			discardPile: "Discard",
			discardCountShort: "{{n}} cards",
			discardEmpty: "The discard pile is empty",
			activeEvents: "Active events",
			noActiveEvents: "No active events",
			table: "Table",
			yourSummoner: "Your summoner",
			enemySummoner: "Enemy summoner",
			aftermath: "The battle is decided",
			turns: "{{n}} turns",
			survivors: "{{n}} units standing",
			finalMagic: "{{n}} magic left",
			victor: "Victor",
			fallenSummoner: "Fallen summoner",
			victorySeal: "Victory",
			championType: "Champion",
			commonType: "Common",
			summonerType: "Summoner",
			selectEventTarget: "Choose a target for the event",
			attackedCount: "Attacked {{n}}",
			movedCount: "Moved {{n}}",
			logSetup: "Armies deployed",
			logSummoned: "Summoned",
			logBuilt: "Built",
			logMoved: "Moved",
			logAttack: "Attacked",
			logDestroyed: "destroyed",
			logDamage: "took damage",
			logHeal: "healed",
			logEventLog: "played an event",
			logMagic: "discarded for magic",
			logDiscarded: "discarded cards",
			logTurn: "ended the turn",
			logSly: "slipped past",
			logRedeploy: "redeployed"
		}
	}
};
//#endregion
export { qe as default };
