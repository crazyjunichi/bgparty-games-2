import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/game/data.ts
var y = {
	2: 37,
	3: 49,
	4: 61
}, b = [
	{
		id: 0,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "p",
				c: "barracks"
			},
			{ k: "q" }
		]
	},
	{
		id: 1,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			},
			{
				k: "p",
				c: "house"
			}
		]
	},
	{
		id: 2,
		hexes: [
			{
				k: "p",
				c: "temple"
			},
			{ k: "q" },
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 3,
		hexes: [
			{
				k: "d",
				c: "garden"
			},
			{
				k: "p",
				c: "house"
			},
			{ k: "q" }
		]
	},
	{
		id: 4,
		hexes: [
			{
				k: "d",
				c: "garden"
			},
			{
				k: "p",
				c: "market"
			},
			{ k: "q" }
		]
	},
	{
		id: 5,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "p",
				c: "garden"
			},
			{ k: "q" }
		]
	},
	{
		id: 6,
		hexes: [
			{
				k: "d",
				c: "garden"
			},
			{ k: "q" },
			{
				k: "p",
				c: "market"
			}
		]
	},
	{
		id: 7,
		hexes: [
			{
				k: "p",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			}
		]
	},
	{
		id: 8,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "house"
			},
			{
				k: "p",
				c: "barracks"
			}
		]
	},
	{
		id: 9,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			},
			{
				k: "p",
				c: "garden"
			}
		]
	},
	{
		id: 10,
		hexes: [
			{ k: "q" },
			{
				k: "p",
				c: "garden"
			},
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 11,
		hexes: [
			{
				k: "p",
				c: "temple"
			},
			{
				k: "d",
				c: "market"
			},
			{ k: "q" }
		]
	},
	{
		id: 12,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "market"
			},
			{
				k: "p",
				c: "market"
			}
		]
	},
	{
		id: 13,
		hexes: [
			{
				k: "p",
				c: "temple"
			},
			{
				k: "d",
				c: "barracks"
			},
			{ k: "q" }
		]
	},
	{
		id: 14,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			},
			{
				k: "d",
				c: "market"
			}
		]
	},
	{
		id: 15,
		hexes: [
			{
				k: "d",
				c: "garden"
			},
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 16,
		hexes: [
			{
				k: "d",
				c: "temple"
			},
			{
				k: "d",
				c: "house"
			},
			{ k: "q" }
		]
	},
	{
		id: 17,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 18,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "garden"
			}
		]
	},
	{
		id: 19,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 20,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 21,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "garden"
			},
			{ k: "q" }
		]
	},
	{
		id: 22,
		hexes: [
			{
				k: "d",
				c: "temple"
			},
			{ k: "q" },
			{ k: "q" }
		]
	},
	{
		id: 23,
		hexes: [
			{
				k: "d",
				c: "barracks"
			},
			{ k: "q" },
			{ k: "q" }
		]
	},
	{
		id: 24,
		hexes: [
			{ k: "q" },
			{ k: "q" },
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 25,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			},
			{ k: "q" }
		]
	},
	{
		id: 26,
		hexes: [
			{ k: "q" },
			{
				k: "p",
				c: "market"
			},
			{ k: "q" }
		]
	},
	{
		id: 27,
		hexes: [
			{
				k: "d",
				c: "barracks"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 28,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "temple"
			}
		]
	},
	{
		id: 29,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 30,
		hexes: [
			{
				k: "d",
				c: "barracks"
			},
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 31,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 32,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 33,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "p",
				c: "barracks"
			},
			{
				k: "d",
				c: "temple"
			}
		]
	},
	{
		id: 34,
		hexes: [
			{ k: "q" },
			{ k: "q" },
			{ k: "q" }
		]
	},
	{
		id: 35,
		hexes: [
			{
				k: "p",
				c: "house"
			},
			{
				k: "p",
				c: "barracks"
			},
			{ k: "q" }
		]
	},
	{
		id: 36,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "p",
				c: "temple"
			},
			{
				k: "p",
				c: "house"
			}
		]
	},
	{
		id: 37,
		hexes: [
			{
				k: "d",
				c: "barracks"
			},
			{ k: "q" },
			{
				k: "p",
				c: "temple"
			}
		]
	},
	{
		id: 38,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{ k: "q" },
			{
				k: "p",
				c: "garden"
			}
		]
	},
	{
		id: 39,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "garden"
			},
			{
				k: "p",
				c: "market"
			}
		]
	},
	{
		id: 40,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{ k: "q" },
			{
				k: "p",
				c: "barracks"
			}
		]
	},
	{
		id: 41,
		hexes: [
			{
				k: "p",
				c: "house"
			},
			{
				k: "d",
				c: "barracks"
			},
			{ k: "q" }
		]
	},
	{
		id: 42,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 43,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			},
			{ k: "q" }
		]
	},
	{
		id: 44,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 45,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			},
			{ k: "q" }
		]
	},
	{
		id: 46,
		hexes: [
			{ k: "q" },
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			}
		]
	},
	{
		id: 47,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 48,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "market"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 49,
		hexes: [
			{
				k: "p",
				c: "temple"
			},
			{
				k: "d",
				c: "house"
			},
			{ k: "q" }
		]
	},
	{
		id: 50,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{
				k: "p",
				c: "garden"
			},
			{ k: "q" }
		]
	},
	{
		id: 51,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "garden"
			},
			{
				k: "p",
				c: "barracks"
			}
		]
	},
	{
		id: 52,
		hexes: [
			{
				k: "p",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "temple"
			}
		]
	},
	{
		id: 53,
		hexes: [
			{
				k: "d",
				c: "temple"
			},
			{ k: "q" },
			{
				k: "p",
				c: "market"
			}
		]
	},
	{
		id: 54,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{ k: "q" },
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 55,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			}
		]
	},
	{
		id: 56,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			},
			{ k: "q" }
		]
	},
	{
		id: 57,
		hexes: [
			{ k: "q" },
			{
				k: "d",
				c: "barracks"
			},
			{ k: "q" }
		]
	},
	{
		id: 58,
		hexes: [
			{
				k: "d",
				c: "market"
			},
			{ k: "q" },
			{ k: "q" }
		]
	},
	{
		id: 59,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "barracks"
			},
			{
				k: "d",
				c: "house"
			}
		]
	},
	{
		id: 60,
		hexes: [
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "house"
			},
			{
				k: "d",
				c: "market"
			}
		]
	}
], x = [
	"house",
	"market",
	"barracks",
	"temple",
	"garden"
], S = {
	house: 1,
	market: 2,
	barracks: 2,
	temple: 2,
	garden: 3
}, C = {
	house: "#2f7fc1",
	market: "#e0a51c",
	barracks: "#c94f37",
	temple: "#7b57a8",
	garden: "#4e9b47"
}, w = {
	house: "#1d5687",
	market: "#9c6d0c",
	barracks: "#8f2f20",
	temple: "#553676",
	garden: "#326a2e"
}, T = [
	[0, 0],
	[1, 0],
	[0, 1]
], E = (e, t) => [-t, e + t], D = Array.from({ length: 6 }, (e, t) => T.map(([e, n]) => {
	let r = [e, n];
	for (let e = 0; e < t; e++) r = E(r[0], r[1]);
	return r;
})), O = (e, t) => `${e},${t}`, k = (e) => {
	let [t, n] = e.split(",").map(Number);
	return [t, n];
}, A = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], j = (e) => {
	let [t, n] = k(e);
	return A.map(([e, r]) => O(t + e, n + r));
}, M = (e, t) => e[t]?.length ?? 0, N = (e, t) => e[t]?.at(-1);
function ee() {
	let e = () => ({
		k: "q",
		tile: -1
	});
	return {
		"0,0": [{
			k: "p",
			c: "house",
			tile: -1
		}],
		"-1,0": [e()],
		"-1,1": [e()],
		"0,1": [e()]
	};
}
var te = (e, t) => e + ":" + [...t].sort().join("|");
function P(e, t, n) {
	return D[e % 6].map(([e, r]) => O(t + e, n + r));
}
function F(e) {
	let t = [], n = /* @__PURE__ */ new Set(), r = (e) => {
		let r = te(e.level, e.cells);
		n.has(r) || (n.add(r), t.push(e));
	}, i = Object.keys(e).filter((t) => M(e, t) > 0), a = /* @__PURE__ */ new Set();
	for (let e of i) {
		a.add(e);
		for (let t of j(e)) a.add(t);
	}
	for (let t of a) {
		let [n, i] = k(t);
		for (let a = 0; a < 6; a++) {
			let o = P(a, n, i);
			if (o.every((t) => M(e, t) === 0)) {
				o.some((t) => j(t).some((t) => M(e, t) > 0)) && r({
					rot: a,
					q: n,
					r: i,
					level: 1,
					cells: o
				});
				continue;
			}
			let s = M(e, t) + 1;
			s < 2 || o.every((t) => M(e, t) === s - 1) && new Set(o.map((t) => N(e, t).tile)).size >= 2 && r({
				rot: a,
				q: n,
				r: i,
				level: s,
				cells: o
			});
		}
	}
	return t.sort((e, t) => e.level - t.level || e.cells[0].localeCompare(t.cells[0]) || e.rot - t.rot);
}
function I(e, t, n) {
	let r = { ...e }, i = 0;
	return n.cells.forEach((a, o) => {
		n.level > 1 && N(e, a)?.k === "q" && i++, r[a] = [...e[a] ?? [], {
			...t.hexes[o],
			tile: t.id
		}];
	}), {
		city: r,
		gained: i
	};
}
function L(e) {
	let t = new Set(e), n = [];
	for (let r of e) {
		if (!t.delete(r)) continue;
		let e = [r];
		for (let n = 0; n < e.length; n++) for (let r of j(e[n])) t.delete(r) && e.push(r);
		n.push(e);
	}
	return n;
}
function R(e, t, n) {
	let r = Object.entries(e).filter(([, e]) => {
		let t = e.at(-1);
		return t.k === "d" && t.c === n;
	}), i = (t) => M(e, t);
	if (n === "house") {
		let e = 0;
		for (let n of L(r.map(([e]) => e))) {
			let r = n.reduce((e, t) => e + i(t), 0);
			t.house && r >= 10 && (r *= 2), e = Math.max(e, r);
		}
		return e;
	}
	let a = 0;
	for (let [o] of r) {
		let r = i(o), s = j(o);
		if (n === "market") {
			if (s.some((t) => {
				let n = N(e, t);
				return n?.k === "d" && n.c === "market";
			})) continue;
			let n = s.some((t) => {
				let n = N(e, t);
				return n?.k === "p" && n.c === "market";
			});
			a += r * (t.market && n ? 2 : 1);
		} else if (n === "barracks") {
			let n = s.filter((t) => M(e, t) === 0).length;
			if (n === 0) continue;
			a += r * (t.barracks && (n === 3 || n === 4) ? 2 : 1);
		} else if (n === "temple") {
			if (!s.every((t) => M(e, t) > 0)) continue;
			a += r * (t.temple && r > 1 ? 2 : 1);
		} else {
			let n = s.some((t) => M(e, t) === 0 && j(t).every((t) => M(e, t) > 0));
			a += r * (t.garden && n ? 2 : 1);
		}
	}
	return a;
}
function z(e, t, n) {
	let r = x.map((t) => {
		let r = Object.entries(e).reduce((e, [, n]) => {
			let r = n.at(-1);
			return e + (r.k === "p" && r.c === t ? S[t] : 0);
		}, 0), i = r > 0 ? R(e, n, t) : 0;
		return {
			color: t,
			value: i,
			stars: r,
			points: i * r
		};
	});
	return {
		entries: r,
		stones: t,
		total: r.reduce((e, t) => e + t.points, 0) + t
	};
}
var B = (e) => b[e], V = {
	id: "acropolis",
	uuid: "3029e6ae-80c0-48f4-8e80-f75aa207efdd",
	tier: "alpha",
	mechanics: ["tile-placement", "drafting"],
	interactionTags: [],
	nameKey: "games.acropolis.name",
	descKey: "games.acropolis.desc",
	rulesKey: "games.acropolis.rules",
	icon: "🏛️",
	iconImg: "games/acropolis.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#b4552d",
	releasedAt: "2026-11-22T22:40:00+08:00",
	search: {
		py: "ya dian wei cheng",
		init: "ydwc"
	},
	hotseat: "open",
	rulesUrl: { en: "https://content.cmpl.org/bg/Akropolis.pdf" }
}, H = t.enum([
	"house",
	"market",
	"barracks",
	"temple",
	"garden"
]), U = t.discriminatedUnion("k", [
	t.object({ k: t.literal("q") }),
	t.object({
		k: t.literal("p"),
		c: H
	}),
	t.object({
		k: t.literal("d"),
		c: H
	})
]), W = t.object({
	id: t.int().min(0).max(60),
	hexes: t.array(U).length(3)
}), G = t.object({
	house: t.boolean().default(!1),
	market: t.boolean().default(!1),
	barracks: t.boolean().default(!1),
	temple: t.boolean().default(!1),
	garden: t.boolean().default(!1)
}).default({
	house: !1,
	market: !1,
	barracks: !1,
	temple: !1,
	garden: !1
}), ne = t.string().regex(/^-?\d+,-?\d+$/).max(12), re = t.discriminatedUnion("type", [t.object({
	type: t.literal("take"),
	index: t.int().min(0).max(7)
}), t.object({
	type: t.literal("place"),
	rot: t.int().min(0).max(5),
	q: t.int().min(-24).max(24),
	r: t.int().min(-24).max(24)
})]), ie = t.object({
	k: t.enum([
		"q",
		"p",
		"d"
	]),
	c: H.optional(),
	tile: t.int().min(-1).max(60)
}), ae = t.object({
	entries: t.array(t.object({
		color: H,
		value: t.number().min(0),
		stars: t.int().min(0),
		points: t.number().min(0)
	})),
	stones: t.int().min(0),
	total: t.number().min(0)
}), oe = t.object({
	rid: t.string(),
	kind: t.enum(["take", "place"]),
	tile: t.int().optional(),
	index: t.int().optional(),
	level: t.int().optional(),
	gained: t.int().optional()
}), se = t.object({
	phase: t.enum(["play", "done"]),
	config: G,
	current: t.string(),
	chief: t.string(),
	round: t.int().min(1),
	players: t.array(t.object({
		rid: t.string(),
		stones: t.int().min(0),
		city: t.record(ne, t.array(ie).min(1).max(32)),
		score: ae
	})).min(2).max(4),
	site: t.array(W).min(0).max(8),
	stacks: t.int().min(0),
	pending: W.nullable(),
	lastPlacement: t.object({
		rid: t.string(),
		cells: t.array(ne).length(3),
		level: t.int().min(1),
		serial: t.int().min(0)
	}).nullable(),
	log: t.array(oe).max(40)
}), ce = t.object({}), le = (e) => e === 4 ? 5 : e === 3 ? 4 : 3;
function ue(t, n, r) {
	let i = n.length, a = Array.from({ length: y[i] }, (e, t) => t), o = 0;
	for (let t = a.length - 1; t > 0; t--) {
		let n = e(r, o++, t + 1);
		[a[t], a[n]] = [a[n], a[t]];
	}
	let s = le(i), c = [];
	for (let e = 0; e < 11; e++) c.push(a.splice(0, s));
	let l = {
		phase: "play",
		config: t,
		players: [...n],
		cities: {},
		stones: {},
		site: a,
		stacks: c,
		current: 0,
		chief: 0,
		round: 1,
		pending: null,
		serial: 0,
		lastPlacement: null,
		log: []
	};
	return n.forEach((e, t) => {
		l.cities[e] = ee(), l.stones[e] = t + 1;
	}), { state: l };
}
var de = () => ({ code: "games.acropolis.invalid" });
function fe(e, t, { by: n }) {
	if (e.phase !== "play" || e.players[e.current] !== n) return { code: "games.acropolis.notYourTurn" };
	let r = structuredClone(e);
	if (t.type === "take") {
		if (r.pending !== null || t.index >= r.site.length) return de();
		let e = t.index;
		if (r.stones[n] < e) return { code: "games.acropolis.needStones" };
		let i = r.site[t.index];
		r.site.splice(t.index, 1), r.stones[n] -= e, r.pending = i;
		let a = B(i);
		return r.serial++, r.lastPlacement = null, r.log.push({
			rid: n,
			kind: "take",
			tile: i,
			index: t.index
		}), {
			state: r,
			fx: [{
				kind: "take",
				rid: n,
				data: {
					tile: i,
					index: t.index,
					hexes: a.hexes
				}
			}]
		};
	}
	if (r.pending === null) return de();
	let i = B(r.pending), a = r.cities[n], o = F(a).find((e) => e.rot === t.rot && e.q === t.q && e.r === t.r);
	if (!o) return { code: "games.acropolis.illegalPlace" };
	let s = I(a, i, o);
	r.cities[n] = s.city, r.stones[n] += s.gained, r.serial++, r.pending = null, r.lastPlacement = {
		rid: n,
		cells: o.cells,
		level: o.level,
		serial: r.serial
	}, r.log.push({
		rid: n,
		kind: "place",
		tile: i.id,
		level: o.level,
		gained: s.gained
	});
	let c = [{
		kind: "place",
		rid: n,
		data: {
			tile: i.id,
			cells: o.cells,
			level: o.level,
			gained: s.gained,
			rot: o.rot
		}
	}];
	if (r.site.length === 1) {
		if (r.stacks.length > 0) {
			let e = r.stacks.pop();
			r.site = [r.site[0], ...e], r.chief = (r.chief + 1) % r.players.length, r.current = r.chief, r.round++, c.push({
				kind: "refill",
				rid: n,
				data: { count: r.site.length }
			});
		} else r.phase = "done";
	} else r.current = (r.current + 1) % r.players.length;
	return r.log.length > 80 && (r.log = r.log.slice(-60)), {
		state: r,
		fx: c
	};
}
function pe(e) {
	let t = e.players.map((t) => ({
		rid: t,
		stones: e.stones[t],
		city: structuredClone(e.cities[t]),
		score: z(e.cities[t], e.stones[t], e.config)
	}));
	return {
		public: {
			phase: e.phase,
			config: e.config,
			current: e.phase === "done" ? "" : e.players[e.current],
			chief: e.players[e.chief],
			round: e.round,
			players: t,
			site: e.site.map((e) => B(e)),
			stacks: e.stacks.length,
			pending: e.pending === null ? null : B(e.pending),
			lastPlacement: e.lastPlacement ? { ...e.lastPlacement } : null,
			log: e.log.slice(-30).map((e) => ({ ...e }))
		},
		private: {}
	};
}
var me = {
	saveCompatibility: { version: "1" },
	meta: V,
	schemas: {
		action: re,
		publicView: se,
		privateView: ce,
		config: G
	},
	setup: ue,
	reduce: fe,
	viewFor: pe,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, z(e.cities[t], e.stones[t], e.config)])), n = [...e.players].sort((n, r) => t[r].total - t[n].total || e.stones[r] - e.stones[n]), r = t[n[0]];
		return {
			phase: "done",
			ranking: n,
			winner: n.filter((i) => t[i].total === r.total && e.stones[i] === e.stones[n[0]]),
			scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
		};
	}
}, he = "-30.5 -29 61 59.5", K = "#f8f1e0", ge = "#efe4cd", _e = "#6d5a44", ve = "#cdb287", ye = "#a98a5f";
function q(e, t, n) {
	return "M" + Array.from({ length: 6 }, (r, i) => {
		let a = Math.PI / 180 * (60 * i - 30);
		return `${(e + n * Math.cos(a)).toFixed(2)} ${(t + n * Math.sin(a)).toFixed(2)}`;
	}).join(" L") + " Z";
}
function be({ children: e, r: t }) {
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("g", {
		transform: `translate(0 ${(t * .055).toFixed(2)})`,
		fill: "#3c2f20",
		opacity: ".22",
		children: e
	}), /* @__PURE__ */ m("g", {
		fill: "#fffaf0",
		children: e
	})] });
}
function xe({ c: e }) {
	return /* @__PURE__ */ h("g", {
		fill: e,
		children: [
			/* @__PURE__ */ m("path", { d: "M-7 3 L-7 -3 L-2.6 -6.6 L1.8 -3 L1.8 3 Z" }),
			/* @__PURE__ */ m("path", {
				d: "M.6 3 L.6 -1.4 L4.4 -4.6 L8.2 -1.4 L8.2 3 Z",
				opacity: ".9"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-8",
				y: "3.2",
				width: "16.4",
				height: "1.6",
				rx: ".5"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-4.4",
				y: "-1",
				width: "1.6",
				height: "3.2",
				fill: "#000",
				opacity: ".16"
			}),
			/* @__PURE__ */ m("rect", {
				x: "4.6",
				y: "0",
				width: "1.5",
				height: "2.6",
				fill: "#000",
				opacity: ".16"
			})
		]
	});
}
function Se({ c: e }) {
	return /* @__PURE__ */ h("g", {
		fill: e,
		children: [
			/* @__PURE__ */ m("path", { d: "M-8 -7 L8 -7 L10 -2 L-10 -2 Z" }),
			/* @__PURE__ */ m("path", {
				d: "M-7.4 -1 L7.4 -1 L7.4 6.4 L-7.4 6.4 Z",
				opacity: ".55"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-8 -7 L-5.2 -2 L-2.4 -7 Z M-.8 -7 L2 -2 L4.8 -7 Z M6.4 -7 L9.2 -2 L10 -7 Z",
				fill: "#fffaf0",
				opacity: ".9"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-1.2",
				y: ".8",
				width: "2.4",
				height: "5.6",
				fill: "#fffaf0",
				opacity: ".78"
			})
		]
	});
}
function Ce({ c: e }) {
	return /* @__PURE__ */ h("g", {
		fill: e,
		children: [
			/* @__PURE__ */ m("path", { d: "M-8 6.4 L-8 -2.4 L-5.4 -2.4 L-5.4 -4.8 L-2.4 -4.8 L-2.4 -2.4 L1.6 -2.4 L1.6 -4.8 L4.6 -4.8 L4.6 -2.4 L8 -2.4 L8 6.4 Z" }),
			/* @__PURE__ */ m("path", {
				d: "M-1.8 6.4 L-1.8 1.2 L1.8 1.2 L1.8 6.4 Z",
				fill: "#fffaf0",
				opacity: ".8"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-8 6.4 L8 6.4 L8 7.6 L-8 7.6 Z",
				opacity: ".4"
			})
		]
	});
}
function we({ c: e }) {
	return /* @__PURE__ */ h("g", {
		fill: e,
		children: [
			/* @__PURE__ */ m("path", { d: "M-9 -3.2 L0 -8.6 L9 -3.2 Z" }),
			/* @__PURE__ */ m("rect", {
				x: "-9",
				y: "-2.6",
				width: "18",
				height: "1.7"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-7.6",
				y: "-.4",
				width: "1.9",
				height: "5.8"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-1",
				y: "-.4",
				width: "1.9",
				height: "5.8"
			}),
			/* @__PURE__ */ m("rect", {
				x: "5.7",
				y: "-.4",
				width: "1.9",
				height: "5.8"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-9.4",
				y: "5.6",
				width: "18.8",
				height: "1.8"
			}),
			/* @__PURE__ */ m("rect", {
				x: "-9.4",
				y: "7.4",
				width: "18.8",
				height: "1",
				opacity: ".35"
			})
		]
	});
}
function Te({ c: e }) {
	return /* @__PURE__ */ h("g", {
		fill: e,
		children: [
			/* @__PURE__ */ m("path", { d: "M-.9 7.4 L.9 7.4 L1.4 1 L-1.4 1 Z" }),
			/* @__PURE__ */ m("circle", {
				cx: "0",
				cy: "-4.6",
				r: "5.2"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "-4.9",
				cy: "2",
				r: "3.2",
				opacity: ".86"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "4.9",
				cy: "2",
				r: "3.2",
				opacity: ".86"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "-2.6",
				cy: "-6.6",
				r: "2.2",
				fill: "#fffaf0",
				opacity: ".25"
			})
		]
	});
}
function Ee() {
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: "M-7.6 6.6 L-6.4 -3.6 L-2.6 -1.2 L0 -6.2 L3.2 -1.4 L6.6 -3.8 L7.6 6.6 Z",
			fill: "#d9cfba"
		}),
		/* @__PURE__ */ m("path", {
			d: "M-6.6 6 L-5.8 -.2 L-2.8 2 L-1.4 -2.4 L1.4 1.6 L3.2 -1 L6.2 -.4 L6.6 6 Z",
			fill: "#9a907d"
		}),
		/* @__PURE__ */ m("path", {
			d: "M-5.8 -.2 L-2.8 2 L-1.4 -2.4 L-3.4 -.8 Z",
			fill: "#c3b9a5"
		}),
		/* @__PURE__ */ m("path", {
			d: "M1.4 1.6 L3.2 -1 L6.2 -.4 L4.4 2.6 Z",
			fill: "#7f7563"
		}),
		/* @__PURE__ */ m("path", {
			d: "M-5.2 5.2 L-2.6 3.8 L.2 5.4 L2.8 3.6 L5.4 5.2 L5.4 6.6 L-5.2 6.6 Z",
			fill: "#6f6554",
			opacity: ".55"
		}),
		/* @__PURE__ */ m("path", {
			d: "M-5.8 4.4 L2.4 -3.4",
			stroke: "#5c3d22",
			strokeWidth: "1.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ m("path", {
			d: "M1.2 -4.6 C2.6 -5.4 4.4 -5.2 5.6 -4.2 L4.6 -3.1 C3.8 -3.8 2.8 -3.8 2 -3.2 Z",
			fill: "#8f8b80"
		}),
		/* @__PURE__ */ m("path", {
			d: "M1.2 -4.6 C2.6 -5.4 4.4 -5.2 5.6 -4.2",
			fill: "none",
			stroke: "#5f5b52",
			strokeWidth: ".45"
		})
	] });
}
function De({ x: e, y: t, r: n = 1.5, c: r = "#fff0b8" }) {
	let i = Array.from({ length: 10 }, (r, i) => {
		let a = -Math.PI / 2 + i * Math.PI / 5, o = i % 2 == 0 ? n : n * .44;
		return `${(e + o * Math.cos(a)).toFixed(2)},${(t + o * Math.sin(a)).toFixed(2)}`;
	}).join(" ");
	return /* @__PURE__ */ m("polygon", {
		points: i,
		fill: r,
		stroke: "#8a6418",
		strokeWidth: ".4"
	});
}
function Oe({ color: e, stars: t, r: n = 11 }) {
	let r = n * .66, i = t === 1 ? [[0, 0]] : t === 2 ? [[-r * .42, 0], [r * .42, 0]] : [
		[-r * .5, r * .16],
		[0, -r * .44],
		[r * .5, r * .16]
	], a = t === 1 ? r * .56 : r * .38;
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("circle", {
			r,
			fill: C[e],
			stroke: "#fff8e8",
			strokeWidth: n * .11
		}),
		/* @__PURE__ */ m("circle", {
			r: r * .86,
			fill: "none",
			stroke: w[e],
			strokeWidth: n * .035,
			opacity: ".55"
		}),
		i.map(([e, t], n) => /* @__PURE__ */ m(De, {
			x: e,
			y: t,
			r: a
		}, n))
	] });
}
function ke({ r: e = 11, depth: t = 2.4 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
		d: q(0, t, e),
		fill: ye
	}), /* @__PURE__ */ m("path", {
		d: q(0, 0, e),
		fill: ve
	})] });
}
function Ae({ r: e }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
		d: q(0, -e * .03, e * .93),
		fill: "none",
		stroke: "#fffdf4",
		strokeWidth: e * .045,
		opacity: ".7"
	}), /* @__PURE__ */ m("path", {
		d: q(0, e * .04, e * .97),
		fill: "none",
		stroke: "#9c825e",
		strokeWidth: e * .05,
		opacity: ".26"
	})] });
}
function je({ hex: e, r: t = 11 }) {
	let n = t * .86;
	if (e.k === "q") return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: q(0, 0, t),
			fill: K,
			stroke: _e,
			strokeWidth: t * .07
		}),
		/* @__PURE__ */ m(Ae, { r: t }),
		/* @__PURE__ */ m("path", {
			d: q(0, 0, n),
			fill: ge,
			stroke: "#d8cbb2",
			strokeWidth: t * .035
		}),
		/* @__PURE__ */ m("g", {
			transform: `scale(${(t / 11).toFixed(3)})`,
			children: /* @__PURE__ */ m(Ee, {})
		})
	] });
	if (e.k === "p") return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: q(0, 0, t),
			fill: K,
			stroke: _e,
			strokeWidth: t * .07
		}),
		/* @__PURE__ */ m(Ae, { r: t }),
		/* @__PURE__ */ m(Oe, {
			color: e.c,
			stars: e.c === "house" ? 1 : e.c === "garden" ? 3 : 2,
			r: t
		})
	] });
	let r = C[e.c], i = e.c === "house" ? /* @__PURE__ */ m(xe, {}) : e.c === "market" ? /* @__PURE__ */ m(Se, {}) : e.c === "barracks" ? /* @__PURE__ */ m(Ce, {}) : e.c === "temple" ? /* @__PURE__ */ m(we, {}) : /* @__PURE__ */ m(Te, {});
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("path", {
			d: q(0, 0, t),
			fill: K,
			stroke: _e,
			strokeWidth: t * .07
		}),
		/* @__PURE__ */ m(Ae, { r: t }),
		/* @__PURE__ */ m("path", {
			d: q(0, 0, n),
			fill: r
		}),
		/* @__PURE__ */ m("path", {
			d: q(0, 0, n),
			fill: "none",
			stroke: "#fff6e2",
			strokeWidth: t * .1
		}),
		/* @__PURE__ */ m("path", {
			d: q(0, 0, n * .78),
			fill: "none",
			stroke: w[e.c],
			strokeWidth: t * .022,
			opacity: ".45"
		}),
		/* @__PURE__ */ m("g", {
			transform: `scale(${(t / 11 * 1.02).toFixed(3)})`,
			children: /* @__PURE__ */ m(be, {
				r: t,
				children: i
			})
		})
	] });
}
function Me({ hex: e, r: t = 10 }) {
	return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m(ke, {
		r: t,
		depth: t * .3
	}), /* @__PURE__ */ m(je, {
		hex: e,
		r: t
	})] });
}
var Ne = [
	[0, 0],
	[1, 0],
	[0, 1]
], Pe = (e, t) => [-t, e + t];
function Fe({ hexes: e, size: t, className: n, highlight: r, rot: i = 0, alt: a }) {
	let o = Ne;
	for (let e = 0; e < (i % 6 + 6) % 6; e++) o = o.map(([e, t]) => Pe(e, t));
	let s = o.map(([e, t]) => [Math.sqrt(3) * 11 * (e + t / 2), 16.5 * t]);
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: he,
		className: `acropolis-face${r ? " is-highlight" : ""}${n ? ` ${n}` : ""}`,
		role: a ? "img" : void 0,
		"aria-label": a,
		"aria-hidden": !a || void 0,
		children: [
			e.map((e, t) => /* @__PURE__ */ m("g", {
				transform: `translate(${s[t][0]} ${s[t][1]})`,
				children: /* @__PURE__ */ m(ke, { r: 11 })
			}, `s${t}`)),
			e.map((e, t) => /* @__PURE__ */ m("g", {
				transform: `translate(${s[t][0]} ${s[t][1]})`,
				children: /* @__PURE__ */ m(je, {
					hex: e,
					r: 11
				})
			}, `t${t}`)),
			r && /* @__PURE__ */ m("path", {
				d: q(s[0][0], s[0][1], 11.22),
				fill: "none",
				stroke: "rgba(201,162,74,.9)",
				strokeWidth: "1.6"
			})
		]
	});
}
function J({ size: e = 14 }) {
	return /* @__PURE__ */ h("svg", {
		width: e,
		height: e,
		viewBox: "0 0 18 18",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M2 6 L9 2.4 L16 6 L16 12.4 L9 16 L2 12.4 Z",
				fill: "#c9c0ae",
				stroke: "#6b5a44",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ m("path", {
				d: "M2 6 L9 9.6 L16 6 L16 12.4 L9 16 L2 12.4 Z",
				fill: "#b4a992"
			}),
			/* @__PURE__ */ m("path", {
				d: "M2 6 L9 9.6 L9 16 L2 12.4 Z",
				fill: "#9c907a",
				opacity: ".65"
			}),
			/* @__PURE__ */ m("path", {
				d: "M9 9.6 L16 6",
				fill: "none",
				stroke: "#6b5a44",
				strokeWidth: ".9",
				opacity: ".6"
			})
		]
	});
}
function Ie({ size: e = 20 }) {
	return /* @__PURE__ */ h("svg", {
		width: e,
		height: e,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("circle", {
				cx: "12",
				cy: "12",
				r: "10.2",
				fill: "#f4e6c6",
				stroke: "#8a6a32",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "12",
				cy: "12",
				r: "8",
				fill: "none",
				stroke: "#c9a24a",
				strokeWidth: ".9",
				opacity: ".85"
			}),
			/* @__PURE__ */ m("path", {
				d: "M6.4 15.6 L8 8.6 L12 12 L16 8.6 L17.6 15.6 Z",
				fill: "#b4552d"
			}),
			/* @__PURE__ */ m("path", {
				d: "M9.2 15.6 L10.4 10.8 L12 12.4 L13.6 10.8 L14.8 15.6 Z",
				fill: "#f4e6c6",
				opacity: ".65"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "12",
				cy: "7.1",
				r: "1.4",
				fill: "#c9a24a"
			}),
			/* @__PURE__ */ m("path", {
				d: "M5.4 17.6 C8 19.4 16 19.4 18.6 17.6",
				fill: "none",
				stroke: "#8a6a32",
				strokeWidth: ".9"
			})
		]
	});
}
function Le({ size: e = 48, className: t }) {
	return /* @__PURE__ */ h("svg", {
		width: e,
		height: e,
		viewBox: "0 0 48 48",
		className: t,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("g", {
				fill: "none",
				stroke: "#c9a24a",
				strokeWidth: "1.6",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ m("path", { d: "M24 41 C13 37 8 28 10 17 C11 12 14 8 17 6" }), /* @__PURE__ */ m("path", { d: "M24 41 C35 37 40 28 38 17 C37 12 34 8 31 6" })]
			}),
			/* @__PURE__ */ h("g", {
				fill: "#c9a24a",
				children: [[
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ m("ellipse", {
					cx: 10.6 + e * .4,
					cy: 15 + e * 4.4,
					rx: "3.1",
					ry: "1.5",
					transform: `rotate(${-48 + e * 6} ${10.6 + e * .4} ${15 + e * 4.4})`
				}, `l${e}`)), [
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ m("ellipse", {
					cx: 37.4 - e * .4,
					cy: 15 + e * 4.4,
					rx: "3.1",
					ry: "1.5",
					transform: `rotate(${48 - e * 6} ${37.4 - e * .4} ${15 + e * 4.4})`
				}, `r${e}`))]
			}),
			/* @__PURE__ */ m("circle", {
				cx: "24",
				cy: "5.4",
				r: "2",
				fill: "#c9a24a"
			})
		]
	});
}
//#endregion
//#region src/game/board-view.tsx
var Y = 30, Re = Y * .66, ze = Math.sqrt(3), X = (e, t) => ze * Y * (e + t / 2), Z = (e) => 1.5 * Y * e, Q = (e, t) => Z(e) - (t - 1) * Re;
function Be(e, t) {
	let [n, r] = k(e);
	return {
		x: X(n, r),
		y: Q(r, t)
	};
}
function Ve(e, t, n, r, i) {
	return `M${e + i} ${t} H${n - i} L${n} ${t + i} V${r - i} L${n - i} ${r} H${e + i} L${e} ${r - i} V${t + i} Z`;
}
function He({ city: e, levelMarkers: t, onPlace: o, last: s, serial: c, compact: l = !1, fill: u = !1, placeLabel: d, label: f }) {
	let p = r().replace(/[^a-zA-Z0-9_-]/g, ""), g = i(null), [_, v] = a(0);
	n(() => {
		if (!u) return;
		let e = g.current;
		if (!e) return;
		let t = () => {
			let t = e.clientWidth, n = e.clientHeight;
			t > 0 && n > 0 && v(t / n);
		};
		t();
		let n = new ResizeObserver(t);
		return n.observe(e), () => n.disconnect();
	}, [u]);
	let y = Object.entries(e).filter(([, e]) => e.length > 0), b = [], x = Infinity, S = -Infinity, C = Infinity, w = -Infinity;
	for (let [e, t] of y) {
		let [n, r] = k(e), i = X(n, r), a = Z(r);
		x = Math.min(x, i - Y), S = Math.max(S, i + Y), C = Math.min(C, Q(r, t.length) - Y), w = Math.max(w, a + Y), t.forEach((t, n) => b.push({
			key: e,
			level: n + 1,
			hex: t
		}));
	}
	for (let e of t ?? []) for (let t of e.cells) {
		let [n, r] = k(t);
		x = Math.min(x, X(n, r) - Y), S = Math.max(S, X(n, r) + Y), C = Math.min(C, Q(r, e.level) - Y), w = Math.max(w, Q(r, e.level) + Y);
	}
	Number.isFinite(x) || (x = -30, S = Y, C = -30, w = Y);
	let T = Y * .5;
	x -= T, S += T, C -= T, w += T;
	let E = u && _ > 1.3 ? (w - C) * .17 : 0, D = x, A = S, j = C - E, M = w;
	if (u && _ > 0) {
		let e = Math.min(3.2, Math.max(1, _)), t = M - j;
		if ((S - x) / t < e) {
			let n = (e * t - (S - x)) / 2;
			D -= n, A += n;
		}
	}
	let N = Math.max(A - D, 1), ee = Math.max(M - j, 1), te = (e, t) => !!s && s.level === t && s.cells.includes(e), P = D + Y * .18, F = C + Y * .12, I = A - Y * .18, L = M - Y * .42, R = Math.min(Y * .62, N * .08), z = Ve(P, F, I, L, R), B = Ve(P + 5, F + 5, I - 5, L - 5, Math.max(R * .6, 4)), V = (P + I) / 2, H = (e, t, n, r) => /* @__PURE__ */ h("g", {
		opacity: ".85",
		children: [
			/* @__PURE__ */ m("ellipse", {
				cx: e,
				cy: t,
				rx: 7 * n,
				ry: 4.6 * n,
				fill: "#6d7c41"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: e - 5 * n,
				cy: t + 1 * n,
				rx: 4.6 * n,
				ry: 3.6 * n,
				fill: "#7b8a4a"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: e + 5 * n,
				cy: t + 1.4 * n,
				rx: 4.6 * n,
				ry: 3.6 * n,
				fill: "#5f6e39"
			})
		]
	}, r), U = (e, t, n, r) => /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-9 0 L0 -6 L9 0 L9 10 L0 16 L-9 10 Z",
				fill: "#cdbd9c",
				stroke: "#7b6a52",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-9 0 L0 6 L9 0",
				fill: "none",
				stroke: "#7b6a52",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 6 L0 16",
				fill: "none",
				stroke: "#7b6a52",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-9 0 L0 -6 L9 0 L0 6 Z",
				fill: "#ece1c6",
				stroke: "#7b6a52",
				strokeWidth: "1"
			})
		]
	}, r), W = (e, t, n, r) => /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: "#6d5836",
		fill: "none",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M-16 34 L0 -10 L16 34",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ m("path", {
				d: "M-16 34 H16",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ m("circle", {
				cx: "0",
				cy: "10",
				r: "18",
				strokeWidth: "2.4",
				fill: "rgba(214,197,164,.35)"
			}),
			/* @__PURE__ */ h("g", {
				strokeWidth: "1.1",
				opacity: ".75",
				children: [
					/* @__PURE__ */ m("path", { d: "M0 -8 V28" }),
					/* @__PURE__ */ m("path", { d: "M-18 10 H18" }),
					/* @__PURE__ */ m("path", { d: "M-13 -3 L13 23" }),
					/* @__PURE__ */ m("path", { d: "M13 -3 L-13 23" })
				]
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 -10 L26 -34",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ m("path", {
				d: "M26 -34 V-12",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ m("rect", {
				x: "20",
				y: "-12",
				width: "12",
				height: "10",
				fill: "#cdbd9c",
				stroke: "#6d5836",
				strokeWidth: "1"
			})
		]
	}, r), G = b.sort((e, t) => e.level - t.level || Z(k(e.key)[1]) - Z(k(t.key)[1]) || X(k(e.key)[0], k(e.key)[1]) - X(k(t.key)[0], k(t.key)[1]));
	return /* @__PURE__ */ h("svg", {
		ref: g,
		className: `acropolis-board${l ? " is-compact" : ""}`,
		viewBox: `${D.toFixed(1)} ${j.toFixed(1)} ${N.toFixed(1)} ${ee.toFixed(1)}`,
		preserveAspectRatio: u ? "xMidYMax meet" : "xMidYMid meet",
		role: "img",
		"aria-label": f,
		children: [
			/* @__PURE__ */ h("defs", { children: [
				/* @__PURE__ */ h("linearGradient", {
					id: `acr-slab-${p}`,
					x1: "0",
					y1: "0",
					x2: ".55",
					y2: "1",
					children: [
						/* @__PURE__ */ m("stop", {
							offset: "0",
							stopColor: "#f6eedb"
						}),
						/* @__PURE__ */ m("stop", {
							offset: ".55",
							stopColor: "#ece1c8"
						}),
						/* @__PURE__ */ m("stop", {
							offset: "1",
							stopColor: "#dccbad"
						})
					]
				}),
				/* @__PURE__ */ h("linearGradient", {
					id: `acr-edge-${p}`,
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [/* @__PURE__ */ m("stop", {
						offset: "0",
						stopColor: "#cfc1a8"
					}), /* @__PURE__ */ m("stop", {
						offset: "1",
						stopColor: "#a8987c"
					})]
				}),
				/* @__PURE__ */ h("linearGradient", {
					id: `acr-sky-${p}`,
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [
						/* @__PURE__ */ m("stop", {
							offset: "0",
							stopColor: "#9fcde4"
						}),
						/* @__PURE__ */ m("stop", {
							offset: ".58",
							stopColor: "#cbe3ec"
						}),
						/* @__PURE__ */ m("stop", {
							offset: "1",
							stopColor: "#eef3e4"
						})
					]
				}),
				/* @__PURE__ */ h("radialGradient", {
					id: `acr-cast-${p}`,
					children: [
						/* @__PURE__ */ m("stop", {
							offset: "0",
							stopColor: "#3c2a17",
							stopOpacity: ".32"
						}),
						/* @__PURE__ */ m("stop", {
							offset: ".65",
							stopColor: "#3c2a17",
							stopOpacity: ".13"
						}),
						/* @__PURE__ */ m("stop", {
							offset: "1",
							stopColor: "#3c2a17",
							stopOpacity: "0"
						})
					]
				}),
				/* @__PURE__ */ h("pattern", {
					id: `acr-grain-${p}`,
					width: "10",
					height: "10",
					patternUnits: "userSpaceOnUse",
					children: [
						/* @__PURE__ */ m("circle", {
							cx: "1.6",
							cy: "2.2",
							r: ".5",
							fill: "#9c8763",
							opacity: ".55"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "6.2",
							cy: "5.4",
							r: ".42",
							fill: "#fffaf0",
							opacity: ".6"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "7.8",
							cy: "1.2",
							r: ".34",
							fill: "#9c8763",
							opacity: ".4"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "3.4",
							cy: "8",
							r: ".34",
							fill: "#9c8763",
							opacity: ".35"
						})
					]
				}),
				/* @__PURE__ */ h("radialGradient", {
					id: `acr-contact-${p}`,
					children: [
						/* @__PURE__ */ m("stop", {
							offset: "0",
							stopColor: "#46301a",
							stopOpacity: ".24"
						}),
						/* @__PURE__ */ m("stop", {
							offset: ".7",
							stopColor: "#46301a",
							stopOpacity: ".08"
						}),
						/* @__PURE__ */ m("stop", {
							offset: "1",
							stopColor: "#46301a",
							stopOpacity: "0"
						})
					]
				})
			] }),
			E > 0 && /* @__PURE__ */ h("g", {
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ m("rect", {
						x: D,
						y: j,
						width: N,
						height: F - j + 2,
						fill: `url(#acr-sky-${p})`
					}),
					/* @__PURE__ */ m("ellipse", {
						cx: A - N * .14,
						cy: j + E * .5,
						rx: Y * 1.9,
						ry: Y * 1.9,
						fill: "#fdf1cf",
						opacity: ".35"
					}),
					/* @__PURE__ */ m("circle", {
						cx: A - N * .14,
						cy: j + E * .5,
						r: Y * .8,
						fill: "#f9e9b6"
					}),
					/* @__PURE__ */ m("path", {
						d: `M${D} ${F + 2} V${F - E * .44} Q ${D + N * .22} ${F - E * .66} ${D + N * .44} ${F - E * .36} T ${A} ${F - E * .52} V${F + 2} Z`,
						fill: "#8ba877"
					}),
					/* @__PURE__ */ m("path", {
						d: `M${D} ${F + 2} V${F - E * .2} Q ${D + N * .3} ${F - E * .42} ${D + N * .58} ${F - E * .14} T ${A} ${F - E * .28} V${F + 2} Z`,
						fill: "#6f8f5e"
					}),
					/* @__PURE__ */ h("g", {
						transform: `translate(${A - N * .3} ${F - E * .5}) scale(${Y / 30})`,
						fill: "#efe8d7",
						opacity: ".92",
						children: [
							/* @__PURE__ */ m("path", { d: "M-17 0 L0 -9 L17 0 Z" }),
							/* @__PURE__ */ m("rect", {
								x: "-15",
								y: "0",
								width: "30",
								height: "4"
							}),
							/* @__PURE__ */ m("rect", {
								x: "-12",
								y: "4",
								width: "3",
								height: "8"
							}),
							/* @__PURE__ */ m("rect", {
								x: "-6",
								y: "4",
								width: "3",
								height: "8"
							}),
							/* @__PURE__ */ m("rect", {
								x: "0",
								y: "4",
								width: "3",
								height: "8"
							}),
							/* @__PURE__ */ m("rect", {
								x: "6",
								y: "4",
								width: "3",
								height: "8"
							}),
							/* @__PURE__ */ m("rect", {
								x: "11",
								y: "4",
								width: "3",
								height: "8"
							}),
							/* @__PURE__ */ m("rect", {
								x: "-15",
								y: "12",
								width: "30",
								height: "3"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: V,
				cy: L + 12,
				rx: (I - P) * .5,
				ry: Y * 1.1,
				fill: `url(#acr-cast-${p})`
			}),
			/* @__PURE__ */ m("path", {
				d: z,
				transform: "translate(0 17)",
				fill: "#86643f",
				opacity: ".32"
			}),
			/* @__PURE__ */ m("path", {
				d: z,
				transform: "translate(0 9)",
				fill: "#8b7c64"
			}),
			/* @__PURE__ */ m("path", {
				d: z,
				transform: "translate(0 6)",
				fill: `url(#acr-edge-${p})`,
				stroke: "#6d5f4a",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ m("g", {
				stroke: "#5f5343",
				strokeWidth: ".9",
				opacity: ".35",
				children: [
					.14,
					.3,
					.46,
					.62,
					.78,
					.9
				].map((e) => /* @__PURE__ */ m("path", { d: `M${P + (I - P) * e} ${L - 1} V${L + 7}` }, e))
			}),
			/* @__PURE__ */ m("path", {
				d: z,
				fill: `url(#acr-slab-${p})`,
				stroke: "#7b6a52",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ m("path", {
				d: z,
				fill: `url(#acr-grain-${p})`,
				opacity: ".5"
			}),
			/* @__PURE__ */ m("path", {
				d: B,
				fill: "none",
				stroke: "#fff8e6",
				strokeWidth: "1.5",
				opacity: ".5"
			}),
			/* @__PURE__ */ m("path", {
				d: B,
				transform: "translate(0 1.4)",
				fill: "none",
				stroke: "#ab8e62",
				strokeWidth: "1",
				opacity: ".45"
			}),
			/* @__PURE__ */ h("g", {
				opacity: ".12",
				fill: "none",
				stroke: "#a88d67",
				strokeWidth: "1",
				children: [/* @__PURE__ */ m("path", { d: `M${P + R + 12} ${F + (L - F) * .34} C${P + (I - P) * .3} ${F + (L - F) * .2}, ${P + (I - P) * .62} ${F + (L - F) * .46}, ${I - R - 12} ${F + (L - F) * .32}` }), /* @__PURE__ */ m("path", { d: `M${P + R + 12} ${F + (L - F) * .72} C${P + (I - P) * .28} ${F + (L - F) * .6}, ${P + (I - P) * .66} ${F + (L - F) * .84}, ${I - R - 12} ${F + (L - F) * .7}` })]
			}),
			/* @__PURE__ */ h("g", {
				className: "acropolis-bushes",
				children: [H(P + R + 12, L - 10, .78, "b1"), H(I - R - 14, L - 12, .62, "b2")]
			}),
			(x - P > Y * 1.3 || I - S > Y * 1.3) && /* @__PURE__ */ h("g", {
				className: "acropolis-apron",
				children: [x - P > Y * 1.3 && /* @__PURE__ */ h("g", {
					transform: `translate(${(P + x) / 2} 0)`,
					children: [
						/* @__PURE__ */ h("g", {
							transform: `translate(0 ${F + (L - F) * .2})`,
							children: [
								/* @__PURE__ */ m("path", {
									d: `M-45 0 H${Y * 1.5} L${Y * 1.05} ${Y * .85} H-31.5 Z`,
									fill: "#c3b190"
								}),
								/* @__PURE__ */ m("path", {
									d: `M-31.5 ${Y * .28} H${Y * 1.05} L${Y * .72} ${Y * .85} H${-30 * .72} Z`,
									fill: "#a89572"
								}),
								/* @__PURE__ */ m("path", {
									d: `M${-30 * .72} ${Y * .55} H${Y * .72} L${Y * .45} ${Y * .85} H-13.5 Z`,
									fill: "#8a785a"
								})
							]
						}),
						U(-28.5, L - Y * .95, Y / 30 * .7, "lc1"),
						U(-16.5, L - Y * .9, Y / 30 * .7, "lc2"),
						U(-22.5, L - Y * 1.28, Y / 30 * .7, "lc3")
					]
				}), I - S > Y * 1.3 && /* @__PURE__ */ h("g", {
					transform: `translate(${(S + I) / 2} 0)`,
					children: [
						W(0, F + (L - F) * .42, Y / 30 * .9, "crane"),
						U(Y * .82, L - Y * .95, Y / 30 * .7, "rc1"),
						U(Y * 1.16, L - Y * .9, Y / 30 * .7, "rc2")
					]
				})]
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: V,
				cy: L - Y * 1.05,
				rx: (I - P) * .44,
				ry: Y * .8,
				fill: `url(#acr-contact-${p})`
			}),
			G.map(({ key: e, level: t, hex: n }) => {
				let [r, i] = k(e), a = X(r, i), o = Q(i, t);
				return /* @__PURE__ */ m("g", {
					transform: `translate(${a} ${o})`,
					className: "acropolis-cell",
					children: /* @__PURE__ */ h("g", {
						className: te(e, t) ? "acropolis-new-cell" : void 0,
						style: { animationDelay: `${t * 2}ms` },
						children: [t > 1 && /* @__PURE__ */ m("path", {
							d: q(0, Y * .3, Y * 1.05),
							fill: "#3b2d1e",
							opacity: ".14"
						}), /* @__PURE__ */ m(Me, {
							hex: n.k === "q" ? { k: "q" } : n.k === "p" ? {
								k: "p",
								c: n.c
							} : {
								k: "d",
								c: n.c
							},
							r: Y
						})]
					})
				}, `${e}:${t}`);
			}),
			(t ?? []).map((e, t) => {
				let n = Be(e.cells[0], e.level);
				return /* @__PURE__ */ h("g", {
					className: "acropolis-marker",
					role: "button",
					tabIndex: 0,
					onClick: () => o?.(e),
					onKeyDown: (t) => {
						(t.key === "Enter" || t.key === " ") && o?.(e);
					},
					"aria-label": d?.(t) ?? O(e.q, e.r),
					children: [
						e.cells.map((t) => {
							let n = Be(t, e.level);
							return /* @__PURE__ */ m("path", {
								className: "acropolis-marker-outline",
								d: q(n.x, n.y, Y * .9)
							}, t);
						}),
						/* @__PURE__ */ m("circle", {
							className: "acropolis-marker-disc",
							cx: n.x,
							cy: n.y,
							r: Y * .46
						}),
						/* @__PURE__ */ m("path", {
							className: "acropolis-marker-plus",
							d: `M${n.x - Y * .17} ${n.y} H${n.x + Y * .17} M${n.x} ${n.y - Y * .17} V${n.y + Y * .17}`
						})
					]
				}, `${e.rot}:${e.q},${e.r}:${t}`);
			}),
			/* @__PURE__ */ m("g", { className: `acropolis-serial-${c}` })
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
var $ = {
	house: "games.acropolis.house",
	market: "games.acropolis.market",
	barracks: "games.acropolis.barracks",
	temple: "games.acropolis.temple",
	garden: "games.acropolis.garden"
};
function Ue(e) {
	return /* @__PURE__ */ m(We, {
		...e,
		pub: e.public
	});
}
function We({ pub: e, members: t, myRid: n, send: r, readOnly: i = !1 }) {
	s();
	let p = o(), g = e.players.find((e) => e.rid === n), _ = n === e.current && e.phase === "play" && !i, [v, y] = a(n), [b, S] = a(0), w = e.pending?.id ?? -1, [T, E] = a(w);
	w !== T && (E(w), S(0), _ && y(n));
	let D = e.pending && _ ? n : v, O = e.players.find((e) => e.rid === D) ?? e.players[0], k = e.pending && _ && O.rid === n && g ? F(g.city).filter((e) => e.rot === b) : [], A = (n) => {
		let r = t.find((e) => e.rid === n), i = r?.colorIndex ?? Math.max(0, e.players.findIndex((e) => e.rid === n));
		return r?.name || p(f[i % f.length].nameKey);
	}, j = (e) => e === 0 ? p("games.acropolis.free") : e === 1 ? p("games.acropolis.costOne") : p("games.acropolis.cost", { n: e }), M = (e) => e.k === "q" ? p("games.acropolis.quarry") : e.k === "p" ? p("games.acropolis.plazaOf", { color: p($[e.c]) }) : p($[e.c]), N = (e) => e.kind === "take" ? (e.index ?? 0) === 0 ? p("games.acropolis.logTakeFree", {
		name: A(e.rid),
		n: 1
	}) : p("games.acropolis.logTake", {
		name: A(e.rid),
		n: (e.index ?? 0) + 1,
		cost: e.index ?? 0
	}) : p("games.acropolis.logPlace", {
		name: A(e.rid),
		level: e.level ?? 1
	}) + ((e.gained ?? 0) > 0 ? (e.gained ?? 0) === 1 ? p("games.acropolis.logGainOne") : p("games.acropolis.logGain", { n: e.gained ?? 0 }) : ""), ee = e.phase === "done" ? "done" : _ ? "accent" : "info", te = e.phase === "done" ? p("games.acropolis.endTitle") : _ ? e.pending ? p("games.acropolis.yourPlace") : p("games.acropolis.yourTurn") : p("games.acropolis.waiting", { name: A(e.current) }), P = e.phase === "play" ? e.stacks === 1 ? p("games.acropolis.stacksOne") : p("games.acropolis.stacks", { n: e.stacks }) : void 0;
	return /* @__PURE__ */ m(c, {
		adaptive: !0,
		className: "acropolis-screen",
		scroll: !1,
		actionsHeight: "acropolis-actions-h",
		banner: /* @__PURE__ */ h("div", {
			className: "acropolis-banner",
			children: [
				/* @__PURE__ */ m("div", {
					className: "acropolis-frieze",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ m(u, {
					tone: ee,
					text: te,
					sub: P,
					accent: "#b4552d",
					chip: /* @__PURE__ */ m("span", {
						className: "acropolis-chip",
						children: p("games.acropolis.round", { n: e.round })
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "acropolis-seats",
					children: /* @__PURE__ */ m(d, {
						members: t,
						myRid: n,
						variant: "mini",
						adaptive: !0,
						picked: (e) => e === O.rid,
						onPick: (e) => y(e),
						action: (t) => e.phase === "play" && t === e.current && e.pending ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ h("span", {
								className: "acropolis-seat-stat",
								children: [
									/* @__PURE__ */ h("span", {
										className: "acropolis-stone",
										children: [/* @__PURE__ */ m(J, { size: 10 }), n.stones]
									}),
									/* @__PURE__ */ m("span", {
										className: "acropolis-points",
										children: n.score.total
									}),
									t === e.chief && /* @__PURE__ */ m(Ie, { size: 13 })
								]
							}) : null;
						}
					})
				})
			]
		}),
		overlay: /* @__PURE__ */ h("div", {
			className: "acropolis-scorebar",
			children: [/* @__PURE__ */ m("span", {
				className: "acropolis-scorebar-name",
				children: A(O.rid)
			}), /* @__PURE__ */ h("div", {
				className: "acropolis-score-chips",
				children: [O.score.entries.filter((e) => e.stars > 0).map((e) => /* @__PURE__ */ h("span", {
					className: "acropolis-score-chip",
					style: { "--district": C[e.color] },
					title: `${p($[e.color])} ${e.value} × ${e.stars}`,
					"aria-label": `${p($[e.color])} ${e.value} × ${e.stars} = ${e.points}`,
					children: [
						/* @__PURE__ */ m("i", {}),
						e.value,
						/* @__PURE__ */ m("b", { children: "×" }),
						e.stars,
						/* @__PURE__ */ m("b", { children: "=" }),
						e.points
					]
				}, e.color)), /* @__PURE__ */ h("span", {
					className: "acropolis-score-chip is-stone",
					title: p("games.acropolis.stones"),
					children: [
						/* @__PURE__ */ m(J, { size: 11 }),
						O.score.stones,
						/* @__PURE__ */ m("b", { children: "→" }),
						O.score.total
					]
				})]
			})]
		}),
		actions: /* @__PURE__ */ m("div", {
			className: "acropolis-actions",
			children: e.pending ? _ ? /* @__PURE__ */ h("div", {
				className: "acropolis-pending",
				children: [
					/* @__PURE__ */ m("div", {
						className: "acropolis-pedestal",
						children: /* @__PURE__ */ m(Fe, {
							hexes: e.pending.hexes,
							rot: b,
							highlight: !0
						})
					}),
					/* @__PURE__ */ h("div", {
						className: "acropolis-rotate",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => S((b + 5) % 6),
							"aria-label": p("games.acropolis.rotateLeft"),
							children: "↺"
						}), /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => S((b + 1) % 6),
							"aria-label": p("games.acropolis.rotateRight"),
							children: "↻"
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "acropolis-pending-info",
						children: [/* @__PURE__ */ m("strong", { children: p("games.acropolis.pending") }), /* @__PURE__ */ m("span", {
							className: k.length ? "" : "is-warn",
							children: k.length ? k.length === 1 ? p("games.acropolis.placementsOne") : p("games.acropolis.placements", { n: k.length }) : p("games.acropolis.noPlacement")
						})]
					})
				]
			}) : /* @__PURE__ */ h("div", {
				className: "acropolis-pending is-wait",
				children: [/* @__PURE__ */ m("div", {
					className: "acropolis-pedestal is-muted",
					children: /* @__PURE__ */ m(Fe, { hexes: e.pending.hexes })
				}), /* @__PURE__ */ h("div", {
					className: "acropolis-pending-info",
					children: [/* @__PURE__ */ m("strong", { children: p("games.acropolis.pending") }), /* @__PURE__ */ m("span", { children: p("games.acropolis.waiting", { name: A(e.current) }) })]
				})]
			}) : /* @__PURE__ */ h("div", {
				className: "acropolis-site",
				children: [/* @__PURE__ */ h("div", {
					className: "acropolis-site-head",
					children: [/* @__PURE__ */ m("strong", { children: p("games.acropolis.site") }), /* @__PURE__ */ h("span", {
						className: "acropolis-yard-stone",
						children: [/* @__PURE__ */ m(J, { size: 13 }), g?.stones ?? 0]
					})]
				}), /* @__PURE__ */ m("div", {
					className: "acropolis-site-row",
					children: e.site.map((t, n) => {
						let i = !!g && _ && n <= g.stones && !e.pending;
						return /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !i,
							onClick: () => r({
								type: "take",
								index: n
							}),
							className: `acropolis-site-tile${i ? "" : " is-locked"}`,
							"aria-label": `${p("games.acropolis.site")} ${n + 1} · ${j(n)} · ${t.hexes.map(M).join(p("games.acropolis.listSeparator"))}`,
							children: [/* @__PURE__ */ m("span", {
								className: "acropolis-site-face",
								children: /* @__PURE__ */ m(Fe, { hexes: t.hexes })
							}), /* @__PURE__ */ m("span", {
								className: `acropolis-cost${n === 0 ? " is-free" : ""}`,
								children: j(n)
							})]
						}, `${t.id}:${n}`);
					})
				})]
			})
		}),
		children: /* @__PURE__ */ h("div", {
			className: "acropolis-main",
			children: [
				/* @__PURE__ */ h("div", {
					className: "acropolis-scene",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ m("span", { className: "acropolis-sun" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cloud acropolis-cloud-a" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cloud acropolis-cloud-b" }),
						/* @__PURE__ */ m("span", { className: "acropolis-sea" }),
						/* @__PURE__ */ m("span", { className: "acropolis-haze" }),
						/* @__PURE__ */ m("span", { className: "acropolis-island acropolis-island-a" }),
						/* @__PURE__ */ m("span", { className: "acropolis-island acropolis-island-b" }),
						/* @__PURE__ */ m("span", { className: "acropolis-island acropolis-island-c" }),
						/* @__PURE__ */ h("svg", {
							className: "acropolis-birds",
							viewBox: "0 0 120 40",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ m("path", {
									d: "M6 14 q7 -7 14 0 q7 -7 14 0",
									fill: "none",
									stroke: "#4d5a5f",
									strokeWidth: "1.4",
									strokeLinecap: "round"
								}),
								/* @__PURE__ */ m("path", {
									d: "M44 8 q5 -5 10 0 q5 -5 10 0",
									fill: "none",
									stroke: "#4d5a5f",
									strokeWidth: "1.2",
									strokeLinecap: "round"
								}),
								/* @__PURE__ */ m("path", {
									d: "M86 20 q4 -4 8 0 q4 -4 8 0",
									fill: "none",
									stroke: "#4d5a5f",
									strokeWidth: "1.2",
									strokeLinecap: "round"
								})
							]
						}),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-back" }),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-mid" }),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-front" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-a" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-b" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-c" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-d" }),
						/* @__PURE__ */ h("svg", {
							className: "acropolis-temple",
							viewBox: "0 0 240 100",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ m("path", {
								d: "M0 100 L40 72 L78 78 L112 58 L150 66 L186 50 L222 64 L240 58 L240 100 Z",
								fill: "#6f7647"
							}), /* @__PURE__ */ h("g", {
								fill: "#55513a",
								opacity: ".62",
								children: [
									/* @__PURE__ */ m("path", { d: "M150 48 L180 31 L210 48 Z" }),
									/* @__PURE__ */ m("rect", {
										x: "150",
										y: "48",
										width: "60",
										height: "5"
									}),
									/* @__PURE__ */ m("rect", {
										x: "154",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "168",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "182",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "196",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "203",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "148",
										y: "67",
										width: "64",
										height: "4"
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "acropolis-board-wrap",
					children: /* @__PURE__ */ m(He, {
						city: O.city,
						levelMarkers: k,
						fill: !0,
						placeLabel: (e) => p("games.acropolis.placeAt", { n: e + 1 }),
						label: p("games.acropolis.cityOf", { name: A(O.rid) }),
						onPlace: (e) => r({
							type: "place",
							rot: e.rot,
							q: e.q,
							r: e.r
						}),
						last: e.lastPlacement && e.lastPlacement.rid === O.rid ? e.lastPlacement : null,
						serial: e.lastPlacement?.serial ?? 0
					})
				}),
				/* @__PURE__ */ h("div", {
					className: "acropolis-meta",
					children: [/* @__PURE__ */ m("div", {
						className: "acropolis-legend",
						children: x.map((e) => /* @__PURE__ */ h("span", {
							style: { "--district": C[e] },
							children: [/* @__PURE__ */ m("i", {}), p($[e])]
						}, e))
					}), /* @__PURE__ */ m("div", {
						className: "acropolis-log",
						children: /* @__PURE__ */ m(l, {
							log: e.log.slice(-12),
							line: N
						})
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/game/bot.ts
var Ge = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.current !== t.rid) return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	if (n.pending) {
		let e = F(r.city);
		if (!e.length) return null;
		if (t.difficulty === "weak") return { action: {
			type: "place",
			rot: e[0].rot,
			q: e[0].q,
			r: e[0].r
		} };
		let i = {
			value: -1,
			action: {
				type: "place",
				rot: e[0].rot,
				q: e[0].q,
				r: e[0].r
			}
		};
		for (let t of e) {
			let e = I(r.city, n.pending, t), a = z(e.city, r.stones + e.gained, n.config).total + e.gained * .35 + t.level * .6;
			a > i.value && (i = {
				value: a,
				action: {
					type: "place",
					rot: t.rot,
					q: t.q,
					r: t.r
				}
			});
		}
		return { action: i.action };
	}
	let i = Math.min(r.stones, n.site.length - 1);
	if (i < 0) return null;
	if (t.difficulty === "weak") return { action: {
		type: "take",
		index: 0
	} };
	let a = {
		value: -1,
		action: {
			type: "take",
			index: 0
		}
	};
	for (let e = 0; e <= i; e++) {
		let t = n.site[e];
		if (!t) continue;
		let i = F(r.city);
		for (let o of i) {
			let i = I(r.city, t, o), s = r.stones - e + i.gained, c = z(i.city, s, n.config).total + i.gained * .35 + o.level * .6 - e * .05;
			c > a.value && (a = {
				value: c,
				action: {
					type: "take",
					index: e
				}
			});
		}
	}
	return { action: a.action };
}, Ke = {
	house: "games.acropolis.house",
	market: "games.acropolis.market",
	barracks: "games.acropolis.barracks",
	temple: "games.acropolis.temple",
	garden: "games.acropolis.garden"
};
function qe({ public: e, members: t, myRid: n, result: r, onPlayAgain: i, onBackToLobby: s }) {
	let l = e, u = o(), d = (e) => {
		let n = t.find((t) => t.rid === e), r = n?.colorIndex ?? Math.max(0, l.players.findIndex((t) => t.rid === e));
		return n?.name || u(f[r % f.length].nameKey);
	}, [p, _] = a(Math.max(0, l.players.findIndex((e) => e.rid === n))), v = l.players[p] ?? l.players[0], y = r.winner.map(d).join(" · ");
	return /* @__PURE__ */ m(c, {
		adaptive: !0,
		scroll: !1,
		className: "acropolis-screen acropolis-over",
		actionsHeight: "h-12",
		actions: /* @__PURE__ */ h("div", {
			className: "acropolis-over-actions",
			children: [
				i && /* @__PURE__ */ m(g, {
					compact: !0,
					label: u("session.result.playAgain"),
					confirmLabel: u("games.acropolis.confirmAgain"),
					onConfirm: i
				}),
				s && /* @__PURE__ */ m(g, {
					compact: !0,
					label: u("session.result.backToLobby"),
					confirmLabel: u("games.acropolis.confirmLobby"),
					onConfirm: s
				}),
				!i && !s && /* @__PURE__ */ m("span", { children: u("session.result.waitHost") })
			]
		}),
		banner: /* @__PURE__ */ h("div", {
			className: "acropolis-over-banner",
			children: [/* @__PURE__ */ h("div", {
				className: "acropolis-over-title",
				children: [/* @__PURE__ */ m(Le, {
					size: 40,
					className: "acropolis-over-laurel"
				}), /* @__PURE__ */ h("div", {
					className: "acropolis-over-heading",
					children: [/* @__PURE__ */ m("span", {
						className: "acropolis-over-kicker",
						children: u("games.acropolis.endTitle")
					}), /* @__PURE__ */ m("strong", { children: r.winner.length > 1 ? u("games.acropolis.coWinners", { names: y }) : u("games.acropolis.winner", { name: y }) })]
				})]
			}), /* @__PURE__ */ m("div", {
				className: "acropolis-over-tabs",
				role: "tablist",
				children: l.players.map((e, t) => /* @__PURE__ */ h("button", {
					type: "button",
					role: "tab",
					"aria-selected": t === p,
					className: t === p ? "is-selected" : "",
					onClick: () => _(t),
					children: [
						/* @__PURE__ */ m("span", { children: d(e.rid) }),
						/* @__PURE__ */ m("strong", { children: e.score.total }),
						r.winner.includes(e.rid) && /* @__PURE__ */ m("b", { children: "★" })
					]
				}, e.rid))
			})]
		}),
		children: /* @__PURE__ */ h("div", {
			className: "acropolis-over-main",
			children: [
				/* @__PURE__ */ h("div", {
					className: "acropolis-over-sky",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ m("span", { className: "acropolis-sun" }),
						/* @__PURE__ */ m("span", { className: "acropolis-haze" }),
						/* @__PURE__ */ m("span", { className: "acropolis-sea" }),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-back" }),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-mid" }),
						/* @__PURE__ */ m("span", { className: "acropolis-hill acropolis-hill-front" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-a" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-b" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-c" }),
						/* @__PURE__ */ m("span", { className: "acropolis-cypress acropolis-cy-d" }),
						/* @__PURE__ */ h("svg", {
							className: "acropolis-temple",
							viewBox: "0 0 240 100",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ m("path", {
								d: "M0 100 L40 72 L78 78 L112 58 L150 66 L186 50 L222 64 L240 58 L240 100 Z",
								fill: "#6f7647"
							}), /* @__PURE__ */ h("g", {
								fill: "#55513a",
								opacity: ".55",
								children: [
									/* @__PURE__ */ m("path", { d: "M150 48 L180 31 L210 48 Z" }),
									/* @__PURE__ */ m("rect", {
										x: "150",
										y: "48",
										width: "60",
										height: "5"
									}),
									/* @__PURE__ */ m("rect", {
										x: "154",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "168",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "182",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "196",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "203",
										y: "53",
										width: "4",
										height: "14"
									}),
									/* @__PURE__ */ m("rect", {
										x: "148",
										y: "67",
										width: "64",
										height: "4"
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "acropolis-over-stage",
					children: [/* @__PURE__ */ m(He, {
						city: v.city,
						serial: 0,
						fill: !0,
						label: u("games.acropolis.cityOf", { name: d(v.rid) })
					}), /* @__PURE__ */ m("span", {
						className: "acropolis-over-stage-label",
						children: u("games.acropolis.cityOf", { name: d(v.rid) })
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "acropolis-over-score",
					children: [
						/* @__PURE__ */ m(Le, {
							size: 190,
							className: "acropolis-over-mark"
						}),
						/* @__PURE__ */ h("h2", { children: [
							u("games.acropolis.breakdown"),
							" · ",
							d(v.rid)
						] }),
						/* @__PURE__ */ m("table", { children: /* @__PURE__ */ h("tbody", { children: [
							v.score.entries.map((e) => /* @__PURE__ */ h("tr", { children: [
								/* @__PURE__ */ h("th", { children: [/* @__PURE__ */ m("i", { style: { background: C[e.color] } }), u(Ke[e.color])] }),
								/* @__PURE__ */ h("td", { children: [
									e.value,
									" × ",
									e.stars
								] }),
								/* @__PURE__ */ m("td", { children: /* @__PURE__ */ m("strong", { children: e.points }) })
							] }, e.color)),
							/* @__PURE__ */ h("tr", { children: [
								/* @__PURE__ */ h("th", { children: [/* @__PURE__ */ m(J, { size: 12 }), u("games.acropolis.stones")] }),
								/* @__PURE__ */ m("td", { children: v.score.stones }),
								/* @__PURE__ */ m("td", { children: /* @__PURE__ */ m("strong", { children: v.score.stones }) })
							] }),
							/* @__PURE__ */ h("tr", {
								className: "is-total",
								children: [
									/* @__PURE__ */ m("th", { children: u("games.acropolis.finalScore") }),
									/* @__PURE__ */ m("td", {}),
									/* @__PURE__ */ m("td", { children: /* @__PURE__ */ m("strong", { children: v.score.total }) })
								]
							})
						] }) }),
						r.autopilot && Object.entries(r.autopilot).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ h("p", {
							className: "acropolis-autopilot",
							children: [
								d(e),
								" · ",
								u("session.autopilot.share", { n: Math.round(t * 100) })
							]
						}, e))
					]
				})
			]
		})
	});
}
//#endregion
//#region src/game/options.tsx
function Je({ value: e, onChange: t }) {
	let n = o(), r = G.safeParse(e), i = r.success ? r.data : G.parse(void 0), a = (e) => t({
		...i,
		...e
	}), s = [
		{
			key: "house",
			label: n("games.acropolis.variantHouse")
		},
		{
			key: "market",
			label: n("games.acropolis.variantMarket")
		},
		{
			key: "barracks",
			label: n("games.acropolis.variantBarracks")
		},
		{
			key: "temple",
			label: n("games.acropolis.variantTemple")
		},
		{
			key: "garden",
			label: n("games.acropolis.variantGarden")
		}
	];
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(v, {
		title: n("games.acropolis.optionsTitle"),
		children: s.map((e) => /* @__PURE__ */ m(_, {
			name: `acropolis-${e.key}`,
			value: e.key,
			checked: i[e.key],
			label: e.label,
			accent: V.accent,
			onChange: () => a({ [e.key]: !i[e.key] })
		}, e.key))
	}), /* @__PURE__ */ m("p", {
		className: "mt-2 text-xs opacity-70",
		children: n("games.acropolis.optionsHint")
	})] });
}
//#endregion
//#region src/index.tsx
var Ye = {
	definition: me,
	View: Ue,
	bot: Ge,
	OverView: qe,
	Options: Je,
	locales: {
		zh: {
			name: "雅典卫城",
			desc: "在爱琴海畔兴建城邦：轮流从工地取走板块、逐层叠建，让同类街区连成规模，并借广场与采石场赢取荣耀。",
			rules: "目标：\n每位玩家扮演一位建筑师，在各自的城市中建造住房、市场、兵营、神庙与花园。游戏结束时，按街区类型分别计算得分，总分最高者获胜；总分相同时，剩余石料较多者获胜。\n\n准备：\n将与本局人数相符的城市板块背面朝上洗混，平均分成 11 叠。四人游戏每叠 5 块，三人游戏每叠 4 块，两人游戏每叠 3 块。\n将分叠后剩余的板块正面朝上在桌面中央排成一行，称为“工地”。每轮开始时，工地上有比建筑师人数多 2 块板块。\n每位建筑师拿取 1 块起始板块放在自己面前。起始板块由 4 个建造格组成：中央是 1 个带 1 颗星的住房广场，周围是 3 个采石场。\n最近一次爬过山的建筑师拿取首席建筑师标记，作为第一顺位。从第一顺位开始按顺时针方向，每位建筑师依次拿取石料：第一顺位 1 块，第二顺位 2 块，第三顺位 3 块，第四顺位 4 块。其余石料放在一旁作为公共储备。\n\n流程：\n游戏从首席建筑师开始，按顺时针方向轮流进行。每位建筑师在自己的回合依次执行两个步骤：先从工地取走一块板块，再把它放进自己的城市。建筑师持续轮流行动，直到工地只剩 1 块板块。\n\n取板块：\n建筑师可以选择工地上的任意一块板块。取第一块板块不需要支付石料；若要取更靠后的板块，每越过一块板块就要支付 1 块石料，支付的石料放回公共储备。\n建筑师必须拥有足够的石料才能取走对应位置的板块；石料不足时，只能取第一块板块。建筑师取走板块后，必须在本回合内把它放入自己的城市。\n\n放置板块：\n每块城市板块由 3 个六边形建造格组成，分为采石场、广场和街区三类。板块可以自由旋转。\n放在第 1 层的板块，必须至少有一条边与自己的另一块城市板块相邻，并且 3 个格子都必须是空地。\n放在更高层的板块，必须完整压在 3 个已有格子上，不能悬空；这 3 个格子必须来自至少 2 块不同的板块，而且高度相同。新板块放在这些格子的上一层的同一高度。\n被上层板块覆盖的格子不再保留原有的建造格：街区不再计分，广场不再提供星数，采石场也不再被重复计入。该位置仍然算作被你的城市占据，会影响兵营的边缘、神庙的包围与花园的湖泊判定。覆盖采石场时，每覆盖 1 个采石场，建筑师立即从公共储备获得 1 块石料。\n\n建造格：\n采石场本身不计分。当它被其它板块覆盖时，为覆盖它的建筑师提供 1 块石料。\n广场带有 1 至 3 颗星，同一颜色的广场星数可以累加。广场只按颜色对应街区，不要求与同色街区相邻，也不因所在层数提高而增加星数。\n街区共有五种类型，放置时没有限制，但只有满足该类型的放置条件、并且城市中至少有一个同色广场时，才能得分。街区位于第 1 层时价值为 1，第 2 层为 2，第 3 层为 3，以此类推。\n\n街区放置条件：\n· 住房为蓝色。只有城市中最大的一片相邻住房群计分；其它较小的住房群不计分。住房群可以跨越不同层，群的价值为群内每块住房所在层数之和。\n· 市场为黄色。市场不能与任何其它市场相邻；相邻的市场都不计分。\n· 兵营为红色。兵营必须位于城市边缘，也就是至少有一个相邻格为空。\n· 神庙为紫色。神庙必须被完全包围，六个相邻格都必须有格子。\n· 花园为绿色。花园没有放置条件，所有花园都可以计分。\n相邻关系只看格子在城市平面上的位置，与格子所在的层数无关。例如第 2 层的住房可以与相邻的第 1 层住房属于同一片住房群。\n\n补充工地：\n一名建筑师完成回合后，如果工地只剩 1 块板块，就把该板块留在工地第一位，然后取下一叠板块正面朝上依次排在它后面，使工地重新达到“建筑师人数加 2”块。首席建筑师标记传给左侧的玩家，由新的首席建筑师继续行动。\n若没有剩余的板块叠可以补充工地，则游戏结束。\n\n结算：\n每位建筑师按街区颜色分别计算得分：\n· 先累加所有满足放置条件的同色街区的价值；街区每高一层，价值增加 1。\n· 再累加城市中所有同色广场的星数。\n· 将两者相乘，得到该颜色街区的得分。\n五种颜色分别计算后相加。每块剩余石料额外提供 1 分。\n总分最高的建筑师获胜；总分相同时，剩余石料较多者获胜。\n\n变体：\n开始游戏前可以加入以下任意组合的变体。每个变体为一种街区增加额外条件：满足额外条件时，该类街区的得分翻倍；不满足时仍按正常方式计分。额外条件不会取代原有的放置条件，街区仍须满足原条件，并且城市中仍须有同色广场。\n· 住房：最大住房群的价值达到 10 或以上时，该住房群得分翻倍。\n· 市场：市场与同色市场广场相邻时，该市场得分翻倍。\n· 兵营：兵营有 3 个或 4 个相邻空格时，该兵营得分翻倍。\n· 神庙：神庙建在第 2 层或更高层时，该神庙得分翻倍。\n· 花园：花园与湖泊相邻时，该花园得分翻倍。湖泊是指六个相邻格都已被占据的空格。",
			turn: "轮到{{name}}",
			waiting: "等待{{name}}行动",
			yourTurn: "轮到你了：选择工地上的板块",
			yourPlace: "放置板块：旋转后点击城市中的落点",
			round: "第 {{n}} 轮",
			chief: "首席",
			stones: "石料",
			points: "总分",
			stacks: "剩余板块叠 {{n}}",
			stacksOne: "剩余板块叠 1",
			site: "工地",
			pending: "待放置板块",
			rotateLeft: "向左旋转",
			rotateRight: "向右旋转",
			placements: "{{n}} 处可放置",
			placementsOne: "1 处可放置",
			noPlacement: "当前方向没有合法落点，请旋转板块",
			selectCity: "查看城市",
			you: "你",
			cost: "{{n}} 石",
			costOne: "1 石",
			free: "免费",
			level: "第 {{n}} 层",
			gained: "获得 {{n}} 石",
			logTakeFree: "{{name}} 取走第 1 块板块",
			logTake: "{{name}} 取走第 {{n}} 块板块，支付 {{cost}} 块石料",
			logPlace: "{{name}} 在第 {{level}} 层放置板块",
			logGain: "，并因覆盖采石场获得 {{n}} 块石料",
			logGainOne: "，并因覆盖采石场获得 1 块石料",
			house: "住房",
			market: "市场",
			barracks: "兵营",
			temple: "神庙",
			garden: "花园",
			quarry: "采石场",
			listSeparator: "、",
			plazaOf: "{{color}}广场",
			plaza: "广场",
			stars: "{{n}} 星",
			value: "价值",
			scoring: "计分",
			scoreHint: "价值 × 星数",
			endTitle: "城市落成",
			winner: "{{name}} 获胜",
			coWinners: "并列获胜：{{names}}",
			finalScore: "最终得分",
			breakdown: "街区得分",
			variantTitle: "变体规则",
			variantHouse: "住房群价值达到 10 或以上时得分翻倍",
			variantMarket: "市场与市场广场相邻时得分翻倍",
			variantBarracks: "兵营有 3 或 4 个相邻空格时得分翻倍",
			variantTemple: "神庙位于第 2 层或更高层时得分翻倍",
			variantGarden: "花园与湖泊相邻时得分翻倍",
			variantNone: "未启用变体",
			optionsTitle: "变体",
			optionsHint: "可为一种或多种街区增加翻倍条件；默认关闭。",
			invalid: "该操作无效",
			notYourTurn: "还没有轮到你",
			needStones: "石料不足，只能取第一块板块",
			cityOf: "{{name}} 的城市",
			placeAt: "在此放置板块（第 {{n}} 处）",
			placeHere: "在此放置板块",
			illegalPlace: "这里不能放置板块",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			close: "关闭"
		},
		en: {
			name: "Akropolis",
			desc: "Raise a Greek city on the Aegean: draft tiles from the construction site, stack them upward, and grow matching districts, plazas and quarries into lasting glory.",
			rules: "Goal:\nEach player is an architect building a city with houses, markets, barracks, temples and gardens. At the end of the game, score each district type separately. The player with the most points wins; if players tie on points, the player with the most stones wins.\n\nSetup:\nShuffle the city tiles that match the player count face down and divide them into 11 equal stacks. Use 5 tiles per stack with 4 players, 4 with 3 players, and 3 with 2 players.\nPlace the tiles left over after stacking face up in a line in the center of the table. This line is the construction site. At the start of every round it holds 2 more tiles than there are architects.\nEach architect takes 1 starting tile and places it in front of them. The starting tile has 4 construction spaces: a central housing plaza worth 1 star, surrounded by 3 quarries.\nThe architect who most recently climbed a hill takes the Chief Architect marker and becomes first player. Starting with the first player and proceeding clockwise, each architect takes stones: 1 for the first player, 2 for the second, 3 for the third, and 4 for the fourth. The remaining stones form the common reserve.\n\nPlay:\nStarting with the Chief Architect and proceeding clockwise, architects take turns. On your turn, first take one tile from the construction site, then add it to your city. Play continues until only 1 tile remains in the construction site.\n\nTaking a tile:\nYou may choose any tile in the construction site. Taking the first tile is free; for a tile further back, pay 1 stone for each tile you pass over, returning those stones to the common reserve.\nYou must have enough stones to take a tile at that position. If you do not have enough stones, you must take the first tile. Once you take a tile, you must add it to your city during the same turn.\n\nAdding a tile:\nEach city tile consists of 3 hexagonal construction spaces: quarries, plazas and districts. A tile may be rotated freely.\nA tile placed on the 1st level must share at least one edge with another of your city tiles, and all 3 of its spaces must be empty.\nA tile placed on a higher level must cover 3 existing spaces completely and may not overhang. Those 3 spaces must belong to at least 2 different tiles and must all be at the same height. The new tile is placed on the next level above them.\nA space covered by a tile above no longer keeps its construction space: its district does not score, its plaza provides no stars, and its quarry is no longer counted. The position is still occupied by your city, so it still matters for a barracks edge, a temple's surround and a garden's lake. When you cover a quarry, take 1 stone from the common reserve for each quarry covered.\n\nConstruction spaces:\nQuarries do not score. When a quarry is covered by another tile, the architect who covers it takes 1 stone.\nPlazas show 1 to 3 stars. Stars on plazas of the same colour add together. A plaza matches districts by colour only; it does not need to border a district of that colour, and its stars do not increase with the level it occupies.\nThere are five district types. You may place a district freely, but it scores only when it meets the placement condition for its type and your city contains at least one plaza of the same colour. A district on the 1st level is worth 1, on the 2nd level 2, on the 3rd level 3, and so on.\n\nDistrict placement conditions:\n· Houses are blue. Only the largest single group of adjacent houses in your city scores; smaller groups do not. A house group may span levels, and its value is the sum of the levels of its houses.\n· Markets are yellow. A market must not be adjacent to any other market; markets that touch another market do not score.\n· Barracks are red. A barracks must be on the edge of your city, meaning at least one adjacent space is empty.\n· Temples are purple. A temple must be completely surrounded, with all six adjacent spaces occupied.\n· Gardens are green. Gardens have no placement condition, so every garden scores.\nAdjacency depends only on positions in the city plan, not on level. For example, a house on the 2nd level can belong to the same group as an adjacent house on the 1st level.\n\nSupplying the construction site:\nAfter an architect finishes their turn, if only 1 tile remains in the construction site, leave it in the first position, then take the next stack of tiles and place its tiles face up after it so that the site again holds 2 more tiles than there are architects. Pass the Chief Architect marker to the player on the left, and continue play with the new Chief Architect.\nIf no stacks remain to replenish the site, the game ends.\n\nScoring:\nEach architect scores each district colour separately:\n· Add up the values of all districts of that colour that meet their placement condition. A district is worth 1 more point for each level above the first.\n· Add up the stars on all plazas of that colour in your city.\n· Multiply the two numbers to obtain the points for that colour.\nAdd the five colour totals together. Each stone you have left is worth 1 additional point.\nThe architect with the most points wins. If players tie on points, the player with the most stones wins.\n\nVariants:\nBefore the game, you may add any combination of the following variants. Each variant adds an extra condition for one district type: when the extra condition is met, that district's points are doubled; otherwise it scores normally. The extra condition does not replace the usual placement condition. The district must still meet its usual condition, and your city must still contain a plaza of that colour.\n· Houses: if your largest group of houses has a value of 10 or more, that group's points are doubled.\n· Markets: if a market is next to a market plaza, that market's points are doubled.\n· Barracks: if a barracks has 3 or 4 empty adjacent spaces, that barracks' points are doubled.\n· Temples: if a temple is built on the 2nd level or higher, that temple's points are doubled.\n· Gardens: if a garden is adjacent to a lake, that garden's points are doubled. A lake is an empty space whose six adjacent spaces are all occupied.",
			turn: "{{name}}'s turn",
			waiting: "Waiting for {{name}}",
			yourTurn: "Your turn: pick a tile",
			yourPlace: "Rotate, then tap to place",
			round: "Round {{n}}",
			chief: "Chief",
			stones: "Stones",
			points: "Points",
			stacks: "Stacks left: {{n}}",
			stacksOne: "Stacks left: 1",
			site: "Construction site",
			pending: "Tile to place",
			rotateLeft: "Rotate left",
			rotateRight: "Rotate right",
			placements: "{{n}} legal placements",
			placementsOne: "1 legal placement",
			noPlacement: "No legal placement in this orientation; rotate the tile",
			selectCity: "View city",
			you: "You",
			cost: "{{n}} stones",
			costOne: "1 stone",
			free: "Free",
			level: "Level {{n}}",
			gained: "Gain {{n}} stones",
			logTakeFree: "{{name}} took the first tile",
			logTake: "{{name}} takes tile {{n}}, paying {{cost}} stones",
			logPlace: "{{name}} places a tile on level {{level}}",
			logGain: ", gaining {{n}} stones from covered quarries",
			logGainOne: ", gaining 1 stone from covered quarries",
			house: "Houses",
			market: "Markets",
			barracks: "Barracks",
			temple: "Temples",
			garden: "Gardens",
			quarry: "Quarry",
			listSeparator: ", ",
			plazaOf: "{{color}} plaza",
			plaza: "Plaza",
			stars: "{{n}} stars",
			value: "Value",
			scoring: "Scoring",
			scoreHint: "Value × stars",
			endTitle: "City completed",
			winner: "{{name}} wins",
			coWinners: "Tied winners: {{names}}",
			finalScore: "Final score",
			breakdown: "District scores",
			variantTitle: "Variants",
			variantHouse: "House group worth 10 or more scores double",
			variantMarket: "Market next to a market plaza scores double",
			variantBarracks: "Barracks with 3 or 4 empty neighbours scores double",
			variantTemple: "Temple on level 2 or higher scores double",
			variantGarden: "Garden next to a lake scores double",
			variantNone: "No variants",
			optionsTitle: "Variants",
			optionsHint: "Add a doubling condition to one or more districts. Off by default.",
			invalid: "That action is not valid",
			notYourTurn: "It is not your turn",
			needStones: "Not enough stones; you must take the first tile",
			cityOf: "{{name}}'s city",
			placeAt: "Place the tile here (option {{n}})",
			placeHere: "Place the tile here",
			illegalPlace: "The tile cannot be placed there",
			confirmAgain: "Confirm play again",
			confirmLobby: "Confirm back to lobby",
			close: "Close"
		}
	}
};
//#endregion
export { Ye as default };
