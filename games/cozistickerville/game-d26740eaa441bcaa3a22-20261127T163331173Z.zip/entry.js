import { z as e } from "zod";
import { createContext as t, createElement as n, forwardRef as r, useContext as i, useLayoutEffect as a, useMemo as o, useRef as s, useState as c } from "react";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { readGameStorage as f, writeGameStorage as te } from "@bgparty/sdk/storage";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { usePrefersReducedMotion as m } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
//#region src/game/data/events.ts
var v = [
	{
		id: "y1-01",
		year: 1,
		num: 1,
		file: "events/y1-01.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y1-02",
		year: 1,
		num: 2,
		file: "events/y1-02.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { res: { wood: 1 } } },
			c: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y1-03",
		year: 1,
		num: 3,
		file: "events/y1-03.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: {
				place: "11A",
				n: 2
			} }
		}
	},
	{
		id: "y1-04",
		year: 1,
		num: 4,
		file: "events/y1-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "1H" } },
			b: { do: { place: "5N" } }
		}
	},
	{
		id: "y1-05",
		year: 1,
		num: 5,
		file: "events/y1-05.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "6C" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y1-06",
		year: 1,
		num: 6,
		file: "events/y1-06.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "5M" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y1-07",
		year: 1,
		num: 7,
		file: "events/y1-07.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { place: "12D" } },
			c: { do: { res: { gold: 1 } } }
		}
	},
	{
		id: "y1-08",
		year: 1,
		num: 8,
		file: "events/y1-08.webp",
		kind: "keep",
		keepActions: [{
			key: "sell1",
			label: {
				zh: "卖出 1 食物换 1 金币",
				en: "Sell 1 food for 1 gold"
			},
			do: { res: { gold: 1 } },
			cost: { food: 1 },
			repeat: !0
		}, {
			key: "sell2",
			label: {
				zh: "卖出 2 食物换 2 金币",
				en: "Sell 2 food for 2 gold"
			},
			do: { res: { gold: 2 } },
			cost: { food: 2 },
			repeat: !0
		}],
		keepText: {
			zh: "卖出食物：最多花费 2 食物，每 1 食物换 1 金币（用后不弃）。",
			en: "Sell Food: spend up to 2 food for 1 gold each (card stays)."
		}
	},
	{
		id: "y1-09",
		year: 1,
		num: 9,
		file: "events/y1-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "法默·迪尔：获得图鉴牌 1",
				en: "Farmer Dill: gain card 1"
			},
			do: { card: "1" },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "萨利扎一家：获得图鉴牌 2",
				en: "The Salizars: gain card 2"
			},
			do: { card: "2" },
			discard: !0
		}],
		keepText: {
			zh: "建造房屋：弃掉本牌，选择法默·迪尔（获得图鉴牌 1）或萨利扎一家（获得图鉴牌 2）。",
			en: "Build House: discard; pick Farmer Dill (card 1) or the Salizars (card 2)."
		}
	},
	{
		id: "y1-10",
		year: 1,
		num: 10,
		file: "events/y1-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "扎克·约翰逊：放置贴纸 6A",
				en: "Zach Johnson: place 6A"
			},
			do: { place: "6A" },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "锯木兄妹：放置贴纸 6R",
				en: "The Saw Siblings: place 6R"
			},
			do: { place: "6R" },
			discard: !0
		}],
		keepText: {
			zh: "建造房屋：弃掉本牌，选择扎克·约翰逊（放置贴纸 6A）或锯木兄妹（放置贴纸 6R）。",
			en: "Build House: discard; pick Zach Johnson (place 6A) or the Saw Siblings (place 6R)."
		}
	},
	{
		id: "y1-11",
		year: 1,
		num: 11,
		file: "events/y1-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造市政厅：获得图鉴牌 11",
				en: "Build Town Hall: gain card 11"
			},
			do: { card: "11" },
			discard: !0,
			if: { minResidents: 3 }
		}, {
			key: "b",
			label: {
				zh: "建造农场：获得图鉴牌 8",
				en: "Build Farm: gain card 8"
			},
			do: { card: "8" },
			discard: !0
		}],
		keepText: {
			zh: "建造市政厅（需 3+ 居民，弃牌获得图鉴牌 11）或建造农场（弃牌获得图鉴牌 8）。",
			en: "Build Town Hall (3+ residents, discard, gain card 11) or Farm (discard, gain card 8)."
		}
	},
	{
		id: "y1-12",
		year: 1,
		num: 12,
		file: "events/y1-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "养蜂人：获得图鉴牌 11",
				en: "Bee Lover: gain card 11"
			},
			do: { card: "11" },
			discard: !0,
			if: { countCode: {
				code: "11A",
				min: 4
			} }
		}, {
			key: "b",
			label: {
				zh: "守财奴：获得图鉴牌 10",
				en: "Money Lover: gain card 10"
			},
			do: { card: "10" },
			discard: !0,
			if: { minMapRes: { gold: 2 } }
		}],
		keepText: {
			zh: "新来者的抱负：养蜂人（4+ 花朵贴纸则弃牌获得图鉴牌 11）或守财奴（地图上 2+ 金币图标则弃牌获得图鉴牌 10）。",
			en: "Newcomer Ambition: Bee Lover (4+ flowers -> card 11) or Money Lover (2+ gold icons -> card 10)."
		}
	},
	{
		id: "y2-01",
		year: 2,
		num: 1,
		file: "events/y2-01.webp",
		kind: "choice",
		opts: {
			a: { do: {
				res: { wood: 3 },
				place: "6H",
				cover: !0
			} },
			b: { do: { place: "11K" } }
		}
	},
	{
		id: "y2-02",
		year: 2,
		num: 2,
		file: "events/y2-02.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 2 } } },
			b: { do: { res: { gold: 1 } } }
		}
	},
	{
		id: "y2-03",
		year: 2,
		num: 3,
		file: "events/y2-03.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y2-04",
		year: 2,
		num: 4,
		file: "events/y2-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "1H" } },
			b: { do: { place: "5N" } }
		}
	},
	{
		id: "y2-05",
		year: 2,
		num: 5,
		file: "events/y2-05.webp",
		kind: "choice",
		opts: {
			a: { do: {
				res: { gold: 3 },
				milestone: "Loan|red"
			} },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y2-06",
		year: 2,
		num: 6,
		file: "events/y2-06.webp",
		kind: "choice",
		opts: { a: { do: { dice: [{
			on: [
				1,
				2,
				3,
				4
			],
			do: { place: "3D" }
		}, {
			on: [5, 6],
			do: { res: { gold: 1 } }
		}] } } }
	},
	{
		id: "y2-07",
		year: 2,
		num: 7,
		file: "events/y2-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{ res: { gold: -1 } }, { removeSticker: "5M" }] },
				if: { hasSticker: "5M" },
				label: {
					zh: "已有 Wild Bill 居民：赶走他",
					en: "Wild Bill resident: kick him out"
				}
			},
			b: {
				do: { res: { gold: -1 } },
				if: { hasSticker: "5M" },
				label: {
					zh: "已有 Wild Bill 居民：让他留下",
					en: "Wild Bill resident: let him stay"
				}
			},
			c: {
				do: { place: "5M" },
				if: { notSticker: "5M" },
				label: {
					zh: "没有 Wild Bill 居民：可安置 Wild Bill",
					en: "No Wild Bill resident: may place Wild Bill"
				}
			}
		}
	},
	{
		id: "y2-08",
		year: 2,
		num: 8,
		file: "events/y2-08.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "举办盛宴",
				en: "Throw a feast"
			},
			do: { hap: 1 },
			cost: { food: 4 },
			discard: !0
		}],
		endOfYear: {
			choice: [{
				do: { none: !0 },
				cost: { food: 4 }
			}, { do: { milestone: "Hunger|red" } }],
			discard: !0
		}
	},
	{
		id: "y2-09",
		year: 2,
		num: 9,
		file: "events/y2-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造房屋：Dawes 一家",
				en: "Build house: the Dawes family"
			},
			do: { place: "7A" },
			cost: { wood: 4 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造房屋：Ferguson 教授",
				en: "Build house: Professor Ferguson"
			},
			do: { place: "5H" },
			cost: { wood: 4 },
			discard: !0
		}]
	},
	{
		id: "y2-10",
		year: 2,
		num: 10,
		file: "events/y2-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造市场",
				en: "Build market"
			},
			do: { card: "9" },
			cost: { wood: 3 },
			discard: !0
		}]
	},
	{
		id: "y2-11",
		year: 2,
		num: 11,
		file: "events/y2-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "雇用表演团",
				en: "Hire the performers"
			},
			do: { hap: 1 },
			cost: { gold: 1 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { hap: 1 },
				cost: { gold: 2 }
			},
			discard: !0
		}
	},
	{
		id: "y2-12",
		year: 2,
		num: 12,
		file: "events/y2-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "打零工",
				en: "Work an odd job"
			},
			do: { story: "10.2" },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造游乐场",
				en: "Build playground"
			},
			do: {
				hap: 1,
				place: "6Q"
			},
			cost: { wood: 4 },
			discard: !0
		}]
	},
	{
		id: "y3-01",
		year: 3,
		num: 1,
		file: "events/y3-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y3-02",
		year: 3,
		num: 2,
		file: "events/y3-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 2
			} }
		}
	},
	{
		id: "y3-03",
		year: 3,
		num: 3,
		file: "events/y3-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { place: "5N" },
				cost: { food: 2 }
			},
			b: { do: { res: { food: 1 } } }
		}
	},
	{
		id: "y3-04",
		year: 3,
		num: 4,
		file: "events/y3-04.webp",
		kind: "choice",
		opts: {
			a: { do: { dice: [{
				on: [1],
				do: { hap: -1 }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { res: { food: 1 } }
			}] } },
			b: { do: { seq: [{ res: { gold: 1 } }, { dice: [{
				on: [1],
				do: { upset: 1 }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { none: !0 }
			}] }] } },
			c: { do: { none: !0 } }
		}
	},
	{
		id: "y3-05",
		year: 3,
		num: 5,
		file: "events/y3-05.webp",
		kind: "choice",
		opts: { a: { do: { extraAction: 1 } } }
	},
	{
		id: "y3-06",
		year: 3,
		num: 6,
		file: "events/y3-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "1G",
					cover: !0
				},
				if: { milestone: "Farming" },
				label: {
					zh: "已有 Farming 2/3 里程碑：放置 1G 覆盖",
					en: "Farming 2/3 milestone: place 1G covering"
				}
			},
			b: {
				do: { place: "1H" },
				cost: { gold: 1 },
				if: { notMilestone: "Farming" },
				label: {
					zh: "无上述里程碑：可花 1 金币放置 1H",
					en: "No such milestone: may spend 1 gold to place 1H"
				}
			}
		}
	},
	{
		id: "y3-07",
		year: 3,
		num: 7,
		file: "events/y3-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { wood: 2 } },
				cost: { gold: 1 },
				if: { minRes: { gold: 1 } },
				label: {
					zh: "有 1+ 金币：可花 1 金币换 2 木材",
					en: "1+ gold: may spend 1 gold for 2 wood"
				}
			},
			b: {
				do: { res: { gold: 1 } },
				cost: { food: 1 },
				if: { maxRes: { gold: 0 } },
				label: {
					zh: "没有金币：可花 1 食物换 1 金币",
					en: "No gold: may spend 1 food for 1 gold"
				}
			}
		}
	},
	{
		id: "y3-08",
		year: 3,
		num: 8,
		file: "events/y3-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					res: { gold: 3 },
					milestone: "Loan|red"
				},
				if: { notMilestone: "Loan" },
				label: {
					zh: "没有 Loan 里程碑：可获得 3 金币与 Loan 里程碑",
					en: "No Loan milestone: may gain 3 gold and Loan"
				}
			},
			b: {
				do: { res: { gold: -1 } },
				if: { milestone: "Loan" },
				label: {
					zh: "已有 Loan 里程碑：失去 1 金币",
					en: "Loan milestone: lose 1 gold"
				}
			}
		}
	},
	{
		id: "y3-09",
		year: 3,
		num: 9,
		file: "events/y3-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "修缮房屋",
				en: "Repair homes"
			},
			do: { hap: 1 },
			cost: { wood: 3 },
			discard: !0
		}],
		endOfYear: {
			choice: [{
				do: { none: !0 },
				cost: { wood: 4 }
			}, { do: { milestone: "Termites|red" } }],
			discard: !0
		}
	},
	{
		id: "y3-10",
		year: 3,
		num: 10,
		file: "events/y3-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造桥梁",
				en: "Build bridge"
			},
			do: { place: "12A" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y3-11",
		year: 3,
		num: 11,
		file: "events/y3-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造宠物店",
				en: "Build pet shop"
			},
			do: { card: "19" },
			cost: {
				wood: 4,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造面包房",
				en: "Build bakery"
			},
			do: { card: "20" },
			cost: {
				wood: 3,
				food: 2
			},
			discard: !0
		}]
	},
	{
		id: "y3-12",
		year: 3,
		num: 12,
		file: "events/y3-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造学校",
				en: "Build school"
			},
			do: { card: "21" },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造消防站",
				en: "Build fire station"
			},
			do: { place: "4C" },
			cost: { wood: 5 },
			discard: !0
		}]
	},
	{
		id: "y4-01",
		year: 4,
		num: 1,
		file: "events/y4-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y4-02",
		year: 4,
		num: 2,
		file: "events/y4-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y4-03",
		year: 4,
		num: 3,
		file: "events/y4-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 1 } } },
			b: { do: {
				place: "12R",
				n: 2
			} }
		}
	},
	{
		id: "y4-04",
		year: 4,
		num: 4,
		file: "events/y4-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "5A" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y4-05",
		year: 4,
		num: 5,
		file: "events/y4-05.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 1 } } },
			b: { do: { removeUpset: 1 } }
		}
	},
	{
		id: "y4-06",
		year: 4,
		num: 6,
		file: "events/y4-06.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { place: "12B" } }
		}
	},
	{
		id: "y4-07",
		year: 4,
		num: 7,
		file: "events/y4-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { food: -1 } },
				if: { hasSticker: "5M" },
				label: {
					zh: "若有 Wild Bill 居民：失去 1 食物，再选择赶走或留下",
					en: "If you have the Wild Bill resident: lose 1 food, then kick him out or let him stay"
				}
			},
			b: {
				do: { upset: 1 },
				if: { notSticker: "5M" },
				label: {
					zh: "若无 Wild Bill 居民：付 2 食物或放 1 个不快贴纸",
					en: "Otherwise: spend 2 food or place 1 upset sticker"
				}
			}
		}
	},
	{
		id: "y4-08",
		year: 4,
		num: 8,
		file: "events/y4-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{ place: "12P" }, {
					place: "5Q",
					cover: !0
				}] },
				if: { minMapRes: { wood: 6 } },
				label: {
					zh: "若地图上有 6 个或更多木材图标：放 2 张贴纸",
					en: "If 6+ wood icons on the map: place 2 stickers"
				}
			},
			b: {
				do: { place: "8X" },
				if: { maxMapRes: { wood: 5 } },
				label: {
					zh: "否则：放 1 张树木贴纸",
					en: "Otherwise: place 1 tree sticker"
				}
			}
		}
	},
	{
		id: "y4-09",
		year: 4,
		num: 9,
		file: "events/y4-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: -1 },
				if: { milestone: "Termites" },
				label: {
					zh: "若有 Termites 里程碑：失去 1 幸福或花 3 木材移除它",
					en: "If you have the Termites milestone: lose 1 happiness or spend 3 wood to remove it"
				}
			},
			b: {
				do: { res: { gold: 1 } },
				if: { notMilestone: "Termites" },
				label: {
					zh: "若无 Termites 里程碑：获得 1 金币或移除 1 个不快贴纸",
					en: "Otherwise: gain 1 gold or remove 1 upset sticker"
				}
			}
		}
	},
	{
		id: "y4-10",
		year: 4,
		num: 10,
		file: "events/y4-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "烹饪盛宴",
				en: "Cook feast"
			},
			do: { hap: 1 },
			cost: {
				food: 3,
				gold: 1
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { food: 4 },
				do: { none: !0 }
			}, { do: { hap: -1 } }],
			discard: !0
		}
	},
	{
		id: "y4-11",
		year: 4,
		num: 11,
		file: "events/y4-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造餐馆",
				en: "Build restaurant"
			},
			do: { place: "4M" },
			cost: {
				wood: 3,
				food: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造图书馆",
				en: "Build library"
			},
			do: { card: "34" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y4-12",
		year: 4,
		num: 12,
		file: "events/y4-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鱼店",
				en: "Build fishing shop"
			},
			do: { card: "32" },
			cost: { wood: 4 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造大宅",
				en: "Build large home"
			},
			do: { place: "4H" },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}]
	},
	{
		id: "y5-01",
		year: 5,
		num: 1,
		file: "events/y5-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y5-02",
		year: 5,
		num: 2,
		file: "events/y5-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "12R",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 2
			} }
		}
	},
	{
		id: "y5-03",
		year: 5,
		num: 3,
		file: "events/y5-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 1 } } },
			b: { do: { dice: [
				{
					on: [1],
					do: { hap: -1 }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { food: 1 } }
				},
				{
					on: [5],
					do: { res: { food: 2 } }
				},
				{
					on: [6],
					do: { res: { food: 3 } }
				}
			] } }
		}
	},
	{
		id: "y5-04",
		year: 5,
		num: 4,
		file: "events/y5-04.webp",
		kind: "choice",
		opts: { a: {
			do: { extraAction: 1 },
			cost: { food: 2 }
		} }
	},
	{
		id: "y5-05",
		year: 5,
		num: 5,
		file: "events/y5-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				cost: { gold: 2 }
			},
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y5-06",
		year: 5,
		num: 6,
		file: "events/y5-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { place: "12K" },
				if: { hasSticker: "6A" },
				label: {
					zh: "若有 Zach Johnson 居民：在动物上放帽子贴纸",
					en: "If you have the Zach Johnson resident: place a hat sticker on an animal"
				}
			},
			b: {
				do: { milestone: "Investment|bronze" },
				cost: { gold: 2 },
				if: { notSticker: "6A" },
				label: {
					zh: "若无 Zach Johnson 居民：可花 2 金币获得 Investment 里程碑（铜）",
					en: "Otherwise: may spend 2 gold for the Investment milestone (bronze)"
				}
			}
		}
	},
	{
		id: "y5-07",
		year: 5,
		num: 7,
		file: "events/y5-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				if: { hasSticker: "4C" },
				label: {
					zh: "若有 Fire Station：获得 1 幸福",
					en: "If you have the Fire Station: gain 1 happiness"
				}
			},
			b: {
				do: { dice: [{
					on: [
						1,
						2,
						3,
						4
					],
					do: {
						hap: -1,
						place: "4F",
						cover: !0
					}
				}, {
					on: [5, 6],
					do: { none: !0 }
				}] },
				if: { notSticker: "4C" },
				label: {
					zh: "若无 Fire Station：掷骰，1-4 失去 1 幸福并覆盖房屋",
					en: "Otherwise: roll; on 1-4 lose 1 happiness and cover your house"
				}
			}
		}
	},
	{
		id: "y5-08",
		year: 5,
		num: 8,
		file: "events/y5-08.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "自豪村庄",
				en: "Proud village"
			},
			do: { seq: [{ hap: 1 }, { story: "24.8" }] },
			cost: { gold: 2 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "繁忙村庄",
				en: "Busy village"
			},
			do: { seq: [{ hap: 1 }, { place: "5K" }] },
			cost: { gold: 2 },
			discard: !0
		}]
	},
	{
		id: "y5-09",
		year: 5,
		num: 9,
		file: "events/y5-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "提供补给",
				en: "Give supplies"
			},
			do: { hap: 1 },
			cost: {
				wood: 1,
				food: 3
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { food: 4 },
				do: { none: !0 }
			}, { do: { milestone: "Hard Winter|red" } }],
			discard: !0
		}
	},
	{
		id: "y5-10",
		year: 5,
		num: 10,
		file: "events/y5-10.webp",
		kind: "choice",
		opts: { a: { do: { card: "35" } } }
	},
	{
		id: "y5-11",
		year: 5,
		num: 11,
		file: "events/y5-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造古玩店",
				en: "Build curiosity shop"
			},
			do: { card: "46" },
			cost: {
				wood: 4,
				food: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造水塔",
				en: "Build water tower"
			},
			do: { place: "10C" },
			cost: {
				gold: 3,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y5-12",
		year: 5,
		num: 12,
		file: "events/y5-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鸡舍",
				en: "Build hen house"
			},
			do: { place: "8U" },
			cost: {
				wood: 2,
				food: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造自然保护区",
				en: "Build nature preserve"
			},
			do: { place: "10B" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y6-01",
		year: 6,
		num: 1,
		file: "events/y6-01.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物换取额外行动",
					en: "Pay 2 food for an extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "放弃",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y6-02",
		year: 6,
		num: 2,
		file: "events/y6-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "12R",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 1
			} },
			c: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y6-03",
		year: 6,
		num: 3,
		file: "events/y6-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { removeMilestone: "Lucky" },
				label: {
					zh: "忽略信件",
					en: "Ignore the letter"
				}
			},
			b: {
				do: { milestone: "Lucky|bronze" },
				cost: { food: 1 },
				label: {
					zh: "花1食物写一百封信",
					en: "Spend 1 food to write 100 letters"
				}
			}
		}
	},
	{
		id: "y6-04",
		year: 6,
		num: 4,
		file: "events/y6-04.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 1 } } },
			b: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y6-05",
		year: 6,
		num: 5,
		file: "events/y6-05.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { dice: [{
					on: [5, 6],
					do: { story: "24.4" }
				}, {
					on: [
						1,
						2,
						3,
						4
					],
					do: { res: { food: 1 } }
				}] },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y6-06",
		year: 6,
		num: 6,
		file: "events/y6-06.webp",
		kind: "choice",
		opts: {
			a: { do: { upset: 1 } },
			b: { do: { dice: [{
				on: [1, 2],
				do: { upset: 2 }
			}, {
				on: [
					3,
					4,
					5,
					6
				],
				do: { none: !0 }
			}] } }
		}
	},
	{
		id: "y6-07",
		year: 6,
		num: 7,
		file: "events/y6-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { removeMilestone: "Hard Winter" },
				cost: { food: 3 },
				if: { milestone: "Hard Winter" },
				label: {
					zh: "若已有严冬里程碑：炖一锅热汤",
					en: "If you have Hard Winter: hearty stew"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { notMilestone: "Hard Winter" },
				label: {
					zh: "若没有严冬里程碑：额外行动",
					en: "Otherwise: 1 additional action"
				}
			}
		}
	},
	{
		id: "y6-08",
		year: 6,
		num: 8,
		file: "events/y6-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { story: "10.4" },
				if: { hasSticker: "5A" },
				label: {
					zh: "若已有狼崽·抚摸牠",
					en: "If you have the wolf pup: pet him"
				}
			},
			b: {
				do: { story: "32.7" },
				if: { hasSticker: "5A" },
				label: {
					zh: "若已有狼崽·别管牠",
					en: "If you have the wolf pup: leave him be"
				}
			},
			c: {
				do: { none: !0 },
				if: { notSticker: "5A" },
				label: {
					zh: "若没有狼崽",
					en: "Otherwise"
				}
			}
		}
	},
	{
		id: "y6-09",
		year: 6,
		num: 9,
		file: "events/y6-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "诱捕掠食者",
				en: "Trap predator"
			},
			do: { hap: 1 },
			cost: { wood: 4 },
			discard: !0
		}],
		endOfYear: { discard: !0 }
	},
	{
		id: "y6-10",
		year: 6,
		num: 10,
		file: "events/y6-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "栽种树林",
				en: "Plant grove"
			},
			do: { place: "6T" },
			cost: { gold: 3 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { none: !0 },
				cost: { gold: 1 }
			},
			discard: !0
		}
	},
	{
		id: "y6-11",
		year: 6,
		num: 11,
		file: "events/y6-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鸟类协会",
				en: "Build birding society"
			},
			do: { card: "37" },
			cost: {
				wood: 3,
				food: 1,
				ore: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造服装店",
				en: "Build clothing store"
			},
			do: { card: "40" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y6-12",
		year: 6,
		num: 12,
		file: "events/y6-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造天文台",
				en: "Build observatory"
			},
			do: { card: "41" },
			cost: {
				wood: 2,
				ore: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造钟楼",
				en: "Build clock tower"
			},
			do: { card: "36" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y7-01",
		year: 7,
		num: 1,
		file: "events/y7-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			},
			c: { do: { seq: [{ res: { wood: 2 } }, { upset: 1 }] } }
		}
	},
	{
		id: "y7-02",
		year: 7,
		num: 2,
		file: "events/y7-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: { res: { ore: 1 } } }
		}
	},
	{
		id: "y7-03",
		year: 7,
		num: 3,
		file: "events/y7-03.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { removeUpset: 1 },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y7-04",
		year: 7,
		num: 4,
		file: "events/y7-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物换取额外行动",
					en: "Pay 2 food for an extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "放弃",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y7-05",
		year: 7,
		num: 5,
		file: "events/y7-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{
					pickRes: [
						"wood",
						"food",
						"gold",
						"ore"
					],
					n: 2
				}, { dice: [{
					on: [1, 2],
					do: { hap: -1 }
				}, {
					on: [
						3,
						4,
						5,
						6
					],
					do: { none: !0 }
				}] }] },
				if: { minHearts: 14 },
				label: {
					zh: "若幸福不少于14：早起",
					en: "If happiness 14+: wake before sunrise"
				}
			},
			b: {
				do: {
					place: "3E",
					n: 1
				},
				if: { maxHearts: 13 },
				label: {
					zh: "若幸福少于14",
					en: "Otherwise"
				}
			}
		}
	},
	{
		id: "y7-06",
		year: 7,
		num: 6,
		file: "events/y7-06.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "还清贷款",
				en: "Pay off loan"
			},
			do: { removeMilestone: "Loan" },
			cost: { gold: 4 },
			discard: !0
		}],
		endOfYear: { discard: !0 }
	},
	{
		id: "y7-07",
		year: 7,
		num: 7,
		file: "events/y7-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "8W",
					n: 1,
					cover: !0
				},
				if: { minUpset: 1 },
				label: {
					zh: "若草屋住着不快居民：换新居民",
					en: "If an upset resident is on a grass house: new resident"
				}
			},
			b: {
				do: { hap: 1 },
				if: { maxUpset: 0 },
				label: {
					zh: "否则：匿名来信",
					en: "Otherwise: anonymous letter"
				}
			}
		}
	},
	{
		id: "y7-08",
		year: 7,
		num: 8,
		file: "events/y7-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { food: 1 } },
				if: { hasSticker: "10C" },
				label: {
					zh: "若已有水塔",
					en: "If you have the Water Tower"
				}
			},
			b: {
				do: {
					place: "1G",
					n: 1,
					cover: !0
				},
				if: { notSticker: "10C" },
				label: {
					zh: "若没有水塔：干旱",
					en: "Otherwise: drought"
				}
			}
		}
	},
	{
		id: "y7-09",
		year: 7,
		num: 9,
		file: "events/y7-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "栽种苹果树",
				en: "Plant apple tree"
			},
			do: { place: "5R" },
			cost: {
				food: 2,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "弃牌换取额外行动",
				en: "Discard for an extra action"
			},
			do: { extraAction: 1 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { none: !0 },
				cost: { food: 1 }
			},
			discard: !0
		}
	},
	{
		id: "y7-10",
		year: 7,
		num: 10,
		file: "events/y7-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "山间小屋：矿工鲍勃",
				en: "Mountain home: Bob the Miner"
			},
			do: { place: "4S" },
			cost: {
				wood: 4,
				ore: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "山间小屋：画家伊莉丝",
				en: "Mountain home: Elise the Painter"
			},
			do: { place: "8M" },
			cost: {
				wood: 4,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y7-11",
		year: 7,
		num: 11,
		file: "events/y7-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造禅意花园",
				en: "Build zen garden"
			},
			do: { place: "4V" },
			cost: { wood: 5 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造邮局",
				en: "Build post office"
			},
			do: { story: "26.5" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y7-12",
		year: 7,
		num: 12,
		file: "events/y7-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "升级市场",
				en: "Upgrade market"
			},
			do: { card: "33" },
			cost: {
				wood: 1,
				food: 1,
				gold: 1
			},
			discard: !0
		}]
	},
	{
		id: "y8-01",
		year: 8,
		num: 1,
		file: "events/y8-01.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: {
				place: "1H",
				n: 1,
				seq: [{ place: "11A" }]
			} }
		}
	},
	{
		id: "y8-02",
		year: 8,
		num: 2,
		file: "events/y8-02.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物多做1次行动",
					en: "Spend 2 food for 1 extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "不支付",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y8-03",
		year: 8,
		num: 3,
		file: "events/y8-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			},
			c: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y8-04",
		year: 8,
		num: 4,
		file: "events/y8-04.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { seq: [{ res: { ore: 1 } }, { dice: [{
					on: [
						1,
						2,
						3
					],
					do: { milestone: "Hot Goods|red" }
				}] }] },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y8-05",
		year: 8,
		num: 5,
		file: "events/y8-05.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 2 } } },
			b: { do: { milestone: "Noble|silver" } }
		}
	},
	{
		id: "y8-06",
		year: 8,
		num: 6,
		file: "events/y8-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				cost: { gold: 2 },
				if: { minRes: { gold: 2 } },
				label: {
					zh: "若已有至少2金币：花2金币得1幸福",
					en: "If you have 2+ gold: Spend 2 gold for 1 happiness"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { maxRes: { gold: 1 } },
				label: {
					zh: "若金币不足2：先做一次地图行动",
					en: "If under 2 gold: Take 1 map action"
				}
			}
		}
	},
	{
		id: "y8-07",
		year: 8,
		num: 7,
		file: "events/y8-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { none: !0 },
				if: { milestone: "Test Subject" },
				label: {
					zh: "已有测试对象里程碑：花2食物或失去1幸福",
					en: "With Test Subject milestone: Spend 2 food or lose 1 happiness"
				}
			},
			b: {
				do: { extraAction: 1 },
				cost: { gold: 1 },
				if: { notMilestone: "Test Subject" },
				label: {
					zh: "未有测试对象里程碑：可花1金币多做1次行动",
					en: "Without Test Subject milestone: Spend 1 gold for 1 extra action"
				}
			}
		}
	},
	{
		id: "y8-08",
		year: 8,
		num: 8,
		file: "events/y8-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "8N",
					cover: !0
				},
				if: { noneStickers: ["4C", "10C"] },
				label: {
					zh: "无消防站或水塔：覆盖放置8N",
					en: "Without Fire Station/Water Tower: Place 8N covering"
				}
			},
			b: {
				do: { none: !0 },
				if: { anySticker: ["4C", "10C"] },
				label: {
					zh: "已有消防站或水塔：处理热气球（读29.7或29.8）",
					en: "With Fire Station/Water Tower: Handle the balloon (read 29.7 or 29.8)"
				}
			}
		}
	},
	{
		id: "y8-09",
		year: 8,
		num: 9,
		file: "events/y8-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { none: !0 },
				if: { minCalmResidents: 8 },
				label: {
					zh: "有8名以上未不满居民：卡牌行动耗0资源",
					en: "With 8+ non-upset residents: Card actions cost 0 resources"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { maxCalmResidents: 7 },
				label: {
					zh: "不足8名未不满居民：可多做1次行动",
					en: "With fewer than 8: Take 1 extra action"
				}
			}
		}
	},
	{
		id: "y8-10",
		year: 8,
		num: 10,
		file: "events/y8-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造糖果店",
				en: "Build candy shop"
			},
			do: { card: "56" },
			cost: {
				wood: 3,
				food: 1,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造夏令营",
				en: "Build summer camp"
			},
			do: { place: "10G" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y8-11",
		year: 8,
		num: 11,
		file: "events/y8-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造银行",
				en: "Build bank"
			},
			do: { place: "8V" },
			cost: {
				wood: 3,
				ore: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造报社",
				en: "Build newspaper press"
			},
			do: { place: "7K" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y8-12",
		year: 8,
		num: 12,
		file: "events/y8-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造宅邸：阿比盖尔",
				en: "Build mansion: Lady Abigail"
			},
			do: { card: "53" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造宅邸：尼古拉斯",
				en: "Build mansion: Nicholas Jackson"
			},
			do: { card: "54" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y9-01",
		year: 9,
		num: 1,
		file: "events/y9-01.webp",
		kind: "choice",
		opts: { a: { do: { extraAction: 1 } } }
	},
	{
		id: "y9-02",
		year: 9,
		num: 2,
		file: "events/y9-02.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造围栏",
				en: "Build fence"
			},
			do: {
				place: "12R",
				n: 2
			},
			cost: { wood: 2 },
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { wood: 3 },
				do: { none: !0 }
			}, { do: { upset: 1 } }],
			discard: !0
		}
	},
	{
		id: "y9-03",
		year: 9,
		num: 3,
		file: "events/y9-03.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "11A" } },
			b: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y9-04",
		year: 9,
		num: 4,
		file: "events/y9-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { gold: 1 } },
				if: { hasSticker: "5A" },
				label: {
					zh: "有狼崽：得1金币",
					en: "With the wolf pup: Gain 1 gold"
				}
			},
			b: {
				do: { hap: 1 },
				if: { notSticker: "5A" },
				label: {
					zh: "无狼崽：得1幸福",
					en: "Without the wolf pup: Gain 1 happiness"
				}
			}
		}
	},
	{
		id: "y9-05",
		year: 9,
		num: 5,
		file: "events/y9-05.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "8Y",
				cover: !0
			} },
			b: { do: { skipAction: !0 } },
			c: {
				do: { none: !0 },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y9-06",
		year: 9,
		num: 6,
		file: "events/y9-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				if: { anySticker: ["7H", "4D"] },
				label: {
					zh: "有图书馆和/或学校：得1幸福",
					en: "With Library and/or School: Gain 1 happiness"
				}
			},
			b: {
				do: {
					place: "1G",
					cover: !0
				},
				if: { noneStickers: ["7H", "4D"] },
				label: {
					zh: "没有图书馆和学校：覆盖放置枯灌木1G",
					en: "Without Library/School: Place dead bush 1G covering"
				}
			}
		}
	},
	{
		id: "y9-07",
		year: 9,
		num: 7,
		file: "events/y9-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { upset: 1 },
				if: { milestone: "Unrest" },
				label: {
					zh: "有动乱里程碑：放置1个不满贴纸",
					en: "With Unrest milestone: Place 1 upset sticker"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { notMilestone: "Unrest" },
				label: {
					zh: "无动乱里程碑：多做一次地图行动",
					en: "Without Unrest milestone: Take 1 extra map action"
				}
			}
		}
	},
	{
		id: "y9-08",
		year: 9,
		num: 8,
		file: "events/y9-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { dice: [{
					on: [
						1,
						2,
						3
					],
					do: { story: "24.10" }
				}, {
					on: [
						4,
						5,
						6
					],
					do: { story: "16.9" }
				}] },
				if: { hasSticker: "5M" },
				label: {
					zh: "有野比尔居民：掷骰查表（1-3读24.10，4-6读16.9）",
					en: "With Wild Bill: Roll die (1-3 read 24.10, 4-6 read 16.9)"
				}
			},
			b: {
				do: { place: "3E" },
				cost: { food: 1 },
				if: { notSticker: "5M" },
				label: {
					zh: "无野比尔居民：花1食物放道路3E或花11A",
					en: "Without Wild Bill: Spend 1 food to place road 3E or flower 11A"
				}
			}
		}
	},
	{
		id: "y9-09",
		year: 9,
		num: 9,
		file: "events/y9-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "招待贵客",
				en: "Impress our guest"
			},
			do: { hap: 1 },
			cost: {
				food: 3,
				gold: 1
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { gold: 3 },
				do: { none: !0 }
			}, { do: { story: "24.6" } }],
			discard: !0
		}
	},
	{
		id: "y9-10",
		year: 9,
		num: 10,
		file: "events/y9-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造镇招牌",
				en: "Build town sign"
			},
			do: { story: "26.9" },
			cost: {
				wood: 1,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y9-11",
		year: 9,
		num: 11,
		file: "events/y9-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造雕塑花园",
				en: "Build sculpture garden"
			},
			do: { seq: [{ place: "8C" }, { hap: 1 }] },
			cost: { gold: 2 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造自雕像",
				en: "Build statue in your likeness"
			},
			do: { seq: [{ place: "8S" }, { milestone: "Immortalized|silver" }] },
			cost: {
				gold: 2,
				ore: 2
			},
			discard: !0
		}]
	},
	{
		id: "y9-12",
		year: 9,
		num: 12,
		file: "events/y9-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造火车站",
				en: "Build train station"
			},
			do: { place: "5E" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 2
			},
			discard: !0
		}]
	},
	{
		id: "y10-01",
		year: 10,
		num: 1,
		file: "events/y10-01.webp",
		kind: "choice",
		opts: {
			a: { do: { seq: [{ res: { wood: 3 } }, {
				place: "6K",
				cover: !0
			}] } },
			b: { do: { place: "12H" } }
		}
	},
	{
		id: "y10-02",
		year: 10,
		num: 2,
		file: "events/y10-02.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "修建道路",
				en: "Road construction"
			},
			do: {
				place: "3E",
				cover: !0
			},
			discard: !0
		}]
	},
	{
		id: "y10-03",
		year: 10,
		num: 3,
		file: "events/y10-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { none: !0 },
				label: {
					zh: "对在场卡行动时少付1资源",
					en: "Take a card action at a 1-resource discount"
				}
			},
			b: {
				do: { extraAction: 1 },
				label: {
					zh: "弃掉该卡并多做1次行动",
					en: "Discard that card for 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-04",
		year: 10,
		num: 4,
		file: "events/y10-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: -1 },
				if: { minRedMilestones: 2 },
				label: {
					zh: "有至少2个红色里程碑：失去1幸福或覆盖★",
					en: "With 2+ red milestones: Lose 1 happiness or cover a star"
				}
			},
			b: {
				do: { hap: 1 },
				if: { maxRedMilestones: 1 },
				label: {
					zh: "红色里程碑不足2个：得1幸福或多做1次行动",
					en: "With under 2 red milestones: Gain 1 happiness or take 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-05",
		year: 10,
		num: 5,
		file: "events/y10-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				if: { notMilestone: "Pro Angler" },
				label: {
					zh: "无职业钓手里程碑：在12A/12B钓鱼（可花1食物重掷）",
					en: "Without Pro Angler: Go Fishing on 12A/12B (spend 1 food to reroll)"
				}
			},
			b: {
				do: { hap: 1 },
				if: { milestone: "Pro Angler" },
				label: {
					zh: "有职业钓手里程碑：得1幸福",
					en: "With Pro Angler: Gain 1 happiness"
				}
			}
		}
	},
	{
		id: "y10-06",
		year: 10,
		num: 6,
		file: "events/y10-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "12G",
					cover: !0
				},
				if: { minUpset: 1 },
				label: {
					zh: "有不满居民：失去1幸福或花2食物覆盖12G",
					en: "With an upset resident: Lose 1 happiness or spend 2 food to cover with 12G"
				}
			},
			b: {
				do: { place: "11M" },
				if: { maxUpset: 0 },
				label: {
					zh: "无不满居民：在带居民的建筑放11M",
					en: "Without an upset resident: Place 11M on a building with a resident"
				}
			}
		}
	},
	{
		id: "y10-07",
		year: 10,
		num: 7,
		file: "events/y10-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "11B",
					n: 2
				},
				cost: { gold: 2 },
				if: { milestone: "Farming" },
				label: {
					zh: "有农业里程碑：花0-3金币，每金币放1个农场动物11B",
					en: "With Farming milestone: Spend 0-3 gold; place farm animal 11B per gold"
				}
			},
			b: {
				do: { branch: "y10-07b" },
				if: { notMilestone: "Farming" },
				label: {
					zh: "无农业里程碑：有总统里程碑得1幸福，否则得1金币",
					en: "Without Farming: With President gain 1 happiness, otherwise 1 gold"
				}
			}
		}
	},
	{
		id: "y10-08",
		year: 10,
		num: 8,
		file: "events/y10-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { place: "11A" },
				label: {
					zh: "无垃圾或污染工厂：花0-2食物，每食物放1个花11A",
					en: "Without trash/polluted factories: Spend 0-2 food; place flower 11A each"
				}
			},
			b: {
				do: { seq: [
					{ hap: -1 },
					{
						pickRes: [
							"wood",
							"food",
							"gold",
							"ore"
						],
						n: 1
					},
					{ extraAction: 1 }
				] },
				label: {
					zh: "有垃圾或污染工厂：可失去1幸福，得1自选资源并多做1次行动",
					en: "With trash/polluted factories: Lose 1 happiness to gain 1 resource and 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-09",
		year: 10,
		num: 9,
		file: "events/y10-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { removeMilestone: "Hot Goods" },
				if: { milestone: "Hot Goods" },
				label: {
					zh: "有赃物里程碑：可花2金币或1矿石移除",
					en: "With Hot Goods: Spend 2 gold or 1 ore to remove it"
				}
			},
			b: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				if: { notMilestone: "Hot Goods" },
				label: {
					zh: "无赃物里程碑：可花2食物多做1次行动",
					en: "Without Hot Goods: Spend 2 food for 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-10",
		year: 10,
		num: 10,
		file: "events/y10-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建立贸易路线",
				en: "Establish trade route"
			},
			do: { seq: [{ res: { gold: 3 } }, { milestone: "Ore Tycoon|silver" }] },
			cost: { ore: 2 },
			discard: !0
		}]
	},
	{
		id: "y10-11",
		year: 10,
		num: 11,
		file: "events/y10-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "植树",
				en: "Plant tree"
			},
			do: { place: "8X" },
			cost: { gold: 3 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "翻修邻居房屋",
				en: "Renovate neighbor's home"
			},
			do: { seq: [{
				place: "10N",
				cover: !0
			}] },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}]
	},
	{
		id: "y10-12",
		year: 10,
		num: 12,
		file: "events/y10-12.webp",
		kind: "keep",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "花费 2 食物，本回合多执行一次行动",
					en: "Spend 2 food for an additional action this turn"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "不花费",
					en: "Do not spend"
				}
			}
		},
		keepText: {
			zh: "无论是否花费，本牌均留在场上。",
			en: "Regardless, keep this card in play."
		},
		endOfYear: {
			auto: { story: "31.1" },
			discard: !1
		}
	}
], y = Object.fromEntries(v.map((e) => [e.id, e])), b = {
	wood: 12,
	food: 12,
	gold: 12,
	ore: 6
}, x = [
	["09-01", "09-02"],
	["09-03", "09-04"],
	["09-05", "09-06"],
	["09-07", "09-08"],
	["09-09", "09-10"],
	["09-11", "09-12"],
	["09-13", "09-14"],
	["09-15", "09-16"]
], S = {
	wood: ["木材", "Wood"],
	food: ["食物", "Food"],
	gold: ["金币", "Gold"],
	ore: ["矿石", "Ore"]
}, C = [
	{
		id: "01-1 Heart",
		code: "1 Heart",
		name: "1 Heart",
		page: 1,
		kind: "token",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s000.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1 Progress",
		code: "1 Progress",
		name: "1 Progress",
		page: 1,
		kind: "token",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s001.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1 Upset",
		code: "1 Upset",
		name: "1 Upset",
		page: 1,
		kind: "token",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s002.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1A",
		code: "1A",
		name: "1A",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s003.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1B",
		code: "1B",
		name: "1B",
		page: 1,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s004.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1C",
		code: "1C",
		name: "1C",
		page: 1,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s005.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1D",
		code: "1D",
		name: "1D",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s006.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1E",
		code: "1E",
		name: "1E",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s007.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1F",
		code: "1F",
		name: "1F",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s008.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1G",
		code: "1G",
		name: "1G",
		page: 1,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s009.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1H",
		code: "1H",
		name: "1H",
		page: 1,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s010.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Adventurer",
		code: "2 Adventurer",
		name: "2 Adventurer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s011.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Astronomer",
		code: "2 Astronomer",
		name: "2 Astronomer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s012.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Avian Enthusiast",
		code: "2 Avian Enthusiast",
		name: "2 Avian Enthusiast",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s013.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Bear Tamer",
		code: "2 Bear Tamer",
		name: "2 Bear Tamer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s014.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Big Savings Account",
		code: "2 Big Savings Account",
		name: "2 Big Savings Account",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s015.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Brider",
		code: "2 Brider",
		name: "2 Brider",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s016.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Business Mogul",
		code: "2 Business Mogul",
		name: "2 Business Mogul",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s017.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Camp Counselor",
		code: "2 Camp Counselor",
		name: "2 Camp Counselor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s018.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Conservationist",
		code: "2 Conservationist",
		name: "2 Conservationist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s019.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Dating",
		code: "2 Dating",
		name: "2 Dating",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s020.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Degenerate",
		code: "2 Degenerate",
		name: "2 Degenerate",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s021.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Dictator",
		code: "2 Dictator",
		name: "2 Dictator",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s022.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Expert Baker",
		code: "2 Expert Baker",
		name: "2 Expert Baker",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s023.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Explorer",
		code: "2 Explorer",
		name: "2 Explorer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s024.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fake News",
		code: "2 Fake News",
		name: "2 Fake News",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s025.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Famous Baker",
		code: "2 Famous Baker",
		name: "2 Famous Baker",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s026.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Famous Chef",
		code: "2 Famous Chef",
		name: "2 Famous Chef",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s027.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Farm Hand",
		code: "2 Farm Hand",
		name: "2 Farm Hand",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s028.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fasionable",
		code: "2 Fasionable",
		name: "2 Fasionable",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s029.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Finder of Secrets",
		code: "2 Finder of Secrets",
		name: "2 Finder of Secrets",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s030.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fisher",
		code: "2 Fisher",
		name: "2 Fisher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s031.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Glamorous",
		code: "2 Glamorous",
		name: "2 Glamorous",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s032.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Governor",
		code: "2 Governor",
		name: "2 Governor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s033.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Greedy Company",
		code: "2 Greedy Company",
		name: "2 Greedy Company",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s034.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Green Thumb",
		code: "2 Green Thumb",
		name: "2 Green Thumb",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s035.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hard Winter",
		code: "2 Hard Winter",
		name: "2 Hard Winter",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s036.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Honest Company",
		code: "2 Honest Company",
		name: "2 Honest Company",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s037.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hot Goods",
		code: "2 Hot Goods",
		name: "2 Hot Goods",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s038.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hunger",
		code: "2 Hunger",
		name: "2 Hunger",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s039.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Immortalized",
		code: "2 Immortalized",
		name: "2 Immortalized",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s040.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Investment",
		code: "2 Investment",
		name: "2 Investment",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s041.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Kind",
		code: "2 Kind",
		name: "2 Kind",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s042.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Legendary Rancher",
		code: "2 Legendary Rancher",
		name: "2 Legendary Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s043.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Little Genius",
		code: "2 Little Genius",
		name: "2 Little Genius",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s044.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Loan",
		code: "2 Loan",
		name: "2 Loan",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s045.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Apprentice",
		code: "2 Lodge Apprentice",
		name: "2 Lodge Apprentice",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s046.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Master",
		code: "2 Lodge Master",
		name: "2 Lodge Master",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s047.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Member",
		code: "2 Lodge Member",
		name: "2 Lodge Member",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s048.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lucky",
		code: "2 Lucky",
		name: "2 Lucky",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s049.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Married",
		code: "2 Married",
		name: "2 Married",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s050.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Master Chef",
		code: "2 Master Chef",
		name: "2 Master Chef",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s051.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Master of Agriculture",
		code: "2 Master of Agriculture",
		name: "2 Master of Agriculture",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s052.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Matchmaker",
		code: "2 Matchmaker",
		name: "2 Matchmaker",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s053.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Mayor",
		code: "2 Mayor",
		name: "2 Mayor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s054.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Miracle Medicine",
		code: "2 Miracle Medicine",
		name: "2 Miracle Medicine",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s055.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Monarch",
		code: "2 Monarch",
		name: "2 Monarch",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s056.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 New Family",
		code: "2 New Family",
		name: "2 New Family",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s057.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Noble",
		code: "2 Noble",
		name: "2 Noble",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s058.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Ore Tycoon",
		code: "2 Ore Tycoon",
		name: "2 Ore Tycoon",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s059.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Ornithologist",
		code: "2 Ornithologist",
		name: "2 Ornithologist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s060.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Paleontologist",
		code: "2 Paleontologist",
		name: "2 Paleontologist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s061.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Patron of the Arts",
		code: "2 Patron of the Arts",
		name: "2 Patron of the Arts",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s062.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Perfect Village",
		code: "2 Perfect Village",
		name: "2 Perfect Village",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s063.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pet Lover",
		code: "2 Pet Lover",
		name: "2 Pet Lover",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s064.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pet Rescuer",
		code: "2 Pet Rescuer",
		name: "2 Pet Rescuer",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s065.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Poisoned",
		code: "2 Poisoned",
		name: "2 Poisoned",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s066.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 President",
		code: "2 President",
		name: "2 President",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s067.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pro Angler",
		code: "2 Pro Angler",
		name: "2 Pro Angler",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s068.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Rancher",
		code: "2 Rancher",
		name: "2 Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s069.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Runner Up",
		code: "2 Runner Up",
		name: "2 Runner Up",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s070.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Savings Account",
		code: "2 Savings Account",
		name: "2 Savings Account",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s071.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Secret Spy",
		code: "2 Secret Spy",
		name: "2 Secret Spy",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s072.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Sleuth",
		code: "2 Sleuth",
		name: "2 Sleuth",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s073.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Termites",
		code: "2 Termites",
		name: "2 Termites",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s074.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Test Subject",
		code: "2 Test Subject",
		name: "2 Test Subject",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s075.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Thriving Community",
		code: "2 Thriving Community",
		name: "2 Thriving Community",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s076.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Treasure Hunter",
		code: "2 Treasure Hunter",
		name: "2 Treasure Hunter",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s077.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Trustworthy News",
		code: "2 Trustworthy News",
		name: "2 Trustworthy News",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s078.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Tyrant",
		code: "2 Tyrant",
		name: "2 Tyrant",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s079.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Unrest",
		code: "2 Unrest",
		name: "2 Unrest",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s080.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Upstanding",
		code: "2 Upstanding",
		name: "2 Upstanding",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s081.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Veteran Rancher",
		code: "2 Veteran Rancher",
		name: "2 Veteran Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s082.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-Veteran Fisher",
		code: "Veteran Fisher",
		name: "Veteran Fisher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s083.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3A",
		code: "3A",
		name: "3A",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s084.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3B",
		code: "3B",
		name: "3B",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s085.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3C",
		code: "3C",
		name: "3C",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s086.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3D",
		code: "3D",
		name: "3D",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s087.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3E",
		code: "3E",
		name: "3E",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s088.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4A",
		code: "4A",
		name: "4A",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s089.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4B",
		code: "4B",
		name: "4B",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s090.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4C",
		code: "4C",
		name: "4C",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s091.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4D",
		code: "4D",
		name: "4D",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s092.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "21.1"
	},
	{
		id: "04-4E",
		code: "4E",
		name: "4E",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s093.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4F",
		code: "4F",
		name: "4F",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s094.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4G",
		code: "4G",
		name: "4G",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s095.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4H",
		code: "4H",
		name: "4H",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s096.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "16.1"
	},
	{
		id: "04-4K",
		code: "4K",
		name: "4K",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s097.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4M",
		code: "4M",
		name: "4M",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s098.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.9"
	},
	{
		id: "04-4N",
		code: "4N",
		name: "4N",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s099.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4P",
		code: "4P",
		name: "4P",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s100.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4Q",
		code: "4Q",
		name: "4Q",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s101.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4R",
		code: "4R",
		name: "4R",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s102.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4S",
		code: "4S",
		name: "4S",
		page: 4,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s103.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "19.1"
	},
	{
		id: "04-4T",
		code: "4T",
		name: "4T",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s104.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4U",
		code: "4U",
		name: "4U",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s105.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "18.7"
	},
	{
		id: "04-4V",
		code: "4V",
		name: "4V",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s106.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4W",
		code: "4W",
		name: "4W",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s107.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4X",
		code: "4X",
		name: "4X",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s108.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "04-4Y",
		code: "4Y",
		name: "4Y",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s109.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5A",
		code: "5A",
		name: "5A",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s110.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5B",
		code: "5B",
		name: "5B",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s111.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5C",
		code: "5C",
		name: "5C",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s112.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5D",
		code: "5D",
		name: "5D",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s113.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5E",
		code: "5E",
		name: "5E b",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s114.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "12.8"
	},
	{
		id: "05-5Eb",
		code: "5E",
		name: "5E",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s115.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "12.8"
	},
	{
		id: "05-5F",
		code: "5F",
		name: "5F",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s116.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5G",
		code: "5G",
		name: "5G",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s117.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5H",
		code: "5H",
		name: "5H",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s118.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "14.1"
	},
	{
		id: "05-5K",
		code: "5K",
		name: "5K",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s119.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5M",
		code: "5M",
		name: "5M",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s120.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5N",
		code: "5N",
		name: "5N",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s121.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5P",
		code: "5P",
		name: "5P",
		page: 5,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s122.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "05-5Q",
		code: "5Q",
		name: "5Q",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s123.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1
	},
	{
		id: "05-5R",
		code: "5R",
		name: "5R",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s124.webp",
		wood: 1,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6A",
		code: "6A",
		name: "6A",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s125.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6B",
		code: "6B",
		name: "6B",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s126.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6C",
		code: "6C",
		name: "6C",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s127.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6D",
		code: "6D",
		name: "6D",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s128.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6E",
		code: "6E",
		name: "6E",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s129.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6F",
		code: "6F",
		name: "6F",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s130.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6G",
		code: "6G",
		name: "6G",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s131.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6H",
		code: "6H",
		name: "6H",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s132.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1
	},
	{
		id: "06-6M",
		code: "6M",
		name: "6M",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s133.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6N",
		code: "6N",
		name: "6N",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s134.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6P",
		code: "6P",
		name: "6P",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s135.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6Q",
		code: "6Q",
		name: "6Q",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s136.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6R",
		code: "6R",
		name: "6R",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s137.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6T",
		code: "6T",
		name: "6T",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s138.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6U",
		code: "6U",
		name: "6U",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s139.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6V",
		code: "6V",
		name: "6V",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s140.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 1
	},
	{
		id: "06-6X",
		code: "6X",
		name: "6X",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s141.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6Y",
		code: "6Y",
		name: "6Y",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s142.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6Z",
		code: "6Z",
		name: "6Z",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s143.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1
	},
	{
		id: "07-7A",
		code: "7A",
		name: "7A",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s144.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.1"
	},
	{
		id: "07-7B",
		code: "7B",
		name: "7B",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s145.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7C",
		code: "7C",
		name: "7C",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s146.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7D",
		code: "7D",
		name: "7D",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s147.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7E",
		code: "7E",
		name: "7E",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s148.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7F",
		code: "7F",
		name: "7F",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s149.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7G",
		code: "7G",
		name: "7G",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s150.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7H",
		code: "7H",
		name: "7H",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s151.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7K",
		code: "7K",
		name: "7K",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s152.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "29.2"
	},
	{
		id: "07-7N",
		code: "7N",
		name: "7N",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s153.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7P",
		code: "7P",
		name: "7P",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s154.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7Q",
		code: "7Q",
		name: "7Q",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s155.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7R",
		code: "7R",
		name: "7R",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s156.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "07-7X",
		code: "7X",
		name: "7X",
		page: 7,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s157.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8A",
		code: "8A",
		name: "8A",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s158.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "10.1"
	},
	{
		id: "08-8B",
		code: "8B",
		name: "8B",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s159.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8C",
		code: "8C",
		name: "8C",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s160.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8D",
		code: "8D",
		name: "8D",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s161.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8E",
		code: "8E",
		name: "8E",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s162.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8F",
		code: "8F",
		name: "8F",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s163.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8G",
		code: "8G",
		name: "8G",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s164.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8H",
		code: "8H",
		name: "8H",
		page: 8,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s165.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8K",
		code: "8K",
		name: "8K",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s166.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8M",
		code: "8M",
		name: "8M",
		page: 8,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s167.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "20.1"
	},
	{
		id: "08-8N",
		code: "8N",
		name: "8N",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s168.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8P",
		code: "8P",
		name: "8P",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s169.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8Q",
		code: "8Q",
		name: "8Q",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s170.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8R",
		code: "8R",
		name: "8R",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s171.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8S",
		code: "8S",
		name: "8S",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s172.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8T",
		code: "8T",
		name: "8T",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s173.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8U",
		code: "8U",
		name: "8U",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s174.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8V",
		code: "8V",
		name: "8V",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s175.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "27.2"
	},
	{
		id: "08-8W",
		code: "8W",
		name: "8W",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s176.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8X",
		code: "8X",
		name: "8X",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s177.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "08-8Y",
		code: "8Y",
		name: "8Y",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s178.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-01",
		code: "9A",
		name: "9A",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s179.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-02",
		code: "9B",
		name: "9B",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s180.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-03",
		code: "9C",
		name: "9C",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s181.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "09-04",
		code: "9D",
		name: "9D",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s182.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-05",
		code: "9E",
		name: "9E",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s183.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-06",
		code: "9F",
		name: "9F",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s184.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "09-07",
		code: "9G",
		name: "9G",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s185.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-08",
		code: "9H",
		name: "9H",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s186.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-09",
		code: "9I",
		name: "9I",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s187.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-10",
		code: "9J",
		name: "9J",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s188.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-11",
		code: "9K",
		name: "9K",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s189.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-12",
		code: "9L",
		name: "9L",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s190.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-13",
		code: "9M",
		name: "9M",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s191.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-14",
		code: "9N",
		name: "9N",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s192.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "09-15",
		code: "9O",
		name: "9O",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s193.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0
	},
	{
		id: "09-16",
		code: "9P",
		name: "9P",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s194.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10A",
		code: "10A",
		name: "10A",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s195.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10B",
		code: "10B",
		name: "10B",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s196.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10C",
		code: "10C",
		name: "10C",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s197.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "8.8"
	},
	{
		id: "10-10D",
		code: "10D",
		name: "10D",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s198.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		story: "24.7"
	},
	{
		id: "10-10E",
		code: "10E",
		name: "10E",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s199.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10F",
		code: "10F",
		name: "10F",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s200.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10G",
		code: "10G",
		name: "10G",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s201.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		story: "30.2"
	},
	{
		id: "10-10H",
		code: "10H",
		name: "10H",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s202.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10K",
		code: "10K",
		name: "10K",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s203.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10M",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s204.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10M#2",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s205.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10M#3",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s206.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10M#4",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s207.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-10N",
		code: "10N",
		name: "10N",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s208.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g01",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s209.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g02",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s210.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g03",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s211.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g04",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s212.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g05",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s213.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g06",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s214.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g07",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s215.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g08",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s216.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g09",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s217.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g10",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s218.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g11",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s219.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g12",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s220.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g13",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s221.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g14",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s222.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g15",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s223.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g16",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s224.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g17",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s225.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g18",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s226.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g19",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s227.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g20",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s228.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g21",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s229.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g22",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s230.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g23",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s231.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g24",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s232.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g25",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s233.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g26",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s234.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g27",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s235.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g28",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s236.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g29",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s237.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g30",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s238.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g31",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s239.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g32",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s240.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g33",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s241.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g34",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s242.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g35",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s243.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g36",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s244.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11A",
		code: "11A",
		name: "11A",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11a.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11B",
		code: "11B",
		name: "11B",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11b.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11C",
		code: "11C",
		name: "11C",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11c.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11D",
		code: "11D",
		name: "11D",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11d.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11E",
		code: "11E",
		name: "11E",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11e.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11F",
		code: "11F",
		name: "11F",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11f.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11G",
		code: "11G",
		name: "11G",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11g.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11H",
		code: "11H",
		name: "11H",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11h.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11K",
		code: "11K",
		name: "11K",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11k.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11M",
		code: "11M",
		name: "11M",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11m.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11N",
		code: "11N",
		name: "11N",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/11n.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.8"
	},
	{
		id: "11-11P",
		code: "11P",
		name: "11P",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11p.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11Q",
		code: "11Q",
		name: "11Q",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11q.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11R",
		code: "11R",
		name: "11R",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/11r.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11S",
		code: "11S",
		name: "11S",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/11s.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12A",
		code: "12A",
		name: "12A",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12a.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12B",
		code: "12B",
		name: "12B",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12b.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12C",
		code: "12C",
		name: "12C",
		page: 12,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 2,
		file: "stickers/12c.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12D",
		code: "12D",
		name: "12D",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12d.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12E",
		code: "12E",
		name: "12E",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12e.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12F",
		code: "12F",
		name: "12F",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12f.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12G",
		code: "12G",
		name: "12G",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12g.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12H",
		code: "12H",
		name: "12H",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12h.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12J",
		code: "12J",
		name: "12J",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12j.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12K",
		code: "12K",
		name: "12K",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12k.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12M",
		code: "12M",
		name: "12M",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12m.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12N",
		code: "12N",
		name: "12N",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12n.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12P",
		code: "12P",
		name: "12P",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12p.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12Q",
		code: "12Q",
		name: "12Q",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12q.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12R",
		code: "12R",
		name: "12R",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 2,
		file: "stickers/12r.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12S",
		code: "12S",
		name: "12S",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12s.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "12-12U",
		code: "12U",
		name: "12U",
		page: 12,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/12u.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "06-6K",
		code: "6K",
		name: "6K",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s138.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0
	}
], w = Object.fromEntries(C.map((e) => [e.id, e])), T = C.reduce((e, t) => ((e[t.code] ??= []).push(t), e), {}), E = {
	id: "cozistickerville",
	uuid: "a44fc6d0-0a19-468e-9b9a-63ec6ad897b7",
	sdkApi: 2,
	tier: "alpha",
	mechanics: ["tile-placement", "engine-building"],
	interactionTags: [],
	nameKey: "games.cozistickerville.name",
	descKey: "games.cozistickerville.desc",
	rulesKey: "games.cozistickerville.rules",
	rulesUrl: { en: "https://unexpectedgames.com/s/UGCSV0101_Rulebook.pdf" },
	icon: "🏘️",
	iconImg: "games/cozistickerville.webp",
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#d98c4a",
	releasedAt: "2026-11-27T18:52:00+08:00",
	search: {
		py: "wen xin tie zhi xiao zhen",
		init: "wxtzxz"
	},
	hotseat: "off"
}, D = [
	"wood",
	"food",
	"gold",
	"ore"
], O = e.object({
	wood: e.int().min(0).max(99),
	food: e.int().min(0).max(99),
	gold: e.int().min(0).max(99),
	ore: e.int().min(0).max(99)
}), k = e.object({
	id: e.string().max(24),
	col: e.int().min(0).max(40),
	row: e.int().min(0).max(40),
	cover: e.boolean().optional()
}), A = e.object({
	op: e.enum([
		"res",
		"hap",
		"place",
		"card",
		"story",
		"milestone",
		"removeMilestone",
		"removeSticker",
		"upset",
		"removeUpset",
		"progress",
		"extraAction",
		"skipAction",
		"pickRes",
		"pickCard",
		"pickPlace",
		"exchange",
		"branch",
		"discardCard",
		"discardEvent",
		"ask",
		"none"
	]),
	res: O.partial().optional(),
	n: e.int().min(-99).max(99).optional(),
	code: e.string().max(24).optional(),
	key: e.string().max(40).optional(),
	pick: e.array(e.string().max(24)).max(8).optional(),
	allow: e.boolean().optional()
}), j = e.enum([
	"starting",
	"morning",
	"choice",
	"afternoon",
	"placing",
	"yearEnd",
	"done"
]), M = e.tuple([e.string(), e.string()]), N = e.object({
	kind: e.enum([
		"place",
		"pickRes",
		"pickCard",
		"pickPlace",
		"pickOpt",
		"exchange"
	]),
	code: e.string().optional(),
	n: e.int().optional(),
	cover: e.boolean().optional(),
	allow: e.boolean().optional(),
	pick: e.array(e.string()).max(8).optional()
}), P = e.object({
	version: e.literal(1),
	campaignId: e.string().max(100),
	serial: e.int().nonnegative(),
	owner: e.string(),
	seed: e.number(),
	cursor: e.int().nonnegative(),
	side: e.enum(["A", "B"]),
	year: e.int().min(1).max(10),
	phase: j,
	resources: O,
	happiness: e.int().min(0).max(30),
	action: e.int().min(-1).max(4).default(0),
	upset: e.int().min(0).max(99).default(0),
	progress: e.int().min(0).max(99).default(0),
	placed: e.array(k).max(240),
	startingPairs: e.array(e.string()).max(8),
	inPlay: e.array(e.string()).max(40),
	deck: e.array(e.string()).max(24),
	discard: e.array(e.string()).max(240),
	currentEvent: e.string().nullable(),
	queue: e.array(A).max(120),
	prompt: N.nullable(),
	after: e.enum([
		"afternoon",
		"yearEnd",
		"morning"
	]).nullable(),
	yearEnding: e.boolean().default(!1),
	yearEndQueue: e.array(e.string().max(40)).max(160).default([]),
	catalog: e.array(e.string()).max(80),
	story: e.array(e.string()).max(240),
	milestones: e.array(e.string()).max(80),
	log: e.array(M).max(120)
}), F = e.object({
	checkpoint: P.nullable().default(null),
	side: e.enum(["A", "B"]).default("A")
}).prefault({}), ne = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("placeStarting"),
		id: e.string().max(24),
		col: e.int(),
		row: e.int()
	}),
	e.object({
		type: e.literal("placePending"),
		col: e.int(),
		row: e.int()
	}),
	e.object({ type: e.literal("skipPlace") }),
	e.object({ type: e.literal("draw") }),
	e.object({
		type: e.literal("choice"),
		opt: e.enum([
			"a",
			"b",
			"c"
		])
	}),
	e.object({
		type: e.literal("resolvePrompt"),
		key: e.string().max(40)
	}),
	e.object({
		type: e.literal("useSticker"),
		code: e.string().max(24)
	}),
	e.object({
		type: e.literal("useCard"),
		key: e.string().max(40)
	}),
	e.object({
		type: e.literal("useKeep"),
		id: e.string().max(24),
		key: e.string().max(40)
	}),
	e.object({ type: e.literal("endTurn") }),
	e.object({ type: e.literal("endYear") }),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), I = e.object({
	key: e.enum([
		"a",
		"b",
		"c"
	]),
	label: M,
	enabled: e.boolean()
}), re = e.object({
	key: e.string().max(40),
	label: M,
	enabled: e.boolean()
}), ie = e.object({
	id: e.string(),
	key: e.string(),
	label: M,
	enabled: e.boolean()
}), ae = e.object({
	id: e.string(),
	code: e.string(),
	story: e.string(),
	label: M,
	enabled: e.boolean()
}), oe = e.object({
	campaignId: e.string(),
	side: e.enum(["A", "B"]),
	year: e.int(),
	phase: e.enum([
		"starting",
		"morning",
		"choice",
		"afternoon",
		"placing",
		"yearEnd",
		"done"
	]),
	resources: O,
	happiness: e.int(),
	action: e.int(),
	upset: e.int(),
	progress: e.int(),
	placed: e.array(k),
	startingPairs: e.array(e.string()),
	deckCount: e.int(),
	discard: e.array(e.string()),
	currentEvent: e.string().nullable(),
	inPlay: e.array(e.string()),
	prompt: N.nullable(),
	promptOptions: e.array(re),
	catalog: e.array(e.string()),
	story: e.array(e.string()),
	milestones: e.array(e.string()),
	choices: e.array(I),
	keepActions: e.array(ie),
	catalogActions: e.array(ie),
	stickerActions: e.array(ae),
	ending: e.string().nullable(),
	mapIcons: O,
	log: e.array(M)
}), se = e.object({ checkpoint: P.nullable() }), L = Object.fromEntries([
	{
		label: "3a",
		file: "catalog/c3a.webp",
		entry: {
			place: "9C",
			cover: !0
		},
		actions: [{
			label: {
				zh: "拾取落枝",
				en: "GATHER FALLEN BRANCHES"
			},
			do: { res: { wood: 1 } }
		}, {
			label: {
				zh: "寻找木柴",
				en: "HUNT FOR WOOD"
			},
			do: { dice: [
				{
					on: [1],
					do: { res: { wood: 1 } }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { wood: 2 } }
				},
				{
					on: [5],
					do: { res: { wood: 3 } }
				},
				{
					on: [6],
					do: { story: "6.2" }
				}
			] }
		}]
	},
	{
		label: "2",
		file: "catalog/c2.webp",
		entry: { place: "6B" },
		action: {
			label: {
				zh: "建造工厂",
				en: "BUILD FACTORY"
			},
			do: {
				place: "11R",
				cover: !0
			},
			discard: !0
		}
	},
	{
		label: "1",
		file: "catalog/c1.webp",
		name: {
			zh: "迪尔",
			en: "DILL"
		},
		entry: { place: "8A" },
		action: {
			label: {
				zh: "种植黄瓜地",
				en: "PLANT CUCUMBER PATCH"
			},
			do: { place: "6M" },
			discard: !0
		}
	},
	{
		label: "8",
		file: "catalog/c8.webp",
		entry: { place: "10A" },
		actions: [{
			label: {
				zh: "领养农场动物（放置 2 枚 11B 农场动物贴纸；若已放置 4 枚，弃掉此牌并获得卡牌 17）",
				en: "ADOPT FARM ANIMALS (place 2 farm animal stickers 11B; then, if 4 have been placed, discard this and gain card 17)"
			},
			do: {
				place: "11B",
				n: 2
			},
			followUp: "cat8a"
		}, {
			label: {
				zh: "购买种子（放置贴纸 6N 或 6P；若两者均已放置，弃掉此牌并获得卡牌 16）",
				en: "BUY SEEDS (place sticker 6N or 6P; then, if both have been placed, discard this and gain card 16)"
			},
			do: { pickPlace: ["6N", "6P"] },
			followUp: "cat8b"
		}]
	},
	{
		label: "7",
		file: "catalog/c7.webp",
		entry: { place: "6F" },
		action: {
			label: {
				zh: "竞选市长（放置 2 枚 11C 政治贴纸；可花费 1 金币再放 1 枚；随后若认为支持足够，弃掉此牌并阅读 35.2，否则保留此牌）",
				en: "RUN FOR MAYOR (place 2 political stickers 11C; you may spend 1 gold to place 1 additional; then, if you think you have enough support, discard this and read 35.2, otherwise keep this in play)"
			},
			do: { seq: [
				{
					place: "11C",
					n: 2
				},
				{ ask: "cat7extra" },
				{ ask: "cat7end" }
			] }
		}
	},
	{
		label: "13",
		file: "catalog/c13.webp",
		name: {
			zh: "市长抱负",
			en: "MAYOR AMBITION"
		},
		entry: { milestone: "Mayor|gold" },
		actions: [{
			label: {
				zh: "竞选州长",
				en: "RUN FOR GOVERNOR"
			},
			do: { story: "9.3" },
			if: { minHearts: 5 }
		}, {
			label: {
				zh: "征税（若居民≥9，阅读 22.8）",
				en: "RAISE TAXES (if 9+ residents, read 22.8)"
			},
			do: { story: "22.8" },
			if: { minResidents: 9 },
			followUp: "story22.8"
		}]
	},
	{
		label: "6",
		file: "catalog/c6.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "解读语言（将此牌对应格位全部放上 1D 贴纸；若这些贴纸已放置，则改为放置全部 5P 贴纸）",
				en: "DECIPHER LANGUAGE (place all 1D stickers on the proper spaces of this card; if they are already placed, instead place all 5P stickers)"
			},
			do: { place: "1D" }
		}
	},
	{
		label: "5",
		file: "catalog/c5.webp",
		entry: { seq: [{ removeMilestone: "Politics 1" }, { milestone: "Governor|silver" }] },
		action: {
			label: {
				zh: "宏大抱负（依此牌上的贴纸数量阅读故事：0 枚阅读 25.4；1 枚阅读 25.5；2 枚阅读 25.6）",
				en: "GRAND AMBITION (read the story based on the number of stickers on this card: 0 read 25.4; 1 read 25.5; 2 read 25.6)"
			},
			do: { story: "25.4" }
		}
	},
	{
		label: "4",
		file: "catalog/c4.webp",
		entry: {
			place: "9C",
			cover: !0
		}
	},
	{
		label: "3b",
		file: "catalog/c3b.webp",
		entry: {
			place: "9C",
			cover: !0
		},
		actions: [{
			label: {
				zh: "拾取落枝",
				en: "GATHER FALLEN BRANCHES"
			},
			do: { res: { wood: 1 } }
		}, {
			label: {
				zh: "寻找木柴",
				en: "HUNT FOR WOOD"
			},
			do: { dice: [
				{
					on: [1],
					do: { res: { wood: 1 } }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { wood: 2 } }
				},
				{
					on: [5],
					do: { res: { wood: 3 } }
				},
				{
					on: [6],
					do: { story: "6.2" }
				}
			] }
		}]
	},
	{
		label: "12b",
		file: "catalog/c12b.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "钓鱼（掷骰：1 获得 1 食物并弃掉此牌上的所有食物；2-6 从供应区在此牌上放置 1 食物（上限 3），然后二选一：收线，阅读 35.1；继续钓，重新掷骰）",
				en: "GO FISHING (roll the die: 1 gain 1 food and discard all food from this card; 2-6 place 1 food on this card from the supply (limit 3), then choose one: reel in the fish, read 35.1; keep fishing, roll the die again)"
			},
			do: { dice: [{
				on: [1],
				do: { res: { food: 1 } }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [{ res: { food: 1 } }, { story: "35.1" }] }
			}] }
		}
	},
	{
		label: "12a",
		file: "catalog/c12a.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "钓鱼（掷骰：1 获得 1 食物并弃掉此牌上的所有食物；2-6 从供应区在此牌上放置 1 食物（上限 3），然后二选一：收线，阅读 36.1；继续钓，重新掷骰）",
				en: "GO FISHING (roll the die: 1 gain 1 food and discard all food from this card; 2-6 place 1 food on this card from the supply (limit 3), then choose one: reel in the fish, read 36.1; keep fishing, roll the die again)"
			},
			do: { dice: [{
				on: [1],
				do: { res: { food: 1 } }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [{ res: { food: 1 } }, { story: "36.1" }] }
			}] }
		}
	},
	{
		label: "11",
		file: "catalog/c11.webp",
		entry: { place: "6G" },
		action: {
			label: {
				zh: "建造蜂房",
				en: "BUILD APIARY"
			},
			do: {
				place: "5B",
				cover: !0
			},
			discard: !0
		},
		endOfYear: { discard: !0 }
	},
	{
		label: "10",
		file: "catalog/c10.webp",
		entry: { place: "7B" },
		action: {
			label: {
				zh: "出售木工制品（获得 2 金币并放置 1 枚 11D 木工贴纸；若已放置 3 枚，弃掉此牌）",
				en: "SELL CARPENTRY (gain 2 gold and place 1 carpentry sticker 11D; then, if 3 have been placed, discard this)"
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "11D" }] },
			followUp: "cat10"
		}
	},
	{
		label: "9",
		file: "catalog/c9.webp",
		entry: { place: "6D" },
		action: {
			label: {
				zh: "买卖（将至多 3 份资源兑换为除矿石外任意类型的资源）",
				en: "BUY AND SELL (exchange up to 3 resources for resources of any type(s) except ore)"
			},
			do: { exchange: { n: 3 } }
		}
	},
	{
		label: "25",
		file: "catalog/c25.webp",
		entry: { place: "8P" },
		action: {
			label: {
				zh: "出售玩具（获得 3 金币并放置 1 枚 11Q 玩具贴纸；若已放置 2 枚，弃掉此牌并获得 1 幸福）",
				en: "SELL TOY (gain 3 gold and place 1 toy sticker 11Q; then, if 2 have been placed, discard this and gain 1 happiness)"
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "11Q" }] },
			followUp: "cat25"
		}
	},
	{
		label: "24",
		file: "catalog/c24.webp",
		entry: { milestone: "Famous Baker|silver" },
		action: {
			label: {
				zh: "出售巨型蛋糕（获得 2 金币并放置 1 枚 12G 蛋糕贴纸，可放在地图或其他贴纸上；若已放置 2 枚，弃掉此牌并获得卡牌 28）",
				en: "SELL GIANT CAKE (gain 2 gold and place 1 cake sticker 12G, on the map or on another sticker; then, if 2 have been placed, discard this and gain card 28)"
			},
			do: { seq: [{ res: { gold: 2 } }, {
				place: "12G",
				cover: !0
			}] },
			followUp: "cat24"
		}
	},
	{
		label: "23",
		file: "catalog/c23.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "出售异域宠物（获得 2 金币并放置 1 枚 12F 异域宠物贴纸；若已放置 2 枚，弃掉此牌并获得卡牌 57）",
				en: "SELL EXOTIC PET (gain 2 gold and place 1 exotic pet sticker 12F; then, if 2 have been placed, discard this and gain card 57)"
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "12F" }] },
			followUp: "cat23"
		}
	},
	{
		label: "16",
		file: "catalog/c16.webp",
		name: {
			zh: "农场帮手雄心",
			en: "FARM HAND AMBITION"
		},
		entry: { milestone: "Farm Hand|gold" },
		actions: [{
			label: {
				zh: "蔬果（若地图上苹果图标≥7，弃掉此牌并获得卡牌 26）",
				en: "FRUITS AND VEGGIES (if 7+ apple icons on the map, discard this and gain card 26)"
			},
			do: { card: "26" },
			if: { minMapRes: { food: 7 } }
		}, {
			label: {
				zh: "毛茸茸的朋友（若地图上的动物贴纸≥5，弃掉此牌并获得卡牌 27；只计入独立动物贴纸，不含其他贴纸的一部分）",
				en: "FURRY FRIENDS (if 5+ animal stickers on the map, discard this and gain card 27; only count each animal that is on its own sticker, not part of another sticker)"
			},
			do: { card: "27" },
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 5
			} }
		}]
	},
	{
		label: "15",
		file: "catalog/c15.webp",
		entry: { milestone: "Runner Up|gold" },
		actions: [{
			label: {
				zh: "变得更受欢迎",
				en: "BECOME MORE POPULAR"
			},
			do: { story: "27.1" },
			if: { minHearts: 6 }
		}, {
			label: {
				zh: "夺取权力（若居民≥8，阅读 27.7）",
				en: "SEIZE POWER (if 8+ residents, read 27.7)"
			},
			do: { story: "27.7" },
			if: { minResidents: 8 }
		}]
	},
	{
		label: "14",
		file: "catalog/c14.webp",
		name: {
			zh: "独裁者的野心",
			en: "DICTATOR AMBITION"
		},
		entry: { milestone: "Dictator|bronze" },
		actions: [{
			label: {
				zh: "收紧掌控（若居民不少于 7，阅读 22.8）",
				en: "TIGHTEN YOUR GRIP (if 7+ residents, read 22.8)"
			},
			do: { story: "22.8" },
			if: { minResidents: 7 },
			followUp: "story22.8"
		}, {
			label: {
				zh: "竞选州长（若幸福不少于 7，阅读 9.3）",
				en: "RUN FOR GOVERNOR (if 7+ happiness, read 9.3)"
			},
			do: { story: "9.3" },
			if: { minHearts: 7 }
		}]
	},
	{
		label: "31",
		file: "catalog/c31.webp",
		action: {
			label: {
				zh: "破解密码（按照这些卡牌上隐藏的指示操作；如需提示，阅读 33.9）",
				en: "CRACK THE CODE (follow the instructions hidden on these cards; if you need a hint, read 33.9)"
			},
			do: { story: "33.9" }
		}
	},
	{
		label: "30",
		file: "catalog/c30.webp",
		entry: {
			place: "9C",
			cover: !0,
			milestone: "Matchmaker|silver"
		},
		action: {
			label: {
				zh: "询问感情状况（按此卡上的贴纸数量阅读对应故事：0 张阅读 11.6，1 张阅读 12.1，2 张阅读 12.2，3 张阅读 12.3）",
				en: "ASK ABOUT RELATIONSHIP (read the story based on the number of stickers on this card: 0→11.6, 1→12.1, 2→12.2, 3→12.3)"
			},
			do: { story: "11.6" }
		}
	},
	{
		label: "22",
		file: "catalog/c22.webp",
		action: {
			label: {
				zh: "破解密码（解开谜题并阅读它指向的故事；若故事不以「Using.」开头，则答案有误；如需提示，阅读 11.7）",
				en: "CRACK THE CODE (solve the puzzle and read the story it points to; if the story does not start with the word \"Using.\", you are incorrect; if you need a hint, read 11.7)"
			},
			do: { story: "11.7" }
		}
	},
	{
		label: "21",
		file: "catalog/c21.webp",
		entry: { place: "4D" },
		action: {
			label: {
				zh: "建造大房子",
				en: "BUILD LARGE HOME"
			},
			do: { place: "4E" },
			cost: { gold: 2 },
			discard: !0
		}
	},
	{
		label: "20",
		file: "catalog/c20.webp",
		entry: { place: "4B" },
		action: {
			label: {
				zh: "出售巨型糕点（若已有 2 张放置，弃置此卡并获得卡 24）",
				en: "SELL GIANT PASTRY (if 2 have been placed, discard this and gain card 24)"
			},
			do: { seq: [{ res: { gold: 2 } }, {
				place: "11F",
				n: 1
			}] },
			cost: { food: 1 },
			followUp: "cat20"
		}
	},
	{
		label: "36",
		file: "catalog/c36.webp",
		entry: { place: "10F" },
		action: {
			label: {
				zh: "准时赴约（在现实中查看时钟，精确匹配分针位置，阅读上方对应的故事。例如 4:00 时阅读 28.2；若是 4:01，则不能执行此行动）",
				en: "A TIMELY APPOINTMENT (check the clock in real life; read the story above matching the minute hand exactly. For example, at 4:00 read 28.2; at 4:01 you cannot perform this action)"
			},
			do: { story: "28.2" }
		}
	},
	{
		label: "35b",
		file: "catalog/c35b.webp",
		entry: { place: "7F" },
		action: {
			label: {
				zh: "探索矿井（选择此卡上与爱心相邻的一个格子，阅读该格所示的故事条目）",
				en: "EXPLORE THE MINE (choose a space on this card adjacent to a heart; read the story entry shown in that space)"
			},
			do: { story: "35.6" }
		}
	},
	{
		label: "35a",
		file: "catalog/c35a.webp",
		entry: { place: "7F" },
		action: {
			label: {
				zh: "探索矿井（选择此卡上与爱心相邻的一个格子，阅读该格所示的故事条目）",
				en: "EXPLORE THE MINE (choose a space on this card adjacent to a heart; read the story entry shown in that space)"
			},
			do: { story: "35.6" }
		}
	},
	{
		label: "29",
		file: "catalog/c29.webp",
		entry: { milestone: "Dating|bronze" },
		action: {
			label: {
				zh: "与农夫迪尔约会（按此卡上的贴纸数量阅读对应故事：0 张阅读 10.7，1 张阅读 11.1，2 张阅读 11.2，3 张阅读 11.3，4 张阅读 11.4，5 张阅读 11.5）",
				en: "DATE FARMER DILL (read the story based on the number of stickers on this card: 0→10.7, 1→11.1, 2→11.2, 3→11.3, 4→11.4, 5→11.5)"
			},
			do: { story: "10.7" }
		}
	},
	{
		label: "28",
		file: "catalog/c28.webp",
		action: {
			label: {
				zh: "烘焙比赛（你希望在这场比赛中投入多少？花费 0 至 5 份食物，然后阅读 26.6）",
				en: "BAKING COMPETITION (how much do you want to invest in this competition? Spend 0 to 5 food, then read 26.6)"
			},
			do: { story: "26.6" }
		}
	},
	{
		label: "27",
		file: "catalog/c27.webp",
		entry: {
			milestone: "Veteran Rancher|silver",
			removeMilestone: "Farming 1"
		},
		action: {
			label: {
				zh: "建造奶牛场",
				en: "BUILD DAIRY FARM"
			},
			do: { place: "10D" },
			cost: {
				wood: 4,
				gold: 3
			},
			discard: !0
		}
	},
	{
		label: "26",
		file: "catalog/c26.webp",
		entry: {
			milestone: "Green Thumb|silver",
			removeMilestone: "Farming 1"
		},
		actions: [{
			label: {
				zh: "建造筒仓",
				en: "BUILD SILO"
			},
			do: { seq: [{ res: { food: 1 } }, { place: "4X" }] },
			cost: { gold: 3 }
		}, {
			label: {
				zh: "供养民众（若已建造筒仓，弃置此卡并将「绿手指」里程碑替换为「农业大师」（金））",
				en: "FEED THE PEOPLE (if you have built the Silo, discard this and cover the Green Thumb milestone with Master of Agriculture (gold))"
			},
			do: { seq: [{ removeMilestone: "Green Thumb" }, { milestone: "Master of Agriculture|gold" }] },
			cost: { food: 5 },
			discard: !0,
			if: { hasSticker: "4X" }
		}]
	},
	{
		label: "42",
		file: "catalog/c42.webp",
		entry: { none: !0 }
	},
	{
		label: "41",
		file: "catalog/c41.webp",
		entry: { place: "8H" },
		action: {
			label: {
				zh: "观星（阅读上方一个没有贴纸的故事；若此卡已有 4 张贴纸，弃置此卡）",
				en: "STARGAZING (read a story above with no sticker on it; if there are 4 stickers on this card, discard it)"
			},
			do: { story: "26.1" }
		}
	},
	{
		label: "34",
		file: "catalog/c34.webp",
		entry: { place: "7H" }
	},
	{
		label: "33",
		file: "catalog/c33.webp",
		entry: {
			place: "8K",
			cover: !0
		},
		action: {
			label: {
				zh: "买卖（最多交换 4 个资源，换取任意类型的资源；若要以这种方式获得矿石，须用 2 个资源换取 1 个矿石）",
				en: "BUY AND SELL (exchange up to 4 resources for resources of any type(s); to gain ore this way, you must exchange 2 resources for 1 ore)"
			},
			do: { exchange: {
				n: 4,
				ore: !0
			} }
		}
	},
	{
		label: "32",
		file: "catalog/c32.webp",
		entry: { place: "4K" },
		action: {
			label: {
				zh: "购买渔具（从以下二选一购买：闪亮假饵——在卡 12A 或 12B 上放置贴纸 1B；精美鱼竿——在卡 12A 或 12B 上放置贴纸 1C；两者都购买后，弃置此卡）",
				en: "BUY FISHING GEAR (buy 1 of the following: Shiny Lure—place sticker 1B on card 12A or 12B; Fancy Pole—place sticker 1C on card 12A or 12B; after buying both, discard this)"
			},
			do: { pickPlace: ["1B", "1C"] },
			cost: { gold: 1 }
		}
	},
	{
		label: "40",
		file: "catalog/c40.webp",
		entry: { place: "4R" },
		action: {
			label: {
				zh: "出售衣物（若已有 2 张放置，弃置此卡并获得卡 49）",
				en: "SELL CLOTHING (if 2 have been placed, discard this and gain card 49)"
			},
			do: { seq: [{ res: { gold: 1 } }, {
				place: "3A",
				cover: !0
			}] },
			followUp: "cat40"
		}
	},
	{
		label: "39",
		file: "catalog/c39.webp",
		name: {
			zh: "观鸟 3",
			en: "BIRDWATCHING 3"
		},
		entry: {
			milestone: "Avian Enthusiast|silver",
			removeMilestone: "Birder"
		},
		action: {
			label: {
				zh: "观鸟 3（随时：地图上出现与此卡相同的鸟时，在此卡对应鸟上放置爱心贴纸；若此卡 4 只鸟都有贴纸，弃置此卡并将「鸟类爱好者」里程碑替换为「鸟类学家」（金））",
				en: "BIRDWATCHING 3 (at any time: if you see a bird on the map matching a bird on this card, place a heart sticker on that bird on this card; if all 4 birds on this card have a sticker, discard this and cover the Avian Enthusiast milestone with Ornithologist (gold))"
			},
			do: { seq: [{ removeMilestone: "Avian Enthusiast" }, { milestone: "Ornithologist|gold" }] },
			discard: !0
		}
	},
	{
		label: "38",
		file: "catalog/c38.webp",
		entry: { milestone: "Birder|bronze" }
	},
	{
		label: "48",
		file: "catalog/c48.webp",
		entry: { place: "8D" }
	},
	{
		label: "47",
		file: "catalog/c47.webp",
		entry: { place: "4W" },
		action: {
			label: {
				zh: "递送包裹：在地图上选择一位居民和一枚礼物贴纸（12S）。两者都选定后，阅读上方该居民对应的故事条目。然后，若本卡上已有三枚贴纸，阅读故事24.3。",
				en: "Deliver Package: Choose a resident on the map and a gift sticker (12S). After choosing both, read the resident's story entry above. Then, if 3 stickers are on this card, read 24.3."
			},
			do: { place: "12S" },
			followUp: "cat47"
		}
	},
	{
		label: "46",
		file: "catalog/c46.webp",
		entry: { place: "4P" },
		action: {
			label: {
				zh: "出售古玩：获得三枚金币并放置一枚古玩贴纸（12Q）。然后，若已放置两枚，弃掉本卡。",
				en: "Sell Curios: Gain 3 gold and place 1 curio sticker (12Q). Then, if 2 have been placed, discard this."
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "12Q" }] },
			followUp: "cat46"
		}
	},
	{
		label: "37",
		file: "catalog/c37.webp",
		entry: { place: "4Q" }
	},
	{
		label: "54",
		file: "catalog/c54.webp",
		entry: { place: "8R" },
		action: {
			label: {
				zh: "建造玩具店：弃掉本卡并获得牌25。",
				en: "Build Toy Shop: Discard this and gain card 25."
			},
			do: { card: "25" },
			cost: {
				wood: 2,
				ore: 1
			},
			discard: !0
		}
	},
	{
		label: "53",
		file: "catalog/c53.webp",
		entry: { place: "8T" },
		action: {
			label: {
				zh: "建造露天舞台：弃掉本卡并放置贴纸8Q。",
				en: "Build Outdoor Stage: Discard this and place sticker 8Q."
			},
			do: { place: "8Q" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}
	},
	{
		label: "52",
		file: "catalog/c52.webp",
		entry: {
			place: "10H",
			cover: !0
		}
	},
	{
		label: "45",
		file: "catalog/c45.webp",
		action: {
			label: {
				zh: "循迹追踪：解开谜题并获得它指向的牌。如果该牌的第一个词不是“The”，则答案不正确。如果需要提示，阅读故事29.9。",
				en: "Follow the Clues: Solve the puzzle and gain the card it points to. If the first word on the card is not \"The,\" you are incorrect. If you need a hint, read 29.9."
			},
			do: { story: "29.9" }
		}
	},
	{
		label: "44",
		file: "catalog/c44.webp",
		action: {
			label: {
				zh: "研究本地传说：根据本卡上的贴纸数量阅读故事：零枚时阅读12.5，一枚时阅读32.8，两枚时阅读30.7，三枚时阅读26.7。",
				en: "Research Local Legend: Read the story based on the number of stickers on this card: 0: 12.5; 1: 32.8; 2: 30.7; 3: 26.7."
			},
			do: { story: "12.5" }
		}
	},
	{
		label: "43",
		file: "catalog/c43.webp",
		endOfYear: { discard: !0 }
	},
	{
		label: "51",
		file: "catalog/c51.webp",
		entry: { seq: [
			{ removeMilestone: "Politics" },
			{ milestone: "Tyrant|silver" },
			{ milestone: "Unrest|red" }
		] },
		action: {
			label: {
				zh: "成为君主：根据本卡上的贴纸数量阅读故事：零枚时阅读25.3，一枚时阅读25.1，两枚时阅读25.2。",
				en: "Becoming Monarch: Read the story based on the number of stickers on this card: 0: 25.3; 1: 25.1; 2: 25.2."
			},
			do: { story: "25.3" }
		}
	},
	{
		label: "50",
		file: "catalog/c50.webp",
		entry: { milestone: "Treasure Hunter|bronze" },
		action: {
			label: {
				zh: "寻找迷宫：解开谜题以阅读故事□.○。如果故事不是以“From”一词开头，则答案不正确。如果需要提示，阅读故事34.7。",
				en: "Find the Maze: Solve the puzzle to read story □.○. If the story does not start with the word \"From,\" you are incorrect. If you need a hint, read 34.7."
			},
			do: { story: "34.7" }
		}
	},
	{
		label: "49",
		file: "catalog/c49.webp",
		entry: { milestone: "Fashionable|silver" },
		action: {
			label: {
				zh: "出售帽子：获得两枚金币并放置一枚帽子贴纸（12K）。然后，若已放置三枚（来自本卡和／或其他效果），弃掉本卡并阅读故事28.9。",
				en: "Sell Hat: Gain 2 gold and place a hat sticker (12K). Then, if 3 have been placed (from this and/or other effects), discard this and read 28.9."
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "12K" }] },
			followUp: "cat49"
		}
	},
	{
		label: "57",
		file: "catalog/c57.webp",
		entry: { milestone: "Pet Lover|silver" },
		action: {
			label: {
				zh: "建造宠物收容所：弃掉本卡并放置贴纸4U。",
				en: "Build Pet Shelter: Discard this and place sticker 4U."
			},
			do: { place: "4U" },
			cost: {
				gold: 3,
				ore: 1
			},
			discard: !0
		}
	},
	{
		label: "56",
		file: "catalog/c56.webp",
		entry: { place: "8B" },
		action: {
			label: {
				zh: "出售巨型糖果：获得三枚金币并放置一枚糖果贴纸（11H，可放在地图上或另一张贴纸上）。然后，若已放置两枚，弃掉本卡并获得一点幸福。",
				en: "Sell Giant Candy: Gain 3 gold and place 1 candy sticker (11H) (on the map or on another sticker). Then, if 2 have been placed, discard this and gain 1 happiness."
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "11H" }] },
			cost: { food: 1 },
			followUp: "cat56"
		}
	},
	{
		label: "55",
		file: "catalog/c55.webp",
		name: {
			zh: "名厨雄心",
			en: "Chef Ambition"
		},
		entry: { seq: [{
			place: "9C",
			cover: !0
		}, { milestone: "Famous Chef|silver" }] },
		action: {
			label: {
				zh: "精通甜点：弃掉本卡并阅读故事25.7。此花费为四枚食物，地图上每张蛋糕贴纸（12G）使其减少一枚食物。",
				en: "Mastering Dessert: Discard this and read 25.7. This cost is 4 food; reduce it by 1 food for each cake sticker (12G) on the map."
			},
			do: { story: "25.7" },
			cost: { food: 4 },
			discard: !0,
			reducePer: {
				code: "12G",
				key: "food"
			}
		}
	},
	{
		label: "19",
		file: "catalog/c19.webp",
		entry: { place: "4A" },
		action: {
			label: {
				zh: "出售宠物：获得一枚金币并放置两枚宠物贴纸（11G）。然后，若已放置四枚，弃掉本卡并获得牌23。",
				en: "Sell Pets: Gain 1 gold and place 2 pet stickers (11G). Then, if 4 have been placed, discard this and gain card 23."
			},
			do: { seq: [{ res: { gold: 1 } }, {
				place: "11G",
				n: 2
			}] },
			followUp: "cat19"
		}
	},
	{
		label: "18",
		file: "catalog/c18.webp",
		entry: {
			place: "9C",
			cover: !0
		}
	},
	{
		label: "17",
		file: "catalog/c17.webp",
		name: {
			zh: "牧场主雄心",
			en: "Rancher Ambition"
		},
		entry: { milestone: "Rancher|bronze" },
		actions: [{
			label: {
				zh: "蔬果：如果地图上有五个或更多苹果图标，弃掉本卡并获得牌26。",
				en: "Fruits and Veggies: If 5 or more apple icons on the map, discard this and gain card 26."
			},
			do: { card: "26" },
			if: { minMapRes: { food: 5 } },
			discard: !0
		}, {
			label: {
				zh: "毛茸茸的朋友：如果地图上有七个或更多动物贴纸，弃掉本卡并获得牌27。（只计各自独立贴纸上的动物，不计其他贴纸上的动物。）",
				en: "Furry Friends: If 7 or more animal stickers on the map, discard this and gain card 27. (Only count each animal that is on its own sticker, not part of another sticker.)"
			},
			do: { card: "27" },
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 7
			} },
			discard: !0
		}]
	}
].map((e) => [e.label, e])), ce = {
	y3setup: [{
		if: { milestone: "Hunger" },
		do: { hap: -1 }
	}, { do: { res: { gold: 1 } } }],
	y4setup: [{
		if: { hasSticker: "9L" },
		do: { seq: [{
			place: "7N",
			cover: !0
		}, { res: { food: -2 } }] }
	}, { do: { res: { food: 1 } } }],
	y6setup: [{
		if: { milestone: "Lodge" },
		do: { place: "4T" }
	}, { do: { card: "22" } }],
	y7setup: [{
		if: { anyMilestone: ["Degenerate", "Upstanding"] },
		do: { res: { ore: 1 } }
	}, { do: { story: "18.3" } }],
	y9setup: [{
		if: { hasSticker: "8H" },
		do: { res: { gold: 2 } }
	}, { do: { seq: [{ place: "7E" }, { discardEvent: "y6-12" }] } }],
	"y10-07b": [{
		if: { milestone: "President" },
		do: { hap: 1 }
	}, { do: { res: { gold: 1 } } }],
	cat8a: [{
		if: { countCode: {
			code: "11B",
			min: 4
		} },
		do: { seq: [{ discardCard: "8" }, { card: "17" }] }
	}],
	cat8b: [{
		if: { allStickers: ["6N", "6P"] },
		do: { seq: [{ discardCard: "8" }, { card: "16" }] }
	}],
	cat10: [{
		if: { countCode: {
			code: "11D",
			min: 3
		} },
		do: { discardCard: "10" }
	}],
	cat19: [{
		if: { countCode: {
			code: "11G",
			min: 4
		} },
		do: { seq: [{ discardCard: "19" }, { card: "23" }] }
	}],
	cat20: [{
		if: { countCode: {
			code: "11F",
			min: 2
		} },
		do: { seq: [{ discardCard: "20" }, { card: "24" }] }
	}],
	cat23: [{
		if: { countCode: {
			code: "12F",
			min: 2
		} },
		do: { seq: [{ discardCard: "23" }, { card: "57" }] }
	}],
	cat24: [{
		if: { countCode: {
			code: "12G",
			min: 2
		} },
		do: { seq: [{ discardCard: "24" }, { card: "28" }] }
	}],
	cat25: [{
		if: { countCode: {
			code: "11Q",
			min: 2
		} },
		do: { seq: [{ discardCard: "25" }, { hap: 1 }] }
	}],
	cat40: [{
		if: { countCode: {
			code: "3A",
			min: 2
		} },
		do: { seq: [{ discardCard: "40" }, { card: "49" }] }
	}],
	cat46: [{
		if: { countCode: {
			code: "12Q",
			min: 2
		} },
		do: { discardCard: "46" }
	}],
	cat47: [{
		if: { countCode: {
			code: "12S",
			min: 3
		} },
		do: { story: "24.3" }
	}],
	cat49: [{
		if: { countCode: {
			code: "12K",
			min: 3
		} },
		do: { seq: [{ discardCard: "49" }, { story: "28.9" }] }
	}],
	cat56: [{
		if: { countCode: {
			code: "11H",
			min: 2
		} },
		do: { seq: [{ discardCard: "56" }, { hap: 1 }] }
	}],
	"story22.8": [{
		if: {
			hasCard: "13",
			countCode: {
				code: "11C",
				min: 3
			}
		},
		do: { seq: [{ discardCard: "13" }, { card: "51" }] }
	}, {
		if: {
			hasCard: "14",
			countCode: {
				code: "11C",
				min: 3
			}
		},
		do: { seq: [{ discardCard: "14" }, { card: "51" }] }
	}],
	"story35.2": [{
		if: { countCode: {
			code: "11C",
			min: 5
		} },
		do: { seq: [{ discardCard: "7" }, { card: "13" }] }
	}, { do: { story: "35.5" } }]
}, R = {
	cols: 15,
	rows: 13,
	cellW: 393.1,
	cellH: 232.6,
	folds: [6943 / 3, 13886 / 3],
	sides: {
		A: {
			type: [
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"r",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"r",
					"r",
					"r",
					"g",
					"g",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"w",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				]
			],
			region: [
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					0
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					0,
					0
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				]
			]
		},
		B: {
			type: [
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"r",
					"r",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"r",
					"w",
					"r",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"w",
					"g"
				],
				[
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"g",
					"g",
					"w"
				]
			],
			region: [
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					0
				],
				[
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					0
				]
			]
		}
	}
}, le = [
	{
		id: "02-2 Adventurer",
		name: "Adventurer",
		bg: "rock",
		file: "stickers/s011.webp"
	},
	{
		id: "02-2 Astronomer",
		name: "Astronomer",
		bg: "rock",
		file: "stickers/s012.webp"
	},
	{
		id: "02-2 Avian Enthusiast",
		name: "Avian Enthusiast",
		bg: "rock",
		file: "stickers/s013.webp"
	},
	{
		id: "02-2 Bear Tamer",
		name: "Bear Tamer",
		bg: "rock",
		file: "stickers/s014.webp"
	},
	{
		id: "02-2 Big Savings Account",
		name: "Big Savings Account",
		bg: "rock",
		file: "stickers/s015.webp"
	},
	{
		id: "02-2 Brider",
		name: "Brider",
		bg: "rock",
		file: "stickers/s016.webp"
	},
	{
		id: "02-2 Business Mogul",
		name: "Business Mogul",
		bg: "rock",
		file: "stickers/s017.webp"
	},
	{
		id: "02-2 Camp Counselor",
		name: "Camp Counselor",
		bg: "rock",
		file: "stickers/s018.webp"
	},
	{
		id: "02-2 Conservationist",
		name: "Conservationist",
		bg: "rock",
		file: "stickers/s019.webp"
	},
	{
		id: "02-2 Dating",
		name: "Dating",
		bg: "rock",
		file: "stickers/s020.webp"
	},
	{
		id: "02-2 Degenerate",
		name: "Degenerate",
		bg: "clear",
		file: "stickers/s021.webp"
	},
	{
		id: "02-2 Dictator",
		name: "Dictator",
		bg: "rock",
		file: "stickers/s022.webp"
	},
	{
		id: "02-2 Expert Baker",
		name: "Expert Baker",
		bg: "grass",
		file: "stickers/s023.webp"
	},
	{
		id: "02-2 Explorer",
		name: "Explorer",
		bg: "rock",
		file: "stickers/s024.webp"
	},
	{
		id: "02-2 Fake News",
		name: "Fake News",
		bg: "clear",
		file: "stickers/s025.webp",
		gold: 1
	},
	{
		id: "02-2 Famous Baker",
		name: "Famous Baker",
		bg: "rock",
		file: "stickers/s026.webp"
	},
	{
		id: "02-2 Famous Chef",
		name: "Famous Chef",
		bg: "rock",
		file: "stickers/s027.webp",
		gold: 1
	},
	{
		id: "02-2 Farm Hand",
		name: "Farm Hand",
		bg: "rock",
		file: "stickers/s028.webp"
	},
	{
		id: "02-2 Fasionable",
		name: "Fasionable",
		bg: "rock",
		file: "stickers/s029.webp"
	},
	{
		id: "02-2 Finder of Secrets",
		name: "Finder of Secrets",
		bg: "rock",
		file: "stickers/s030.webp",
		gold: 2
	},
	{
		id: "02-2 Fisher",
		name: "Fisher",
		bg: "rock",
		file: "stickers/s031.webp"
	},
	{
		id: "02-2 Glamorous",
		name: "Glamorous",
		bg: "rock",
		file: "stickers/s032.webp"
	},
	{
		id: "02-2 Governor",
		name: "Governor",
		bg: "rock",
		file: "stickers/s033.webp"
	},
	{
		id: "02-2 Greedy Company",
		name: "Greedy Company",
		bg: "rock",
		file: "stickers/s034.webp",
		gold: 2
	},
	{
		id: "02-2 Green Thumb",
		name: "Green Thumb",
		bg: "rock",
		file: "stickers/s035.webp"
	},
	{
		id: "02-2 Hard Winter",
		name: "Hard Winter",
		bg: "clear",
		file: "stickers/s036.webp"
	},
	{
		id: "02-2 Honest Company",
		name: "Honest Company",
		bg: "rock",
		file: "stickers/s037.webp",
		gold: 1
	},
	{
		id: "02-2 Hot Goods",
		name: "Hot Goods",
		bg: "clear",
		file: "stickers/s038.webp"
	},
	{
		id: "02-2 Hunger",
		name: "Hunger",
		bg: "clear",
		file: "stickers/s039.webp"
	},
	{
		id: "02-2 Immortalized",
		name: "Immortalized",
		bg: "rock",
		file: "stickers/s040.webp"
	},
	{
		id: "02-2 Investment",
		name: "Investment",
		bg: "rock",
		file: "stickers/s041.webp",
		gold: 1
	},
	{
		id: "02-2 Kind",
		name: "Kind",
		bg: "rock",
		file: "stickers/s042.webp"
	},
	{
		id: "02-2 Legendary Rancher",
		name: "Legendary Rancher",
		bg: "rock",
		file: "stickers/s043.webp"
	},
	{
		id: "02-2 Little Genius",
		name: "Little Genius",
		bg: "rock",
		file: "stickers/s044.webp"
	},
	{
		id: "02-2 Loan",
		name: "Loan",
		bg: "clear",
		file: "stickers/s045.webp"
	},
	{
		id: "02-2 Lodge Apprentice",
		name: "Lodge Apprentice",
		bg: "rock",
		file: "stickers/s046.webp"
	},
	{
		id: "02-2 Lodge Master",
		name: "Lodge Master",
		bg: "rock",
		file: "stickers/s047.webp",
		gold: 2
	},
	{
		id: "02-2 Lodge Member",
		name: "Lodge Member",
		bg: "rock",
		file: "stickers/s048.webp"
	},
	{
		id: "02-2 Lucky",
		name: "Lucky",
		bg: "rock",
		file: "stickers/s049.webp"
	},
	{
		id: "02-2 Married",
		name: "Married",
		bg: "rock",
		file: "stickers/s050.webp"
	},
	{
		id: "02-2 Master Chef",
		name: "Master Chef",
		bg: "grass",
		file: "stickers/s051.webp",
		gold: 1
	},
	{
		id: "02-2 Master of Agriculture",
		name: "Master of Agriculture",
		bg: "rock",
		file: "stickers/s052.webp"
	},
	{
		id: "02-2 Matchmaker",
		name: "Matchmaker",
		bg: "rock",
		file: "stickers/s053.webp"
	},
	{
		id: "02-2 Mayor",
		name: "Mayor",
		bg: "rock",
		file: "stickers/s054.webp"
	},
	{
		id: "02-2 Miracle Medicine",
		name: "Miracle Medicine",
		bg: "rock",
		file: "stickers/s055.webp",
		gold: 1
	},
	{
		id: "02-2 Monarch",
		name: "Monarch",
		bg: "rock",
		file: "stickers/s056.webp"
	},
	{
		id: "02-2 New Family",
		name: "New Family",
		bg: "rock",
		file: "stickers/s057.webp"
	},
	{
		id: "02-2 Noble",
		name: "Noble",
		bg: "rock",
		file: "stickers/s058.webp"
	},
	{
		id: "02-2 Ore Tycoon",
		name: "Ore Tycoon",
		bg: "rock",
		file: "stickers/s059.webp",
		gold: 1
	},
	{
		id: "02-2 Ornithologist",
		name: "Ornithologist",
		bg: "rock",
		file: "stickers/s060.webp"
	},
	{
		id: "02-2 Paleontologist",
		name: "Paleontologist",
		bg: "rock",
		file: "stickers/s061.webp"
	},
	{
		id: "02-2 Patron of the Arts",
		name: "Patron of the Arts",
		bg: "rock",
		file: "stickers/s062.webp"
	},
	{
		id: "02-2 Perfect Village",
		name: "Perfect Village",
		bg: "rock",
		file: "stickers/s063.webp"
	},
	{
		id: "02-2 Pet Lover",
		name: "Pet Lover",
		bg: "rock",
		file: "stickers/s064.webp"
	},
	{
		id: "02-2 Pet Rescuer",
		name: "Pet Rescuer",
		bg: "grass",
		file: "stickers/s065.webp"
	},
	{
		id: "02-2 Poisoned",
		name: "Poisoned",
		bg: "clear",
		file: "stickers/s066.webp"
	},
	{
		id: "02-2 President",
		name: "President",
		bg: "rock",
		file: "stickers/s067.webp"
	},
	{
		id: "02-2 Pro Angler",
		name: "Pro Angler",
		bg: "rock",
		file: "stickers/s068.webp"
	},
	{
		id: "02-2 Rancher",
		name: "Rancher",
		bg: "rock",
		file: "stickers/s069.webp"
	},
	{
		id: "02-2 Runner Up",
		name: "Runner Up",
		bg: "rock",
		file: "stickers/s070.webp"
	},
	{
		id: "02-2 Savings Account",
		name: "Savings Account",
		bg: "rock",
		file: "stickers/s071.webp"
	},
	{
		id: "02-2 Secret Spy",
		name: "Secret Spy",
		bg: "rock",
		file: "stickers/s072.webp"
	},
	{
		id: "02-2 Sleuth",
		name: "Sleuth",
		bg: "rock",
		file: "stickers/s073.webp"
	},
	{
		id: "02-2 Termites",
		name: "Termites",
		bg: "clear",
		file: "stickers/s074.webp"
	},
	{
		id: "02-2 Test Subject",
		name: "Test Subject",
		bg: "clear",
		file: "stickers/s075.webp"
	},
	{
		id: "02-2 Thriving Community",
		name: "Thriving Community",
		bg: "rock",
		file: "stickers/s076.webp"
	},
	{
		id: "02-2 Treasure Hunter",
		name: "Treasure Hunter",
		bg: "rock",
		file: "stickers/s077.webp"
	},
	{
		id: "02-2 Trustworthy News",
		name: "Trustworthy News",
		bg: "rock",
		file: "stickers/s078.webp"
	},
	{
		id: "02-2 Tyrant",
		name: "Tyrant",
		bg: "rock",
		file: "stickers/s079.webp"
	},
	{
		id: "02-2 Unrest",
		name: "Unrest",
		bg: "clear",
		file: "stickers/s080.webp"
	},
	{
		id: "02-2 Upstanding",
		name: "Upstanding",
		bg: "rock",
		file: "stickers/s081.webp"
	},
	{
		id: "02-2 Veteran Rancher",
		name: "Veteran Rancher",
		bg: "rock",
		file: "stickers/s082.webp"
	},
	{
		id: "02-Veteran Fisher",
		name: "Veteran Fisher",
		bg: "rock",
		file: "stickers/s083.webp"
	}
], ue = [
	{
		page: 1,
		file: "story/p01.webp"
	},
	{
		page: 2,
		file: "story/p02.webp"
	},
	{
		page: 3,
		file: "story/p03.webp"
	},
	{
		page: 4,
		file: "story/p04.webp"
	},
	{
		page: 5,
		file: "story/p05.webp"
	},
	{
		page: 6,
		file: "story/p06.webp"
	},
	{
		page: 7,
		file: "story/p07.webp"
	},
	{
		page: 8,
		file: "story/p08.webp"
	},
	{
		page: 9,
		file: "story/p09.webp"
	},
	{
		page: 10,
		file: "story/p10.webp"
	},
	{
		page: 11,
		file: "story/p11.webp"
	},
	{
		page: 12,
		file: "story/p12.webp"
	},
	{
		page: 13,
		file: "story/p13.webp"
	},
	{
		page: 14,
		file: "story/p14.webp"
	},
	{
		page: 15,
		file: "story/p15.webp"
	},
	{
		page: 16,
		file: "story/p16.webp"
	},
	{
		page: 17,
		file: "story/p17.webp"
	},
	{
		page: 18,
		file: "story/p18.webp"
	},
	{
		page: 19,
		file: "story/p19.webp"
	},
	{
		page: 20,
		file: "story/p20.webp"
	},
	{
		page: 21,
		file: "story/p21.webp"
	},
	{
		page: 22,
		file: "story/p22.webp"
	},
	{
		page: 23,
		file: "story/p23.webp"
	},
	{
		page: 24,
		file: "story/p24.webp"
	},
	{
		page: 25,
		file: "story/p25.webp"
	},
	{
		page: 26,
		file: "story/p26.webp"
	},
	{
		page: 27,
		file: "story/p27.webp"
	},
	{
		page: 28,
		file: "story/p28.webp"
	},
	{
		page: 29,
		file: "story/p29.webp"
	},
	{
		page: 30,
		file: "story/p30.webp"
	},
	{
		page: 31,
		file: "story/p31.webp"
	},
	{
		page: 32,
		file: "story/p32.webp"
	},
	{
		page: 33,
		file: "story/p33.webp"
	},
	{
		page: 34,
		file: "story/p34.webp"
	},
	{
		page: 35,
		file: "story/p35.webp"
	},
	{
		page: 36,
		file: "story/p36.webp"
	}
], z = {
	"6.2": { choice: [{
		label: {
			zh: "收集树枝：获得 1 木材，然后额外行动一次",
			en: "Gather branches: +1 wood, then another action"
		},
		do: { seq: [{ res: { wood: 1 } }, { extraAction: 1 }] }
	}, {
		label: {
			zh: "砍倒大树：获得 3 木材并记录进度",
			en: "Chop a tree: +3 wood and mark progress"
		},
		do: { seq: [{ res: { wood: 3 } }, { progress: 1 }] }
	}] },
	"8.8": { choice: [{
		label: {
			zh: "让居民免费使用：获得 1 幸福",
			en: "Free for everyone: +1 happiness"
		},
		do: { seq: [{
			place: "9E",
			cover: !0
		}, { hap: 1 }] }
	}, {
		label: {
			zh: "收取合理费用：获得 2 金币",
			en: "Charge a fair fee: +2 gold"
		},
		do: { seq: [{
			place: "9E",
			cover: !0
		}, { res: { gold: 2 } }] }
	}] },
	"9.3": { choice: [{
		label: {
			zh: "暂缓竞选：额外行动一次",
			en: "Hold off: another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "投入 3 金币并掷骰（4-6 成功）",
			en: "Spend 3 gold and roll (4-6 succeeds)"
		},
		cost: { gold: 3 },
		do: { dice: [{
			on: [
				1,
				2,
				3
			],
			do: { none: !0 }
		}, {
			on: [
				4,
				5,
				6
			],
			do: { seq: [
				{ discardCard: "13" },
				{ discardCard: "14" },
				{ card: "5" }
			] }
		}] }
	}] },
	"10.1": { choice: [
		{
			label: {
				zh: "介绍自己的表亲：获得图鉴牌 30",
				en: "Introduce your cousin: gain card 30"
			},
			do: { card: "30" }
		},
		{
			label: {
				zh: "主动应征：放置 9G 并获图鉴牌 29",
				en: "Say you're available: place 9G and gain card 29"
			},
			do: { seq: [{
				place: "9G",
				cover: !0
			}, { card: "29" }] }
		},
		{
			label: {
				zh: "帮不上忙：增加 1 不满",
				en: "You can't help: +1 upset"
			},
			do: { upset: 1 }
		}
	] },
	"10.2": { choice: [{
		label: {
			zh: "做体力活：获得 2 金币",
			en: "Manual labor: +2 gold"
		},
		do: { res: { gold: 2 } }
	}, {
		label: {
			zh: "在集市帮忙：获得 1 金币和 2 食物",
			en: "Help at the market: +1 gold and +2 food"
		},
		do: { res: {
			gold: 1,
			food: 2
		} }
	}] },
	"10.4": { auto: { hap: 1 } },
	"10.7": { choice: [{
		label: {
			zh: "一起去远足：记录进度",
			en: "Go hiking: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 食物做晚餐：记录 2 点进度",
			en: "Spend 1 food for dinner: mark 2 progress"
		},
		cost: { food: 1 },
		do: { progress: 2 }
	}] },
	"11.6": { choice: [{
		label: {
			zh: "劝她慢慢来：记录进度",
			en: "Tell them to take it slow: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币买订婚戒指：记录 2 点进度",
			en: "Spend 1 gold on a ring: mark 2 progress"
		},
		cost: { gold: 1 },
		do: { progress: 2 }
	}] },
	"11.7": { auto: { none: !0 } },
	"12.5": { auto: { progress: 1 } },
	"12.8": { choice: [{
		label: {
			zh: "签订贸易协定：获得 1 木材、1 金币、1 矿石",
			en: "Trade agreement: +1 wood, +1 gold, +1 ore"
		},
		do: { seq: [{
			place: "7Q",
			cover: !0
		}, { res: {
			wood: 1,
			gold: 1,
			ore: 1
		} }] }
	}, {
		label: {
			zh: "花 1 金币去度假：获得 1 幸福",
			en: "Spend 1 gold on a vacation: +1 happiness"
		},
		cost: { gold: 1 },
		do: { seq: [{
			place: "7Q",
			cover: !0
		}, { hap: 1 }] }
	}] },
	"14.1": { choice: [{
		label: {
			zh: "静静聆听：记录进度",
			en: "Listen quietly: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币资助研究：记录 2 点进度",
			en: "Spend 1 gold on research: mark 2 progress"
		},
		cost: { gold: 1 },
		do: { progress: 2 }
	}] },
	"15.1": { auto: { res: { gold: 1 } } },
	"15.8": { choice: [{
		label: {
			zh: "花 2 食物喂熊并掷骰（2-6 成功）",
			en: "Spend 2 food to feed the bear and roll (2-6 succeeds)"
		},
		cost: { food: 2 },
		do: { dice: [{
			on: [1],
			do: { none: !0 }
		}, {
			on: [
				2,
				3,
				4,
				5,
				6
			],
			do: { seq: [{ place: "9E" }, { milestone: "Bear Tamer|silver" }] }
		}] }
	}, {
		label: {
			zh: "保持距离：无效果",
			en: "Keep your distance: no effect"
		},
		do: { none: !0 }
	}] },
	"15.9": { choice: [{
		label: {
			zh: "花 2 食物参加厨艺赛并掷骰",
			en: "Spend 2 food and enter the cooking contest"
		},
		cost: { food: 2 },
		do: { dice: [
			{
				on: [1, 2],
				do: { none: !0 }
			},
			{
				on: [
					3,
					4,
					5
				],
				do: { res: { gold: 2 } }
			},
			{
				on: [6],
				do: { seq: [{ res: { gold: 2 } }, { card: "55" }] }
			}
		] }
	}, {
		label: {
			zh: "不参加：无效果",
			en: "Skip the contest: no effect"
		},
		do: { none: !0 }
	}] },
	"16.1": { choice: [{
		label: {
			zh: "给他私人空间：记录进度",
			en: "Give him privacy: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "闯进他的家：记录 2 点进度",
			en: "Break into his house: mark 2 progress"
		},
		do: { progress: 2 }
	}] },
	"16.9": { auto: { res: { gold: 3 } } },
	"18.2": { choice: [{
		if: { milestone: "Poisoned" },
		label: {
			zh: "中毒未愈：弃掉矿洞牌，获得 1 矿石、1 金币与“探险家”（银）",
			en: "Still poisoned: discard the mine cards, gain 1 ore, 1 gold and Explorer (silver)"
		},
		do: { seq: [
			{ discardCard: "35a" },
			{ discardCard: "35b" },
			{ res: {
				ore: 1,
				gold: 1
			} },
			{ milestone: "Explorer|silver" }
		] }
	}, {
		label: {
			zh: "引开蜘蛛：弃掉矿洞牌，获得 1 矿石、3 金币与“冒险家”（金）",
			en: "Distract the spiders: discard the mine cards, gain 1 ore, 3 gold and Adventurer (gold)"
		},
		do: { seq: [
			{ discardCard: "35a" },
			{ discardCard: "35b" },
			{ res: {
				ore: 1,
				gold: 3
			} },
			{ milestone: "Adventurer|gold" }
		] }
	}] },
	"18.3": { choice: [{
		label: {
			zh: "“我还有活要干”：记录进度并额外行动一次",
			en: "\"I have work to do\": mark progress and take another action"
		},
		do: { seq: [{ progress: 1 }, { extraAction: 1 }] }
	}, {
		label: {
			zh: "花 1 食物一起吃大餐：记录 2 点进度",
			en: "Spend 1 food to feast: mark 2 progress"
		},
		cost: { food: 1 },
		do: { progress: 2 }
	}] },
	"18.7": { choice: [{
		if: { milestone: "Pet Lover" },
		label: {
			zh: "把“爱宠人士”换成“宠物救星”（金）",
			en: "Replace Pet Lover with Pet Rescuer (gold)"
		},
		do: { seq: [{ removeMilestone: "Pet Lover" }, { milestone: "Pet Rescuer|gold" }] }
	}, {
		if: { notMilestone: "Pet Lover" },
		label: {
			zh: "放置 9E 和 1 枚宠物贴纸 11G",
			en: "Place 9E and 1 pet sticker 11G"
		},
		do: { seq: [{
			place: "9E",
			cover: !0
		}, { place: "11G" }] }
	}] },
	"19.1": { choice: [{
		label: {
			zh: "追问那次事故：记录进度",
			en: "Ask about the incident: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "参观采石场：放置 7G",
			en: "See the quarry: place 7G"
		},
		do: { place: "7G" }
	}] },
	"20.1": { choice: [{
		label: {
			zh: "婉拒：记录进度",
			en: "Decline politely: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币买画：放置 12M",
			en: "Spend 1 gold on a painting: place 12M"
		},
		cost: { gold: 1 },
		do: { place: "12M" }
	}] },
	"21.1": { choice: [{
		label: {
			zh: "重视考试：记录 2 点进度",
			en: "Focus on tests: mark 2 progress"
		},
		do: { progress: 2 }
	}, {
		label: {
			zh: "寓教于乐：记录进度",
			en: "Make learning fun: mark progress"
		},
		do: { progress: 1 }
	}] },
	"22.8": { auto: { seq: [{ res: { gold: 1 } }, { progress: 1 }] } },
	"24.3": { auto: { seq: [{ hap: 1 }, { discardCard: "47" }] } },
	"24.4": { auto: { place: "1H" } },
	"24.6": { auto: { hap: -1 } },
	"24.7": { choice: [
		{
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 9
			} },
			label: {
				zh: "获得“传奇牧场主”（金）并放置 9E",
				en: "Gain Legendary Rancher (gold) and place 9E"
			},
			do: { seq: [
				{
					place: "9E",
					cover: !0
				},
				{ removeMilestone: "Veteran Rancher" },
				{ milestone: "Legendary Rancher|gold" }
			] }
		},
		{
			label: {
				zh: "花 1 金币放置农场动物贴纸 11B",
				en: "Spend 1 gold to place farm animal 11B"
			},
			cost: { gold: 1 },
			do: { place: "11B" }
		},
		{
			label: {
				zh: "再行动一次",
				en: "Take another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"24.8": { auto: { place: "10K" } },
	"24.10": { auto: { res: { food: 2 } } },
	"25.3": { choice: [{
		label: {
			zh: "花 2 金币买民心：记录进度",
			en: "Spend 2 gold for support: mark progress"
		},
		cost: { gold: 2 },
		do: { progress: 1 }
	}, {
		label: {
			zh: "强迫宣誓：记录进度并增加 1 不满",
			en: "Force an oath: mark progress and +1 upset"
		},
		do: { seq: [{ progress: 1 }, { upset: 1 }] }
	}] },
	"25.4": { choice: [
		{
			if: { minCalmResidents: 9 },
			label: {
				zh: "赢得支持：记录进度",
				en: "Win the people over: mark progress"
			},
			do: { progress: 1 }
		},
		{
			if: { maxCalmResidents: 8 },
			label: {
				zh: "花 2 金币移除 1 不满",
				en: "Spend 2 gold to remove 1 upset"
			},
			cost: { gold: 2 },
			do: { removeUpset: 1 }
		},
		{
			if: { maxCalmResidents: 8 },
			label: {
				zh: "再行动一次",
				en: "Take another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"25.7": { auto: { seq: [
		{ res: { gold: 1 } },
		{ removeMilestone: "Famous Chef" },
		{ milestone: "Master Chef|gold" }
	] } },
	"26.1": { choice: [{
		label: {
			zh: "邀请居民观星：获得 1 幸福",
			en: "Invite the residents: +1 happiness"
		},
		do: { hap: 1 }
	}, {
		label: {
			zh: "出售门票：获得 2 金币",
			en: "Sell tickets: +2 gold"
		},
		do: { res: { gold: 2 } }
	}] },
	"26.5": { auto: { card: "47" } },
	"26.6": { choice: [
		{
			cost: { food: 0 },
			label: {
				zh: "投入 0 食物并掷骰",
				en: "Spend 0 food and roll"
			},
			do: { dice: [{
				on: [
					1,
					2,
					3
				],
				do: { extraAction: 1 }
			}, {
				on: [
					4,
					5,
					6
				],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}] }
		},
		{
			cost: { food: 1 },
			label: {
				zh: "投入 1 食物并掷骰（结果加 1）",
				en: "Spend 1 food and roll (add 1)"
			},
			do: { dice: [
				{
					on: [1, 2],
					do: { extraAction: 1 }
				},
				{
					on: [
						3,
						4,
						5
					],
					do: { res: {
						food: 1,
						gold: 1
					} }
				},
				{
					on: [6],
					do: { seq: [
						{ res: { gold: 2 } },
						{ discardCard: "28" },
						{ removeMilestone: "Famous Baker" },
						{ milestone: "Expert Baker|gold" }
					] }
				}
			] }
		},
		{
			cost: { food: 2 },
			label: {
				zh: "投入 2 食物并掷骰（结果加 2）",
				en: "Spend 2 food and roll (add 2)"
			},
			do: { dice: [
				{
					on: [1],
					do: { extraAction: 1 }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: {
						food: 1,
						gold: 1
					} }
				},
				{
					on: [5, 6],
					do: { seq: [
						{ res: { gold: 2 } },
						{ discardCard: "28" },
						{ removeMilestone: "Famous Baker" },
						{ milestone: "Expert Baker|gold" }
					] }
				}
			] }
		},
		{
			cost: { food: 3 },
			label: {
				zh: "投入 3 食物并掷骰（结果加 3）",
				en: "Spend 3 food and roll (add 3)"
			},
			do: { dice: [{
				on: [
					1,
					2,
					3
				],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		},
		{
			cost: { food: 4 },
			label: {
				zh: "投入 4 食物并掷骰（结果加 4）",
				en: "Spend 4 food and roll (add 4)"
			},
			do: { dice: [{
				on: [1, 2],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					3,
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		},
		{
			cost: { food: 5 },
			label: {
				zh: "投入 5 食物并掷骰（结果加 5）",
				en: "Spend 5 food and roll (add 5)"
			},
			do: { dice: [{
				on: [1],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		}
	] },
	"26.9": { auto: { seq: [{ place: "11M" }, { hap: 1 }] } },
	"27.1": { choice: [{
		label: {
			zh: "再行动一次",
			en: "Take another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 3 金币并掷骰（4-6 成功）",
			en: "Spend 3 gold and roll (4-6 succeeds)"
		},
		cost: { gold: 3 },
		do: { dice: [{
			on: [
				1,
				2,
				3
			],
			do: { none: !0 }
		}, {
			on: [
				4,
				5,
				6
			],
			do: { seq: [{ discardCard: "15" }, { card: "5" }] }
		}] }
	}] },
	"27.2": { choice: [{
		label: {
			zh: "再行动一次",
			en: "Take another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 2 金币开户：获得“储蓄账户”（铜）并记录进度",
			en: "Spend 2 gold to open an account: Savings Account (bronze) and mark progress"
		},
		cost: { gold: 2 },
		do: { seq: [{ milestone: "Savings Account|bronze" }, { progress: 1 }] }
	}] },
	"27.7": { auto: { seq: [
		{ discardCard: "15" },
		{ hap: -1 },
		{ card: "51" }
	] } },
	"28.2": { auto: { seq: [{ milestone: "Secret Spy|silver" }, { progress: 1 }] } },
	"28.9": { auto: { seq: [{ removeMilestone: "Fashionable" }, { milestone: "Glamorous|gold" }] } },
	"29.2": { choice: [{
		label: {
			zh: "刊登暖心故事：记录进度",
			en: "Print a heartwarming story: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "刊登质疑报道：获得 1 金币并记录进度",
			en: "Print a provocative story: +1 gold and mark progress"
		},
		do: { seq: [{ res: { gold: 1 } }, { progress: 1 }] }
	}] },
	"29.9": { auto: { none: !0 } },
	"30.2": { auto: { seq: [{ res: { gold: 1 } }, { progress: 1 }] } },
	"31.1": { auto: { none: !0 } },
	"32.7": { auto: { removeSticker: "5A" } },
	"33.9": { auto: { none: !0 } },
	"34.7": { auto: { none: !0 } },
	"35.1": { auto: { seq: [{ res: { food: 1 } }, { milestone: "Fisher|bronze" }] } },
	"35.2": { auto: { branch: "story35.2" } },
	"35.5": { choice: [{
		label: {
			zh: "坦然接受落败：获得图鉴牌 15",
			en: "Accept defeat gracefully: gain card 15"
		},
		do: { card: "15" }
	}, {
		label: {
			zh: "宣布投票无效：获得图鉴牌 14",
			en: "Declare the vote invalid: gain card 14"
		},
		do: { card: "14" }
	}] },
	"35.6": { choice: [{
		label: {
			zh: "花 1 木材再行动一次",
			en: "Spend 1 wood for another action"
		},
		cost: { wood: 1 },
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "结束探索",
			en: "End the exploration"
		},
		do: { none: !0 }
	}] },
	"36.1": { auto: { seq: [{ res: { food: 1 } }, { milestone: "Fisher|bronze" }] } }
}, B = [
	{
		key: "outpost",
		minHearts: 0,
		title: {
			zh: "寂静前哨",
			en: "A Quiet Outpost"
		},
		text: {
			zh: "十年过去，村庄仍然只是河畔一处安静的小聚落。居民们过着平淡的日子，但每当夜风吹过空荡的街道，你总会想起那些没能实现的心愿。",
			en: "Ten years on, the village is still little more than a quiet cluster by the river. Life is peaceful, yet on windy nights you cannot help but remember the dreams that never took root."
		}
	},
	{
		key: "settlement",
		minHearts: 6,
		title: {
			zh: "温暖的聚落",
			en: "A Warm Settlement"
		},
		text: {
			zh: "村庄渐渐有了烟火气。邻里间彼此照应，孩子们在巷口嬉闹。它算不上繁华，却是一个让人愿意留下来的地方。",
			en: "The village has grown lively. Neighbours look out for one another and children play in the lanes. It is not grand, but it is a place where people want to stay."
		}
	},
	{
		key: "cozy",
		minHearts: 12,
		title: {
			zh: "温馨小镇",
			en: "A Cozy Town"
		},
		text: {
			zh: "曾经荒芜的土地如今变成了温馨的小镇。每逢节日，广场上灯笼高挂，居民们的笑脸映在河面上，你知道这些年的辛劳都值得。",
			en: "The barren land has become a cozy town. On festival days lanterns hang over the square and smiling faces reflect in the river — all those years of work were worth it."
		}
	},
	{
		key: "thriving",
		minHearts: 18,
		title: {
			zh: "繁荣之心",
			en: "The Thriving Heart"
		},
		text: {
			zh: "你的村庄声名远扬，商队与旅人络绎不绝。整洁的街道、兴旺的集市与和睦的居民，让它成了整片山谷最向往的地方。",
			en: "Your village is famous across the valley. Caravans and travellers arrive in a steady stream, drawn by tidy streets, a bustling market and contented residents."
		}
	},
	{
		key: "legendary",
		minHearts: 24,
		title: {
			zh: "传奇村庄",
			en: "A Legendary Village"
		},
		text: {
			zh: "诗人传唱着你的村庄，远方的国王也派人前来拜访。这座由你亲手打造的传奇村庄，将被一代又一代人铭记。",
			en: "Poets sing of your village and kings send envoys to visit. The legendary village you built with your own hands will be remembered for generations."
		}
	}
];
//#endregion
//#region src/game/state.ts
function de() {
	return {
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	};
}
function fe(e, t, n) {
	let r = (Math.floor(e) ^ t * 2654435761 ^ n * 2246822507) >>> 0;
	return () => {
		r = r + 1831565813 >>> 0;
		let e = r;
		return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
function pe(e, t, n, r = 0) {
	let i = e.slice(), a = fe(t, n, r);
	for (let e = i.length - 1; e > 0; e--) {
		let t = Math.floor(a() * (e + 1));
		[i[e], i[t]] = [i[t], i[e]];
	}
	return i;
}
function me(e, t) {
	return pe(v.filter((t) => t.year === e).map((e) => e.id), t, e);
}
function V(e) {
	return w[e] ?? T[e]?.[0];
}
function he(e, t) {
	return e.col < t.col + t.cols && t.col < e.col + e.cols && e.row < t.row + t.rows && t.row < e.row + e.rows;
}
function ge(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n = 0; n < e.length; n++) {
		let r = w[e[n].id];
		if (!r) continue;
		let i = {
			col: e[n].col,
			row: e[n].row,
			cols: r.cols,
			rows: r.rows
		};
		for (let r = n + 1; r < e.length; r++) {
			let a = e[r];
			if (!a.cover) continue;
			let o = w[a.id];
			if (o && o.bg !== "clear" && he(i, {
				col: a.col,
				row: a.row,
				cols: o.cols,
				rows: o.rows
			})) {
				t.add(n);
				break;
			}
		}
	}
	return t;
}
function _e(e) {
	let t = ge(e), n = de();
	return e.forEach((e, r) => {
		if (t.has(r)) return;
		let i = w[e.id];
		i && (n.wood += i.wood, n.food += i.food, n.gold += i.gold, n.ore += i.ore);
	}), n;
}
var ve = {
	grass: "g",
	water: "w",
	rock: "r"
};
function ye(e, t, n, r) {
	let i = [];
	for (let a = t; a < t + r; a++) for (let t = e; t < e + n; t++) i.push({
		col: t,
		row: a
	});
	return i;
}
var be = [5, 10];
function xe(e, t) {
	let n = e + t - 1;
	return be.some((t) => e < t && n >= t);
}
function Se(e, t, n, r, i = !1) {
	let a = t.cols, o = t.rows;
	if (n < 0 || r < 0 || n + a > R.cols || r + o > R.rows) return {
		ok: !1,
		reason: "oob"
	};
	let s = R.sides[e.side], c = ye(n, r, a, o);
	if (t.bg !== "clear" && xe(n, a)) return {
		ok: !1,
		reason: "fold"
	};
	if (t.bg !== "clear") {
		let e = ve[t.bg];
		if (e) for (let t of c) {
			let n = s.type[t.row]?.[t.col];
			if (n && n !== e) return {
				ok: !1,
				reason: "bg"
			};
		}
	}
	if (t.bg !== "clear" && !i) for (let t of e.placed) {
		let e = w[t.id];
		if (e && ye(t.col, t.row, e.cols, e.rows).some((e) => c.some((t) => e.col === t.col && e.row === t.row))) return {
			ok: !1,
			reason: "overlap"
		};
	}
	if (t.bg === "grass") {
		let e = /* @__PURE__ */ new Set();
		for (let t of c) {
			let n = s.region[t.row]?.[t.col];
			n && n > 0 && e.add(n);
		}
		if (e.size > 1) return {
			ok: !1,
			reason: "river"
		};
	}
	return { ok: !0 };
}
function Ce(e, t) {
	let n = V(t);
	if (!n) return !1;
	for (let t = 0; t <= R.rows - n.rows; t++) for (let r = 0; r <= R.cols - n.cols; r++) if (Se(e, n, r, t).ok) return !0;
	return !1;
}
function H(e, t) {
	if (!t) return [];
	if (t.none) return [{ op: "none" }];
	let n = [];
	if (t.dice) {
		let r = 1 + Math.floor(fe(e.seed, e.year, 9e3 + e.cursor++)() * 6), i = t.dice.find((e) => e.on.includes(r));
		n.push({ op: "none" }), i && n.push(...H(e, i.do));
	}
	if (t.res && n.push({
		op: "res",
		res: t.res
	}), t.hap && n.push({
		op: "hap",
		n: t.hap
	}), t.place && n.push({
		op: "place",
		code: t.place,
		n: t.n ?? 1,
		allow: t.cover
	}), t.pickPlace && n.push({
		op: "pickPlace",
		pick: t.pickPlace
	}), t.card && n.push({
		op: "card",
		key: t.card
	}), t.pickCard && n.push({
		op: "pickCard",
		pick: t.pickCard
	}), t.story && n.push({
		op: "story",
		key: t.story
	}), t.milestone && n.push({
		op: "milestone",
		key: t.milestone
	}), t.removeMilestone && n.push({
		op: "removeMilestone",
		key: t.removeMilestone
	}), t.removeSticker && n.push({
		op: "removeSticker",
		key: t.removeSticker
	}), t.upset && n.push({
		op: "upset",
		n: t.upset
	}), t.removeUpset && n.push({
		op: "removeUpset",
		n: t.removeUpset
	}), t.extraAction && n.push({
		op: "extraAction",
		n: t.extraAction
	}), t.skipAction && n.push({ op: "skipAction" }), t.progress && n.push({
		op: "progress",
		n: t.progress
	}), t.pickRes && n.push({
		op: "pickRes",
		pick: t.pickRes,
		n: t.n ?? 1
	}), t.exchange && n.push({
		op: "exchange",
		n: t.exchange.n,
		allow: !!t.exchange.ore
	}), t.branch && n.push({
		op: "branch",
		key: t.branch
	}), t.discardCard && n.push({
		op: "discardCard",
		key: t.discardCard
	}), t.discardEvent && n.push({
		op: "discardEvent",
		key: t.discardEvent
	}), t.ask && n.push({
		op: "ask",
		key: t.ask
	}), t.seq) for (let r of t.seq) n.push(...H(e, r));
	return n;
}
function we(e, t) {
	e.resources[t] = Math.max(0, Math.min(b[t], e.resources[t]));
}
function Te(e) {
	return e.split("|")[0].trim().toLowerCase();
}
function Ee(e) {
	for (; !e.prompt && e.queue.length;) {
		let t = e.queue[0];
		if (t.op === "place") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "place",
				code: t.code,
				n: t.n ?? 1,
				cover: t.allow
			};
			return;
		}
		if (t.op === "pickPlace") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickPlace",
				pick: t.pick
			};
			return;
		}
		if (t.op === "pickCard") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickCard",
				pick: t.pick
			};
			return;
		}
		if (t.op === "pickRes") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickRes",
				pick: t.pick,
				n: t.n ?? 1
			};
			return;
		}
		if (t.op === "exchange") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "exchange",
				n: t.n ?? 1,
				allow: t.allow
			};
			return;
		}
		if (t.op === "ask") {
			e.prompt = {
				kind: "pickOpt",
				code: `ask:${t.key}`
			};
			return;
		}
		if (e.queue.shift(), t.op === "res" && t.res) for (let n of Object.keys(t.res)) e.resources[n] += t.res[n] ?? 0, we(e, n);
		else if (t.op === "hap") e.happiness = Math.max(0, Math.min(30, e.happiness + (t.n ?? 0)));
		else if (t.op === "card" && t.key) {
			if (!e.catalog.includes(t.key)) {
				e.catalog.push(t.key);
				let n = L[t.key]?.entry;
				n && e.queue.unshift(...H(e, n));
			}
		} else if (t.op === "story" && t.key) {
			e.story.includes(t.key) || e.story.push(t.key);
			let n = z[t.key];
			if (n?.choice?.length) {
				e.yearEnding || (e.phase = "placing"), e.prompt = {
					kind: "pickOpt",
					code: `st:${t.key}`,
					pick: n.choice.map((e, t) => String(t))
				};
				return;
			}
			n?.auto && e.queue.unshift(...H(e, n.auto));
		} else if (t.op === "branch" && t.key) {
			let n = ce[t.key]?.find((t) => q(e, t.if));
			n && e.queue.unshift(...H(e, n.do));
		} else if (t.op === "discardCard" && t.key) e.catalog = e.catalog.filter((e) => e !== t.key);
		else if (t.op === "discardEvent" && t.key) e.inPlay = e.inPlay.filter((e) => e !== t.key), e.deck = e.deck.filter((e) => e !== t.key);
		else if (t.op === "milestone" && t.key) e.milestones.includes(t.key) || e.milestones.push(t.key);
		else if (t.op === "removeMilestone" && t.key) {
			let n = t.key.toLowerCase();
			e.milestones = e.milestones.filter((e) => !Te(e).includes(n));
		} else if (t.op === "removeSticker" && t.key) {
			let n = V(t.key);
			n && (e.placed = e.placed.filter((e) => e.id !== n.id));
		} else t.op === "upset" ? e.upset = Math.max(0, Math.min(99, e.upset + (t.n ?? 0))) : t.op === "removeUpset" ? e.upset = Math.max(0, e.upset - (t.n ?? 0)) : t.op === "progress" ? e.progress = Math.max(0, Math.min(99, e.progress + (t.n ?? 0))) : t.op === "extraAction" ? e.action += t.n ?? 1 : t.op === "skipAction" && (e.action = 0);
	}
}
function De(e) {
	if (e.startsWith("e:")) return y[e.slice(2)]?.endOfYear ?? void 0;
	if (e.startsWith("c:")) return L[e.slice(2)]?.endOfYear;
}
function Oe(e, t) {
	t.startsWith("e:") ? e.inPlay = e.inPlay.filter((e) => e !== t.slice(2)) : t.startsWith("c:") && (e.catalog = e.catalog.filter((e) => e !== t.slice(2)));
}
function ke(e) {
	e.yearEnding = !1, e.yearEndQueue = [], e.year >= 10 ? (e.phase = "done", W(e, "十年结束，村庄故事落幕。", "Ten years passed. The village story concludes.")) : (We(e, e.year + 1), W(e, `第 ${e.year} 年开始。`, `Year ${e.year} begins.`));
}
function Ae(e) {
	for (;;) {
		if (e.prompt || e.queue.length) return;
		if (!e.yearEndQueue.length) {
			ke(e);
			return;
		}
		let t = e.yearEndQueue.shift(), n = De(t);
		if (n) {
			if (n.discard && Oe(e, t), n.auto) {
				e.queue.push(...H(e, n.auto)), Ee(e);
				continue;
			}
			if (n.choice?.length) {
				e.phase = "yearEnd", e.prompt = {
					kind: "pickOpt",
					code: t,
					pick: n.choice.map((e, t) => String(t))
				};
				return;
			}
			if (n.optional) {
				e.phase = "yearEnd", e.prompt = {
					kind: "pickOpt",
					code: t,
					pick: ["opt", "skip"]
				};
				return;
			}
		}
	}
}
function je(e, t, n) {
	let r = Qe(e, n), i = Ze(t, n);
	return r ? `${r} · ${i}` : i;
}
function Me(e) {
	if (e.prompt?.kind !== "pickOpt") return null;
	let t = De(e.prompt.code ?? "");
	if (!t) return [];
	let n = (t, n) => ({
		key: n,
		label: t.label ? [t.label.zh, t.label.en] : [je(t.cost, t.do, 0), je(t.cost, t.do, 1)],
		enabled: G(e, t.cost) && q(e, t.if)
	});
	return t.choice?.length ? t.choice.map((e, t) => n(e, String(t))) : t.optional ? [n(t.optional, "opt"), {
		key: "skip",
		label: ["跳过", "Skip"],
		enabled: !0
	}] : [];
}
function Ne(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !Me(e)?.find((e) => e.key === t)?.enabled) return !1;
	let n = De(e.prompt.code ?? "");
	if (e.prompt = null, n?.choice) {
		let r = n.choice[Number(t)];
		r && (K(e, r.cost), e.queue.push(...H(e, r.do)));
	} else n?.optional && t === "opt" && (K(e, n.optional.cost), e.queue.push(...H(e, n.optional.do)));
	return U(e), !0;
}
function Pe(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("st:")) return null;
	let t = z[e.prompt.code.slice(3)];
	return t?.choice ? t.choice.map((t, n) => ({
		key: String(n),
		label: [t.label.zh, t.label.en],
		enabled: G(e, t.cost) && q(e, t.if)
	})) : [];
}
function Fe(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("st:") || !Pe(e)?.find((e) => e.key === t)?.enabled) return !1;
	let n = e.prompt.code.slice(3), r = z[n]?.choice?.[Number(t)];
	return e.prompt = null, r && (K(e, r.cost), e.queue.push(...H(e, r.do)), W(e, `故事 ${n}：${r.label.zh}`, `Story ${n}: ${r.label.en}`)), U(e), !0;
}
function Ie(e) {
	return e.prompt?.kind !== "pickOpt" || e.prompt.code !== "setup:8" ? null : [{
		key: "flower",
		label: ["免费放置 1 枚花朵贴纸（11A）", "Place 1 flower sticker (11A) free"],
		enabled: !0
	}, {
		key: "road",
		label: ["花 1 金币放置 1 枚道路贴纸（3E）", "Spend 1 gold to place 1 road sticker (3E)"],
		enabled: e.resources.gold >= 1
	}];
}
function Le(e, t) {
	return e.prompt?.kind !== "pickOpt" || e.prompt.code !== "setup:8" || !Ie(e)?.find((e) => e.key === t)?.enabled ? !1 : (e.prompt = null, t === "flower" ? e.queue.push({
		op: "place",
		code: "11A",
		n: 1
	}) : (K(e, { gold: 1 }), e.queue.push({
		op: "place",
		code: "3E",
		n: 1
	})), W(e, "村口的园丁送来一份礼物。", "The village gardener brings a gift."), U(e), !0);
}
var Re = {
	cat7extra: (e) => [{
		key: "yes",
		label: ["花费 1 金币再放 1 枚政治贴纸", "Spend 1 gold to place 1 more political sticker"],
		enabled: e.resources.gold >= 1
	}, {
		key: "no",
		label: ["不再追加", "Place no more"],
		enabled: !0
	}],
	cat7end: () => [{
		key: "yes",
		label: ["弃掉此牌并宣布参选结果（阅读 35.2）", "Discard this card and read 35.2"],
		enabled: !0
	}, {
		key: "no",
		label: ["保留此牌，稍后再宣布", "Keep this card for later"],
		enabled: !0
	}]
};
function ze(e) {
	return e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("ask:") ? null : Re[e.prompt.code.slice(4)]?.(e) ?? [];
}
function Be(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("ask:")) return !1;
	let n = e.prompt.code.slice(4);
	return ze(e)?.find((e) => e.key === t)?.enabled ? (e.prompt = null, e.queue[0]?.op === "ask" && e.queue.shift(), n === "cat7extra" && t === "yes" ? (K(e, { gold: 1 }), e.queue.unshift({
		op: "place",
		code: "11C",
		n: 1
	})) : n === "cat7end" && t === "yes" && (e.catalog = e.catalog.filter((e) => e !== "7"), e.queue.unshift({
		op: "story",
		key: "35.2"
	})), W(e, n === "cat7end" && t === "yes" ? "宣布参选结果。" : "竞选市长。", n === "cat7end" && t === "yes" ? "Declared the election result." : "Campaigning for mayor."), U(e), J(e), !0) : !1;
}
function U(e) {
	Ee(e), !e.prompt && !e.yearEnding && (e.after ? (e.phase = e.after, e.after = null) : e.phase === "placing" && (e.phase = "afternoon")), e.yearEnding && Ae(e);
}
function Ve(e) {
	let t = 0;
	for (let n of e.milestones) {
		let e = Te(n), r = le.find((t) => t.name.toLowerCase() === e);
		t += r?.gold ?? 0;
	}
	return t;
}
function He(e) {
	let t = _e(e.placed);
	e.resources.wood = Math.min(b.wood, e.resources.wood + t.wood), e.resources.food = Math.min(b.food, e.resources.food + t.food), e.resources.gold = Math.min(b.gold, e.resources.gold + Ve(e));
}
var Ue = {
	3: "y3setup",
	4: "y4setup",
	6: "y6setup",
	7: "y7setup",
	9: "y9setup"
};
function We(e, t) {
	e.year = t, e.deck = me(t, e.seed), e.discard = [], e.currentEvent = null, e.queue = [], e.prompt = null, e.after = null, e.yearEnding = !1, e.yearEndQueue = [], e.action = 0, t > 1 && He(e), e.phase = "morning";
	let n = !1;
	if (t === 2) e.queue.push({
		op: "card",
		key: "42"
	}), n = !0;
	else if (t === 5) e.queue.push({
		op: "place",
		code: Ce(e, "5C") ? "5C" : "5D",
		n: 1
	}), n = !0;
	else if (t === 8) q(e, { milestone: "Lucky" }) ? (e.phase = "placing", e.prompt = {
		kind: "pickOpt",
		code: "setup:8",
		pick: ["flower", "road"]
	}) : e.queue.push({
		op: "place",
		code: "10E",
		n: 1,
		allow: !0
	}), n = !0;
	else {
		let r = Ue[t];
		r && (e.queue.push({
			op: "branch",
			key: r
		}), n = !0);
	}
	n && (e.after = "morning", U(e));
}
function W(e, t, n) {
	e.log.push([t, n]), e.log.length > 120 && e.log.splice(0, e.log.length - 120);
}
function Ge(e, t, n) {
	return {
		version: 1,
		campaignId: "coz-" + (Math.floor(t) >>> 0).toString(36),
		serial: 0,
		owner: e,
		seed: t,
		cursor: 0,
		side: n,
		year: 1,
		phase: "starting",
		resources: de(),
		happiness: 2,
		action: 0,
		upset: 0,
		progress: 0,
		placed: [],
		startingPairs: [],
		inPlay: [],
		deck: [],
		discard: [],
		currentEvent: null,
		queue: [],
		prompt: null,
		after: null,
		yearEnding: !1,
		yearEndQueue: [],
		catalog: [],
		story: [],
		milestones: [],
		log: []
	};
}
var Ke = C.filter((e) => e.page === 9);
function qe(e) {
	return x.find((t) => t.includes(e));
}
function G(e, t) {
	return !t || Object.keys(t).every((n) => e.resources[n] >= (t[n] ?? 0));
}
function Je(e, t) {
	if (t) for (let n of Object.keys(t)) e.resources[n] = Math.max(0, e.resources[n] - (t[n] ?? 0));
}
function K(e, t) {
	Je(e, t);
}
function Ye(e) {
	let t = ge(e.placed), n = [];
	return e.placed.forEach((e, r) => {
		if (t.has(r)) return;
		let i = w[e.id];
		i && n.push({
			p: e,
			d: i
		});
	}), n;
}
function q(e, t) {
	if (!t) return !0;
	let n = (t) => e.milestones.some((e) => Te(e).includes(t.toLowerCase())), r = Ye(e), i = (e) => {
		let t = V(e)?.code ?? e;
		return r.filter((e) => e.d.code === t).length;
	}, a = (e) => e.reduce((e, t) => e + i(t), 0), o = r.filter((e) => e.d.bg !== "clear" && e.d.cols * e.d.rows >= 4).length, s = e.milestones.filter((e) => /\|red$/i.test(e)).length;
	if (t.milestone && !n(t.milestone) || t.notMilestone && n(t.notMilestone) || t.anyMilestone && !t.anyMilestone.some(n) || t.minHearts != null && e.happiness < t.minHearts || t.maxHearts != null && e.happiness > t.maxHearts) return !1;
	if (t.minRes) {
		for (let n of Object.keys(t.minRes)) if (e.resources[n] < (t.minRes[n] ?? 0)) return !1;
	}
	if (t.maxRes) {
		for (let n of Object.keys(t.maxRes)) if (e.resources[n] > (t.maxRes[n] ?? 0)) return !1;
	}
	if (t.hasSticker && !i(t.hasSticker) || t.notSticker && i(t.notSticker) || t.anySticker && !t.anySticker.some((e) => i(e) > 0) || t.noneStickers && t.noneStickers.some((e) => i(e) > 0) || t.allStickers && !t.allStickers.every((e) => i(e) > 0) || t.minUpset != null && e.upset < t.minUpset || t.maxUpset != null && e.upset > t.maxUpset) return !1;
	if (t.countCode) {
		let e = i(t.countCode.code);
		if (t.countCode.min != null && e < t.countCode.min || t.countCode.max != null && e > t.countCode.max) return !1;
	}
	if (t.countAny) {
		let e = a(t.countAny.codes);
		if (t.countAny.min != null && e < t.countAny.min || t.countAny.max != null && e > t.countAny.max) return !1;
	}
	if (t.minResidents != null && o < t.minResidents || t.maxResidents != null && o > t.maxResidents) return !1;
	let c = o - e.upset;
	if (t.minCalmResidents != null && c < t.minCalmResidents || t.maxCalmResidents != null && c > t.maxCalmResidents || t.minRedMilestones != null && s < t.minRedMilestones || t.maxRedMilestones != null && s > t.maxRedMilestones) return !1;
	if (t.minMapRes) {
		let n = _e(e.placed);
		for (let e of Object.keys(t.minMapRes)) if (n[e] < (t.minMapRes[e] ?? 0)) return !1;
	}
	if (t.maxMapRes) {
		let n = _e(e.placed);
		for (let e of Object.keys(t.maxMapRes)) if (n[e] > (t.maxMapRes[e] ?? 0)) return !1;
	}
	return !(t.hasCard && !e.catalog.includes(t.hasCard) || t.notCard && e.catalog.includes(t.notCard) || t.built && !n(t.built));
}
function Xe(e, t) {
	let n = [];
	for (let r of Object.keys(e)) {
		let i = e[r] ?? 0;
		if (!i) continue;
		let a = S[r][t];
		n.push(`${i > 0 ? "+" : ""}${i} ${a}`);
	}
	return n.join(t ? ", " : "，");
}
function Ze(e, t) {
	let n = t ? "no effect" : "无效果";
	if (!e || e.none) return n;
	let r = [];
	if (e.res && r.push(Xe(e.res, t)), e.hap && r.push(t ? `${e.hap > 0 ? "+" : ""}${e.hap} happiness` : `${e.hap > 0 ? "+" : ""}${e.hap} 心情`), e.place) {
		let n = e.n ?? 1;
		r.push(t ? `place ${e.place}${n > 1 ? " ×" + n : ""}` : `放置 ${e.place}${n > 1 ? " ×" + n : ""}`);
	}
	if (e.pickPlace && r.push(t ? "place a chosen sticker" : "放置自选贴纸"), e.card && r.push(t ? `gain card ${e.card}` : `获得图鉴牌 ${e.card}`), e.pickCard && r.push(t ? "gain a chosen card" : "获得自选图鉴牌"), e.pickRes && r.push(t ? "gain a chosen resource" : "获得自选资源"), e.exchange && r.push(t ? `exchange up to ${e.exchange.n}` : `兑换至多 ${e.exchange.n}`), e.story && r.push(t ? `read story ${e.story}` : `阅读故事 ${e.story}`), e.milestone && r.push(t ? `milestone ${e.milestone.split("|")[0]}` : `里程碑 ${e.milestone.split("|")[0]}`), e.removeMilestone && r.push(t ? `remove milestone ${e.removeMilestone}` : `移除里程碑 ${e.removeMilestone}`), e.upset && r.push(t ? `+${e.upset} upset` : `+${e.upset} 不满`), e.removeUpset && r.push(t ? `-${e.removeUpset} upset` : `-${e.removeUpset} 不满`), e.extraAction && r.push(t ? "another action" : "额外一次行动"), e.dice && r.push(t ? "roll a die" : "掷骰"), e.seq) for (let n of e.seq) r.push(Ze(n, t));
	return r.filter(Boolean).join(t ? ", " : "，") || n;
}
function Qe(e, t) {
	return e ? Object.keys(e).map((n) => `${e[n] ?? 0} ${S[n][t]}`).join(t ? ", " : "，") : "";
}
function $e(e) {
	let t = e.currentEvent ? y[e.currentEvent] : void 0;
	if (!t || !t.opts) return [];
	let n = [];
	for (let r of [
		"a",
		"b",
		"c"
	]) {
		let i = t.opts[r];
		if (!i) continue;
		let a;
		if (i.label) a = [i.label.zh, i.label.en];
		else {
			let e = Ze(i.do, 0), t = Ze(i.do, 1);
			a = i.cost ? [`${Qe(i.cost, 0)} · ${e}`, `${Qe(i.cost, 1)} · ${t}`] : [e, t];
		}
		n.push({
			key: r,
			label: a,
			cost: i.cost,
			enabled: G(e, i.cost) && q(e, i.if)
		});
	}
	return n;
}
function et(e) {
	let t = [];
	for (let n of e.inPlay) {
		let r = y[n];
		if (r?.keepActions) for (let i of r.keepActions) t.push({
			id: n,
			key: i.key,
			label: [i.label.zh, i.label.en],
			enabled: G(e, i.cost) && q(e, i.if)
		});
	}
	return t;
}
function tt(e) {
	let t = L[e];
	return { actions: t?.actions ?? (t?.action ? [t.action] : []) };
}
function nt(e, t) {
	if (!t.cost) return;
	let n = { ...t.cost };
	if (t.reducePer) {
		let r = V(t.reducePer.code)?.code ?? t.reducePer.code, i = Ye(e).filter((e) => e.d.code === r).length, a = t.reducePer.key;
		n[a] != null && (n[a] = Math.max(0, n[a] - i));
	}
	return n;
}
function rt(e) {
	let [t, n] = e.split("#");
	if (!t) return null;
	let r = tt(t).actions[Number(n ?? 0)];
	return r ? {
		label: t,
		action: r
	} : null;
}
function it(e) {
	let t = [];
	for (let n of e.catalog) tt(n).actions.forEach((r, i) => {
		t.push({
			id: n,
			key: `${n}#${i}`,
			label: [r.label.zh, r.label.en],
			enabled: G(e, nt(e, r)) && q(e, r.if)
		});
	});
	return t;
}
function at(e) {
	let t = ge(e.placed), n = /* @__PURE__ */ new Set(), r = [];
	return e.placed.forEach((i, a) => {
		if (t.has(a)) return;
		let o = w[i.id];
		o?.story && !n.has(o.code) && (n.add(o.code), r.push({
			id: i.id,
			code: o.code,
			story: o.story,
			label: [`${o.code} · 阅读 ${o.story}`, `${o.code} · read ${o.story}`],
			enabled: e.action > 0
		}));
	}), r;
}
function ot(e) {
	if (e.prompt?.kind !== "exchange") return null;
	let t = e.prompt.n ?? 0, n = !!e.prompt.allow, r = [];
	for (let i of D) for (let a of D) {
		if (i === a || a === "ore" && !n) continue;
		let o = a === "ore" ? 2 : 1;
		if (t < o || e.resources[i] < o || e.resources[a] + 1 > b[a]) continue;
		let s = `${S[i][0]}${o > 1 ? " ×2" : ""} → ${S[a][0]}`, c = `${S[i][1]}${o > 1 ? " ×2" : ""} → ${S[a][1]}`;
		r.push({
			key: `${i}>${a}`,
			label: [s, c],
			enabled: !0
		});
	}
	return r.push({
		key: "done",
		label: ["结束兑换", "Finish exchange"],
		enabled: !0
	}), r;
}
function st(e) {
	return e.prompt?.kind === "pickOpt" ? e.prompt.code?.startsWith("st:") ? Pe(e) ?? [] : e.prompt.code?.startsWith("ask:") ? ze(e) ?? [] : e.prompt.code === "setup:8" ? Ie(e) ?? [] : Me(e) ?? [] : e.prompt?.kind === "exchange" ? ot(e) ?? [] : [];
}
function ct(e) {
	if (e.currentEvent = null, e.action = 0, e.prompt = null, e.queue = [], e.after = null, !e.deck.length) {
		e.phase = "yearEnd";
		return;
	}
	e.phase = "morning";
}
function J(e) {
	!e.prompt && e.phase === "afternoon" && e.action <= 0 && ct(e);
}
function lt(e) {
	return e.happiness + e.milestones.length + e.catalog.length;
}
function ut(e) {
	let t = B[0];
	for (let n of B) e.happiness >= n.minHearts && (t = n);
	return t;
}
//#endregion
//#region src/game/rules.ts
var dt = {
	oob: "games.cozistickerville.errOob",
	bg: "games.cozistickerville.errBg",
	overlap: "games.cozistickerville.errOverlap",
	river: "games.cozistickerville.errRiver",
	pair: "games.cozistickerville.errPair",
	fold: "games.cozistickerville.errFold"
}, Y = (e) => ({ code: e ? dt[e] ?? "games.cozistickerville.invalid" : "games.cozistickerville.invalid" });
function ft(e) {
	e.prompt = null, e.queue[0]?.op === "place" && e.queue.shift(), U(e), J(e);
}
var pt = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: oe,
		privateView: se,
		config: F
	},
	setup(e, t, n) {
		let r = e.checkpoint ? structuredClone(e.checkpoint) : Ge(t[0], n, e.side);
		return r.owner = t[0], { state: r };
	},
	reduce(e, t, n) {
		if (t.type === "tick") return n.by === "$engine" ? { state: e } : Y();
		if (n.by !== e.owner || e.phase === "done") return Y();
		let r = structuredClone(e);
		if (t.type === "placeStarting") {
			if (r.phase !== "starting") return Y();
			let e = w[t.id];
			if (!e || e.page !== 9) return Y();
			if (r.startingPairs.includes(t.id) || qe(t.id)?.some((e) => e !== t.id && r.startingPairs.includes(e))) return Y("pair");
			let n = Se(r, e, t.col, t.row);
			if (!n.ok) return Y(n.reason);
			r.placed.push({
				id: e.id,
				col: t.col,
				row: t.row
			}), r.startingPairs.push(t.id), W(r, `放置起始贴纸 ${e.code}`, `Placed starting sticker ${e.code}`), r.startingPairs.length >= 8 && (He(r), W(r, "第一年开始。", "Year 1 begins."), We(r, 1));
		} else if (t.type === "placePending") {
			if (r.prompt?.kind !== "place") return Y();
			let e = V(r.prompt.code ?? "");
			if (!e) return Y();
			let n = !!r.prompt.cover, i = Se(r, e, t.col, t.row, n);
			if (!i.ok) return Y(i.reason);
			r.placed.push({
				id: e.id,
				col: t.col,
				row: t.row,
				cover: n || void 0
			}), W(r, `放置贴纸 ${e.code}`, `Placed sticker ${e.code}`), r.prompt = {
				...r.prompt,
				n: (r.prompt.n ?? 1) - 1
			}, (r.prompt.n ?? 0) <= 0 && ft(r);
		} else if (t.type === "skipPlace") {
			if (r.prompt?.kind !== "place") return Y();
			W(r, `跳过贴纸 ${r.prompt.code}`, `Skipped sticker ${r.prompt.code}`), r.prompt = {
				...r.prompt,
				n: (r.prompt.n ?? 1) - 1
			}, (r.prompt.n ?? 0) <= 0 && ft(r);
		} else if (t.type === "resolvePrompt") {
			if (!r.prompt) return Y();
			let e = r.prompt;
			if (e.kind === "pickOpt") {
				let n = e.code ?? "";
				if (n.startsWith("st:")) {
					if (!Fe(r, t.key)) return Y();
					J(r);
				} else if (n.startsWith("ask:")) {
					if (!Be(r, t.key)) return Y();
				} else if (n === "setup:8") {
					if (!Le(r, t.key)) return Y();
				} else if (!Ne(r, t.key)) return Y();
			} else if (r.phase !== "placing") return Y();
			else if (e.kind === "pickPlace") {
				if (!e.pick?.includes(t.key)) return Y();
				r.prompt = null, r.queue[0]?.op === "pickPlace" && r.queue.shift(), r.queue.unshift({
					op: "place",
					code: t.key,
					n: 1
				}), U(r);
			} else if (e.kind === "pickCard") {
				if (!e.pick?.includes(t.key)) return Y();
				r.prompt = null, r.queue[0]?.op === "pickCard" && r.queue.shift(), r.queue.unshift({
					op: "card",
					key: t.key
				}), W(r, `选择图鉴牌 ${t.key}`, `Chose catalog card ${t.key}`), U(r);
			} else if (e.kind === "pickRes") {
				if (!e.pick?.includes(t.key)) return Y();
				let n = t.key, i = e.n ?? 1;
				r.resources[n] = Math.min(b[n], r.resources[n] + i), r.prompt = null, r.queue[0]?.op === "pickRes" && r.queue.shift(), W(r, `获得资源 ${t.key} ×${i}`, `Gained ${t.key} ×${i}`), U(r);
			} else if (e.kind === "exchange") {
				if (t.key === "done") r.prompt = null, r.queue[0]?.op === "exchange" && r.queue.shift(), U(r), J(r);
				else {
					let [n, i] = t.key.split(">");
					if (!D.includes(n) || !D.includes(i) || n === i) return Y();
					let a = i === "ore" ? 2 : 1;
					if (i === "ore" && !e.allow || (e.n ?? 0) < a || r.resources[n] < a || r.resources[i] + 1 > b[i]) return Y();
					r.resources[n] -= a, r.resources[i] += 1, W(r, `兑换 1 ${S[i][0]}`, `Exchanged for 1 ${S[i][1]}`);
					let o = (e.n ?? 0) - a;
					o <= 0 ? (r.prompt = null, r.queue[0]?.op === "exchange" && r.queue.shift(), U(r), J(r)) : (r.prompt = {
						...e,
						n: o
					}, r.queue[0]?.op === "exchange" && (r.queue[0].n = o));
				}
			} else return Y();
		} else if (t.type === "draw") {
			if (r.phase !== "morning") return Y();
			if (!r.deck.length) return r.phase = "yearEnd", {
				state: r,
				fx: []
			};
			let e = r.deck.pop();
			r.currentEvent = e;
			let t = y[e];
			W(r, `第 ${r.year} 年 · 事件 ${t?.num ?? "?"}`, `Year ${r.year} · Event ${t?.num ?? "?"}`), t?.opts ? $e(r).every((e) => !e.enabled) ? (W(r, `事件 ${t.num} 无可用选项，跳过。`, `Event ${t.num}: no option available, skipped.`), t.kind === "keep" && !r.inPlay.includes(e) && r.inPlay.push(e), r.action = Math.max(1, r.action), r.phase = "afternoon") : r.phase = "choice" : (t?.kind === "keep" && !r.inPlay.includes(e) && r.inPlay.push(e), r.action = Math.max(1, r.action), r.phase = "afternoon");
		} else if (t.type === "choice") {
			if (r.phase !== "choice" || !r.currentEvent) return Y();
			let e = $e(r).find((e) => e.key === t.opt);
			if (!e || !e.enabled) return Y();
			let n = y[r.currentEvent], i = n?.opts?.[t.opt];
			K(r, i?.cost), r.action = 1, r.queue.push(...H(r, i?.do)), n?.kind === "keep" && !r.inPlay.includes(n.id) && r.inPlay.push(n.id), r.after = "afternoon", U(r);
		} else if (t.type === "useSticker") {
			if (r.phase !== "afternoon" || r.action <= 0) return Y();
			let e = at(r).find((e) => e.code === t.code);
			if (!e) return Y();
			r.queue.push({
				op: "story",
				key: e.story
			}), W(r, `贴纸行动：阅读故事 ${e.story}`, `Sticker action: read story ${e.story}`), --r.action, U(r), J(r);
		} else if (t.type === "useCard") {
			if (r.phase !== "afternoon" || r.action <= 0) return Y();
			let e = rt(t.key);
			if (!e || !r.catalog.includes(e.label)) return Y();
			let n = e.action;
			if (!q(r, n.if) || !G(r, nt(r, n))) return Y();
			K(r, nt(r, n)), r.queue.push(...H(r, n.do)), n.followUp && r.queue.push({
				op: "branch",
				key: n.followUp
			}), n.discard && (r.catalog = r.catalog.filter((t) => t !== e.label)), W(r, `使用图鉴牌 ${e.label}`, `Used catalog card ${e.label}`), --r.action, U(r), J(r);
		} else if (t.type === "useKeep") {
			if (r.phase !== "afternoon" || r.action <= 0) return Y();
			let e = y[t.id], n = e?.keepActions?.find((e) => e.key === t.key);
			if (!e || !r.inPlay.includes(t.id) || !n || !q(r, n.if) || !G(r, n.cost)) return Y();
			K(r, n.cost), r.queue.push(...H(r, n.do)), n.discard && (r.inPlay = r.inPlay.filter((e) => e !== t.id)), W(r, `使用留场牌：${n.label.zh}`, `Used kept card: ${n.label.en}`), --r.action, U(r), J(r);
		} else if (t.type === "endTurn") {
			if (r.phase !== "afternoon" && r.phase !== "placing") return Y();
			ct(r);
		} else if (t.type === "endYear") {
			if (r.phase !== "yearEnd" || r.yearEnding) return Y();
			r.yearEnding = !0, r.yearEndQueue = [...r.inPlay.map((e) => `e:${e}`), ...r.catalog.map((e) => `c:${e}`)].filter((e) => !!De(e)), r.after = null, U(r);
		}
		return r.serial++, {
			state: r,
			fx: []
		};
	},
	viewFor(e, t) {
		let n = e.phase === "choice" ? $e(e).map((e) => ({
			key: e.key,
			label: e.label,
			enabled: e.enabled
		})) : [], r = e.phase === "afternoon" ? et(e) : [], i = e.phase === "afternoon" ? it(e) : [], a = e.phase === "afternoon" ? at(e) : [], o = st(e).map((e) => ({
			key: e.key,
			label: e.label,
			enabled: e.enabled
		}));
		return {
			public: {
				campaignId: e.campaignId,
				side: e.side,
				year: e.year,
				phase: e.phase,
				resources: e.resources,
				happiness: e.happiness,
				action: e.action,
				upset: e.upset,
				progress: e.progress,
				placed: e.placed,
				startingPairs: e.startingPairs,
				deckCount: e.deck.length,
				discard: e.discard,
				currentEvent: e.currentEvent,
				inPlay: e.inPlay,
				prompt: e.prompt,
				promptOptions: o,
				catalog: e.catalog,
				story: e.story,
				milestones: e.milestones,
				choices: n,
				keepActions: r.map((e) => ({
					id: e.id,
					key: e.key,
					label: e.label,
					enabled: e.enabled
				})),
				catalogActions: i.map((e) => ({
					id: e.id,
					key: e.key,
					label: e.label,
					enabled: e.enabled
				})),
				stickerActions: a.map((e) => ({
					id: e.id,
					code: e.code,
					story: e.story,
					label: e.label,
					enabled: e.enabled
				})),
				ending: e.phase === "done" ? ut(e).key : null,
				mapIcons: _e(e.placed),
				log: e.log
			},
			private: { checkpoint: t === e.owner ? structuredClone(e) : null }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: [e.owner],
			ranking: [e.owner],
			scores: { [e.owner]: lt(e) }
		} : { phase: e.phase };
	}
}, mt = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), ht = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), gt = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), _t = (e) => {
	let t = gt(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, vt = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, yt = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, bt = t({}), xt = () => i(bt), St = r(({ color: e, size: t, strokeWidth: r, absoluteStrokeWidth: i, className: a = "", children: o, iconNode: s, ...c }, l) => {
	let { size: u = 24, strokeWidth: d = 2, absoluteStrokeWidth: ee = !1, color: f = "currentColor", className: te = "" } = xt() ?? {}, p = i ?? ee ? Number(r ?? d) * 24 / Number(t ?? u) : r ?? d;
	return n("svg", {
		ref: l,
		...vt,
		width: t ?? u ?? vt.width,
		height: t ?? u ?? vt.height,
		stroke: e ?? f,
		strokeWidth: p,
		className: mt("lucide", te, a),
		...!o && !yt(c) && { "aria-hidden": "true" },
		...c
	}, [...s.map(([e, t]) => n(e, t)), ...Array.isArray(o) ? o : [o]]);
}), Ct = (e, t) => {
	let i = r(({ className: r, ...i }, a) => n(St, {
		ref: a,
		iconNode: t,
		className: mt(`lucide-${ht(_t(e))}`, `lucide-${e}`, r),
		...i
	}));
	return i.displayName = _t(e), i;
}, wt = Ct("cloud-rain", [
	["path", {
		d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
		key: "1pljnt"
	}],
	["path", {
		d: "M16 14v6",
		key: "1j4efv"
	}],
	["path", {
		d: "M8 14v6",
		key: "17c4r9"
	}],
	["path", {
		d: "M12 16v6",
		key: "c8a4gj"
	}]
]), Tt = Ct("heart", [["path", {
	d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
	key: "mvr1a0"
}]]), Et = Ct("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]), Dt = "town-v1";
async function Ot() {
	let e = await f();
	return e.values[Dt] ? P.parse(JSON.parse(e.values[Dt])) : null;
}
async function kt(e) {
	let t = await f();
	for (let n = 0; n < 5; n++) {
		let n = t.values[Dt], r = n ? P.parse(JSON.parse(n)) : null;
		if (r?.campaignId === e.campaignId && r.serial > e.serial) return "newer";
		if (r?.campaignId === e.campaignId && r.serial === e.serial) return JSON.stringify(r) === JSON.stringify(e) ? "saved" : "newer";
		let i = await te({
			revision: t.revision,
			values: {
				...t.values,
				[Dt]: JSON.stringify(e)
			}
		});
		if (i.status === "saved") return "saved";
		if (i.snapshot.values[Dt] !== t.values[Dt]) return "newer";
		t = i.snapshot;
	}
	throw Error("storage-conflict");
}
//#endregion
//#region src/game/town-map.tsx
var X = (e) => p(`games/cozistickerville/${e}`), Z = {
	w: 4400,
	h: 1916
}, At = {
	x: 27,
	y: 26,
	w: 3867,
	h: 1864
}, Q = {
	w: At.w / R.cols,
	h: At.h / R.rows
}, jt = {
	x: Z.w / 2,
	y: Z.h / 2,
	z: 1
}, Mt = {
	oob: "games.cozistickerville.errOob",
	bg: "games.cozistickerville.errBg",
	overlap: "games.cozistickerville.errOverlap",
	river: "games.cozistickerville.errRiver",
	fold: "games.cozistickerville.errFold",
	pair: "games.cozistickerville.errPair"
}, $ = ({ col: e, row: t }) => t * R.cols + e, Nt = ({ col: e, row: t }) => e >= 0 && e < R.cols && t >= 0 && t < R.rows, Pt = ({ col: e, row: t }) => ({
	x: At.x + e * Q.w,
	y: At.y + t * Q.h
}), Ft = (e, t, n) => Math.min(n, Math.max(t, e)), It = (e, t) => ({
	x: (e.x + t.x) / 2,
	y: (e.y + t.y) / 2
}), Lt = (e, t) => Math.hypot(e.x - t.x, e.y - t.y);
function Rt(e, t) {
	return {
		left: t.x,
		top: t.y,
		width: e.cols * Q.w,
		height: e.rows * Q.h
	};
}
function zt({ w: e, h: t }) {
	return Math.min(e / Z.w, t / Z.h);
}
function Bt(e, t) {
	let n = zt(t) * e.z;
	if (!n) return e;
	let r = Math.min(Z.w / 2, t.w / (2 * n)), i = Math.min(Z.h / 2, t.h / (2 * n));
	return {
		x: Ft(e.x, r, Z.w - r),
		y: Ft(e.y, i, Z.h - i),
		z: e.z
	};
}
function Vt(e, t, n) {
	let r = zt(n) * t.z;
	return {
		x: t.x + (e.x - n.w / 2) / r,
		y: t.y + (e.y - n.h / 2) / r
	};
}
function Ht(e, t, n, r, i) {
	let a = Vt(n, e, t), o = Ft(e.z * i, 1, 5), s = zt(t) * o;
	return Bt({
		z: o,
		x: a.x - (r.x - t.w / 2) / s,
		y: a.y - (r.y - t.h / 2) / s
	}, t);
}
function Ut({ side: e, placed: t, draft: n, stories: r, readOnly: i = !1, children: o }) {
	let l = d(), u = m(), ee = s(null), [f, te] = c({
		w: 0,
		h: 0
	}), [p, h] = c(jt), v = s(jt), y = s(/* @__PURE__ */ new Map()), b = s(null), [x, S] = c(null), [C, T] = c(null), [E, D] = c(null), O = n?.pending, k = zt(f) * p.z, A = f.w / 2 - p.x * k, j = f.h / 2 - p.y * k;
	a(() => {
		let e = ee.current;
		if (!e) return;
		function t() {
			if (!e) return;
			let t = {
				w: e.clientWidth,
				h: e.clientHeight
			};
			v.current = Bt(v.current, t), h(v.current), te(t);
		}
		function n(t) {
			if (!e || y.current.size || !e.clientWidth || !e.clientHeight || !t.deltaY) return;
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = {
				x: t.clientX - n.left - e.clientLeft,
				y: t.clientY - n.top - e.clientTop
			}, i = t.deltaY * (t.deltaMode === 1 ? 16 : t.deltaMode === 2 ? 100 : 1), a = {
				w: e.clientWidth,
				h: e.clientHeight
			}, o = Ht(v.current, a, r, r, Math.exp(-Ft(i, -160, 160) * .0035));
			v.current = o, h(o);
		}
		t();
		let r = new ResizeObserver(t);
		return r.observe(e), e.addEventListener("wheel", n, { passive: !1 }), () => {
			r.disconnect(), e.removeEventListener("wheel", n);
		};
	}, []);
	function M(e) {
		v.current = e, h(e);
	}
	function N(e) {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: e.clientX - t.left - e.currentTarget.clientLeft,
			y: e.clientY - t.top - e.currentTarget.clientTop
		};
	}
	function P(e) {
		let t = Vt(e, v.current, f);
		return {
			col: Math.floor((t.x - At.x) / Q.w),
			row: Math.floor((t.y - At.y) / Q.h)
		};
	}
	function F(e) {
		if (!n) return;
		let t = Nt(e) ? n.hits.get($(e)) : void 0;
		if (!t?.ok) {
			D({
				scope: n.scope,
				message: t ? Mt[t.reason] : Mt.oob
			});
			return;
		}
		D(null), n.choose(e);
	}
	function ne(e) {
		if (!k || e.button !== 0 || e.target.closest("button")) return;
		let t = N(e);
		if (y.current.set(e.pointerId, t), e.currentTarget.setPointerCapture(e.pointerId), y.current.size === 1) {
			let n = e.target.closest(".cz-map-picked");
			b.current = {
				start: t,
				last: t,
				moved: !1,
				anchor: n && O ? O : void 0
			}, D(null);
		} else b.current = null, S(null);
		T(null);
	}
	function I(e, t) {
		let n = Pt(e.anchor), r = zt(f) * v.current.z, i = (t.x - e.start.x) / r, a = (t.y - e.start.y) / r;
		return {
			art: {
				x: n.x + i,
				y: n.y + a
			},
			at: {
				col: e.anchor.col + Math.round(i / Q.w),
				row: e.anchor.row + Math.round(a / Q.h)
			}
		};
	}
	function re(e) {
		if (!k) return;
		let t = N(e), r = y.current.get(e.pointerId);
		if (!r) {
			e.pointerType === "mouse" && n && !O && T(P(t));
			return;
		}
		if (y.current.set(e.pointerId, t), y.current.size === 2) {
			let n = [...y.current].find(([t]) => t !== e.pointerId)?.[1];
			if (!n) return;
			let i = Lt(r, n);
			i > 0 && M(Ht(v.current, f, It(r, n), It(t, n), Lt(t, n) / i));
			return;
		}
		let i = b.current;
		i && (!i.moved && Lt(t, i.start) < 5 || (i.moved = !0, i.anchor && O && n ? S(I(i, t)) : i.anchor || M(Ht(v.current, f, i.last, t, 1)), i.last = t));
	}
	function ie(e, t = !1) {
		if (!y.current.delete(e.pointerId)) return;
		let r = b.current, i = N(e);
		r && !t && (r.anchor && r.moved && n && O && F(I(r, i).at), !r.anchor && !r.moved && F(P(i)));
		let a = y.current.size === 1 ? y.current.values().next().value : void 0;
		b.current = a ? {
			start: a,
			last: a,
			moved: !0
		} : null, S(null);
	}
	function ae(e) {
		if (!k) return;
		let t = {
			x: f.w / 2,
			y: f.h / 2
		};
		M(Ht(v.current, f, t, t, e));
	}
	function oe(e) {
		if (!n || !k) return !1;
		let t = {
			ArrowLeft: [-1, 0],
			ArrowUp: [0, -1],
			ArrowRight: [1, 0],
			ArrowDown: [0, 1]
		}[e];
		if (!t) return !1;
		let [r = 0, i = 0] = t, a = O ? Array.from({ length: Math.max(R.cols, R.rows) }, (e, t) => ({
			col: O.col + r * (t + 1),
			row: O.row + i * (t + 1)
		})).find((e) => Nt(e) && n.hits.get($(e))?.ok) : [...n.hits].filter(([, e]) => e.ok).map(([e]) => ({
			col: e % R.cols,
			row: Math.floor(e / R.cols)
		}))[0];
		if (a) {
			F(a);
			let e = Pt(a);
			M(Bt({
				x: e.x + Q.w * n.sticker.cols / 2,
				y: e.y + Q.h * n.sticker.rows / 2,
				z: v.current.z
			}, f));
		}
		return !0;
	}
	let se = r?.length ? ge(t) : void 0, L = n && (x?.at ?? O ?? (C && Nt(C) && n.hits.get($(C))?.ok ? C : null)), ce = L ? Pt(L) : void 0, le = L && Nt(L) ? n?.hits.get($(L)) : void 0, ue = n && (x && !le?.ok ? le ? Mt[le.reason] : Mt.oob : E?.scope === n.scope && E.message), z = ce && n ? Rt(n.sticker, ce) : void 0, B = z && {
		x: A + (z.left + z.width / 2) * k,
		y: j + z.top * k
	}, de = B && z ? B.y + z.height * k : 0, fe = B && z && B.x + z.width * k / 2 > 0 && B.x - z.width * k / 2 < f.w && de > 0 && B.y < f.h, pe = n && [...n.hits].filter(([, e]) => e.ok), me = !!pe && pe.length > 16, V = !u && /* @__PURE__ */ g("animate", {
		attributeName: "stroke-dashoffset",
		from: "0",
		to: "-12",
		dur: ".7s",
		repeatCount: "indefinite"
	}), he = k ? 1 / k : 1, _e = !u && /* @__PURE__ */ g("animate", {
		attributeName: "stroke-dashoffset",
		from: "0",
		to: -12 * he,
		dur: ".7s",
		repeatCount: "indefinite"
	}), ve = X(`map/${e.toLowerCase()}.webp`);
	return /* @__PURE__ */ _("div", {
		className: "cz-map-viewport",
		ref: ee,
		tabIndex: 0,
		"aria-label": l("games.cozistickerville.side", { s: e }),
		onPointerDown: ne,
		onPointerMove: re,
		onPointerUp: ie,
		onPointerCancel: (e) => ie(e, !0),
		onLostPointerCapture: (e) => ie(e, !0),
		onPointerLeave: () => T(null),
		onKeyDown: (e) => {
			e.currentTarget === e.target && oe(e.key) && e.preventDefault();
		},
		children: [
			/* @__PURE__ */ _("div", {
				className: "cz-map-stage",
				style: {
					width: Z.w,
					height: Z.h,
					transform: `translate(${A}px, ${j}px) scale(${k})`
				},
				children: [
					/* @__PURE__ */ g("img", {
						className: "cz-map-img",
						src: ve,
						alt: "",
						draggable: !1
					}),
					t.map((e, t) => {
						let n = w[e.id];
						if (!n) return null;
						let a = !se?.has(t) && r?.find((e) => e.code === n.code), o = Rt(n, Pt(e));
						return /* @__PURE__ */ _("div", {
							className: "cz-map-sticker",
							style: {
								...o,
								zIndex: t
							},
							children: [/* @__PURE__ */ g("img", {
								src: X(n.file),
								alt: i ? "" : n.name,
								draggable: !1
							}), a && k > 0 && /* @__PURE__ */ g("button", {
								type: "button",
								className: "cz-map-story",
								style: {
									width: 25 / k,
									height: 25 / k,
									fontSize: 14 / k,
									borderRadius: 5 / k
								},
								onClick: a.read,
								"aria-label": a.label,
								title: a.label,
								children: "↗"
							})]
						}, `${e.id}-${e.col}-${e.row}-${t}`);
					}),
					!!pe?.length && /* @__PURE__ */ g("svg", {
						className: "cz-map-targets",
						viewBox: `0 0 ${Z.w} ${Z.h}`,
						"aria-hidden": "true",
						children: pe.map(([e]) => {
							let t = Pt({
								col: e % R.cols,
								row: Math.floor(e / R.cols)
							}), n = t.x + Q.w / 2, r = t.y + Q.h / 2;
							return me ? /* @__PURE__ */ g("path", { d: `M ${n} ${r - 17} l 17 17 -17 17 -17 -17 Z` }, e) : /* @__PURE__ */ g("rect", {
								x: t.x + 11,
								y: t.y + 11,
								width: Q.w - 22,
								height: Q.h - 22,
								rx: 15,
								className: "cz-map-dashes",
								children: V
							}, e);
						})
					}),
					z && n && /* @__PURE__ */ _("div", {
						className: `cz-map-preview${O && !x ? " cz-map-picked" : ""}${le?.ok ? "" : " is-invalid"}`,
						style: z,
						children: [/* @__PURE__ */ _("svg", {
							viewBox: `0 0 ${z.width} ${z.height}`,
							"aria-hidden": "true",
							children: [/* @__PURE__ */ g("rect", {
								x: "5",
								y: "5",
								width: z.width - 10,
								height: z.height - 10,
								rx: "12",
								strokeWidth: 4 * he
							}), /* @__PURE__ */ g("rect", {
								x: "5",
								y: "5",
								width: z.width - 10,
								height: z.height - 10,
								rx: "12",
								strokeWidth: 2 * he,
								strokeDasharray: `${7 * he} ${5 * he}`,
								children: _e
							})]
						}), /* @__PURE__ */ g("img", {
							src: X(n.sticker.file),
							alt: "",
							draggable: !1,
							style: x ? { transform: `translate(${x.art.x - z.left}px, ${x.art.y - z.top}px)` } : void 0
						})]
					})
				]
			}),
			p.z > 1.01 && /* @__PURE__ */ _("div", {
				className: "cz-map-mini",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ g("img", {
					src: ve,
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ g("span", { style: {
					left: `${Math.max(0, -A / (k * Z.w) * 100)}%`,
					top: `${Math.max(0, -j / (k * Z.h) * 100)}%`,
					width: `${Math.min(100, f.w / (k * Z.w) * 100)}%`,
					height: `${Math.min(100, f.h / (k * Z.h) * 100)}%`
				} })]
			}),
			/* @__PURE__ */ _("div", {
				className: "cz-map-tools",
				children: [
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => ae(1.4),
						disabled: p.z >= 5,
						"aria-label": l("games.cozistickerville.zoomIn"),
						children: "+"
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => ae(1 / 1.4),
						disabled: p.z <= 1,
						"aria-label": l("games.cozistickerville.zoomOut"),
						children: "−"
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => M(jt),
						children: l("games.cozistickerville.zoomReset")
					})
				]
			}),
			O && !x && n && B && fe && /* @__PURE__ */ _("div", {
				className: "cz-map-confirm",
				style: {
					left: Ft(B.x, Math.min(f.w / 2, 112), Math.max(f.w / 2, f.w - 112)),
					top: de + 100 < f.h ? Math.max(6, de + 8) : Math.max(6, Math.min(f.h - 95, B.y - 45))
				},
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: "cz-btn",
					onClick: () => {
						D(null), n.choose(null);
					},
					children: l("games.cozistickerville.cancel")
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "cz-btn cz-primary",
					onClick: () => {
						D(null), n.confirm();
					},
					children: l("games.cozistickerville.confirmPlace")
				})]
			}),
			ue && /* @__PURE__ */ g("div", {
				className: "cz-map-error",
				role: "status",
				children: l(ue)
			}),
			o
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
var Wt = {
	starting: "games.cozistickerville.phStarting",
	morning: "games.cozistickerville.phMorning",
	choice: "games.cozistickerville.phChoice",
	afternoon: "games.cozistickerville.phAfternoon",
	placing: "games.cozistickerville.phPlacing",
	yearEnd: "games.cozistickerville.phYearEnd",
	done: "games.cozistickerville.phDone"
}, Gt = [
	{
		key: "wood",
		label: "games.cozistickerville.wood"
	},
	{
		key: "food",
		label: "games.cozistickerville.food"
	},
	{
		key: "gold",
		label: "games.cozistickerville.gold"
	},
	{
		key: "ore",
		label: "games.cozistickerville.ore"
	}
], Kt = {
	wood: {
		background: "#eaa153",
		mark: /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				fill: "#7d4c28",
				d: "M5 16 8 12l1-5 2-1 1 4 3-5 4 1 2 4-9 10-4-1Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "#eeb67a",
				d: "m15 5 4 1 2 4-3 2-4-3Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "none",
				stroke: "#5c3925",
				d: "m8 16 6-6m-3 8 5-6m1-5 2 2"
			})
		] })
	},
	food: {
		background: "#6d8a55",
		mark: /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				fill: "#ae392c",
				d: "M12 9c-3-3-8-1-8 4 0 4 3 8 6 7l2-1 2 1c3 1 6-3 6-7 0-5-5-7-8-4Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "#77a449",
				d: "M12 8c0-3 3-5 6-4-1 3-3 4-6 4Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "none",
				d: "m12 9-2-5"
			}),
			/* @__PURE__ */ g("path", {
				stroke: "#ffd68a",
				strokeWidth: "2",
				d: "m7.5 12-.5 2"
			})
		] })
	},
	gold: {
		background: "#f6c761",
		mark: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("circle", {
			cx: "12",
			cy: "12",
			r: "8",
			fill: "#f8d77e",
			stroke: "#835522"
		}), /* @__PURE__ */ g("path", {
			fill: "#e4a543",
			stroke: "#835522",
			d: "m6 10 3 2 3-4 3 4 3-2-2 6H8Z"
		})] })
	},
	ore: {
		background: "#85adbf",
		mark: /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				fill: "#56595b",
				d: "m6 12 1-4 4-3 3 2 3-1 2 3 1 3Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "#a6754d",
				d: "M4 12h16l-2 6H6Z"
			}),
			/* @__PURE__ */ g("path", {
				fill: "none",
				stroke: "#503c2e",
				d: "M8 15h8"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "8",
				cy: "19",
				r: "1.3",
				fill: "#292824"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "16",
				cy: "19",
				r: "1.3",
				fill: "#292824"
			})
		] })
	}
};
function qt({ kind: e }) {
	let { background: t, mark: n } = Kt[e];
	return /* @__PURE__ */ _("svg", {
		width: "18",
		height: "18",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ g("circle", {
			cx: "12",
			cy: "12",
			r: "10.8",
			fill: t,
			stroke: "#5e4533",
			strokeWidth: "1.1"
		}), /* @__PURE__ */ g("g", {
			stroke: "#352b22",
			strokeWidth: "1.15",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: n
		})]
	});
}
var Jt = Ke.flatMap((e) => {
	let t = qe(e.id);
	return t?.[0] === e.id ? [t.map((e) => w[e])] : [];
});
function Yt({ open: e, title: t, onClose: n, children: r }) {
	return /* @__PURE__ */ g(l, {
		open: e,
		onClose: n,
		label: t,
		title: t,
		tall: !0,
		compact: !0,
		children: /* @__PURE__ */ g("div", {
			className: "cz-sheet",
			children: /* @__PURE__ */ g("div", {
				className: "cz-sheet-body",
				children: r
			})
		})
	});
}
function Xt({ checkpoint: e }) {
	let t = d(), [n, r] = c(null), [i, a] = c(!1);
	async function o() {
		if (e && !i) {
			a(!0), r("games.cozistickerville.saving");
			try {
				let t = await kt(e);
				r(t === "saved" ? "games.cozistickerville.saved" : "games.cozistickerville.saveNewer");
			} catch {
				r("games.cozistickerville.saveError");
			} finally {
				a(!1);
			}
		}
	}
	return /* @__PURE__ */ _("div", {
		className: "cz-save",
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			className: "cz-btn cz-save-btn",
			disabled: !e || i,
			onClick: () => void o(),
			children: t(n === "games.cozistickerville.saving" ? "games.cozistickerville.saving" : "games.cozistickerville.save")
		}), n && n !== "games.cozistickerville.saving" && n !== "games.cozistickerville.save" && /* @__PURE__ */ g("span", {
			role: "status",
			className: "cz-save-status",
			children: t(n)
		})]
	});
}
function Zt(e) {
	let t = e.public, n = e.private?.checkpoint ?? null, r = d(), i = u((e) => e.locale) === "zh" ? 0 : 1, a = (e) => i === 0 ? e.zh : e.en, s = e.send, [l, f] = c(null), [te, p] = c(null), [m, h] = c(null), v = t.prompt, b = `${t.campaignId}:${t.side}`, x = new Set(t.startingPairs), S = (e) => !x.has(e) && !qe(e)?.some((e) => x.has(e)), C = t.phase === "starting" && l?.campaign === b && S(l.id) ? l.id : null, T = C ? w[C] : v?.kind === "place" ? V(v.code ?? "") : void 0, E = !C && !!v?.cover, D = `${b}:${t.phase}:${t.year}:${T?.id ?? ""}:${t.placed.length}:${E}:${v?.n ?? ""}`, O = o(() => {
		let e = /* @__PURE__ */ new Map();
		if (!T) return e;
		let n = {
			side: t.side,
			placed: t.placed
		};
		for (let t = 0; t < R.rows; t++) for (let r = 0; r < R.cols; r++) e.set($({
			col: r,
			row: t
		}), Se(n, T, r, t, E));
		return e;
	}, [
		t.side,
		t.placed,
		T,
		E
	]), k = te?.scope === D && O.get($(te.cell))?.ok ? te.cell : null, A = t.phase === "afternoon" && t.action > 0;
	function j(e) {
		p(e ? {
			scope: D,
			cell: e
		} : null);
	}
	function M() {
		k && T && (j(null), C ? (f(null), s({
			type: "placeStarting",
			id: C,
			...k
		})) : v?.kind === "place" && s({
			type: "placePending",
			...k
		}));
	}
	let N = /* @__PURE__ */ _("div", {
		className: "cz-banner",
		children: [/* @__PURE__ */ _("div", {
			className: "cz-banner-row",
			children: [
				/* @__PURE__ */ _("div", {
					className: "cz-title",
					children: [/* @__PURE__ */ g("h1", { children: r("games.cozistickerville.name") }), /* @__PURE__ */ g("span", {
						className: "cz-phase",
						children: r(Wt[t.phase] ?? "games.cozistickerville.phMorning")
					})]
				}),
				/* @__PURE__ */ _("div", {
					className: "cz-banner-meta",
					children: [
						/* @__PURE__ */ g("span", { children: r("games.cozistickerville.year", { n: t.year }) }),
						t.phase !== "starting" && /* @__PURE__ */ g("span", { children: r("games.cozistickerville.deckCount", { n: t.deckCount }) }),
						t.phase === "afternoon" && /* @__PURE__ */ g("span", { children: r("games.cozistickerville.actionLeft", { n: t.action }) })
					]
				}),
				/* @__PURE__ */ g(Xt, { checkpoint: n })
			]
		}), /* @__PURE__ */ _("div", {
			className: "cz-stats",
			children: [
				/* @__PURE__ */ _("div", {
					className: "cz-hearts",
					title: r("games.cozistickerville.hearts"),
					children: [/* @__PURE__ */ g(Tt, {
						size: 18,
						fill: "currentColor",
						"aria-hidden": "true"
					}), /* @__PURE__ */ g("b", { children: t.happiness })]
				}),
				Gt.map(({ key: e, label: n }) => /* @__PURE__ */ _("div", {
					className: `cz-res is-${e}`,
					title: r(n),
					"aria-label": `${r(n)} ${t.resources[e]}`,
					children: [/* @__PURE__ */ g(qt, { kind: e }), /* @__PURE__ */ g("b", { children: t.resources[e] })]
				}, e)),
				t.upset > 0 && /* @__PURE__ */ _("div", {
					className: "cz-res is-upset",
					title: r("games.cozistickerville.upset"),
					children: [/* @__PURE__ */ g(wt, {
						size: 18,
						"aria-hidden": "true"
					}), /* @__PURE__ */ g("b", { children: t.upset })]
				})
			]
		})]
	}), P = /* @__PURE__ */ g(Ut, {
		side: t.side,
		placed: t.placed,
		draft: T ? {
			scope: D,
			sticker: T,
			pending: k,
			hits: O,
			choose: j,
			confirm: M
		} : void 0,
		stories: A ? t.stickerActions.filter((e) => e.enabled).map((e) => ({
			code: e.code,
			label: e.label[i],
			read: () => s({
				type: "useSticker",
				code: e.code
			})
		})) : void 0
	}, b), F = t.currentEvent && /* @__PURE__ */ g("button", {
		type: "button",
		className: "cz-event",
		onClick: () => h("event"),
		"aria-label": r("games.cozistickerville.eventTitle"),
		children: /* @__PURE__ */ g("img", {
			src: X(`events/${t.currentEvent}.webp`),
			alt: "",
			draggable: !1
		})
	}), ne = t.phase === "starting" && /* @__PURE__ */ g("div", {
		className: "cz-start-strip",
		children: /* @__PURE__ */ g("div", {
			className: "cz-start-cards",
			children: Jt.map((e) => /* @__PURE__ */ g("div", {
				className: "cz-start-pair",
				children: e.map((e, t) => /* @__PURE__ */ _("div", {
					className: "cz-pair-item",
					children: [t > 0 && /* @__PURE__ */ g("span", {
						className: "cz-pair-or",
						children: r("games.cozistickerville.pairOr")
					}), /* @__PURE__ */ _("button", {
						type: "button",
						className: `cz-start-card${C === e.id ? " is-selected" : ""}`,
						disabled: !S(e.id),
						"aria-pressed": C === e.id,
						onClick: () => {
							j(null), f(C === e.id ? null : {
								campaign: b,
								id: e.id
							});
						},
						children: [/* @__PURE__ */ g("img", {
							src: X(e.file),
							alt: "",
							draggable: !1
						}), /* @__PURE__ */ g("span", { children: e.code })]
					})]
				}, e.id))
			}, e[0]?.id))
		})
	}), I;
	if (t.phase === "starting") I = /* @__PURE__ */ _("div", {
		className: "cz-work-content",
		children: [
			/* @__PURE__ */ g("h2", { children: r("games.cozistickerville.phStarting") }),
			/* @__PURE__ */ g("p", { children: r("games.cozistickerville.setupCount", {
				done: t.startingPairs.length,
				total: 8
			}) }),
			T && /* @__PURE__ */ _("figure", {
				className: "cz-current-sticker",
				children: [/* @__PURE__ */ g("img", {
					src: X(T.file),
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ g("figcaption", { children: T.code })]
			}),
			/* @__PURE__ */ g("p", { children: r(k ? "games.cozistickerville.adjustSticker" : T ? "games.cozistickerville.pickPosition" : "games.cozistickerville.pairHint") })
		]
	});
	else if (t.phase === "morning") I = /* @__PURE__ */ _("div", {
		className: "cz-work-content",
		children: [/* @__PURE__ */ g("h2", { children: r("games.cozistickerville.phMorning") }), /* @__PURE__ */ _("button", {
			type: "button",
			className: "cz-deck",
			onClick: () => s({ type: "draw" }),
			children: [/* @__PURE__ */ g("span", {
				className: "cz-deck-back",
				"aria-hidden": "true",
				children: /* @__PURE__ */ g(Et, { size: 32 })
			}), /* @__PURE__ */ g("span", { children: r("games.cozistickerville.draw") })]
		})]
	});
	else if (t.phase === "choice") I = /* @__PURE__ */ _("div", {
		className: "cz-work-content cz-choice-list",
		children: [F, t.choices.map((e) => /* @__PURE__ */ _("button", {
			type: "button",
			className: "cz-btn cz-choice",
			disabled: !e.enabled,
			onClick: () => s({
				type: "choice",
				opt: e.key
			}),
			children: [/* @__PURE__ */ g("span", {
				className: "cz-choice-key",
				children: e.key.toUpperCase()
			}), /* @__PURE__ */ g("span", {
				className: "cz-choice-label",
				children: e.label[i]
			})]
		}, e.key))]
	});
	else if (t.phase === "afternoon") I = /* @__PURE__ */ _("div", {
		className: "cz-work-content",
		children: [
			F,
			t.inPlay.length > 0 && /* @__PURE__ */ g("button", {
				type: "button",
				className: "cz-btn",
				onClick: () => h("buildings"),
				children: r("games.cozistickerville.inPlayTitle")
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "cz-btn cz-primary",
				onClick: () => s({ type: "endTurn" }),
				children: r("games.cozistickerville.endTurn")
			})
		]
	});
	else if (t.phase === "placing" || t.phase === "yearEnd") {
		if (v?.kind === "pickOpt") I = /* @__PURE__ */ g("div", {
			className: "cz-actions cz-choice-list",
			children: t.promptOptions.map((e) => /* @__PURE__ */ _("button", {
				type: "button",
				className: "cz-btn cz-choice",
				disabled: !e.enabled,
				onClick: () => s({
					type: "resolvePrompt",
					key: e.key
				}),
				children: [/* @__PURE__ */ g("span", {
					className: "cz-choice-key",
					children: e.key === "skip" ? "–" : "✓"
				}), /* @__PURE__ */ g("span", {
					className: "cz-choice-label",
					children: e.label[i]
				})]
			}, e.key))
		});
		else if (v?.kind === "exchange") I = /* @__PURE__ */ _("div", {
			className: "cz-actions cz-choice-list",
			children: [/* @__PURE__ */ g("div", {
				className: "cz-hint",
				children: r("games.cozistickerville.exchangeHint", { n: v.n ?? 0 })
			}), t.promptOptions.map((e) => /* @__PURE__ */ _("button", {
				type: "button",
				className: "cz-btn cz-choice",
				disabled: !e.enabled,
				onClick: () => s({
					type: "resolvePrompt",
					key: e.key
				}),
				children: [/* @__PURE__ */ g("span", {
					className: "cz-choice-key",
					children: e.key === "done" ? "–" : "⇄"
				}), /* @__PURE__ */ g("span", {
					className: "cz-choice-label",
					children: e.label[i]
				})]
			}, e.key))]
		});
		else if (v?.kind === "pickRes" || v?.kind === "pickCard" || v?.kind === "pickPlace") {
			let e = v.kind === "pickRes" ? "games.cozistickerville.pickResHint" : v.kind === "pickCard" ? "games.cozistickerville.pickCardHint" : "games.cozistickerville.pickPlaceHint";
			I = /* @__PURE__ */ _("div", {
				className: "cz-actions",
				children: [/* @__PURE__ */ g("div", {
					className: "cz-hint",
					children: r(e)
				}), /* @__PURE__ */ g("div", {
					className: "cz-act-list",
					children: (v.pick ?? []).map((e) => {
						let t = v.kind === "pickPlace" ? V(e) : void 0, n = v.kind === "pickCard" ? L[e] : void 0, i = v.kind === "pickRes" ? Gt.find((t) => t.key === e) : void 0, a = t?.file ?? n?.file;
						return /* @__PURE__ */ _("button", {
							type: "button",
							className: "cz-btn cz-act",
							onClick: () => s({
								type: "resolvePrompt",
								key: e
							}),
							children: [
								a && /* @__PURE__ */ g("img", {
									src: X(a),
									alt: "",
									draggable: !1
								}),
								i && /* @__PURE__ */ g(qt, { kind: i.key }),
								t?.code ?? (i ? r(i.label) : e)
							]
						}, e);
					})
				})]
			});
		} else I = v?.kind === "place" ? /* @__PURE__ */ _("div", {
			className: "cz-actions",
			children: [
				T && /* @__PURE__ */ g("img", {
					className: "cz-prompt-sticker",
					src: X(T.file),
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ g("div", {
					className: "cz-hint",
					children: r("games.cozistickerville.pendingHint", {
						code: v.code ?? "",
						n: v.n ?? 0
					})
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: "cz-btn",
					onClick: () => {
						j(null), s({ type: "skipPlace" });
					},
					children: r("games.cozistickerville.skipPlace")
				})
			]
		}) : /* @__PURE__ */ _("div", {
			className: "cz-actions",
			children: [/* @__PURE__ */ g("div", {
				className: "cz-hint",
				children: r("games.cozistickerville.yearEndHint")
			}), /* @__PURE__ */ g("button", {
				type: "button",
				className: "cz-btn cz-primary",
				onClick: () => s({ type: "endYear" }),
				children: r("games.cozistickerville.endYear")
			})]
		});
	} else I = /* @__PURE__ */ g("div", {
		className: "cz-actions cz-finale",
		children: /* @__PURE__ */ g("div", {
			className: "cz-hint",
			children: r("games.cozistickerville.score", { n: t.happiness + t.milestones.length + t.catalog.length })
		})
	});
	return /* @__PURE__ */ _("div", {
		className: "cz-root",
		children: [
			/* @__PURE__ */ g(ee, {
				adaptive: !0,
				scroll: !1,
				className: "cz-screen",
				banner: N,
				children: /* @__PURE__ */ _("div", {
					className: "cz-table",
					children: [
						P,
						/* @__PURE__ */ g("aside", {
							className: "cz-work",
							children: I
						}),
						/* @__PURE__ */ _("div", {
							className: "cz-dock",
							children: [ne, /* @__PURE__ */ _("nav", {
								className: "cz-tray",
								"aria-label": r("games.cozistickerville.townTabs"),
								children: [
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => h("log"),
										children: r("games.cozistickerville.openLog")
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => h("mile"),
										children: r("games.cozistickerville.openMile")
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => h("story"),
										children: r("games.cozistickerville.openStory")
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => h("catalog"),
										children: r("games.cozistickerville.openCatalog")
									})
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "buildings",
				title: r("games.cozistickerville.inPlayTitle"),
				onClose: () => h(null),
				children: /* @__PURE__ */ g("div", {
					className: "cz-catalog-grid",
					children: t.inPlay.map((e) => /* @__PURE__ */ _("article", {
						className: "cz-catalog-card",
						children: [
							/* @__PURE__ */ g("img", {
								src: X(`events/${e}.webp`),
								alt: e,
								draggable: !1
							}),
							t.keepActions.filter((t) => t.id === e).map((t) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "cz-btn cz-card-action",
								disabled: !A || !t.enabled,
								onClick: () => {
									h(null), s({
										type: "useKeep",
										id: e,
										key: t.key
									});
								},
								children: t.label[i]
							}, t.key)),
							y[e]?.keepText && /* @__PURE__ */ g("p", {
								className: "cz-card-text",
								children: a(y[e].keepText)
							})
						]
					}, e))
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "log",
				title: r("games.cozistickerville.logTitle"),
				onClose: () => h(null),
				children: t.log.length === 0 ? /* @__PURE__ */ g("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyLog")
				}) : /* @__PURE__ */ g("ul", {
					className: "cz-log",
					children: t.log.slice().reverse().map((e, t) => /* @__PURE__ */ g("li", { children: e[i] }, t))
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "catalog",
				title: r("games.cozistickerville.catalogTitle"),
				onClose: () => h(null),
				children: t.catalog.length === 0 ? /* @__PURE__ */ g("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyCatalog")
				}) : /* @__PURE__ */ g("div", {
					className: "cz-catalog-grid",
					children: t.catalog.map((e) => /* @__PURE__ */ _("div", {
						className: "cz-catalog-card",
						children: [L[e] && /* @__PURE__ */ g("img", {
							src: X(L[e].file),
							alt: e,
							draggable: !1
						}), A ? t.catalogActions.filter((t) => t.id === e).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							className: "cz-btn cz-card-action",
							disabled: !e.enabled,
							onClick: () => {
								h(null), s({
									type: "useCard",
									key: e.key
								});
							},
							children: e.label[i]
						}, e.key)) : L[e] && (L[e].actions ?? (L[e].action ? [L[e].action] : [])).map((e, t) => /* @__PURE__ */ g("p", {
							className: "cz-card-text",
							children: a(e.label)
						}, t))]
					}, e))
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "story",
				title: r("games.cozistickerville.storyTitle"),
				onClose: () => h(null),
				children: t.story.length === 0 ? /* @__PURE__ */ g("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyStory")
				}) : /* @__PURE__ */ g("div", {
					className: "cz-story-grid",
					children: t.story.map((e) => {
						let t = Math.floor(Number(e)), n = ue.find((e) => e.page === t)?.file;
						return n ? /* @__PURE__ */ _("figure", {
							className: "cz-story-card",
							children: [/* @__PURE__ */ g("img", {
								src: X(n),
								alt: e,
								draggable: !1
							}), /* @__PURE__ */ g("figcaption", { children: e })]
						}, e) : null;
					})
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "event",
				title: r("games.cozistickerville.eventTitle"),
				onClose: () => h(null),
				children: t.currentEvent && /* @__PURE__ */ g("img", {
					className: "cz-event-full",
					src: X(`events/${t.currentEvent}.webp`),
					alt: "",
					draggable: !1
				})
			}),
			/* @__PURE__ */ g(Yt, {
				open: m === "mile",
				title: r("games.cozistickerville.milestonesTitle"),
				onClose: () => h(null),
				children: t.milestones.length === 0 ? /* @__PURE__ */ g("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyMile")
				}) : /* @__PURE__ */ g("ul", {
					className: "cz-log",
					children: t.milestones.map((e) => /* @__PURE__ */ g("li", { children: e.split("|")[0] }, e))
				})
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
function Qt(e, t, n = !1) {
	let r = w[t];
	if (!r) return null;
	let i = {
		side: e.side,
		placed: e.placed
	}, a = null;
	for (let t = 0; t <= R.rows - r.rows; t++) for (let o = 0; o <= R.cols - r.cols; o++) if (Se(i, r, o, t, n).ok) {
		if (!e.placed.some((e) => {
			let n = w[e.id];
			return !!n && o < e.col + n.cols && e.col < o + r.cols && t < e.row + n.rows && e.row < t + r.rows;
		})) return {
			col: o,
			row: t
		};
		a ??= {
			col: o,
			row: t
		};
	}
	return a;
}
var $t = (e) => {
	let t = e.public;
	if (t.phase === "done") return null;
	let n = t.prompt;
	if (n) {
		if (n.kind === "pickOpt") {
			let e = t.promptOptions.find((e) => e.enabled) ?? t.promptOptions[0];
			return e ? { action: {
				type: "resolvePrompt",
				key: e.key
			} } : null;
		}
		if (n.kind === "exchange") return { action: {
			type: "resolvePrompt",
			key: t.promptOptions.find((e) => e.enabled && e.key !== "done")?.key ?? "done"
		} };
		if (n.kind === "pickRes" || n.kind === "pickCard" || n.kind === "pickPlace") {
			let e = n.pick?.[0];
			return e ? { action: {
				type: "resolvePrompt",
				key: e
			} } : null;
		}
		let e = V(n.code ?? "");
		if (!e) return null;
		let r = Qt(t, e.id, !!n.cover);
		return r ? { action: {
			type: "placePending",
			col: r.col,
			row: r.row
		} } : { action: { type: "skipPlace" } };
	}
	if (t.phase === "starting") {
		if (t.startingPairs.length >= 8) return null;
		let e = new Set(t.startingPairs), n = Ke.filter((t) => !e.has(t.id) && !qe(t.id)?.some((n) => n !== t.id && e.has(n)));
		for (let e of n) {
			let n = Qt(t, e.id);
			if (n) return { action: {
				type: "placeStarting",
				id: e.id,
				col: n.col,
				row: n.row
			} };
		}
		return null;
	}
	if (t.phase === "morning") return { action: { type: "draw" } };
	if (t.phase === "choice") {
		let e = t.choices.find((e) => e.enabled);
		return e ? { action: {
			type: "choice",
			opt: e.key
		} } : null;
	}
	if (t.phase === "afternoon") {
		if (t.action > 0) {
			let e = t.keepActions.find((e) => e.enabled);
			if (e) return { action: {
				type: "useKeep",
				id: e.id,
				key: e.key
			} };
			let n = t.catalogActions.find((e) => e.enabled);
			if (n) return { action: {
				type: "useCard",
				key: n.key
			} };
			let r = t.stickerActions.find((e) => e.enabled);
			if (r) return { action: {
				type: "useSticker",
				code: r.code
			} };
		}
		return { action: { type: "endTurn" } };
	}
	return t.phase === "yearEnd" ? { action: { type: "endYear" } } : null;
};
//#endregion
//#region src/game/game-over.tsx
function en(e) {
	let t = e.public, n = d(), r = u((e) => e.locale) === "zh" ? "zh" : "en", [i, a] = c(!1), o = t.ending ? B.find((e) => e.key === t.ending) : void 0, s = e.result.scores?.[e.myRid] ?? t.happiness + t.milestones.length + t.catalog.length;
	return /* @__PURE__ */ _("div", {
		className: `cz-root cz-over${i ? " is-reviewing" : ""}`,
		children: [/* @__PURE__ */ _("header", {
			className: "cz-over-header",
			children: [/* @__PURE__ */ g("h1", { children: n("games.cozistickerville.name") }), /* @__PURE__ */ g("span", { children: n("games.cozistickerville.year", { n: t.year }) })]
		}), /* @__PURE__ */ _("div", {
			className: "cz-over-spread",
			children: [/* @__PURE__ */ _("div", {
				className: "cz-over-map",
				children: [/* @__PURE__ */ g(Ut, {
					side: t.side,
					placed: t.placed,
					readOnly: !0
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: "cz-btn cz-primary cz-over-review",
					onClick: () => a(!i),
					children: n(i ? "games.cozistickerville.closeTown" : "games.cozistickerville.revisitTown")
				})]
			}), /* @__PURE__ */ _("div", {
				className: "cz-over-card",
				hidden: i,
				children: [
					/* @__PURE__ */ g("p", {
						className: "cz-over-kicker",
						children: n("games.cozistickerville.finalTitle")
					}),
					o && /* @__PURE__ */ _("section", {
						className: "cz-over-ending",
						children: [/* @__PURE__ */ g("h2", { children: o.title[r] }), /* @__PURE__ */ g("p", { children: o.text[r] })]
					}),
					/* @__PURE__ */ _("div", {
						className: "cz-over-score",
						children: [/* @__PURE__ */ g("span", { children: n("games.cozistickerville.scoreLabel") }), /* @__PURE__ */ g("strong", { children: s })]
					}),
					/* @__PURE__ */ _("dl", {
						className: "cz-over-breakdown",
						children: [
							/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: n("games.cozistickerville.hearts") }), /* @__PURE__ */ g("dd", { children: t.happiness })] }),
							/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: n("games.cozistickerville.openMile") }), /* @__PURE__ */ g("dd", { children: t.milestones.length })] }),
							/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: n("games.cozistickerville.openCatalog") }), /* @__PURE__ */ g("dd", { children: t.catalog.length })] })
						]
					}),
					e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ _("div", {
						className: "cz-over-btns",
						children: [e.onPlayAgain && /* @__PURE__ */ g("button", {
							type: "button",
							className: "cz-btn cz-primary",
							onClick: e.onPlayAgain,
							children: n("session.result.playAgain")
						}), e.onBackToLobby && /* @__PURE__ */ g("button", {
							type: "button",
							className: "cz-btn",
							onClick: e.onBackToLobby,
							children: n("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ g("p", {
						className: "cz-over-wait",
						children: n("session.result.waitHost")
					})
				]
			})]
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function tn({ value: e, onChange: t }) {
	let n = d(), r = F.safeParse(e), i = r.success ? r.data : F.parse({}), [a, o] = c(""), [s, l] = c(!1);
	async function u() {
		l(!0), o("");
		try {
			let e = await Ot();
			e ? (t({
				...i,
				checkpoint: e
			}), o(n("games.cozistickerville.checkpoint"))) : o(n("games.cozistickerville.emptyArchive"));
		} catch {
			o(n("games.cozistickerville.loadError"));
		} finally {
			l(!1);
		}
	}
	return /* @__PURE__ */ _("section", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("h3", {
				className: "font-bold",
				children: n("games.cozistickerville.sidePick")
			}), /* @__PURE__ */ g("div", {
				className: "mt-2 flex gap-2",
				children: ["A", "B"].map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					className: i.side === e ? "btn-base bg-sky-500 text-white" : "btn-base bg-surface",
					disabled: !!i.checkpoint,
					onClick: () => t({
						...i,
						side: e
					}),
					children: n("games.cozistickerville.side", { s: e })
				}, e))
			})] }),
			/* @__PURE__ */ g("h3", {
				className: "font-bold",
				children: n("games.cozistickerville.archive")
			}),
			/* @__PURE__ */ g("button", {
				className: "btn-base bg-surface",
				type: "button",
				disabled: s,
				onClick: () => void u(),
				children: n(s ? "games.cozistickerville.loading" : "games.cozistickerville.load")
			}),
			i.checkpoint && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", { children: n("games.cozistickerville.year", { n: i.checkpoint.year }) }), /* @__PURE__ */ g("button", {
				type: "button",
				className: "btn-quiet",
				onClick: () => {
					t({
						...i,
						checkpoint: null
					}), o("");
				},
				children: n("games.cozistickerville.newCampaign")
			})] }),
			/* @__PURE__ */ g("p", {
				role: "status",
				children: a
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var nn = {
	definition: pt,
	View: Zt,
	bot: $t,
	OverView: en,
	Options: tn,
	locales: {
		zh: {
			name: "温馨贴纸小镇",
			desc: "在双面村庄地图上贴满居民与建筑，经营十年温馨小镇。",
			rules: "目标：\n用十年时间建设温馨贴纸小镇，让居民幸福生活，并在结束时获得尽可能高的小镇评分。本作为单人游戏，没有失败条件；根据最终心情与达成的内容，你会读到五个结局之一。\n\n地图与贴纸：\n地图分为正反两面，开局时选择其中一面。两面地图都由草地、水域与岩地组成，一条河流把草地分成两岸，折痕把地图分成若干版块；完成一局后，可以在另一面地图上再玩一次。贴纸分为地形贴纸与透明贴纸：地形贴纸带有草地、水域或岩地背景，必须贴在背景相符的地形上；透明贴纸没有背景，可以叠放在任意贴纸上。放置地形贴纸时，贴纸的格子必须与地图网格对齐，全部格子都要落在相符的地形内，并且所有草地贴纸都必须位于河流的同一侧。任何地形贴纸都不能跨越折痕。地形贴纸不能覆盖其他地形贴纸，只有效果明确允许覆盖时，才能盖在其他贴纸上。\n\n开局：\n从第九页的起始贴纸中，每一对只能选择一枚，一共把八枚贴纸放到地图上。八枚起始贴纸放置完成后，按地图上的图标获得一次岁初收入，随后第一年开始。起始心情为两颗心。\n\n每年流程：\n每年使用一组十二张事件牌作为牌库，并按随机顺序排列。每天清晨，你从牌库抽取一张事件牌，然后按下列步骤进行：\n· 若事件牌印有选项，你从可支付的选项中选取一项，支付其费用并立即结算效果。\n· 若事件牌没有选项，它直接留在场上，本日照常进入午后。\n结算完成后进入午后，你可以执行一次午后行动：\n· 使用一张留场建筑牌上印有的行动。\n· 使用一张图鉴牌上印有的行动。\n· 使用一枚已放置贴纸印有的“阅读故事”行动。\n你也可以不执行行动，直接结束这一天。执行一次行动后，本日随即结束；若效果给予额外行动，你可以在同一天继续行动。若牌库还有牌，就进入下一天；若牌库已空，则进入岁末。\n\n岁初收入：\n放置完起始贴纸后，以及从第二年起每年开始时，按地图上未被遮住的图标获得资源：每个木材图标获得一份木材，每个食物图标获得一份食物，每个印有金币图标的里程碑获得一份金币。矿石不能通过这种方式获得。被地形贴纸遮住的贴纸不再提供图标与行动。\n\n资源、心情与不满：\n木材、食物、金币与矿石的数量受供应限制：木材、食物与金币最多各十二个，矿石最多六个。心情沿地图上的心情轨道记录，最多三十颗心。部分效果会增加或移除不满标记；不满本身没有固定规则，只在明确引用它的效果中起作用。\n\n岁初设置：\n第一年开始前，按故事书的岁初设置执行。从第二年开始，每年开始先结算当年的岁初设置，再抽取当年第一张事件牌：\n· 第二年：获得图鉴牌 42。\n· 第三年：若你拥有“Hunger”里程碑，失去 1 颗心；否则获得 1 金币。\n· 第四年：若你已放置起始贴纸 9L，则把 7N 覆盖在指定位置，并失去 2 份食物；否则获得 1 份食物。\n· 第五年：放置贴纸 5C；若无法放置，则改为放置贴纸 5D。\n· 第六年：若你拥有“Lodge”里程碑，放置贴纸 4T；否则获得图鉴牌 22。\n· 第七年：若你拥有“Degenerate”或“Upstanding”里程碑，获得 1 份矿石；否则阅读故事 18.3。\n· 第八年：若你拥有“Lucky”里程碑，可以免费放置花朵贴纸 11A，或花费 1 金币放置道路贴纸 3E；否则把贴纸 10E 放在悬崖边。\n· 第九年：若你已放置贴纸 8H，获得 2 金币；否则放置贴纸 7E，并把事件牌 Y6-12 移出本局。\n· 第十年：没有额外的岁初设置。\n\n岁末与终局：\n每年结束时，先依次结算留场建筑与图鉴牌上标注的岁末效果，再进入下一年。第十年结束后计算小镇评分：评分为心情、里程碑数量与图鉴牌数量之和，并根据心情落在哪一档给出对应结局。\n\n保存：\n使用“保存小镇”把进度写入本机档案；只有界面显示已保存，才代表写入成功。开局选项可以载入已有档案；若档案被其他页面更新，请重新载入最新档案。\n\n改编说明：\n本电子版把原版的纸质贴纸与故事书改编为可交互的地图、卡牌与故事弹层。以下细节采用固定分支或近似处理：\n· 卡面自身贴纸数量无法逐枚记录：卡 5、29、30、44、51 以及观星、观鸟相关行动，统一按该卡零枚贴纸的条目结算。\n· 竞选州长（故事 9.3、27.1）固定为花费 3 金币并掷骰，掷出 4 至 6 即成功。\n· 烘焙比赛（故事 26.6）按选定的食物数量结算掷骰与奖励，但不限制卡 28 能否带来额外行动。\n· 岁初设置中的指定位置以任意合法位置近似：第四年的 7N 与第八年的 10E 可以放在任何合法位置，第八年的悬崖相邻关系不单独判定。\n· 居民数量按地图上未被遮住、占据至少四格的不透明贴纸近似；需要统计居民的效果据此计算。\n· 卡 36 的现实时钟，以及卡 22、31、45、50 的谜题答案，改为阅读对应的提示故事条目。\n起始贴纸按贴纸编号顺序两两成对，具体结果以牌面与故事条目的文字为准。",
			invalid: "这个操作当前不可执行。",
			errOob: "超出地图边界。",
			errBg: "贴纸背景与地形不符。",
			errOverlap: "这里已经有贴纸了。",
			errRiver: "草地贴纸必须放在同一条河岸。",
			errPair: "这一对起始贴纸只能选择其中一个。",
			errFold: "贴纸不能压在折痕上。",
			sidePick: "选择地图",
			actionLeft: "剩余行动 {{n}}",
			upset: "不满",
			pickResHint: "选择一种资源。",
			pickCardHint: "选择一张图鉴牌。",
			pickPlaceHint: "选择要放置的贴纸。",
			exchangeHint: "可兑换 {{n}} 份资源；兑换矿石时，每 1 枚矿石需要 2 份资源。",
			phStarting: "起始布置",
			phMorning: "清晨",
			phChoice: "抉择",
			phAfternoon: "午后",
			phPlacing: "放置",
			phYearEnd: "岁末",
			phDone: "落幕",
			draw: "抽取事件",
			endTurn: "结束这一天",
			endYear: "进入下一年",
			choose: "选择结果",
			year: "第 {{n}} 年",
			hearts: "心情",
			resources: "资源",
			placedCount: "已放置 {{n}}",
			deckCount: "牌库 {{n}}",
			startHint: "选择一组起始贴纸，放到相符的地形上。已完成 {{done}} / {{total}}。",
			startEmpty: "请从下方选择一张起始贴纸。",
			pendingHint: "在地图上放置贴纸 {{code}}，剩余 {{n}} 张。",
			skipPlace: "跳过此贴纸",
			confirmPlace: "确认贴上",
			cancelPlace: "取消放置",
			placeRemaining: "待放置 {{code}} ×{{n}}",
			morningHint: "清晨：从牌库抽取一张事件牌。",
			afternoonHint: "午后：使用卡牌或贴纸上的行动，或直接结束这一天。",
			yearEndHint: "本年结束，确认后进入下一年。",
			eventTitle: "事件",
			noEvent: "尚未抽取事件",
			logTitle: "小镇记事",
			inPlayTitle: "留场建筑",
			catalogTitle: "图鉴",
			storyTitle: "故事",
			milestonesTitle: "里程碑",
			save: "保存小镇",
			saving: "正在保存…",
			saved: "已保存",
			saveError: "保存失败，请重试。",
			saveNewer: "档案已被另一页面更新，请载入最新档案。",
			load: "载入小镇档案",
			loading: "正在读取档案…",
			loadError: "读取失败，请重试。",
			emptyArchive: "尚无小镇档案。",
			newCampaign: "开始新小镇",
			archive: "小镇档案",
			checkpoint: "已选中小镇档案，开局后从保存位置继续。",
			confirmNew: "保存将替换现有小镇档案，是否继续？",
			cancel: "取消",
			confirm: "确认",
			close: "关闭",
			resume: "继续档案",
			zoomIn: "放大",
			zoomOut: "缩小",
			zoomReset: "全图",
			pairOr: "或",
			pairHint: "每对贴纸选择一枚。",
			setupCount: "已放置 {{done}} / {{total}}",
			pickPosition: "在地图上选择一个标出的落点。",
			adjustSticker: "可拖动贴纸调整落点。",
			townTabs: "小镇资料",
			revisitTown: "回看小镇",
			closeTown: "返回结局",
			scoreLabel: "小镇评分",
			mapHint: "拖动平移地图，使用按钮缩放。",
			wood: "木材",
			food: "食物",
			gold: "金币",
			ore: "矿石",
			side: "地图 {{s}} 面",
			finalTitle: "小镇故事落幕",
			score: "小镇评分 {{n}}",
			again: "重新开始",
			back: "返回大厅",
			openLog: "记事",
			openCatalog: "图鉴",
			openStory: "故事",
			openMile: "里程碑",
			emptyLog: "还没有记下任何事。",
			emptyCatalog: "还未获得图鉴牌。",
			emptyStory: "还未阅读故事。",
			emptyMile: "还未达成里程碑。",
			useCard: "使用",
			startCount: "{{n}} 张",
			turnLabel: "行动",
			place: "放置"
		},
		en: {
			name: "Cozy Stickerville",
			desc: "Fill a double-sided village map with residents and buildings across ten cozy years.",
			rules: "Goal:\nBuild the cozy town of Stickerville over ten years, keep its residents happy, and finish with the highest town score you can. This is a solo game with no way to lose; your final hearts and achievements lead you to one of five endings.\n\nMap and stickers:\nThe map has two sides, and you choose one at setup. Both sides are made of grass, water, and rock; a river splits the grass into two banks, and folds divide the map into panels. After finishing a game you may play again on the other side. Stickers come in terrain stickers and clear stickers: a terrain sticker carries a grass, water, or rock background and must be placed on matching terrain, while a clear sticker has no background and may be stacked on any sticker. When you place a terrain sticker, its cells must line up with the map grid, every cell must fall on matching terrain, and all grass stickers must stay on one bank of the river. No terrain sticker may straddle a fold. A terrain sticker may not cover another terrain sticker, and it may cover another sticker only when an effect explicitly allows it.\n\nSetup:\nFrom the page-nine starting stickers, you choose exactly one of each pair and place eight stickers on the map. Once all eight are placed, you gain one year-setup income from the icons on the map, and year 1 begins. You start with two hearts.\n\nYearly flow:\nEach year uses twelve event cards, shuffled into its deck. Every morning you draw one event card, then follow these steps:\n· If the card prints options, choose one you can afford, pay its cost, and resolve its effect immediately.\n· If the card has no options, it simply stays in play and the day proceeds to the afternoon.\nAfter resolution the afternoon begins, and you may take one afternoon action:\n· use an action printed on a kept building card;\n· use an action printed on a catalog card;\n· use a “read story” action printed on a placed sticker.\nYou may also end the day without taking an action. Your day ends after one action; if an effect grants an extra action, you may keep acting that day. If the deck still has cards, the next day begins; otherwise the year ends.\n\nYear-setup income:\nAfter the starting stickers are placed, and at the start of every year from year 2 onward, you gain resources from the uncovered icons on the map: one wood for each wood icon, one food for each food icon, and one gold for each milestone that prints a gold icon. Ore is never gained this way. Stickers hidden under a terrain sticker no longer provide icons or actions.\n\nResources, hearts, and upset:\nWood, food, gold, and ore are limited by the supply: wood, food, and gold cap at twelve each, and ore caps at six. Hearts are tracked on the map’s happiness track, up to thirty. Some effects add or remove upset stickers; upset has no fixed rule of its own and matters only in effects that explicitly refer to it.\n\nYear setup:\nBefore year 1 begins, follow the storybook’s year setup. From year 2 onward, resolve the year’s setup before drawing that year’s first event card:\n· Year 2: gain catalog card 42.\n· Year 3: if you have the Hunger milestone, lose 1 heart; otherwise gain 1 gold.\n· Year 4: if the starting sticker 9L is on the map, cover the indicated spot with 7N and lose 2 food; otherwise gain 1 food.\n· Year 5: place sticker 5C; if it cannot be placed, place sticker 5D instead.\n· Year 6: if you have a Lodge milestone, place sticker 4T; otherwise gain catalog card 22.\n· Year 7: if you have the Degenerate or Upstanding milestone, gain 1 ore; otherwise read story 18.3.\n· Year 8: if you have the Lucky milestone, either place the flower sticker 11A for free or spend 1 gold to place the road sticker 3E; otherwise place sticker 10E by the cliff.\n· Year 9: if sticker 8H is on the map, gain 2 gold; otherwise place sticker 7E and remove event card Y6-12 from this game.\n· Year 10: there is no further setup.\n\nYear end and finale:\nAt each year end, resolve the year-end effects printed on kept buildings and catalog cards in turn, then begin the next year. After year 10 you tally the town score: hearts plus the number of milestones plus the number of catalog cards, and your hearts decide which of the five endings you read.\n\nSaving:\nUse “Save town” to write your progress to this device’s archive; it is only saved once the interface says so. The setup options can load an existing archive; if another page updates the archive, load the newest one again.\n\nAdaptation note:\nThis digital edition turns the physical stickers and storybook into an interactive map, cards, and story sheets. The following details use fixed branches or approximations:\n· The number of stickers on a card cannot be tracked individually, so cards 5, 29, 30, 44, and 51 and the stargazing and birdwatching actions always resolve the entry for zero stickers on that card.\n· Running for governor (stories 9.3 and 27.1) is always a 3-gold roll that succeeds on 4 to 6.\n· The baking competition (story 26.6) resolves the roll and reward for the chosen amount of food but does not prevent card 28 from granting an extra action.\n· The indicated spots in year setup are approximated by any legal placement: 7N in year 4 and 10E in year 8 may go anywhere legal, and year 8 does not check cliff-side adjacency.\n· The number of residents is approximated by uncovered opaque stickers covering at least four cells, and effects that count residents use that number.\n· The real-world clock on card 36 and the puzzle answers on cards 22, 31, 45, and 50 are replaced by reading the corresponding hint story entries.\nStarting stickers pair up in sticker-number order, and the printed text on cards and story entries remains the reference for each result.",
			invalid: "That action is not available right now.",
			errOob: "That placement is outside the map.",
			errBg: "This sticker’s background does not match the terrain.",
			errOverlap: "A sticker already covers that spot.",
			errRiver: "Grass stickers must stay on the same river bank.",
			errPair: "You may pick only one sticker from each starting pair.",
			errFold: "Stickers cannot straddle a map fold.",
			sidePick: "Choose a map",
			actionLeft: "Actions left {{n}}",
			upset: "Upset",
			pickResHint: "Choose a resource.",
			pickCardHint: "Choose a catalog card.",
			pickPlaceHint: "Choose a sticker to place.",
			exchangeHint: "Exchange up to {{n}} resources; each ore costs 2 resources.",
			phStarting: "Setup",
			phMorning: "Morning",
			phChoice: "Choice",
			phAfternoon: "Afternoon",
			phPlacing: "Placing",
			phYearEnd: "Year end",
			phDone: "Finale",
			draw: "Draw event",
			endTurn: "End the day",
			endYear: "Begin next year",
			choose: "Choose an option",
			year: "Year {{n}}",
			hearts: "Hearts",
			resources: "Resources",
			placedCount: "Placed {{n}}",
			deckCount: "Deck {{n}}",
			startHint: "Pick one sticker from each pair and place it on matching terrain. Done {{done}} / {{total}}.",
			startEmpty: "Pick a starting sticker below.",
			pendingHint: "Place sticker {{code}} on the map; {{n}} remaining.",
			skipPlace: "Skip this sticker",
			confirmPlace: "Confirm placement",
			cancelPlace: "Cancel placement",
			placeRemaining: "To place {{code}} ×{{n}}",
			morningHint: "Morning: draw an event card from the deck.",
			afternoonHint: "Afternoon: use an action from a card or placed sticker, or end the day.",
			yearEndHint: "The year is over. Confirm to begin the next year.",
			eventTitle: "Event",
			noEvent: "No event drawn yet",
			logTitle: "Town chronicle",
			inPlayTitle: "Kept buildings",
			catalogTitle: "Catalog",
			storyTitle: "Story",
			milestonesTitle: "Milestones",
			save: "Save town",
			saving: "Saving…",
			saved: "Saved",
			saveError: "Save failed. Please try again.",
			saveNewer: "The archive was updated in another tab. Load the newest archive.",
			load: "Load town archive",
			loading: "Reading archive…",
			loadError: "Could not read the archive. Please try again.",
			emptyArchive: "No town archive yet.",
			newCampaign: "Start a new town",
			archive: "Town archive",
			checkpoint: "A town archive is selected; the game resumes from the saved position.",
			confirmNew: "Saving will replace the existing town archive. Continue?",
			cancel: "Cancel",
			confirm: "Confirm",
			close: "Close",
			resume: "Resume archive",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			zoomReset: "Full map",
			pairOr: "or",
			pairHint: "Choose one sticker from each pair.",
			setupCount: "Placed {{done}} / {{total}}",
			pickPosition: "Choose a marked spot on the map.",
			adjustSticker: "Drag the sticker to adjust its position.",
			townTabs: "Town records",
			revisitTown: "Explore the town",
			closeTown: "Return to ending",
			scoreLabel: "Town score",
			mapHint: "Drag to pan the map; use the buttons to zoom.",
			wood: "Wood",
			food: "Food",
			gold: "Gold",
			ore: "Ore",
			side: "Map side {{s}}",
			finalTitle: "The town story concludes",
			score: "Town score {{n}}",
			again: "Play again",
			back: "Back to lobby",
			openLog: "Log",
			openCatalog: "Catalog",
			openStory: "Story",
			openMile: "Milestones",
			emptyLog: "Nothing recorded yet.",
			emptyCatalog: "No catalog cards yet.",
			emptyStory: "No stories read yet.",
			emptyMile: "No milestones reached yet.",
			useCard: "Use",
			startCount: "{{n}}",
			turnLabel: "Action",
			place: "Place"
		}
	}
};
//#endregion
export { nn as default };
