import { z as e } from "zod";
import { createContext as t, createElement as n, forwardRef as r, useContext as i, useId as a, useLayoutEffect as o, useMemo as s, useRef as c, useState as l } from "react";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { readGameStorage as te, writeGameStorage as ne } from "@bgparty/sdk/storage";
import { gameAssetUrl as f } from "@bgparty/sdk/assets";
import { usePrefersReducedMotion as p } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
//#region src/game/data/events.ts
var re = [
	{
		id: "y1-01",
		year: 1,
		num: 1,
		file: "events/y1-01.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y1-02",
		year: 1,
		num: 2,
		file: "events/y1-02.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { res: { wood: 1 } } },
			c: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y1-03",
		year: 1,
		num: 3,
		file: "events/y1-03.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: {
				place: "11A",
				n: 2
			} }
		}
	},
	{
		id: "y1-04",
		year: 1,
		num: 4,
		file: "events/y1-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "1H" } },
			b: { do: { place: "5N" } }
		}
	},
	{
		id: "y1-05",
		year: 1,
		num: 5,
		file: "events/y1-05.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "6C" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y1-06",
		year: 1,
		num: 6,
		file: "events/y1-06.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "5M" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y1-07",
		year: 1,
		num: 7,
		file: "events/y1-07.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { place: "12D" } },
			c: { do: { res: { gold: 1 } } }
		}
	},
	{
		id: "y1-08",
		year: 1,
		num: 8,
		file: "events/y1-08.webp",
		kind: "keep",
		keepActions: [{
			key: "sell1",
			label: {
				zh: "卖出 1 食物换 1 金币",
				en: "Sell 1 food for 1 gold"
			},
			do: { res: { gold: 1 } },
			cost: { food: 1 },
			repeat: !0
		}, {
			key: "sell2",
			label: {
				zh: "卖出 2 食物换 2 金币",
				en: "Sell 2 food for 2 gold"
			},
			do: { res: { gold: 2 } },
			cost: { food: 2 },
			repeat: !0
		}],
		keepText: {
			zh: "卖出食物：最多花费 2 食物，每 1 食物换 1 金币（用后不弃）。 岁末：弃掉此牌并阅读故事 34.1。",
			en: "Sell Food: spend up to 2 food for 1 gold each (card stays). End of year: discard and read 34.1."
		},
		endOfYear: {
			discard: !0,
			auto: { story: "34.1" }
		}
	},
	{
		id: "y1-09",
		year: 1,
		num: 9,
		file: "events/y1-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "法默·迪尔：获得图鉴牌 1",
				en: "Farmer Dill: gain card 1"
			},
			do: { card: "1" },
			discard: !0,
			cost: { wood: 3 }
		}, {
			key: "b",
			label: {
				zh: "萨利扎一家：获得图鉴牌 2",
				en: "The Salizars: gain card 2"
			},
			do: { card: "2" },
			discard: !0,
			cost: { wood: 3 }
		}],
		keepText: {
			zh: "建造房屋（3 木材）：弃掉本牌，选择农夫迪尔（获得图鉴牌 1）或萨利扎一家（获得图鉴牌 2）。",
			en: "Build House (3 wood): discard; pick Farmer Dill (card 1) or the Salizars (card 2)."
		}
	},
	{
		id: "y1-10",
		year: 1,
		num: 10,
		file: "events/y1-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "扎克·约翰逊：放置贴纸 6A",
				en: "Zach Johnson: place 6A"
			},
			do: { place: "6A" },
			discard: !0,
			cost: { wood: 4 }
		}, {
			key: "b",
			label: {
				zh: "锯木兄妹：放置贴纸 6R",
				en: "The Saw Siblings: place 6R"
			},
			do: { place: "6R" },
			discard: !0,
			cost: { wood: 4 }
		}],
		keepText: {
			zh: "建造房屋（4 木材）：弃掉本牌，选择扎克·约翰逊（放置贴纸 6A）或锯木兄妹（放置贴纸 6R）。",
			en: "Build House (4 wood): discard; pick Zach Johnson (place 6A) or the Saw Siblings (place 6R)."
		}
	},
	{
		id: "y1-11",
		year: 1,
		num: 11,
		file: "events/y1-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造市政厅（5 木材）：获得图鉴牌 7",
				en: "Build Town Hall (5 wood): gain card 7"
			},
			do: { card: "7" },
			discard: !0,
			if: { minResidents: 3 },
			cost: { wood: 5 }
		}, {
			key: "b",
			label: {
				zh: "建造农场（4 木材、1 金币）：获得图鉴牌 8",
				en: "Build Farm (4 wood, 1 gold): gain card 8"
			},
			do: { card: "8" },
			discard: !0,
			cost: {
				wood: 4,
				gold: 1
			}
		}],
		keepText: {
			zh: "建造市政厅（5 木材，需 3+ 居民，弃牌获得图鉴牌 7）或建造农场（4 木材、1 金币，弃牌获得图鉴牌 8）。",
			en: "Build Town Hall (5 wood, 3+ residents, discard, gain card 7) or Farm (4 wood, 1 gold, discard, gain card 8)."
		}
	},
	{
		id: "y1-12",
		year: 1,
		num: 12,
		file: "events/y1-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "养蜂人：获得图鉴牌 11",
				en: "Bee Lover: gain card 11"
			},
			do: { card: "11" },
			discard: !0,
			if: { countCode: {
				code: "11A",
				min: 4
			} }
		}, {
			key: "b",
			label: {
				zh: "守财奴：地图上 2+ 斧头图标时获得图鉴牌 10",
				en: "Money Lover: with 2+ axe icons, gain card 10"
			},
			do: { card: "10" },
			discard: !0,
			if: { minMapIcons: { axe: 2 } }
		}],
		keepText: {
			zh: "新来者的抱负：蜜蜂爱好者（4+ 花朵贴纸则弃牌获得图鉴牌 11）或守财奴（地图上 2+ 斧头图标则弃牌获得图鉴牌 10）。",
			en: "Newcomer Ambition: Bee Lover (4+ flowers -> card 11) or Money Lover (2+ axe icons -> card 10)."
		}
	},
	{
		id: "y2-01",
		year: 2,
		num: 1,
		file: "events/y2-01.webp",
		kind: "choice",
		opts: {
			a: { do: {
				res: { wood: 3 },
				place: "6H",
				cover: !0,
				must: { trees: 2 }
			} },
			b: { do: { place: "11K" } }
		}
	},
	{
		id: "y2-02",
		year: 2,
		num: 2,
		file: "events/y2-02.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 2 } } },
			b: { do: { res: { gold: 1 } } }
		}
	},
	{
		id: "y2-03",
		year: 2,
		num: 3,
		file: "events/y2-03.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y2-04",
		year: 2,
		num: 4,
		file: "events/y2-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "1H" } },
			b: { do: { place: "5N" } }
		}
	},
	{
		id: "y2-05",
		year: 2,
		num: 5,
		file: "events/y2-05.webp",
		kind: "choice",
		opts: {
			a: { do: {
				res: { gold: 3 },
				milestone: "Loan|red"
			} },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y2-06",
		year: 2,
		num: 6,
		file: "events/y2-06.webp",
		kind: "choice",
		opts: { a: { do: { dice: [{
			on: [
				1,
				2,
				3,
				4
			],
			do: { place: "3D" },
			rerollIf: {
				milestone: "Lucky",
				on: [
					1,
					2,
					3,
					4
				]
			}
		}, {
			on: [5, 6],
			do: { res: { gold: 1 } }
		}] } } }
	},
	{
		id: "y2-07",
		year: 2,
		num: 7,
		file: "events/y2-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{ res: { gold: -1 } }, { removeSticker: "5M" }] },
				if: { hasSticker: "5M" },
				label: {
					zh: "已有 Wild Bill 居民：赶走他",
					en: "Wild Bill resident: kick him out"
				}
			},
			b: {
				do: { res: { gold: -1 } },
				if: { hasSticker: "5M" },
				label: {
					zh: "已有 Wild Bill 居民：让他留下",
					en: "Wild Bill resident: let him stay"
				}
			},
			c: {
				do: { place: "5M" },
				if: { notSticker: "5M" },
				label: {
					zh: "没有 Wild Bill 居民：可安置 Wild Bill",
					en: "No Wild Bill resident: may place Wild Bill"
				}
			}
		}
	},
	{
		id: "y2-08",
		year: 2,
		num: 8,
		file: "events/y2-08.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "举办盛宴",
				en: "Throw a feast"
			},
			do: { hap: 1 },
			cost: { food: 4 },
			discard: !0
		}],
		endOfYear: {
			choice: [{
				do: { none: !0 },
				cost: { food: 4 }
			}, { do: { milestone: "Hunger|red" } }],
			discard: !0
		}
	},
	{
		id: "y2-09",
		year: 2,
		num: 9,
		file: "events/y2-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造房屋：Dawes 一家",
				en: "Build house: the Dawes family"
			},
			do: { place: "7A" },
			cost: { wood: 4 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造房屋：Ferguson 教授",
				en: "Build house: Professor Ferguson"
			},
			do: { place: "5H" },
			cost: { wood: 4 },
			discard: !0
		}]
	},
	{
		id: "y2-10",
		year: 2,
		num: 10,
		file: "events/y2-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造市场",
				en: "Build market"
			},
			do: { card: "9" },
			cost: { wood: 3 },
			discard: !0
		}]
	},
	{
		id: "y2-11",
		year: 2,
		num: 11,
		file: "events/y2-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "雇用表演团",
				en: "Hire the performers"
			},
			do: { hap: 1 },
			cost: { gold: 1 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { hap: 1 },
				cost: { gold: 2 }
			},
			discard: !0
		}
	},
	{
		id: "y2-12",
		year: 2,
		num: 12,
		file: "events/y2-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "打零工",
				en: "Work an odd job"
			},
			do: { story: "10.2" },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造游乐场",
				en: "Build playground"
			},
			do: {
				hap: 1,
				place: "6Q"
			},
			cost: { wood: 4 },
			discard: !0
		}]
	},
	{
		id: "y3-01",
		year: 3,
		num: 1,
		file: "events/y3-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y3-02",
		year: 3,
		num: 2,
		file: "events/y3-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 2
			} }
		}
	},
	{
		id: "y3-03",
		year: 3,
		num: 3,
		file: "events/y3-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { place: "5N" },
				cost: { food: 2 }
			},
			b: { do: { res: { food: 1 } } }
		}
	},
	{
		id: "y3-04",
		year: 3,
		num: 4,
		file: "events/y3-04.webp",
		kind: "choice",
		opts: {
			a: { do: { dice: [{
				on: [1],
				do: { hap: -1 }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { res: { food: 1 } }
			}] } },
			b: { do: { seq: [{ res: { gold: 1 } }, { dice: [{
				on: [1],
				do: { upset: 1 }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { none: !0 }
			}] }] } },
			c: { do: { none: !0 } }
		}
	},
	{
		id: "y3-05",
		year: 3,
		num: 5,
		file: "events/y3-05.webp",
		kind: "choice",
		opts: { a: { do: { extraAction: 1 } } }
	},
	{
		id: "y3-06",
		year: 3,
		num: 6,
		file: "events/y3-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "1G",
					cover: !0,
					must: {
						berryBush: !0,
						food: 1
					},
					softMust: !0
				},
				if: { anyMilestone: ["Farming 2", "Farming 3"] },
				label: {
					zh: "已有农业 2/3 里程碑：放置 1G，尽可能覆盖浆果灌木和食物图标",
					en: "Farming 2/3 milestone: place 1G covering a berry bush and food icon, if able"
				}
			},
			b: {
				do: { place: "1H" },
				cost: { gold: 1 },
				if: { notAnyMilestone: ["Farming 2", "Farming 3"] },
				label: {
					zh: "无上述里程碑：可花 1 金币放置 1H",
					en: "No such milestone: may spend 1 gold to place 1H"
				}
			}
		}
	},
	{
		id: "y3-07",
		year: 3,
		num: 7,
		file: "events/y3-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { wood: 2 } },
				cost: { gold: 1 },
				if: { minRes: { gold: 1 } },
				label: {
					zh: "有 1+ 金币：可花 1 金币换 2 木材",
					en: "1+ gold: may spend 1 gold for 2 wood"
				}
			},
			b: {
				do: { res: { gold: 1 } },
				cost: { food: 1 },
				if: { maxRes: { gold: 0 } },
				label: {
					zh: "没有金币：可花 1 食物换 1 金币",
					en: "No gold: may spend 1 food for 1 gold"
				}
			}
		}
	},
	{
		id: "y3-08",
		year: 3,
		num: 8,
		file: "events/y3-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					res: { gold: 3 },
					milestone: "Loan|red"
				},
				if: { notMilestone: "Loan" },
				label: {
					zh: "没有 Loan 里程碑：可获得 3 金币与 Loan 里程碑",
					en: "No Loan milestone: may gain 3 gold and Loan"
				}
			},
			b: {
				do: { branch: "y3-08b" },
				if: { milestone: "Loan" },
				label: {
					zh: "已有 Loan 里程碑：失去 1 金币",
					en: "Loan milestone: lose 1 gold"
				}
			}
		}
	},
	{
		id: "y3-09",
		year: 3,
		num: 9,
		file: "events/y3-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "修缮房屋",
				en: "Repair homes"
			},
			do: { hap: 1 },
			cost: { wood: 3 },
			discard: !0
		}],
		endOfYear: {
			choice: [{
				do: { none: !0 },
				cost: { wood: 4 }
			}, { do: { milestone: "Termites|red" } }],
			discard: !0
		}
	},
	{
		id: "y3-10",
		year: 3,
		num: 10,
		file: "events/y3-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造桥梁",
				en: "Build bridge"
			},
			do: { place: "12A" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y3-11",
		year: 3,
		num: 11,
		file: "events/y3-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造宠物店",
				en: "Build pet shop"
			},
			do: { card: "19" },
			cost: {
				wood: 4,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造面包房",
				en: "Build bakery"
			},
			do: { card: "20" },
			cost: {
				wood: 3,
				food: 2
			},
			discard: !0
		}]
	},
	{
		id: "y3-12",
		year: 3,
		num: 12,
		file: "events/y3-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造学校",
				en: "Build school"
			},
			do: { card: "21" },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造消防站",
				en: "Build fire station"
			},
			do: { place: "4C" },
			cost: { wood: 5 },
			discard: !0
		}]
	},
	{
		id: "y4-01",
		year: 4,
		num: 1,
		file: "events/y4-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y4-02",
		year: 4,
		num: 2,
		file: "events/y4-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "11A",
				n: 2
			} },
			b: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y4-03",
		year: 4,
		num: 3,
		file: "events/y4-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 1 } } },
			b: { do: {
				place: "12R",
				n: 2
			} }
		}
	},
	{
		id: "y4-04",
		year: 4,
		num: 4,
		file: "events/y4-04.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "5A" } },
			b: { do: { none: !0 } }
		}
	},
	{
		id: "y4-05",
		year: 4,
		num: 5,
		file: "events/y4-05.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 1 } } },
			b: {
				do: { branch: "y4-05b" },
				label: {
					zh: "移除 1 枚不满贴纸；若没有则获得 1 心情",
					en: "Remove 1 upset; if none, gain 1 happiness"
				}
			}
		}
	},
	{
		id: "y4-06",
		year: 4,
		num: 6,
		file: "events/y4-06.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: { do: { place: "12B" } }
		}
	},
	{
		id: "y4-07",
		year: 4,
		num: 7,
		file: "events/y4-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{ res: { food: -1 } }, { ask: "y4-07a" }] },
				if: { hasSticker: "5M" },
				label: {
					zh: "若有 Wild Bill 居民：失去 1 食物，再选择赶走或留下",
					en: "If you have the Wild Bill resident: lose 1 food, then kick him out or let him stay"
				}
			},
			b: {
				do: { ask: "y4-07b" },
				if: { notSticker: "5M" },
				label: {
					zh: "若无 Wild Bill 居民：付 2 食物或放 1 个不快贴纸",
					en: "Otherwise: spend 2 food or place 1 upset sticker"
				}
			}
		}
	},
	{
		id: "y4-08",
		year: 4,
		num: 8,
		file: "events/y4-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{ place: "12P" }, {
					place: "5Q",
					cover: !0
				}] },
				if: { minMapRes: { wood: 6 } },
				label: {
					zh: "若地图上有 6 个或更多木材图标：放 2 张贴纸",
					en: "If 6+ wood icons on the map: place 2 stickers"
				}
			},
			b: {
				do: { place: "8X" },
				if: { maxMapRes: { wood: 5 } },
				label: {
					zh: "否则：放 1 张树木贴纸",
					en: "Otherwise: place 1 tree sticker"
				}
			}
		}
	},
	{
		id: "y4-09",
		year: 4,
		num: 9,
		file: "events/y4-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y4-09a" },
				if: { milestone: "Termites" },
				label: {
					zh: "若有 Termites 里程碑：失去 1 幸福或花 3 木材移除它",
					en: "If you have the Termites milestone: lose 1 happiness or spend 3 wood to remove it"
				}
			},
			b: {
				do: { ask: "y4-09b" },
				if: { notMilestone: "Termites" },
				label: {
					zh: "若无 Termites 里程碑：获得 1 金币或移除 1 个不快贴纸",
					en: "Otherwise: gain 1 gold or remove 1 upset sticker"
				}
			}
		}
	},
	{
		id: "y4-10",
		year: 4,
		num: 10,
		file: "events/y4-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "烹饪盛宴",
				en: "Cook feast"
			},
			do: { hap: 1 },
			cost: {
				food: 3,
				gold: 1
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { food: 4 },
				do: { none: !0 }
			}, { do: { hap: -1 } }],
			discard: !0
		}
	},
	{
		id: "y4-11",
		year: 4,
		num: 11,
		file: "events/y4-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造餐馆",
				en: "Build restaurant"
			},
			do: { place: "4M" },
			cost: {
				wood: 3,
				food: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造图书馆",
				en: "Build library"
			},
			do: { card: "34" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y4-12",
		year: 4,
		num: 12,
		file: "events/y4-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鱼店",
				en: "Build fishing shop"
			},
			do: { card: "32" },
			cost: { wood: 4 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造大宅",
				en: "Build large home"
			},
			do: { place: "4H" },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}]
	},
	{
		id: "y5-01",
		year: 5,
		num: 1,
		file: "events/y5-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y5-02",
		year: 5,
		num: 2,
		file: "events/y5-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "12R",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 2
			} }
		}
	},
	{
		id: "y5-03",
		year: 5,
		num: 3,
		file: "events/y5-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { wood: 1 } } },
			b: { do: { dice: [
				{
					on: [1],
					do: { hap: -1 }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { food: 1 } }
				},
				{
					on: [5],
					do: { res: { food: 2 } }
				},
				{
					on: [6],
					do: { res: { food: 3 } }
				}
			] } }
		}
	},
	{
		id: "y5-04",
		year: 5,
		num: 4,
		file: "events/y5-04.webp",
		kind: "choice",
		opts: { a: {
			do: { extraAction: 1 },
			cost: { food: 2 }
		} }
	},
	{
		id: "y5-05",
		year: 5,
		num: 5,
		file: "events/y5-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				cost: { gold: 2 }
			},
			b: {
				do: { progress: 1 },
				label: {
					zh: "翻开故事书并放置 1 枚进度贴纸",
					en: "Open the storybook and place 1 progress sticker"
				}
			}
		}
	},
	{
		id: "y5-06",
		year: 5,
		num: 6,
		file: "events/y5-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { place: "12K" },
				if: { hasSticker: "6A" },
				label: {
					zh: "若有 Zach Johnson 居民：在动物上放帽子贴纸",
					en: "If you have the Zach Johnson resident: place a hat sticker on an animal"
				}
			},
			b: {
				do: { milestone: "Investment|bronze" },
				cost: { gold: 2 },
				if: { notSticker: "6A" },
				label: {
					zh: "若无 Zach Johnson 居民：可花 2 金币获得 Investment 里程碑（铜）",
					en: "Otherwise: may spend 2 gold for the Investment milestone (bronze)"
				}
			}
		}
	},
	{
		id: "y5-07",
		year: 5,
		num: 7,
		file: "events/y5-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				if: { hasSticker: "4C" },
				label: {
					zh: "若有 Fire Station：获得 1 幸福",
					en: "If you have the Fire Station: gain 1 happiness"
				}
			},
			b: {
				do: { dice: [{
					on: [
						1,
						2,
						3,
						4
					],
					do: {
						hap: -1,
						place: "4F",
						cover: !0
					}
				}, {
					on: [5, 6],
					do: { none: !0 }
				}] },
				if: { notSticker: "4C" },
				label: {
					zh: "若无 Fire Station：掷骰，1-4 失去 1 幸福并覆盖房屋",
					en: "Otherwise: roll; on 1-4 lose 1 happiness and cover your house"
				}
			}
		}
	},
	{
		id: "y5-08",
		year: 5,
		num: 8,
		file: "events/y5-08.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "自豪村庄",
				en: "Proud village"
			},
			do: { seq: [{ hap: 1 }, { story: "24.8" }] },
			cost: { gold: 2 },
			discard: !0,
			if: { minHearts: 10 }
		}, {
			key: "b",
			label: {
				zh: "繁忙村庄",
				en: "Busy village"
			},
			do: { seq: [{ hap: 1 }, { place: "5K" }] },
			cost: { gold: 2 },
			discard: !0,
			if: { countCode: {
				code: "3E",
				min: 12
			} }
		}]
	},
	{
		id: "y5-09",
		year: 5,
		num: 9,
		file: "events/y5-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "提供补给",
				en: "Give supplies"
			},
			do: { hap: 1 },
			cost: {
				wood: 1,
				food: 3
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { food: 4 },
				do: { none: !0 }
			}, { do: { milestone: "Hard Winter|red" } }],
			discard: !0
		}
	},
	{
		id: "y5-10",
		year: 5,
		num: 10,
		file: "events/y5-10.webp",
		kind: "choice",
		opts: { a: { do: { card: "35a" } } }
	},
	{
		id: "y5-11",
		year: 5,
		num: 11,
		file: "events/y5-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造古玩店",
				en: "Build curiosity shop"
			},
			do: { card: "46" },
			cost: {
				wood: 4,
				food: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造水塔",
				en: "Build water tower"
			},
			do: { place: "10C" },
			cost: {
				gold: 3,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y5-12",
		year: 5,
		num: 12,
		file: "events/y5-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鸡舍",
				en: "Build hen house"
			},
			do: { place: "8U" },
			cost: {
				wood: 2,
				food: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造自然保护区",
				en: "Build nature preserve"
			},
			do: { place: "10B" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y6-01",
		year: 6,
		num: 1,
		file: "events/y6-01.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物换取额外行动",
					en: "Pay 2 food for an extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "放弃",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y6-02",
		year: 6,
		num: 2,
		file: "events/y6-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "12R",
				n: 2
			} },
			b: { do: {
				place: "3E",
				n: 1
			} },
			c: {
				do: {
					place: "3E",
					n: 3
				},
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y6-03",
		year: 6,
		num: 3,
		file: "events/y6-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { removeMilestone: "Lucky" },
				label: {
					zh: "忽略信件",
					en: "Ignore the letter"
				}
			},
			b: {
				do: { branch: "y6-03b" },
				cost: { food: 1 },
				label: {
					zh: "花1食物写一百封信",
					en: "Spend 1 food to write 100 letters"
				}
			}
		}
	},
	{
		id: "y6-04",
		year: 6,
		num: 4,
		file: "events/y6-04.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 1 } } },
			b: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y6-05",
		year: 6,
		num: 5,
		file: "events/y6-05.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { dice: [{
					on: [5, 6],
					do: { story: "24.4" }
				}, {
					on: [
						1,
						2,
						3,
						4
					],
					do: { res: { food: 1 } }
				}] },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y6-06",
		year: 6,
		num: 6,
		file: "events/y6-06.webp",
		kind: "choice",
		opts: {
			a: { do: { upset: 1 } },
			b: { do: { dice: [{
				on: [1, 2],
				do: { upset: 2 }
			}, {
				on: [
					3,
					4,
					5,
					6
				],
				do: { none: !0 }
			}] } }
		}
	},
	{
		id: "y6-07",
		year: 6,
		num: 7,
		file: "events/y6-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y6-07a" },
				if: { milestone: "Hard Winter" },
				label: {
					zh: "若已有严冬里程碑：炖一锅热汤",
					en: "If you have Hard Winter: hearty stew"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { notMilestone: "Hard Winter" },
				label: {
					zh: "若没有严冬里程碑：额外行动",
					en: "Otherwise: 1 additional action"
				}
			}
		}
	},
	{
		id: "y6-08",
		year: 6,
		num: 8,
		file: "events/y6-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { story: "10.4" },
				if: { hasSticker: "5A" },
				label: {
					zh: "若已有狼崽·抚摸牠",
					en: "If you have the wolf pup: pet him"
				}
			},
			b: {
				do: { story: "32.7" },
				if: { hasSticker: "5A" },
				label: {
					zh: "若已有狼崽·别管牠",
					en: "If you have the wolf pup: leave him be"
				}
			},
			c: {
				do: { invokeCard: {
					labels: ["12a", "12b"],
					onesAs: 6
				} },
				if: { notSticker: "5A" },
				label: {
					zh: "若没有狼崽",
					en: "Otherwise"
				}
			}
		}
	},
	{
		id: "y6-09",
		year: 6,
		num: 9,
		file: "events/y6-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "诱捕掠食者",
				en: "Trap predator"
			},
			do: { hap: 1 },
			cost: { wood: 4 },
			discard: !0,
			reducePer: {
				code: "12R",
				key: "wood"
			}
		}],
		endOfYear: {
			discard: !0,
			auto: { story: "9.8" }
		}
	},
	{
		id: "y6-10",
		year: 6,
		num: 10,
		file: "events/y6-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "栽种树林",
				en: "Plant grove"
			},
			do: { place: "6T" },
			cost: { gold: 3 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { none: !0 },
				cost: { gold: 1 }
			},
			discard: !0
		}
	},
	{
		id: "y6-11",
		year: 6,
		num: 11,
		file: "events/y6-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造鸟类协会",
				en: "Build birding society"
			},
			do: { card: "37" },
			cost: {
				wood: 3,
				food: 1,
				ore: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造服装店",
				en: "Build clothing store"
			},
			do: { card: "40" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y6-12",
		year: 6,
		num: 12,
		file: "events/y6-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造天文台",
				en: "Build observatory"
			},
			do: { card: "41" },
			cost: {
				wood: 2,
				ore: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造钟楼",
				en: "Build clock tower"
			},
			do: { card: "36" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y7-01",
		year: 7,
		num: 1,
		file: "events/y7-01.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 1 } },
				cost: { food: 1 }
			},
			c: { do: { seq: [{ res: { wood: 2 } }, { upset: 1 }] } }
		}
	},
	{
		id: "y7-02",
		year: 7,
		num: 2,
		file: "events/y7-02.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: { res: { ore: 1 } } }
		}
	},
	{
		id: "y7-03",
		year: 7,
		num: 3,
		file: "events/y7-03.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { branch: "y7-03b" },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y7-04",
		year: 7,
		num: 4,
		file: "events/y7-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物换取额外行动",
					en: "Pay 2 food for an extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "放弃",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y7-05",
		year: 7,
		num: 5,
		file: "events/y7-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y7-05a" },
				if: { minHearts: 14 },
				label: {
					zh: "若幸福不少于14：早起",
					en: "If happiness 14+: wake before sunrise"
				}
			},
			b: {
				do: { ask: "y7-05b" },
				if: { maxHearts: 13 },
				label: {
					zh: "若幸福少于14",
					en: "Otherwise"
				}
			}
		}
	},
	{
		id: "y7-06",
		year: 7,
		num: 6,
		file: "events/y7-06.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "还清贷款",
				en: "Pay off loan"
			},
			do: { removeMilestone: "Loan" },
			cost: { gold: 4 },
			discard: !0
		}],
		endOfYear: {
			discard: !0,
			auto: { story: "28.8" }
		},
		enter: {
			if: { milestone: "Loan" },
			elseDo: { extraAction: 1 }
		}
	},
	{
		id: "y7-07",
		year: 7,
		num: 7,
		file: "events/y7-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { seq: [{
					place: "8W",
					cover: !0,
					must: { house: !0 }
				}, { removeUpset: 1 }] },
				if: { minUpset: 1 },
				label: {
					zh: "若草屋住着不快居民：换新居民",
					en: "If an upset resident is on a grass house: new resident"
				}
			},
			b: {
				do: { hap: 1 },
				if: { maxUpset: 0 },
				label: {
					zh: "否则：匿名来信",
					en: "Otherwise: anonymous letter"
				}
			}
		}
	},
	{
		id: "y7-08",
		year: 7,
		num: 8,
		file: "events/y7-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { food: 1 } },
				if: { hasSticker: "10C" },
				label: {
					zh: "若已有水塔",
					en: "If you have the Water Tower"
				}
			},
			b: {
				do: {
					place: "1G",
					n: 1,
					cover: !0
				},
				if: { notSticker: "10C" },
				label: {
					zh: "若没有水塔：干旱",
					en: "Otherwise: drought"
				}
			}
		}
	},
	{
		id: "y7-09",
		year: 7,
		num: 9,
		file: "events/y7-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "栽种苹果树",
				en: "Plant apple tree"
			},
			do: { place: "5R" },
			cost: {
				food: 2,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "弃牌换取额外行动",
				en: "Discard for an extra action"
			},
			do: { extraAction: 1 },
			discard: !0
		}],
		endOfYear: {
			optional: {
				do: { none: !0 },
				cost: { food: 1 }
			},
			discard: !0
		}
	},
	{
		id: "y7-10",
		year: 7,
		num: 10,
		file: "events/y7-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "山间小屋：矿工鲍勃",
				en: "Mountain home: Bob the Miner"
			},
			do: { place: "4S" },
			cost: {
				wood: 4,
				ore: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "山间小屋：画家伊莉丝",
				en: "Mountain home: Elise the Painter"
			},
			do: { place: "8M" },
			cost: {
				wood: 4,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y7-11",
		year: 7,
		num: 11,
		file: "events/y7-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造禅意花园",
				en: "Build zen garden"
			},
			do: { place: "4V" },
			cost: { wood: 5 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造邮局",
				en: "Build post office"
			},
			do: { story: "26.5" },
			cost: {
				wood: 3,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y7-12",
		year: 7,
		num: 12,
		file: "events/y7-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "升级市场",
				en: "Upgrade market"
			},
			do: { seq: [{ discardCard: "9" }, { card: "33" }] },
			cost: {
				wood: 1,
				food: 1,
				gold: 1
			},
			discard: !0,
			if: { hasCard: "9" }
		}]
	},
	{
		id: "y8-01",
		year: 8,
		num: 1,
		file: "events/y8-01.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "3E",
				n: 2
			} },
			b: { do: {
				place: "1H",
				n: 1,
				seq: [{ place: "11A" }]
			} }
		}
	},
	{
		id: "y8-02",
		year: 8,
		num: 2,
		file: "events/y8-02.webp",
		kind: "choice",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "支付2食物多做1次行动",
					en: "Spend 2 food for 1 extra action"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "不支付",
					en: "Decline"
				}
			}
		}
	},
	{
		id: "y8-03",
		year: 8,
		num: 3,
		file: "events/y8-03.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { food: 1 } } },
			b: {
				do: { res: { wood: 2 } },
				cost: { food: 1 }
			},
			c: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y8-04",
		year: 8,
		num: 4,
		file: "events/y8-04.webp",
		kind: "choice",
		opts: {
			a: { do: { none: !0 } },
			b: {
				do: { seq: [{ res: { ore: 1 } }, { dice: [{
					on: [
						1,
						2,
						3
					],
					do: { milestone: "Hot Goods|red" }
				}] }] },
				cost: { food: 1 }
			}
		}
	},
	{
		id: "y8-05",
		year: 8,
		num: 5,
		file: "events/y8-05.webp",
		kind: "choice",
		opts: {
			a: { do: { res: { gold: 2 } } },
			b: { do: { milestone: "Noble|silver" } }
		}
	},
	{
		id: "y8-06",
		year: 8,
		num: 6,
		file: "events/y8-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				cost: { gold: 2 },
				if: { minRes: { gold: 2 } },
				label: {
					zh: "若已有至少2金币：花2金币得1幸福",
					en: "If you have 2+ gold: Spend 2 gold for 1 happiness"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { maxRes: { gold: 1 } },
				label: {
					zh: "若金币不足2：先做一次地图行动",
					en: "If under 2 gold: Take 1 map action"
				}
			}
		}
	},
	{
		id: "y8-07",
		year: 8,
		num: 7,
		file: "events/y8-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y8-07a" },
				if: { milestone: "Test Subject" },
				label: {
					zh: "已有测试对象里程碑：花2食物或失去1幸福",
					en: "With Test Subject milestone: Spend 2 food or lose 1 happiness"
				}
			},
			b: {
				do: { extraAction: 1 },
				cost: { gold: 1 },
				if: { notMilestone: "Test Subject" },
				label: {
					zh: "未有测试对象里程碑：可花1金币多做1次行动",
					en: "Without Test Subject milestone: Spend 1 gold for 1 extra action"
				}
			}
		}
	},
	{
		id: "y8-08",
		year: 8,
		num: 8,
		file: "events/y8-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: {
					place: "8N",
					cover: !0,
					must: { woodAxeAlternative: !0 },
					softMust: !1
				},
				if: { noneStickers: ["4C", "10C"] },
				label: {
					zh: "无消防站或水塔：覆盖放置8N",
					en: "Without Fire Station/Water Tower: Place 8N covering"
				}
			},
			b: {
				do: { ask: "y8-08b" },
				if: { anySticker: ["4C", "10C"] },
				label: {
					zh: "已有消防站或水塔：处理热气球（读29.7或29.8）",
					en: "With Fire Station/Water Tower: Handle the balloon (read 29.7 or 29.8)"
				}
			}
		}
	},
	{
		id: "y8-09",
		year: 8,
		num: 9,
		file: "events/y8-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { freeCardActions: !0 },
				if: { minCalmResidents: 8 },
				label: {
					zh: "有8名以上未不满居民：卡牌行动耗0资源",
					en: "With 8+ non-upset residents: Card actions cost 0 resources"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { maxCalmResidents: 7 },
				label: {
					zh: "不足8名未不满居民：可多做1次行动",
					en: "With fewer than 8: Take 1 extra action"
				}
			}
		}
	},
	{
		id: "y8-10",
		year: 8,
		num: 10,
		file: "events/y8-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造糖果店",
				en: "Build candy shop"
			},
			do: { card: "56" },
			cost: {
				wood: 3,
				food: 1,
				gold: 1
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造夏令营",
				en: "Build summer camp"
			},
			do: { place: "10G" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y8-11",
		year: 8,
		num: 11,
		file: "events/y8-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造银行",
				en: "Build bank"
			},
			do: { place: "8V" },
			cost: {
				wood: 3,
				ore: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造报社",
				en: "Build newspaper press"
			},
			do: { place: "7K" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y8-12",
		year: 8,
		num: 12,
		file: "events/y8-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造宅邸：阿比盖尔",
				en: "Build mansion: Lady Abigail"
			},
			do: { card: "53" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造宅邸：尼古拉斯",
				en: "Build mansion: Nicholas Jackson"
			},
			do: { card: "54" },
			cost: {
				wood: 4,
				gold: 2
			},
			discard: !0
		}]
	},
	{
		id: "y9-01",
		year: 9,
		num: 1,
		file: "events/y9-01.webp",
		kind: "choice",
		opts: { a: { do: { invokeCard: {
			labels: ["12a", "12b"],
			goldIfValue: 2
		} } } }
	},
	{
		id: "y9-02",
		year: 9,
		num: 2,
		file: "events/y9-02.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造围栏",
				en: "Build fence"
			},
			do: { seq: [{
				place: "12R",
				n: 2
			}, { branch: "y9-02fence" }] },
			cost: { wood: 2 }
		}],
		endOfYear: {
			choice: [{
				cost: { wood: 3 },
				do: { none: !0 }
			}, { do: { upset: 1 } }],
			discard: !0
		}
	},
	{
		id: "y9-03",
		year: 9,
		num: 3,
		file: "events/y9-03.webp",
		kind: "choice",
		opts: {
			a: { do: { place: "11A" } },
			b: {
				do: { res: { ore: 1 } },
				cost: { food: 2 }
			}
		}
	},
	{
		id: "y9-04",
		year: 9,
		num: 4,
		file: "events/y9-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { res: { gold: 1 } },
				if: { hasSticker: "5A" },
				label: {
					zh: "有狼崽：得1金币",
					en: "With the wolf pup: Gain 1 gold"
				}
			},
			b: {
				do: { hap: 1 },
				if: { notSticker: "5A" },
				label: {
					zh: "无狼崽：得1幸福",
					en: "Without the wolf pup: Gain 1 happiness"
				}
			}
		}
	},
	{
		id: "y9-05",
		year: 9,
		num: 5,
		file: "events/y9-05.webp",
		kind: "choice",
		opts: {
			a: { do: {
				place: "8Y",
				cover: !0
			} },
			b: { do: { skipAction: !0 } },
			c: {
				do: { none: !0 },
				cost: { gold: 1 }
			}
		}
	},
	{
		id: "y9-06",
		year: 9,
		num: 6,
		file: "events/y9-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { hap: 1 },
				if: { anySticker: ["7H", "4D"] },
				label: {
					zh: "有图书馆和/或学校：得1幸福",
					en: "With Library and/or School: Gain 1 happiness"
				}
			},
			b: {
				do: {
					place: "1G",
					cover: !0,
					must: {
						berryBush: !0,
						food: 1
					},
					softMust: !0
				},
				if: { noneStickers: ["7H", "4D"] },
				label: {
					zh: "没有图书馆和学校：覆盖放置枯灌木1G",
					en: "Without Library/School: Place dead bush 1G covering"
				}
			}
		}
	},
	{
		id: "y9-07",
		year: 9,
		num: 7,
		file: "events/y9-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { upset: 1 },
				if: { milestone: "Unrest" },
				label: {
					zh: "有动乱里程碑：放置1个不满贴纸",
					en: "With Unrest milestone: Place 1 upset sticker"
				}
			},
			b: {
				do: { extraAction: 1 },
				if: { notMilestone: "Unrest" },
				label: {
					zh: "无动乱里程碑：多做一次地图行动",
					en: "Without Unrest milestone: Take 1 extra map action"
				}
			}
		}
	},
	{
		id: "y9-08",
		year: 9,
		num: 8,
		file: "events/y9-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { dice: [{
					on: [
						1,
						2,
						3
					],
					do: { story: "24.10" }
				}, {
					on: [
						4,
						5,
						6
					],
					do: { story: "16.9" }
				}] },
				if: { hasSticker: "5M" },
				label: {
					zh: "有野比尔居民：掷骰查表（1-3读24.10，4-6读16.9）",
					en: "With Wild Bill: Roll die (1-3 read 24.10, 4-6 read 16.9)"
				}
			},
			b: {
				do: { ask: "y9-08b" },
				if: { notSticker: "5M" },
				label: {
					zh: "无野比尔居民：花1食物放道路3E或花11A",
					en: "Without Wild Bill: Spend 1 food to place road 3E or flower 11A"
				}
			}
		}
	},
	{
		id: "y9-09",
		year: 9,
		num: 9,
		file: "events/y9-09.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "招待贵客",
				en: "Impress our guest"
			},
			do: { hap: 1 },
			cost: {
				food: 3,
				gold: 1
			},
			discard: !0
		}],
		endOfYear: {
			choice: [{
				cost: { gold: 3 },
				do: { none: !0 }
			}, { do: { story: "24.6" } }],
			discard: !0
		}
	},
	{
		id: "y9-10",
		year: 9,
		num: 10,
		file: "events/y9-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造镇招牌",
				en: "Build town sign"
			},
			do: { story: "26.9" },
			cost: {
				wood: 1,
				gold: 1,
				ore: 1
			},
			discard: !0
		}]
	},
	{
		id: "y9-11",
		year: 9,
		num: 11,
		file: "events/y9-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造雕塑花园",
				en: "Build sculpture garden"
			},
			do: { seq: [{ place: "8C" }, { hap: 1 }] },
			cost: { gold: 2 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "建造自雕像",
				en: "Build statue in your likeness"
			},
			do: { seq: [{ place: "8S" }, { milestone: "Immortalized|silver" }] },
			cost: {
				gold: 2,
				ore: 2
			},
			discard: !0
		}]
	},
	{
		id: "y9-12",
		year: 9,
		num: 12,
		file: "events/y9-12.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建造火车站",
				en: "Build train station"
			},
			do: { place: "5E" },
			cost: {
				wood: 3,
				gold: 1,
				ore: 2
			},
			discard: !0
		}]
	},
	{
		id: "y10-01",
		year: 10,
		num: 1,
		file: "events/y10-01.webp",
		kind: "choice",
		opts: {
			a: { do: { seq: [{ res: { wood: 3 } }, {
				place: "6K",
				cover: !0
			}] } },
			b: { do: { place: "12H" } }
		}
	},
	{
		id: "y10-02",
		year: 10,
		num: 2,
		file: "events/y10-02.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "修建道路",
				en: "Road construction"
			},
			do: { ask: "y10-02" },
			discard: !0
		}]
	},
	{
		id: "y10-03",
		year: 10,
		num: 3,
		file: "events/y10-03.webp",
		kind: "choice",
		opts: {
			a: {
				do: { pickTarget: "discount" },
				label: {
					zh: "对在场卡行动时少付1资源",
					en: "Take a card action at a 1-resource discount"
				}
			},
			b: {
				do: { pickTarget: "discard" },
				label: {
					zh: "弃掉该卡并多做1次行动",
					en: "Discard that card for 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-04",
		year: 10,
		num: 4,
		file: "events/y10-04.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y10-04a" },
				if: { minRedMilestones: 2 },
				label: {
					zh: "有至少2个红色里程碑：失去1幸福或覆盖★",
					en: "With 2+ red milestones: Lose 1 happiness or cover a star"
				}
			},
			b: {
				do: { ask: "y10-04b" },
				if: { maxRedMilestones: 1 },
				label: {
					zh: "红色里程碑不足2个：得1幸福或多做1次行动",
					en: "With under 2 red milestones: Gain 1 happiness or take 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-05",
		year: 10,
		num: 5,
		file: "events/y10-05.webp",
		kind: "choice",
		opts: {
			a: {
				do: { invokeCard: {
					labels: ["12a", "12b"],
					reroll: !0
				} },
				if: { notMilestone: "Pro Angler" },
				label: {
					zh: "无职业钓手里程碑：在12A/12B钓鱼（可花1食物重掷）",
					en: "Without Pro Angler: Go Fishing on 12A/12B (spend 1 food to reroll)"
				}
			},
			b: {
				do: { hap: 1 },
				if: { milestone: "Pro Angler" },
				label: {
					zh: "有职业钓手里程碑：得1幸福",
					en: "With Pro Angler: Gain 1 happiness"
				}
			}
		}
	},
	{
		id: "y10-06",
		year: 10,
		num: 6,
		file: "events/y10-06.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y10-06a" },
				if: { minUpset: 1 },
				label: {
					zh: "有不满居民：失去1幸福或花2食物覆盖12G",
					en: "With an upset resident: Lose 1 happiness or spend 2 food to cover with 12G"
				}
			},
			b: {
				do: {
					place: "11M",
					must: { house: !0 }
				},
				if: { maxUpset: 0 },
				label: {
					zh: "无不满居民：在带居民的建筑放11M",
					en: "Without an upset resident: Place 11M on a building with a resident"
				}
			}
		}
	},
	{
		id: "y10-07",
		year: 10,
		num: 7,
		file: "events/y10-07.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y10-07a" },
				if: { milestone: "Farming" },
				label: {
					zh: "有农业里程碑：花0-3金币，每金币放1个农场动物11B",
					en: "With Farming milestone: Spend 0-3 gold; place farm animal 11B per gold"
				}
			},
			b: {
				do: { branch: "y10-07b" },
				if: { notMilestone: "Farming" },
				label: {
					zh: "无农业里程碑：有总统里程碑得1幸福，否则得1金币",
					en: "Without Farming: With President gain 1 happiness, otherwise 1 gold"
				}
			}
		}
	},
	{
		id: "y10-08",
		year: 10,
		num: 8,
		file: "events/y10-08.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y10-08a" },
				label: {
					zh: "无垃圾或污染工厂：花0-2食物，每食物放1个花11A",
					en: "Without trash/polluted factories: Spend 0-2 food; place flower 11A each"
				}
			},
			b: {
				do: { seq: [
					{ hap: -1 },
					{
						pickRes: [
							"wood",
							"food",
							"gold",
							"ore"
						],
						n: 1
					},
					{ extraAction: 1 }
				] },
				label: {
					zh: "有垃圾或污染工厂：可失去1幸福，得1自选资源并多做1次行动",
					en: "With trash/polluted factories: Lose 1 happiness to gain 1 resource and 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-09",
		year: 10,
		num: 9,
		file: "events/y10-09.webp",
		kind: "choice",
		opts: {
			a: {
				do: { ask: "y10-09a" },
				if: { milestone: "Hot Goods" },
				label: {
					zh: "有赃物里程碑：可花2金币或1矿石移除",
					en: "With Hot Goods: Spend 2 gold or 1 ore to remove it"
				}
			},
			b: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				if: { notMilestone: "Hot Goods" },
				label: {
					zh: "无赃物里程碑：可花2食物多做1次行动",
					en: "Without Hot Goods: Spend 2 food for 1 extra action"
				}
			}
		}
	},
	{
		id: "y10-10",
		year: 10,
		num: 10,
		file: "events/y10-10.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "建立贸易路线",
				en: "Establish trade route"
			},
			do: { seq: [{ res: { gold: 3 } }, { milestone: "Ore Tycoon|silver" }] },
			cost: { ore: 2 },
			discard: !0
		}]
	},
	{
		id: "y10-11",
		year: 10,
		num: 11,
		file: "events/y10-11.webp",
		kind: "keep",
		keepActions: [{
			key: "a",
			label: {
				zh: "植树",
				en: "Plant tree"
			},
			do: { place: "8X" },
			cost: { gold: 3 },
			discard: !0
		}, {
			key: "b",
			label: {
				zh: "翻修邻居房屋",
				en: "Renovate neighbor's home"
			},
			do: { seq: [{
				place: "10N",
				cover: !0,
				must: {
					house: !0,
					grassHouse: !0
				}
			}, { ask: "y10-11b" }] },
			cost: {
				wood: 3,
				gold: 1
			},
			discard: !0
		}]
	},
	{
		id: "y10-12",
		year: 10,
		num: 12,
		file: "events/y10-12.webp",
		kind: "keep",
		opts: {
			a: {
				do: { extraAction: 1 },
				cost: { food: 2 },
				label: {
					zh: "花费 2 食物，本回合多执行一次行动",
					en: "Spend 2 food for an additional action this turn"
				}
			},
			b: {
				do: { none: !0 },
				label: {
					zh: "不花费",
					en: "Do not spend"
				}
			}
		},
		keepText: {
			zh: "无论是否花费，本牌均留在场上。",
			en: "Regardless, keep this card in play."
		},
		endOfYear: {
			auto: { story: "31.1" },
			discard: !1
		}
	}
], _ = Object.fromEntries(re.map((e) => [e.id, e])), ie = {
	22: "30.8",
	50: "9.4",
	31: null
}, ae = { 45: [
	"4",
	"7",
	"9",
	"31",
	"34",
	"46",
	"48",
	"51"
] }, v = {
	wood: 12,
	food: 12,
	gold: 12,
	ore: 6
}, y = [
	["09-01", "09-02"],
	["09-03", "09-04"],
	["09-05", "09-06"],
	["09-07", "09-08"],
	["09-09", "09-10"],
	["09-11", "09-12"],
	["09-13", "09-14"],
	["09-15", "09-16"]
], b = {
	wood: ["木材", "Wood"],
	food: ["食物", "Food"],
	gold: ["金币", "Gold"],
	ore: ["矿石", "Ore"]
}, oe = [
	{
		id: "01-1 Heart",
		code: "1 Heart",
		name: "1 Heart",
		page: 1,
		kind: "token",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s000.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1 Progress",
		code: "1 Progress",
		name: "1 Progress",
		page: 1,
		kind: "token",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s001.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1 Upset",
		code: "1 Upset",
		name: "1 Upset",
		page: 1,
		kind: "token",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s002.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "01-1A",
		code: "1A",
		name: "1A",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s003.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1B",
		code: "1B",
		name: "1B",
		page: 1,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s004.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1C",
		code: "1C",
		name: "1C",
		page: 1,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s005.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1D",
		code: "1D",
		name: "1D",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s006.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1E",
		code: "1E",
		name: "1E",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s007.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1F",
		code: "1F",
		name: "1F",
		page: 1,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 1,
		file: "stickers/s008.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1G",
		code: "1G",
		name: "1G",
		page: 1,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s009.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "01-1H",
		code: "1H",
		name: "1H",
		page: 1,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s010.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		berryBush: !0
	},
	{
		id: "02-2 Adventurer",
		code: "2 Adventurer",
		name: "2 Adventurer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s011.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Astronomer",
		code: "2 Astronomer",
		name: "2 Astronomer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s012.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Avian Enthusiast",
		code: "2 Avian Enthusiast",
		name: "2 Avian Enthusiast",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s013.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Bear Tamer",
		code: "2 Bear Tamer",
		name: "2 Bear Tamer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s014.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Big Savings Account",
		code: "2 Big Savings Account",
		name: "2 Big Savings Account",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s015.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Birder",
		code: "2 Birder",
		name: "2 Birder",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s016.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Business Mogul",
		code: "2 Business Mogul",
		name: "2 Business Mogul",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s017.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Camp Counselor",
		code: "2 Camp Counselor",
		name: "2 Camp Counselor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s018.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Conservationist",
		code: "2 Conservationist",
		name: "2 Conservationist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s019.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Dating",
		code: "2 Dating",
		name: "2 Dating",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s020.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Degenerate",
		code: "2 Degenerate",
		name: "2 Degenerate",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s021.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Dictator",
		code: "2 Dictator",
		name: "2 Dictator",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s022.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Expert Baker",
		code: "2 Expert Baker",
		name: "2 Expert Baker",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s023.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Explorer",
		code: "2 Explorer",
		name: "2 Explorer",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s024.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fake News",
		code: "2 Fake News",
		name: "2 Fake News",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s025.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Famous Baker",
		code: "2 Famous Baker",
		name: "2 Famous Baker",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s026.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Famous Chef",
		code: "2 Famous Chef",
		name: "2 Famous Chef",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s027.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Farm Hand",
		code: "2 Farm Hand",
		name: "2 Farm Hand",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s028.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fashionable",
		code: "2 Fashionable",
		name: "2 Fashionable",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s029.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Finder of Secrets",
		code: "2 Finder of Secrets",
		name: "2 Finder of Secrets",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s030.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Fisher",
		code: "2 Fisher",
		name: "2 Fisher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s031.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Glamorous",
		code: "2 Glamorous",
		name: "2 Glamorous",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s032.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Governor",
		code: "2 Governor",
		name: "2 Governor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s033.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Greedy Company",
		code: "2 Greedy Company",
		name: "2 Greedy Company",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s034.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Green Thumb",
		code: "2 Green Thumb",
		name: "2 Green Thumb",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s035.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hard Winter",
		code: "2 Hard Winter",
		name: "2 Hard Winter",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s036.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Honest Company",
		code: "2 Honest Company",
		name: "2 Honest Company",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s037.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hot Goods",
		code: "2 Hot Goods",
		name: "2 Hot Goods",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s038.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Hunger",
		code: "2 Hunger",
		name: "2 Hunger",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s039.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Immortalized",
		code: "2 Immortalized",
		name: "2 Immortalized",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s040.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Investment",
		code: "2 Investment",
		name: "2 Investment",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s041.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Kind",
		code: "2 Kind",
		name: "2 Kind",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s042.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Legendary Rancher",
		code: "2 Legendary Rancher",
		name: "2 Legendary Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s043.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Little Genius",
		code: "2 Little Genius",
		name: "2 Little Genius",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s044.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Loan",
		code: "2 Loan",
		name: "2 Loan",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s045.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Apprentice",
		code: "2 Lodge Apprentice",
		name: "2 Lodge Apprentice",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s046.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Master",
		code: "2 Lodge Master",
		name: "2 Lodge Master",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s047.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lodge Member",
		code: "2 Lodge Member",
		name: "2 Lodge Member",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s048.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Lucky",
		code: "2 Lucky",
		name: "2 Lucky",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s049.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Married",
		code: "2 Married",
		name: "2 Married",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s050.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Master Chef",
		code: "2 Master Chef",
		name: "2 Master Chef",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s051.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Master of Agriculture",
		code: "2 Master of Agriculture",
		name: "2 Master of Agriculture",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s052.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Matchmaker",
		code: "2 Matchmaker",
		name: "2 Matchmaker",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s053.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Mayor",
		code: "2 Mayor",
		name: "2 Mayor",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s054.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Miracle Medicine",
		code: "2 Miracle Medicine",
		name: "2 Miracle Medicine",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s055.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Monarch",
		code: "2 Monarch",
		name: "2 Monarch",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s056.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 New Family",
		code: "2 New Family",
		name: "2 New Family",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s057.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Noble",
		code: "2 Noble",
		name: "2 Noble",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s058.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Ore Tycoon",
		code: "2 Ore Tycoon",
		name: "2 Ore Tycoon",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s059.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Ornithologist",
		code: "2 Ornithologist",
		name: "2 Ornithologist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s060.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Paleontologist",
		code: "2 Paleontologist",
		name: "2 Paleontologist",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s061.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Patron of the Arts",
		code: "2 Patron of the Arts",
		name: "2 Patron of the Arts",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s062.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Perfect Village",
		code: "2 Perfect Village",
		name: "2 Perfect Village",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s063.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pet Lover",
		code: "2 Pet Lover",
		name: "2 Pet Lover",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s064.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pet Rescuer",
		code: "2 Pet Rescuer",
		name: "2 Pet Rescuer",
		page: 2,
		kind: "milestone",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s065.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Poisoned",
		code: "2 Poisoned",
		name: "2 Poisoned",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s066.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 President",
		code: "2 President",
		name: "2 President",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s067.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Pro Angler",
		code: "2 Pro Angler",
		name: "2 Pro Angler",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s068.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Rancher",
		code: "2 Rancher",
		name: "2 Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s069.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Runner Up",
		code: "2 Runner Up",
		name: "2 Runner Up",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s070.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Savings Account",
		code: "2 Savings Account",
		name: "2 Savings Account",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s071.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Secret Spy",
		code: "2 Secret Spy",
		name: "2 Secret Spy",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s072.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Sleuth",
		code: "2 Sleuth",
		name: "2 Sleuth",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s073.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Termites",
		code: "2 Termites",
		name: "2 Termites",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s074.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Test Subject",
		code: "2 Test Subject",
		name: "2 Test Subject",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s075.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Thriving Community",
		code: "2 Thriving Community",
		name: "2 Thriving Community",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s076.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Treasure Hunter",
		code: "2 Treasure Hunter",
		name: "2 Treasure Hunter",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s077.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Trustworthy News",
		code: "2 Trustworthy News",
		name: "2 Trustworthy News",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s078.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Tyrant",
		code: "2 Tyrant",
		name: "2 Tyrant",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s079.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Unrest",
		code: "2 Unrest",
		name: "2 Unrest",
		page: 2,
		kind: "milestone",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s080.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Upstanding",
		code: "2 Upstanding",
		name: "2 Upstanding",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s081.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-2 Veteran Rancher",
		code: "2 Veteran Rancher",
		name: "2 Veteran Rancher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s082.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "02-Veteran Fisher",
		code: "Veteran Fisher",
		name: "Veteran Fisher",
		page: 2,
		kind: "milestone",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s083.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "03-3A",
		code: "3A",
		name: "3A",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s084.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "03-3B",
		code: "3B",
		name: "3B",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s085.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "03-3C",
		code: "3C",
		name: "3C",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s086.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "03-3D",
		code: "3D",
		name: "3D",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s087.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "03-3E",
		code: "3E",
		name: "3E",
		page: 3,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s088.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4A",
		code: "4A",
		name: "4A",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s089.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4B",
		code: "4B",
		name: "4B",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s090.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4C",
		code: "4C",
		name: "4C",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s091.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4D",
		code: "4D",
		name: "4D",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s092.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "21.1",
		trees: 1,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4E",
		code: "4E",
		name: "4E",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s093.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 4,
		house: !0
	},
	{
		id: "04-4F",
		code: "4F",
		name: "4F",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s094.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4G",
		code: "4G",
		name: "4G",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s095.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "04-4H",
		code: "4H",
		name: "4H",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s096.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "16.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "04-4K",
		code: "4K",
		name: "4K",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s097.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4M",
		code: "4M",
		name: "4M",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s098.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.9",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4N",
		code: "4N",
		name: "4N",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s099.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "33.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1,
		house: !0
	},
	{
		id: "04-4P",
		code: "4P",
		name: "4P",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s100.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "04-4Q",
		code: "4Q",
		name: "4Q",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s101.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "04-4R",
		code: "4R",
		name: "4R",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s102.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4S",
		code: "4S",
		name: "4S",
		page: 4,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s103.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "19.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1,
		house: !0
	},
	{
		id: "04-4T",
		code: "4T",
		name: "4T",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s104.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4U",
		code: "4U",
		name: "4U",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s105.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "18.7",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4V",
		code: "4V",
		name: "4V",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s106.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4W",
		code: "4W",
		name: "4W",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s107.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4X",
		code: "4X",
		name: "4X",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s108.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "04-4Y",
		code: "4Y",
		name: "4Y",
		page: 4,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s109.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5A",
		code: "5A",
		name: "5A",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s110.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5B",
		code: "5B",
		name: "5B",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s111.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5C",
		code: "5C",
		name: "5C",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s112.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "05-5D",
		code: "5D",
		name: "5D",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s113.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "05-5E",
		code: "5E",
		name: "5E b",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s114.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "12.8",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5Eb",
		code: "5E",
		name: "5E",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s115.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "12.8",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5F",
		code: "5F",
		name: "5F",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s116.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5G",
		code: "5G",
		name: "5G",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s117.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5H",
		code: "5H",
		name: "5H",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s118.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "14.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "05-5K",
		code: "5K",
		name: "5K",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s119.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 5,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5M",
		code: "5M",
		name: "5M",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s120.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "05-5N",
		code: "5N",
		name: "5N",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s121.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "05-5P",
		code: "5P",
		name: "5P",
		page: 5,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s122.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "05-5Q",
		code: "5Q",
		name: "5Q",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s123.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1,
		trees: 0,
		axe: 1,
		log: 0,
		residents: 0
	},
	{
		id: "05-5R",
		code: "5R",
		name: "5R",
		page: 5,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s124.webp",
		wood: 1,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "06-6A",
		code: "6A",
		name: "6A",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s125.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1,
		house: !0
	},
	{
		id: "06-6B",
		code: "6B",
		name: "6B",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s126.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "06-6C",
		code: "6C",
		name: "6C",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s127.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6D",
		code: "6D",
		name: "6D",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s128.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6E",
		code: "6E",
		name: "6E",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s129.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "06-6F",
		code: "6F",
		name: "6F",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s130.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6G",
		code: "6G",
		name: "6G",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s131.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "06-6H",
		code: "6H",
		name: "6H",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s132.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1,
		trees: 0,
		axe: 1,
		log: 0,
		residents: 0
	},
	{
		id: "06-6M",
		code: "6M",
		name: "6M",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s133.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6N",
		code: "6N",
		name: "6N",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s134.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6P",
		code: "6P",
		name: "6P",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s135.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6Q",
		code: "6Q",
		name: "6Q",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s136.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6R",
		code: "6R",
		name: "6R",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s137.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "8.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "06-6T",
		code: "6T",
		name: "6T",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s138.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "06-6U",
		code: "6U",
		name: "6U",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s139.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6V",
		code: "6V",
		name: "6V",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s140.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 1,
		trees: 1,
		axe: 1,
		log: 1,
		residents: 0
	},
	{
		id: "06-6X",
		code: "6X",
		name: "6X",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s141.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6Y",
		code: "6Y",
		name: "6Y",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s142.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6Z",
		code: "6Z",
		name: "6Z",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s143.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 1,
		trees: 0,
		axe: 1,
		log: 0,
		residents: 0
	},
	{
		id: "07-7A",
		code: "7A",
		name: "7A",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s144.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "07-7B",
		code: "7B",
		name: "7B",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s145.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7C",
		code: "7C",
		name: "7C",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s146.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "07-7D",
		code: "7D",
		name: "7D",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s147.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 2,
		house: !0
	},
	{
		id: "07-7E",
		code: "7E",
		name: "7E",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s148.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7F",
		code: "7F",
		name: "7F",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s149.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7G",
		code: "7G",
		name: "7G",
		page: 7,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s150.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7H",
		code: "7H",
		name: "7H",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s151.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7K",
		code: "7K",
		name: "7K",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s152.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "29.2",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7N",
		code: "7N",
		name: "7N",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s153.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7P",
		code: "7P",
		name: "7P",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s154.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "07-7Q",
		code: "7Q",
		name: "7Q",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s155.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7R",
		code: "7R",
		name: "7R",
		page: 7,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s156.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "07-7X",
		code: "7X",
		name: "7X",
		page: 7,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 1,
		file: "stickers/s157.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8A",
		code: "8A",
		name: "8A",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s158.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "10.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1,
		house: !0
	},
	{
		id: "08-8B",
		code: "8B",
		name: "8B",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s159.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8C",
		code: "8C",
		name: "8C",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s160.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8D",
		code: "8D",
		name: "8D",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s161.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8E",
		code: "8E",
		name: "8E",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s162.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8F",
		code: "8F",
		name: "8F",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s163.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8G",
		code: "8G",
		name: "8G",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s164.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8H",
		code: "8H",
		name: "8H",
		page: 8,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s165.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8K",
		code: "8K",
		name: "8K",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s166.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8M",
		code: "8M",
		name: "8M",
		page: 8,
		kind: "map",
		bg: "rock",
		cols: 2,
		rows: 2,
		file: "stickers/s167.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "20.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1,
		house: !0
	},
	{
		id: "08-8N",
		code: "8N",
		name: "8N",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s168.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8P",
		code: "8P",
		name: "8P",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s169.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8Q",
		code: "8Q",
		name: "8Q",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s170.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8R",
		code: "8R",
		name: "8R",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s171.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "08-8S",
		code: "8S",
		name: "8S",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s172.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8T",
		code: "8T",
		name: "8T",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s173.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "08-8U",
		code: "8U",
		name: "8U",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s174.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8V",
		code: "8V",
		name: "8V",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s175.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "27.2",
		trees: 5,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "08-8W",
		code: "8W",
		name: "8W",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s176.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "9.1",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "08-8X",
		code: "8X",
		name: "8X",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s177.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "08-8Y",
		code: "8Y",
		name: "8Y",
		page: 8,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s178.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "09-01",
		code: "9A",
		name: "9A",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s179.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "09-02",
		code: "9B",
		name: "9B",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s180.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "09-03",
		code: "9C",
		name: "9C",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s181.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "09-04",
		code: "9D",
		name: "9D",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s182.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "09-05",
		code: "9E",
		name: "9E",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s183.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-06",
		code: "9F",
		name: "9F",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s184.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "09-07",
		code: "9G",
		name: "9G",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s185.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		berryBush: !0
	},
	{
		id: "09-08",
		code: "9H",
		name: "9H",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s186.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 0,
		residents: 0,
		berryBush: !0
	},
	{
		id: "09-09",
		code: "9I",
		name: "9I",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s187.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-10",
		code: "9J",
		name: "9J",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s188.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-11",
		code: "9K",
		name: "9K",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s189.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 3,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-12",
		code: "9L",
		name: "9L",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s190.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-13",
		code: "9M",
		name: "9M",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s191.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 3,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-14",
		code: "9N",
		name: "9N",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s192.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "09-15",
		code: "9O",
		name: "9O",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s193.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		berryBush: !0
	},
	{
		id: "09-16",
		code: "9P",
		name: "9P",
		page: 9,
		kind: "starting",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s194.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 5,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10A",
		code: "10A",
		name: "10A",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s195.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10B",
		code: "10B",
		name: "10B",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s196.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		story: "10.8",
		trees: 5,
		axe: 0,
		log: 1,
		residents: 0
	},
	{
		id: "10-10C",
		code: "10C",
		name: "10C",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s197.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "8.8",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10D",
		code: "10D",
		name: "10D",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 3,
		rows: 3,
		file: "stickers/s198.webp",
		wood: 0,
		food: 1,
		gold: 0,
		ore: 0,
		story: "24.7",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10E",
		code: "10E",
		name: "10E",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s199.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10F",
		code: "10F",
		name: "10F",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s200.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10G",
		code: "10G",
		name: "10G",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 3,
		file: "stickers/s201.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		story: "30.2",
		trees: 1,
		axe: 0,
		log: 1,
		residents: 0,
		house: !0
	},
	{
		id: "10-10H",
		code: "10H",
		name: "10H",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s202.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10K",
		code: "10K",
		name: "10K",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s203.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10M",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s204.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10M#2",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s205.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10M#3",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s206.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10M#4",
		code: "10M",
		name: "10M",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s207.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "10-10N",
		code: "10N",
		name: "10N",
		page: 10,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 2,
		file: "stickers/s208.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		house: !0
	},
	{
		id: "10-g01",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s209.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g02",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s210.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g03",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s211.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g04",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s212.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g05",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s213.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g06",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s214.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g07",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s215.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g08",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s216.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g09",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s217.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g10",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s218.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g11",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s219.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g12",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s220.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g13",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s221.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g14",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s222.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g15",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s223.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g16",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s224.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g17",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s225.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g18",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s226.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g19",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s227.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g20",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s228.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g21",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s229.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g22",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s230.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g23",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s231.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g24",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s232.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g25",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s233.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g26",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s234.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g27",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s235.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g28",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s236.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g29",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s237.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g30",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s238.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g31",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s239.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g32",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "water",
		cols: 1,
		rows: 1,
		file: "stickers/s240.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g33",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "rock",
		cols: 1,
		rows: 1,
		file: "stickers/s241.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g34",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/s242.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g35",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s243.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "10-g36",
		code: "p10",
		name: "Page 10",
		page: 10,
		kind: "overlay",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/s244.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	},
	{
		id: "11-11A",
		code: "11A",
		name: "11A",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11a.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11B",
		code: "11B",
		name: "11B",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11b.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11C",
		code: "11C",
		name: "11C",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11c.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11D",
		code: "11D",
		name: "11D",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11d.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11E",
		code: "11E",
		name: "11E",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11e.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11F",
		code: "11F",
		name: "11F",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11f.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11G",
		code: "11G",
		name: "11G",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11g.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11H",
		code: "11H",
		name: "11H",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11h.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11K",
		code: "11K",
		name: "11K",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11k.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11M",
		code: "11M",
		name: "11M",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11m.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "11-11N",
		code: "11N",
		name: "11N",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/11n.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		story: "15.8",
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11P",
		code: "11P",
		name: "11P",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11p.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 1
	},
	{
		id: "11-11Q",
		code: "11Q",
		name: "11Q",
		page: 11,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/11q.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11R",
		code: "11R",
		name: "11R",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/11r.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "11-11S",
		code: "11S",
		name: "11S",
		page: 11,
		kind: "map",
		bg: "grass",
		cols: 1,
		rows: 1,
		file: "stickers/11s.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12A",
		code: "12A",
		name: "12A",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12a.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12B",
		code: "12B",
		name: "12B",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12b.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12C",
		code: "12C",
		name: "12C",
		page: 12,
		kind: "map",
		bg: "rock",
		cols: 1,
		rows: 2,
		file: "stickers/12c.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12D",
		code: "12D",
		name: "12D",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12d.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12E",
		code: "12E",
		name: "12E",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12e.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12F",
		code: "12F",
		name: "12F",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12f.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12G",
		code: "12G",
		name: "12G",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12g.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12H",
		code: "12H",
		name: "12H",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12h.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12J",
		code: "12J",
		name: "12J",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12j.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12K",
		code: "12K",
		name: "12K",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12k.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12M",
		code: "12M",
		name: "12M",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12m.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12N",
		code: "12N",
		name: "12N",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12n.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12P",
		code: "12P",
		name: "12P",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12p.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12Q",
		code: "12Q",
		name: "12Q",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12q.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12R",
		code: "12R",
		name: "12R",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 2,
		rows: 2,
		file: "stickers/12r.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0,
		fence: !0
	},
	{
		id: "12-12S",
		code: "12S",
		name: "12S",
		page: 12,
		kind: "map",
		bg: "clear",
		cols: 1,
		rows: 1,
		file: "stickers/12s.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "12-12U",
		code: "12U",
		name: "12U",
		page: 12,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/12u.webp",
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 0,
		axe: 0,
		log: 0,
		residents: 0
	},
	{
		id: "06-6K",
		code: "6K",
		name: "6K",
		page: 6,
		kind: "map",
		bg: "grass",
		cols: 2,
		rows: 2,
		file: "stickers/s138.webp",
		wood: 1,
		food: 0,
		gold: 0,
		ore: 0,
		trees: 2,
		axe: 0,
		log: 1,
		residents: 0
	}
], x = Object.fromEntries(oe.map((e) => [e.id, e])), se = oe.reduce((e, t) => ((e[t.code] ??= []).push(t), e), {}), ce = {
	id: "cozistickerville",
	uuid: "a44fc6d0-0a19-468e-9b9a-63ec6ad897b7",
	sdkApi: 2,
	tier: "alpha",
	mechanics: ["tile-placement", "engine-building"],
	interactionTags: [],
	nameKey: "games.cozistickerville.name",
	descKey: "games.cozistickerville.desc",
	rulesKey: "games.cozistickerville.rules",
	rulesUrl: { en: "https://unexpectedgames.com/s/UGCSV0101_Rulebook.pdf" },
	icon: "🏘️",
	iconImg: "games/cozistickerville.webp",
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#d98c4a",
	releasedAt: "2026-11-27T18:52:00+08:00",
	search: {
		py: "wen xin tie zhi xiao zhen",
		init: "wxtzxz"
	},
	hotseat: "off"
}, S = [
	"wood",
	"food",
	"gold",
	"ore"
], le = e.object({
	wood: e.int().min(0).max(99),
	food: e.int().min(0).max(99),
	gold: e.int().min(0).max(99),
	ore: e.int().min(0).max(99)
}), ue = e.object({
	id: e.string().max(24),
	col: e.int().min(0).max(40),
	row: e.int().min(0).max(40),
	cover: e.boolean().optional(),
	numberOverlay: e.object({
		id: e.string().max(24),
		col: e.int().min(0).max(40),
		row: e.int().min(0).max(40)
	}).optional()
}), de = e.record(e.string().regex(/^\d{1,2}\.\d{1,2}$/), e.enum(["heart", "progress"])), C = e.partialRecord(e.enum(["3a", "3b"]), e.literal("1E")), w = e.object({
	op: e.enum(/* @__PURE__ */ "res.loseRes.hap.place.card.story.milestone.removeMilestone.removeMilestoneExact.removeSticker.upset.removeUpset.progress.extraAction.skipAction.pickRes.pickCard.pickPlace.pickLose.exchange.branch.discardCard.discardEvent.ask.empty.invokeCard.cardSticker.storySticker.cardFood.clearCardFood.discount.freeCards.coverMilestoneIcon.removeRedMilestone.clock.villageName.pickTarget.special.cardStory.puzzle.villageNameRoll.none".split(".")),
	res: le.partial().optional(),
	n: e.int().min(-99).max(99).optional(),
	code: e.string().max(24).optional(),
	key: e.string().max(40).optional(),
	pick: e.array(e.string().max(24)).max(8).optional(),
	allow: e.boolean().optional(),
	must: e.record(e.string(), e.union([
		e.boolean(),
		e.int(),
		e.string().max(8)
	])).optional(),
	fullCover: e.boolean().optional(),
	soft: e.boolean().optional(),
	onesAs: e.int().min(1).max(6).optional(),
	goldIfValue: e.int().min(0).max(99).optional(),
	storyOnPlace: e.string().max(12).optional()
}), fe = e.enum([
	"starting",
	"morning",
	"choice",
	"afternoon",
	"placing",
	"yearEnd",
	"done"
]), T = e.tuple([e.string(), e.string()]), E = e.object({
	kind: e.enum([
		"place",
		"pickRes",
		"pickCard",
		"pickPlace",
		"pickOpt",
		"exchange",
		"clock",
		"name",
		"puzzle"
	]),
	code: e.string().optional(),
	n: e.int().optional(),
	cover: e.boolean().optional(),
	allow: e.boolean().optional(),
	pick: e.array(e.string()).max(8).optional(),
	must: e.record(e.string(), e.union([
		e.boolean(),
		e.int(),
		e.string().max(8)
	])).optional(),
	fullCover: e.boolean().optional(),
	soft: e.boolean().optional(),
	storyOnPlace: e.string().max(12).optional()
}), pe = e.object({
	version: e.literal(1),
	campaignId: e.string().max(100),
	serial: e.int().nonnegative(),
	owner: e.string(),
	seed: e.number(),
	cursor: e.int().nonnegative(),
	side: e.enum(["A", "B"]),
	year: e.int().min(1).max(10),
	phase: fe,
	resources: le,
	happiness: e.int().min(0).max(30),
	action: e.int().min(-1).max(4).default(0),
	upset: e.int().min(0).max(99).default(0),
	progress: e.int().min(0).max(99).default(0),
	placed: e.array(ue).max(240),
	startingPairs: e.array(e.string()).max(8),
	inPlay: e.array(e.string()).max(40),
	deck: e.array(e.string()).max(24),
	discard: e.array(e.string()).max(240),
	currentEvent: e.string().nullable(),
	queue: e.array(w).max(120),
	prompt: E.nullable(),
	after: e.enum([
		"afternoon",
		"yearEnd",
		"morning"
	]).nullable(),
	yearEnding: e.boolean().default(!1),
	yearEndQueue: e.array(e.string().max(40)).max(160).default([]),
	catalog: e.array(e.string()).max(80),
	story: e.array(e.string()).max(240),
	milestones: e.array(e.string()).max(80),
	cardStickers: e.record(e.string(), e.object({
		heart: e.int().min(0).max(99).default(0),
		progress: e.int().min(0).max(99).default(0)
	})).default({}),
	storyEntryStickers: de.default({}),
	cardAttachments: C.default({}),
	cardFood: e.record(e.string(), e.int().min(0).max(3)).default({}),
	cardSpaces: e.record(e.string(), e.array(e.string().max(8)).max(24)).default({}),
	bridge: e.boolean().default(!1),
	cardDiscount: e.int().min(0).max(99).default(0),
	cardDiscountTarget: e.string().max(40).nullable().default(null),
	freeCardActions: e.boolean().default(!1),
	villageName: e.string().max(40).nullable().default(null),
	coveredMilestoneIcons: e.array(e.object({
		milestone: e.string().max(60),
		icon: e.enum(["star", "gold"])
	})).max(80).default([]),
	upsetMarks: e.array(e.string().max(24)).max(99).default([]),
	log: e.array(T).max(120)
}), D = e.object({
	checkpoint: pe.nullable().default(null),
	side: e.enum(["A", "B"]).default("A")
}).prefault({}), O = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("placeStarting"),
		id: e.string().max(24),
		col: e.int(),
		row: e.int()
	}),
	e.object({
		type: e.literal("placePending"),
		col: e.int(),
		row: e.int()
	}),
	e.object({ type: e.literal("skipPlace") }),
	e.object({ type: e.literal("draw") }),
	e.object({
		type: e.literal("choice"),
		opt: e.enum([
			"a",
			"b",
			"c"
		])
	}),
	e.object({
		type: e.literal("resolvePrompt"),
		key: e.string().max(40)
	}),
	e.object({
		type: e.literal("useSticker"),
		code: e.string().max(24)
	}),
	e.object({
		type: e.literal("useCard"),
		key: e.string().max(40)
	}),
	e.object({
		type: e.literal("cardSticker"),
		label: e.string().max(16),
		kind: e.enum(["heart", "progress"])
	}),
	e.object({
		type: e.literal("pageSticker"),
		page: e.string().max(2),
		kind: e.enum(["heart", "progress"])
	}),
	e.object({
		type: e.literal("birdWatch"),
		label: e.string().max(16)
	}),
	e.object({
		type: e.literal("readPrev"),
		entry: e.string().max(12)
	}),
	e.object({
		type: e.literal("useKeep"),
		id: e.string().max(24),
		key: e.string().max(40)
	}),
	e.object({ type: e.literal("endTurn") }),
	e.object({ type: e.literal("endYear") }),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), k = e.object({
	key: e.enum([
		"a",
		"b",
		"c"
	]),
	label: T,
	enabled: e.boolean()
}), A = e.object({
	key: e.string().max(40),
	label: T,
	enabled: e.boolean()
}), j = e.object({
	id: e.string(),
	key: e.string(),
	label: T,
	enabled: e.boolean()
}), me = e.object({
	id: e.string(),
	code: e.string(),
	story: e.string().optional(),
	card: e.enum(["3a", "3b"]).optional(),
	label: T,
	enabled: e.boolean()
}), he = e.object({
	campaignId: e.string(),
	side: e.enum(["A", "B"]),
	year: e.int(),
	phase: e.enum([
		"starting",
		"morning",
		"choice",
		"afternoon",
		"placing",
		"yearEnd",
		"done"
	]),
	resources: le,
	happiness: e.int(),
	action: e.int(),
	upset: e.int(),
	progress: e.int(),
	placed: e.array(ue),
	startingPairs: e.array(e.string()),
	deckCount: e.int(),
	discard: e.array(e.string()),
	currentEvent: e.string().nullable(),
	inPlay: e.array(e.string()),
	prompt: E.nullable(),
	promptOptions: e.array(A),
	catalog: e.array(e.string()),
	story: e.array(e.string()),
	milestones: e.array(e.string()),
	cardStickers: e.record(e.string(), e.object({
		heart: e.int(),
		progress: e.int()
	})),
	storyEntryStickers: de,
	cardAttachments: C,
	cardFood: e.record(e.string(), e.int()),
	cardSpaces: e.record(e.string(), e.array(e.string())),
	bridge: e.boolean(),
	cardDiscount: e.int(),
	cardDiscountTarget: e.string().nullable(),
	freeCardActions: e.boolean(),
	villageName: e.string().nullable(),
	coveredMilestoneIcons: e.array(e.object({
		milestone: e.string(),
		icon: e.enum(["star", "gold"])
	})),
	choices: e.array(k),
	keepActions: e.array(j),
	catalogActions: e.array(j),
	stickerActions: e.array(me),
	ending: e.string().nullable(),
	mapIcons: le,
	log: e.array(T)
}), M = e.object({ checkpoint: pe.nullable() }), N = Object.fromEntries([
	{
		label: "3a",
		file: "catalog/c3a.webp",
		entry: {
			place: "9C",
			cover: !0,
			must: { number: "3" }
		},
		actions: [{
			label: {
				zh: "拾取落枝",
				en: "GATHER FALLEN BRANCHES"
			},
			do: { res: { wood: 1 } }
		}, {
			label: {
				zh: "寻找木柴（1 食物）",
				en: "HUNT FOR WOOD (1 food)"
			},
			cost: { food: 1 },
			do: { dice: [
				{
					on: [1],
					do: { res: { wood: 1 } }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { wood: 2 } }
				},
				{
					on: [5],
					do: { res: { wood: 3 } }
				},
				{
					on: [6],
					do: { story: "6.2" }
				}
			] }
		}]
	},
	{
		label: "2",
		file: "catalog/c2.webp",
		entry: { place: "6B" },
		action: {
			label: {
				zh: "建造工厂",
				en: "BUILD FACTORY"
			},
			do: {
				place: "11R",
				cover: !0
			},
			discard: !0
		}
	},
	{
		label: "1",
		file: "catalog/c1.webp",
		name: {
			zh: "迪尔",
			en: "DILL"
		},
		entry: { place: "8A" },
		action: {
			label: {
				zh: "种植黄瓜地",
				en: "PLANT CUCUMBER PATCH"
			},
			do: { place: "6M" },
			discard: !0
		}
	},
	{
		label: "8",
		file: "catalog/c8.webp",
		entry: { place: "10A" },
		actions: [{
			label: {
				zh: "领养农场动物（放置 2 枚 11B 农场动物贴纸；若已放置 4 枚，弃掉此牌并获得卡牌 17）",
				en: "ADOPT FARM ANIMALS (place 2 farm animal stickers 11B; then, if 4 have been placed, discard this and gain card 17)"
			},
			do: {
				place: "11B",
				n: 2
			},
			followUp: "cat8a"
		}, {
			label: {
				zh: "购买种子（放置贴纸 6N 或 6P；若两者均已放置，弃掉此牌并获得卡牌 16）",
				en: "BUY SEEDS (place sticker 6N or 6P; then, if both have been placed, discard this and gain card 16)"
			},
			do: { pickPlace: ["6N", "6P"] },
			followUp: "cat8b"
		}]
	},
	{
		label: "7",
		file: "catalog/c7.webp",
		entry: { place: "6F" },
		action: {
			label: {
				zh: "竞选市长（放置 2 枚 11C 政治贴纸；可花费 1 金币再放 1 枚；随后若认为支持足够，弃掉此牌并阅读 35.2，否则保留此牌）",
				en: "RUN FOR MAYOR (place 2 political stickers 11C; you may spend 1 gold to place 1 additional; then, if you think you have enough support, discard this and read 35.2, otherwise keep this in play)"
			},
			do: { seq: [
				{
					place: "11C",
					n: 2
				},
				{ ask: "cat7extra" },
				{ ask: "cat7end" }
			] }
		}
	},
	{
		label: "13",
		file: "catalog/c13.webp",
		name: {
			zh: "市长抱负",
			en: "MAYOR AMBITION"
		},
		entry: { milestone: "Mayor|bronze" },
		actions: [{
			label: {
				zh: "竞选州长",
				en: "RUN FOR GOVERNOR"
			},
			do: { story: "9.3" },
			if: { minHearts: 5 }
		}, {
			label: {
				zh: "征税（若居民≥9，阅读 22.8）",
				en: "RAISE TAXES (if 9+ residents, read 22.8)"
			},
			do: { story: "22.8" },
			if: { minResidents: 9 },
			followUp: "story22.8"
		}]
	},
	{
		label: "6",
		file: "catalog/c6.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "解读语言（将此牌对应格位全部放上 1D 贴纸；若这些贴纸已放置，则改为放置全部 5P 贴纸）",
				en: "DECIPHER LANGUAGE (place all 1D stickers on the proper spaces of this card; if they are already placed, instead place all 5P stickers)"
			},
			do: { place: "1D" },
			followUp: "cat6"
		}
	},
	{
		label: "5",
		file: "catalog/c5.webp",
		entry: { seq: [{ removeMilestone: "Politics 1" }, { milestone: "Governor|silver" }] },
		action: {
			label: {
				zh: "宏大抱负（依此牌上的贴纸数量阅读故事：0 枚阅读 25.4；1 枚阅读 25.5；2 枚阅读 25.6）",
				en: "GRAND AMBITION (read the story based on the number of stickers on this card: 0 read 25.4; 1 read 25.5; 2 read 25.6)"
			},
			do: { cardStory: {
				label: "5",
				entries: [
					"25.4",
					"25.5",
					"25.6"
				]
			} }
		}
	},
	{
		label: "4",
		file: "catalog/c4.webp",
		entry: {
			place: "9C",
			cover: !0,
			must: { number: "22.1" }
		}
	},
	{
		label: "3b",
		file: "catalog/c3b.webp",
		entry: {
			place: "9C",
			cover: !0,
			must: { number: "3" }
		},
		actions: [{
			label: {
				zh: "拾取落枝",
				en: "GATHER FALLEN BRANCHES"
			},
			do: { res: { wood: 1 } }
		}, {
			label: {
				zh: "寻找木柴（1 食物）",
				en: "HUNT FOR WOOD (1 food)"
			},
			cost: { food: 1 },
			do: { dice: [
				{
					on: [1],
					do: { res: { wood: 1 } }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: { wood: 2 } }
				},
				{
					on: [5],
					do: { res: { wood: 3 } }
				},
				{
					on: [6],
					do: { story: "6.2" }
				}
			] }
		}]
	},
	{
		label: "12b",
		file: "catalog/c12b.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "钓鱼（掷骰：1 获得 1 食物并弃掉此牌上的所有食物；2-6 从供应区在此牌上放置 1 食物（上限 3），然后二选一：收线，阅读 35.1；继续钓，重新掷骰）",
				en: "GO FISHING (roll the die: 1 gain 1 food and discard all food from this card; 2-6 place 1 food on this card from the supply (limit 3), then choose one: reel in the fish, read 35.1; keep fishing, roll the die again)"
			},
			do: { dice: [{
				on: [1],
				do: { res: { food: 1 } }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [{ res: { food: 1 } }, { story: "35.1" }] }
			}] }
		}
	},
	{
		label: "12a",
		file: "catalog/c12a.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "钓鱼（掷骰：1 获得 1 食物并弃掉此牌上的所有食物；2-6 从供应区在此牌上放置 1 食物（上限 3），然后二选一：收线，阅读 36.1；继续钓，重新掷骰）",
				en: "GO FISHING (roll the die: 1 gain 1 food and discard all food from this card; 2-6 place 1 food on this card from the supply (limit 3), then choose one: reel in the fish, read 36.1; keep fishing, roll the die again)"
			},
			do: { dice: [{
				on: [1],
				do: { res: { food: 1 } }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [{ res: { food: 1 } }, { story: "36.1" }] }
			}] }
		}
	},
	{
		label: "11",
		file: "catalog/c11.webp",
		entry: { place: "6G" },
		action: {
			label: {
				zh: "建造蜂房",
				en: "BUILD APIARY"
			},
			do: {
				place: "5B",
				cover: !0
			},
			discard: !0,
			cost: {
				wood: 1,
				food: 1
			}
		},
		endOfYear: {
			discard: !0,
			auto: {
				place: "11N",
				cover: !0
			}
		}
	},
	{
		label: "10",
		file: "catalog/c10.webp",
		entry: { place: "7B" },
		action: {
			label: {
				zh: "出售木工制品（获得 2 金币并放置 1 枚 11D 木工贴纸；若已放置 3 枚，弃掉此牌）",
				en: "SELL CARPENTRY (gain 2 gold and place 1 carpentry sticker 11D; then, if 3 have been placed, discard this)"
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "11D" }] },
			followUp: "cat10"
		}
	},
	{
		label: "9",
		file: "catalog/c9.webp",
		entry: { place: "6D" },
		action: {
			label: {
				zh: "买卖（将至多 3 份资源兑换为除矿石外任意类型的资源）",
				en: "BUY AND SELL (exchange up to 3 resources for resources of any type(s) except ore)"
			},
			do: { exchange: { n: 3 } }
		}
	},
	{
		label: "25",
		file: "catalog/c25.webp",
		entry: { place: "8P" },
		action: {
			label: {
				zh: "出售玩具（获得 3 金币并放置 1 枚 11Q 玩具贴纸；若已放置 2 枚，弃掉此牌并获得 1 幸福）",
				en: "SELL TOY (gain 3 gold and place 1 toy sticker 11Q; then, if 2 have been placed, discard this and gain 1 happiness)"
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "11Q" }] },
			followUp: "cat25"
		}
	},
	{
		label: "24",
		file: "catalog/c24.webp",
		entry: { milestone: "Famous Baker|silver" },
		action: {
			label: {
				zh: "出售巨型蛋糕（获得 2 金币并放置 1 枚 12G 蛋糕贴纸，可放在地图或其他贴纸上；若已放置 2 枚，弃掉此牌并获得卡牌 28）",
				en: "SELL GIANT CAKE (gain 2 gold and place 1 cake sticker 12G, on the map or on another sticker; then, if 2 have been placed, discard this and gain card 28)"
			},
			do: { seq: [{ res: { gold: 2 } }, {
				place: "12G",
				cover: !0
			}] },
			followUp: "cat24"
		}
	},
	{
		label: "23",
		file: "catalog/c23.webp",
		entry: { none: !0 },
		action: {
			label: {
				zh: "出售异域宠物（获得 2 金币并放置 1 枚 12F 异域宠物贴纸；若已放置 2 枚，弃掉此牌并获得卡牌 57）",
				en: "SELL EXOTIC PET (gain 2 gold and place 1 exotic pet sticker 12F; then, if 2 have been placed, discard this and gain card 57)"
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "12F" }] },
			followUp: "cat23"
		}
	},
	{
		label: "16",
		file: "catalog/c16.webp",
		name: {
			zh: "农场帮手雄心",
			en: "FARM HAND AMBITION"
		},
		entry: { milestone: "Farm Hand|bronze" },
		actions: [{
			label: {
				zh: "蔬果（若地图上苹果图标≥7，弃掉此牌并获得卡牌 26）",
				en: "FRUITS AND VEGGIES (if 7+ apple icons on the map, discard this and gain card 26)"
			},
			do: { card: "26" },
			discard: !0,
			if: { minMapRes: { food: 7 } }
		}, {
			label: {
				zh: "毛茸茸的朋友（若地图上的动物贴纸≥5，弃掉此牌并获得卡牌 27；只计入独立动物贴纸，不含其他贴纸的一部分）",
				en: "FURRY FRIENDS (if 5+ animal stickers on the map, discard this and gain card 27; only count each animal that is on its own sticker, not part of another sticker)"
			},
			do: { card: "27" },
			discard: !0,
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 5
			} }
		}]
	},
	{
		label: "15",
		file: "catalog/c15.webp",
		entry: { milestone: "Runner Up|bronze" },
		actions: [{
			label: {
				zh: "变得更受欢迎",
				en: "BECOME MORE POPULAR"
			},
			do: { story: "27.1" },
			if: { minHearts: 6 }
		}, {
			label: {
				zh: "夺取权力（若居民≥8，阅读 27.7）",
				en: "SEIZE POWER (if 8+ residents, read 27.7)"
			},
			do: { story: "27.7" },
			if: { minResidents: 8 }
		}]
	},
	{
		label: "14",
		file: "catalog/c14.webp",
		name: {
			zh: "独裁者的野心",
			en: "DICTATOR AMBITION"
		},
		entry: { milestone: "Dictator|bronze" },
		actions: [{
			label: {
				zh: "收紧掌控（若居民不少于 7，阅读 22.8）",
				en: "TIGHTEN YOUR GRIP (if 7+ residents, read 22.8)"
			},
			do: { story: "22.8" },
			if: { minResidents: 7 },
			followUp: "story22.8"
		}, {
			label: {
				zh: "竞选州长（若幸福不少于 7，阅读 9.3）",
				en: "RUN FOR GOVERNOR (if 7+ happiness, read 9.3)"
			},
			do: { story: "9.3" },
			if: { minHearts: 7 }
		}]
	},
	{
		label: "31",
		file: "catalog/c31.webp",
		action: {
			label: {
				zh: "破解密码（按照这些卡牌上隐藏的指示操作；如需提示，阅读 33.9）",
				en: "CRACK THE CODE (follow the instructions hidden on these cards; if you need a hint, read 33.9)"
			},
			do: { puzzle: {
				label: "31",
				kind: "story"
			} }
		}
	},
	{
		label: "30",
		file: "catalog/c30.webp",
		entry: {
			place: "9C",
			cover: !0,
			must: { number: "10.1" },
			milestone: "Matchmaker|silver"
		},
		action: {
			label: {
				zh: "询问感情状况（按此卡上的贴纸数量阅读对应故事：0 张阅读 11.6，1 张阅读 12.1，2 张阅读 12.2，3 张阅读 12.3）",
				en: "ASK ABOUT RELATIONSHIP (read the story based on the number of stickers on this card: 0→11.6, 1→12.1, 2→12.2, 3→12.3)"
			},
			do: { cardStory: {
				label: "30",
				entries: [
					"11.6",
					"12.1",
					"12.2",
					"12.3"
				]
			} }
		}
	},
	{
		label: "22",
		file: "catalog/c22.webp",
		action: {
			label: {
				zh: "破解密码（解开谜题并阅读它指向的故事；若故事不以「Using.」开头，则答案有误；如需提示，阅读 11.7）",
				en: "CRACK THE CODE (solve the puzzle and read the story it points to; if the story does not start with the word \"Using.\", you are incorrect; if you need a hint, read 11.7)"
			},
			do: { puzzle: {
				label: "22",
				kind: "story"
			} }
		}
	},
	{
		label: "21",
		file: "catalog/c21.webp",
		entry: { place: "4D" },
		action: {
			label: {
				zh: "建造大房子",
				en: "BUILD LARGE HOME"
			},
			do: { place: "4E" },
			cost: { gold: 2 },
			discard: !0
		}
	},
	{
		label: "20",
		file: "catalog/c20.webp",
		entry: { place: "4B" },
		action: {
			label: {
				zh: "出售巨型糕点（若已有 2 张放置，弃置此卡并获得卡 24）",
				en: "SELL GIANT PASTRY (if 2 have been placed, discard this and gain card 24)"
			},
			do: { seq: [{ res: { gold: 2 } }, {
				place: "11F",
				n: 1
			}] },
			cost: { food: 1 },
			followUp: "cat20"
		}
	},
	{
		label: "36",
		file: "catalog/c36.webp",
		entry: { place: "10F" },
		action: {
			label: {
				zh: "准时赴约（在现实中查看时钟，精确匹配分针位置，阅读上方对应的故事。例如 4:00 时阅读 28.2；若是 4:01，则不能执行此行动）",
				en: "A TIMELY APPOINTMENT (check the clock in real life; read the story above matching the minute hand exactly. For example, at 4:00 read 28.2; at 4:01 you cannot perform this action)"
			},
			do: { clock: !0 }
		}
	},
	{
		label: "35b",
		file: "catalog/c35b.webp",
		entry: { place: "7F" },
		action: {
			label: {
				zh: "探索矿井（选择此卡上与爱心相邻的一个格子，阅读该格所示的故事条目）",
				en: "EXPLORE THE MINE (choose a space on this card adjacent to a heart; read the story entry shown in that space)"
			},
			do: { story: "35.6" }
		}
	},
	{
		label: "35a",
		file: "catalog/c35a.webp",
		entry: { place: "7F" },
		action: {
			label: {
				zh: "探索矿井（选择此卡上与爱心相邻的一个格子，阅读该格所示的故事条目）",
				en: "EXPLORE THE MINE (choose a space on this card adjacent to a heart; read the story entry shown in that space)"
			},
			do: { story: "35.6" }
		}
	},
	{
		label: "29",
		file: "catalog/c29.webp",
		entry: { milestone: "Dating|bronze" },
		action: {
			label: {
				zh: "与农夫迪尔约会（按此卡上的贴纸数量阅读对应故事：0 张阅读 10.7，1 张阅读 11.1，2 张阅读 11.2，3 张阅读 11.3，4 张阅读 11.4，5 张阅读 11.5）",
				en: "DATE FARMER DILL (read the story based on the number of stickers on this card: 0→10.7, 1→11.1, 2→11.2, 3→11.3, 4→11.4, 5→11.5)"
			},
			do: { cardStory: {
				label: "29",
				entries: [
					"10.7",
					"11.1",
					"11.2",
					"11.3",
					"11.4",
					"11.5"
				]
			} }
		}
	},
	{
		label: "28",
		file: "catalog/c28.webp",
		action: {
			label: {
				zh: "烘焙比赛（你希望在这场比赛中投入多少？花费 0 至 5 份食物，然后阅读 26.6）",
				en: "BAKING COMPETITION (how much do you want to invest in this competition? Spend 0 to 5 food, then read 26.6)"
			},
			do: { story: "26.6" }
		}
	},
	{
		label: "27",
		file: "catalog/c27.webp",
		entry: {
			milestone: "Veteran Rancher|silver",
			removeMilestone: "Farming 1"
		},
		action: {
			label: {
				zh: "建造奶牛场",
				en: "BUILD DAIRY FARM"
			},
			do: { place: "10D" },
			cost: {
				wood: 4,
				gold: 3
			},
			discard: !0
		}
	},
	{
		label: "26",
		file: "catalog/c26.webp",
		entry: {
			milestone: "Green Thumb|silver",
			removeMilestone: "Farming 1"
		},
		actions: [{
			label: {
				zh: "建造筒仓",
				en: "BUILD SILO"
			},
			do: { seq: [{ res: { food: 1 } }, { place: "4X" }] },
			cost: { gold: 3 }
		}, {
			label: {
				zh: "供养民众（若已建造筒仓，弃置此卡并将「绿手指」里程碑替换为「农业大师」（金））",
				en: "FEED THE PEOPLE (if you have built the Silo, discard this and cover the Green Thumb milestone with Master of Agriculture (gold))"
			},
			do: { seq: [{ removeMilestone: "Green Thumb" }, { milestone: "Master of Agriculture|gold" }] },
			cost: { food: 5 },
			discard: !0,
			if: { hasSticker: "4X" }
		}]
	},
	{
		label: "42",
		file: "catalog/c42.webp",
		entry: { none: !0 }
	},
	{
		label: "41",
		file: "catalog/c41.webp",
		entry: { place: "8H" },
		action: {
			label: {
				zh: "观星（阅读上方一个没有贴纸的故事；若此卡已有 4 张贴纸，弃置此卡）",
				en: "STARGAZING (read a story above with no sticker on it; if there are 4 stickers on this card, discard it)"
			},
			do: { story: "26.1" }
		}
	},
	{
		label: "34",
		file: "catalog/c34.webp",
		entry: { place: "7H" }
	},
	{
		label: "33",
		file: "catalog/c33.webp",
		entry: {
			place: "8K",
			cover: !0
		},
		action: {
			label: {
				zh: "买卖（最多交换 4 个资源，换取任意类型的资源；若要以这种方式获得矿石，须用 2 个资源换取 1 个矿石）",
				en: "BUY AND SELL (exchange up to 4 resources for resources of any type(s); to gain ore this way, you must exchange 2 resources for 1 ore)"
			},
			do: { exchange: {
				n: 4,
				ore: !0
			} }
		}
	},
	{
		label: "32",
		file: "catalog/c32.webp",
		entry: { place: "4K" },
		action: {
			label: {
				zh: "购买渔具（从以下二选一购买：闪亮假饵——在卡 12A 或 12B 上放置贴纸 1B；精美鱼竿——在卡 12A 或 12B 上放置贴纸 1C；两者都购买后，弃置此卡）",
				en: "BUY FISHING GEAR (buy 1 of the following: Shiny Lure—place sticker 1B on card 12A or 12B; Fancy Pole—place sticker 1C on card 12A or 12B; after buying both, discard this)"
			},
			do: { pickPlace: ["1B", "1C"] },
			cost: { gold: 1 }
		}
	},
	{
		label: "40",
		file: "catalog/c40.webp",
		entry: { place: "4R" },
		action: {
			label: {
				zh: "出售衣物（若已有 2 张放置，弃置此卡并获得卡 49）",
				en: "SELL CLOTHING (if 2 have been placed, discard this and gain card 49)"
			},
			do: { seq: [{ res: { gold: 1 } }, {
				place: "3A",
				cover: !0
			}] },
			followUp: "cat40"
		}
	},
	{
		label: "39",
		file: "catalog/c39.webp",
		name: {
			zh: "观鸟 3",
			en: "BIRDWATCHING 3"
		},
		entry: {
			milestone: "Avian Enthusiast|silver",
			removeMilestone: "Birder"
		},
		action: {
			label: {
				zh: "观鸟 3（随时：地图上出现与此卡相同的鸟时，在此卡对应鸟上放置爱心贴纸；若此卡 4 只鸟都有贴纸，弃置此卡并将「鸟类爱好者」里程碑替换为「鸟类学家」（金））",
				en: "BIRDWATCHING 3 (at any time: if you see a bird on the map matching a bird on this card, place a heart sticker on that bird on this card; if all 4 birds on this card have a sticker, discard this and cover the Avian Enthusiast milestone with Ornithologist (gold))"
			},
			do: { seq: [{ removeMilestone: "Avian Enthusiast" }, { milestone: "Ornithologist|gold" }] },
			discard: !0
		}
	},
	{
		label: "38",
		file: "catalog/c38.webp",
		name: {
			zh: "观鸟 2",
			en: "BIRDWATCHING 2"
		},
		entry: { milestone: "Birder|bronze" }
	},
	{
		label: "48",
		file: "catalog/c48.webp",
		entry: { place: "8D" }
	},
	{
		label: "47",
		file: "catalog/c47.webp",
		entry: { place: "4W" },
		action: {
			label: {
				zh: "递送包裹：在地图上选择一位居民和一枚礼物贴纸（12S）。两者都选定后，阅读上方该居民对应的故事条目。然后，若本卡上已有三枚贴纸，阅读故事24.3。",
				en: "Deliver Package: Choose a resident on the map and a gift sticker (12S). After choosing both, read the resident's story entry above. Then, if 3 stickers are on this card, read 24.3."
			},
			do: { place: "12S" },
			followUp: "cat47"
		}
	},
	{
		label: "46",
		file: "catalog/c46.webp",
		entry: { place: "4P" },
		action: {
			label: {
				zh: "出售古玩：获得三枚金币并放置一枚古玩贴纸（12Q）。然后，若已放置两枚，弃掉本卡。",
				en: "Sell Curios: Gain 3 gold and place 1 curio sticker (12Q). Then, if 2 have been placed, discard this."
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "12Q" }] },
			followUp: "cat46"
		}
	},
	{
		label: "37",
		file: "catalog/c37.webp",
		name: {
			zh: "观鸟 1",
			en: "BIRDWATCHING 1"
		},
		entry: { place: "4Q" }
	},
	{
		label: "54",
		file: "catalog/c54.webp",
		entry: { place: "8R" },
		action: {
			label: {
				zh: "建造玩具店：弃掉本卡并获得牌25。",
				en: "Build Toy Shop: Discard this and gain card 25."
			},
			do: { card: "25" },
			cost: {
				wood: 2,
				ore: 1
			},
			discard: !0
		}
	},
	{
		label: "53",
		file: "catalog/c53.webp",
		entry: { place: "8T" },
		action: {
			label: {
				zh: "建造露天舞台：弃掉本卡并放置贴纸8Q。",
				en: "Build Outdoor Stage: Discard this and place sticker 8Q."
			},
			do: { place: "8Q" },
			cost: {
				wood: 2,
				gold: 2
			},
			discard: !0
		}
	},
	{
		label: "52",
		file: "catalog/c52.webp",
		entry: { seq: [{ discardCard: "48" }, {
			place: "10H",
			cover: !0,
			must: { number: "28.6" }
		}] }
	},
	{
		label: "45",
		file: "catalog/c45.webp",
		action: {
			label: {
				zh: "循迹追踪：解开谜题并获得它指向的牌。如果该牌的第一个词不是“The”，则答案不正确。如果需要提示，阅读故事29.9。",
				en: "Follow the Clues: Solve the puzzle and gain the card it points to. If the first word on the card is not \"The,\" you are incorrect. If you need a hint, read 29.9."
			},
			do: { puzzle: {
				label: "45",
				kind: "card"
			} }
		}
	},
	{
		label: "44",
		file: "catalog/c44.webp",
		action: {
			label: {
				zh: "研究本地传说：根据本卡上的贴纸数量阅读故事：零枚时阅读12.5，一枚时阅读32.8，两枚时阅读30.7，三枚时阅读26.7。",
				en: "Research Local Legend: Read the story based on the number of stickers on this card: 0: 12.5; 1: 32.8; 2: 30.7; 3: 26.7."
			},
			do: { cardStory: {
				label: "44",
				entries: [
					"12.5",
					"32.8",
					"30.7",
					"26.7"
				]
			} }
		}
	},
	{
		label: "43",
		file: "catalog/c43.webp",
		endOfYear: {
			discard: !0,
			auto: { seq: [{ place: "6U" }, { hap: 1 }] }
		}
	},
	{
		label: "51",
		file: "catalog/c51.webp",
		entry: { seq: [
			{ removeMilestone: "Politics" },
			{ milestone: "Tyrant|silver" },
			{ milestone: "Unrest|red" }
		] },
		action: {
			label: {
				zh: "成为君主：根据本卡上的贴纸数量阅读故事：零枚时阅读25.3，一枚时阅读25.1，两枚时阅读25.2。",
				en: "Becoming Monarch: Read the story based on the number of stickers on this card: 0: 25.3; 1: 25.1; 2: 25.2."
			},
			do: { cardStory: {
				label: "51",
				entries: [
					"25.3",
					"25.1",
					"25.2"
				]
			} }
		}
	},
	{
		label: "50",
		file: "catalog/c50.webp",
		entry: { seq: [
			{ milestone: "Treasure Hunter|bronze" },
			{ discardCard: "44" },
			{ discardCard: "45" }
		] },
		action: {
			label: {
				zh: "寻找迷宫：解开谜题以阅读故事□.○。如果故事不是以“From”一词开头，则答案不正确。如果需要提示，阅读故事34.7。",
				en: "Find the Maze: Solve the puzzle to read story □.○. If the story does not start with the word \"From,\" you are incorrect. If you need a hint, read 34.7."
			},
			do: { puzzle: {
				label: "50",
				kind: "story"
			} }
		}
	},
	{
		label: "49",
		file: "catalog/c49.webp",
		entry: { milestone: "Fashionable|silver" },
		action: {
			label: {
				zh: "出售帽子：获得两枚金币并放置一枚帽子贴纸（12K）。然后，若已放置三枚（来自本卡和／或其他效果），弃掉本卡并阅读故事28.9。",
				en: "Sell Hat: Gain 2 gold and place a hat sticker (12K). Then, if 3 have been placed (from this and/or other effects), discard this and read 28.9."
			},
			do: { seq: [{ res: { gold: 2 } }, { place: "12K" }] },
			followUp: "cat49"
		}
	},
	{
		label: "57",
		file: "catalog/c57.webp",
		entry: { milestone: "Pet Lover|silver" },
		action: {
			label: {
				zh: "建造宠物收容所：弃掉本卡并放置贴纸4U。",
				en: "Build Pet Shelter: Discard this and place sticker 4U."
			},
			do: { place: "4U" },
			cost: {
				gold: 3,
				ore: 1
			},
			discard: !0
		}
	},
	{
		label: "56",
		file: "catalog/c56.webp",
		entry: { place: "8B" },
		action: {
			label: {
				zh: "出售巨型糖果：获得三枚金币并放置一枚糖果贴纸（11H，可放在地图上或另一张贴纸上）。然后，若已放置两枚，弃掉本卡并获得一点幸福。",
				en: "Sell Giant Candy: Gain 3 gold and place 1 candy sticker (11H) (on the map or on another sticker). Then, if 2 have been placed, discard this and gain 1 happiness."
			},
			do: { seq: [{ res: { gold: 3 } }, { place: "11H" }] },
			cost: { food: 1 },
			followUp: "cat56"
		}
	},
	{
		label: "55",
		file: "catalog/c55.webp",
		name: {
			zh: "名厨雄心",
			en: "Chef Ambition"
		},
		entry: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "15.9" }
		}, { milestone: "Famous Chef|silver" }] },
		action: {
			label: {
				zh: "精通甜点：弃掉本卡并阅读故事25.7。此花费为四枚食物，地图上每张蛋糕贴纸（12G）使其减少一枚食物。",
				en: "Mastering Dessert: Discard this and read 25.7. This cost is 4 food; reduce it by 1 food for each cake sticker (12G) on the map."
			},
			do: { story: "25.7" },
			cost: { food: 4 },
			discard: !0,
			reducePer: {
				code: "12G",
				key: "food"
			}
		}
	},
	{
		label: "19",
		file: "catalog/c19.webp",
		entry: { place: "4A" },
		action: {
			label: {
				zh: "出售宠物：获得一枚金币并放置两枚宠物贴纸（11G）。然后，若已放置四枚，弃掉本卡并获得牌23。",
				en: "Sell Pets: Gain 1 gold and place 2 pet stickers (11G). Then, if 4 have been placed, discard this and gain card 23."
			},
			do: { seq: [{ res: { gold: 1 } }, {
				place: "11G",
				n: 2
			}] },
			followUp: "cat19"
		}
	},
	{
		label: "18",
		file: "catalog/c18.webp",
		entry: {
			place: "9C",
			cover: !0,
			must: { number: "18" }
		}
	},
	{
		label: "17",
		file: "catalog/c17.webp",
		name: {
			zh: "牧场主雄心",
			en: "Rancher Ambition"
		},
		entry: { milestone: "Rancher|bronze" },
		actions: [{
			label: {
				zh: "蔬果：如果地图上有五个或更多苹果图标，弃掉本卡并获得牌26。",
				en: "Fruits and Veggies: If 5 or more apple icons on the map, discard this and gain card 26."
			},
			do: { card: "26" },
			if: { minMapRes: { food: 5 } },
			discard: !0
		}, {
			label: {
				zh: "毛茸茸的朋友：如果地图上有七个或更多动物贴纸，弃掉本卡并获得牌27。（只计各自独立贴纸上的动物，不计其他贴纸上的动物。）",
				en: "Furry Friends: If 7 or more animal stickers on the map, discard this and gain card 27. (Only count each animal that is on its own sticker, not part of another sticker.)"
			},
			do: { card: "27" },
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 7
			} },
			discard: !0
		}]
	}
].map((e) => [e.label, e])), ge = {
	"story8.3Tree": [{
		if: { hasLoneTree: !0 },
		do: {
			place: "5Q",
			cover: !0,
			must: { loneTree: !0 }
		}
	}, { do: {
		place: "6Z",
		cover: !0,
		must: { logIcon: !0 }
	} }],
	"story8.5": [{
		if: { hasLoneTree: !0 },
		do: { seq: [
			{ res: { wood: 3 } },
			{ storySticker: {
				entry: "8.5",
				kind: "heart"
			} },
			{
				place: "5Q",
				cover: !0,
				must: { loneTree: !0 }
			}
		] }
	}, { do: { seq: [{ storySticker: {
		entry: "8.5",
		kind: "progress"
	} }, { res: { wood: 1 } }] } }],
	"y3-08b": [{
		if: { minRes: { gold: 1 } },
		do: { loseRes: { gold: 1 } }
	}, { do: { pickLose: {
		n: 1,
		pick: [
			"wood",
			"food",
			"ore"
		]
	} } }],
	"y4-05b": [{
		if: { minUpset: 1 },
		do: { removeUpset: 1 }
	}, { do: { hap: 1 } }],
	"y6-03b": [{
		if: { milestone: "Lucky" },
		do: { res: { gold: 1 } }
	}, { do: { milestone: "Lucky|bronze" } }],
	"y7-03b": [{
		if: { minUpset: 1 },
		do: { removeUpset: 1 }
	}, { do: { hap: 1 } }],
	"y9-02fence": [{
		if: { fenceEnclosedHouse: !0 },
		do: { seq: [{ discardEvent: "y9-02" }, { hap: 1 }] }
	}, { do: { none: !0 } }],
	"story11.4a": [{
		if: { cardStickers: {
			label: "29",
			kind: "heart",
			min: 3
		} },
		do: { cardSticker: {
			label: "29",
			kind: "heart",
			n: 1
		} }
	}, { do: { discardCard: "29" } }],
	"story28.2": [{
		if: { cardStickers: {
			label: "36",
			kind: "progress",
			min: 1
		} },
		do: { seq: [{ milestone: "Secret Spy|silver" }, { branch: "story28.2a" }] }
	}, { do: { extraAction: 1 } }],
	"story28.2a": [{
		if: { cardStickers: {
			label: "36",
			min: 3
		} },
		do: { discardCard: "36" }
	}, { do: { cardSticker: {
		label: "36",
		kind: "progress",
		n: 1
	} } }],
	"story28.3": [{
		if: { cardStickers: {
			label: "36",
			kind: "heart",
			min: 1
		} },
		do: { seq: [{ hap: 1 }, { branch: "story28.3a" }] }
	}, { do: { cardSticker: {
		label: "36",
		kind: "heart",
		n: 1
	} } }],
	"story28.3a": [{
		if: { cardStickers: {
			label: "36",
			min: 3
		} },
		do: { discardCard: "36" }
	}, { do: { cardSticker: {
		label: "36",
		kind: "heart",
		n: 1
	} } }],
	"story28.5": [{
		if: { cardStickers: {
			label: "36",
			kind: "heart",
			min: 1
		} },
		do: { seq: [{ hap: 1 }, { branch: "story28.5a" }] }
	}, { do: { cardSticker: {
		label: "36",
		kind: "heart",
		n: 1
	} } }],
	"story28.5a": [{
		if: { cardStickers: {
			label: "36",
			min: 3
		} },
		do: { discardCard: "36" }
	}, { do: { cardSticker: {
		label: "36",
		kind: "heart",
		n: 1
	} } }],
	"story26.9c": [{
		if: { minUpset: 1 },
		do: { removeUpset: 1 }
	}, { do: { hap: 1 } }],
	"story34.1": [{
		if: { milestone: "Lodge" },
		do: {
			place: "6V",
			cover: !0,
			must: { trees: 2 }
		}
	}, { do: { card: "44" } }],
	y3setup: [{
		if: { milestone: "Hunger" },
		do: { hap: -1 }
	}, { do: { res: { gold: 1 } } }],
	y4setup: [{
		if: { hasSticker: "9L" },
		do: { seq: [{
			place: "7N",
			cover: !0,
			must: { number: "6.4" }
		}, { loseRes: { food: 2 } }] }
	}, { do: { res: { food: 1 } } }],
	y6setup: [{
		if: { milestone: "Lodge" },
		do: { place: "4T" }
	}, { do: { card: "22" } }],
	y7setup: [{
		if: { anyMilestone: ["Degenerate", "Upstanding"] },
		do: { res: { ore: 1 } }
	}, { do: { story: "18.3" } }],
	y9setup: [{
		if: { hasSticker: "8H" },
		do: { res: { gold: 2 } }
	}, { do: { seq: [{ place: "7E" }, { discardEvent: "y6-12" }] } }],
	"y10-07b": [{
		if: { milestone: "President" },
		do: { hap: 1 }
	}, { do: { res: { gold: 1 } } }],
	cat6: [{
		if: { hasSticker: "1D" },
		do: { place: "5P" }
	}, { do: { place: "1D" } }],
	cat8a: [{
		if: { countCode: {
			code: "11B",
			min: 4
		} },
		do: { seq: [{ discardCard: "8" }, { card: "17" }] }
	}],
	cat8b: [{
		if: { allStickers: ["6N", "6P"] },
		do: { seq: [{ discardCard: "8" }, { card: "16" }] }
	}],
	cat10: [{
		if: { countCode: {
			code: "11D",
			min: 3
		} },
		do: { discardCard: "10" }
	}],
	cat19: [{
		if: { countCode: {
			code: "11G",
			min: 4
		} },
		do: { seq: [{ discardCard: "19" }, { card: "23" }] }
	}],
	cat20: [{
		if: { countCode: {
			code: "11F",
			min: 2
		} },
		do: { seq: [{ discardCard: "20" }, { card: "24" }] }
	}],
	cat23: [{
		if: { countCode: {
			code: "12F",
			min: 2
		} },
		do: { seq: [{ discardCard: "23" }, { card: "57" }] }
	}],
	cat24: [{
		if: { countCode: {
			code: "12G",
			min: 2
		} },
		do: { seq: [{ discardCard: "24" }, { card: "28" }] }
	}],
	cat25: [{
		if: { countCode: {
			code: "11Q",
			min: 2
		} },
		do: { seq: [{ discardCard: "25" }, { hap: 1 }] }
	}],
	cat40: [{
		if: { countCode: {
			code: "3A",
			min: 2
		} },
		do: { seq: [{ discardCard: "40" }, { card: "49" }] }
	}],
	cat46: [{
		if: { countCode: {
			code: "12Q",
			min: 2
		} },
		do: { discardCard: "46" }
	}],
	cat47: [{
		if: { countCode: {
			code: "12S",
			min: 3
		} },
		do: { story: "24.3" }
	}],
	cat49: [{
		if: { countCode: {
			code: "12K",
			min: 3
		} },
		do: { seq: [{ discardCard: "49" }, { story: "28.9" }] }
	}],
	cat56: [{
		if: { countCode: {
			code: "11H",
			min: 2
		} },
		do: { seq: [{ discardCard: "56" }, { hap: 1 }] }
	}],
	"story22.8": [{
		if: {
			hasCard: "13",
			countCode: {
				code: "11C",
				min: 3
			}
		},
		do: { seq: [{ discardCard: "13" }, { card: "51" }] }
	}, {
		if: {
			hasCard: "14",
			countCode: {
				code: "11C",
				min: 3
			}
		},
		do: { seq: [{ discardCard: "14" }, { card: "51" }] }
	}],
	"story35.2": [{
		if: { countCode: {
			code: "11C",
			min: 5
		} },
		do: { seq: [{ discardCard: "7" }, { card: "13" }] }
	}, { do: { story: "35.5" } }],
	"story6.4": [{
		if: { milestone: "Lucky" },
		do: { res: { ore: 1 } }
	}, { do: { hap: -1 } }],
	"story9.6": [{
		if: { maxUpset: 0 },
		do: { hap: 1 }
	}, { do: { removeUpset: 1 } }],
	"story10.8": [{
		if: { onNumber: {
			number: "10.8",
			codes: [
				"11B",
				"11G",
				"12F",
				"12H",
				"5A"
			],
			max: 1
		} },
		do: {
			place: "12H",
			must: { number: "10.8" }
		}
	}, { do: { seq: [{
		place: "12J",
		cover: !0,
		must: { number: "10.8" }
	}, { hap: 1 }] } }],
	"story13.7": [{
		if: { cardStickers: {
			label: "p13",
			kind: "heart",
			min: 4
		} },
		do: { milestone: "Honest Company|gold" }
	}, { do: { seq: [{ res: { gold: 2 } }, { milestone: "Greedy Company|silver" }] } }],
	"story14.8": [{
		if: { cardStickers: {
			label: "p14",
			kind: "heart",
			min: 3
		} },
		do: { milestone: "Miracle Medicine|silver" }
	}, { do: { res: { gold: 3 } } }],
	"story18.6": [{
		if: { cardStickers: {
			label: "p18",
			kind: "progress",
			min: 2
		} },
		do: { milestone: "Upstanding|silver" }
	}, { do: { seq: [{ milestone: "Degenerate|red" }, { hap: 1 }] } }],
	"story21.7": [{
		if: { cardStickers: {
			label: "p21",
			kind: "heart",
			min: 3
		} },
		do: { hap: 1 }
	}, { do: { milestone: "Little Genius|silver" } }],
	"story22.2": [{
		if: { cardStickers: {
			label: "p23",
			kind: "heart",
			min: 1
		} },
		do: { seq: [{ upset: 1 }, { place: "11P" }] }
	}, { do: { place: "11P" } }],
	"story22.7": [{
		if: { cardStickers: {
			label: "p22",
			kind: "progress",
			min: 2
		} },
		do: { milestone: "Upstanding|silver" }
	}, { do: { seq: [{ milestone: "Degenerate|red" }, { hap: 1 }] } }],
	"story27.6a": [{
		if: { milestoneExact: "Big Savings Account" },
		do: { res: { gold: 7 } }
	}, {
		if: { milestoneExact: "Savings Account" },
		do: { res: { gold: 4 } }
	}],
	"story29.6": [{
		if: { cardStickers: {
			label: "p29",
			kind: "heart",
			min: 2
		} },
		do: { milestone: "Trustworthy News|silver" }
	}, { do: { seq: [{ res: { gold: 2 } }, { milestone: "Fake News|red" }] } }],
	"story30.6": [{
		if: { cardStickers: {
			label: "p30",
			kind: "heart",
			min: 2
		} },
		do: { seq: [{ hap: 1 }, { milestone: "Camp Counselor|silver" }] }
	}, { do: { seq: [{ res: { gold: 1 } }, { milestone: "Camp Counselor|silver" }] } }],
	"story32.6": [{
		if: { cardStickers: {
			label: "p32",
			kind: "heart",
			min: 2
		} },
		do: { milestone: "Patron of the Arts|silver" }
	}, { do: { seq: [
		{ res: { gold: 2 } },
		{ hap: 1 },
		{ upset: 1 }
	] } }],
	removeJessie: [{
		if: { hasSticker: "5C" },
		do: { removeSticker: "5C" }
	}, {
		if: { hasSticker: "5D" },
		do: { removeSticker: "5D" }
	}]
}, P = {
	"story11.4b": [{
		label: {
			zh: "额外行动一次",
			en: "Take another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "用 1 枚爱心覆盖 1 枚进度",
			en: "Cover 1 progress with 1 heart"
		},
		do: { seq: [{ cardSticker: {
			label: "29",
			kind: "progress",
			n: -1
		} }, { cardSticker: {
			label: "29",
			kind: "heart",
			n: 1
		} }] }
	}],
	"story26.9": [
		{
			label: {
				zh: "投票决定村庄名称：获得 1 点心情并命名",
				en: "Vote on the name: gain 1 happiness and name the village"
			},
			do: { seq: [{ hap: 1 }, { villageName: !0 }] }
		},
		{
			label: {
				zh: "起个傻气的名字：获得 1 点心情并命名",
				en: "Give it a silly name: gain 1 happiness and name it"
			},
			do: { seq: [{ hap: 1 }, { villageName: !0 }] }
		},
		{
			label: {
				zh: "让居民命名：移除 1 枚不满（没有则 +1 心情），掷骰取名",
				en: "Let residents name it: remove 1 upset (or +1 happiness), then roll for a name"
			},
			do: { seq: [{ branch: "story26.9c" }, { villageNameRoll: !0 }] }
		}
	],
	"y4-07a": [{
		label: {
			zh: "赶走他：移除野比尔贴纸",
			en: "Kick him out: remove Wild Bill"
		},
		do: { removeSticker: "5M" }
	}, {
		label: {
			zh: "让他留下",
			en: "Let him stay"
		},
		do: { none: !0 }
	}],
	"y4-07b": [{
		label: {
			zh: "花费 2 食物",
			en: "Spend 2 food"
		},
		cost: { food: 2 },
		do: { none: !0 }
	}, {
		label: {
			zh: "放置 1 枚不满贴纸",
			en: "Place 1 upset sticker"
		},
		do: { upset: 1 }
	}],
	"y4-09a": [{
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}, {
		label: {
			zh: "花费 3 木材移除白蚁里程碑",
			en: "Spend 3 wood to remove Termites"
		},
		cost: { wood: 3 },
		do: { removeMilestone: "Termites" }
	}],
	"y4-09b": [{
		label: {
			zh: "获得 1 金币",
			en: "Gain 1 gold"
		},
		do: { res: { gold: 1 } }
	}, {
		label: {
			zh: "移除 1 枚不满贴纸",
			en: "Remove 1 upset sticker"
		},
		do: { removeUpset: 1 }
	}],
	"y6-07a": [{
		label: {
			zh: "花费 3 食物移除严冬里程碑",
			en: "Spend 3 food to remove Hard Winter"
		},
		cost: { food: 3 },
		do: { removeMilestone: "Hard Winter" }
	}, {
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}],
	"y7-05a": [{
		label: {
			zh: "获得 2 份自选资源并掷骰",
			en: "Gain 2 chosen resources and roll"
		},
		do: { seq: [{
			pickRes: [
				"wood",
				"food",
				"gold",
				"ore"
			],
			n: 2
		}, { dice: [{
			on: [1, 2],
			do: { hap: -1 }
		}, {
			on: [
				3,
				4,
				5,
				6
			],
			do: { none: !0 }
		}] }] }
	}, {
		label: {
			zh: "不获得资源",
			en: "Gain nothing"
		},
		do: { none: !0 }
	}],
	"y7-05b": [{
		label: {
			zh: "放置 1 张道路贴纸 3E",
			en: "Place 1 road sticker 3E"
		},
		do: { place: "3E" }
	}, {
		label: {
			zh: "本回合额外行动一次",
			en: "Take 1 additional action"
		},
		do: { extraAction: 1 }
	}],
	"y8-07a": [{
		label: {
			zh: "花费 2 食物",
			en: "Spend 2 food"
		},
		cost: { food: 2 },
		do: { none: !0 }
	}, {
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}],
	"y8-08b": [{
		label: {
			zh: "阅读故事 29.7（获得 1 矿石）",
			en: "Read 29.7 (gain 1 ore)"
		},
		do: { story: "29.7" }
	}, {
		label: {
			zh: "阅读故事 29.8（放置 4Y）",
			en: "Read 29.8 (place 4Y)"
		},
		do: { story: "29.8" }
	}],
	"y9-08b": [
		{
			label: {
				zh: "花费 1 食物放置道路 3E",
				en: "Spend 1 food to place road 3E"
			},
			cost: { food: 1 },
			do: { place: "3E" }
		},
		{
			label: {
				zh: "花费 1 食物放置花朵 11A",
				en: "Spend 1 food to place flower 11A"
			},
			cost: { food: 1 },
			do: { place: "11A" }
		},
		{
			label: {
				zh: "不花费",
				en: "Do not spend"
			},
			do: { none: !0 }
		}
	],
	"y10-02": [
		{
			label: {
				zh: "花费 0 金币",
				en: "Spend 0 gold"
			},
			do: { none: !0 }
		},
		{
			label: {
				zh: "花费 2 金币，放置 1 张道路 3E",
				en: "Spend 2 gold, place 1 road 3E"
			},
			cost: { gold: 2 },
			do: {
				place: "3E",
				n: 1,
				cover: !0,
				fullCover: !0
			}
		},
		{
			label: {
				zh: "花费 4 金币，放置 2 张道路 3E",
				en: "Spend 4 gold, place 2 roads 3E"
			},
			cost: { gold: 4 },
			do: {
				place: "3E",
				n: 2,
				cover: !0,
				fullCover: !0
			}
		},
		{
			label: {
				zh: "花费 6 金币，放置 3 张道路 3E",
				en: "Spend 6 gold, place 3 roads 3E"
			},
			cost: { gold: 6 },
			do: {
				place: "3E",
				n: 3,
				cover: !0,
				fullCover: !0
			}
		},
		{
			label: {
				zh: "花费 8 金币，放置 4 张道路 3E",
				en: "Spend 8 gold, place 4 roads 3E"
			},
			cost: { gold: 8 },
			do: {
				place: "3E",
				n: 4,
				cover: !0,
				fullCover: !0
			}
		}
	],
	"y10-04a": [{
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}, {
		label: {
			zh: "用不满覆盖里程碑上的 ★",
			en: "Cover a ★ icon on a milestone"
		},
		if: { minMilestoneIcons: { star: 1 } },
		do: { coverMilestoneIcon: "star" }
	}],
	"y10-04b": [{
		label: {
			zh: "获得 1 点心情",
			en: "Gain 1 happiness"
		},
		do: { hap: 1 }
	}, {
		label: {
			zh: "本回合额外行动一次",
			en: "Take 1 additional action"
		},
		do: { extraAction: 1 }
	}],
	"y10-06a": [{
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}, {
		label: {
			zh: "花费 2 食物，用 12G 覆盖不满贴纸",
			en: "Spend 2 food to cover an upset with 12G"
		},
		cost: { food: 2 },
		do: { seq: [{
			place: "12G",
			cover: !0
		}, { removeUpset: 1 }] }
	}],
	"y10-07a": [
		{
			label: {
				zh: "花费 0 金币",
				en: "Spend 0 gold"
			},
			do: { none: !0 }
		},
		{
			label: {
				zh: "花费 1 金币，放置 1 枚 11B",
				en: "Spend 1 gold, place 1 farm animal 11B"
			},
			cost: { gold: 1 },
			do: { place: "11B" }
		},
		{
			label: {
				zh: "花费 2 金币，放置 2 枚 11B",
				en: "Spend 2 gold, place 2 farm animals 11B"
			},
			cost: { gold: 2 },
			do: {
				place: "11B",
				n: 2
			}
		},
		{
			label: {
				zh: "花费 3 金币，放置 3 枚 11B",
				en: "Spend 3 gold, place 3 farm animals 11B"
			},
			cost: { gold: 3 },
			do: {
				place: "11B",
				n: 3
			}
		}
	],
	"y10-08a": [
		{
			label: {
				zh: "花费 0 食物",
				en: "Spend 0 food"
			},
			do: { none: !0 }
		},
		{
			label: {
				zh: "花费 1 食物，放置 1 枚花朵 11A",
				en: "Spend 1 food, place 1 flower 11A"
			},
			cost: { food: 1 },
			do: { place: "11A" }
		},
		{
			label: {
				zh: "花费 2 食物，放置 2 枚花朵 11A",
				en: "Spend 2 food, place 2 flowers 11A"
			},
			cost: { food: 2 },
			do: {
				place: "11A",
				n: 2
			}
		}
	],
	"y10-09a": [
		{
			label: {
				zh: "花费 2 金币移除赃物里程碑",
				en: "Spend 2 gold to remove Hot Goods"
			},
			cost: { gold: 2 },
			do: { removeMilestone: "Hot Goods" }
		},
		{
			label: {
				zh: "花费 1 矿石移除赃物里程碑",
				en: "Spend 1 ore to remove Hot Goods"
			},
			cost: { ore: 1 },
			do: { removeMilestone: "Hot Goods" }
		},
		{
			label: {
				zh: "不移除",
				en: "Leave it"
			},
			do: { none: !0 }
		}
	],
	"y10-11b": [{
		label: {
			zh: "获得 1 点心情",
			en: "Gain 1 happiness"
		},
		do: { hap: 1 }
	}, {
		label: {
			zh: "移除该房屋居民的 1 枚不满",
			en: "Remove 1 upset from that house’s resident"
		},
		do: { removeUpset: 1 }
	}]
}, F = {
	cols: 15,
	rows: 13,
	cellW: 393.1,
	cellH: 232.6,
	folds: [6943 / 3, 13886 / 3],
	sides: {
		A: {
			type: [
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"r",
					"r",
					"r",
					"r",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"r",
					"r",
					"r",
					"g",
					"g",
					"r"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"w",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				]
			],
			region: [
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					0
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					0,
					0
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				]
			]
		},
		B: {
			type: [
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"r",
					"r",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"r",
					"w",
					"r",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"r",
					"w",
					"w",
					"g"
				],
				[
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"r",
					"r",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"g",
					"w",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"g",
					"w"
				],
				[
					"g",
					"g",
					"g",
					"g",
					"w",
					"r",
					"g",
					"g",
					"g",
					"g",
					"g",
					"r",
					"g",
					"g",
					"w"
				]
			],
			region: [
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					0,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2
				],
				[
					1,
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					0
				],
				[
					1,
					1,
					1,
					1,
					0,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					2,
					0
				]
			]
		}
	}
}, _e = [
	{
		id: "02-2 Adventurer",
		name: "Adventurer",
		bg: "rock",
		file: "stickers/s011.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Astronomer",
		name: "Astronomer",
		bg: "rock",
		file: "stickers/s012.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Avian Enthusiast",
		name: "Avian Enthusiast",
		bg: "rock",
		file: "stickers/s013.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Bear Tamer",
		name: "Bear Tamer",
		bg: "rock",
		file: "stickers/s014.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Big Savings Account",
		name: "Big Savings Account",
		bg: "rock",
		file: "stickers/s015.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Birder",
		name: "Birder",
		bg: "rock",
		file: "stickers/s016.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Business Mogul",
		name: "Business Mogul",
		bg: "rock",
		file: "stickers/s017.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Camp Counselor",
		name: "Camp Counselor",
		bg: "rock",
		file: "stickers/s018.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Conservationist",
		name: "Conservationist",
		bg: "rock",
		file: "stickers/s019.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Dating",
		name: "Dating",
		bg: "rock",
		file: "stickers/s020.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Degenerate",
		name: "Degenerate",
		bg: "clear",
		file: "stickers/s021.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Dictator",
		name: "Dictator",
		bg: "rock",
		file: "stickers/s022.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Expert Baker",
		name: "Expert Baker",
		bg: "grass",
		file: "stickers/s023.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Explorer",
		name: "Explorer",
		bg: "rock",
		file: "stickers/s024.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Fake News",
		name: "Fake News",
		bg: "clear",
		file: "stickers/s025.webp",
		gold: 1,
		star: 0,
		smiley: 0
	},
	{
		id: "02-2 Famous Baker",
		name: "Famous Baker",
		bg: "rock",
		file: "stickers/s026.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Famous Chef",
		name: "Famous Chef",
		bg: "rock",
		file: "stickers/s027.webp",
		gold: 1,
		star: 1,
		smiley: 0
	},
	{
		id: "02-2 Farm Hand",
		name: "Farm Hand",
		bg: "rock",
		file: "stickers/s028.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Fashionable",
		name: "Fashionable",
		bg: "rock",
		file: "stickers/s029.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Finder of Secrets",
		name: "Finder of Secrets",
		bg: "rock",
		file: "stickers/s030.webp",
		gold: 2,
		star: 2,
		smiley: 0
	},
	{
		id: "02-2 Fisher",
		name: "Fisher",
		bg: "rock",
		file: "stickers/s031.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Glamorous",
		name: "Glamorous",
		bg: "rock",
		file: "stickers/s032.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Governor",
		name: "Governor",
		bg: "rock",
		file: "stickers/s033.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Greedy Company",
		name: "Greedy Company",
		bg: "rock",
		file: "stickers/s034.webp",
		gold: 2,
		star: 1,
		smiley: 0
	},
	{
		id: "02-2 Green Thumb",
		name: "Green Thumb",
		bg: "rock",
		file: "stickers/s035.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Hard Winter",
		name: "Hard Winter",
		bg: "clear",
		file: "stickers/s036.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Honest Company",
		name: "Honest Company",
		bg: "rock",
		file: "stickers/s037.webp",
		gold: 1,
		star: 2,
		smiley: 0
	},
	{
		id: "02-2 Hot Goods",
		name: "Hot Goods",
		bg: "clear",
		file: "stickers/s038.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Hunger",
		name: "Hunger",
		bg: "clear",
		file: "stickers/s039.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Immortalized",
		name: "Immortalized",
		bg: "rock",
		file: "stickers/s040.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Investment",
		name: "Investment",
		bg: "rock",
		file: "stickers/s041.webp",
		gold: 1,
		star: 0,
		smiley: 0
	},
	{
		id: "02-2 Kind",
		name: "Kind",
		bg: "rock",
		file: "stickers/s042.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Legendary Rancher",
		name: "Legendary Rancher",
		bg: "rock",
		file: "stickers/s043.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Little Genius",
		name: "Little Genius",
		bg: "rock",
		file: "stickers/s044.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Loan",
		name: "Loan",
		bg: "clear",
		file: "stickers/s045.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Lodge Apprentice",
		name: "Lodge Apprentice",
		bg: "rock",
		file: "stickers/s046.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Lodge Master",
		name: "Lodge Master",
		bg: "rock",
		file: "stickers/s047.webp",
		gold: 2,
		star: 2,
		smiley: 0
	},
	{
		id: "02-2 Lodge Member",
		name: "Lodge Member",
		bg: "rock",
		file: "stickers/s048.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Lucky",
		name: "Lucky",
		bg: "rock",
		file: "stickers/s049.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Married",
		name: "Married",
		bg: "rock",
		file: "stickers/s050.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Master Chef",
		name: "Master Chef",
		bg: "grass",
		file: "stickers/s051.webp",
		gold: 1,
		star: 2,
		smiley: 0
	},
	{
		id: "02-2 Master of Agriculture",
		name: "Master of Agriculture",
		bg: "rock",
		file: "stickers/s052.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Matchmaker",
		name: "Matchmaker",
		bg: "rock",
		file: "stickers/s053.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Mayor",
		name: "Mayor",
		bg: "rock",
		file: "stickers/s054.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Miracle Medicine",
		name: "Miracle Medicine",
		bg: "rock",
		file: "stickers/s055.webp",
		gold: 1,
		star: 1,
		smiley: 0
	},
	{
		id: "02-2 Monarch",
		name: "Monarch",
		bg: "rock",
		file: "stickers/s056.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 New Family",
		name: "New Family",
		bg: "rock",
		file: "stickers/s057.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Noble",
		name: "Noble",
		bg: "rock",
		file: "stickers/s058.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Ore Tycoon",
		name: "Ore Tycoon",
		bg: "rock",
		file: "stickers/s059.webp",
		gold: 1,
		star: 1,
		smiley: 0
	},
	{
		id: "02-2 Ornithologist",
		name: "Ornithologist",
		bg: "rock",
		file: "stickers/s060.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Paleontologist",
		name: "Paleontologist",
		bg: "rock",
		file: "stickers/s061.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Patron of the Arts",
		name: "Patron of the Arts",
		bg: "rock",
		file: "stickers/s062.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Perfect Village",
		name: "Perfect Village",
		bg: "rock",
		file: "stickers/s063.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Pet Lover",
		name: "Pet Lover",
		bg: "rock",
		file: "stickers/s064.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Pet Rescuer",
		name: "Pet Rescuer",
		bg: "grass",
		file: "stickers/s065.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Poisoned",
		name: "Poisoned",
		bg: "clear",
		file: "stickers/s066.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 President",
		name: "President",
		bg: "rock",
		file: "stickers/s067.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Pro Angler",
		name: "Pro Angler",
		bg: "rock",
		file: "stickers/s068.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Rancher",
		name: "Rancher",
		bg: "rock",
		file: "stickers/s069.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Runner Up",
		name: "Runner Up",
		bg: "rock",
		file: "stickers/s070.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Savings Account",
		name: "Savings Account",
		bg: "rock",
		file: "stickers/s071.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Secret Spy",
		name: "Secret Spy",
		bg: "rock",
		file: "stickers/s072.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Sleuth",
		name: "Sleuth",
		bg: "rock",
		file: "stickers/s073.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Termites",
		name: "Termites",
		bg: "clear",
		file: "stickers/s074.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Test Subject",
		name: "Test Subject",
		bg: "clear",
		file: "stickers/s075.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Thriving Community",
		name: "Thriving Community",
		bg: "rock",
		file: "stickers/s076.webp",
		star: 2,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Treasure Hunter",
		name: "Treasure Hunter",
		bg: "rock",
		file: "stickers/s077.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Trustworthy News",
		name: "Trustworthy News",
		bg: "rock",
		file: "stickers/s078.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Tyrant",
		name: "Tyrant",
		bg: "rock",
		file: "stickers/s079.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Unrest",
		name: "Unrest",
		bg: "clear",
		file: "stickers/s080.webp",
		star: 0,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Upstanding",
		name: "Upstanding",
		bg: "rock",
		file: "stickers/s081.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-2 Veteran Rancher",
		name: "Veteran Rancher",
		bg: "rock",
		file: "stickers/s082.webp",
		star: 1,
		gold: 0,
		smiley: 0
	},
	{
		id: "02-Veteran Fisher",
		name: "Veteran Fisher",
		bg: "rock",
		file: "stickers/s083.webp",
		star: 1,
		gold: 0,
		smiley: 0
	}
], ve = {
	"04-4D": "21.1",
	"04-4H": "16.1",
	"04-4M": "15.9",
	"04-4S": "19.1",
	"04-4U": "18.7",
	"05-5E": "12.8",
	"05-5Eb": "12.8",
	"05-5H": "14.1",
	"07-7A": "15.1",
	"07-7K": "29.2",
	"08-8A": "10.1",
	"08-8M": "20.1",
	"08-8V": "27.2",
	"10-10C": "8.8",
	"10-10D": "24.7",
	"10-10G": "30.2",
	"11-11N": "15.8",
	"03-3D": "9.2",
	"04-4C": "9.5",
	"04-4F": "12.4",
	"04-4N": "33.1",
	"04-4T": "22.1",
	"04-4V": "9.6",
	"05-5C": "18.2",
	"05-5D": "22.3",
	"06-6A": "23.1",
	"06-6C": "7.2",
	"06-6R": "8.1",
	"06-6V": "18",
	"07-7D": "22.2",
	"07-7E": "6.4",
	"08-8D": "28.6",
	"08-8Q": "32.3",
	"08-8W": "9.1",
	"09-04": "27.8",
	"09-06": "35.4",
	"09-07": "15.7",
	"09-08": "35.3",
	"09-09": "10.3",
	"09-11": "3",
	"09-13": "3",
	"09-16": "32.1",
	"10-10B": "10.8",
	"12-12U": "13.1"
};
function I(e) {
	return ve[e];
}
//#endregion
//#region src/game/data/number-overlays.ts
var ye = {
	"08-8W/07-7P": {
		cell: [1, 1],
		source: [640, 385],
		art: [
			320,
			8,
			320,
			369
		]
	},
	"04-4C/06-6E": {
		cell: [0, 0],
		source: [640, 386],
		art: [
			0,
			0,
			320,
			368
		]
	},
	"09-09/06-6X": {
		cell: [0, 0],
		source: [640, 588],
		art: [
			0,
			0,
			640,
			290
		]
	},
	"10-10B/12-12J": {
		cell: [1, 1],
		source: [640, 587],
		art: [
			390,
			80,
			250,
			240
		]
	},
	"05-5E/07-7Q": {
		cell: [0, 1],
		source: [900, 571],
		art: [
			0,
			151,
			320,
			367
		]
	},
	"05-5Eb/07-7Q": {
		cell: [0, 1],
		source: [900, 525],
		art: [
			0,
			135,
			320,
			367
		]
	},
	"12-12U/11-11S": {
		cell: [1, 0],
		source: [640, 390],
		art: [
			320,
			24,
			320,
			367
		]
	},
	"09-07/03-3C": {
		cell: [0, 1],
		source: [640, 382],
		art: [
			0,
			0,
			320,
			385
		]
	},
	"10-10D/09-03": {
		cell: [2, 1],
		source: [900, 540],
		art: [
			260,
			30,
			640,
			382
		]
	},
	"08-8D/10-10H": {
		cell: [0, 0],
		source: [640, 385],
		art: [
			0,
			0,
			320,
			375
		]
	},
	"10-10G/09-03": {
		cell: [0, 1],
		source: [640, 587],
		art: [
			0,
			65,
			440,
			264
		]
	},
	"09-08/06-6Y": {
		cell: [1, 1],
		source: [900, 540],
		art: [
			240,
			0,
			640,
			385
		]
	},
	"09-06/03-3B": {
		cell: [0, 1],
		source: [640, 382],
		art: [
			0,
			0,
			320,
			385
		]
	},
	"10-10C/09-03": {
		cell: [0, 1],
		source: [640, 587],
		art: [
			0,
			65,
			435,
			261
		]
	}
}, be = [{
	cell: [0, 0],
	source: [640, 587],
	art: [
		135,
		45,
		210,
		212
	]
}, {
	cell: [0, 2],
	source: [640, 587],
	art: [
		155,
		321,
		210,
		212
	]
}];
function L(e, t, n) {
	return e === "10-10B" && t === "12-12H" ? n ? be.find(({ cell: e }) => e[0] === n.col && e[1] === n.row) : be[0] : ye[`${e}/${t}`];
}
//#endregion
//#region src/game/data/story.ts
var R = [
	{
		page: 1,
		file: "story/p01.webp"
	},
	{
		page: 2,
		file: "story/p02.webp"
	},
	{
		page: 3,
		file: "story/p03.webp"
	},
	{
		page: 4,
		file: "story/p04.webp"
	},
	{
		page: 5,
		file: "story/p05.webp"
	},
	{
		page: 6,
		file: "story/p06.webp"
	},
	{
		page: 7,
		file: "story/p07.webp"
	},
	{
		page: 8,
		file: "story/p08.webp"
	},
	{
		page: 9,
		file: "story/p09.webp"
	},
	{
		page: 10,
		file: "story/p10.webp"
	},
	{
		page: 11,
		file: "story/p11.webp"
	},
	{
		page: 12,
		file: "story/p12.webp"
	},
	{
		page: 13,
		file: "story/p13.webp"
	},
	{
		page: 14,
		file: "story/p14.webp"
	},
	{
		page: 15,
		file: "story/p15.webp"
	},
	{
		page: 16,
		file: "story/p16.webp"
	},
	{
		page: 17,
		file: "story/p17.webp"
	},
	{
		page: 18,
		file: "story/p18.webp"
	},
	{
		page: 19,
		file: "story/p19.webp"
	},
	{
		page: 20,
		file: "story/p20.webp"
	},
	{
		page: 21,
		file: "story/p21.webp"
	},
	{
		page: 22,
		file: "story/p22.webp"
	},
	{
		page: 23,
		file: "story/p23.webp"
	},
	{
		page: 24,
		file: "story/p24.webp"
	},
	{
		page: 25,
		file: "story/p25.webp"
	},
	{
		page: 26,
		file: "story/p26.webp"
	},
	{
		page: 27,
		file: "story/p27.webp"
	},
	{
		page: 28,
		file: "story/p28.webp"
	},
	{
		page: 29,
		file: "story/p29.webp"
	},
	{
		page: 30,
		file: "story/p30.webp"
	},
	{
		page: 31,
		file: "story/p31.webp"
	},
	{
		page: 32,
		file: "story/p32.webp"
	},
	{
		page: 33,
		file: "story/p33.webp"
	},
	{
		page: 34,
		file: "story/p34.webp"
	},
	{
		page: 35,
		file: "story/p35.webp"
	},
	{
		page: 36,
		file: "story/p36.webp"
	}
], z = {
	"8.1": [
		"8.2",
		"8.3",
		"8.4",
		"8.5",
		"8.6"
	],
	"33.1": [
		"33.2",
		"33.3",
		"33.4",
		"33.5"
	]
}, B = {
	"6.2": { choice: [{
		label: {
			zh: "收集树枝：获得 1 木材，然后额外行动一次",
			en: "Gather branches: +1 wood, then another action"
		},
		do: { seq: [{ res: { wood: 1 } }, { extraAction: 1 }] }
	}, {
		label: {
			zh: "砍倒大树：获得 3 木材并记录进度",
			en: "Chop a tree: +3 wood and mark progress"
		},
		do: { seq: [{ res: { wood: 3 } }, { progress: 1 }] }
	}] },
	"8.8": { choice: [{
		label: {
			zh: "让居民免费使用：获得 1 幸福",
			en: "Free for everyone: +1 happiness"
		},
		do: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "8.8" }
		}, { hap: 1 }] }
	}, {
		label: {
			zh: "收取合理费用：获得 2 金币",
			en: "Charge a fair fee: +2 gold"
		},
		do: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "8.8" }
		}, { res: { gold: 2 } }] }
	}] },
	"9.3": { choice: [{
		label: {
			zh: "暂缓竞选：额外行动一次",
			en: "Hold off: another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "投入 3 金币并掷骰（4-6 成功）",
			en: "Spend 3 gold and roll (4-6 succeeds)"
		},
		cost: { gold: 3 },
		do: { dice: [{
			on: [
				1,
				2,
				3
			],
			do: { none: !0 }
		}, {
			on: [
				4,
				5,
				6
			],
			do: { seq: [
				{ discardCard: "13" },
				{ discardCard: "14" },
				{ card: "5" }
			] }
		}] }
	}] },
	"10.1": { choice: [
		{
			label: {
				zh: "介绍自己的表亲：获得图鉴牌 30",
				en: "Introduce your cousin: gain card 30"
			},
			do: { card: "30" }
		},
		{
			label: {
				zh: "主动应征：放置 9C 并获图鉴牌 29",
				en: "Say you're available: place 9C and gain card 29"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "10.1" }
			}, { card: "29" }] }
		},
		{
			label: {
				zh: "帮不上忙：增加 1 不满",
				en: "You can't help: +1 upset"
			},
			do: { upset: 1 }
		}
	] },
	"10.2": { choice: [{
		label: {
			zh: "做体力活：获得 2 金币",
			en: "Manual labor: +2 gold"
		},
		do: { res: { gold: 2 } }
	}, {
		label: {
			zh: "在集市帮忙：获得 1 金币和 2 食物",
			en: "Help at the market: +1 gold and +2 food"
		},
		do: { res: {
			gold: 1,
			food: 2
		} }
	}] },
	"10.4": { auto: { hap: 1 } },
	"10.7": { choice: [{
		label: {
			zh: "一起去远足：记录进度",
			en: "Go hiking: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 食物做晚餐：记录 2 点进度",
			en: "Spend 1 food for dinner: mark 2 progress"
		},
		cost: { food: 1 },
		do: { progress: 2 }
	}] },
	"11.6": { choice: [{
		label: {
			zh: "劝她慢慢来：记录进度",
			en: "Tell them to take it slow: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币买订婚戒指：记录 2 点进度",
			en: "Spend 1 gold on a ring: mark 2 progress"
		},
		cost: { gold: 1 },
		do: { progress: 2 }
	}] },
	"11.7": { auto: { none: !0 } },
	"12.5": { auto: { progress: 1 } },
	"12.8": { choice: [{
		label: {
			zh: "签订贸易协定：获得 1 木材、1 金币、1 矿石",
			en: "Trade agreement: +1 wood, +1 gold, +1 ore"
		},
		do: { seq: [{
			place: "7Q",
			cover: !0,
			must: { number: "12.8" }
		}, { res: {
			wood: 1,
			gold: 1,
			ore: 1
		} }] }
	}, {
		label: {
			zh: "花 1 金币去度假：获得 1 幸福",
			en: "Spend 1 gold on a vacation: +1 happiness"
		},
		cost: { gold: 1 },
		do: { seq: [{
			place: "7Q",
			cover: !0,
			must: { number: "12.8" }
		}, { hap: 1 }] }
	}] },
	"14.1": { choice: [{
		label: {
			zh: "静静聆听：记录进度",
			en: "Listen quietly: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币资助研究：记录 2 点进度",
			en: "Spend 1 gold on research: mark 2 progress"
		},
		cost: { gold: 1 },
		do: { progress: 2 }
	}] },
	"15.1": { auto: { res: { gold: 1 } } },
	"15.8": { choice: [{
		label: {
			zh: "花 2 食物喂熊并掷骰（2-6 成功）",
			en: "Spend 2 food to feed the bear and roll (2-6 succeeds)"
		},
		cost: { food: 2 },
		do: { dice: [{
			on: [1],
			do: { none: !0 }
		}, {
			on: [
				2,
				3,
				4,
				5,
				6
			],
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "15.8" }
			}, { milestone: "Bear Tamer|silver" }] }
		}] }
	}, {
		label: {
			zh: "保持距离：无效果",
			en: "Keep your distance: no effect"
		},
		do: { none: !0 }
	}] },
	"15.9": { choice: [{
		label: {
			zh: "花 2 食物参加厨艺赛并掷骰",
			en: "Spend 2 food and enter the cooking contest"
		},
		cost: { food: 2 },
		do: { dice: [
			{
				on: [1, 2],
				do: { none: !0 }
			},
			{
				on: [
					3,
					4,
					5
				],
				do: { res: { gold: 2 } }
			},
			{
				on: [6],
				do: { seq: [{ res: { gold: 2 } }, { card: "55" }] }
			}
		] }
	}, {
		label: {
			zh: "不参加：无效果",
			en: "Skip the contest: no effect"
		},
		do: { none: !0 }
	}] },
	"16.1": { choice: [{
		label: {
			zh: "给他私人空间：记录进度",
			en: "Give him privacy: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "闯进他的家：记录 2 点进度",
			en: "Break into his house: mark 2 progress"
		},
		do: { progress: 2 }
	}] },
	"16.9": { auto: { res: { gold: 3 } } },
	"18.2": { choice: [{
		if: { milestone: "Poisoned" },
		label: {
			zh: "中毒未愈：弃掉矿洞牌，获得 1 矿石、1 金币与“探险家”（银）",
			en: "Still poisoned: discard the mine cards, gain 1 ore, 1 gold and Explorer (silver)"
		},
		do: { seq: [
			{ discardCard: "35a" },
			{ discardCard: "35b" },
			{ res: {
				ore: 1,
				gold: 1
			} },
			{ milestone: "Explorer|silver" }
		] }
	}, {
		label: {
			zh: "引开蜘蛛：弃掉矿洞牌，获得 1 矿石、3 金币与“冒险家”（金）",
			en: "Distract the spiders: discard the mine cards, gain 1 ore, 3 gold and Adventurer (gold)"
		},
		do: { seq: [
			{ discardCard: "35a" },
			{ discardCard: "35b" },
			{ res: {
				ore: 1,
				gold: 3
			} },
			{ milestone: "Adventurer|gold" }
		] }
	}] },
	"18.3": { choice: [{
		label: {
			zh: "“我还有活要干”：记录进度并额外行动一次",
			en: "\"I have work to do\": mark progress and take another action"
		},
		do: { seq: [{ progress: 1 }, { extraAction: 1 }] }
	}, {
		label: {
			zh: "花 1 食物一起吃大餐：记录 2 点进度",
			en: "Spend 1 food to feast: mark 2 progress"
		},
		cost: { food: 1 },
		do: { progress: 2 }
	}] },
	"18.7": { choice: [{
		if: { milestone: "Pet Lover" },
		label: {
			zh: "把“爱宠人士”换成“宠物救星”（金）",
			en: "Replace Pet Lover with Pet Rescuer (gold)"
		},
		do: { seq: [{ removeMilestone: "Pet Lover" }, { milestone: "Pet Rescuer|gold" }] }
	}, {
		if: { notMilestone: "Pet Lover" },
		label: {
			zh: "放置 9C 和 1 枚宠物贴纸 11G",
			en: "Place 9C and 1 pet sticker 11G"
		},
		do: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "18.7" }
		}, { place: "11G" }] }
	}] },
	"19.1": { choice: [{
		label: {
			zh: "追问那次事故：记录进度",
			en: "Ask about the incident: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "参观采石场：放置 7G",
			en: "See the quarry: place 7G"
		},
		do: { place: "7G" }
	}] },
	"20.1": { choice: [{
		label: {
			zh: "婉拒：记录进度",
			en: "Decline politely: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "花 1 金币买画：放置 12M",
			en: "Spend 1 gold on a painting: place 12M"
		},
		cost: { gold: 1 },
		do: { place: "12M" }
	}] },
	"21.1": { choice: [{
		label: {
			zh: "重视考试：记录 2 点进度",
			en: "Focus on tests: mark 2 progress"
		},
		do: { progress: 2 }
	}, {
		label: {
			zh: "寓教于乐：记录进度",
			en: "Make learning fun: mark progress"
		},
		do: { progress: 1 }
	}] },
	"22.8": { auto: { seq: [{ res: { gold: 1 } }, { progress: 1 }] } },
	"24.3": { auto: { seq: [{ hap: 1 }, { discardCard: "47" }] } },
	"24.4": { auto: { place: "1H" } },
	"24.6": { auto: { hap: -1 } },
	"24.7": { choice: [
		{
			if: { countAny: {
				codes: [
					"11B",
					"11G",
					"12F",
					"5A"
				],
				min: 9
			} },
			label: {
				zh: "获得“传奇牧场主”（金）并放置 9C",
				en: "Gain Legendary Rancher (gold) and place 9C"
			},
			do: { seq: [
				{
					place: "9C",
					cover: !0,
					must: { number: "24.7" }
				},
				{ removeMilestone: "Veteran Rancher" },
				{ milestone: "Legendary Rancher|gold" }
			] }
		},
		{
			label: {
				zh: "花 1 金币放置农场动物贴纸 11B",
				en: "Spend 1 gold to place farm animal 11B"
			},
			cost: { gold: 1 },
			do: { place: "11B" }
		},
		{
			label: {
				zh: "再行动一次",
				en: "Take another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"24.8": { auto: { place: "10K" } },
	"24.10": { auto: { res: { food: 2 } } },
	"25.3": { choice: [{
		label: {
			zh: "花 2 金币买民心：记录进度",
			en: "Spend 2 gold for support: mark progress"
		},
		cost: { gold: 2 },
		do: { progress: 1 }
	}, {
		label: {
			zh: "强迫宣誓：记录进度并增加 1 不满",
			en: "Force an oath: mark progress and +1 upset"
		},
		do: { seq: [{ progress: 1 }, { upset: 1 }] }
	}] },
	"25.4": { choice: [
		{
			if: { minCalmResidents: 9 },
			label: {
				zh: "赢得支持：记录进度",
				en: "Win the people over: mark progress"
			},
			do: { progress: 1 }
		},
		{
			if: { maxCalmResidents: 8 },
			label: {
				zh: "花 2 金币移除 1 不满",
				en: "Spend 2 gold to remove 1 upset"
			},
			cost: { gold: 2 },
			do: { removeUpset: 1 }
		},
		{
			if: { maxCalmResidents: 8 },
			label: {
				zh: "再行动一次",
				en: "Take another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"25.7": { auto: { seq: [
		{ res: { gold: 1 } },
		{ removeMilestone: "Famous Chef" },
		{ milestone: "Master Chef|gold" }
	] } },
	"26.1": { choice: [{
		label: {
			zh: "邀请居民观星：获得 1 幸福",
			en: "Invite the residents: +1 happiness"
		},
		do: { hap: 1 }
	}, {
		label: {
			zh: "出售门票：获得 2 金币",
			en: "Sell tickets: +2 gold"
		},
		do: { res: { gold: 2 } }
	}] },
	"26.5": { auto: { card: "47" } },
	"26.6": { choice: [
		{
			cost: { food: 0 },
			label: {
				zh: "投入 0 食物并掷骰",
				en: "Spend 0 food and roll"
			},
			do: { dice: [{
				on: [
					1,
					2,
					3
				],
				do: { extraAction: 1 }
			}, {
				on: [
					4,
					5,
					6
				],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}] }
		},
		{
			cost: { food: 1 },
			label: {
				zh: "投入 1 食物并掷骰（结果加 1）",
				en: "Spend 1 food and roll (add 1)"
			},
			do: { dice: [
				{
					on: [1, 2],
					do: { extraAction: 1 }
				},
				{
					on: [
						3,
						4,
						5
					],
					do: { res: {
						food: 1,
						gold: 1
					} }
				},
				{
					on: [6],
					do: { seq: [
						{ res: { gold: 2 } },
						{ discardCard: "28" },
						{ removeMilestone: "Famous Baker" },
						{ milestone: "Expert Baker|gold" }
					] }
				}
			] }
		},
		{
			cost: { food: 2 },
			label: {
				zh: "投入 2 食物并掷骰（结果加 2）",
				en: "Spend 2 food and roll (add 2)"
			},
			do: { dice: [
				{
					on: [1],
					do: { extraAction: 1 }
				},
				{
					on: [
						2,
						3,
						4
					],
					do: { res: {
						food: 1,
						gold: 1
					} }
				},
				{
					on: [5, 6],
					do: { seq: [
						{ res: { gold: 2 } },
						{ discardCard: "28" },
						{ removeMilestone: "Famous Baker" },
						{ milestone: "Expert Baker|gold" }
					] }
				}
			] }
		},
		{
			cost: { food: 3 },
			label: {
				zh: "投入 3 食物并掷骰（结果加 3）",
				en: "Spend 3 food and roll (add 3)"
			},
			do: { dice: [{
				on: [
					1,
					2,
					3
				],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		},
		{
			cost: { food: 4 },
			label: {
				zh: "投入 4 食物并掷骰（结果加 4）",
				en: "Spend 4 food and roll (add 4)"
			},
			do: { dice: [{
				on: [1, 2],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					3,
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		},
		{
			cost: { food: 5 },
			label: {
				zh: "投入 5 食物并掷骰（结果加 5）",
				en: "Spend 5 food and roll (add 5)"
			},
			do: { dice: [{
				on: [1],
				do: { res: {
					food: 1,
					gold: 1
				} }
			}, {
				on: [
					2,
					3,
					4,
					5,
					6
				],
				do: { seq: [
					{ res: { gold: 2 } },
					{ discardCard: "28" },
					{ removeMilestone: "Famous Baker" },
					{ milestone: "Expert Baker|gold" }
				] }
			}] }
		}
	] },
	"11.1": { choice: [{
		label: {
			zh: "叫她迪莉：在图鉴牌 29 上放 2 枚爱心",
			en: "Call her Dilly: 2 hearts on card 29"
		},
		do: { cardSticker: {
			label: "29",
			kind: "heart",
			n: 2
		} }
	}, {
		label: {
			zh: "叫她笨手笨脚：在图鉴牌 29 上放 1 枚进度",
			en: "Call her Klutz: 1 progress on card 29"
		},
		do: { cardSticker: {
			label: "29",
			kind: "progress",
			n: 1
		} }
	}] },
	"11.2": { choice: [{
		label: {
			zh: "说谢谢：在图鉴牌 29 上放 1 枚进度",
			en: "Say thanks: 1 progress on card 29"
		},
		do: { cardSticker: {
			label: "29",
			kind: "progress",
			n: 1
		} }
	}, {
		label: {
			zh: "说我也爱你：在图鉴牌 29 上放 1 枚爱心",
			en: "Say I love you too: 1 heart on card 29"
		},
		do: { cardSticker: {
			label: "29",
			kind: "heart",
			n: 1
		} }
	}] },
	"11.3": { choice: [
		{
			label: {
				zh: "分手：弃掉图鉴牌 29 并放 1 枚不满",
				en: "Break up: discard 29 and place 1 upset"
			},
			do: { seq: [{ discardCard: "29" }, { upset: 1 }] }
		},
		{
			label: {
				zh: "深谈：获得 1 心情并在图鉴牌 29 上放 1 枚爱心",
				en: "Deep talk: +1 happiness and 1 heart on 29"
			},
			do: { seq: [{ hap: 1 }, { cardSticker: {
				label: "29",
				kind: "heart",
				n: 1
			} }] }
		},
		{
			label: {
				zh: "买订婚戒指（1 金币）：获得 1 心情并在图鉴牌 29 上放 2 枚爱心",
				en: "Buy a ring (1 gold): +1 happiness and 2 hearts on 29"
			},
			cost: { gold: 1 },
			do: { seq: [{ hap: 1 }, { cardSticker: {
				label: "29",
				kind: "heart",
				n: 2
			} }] }
		}
	] },
	"11.4": { choice: [{
		label: {
			zh: "求婚：若图鉴牌 29 有 3+ 爱心则加 1 爱心，否则弃掉 29",
			en: "Propose: 3+ hearts on 29 -> +1 heart, else discard 29"
		},
		do: { branch: "story11.4a" }
	}, {
		label: {
			zh: "问晚饭：额外行动，或用爱心覆盖 1 枚进度",
			en: "Ask about dinner: another action, or cover 1 progress with a heart"
		},
		do: { ask: "story11.4b" }
	}] },
	"11.5": { choice: [{
		label: {
			zh: "我愿意：弃掉 29，用已婚（金）覆盖恋爱中",
			en: "I do: discard 29, cover Dating with Married (gold)"
		},
		do: { seq: [
			{ discardCard: "29" },
			{ removeMilestone: "Dating" },
			{ milestone: "Married|gold" }
		] }
	}, {
		label: {
			zh: "我不愿意：弃掉 29 并放 1 枚不满",
			en: "I do not: discard 29 and place 1 upset"
		},
		do: { seq: [{ discardCard: "29" }, { upset: 1 }] }
	}] },
	"12.1": { choice: [{
		label: {
			zh: "劝她分手：弃掉图鉴牌 30",
			en: "Tell her to break up: discard card 30"
		},
		do: { discardCard: "30" }
	}, {
		label: {
			zh: "劝她给点时间：在图鉴牌 30 上放 1 枚爱心",
			en: "Give it time: 1 heart on card 30"
		},
		do: { cardSticker: {
			label: "30",
			kind: "heart",
			n: 1
		} }
	}] },
	"12.2": { choice: [{
		label: {
			zh: "默默旁观：在图鉴牌 30 上放 1 枚爱心，并用 4G 覆盖迪尔的房屋",
			en: "Watch silently: 1 heart on 30 and cover Dill’s house with 4G"
		},
		do: { seq: [{ cardSticker: {
			label: "30",
			kind: "heart",
			n: 1
		} }, {
			place: "4G",
			cover: !0,
			must: { house: !0 }
		}] }
	}, {
		label: {
			zh: "宣告爱意：弃掉图鉴牌 30 并获得图鉴牌 29",
			en: "Declare love: discard 30 and gain card 29"
		},
		do: { seq: [{ discardCard: "30" }, { card: "29" }] }
	}] },
	"12.3": { choice: [
		{
			label: {
				zh: "这是你和亚历克斯的事：掷骰，1-3 读 B，4-6 读 C",
				en: "That is between you and Alex: roll, 1-3 read B, 4-6 read C"
			},
			do: { dice: [{
				on: [
					1,
					2,
					3
				],
				do: { discardCard: "30" }
			}, {
				on: [
					4,
					5,
					6
				],
				do: { seq: [{ discardCard: "30" }, { place: "11P" }] }
			}] }
		},
		{
			label: {
				zh: "别要孩子：弃掉图鉴牌 30",
				en: "You do not want kids: discard 30"
			},
			do: { discardCard: "30" }
		},
		{
			label: {
				zh: "设立大学基金（1 金币）：弃掉 30 并放置婴儿 11P",
				en: "College fund (1 gold): discard 30 and place baby 11P"
			},
			cost: { gold: 1 },
			do: { seq: [{ discardCard: "30" }, { place: "11P" }] }
		}
	] },
	"25.1": { choice: [
		{
			label: {
				zh: "建城堡（2 矿石、3 金币）：在图鉴牌 51 上放 1 枚爱心，并用 8G 覆盖房屋",
				en: "Build a castle (2 ore, 3 gold): 1 heart on 51 and cover a house with 8G"
			},
			cost: {
				ore: 2,
				gold: 3
			},
			do: { seq: [{ cardSticker: {
				label: "51",
				kind: "heart",
				n: 1
			} }, {
				place: "8G",
				cover: !0,
				must: { house: !0 }
			}] }
		},
		{
			label: {
				zh: "送居民去采石场：获得 1 矿石和 1 金币，然后放 1 枚不满",
				en: "Send residents to the quarry: +1 ore, +1 gold, then 1 upset"
			},
			do: { seq: [{ res: {
				ore: 1,
				gold: 1
			} }, { upset: 1 }] }
		},
		{
			label: {
				zh: "静待时机：额外行动一次",
				en: "Bide your time: another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"25.2": { choice: [
		{
			label: {
				zh: "买王冠（4 金币）：弃掉 51，用君主（金）覆盖政治 2",
				en: "Buy a crown (4 gold): discard 51, cover Politics 2 with Monarch (gold)"
			},
			cost: { gold: 4 },
			do: { seq: [
				{ discardCard: "51" },
				{ removeMilestone: "Politics 2" },
				{ milestone: "Monarch|gold" }
			] }
		},
		{
			label: {
				zh: "征税：获得 2 金币，失去 1 心情",
				en: "Tax residents: +2 gold, -1 happiness"
			},
			do: { seq: [{ res: { gold: 2 } }, { hap: -1 }] }
		},
		{
			label: {
				zh: "另寻他法：额外行动一次",
				en: "Seek alternatives: another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"26.7": { auto: { card: "45" } },
	"30.7": { auto: { cardSticker: {
		label: "44",
		kind: "heart",
		n: 1
	} } },
	"32.8": { choice: [{
		label: {
			zh: "游向下游：在图鉴牌 44 上放 1 枚爱心",
			en: "Swim downriver: 1 heart on card 44"
		},
		do: { cardSticker: {
			label: "44",
			kind: "heart",
			n: 1
		} }
	}, {
		label: {
			zh: "花 1 木材造木筏：在图鉴牌 44 上放 2 枚爱心",
			en: "Spend 1 wood on a raft: 2 hearts on card 44"
		},
		cost: { wood: 1 },
		do: { cardSticker: {
			label: "44",
			kind: "heart",
			n: 2
		} }
	}] },
	"26.9": { auto: { seq: [{ place: "1A" }, { ask: "story26.9" }] } },
	"27.1": { choice: [{
		label: {
			zh: "再行动一次",
			en: "Take another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 3 金币并掷骰（4-6 成功）",
			en: "Spend 3 gold and roll (4-6 succeeds)"
		},
		cost: { gold: 3 },
		do: { dice: [{
			on: [
				1,
				2,
				3
			],
			do: { none: !0 }
		}, {
			on: [
				4,
				5,
				6
			],
			do: { seq: [{ discardCard: "15" }, { card: "5" }] }
		}] }
	}] },
	"27.2": { choice: [{
		label: {
			zh: "再行动一次",
			en: "Take another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 2 金币开户：获得“储蓄账户”（铜）并记录进度",
			en: "Spend 2 gold to open an account: Savings Account (bronze) and mark progress"
		},
		cost: { gold: 2 },
		do: { seq: [{ milestone: "Savings Account|bronze" }, { progress: 1 }] }
	}] },
	"27.7": { auto: { seq: [
		{ discardCard: "15" },
		{ hap: -1 },
		{ card: "51" }
	] } },
	"28.2": { auto: { branch: "story28.2" } },
	"28.3": { auto: { branch: "story28.3" } },
	"28.4": { auto: { cardSticker: {
		label: "36",
		kind: "progress",
		n: 1
	} } },
	"28.5": { auto: { branch: "story28.5" } },
	"28.9": { auto: { seq: [{ removeMilestone: "Fashionable" }, { milestone: "Glamorous|gold" }] } },
	"29.2": { choice: [{
		label: {
			zh: "刊登暖心故事：记录进度",
			en: "Print a heartwarming story: mark progress"
		},
		do: { progress: 1 }
	}, {
		label: {
			zh: "刊登质疑报道：获得 1 金币并记录进度",
			en: "Print a provocative story: +1 gold and mark progress"
		},
		do: { seq: [{ res: { gold: 1 } }, { progress: 1 }] }
	}] },
	"29.9": { auto: { none: !0 } },
	"30.2": { auto: { seq: [{ res: { gold: 1 } }, { progress: 1 }] } },
	"31.1": { auto: { special: "finale31" } },
	"31.2": { auto: { milestone: "Thriving Community|gold" } },
	"31.3": { auto: { milestone: "Conservationist|gold" } },
	"31.4": { auto: { milestone: "Business Mogul|gold" } },
	"32.7": { auto: { removeSticker: "5A" } },
	"33.9": { auto: { none: !0 } },
	"34.7": { auto: { none: !0 } },
	"35.1": { auto: { none: !0 } },
	"35.2": { auto: { branch: "story35.2" } },
	"35.5": { choice: [{
		label: {
			zh: "坦然接受落败：获得图鉴牌 15",
			en: "Accept defeat gracefully: gain card 15"
		},
		do: { card: "15" }
	}, {
		label: {
			zh: "宣布投票无效：获得图鉴牌 14",
			en: "Declare the vote invalid: gain card 14"
		},
		do: { card: "14" }
	}] },
	"35.6": { choice: [{
		label: {
			zh: "花 1 木材再行动一次",
			en: "Spend 1 wood for another action"
		},
		cost: { wood: 1 },
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "结束探索",
			en: "End the exploration"
		},
		do: { none: !0 }
	}] },
	"36.1": { auto: { none: !0 } },
	"9.8": { auto: { empty: "food" } },
	"29.7": { auto: { res: { ore: 1 } } },
	"29.8": { auto: { place: "4Y" } },
	"34.1": { auto: { branch: "story34.1" } },
	"28.8": { choice: [{
		label: {
			zh: "覆盖里程碑上 1 个金币图标",
			en: "Cover 1 gold icon on a milestone"
		},
		if: { minMilestoneIcons: { gold: 1 } },
		do: { coverMilestoneIcon: "gold" }
	}, {
		label: {
			zh: "失去 1 点心情",
			en: "Lose 1 happiness"
		},
		do: { hap: -1 }
	}] },
	"6.3": { auto: { seq: [
		{ res: { ore: 1 } },
		{ res: { gold: 2 } },
		{
			place: "9D",
			cover: !0,
			must: { number: "6.4" }
		}
	] } },
	"6.4": { auto: { seq: [{
		place: "9D",
		cover: !0,
		must: { number: "6.4" }
	}, { branch: "story6.4" }] } },
	"7.6": { choice: [{
		label: {
			zh: "花 4 金币翻修小屋：覆盖 7.2 并阅读 28.1",
			en: "Spend 4 gold to renovate the lodge: cover 7.2 and read 28.1"
		},
		cost: { gold: 4 },
		do: { seq: [{
			place: "8E",
			cover: !0,
			must: { number: "7.2" }
		}, { story: "28.1" }] }
	}, {
		label: {
			zh: "暂时作罢：额外行动一次",
			en: "Pass for now: another action"
		},
		do: { extraAction: 1 }
	}] },
	"8.2": { choice: [{
		label: {
			zh: "收集木柴：获得 2 木材并贴爱心",
			en: "Gather wood: gain 2 wood and place a heart"
		},
		do: { seq: [{ res: { wood: 2 } }, { storySticker: {
			entry: "8.2",
			kind: "heart"
		} }] }
	}, {
		label: {
			zh: "花 2 食物种树：贴进度并放置 5N",
			en: "Spend 2 food to plant a tree: place progress and sticker 5N"
		},
		cost: { food: 2 },
		do: { seq: [{ storySticker: {
			entry: "8.2",
			kind: "progress"
		} }, { place: "5N" }] }
	}] },
	"8.3": { choice: [{
		label: {
			zh: "砍树：获得 3 木材并贴爱心",
			en: "Chop a tree: gain 3 wood and place a heart"
		},
		do: { seq: [
			{ res: { wood: 3 } },
			{ storySticker: {
				entry: "8.3",
				kind: "heart"
			} },
			{ branch: "story8.3Tree" }
		] }
	}, {
		label: {
			zh: "收集落枝：获得 1 木材并贴进度",
			en: "Gather fallen wood: gain 1 wood and place progress"
		},
		do: { seq: [{ res: { wood: 1 } }, { storySticker: {
			entry: "8.3",
			kind: "progress"
		} }] }
	}] },
	"8.4": { choice: [{
		label: {
			zh: "收集木柴：获得 2 木材并贴爱心",
			en: "Gather wood: gain 2 wood and place a heart"
		},
		do: { seq: [{ res: { wood: 2 } }, { storySticker: {
			entry: "8.4",
			kind: "heart"
		} }] }
	}, {
		label: {
			zh: "花 2 金币种树：贴进度并放置 5N",
			en: "Spend 2 gold to plant a tree: place progress and sticker 5N"
		},
		cost: { gold: 2 },
		do: { seq: [{ storySticker: {
			entry: "8.4",
			kind: "progress"
		} }, { place: "5N" }] }
	}] },
	"8.5": { auto: { branch: "story8.5" } },
	"8.6": { choice: [
		{
			if: {
				cardStickers: {
					label: "p8",
					kind: "heart",
					min: 3
				},
				hatchetAvailable: !0
			},
			label: {
				zh: "免费领取斧头 1E，覆盖 8.1",
				en: "Take hatchet 1E for free and cover 8.1"
			},
			do: { seq: [{ special: "attachHatchet" }, {
				place: "9C",
				cover: !0,
				must: { number: "8.1" }
			}] }
		},
		{
			if: { cardStickers: {
				label: "p8",
				kind: "heart",
				min: 3
			} },
			label: {
				zh: "不放置 1E",
				en: "Do not place 1E"
			},
			do: { none: !0 }
		},
		{
			if: {
				cardStickers: {
					label: "p8",
					kind: "heart",
					max: 2
				},
				hatchetAvailable: !0
			},
			label: {
				zh: "花 2 金币购买斧头 1E，覆盖 8.1",
				en: "Spend 2 gold on hatchet 1E and cover 8.1"
			},
			cost: { gold: 2 },
			do: { seq: [{ special: "attachHatchet" }, {
				place: "9C",
				cover: !0,
				must: { number: "8.1" }
			}] }
		},
		{
			if: { cardStickers: {
				label: "p8",
				kind: "heart",
				max: 2
			} },
			label: {
				zh: "额外行动一次",
				en: "Another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"9.1": { choice: [{
		label: {
			zh: "让杰西搬进来：移除杰西并覆盖 9.1",
			en: "Let Jessie move in: remove Jessie and cover 9.1"
		},
		do: { seq: [{ branch: "removeJessie" }, {
			place: "7P",
			cover: !0,
			must: { number: "9.1" }
		}] }
	}, {
		label: {
			zh: "邀请乔丹·图茨：放置 4N 并阅读 33.1",
			en: "Invite Jordan Toots: place 4N and read 33.1"
		},
		do: {
			place: "4N",
			cover: !0,
			must: { number: "9.1" },
			storyOnPlace: "33.1"
		}
	}] },
	"9.2": { choice: [{
		label: {
			zh: "不予理会：额外行动一次",
			en: "Ignore it: another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 1 木材搭桥：覆盖 9.2",
			en: "Spend 1 wood on a bridge: cover 9.2"
		},
		cost: { wood: 1 },
		do: {
			place: "7R",
			cover: !0,
			must: { number: "9.2" }
		}
	}] },
	"9.5": { choice: [{
		label: {
			zh: "暂时等待：额外行动一次",
			en: "Wait for now: another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 1 金币聘请消防员：覆盖 9.5",
			en: "Spend 1 gold on a firefighter: cover 9.5"
		},
		cost: { gold: 1 },
		do: {
			place: "6E",
			cover: !0,
			must: { number: "9.5" }
		}
	}] },
	"9.6": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "9.6" }
	}, { branch: "story9.6" }] } },
	"10.3": { choice: [{
		label: {
			zh: "花 1 木材建钓鱼码头：覆盖 10.3 并获得图鉴牌 12",
			en: "Spend 1 wood on a fishing dock: cover 10.3 and gain card 12"
		},
		cost: { wood: 1 },
		do: { seq: [{
			place: "6X",
			cover: !0,
			must: { number: "10.3" }
		}, { card: "12a" }] }
	}, {
		label: {
			zh: "额外行动一次",
			en: "Another action"
		},
		do: { extraAction: 1 }
	}] },
	"10.5": { choice: [{
		label: {
			zh: "答应约会：覆盖 10.1 并获得图鉴牌 29",
			en: "Say yes: cover 10.1 and gain card 29"
		},
		do: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "10.1" }
		}, { card: "29" }] }
	}, {
		label: {
			zh: "介绍表亲：阅读故事 10.6",
			en: "Mention your cousin: read 10.6"
		},
		do: { story: "10.6" }
	}] },
	"10.8": { auto: { branch: "story10.8" } },
	"12.4": { choice: [{
		label: {
			zh: "花 1 金币和 2 木材建新家：获得 1 心情并覆盖 12.4",
			en: "Spend 1 gold and 2 wood on a new home: +1 happiness and cover 12.4"
		},
		cost: {
			gold: 1,
			wood: 2
		},
		do: { seq: [{ hap: 1 }, {
			place: "7C",
			cover: !0,
			must: { number: "12.4" }
		}] }
	}, {
		label: {
			zh: "住帐篷：额外行动一次",
			en: "Live in a tent: another action"
		},
		do: { extraAction: 1 }
	}] },
	"12.6": { choice: [{
		label: {
			zh: "威胁揭发：获得 7 金币并覆盖 7.2",
			en: "Threaten to expose them: +7 gold and cover 7.2"
		},
		do: { seq: [{ res: { gold: 7 } }, {
			place: "9C",
			cover: !0,
			must: { number: "7.2" }
		}] }
	}, {
		label: {
			zh: "保守秘密：获得 1 金币",
			en: "Keep their secret: +1 gold"
		},
		do: { res: { gold: 1 } }
	}] },
	"13.3": { choice: [{
		label: {
			zh: "花 1 金币安全处理：在本页 13.3 放爱心",
			en: "Spend 1 gold on safe disposal: heart on 13.3"
		},
		cost: { gold: 1 },
		do: { cardSticker: {
			label: "p13",
			kind: "heart",
			n: 1
		} }
	}, {
		label: {
			zh: "倒进河里：获得 1 金币，本页 13.3 放进度并覆盖 13.1",
			en: "Dump it: +1 gold, progress on 13.3 and cover 13.1"
		},
		do: { seq: [
			{ res: { gold: 1 } },
			{ cardSticker: {
				label: "p13",
				kind: "progress",
				n: 1
			} },
			{
				place: "12U",
				cover: !0,
				must: { number: "13.1" }
			}
		] }
	}] },
	"13.7": { auto: { seq: [{
		place: "11S",
		cover: !0,
		must: { number: "13.1" }
	}, { branch: "story13.7" }] } },
	"14.8": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "14.1" }
	}, { branch: "story14.8" }] } },
	"15.6": { choice: [{
		label: {
			zh: "接受试验：覆盖 15.1，获得「试验对象」（红）和 3 金币",
			en: "Join the trial: cover 15.1, gain Test Subject (red) and 3 gold"
		},
		do: { seq: [
			{
				place: "9C",
				cover: !0,
				must: { number: "15.1" }
			},
			{ milestone: "Test Subject|red" },
			{ res: { gold: 3 } }
		] }
	}, {
		label: {
			zh: "拒绝试验：覆盖 15.1",
			en: "Decline the trial: cover 15.1"
		},
		do: {
			place: "9C",
			cover: !0,
			must: { number: "15.1" }
		}
	}] },
	"15.7": { choice: [{
		label: {
			zh: "赶走小鹿：获得 1 食物并覆盖 15.7",
			en: "Chase the deer off: +1 food and cover 15.7"
		},
		do: { seq: [{ res: { food: 1 } }, {
			place: "9C",
			cover: !0,
			must: { number: "15.7" }
		}] }
	}, {
		label: {
			zh: "远远看着：失去 1 食物并覆盖 15.7",
			en: "Watch from afar: lose 1 food and cover 15.7"
		},
		do: { seq: [{ loseRes: { food: 1 } }, {
			place: "3C",
			cover: !0,
			must: { number: "15.7" }
		}] }
	}] },
	"16.7": { choice: [
		{
			label: {
				zh: "猜是间谍：覆盖 16.1，无效果",
				en: "Guess spy: cover 16.1, no effect"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "16.1" }
			}, { story: "9.9" }] }
		},
		{
			label: {
				zh: "猜是税务员：覆盖 16.1，获得「侦探」（金）",
				en: "Guess tax agent: cover 16.1, gain Sleuth (gold)"
			},
			do: { seq: [
				{
					place: "9C",
					cover: !0,
					must: { number: "16.1" }
				},
				{ story: "9.9" },
				{ milestone: "Sleuth|gold" }
			] }
		},
		{
			label: {
				zh: "猜是罪犯：覆盖 16.1，无效果",
				en: "Guess criminal: cover 16.1, no effect"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "16.1" }
			}, { story: "9.9" }] }
		}
	] },
	"18.6": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "18.2" }
	}, { branch: "story18.6" }] } },
	"19.5": { choice: [{
		label: {
			zh: "叫专家来：在本页 19.5 放爱心",
			en: "Call an expert: heart on 19.5"
		},
		do: { cardSticker: {
			label: "p19",
			kind: "heart",
			n: 1
		} }
	}, {
		label: {
			zh: "继续挖：获得 1 矿石并覆盖 19.1",
			en: "Keep digging: +1 ore and cover 19.1"
		},
		do: { seq: [{ res: { ore: 1 } }, {
			place: "9D",
			cover: !0,
			must: { number: "19.1" }
		}] }
	}] },
	"19.6": { choice: [{
		label: {
			zh: "同意停工：覆盖 19.1 并获得「古生物学家」（银）",
			en: "Stop mining: cover 19.1 and gain Paleontologist (silver)"
		},
		do: { seq: [{
			place: "9D",
			cover: !0,
			must: { number: "19.1" }
		}, { milestone: "Paleontologist|silver" }] }
	}, {
		label: {
			zh: "继续开采：覆盖 19.1 并获得 1 矿石",
			en: "Keep mining: cover 19.1 and gain 1 ore"
		},
		do: { seq: [{
			place: "9D",
			cover: !0,
			must: { number: "19.1" }
		}, { res: { ore: 1 } }] }
	}] },
	"20.7": { choice: [{
		label: {
			zh: "认为已完成：覆盖 20.1 并放置 12N",
			en: "Call it finished: cover 20.1 and place 12N"
		},
		do: { seq: [{
			place: "9D",
			cover: !0,
			must: { number: "20.1" }
		}, { place: "12N" }] }
	}, {
		label: {
			zh: "继续等待：覆盖 20.1 并获得图鉴牌 43",
			en: "Wait: cover 20.1 and gain card 43"
		},
		do: { seq: [{
			place: "9D",
			cover: !0,
			must: { number: "20.1" }
		}, { card: "43" }] }
	}] },
	"21.7": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "21.1" }
	}, { branch: "story21.7" }] } },
	"22.2": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "22.2" }
	}, { branch: "story22.2" }] } },
	"22.7": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "22.3" }
	}, { branch: "story22.7" }] } },
	"23.5": { choice: [
		{
			if: { cardStickers: {
				label: "p23",
				kind: "heart",
				min: 3
			} },
			label: {
				zh: "接受投资：覆盖 23.1 并获得「投资」（铜）",
				en: "Accept the investment: cover 23.1 and gain Investment (bronze)"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "23.1" }
			}, { milestone: "Investment|bronze" }] }
		},
		{
			if: { cardStickers: {
				label: "p23",
				kind: "heart",
				max: 2
			} },
			label: {
				zh: "花 1 金币投资：覆盖 23.1 并获得「投资」（铜）",
				en: "Spend 1 gold to invest: cover 23.1 and gain Investment (bronze)"
			},
			cost: { gold: 1 },
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "23.1" }
			}, { milestone: "Investment|bronze" }] }
		},
		{
			if: { cardStickers: {
				label: "p23",
				kind: "heart",
				max: 2
			} },
			label: {
				zh: "额外行动一次",
				en: "Another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"27.5": { choice: [
		{
			label: {
				zh: "取出全部存款：获得 4 金币并覆盖 27.2",
				en: "Withdraw everything: +4 gold and cover 27.2"
			},
			do: { seq: [{ res: { gold: 4 } }, {
				place: "9C",
				cover: !0,
				must: { number: "27.2" }
			}] }
		},
		{
			if: { milestoneExact: "Savings Account" },
			label: {
				zh: "存入更多：本页 27.5 放爱心，存款升级为大额存款（银）",
				en: "Deposit more: heart on 27.5, upgrade Savings to Big Savings (silver)"
			},
			cost: { gold: 1 },
			do: { seq: [
				{ cardSticker: {
					label: "p27",
					kind: "heart",
					n: 1
				} },
				{ removeMilestoneExact: "Savings Account" },
				{ milestone: "Big Savings Account|silver" }
			] }
		},
		{
			label: {
				zh: "不动它：本页 27.5 放爱心并额外行动一次",
				en: "Leave it: heart on 27.5 and another action"
			},
			do: { seq: [{ cardSticker: {
				label: "p27",
				kind: "heart",
				n: 1
			} }, { extraAction: 1 }] }
		}
	] },
	"27.6": { choice: [
		{
			label: {
				zh: "取出全部存款：按里程碑获得金币并覆盖 27.2",
				en: "Withdraw everything: gain gold by milestone and cover 27.2"
			},
			do: { seq: [{ branch: "story27.6a" }, {
				place: "9C",
				cover: !0,
				must: { number: "27.2" }
			}] }
		},
		{
			if: { milestoneExact: "Savings Account" },
			label: {
				zh: "继续存：存款升级为大额存款（银）",
				en: "Keep saving: upgrade Savings to Big Savings (silver)"
			},
			do: { seq: [{ removeMilestoneExact: "Savings Account" }, { milestone: "Big Savings Account|silver" }] }
		},
		{
			if: { notMilestoneExact: "Savings Account" },
			label: {
				zh: "额外行动一次",
				en: "Another action"
			},
			do: { extraAction: 1 }
		}
	] },
	"27.8": { choice: [{
		label: {
			zh: "打水喝：额外行动一次",
			en: "Draw water: another action"
		},
		do: { extraAction: 1 }
	}, {
		label: {
			zh: "花 1 金币许愿：覆盖 27.8 并获得「幸运儿」（铜）",
			en: "Spend 1 gold on a wish: cover 27.8 and gain Lucky (bronze)"
		},
		cost: { gold: 1 },
		do: { seq: [{
			place: "9C",
			cover: !0,
			must: { number: "27.8" }
		}, { milestone: "Lucky|bronze" }] }
	}] },
	"29.6": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "29.2" }
	}, { branch: "story29.6" }] } },
	"30.6": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "30.2" }
	}, { branch: "story30.6" }] } },
	"32.1": { choice: [{
		label: {
			zh: "找到了四叶草：获得「幸运儿」（铜）并覆盖 32.1",
			en: "Found a four-leaf clover: gain Lucky (bronze) and cover 32.1"
		},
		do: { seq: [{ milestone: "Lucky|bronze" }, {
			place: "9C",
			cover: !0,
			must: { number: "32.1" }
		}] }
	}, {
		label: {
			zh: "没找到：额外行动一次",
			en: "No luck: another action"
		},
		do: { extraAction: 1 }
	}] },
	"32.6": { auto: { seq: [{
		place: "9C",
		cover: !0,
		must: { number: "32.3" }
	}, { branch: "story32.6" }] } },
	"33.2": { choice: [{
		label: {
			zh: "婉拒：贴一枚进度贴纸",
			en: "Decline: place a progress sticker"
		},
		do: { storySticker: {
			entry: "33.2",
			kind: "progress"
		} }
	}, {
		label: {
			zh: "花 1 金币聘请乔丹：贴一枚爱心",
			en: "Hire Jordan for 1 gold: place a heart"
		},
		cost: { gold: 1 },
		do: { storySticker: {
			entry: "33.2",
			kind: "heart"
		} }
	}] },
	"33.3": { choice: [{
		label: {
			zh: "劝乔丹停止练习：贴一枚进度贴纸",
			en: "Ask Jordan to stop practicing: place a progress sticker"
		},
		do: { storySticker: {
			entry: "33.3",
			kind: "progress"
		} }
	}, {
		label: {
			zh: "让乔丹继续练习：贴一枚爱心并增加 1 不满",
			en: "Let Jordan keep practicing: place a heart and add 1 upset"
		},
		do: { seq: [{ storySticker: {
			entry: "33.3",
			kind: "heart"
		} }, { upset: 1 }] }
	}] },
	"33.4": { choice: [{
		label: {
			zh: "不想听：阅读 33.5",
			en: "Decline to listen: read 33.5"
		},
		do: { story: "33.5" }
	}, {
		label: {
			zh: "听乔丹演奏：贴一枚爱心并阅读 33.5",
			en: "Listen to Jordan: place a heart and read 33.5"
		},
		do: { seq: [{ storySticker: {
			entry: "33.4",
			kind: "heart"
		} }, { story: "33.5" }] }
	}] },
	"33.5": { choice: [
		{
			if: {
				cardStickers: {
					label: "p33",
					kind: "heart",
					min: 2
				},
				minRedMilestones: 1
			},
			label: {
				zh: "移除 1 个红色里程碑：覆盖 33.1",
				en: "Remove a red milestone: cover 33.1"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "33.1" }
			}, { removeRedMilestone: !0 }] }
		},
		{
			if: { cardStickers: {
				label: "p33",
				kind: "heart",
				min: 2
			} },
			label: {
				zh: "获得 1 点心情：覆盖 33.1",
				en: "Gain 1 happiness: cover 33.1"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "33.1" }
			}, { hap: 1 }] }
		},
		{
			if: { cardStickers: {
				label: "p33",
				kind: "heart",
				max: 1
			} },
			label: {
				zh: "提前离场：覆盖 33.1 并额外行动一次",
				en: "Leave early: cover 33.1 and another action"
			},
			do: { seq: [{
				place: "9C",
				cover: !0,
				must: { number: "33.1" }
			}, { extraAction: 1 }] }
		}
	] },
	"35.3": { choice: [{
		label: {
			zh: "花 1 木材停渔船：覆盖 35.3 并获得图鉴牌 12",
			en: "Spend 1 wood on a fishing boat: cover 35.3 and gain card 12"
		},
		cost: { wood: 1 },
		do: { seq: [{
			place: "6Y",
			cover: !0,
			must: { number: "35.3" }
		}, { card: "12a" }] }
	}, {
		label: {
			zh: "额外行动一次",
			en: "Another action"
		},
		do: { extraAction: 1 }
	}] },
	"35.4": { choice: [{
		label: {
			zh: "赶走兔子：获得 1 食物并覆盖 35.4",
			en: "Chase the rabbit off: +1 food and cover 35.4"
		},
		do: { seq: [{ res: { food: 1 } }, {
			place: "9C",
			cover: !0,
			must: { number: "35.4" }
		}] }
	}, {
		label: {
			zh: "看着它吃：失去 1 食物并覆盖 35.4",
			en: "Watch it eat: lose 1 food and cover 35.4"
		},
		do: { seq: [{ loseRes: { food: 1 } }, {
			place: "3B",
			cover: !0,
			must: { number: "35.4" }
		}] }
	}] },
	"23.6": { choice: [{
		label: {
			zh: "免费住：获得 1 心情，移除杰西并覆盖 23.6",
			en: "Live rent-free: +1 happiness, remove Jessie and cover 23.6"
		},
		do: { seq: [
			{ hap: 1 },
			{ branch: "removeJessie" },
			{
				place: "7P",
				cover: !0,
				must: { number: "23.6" },
				softMust: !0
			}
		] }
	}, {
		label: {
			zh: "收租：获得 2 金币，移除杰西并覆盖 23.6",
			en: "Charge rent: +2 gold, remove Jessie and cover 23.6"
		},
		do: { seq: [
			{ res: { gold: 2 } },
			{ branch: "removeJessie" },
			{
				place: "7P",
				cover: !0,
				must: { number: "23.6" },
				softMust: !0
			}
		] }
	}] },
	"9.9": { auto: { none: !0 } }
}, xe = [
	{
		key: "outpost",
		minHearts: 0,
		title: {
			zh: "寂静前哨",
			en: "A Quiet Outpost"
		},
		text: {
			zh: "十年过去，村庄仍然只是河畔一处安静的小聚落。居民们过着平淡的日子，但每当夜风吹过空荡的街道，你总会想起那些没能实现的心愿。",
			en: "Ten years on, the village is still little more than a quiet cluster by the river. Life is peaceful, yet on windy nights you cannot help but remember the dreams that never took root."
		}
	},
	{
		key: "settlement",
		minHearts: 6,
		title: {
			zh: "温暖的聚落",
			en: "A Warm Settlement"
		},
		text: {
			zh: "村庄渐渐有了烟火气。邻里间彼此照应，孩子们在巷口嬉闹。它算不上繁华，却是一个让人愿意留下来的地方。",
			en: "The village has grown lively. Neighbours look out for one another and children play in the lanes. It is not grand, but it is a place where people want to stay."
		}
	},
	{
		key: "cozy",
		minHearts: 12,
		title: {
			zh: "温馨小镇",
			en: "A Cozy Town"
		},
		text: {
			zh: "曾经荒芜的土地如今变成了温馨的小镇。每逢节日，广场上灯笼高挂，居民们的笑脸映在河面上，你知道这些年的辛劳都值得。",
			en: "The barren land has become a cozy town. On festival days lanterns hang over the square and smiling faces reflect in the river — all those years of work were worth it."
		}
	},
	{
		key: "thriving",
		minHearts: 18,
		title: {
			zh: "繁荣之心",
			en: "The Thriving Heart"
		},
		text: {
			zh: "你的村庄声名远扬，商队与旅人络绎不绝。整洁的街道、兴旺的集市与和睦的居民，让它成了整片山谷最向往的地方。",
			en: "Your village is famous across the valley. Caravans and travellers arrive in a steady stream, drawn by tidy streets, a bustling market and contented residents."
		}
	},
	{
		key: "legendary",
		minHearts: 24,
		title: {
			zh: "传奇村庄",
			en: "A Legendary Village"
		},
		text: {
			zh: "诗人传唱着你的村庄，远方的国王也派人前来拜访。这座由你亲手打造的传奇村庄，将被一代又一代人铭记。",
			en: "Poets sing of your village and kings send envoys to visit. The legendary village you built with your own hands will be remembered for generations."
		}
	}
], V = {
	x: 27,
	y: 26,
	w: 3867,
	h: 1864
}, H = {
	w: V.w / F.cols,
	h: V.h / F.rows
}, Se = {
	box: [
		[0, 0],
		[1, 0],
		[1, 1],
		[0, 1]
	],
	single: [
		[.5, 0],
		[1, .5],
		[.5, 1],
		[0, .5]
	],
	left: [
		[1, 0],
		[1, 1],
		[0, .5]
	],
	right: [
		[0, 0],
		[1, .5],
		[0, 1]
	],
	double: [
		[.5, 0],
		[1, 1 / 3],
		[.75, .5],
		[1, 2 / 3],
		[.5, 1],
		[0, 2 / 3],
		[.25, .5],
		[0, 1 / 3]
	]
}, Ce = /* @__PURE__ */ new Set([
	"01-1G",
	"01-1H",
	"03-3A",
	"03-3E",
	"04-4Y",
	"05-5A",
	"05-5C",
	"05-5D",
	"05-5F",
	"05-5G",
	"05-5M",
	"08-8Y"
]), we = {
	"03-3B": {
		kind: "left",
		width: 320,
		height: 385
	},
	"03-3C": {
		kind: "left",
		width: 320,
		height: 385
	},
	"05-5B": {
		kind: "left",
		width: 320,
		height: 368
	},
	"05-5N": {
		kind: "right",
		width: 320,
		height: 378
	},
	"05-5Q": {
		kind: "right",
		width: 320,
		height: 378
	},
	"05-5R": {
		kind: "right",
		width: 320,
		height: 378
	},
	"06-6E": {
		kind: "left",
		width: 320,
		height: 368
	},
	"07-7P": {
		kind: "right",
		width: 320,
		height: 367
	},
	"07-7Q": {
		kind: "left",
		width: 320,
		height: 367
	},
	"08-8X": {
		kind: "right",
		width: 320,
		height: 380
	},
	"09-09": {
		kind: "double",
		width: 640,
		height: 588
	},
	"10-10A": {
		kind: "double",
		width: 640,
		height: 587
	},
	"10-10B": {
		kind: "double",
		width: 640,
		height: 587
	},
	"10-10C": {
		kind: "double",
		width: 640,
		height: 587
	},
	"10-10F": {
		kind: "double",
		width: 640,
		height: 583
	},
	"10-10G": {
		kind: "double",
		width: 640,
		height: 587
	},
	"10-10H": {
		kind: "left",
		width: 320,
		height: 375
	},
	"11-11S": {
		kind: "right",
		width: 320,
		height: 376
	}
}, Te = {
	kind: "single",
	width: 320,
	height: 194
};
function Ee(e, t, n) {
	return {
		left: e.col * H.w,
		top: e.row * H.h,
		width: t * H.w,
		height: n * H.h
	};
}
function De(e, t, n) {
	let r = Math.min(e.width / t, e.height / n);
	return {
		left: e.left + (e.width - t * r) / 2,
		top: e.top + (e.height - n * r) / 2,
		width: t * r,
		height: n * r
	};
}
function U(e, t, n) {
	let r = we[e.id] ?? (Ce.has(e.id) ? Te : void 0), i = r?.kind ?? "box", a = Ee(t, e.cols, e.rows), o = r ? De(a, r.width, r.height) : a, s = n && x[n.id], c = n && s && L(s.id, e.id, {
		col: t.col - n.col,
		row: t.row - n.row
	});
	if (n && s && c) {
		let [e, t] = c.source, r = De(Ee(n, s.cols, s.rows), e, t), [i, a, l, u] = c.art, d = r.width / e;
		o = {
			left: r.left + i * d,
			top: r.top + a * d,
			width: l * d,
			height: u * d
		};
	}
	let l = ([e, t]) => ({
		x: o.left + e * o.width,
		y: o.top + t * o.height
	}), u = Se[i].map(l), d = i === "double" ? [u.slice(0, 3).concat(u.slice(6)), u.slice(2, 7)] : [u], ee = i === "box" && !c ? {
		x: a.left + H.w / 2,
		y: a.top + H.h / 2
	} : l([i === "right" ? 0 : i === "left" ? 1 : .5, i === "double" ? 1 / 3 : .5]);
	return {
		box: o,
		contour: u,
		lobes: d,
		align: ee,
		kind: i,
		overlay: !!c
	};
}
var Oe = (e, t, n) => (t.x - e.x) * (n.y - e.y) - (t.y - e.y) * (n.x - e.x);
function ke(e, t) {
	return t.some((t) => t.every((n, r) => Oe(n, t[(r + 1) % t.length], e) >= -1e-6));
}
function Ae(e) {
	return Math.abs(e.reduce((t, n, r) => {
		let i = e[(r + 1) % e.length];
		return t + n.x * i.y - i.x * n.y;
	}, 0)) / 2;
}
function je(e, t) {
	let n = e;
	for (let e = 0; e < t.length && n.length; e++) {
		let r = t[e], i = t[(e + 1) % t.length], a = [];
		for (let e = 0; e < n.length; e++) {
			let t = n[e], o = n[(e + 1) % n.length], s = Oe(r, i, t), c = Oe(r, i, o);
			if (s >= 0 && a.push(t), s >= 0 != c >= 0) {
				let e = s / (s - c);
				a.push({
					x: t.x + (o.x - t.x) * e,
					y: t.y + (o.y - t.y) * e
				});
			}
		}
		n = a;
	}
	return Ae(n);
}
var Me = 1e-4;
function Ne(e, t) {
	return e.left < t.left + t.width && t.left < e.left + e.width && e.top < t.top + t.height && t.top < e.top + e.height;
}
function Pe(e, t) {
	return Ne(e.box, t.box) ? e.lobes.some((e) => t.lobes.some((t) => je(e, t) > Me)) : !1;
}
function Fe(e, t) {
	return t.lobes.every((t) => Ae(t) - e.lobes.reduce((e, n) => e + je(t, n), 0) < Me);
}
function Ie(e) {
	let { box: t, lobes: n } = e, r = [];
	for (let e = Math.floor(t.top / H.h); e < Math.ceil((t.top + t.height) / H.h - 1e-9); e++) for (let i = Math.floor(t.left / H.w); i < Math.ceil((t.left + t.width) / H.w - 1e-9); i++) {
		let t = Ee({
			col: i,
			row: e
		}, 1, 1), a = Se.box.map(([e, n]) => ({
			x: t.left + e * t.width,
			y: t.top + n * t.height
		}));
		n.some((e) => je(e, a) > Me) && r.push({
			col: i,
			row: e
		});
	}
	return r;
}
//#endregion
//#region src/game/state.ts
function Le() {
	return {
		wood: 0,
		food: 0,
		gold: 0,
		ore: 0
	};
}
function Re(e, t, n) {
	let r = (Math.floor(e) ^ t * 2654435761 ^ n * 2246822507) >>> 0;
	return () => {
		r = r + 1831565813 >>> 0;
		let e = r;
		return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
function ze(e, t, n, r = 0) {
	let i = e.slice(), a = Re(t, n, r);
	for (let e = i.length - 1; e > 0; e--) {
		let t = Math.floor(a() * (e + 1));
		[i[e], i[t]] = [i[t], i[e]];
	}
	return i;
}
function Be(e, t) {
	return ze(re.filter((t) => t.year === e).map((e) => e.id), t, e);
}
function Ve(e) {
	return x[e] ?? se[e]?.[0];
}
function He(e, t) {
	return e.col < t.col + t.cols && t.col < e.col + e.cols && e.row < t.row + t.rows && t.row < e.row + e.rows;
}
function W(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n = 0; n < e.length; n++) Ue(e, e[n], n) && t.add(n);
	return t;
}
function Ue(e, t, n) {
	let r = x[t.id];
	if (!r) return !1;
	let i = U(r, t, t.numberOverlay);
	for (let t = n + 1; t < e.length; t++) {
		let n = e[t];
		if (!n.cover || n.numberOverlay) continue;
		let r = x[n.id];
		if (r && r.bg !== "clear" && Pe(i, U(r, n))) return !0;
	}
	return !1;
}
function G(e, t) {
	let n = e.indexOf(t);
	return n < 0 ? !1 : e.some(({ cover: e, numberOverlay: r }, i) => i > n && e && r?.id === t.id && r.col === t.col && r.row === t.row);
}
function We(e) {
	let t = W(e), n = Le();
	return e.forEach((e, r) => {
		if (t.has(r)) return;
		let i = x[e.id];
		i && (n.wood += i.wood, n.food += i.food, n.gold += i.gold, n.ore += i.ore);
	}), n;
}
function Ge(e) {
	let t = W(e), n = {
		axe: 0,
		log: 0
	};
	return e.forEach((e, r) => {
		if (t.has(r)) return;
		let i = x[e.id];
		i && (n.axe += i.axe ?? 0, n.log += i.log ?? 0);
	}), n;
}
function Ke(e) {
	return e.bridge || e.placed.some((e) => Ve(e.id)?.code === "12A");
}
function qe(e) {
	let t = W(e.placed), n = /* @__PURE__ */ new Set(), r = [];
	e.placed.forEach((e, i) => {
		if (t.has(i)) return;
		let a = x[e.id];
		if (a) {
			if (a.fence) for (let t of rt(e.col, e.row, a.cols, a.rows)) n.add(`${t.col},${t.row}`);
			a.house && r.push({
				p: e,
				d: a
			});
		}
	});
	let i = F.sides[e.side];
	for (let { p: e, d: t } of r) {
		let r = new Set(rt(e.col, e.row, t.cols, t.rows).map((e) => `${e.col},${e.row}`)), a = !0;
		for (let o of rt(e.col, e.row, t.cols, t.rows)) for (let [e, t] of [
			[1, 0],
			[-1, 0],
			[0, 1],
			[0, -1]
		]) {
			let s = o.col + e, c = o.row + t, l = `${s},${c}`;
			r.has(l) || n.has(l) || s < 0 || c < 0 || s >= F.cols || c >= F.rows || i.type[c]?.[s] !== "w" && (a = !1);
		}
		if (a) return !0;
	}
	return !1;
}
function Je(e, t, n) {
	let r = t.startsWith("p") ? Ye(e, t.slice(1)) : e.cardStickers[t];
	return r ? n ? r[n] : r.heart + r.progress : 0;
}
function Ye(e, t) {
	let n = { ...e.cardStickers[`p${t}`] ?? {
		heart: 0,
		progress: 0
	} };
	for (let [r, i] of Object.entries(e.storyEntryStickers)) r.startsWith(`${t}.`) && n[i]++;
	return n;
}
function Xe(e) {
	if (!(e.cardAttachments["3a"] || e.cardAttachments["3b"])) return e.catalog.find((e) => e === "3a" || e === "3b");
}
function Ze(e) {
	return e.cols === 1 && e.rows === 2 && e.trees === 1 && (e.log ?? 0) > 0;
}
function Qe(e, t) {
	let n = ut(e), r = _e.find((e) => e.name.toLowerCase() === n), i = t.filter((t) => t.milestone === e);
	return {
		gold: Math.max(0, (r?.gold ?? 0) - i.filter((e) => e.icon === "gold").length),
		star: Math.max(0, (r?.star ?? 0) - i.filter((e) => e.icon === "star").length),
		smiley: r?.smiley ?? 0
	};
}
function $e(e) {
	let t = {
		star: 0,
		gold: 0,
		smiley: 0
	};
	for (let n of e.milestones) {
		let r = Qe(n, e.coveredMilestoneIcons);
		t.gold += r.gold, t.star += r.star, t.smiley += r.smiley;
	}
	return t;
}
var et = {
	grass: "g",
	water: "w",
	rock: "r"
};
function tt(e, t) {
	return e.placed.filter((n, r) => I(n.id) === t && !Ue(e.placed, n, r) && !G(e.placed, n));
}
function nt(e, t, n) {
	if (typeof n != "string" || n === "23.6") return;
	let r = tt(e, n);
	if (!r.length) return;
	let i = r.filter((e) => L(e.id, t.id)).length;
	return i === r.length ? "label" : i === 0 ? "whole" : void 0;
}
function rt(e, t, n, r) {
	let i = [];
	for (let a = t; a < t + r; a++) for (let t = e; t < e + n; t++) i.push({
		col: t,
		row: a
	});
	return i;
}
var it = [5, 10];
function at(e, t, n, r, i = !1, a, o = !1, s = !1) {
	let c = t.cols, l = t.rows, u = typeof a?.number == "string" ? a.number : void 0, d = u != null && u !== "23.6", ee = d ? tt(e, u) : [];
	if (n < 0 || r < 0 || n >= F.cols || r >= F.rows) return {
		ok: !1,
		reason: "oob"
	};
	for (let o of ee) {
		let s = {
			col: n - o.col,
			row: r - o.row
		}, c = L(o.id, t.id, s);
		if (c && st(x[o.id], a) && s.col === c.cell[0] && s.row === c.cell[1]) {
			if (!i && e.placed.some((e) => e.id === t.id && e.col === n && e.row === r)) continue;
			return {
				ok: !0,
				numberOverlay: {
					id: o.id,
					col: o.col,
					row: o.row
				}
			};
		}
	}
	if (n + c > F.cols || r + l > F.rows) return {
		ok: !1,
		reason: "oob"
	};
	let te = F.sides[e.side], ne = U(t, {
		col: n,
		row: r
	}), f = u === "23.6", p = f ? rt(n, r, c, l) : Ie(ne);
	if (t.bg !== "clear" && it.some((e) => p.some((t) => t.col < e) && p.some((t) => t.col >= e))) return {
		ok: !1,
		reason: "fold"
	};
	if (t.bg !== "clear" && a?.number == null) {
		let e = et[t.bg];
		if (e) for (let t of p) {
			let n = te.type[t.row]?.[t.col];
			if (n && n !== e) return {
				ok: !1,
				reason: "bg"
			};
		}
	}
	let m = e.placed.filter((e) => {
		let t = x[e.id];
		return t ? f ? He({
			col: n,
			row: r,
			cols: c,
			rows: l
		}, {
			...e,
			cols: t.cols,
			rows: t.rows
		}) : Pe(ne, U(t, e, e.numberOverlay)) : !1;
	}), h = (e, t) => f ? e.col >= n && e.row >= r && e.col + t.cols <= n + c && e.row + t.rows <= r + l : Fe(ne, U(t, e, e.numberOverlay));
	if (t.bg !== "clear" && !i && m.length) return {
		ok: !1,
		reason: "overlap"
	};
	if (a) {
		let i = a.loneTree || a.logIcon ? W(e.placed) : void 0;
		if (!m.filter((o) => {
			let s = x[o.id];
			return !s || i?.has(e.placed.indexOf(o)) || !st(s, a) ? !1 : u === "23.6" && Object.keys(a).length === 1 ? !0 : d && (!ee.includes(o) || L(o.id, t.id)) ? !1 : d && s.cols === c && s.rows === l ? o.col === n && o.row === r : a.logIcon ? !0 : h(o, s);
		}).length && !s) return {
			ok: !1,
			reason: "target"
		};
	}
	if ((o || d) && m.length) for (let e of m) {
		let t = x[e.id];
		if (t && !e.numberOverlay && !(d && ee.includes(e) && t.cols === c && t.rows === l && e.col === n && e.row === r) && !h(e, t)) return {
			ok: !1,
			reason: "target"
		};
	}
	if (t.bg === "grass" && !Ke(e)) {
		let e = /* @__PURE__ */ new Set();
		for (let t of p) {
			let n = te.region[t.row]?.[t.col];
			n && n > 0 && e.add(n);
		}
		if (e.size > 1) return {
			ok: !1,
			reason: "river"
		};
	}
	return { ok: !0 };
}
function ot(e, t, n, r, i) {
	return at(e, t, n, r, i?.cover, i?.must, i?.fullCover, i?.soft);
}
function st(e, t) {
	return t.loneTree && !Ze(e) || t.logIcon && !(e.log ?? 0) || t.number != null && I(e.id) !== t.number ? !1 : t.woodAxeAlternative ? (e.trees ?? 0) === 2 && e.wood > 0 || e.wood > 0 && (e.axe ?? 0) > 0 : !(t.trees != null && (e.trees ?? 0) !== t.trees || t.berryBush != null && !!e.berryBush !== t.berryBush || t.wood != null && e.wood < t.wood || t.food != null && e.food < t.food || t.axe != null && (e.axe ?? 0) < t.axe || t.woodOrAxeBoth && !(e.wood > 0 && (e.axe ?? 0) > 0) || t.house != null && !!e.house !== t.house || t.grassHouse != null && t.grassHouse && !(e.house && e.bg === "grass"));
}
function ct(e, t) {
	let n = Ve(t);
	if (!n) return !1;
	for (let t = 0; t <= F.rows - n.rows; t++) for (let r = 0; r <= F.cols - n.cols; r++) if (at(e, n, r, t).ok) return !0;
	return !1;
}
function K(e, t) {
	if (!t) return [];
	if (t.none) return [{ op: "none" }];
	let n = [];
	if (t.dice) {
		let r = 1 + Math.floor(Re(e.seed, e.year, 9e3 + e.cursor++)() * 6), i = t.dice.find((e) => e.on.includes(r));
		i?.rerollIf && i.rerollIf.on.includes(r) && (!i.rerollIf.milestone || Y(e, { milestone: i.rerollIf.milestone })) && (r = 1 + Math.floor(Re(e.seed, e.year, 9e3 + e.cursor++)() * 6));
		let a = t.dice.find((e) => e.on.includes(r));
		n.push({ op: "none" }), a && n.push(...K(e, a.do));
	}
	if (t.res && n.push({
		op: "res",
		res: t.res
	}), t.loseRes && n.push({
		op: "loseRes",
		res: t.loseRes
	}), t.hap && n.push({
		op: "hap",
		n: t.hap
	}), t.place && n.push({
		op: "place",
		code: t.place,
		n: t.n ?? 1,
		allow: t.cover,
		must: t.must,
		fullCover: t.fullCover,
		soft: t.softMust,
		storyOnPlace: t.storyOnPlace
	}), t.pickPlace && n.push({
		op: "pickPlace",
		pick: t.pickPlace
	}), t.card && n.push({
		op: "card",
		key: t.card
	}), t.pickCard && n.push({
		op: "pickCard",
		pick: t.pickCard
	}), t.story && n.push({
		op: "story",
		key: t.story
	}), t.milestone && n.push({
		op: "milestone",
		key: t.milestone
	}), t.removeMilestone && n.push({
		op: "removeMilestone",
		key: t.removeMilestone
	}), t.removeMilestoneExact && n.push({
		op: "removeMilestoneExact",
		key: t.removeMilestoneExact
	}), t.removeSticker && n.push({
		op: "removeSticker",
		key: t.removeSticker
	}), t.upset && n.push({
		op: "upset",
		n: t.upset
	}), t.removeUpset && n.push({
		op: "removeUpset",
		n: t.removeUpset
	}), t.extraAction && n.push({
		op: "extraAction",
		n: t.extraAction
	}), t.skipAction && n.push({ op: "skipAction" }), t.progress && n.push({
		op: "progress",
		n: t.progress
	}), t.pickRes && n.push({
		op: "pickRes",
		pick: t.pickRes,
		n: t.n ?? 1
	}), t.pickLose && n.push({
		op: "pickLose",
		pick: t.pickLose.pick,
		n: t.pickLose.n ?? 1
	}), t.empty && n.push({
		op: "empty",
		key: t.empty
	}), t.exchange && n.push({
		op: "exchange",
		n: t.exchange.n,
		allow: !!t.exchange.ore
	}), t.branch && n.push({
		op: "branch",
		key: t.branch
	}), t.discardCard && n.push({
		op: "discardCard",
		key: t.discardCard
	}), t.discardEvent && n.push({
		op: "discardEvent",
		key: t.discardEvent
	}), t.ask && n.push({
		op: "ask",
		key: t.ask
	}), t.invokeCard && n.push({
		op: "invokeCard",
		key: t.invokeCard.labels.join(","),
		onesAs: t.invokeCard.onesAs,
		goldIfValue: t.invokeCard.goldIfValue,
		soft: t.invokeCard.reroll
	}), t.cardSticker && n.push({
		op: "cardSticker",
		key: t.cardSticker.label,
		code: t.cardSticker.kind,
		n: t.cardSticker.n ?? 1
	}), t.storySticker && n.push({
		op: "storySticker",
		key: t.storySticker.entry,
		code: t.storySticker.kind
	}), t.cardFood && n.push({
		op: "cardFood",
		key: t.cardFood.label,
		n: t.cardFood.n ?? 1
	}), t.clearCardFood && n.push({
		op: "clearCardFood",
		key: t.clearCardFood
	}), t.discount && n.push({
		op: "discount",
		n: t.discount
	}), t.freeCardActions && n.push({ op: "freeCards" }), t.coverMilestoneIcon && n.push({
		op: "coverMilestoneIcon",
		key: t.coverMilestoneIcon
	}), t.removeRedMilestone && n.push({ op: "removeRedMilestone" }), t.clock && n.push({ op: "clock" }), t.villageName && n.push({ op: "villageName" }), t.villageNameRoll && n.push({ op: "villageNameRoll" }), t.special && n.push({
		op: "special",
		key: t.special
	}), t.cardStory && n.push({
		op: "cardStory",
		key: t.cardStory.label,
		pick: t.cardStory.entries
	}), t.puzzle && n.push({
		op: "puzzle",
		key: t.puzzle.label,
		code: t.puzzle.kind
	}), t.pickTarget && n.push({
		op: "pickTarget",
		key: t.pickTarget
	}), t.seq) for (let r of t.seq) n.push(...K(e, r));
	return n;
}
function lt(e, t) {
	e.resources[t] = Math.max(0, Math.min(v[t], e.resources[t]));
}
function ut(e) {
	return e.split("|")[0].trim().toLowerCase();
}
function dt(e) {
	return zt(e).reduce((e, t) => e + (t.d.residents ?? 0), 0);
}
function ft(e) {
	let t = (t) => zt(e).filter((e) => e.d.code === t).length, n = [
		"11B",
		"11G",
		"12F",
		"12H",
		"5A"
	].reduce((e, n) => e + t(n), 0), r = [
		"3E",
		"12A",
		"4Q"
	].reduce((e, n) => e + t(n), 0), i = $e(e), a = Math.max(0, dt(e) - e.upset), o = +(e.happiness >= 21) + +(i.star >= 18) + +(a >= 10), s = +(n >= 10) + +(Ge(e.placed).log >= 6) + +(t("11A") >= 7), c = +(r >= 18) + +(i.gold >= 4) + +(Ge(e.placed).axe >= 3), l = o + s + c, u = "6.6";
	l >= 6 ? u = "6.5" : l >= 3 && (u = c >= s && c >= o ? "31.4" : s >= o ? "31.3" : "31.2"), e.queue.unshift({
		op: "story",
		key: u
	}), J(e, `终局目标：受爱戴 ${o}、自然主义者 ${s}、大亨 ${c}，共 ${l} 枚标记。`, `Finale goals: Beloved ${o}, Naturalist ${s}, Tycoon ${c}; ${l} tokens.`);
}
function pt(e) {
	for (; !e.prompt && e.queue.length;) {
		let t = e.queue[0];
		if (t.op === "place") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "place",
				code: t.code,
				n: t.n ?? 1,
				cover: t.allow,
				must: t.must,
				fullCover: t.fullCover,
				soft: t.soft,
				storyOnPlace: t.storyOnPlace
			};
			return;
		}
		if (t.op === "pickPlace") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickPlace",
				pick: t.pick
			};
			return;
		}
		if (t.op === "pickCard") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickCard",
				pick: t.pick
			};
			return;
		}
		if (t.op === "pickRes") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickRes",
				pick: t.pick,
				n: t.n ?? 1
			};
			return;
		}
		if (t.op === "exchange") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "exchange",
				n: t.n ?? 1,
				allow: t.allow
			};
			return;
		}
		if (t.op === "ask") {
			e.prompt = {
				kind: "pickOpt",
				code: `ask:${t.key}`
			};
			return;
		}
		if (t.op === "pickLose") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickOpt",
				code: `lose:${(t.pick ?? S).join(",")}:${t.n ?? 1}`,
				pick: t.pick ?? [...S]
			};
			return;
		}
		if (t.op === "invokeCard") {
			let n = (t.key ?? "").split(",").filter(Boolean).filter((t) => e.catalog.includes(t));
			if (!n.length) {
				e.queue.shift();
				continue;
			}
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickOpt",
				code: `invoke:${n.join(",")}:${t.onesAs ?? 0}:${t.goldIfValue ?? 0}:${+!!t.soft}`
			};
			return;
		}
		if (t.op === "removeRedMilestone") {
			if (!e.milestones.filter((e) => /\|red$/i.test(e)).length) {
				e.queue.shift();
				continue;
			}
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickOpt",
				code: "ms:red"
			};
			return;
		}
		if (t.op === "coverMilestoneIcon") {
			if (t.key !== "star" && t.key !== "gold" || !$e(e)[t.key]) {
				e.queue.shift();
				continue;
			}
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickOpt",
				code: `icon:${t.key}`
			};
			return;
		}
		if (t.op === "clock") {
			e.prompt = { kind: "clock" };
			return;
		}
		if (t.op === "villageName") {
			e.prompt = { kind: "name" };
			return;
		}
		if (t.op === "puzzle") {
			e.prompt = {
				kind: "puzzle",
				code: `${t.key}:${t.code}`
			};
			return;
		}
		if (t.op === "villageNameRoll") {
			let t = 1 + Math.floor(Re(e.seed, e.year, 9e3 + e.cursor++)() * 6);
			e.queue.shift(), e.villageName = t <= 2 ? "杰西村" : t <= 4 ? "我们的镇" : "超赞镇", J(e, `掷骰 ${t}：村庄命名为「${e.villageName}」。`, `Roll ${t}: the village is named “${e.villageName}”.`);
			continue;
		}
		if (t.op === "cardStory" && t.key && t.pick?.length) {
			let n = Je(e, t.key), r = t.pick[Math.min(n, t.pick.length - 1)];
			e.queue.shift(), e.queue.unshift({
				op: "story",
				key: r
			});
			continue;
		}
		if (t.op === "special") {
			if (e.queue.shift(), t.key === "finale31" && ft(e), t.key === "attachHatchet") {
				let t = Xe(e);
				t && (e.cardAttachments[t] = "1E", J(e, `将斧头贴纸 1E 放在图鉴牌 ${t.toUpperCase()} 上。`, `Attached hatchet sticker 1E to catalog card ${t.toUpperCase()}.`));
			}
			continue;
		}
		if (t.op === "pickTarget") {
			e.yearEnding || (e.phase = "placing"), e.prompt = {
				kind: "pickOpt",
				code: `target:${t.key}`
			};
			return;
		}
		if (e.queue.shift(), t.op === "res" && t.res) for (let n of Object.keys(t.res)) e.resources[n] += t.res[n] ?? 0, lt(e, n);
		else if (t.op === "loseRes" && t.res) for (let n of Object.keys(t.res)) e.resources[n] -= t.res[n] ?? 0, lt(e, n);
		else if (t.op === "hap") e.happiness = Math.max(0, Math.min(30, e.happiness + (t.n ?? 0)));
		else if (t.op === "card" && t.key) {
			if (!e.catalog.includes(t.key)) {
				e.catalog.push(t.key);
				let n = N[t.key]?.entry;
				n && e.queue.unshift(...K(e, n));
			}
		} else if (t.op === "story" && t.key) {
			let n = z[t.key];
			if (n) {
				let t = n.find((t) => !e.storyEntryStickers[t]);
				t && e.queue.unshift({
					op: "story",
					key: t
				});
				continue;
			}
			e.story.includes(t.key) || e.story.push(t.key);
			let r = B[t.key];
			if (r?.choice?.length) {
				e.yearEnding || (e.phase = "placing"), e.prompt = {
					kind: "pickOpt",
					code: `st:${t.key}`,
					pick: r.choice.map((e, t) => String(t))
				};
				return;
			}
			r?.auto && e.queue.unshift(...K(e, r.auto));
		} else if (t.op === "branch" && t.key) {
			let n = ge[t.key]?.find((t) => Y(e, t.if));
			n && e.queue.unshift(...K(e, n.do));
		} else if (t.op === "discardCard" && t.key) e.catalog = e.catalog.filter((e) => e !== t.key);
		else if (t.op === "discardEvent" && t.key) e.inPlay = e.inPlay.filter((e) => e !== t.key), e.deck = e.deck.filter((e) => e !== t.key);
		else if (t.op === "milestone" && t.key) e.milestones.includes(t.key) || e.milestones.push(t.key);
		else if (t.op === "removeMilestone" && t.key) {
			let n = t.key.toLowerCase();
			e.milestones = e.milestones.filter((e) => !ut(e).includes(n));
		} else if (t.op === "removeMilestoneExact" && t.key) {
			let n = t.key.toLowerCase();
			e.milestones = e.milestones.filter((e) => ut(e) !== n);
		} else if (t.op === "removeSticker" && t.key) {
			let n = Ve(t.key);
			n && (e.placed = e.placed.filter((e) => e.id !== n.id));
		} else if (t.op === "upset") e.upset = Math.max(0, Math.min(99, e.upset + (t.n ?? 0)));
		else if (t.op === "removeUpset") e.upset = Math.max(0, e.upset - (t.n ?? 0));
		else if (t.op === "progress") e.progress = Math.max(0, Math.min(99, e.progress + (t.n ?? 0)));
		else if (t.op === "extraAction") e.action += t.n ?? 1;
		else if (t.op === "skipAction") e.action = 0;
		else if (t.op === "empty" && t.key) {
			let n = t.key;
			n in e.resources && (e.resources[n] = 0);
		} else if (t.op === "cardSticker" && t.key) {
			let n = t.code === "progress" ? "progress" : "heart", r = e.cardStickers[t.key] ??= {
				heart: 0,
				progress: 0
			};
			r[n] = Math.max(0, r[n] + (t.n ?? 1));
		} else t.op === "storySticker" && t.key && (t.code === "heart" || t.code === "progress") ? e.storyEntryStickers[t.key] ??= t.code : t.op === "cardFood" && t.key ? e.cardFood[t.key] = Math.min(3, (e.cardFood[t.key] ?? 0) + (t.n ?? 1)) : t.op === "clearCardFood" && t.key ? e.cardFood[t.key] = 0 : t.op === "discount" ? e.cardDiscount += t.n ?? 1 : t.op === "freeCards" && (e.freeCardActions = !0);
	}
}
function mt(e) {
	if (e.startsWith("e:")) return _[e.slice(2)]?.endOfYear ?? void 0;
	if (e.startsWith("c:")) return N[e.slice(2)]?.endOfYear;
}
function ht(e, t) {
	t.startsWith("e:") ? e.inPlay = e.inPlay.filter((e) => e !== t.slice(2)) : t.startsWith("c:") && (e.catalog = e.catalog.filter((e) => e !== t.slice(2)));
}
function gt(e) {
	e.yearEnding = !1, e.yearEndQueue = [], e.year >= 10 ? (e.phase = "done", J(e, "十年结束，村庄故事落幕。", "Ten years passed. The village story concludes.")) : (Mt(e, e.year + 1), J(e, `第 ${e.year} 年开始。`, `Year ${e.year} begins.`));
}
function _t(e) {
	for (;;) {
		if (e.prompt || e.queue.length) return;
		if (!e.yearEndQueue.length) {
			gt(e);
			return;
		}
		let t = e.yearEndQueue.shift(), n = mt(t);
		if (n) {
			if (n.discard && ht(e, t), n.auto) {
				e.queue.push(...K(e, n.auto)), pt(e);
				continue;
			}
			if (n.choice?.length) {
				e.phase = "yearEnd", e.prompt = {
					kind: "pickOpt",
					code: t,
					pick: n.choice.map((e, t) => String(t))
				};
				return;
			}
			if (n.optional) {
				e.phase = "yearEnd", e.prompt = {
					kind: "pickOpt",
					code: t,
					pick: ["opt", "skip"]
				};
				return;
			}
		}
	}
}
function vt(e, t, n) {
	let r = Ht(e, n), i = Vt(t, n);
	return r ? `${r} · ${i}` : i;
}
function yt(e) {
	if (e.prompt?.kind !== "pickOpt") return null;
	let t = mt(e.prompt.code ?? "");
	if (!t) return [];
	let n = (t, n) => ({
		key: n,
		label: t.label ? [t.label.zh, t.label.en] : [vt(t.cost, t.do, 0), vt(t.cost, t.do, 1)],
		enabled: It(e, t.cost) && Y(e, t.if)
	});
	return t.choice?.length ? t.choice.map((e, t) => n(e, String(t))) : t.optional ? [n(t.optional, "opt"), {
		key: "skip",
		label: ["跳过", "Skip"],
		enabled: !0
	}] : [];
}
function bt(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !yt(e)?.find((e) => e.key === t)?.enabled) return !1;
	let n = mt(e.prompt.code ?? "");
	if (e.prompt = null, n?.choice) {
		let r = n.choice[Number(t)];
		r && (Rt(e, r.cost), e.queue.push(...K(e, r.do)));
	} else n?.optional && t === "opt" && (Rt(e, n.optional.cost), e.queue.push(...K(e, n.optional.do)));
	return q(e), !0;
}
function xt(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("st:")) return null;
	let t = B[e.prompt.code.slice(3)];
	return t?.choice ? t.choice.map((t, n) => ({
		key: String(n),
		label: [t.label.zh, t.label.en],
		enabled: It(e, t.cost) && Y(e, t.if)
	})) : [];
}
function St(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("st:") || !xt(e)?.find((e) => e.key === t)?.enabled) return !1;
	let n = e.prompt.code.slice(3), r = B[n]?.choice?.[Number(t)];
	return e.prompt = null, r && (Rt(e, r.cost), e.queue.push(...K(e, r.do)), J(e, `故事 ${n}：${r.label.zh}`, `Story ${n}: ${r.label.en}`)), q(e), !0;
}
function Ct(e) {
	return e.prompt?.kind !== "pickOpt" || e.prompt.code !== "setup:8" ? null : [{
		key: "flower",
		label: ["免费放置 1 枚花朵贴纸（11A）", "Place 1 flower sticker (11A) free"],
		enabled: !0
	}, {
		key: "road",
		label: ["花 1 金币放置 1 枚道路贴纸（3E）", "Spend 1 gold to place 1 road sticker (3E)"],
		enabled: e.resources.gold >= 1
	}];
}
function wt(e, t) {
	return e.prompt?.kind !== "pickOpt" || e.prompt.code !== "setup:8" || !Ct(e)?.find((e) => e.key === t)?.enabled ? !1 : (e.prompt = null, t === "flower" ? e.queue.push({
		op: "place",
		code: "11A",
		n: 1
	}) : (Rt(e, { gold: 1 }), e.queue.push({
		op: "place",
		code: "3E",
		n: 1
	})), J(e, "村口的园丁送来一份礼物。", "The village gardener brings a gift."), q(e), !0);
}
var Tt = {
	cat7extra: (e) => [{
		key: "yes",
		label: ["花费 1 金币再放 1 枚政治贴纸", "Spend 1 gold to place 1 more political sticker"],
		enabled: e.resources.gold >= 1
	}, {
		key: "no",
		label: ["不再追加", "Place no more"],
		enabled: !0
	}],
	cat7end: () => [{
		key: "yes",
		label: ["弃掉此牌并宣布参选结果（阅读 35.2）", "Discard this card and read 35.2"],
		enabled: !0
	}, {
		key: "no",
		label: ["保留此牌，稍后再宣布", "Keep this card for later"],
		enabled: !0
	}]
};
function Et(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("ask:")) return null;
	let t = e.prompt.code.slice(4);
	if (Tt[t]) return Tt[t](e);
	let n = P[t];
	return n ? n.map((t, n) => ({
		key: String(n),
		label: [t.label.zh, t.label.en],
		enabled: It(e, t.cost) && Y(e, t.if)
	})) : [];
}
function Dt(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("ask:")) return !1;
	let n = e.prompt.code.slice(4);
	if (!Et(e)?.find((e) => e.key === t)?.enabled) return !1;
	if (e.prompt = null, e.queue[0]?.op === "ask" && e.queue.shift(), !Tt[n]) {
		let r = P[n]?.[Number(t)];
		return r && (Rt(e, r.cost), e.queue.unshift(...K(e, r.do)), J(e, r.label.zh, r.label.en)), q(e), X(e), !0;
	}
	return n === "cat7extra" && t === "yes" ? (Rt(e, { gold: 1 }), e.queue.unshift({
		op: "place",
		code: "11C",
		n: 1
	})) : n === "cat7end" && t === "yes" && (e.catalog = e.catalog.filter((e) => e !== "7"), e.queue.unshift({
		op: "story",
		key: "35.2"
	})), J(e, n === "cat7end" && t === "yes" ? "宣布参选结果。" : "竞选市长。", n === "cat7end" && t === "yes" ? "Declared the election result." : "Campaigning for mayor."), q(e), X(e), !0;
}
function q(e) {
	pt(e), !e.prompt && !e.yearEnding && (e.after ? (e.phase = e.after, e.after = null) : e.phase === "placing" && (e.phase = "afternoon")), e.yearEnding && _t(e);
}
function Ot(e) {
	return $e(e).gold;
}
function kt(e) {
	let t = We(e.placed);
	e.resources.wood = Math.min(v.wood, e.resources.wood + t.wood), e.resources.food = Math.min(v.food, e.resources.food + t.food), e.resources.gold = Math.min(v.gold, e.resources.gold + Ot(e));
}
function At(e) {
	let t = _[e];
	return t ? `Y${t.year}-${String(t.num).padStart(2, "0")}` : e;
}
var jt = {
	3: "y3setup",
	4: "y4setup",
	6: "y6setup",
	7: "y7setup",
	9: "y9setup"
};
function Mt(e, t) {
	e.year = t, e.deck = Be(t, e.seed), e.discard = [], e.currentEvent = null, e.queue = [], e.prompt = null, e.after = null, e.yearEnding = !1, e.yearEndQueue = [], e.action = 0, e.cardDiscount = 0, e.cardDiscountTarget = null, e.freeCardActions = !1, t > 1 && kt(e), e.phase = "morning";
	let n = !1;
	if (t === 2) e.queue.push({
		op: "card",
		key: "42"
	}), n = !0;
	else if (t === 5) e.queue.push({
		op: "place",
		code: ct(e, "5C") ? "5C" : "5D",
		n: 1
	}), n = !0;
	else if (t === 8) Y(e, { milestone: "Lucky" }) ? (e.phase = "placing", e.prompt = {
		kind: "pickOpt",
		code: "setup:8",
		pick: ["flower", "road"]
	}) : e.queue.push({
		op: "place",
		code: "10E",
		n: 1,
		allow: !0
	}), n = !0;
	else {
		let r = jt[t];
		r && (e.queue.push({
			op: "branch",
			key: r
		}), n = !0);
	}
	n && (e.after = "morning", q(e));
}
function J(e, t, n) {
	e.log.push([t, n]), e.log.length > 120 && e.log.splice(0, e.log.length - 120);
}
function Nt(e, t, n) {
	return {
		version: 1,
		campaignId: "coz-" + (Math.floor(t) >>> 0).toString(36),
		serial: 0,
		owner: e,
		seed: t,
		cursor: 0,
		side: n,
		year: 1,
		phase: "starting",
		resources: Le(),
		happiness: 2,
		action: 0,
		upset: 0,
		progress: 0,
		placed: [],
		startingPairs: [],
		inPlay: [],
		deck: [],
		discard: [],
		currentEvent: null,
		queue: [],
		prompt: null,
		after: null,
		yearEnding: !1,
		yearEndQueue: [],
		catalog: [],
		story: [],
		milestones: [],
		cardStickers: {},
		storyEntryStickers: {},
		cardAttachments: {},
		cardFood: {},
		cardSpaces: {},
		bridge: !1,
		cardDiscount: 0,
		cardDiscountTarget: null,
		freeCardActions: !1,
		villageName: null,
		coveredMilestoneIcons: [],
		upsetMarks: [],
		log: []
	};
}
var Pt = oe.filter((e) => e.page === 9);
function Ft(e) {
	return y.find((t) => t.includes(e));
}
function It(e, t) {
	return !t || Object.keys(t).every((n) => e.resources[n] >= (t[n] ?? 0));
}
function Lt(e, t) {
	if (t) for (let n of Object.keys(t)) e.resources[n] = Math.max(0, e.resources[n] - (t[n] ?? 0));
}
function Rt(e, t) {
	Lt(e, t);
}
function zt(e) {
	let t = W(e.placed), n = [];
	return e.placed.forEach((e, r) => {
		if (t.has(r)) return;
		let i = x[e.id];
		i && n.push({
			p: e,
			d: i
		});
	}), n;
}
function Y(e, t) {
	if (!t) return !0;
	let n = (t) => e.milestones.some((e) => ut(e).includes(t.toLowerCase())), r = zt(e), i = (e) => {
		let t = Ve(e)?.code ?? e;
		return r.filter((e) => e.d.code === t).length;
	}, a = (e) => e.reduce((e, t) => e + i(t), 0), o = r.reduce((e, t) => e + (t.d.residents ?? 0), 0), s = e.milestones.filter((e) => /\|red$/i.test(e)).length, c = Ge(e.placed);
	if (t.milestone && !n(t.milestone) || t.milestoneExact && !e.milestones.some((e) => ut(e) === t.milestoneExact.toLowerCase()) || t.notMilestoneExact && e.milestones.some((e) => ut(e) === t.notMilestoneExact.toLowerCase()) || t.notMilestone && n(t.notMilestone) || t.anyMilestone && !t.anyMilestone.some(n) || t.notAnyMilestone && t.notAnyMilestone.some(n) || t.minHearts != null && e.happiness < t.minHearts || t.maxHearts != null && e.happiness > t.maxHearts) return !1;
	if (t.minRes) {
		for (let n of Object.keys(t.minRes)) if (e.resources[n] < (t.minRes[n] ?? 0)) return !1;
	}
	if (t.maxRes) {
		for (let n of Object.keys(t.maxRes)) if (e.resources[n] > (t.maxRes[n] ?? 0)) return !1;
	}
	if (t.hasSticker && !i(t.hasSticker) || t.notSticker && i(t.notSticker) || t.anySticker && !t.anySticker.some((e) => i(e) > 0) || t.noneStickers && t.noneStickers.some((e) => i(e) > 0) || t.allStickers && !t.allStickers.every((e) => i(e) > 0) || t.minUpset != null && e.upset < t.minUpset || t.maxUpset != null && e.upset > t.maxUpset) return !1;
	if (t.countCode) {
		let e = i(t.countCode.code);
		if (t.countCode.min != null && e < t.countCode.min || t.countCode.max != null && e > t.countCode.max) return !1;
	}
	if (t.countAny) {
		let e = a(t.countAny.codes);
		if (t.countAny.min != null && e < t.countAny.min || t.countAny.max != null && e > t.countAny.max) return !1;
	}
	if (t.minResidents != null && o < t.minResidents || t.maxResidents != null && o > t.maxResidents) return !1;
	let l = o - e.upset;
	if (t.minCalmResidents != null && l < t.minCalmResidents || t.maxCalmResidents != null && l > t.maxCalmResidents || t.minRedMilestones != null && s < t.minRedMilestones || t.maxRedMilestones != null && s > t.maxRedMilestones) return !1;
	if (t.minMapRes) {
		let n = We(e.placed);
		for (let e of Object.keys(t.minMapRes)) if (n[e] < (t.minMapRes[e] ?? 0)) return !1;
	}
	if (t.maxMapRes) {
		let n = We(e.placed);
		for (let e of Object.keys(t.maxMapRes)) if (n[e] > (t.maxMapRes[e] ?? 0)) return !1;
	}
	if (t.minMapIcons && (t.minMapIcons.axe != null && c.axe < t.minMapIcons.axe || t.minMapIcons.log != null && c.log < t.minMapIcons.log)) return !1;
	if (t.minMilestoneIcons) {
		let n = $e(e);
		if (t.minMilestoneIcons.star != null && n.star < t.minMilestoneIcons.star || t.minMilestoneIcons.gold != null && n.gold < t.minMilestoneIcons.gold || t.minMilestoneIcons.smiley != null && n.smiley < t.minMilestoneIcons.smiley) return !1;
	}
	if (t.cardStickers) {
		let n = Je(e, t.cardStickers.label, t.cardStickers.kind);
		if (t.cardStickers.min != null && n < t.cardStickers.min || t.cardStickers.max != null && n > t.cardStickers.max) return !1;
	}
	if (t.onNumber) {
		let e = r.find((e) => I(e.d.id) === t.onNumber.number), n = 0;
		if (e) {
			let i = rt(e.p.col, e.p.row, e.d.cols, e.d.rows);
			n = r.filter((n) => n === e || t.onNumber.codes && !t.onNumber.codes.includes(n.d.code) ? !1 : rt(n.p.col, n.p.row, n.d.cols, n.d.rows).some((e) => i.some((t) => e.col === t.col && e.row === t.row))).length;
		}
		if (t.onNumber.min != null && n < t.onNumber.min || t.onNumber.max != null && n > t.onNumber.max) return !1;
	}
	if (t.cardFood) {
		let n = e.cardFood[t.cardFood.label] ?? 0;
		if (t.cardFood.min != null && n < t.cardFood.min || t.cardFood.max != null && n > t.cardFood.max) return !1;
	}
	return !(t.hasBridge && !Ke(e) || t.fenceEnclosedHouse && !qe(e) || t.hasCard && !e.catalog.includes(t.hasCard) || t.hatchetAvailable && !Xe(e) || t.hasLoneTree != null && r.some(({ d: e }) => Ze(e)) !== t.hasLoneTree || t.notCard && e.catalog.includes(t.notCard) || t.built && !n(t.built));
}
function Bt(e, t) {
	let n = [];
	for (let r of Object.keys(e)) {
		let i = e[r] ?? 0;
		if (!i) continue;
		let a = b[r][t];
		n.push(`${i > 0 ? "+" : ""}${i} ${a}`);
	}
	return n.join(t ? ", " : "，");
}
function Vt(e, t) {
	let n = t ? "no effect" : "无效果";
	if (!e || e.none) return n;
	let r = [];
	if (e.res && r.push(Bt(e.res, t)), e.hap && r.push(t ? `${e.hap > 0 ? "+" : ""}${e.hap} happiness` : `${e.hap > 0 ? "+" : ""}${e.hap} 心情`), e.place) {
		let n = e.n ?? 1;
		r.push(t ? `place ${e.place}${n > 1 ? " ×" + n : ""}` : `放置 ${e.place}${n > 1 ? " ×" + n : ""}`);
	}
	if (e.pickPlace && r.push(t ? "place a chosen sticker" : "放置自选贴纸"), e.card && r.push(t ? `gain card ${e.card}` : `获得图鉴牌 ${e.card}`), e.pickCard && r.push(t ? "gain a chosen card" : "获得自选图鉴牌"), e.pickRes && r.push(t ? "gain a chosen resource" : "获得自选资源"), e.exchange && r.push(t ? `exchange up to ${e.exchange.n}` : `兑换至多 ${e.exchange.n}`), e.pickLose && r.push(t ? "lose a chosen resource" : "失去自选资源"), e.empty && r.push(t ? `lose all ${b[e.empty][1]}` : `失去全部${b[e.empty][0]}`), e.cardSticker && r.push(t ? `sticker ${e.cardSticker.kind} on card ${e.cardSticker.label}` : `在图鉴牌 ${e.cardSticker.label} 上放置${e.cardSticker.kind === "heart" ? "爱心" : "进度"}贴纸`), e.cardFood && r.push(t ? `place food on card ${e.cardFood.label}` : `在图鉴牌 ${e.cardFood.label} 上放置食物`), e.freeCardActions && r.push(t ? "card actions cost 0 this turn" : "本回合卡牌行动免费"), e.discount && r.push(t ? `next card action costs ${e.discount} less` : `下一次卡牌行动少付 ${e.discount} 资源`), e.coverMilestoneIcon && r.push(t ? `cover a ${e.coverMilestoneIcon} icon on a milestone` : `覆盖里程碑上的${e.coverMilestoneIcon === "star" ? "★" : "金币"}图标`), e.story && r.push(t ? `read story ${e.story}` : `阅读故事 ${e.story}`), e.milestone && r.push(t ? `milestone ${e.milestone.split("|")[0]}` : `里程碑 ${e.milestone.split("|")[0]}`), e.removeMilestone && r.push(t ? `remove milestone ${e.removeMilestone}` : `移除里程碑 ${e.removeMilestone}`), e.upset && r.push(t ? `+${e.upset} upset` : `+${e.upset} 不满`), e.removeUpset && r.push(t ? `-${e.removeUpset} upset` : `-${e.removeUpset} 不满`), e.extraAction && r.push(t ? "another action" : "额外一次行动"), e.dice && r.push(t ? "roll a die" : "掷骰"), e.seq) for (let n of e.seq) r.push(Vt(n, t));
	return r.filter(Boolean).join(t ? ", " : "，") || n;
}
function Ht(e, t) {
	return e ? Object.keys(e).map((n) => `${e[n] ?? 0} ${b[n][t]}`).join(t ? ", " : "，") : "";
}
function Ut(e) {
	let t = e.currentEvent ? _[e.currentEvent] : void 0;
	if (!t || !t.opts) return [];
	let n = [];
	for (let r of [
		"a",
		"b",
		"c"
	]) {
		let i = t.opts[r];
		if (!i) continue;
		let a;
		if (i.label) a = [i.label.zh, i.label.en];
		else {
			let e = Vt(i.do, 0), t = Vt(i.do, 1);
			a = i.cost ? [`${Ht(i.cost, 0)} · ${e}`, `${Ht(i.cost, 1)} · ${t}`] : [e, t];
		}
		n.push({
			key: r,
			label: a,
			cost: i.cost,
			enabled: It(e, i.cost) && Y(e, i.if)
		});
	}
	return n;
}
function Wt(e) {
	let t = [];
	for (let n of e.inPlay) {
		let r = _[n];
		if (r?.keepActions) for (let i of r.keepActions) t.push({
			id: n,
			key: i.key,
			label: [i.label.zh, i.label.en],
			enabled: It(e, qt(e, i)) && Y(e, i.if)
		});
	}
	return t;
}
function Gt(e) {
	let t = N[e];
	return { actions: t?.actions ?? (t?.action ? [t.action] : []) };
}
function Kt(e, t) {
	if (e.freeCardActions) return {};
	if (!t.cost) return;
	let n = { ...t.cost };
	if (t.reducePer) {
		let r = Ve(t.reducePer.code)?.code ?? t.reducePer.code, i = zt(e).filter((e) => e.d.code === r).length, a = t.reducePer.key;
		n[a] != null && (n[a] = Math.max(0, n[a] - i));
	}
	let r = e.cardDiscountTarget && e.cardDiscountTarget !== `c:${t.label}` ? 0 : e.cardDiscount;
	for (let e of Object.keys(n)) {
		if (r <= 0) break;
		let t = Math.min(r, n[e] ?? 0);
		t > 0 && (n[e] = (n[e] ?? 0) - t, r -= t);
	}
	return n;
}
function qt(e, t) {
	if (!t.cost) return;
	let n = { ...t.cost };
	if (t.reducePer) {
		let r = Ve(t.reducePer.code)?.code ?? t.reducePer.code, i = zt(e).filter((e) => e.d.code === r).length, a = t.reducePer.key;
		n[a] != null && (n[a] = Math.max(0, n[a] - i));
	}
	return n;
}
function Jt(e, t) {
	let [n, r] = t.split("#");
	if (!n) return null;
	let i = Gt(n).actions[Number(r ?? 0)];
	if (!i) return null;
	if ((n === "3a" || n === "3b") && e.cardAttachments[n] === "1E" && i.do.dice) {
		let e = i.do.dice.map((e) => e.on.includes(1) ? {
			...e,
			do: { res: { wood: 2 } }
		} : e);
		return {
			label: n,
			action: {
				...i,
				do: {
					...i.do,
					dice: e
				}
			}
		};
	}
	return {
		label: n,
		action: i
	};
}
function Yt(e) {
	let t = [];
	for (let n of e.catalog) Gt(n).actions.forEach((r, i) => {
		t.push({
			id: n,
			key: `${n}#${i}`,
			label: [r.label.zh, r.label.en],
			enabled: It(e, Kt(e, r)) && Y(e, r.if)
		});
	});
	return t;
}
function Xt(e) {
	let t = W(e.placed), n = /* @__PURE__ */ new Set(), r = [];
	return e.placed.forEach((i, a) => {
		if (t.has(a) || G(e.placed, i)) return;
		let o = x[i.id];
		if (!o || n.has(o.code)) return;
		let s = I(o.id) === "3" ? e.side === "A" ? "3a" : "3b" : void 0;
		!(o.story || s) || s && e.catalog.includes(s) || (n.add(o.code), r.push({
			id: i.id,
			code: o.code,
			story: o.story,
			card: s,
			label: s ? [`${o.code} · 获得图鉴牌 ${s.toUpperCase()}`, `${o.code} · gain catalog card ${s.toUpperCase()}`] : [`${o.code} · 阅读 ${o.story}`, `${o.code} · read ${o.story}`],
			enabled: e.action > 0
		}));
	}), r;
}
function Zt(e) {
	if (e.prompt?.kind !== "exchange") return null;
	let t = e.prompt.n ?? 0, n = !!e.prompt.allow, r = [];
	for (let i of S) for (let a of S) {
		if (i === a || a === "ore" && !n) continue;
		let o = a === "ore" ? 2 : 1;
		if (t < o || e.resources[i] < o || e.resources[a] + 1 > v[a]) continue;
		let s = `${b[i][0]}${o > 1 ? " ×2" : ""} → ${b[a][0]}`, c = `${b[i][1]}${o > 1 ? " ×2" : ""} → ${b[a][1]}`;
		r.push({
			key: `${i}>${a}`,
			label: [s, c],
			enabled: !0
		});
	}
	return r.push({
		key: "done",
		label: ["结束兑换", "Finish exchange"],
		enabled: !0
	}), r;
}
function Qt(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("lose:")) return null;
	let [, t = "", n = "1"] = e.prompt.code.split(":"), r = t ? t.split(",") : [...S], i = [];
	for (let t of r) {
		if (e.resources[t] <= 0) continue;
		let r = Math.min(Number(n) || 1, e.resources[t]);
		i.push({
			key: t,
			label: [`失去 ${r} ${b[t][0]}`, `Lose ${r} ${b[t][1]}`],
			enabled: !0
		});
	}
	return i;
}
function $t(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("invoke:")) return null;
	let [, t = ""] = e.prompt.code.split(":");
	return t.split(",").filter(Boolean).map((t) => ({
		key: t,
		label: [`对图鉴牌 ${t} 执行行动`, `Use catalog card ${t}`],
		enabled: e.catalog.includes(t)
	}));
}
function en(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("icon:")) return null;
	let t = e.prompt.code.slice(5);
	return e.milestones.flatMap((n, r) => {
		let i = ut(n);
		return Qe(n, e.coveredMilestoneIcons)[t] ? [{
			key: String(r),
			label: [n.split("|")[0], i],
			enabled: !0
		}] : [];
	});
}
function tn(e, t, n = {}) {
	let r = 1 + Math.floor(Re(e.seed, e.year, 9e3 + e.cursor++)() * 6);
	if (n.onesAs && r === 1 && (r = n.onesAs), r === 1) {
		e.resources.food = Math.min(v.food, e.resources.food + 1), e.cardFood[t] = 0, J(e, `钓鱼掷出 1：获得 1 食物，弃掉图鉴牌 ${t} 上的食物。`, `Fishing roll 1: gain 1 food and clear card ${t}.`);
		return;
	}
	e.cardFood[t] = Math.min(3, (e.cardFood[t] ?? 0) + 1), e.prompt = {
		kind: "pickOpt",
		code: `fish:${t}:${r}:${n.onesAs ?? 0}:${n.goldIfValue ?? 0}:${+!!n.reroll}`,
		pick: [
			"reel",
			"again",
			...n.reroll ? ["reroll"] : []
		]
	}, J(e, `钓鱼掷出 ${r}：图鉴牌 ${t} 上现有 ${e.cardFood[t]} 份食物。`, `Fishing roll ${r}: ${e.cardFood[t]} food on card ${t}.`);
}
function nn(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("fish:")) return null;
	let [, , , , , t = "0"] = e.prompt.code.split(":"), n = [{
		key: "reel",
		label: ["收线：阅读故事并取走牌上的食物", "Reel in: read the story and take the food"],
		enabled: !0
	}, {
		key: "again",
		label: ["继续钓鱼：重新掷骰", "Keep fishing: roll again"],
		enabled: !0
	}];
	return t === "1" && n.push({
		key: "reroll",
		label: ["花 1 食物重掷", "Spend 1 food to reroll"],
		enabled: e.resources.food >= 1
	}), n;
}
function rn(e, t) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("fish:")) return !1;
	let [, n = "", , r = "0", i = "0", a = "0"] = e.prompt.code.split(":");
	if (e.prompt = null, t === "again") return tn(e, n, {
		onesAs: Number(r) || void 0,
		goldIfValue: Number(i) || void 0,
		reroll: a === "1"
	}), !0;
	if (t === "reroll") return e.resources.food < 1 ? !1 : (--e.resources.food, tn(e, n, {
		onesAs: Number(r) || void 0,
		goldIfValue: Number(i) || void 0,
		reroll: !0
	}), !0);
	let o = e.cardFood[n] ?? 0;
	o > 0 && (e.resources.food = Math.min(v.food, e.resources.food + o), e.cardFood[n] = 0), Number(i) > 0 && o >= Number(i) && (e.resources.gold = Math.min(v.gold, e.resources.gold + 1));
	let s = n === "12b" ? "35" : "36", c = e.cardStickers[s] ??= {
		heart: 0,
		progress: 0
	};
	c.heart += 1;
	let l = c.heart;
	if (l === 3) e.milestones.push("Fisher|bronze");
	else if (l === 6 || l === 9) {
		let t = (t) => e.milestones = e.milestones.filter((e) => !ut(e).includes(t));
		t("fisher"), t("pro angler"), e.milestones.push(l === 6 ? "Veteran Fisher|silver" : "Pro Angler|gold");
	}
	return e.queue.unshift({
		op: "story",
		key: s === "35" ? "35.1" : "36.1"
	}), J(e, `收线：获得图鉴牌 ${n} 上的 ${o} 份食物。`, `Reeled in: gained ${o} food from card ${n}.`), q(e), X(e), !0;
}
function an(e) {
	if (e.prompt?.kind !== "pickOpt" || !e.prompt.code?.startsWith("target:")) return null;
	let t = [];
	for (let n of e.catalog) Gt(n).actions.length && t.push({
		key: `c:${n}`,
		label: [`图鉴牌 ${n}`, `Card ${n}`],
		enabled: !0
	});
	for (let n of e.inPlay) _[n]?.keepActions?.length && t.push({
		key: `e:${n}`,
		label: [`留场牌 ${At(n)}`, `Kept card ${n}`],
		enabled: !0
	});
	return t;
}
function on(e) {
	return e.prompt?.kind === "pickOpt" ? e.prompt.code?.startsWith("st:") ? xt(e) ?? [] : e.prompt.code?.startsWith("ask:") ? Et(e) ?? [] : e.prompt.code?.startsWith("lose:") ? Qt(e) ?? [] : e.prompt.code?.startsWith("invoke:") ? $t(e) ?? [] : e.prompt.code?.startsWith("icon:") ? en(e) ?? [] : e.prompt.code === "ms:red" ? e.milestones.filter((e) => /\|red$/i.test(e)).map((e, t) => {
		let n = e.split("|")[0].trim();
		return {
			key: String(t),
			label: [n, n],
			enabled: !0
		};
	}) : e.prompt.code?.startsWith("fish:") ? nn(e) ?? [] : e.prompt.code?.startsWith("target:") ? an(e) ?? [] : e.prompt.code === "setup:8" ? Ct(e) ?? [] : yt(e) ?? [] : e.prompt?.kind === "exchange" ? Zt(e) ?? [] : [];
}
function sn(e) {
	if (e.cardDiscount = 0, e.cardDiscountTarget = null, e.freeCardActions = !1, e.currentEvent = null, e.action = 0, e.prompt = null, e.queue = [], e.after = null, !e.deck.length) {
		e.phase = "yearEnd";
		return;
	}
	e.phase = "morning";
}
function X(e) {
	!e.prompt && e.phase === "afternoon" && e.action <= 0 && sn(e);
}
function cn(e) {
	return e.happiness + e.milestones.length + e.catalog.length;
}
function ln(e) {
	let t = xe[0];
	for (let n of xe) e.happiness >= n.minHearts && (t = n);
	return t;
}
//#endregion
//#region src/game/rules.ts
var un = {
	oob: "games.cozistickerville.errOob",
	bg: "games.cozistickerville.errBg",
	overlap: "games.cozistickerville.errOverlap",
	river: "games.cozistickerville.errRiver",
	pair: "games.cozistickerville.errPair",
	fold: "games.cozistickerville.errFold",
	target: "games.cozistickerville.invalid"
}, Z = (e) => ({ code: e ? un[e] ?? "games.cozistickerville.invalid" : "games.cozistickerville.invalid" });
function dn(e, t) {
	e.prompt = null, e.queue[0]?.op === "place" && e.queue.shift(), t && e.queue.unshift({
		op: "story",
		key: t
	}), q(e), X(e);
}
var fn = {
	meta: ce,
	saveCompatibility: { version: "3" },
	snapshotCompatibility: {
		version: "1",
		state: pe,
		validate: (e, t) => {
			let n = D.safeParse(t.config);
			if (!n.success || e.owner !== t.players[0]) return !1;
			let r = n.data.checkpoint;
			return r ? e.seed === r.seed && e.side === r.side : e.seed === t.seed && e.side === n.data.side;
		}
	},
	schemas: {
		action: O,
		publicView: he,
		privateView: M,
		config: D
	},
	setup(e, t, n) {
		let r = e.checkpoint ? structuredClone(e.checkpoint) : Nt(t[0], n, e.side);
		return r.owner = t[0], { state: r };
	},
	reduce(e, t, n) {
		if (t.type === "tick") return n.by === "$engine" ? { state: e } : Z();
		if (n.by !== e.owner || e.phase === "done") return Z();
		let r = structuredClone(e);
		if (t.type === "placeStarting") {
			if (r.phase !== "starting") return Z();
			let e = x[t.id];
			if (!e || e.page !== 9) return Z();
			if (r.startingPairs.includes(t.id) || Ft(t.id)?.some((e) => e !== t.id && r.startingPairs.includes(e))) return Z("pair");
			let n = at(r, e, t.col, t.row);
			if (!n.ok) return Z(n.reason);
			r.placed.push({
				id: e.id,
				col: t.col,
				row: t.row
			}), r.startingPairs.push(t.id), J(r, `放置起始贴纸 ${e.code}`, `Placed starting sticker ${e.code}`), r.startingPairs.length >= 8 && (kt(r), J(r, "第一年开始。", "Year 1 begins."), Mt(r, 1));
		} else if (t.type === "placePending") {
			if (r.prompt?.kind !== "place") return Z();
			let e = Ve(r.prompt.code ?? "");
			if (!e) return Z();
			let n = !!r.prompt.cover, i = ot(r, e, t.col, t.row, r.prompt);
			if (!i.ok) return Z(i.reason);
			r.placed.push({
				id: e.id,
				col: t.col,
				row: t.row,
				cover: n || void 0,
				numberOverlay: i.numberOverlay
			}), e.code === "12A" && (r.bridge = !0), J(r, `放置贴纸 ${e.code}`, `Placed sticker ${e.code}`), r.prompt = {
				...r.prompt,
				n: (r.prompt.n ?? 1) - 1
			}, (r.prompt.n ?? 0) <= 0 && dn(r, r.prompt.storyOnPlace ?? (e.code === "4N" && r.prompt.must?.number === "9.1" ? "33.1" : void 0));
		} else if (t.type === "skipPlace") {
			if (r.prompt?.kind !== "place") return Z();
			J(r, `跳过贴纸 ${r.prompt.code}`, `Skipped sticker ${r.prompt.code}`), r.prompt = {
				...r.prompt,
				n: (r.prompt.n ?? 1) - 1
			}, (r.prompt.n ?? 0) <= 0 && dn(r);
		} else if (t.type === "resolvePrompt") {
			if (!r.prompt) return Z();
			let e = r.prompt;
			if (e.kind === "pickOpt") {
				let n = e.code ?? "";
				if (n.startsWith("st:")) {
					if (!St(r, t.key)) return Z();
					X(r);
				} else if (n.startsWith("ask:")) {
					if (!Dt(r, t.key)) return Z();
				} else if (n.startsWith("lose:")) {
					let n = t.key;
					if (!e.pick?.includes(n) || r.resources[n] <= 0) return Z();
					let i = Math.min(e.n ?? 1, r.resources[n]);
					r.resources[n] -= i, r.prompt = null, r.queue[0]?.op === "pickLose" && r.queue.shift(), J(r, `失去 ${i} ${b[n][0]}`, `Lost ${i} ${b[n][1]}`), q(r), X(r);
				} else if (n.startsWith("invoke:")) {
					if (!r.catalog.includes(t.key)) return Z();
					let e = n.split(":"), i = Number(e[2]) || void 0, a = Number(e[3]) || void 0;
					r.prompt = null, r.queue[0]?.op === "invokeCard" && r.queue.shift(), tn(r, t.key, {
						onesAs: i,
						goldIfValue: a,
						reroll: e[4] === "1"
					}), q(r), X(r);
				} else if (n.startsWith("fish:")) {
					if (!rn(r, t.key)) return Z();
				} else if (n.startsWith("icon:")) {
					let e = r.milestones[Number(t.key)], i = n.slice(5);
					if (!e || !on(r).some((e) => e.key === t.key)) return Z();
					r.coveredMilestoneIcons.push({
						milestone: e,
						icon: i
					}), r.prompt = null, r.queue[0]?.op === "coverMilestoneIcon" && r.queue.shift(), J(r, `用不满覆盖里程碑「${e.split("|")[0]}」的图标`, `Covered a ${i} icon on ${e}.`), q(r), X(r);
				} else if (n === "ms:red") {
					let e = r.milestones.filter((e) => /\|red$/i.test(e))[Number(t.key)];
					if (!Number.isInteger(Number(t.key)) || !e) return Z();
					r.milestones = r.milestones.filter((t) => t !== e);
					let n = e.split("|")[0].trim();
					r.prompt = null, r.queue[0]?.op === "removeRedMilestone" && r.queue.shift(), J(r, `移除红色里程碑「${n}」`, `Removed the red milestone ${n}`), q(r), X(r);
				} else if (n.startsWith("target:")) {
					let e = n.slice(7), i = t.key, [a, o] = i.split(":");
					if (a === "c" && !r.catalog.includes(o) || a === "e" && !r.inPlay.includes(o)) return Z();
					r.prompt = null, r.queue[0]?.op === "pickTarget" && r.queue.shift(), e === "discount" ? (r.cardDiscount = 1, r.cardDiscountTarget = i, J(r, `选择卡牌 ${o}：下一次行动少付 1 资源`, `Chose card ${o}: next action costs 1 less`)) : (a === "c" ? r.catalog = r.catalog.filter((e) => e !== o) : r.inPlay = r.inPlay.filter((e) => e !== o), r.action += 1, J(r, `弃掉卡牌 ${o}：额外行动一次`, `Discarded card ${o}: one extra action`)), q(r), X(r);
				} else if (n === "setup:8") {
					if (!wt(r, t.key)) return Z();
				} else if (!bt(r, t.key)) return Z();
			} else if (e.kind === "name") r.villageName = t.key.slice(0, 40), r.prompt = null, J(r, `村庄命名为「${r.villageName}」。`, `The village is named “${r.villageName}”.`), q(r), X(r);
			else if (e.kind === "puzzle") {
				let [n, i] = (e.code ?? "").split(":"), a = t.key.trim();
				if (!n || !a) return Z();
				if (i === "story") {
					let e = ie[n];
					if (e && a !== e) return Z();
					r.prompt = null, r.queue.unshift({
						op: "story",
						key: a
					});
				} else {
					if (!(ae[n] ?? []).includes(a)) return Z();
					r.prompt = null, r.queue.unshift({
						op: "card",
						key: a
					});
				}
				q(r), X(r);
			} else if (e.kind === "clock") {
				let e = /^(\d{1,2}):(\d{2})$/.exec(t.key), n = e ? Number(e[2]) : -1, i = n === 0 ? "28.2" : n === 15 ? "28.3" : n === 30 ? "28.4" : n === 45 ? "28.5" : null;
				if (!i) return J(r, "分针不在整点、15、30 或 45 分，无法赴约。", "The minute hand is not at 0, 15, 30 or 45; the appointment cannot be kept."), Z();
				r.prompt = null, r.queue.unshift({
					op: "story",
					key: i
				}), q(r), X(r);
			} else if (r.phase !== "placing") return Z();
			else if (e.kind === "pickPlace") {
				if (!e.pick?.includes(t.key)) return Z();
				r.prompt = null, r.queue[0]?.op === "pickPlace" && r.queue.shift(), r.queue.unshift({
					op: "place",
					code: t.key,
					n: 1
				}), q(r);
			} else if (e.kind === "pickCard") {
				if (!e.pick?.includes(t.key)) return Z();
				r.prompt = null, r.queue[0]?.op === "pickCard" && r.queue.shift(), r.queue.unshift({
					op: "card",
					key: t.key
				}), J(r, `选择图鉴牌 ${t.key}`, `Chose catalog card ${t.key}`), q(r);
			} else if (e.kind === "pickRes") {
				if (!e.pick?.includes(t.key)) return Z();
				let n = t.key, i = e.n ?? 1;
				r.resources[n] = Math.min(v[n], r.resources[n] + i), r.prompt = null, r.queue[0]?.op === "pickRes" && r.queue.shift(), J(r, `获得资源 ${t.key} ×${i}`, `Gained ${t.key} ×${i}`), q(r);
			} else if (e.kind === "exchange") {
				if (t.key === "done") r.prompt = null, r.queue[0]?.op === "exchange" && r.queue.shift(), q(r), X(r);
				else {
					let [n, i] = t.key.split(">");
					if (!S.includes(n) || !S.includes(i) || n === i) return Z();
					let a = i === "ore" ? 2 : 1;
					if (i === "ore" && !e.allow || (e.n ?? 0) < a || r.resources[n] < a || r.resources[i] + 1 > v[i]) return Z();
					r.resources[n] -= a, r.resources[i] += 1, J(r, `兑换 1 ${b[i][0]}`, `Exchanged for 1 ${b[i][1]}`);
					let o = (e.n ?? 0) - a;
					o <= 0 ? (r.prompt = null, r.queue[0]?.op === "exchange" && r.queue.shift(), q(r), X(r)) : (r.prompt = {
						...e,
						n: o
					}, r.queue[0]?.op === "exchange" && (r.queue[0].n = o));
				}
			} else return Z();
		} else if (t.type === "draw") {
			if (r.phase !== "morning") return Z();
			if (!r.deck.length) return r.phase = "yearEnd", {
				state: r,
				fx: []
			};
			let e = r.deck.pop();
			r.currentEvent = e;
			let t = _[e];
			if (J(r, `第 ${r.year} 年 · 事件 ${t?.num ?? "?"}`, `Year ${r.year} · Event ${t?.num ?? "?"}`), t?.opts) Ut(r).every((e) => !e.enabled) ? (J(r, `事件 ${t.num} 无可用选项，跳过。`, `Event ${t.num}: no option available, skipped.`), t.kind === "keep" && !r.inPlay.includes(e) && r.inPlay.push(e), r.action = Math.max(1, r.action), r.phase = "afternoon") : r.phase = "choice";
			else {
				if (t?.kind === "keep") {
					let n = !t.enter || Y(r, t.enter.if);
					n && !r.inPlay.includes(e) && r.inPlay.push(e), n || (J(r, `弃掉事件牌 ${t.num}（入场条件未满足）。`, `Discarded event ${t.num} (entry condition not met).`), t.enter?.elseDo && r.queue.push(...K(r, t.enter.elseDo)));
				}
				r.action = Math.max(1, r.action), r.phase = "afternoon", r.queue.length && (r.after = "afternoon", q(r));
			}
		} else if (t.type === "choice") {
			if (r.phase !== "choice" || !r.currentEvent) return Z();
			let e = Ut(r).find((e) => e.key === t.opt);
			if (!e || !e.enabled) return Z();
			let n = _[r.currentEvent], i = n?.opts?.[t.opt];
			Rt(r, i?.cost), r.action = 1, r.queue.push(...K(r, i?.do)), n?.kind === "keep" && !r.inPlay.includes(n.id) && r.inPlay.push(n.id), r.after = "afternoon", q(r);
		} else if (t.type === "useSticker") {
			if (r.phase !== "afternoon" || r.action <= 0) return Z();
			let e = Xt(r).find((e) => e.code === t.code);
			if (!e) return Z();
			e.card ? (r.queue.push({
				op: "card",
				key: e.card
			}), J(r, `贴纸行动：获得图鉴牌 ${e.card.toUpperCase()}`, `Sticker action: gain catalog card ${e.card.toUpperCase()}`)) : e.story && (r.queue.push({
				op: "story",
				key: e.story
			}), J(r, `贴纸行动：阅读故事 ${e.story}`, `Sticker action: read story ${e.story}`)), --r.action, q(r), X(r);
		} else if (t.type === "useCard") {
			if (r.phase !== "afternoon" || r.action <= 0) return Z();
			let e = Jt(r, t.key);
			if (!e || !r.catalog.includes(e.label)) return Z();
			let n = e.action;
			if (!Y(r, n.if) || !It(r, Kt(r, n))) return Z();
			Rt(r, Kt(r, n)), r.cardDiscount = 0, --r.action, e.label === "12a" || e.label === "12b" ? (tn(r, e.label), J(r, `使用图鉴牌 ${e.label} 钓鱼`, `Fishing on card ${e.label}`), q(r), X(r)) : (r.queue.push(...K(r, n.do)), n.followUp && r.queue.push({
				op: "branch",
				key: n.followUp
			}), n.discard && (r.catalog = r.catalog.filter((t) => t !== e.label)), J(r, `使用图鉴牌 ${e.label}`, `Used catalog card ${e.label}`), q(r), X(r));
		} else if (t.type === "useKeep") {
			if (r.phase !== "afternoon" || r.action <= 0) return Z();
			let e = _[t.id], n = e?.keepActions?.find((e) => e.key === t.key);
			if (!e || !r.inPlay.includes(t.id) || !n || !Y(r, n.if) || !It(r, qt(r, n))) return Z();
			Rt(r, qt(r, n)), r.queue.push(...K(r, n.do)), n.discard && (r.inPlay = r.inPlay.filter((e) => e !== t.id)), J(r, `使用留场牌：${n.label.zh}`, `Used kept card: ${n.label.en}`), --r.action, q(r), X(r);
		} else if (t.type === "cardSticker") {
			if (!r.catalog.includes(t.label)) return Z();
			let e = r.cardStickers[t.label] ??= {
				heart: 0,
				progress: 0
			};
			e[t.kind] += 1, J(r, `在图鉴牌 ${t.label} 上放置${t.kind === "heart" ? "爱心" : "进度"}贴纸`, `Placed a ${t.kind} sticker on card ${t.label}`);
		} else if (t.type === "pageSticker") {
			if (!/^\d{1,2}$/.test(t.page)) return Z();
			let e = `p${t.page}`, n = r.cardStickers[e] ??= {
				heart: 0,
				progress: 0
			};
			n[t.kind] += 1, J(r, `在故事第 ${t.page} 页放置${t.kind === "heart" ? "爱心" : "进度"}贴纸`, `Placed a ${t.kind} sticker on story page ${t.page}`);
		} else if (t.type === "birdWatch") {
			if (![
				"37",
				"38",
				"39"
			].includes(t.label) || !r.catalog.includes(t.label)) return Z();
			let e = r.cardStickers[t.label] ??= {
				heart: 0,
				progress: 0
			};
			e.heart += 1, J(r, `观鸟：在图鉴牌 ${t.label} 上放置 1 枚爱心贴纸`, `Birdwatching: placed a heart on card ${t.label}`), e.heart >= 4 && (r.catalog = r.catalog.filter((e) => e !== t.label), t.label === "37" ? r.queue.push({
				op: "card",
				key: "38"
			}) : t.label === "38" ? r.queue.push({
				op: "card",
				key: "39"
			}) : (r.milestones = r.milestones.filter((e) => !e.split("|")[0].trim().toLowerCase().includes("avian enthusiast")), r.queue.push({
				op: "milestone",
				key: "Ornithologist|gold"
			})), q(r));
		} else if (t.type === "readPrev") {
			if (!r.catalog.includes("34")) return Z();
			r.queue.push({
				op: "story",
				key: t.entry
			}), J(r, `研究课题：改读故事 ${t.entry}`, `Research Topics: read ${t.entry} instead`), q(r);
		} else if (t.type === "endTurn") {
			if (r.phase !== "afternoon" && r.phase !== "placing") return Z();
			sn(r);
		} else if (t.type === "endYear") {
			if (r.phase !== "yearEnd" || r.yearEnding) return Z();
			r.yearEnding = !0, r.yearEndQueue = [...r.inPlay.map((e) => `e:${e}`), ...r.catalog.map((e) => `c:${e}`)].filter((e) => !!mt(e)), r.after = null, q(r);
		}
		return r.serial++, {
			state: r,
			fx: []
		};
	},
	viewFor(e, t) {
		let n = e.phase === "choice" ? Ut(e).map((e) => ({
			key: e.key,
			label: e.label,
			enabled: e.enabled
		})) : [], r = e.phase === "afternoon" ? Wt(e) : [], i = e.phase === "afternoon" ? Yt(e) : [], a = e.phase === "afternoon" ? Xt(e) : [], o = on(e).map((e) => ({
			key: e.key,
			label: e.label,
			enabled: e.enabled
		}));
		return {
			public: {
				campaignId: e.campaignId,
				side: e.side,
				year: e.year,
				phase: e.phase,
				resources: e.resources,
				happiness: e.happiness,
				action: e.action,
				upset: e.upset,
				progress: e.progress,
				placed: e.placed,
				startingPairs: e.startingPairs,
				deckCount: e.deck.length,
				discard: e.discard,
				currentEvent: e.currentEvent,
				inPlay: e.inPlay,
				prompt: e.prompt,
				promptOptions: o,
				catalog: e.catalog,
				story: e.story,
				milestones: e.milestones,
				cardStickers: e.cardStickers,
				storyEntryStickers: e.storyEntryStickers,
				cardAttachments: e.cardAttachments,
				cardFood: e.cardFood,
				cardSpaces: e.cardSpaces,
				bridge: Ke(e),
				cardDiscount: e.cardDiscount,
				cardDiscountTarget: e.cardDiscountTarget,
				freeCardActions: e.freeCardActions,
				villageName: e.villageName,
				coveredMilestoneIcons: e.coveredMilestoneIcons,
				choices: n,
				keepActions: r.map((e) => ({
					id: e.id,
					key: e.key,
					label: e.label,
					enabled: e.enabled
				})),
				catalogActions: i.map((e) => ({
					id: e.id,
					key: e.key,
					label: e.label,
					enabled: e.enabled
				})),
				stickerActions: a,
				ending: e.phase === "done" ? ln(e).key : null,
				mapIcons: We(e.placed),
				log: e.log
			},
			private: { checkpoint: t === e.owner ? structuredClone(e) : null }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: [e.owner],
			ranking: [e.owner],
			scores: { [e.owner]: cn(e) }
		} : { phase: e.phase };
	}
}, pn = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), mn = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), hn = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), gn = (e) => {
	let t = hn(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, _n = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, vn = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, yn = t({}), bn = () => i(yn), xn = r(({ color: e, size: t, strokeWidth: r, absoluteStrokeWidth: i, className: a = "", children: o, iconNode: s, ...c }, l) => {
	let { size: u = 24, strokeWidth: d = 2, absoluteStrokeWidth: ee = !1, color: te = "currentColor", className: ne = "" } = bn() ?? {}, f = i ?? ee ? Number(r ?? d) * 24 / Number(t ?? u) : r ?? d;
	return n("svg", {
		ref: l,
		..._n,
		width: t ?? u ?? _n.width,
		height: t ?? u ?? _n.height,
		stroke: e ?? te,
		strokeWidth: f,
		className: pn("lucide", ne, a),
		...!o && !vn(c) && { "aria-hidden": "true" },
		...c
	}, [...s.map(([e, t]) => n(e, t)), ...Array.isArray(o) ? o : [o]]);
}), Sn = (e, t) => {
	let i = r(({ className: r, ...i }, a) => n(xn, {
		ref: a,
		iconNode: t,
		className: pn(`lucide-${mn(gn(e))}`, `lucide-${e}`, r),
		...i
	}));
	return i.displayName = gn(e), i;
}, Cn = Sn("award", [["path", {
	d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
	key: "1yiouv"
}], ["circle", {
	cx: "12",
	cy: "8",
	r: "6",
	key: "1vp47v"
}]]), wn = Sn("book-open", [["path", {
	d: "M12 5v16",
	key: "1f6ucr"
}], ["path", {
	d: "M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z",
	key: "1fyvmf"
}]]), Tn = Sn("cloud-rain", [
	["path", {
		d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
		key: "1pljnt"
	}],
	["path", {
		d: "M16 14v6",
		key: "1j4efv"
	}],
	["path", {
		d: "M8 14v6",
		key: "17c4r9"
	}],
	["path", {
		d: "M12 16v6",
		key: "c8a4gj"
	}]
]), En = Sn("crown", [["path", {
	d: "M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",
	key: "1vdc57"
}], ["path", {
	d: "M5 21h14",
	key: "11awu3"
}]]), Dn = Sn("heart", [["path", {
	d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
	key: "mvr1a0"
}]]), On = Sn("notebook-text", [
	["path", {
		d: "M2 6h4",
		key: "aawbzj"
	}],
	["path", {
		d: "M2 10h4",
		key: "l0bgd4"
	}],
	["path", {
		d: "M2 14h4",
		key: "1gsvsf"
	}],
	["path", {
		d: "M2 18h4",
		key: "1bu2t1"
	}],
	["rect", {
		width: "16",
		height: "20",
		x: "4",
		y: "2",
		rx: "2",
		key: "1nb95v"
	}],
	["path", {
		d: "M9.5 8h5",
		key: "11mslq"
	}],
	["path", {
		d: "M9.5 12H16",
		key: "ktog6x"
	}],
	["path", {
		d: "M9.5 16H14",
		key: "p1seyn"
	}]
]), kn = Sn("panels-top-left", [
	["rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "3",
		rx: "2",
		key: "afitv7"
	}],
	["path", {
		d: "M3 9h18",
		key: "1pudct"
	}],
	["path", {
		d: "M9 21V9",
		key: "1oto5p"
	}]
]), An = Sn("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]), jn = Sn("zoom-in", [
	["circle", {
		cx: "11",
		cy: "11",
		r: "8",
		key: "4ej97u"
	}],
	["line", {
		x1: "21",
		x2: "16.65",
		y1: "21",
		y2: "16.65",
		key: "13gj7c"
	}],
	["line", {
		x1: "11",
		x2: "11",
		y1: "8",
		y2: "14",
		key: "1vmskp"
	}],
	["line", {
		x1: "8",
		x2: "14",
		y1: "11",
		y2: "11",
		key: "durymu"
	}]
]), Mn = "town-v1";
async function Nn() {
	let e = await te();
	return e.values[Mn] ? pe.parse(JSON.parse(e.values[Mn])) : null;
}
async function Pn(e) {
	let t = await te();
	for (let n = 0; n < 5; n++) {
		let n = t.values[Mn], r = n ? pe.parse(JSON.parse(n)) : null;
		if (r?.campaignId === e.campaignId && r.serial > e.serial) return "newer";
		if (r?.campaignId === e.campaignId && r.serial === e.serial) return JSON.stringify(r) === JSON.stringify(e) ? "saved" : "newer";
		let i = await ne({
			revision: t.revision,
			values: {
				...t.values,
				[Mn]: JSON.stringify(e)
			}
		});
		if (i.status === "saved") return "saved";
		if (i.snapshot.values[Mn] !== t.values[Mn]) return "newer";
		t = i.snapshot;
	}
	throw Error("storage-conflict");
}
//#endregion
//#region src/game/data/milestone-banners.ts
var Fn = {
	Adventurer: {
		name: "Adventurer",
		zh: "冒险家",
		category: "THE MINE",
		categoryZh: "矿场",
		from: "#dead0d",
		to: "#e4bd10",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Astronomer: {
		name: "Astronomer",
		zh: "天文学家",
		category: "OBSERVATORY",
		categoryZh: "天文台",
		from: "#dadada",
		to: "#d1d3d4",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Avian Enthusiast": {
		name: "Avian Enthusiast",
		zh: "鸟类爱好者",
		category: "BIRD WATCHING 2",
		categoryZh: "观鸟 2",
		from: "#bbbcbd",
		to: "#e5e8e7",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Bear Tamer": {
		name: "Bear Tamer",
		zh: "驯熊师",
		category: "HONEY TREE",
		categoryZh: "蜜树",
		from: "#bbbdbd",
		to: "#dbdfe0",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Big Savings Account": {
		name: "Big Savings Account",
		zh: "大额存款",
		category: "BANK",
		categoryZh: "银行",
		from: "#d7d8d7",
		to: "#b7bcbc",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Birder: {
		name: "Birder",
		zh: "观鸟者",
		category: "BIRD WATCHING 1",
		categoryZh: "观鸟 1",
		from: "#ca884b",
		to: "#d89c63",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Business Mogul": {
		name: "Business Mogul",
		zh: "商业大亨",
		category: "FINALE",
		categoryZh: "终局",
		from: "#e4ab18",
		to: "#e4b820",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Camp Counselor": {
		name: "Camp Counselor",
		zh: "营地辅导员",
		category: "SUMMER CAMP",
		categoryZh: "夏令营",
		from: "#d8d9da",
		to: "#cdd0d1",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Conservationist: {
		name: "Conservationist",
		zh: "环保主义者",
		category: "FINALE",
		categoryZh: "终局",
		from: "#e0bd0a",
		to: "#e5e456",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Dating: {
		name: "Dating",
		zh: "恋爱中",
		category: "FARMER DILL",
		categoryZh: "农夫迪尔",
		from: "#c27e41",
		to: "#c98a51",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Degenerate: {
		name: "Degenerate",
		zh: "堕落者",
		category: "JESSIE",
		categoryZh: "杰西",
		from: "#d2323d",
		to: "#d73b45",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Dictator: {
		name: "Dictator",
		zh: "独裁者",
		category: "POLITICS 1",
		categoryZh: "政治 1",
		from: "#d0a47c",
		to: "#c68c56",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Expert Baker": {
		name: "Expert Baker",
		zh: "烘焙专家",
		category: "BAKERY 2",
		categoryZh: "烘焙坊 2",
		from: "#e5d633",
		to: "#e4c92f",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Explorer: {
		name: "Explorer",
		zh: "探险家",
		category: "THE MINE",
		categoryZh: "矿场",
		from: "#d8dbdd",
		to: "#dee0e3",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Fake News": {
		name: "Fake News",
		zh: "假新闻",
		category: "NEWSPAPER",
		categoryZh: "报社",
		from: "#d23d45",
		to: "#c6343f",
		star: 0,
		gold: 1,
		smiley: 0
	},
	"Famous Baker": {
		name: "Famous Baker",
		zh: "著名烘焙师",
		category: "BAKERY 1",
		categoryZh: "烘焙坊 1",
		from: "#b7bbba",
		to: "#d2d2d3",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Famous Chef": {
		name: "Famous Chef",
		zh: "名厨",
		category: "RESTAURANT 1",
		categoryZh: "餐馆 1",
		from: "#d3d6d8",
		to: "#a5a9a8",
		star: 1,
		gold: 1,
		smiley: 0
	},
	"Farm Hand": {
		name: "Farm Hand",
		zh: "农场帮工",
		category: "FARMING 1",
		categoryZh: "农业 1",
		from: "#b27e4c",
		to: "#d6a779",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Fashionable: {
		name: "Fashionable",
		zh: "时尚达人",
		category: "CLOTHING STORE 1",
		categoryZh: "服装店 1",
		from: "#d9dadb",
		to: "#b8bbbd",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Finder of Secrets": {
		name: "Finder of Secrets",
		zh: "秘密发现者",
		category: "TREASURE 2",
		categoryZh: "宝藏 2",
		from: "#e4b328",
		to: "#e0cc31",
		star: 2,
		gold: 2,
		smiley: 0
	},
	Fisher: {
		name: "Fisher",
		zh: "渔夫",
		category: "FISHING 1",
		categoryZh: "渔业 1",
		from: "#cd8e57",
		to: "#deb68b",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Veteran Fisher": {
		name: "Veteran Fisher",
		zh: "资深渔夫",
		category: "FISHING 2",
		categoryZh: "渔业 2",
		from: "#b8c0c0",
		to: "#d5d5d0",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Glamorous: {
		name: "Glamorous",
		zh: "魅力四射",
		category: "CLOTHING STORE 2",
		categoryZh: "服装店 2",
		from: "#e0dc36",
		to: "#e6d942",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Governor: {
		name: "Governor",
		zh: "州长",
		category: "POLITICS 2",
		categoryZh: "政治 2",
		from: "#c0c0c0",
		to: "#dbdbdb",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Greedy Company": {
		name: "Greedy Company",
		zh: "贪婪公司",
		category: "FACTORY",
		categoryZh: "工厂",
		from: "#b7b9b8",
		to: "#bec1c0",
		star: 1,
		gold: 2,
		smiley: 0
	},
	"Green Thumb": {
		name: "Green Thumb",
		zh: "园艺高手",
		category: "FARMING 2",
		categoryZh: "农业 2",
		from: "#cfd2d3",
		to: "#dfe2e3",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Hard Winter": {
		name: "Hard Winter",
		zh: "严冬",
		category: "EVENT",
		categoryZh: "事件",
		from: "#cf3841",
		to: "#d0323d",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Honest Company": {
		name: "Honest Company",
		zh: "诚信公司",
		category: "FACTORY",
		categoryZh: "工厂",
		from: "#e6b215",
		to: "#d2d362",
		star: 2,
		gold: 1,
		smiley: 0
	},
	"Hot Goods": {
		name: "Hot Goods",
		zh: "赃物",
		category: "STOLEN ORE",
		categoryZh: "失窃矿石",
		from: "#d23b45",
		to: "#d0323f",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Hunger: {
		name: "Hunger",
		zh: "饥饿",
		category: "EVENT",
		categoryZh: "事件",
		from: "#cf353b",
		to: "#d33740",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Immortalized: {
		name: "Immortalized",
		zh: "名垂青史",
		category: "STATUE",
		categoryZh: "雕像",
		from: "#bababa",
		to: "#c3c5c6",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Investment: {
		name: "Investment",
		zh: "投资",
		category: "",
		categoryZh: "",
		from: "#d39e6d",
		to: "#c68854",
		star: 0,
		gold: 1,
		smiley: 0
	},
	Kind: {
		name: "Kind",
		zh: "善良",
		category: "FLISE THE PAINTER",
		categoryZh: "画家弗莉丝",
		from: "#cfcfcf",
		to: "#b3b9ba",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Legendary Rancher": {
		name: "Legendary Rancher",
		zh: "传奇牧场主",
		category: "FARMING 3",
		categoryZh: "农业 3",
		from: "#e1dc39",
		to: "#e0af11",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Little Genius": {
		name: "Little Genius",
		zh: "小天才",
		category: "SCHOOL",
		categoryZh: "学校",
		from: "#bfc1c0",
		to: "#d5d6d6",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Loan: {
		name: "Loan",
		zh: "贷款",
		category: "EVENT",
		categoryZh: "事件",
		from: "#d03844",
		to: "#d33640",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Lodge Apprentice": {
		name: "Lodge Apprentice",
		zh: "小屋学徒",
		category: "LODGE 2",
		categoryZh: "小屋 2",
		from: "#d7dbdb",
		to: "#bec0bf",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Lodge Master": {
		name: "Lodge Master",
		zh: "小屋大师",
		category: "LODGE 3",
		categoryZh: "小屋 3",
		from: "#e4b32a",
		to: "#dddd4d",
		star: 2,
		gold: 2,
		smiley: 0
	},
	"Lodge Member": {
		name: "Lodge Member",
		zh: "小屋成员",
		category: "LODGE 1",
		categoryZh: "小屋 1",
		from: "#deba8a",
		to: "#c6915b",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Lucky: {
		name: "Lucky",
		zh: "幸运儿",
		category: "",
		categoryZh: "",
		from: "#dcaf7e",
		to: "#dcae83",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Married: {
		name: "Married",
		zh: "已婚",
		category: "FARMER DILL",
		categoryZh: "农夫迪尔",
		from: "#e2d739",
		to: "#e8b629",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Master Chef": {
		name: "Master Chef",
		zh: "厨艺大师",
		category: "RESTAURANT 2",
		categoryZh: "餐馆 2",
		from: "#ddd832",
		to: "#dac736",
		star: 2,
		gold: 1,
		smiley: 0
	},
	"Master of Agriculture": {
		name: "Master of Agriculture",
		zh: "农业大师",
		category: "FARMING 3",
		categoryZh: "农业 3",
		from: "#e2cf2f",
		to: "#e3c111",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Matchmaker: {
		name: "Matchmaker",
		zh: "媒人",
		category: "FARMER DILL",
		categoryZh: "农夫迪尔",
		from: "#b9baba",
		to: "#dce2e3",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Mayor: {
		name: "Mayor",
		zh: "市长",
		category: "POLITICS 1",
		categoryZh: "政治 1",
		from: "#dab88a",
		to: "#c68756",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Miracle Medicine": {
		name: "Miracle Medicine",
		zh: "灵丹妙药",
		category: "PROFESSOR FERGUSON",
		categoryZh: "弗格森教授",
		from: "#e3e4e4",
		to: "#b0b5b3",
		star: 1,
		gold: 1,
		smiley: 0
	},
	Monarch: {
		name: "Monarch",
		zh: "君主",
		category: "POLITICS 3",
		categoryZh: "政治 3",
		from: "#e5b11a",
		to: "#e2de4d",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"New Family": {
		name: "New Family",
		zh: "新家庭",
		category: "FINALE",
		categoryZh: "终局",
		from: "#dfb11c",
		to: "#e2df4e",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Noble: {
		name: "Noble",
		zh: "贵族",
		category: "MOTHER",
		categoryZh: "母亲",
		from: "#d2d2d2",
		to: "#e1e3e4",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Ore Tycoon": {
		name: "Ore Tycoon",
		zh: "矿石大亨",
		category: "TRAINSTATION",
		categoryZh: "火车站",
		from: "#b8bebd",
		to: "#c6c8c7",
		star: 1,
		gold: 1,
		smiley: 0
	},
	Ornithologist: {
		name: "Ornithologist",
		zh: "鸟类学家",
		category: "BIRD WATCHING 3",
		categoryZh: "观鸟 3",
		from: "#dcd943",
		to: "#e6b424",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Paleontologist: {
		name: "Paleontologist",
		zh: "古生物学家",
		category: "BOBTHEMINER",
		categoryZh: "矿工鲍勃",
		from: "#e7e8e7",
		to: "#b7bdbe",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Patron of the Arts": {
		name: "Patron of the Arts",
		zh: "艺术赞助人",
		category: "QUTDOOR STAGE",
		categoryZh: "露天舞台",
		from: "#c9cacb",
		to: "#dbdddf",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Perfect Village": {
		name: "Perfect Village",
		zh: "完美村庄",
		category: "FINALE",
		categoryZh: "终局",
		from: "#e2b018",
		to: "#e0ab1b",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Pet Lover": {
		name: "Pet Lover",
		zh: "宠物爱好者",
		category: "PET SHOP 1",
		categoryZh: "宠物店 1",
		from: "#cccfcf",
		to: "#c4c7c7",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Pet Rescuer": {
		name: "Pet Rescuer",
		zh: "宠物救助者",
		category: "PET SHOP 2",
		categoryZh: "宠物店 2",
		from: "#e3d537",
		to: "#e2b020",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Poisoned: {
		name: "Poisoned",
		zh: "中毒",
		category: "THE MINE",
		categoryZh: "矿场",
		from: "#cf313c",
		to: "#d4303c",
		star: 0,
		gold: 0,
		smiley: 0
	},
	President: {
		name: "President",
		zh: "总统",
		category: "POLITICS 3",
		categoryZh: "政治 3",
		from: "#e4b229",
		to: "#e7ca3a",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Pro Angler": {
		name: "Pro Angler",
		zh: "钓鱼高手",
		category: "FISHING 3",
		categoryZh: "渔业 3",
		from: "#e1b110",
		to: "#e5de3e",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Rancher: {
		name: "Rancher",
		zh: "牧场主",
		category: "FARMING 1",
		categoryZh: "农业 1",
		from: "#c68a54",
		to: "#d8a574",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Runner Up": {
		name: "Runner Up",
		zh: "亚军",
		category: "POLITICS 1",
		categoryZh: "政治 1",
		from: "#dbb687",
		to: "#cc935e",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Savings Account": {
		name: "Savings Account",
		zh: "存款",
		category: "BANK",
		categoryZh: "银行",
		from: "#dca777",
		to: "#ddac7f",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Secret Spy": {
		name: "Secret Spy",
		zh: "秘密间谍",
		category: "CLOCK TOWER",
		categoryZh: "钟楼",
		from: "#c9c9c9",
		to: "#e6e8e8",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Sleuth: {
		name: "Sleuth",
		zh: "侦探",
		category: "REX DANGER",
		categoryZh: "雷克斯·丹杰",
		from: "#e3df4b",
		to: "#e2af17",
		star: 2,
		gold: 0,
		smiley: 0
	},
	Termites: {
		name: "Termites",
		zh: "白蚁",
		category: "EVENT",
		categoryZh: "事件",
		from: "#d13541",
		to: "#d33140",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Test Subject": {
		name: "Test Subject",
		zh: "试验对象",
		category: "",
		categoryZh: "",
		from: "#d0323c",
		to: "#d6373f",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Thriving Community": {
		name: "Thriving Community",
		zh: "繁荣社区",
		category: "FINALE",
		categoryZh: "终局",
		from: "#e2bb2d",
		to: "#e0df5d",
		star: 2,
		gold: 0,
		smiley: 0
	},
	"Treasure Hunter": {
		name: "Treasure Hunter",
		zh: "寻宝者",
		category: "TREASURE 1",
		categoryZh: "宝藏 1",
		from: "#d29460",
		to: "#dda370",
		star: 0,
		gold: 0,
		smiley: 0
	},
	"Trustworthy News": {
		name: "Trustworthy News",
		zh: "可信新闻",
		category: "NEWSPAPER",
		categoryZh: "报社",
		from: "#b3bbba",
		to: "#b9c1bf",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Tyrant: {
		name: "Tyrant",
		zh: "暴君",
		category: "POLITICS 2",
		categoryZh: "政治 2",
		from: "#e0e2e4",
		to: "#b3bcbb",
		star: 1,
		gold: 0,
		smiley: 0
	},
	Unrest: {
		name: "Unrest",
		zh: "动荡",
		category: "",
		categoryZh: "",
		from: "#d13a44",
		to: "#d13440",
		star: 0,
		gold: 0,
		smiley: 0
	},
	Upstanding: {
		name: "Upstanding",
		zh: "正直者",
		category: "JESSIE",
		categoryZh: "杰西",
		from: "#bcbdbc",
		to: "#e2e4e5",
		star: 1,
		gold: 0,
		smiley: 0
	},
	"Veteran Rancher": {
		name: "Veteran Rancher",
		zh: "资深牧场主",
		category: "FARMING 2",
		categoryZh: "农业 2",
		from: "#dde0e1",
		to: "#d5d6d6",
		star: 1,
		gold: 0,
		smiley: 0
	}
}, In = {
	Adventurer: "冒险家",
	Astronomer: "天文学家",
	"Avian Enthusiast": "鸟类爱好者",
	"Bear Tamer": "驯熊师",
	"Big Savings Account": "大额存款",
	Birder: "观鸟者",
	"Business Mogul": "商业大亨",
	"Camp Counselor": "营地辅导员",
	Conservationist: "环保主义者",
	Dating: "恋爱中",
	Degenerate: "堕落者",
	Dictator: "独裁者",
	"Expert Baker": "烘焙专家",
	Explorer: "探险家",
	"Fake News": "假新闻",
	"Famous Baker": "著名烘焙师",
	"Famous Chef": "名厨",
	"Farm Hand": "农场帮工",
	Fashionable: "时尚达人",
	"Finder of Secrets": "秘密发现者",
	Fisher: "渔夫",
	Glamorous: "魅力四射",
	Governor: "州长",
	"Greedy Company": "贪婪公司",
	"Green Thumb": "园艺高手",
	"Hard Winter": "严冬",
	"Honest Company": "诚信公司",
	"Hot Goods": "赃物",
	Hunger: "饥饿",
	Immortalized: "名垂青史",
	Investment: "投资",
	Kind: "善良",
	"Legendary Rancher": "传奇牧场主",
	"Little Genius": "小天才",
	Loan: "贷款",
	"Lodge Apprentice": "小屋学徒",
	"Lodge Master": "小屋大师",
	"Lodge Member": "小屋成员",
	Lucky: "幸运儿",
	Married: "已婚",
	"Master Chef": "厨艺大师",
	"Master of Agriculture": "农业大师",
	Matchmaker: "媒人",
	Mayor: "市长",
	"Miracle Medicine": "灵丹妙药",
	Monarch: "君主",
	"New Family": "新家庭",
	Noble: "贵族",
	"Ore Tycoon": "矿石大亨",
	Ornithologist: "鸟类学家",
	Paleontologist: "古生物学家",
	"Patron of the Arts": "艺术赞助人",
	"Perfect Village": "完美村庄",
	"Pet Lover": "宠物爱好者",
	"Pet Rescuer": "宠物救助者",
	Poisoned: "中毒",
	President: "总统",
	"Pro Angler": "钓鱼高手",
	Rancher: "牧场主",
	"Runner Up": "亚军",
	"Savings Account": "存款",
	"Secret Spy": "秘密间谍",
	Sleuth: "侦探",
	Termites: "白蚁",
	"Test Subject": "试验对象",
	"Thriving Community": "繁荣社区",
	"Treasure Hunter": "寻宝者",
	"Trustworthy News": "可信新闻",
	Tyrant: "暴君",
	Unrest: "动荡",
	Upstanding: "正直者",
	"Veteran Rancher": "资深牧场主",
	"Veteran Fisher": "资深渔夫",
	Farming: "农业",
	"Farming 1": "农业 1",
	"Farming 2": "农业 2",
	"Farming 3": "农业 3",
	Politics: "政治",
	"Politics 1": "政治 1",
	"Politics 2": "政治 2"
}, Ln = {
	bronze: "is-bronze",
	silver: "is-silver",
	gold: "is-gold",
	red: "is-red"
};
function Rn({ entry: e, lang: t, covered: n }) {
	let [r = "", i = "bronze"] = e.split("|"), a = Fn[r], o = Ln[i] ?? Ln.bronze;
	if (!a) {
		let e = t === "zh" ? In[r] ?? r : r;
		return /* @__PURE__ */ h("span", {
			className: `cz-mile-banner ${o}`,
			style: { background: "linear-gradient(100deg, #ead9b8, #cdb489)" },
			children: e
		});
	}
	let s = t === "zh" ? a.zh : a.name, c = t === "zh" && a.categoryZh || a.category, l = Qe(e, n);
	return /* @__PURE__ */ g("span", {
		className: `cz-mile-banner ${o}`,
		style: { background: `linear-gradient(100deg, ${a.from}, ${a.to})` },
		title: `${s}${c ? ` · ${c}` : ""}`,
		children: [
			l.gold > 0 && /* @__PURE__ */ h("span", {
				className: "cz-mile-banner-icons cz-mile-banner-gold",
				"aria-hidden": "true",
				children: Array.from({ length: l.gold }, (e, t) => /* @__PURE__ */ h(En, { size: 13 }, t))
			}),
			/* @__PURE__ */ g("span", {
				className: "cz-mile-banner-text",
				children: [/* @__PURE__ */ h("strong", { children: s }), c && /* @__PURE__ */ h("small", { children: c })]
			}),
			/* @__PURE__ */ g("span", {
				className: "cz-mile-banner-icons",
				"aria-hidden": "true",
				children: [l.star > 0 && /* @__PURE__ */ h("span", {
					className: "is-star",
					children: "★".repeat(l.star)
				}), l.smiley > 0 && /* @__PURE__ */ h("span", {
					className: "is-smiley",
					children: "☺".repeat(l.smiley)
				})]
			})
		]
	});
}
//#endregion
//#region src/game/town-map.tsx
var Q = (e) => f(`games/cozistickerville/${e}`), $ = {
	w: 4400,
	h: 1916
}, zn = {
	x: 3936,
	ys: [
		68,
		130,
		191,
		252,
		314,
		376,
		437,
		499,
		560,
		621,
		682,
		744,
		805,
		866,
		929,
		990,
		1050,
		1112,
		1173,
		1234,
		1295,
		1351,
		1417,
		1478,
		1540,
		1600,
		1656,
		1722,
		1782,
		1843
	]
}, Bn = {
	x: 4047,
	w: 300,
	h: 60,
	ys: [
		75,
		146,
		217,
		288,
		359,
		430,
		501,
		573,
		642,
		714,
		784,
		853,
		927,
		995,
		1067,
		1137,
		1205,
		1277,
		1349,
		1419,
		1491,
		1560,
		1630,
		1700,
		1770,
		1841
	]
}, Vn = {
	x: $.w / 2,
	y: $.h / 2,
	z: 1
}, Hn = {
	oob: "games.cozistickerville.errOob",
	bg: "games.cozistickerville.errBg",
	overlap: "games.cozistickerville.errOverlap",
	river: "games.cozistickerville.errRiver",
	fold: "games.cozistickerville.errFold",
	pair: "games.cozistickerville.errPair",
	target: "games.cozistickerville.errTarget"
}, Un = ({ col: e, row: t }) => t * F.cols + e, Wn = ({ col: e, row: t }) => e >= 0 && e < F.cols && t >= 0 && t < F.rows, Gn = (e, t, n) => Math.min(n, Math.max(t, e)), Kn = (e, t) => ({
	x: (e.x + t.x) / 2,
	y: (e.y + t.y) / 2
}), qn = (e, t) => Math.hypot(e.x - t.x, e.y - t.y);
function Jn({ box: e }, t = {
	x: 0,
	y: 0
}) {
	return {
		...e,
		left: V.x + e.left + t.x,
		top: V.y + e.top + t.y
	};
}
function Yn(e, t = !1) {
	let n = t ? -e.box.left : V.x, r = t ? -e.box.top : V.y;
	return e.contour.map((e) => `${e.x + n},${e.y + r}`).join(" ");
}
function Xn({ w: e, h: t }) {
	return Math.min(e / $.w, t / $.h);
}
function Zn(e, t) {
	let n = Xn(t) * e.z;
	if (!n) return e;
	let r = Math.min($.w / 2, t.w / (2 * n)), i = Math.min($.h / 2, t.h / (2 * n));
	return {
		x: Gn(e.x, r, $.w - r),
		y: Gn(e.y, i, $.h - i),
		z: e.z
	};
}
function Qn(e, t, n) {
	let r = Xn(n) * t.z;
	return {
		x: t.x + (e.x - n.w / 2) / r,
		y: t.y + (e.y - n.h / 2) / r
	};
}
function $n(e, t, n, r, i) {
	let a = Qn(n, e, t), o = Gn(e.z * i, 1, 5), s = Xn(t) * o;
	return Zn({
		z: o,
		x: a.x - (r.x - t.w / 2) / s,
		y: a.y - (r.y - t.h / 2) / s
	}, t);
}
function er({ side: e, placed: t, happiness: n, milestones: r, coveredMilestoneIcons: i, lang: a, draft: u, stories: ee, readOnly: te = !1, children: ne }) {
	let f = d(), m = p(), re = c(null), [_, ie] = l({
		w: 0,
		h: 0
	}), [ae, v] = l(Vn), y = c(Vn), b = c(/* @__PURE__ */ new Map()), oe = c(null), [se, ce] = l(null), [S, le] = l(null), [ue, de] = l(null), C = u?.pending, w = Xn(_) * ae.z, fe = _.w / 2 - ae.x * w, T = _.h / 2 - ae.y * w, E = u?.hits, pe = u?.sticker, D = s(() => !pe || !E ? [] : [...E].flatMap(([e, t]) => {
		if (!t.ok) return [];
		let n = {
			col: e % F.cols,
			row: Math.floor(e / F.cols)
		};
		return [{
			key: e,
			cell: n,
			geometry: U(pe, n, t.numberOverlay)
		}];
	}), [E, pe]), O = D.length > 16;
	o(() => {
		let e = re.current;
		if (!e) return;
		function t() {
			if (!e) return;
			let t = {
				w: e.clientWidth,
				h: e.clientHeight
			};
			y.current = Zn(y.current, t), v(y.current), ie(t);
		}
		function n(t) {
			if (!e || b.current.size || !e.clientWidth || !e.clientHeight || !t.deltaY) return;
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = {
				x: t.clientX - n.left - e.clientLeft,
				y: t.clientY - n.top - e.clientTop
			}, i = t.deltaY * (t.deltaMode === 1 ? 16 : t.deltaMode === 2 ? 100 : 1), a = {
				w: e.clientWidth,
				h: e.clientHeight
			}, o = $n(y.current, a, r, r, Math.exp(-Gn(i, -160, 160) * .0035));
			y.current = o, v(o);
		}
		t();
		let r = new ResizeObserver(t);
		return r.observe(e), e.addEventListener("wheel", n, { passive: !1 }), () => {
			r.disconnect(), e.removeEventListener("wheel", n);
		};
	}, []);
	function k(e) {
		y.current = e, v(e);
	}
	function A(e) {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: e.clientX - t.left - e.currentTarget.clientLeft,
			y: e.clientY - t.top - e.currentTarget.clientTop
		};
	}
	function j(e) {
		let t = Qn(e, y.current, _), n = {
			x: t.x - V.x,
			y: t.y - V.y
		}, r = {
			col: Math.floor(n.x / H.w),
			row: Math.floor(n.y / H.h)
		}, i = D.filter(({ geometry: e }) => {
			let { kind: t, overlay: r, lobes: i } = e;
			return !r && (t === "box" || t === "single") ? !1 : ke(n, t === "double" && O ? i.slice(0, 1) : i);
		}).sort((e, t) => qn(e.geometry.align, n) - qn(t.geometry.align, n))[0];
		if (i) return i.cell;
		let a = D.find((e) => e.key === Un(r));
		return a && (a.geometry.overlay || !["box", "single"].includes(a.geometry.kind)) ? null : r;
	}
	function me(e) {
		if (!u) return;
		let t = Wn(e) ? u.hits.get(Un(e)) : void 0;
		if (!t?.ok) {
			de({
				scope: u.scope,
				message: t ? Hn[t.reason] : Hn.oob
			});
			return;
		}
		de(null), u.choose(e);
	}
	function he(e) {
		if (!w || e.button !== 0 || e.target.closest("button")) return;
		let t = A(e);
		if (b.current.set(e.pointerId, t), e.currentTarget.setPointerCapture(e.pointerId), b.current.size === 1) {
			let e = Qn(t, y.current, _), n = C && D.find((e) => e.key === Un(C)), r = n && ke({
				x: e.x - V.x,
				y: e.y - V.y
			}, n.geometry.lobes);
			oe.current = {
				start: t,
				last: t,
				moved: !1,
				anchor: r && C ? C : void 0
			}, de(null);
		} else oe.current = null, ce(null);
		le(null);
	}
	function M(e, t) {
		let n = e.anchor, r = u.hits.get(Un(n)), i = U(u.sticker, n, r?.ok ? r.numberOverlay : void 0), a = Xn(_) * y.current.z, o = (t.x - e.start.x) / a, s = (t.y - e.start.y) / a, c = {
			x: i.align.x + o,
			y: i.align.y + s
		}, l = {
			col: n.col + Math.round(o / H.w),
			row: n.row + Math.round(s / H.h)
		}, d = D.filter((e) => Math.abs(e.geometry.align.x - c.x) <= H.w / 2 && Math.abs(e.geometry.align.y - c.y) <= H.h / 2).sort((e, t) => qn(e.geometry.align, c) - qn(t.geometry.align, c))[0];
		return {
			geometry: i,
			delta: {
				x: o,
				y: s
			},
			at: d?.cell ?? l
		};
	}
	function N(e) {
		if (!w) return;
		let t = A(e), n = b.current.get(e.pointerId);
		if (!n) {
			e.pointerType === "mouse" && u && !C && le(j(t));
			return;
		}
		if (b.current.set(e.pointerId, t), b.current.size === 2) {
			let r = [...b.current].find(([t]) => t !== e.pointerId)?.[1];
			if (!r) return;
			let i = qn(n, r);
			i > 0 && k($n(y.current, _, Kn(n, r), Kn(t, r), qn(t, r) / i));
			return;
		}
		let r = oe.current;
		r && (!r.moved && qn(t, r.start) < 5 || (r.moved = !0, r.anchor && C && u ? ce(M(r, t)) : r.anchor || k($n(y.current, _, r.last, t, 1)), r.last = t));
	}
	function ge(e, t = !1) {
		if (!b.current.delete(e.pointerId)) return;
		let n = oe.current, r = A(e);
		if (n && !t) {
			n.anchor && n.moved && u && C && me(M(n, r).at);
			let e = !n.anchor && !n.moved ? j(r) : null;
			e && me(e);
		}
		let i = b.current.size === 1 ? b.current.values().next().value : void 0;
		oe.current = i ? {
			start: i,
			last: i,
			moved: !0
		} : null, ce(null);
	}
	function P(e) {
		if (!w) return;
		let t = {
			x: _.w / 2,
			y: _.h / 2
		};
		k($n(y.current, _, t, t, e));
	}
	function _e(e) {
		if (!u || !w) return !1;
		let t = {
			ArrowLeft: [-1, 0],
			ArrowUp: [0, -1],
			ArrowRight: [1, 0],
			ArrowDown: [0, 1]
		}[e];
		if (!t) return !1;
		let [n = 0, r = 0] = t, i = D.filter(({ geometry: e }) => {
			let t = Jn(e), n = fe + t.left * w, r = T + t.top * w;
			return n < _.w && r < _.h && n + t.width * w > 0 && r + t.height * w > 0;
		}), a = C ? Array.from({ length: Math.max(F.cols, F.rows) }, (e, t) => ({
			col: C.col + n * (t + 1),
			row: C.row + r * (t + 1)
		})).find((e) => Wn(e) && i.some((t) => t.key === Un(e))) : i[0]?.cell;
		return a && me(a), !0;
	}
	let ve = ee?.length ? W(t) : void 0, I = u && (se?.at ?? C ?? (S && Wn(S) && u.hits.get(Un(S))?.ok ? S : null)), ye = I && Wn(I) ? u?.hits.get(Un(I)) : void 0, be = u && (se && !ye?.ok ? ye ? Hn[ye.reason] : Hn.oob : ue?.scope === u.scope && ue.message), L = se?.geometry ?? (I && u ? U(u.sticker, I, ye?.ok ? ye.numberOverlay : void 0) : void 0), R = L && Jn(L, se?.delta), z = R && {
		x: fe + (R.left + R.width / 2) * w,
		y: T + R.top * w
	}, B = z && R ? z.y + R.height * w : 0, xe = z && R && z.x + R.width * w / 2 > 0 && z.x - R.width * w / 2 < _.w && B > 0 && z.y < _.h, Se = !m && /* @__PURE__ */ h("animate", {
		attributeName: "stroke-dashoffset",
		from: "0",
		to: "-12",
		dur: ".7s",
		repeatCount: "indefinite"
	}), Ce = w ? 1 / w : 1, we = !m && /* @__PURE__ */ h("animate", {
		attributeName: "stroke-dashoffset",
		from: "0",
		to: -12 * Ce,
		dur: ".7s",
		repeatCount: "indefinite"
	}), Te = Q(`map/${e.toLowerCase()}.webp`);
	return /* @__PURE__ */ g("div", {
		className: "cz-map-viewport",
		ref: re,
		tabIndex: 0,
		"aria-label": f("games.cozistickerville.side", { s: e }),
		onPointerDown: he,
		onPointerMove: N,
		onPointerUp: ge,
		onPointerCancel: (e) => ge(e, !0),
		onLostPointerCapture: (e) => ge(e, !0),
		onPointerLeave: () => le(null),
		onKeyDown: (e) => {
			e.currentTarget === e.target && _e(e.key) && e.preventDefault();
		},
		children: [
			/* @__PURE__ */ g("div", {
				className: "cz-map-stage",
				style: {
					width: $.w,
					height: $.h,
					transform: `translate(${fe}px, ${T}px) scale(${w})`
				},
				children: [
					/* @__PURE__ */ h("img", {
						className: "cz-map-img",
						src: Te,
						alt: "",
						draggable: !1
					}),
					/* @__PURE__ */ h("div", {
						className: "cz-map-board",
						"aria-hidden": "true",
						children: r.slice(0, Bn.ys.length).map((e, t) => /* @__PURE__ */ h("span", {
							className: "cz-map-mile-slot",
							style: {
								left: Bn.x,
								top: Bn.ys[t] - Bn.h / 2
							},
							children: /* @__PURE__ */ h(Rn, {
								entry: e,
								covered: i,
								lang: a
							})
						}, `mile-${e}-${t}`))
					}),
					t.map((e, n) => {
						let r = x[e.id];
						if (!r) return null;
						let i = !ve?.has(n) && !G(t, e) && ee?.find((e) => e.code === r.code), a = U(r, e, e.numberOverlay), o = Jn(a);
						return /* @__PURE__ */ g("div", {
							className: "cz-map-sticker",
							style: {
								...o,
								zIndex: n
							},
							children: [/* @__PURE__ */ h("img", {
								src: Q(r.file),
								alt: te ? "" : r.name,
								draggable: !1,
								style: a.overlay || a.kind !== "box" ? { objectFit: "fill" } : void 0
							}), i && w > 0 && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-map-story",
								style: {
									width: 25 / w,
									height: 25 / w,
									fontSize: 14 / w,
									borderRadius: 5 / w
								},
								onClick: i.read,
								"aria-label": i.label,
								title: i.label,
								children: "↗"
							})]
						}, `${e.id}-${e.col}-${e.row}-${n}`);
					}),
					!!D.length && /* @__PURE__ */ h("svg", {
						className: "cz-map-targets",
						viewBox: `0 0 ${$.w} ${$.h}`,
						"aria-hidden": "true",
						children: D.map(({ key: e, geometry: t }) => {
							let n = t.align.x + V.x, r = t.align.y + V.y;
							return t.overlay || t.kind === "left" || t.kind === "right" || !O && t.kind !== "box" ? /* @__PURE__ */ h("polygon", {
								className: "cz-map-target-outline cz-map-dashes",
								points: Yn(t),
								children: Se
							}, e) : O ? /* @__PURE__ */ h("path", { d: `M ${n} ${r - 17} l 17 17 -17 17 -17 -17 Z` }, e) : /* @__PURE__ */ h("rect", {
								x: n - H.w / 2 + 11,
								y: r - H.h / 2 + 11,
								width: H.w - 22,
								height: H.h - 22,
								rx: 15,
								className: "cz-map-dashes",
								children: Se
							}, e);
						})
					}),
					R && L && u && /* @__PURE__ */ g("div", {
						className: `cz-map-preview${C && !se ? " cz-map-picked" : ""}${ye?.ok ? "" : " is-invalid"}`,
						style: R,
						children: [/* @__PURE__ */ g("svg", {
							viewBox: `0 0 ${R.width} ${R.height}`,
							"aria-hidden": "true",
							children: [/* @__PURE__ */ h("polygon", {
								points: Yn(L, !0),
								strokeWidth: 4 * Ce
							}), /* @__PURE__ */ h("polygon", {
								points: Yn(L, !0),
								strokeWidth: 2 * Ce,
								strokeDasharray: `${7 * Ce} ${5 * Ce}`,
								children: we
							})]
						}), /* @__PURE__ */ h("img", {
							src: Q(u.sticker.file),
							alt: "",
							draggable: !1,
							style: L.overlay || L.kind !== "box" ? { objectFit: "fill" } : void 0
						})]
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "cz-map-hearts",
				"aria-hidden": "true",
				children: (w * 61.5 < 12 ? n > 0 ? [Math.min(n, zn.ys.length)] : [] : Array.from({ length: Math.min(n, zn.ys.length) }, (e, t) => t + 1)).map((e) => /* @__PURE__ */ h("svg", {
					className: "cz-map-heart",
					viewBox: "0 0 24 24",
					style: {
						left: fe + zn.x * w,
						top: T + zn.ys[zn.ys.length - e] * w
					},
					children: /* @__PURE__ */ h("path", { d: "M12 21s-6.7-4.4-9.1-8.1C.9 9.7 2.2 5.6 5.8 4.8c2-.4 3.8.5 5 2.1 1.2-1.6 3-2.5 5-2.1 3.6.8 4.9 4.9 2.9 8.1C18.7 16.6 12 21 12 21z" })
				}, `heart-${e}`))
			}),
			ae.z > 1.01 && /* @__PURE__ */ g("div", {
				className: "cz-map-mini",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ h("img", {
					src: Te,
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ h("span", { style: {
					left: `${Math.max(0, -fe / (w * $.w) * 100)}%`,
					top: `${Math.max(0, -T / (w * $.h) * 100)}%`,
					width: `${Math.min(100, _.w / (w * $.w) * 100)}%`,
					height: `${Math.min(100, _.h / (w * $.h) * 100)}%`
				} })]
			}),
			/* @__PURE__ */ g("div", {
				className: "cz-map-tools",
				children: [
					/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => P(1.4),
						disabled: ae.z >= 5,
						"aria-label": f("games.cozistickerville.zoomIn"),
						children: "+"
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => P(1 / 1.4),
						disabled: ae.z <= 1,
						"aria-label": f("games.cozistickerville.zoomOut"),
						children: "−"
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => k(Vn),
						children: f("games.cozistickerville.zoomReset")
					})
				]
			}),
			C && !se && u && z && xe && /* @__PURE__ */ g("div", {
				className: "cz-map-confirm",
				style: {
					left: Gn(z.x, Math.min(_.w / 2, 112), Math.max(_.w / 2, _.w - 112)),
					top: B + 100 < _.h ? Math.max(6, B + 8) : Math.max(6, Math.min(_.h - 95, z.y - 45))
				},
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					className: "cz-btn",
					onClick: () => {
						de(null), u.choose(null);
					},
					children: f("games.cozistickerville.cancel")
				}), /* @__PURE__ */ h("button", {
					type: "button",
					className: "cz-btn cz-primary",
					onClick: () => {
						de(null), u.confirm();
					},
					children: f("games.cozistickerville.confirmPlace")
				})]
			}),
			be && /* @__PURE__ */ h("div", {
				className: "cz-map-error",
				role: "status",
				children: f(be)
			}),
			ne
		]
	});
}
//#endregion
//#region src/game/town-dialog.tsx
function tr({ open: e, title: t, closeLabel: n, onClose: r, kind: i = "drawer", children: s }) {
	let l = c(null), u = a();
	return o(() => {
		let t = l.current;
		t && (e && !t.open && t.showModal(), !e && t.open && t.close());
	}, [e]), e ? /* @__PURE__ */ g("dialog", {
		ref: l,
		className: `cz-dialog cz-dialog--${i}`,
		"aria-labelledby": u,
		onCancel: (e) => {
			e.preventDefault(), r();
		},
		children: [/* @__PURE__ */ g("div", {
			className: "cz-dialog-header",
			children: [/* @__PURE__ */ h("h2", {
				id: u,
				children: t
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "cz-btn cz-dialog-close",
				onClick: r,
				children: n
			})]
		}), s]
	}) : null;
}
//#endregion
//#region src/game/event-reading.ts
var nr = { "y1-07": {
	story: ["你在森林里发现了一个鸟巢。你已经很久没吃煎蛋了。", "You find a bird’s nest in the forest. You haven’t had an omelet in ages!"],
	options: {
		a: ["取走鸟蛋", "Take the eggs"],
		b: ["把鸟蛋留在原处", "Leave the eggs"],
		c: ["卖掉鸟蛋", "Sell the eggs"]
	}
} };
function rr(e) {
	return nr[e];
}
function ir(e) {
	let t = _[e]?.opts;
	return t ? [
		"a",
		"b",
		"c"
	].flatMap((e) => {
		let n = t[e];
		return n ? [{
			key: e,
			enabled: !1,
			label: n.label ? [n.label.zh, n.label.en] : [Vt(n.do, 0), Vt(n.do, 1)]
		}] : [];
	}) : [];
}
//#endregion
//#region src/game/data/l10n/events-text.ts
var ar = {
	"y1-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your bed is so warm and cozy that you could spend the entire day napping.",
			panel: "Either A nap the day away, or B spend 1 food to eat a hearty breakfast.\nRead the matching effect, then discard this.",
			options: {
				a: "You sleep through lunch and have no regrets. No effect.",
				b: "Energized, you decide to do some chores before lunch. Gain 1 wood."
			}
		},
		zh: {
			flavor: "你的被窝又暖又软，简直可以睡上一整天。",
			panel: "选择 A 睡到自然醒，或选择 B 花费 1 份食物享用一顿丰盛的早餐。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "你一路睡过午饭，毫不后悔。没有效果。",
				b: "你精神饱满，午饭前做了一些家务。获得 1 份木材。"
			}
		},
		uncertain: []
	},
	"y1-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Just because you've never worked a full day in your life doesn't mean you can't.",
			panel: "Either A forage for berries, B gather wood, or C spend 1 food to gather lots of wood.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 1 wood.",
				c: "Gain 2 wood."
			}
		},
		zh: {
			flavor: "你这一辈子从没正经工作过一整天，但这并不代表你干不了。",
			panel: "选择 A 采摘浆果，选择 B 收集木材，或选择 C 花费 1 份食物收集大量木材。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 1 份木材。",
				c: "获得 2 份木材。"
			}
		},
		uncertain: []
	},
	"y1-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "The village looks as bland as yesterday's oatmeal. Let's add some flavor!",
			panel: "Either A build roads, or B plant flowers.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 road stickers (3E).",
				b: "Place 2 flower stickers (11A)."
			}
		},
		zh: {
			flavor: "村子看上去像昨天的燕麦粥一样寡淡。来加点滋味吧！",
			panel: "选择 A 修建道路，或选择 B 种植花朵。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚道路贴纸 3E。",
				b: "放置 2 枚花朵贴纸 11A。"
			}
		},
		uncertain: []
	},
	"y1-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "What you really want to plant is a hamburger bush. Too bad those don't exist.",
			panel: "Either A plant a berry bush, or B plant a tree.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 1 bush sticker (1H).",
				b: "Place 1 tree sticker (5N)."
			}
		},
		zh: {
			flavor: "你真正想种的是汉堡灌木，可惜世上没有这种东西。",
			panel: "选择 A 种一丛浆果灌木，或选择 B 种一棵树。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 1 枚灌木贴纸 1H。",
				b: "放置 1 枚树木贴纸 5N。"
			}
		},
		uncertain: []
	},
	"y1-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A man approaches in comically large black robes. “This land… I sense that it is full of power… and riches! They could be yours, if you let me build my lodge here.”",
			panel: "Either say:\nA “Great power? Build away!”\nB “No thanks, I'll find the riches myself.”\nRead the matching effect, then discard this.",
			options: {
				a: "Place sticker (6C).",
				b: "“Fool! This land is worth more than you know.” No effect (for now)."
			}
		},
		zh: {
			flavor: "一个男人穿着大得滑稽的黑色长袍走来。「这片土地……我能感觉到，它充满力量……还有财富！只要你让我在这里建起我的小屋，这些都可以归你。」",
			panel: "你可以说：\nA「巨大的力量？那就尽管建吧！」\nB「不了，谢谢，财富我自己会找到。」\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置贴纸 6C。",
				b: "「蠢货！这片土地的价值远比你想象的高。」没有效果（暂时）。"
			}
		},
		uncertain: []
	},
	"y1-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A wanderer stops by, admiring all that you've built. “Whooee! I been livin' round these woods ma whole life - ain't never seen nuthin' like this. Could get used to it.”",
			panel: "Either A let him live here, or B politely ask him to leave.\nRead the matching effect, then discard this.",
			options: {
				a: "Place the Wild Bill sticker (5M).",
				b: "“I understand. Most people think I'm a thief or something. Lies! Oh well, guess I'll just shuffle on.” No effect."
			}
		},
		zh: {
			flavor: "一个流浪汉停下脚步，赞叹你建起的一切。「哇哦！我在这一带林子里住了一辈子——从没见过这样的光景。真叫人想留下来。」",
			panel: "选择 A 让他住在这里，或选择 B 礼貌地请他离开。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置野比尔贴纸 5M。",
				b: "「我明白。大多数人觉得我是小偷之类的。胡说！唉，算了，我还是接着晃荡吧。」没有效果。"
			}
		},
		uncertain: []
	},
	"y1-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find a bird's nest in the forest. You haven't had an omelet in ages!",
			panel: "Either A take the eggs, B leave them, or C sell them.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Place sticker (12D).",
				c: "Gain 1 gold."
			}
		},
		zh: {
			flavor: "你在森林里发现了一个鸟巢。你已经很久没吃过煎蛋卷了！",
			panel: "选择 A 拿走鸟蛋，选择 B 留下它们，或选择 C 把它们卖掉。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "放置贴纸 12D。",
				c: "获得 1 金币。"
			}
		},
		uncertain: []
	},
	"y1-08": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You awaken to a golden sunrise and the approaching sound of music. A merchant sings a merry tune as her wagon crests the hill.",
			panel: "Keep this card in play.\n\nSELL FOOD\nSpend up to 2 food to gain 1 gold each. (Do not discard this after use.)\n\nEND OF THE YEAR\nDiscard this and read 34.1.",
			options: {}
		},
		zh: {
			flavor: "你在金色的日出中醒来，远处传来渐渐靠近的乐声。一名商贩唱着欢快的曲调，驾着货车翻过山丘。",
			panel: "将此牌留在场上。\n\n卖出食物\n最多花费 2 份食物，每花费 1 份获得 1 金币。（使用后不要弃掉此牌。）\n\n岁末\n弃掉此牌并阅读 34.1。",
			options: {}
		},
		uncertain: []
	},
	"y1-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Farmer Dill would like to live here, but you also have interest from the Salizars who want to bring big business to this small village.",
			panel: "Keep this card in play.\n\nBUILD HOUSE (3 wood)\nDiscard this and choose who should live in this house:",
			options: {
				a: "Farmer Dill: Gain card 1.",
				b: "The Salizars: Gain card 2."
			}
		},
		zh: {
			flavor: "农夫迪尔想住在这里，但萨利扎一家也看中了这里，他们想给这座小村庄带来大生意。",
			panel: "将此牌留在场上。\n\n建造房屋（3 木材）\n弃掉此牌，并选择由谁住进这栋房子：",
			options: {
				a: "农夫迪尔：获得图鉴牌 1。",
				b: "萨利扎一家：获得图鉴牌 2。"
			}
		},
		uncertain: []
	},
	"y1-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Zach Johnson wants to sell his new inventions, but the Saw Siblings want to build a lumber empire.",
			panel: "Keep this card in play.\n\nBUILD HOUSE (4 wood)\nDiscard this and choose who should live in this house:",
			options: {
				a: "Zach Johnson: place sticker (6A).",
				b: "The Saw Siblings: place sticker (6R)."
			}
		},
		zh: {
			flavor: "扎克·约翰逊想推销他的新发明，但锯木兄妹想建立木材帝国。",
			panel: "将此牌留在场上。\n\n建造房屋（4 木材）\n弃掉此牌，并选择由谁住进这栋房子：",
			options: {
				a: "扎克·约翰逊：放置贴纸 6A。",
				b: "锯木兄妹：放置贴纸 6R。"
			}
		},
		uncertain: []
	},
	"y1-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD TOWN HALL (5 wood)\nIf you have 3 or more residents, discard this and gain card 7.\n(You are not a resident. Count the number of people shown in artwork on the map, including children and babies.)\n\nBUILD FARM (4 wood, 1 gold)\nDiscard this and gain card 8.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造市政厅（5 木材）\n若你拥有 3 名或更多居民，弃掉此牌并获得图鉴牌 7。\n（你不是居民。统计地图插画中出现的人物数量，包括儿童和婴儿。）\n\n建造农场（4 木材、1 金币）\n弃掉此牌并获得图鉴牌 8。",
			options: {}
		},
		uncertain: []
	},
	"y1-12": {
		kind: "keep",
		title: {
			en: "NEWCOMER AMBITION",
			zh: "新来者的抱负"
		},
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBEE LOVER\nIf 4 or more flower stickers (11A) on the map, discard this and gain card 11.\n\nMONEY LOVER\nIf 2 or more hatchet icons on the map, discard this and gain card 10.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n蜜蜂爱好者\n若地图上有 4 枚或更多花朵贴纸 11A，弃掉此牌并获得图鉴牌 11。\n\n守财奴\n若地图上有 2 个或更多斧头图标，弃掉此牌并获得图鉴牌 10。",
			options: {}
		},
		uncertain: ["MONEY LOVER 的斧头图标指向哪种地图资源未能确认；现有数据记为金币，但卡面画的是斧头。"]
	},
	"y2-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Birds sing as squirrels chase each other from tree to tree. A disgruntled woodsman waves his axe at them. “Shoo, shoo, you vermin!”",
			panel: "Either A help him chop down trees for lumber, or B let the wildlife thrive.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 3 wood and place sticker 6H, covering a sticker that has exactly 2 trees.",
				b: "Place sticker 11K."
			}
		},
		zh: {
			flavor: "鸟儿歌唱，松鼠在树间互相追逐。一个满腹牢骚的伐木工朝它们挥动斧头。「去，去，你们这些害兽！」",
			panel: "选择 A 帮他砍树换取木材，或选择 B 让野生动物继续繁衍生息。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 3 份木材，并放置贴纸 6H，覆盖在一张恰好画有 2 棵树的贴纸上。",
				b: "放置贴纸 11K。"
			}
		},
		uncertain: []
	},
	"y2-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your morning hike is cut short by a massive log blocking the path. Always the opportunist, you break out your saw and get to work.",
			panel: "Either A keep the wood, or B sell it.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 2 wood.",
				b: "Gain 1 gold."
			}
		},
		zh: {
			flavor: "清晨的徒步被一根横在路上的巨大原木打断了。你向来善于抓住机会，于是掏出锯子干了起来。",
			panel: "选择 A 留下木材，或选择 B 把它卖掉。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 2 份木材。",
				b: "获得 1 金币。"
			}
		},
		uncertain: []
	},
	"y2-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Roads are crucial for a proper town, but they might disrupt the local ecosystem.",
			panel: "Either A plant flowers, or B spend 1 food to build lots of roads.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 flower stickers (11A).",
				b: "Place 3 road stickers (3E)."
			}
		},
		zh: {
			flavor: "道路对一座像样的城镇至关重要，但它们也可能破坏当地的生态。",
			panel: "选择 A 种花，或选择 B 花费 1 份食物修建大量道路。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚花朵贴纸 11A。",
				b: "放置 3 枚道路贴纸 3E。"
			}
		},
		uncertain: []
	},
	"y2-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Are you sick of eating berries yet? At least they taste better than pine cone à la mode.",
			panel: "Either plant A a berry bush, or B a tree.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 1 bush sticker (1H).",
				b: "Place 1 tree sticker (5N)."
			}
		},
		zh: {
			flavor: "浆果还没吃腻吗？至少它们比松果配冰淇淋好吃。",
			panel: "选择 A 种下一丛浆果灌木，或选择 B 种下一棵树。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 1 枚灌木贴纸 1H。",
				b: "放置 1 枚树木贴纸 5N。"
			}
		},
		uncertain: []
	},
	"y2-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A moneylender pays you a visit from the city. He seems friendly enough. “We're basically offering you free money. This is the deal of a lifetime!”",
			panel: "Either A take the money, or B refuse it.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 3 gold and the Loan milestone (red).",
				b: "You lay awake at night thinking about all the things you could have done with that money. No effect."
			}
		},
		zh: {
			flavor: "一位城里的放贷人登门拜访。他看上去还算友善。「我们基本上就是在白送钱给你。这可是千载难逢的好买卖！」",
			panel: "选择 A 收下这笔钱，或选择 B 拒绝。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 3 金币和 贷款 里程碑（红色）。",
				b: "你夜里翻来覆去，想着那些钱本来能用来做多少事。没有效果。"
			}
		},
		uncertain: []
	},
	"y2-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You awaken to windows, doors, and cabinets rattling... Earthquake!",
			panel: "Roll the die. If you have the Lucky milestone and roll 1-4, reroll it once.\nRead the effect below matching the final result, then discard this.",
			options: {
				a: "1-4 The ground splits open.\nPlace sticker 3D.",
				b: "5-6 The small quake exposed a gold nugget. Hot dog! Gain 1 gold."
			}
		},
		zh: {
			flavor: "你在窗户、房门和橱柜的震颤中醒来……地震了！",
			panel: "掷骰。若你拥有 幸运儿 里程碑且掷出 1 至 4，重掷一次。\n阅读下方与最终结果对应的效果，然后弃掉此牌。",
			options: {
				a: "1 至 4：地面裂开了。\n放置贴纸 3D。",
				b: "5 至 6：这场小地震震出了一块金块。太棒了！获得 1 金币。"
			}
		},
		uncertain: []
	},
	"y2-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Wild Bill resident, read option A, otherwise read B.",
			options: {
				a: "Money has gone missing and you suspect Bill is to blame. You can't prove it, though.\n\nLose 1 gold, if able. Then choose one:\nA Kick him out: Discard this and remove the Wild Bill sticker.\nB Let him stay: Discard this.",
				b: "Wild Bill returns. “Please let me live here; I got nowhere else to go!”\n\nYou may place Wild Bill (sticker 5M).\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有野比尔居民，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "钱不翼而飞，你怀疑是野比尔干的。可你没有证据。\n\n若能够，失去 1 金币。然后选择一项：\nA 赶走他：弃掉此牌并移除野比尔贴纸。\nB 让他留下：弃掉此牌。",
				b: "野比尔回来了。「请让我住在这里吧，我实在没别的地方可去了！」\n\n你可以放置野比尔（贴纸 5M）。\n无论是否放置，随后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y2-08": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You've accomplished much in this past year, but your neighbors are growing hungry.",
			panel: "Keep this card in play.\n\nTHROW FEAST (4 food)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 4 food or gain the Hunger milestone (red).\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "这一年你颇有建树，可邻居们却开始饿肚子了。",
			panel: "将此牌留在场上。\n\n举办盛宴（4 食物）\n弃掉此牌并获得 1 点心情。\n\n岁末\n花费 4 份食物，或获得 饥饿 里程碑（红色）。\n无论选择哪项，随后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y2-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "David Dawes knows a dozen ways to make money, but a brilliant researcher could provide a scientific breakthrough.",
			panel: "Keep this card in play.\n\nBUILD HOUSE (4 wood)\nDiscard this and choose who should live in this house:",
			options: {
				a: "The Dawes Family: place sticker 7A.",
				b: "Professor Ferguson: place sticker 5H."
			}
		},
		zh: {
			flavor: "大卫·道斯有十几种赚钱的法子，但一位出色的研究者也许能带来科学上的突破。",
			panel: "将此牌留在场上。\n\n建造房屋（4 木材）\n弃掉此牌，并选择由谁住进这栋房子：",
			options: {
				a: "道斯一家：放置贴纸 7A。",
				b: "弗格森教授：放置贴纸 5H。"
			}
		},
		uncertain: []
	},
	"y2-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "A market is crucial for buying and selling goods.",
			panel: "Keep this card in play.\n\nBUILD MARKET (3 wood)\nDiscard this and gain card 9.",
			options: {}
		},
		zh: {
			flavor: "市场对买卖货物至关重要。",
			panel: "将此牌留在场上。\n\n建造市场（3 木材）\n弃掉此牌并获得图鉴牌 9。",
			options: {}
		},
		uncertain: []
	},
	"y2-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: "A traveling troupe of performers arrives in town offering a week of festivities. Music, dancing, juggling, and theater. It can all be yours for a small fee.",
			panel: "Keep this card in play.\n\nHIRE THE PERFORMERS (1 gold)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nYou may spend 2 gold to gain 1 happiness. Regardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "一支巡回表演团来到镇上，要献上一周的庆典：音乐、舞蹈、杂耍和戏剧。只收一点小钱，这一切就都归你。",
			panel: "将此牌留在场上。\n\n雇用表演团（1 金币）\n弃掉此牌并获得 1 点心情。\n\n岁末\n你可以花费 2 金币获得 1 点心情。无论是否花费，随后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y2-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: "There comes a time in everyone's life when they need to choose between money and happiness.",
			panel: "Keep this card in play.\n\nWORK AN ODD JOB\nDiscard this and read 10.2.\n\nBUILD PLAYGROUND (4 wood)\nDiscard this, gain 1 happiness, and place sticker 6Q.",
			options: {}
		},
		zh: {
			flavor: "每个人一生中总有那么一刻，要在金钱和心情之间做出选择。",
			panel: "将此牌留在场上。\n\n打零工\n弃掉此牌并阅读 10.2。\n\n建造游乐场（4 木材）\n弃掉此牌，获得 1 点心情，并放置贴纸 6Q。",
			options: {}
		},
		uncertain: []
	},
	"y3-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "The past two years of physical labor have burned away all your belly fat. It's like you discovered a secret weight loss trick!",
			panel: "Either A gather food, or B spend 1 food to gather lots of wood.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 2 wood."
			}
		},
		zh: {
			flavor: "两年的体力劳动烧光了你的肚腩。就像你发现了一种秘密减肥法！",
			panel: "选择 A 采集食物，或选择 B 花费 1 份食物采集大量木材。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 2 份木材。"
			}
		},
		uncertain: []
	},
	"y3-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your village is still looking a little plain.",
			panel: "Either A plant flowers, or B build roads.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 flower stickers (11A).",
				b: "Place 2 road stickers (3E)."
			}
		},
		zh: {
			flavor: "你的村庄看上去还是有点单调。",
			panel: "选择 A 种花，或选择 B 修建道路。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚花朵贴纸 11A。",
				b: "放置 2 枚道路贴纸 3E。"
			}
		},
		uncertain: []
	},
	"y3-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find a beautiful sapling on the outskirts of town and consider relocating it. It would be a lot of work, but also something to take pride in.",
			panel: "Either A spend 2 food to relocate the tree, or B hunt for berries.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 1 tree sticker (5N).",
				b: "Gain 1 food."
			}
		},
		zh: {
			flavor: "你在镇子外围发现了一棵漂亮的树苗，考虑把它移栽过来。这要费不少力气，但也是一件值得骄傲的事。",
			panel: "选择 A 花费 2 份食物移栽这棵树，或选择 B 采集浆果。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 1 枚树木贴纸 5N。",
				b: "获得 1 份食物。"
			}
		},
		uncertain: []
	},
	"y3-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find some wild mushrooms in the forest. You're 80% sure they're not poisonous.",
			panel: "Either A keep them, B sell them to your neighbor, or C leave them.\nRead the matching effect, then discard this.",
			options: {
				a: "Roll the die. On a 1, you get sick: Lose 1 happiness. Otherwise, gain 1 food.",
				b: "Gain 1 gold, then roll the die. On a 1, your neighbor gets sick: Place 1 upset sticker near a resident that is not upset. Otherwise, no effect.",
				c: "No effect."
			}
		},
		zh: {
			flavor: "你在森林里发现了一些野生蘑菇。你有八成把握它们没有毒。",
			panel: "选择 A 留下它们，选择 B 卖给邻居，或选择 C 不管它们。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "掷骰。若掷出 1，你中毒了：失去 1 点心情。否则获得 1 份食物。",
				b: "获得 1 金币，然后掷骰。若掷出 1，你的邻居中毒了：在一名未处于不满状态的居民附近放置 1 枚不满贴纸。否则没有效果。",
				c: "没有效果。"
			}
		},
		uncertain: []
	},
	"y3-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You awaken before your alarm goes off, feeling more alive than you've felt in years. Today is gonna be a good day!",
			panel: "Discard this card. You may perform 1 additional action this turn.",
			options: {}
		},
		zh: {
			flavor: "闹钟还没响你就醒了，多年没有这样精神焕发。今天一定是个好日子！",
			panel: "弃掉此牌。本回合你可以额外执行 1 次行动。",
			options: {}
		},
		uncertain: []
	},
	"y3-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have a “Farming 2” or “Farming 3” milestone, read option A, otherwise read B.",
			options: {
				a: "An animal has been eating one of your berry bushes. Not just the berries, but the bush itself!\n\nDiscard this and place sticker 1G, covering 1 berry bush and a food icon, if able.",
				b: "You'd love to impress the community with your gardening skills.\n\nYou may spend 1 gold to plant a berry bush: Place sticker 1H. Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有「农业 2」或「农业 3」里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "有动物一直在啃你的浆果灌木。它不只吃浆果，连灌木本身都啃了！\n\n弃掉此牌并放置贴纸 1G，覆盖 1 丛浆果灌木和一个食物图标（如能）。",
				b: "你很乐意让大家见识一下你的园艺本事。\n\n你可以花费 1 金币种下一丛浆果灌木：放置贴纸 1H。无论是否种下，随后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y3-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have 1 or more gold, read option A, otherwise read B.",
			options: {
				a: "A woodsman offers to sell you lumber at a good price.\n\nYou may spend 1 gold to gain 2 wood. Regardless, then discard this.",
				b: "The merchant returns in her wagon, singing a new song. “I'm just searching for… searching for… fresh produce!”\n\nYou may spend 1 food to gain 1 gold. Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有 1 枚或更多金币，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "一位伐木工愿意以优惠的价格把木材卖给你。\n\n你可以花费 1 金币获得 2 份木材。无论是否购买，随后弃掉此牌。",
				b: "商贩驾着货车回来了，唱着一首新歌。「我正在找……正在找……新鲜农产品！」\n\n你可以花费 1 份食物获得 1 金币。无论是否兑换，随后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y3-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you do not have the Loan milestone, read option A, otherwise read B.",
			options: {
				a: "The moneylender returns. “Are you sure you don't want some extra spending money?”\n\nYou may gain 3 gold. If you do, gain the Loan milestone (red).\nRegardless, then discard this.",
				b: "The moneylender returns. “Your interest is due, and I've come to collect. Oh, you didn't read the fine print?”\n\nLose 1 gold. If you had none, instead lose 1 of another resource, if able.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你没有 贷款 里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "放贷人又来了。「你确定不需要一点额外的零花钱吗？」\n\n你可以获得 3 金币。若你这样做，获得 贷款 里程碑（红色）。\n无论是否接受，随后弃掉此牌。",
				b: "放贷人又来了。「你的利息到期了，我是来收账的。哦，你没读那些小字条款？」\n\n失去 1 金币。若你没有金币，则改为失去 1 份其他资源（如能）。\n无论结果如何，随后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y3-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Some residents are complaining that their new homes are falling apart.",
			panel: "Keep this card in play.\n\nREPAIR HOMES (3 wood)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 4 wood or gain the Termites milestone (red).\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "一些居民抱怨说，他们的新房子正摇摇欲坠。",
			panel: "将此牌留在场上。\n\n修缮房屋（3 木材）\n弃掉此牌并获得 1 点心情。\n\n岁末\n花费 4 份木材，或获得 白蚁 里程碑（红色）。\n无论选择哪项，随后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y3-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "There's so much potential on the other side of the river. If only there was a permanent way to reach it...",
			panel: "Keep this card in play.\n\nBUILD BRIDGE (2 wood, 2 gold)\nDiscard this and place sticker 12A on the river.\n\nAfter the bridge is built, you can place stickers on both sides of the river for the rest of the game.",
			options: {}
		},
		zh: {
			flavor: "河对岸有那么多的潜力。要是有一座永久性的通道就好了……",
			panel: "将此牌留在场上。\n\n建造桥梁（2 木材、2 金币）\n弃掉此牌，并把贴纸 12A放在河上。\n\n桥梁建成后，本局余下的时间里，你可以在河的两岸放置贴纸。",
			options: {}
		},
		uncertain: []
	},
	"y3-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD PET SHOP (4 wood, 1 gold)\nDiscard this and gain card 19.\n\nBUILD BAKERY (3 wood, 2 food)\nDiscard this and gain card 20.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造宠物店（4 木材、1 金币）\n弃掉此牌并获得图鉴牌 19。\n\n建造面包房（3 木材、2 食物）\n弃掉此牌并获得图鉴牌 20。",
			options: {}
		},
		uncertain: []
	},
	"y3-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD SCHOOL (3 wood, 1 gold)\nDiscard this and gain card 21.\n\nBUILD FIRE STATION (5 wood)\nDiscard this and place sticker 4C.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造学校（3 木材、1 金币）\n弃掉此牌并获得图鉴牌 21。\n\n建造消防站（5 木材）\n弃掉此牌并放置贴纸 4C。",
			options: {}
		},
		uncertain: []
	},
	"y4-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You never worked this hard when you were living with Father.",
			panel: "Either A gather food, or B spend 1 food to gather wood.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 1 wood."
			}
		},
		zh: {
			flavor: "你和父亲住在一起的时候，从没这么拼命干过活。",
			panel: "选择 A 采集食物，或选择 B 花费 1 份食物采集木材。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 1 份木材。"
			}
		},
		uncertain: []
	},
	"y4-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your village is starting to have its own vibe, but it could always use more style.",
			panel: "Either A plant flowers, or B spend 1 gold to build lots of roads.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 flower stickers (11A).",
				b: "Place 3 road stickers (3E)."
			}
		},
		zh: {
			flavor: "你的村子渐渐有了自己的氛围，不过再多几分格调总是好的。",
			panel: "选择 A 种植花朵，或选择 B 花费 1 金币修建大量道路。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚花朵贴纸 11A。",
				b: "放置 3 枚道路贴纸 3E。"
			}
		},
		uncertain: []
	},
	"y4-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your last building project left you with a surplus of scrap wood.",
			panel: "Either A save the wood, or B build some fences.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 wood.",
				b: "Place 2 fence stickers (12R)."
			}
		},
		zh: {
			flavor: "上一次建造工程结束后，你还剩下不少零碎木料。",
			panel: "选择 A 把木料收起来，或选择 B 修建一些围栏。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份木材。",
				b: "放置 2 枚围栏贴纸 12R。"
			}
		},
		uncertain: []
	},
	"y4-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find a one-eyed wolf pup outside your home, the mother nowhere in sight.",
			panel: "Either A raise the wolf pup, or B safely release it back into the wild.\nRead the matching effect, then discard this.",
			options: {
				a: "You name him Patch. There is no way this turns out poorly. Place the wolf pup sticker (5A).",
				b: "You give it some scraps of food, then send it to live with its kind. No effect."
			}
		},
		zh: {
			flavor: "你在家门外发现一只独眼的小狼崽，四处都不见母狼的踪影。",
			panel: "选择 A 收养这只小狼崽，或选择 B 把它安全地放回野外。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "你给它取名帕奇。这事怎么看都不会出岔子。放置小狼崽贴纸 5A。",
				b: "你喂了它一些食物碎屑，然后送它回到同类身边。没有效果。"
			}
		},
		uncertain: []
	},
	"y4-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Your sister Jessie sends you a letter. “Here's the money you loaned me years ago. It's actually Daddy's, but he won't miss it.”",
			panel: "Either A keep the money, or B use it to immediately improve your village.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 gold.",
				b: "Remove 1 upset sticker from the map. If there are none, instead gain 1 happiness."
			}
		},
		zh: {
			flavor: "你的妹妹杰西寄来一封信。「这是你多年前借给我的钱。其实那是爸爸的，不过他不会发现的。」",
			panel: "选择 A 把钱留下，或选择 B 用它立刻改善你的村子。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 金币。",
				b: "从地图上移除 1 枚不满贴纸。如果没有不满贴纸，改为获得 1 心情。"
			}
		},
		uncertain: []
	},
	"y4-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You stumble upon a wild pig rummaging through the forest.",
			panel: "Either A hunt it, or B let it live here.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Place sticker (12B)."
			}
		},
		zh: {
			flavor: "你撞见一头野猪在森林里翻找食物。",
			panel: "选择 A 猎杀它，或选择 B 让它在这里住下。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "放置贴纸 12B。"
			}
		},
		uncertain: []
	},
	"y4-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Wild Bill resident, read option A, otherwise read B.",
			options: {
				a: "Someone has been stealing your food, and your gut tells you it was Wild Bill.\nLose 1 food, if able. Then choose one:\nA Kick him out: Discard this and remove the Wild Bill sticker.\nB Let him stay: Discard this.",
				b: "Your neighbor finds a raccoon living in their basement. They scare it off, but not before it ate a bushel of apples.\nEither spend 2 food or place 1 upset sticker on the map near a resident that isn't upset. Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有野比尔居民，阅读 A 选项；否则阅读 B 选项。",
			options: {
				a: "有人一直在偷你的食物，你直觉认定是野比尔所为。\n若可以，失去 1 份食物。然后选择一项：\nA 赶走他：弃掉此牌并移除野比尔贴纸。\nB 让他留下：弃掉此牌。",
				b: "你的邻居发现一只浣熊住在地下室。他们把它吓跑了，但它已经吃掉整整一蒲式耳的苹果。\n花费 2 份食物，或在一名尚未不满的居民附近放置 1 枚不满贴纸。无论选择哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y4-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If 6 or more wood icons on the map, read option A, otherwise read B.",
			options: {
				a: "A family of beavers has been busy building a dam. Where did the lumber come from? One of your finest trees!\nPlace 2 stickers: sticker 12P on the river and sticker 5Q covering a lone tree (triangle sticker, if able). Then discard this.",
				b: "Why are there so few trees here? Did you chop them all down? Planting a sapling should help remedy this.\nDiscard this and place 1 tree sticker 8X."
			}
		},
		zh: {
			flavor: null,
			panel: "若地图上有 6 个或更多木材图标，阅读 A 选项；否则阅读 B 选项。",
			options: {
				a: "一家河狸一直忙着修筑水坝。木料是从哪里来的？是你最好的树之一！\n放置 2 枚贴纸：把贴纸 12P 放在河上，并让贴纸 5Q 覆盖一棵孤树（如可以，使用三角形贴纸）。然后弃掉此牌。",
				b: "这里的树怎么这么少？是不是都被你砍光了？种下一棵树苗应该能弥补这个问题。\n弃掉此牌并放置 1 枚树木贴纸 8X。"
			}
		},
		uncertain: []
	},
	"y4-09": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Termites milestone, read option A, otherwise read B.",
			options: {
				a: "Your neighbor's home is literally being chewed apart!\nEither lose 1 happiness or spend 3 wood to remove the Termites milestone. Regardless, then discard this.",
				b: "At night you see a shooting star streak across the sky. You make a wish.\nEither gain 1 gold or remove 1 upset sticker from the map. Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有白蚁里程碑，阅读 A 选项；否则阅读 B 选项。",
			options: {
				a: "邻居家的房子真的正在被啃噬殆尽！\n失去 1 心情，或花费 3 份木材移除白蚁里程碑。无论选择哪种，然后弃掉此牌。",
				b: "夜里，你看见一颗流星划过天空，便许了个愿。\n获得 1 金币，或从地图上移除 1 枚不满贴纸。无论选择哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y4-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "The people deserve another feast to recognize the year's accomplishments!",
			panel: "Keep this card in play.\n\nCOOK FEAST (3 food, 1 gold)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 4 food or lose 1 happiness. Regardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "为了表彰这一年的成就，大家值得再享用一场盛宴！",
			panel: "将此牌留在场上。\n\n烹饪盛宴（3 食物、1 金币）\n弃掉此牌并获得 1 心情。\n\n岁末\n花费 4 份食物，或失去 1 心情。无论选择哪种，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y4-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD RESTAURANT (3 wood, 2 food)\nDiscard this and place sticker 4M.\n\nBUILD LIBRARY (2 wood, 2 gold)\nDiscard this and gain card 34.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造餐馆（3 木材、2 食物）\n弃掉此牌并放置贴纸 4M。\n\n建造图书馆（2 木材、2 金币）\n弃掉此牌并获得图鉴牌 34。",
			options: {}
		},
		uncertain: []
	},
	"y4-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD FISHING SHOP (4 wood)\nDiscard this and gain card 32.\n\nBUILD LARGE HOME (3 wood, 1 gold)\nDiscard this and place sticker 4H.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造鱼店（4 木材）\n弃掉此牌并获得图鉴牌 32。\n\n建造大宅（3 木材、1 金币）\n弃掉此牌并放置贴纸 4H。",
			options: {}
		},
		uncertain: []
	},
	"y5-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "The old you might have complained about hauling food and wood everywhere. The new you enjoys the peace and simplicity of working outdoors.",
			panel: "Either A gather food, or B spend 1 food to gather wood.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 1 wood."
			}
		},
		zh: {
			flavor: "过去的你也许会抱怨整天到处搬运食物和木料。如今的你享受着在户外劳作的平静与简单。",
			panel: "选择 A 采集食物，或选择 B 花费 1 份食物采集木材。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 1 份木材。"
			}
		},
		uncertain: []
	},
	"y5-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Fences might be helpful in deterring a predator or two.",
			panel: "Either A build some fences, or B build some roads.",
			options: {
				a: "Place 2 fence stickers (12R).",
				b: "Place 2 road stickers (3E)."
			}
		},
		zh: {
			flavor: "围栏也许有助于挡下一两只掠食者。",
			panel: "选择 A 修建一些围栏，或选择 B 修建一些道路。",
			options: {
				a: "放置 2 枚围栏贴纸 12R。",
				b: "放置 2 枚道路贴纸 3E。"
			}
		},
		uncertain: []
	},
	"y5-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A day in the forest would do you well. Maybe you could even practice your hunting skills?",
			panel: "Either gain 1 wood or go hunting. If you go hunting, roll the die and read the effect below matching the result.\nRegardless, then discard this.",
			options: {
				a: "Gain 1 wood.",
				b: "Roll the die and read the effect matching the result:\n1: The only thing you catch is poison ivy. Lose 1 happiness.\n2-4: You catch a rabbit. Gain 1 food.\n5: A deer! Gain 2 food.\n6: That's a lot of moose meat. Gain 3 food."
			}
		},
		zh: {
			flavor: "在森林里待上一天对你有好处。也许你还能顺便练练打猎的本事？",
			panel: "获得 1 份木材，或外出打猎。如果你外出打猎，掷骰并阅读下方与结果对应的效果。\n无论选择哪种，然后弃掉此牌。",
			options: {
				a: "获得 1 份木材。",
				b: "掷骰并阅读与结果对应的效果：\n掷出 1：你只抓到毒藤。失去 1 心情。\n掷出 2-4：你抓到了一只兔子。获得 1 份食物。\n掷出 5：一头鹿！获得 2 份食物。\n掷出 6：好多的驼鹿肉。获得 3 份食物。"
			}
		},
		uncertain: ["打猎结果以骰面点数图标印刷，已按点数转写；卡面底部为倒置排版。"]
	},
	"y5-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "What better way to start the day than with a big breakfast?\nYour mouth waters as you imagine a plate of golden brown french toast. And maybe a few slices of thick, fatty bacon.",
			panel: "You may spend 2 food to perform 1 additional action this turn.\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "还有什么比一顿丰盛的早餐更适合开启新的一天？\n想到一盘金黄的法式吐司，也许再来几片厚实的肥培根，你就忍不住流口水。",
			panel: "你可以花费 2 份食物，在本回合额外行动一次。\n无论是否如此，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y5-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Jessie begs to borrow money, but you doubt she'll repay you. “My girls are waiting for me in the city! And it's not like you need it for anything.”",
			panel: "Either A spend 2 gold to say, “Sure,” or B say, “Sorry, no.”\nRead the matching effect, then discard this.",
			options: {
				a: "“I knew I could count on you!” Gain 1 happiness.",
				b: "“You're just like Daddy!” Open the storybook to the page shown on Jessie's resident sticker (18 or 22). Place 1 progress sticker covering the “?” near that page number."
			}
		},
		zh: {
			flavor: "杰西苦苦哀求你借钱给她，可你怀疑她根本不会还。「我的姐妹们在城里等着我呢！再说你留着这钱也没什么用。」",
			panel: "选择 A 花费 2 金币说「当然可以」，或选择 B 说「抱歉，不行」。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "「我就知道能指望你！」获得 1 心情。",
				b: "「你简直跟爸爸一个样！」翻开故事书，翻到杰西的居民贴纸上标示的页码（18 或 22）。放置 1 枚进度贴纸，覆盖该页码附近的「？」。"
			}
		},
		uncertain: []
	},
	"y5-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Zach Johnson resident, read option A, otherwise read B.",
			options: {
				a: "“The world NEEDS to see my animal hats! Can you imagine a cow wearing a sombrero? I can!”\nDiscard this and place a hat sticker 12K on an animal, if able.",
				b: "An inventor stands on your doorstep. “Need a perfect smile? Just say CHEESE with my cheddar toothpaste. Invest now, and we can both become rich!”\nYou may spend 2 gold to gain the Investment milestone (bronze). Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有扎克·约翰逊居民，阅读 A 选项；否则阅读 B 选项。",
			options: {
				a: "「全世界都必须看看我的动物帽子！你能想象一头牛戴着墨西哥宽边帽吗？我能！」\n弃掉此牌，并在一只动物上放置帽子贴纸 12K，如可以。",
				b: "一位发明家站在你家门口。「想要完美的笑容吗？用我的切达奶酪牙膏，只要说一声『CHEESE』！现在就投资，我们俩都能发财！」\n你可以花费 2 金币获得投资里程碑（铜）。无论是否如此，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y5-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Fire Station, read option A, otherwise read B.",
			options: {
				a: "You carelessly knock over a candle and start a fire! Luckily, the fire department is quick to respond and saves your home.\nDiscard this and gain 1 happiness.",
				b: "You carelessly knock over a candle and start a fire!\nRoll the die. On a 1-4, lose 1 happiness and cover your house with sticker 4F. Otherwise, you quickly put out the fire (no effect).\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有消防站，阅读 A 选项；否则阅读 B 选项。",
			options: {
				a: "你不小心碰倒蜡烛，引发了一场火灾！幸好消防队反应迅速，保住了你的家。\n弃掉此牌并获得 1 心情。",
				b: "你不小心碰倒蜡烛，引发了一场火灾！\n掷骰。掷出 1-4 时，失去 1 心情并用贴纸 4F 覆盖你的房屋。否则，你迅速扑灭了火（没有效果）。\n无论选择哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y5-08": {
		kind: "keep",
		title: {
			en: "YEAR FIVE AMBITION",
			zh: "第五年的抱负"
		},
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nPROUD VILLAGE (2 gold)\nIf you have 10 or more happiness, discard this, gain 1 happiness, and read 24.8.\n\nBUSY VILLAGE (2 gold)\nIf you have 12 or more roads, discard this, gain 1 happiness, and place sticker 5K.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n自豪村庄（2 金币）\n若你拥有 10 点或更多心情，弃掉此牌，获得 1 心情，并阅读 24.8。\n\n繁忙村庄（2 金币）\n若你拥有 12 条或更多道路，弃掉此牌，获得 1 心情，并放置贴纸 5K。",
			options: {}
		},
		uncertain: []
	},
	"y5-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Cold winds blow as your villagers huddle in their homes. They're running out of food and firewood!",
			panel: "Keep this card in play.\n\nGIVE SUPPLIES (1 wood, 3 food)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 4 food or gain the Hard Winter milestone (red). Regardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "寒风呼啸，村民们蜷缩在家中。他们的食物和柴火都快用完了！",
			panel: "将此牌留在场上。\n\n提供补给（1 木材、3 食物）\n弃掉此牌并获得 1 心情。\n\n岁末\n花费 4 份食物，或获得严冬里程碑（红）。无论选择哪种，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y5-10": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find an abandoned mine in the mountains.",
			panel: "Discard this and gain card 35.\n(Reminder: Use card 35A unless this is your second playthrough.)",
			options: {}
		},
		zh: {
			flavor: "你在山里发现了一座废弃的矿井。",
			panel: "弃掉此牌并获得图鉴牌 35。\n（提示：除非这是你的第二轮游玩，否则使用图鉴牌 35A。）",
			options: {}
		},
		uncertain: []
	},
	"y5-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD CURIOSITY SHOP (4 wood, 1 food)\nDiscard this and gain card 46.\n\nBUILD WATER TOWER (3 gold, 1 ore)\nDiscard this and place sticker 10C.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造古玩店（4 木材、1 食物）\n弃掉此牌并获得图鉴牌 46。\n\n建造水塔（3 金币、1 矿石）\n弃掉此牌并放置贴纸 10C。",
			options: {}
		},
		uncertain: []
	},
	"y5-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD HEN HOUSE (2 wood, 2 food)\nDiscard this and place sticker 8U.\n\nBUILD NATURE PRESERVE (3 wood, 2 gold)\nDiscard this and place sticker 10B.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造鸡舍（2 木材、2 食物）\n弃掉此牌并放置贴纸 8U。\n\n建造自然保护区（3 木材、2 金币）\n弃掉此牌并放置贴纸 10B。",
			options: {}
		},
		uncertain: []
	},
	"y6-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You step out your front door and almost walk right into a grizzly bear! It stares at you, and you stare back, frozen. After what seems like an eternity, it sniffs the air and then wanders away.\n\nToday, life feels like a gift, and you want to make the most of it.",
			panel: "You may spend 2 food to perform 1 additional action this turn.\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "你走出家门，差点迎面撞上一头灰熊！它盯着你，你也僵在原地盯着它。仿佛过了整整一个世纪，它嗅了嗅空气，转身走开了。\n\n今天，生命仿佛是一份礼物，你想好好珍惜。",
			panel: "你可以花费 2 份食物，在本回合额外行动 1 次。\n无论如何，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y6-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "“It's just a pile of old sticks and rubble,” Jessie says with a shrug. She suggests throwing it all in the river, but you have a better idea.",
			panel: "Either A build fences, B build a road, or C spend 1 gold to build lots of roads.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 fence stickers 12R.",
				b: "Place 1 road sticker 3E.",
				c: "Place 3 road stickers 3E."
			}
		},
		zh: {
			flavor: "「这不过是一堆旧树枝和碎石罢了。」杰西耸耸肩说。她建议把这些统统扔进河里，但你有个更好的主意。",
			panel: "选择 A 修建栅栏，选择 B 修建一条道路，或选择 C 花费 1 金币修建大量道路。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚栅栏贴纸 12R。",
				b: "放置 1 枚道路贴纸 3E。",
				c: "放置 3 枚道路贴纸 3E。"
			}
		},
		uncertain: []
	},
	"y6-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You receive a letter from your Aunt Claire. “Send this letter to one hundred people to receive good luck!”\n\n100 people? That would take all day!",
			panel: "Either A ignore the letter, or B spend 1 food to write 100 letters.\nRead the matching effect, then discard this.",
			options: {
				a: "If you have the Lucky milestone, remove it. Otherwise, no effect.",
				b: "If you have the Lucky milestone, gain 1 gold. Otherwise, gain the Lucky milestone (bronze)."
			}
		},
		zh: {
			flavor: "你收到克莱尔姑妈寄来的一封信。「把这封信寄给一百个人，你就会得到好运！」\n\n一百个人？那得花上一整天！",
			panel: "选择 A 无视这封信，或选择 B 花费 1 份食物，写上一百封信。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "若你拥有幸运儿里程碑，移除它。否则没有效果。",
				b: "若你拥有幸运儿里程碑，获得 1 金币。否则获得幸运儿里程碑（铜级）。"
			}
		},
		uncertain: []
	},
	"y6-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A day in the mine is worth two in the bush! You don't know what that means, but it's something Father used to say.",
			panel: "Either A mine gold, or B spend 2 food to mine ore.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 gold.",
				b: "Gain 1 ore."
			}
		},
		zh: {
			flavor: "矿井里的一天胜过灌木丛里的两天！你并不明白这句话是什么意思，但这是父亲常挂在嘴边的话。",
			panel: "选择 A 开采黄金，或选择 B 花费 2 份食物开采矿石。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 金币。",
				b: "获得 1 份矿石。"
			}
		},
		uncertain: []
	},
	"y6-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "A traveler offers to sell you some magic beans.",
			panel: "Either A say, “Nope, sounds like a scam,” or B spend 1 gold to buy the beans.\nRead the matching effect, then discard this.",
			options: {
				a: "“Your loss!” No effect.",
				b: "Roll the die. On a 5 or 6, read 24.4. Otherwise, they are just normal beans: Gain 1 food."
			}
		},
		zh: {
			flavor: "一名旅行者向你兜售一些魔豆。",
			panel: "选择 A 说「不了，听起来像是骗局」，或选择 B 花费 1 金币买下这些豆子。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "「那是你的损失！」没有效果。",
				b: "掷骰。若掷出 5 点或 6 点，阅读故事 24.4。否则，它们只是普通的豆子：获得 1 份食物。"
			}
		},
		uncertain: []
	},
	"y6-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find yourself in the middle of a dispute. “Stop stealing my apples!” one resident shouts. “As soon as you stop planting crops in my field!” the other retorts.",
			panel: "Either A side with one of them, or B attempt a compromise.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 1 upset sticker on the map near a resident that is not upset.",
				b: "Roll a die. On a 1 or 2, resolve option A twice. Otherwise, everyone seems happy-ish: no effect."
			}
		},
		zh: {
			flavor: "你发现自己被卷入了两位居民的争执。「别再偷我的苹果了！」一位居民喊道。「那你先别在我的田里种庄稼！」另一位回敬道。",
			panel: "选择 A 站到其中一方那边，或选择 B 试着调解。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "在地图上一位没有不满的居民附近放置 1 枚不满贴纸。",
				b: "掷骰。若掷出 1 点或 2 点，将选项 A 结算两次。否则，大家似乎还算开心：没有效果。"
			}
		},
		uncertain: []
	},
	"y6-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Hard Winter milestone, read option A, otherwise read B.",
			options: {
				a: "Memories of recent hardships linger like an unwanted guest. Perhaps a hearty stew would help?\n\nYou may spend 3 food to remove the Hard Winter milestone. Otherwise, lose 1 happiness.\nRegardless, then discard this.",
				b: "You're feeling stronger and more alive than you've felt in a long time.\n\nDiscard this card. You may perform 1 additional action this turn."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有严冬里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "最近的艰辛像不速之客一样萦绕不去。也许一锅热汤会有帮助？\n\n你可以花费 3 份食物移除严冬里程碑。否则失去 1 点心情。\n无论如何，然后弃掉此牌。",
				b: "你感觉自己比很久以来都更强壮、更有活力。\n\n弃掉此牌。你可以在本回合额外行动 1 次。"
			}
		},
		uncertain: []
	},
	"y6-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the wolf pup, read option A, otherwise read B.",
			options: {
				a: "While lounging in your favorite chair, you hear wolves howling in the distance. Patch sits up at attention.\n\nChoose one:\nA Pet him: Read 10.4.\nB Leave him be: Read 32.7.",
				b: "The fish are practically jumping out of the water today. You don't need a hook; you need a bucket!\n\nIf you have card 12A or 12B, perform the “Go Fishing” action on it. During this action, treat all 1s rolled as 6s.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有狼崽，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你正窝在最喜欢的椅子里，忽然听见远处传来狼嚎。帕奇警觉地坐直了身子。\n\n选择一项：\nA 抚摸他：阅读故事 10.4。\nB 不去管他：阅读故事 32.7。",
				b: "今天的鱼几乎要自己跳出水面了。你不需要鱼钩，你需要的是水桶！\n\n若你拥有图鉴牌 12A 或 12B，对其执行「去钓鱼」行动。在此行动中，将掷出的所有 1 点视为 6 点。\n无论如何，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y6-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "A predator has been hunting local wildlife and stealing food from your residents.",
			panel: "Keep this card in play.\n\nTRAP PREDATOR (4 wood)\nDiscard this and gain 1 happiness.\n*Reduce this cost by 1 wood for each fence sticker on the map.\n\nEND OF THE YEAR\nDiscard this and read 9.8.",
			options: {}
		},
		zh: {
			flavor: "一头掠食者一直在捕食当地的野生动物，还偷走居民们的食物。",
			panel: "将此牌留在场上。\n\n诱捕掠食者（4 木材）\n弃掉此牌并获得 1 点心情。\n地图上每有 1 枚栅栏贴纸，此费用减少 1 份木材。\n\n岁末\n弃掉此牌并阅读故事 9.8。",
			options: {}
		},
		uncertain: []
	},
	"y6-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You could always use more trees, assuming you could find the time to plant them and money to hire help.",
			panel: "Keep this card in play.\n\nPLANT GROVE (3 gold)\nDiscard this and place sticker 6T.\n\nEND OF THE YEAR\nEither spend 1 gold or discard this.",
			options: {}
		},
		zh: {
			flavor: "你总需要更多的树，前提是你抽得出时间种下它们，也拿得出钱雇人帮忙。",
			panel: "将此牌留在场上。\n\n种植树林（3 金币）\n弃掉此牌并放置贴纸 6T。\n\n岁末\n花费 1 金币，或弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y6-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD BIRDING SOCIETY (3 wood, 1 food, 1 ore)\nDiscard this and gain card 37.\n\nBUILD CLOTHING STORE (3 wood, 2 gold)\nDiscard this and gain card 40.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造鸟类协会（3 木材、1 份食物、1 矿石）\n弃掉此牌并获得图鉴牌 37。\n\n建造服装店（3 木材、2 金币）\n弃掉此牌并获得图鉴牌 40。",
			options: {}
		},
		uncertain: []
	},
	"y6-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD OBSERVATORY (2 wood, 2 ore)\nDiscard this and gain card 41.\n\nBUILD CLOCK TOWER (3 wood, 1 gold, 1 ore)\nDiscard this and gain card 36.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造天文台（2 木材、2 矿石）\n弃掉此牌并获得图鉴牌 41。\n\n建造钟楼（3 木材、1 金币、1 矿石）\n弃掉此牌并获得图鉴牌 36。",
			options: {}
		},
		uncertain: []
	},
	"y7-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You wake up exhausted all the way down to your bones. But there's work to be done, and someone has to do it!",
			panel: "Either A gather food, B spend 1 food to gather wood, or C trick your neighbor into gathering lots of wood.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 1 wood.",
				c: "You pretend to be deathly ill. They help you but suspect you were faking. Gain 2 wood. Then place 1 upset sticker on a resident that isn't upset."
			}
		},
		zh: {
			flavor: "你醒来时疲惫到骨子里。但活儿总得有人干，而这个人只能是你！",
			panel: "选择 A 采集食物，选择 B 花费 1 份食物采集木材，或选择 C 哄骗邻居替你采集大量木材。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 1 份木材。",
				c: "你假装病入膏肓。他们帮了你，却怀疑你在装病。获得 2 份木材。然后在一名没有不满的居民身上放置 1 枚不满贴纸。"
			}
		},
		uncertain: []
	},
	"y7-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You are surprised to hear that Jessie is heading to the quarry. “I gotta find a new rock-friend,” she says mysteriously. “Need anything?”",
			panel: "Either A ask her to bring back cobblestones for roads, or B ask for ore.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 road stickers 3E.",
				b: "Gain 1 ore."
			}
		},
		zh: {
			flavor: "你惊讶地听说杰西要去采石场。「我得去找个新的石头朋友。」她神秘地说，「需要带点什么吗？」",
			panel: "选择 A 请她带些铺路用的鹅卵石回来，或选择 B 请她带些矿石回来。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚道路贴纸 3E。",
				b: "获得 1 份矿石。"
			}
		},
		uncertain: []
	},
	"y7-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You completely forgot that today is your neighbor's birthday! If you hurry, you might have time to find them a present.",
			panel: "Either A give them a pair of your clean socks, or B spend 1 gold to buy them a fine teapot.\nRead the matching effect, then discard this.",
			options: {
				a: "“There are holes in these, but thanks?” No effect.",
				b: "They love it and invite you to a tea party! Remove 1 upset sticker from the map. If no upset stickers on the map, instead gain 1 happiness."
			}
		},
		zh: {
			flavor: "你完全忘了今天是邻居的生日！如果动作快点，也许还来得及给他们找份礼物。",
			panel: "选择 A 送他们一双你干净的袜子，或选择 B 花费 1 金币给他们买一把精致的茶壶。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "「这上面破了洞，不过还是谢谢？」没有效果。",
				b: "他们很喜欢，还邀请你参加茶会！从地图上移除 1 枚不满贴纸。若地图上没有不满贴纸，则改为获得 1 点心情。"
			}
		},
		uncertain: []
	},
	"y7-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You used to sleep until noon, but now you find yourself waking at sunrise.\nA big breakfast and you'll be ready to go.",
			panel: "You may spend 2 food to perform 1 additional action this turn.\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "你过去总要睡到中午，如今却发现自己日出即醒。\n吃一顿丰盛的早餐，你就准备好出发了。",
			panel: "你可以花费 2 份食物，在本回合额外行动 1 次。\n无论如何，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y7-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have 14 or more happiness, read option A, otherwise read B.",
			options: {
				a: "You're happy, but is that enough? You could accomplish so much more if you started waking up before sunrise.\n\nYou may gain 2 resources of your choice. If you do, roll the die. On a 1 or 2, lose 1 happiness.\nRegardless, then discard this.",
				b: "Don't dwell on your feelings. Keep busy and things will work out.\n\nEither place 1 road sticker 3E or perform 1 additional action this turn.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你的心情不少于 14 点，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你很快乐，但这样就够了吗？若能赶在日出前起床，你还能成就更多。\n\n你可以获得 2 份自选资源。若你这么做，掷骰。若掷出 1 点或 2 点，失去 1 点心情。\n无论如何，然后弃掉此牌。",
				b: "别沉溺于自己的感受。保持忙碌，事情总会好起来。\n\n放置 1 枚道路贴纸 3E，或在本回合额外行动 1 次。\n无论如何，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y7-06": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Loan milestone, keep this card in play.\nOtherwise, discard this and perform 1 additional action this turn.\n\nPAY OFF LOAN (4 gold)\nDiscard this and remove the Loan milestone.\n\nEND OF THE YEAR\nDiscard this and read 28.8.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "若你拥有贷款里程碑，将此牌留在场上。\n否则，弃掉此牌，并在本回合额外行动 1 次。\n\n还清贷款（4 金币）\n弃掉此牌并移除贷款里程碑。\n\n岁末\n弃掉此牌并阅读故事 28.8。",
			options: {}
		},
		uncertain: []
	},
	"y7-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If there is an upset resident on a house sticker with a grass background, read option A, otherwise read B.",
			options: {
				a: "You find their house vacant, not one stick of furniture left. They didn't even leave a goodbye note.\n\nDiscard this. Then place sticker 8W (either one) over that resident and their house. Discard all cards in play with that resident's art on it (except card 47).",
				b: "Someone sends you an anonymous letter that sings praises about your village and how much they love living here.\n\nDiscard this and gain 1 happiness."
			}
		},
		zh: {
			flavor: null,
			panel: "若草地背景的房屋贴纸上住着一位不满的居民，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你发现他们的房子已经空了，一件家具都没留下。他们甚至没有留下告别信。\n\n弃掉此牌。然后将贴纸（8W，两种任选其一）覆盖在那名居民及其房屋上。弃掉场上所有印有该居民插画的牌（图鉴牌 47 除外）。",
				b: "有人给你寄来一封匿名信，信中盛赞你的村庄，说他们多么喜欢住在这里。\n\n弃掉此牌并获得 1 点心情。"
			}
		},
		uncertain: []
	},
	"y7-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Water Tower, read option A, otherwise read B.",
			options: {
				a: "While neighboring villages are experiencing a drought, you have ample water to feed your crops.\n\nDiscard this and gain 1 food.",
				b: "It hasn't rained in weeks, and the plants are turning brown.\n\nDiscard this and place sticker 1G, covering 1 berry bush and apple icon, if able."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有水塔，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "邻近的村庄正遭受旱灾，而你有充足的水灌溉庄稼。\n\n弃掉此牌并获得 1 份食物。",
				b: "已经好几周没有下雨，植物都在变黄了。\n\n弃掉此牌并放置贴纸 1G，覆盖 1 丛浆果灌木和 1 个苹果图标，若可以的话。"
			}
		},
		uncertain: ["选项 B 中被覆盖的第二个图标（浆果丛旁的小图标）形似苹果，按苹果图标处理；卡面未给出文字说明。"]
	},
	"y7-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Apple trees require special cultivation. If you just plant apple seeds, the fruit will likely be inedible.",
			panel: "Either keep this card in play or discard it to perform 1 additional action this turn.\n\nPLANT APPLE TREE (2 food, 1 gold)\nDiscard this and place sticker 5R.\n\nEND OF THE YEAR\nEither spend 1 food or discard this.",
			options: {}
		},
		zh: {
			flavor: "苹果树需要特别的栽培。若只是播下苹果种子，结出的果实多半无法食用。",
			panel: "将此牌留在场上，或弃掉此牌，以在本回合额外行动 1 次。\n\n栽种苹果树（2 份食物、1 金币）\n弃掉此牌并放置贴纸 5R。\n\n岁末\n花费 1 份食物，或弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y7-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Up on the mountainside, you find the perfect place to build a cabin. The view would be spectacular!",
			panel: "Keep this card in play.\n\nBUILD MOUNTAIN HOME (4 wood, 1 ore)\nDiscard this and choose who should live in this house:",
			options: {
				a: "Bob the Miner: place sticker 4S.",
				b: "Elise the Painter: place sticker 8M."
			}
		},
		zh: {
			flavor: "你在山坡上找到一处建造小屋的绝佳地点。这里的景色一定美不胜收！",
			panel: "将此牌留在场上。\n\n建造山间小屋（4 木材、1 矿石）\n弃掉此牌，并选择由谁住进这栋房子：",
			options: {
				a: "矿工鲍勃：放置贴纸 4S。",
				b: "画家伊莉丝：放置贴纸 8M。"
			}
		},
		uncertain: []
	},
	"y7-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD ZEN GARDEN (5 wood)\nDiscard this and place sticker 4V.\n\nBUILD POST OFFICE (3 wood, 2 gold)\nDiscard this and read 26.5.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造禅意花园（5 木材）\n弃掉此牌并放置贴纸 4V。\n\n建造邮局（3 木材、2 金币）\n弃掉此牌并阅读故事 26.5。",
			options: {}
		},
		uncertain: []
	},
	"y7-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You'd like to expand the selection of goods in the market, and maybe get better deals!",
			panel: "Keep this card in play.\n\nUPGRADE MARKET (1 wood, 1 food, 1 gold)\nIf you have card 9, discard it and gain card 33. Then discard this card.",
			options: {}
		},
		zh: {
			flavor: "你想扩充市场上的商品种类，也许还能谈成更好的交易！",
			panel: "将此牌留在场上。\n\n升级市场（1 木材、1 份食物、1 金币）\n若你拥有图鉴牌 9，弃掉它并获得图鉴牌 33。然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y8-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You find a pile of cobblestones slowly being claimed by moss. Finders, keepers! Wherever they're from, they should make road construction a breeze.",
			panel: "Either A build some roads, or B forget the cobblestones and plant some greenery.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 2 road stickers (3E).",
				b: "Place 1 bush sticker (1H) and 1 flower sticker (11A)."
			}
		},
		zh: {
			flavor: "你发现一堆正在被苔藓慢慢吞没的鹅卵石。先到先得！不管它们从哪来，修起路来一定轻松不少。",
			panel: "选择 A 修一些道路，或选择 B 不管这些鹅卵石，种些绿植。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 2 枚道路贴纸 3E。",
				b: "放置 1 枚灌木贴纸 1H和 1 枚花朵贴纸 11A。"
			}
		},
		uncertain: []
	},
	"y8-02": {
		kind: "choice",
		title: null,
		en: {
			flavor: "You'd give your left kidney for a grilled cheese sandwich. Such a simple meal. Just bread, cheese, and a little butter. Golden brown perfection!",
			panel: "You may spend 2 food to perform 1 additional action this turn.\nRegardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "为了一块烤奶酪三明治，你愿意捐出一个肾。多简单的一顿饭。不过是面包、奶酪和一点黄油。烤到金黄，完美无缺！",
			panel: "你可以花费 2 份食物，本回合额外行动一次。\n无论如何，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y8-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "The menu options for today: fruit, sticks, or shiny rocks?",
			panel: "Either A gather food, B spend 1 food to gather lots of wood, or C spend 2 food to mine ore.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 1 food.",
				b: "Gain 2 wood.",
				c: "Gain 1 ore."
			}
		},
		zh: {
			flavor: "今天的菜单：水果、树枝，还是亮晶晶的石头？",
			panel: "选择 A 采集食物，选择 B 花费 1 份食物采集大量木材，或选择 C 花费 2 份食物开采矿石。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 1 份食物。",
				b: "获得 2 份木材。",
				c: "获得 1 份矿石。"
			}
		},
		uncertain: []
	},
	"y8-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Ore is expensive, so you're surprised when a stranger offers to trade you some for a single apple pie.\n“I swear I'm a real merchant,” she says. “I'm just craving a pastry.”",
			panel: "Either A politely refuse, or B spend 1 food to accept the trade.\nRead the matching effect, then discard this.",
			options: {
				a: "“Your loss.” No effect.",
				b: "“Deal! Well, I need to get moving.”\nGain 1 ore and roll the die. On a 1-3, gain the Hot Goods milestone (red). Otherwise, no additional effect."
			}
		},
		zh: {
			flavor: "矿石很贵，所以当一位陌生人提出用一块苹果派换些矿石时，你很惊讶。\n「我发誓我是真正的商人，」她说，「我只是馋一块点心。」",
			panel: "选择 A 礼貌拒绝，或选择 B 花费 1 份食物接受这笔交易。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "「那是你的损失。」没有效果。",
				b: "「成交！好了，我得赶路了。」\n获得 1 份矿石并掷骰。若掷出 1-3，获得赃物里程碑（红）。否则没有额外效果。"
			}
		},
		uncertain: []
	},
	"y8-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Mother pays you a surprise visit. “I've missed you dearie, but it looks like you're doing just fine.” She kisses your forehead then hands you a small coin-purse. “And here... a little gift.”",
			panel: "Either A accept the money, or B politely refuse.\nRead the matching effect, then discard this.",
			options: {
				a: "“Thanks Mom!” Gain 2 gold.",
				b: "“Just seeing you was reward enough.” Gain the Noble milestone (silver)."
			}
		},
		zh: {
			flavor: "母亲突然来看你。「亲爱的，我很想你，不过看样子你过得挺好。」她亲了亲你的额头，然后递给你一个小钱袋。「拿着……一点小礼物。」",
			panel: "选择 A 收下这笔钱，或选择 B 礼貌拒绝。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "「谢谢妈妈！」获得 2 金币。",
				b: "「能见到你就是最好的回报。」获得贵族里程碑（银）。"
			}
		},
		uncertain: []
	},
	"y8-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have 2 or more gold, read option A, otherwise read B.",
			options: {
				a: "They say money can't buy happiness, but buying that gold watch would make you quite happy.\n\nYou may spend 2 gold to gain 1 happiness.\nRegardless, then discard this.",
				b: "You may not have much money, but you do have plenty of time, and time is money, right?\n\nDiscard this and perform any action on the map. (Then perform another action as normal.)"
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有 2 枚或更多金币，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "他们都说金钱买不到心情，可买下那块金表会让你相当心情。\n\n你可以花费 2 金币获得 1 点心情。\n无论如何，然后弃掉此牌。",
				b: "你也许没多少钱，但你有的是时间，而时间就是金钱，对吧？\n\n弃掉此牌，并在地图上执行任意一次行动。（然后照常再进行一次行动。）"
			}
		},
		uncertain: []
	},
	"y8-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Test Subject milestone, read option A, otherwise read B.",
			options: {
				a: "You awaken at 3 AM with an insatiable urge to eat large amounts of raw meat. What's going on?\n\nEither spend 2 food or lose 1 happiness.\nRegardless, then discard this.",
				b: "Hiring some part time help would give you more time to do the things that really matter.\n\nYou may spend 1 gold to perform 1 additional action this turn. Regardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有试验对象里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你在凌晨三点醒来，无比渴望大吃生肉。这是怎么回事？\n\n选择花费 2 份食物，或失去 1 点心情。\n无论如何，然后弃掉此牌。",
				b: "雇些兼职帮手，能让你有更多时间去做真正重要的事。\n\n你可以花费 1 金币，本回合额外行动一次。无论如何，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y8-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you do not have a Fire Station or Water Tower, read option A, otherwise read B.",
			options: {
				a: "The forest burns. You and your neighbors spend hours throwing buckets of water on the flames.\n\nPlace sticker 8N. It must cover a sticker with a wood icon and exactly 2 trees (or a sticker with both a wood and axe icon).",
				b: "A magnificent hot air balloon lands in your field. The pilot seems to be having trouble getting back in the air.\n\nEither help them fix the balloon (read 29.7) or ask them to stay (read 29.8)."
			}
		},
		zh: {
			flavor: null,
			panel: "若你没有消防站或水塔，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "森林燃起大火。你和邻居们花了好几个小时往火焰上泼水。\n\n放置贴纸 8N。它必须覆盖 1 枚带有木材图标的贴纸和恰好 2 棵树（或 1 枚同时带有木材和斧头图标的贴纸）。",
				b: "一只巨大的热气球降落在你的田地里。飞行员似乎很难让气球重新升空。\n\n选择帮他修好气球（阅读故事 29.7），或请他留下来（阅读故事 29.8）。"
			}
		},
		uncertain: []
	},
	"y8-09": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have 8 or more residents that are not upset, read option A, otherwise read B.",
			options: {
				a: "You invite your neighbors to a good old-fashioned barn raisin' party. With their help, you should have this structure built in no time.\n\nIf you perform an action on a card this turn, it costs 0 resources instead of the resources printed on it. Regardless, then discard this.",
				b: "Your solitary life gives you plenty of time to get things done.\n\nDiscard this card. You may perform 1 additional action this turn."
			}
		},
		zh: {
			flavor: null,
			panel: "若你有 8 名或更多未处于不满状态的居民，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你邀请邻居们来参加一场老式的谷仓聚会。有了他们的帮忙，这座建筑转眼就能盖好。\n\n本回合若你在某张卡牌上执行行动，其花费为 0 资源，而不是卡面印制所需的资源。无论如何，然后弃掉此牌。",
				b: "独居生活让你有充足的时间把事情做完。\n\n弃掉此牌。本回合你可以额外行动一次。"
			}
		},
		uncertain: []
	},
	"y8-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD CANDY SHOP (3 wood, 1 food, 1 gold)\nDiscard this and gain card 56.\n\nBUILD SUMMER CAMP (4 wood, 2 gold)\nDiscard this and place sticker 10G.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造糖果店（3 木材、1 食物、1 金币）\n弃掉此牌并获得图鉴牌 56。\n\n建造夏令营（4 木材、2 金币）\n弃掉此牌并放置贴纸 10G。",
			options: {}
		},
		uncertain: []
	},
	"y8-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD BANK (3 wood, 2 ore)\nDiscard this and place sticker 8V.\n\nBUILD NEWSPAPER PRESS (3 wood, 1 gold, 1 ore)\nDiscard this and place sticker 7K.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造银行（3 木材、2 矿石）\n弃掉此牌并放置贴纸 8V。\n\n建造报社（3 木材、1 金币、1 矿石）\n弃掉此牌并放置贴纸 7K。",
			options: {}
		},
		uncertain: []
	},
	"y8-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Lady Abigail wants to bring theater to this village but Nicholas Jackson dreams of opening a toy shop.",
			panel: "Keep this card in play.\n\nBUILD MANSION (4 wood, 2 gold)\nDiscard this and choose who should live in this house:",
			options: {
				a: "Lady Abigail: Gain card 53.",
				b: "Nicholas Jackson: Gain card 54."
			}
		},
		zh: {
			flavor: "阿比盖尔夫人想给这座村庄带来戏剧，而尼古拉斯·杰克逊梦想开一家玩具店。",
			panel: "将此牌留在场上。\n\n建造宅邸（4 木材、2 金币）\n弃掉此牌，并选择由谁住进这栋房子：",
			options: {
				a: "阿比盖尔夫人：获得图鉴牌 53。",
				b: "尼古拉斯·杰克逊：获得图鉴牌 54。"
			}
		},
		uncertain: []
	},
	"y9-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "The annual Tri-County Fishing Competition has chosen your village to be this year's host. There's even a cash prize!",
			panel: "If you have card 12A or 12B, perform the “Go Fishing” action on it.\nIf you reel in a fish worth 2 or more food, you also gain 1 gold.\nRegardless, then discard this (and perform another action as normal).",
			options: {}
		},
		zh: {
			flavor: "一年一度的三县钓鱼大赛选中了你的村庄作为今年的主办地。甚至还有现金奖励！",
			panel: "若你拥有图鉴牌 12A 或 12B，在其上执行「去钓鱼」行动。\n若你钓到价值 2 份或更多食物的鱼，你还额外获得 1 金币。\n无论如何，然后弃掉此牌（并照常再进行一次行动）。",
			options: {}
		},
		uncertain: []
	},
	"y9-02": {
		kind: "keep",
		title: null,
		en: {
			flavor: "“My house is so drafty!” your neighbor laments. “And there's no privacy! This isn't the dream home I was hoping for.”",
			panel: "Keep this card in play.\n\nBUILD FENCE (2 wood)\nPlace up to 2 fence stickers (12R). Then, if a house is completely surrounded by fences, discard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 3 wood or place 1 upset sticker near a resident that isn't already upset. Regardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "「我的房子太漏风了！」你的邻居抱怨道，「而且一点隐私都没有！这可不是我梦想中的家。」",
			panel: "将此牌留在场上。\n\n建造围栏（2 木材）\n放置至多 2 枚围栏贴纸 12R。然后，若有一栋房子被围栏完全围住，弃掉此牌并获得 1 点心情。\n\n岁末\n选择花费 3 份木材，或在一名尚未不满的居民附近放置 1 枚不满贴纸。无论如何，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y9-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "What do a basket, a shovel, and a pickaxe all have in common? Who cares. Get to work.",
			panel: "Either A plant flowers, or B spend 2 food to mine ore.\nRead the matching effect, then discard this.",
			options: {
				a: "Place 1 flower sticker (11A).",
				b: "Gain 1 ore."
			}
		},
		zh: {
			flavor: "篮子、铲子和镐有什么共同点？谁在乎。干活吧。",
			panel: "选择 A 种植花朵，或选择 B 花费 2 份食物开采矿石。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "放置 1 枚花朵贴纸 11A。",
				b: "获得 1 份矿石。"
			}
		},
		uncertain: []
	},
	"y9-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the wolf pup, read option A, otherwise read B.",
			options: {
				a: "A burglar breaks into your house, but luckily Patch chases him off. When Patch returns, he's carrying a few gifts in his mouth: a small coin purse and a torn piece of heart-patterned boxers.\n\nDiscard this and gain 1 gold.",
				b: "While hiking through the woods, you see a pack of wolves howling in the distance. Their one-eyed alpha looks familiar, and you smile knowing you made the right decision.\n\nDiscard this and gain 1 happiness."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有狼崽，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "窃贼闯进你家，幸好帕奇把他赶走了。帕奇回来时，嘴里叼着几样礼物：一个小钱袋和一片心形图案拳击短裤的破布。\n\n弃掉此牌并获得 1 金币。",
				b: "你在林中徒步时，看见远处一群狼在嗥叫。那头独眼的狼王看起来很眼熟，你微笑着，知道自己做了正确的决定。\n\n弃掉此牌并获得 1 点心情。"
			}
		},
		uncertain: []
	},
	"y9-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Torrential rain sweeps through your village, flooding the river and washing away part of your meticulously-placed road.",
			panel: "Either A ignore it, B spend the entire day repairing the road, or C spend 1 gold to hire someone else to repair it.\nRead the matching effect, then discard this.",
			options: {
				a: "Place sticker 8Y over 1 road (it is no longer considered a road).",
				b: "You fix the road, but it takes all day. Skip your action this turn.",
				c: "They do a great job, and the road soon looks back to normal. No effect."
			}
		},
		zh: {
			flavor: "暴雨席卷你的村庄，河水泛滥，冲走了你精心铺设的一段道路。",
			panel: "选择 A 不予理会，选择 B 花一整天修路，或选择 C 花费 1 金币雇别人来修。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "在 1 条道路上覆盖放置贴纸 8Y（它不再被视为道路）。",
				b: "你修好了道路，但这花了一整天。本回合跳过你的行动。",
				c: "他们干得很出色，道路很快恢复如初。没有效果。"
			}
		},
		uncertain: []
	},
	"y9-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Library and/or School, read option A, otherwise read B.",
			options: {
				a: "A local girl named Veronica has written a novel called Teenage Werewolf Warriors. It quickly becomes an international bestseller.\n\nDiscard this and gain 1 happiness.",
				b: "The plants are dying and no one can figure out why.\n\nDiscard this and place 1 dead bush sticker 1G, covering a berry bush and food icon, if able."
			}
		},
		zh: {
			flavor: null,
			panel: "若你有图书馆和／或学校，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "本地一个名叫维罗妮卡的女孩写了一本小说，名叫《少年狼人战士》。它迅速成为国际畅销书。\n\n弃掉此牌并获得 1 点心情。",
				b: "植物不断枯萎，谁也弄不明白原因。\n\n弃掉此牌并放置 1 枚枯灌木贴纸 1G，若可能，覆盖 1 丛浆果灌木和食物图标。"
			}
		},
		uncertain: []
	},
	"y9-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Unrest milestone, read option A, otherwise read B.",
			options: {
				a: "One of the residents chews you out in public, right in front of all your friends. How embarrassing!\n\nDiscard this and place 1 upset sticker on the map near a resident that isn't already upset.",
				b: "Friendship requires effort, so you make plans to visit a friend in town.\n\nDiscard this and perform any action on the map. (Then perform another action as normal.)"
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有动乱里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "一名居民当众把你数落了一顿，就在你所有朋友面前。真是丢脸！\n\n弃掉此牌，并在地图上一位尚未不满的居民附近放置 1 枚不满贴纸。",
				b: "友谊需要经营，于是你打算去镇上拜访一位朋友。\n\n弃掉此牌，并在地图上执行任意一次行动。（然后照常再进行一次行动。）"
			}
		},
		uncertain: []
	},
	"y9-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Wild Bill resident, read option A, otherwise read B.",
			options: {
				a: "Wild Bill looks like he's got something to say, but he's avoiding your eyes.\n\nRoll the die. Read the matching effect, then discard this:\n1-3: Read 24.10.\n4-6: Read 16.9.",
				b: "Wild Bill returns, offering to work for a hot meal.\n\nYou may spend 1 food to place 1 road sticker 3E or 1 flower sticker 11A.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你有野比尔这位居民，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "野比尔看起来有话要说，却一直避开你的目光。\n\n掷骰。阅读对应的效果，然后弃掉此牌：\n1-3：阅读故事 24.10。\n4-6：阅读故事 16.9。",
				b: "野比尔回来了，提出用干活换一顿热饭。\n\n你可以花费 1 份食物，放置 1 枚道路贴纸 3E或 1 枚花朵贴纸 11A。\n无论如何，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y9-09": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You never dreamed that a celebrity like Pierre Dubois would ever decide to vacation in your village. Unfortunately, he is hard to please.",
			panel: "Keep this card in play.\n\nIMPRESS OUR GUEST (3 food, 1 gold)\nDiscard this and gain 1 happiness.\n\nEND OF THE YEAR\nEither spend 3 gold or read 24.6. Regardless, then discard this.",
			options: {}
		},
		zh: {
			flavor: "你从没想过像皮埃尔·杜布瓦这样的名人会决定来你的村庄度假。可惜，他很难伺候。",
			panel: "将此牌留在场上。\n\n招待贵客（3 食物、1 金币）\n弃掉此牌并获得 1 点心情。\n\n岁末\n选择花费 3 金币，或阅读故事 24.6。无论如何，然后弃掉此牌。",
			options: {}
		},
		uncertain: []
	},
	"y9-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "It's time you gave this village an official name. Something catchy like “Sneezeville.” Just not as weird. Or more weird? Either way, you can do better!",
			panel: "Keep this card in play.\n\nBUILD TOWN SIGN (1 wood, 1 gold, 1 ore)\nDiscard this and read 26.9.",
			options: {}
		},
		zh: {
			flavor: "是时候给这座村庄起个正式的名字了。要像「喷嚏镇」那样朗朗上口。只是别那么古怪。或者更古怪？不管怎样，你肯定能想出更好的！",
			panel: "将此牌留在场上。\n\n建造镇招牌（1 木材、1 金币、1 矿石）\n弃掉此牌并阅读故事 26.9。",
			options: {}
		},
		uncertain: []
	},
	"y9-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nBUILD SCULPTURE GARDEN (2 gold)\nDiscard this and place sticker 8C. Then gain 1 happiness.\n\nBUILD STATUE IN YOUR LIKENESS (2 gold, 2 ore)\nDiscard this and place sticker 8S. Then gain the Immortalized milestone (silver).",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n建造雕塑花园（2 金币）\n弃掉此牌并放置贴纸 8C。然后获得 1 点心情。\n\n建造自雕像（2 金币、2 矿石）\n弃掉此牌并放置贴纸 8S。然后获得名垂青史里程碑（银）。",
			options: {}
		},
		uncertain: []
	},
	"y9-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: "Connecting your village to the rail network is the perfect way to transport goods and visit far-off lands!",
			panel: "Keep this card in play.\n\nBUILD TRAIN STATION (3 wood, 1 gold, 2 ore)\nDiscard this and place sticker 5E.",
			options: {}
		},
		zh: {
			flavor: "把你的村庄接入铁路网，是运输货物和前往远方旅行的绝佳方式！",
			panel: "将此牌留在场上。\n\n建造火车站（3 木材、1 金币、2 矿石）\n弃掉此牌并放置贴纸 5E。",
			options: {}
		},
		uncertain: []
	},
	"y10-01": {
		kind: "choice",
		title: null,
		en: {
			flavor: "“These trees are a waste of space,” Father says. “You should cut them down so you can use the land.”",
			panel: "Either A clear-cut the forest, or B refuse.\nRead the matching effect, then discard this.",
			options: {
				a: "Gain 3 wood. Then place sticker 6K, completely covering a sticker with exactly 3 trees, if able.",
				b: "Place 1 wild animal sticker 12H."
			}
		},
		zh: {
			flavor: "「这些树纯属浪费地方，」父亲说。「你该把它们砍了，好把这片地利用起来。」",
			panel: "选择 A 把森林全部砍光，或选择 B 拒绝。\n阅读对应的效果，然后弃掉此牌。",
			options: {
				a: "获得 3 份木材。然后若可以，放置贴纸 6K，完整覆盖一张恰好画有 3 棵树的贴纸。",
				b: "放置 1 枚野生动物贴纸 12H。"
			}
		},
		uncertain: []
	},
	"y10-02": {
		kind: "keep",
		title: null,
		en: {
			flavor: "“Finish building that road,” Father says. “It will be crucial for the flow of goods and services!”",
			panel: "Keep this card in play.\n\nROAD CONSTRUCTION\nDiscard this and spend 0 to 8 gold. For every 2 gold spent, place 1 road sticker 3E. They may even cover other stickers (if covering completely).",
			options: {}
		},
		zh: {
			flavor: "「把那条路修完，」父亲说。「它对货物和服务的流通至关重要！」",
			panel: "将此牌留在场上。\n\n修建道路\n弃掉此牌并花费 0 至 8 金币。每花费 2 金币，放置 1 枚道路贴纸 3E。这些贴纸甚至可以覆盖其他贴纸（前提是完全覆盖）。",
			options: {}
		},
		uncertain: []
	},
	"y10-03": {
		kind: "choice",
		title: null,
		en: {
			flavor: "Time is slipping through your fingers like a greased-up watermelon. Should you cling tightly or let go and see what happens?",
			panel: "Choose a card in play. Either perform an action on it with a discount of 1 resource or discard the card to perform 1 additional action this turn.\n\nRegardless, then discard this (and perform an action as normal).",
			options: {}
		},
		zh: {
			flavor: "时间正从你指缝间溜走，像一颗抹了油的西瓜。你该紧紧抓住，还是放手看看会发生什么？",
			panel: "选择场上的一张牌。对该牌执行行动时少付 1 份资源，或弃掉该牌，在本回合额外行动一次。\n\n无论哪种，然后弃掉此牌（并照常执行一次行动）。",
			options: {}
		},
		uncertain: []
	},
	"y10-04": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have 2 or more red milestones, read option A, otherwise read B.",
			options: {
				a: "“Your failures unfortunately do not surprise me,” Father says.\n\nEither lose 1 happiness or cover a ★ icon on a milestone with an upset sticker (it no longer counts as a ★).\nRegardless, then discard this.",
				b: "Your local nickname is “Old Reliable.”\n\nEither gain 1 happiness or perform 1 additional action this turn.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有 2 个或更多红色里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "「你的失败，很遗憾，一点也不让我意外。」父亲说。\n\n选择失去 1 心情，或用 1 枚不满贴纸覆盖某个里程碑上的 ★ 图标（该图标不再计为 ★）。\n无论哪种，然后弃掉此牌。",
				b: "你在本地得了个绰号：「老可靠」。\n\n选择获得 1 心情，或在本回合额外行动一次。\n无论哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y10-05": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you do not have the Pro Angler milestone, read option A, otherwise read B.",
			options: {
				a: "You're determined to get that big catch.\n\nIf you have card 12A or 12B, perform the “Go Fishing” action on it.\nDuring this action, you may spend 1 food to reroll your die (do this as many times as you wish).\nRegardless, then discard this (and perform another action as normal).",
				b: "Everyone remembers the time you caught a 15 pound catfish. It's impossible to forget, given how much you talk about it.\n\nDiscard this and gain 1 happiness."
			}
		},
		zh: {
			flavor: null,
			panel: "若你没有「钓鱼高手」里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你下定决心要钓上那条大鱼。\n\n若你拥有图鉴牌 12A 或 12B，对其中一张执行「钓鱼」行动。\n在此行动中，你可以花费 1 份食物重掷骰子（可重复任意次）。\n无论哪种，然后弃掉此牌（并照常执行一次行动）。",
				b: "所有人都记得你钓上那条 15 磅鲶鱼的那一次。鉴于你逢人便说，想忘也忘不掉。\n\n弃掉此牌并获得 1 心情。"
			}
		},
		uncertain: []
	},
	"y10-06": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If there is an upset resident, read option A, otherwise read B.",
			options: {
				a: "Your neighbor is still mad at you, but maybe a giant cake will fix things?\n\nEither lose 1 happiness or spend 2 food to cover an upset sticker on the map with sticker 12G.\nRegardless, then discard this.",
				b: "“My best friend heard about this village and now they're coming to live with me,” your neighbor tells you.\n\nDiscard this and place sticker 11M on any building that has a resident. Do not use a sticker matching a resident already on the map."
			}
		},
		zh: {
			flavor: null,
			panel: "若有不满的居民，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你的邻居还在生你的气，不过也许一个巨型蛋糕能弥补一切？\n\n选择失去 1 心情，或花费 2 份食物，用贴纸 12G覆盖地图上的一枚不满贴纸。\n无论哪种，然后弃掉此牌。",
				b: "「我最好的朋友听说了这个村子，现在就要搬来和我一起住了。」你的邻居告诉你。\n\n弃掉此牌，并在任意有居民的建筑上放置贴纸 11M。不要使用与地图上已有居民相同的贴纸。"
			}
		},
		uncertain: []
	},
	"y10-07": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have a “Farming” milestone, read option A, otherwise read B.",
			options: {
				a: "A local farm is looking to sell some of their animals.\n\nDiscard this and spend 0 to 3 gold. For each gold spent, place 1 farm animal sticker 11B.",
				b: "You had political ambitions, but did you make friends along the way?\n\nIf you have the President milestone, gain 1 happiness. Otherwise, gain 1 gold.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有「农业」里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "本地一家农场打算卖掉一些牲畜。\n\n弃掉此牌并花费 0 至 3 金币。每花费 1 金币，放置 1 枚农场动物贴纸 11B。",
				b: "你曾有过政治抱负，可这一路上你交到朋友了吗？\n\n若你拥有「总统」里程碑，获得 1 心情；否则获得 1 金币。\n无论哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y10-08": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you do not have any trash or polluted factories, read option A, otherwise read B.",
			options: {
				a: "You've taken care of this land, and nature is blooming.\n\nDiscard this and spend 0 to 2 food. For each food spent, place 1 flower sticker 11A.",
				b: "Progress requires sacrifice.\n\nYou may lose 1 happiness. If you do, gain 1 resource of your choice and perform 1 additional action this turn.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你没有任何垃圾工厂或污染工厂，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "你悉心照料这片土地，大自然正焕发生机。\n\n弃掉此牌并花费 0 至 2 份食物。每花费 1 份食物，放置 1 枚花朵贴纸 11A。",
				b: "进步需要牺牲。\n\n你可以失去 1 心情。若如此做，获得 1 份自选资源，并在本回合额外行动一次。\n无论哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y10-09": {
		kind: "choice",
		title: null,
		en: {
			flavor: null,
			panel: "If you have the Hot Goods milestone, read option A, otherwise read B.",
			options: {
				a: "“We've received reports of stolen ore in the area,” the constable says. “Would you happen to know anything about that?”\n\nYou may spend 2 gold or 1 ore to remove the Hot Goods milestone.\nRegardless, then discard this.",
				b: "You pass Father on the road during your morning run. “You're up early,” he remarks. “Color me impressed.”\n\nYou may spend 2 food to perform 1 additional action this turn.\nRegardless, then discard this."
			}
		},
		zh: {
			flavor: null,
			panel: "若你拥有「赃物」里程碑，阅读选项 A；否则阅读选项 B。",
			options: {
				a: "「我们接到报案，说这一带有失窃的矿石。」治安官说。「你碰巧知道些什么吗？」\n\n你可以花费 2 金币或 1 份矿石，移除「赃物」里程碑。\n无论哪种，然后弃掉此牌。",
				b: "晨跑时，你在路上遇见了父亲。「你今天起得早，」他说，「我可真对你刮目相看。」\n\n你可以花费 2 份食物，在本回合额外行动一次。\n无论哪种，然后弃掉此牌。"
			}
		},
		uncertain: []
	},
	"y10-10": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You've never seen Father this excited before. “The railroad will change everything!”",
			panel: "Keep this card in play.\n\nESTABLISH TRADE ROUTE (2 ore)\nIf you have the Train Station, discard this, gain 3 gold, and gain the Ore Tycoon milestone (silver).",
			options: {}
		},
		zh: {
			flavor: "你从没见过父亲这么兴奋。「铁路会改变一切！」",
			panel: "将此牌留在场上。\n\n建立贸易路线（2 矿石）\n若你拥有火车站，弃掉此牌，获得 3 金币，并获得「矿石大亨」里程碑（银）。",
			options: {}
		},
		uncertain: []
	},
	"y10-11": {
		kind: "keep",
		title: null,
		en: {
			flavor: null,
			panel: "Keep this card in play.\n\nPLANT TREE (3 gold)\nDiscard this and place sticker 8X.\n\nRENOVATE NEIGHBOR'S HOME (3 wood, 1 gold)\nDiscard this and place sticker 10N, covering any house with a grass background. Then either gain 1 happiness or remove 1 upset sticker from a resident on that house sticker.",
			options: {}
		},
		zh: {
			flavor: null,
			panel: "将此牌留在场上。\n\n植树（3 金币）\n弃掉此牌并放置贴纸 8X。\n\n翻修邻居的房屋（3 木材、1 金币）\n弃掉此牌并放置贴纸 10N，覆盖任意带草地背景的房屋。然后选择获得 1 心情，或移除该房屋贴纸上某位居民的 1 枚不满贴纸。",
			options: {}
		},
		uncertain: []
	},
	"y10-12": {
		kind: "keep",
		title: null,
		en: {
			flavor: "You've turned this wilderness into a home, and you never plan to leave. But what kind of village did you create?",
			panel: "You may spend 2 food to perform 1 additional action this turn.\nRegardless, keep this card in play.\n\nEND OF THE YEAR\nRead 31.1.\nThis effect will vary based on the goals you've accomplished on card 42.",
			options: {}
		},
		zh: {
			flavor: "你已经把这片荒野变成了家园，并且永远不打算离开。可你究竟建成了一个什么样的村子？",
			panel: "你可以花费 2 份食物，在本回合额外行动一次。\n无论是否花费，将此牌留在场上。\n\n岁末\n阅读 31.1。\n此效果将根据你在图鉴牌 42 上完成的目标而有所不同。",
			options: {}
		},
		uncertain: []
	}
}, or = {
	1: { blocks: [{
		type: "setup",
		heading: {
			en: "YEAR 1 SETUP",
			zh: "第 1 年岁初设置"
		},
		en: { text: "Reminder: Place starting stickers on the map (see page 1 of the rulebook). Then read the following:\n\nShortly after arriving at your new home, you decide to re-read Father's letter.\n\nYou have lived off my fortune for far too long, and you have grown soft. Well, no more! It is time for you to learn the value of hard work.\n\nI am granting you a tract of land just south of Cheshire. It is empty and undeveloped, but with a little effort, you might just build something worthy of the family name.\n\nI expect that you will squander this opportunity, but it is my final handout.\n— Father\n\nYou smile and roll your eyes; he does have a flair for the dramatic. You put the letter in your pocket and look upon a field of possibility.\n\n1. Gain 2 happiness (place 2 heart stickers from page 1 of the sticker book on the happiness track).\n2. Gain starting resources as follows: Gain 1 wood token for each wood icon on the map and 1 food token for each food icon on the map. (Resources are shared among all players.)\n3. Shuffle the year 1 event deck (the 12 event cards with a \"1\" on the back). Then choose a player to take the first turn." },
		zh: { text: "提醒：把起始贴纸放到地图上（见规则书第 1 页），然后阅读以下内容：\n\n搬进新家后不久，你决定重读一遍父亲的来信。\n\n你靠我的家产过活已经太久了，人也变得软弱。好了，到此为止！是时候让你明白辛勤劳作的价值了。\n\n我赐给你柴郡以南的一块土地。那里一片荒芜、尚未开发，但只要付出一点努力，你或许就能建起配得上家族名号的东西。\n\n我料想你会浪费这个机会，但这是我最后一次施舍。\n——父亲\n\n你笑了笑，翻了个白眼；他说话确实爱添几分戏剧性。你把信收进口袋，望向眼前这片充满可能的土地。\n\n1. 获得 2 点心情（从贴纸册第 1 页取 2 枚爱心贴纸，放在心情轨上）。\n2. 按以下方式获得起始资源：地图上的每个木材图标提供 1 个木材标记，地图上的每个食物图标提供 1 个食物标记。（资源由所有玩家共享。）\n3. 洗混第 1 年事件牌堆（背面印有「1」的 12 张事件牌），然后选择一名玩家进行第一个回合。" }
	}, {
		type: "note",
		en: { text: "For example, this sticker provides 1 wood at the start of each year." },
		zh: { text: "例如，这枚贴纸在每年岁初提供 1 份木材。" }
	}] },
	2: { blocks: [
		{
			type: "setup",
			heading: {
				en: "YEAR 2 SETUP",
				zh: "第 2 年岁初设置"
			},
			en: { text: "Reminder: Resolve \"End of Year\" effects on cards in play (for the end of year 1, if you haven't yet).\n\nNow that you're settling in, you start to think about the future. What are your dreams? Your aspirations? You decide to create a list of potential long-term goals.\n\n1. Gain card 42. This lists some goals to work towards over the next 9 years. You won't be able to accomplish all of them, but they can offer some guidance.\n2. Gain 1 gold for each gold icon on milestones. Then gain starting resources (1 wood for each wood icon on the map, 1 food for each food icon on the map).\n3. Shuffle the year 2 event deck, then choose a player to take the first turn." },
			zh: { text: "提醒：结算场上卡牌的「岁末」效果（如果尚未结算第 1 年的岁末效果，现在结算）。\n\n安顿下来之后，你开始思考未来。你的梦想是什么？你的抱负是什么？你决定列出一些可能实现的长期目标。\n\n1. 获得图鉴牌 42。上面列出了未来 9 年可以努力实现的若干目标。你无法全部完成，但它们能提供一些指引。\n2. 里程碑上的每个金币图标提供 1 枚金币。然后获得起始资源（地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n3. 洗混第 2 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		},
		{
			type: "setup",
			heading: {
				en: "YEAR 3 SETUP",
				zh: "第 3 年岁初设置"
			},
			en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if you have the Hunger milestone, read option A, otherwise read option B.\n\nOption A: Your neighbors are starving and beginning to regret moving here.\n1. Lose 1 happiness.\n2. Shuffle the year 3 event deck, then choose a player to take the first turn.\n\nOption B: You receive a letter in the mail from Mother.\n\nI hope you are staying happy and healthy out there in the wilderness. Your Father speaks of you often, not always kindly, but please know he does care. From what I hear, your town is missing purpose. Please use this gift to help build something special. I know you will make us proud.\n— With Love, Mother\n\n1. Gain 1 gold.\n2. Shuffle the year 3 event deck, then choose a player to take the first turn." },
			zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果你拥有「饥饿」里程碑，阅读选项 A，否则阅读选项 B。\n\n选项 A：你的邻居们正在挨饿，开始后悔搬到这里。\n1. 失去 1 点心情。\n2. 洗混第 3 年事件牌堆，然后选择一名玩家进行第一个回合。\n\n选项 B：你收到一封母亲寄来的信。\n\n希望你在荒野中过得快乐健康。你父亲常常提起你，虽然未必总是好话，但请相信他确实关心你。据我所知，你的小镇缺少目标。请用这份礼物去建造一些特别的东西。我知道你会让我们骄傲的。\n——爱你的母亲\n\n1. 获得 1 枚金币。\n2. 洗混第 3 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		},
		{
			type: "setup",
			heading: {
				en: "YEAR 4 SETUP",
				zh: "第 4 年岁初设置"
			},
			en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if 6.4 is visible on your map (on the Chasm), read option A, otherwise read option B (on page 3).\n\nOption A: A swarm of bats has made their home in the chasm. You wouldn't mind these furry friends if they didn't like your berries so much.\n1. Cover 6.4 on the map with sticker 7N.\n2. Lose 2 food.\n3. Shuffle the year 4 event deck, then choose a player to take the first turn." },
			zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果地图上可见 6.4 标记（位于裂隙上），阅读选项 A，否则阅读选项 B（见第 3 页）。\n\n选项 A：一群蝙蝠在裂隙里安了家。要不是这些毛茸茸的朋友这么爱吃你的浆果，你本来不会介意它们。\n1. 用贴纸 7N 覆盖地图上的 6.4 标记。\n2. 失去 2 份食物。\n3. 洗混第 4 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		}
	] },
	3: { blocks: [
		{
			type: "setup",
			heading: {
				en: "YEAR 4 CONTINUED",
				zh: "第 4 年（续）"
			},
			en: { text: "Option B: You have an unexpected bumper crop, with your plants providing far more food than normal. Sometimes, you're just lucky!\n1. Gain 1 food.\n2. Shuffle the year 4 event deck, then choose a player to take the first turn." },
			zh: { text: "选项 B：你的作物意外丰收，产量远超平常。有时候，你就是运气好！\n1. 获得 1 份食物。\n2. 洗混第 4 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		},
		{
			type: "setup",
			heading: {
				en: "YEAR 5 SETUP",
				zh: "第 5 年岁初设置"
			},
			en: { text: "\"Surprise!\" Your sister Jessie stands in your doorway, a goofy smile on her face. \"Let's make up a fake holiday and have a party, just like old times!\"\n\nYou know her well enough to see that something is wrong, so you probe deeper.\n\n\"Daddy kicked me out!\" she wails. \"But unlike you, he didn't give me a free place to live. Can I PLEEEAASE live here? Just for a bit?\"\n\nYou can't turn away your own sister. Unlike Father, you've got a heart.\n\n1. Place sticker 5C (do not cover another sticker). If it is not available, instead place sticker 5D.\n2. Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n3. Shuffle the year 5 event deck, then choose a player to take the first turn." },
			zh: { text: "「惊喜！」你的妹妹杰西站在门口，脸上挂着傻乎乎的笑容。「我们来编个假节日，办一场派对，就像从前那样！」\n\n你太了解她了，一眼就看出有什么事不对劲，于是追问下去。\n\n「爸爸把我赶出来了！」她哭喊道。「可不像你，他没给我一个免费住的地方。我求求你了，我能住在这里吗？就住一小段时间？」\n\n你没法把自己的妹妹拒之门外。你和父亲不一样，你是有良心的。\n\n1. 放置贴纸 5C（不要覆盖其他贴纸）。如果无法放置，则改为放置贴纸 5D。\n2. 获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n3. 洗混第 5 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		},
		{
			type: "setup",
			heading: {
				en: "YEAR 6 SETUP",
				zh: "第 6 年岁初设置"
			},
			en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if you have built the Lodge, read option A, otherwise read option B.\n\nOption A: \"Ah yes, you're probably wondering how that Crypt got here. We built it last week as a place to honor the dead, and definitely not for some nefarious reason. I hope you don't mind.\"\n1. Place sticker 4T.\n2. Shuffle the year 6 event deck, then choose a player to take the first turn.\n\nOption B: Your contact at the historical society mails you a surprise find: an old letter written by Beatrice Cobblepot, fabled last owner of the Cobblepot Fortune. This is the clue you were missing; this is the crucial piece!\n1. Gain card 22.\n2. Shuffle the year 6 event deck, then choose a player to take the first turn." },
			zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果你已经建造了小屋，阅读选项 A，否则阅读选项 B。\n\n选项 A：「啊，对了，你大概想知道那座墓穴是怎么来的。我们上周把它建好了，用来安葬逝者，绝对不是为了什么见不得人的目的。希望你不要介意。」\n1. 放置贴纸 4T。\n2. 洗混第 6 年事件牌堆，然后选择一名玩家进行第一个回合。\n\n选项 B：你在历史学会的联络人寄来一件意外的发现：一封比阿特丽斯·科布尔波特写的旧信。她据说是科布尔波特宝藏的最后一位主人。这正是你一直缺少的线索，是关键的一块拼图！\n1. 获得图鉴牌 22。\n2. 洗混第 6 年事件牌堆，然后选择一名玩家进行第一个回合。" }
		}
	] },
	4: { blocks: [{
		type: "setup",
		heading: {
			en: "YEAR 7 SETUP",
			zh: "第 7 年岁初设置"
		},
		en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if you have the Degenerate or Upstanding milestone, read option A, otherwise read option B.\n\nOption A: \"This may sound crazy,\" Jessie says, \"but I like living here.\"\nYou wait for the sarcastic follow-up, but it doesn't come. Instead, she hands you a strange metallic rock with a face drawn on it. \"Here, I want you to have Mr. Magnet-Head.\"\n1. Gain 1 ore.\n2. Shuffle the year 7 event deck, then choose a player to take the first turn.\n\nOption B: You receive another letter from Father.\n\nI hear that you've let your sister live with you. Good luck with that freeloader.\n\nYour Mother tells me bits and pieces about your thriving village, and if true, I am pleasantly surprised. Maybe you are finally turning your life around. This may be too much to ask, but perhaps you can reform your sister as well?\n\nKeep at it, and perhaps I will grace your small village with a visit.\n\n1. Perform the action on Jessie's sticker (18.2 or 22.3). Make all decisions for this action as a group.\n2. Shuffle the year 7 event deck, then choose a player to take the first turn." },
		zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果你拥有「堕落者」或「正直者」里程碑，阅读选项 A，否则阅读选项 B。\n\n选项 A：「这话听起来可能很疯狂，」杰西说，「但我喜欢住在这里。」\n你等着她照例补上一句挖苦，可这次没有。她反而递给你一块奇怪的金属石头，上面画着一张脸。「给，我想把磁铁头先生送给你。」\n1. 获得 1 份矿石。\n2. 洗混第 7 年事件牌堆，然后选择一名玩家进行第一个回合。\n\n选项 B：你又收到一封父亲的来信。\n\n我听说你让妹妹住进了你家。祝你和那个白吃白喝的人相处愉快。\n\n你母亲零零碎碎地跟我提起你那个蒸蒸日上的村庄。如果属实，我倒有些惊喜。也许你终于要走上正轨了。这也许要求太高，但或许你也能把妹妹引上正道？\n\n坚持下去，说不定我会赏脸去你的小村庄看看。\n\n1. 执行杰西贴纸（18.2 或 22.3）上的行动。此行动的所有决定由全体玩家共同作出。\n2. 洗混第 7 年事件牌堆，然后选择一名玩家进行第一个回合。" }
	}, {
		type: "setup",
		heading: {
			en: "YEAR 8 SETUP",
			zh: "第 8 年岁初设置"
		},
		en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if you have the Lucky milestone, read option A, otherwise read option B.\n\nOption A: A gardener with dirt-covered overalls stands proudly on your doorstep. \"Your Father sent me to help beautify your village,\" the man says as he adjusts a sun hat, \"and it looks like you need it.\"\n1. Either place 1 flower sticker 11A or spend 1 gold to place 1 road sticker 3E.\n2. Shuffle the year 8 event deck, then choose a player to take the first turn.\n\nOption B: While exploring the mountainside, you accidentally set off a landslide. Hopefully no one was buried underneath!\n1. Place sticker 10E so that at least part of it is next to (shares an edge with) a cliff-side. You must cover another sticker, if possible (but only if it completely covers it).\n2. Shuffle the year 8 event deck, then choose a player to take the first turn." },
		zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果你拥有「幸运儿」里程碑，阅读选项 A，否则阅读选项 B。\n\n选项 A：一个穿着沾满泥土的背带裤的园丁自豪地站在你家门口。「你父亲派我来帮忙美化你的村庄，」他一边扶正遮阳帽一边说，「看样子你确实需要。」\n1. 放置 1 枚花朵贴纸 11A，或花费 1 枚金币放置 1 枚道路贴纸 3E。\n2. 洗混第 8 年事件牌堆，然后选择一名玩家进行第一个回合。\n\n选项 B：你在山腰探险时，不小心引发了一场山体滑坡。但愿没有人被埋在下面！\n1. 放置贴纸 10E，使它至少有一部分紧邻崖边（与崖边共边）。如果可能，你必须覆盖另一枚贴纸（但仅当能够将其完全覆盖时）。\n2. 洗混第 8 年事件牌堆，然后选择一名玩家进行第一个回合。" }
	}] },
	5: { blocks: [{
		type: "setup",
		heading: {
			en: "YEAR 9 SETUP",
			zh: "第 9 年岁初设置"
		},
		en: { text: "Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n\nThen, if you have built the Observatory, read option A, otherwise read option B.\n\nOption A: Your warning about the asteroid wins you an award and recognition within the astronomical community. Luckily, it barely misses the Earth.\n1. Gain 2 gold.\n2. Shuffle the year 9 event deck, then choose a player to take the first turn.\n\nOption B: A meteor streaks through the sky and explodes on the mountainside! That's gonna leave a mark.\n1. Place sticker 7E.\n2. If the \"Build Observatory\" event card (Y6-12) is in play, discard it.\n3. Shuffle the year 9 event deck, then choose a player to take the first turn." },
		zh: { text: "获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n\n然后，如果你已经建造了天文台，阅读选项 A，否则阅读选项 B。\n\n选项 A：你对小行星的预警为你赢得了天文学界的奖项与认可。幸运的是，它与地球擦肩而过。\n1. 获得 2 枚金币。\n2. 洗混第 9 年事件牌堆，然后选择一名玩家进行第一个回合。\n\n选项 B：一颗流星划过天空，在山腰上炸开！这下可要留下一个大坑了。\n1. 放置贴纸 7E。\n2. 如果场上存在「建造天文台」事件牌（Y6-12），弃掉它。\n3. 洗混第 9 年事件牌堆，然后选择一名玩家进行第一个回合。" }
	}, {
		type: "setup",
		heading: {
			en: "YEAR 10 SETUP",
			zh: "第 10 年岁初设置"
		},
		en: { text: "When Father shows up on your doorstep (with his butler, no less), you feel like a child caught stealing cookies. He stares you down from head to toe, and you fight for composure.\n\n\"Not bad,\" Father says at last, looking around. You're ashamed to admit that his words feel good. \"I want to learn more about your village and your so-called accomplishments.\"\n\nYou offer him a room in your house.\n\n\"Lord no! My country estate is nearby, so I'll just stop by periodically and poke around. See you again soon.\"\n\nYou smile and shake your head as he leaves. Do you really care about his opinion?\n\n1. Gain starting resources (1 gold for each gold icon on milestones, 1 wood for each wood icon on the map, 1 food for each food icon on the map).\n2. Shuffle the year 10 event deck, then choose a player to take the first turn." },
		zh: { text: "父亲出现在你家门口时（竟然还带着他的管家），你感觉自己像个偷吃饼干被抓住的孩子。他从头到脚打量着你，你努力保持镇定。\n\n「还不错，」父亲最后环视一圈说道。你羞愧地承认，他的话让你感觉不错。「我想多了解你的村庄，还有你那些所谓的成就。」\n\n你提出在家里给他安排一个房间。\n\n「老天，不行！我的乡间庄园就在附近，我会时不时过来转转。回头见。」\n\n他离开时，你笑着摇了摇头。你真的在乎他的看法吗？\n\n1. 获得起始资源（里程碑上的每个金币图标提供 1 枚金币，地图上的每个木材图标提供 1 份木材，地图上的每个食物图标提供 1 份食物）。\n2. 洗混第 10 年事件牌堆，然后选择一名玩家进行第一个回合。" }
	}] },
	6: { blocks: [
		{
			type: "entry",
			id: "6.1",
			en: {
				text: "If you are reading this, you are either in the wrong place or cheating.",
				choices: []
			},
			zh: {
				text: "如果你正在读这段文字，那么你要么翻错了地方，要么在作弊。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "6.2",
			en: {
				text: "You're desperate for wood, but want to pace yourself. Either A gather branches, or B chop down a tree.",
				choices: [{
					key: "a",
					text: "You work quickly and get home with plenty of daylight left. Gain 1 wood. Then perform another action."
				}, {
					key: "b",
					text: "It comes down in a crash. You then count how many trees are left in the forest. Gain 3 wood. Then place 1 heart sticker on this card (3A or 3B). If this is the 4th sticker on it, read 15.10."
				}]
			},
			zh: {
				text: "你急需木材，但又想细水长流。选择 A 捡拾树枝，或 B 砍倒一棵树。",
				choices: [{
					key: "a",
					text: "你手脚麻利，回到家时天还大亮。获得 1 份木材，然后额外行动一次。"
				}, {
					key: "b",
					text: "树轰然倒下。你随后数了数森林里还剩下多少棵树。获得 3 份木材。然后在此牌（3A 或 3B）上放置 1 枚爱心贴纸。如果这是其上的第 4 枚贴纸，阅读故事 15.10。"
				}]
			}
		},
		{
			type: "entry",
			id: "6.3",
			en: {
				text: "Your research warns you to check radiation levels before approaching. Sure enough, your Geiger counter says to stay away. You tell the authorities, and they offer to buy the meteorite! Gain 1 ore and 2 gold. Then cover 6.4 on the map with sticker 9D.",
				choices: []
			},
			zh: {
				text: "你的研究提醒你，靠近前要先检测辐射水平。果然，你的盖革计数器显示应当远离。你报告了当局，他们提出买下这颗陨石！获得 1 份矿石和 2 枚金币。然后用贴纸 9D 覆盖地图上的 6.4 标记。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "6.4",
			en: {
				text: "In the center of the smoking crater, you find a glowing meteorite. You reach down to pick it up. Cover 6.4 on the map with sticker 9D. If you have the Lucky milestone, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "It is made of a strange metal alloy. Gain 1 ore."
				}, {
					key: "b",
					text: "The glowing stone makes you feel nauseous. Lose 1 happiness."
				}]
			},
			zh: {
				text: "在冒烟的陨石坑中央，你发现了一块发光的陨石。你俯身去捡。用贴纸 9D 覆盖地图上的 6.4 标记。如果你拥有「幸运儿」里程碑，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "它由一种奇特的金属合金构成。获得 1 份矿石。"
				}, {
					key: "b",
					text: "这块发光的石头让你感到恶心。失去 1 点心情。"
				}]
			}
		},
		{
			type: "entry",
			id: "6.5",
			en: {
				text: "\"...and because of these accomplishments, you are hereby awarded the Medal of Excellence!\" The judge places the medal around your neck as the crowd cheers. It goes on and on, the whooping and clapping. You look around at all the beaming faces. They are your friends, your neighbors, your family. Even Jessie and Father look proud.\n\nTen years ago, you could never have imagined being here. Hard work and determination have turned this untamed land into the perfect village.\n\nGain the Perfect Village milestone (gold), then read 36.2.",
				choices: []
			},
			zh: {
				text: "「……鉴于这些成就，特此授予你卓越勋章！」在人群的欢呼声中，评委把勋章挂到你的脖子上。喝彩与掌声经久不息。你环顾四周一张张笑意盈盈的脸。他们是你的朋友、你的邻居、你的家人。就连杰西和父亲看上去也满脸自豪。\n\n十年前，你根本无法想象自己会站在这里。辛勤的劳作与坚定的决心，把这片蛮荒之地变成了完美的村庄。\n\n获得「完美村庄」里程碑（金色），然后阅读故事 36.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "6.6",
			en: {
				text: "Father's face is especially grumpy today. \"Why would anyone want to live in this dump? I am beyond disappointed.\"\n\nThe words hurt, but not as much as they would have ten years ago.\n\n\"You know what?\" you say. \"I don't need your approval. Is this village perfect? No, but that's ok! Perfect is for dreams, not reality. I built this village with my friends, and I'm proud of it!\"\n\n\"I disagree. You're an embarrassment to the family, and...\"\n\nYou cut him off. \"No. Look around. THIS is my family. They accept me, and that's enough.\"\n\nHe frowns, then wanders off. You don't mind; you love your new home.\n\nGain the New Family milestone (gold), then read 36.2.",
				choices: []
			},
			zh: {
				text: "父亲今天脸色格外阴沉。「怎么会有人愿意住在这样的破地方？我失望至极。」\n\n这些话很伤人，但已不像十年前那样刺痛你。\n\n「你知道吗？」你说，「我不需要你的认可。这个村庄完美吗？不完美，但那没关系！完美属于梦想，不属于现实。我和朋友们一起建起了这个村庄，我为之自豪！」\n\n「我不同意。你是家族的耻辱，而且……」\n\n你打断了他。「不。看看四周。这些才是我的家人。他们接纳我，这就足够了。」\n\n他皱起眉头，随后转身走开。你并不在意；你爱你的新家。\n\n获得「新家庭」里程碑（金色），然后阅读故事 36.2。",
				choices: []
			}
		}
	] },
	7: { blocks: [
		{
			type: "entry",
			id: "7.1",
			en: {
				text: "It would take long nights of research, but you think you could uncover the lodge's true purpose. You may spend 2 food to read 12.6. Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "这需要熬过许多个夜晚做研究，但你认为自己能够揭开小屋的真正用途。你可以花费 2 份食物阅读故事 12.6。否则，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "7.2",
			en: {
				text: "If you have no \"Lodge\" milestones, read the New Visitor story below. Otherwise, read the story below matching your lodge milestone.",
				choices: []
			},
			zh: {
				text: "如果你没有任何「小屋」里程碑，阅读下方的「新访客」故事。否则，阅读与你当前的小屋里程碑相符的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "7.3",
			en: {
				text: "NEW VISITOR:\n\n\"Ah, welcome! Do you wish to join our organization? The fee is very reasonable.\" Either A decline, or B spend 1 gold to join the lodge.",
				choices: [{
					key: "a",
					text: "\"You'll be back. They all come back.\" Perform another action."
				}, {
					key: "b",
					text: "He teaches you the secret handshake and tells you to return when you are ready to learn more about the lodge. Gain the Lodge Member milestone (bronze)."
				}]
			},
			zh: {
				text: "新访客：\n\n「啊，欢迎！你想加入我们的组织吗？会费非常合理。」选择 A 拒绝，或 B 花费 1 枚金币加入小屋。",
				choices: [{
					key: "a",
					text: "「你会回来的。他们最后都会回来。」额外行动一次。"
				}, {
					key: "b",
					text: "他教了你秘密握手礼，并让你准备好进一步了解小屋时再来。获得「小屋成员」里程碑（铜色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "7.4",
			en: {
				text: "LODGE MEMBER:\n\n\"Welcome, member!\" The lodge leader guides you through a study filled with hundreds of books of all shapes and sizes. \"We are close to unraveling the secrets of the universe, and for a low fee you can get a glimpse of it.\" Either A decline, or B spend 3 gold to buy a book.",
				choices: [{
					key: "a",
					text: "\"Come back when you're ready to expand your mind.\" Perform another action."
				}, {
					key: "b",
					text: "The tome seems to be instructions for understanding a dead language. Have you seen these symbols before? Gain card 6."
				}]
			},
			zh: {
				text: "小屋成员：\n\n「欢迎，成员！」小屋的领袖领你穿过一间书房，里面摆满了数百本大小不一、形状各异的书。「我们即将揭开宇宙的奥秘，只要付一点费用，你就能窥见一斑。」选择 A 拒绝，或 B 花费 3 枚金币买一本书。",
				choices: [{
					key: "a",
					text: "「等你准备好开阔思路时再来。」额外行动一次。"
				}, {
					key: "b",
					text: "这本厚重的书似乎是理解某种已消亡语言的说明。你以前见过这些符号吗？获得图鉴牌 6。"
				}]
			}
		},
		{
			type: "entry",
			id: "7.5",
			en: {
				text: "LODGE APPRENTICE:\n\n\"Now that you are a full-fledged apprentice, we will reveal more of our secrets to you.\" The robed man leads you to a sealed door. \"For a price, of course.\" You may spend 2 gold to gain card 31. Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "小屋学徒：\n\n「既然你已经是正式学徒，我们会向你透露更多秘密。」那个穿长袍的男人领你来到一扇封闭的门前。「当然，要付一点费用。」你可以花费 2 枚金币获得图鉴牌 31。否则，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "7.6",
			en: {
				text: "LODGE MASTER:\n\n\"Do you wish to learn the secret of our true purpose? Help us turn this lodge into a grand monument, and I will share it with you.\" Either A spend 4 gold to renovate the lodge, or B pass for now.",
				choices: [{
					key: "a",
					text: "\"Excellent! We'll start construction immediately. Now come with me to discover our deepest secret.\" Cover 7.2 on the map with sticker 8E. Then read 28.1."
				}, {
					key: "b",
					text: "\"Come back when you're ready.\" Perform another action."
				}]
			},
			zh: {
				text: "小屋大师：\n\n「你想知道我们真正目的的秘密吗？帮我们把这座小屋变成宏伟的纪念碑，我就与你分享。」选择 A 花费 4 枚金币翻修小屋，或 B 暂时作罢。",
				choices: [{
					key: "a",
					text: "「太好了！我们立刻开工。现在跟我来，去揭开我们最深的秘密。」用贴纸 8E 覆盖地图上的 7.2 标记。然后阅读故事 28.1。"
				}, {
					key: "b",
					text: "「等你准备好了再来。」额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "7.7",
			en: {
				text: "\"Yes, yes! You are beginning to unravel the secrets of the universe. It's here. It's everywhere! Come see me when you are ready to learn more.\" Discard cards 6 and 18. Then cover the Lodge Member milestone with Lodge Apprentice (silver).",
				choices: []
			},
			zh: {
				text: "「对，对！你已经开始揭开宇宙的奥秘了。它就在这里，无处不在！等你准备好了解更多时，再来找我。」弃掉图鉴牌 6 和图鉴牌 18。然后用「小屋学徒」（银色）覆盖「小屋成员」里程碑。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "7.8",
			en: {
				text: "If you chose the Jar sticker, read option A; if you chose the Bassinet sticker, read B; otherwise read C.",
				choices: [
					{
						key: "a",
						text: "\"I can finally make pickles!\" Place the Jar sticker on the map near this resident. Then cover 7.8 on card 47 with a heart sticker."
					},
					{
						key: "b",
						text: "If there is a baby (sticker 11P) on Farmer Dill, read option D, otherwise read C."
					},
					{
						key: "c",
						text: "\"I can't make pickles with this!\" Cover 7.8 on card 47 with the chosen gift sticker."
					},
					{
						key: "d",
						text: "\"Just what I need for my little pickle!\" Place the Bassinet sticker on the map near this resident. Then cover 7.8 on card 47 with a heart sticker."
					}
				]
			},
			zh: {
				text: "如果你选择了罐子贴纸，阅读选项 A；如果你选择了摇篮贴纸，阅读选项 B；否则阅读选项 C。",
				choices: [
					{
						key: "a",
						text: "「我终于可以腌酸黄瓜了！」把罐子贴纸放在地图上这位居民的附近。然后用 1 枚爱心贴纸覆盖图鉴牌 47 上的 7.8 标记。"
					},
					{
						key: "b",
						text: "如果农夫迪尔身上有婴儿（贴纸 11P），阅读选项 D，否则阅读选项 C。"
					},
					{
						key: "c",
						text: "「用这个可腌不了酸黄瓜！」用所选礼物贴纸覆盖图鉴牌 47 上的 7.8 标记。"
					},
					{
						key: "d",
						text: "「正好给我家的小酸黄瓜用！」把摇篮贴纸放在地图上这位居民的附近。然后用 1 枚爱心贴纸覆盖图鉴牌 47 上的 7.8 标记。"
					}
				]
			}
		}
	] },
	8: { blocks: [
		{
			type: "entry",
			id: "8.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "8.2",
			en: {
				text: "“I don't understand; you want us to PLANT trees? As long as we can cut them down later, I suppose…” Either A say, “Never mind, just gather some wood,” or B spend 2 food to insist that they plant a tree.",
				choices: [{
					key: "a",
					text: "Gain 2 wood and cover 8.2 on this page with a heart sticker."
				}, {
					key: "b",
					text: "Cover 8.2 on this page with a progress sticker. Then place 1 tree sticker 5N."
				}]
			},
			zh: {
				text: "「我不明白，你们要我们种树？只要以后能把这些树砍掉，我想也行……」你可以说 A「算了，随便捡些木柴就好」，或花费 2 份食物坚持让他们种一棵树。",
				choices: [{
					key: "a",
					text: "获得 2 份木材，并用爱心贴纸覆盖本页的 8.2。"
				}, {
					key: "b",
					text: "用进度贴纸覆盖本页的 8.2，然后放置 1 枚树木贴纸 5N。"
				}]
			}
		},
		{
			type: "entry",
			id: "8.3",
			en: {
				text: "“Can we pleeease chop down a tree now? Can we, can we?” Either say A “Chop away,” or B “Just gather fallen logs.”",
				choices: [{
					key: "a",
					text: "Gain 3 wood and cover 8.3 on this page with a heart sticker. Then place sticker 5Q, covering a lone tree (triangle sticker with a tree icon). If there are none, instead cover a tree icon on the map with sticker 6Z."
				}, {
					key: "b",
					text: "Gain 1 wood and cover 8.3 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「我们现在可以砍树了吗？求求你了，可以吗，可以吗？」你可以说 A「去砍吧」，或 B「捡些倒下的木头就好」。",
				choices: [{
					key: "a",
					text: "获得 3 份木材，并用爱心贴纸覆盖本页的 8.3。然后放置贴纸 5Q，覆盖一棵孤树（带树木图标的三角形贴纸）。如果没有孤树，则改为用贴纸 6Z 覆盖地图上的一个树木图标。"
				}, {
					key: "b",
					text: "获得 1 份木材，并用进度贴纸覆盖本页的 8.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "8.4",
			en: {
				text: "“Plant more trees? You do know we're lumberjacks, right?” Either A say, “Never mind, just gather some wood,” or B spend 2 gold to insist that they plant a tree.",
				choices: [{
					key: "a",
					text: "Gain 2 wood and cover 8.4 on this page with a heart sticker."
				}, {
					key: "b",
					text: "Cover 8.4 on this page with a progress sticker. Then place 1 tree sticker 5N."
				}]
			},
			zh: {
				text: "「还要种树？你总该知道我们是伐木工吧？」你可以说 A「算了，随便捡些木柴就好」，或花费 2 枚金币坚持让他们种一棵树。",
				choices: [{
					key: "a",
					text: "获得 2 份木材，并用爱心贴纸覆盖本页的 8.4。"
				}, {
					key: "b",
					text: "用进度贴纸覆盖本页的 8.4，然后放置 1 枚树木贴纸 5N。"
				}]
			}
		},
		{
			type: "entry",
			id: "8.5",
			en: {
				text: "“Let me at those trees!” Suzie Saw says as she cracks her knuckles. There's no holding her back. If there are 1 or more lone trees on the map (triangle sticker with a tree icon), read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Gain 3 wood and cover 8.5 on this page with a heart sticker. Then place sticker 5Q, covering a lone tree on the map (triangle sticker with a tree icon)."
				}, {
					key: "b",
					text: "Cover 8.5 on this page with a progress sticker. Then gain 1 wood."
				}]
			},
			zh: {
				text: "「让我去收拾那些树！」苏西·索一边把指关节掰得咔咔作响，一边说道。谁也拦不住她。如果地图上有 1 棵或更多孤树（带树木图标的三角形贴纸），阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "获得 3 份木材，并用爱心贴纸覆盖本页的 8.5。然后放置贴纸 5Q，覆盖地图上的一棵孤树（带树木图标的三角形贴纸）。"
				}, {
					key: "b",
					text: "用进度贴纸覆盖本页的 8.5，然后获得 1 份木材。"
				}]
			}
		},
		{
			type: "entry",
			id: "8.6",
			en: {
				text: "If 3 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“You've been good to us. Here, take this hatchet.” You may place sticker 1E on card 3 (A or B). If you do, cover 8.1 on the map with sticker 9C."
				}, {
					key: "b",
					text: "You may spend 2 gold to buy a hatchet (read option A). Otherwise, perform another action."
				}]
			},
			zh: {
				text: "如果本页有 3 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「你一直待我们不薄。来，这把斧头送给你。」你可以将贴纸 1E 放在图鉴牌 3（A 或 B）上。如果这样做，就用贴纸 9C 覆盖地图上的 8.1 标记。"
				}, {
					key: "b",
					text: "你可以花费 2 枚金币买一把斧头（阅读选项 A）。否则，额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "8.7",
			en: {
				text: "Read the hint below. If you solve the puzzle, do as the card instructs.\nThe dates on card 4 are out of order.\nIf you need an additional hint, spend 1 gold to read 33.6.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，就按卡牌上的指示行动。\n图鉴牌 4 上的日期顺序错乱了。\n如果你需要额外提示，花费 1 枚金币阅读故事 33.6。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "8.8",
			en: {
				text: "Now that you have running water in town, how do you want to distribute it? Cover 8.8 on the map with sticker 9C. Then either A make it free for all residents, or B charge a reasonable fee.",
				choices: [{
					key: "a",
					text: "Your residents are amazed by your generosity! They spend all day frolicking in the sprinklers. Gain 1 happiness."
				}, {
					key: "b",
					text: "The residents don't seem to mind paying for this convenience. Gain 2 gold."
				}]
			},
			zh: {
				text: "如今镇上有了自来水，你打算如何分配？用贴纸 9C 覆盖地图上的 8.8 标记。然后选择 A 让所有居民免费使用，或 B 收取合理的费用。",
				choices: [{
					key: "a",
					text: "居民们对你的慷慨惊叹不已！他们整天在洒水器旁嬉戏。获得 1 点心情。"
				}, {
					key: "b",
					text: "居民们似乎并不介意为此付费。获得 2 枚金币。"
				}]
			}
		}
	] },
	9: { blocks: [
		{
			type: "entry",
			id: "9.1",
			en: {
				text: "Who should live in this newly vacated home? Either A let Jessie move in, or B invite local musician Jordan Toots.",
				choices: [{
					key: "a",
					text: "“It's about time!” Remove the Jessie resident from the map and cover 9.1 on the map with sticker 7P."
				}, {
					key: "b",
					text: "Cover 9.1 on the map with sticker 4N. Immediately read the story on it."
				}]
			},
			zh: {
				text: "谁应该住进这栋新空出来的房子？选择 A 让杰西搬进来，或 B 邀请本地乐手乔丹·图茨。",
				choices: [{
					key: "a",
					text: "「总算到时候了！」将杰西居民从地图上移除，并用贴纸 7P 覆盖地图上的 9.1 标记。"
				}, {
					key: "b",
					text: "用贴纸 4N 覆盖地图上的 9.1 标记。随即阅读其上的故事。"
				}]
			}
		},
		{
			type: "entry",
			id: "9.2",
			en: {
				text: "This crevice is going to be a problem, isn't it? Well, the best you can do is try to make it a little safer. Either A ignore it, or B spend 1 wood to build a bridge.",
				choices: [{
					key: "a",
					text: "Perform another action."
				}, {
					key: "b",
					text: "That should prevent people from falling in. Cover 9.2 on the map with sticker 7R."
				}]
			},
			zh: {
				text: "这道裂缝迟早会是个麻烦，不是吗？你能做的，就是尽量让它安全一些。选择 A 不予理会，或 B 花费 1 份木材搭一座桥。",
				choices: [{
					key: "a",
					text: "额外行动一次。"
				}, {
					key: "b",
					text: "这样应该能防止有人掉进去了。用贴纸 7R 覆盖地图上的 9.2 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "9.3",
			en: {
				text: "Your village is thriving and your residents are quite happy with how you've been running things. You now turn your sights to the nearby towns. If you give the project enough financial support, you could become governor of the entire region! Either perform another action or spend 0 to 5 gold to roll the die. If your roll plus the amount of gold spent is 6 or higher, discard this card (card 13 or 14) and gain card 5.",
				choices: []
			},
			zh: {
				text: "你的村庄欣欣向荣，居民们对你经营小镇的方式相当满意。如今你把目光投向邻近的城镇。如果你为这项计划提供足够的资金支持，你就有可能成为整个地区的州长！选择额外行动一次，或花费 0 至 5 枚金币掷骰。如果掷骰结果加上花费的金币数为 6 或更高，弃掉此牌（图鉴牌 13 或 14），并获得图鉴牌 5。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "9.4",
			en: {
				text: "From the mountainside you spy the location of the hedge maze. It blends into the landscape with unusual camouflage, but now that you've seen it, you'll never lose it.\nDiscard card 50 and gain card 48.",
				choices: []
			},
			zh: {
				text: "你从山腰上望见了树篱迷宫的位置。它以奇特的伪装融入周围的景色，但既然你已经看到了，就再也不会找不到它。\n弃掉图鉴牌 50，并获得图鉴牌 48。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "9.5",
			en: {
				text: "Your volunteer fire department is a good start, but you should really hire a full-time firefighter. Either A wait for now, or B spend 1 gold to hire a firefighter.",
				choices: [{
					key: "a",
					text: "Perform another action."
				}, {
					key: "b",
					text: "Cover 9.5 on the map with sticker 6E."
				}]
			},
			zh: {
				text: "你的志愿消防队是个不错的开端，但你还是应该聘请一名全职消防员。选择 A 暂时等待，或 B 花费 1 枚金币聘请一名消防员。",
				choices: [{
					key: "a",
					text: "额外行动一次。"
				}, {
					key: "b",
					text: "用贴纸 6E 覆盖地图上的 9.5 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "9.6",
			en: {
				text: "Cover 9.6 on the map with sticker 9C. If no upset stickers on the map, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "The world is happy. The world is at peace. Gain 1 happiness."
				}, {
					key: "b",
					text: "Calm. Peace. Quiet. This place soothes your soul, and you would like to share its beauty with others. Remove 1 upset sticker from the map."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 9.6 标记。如果地图上没有不满贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "世界洋溢喜悦，世界一片安宁。获得 1 点心情。"
				}, {
					key: "b",
					text: "宁静。平和。安详。这里抚慰了你的心灵，你希望与他人分享它的美。从地图上移除 1 枚不满贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "9.7",
			en: {
				text: "You find paw prints, and your research tells you that this is a fox. You use an herbal concoction to scare it off without harming it. Gain 1 happiness.",
				choices: []
			},
			zh: {
				text: "你发现了爪印，研究之后确认那是一只狐狸。你用草药熬制的药剂把它吓走，而没有伤害它。获得 1 点心情。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "9.8",
			en: {
				text: "How many foxes are there? In the dark, you can't quite tell. Regardless, they got into your food stores and ate everything. Lose all of your food.",
				choices: []
			},
			zh: {
				text: "到底有几只狐狸？在黑暗里你数不清。不管怎样，它们钻进了你的粮仓，把食物吃得精光。失去全部食物。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "9.9",
			en: {
				text: "Read the effect based on your choice:",
				choices: [
					{
						key: "a",
						text: "“Ha! I'm not that exciting. I investigate tax fraud.” Hmm, that's just what a spy WOULD say. No effect."
					},
					{
						key: "b",
						text: "“It's not glamorous, but it pays well. And I get to expose a slimy business or two!” Gain the Sleuth milestone (gold)."
					},
					{
						key: "c",
						text: "“You couldn't be more wrong. I investigate criminals, ones who owe the government money.” No effect"
					}
				]
			},
			zh: {
				text: "根据你的选择阅读对应效果：",
				choices: [
					{
						key: "a",
						text: "「哈！我可没那么有趣。我是查偷税漏税的。」嗯，这正是间谍会说的话。没有效果。"
					},
					{
						key: "b",
						text: "「这活儿不光鲜，但报酬不错。而且我还能揭发一两桩见不得光的生意！」获得「侦探」里程碑（金色）。"
					},
					{
						key: "c",
						text: "「你大错特错了。我调查的是罪犯，那些欠政府钱的人。」没有效果。"
					}
				]
			}
		}
	] },
	10: { blocks: [
		{
			type: "entry",
			id: "10.1",
			en: {
				text: "“I enjoy my small farm, but it gets lonely sometimes. Do you think… maybe… you could help me find love?” Either say A “I have a cousin,” B “I'm available,” or C “I can't help you.”",
				choices: [
					{
						key: "a",
						text: "Read 10.6"
					},
					{
						key: "b",
						text: "Read 10.5"
					},
					{
						key: "c",
						text: "“I'll be alone forever!” Place an upset sticker on the map near the Farmer Dill resident."
					}
				]
			},
			zh: {
				text: "「我很喜欢我的小农场，可有时候实在孤单。你觉得……也许……你能帮我找到真爱吗？」你可以说 A「我有个表亲」，B「我正单身」，或 C「我帮不了你」。",
				choices: [
					{
						key: "a",
						text: "阅读故事 10.6"
					},
					{
						key: "b",
						text: "阅读故事 10.5"
					},
					{
						key: "c",
						text: "「我会孤独终老！」在农夫迪尔的居民贴纸附近的地图上放置 1 枚不满贴纸。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "10.2",
			en: {
				text: "You spend the day in the city, looking for ways to make money. Either A choose manual labor, or B help in the farmer's market.",
				choices: [{
					key: "a",
					text: "They need help building a skyscraper! You fasten hundreds of bolts while standing on bare iron beams 32 stories in the air. Gain 2 gold."
				}, {
					key: "b",
					text: "You help an old farmer sell his crops. The pay isn't great, but he also gives you two overflowing sacks of onions. Gain 1 gold and 2 food."
				}]
			},
			zh: {
				text: "你在城里度过了一天，四处寻找赚钱的办法。选择 A 做体力活，或 B 在农贸市场帮工。",
				choices: [{
					key: "a",
					text: "他们需要人手建摩天大楼！你站在 32 层楼高的裸露钢梁上，拧紧了数百颗螺栓。获得 2 枚金币。"
				}, {
					key: "b",
					text: "你帮一位老农卖掉了他的作物。报酬不算多，但他还给了你两袋堆得满满的洋葱。获得 1 枚金币和 2 份食物。"
				}]
			}
		},
		{
			type: "entry",
			id: "10.3",
			en: {
				text: "This looks like the perfect place to build a fishing dock! You may spend 1 wood to cover 10.3 on the map with sticker 6X and gain card 12. (Reminder: Use card 12A unless this is your second playthrough.) Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "这里看起来是修建钓鱼码头的绝佳位置！你可以花费 1 份木材，用贴纸 6X 覆盖地图上的 10.3 标记，并获得图鉴牌 12。（提醒：除非这是你的第二遍游戏，否则使用图鉴牌 12A。）否则，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "10.4",
			en: {
				text: "Patch rolls over on his back so you can scratch his belly. He's a good boy.\nGain 1 happiness.",
				choices: []
			},
			zh: {
				text: "帕奇翻过身露出肚皮，让你挠它。它真是条好狗。\n获得 1 点心情。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "10.5",
			en: {
				text: "Farmer Dill blushes. “You saw right through me; I'm glad you picked up on that. Would you… would you like to have dinner sometime?” Either say A “Yes, absolutely!” or B “Have you met my cousin?”",
				choices: [{
					key: "a",
					text: "“Hurray! It's a date!” Cover 10.1 on the map with sticker 9C. Then gain card 29."
				}, {
					key: "b",
					text: "Read 10.6"
				}]
			},
			zh: {
				text: "农夫迪尔脸红了。「你把我看穿了，我很高兴你能察觉到。你……你愿意找个时间一起吃饭吗？」你可以说 A「当然愿意！」，或 B「你见过我表亲吗？」",
				choices: [{
					key: "a",
					text: "「太好了！就这么定了！」用贴纸 9C 覆盖地图上的 10.1 标记，然后获得图鉴牌 29。"
				}, {
					key: "b",
					text: "阅读故事 10.6"
				}]
			}
		},
		{
			type: "entry",
			id: "10.6",
			en: {
				text: "You describe your cousin Alex, and Farmer Dill's eyes light up. “Another farmer, you say? That sounds perfect! Could you set up a date?” Either say A “Absolutely,” or B “What's in it for me?”",
				choices: [{
					key: "a",
					text: "“Hurray!” Gain card 30."
				}, {
					key: "b",
					text: "“Oh… I guess I can give you some cucumbers?” Gain 1 food and card 30."
				}]
			},
			zh: {
				text: "你向农夫迪尔描述了表亲亚历克斯，迪尔的眼睛一下子亮了。「你说对方也务农？那真是再合适不过了！你能帮我们安排一次约会吗？」你可以说 A「当然」，或 B「对我有什么好处？」",
				choices: [{
					key: "a",
					text: "「太好了！」获得图鉴牌 30。"
				}, {
					key: "b",
					text: "「哦……我想我可以送你一些黄瓜？」获得 1 份食物和图鉴牌 30。"
				}]
			}
		},
		{
			type: "entry",
			id: "10.7",
			en: {
				text: "What would you like to do for your first date with Farmer Dill? Either A go for a hike, or B spend 1 food to make a home-cooked meal.",
				choices: [{
					key: "a",
					text: "During your hike, Farmer Dill skins her knee and you get poison ivy. Ouch! At least the company was good. Place 1 heart sticker on card 29."
				}, {
					key: "b",
					text: "Over a delicious dinner, you find that you both love cringe-worthy dad jokes! You spend the evening swapping puns. Place 2 heart stickers on card 29."
				}]
			},
			zh: {
				text: "你和农夫迪尔的第一次约会想做什么？选择 A 去远足，或 B 花费 1 份食物做一顿家常饭。",
				choices: [{
					key: "a",
					text: "远足途中，农夫迪尔擦破了膝盖，你还染上了毒藤。哎哟！至少同伴相处得很愉快。在图鉴牌 29 上放置 1 枚爱心贴纸。"
				}, {
					key: "b",
					text: "一顿美味的晚餐中，你发现你们俩都爱讲那些让人尴尬的冷笑话！你们整晚都在互抛谐音梗。在图鉴牌 29 上放置 2 枚爱心贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "10.8",
			en: {
				text: "You spend the afternoon walking the trails, observing wildlife, and unwinding. If there is 1 or fewer animal stickers on the Nature Preserve (the sticker with 10.8), read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Place 1 wild animal sticker 12H on the Nature Preserve."
				}, {
					key: "b",
					text: "Cover 10.8 on the map with sticker 12J. Then gain 1 happiness."
				}]
			},
			zh: {
				text: "你花了一个下午在林间小径上散步，观察野生动物，放松身心。如果自然保护区（带有 10.8 标记的贴纸）上有 1 枚或更少的动物贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "在自然保护区放置 1 枚野生动物贴纸 12H。"
				}, {
					key: "b",
					text: "用贴纸 12J 覆盖地图上的 10.8 标记，然后获得 1 点心情。"
				}]
			}
		}
	] },
	11: { blocks: [
		{
			type: "entry",
			id: "11.1",
			en: {
				text: "You learn that Farmer Dill's first name is Robin. That's also Mother's first name, so you decide to come up with a nickname. Either say A “Can I call you Dilly?” or B “I'm gonna call you Klutz.”",
				choices: [{
					key: "a",
					text: "“Aww, that's sweet. Yes you may!” Place 2 heart stickers on card 29."
				}, {
					key: "b",
					text: "Dill spends the next hour sulking. Place 1 progress sticker on card 29."
				}]
			},
			zh: {
				text: "你得知农夫迪尔的名字叫罗宾。母亲的名字也叫罗宾，于是你决定给她起个昵称。你可以说 A「我能叫你迪莉吗？」，或 B「我就叫你笨手笨脚吧。」",
				choices: [{
					key: "a",
					text: "「哎呀，真贴心。当然可以！」在图鉴牌 29 上放置 2 枚爱心贴纸。"
				}, {
					key: "b",
					text: "迪尔闷闷不乐了一个钟头。在图鉴牌 29 上放置 1 枚进度贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "11.2",
			en: {
				text: "As the seasons stretch on, you find that you are falling for Dill. After a wonderful picnic, she says “I love you” for the first time. Either say A “Thank you,” or B “I love you too.”",
				choices: [{
					key: "a",
					text: "She finds an excuse to go home early. Place 1 progress sticker on card 29."
				}, {
					key: "b",
					text: "She smiles and pulls you close. Place 1 heart sticker on card 29."
				}]
			},
			zh: {
				text: "季节流转，你发现自己渐渐爱上了迪尔。一次愉快的野餐之后，她第一次对你说「我爱你」。你可以说 A「谢谢」，或 B「我也爱你」。",
				choices: [{
					key: "a",
					text: "她找了个借口提前回家。在图鉴牌 29 上放置 1 枚进度贴纸。"
				}, {
					key: "b",
					text: "她微笑着把你拉近。在图鉴牌 29 上放置 1 枚爱心贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "11.3",
			en: {
				text: "You've been dating for months now, and its time to decide if you want to spend the rest of your life with Dill. Either A break up, B have a deep conversation, or C spend 1 gold to buy an engagement ring.",
				choices: [
					{
						key: "a",
						text: "“I'll be alone forever…” Discard card 29 and place an upset sticker on the map near the Farmer Dill resident."
					},
					{
						key: "b",
						text: "You talk all night until the sun begins to rise. You talk about children, about dreams, and about the mysteries of the universe. Gain 1 happiness and place 1 heart sticker on card 29."
					},
					{
						key: "c",
						text: "She sees the ring and says “Yes!” without hesitation. Gain 1 happiness and place 2 heart stickers on card 29."
					}
				]
			},
			zh: {
				text: "你们已经交往了好几个月，是时候决定是否愿意与迪尔共度余生了。选择 A 分手，B 进行一次深谈，或 C 花费 1 枚金币买一枚订婚戒指。",
				choices: [
					{
						key: "a",
						text: "「我会孤独终老……」弃掉图鉴牌 29，并在农夫迪尔的居民贴纸附近的地图上放置 1 枚不满贴纸。"
					},
					{
						key: "b",
						text: "你们聊了一整夜，直到太阳升起。你们谈起孩子，谈起梦想，也谈起宇宙的奥秘。获得 1 点心情，并在图鉴牌 29 上放置 1 枚爱心贴纸。"
					},
					{
						key: "c",
						text: "她看到戒指，毫不犹豫地说了「愿意」。获得 1 点心情，并在图鉴牌 29 上放置 2 枚爱心贴纸。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "11.4",
			en: {
				text: "Are you ready to pop the big question? Either ask A “Will you Marry Me?” or B “Do you want chicken for dinner?”",
				choices: [{
					key: "a",
					text: "If 3 or more heart stickers on card 29, she says yes: Place 1 heart sticker on card 29. Otherwise, she breaks up with you: Discard card 29."
				}, {
					key: "b",
					text: "“Sure! That sounds tasty.” Either perform another action or cover 1 progress sticker on card 29 with a heart sticker."
				}]
			},
			zh: {
				text: "你准备好提出那个重要的问题了吗？选择 A 问「你愿意嫁给我吗？」，或 B 问「晚饭想吃鸡肉吗？」",
				choices: [{
					key: "a",
					text: "如果图鉴牌 29 上有 3 枚或更多爱心贴纸，她答应了：在图鉴牌 29 上放置 1 枚爱心贴纸。否则，她与你分手：弃掉图鉴牌 29。"
				}, {
					key: "b",
					text: "「好啊！听起来很好吃。」选择额外行动一次，或用 1 枚爱心贴纸覆盖图鉴牌 29 上的 1 枚进度贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "11.5",
			en: {
				text: "The wedding day has arrived. You stand with Dill at the altar, and everyone is waiting for you to say the final words. Either say A “I do,” or B “I don't.”",
				choices: [{
					key: "a",
					text: "“You may now kiss.” Discard card 29 and cover the Dating milestone with Married (gold)."
				}, {
					key: "b",
					text: "Dill runs away in tears. Discard card 29 and place an upset sticker on the map near the Farmer Dill resident."
				}]
			},
			zh: {
				text: "婚礼当天到了。你与迪尔并肩站在圣坛前，所有人都在等你说出最后那句话。你可以说 A「我愿意」，或 B「我不愿意」。",
				choices: [{
					key: "a",
					text: "「现在你们可以亲吻了。」弃掉图鉴牌 29，并用「已婚」（金色）覆盖「恋爱中」里程碑。"
				}, {
					key: "b",
					text: "迪尔流着泪跑开了。弃掉图鉴牌 29，并在农夫迪尔的居民贴纸附近的地图上放置 1 枚不满贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "11.6",
			en: {
				text: "“Your Cousin Alex is wonderful; I think they might be the one!” Either A tell Dill to take it slow, or B spend 1 gold to help buy an engagement ring.",
				choices: [{
					key: "a",
					text: "“Will do!” Place 1 heart sticker on card 30."
				}, {
					key: "b",
					text: "“Don't you think it's a bit early? Oh well, you know best!” Place 2 heart stickers on card 30."
				}]
			},
			zh: {
				text: "「你的表亲亚历克斯真是太好了，我觉得就是这个人了！」选择 A 劝迪尔慢慢来，或 B 花费 1 枚金币帮忙买一枚订婚戒指。",
				choices: [{
					key: "a",
					text: "「我会的！」在图鉴牌 30 上放置 1 枚爱心贴纸。"
				}, {
					key: "b",
					text: "「你不觉得有点早吗？算了，你最清楚！」在图鉴牌 30 上放置 2 枚爱心贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "11.7",
			en: {
				text: "Read the hint below. If you solve the puzzle, read the story it points to.\nYou need to use card 52. Most of the letters on this are a distraction.\nIf you need an additional hint, spend 1 gold to read 33.8.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，就阅读它指向的故事。\n你需要使用图鉴牌 52。这上面的多数字母都是干扰项。\n如果你需要额外提示，花费 1 枚金币阅读故事 33.8。",
				choices: []
			}
		}
	] },
	12: { blocks: [
		{
			type: "entry",
			id: "12.1",
			en: {
				text: "\"Thanks for the advice so far. I'm glad I didn't jump in too fast; I'm having second thoughts.\" Either say A \"You should break up,\" or B \"Relationships are hard, give it time.\"",
				choices: [{
					key: "a",
					text: "\"You're right,\" she says sadly. Discard card 30."
				}, {
					key: "b",
					text: "She nods and smiles. Place 1 heart sticker on card 30."
				}]
			},
			zh: {
				text: "「谢谢你这段时间的建议。还好我没有一头扎进去，我现在有些动摇了。」你可以说 A「你们应该分手」，或 B「感情本来就不容易，给它一点时间。」",
				choices: [{
					key: "a",
					text: "「你说得对。」她难过地说。弃掉图鉴牌 30。"
				}, {
					key: "b",
					text: "她点点头，笑了。在图鉴牌 30 上放置 1 枚爱心贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "12.2",
			en: {
				text: "At the wedding, the officiant says, \"If anyone has a reason why these two should not be married, please stand up now.\" Either A watch silently, or B loudly proclaim your love for Dill.",
				choices: [{
					key: "a",
					text: "\"You may now kiss!\" Place 1 heart sticker on card 30, and cover Farmer Dill's house with sticker 4G."
				}, {
					key: "b",
					text: "Dill runs into your arms. Alex is devastated, but you've saved yourself a lifetime of regret. Discard card 30 and gain card 29."
				}]
			},
			zh: {
				text: "婚礼上，主婚人说：「如果有人认为这两位不该结为夫妻，请现在就站出来。」你可以选择 A 默默旁观，或 B 大声宣告你对迪尔的爱。",
				choices: [{
					key: "a",
					text: "「现在你们可以亲吻了！」在图鉴牌 30 上放置 1 枚爱心贴纸，并用贴纸 4G 覆盖农夫迪尔的房子。"
				}, {
					key: "b",
					text: "迪尔扑进你的怀里。亚历克斯伤心欲绝，但你为自己免除了一生的遗憾。弃掉图鉴牌 30，并获得图鉴牌 29。"
				}]
			}
		},
		{
			type: "entry",
			id: "12.3",
			en: {
				text: "\"Alex really wants kids, but I'm not so sure. It's a huge expense, and I don't know if we can afford it. What do you think?\" Either A say, \"That's between you and Alex,\" or B say, \"You don't want kids, trust me,\" or C spend 1 gold to start a college fund.",
				choices: [
					{
						key: "a",
						text: "Roll a die. On a 1-3, read option B, otherwise read C."
					},
					{
						key: "b",
						text: "\"Yeah, I think it's best to wait.\" Discard card 30."
					},
					{
						key: "c",
						text: "\"We decided to adopt a baby!\" Discard card 30. Then place 1 baby sticker 11P on the map on the Farmer Dill resident."
					}
				]
			},
			zh: {
				text: "「亚历克斯很想要孩子，可我不太确定。那要花很多钱，我不知道我们负担不负担得起。你怎么看？」你可以说 A「这是你和亚历克斯之间的事」，或 B「相信我，你不会想要孩子的」，或 C 花费 1 枚金币设立一笔大学基金。",
				choices: [
					{
						key: "a",
						text: "掷一次骰子。如果掷出 1 至 3，阅读选项 B，否则阅读选项 C。"
					},
					{
						key: "b",
						text: "「是啊，我想还是再等等最好。」弃掉图鉴牌 30。"
					},
					{
						key: "c",
						text: "「我们决定领养一个孩子！」弃掉图鉴牌 30。然后在地图上农夫迪尔的居民贴纸上放置 1 枚婴儿贴纸 11P。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "12.4",
			en: {
				text: "Your house burned down, but that just means you can build something bigger and better! Either A spend 1 gold and 2 wood to build a new home, or B live in a tent for now.",
				choices: [{
					key: "a",
					text: "Gain 1 happiness and cover 12.4 on the map with sticker 7C."
				}, {
					key: "b",
					text: "Perform another action."
				}]
			},
			zh: {
				text: "你的房子烧毁了，但这只意味着你可以建一座更大更好的！选择 A 花费 1 枚金币和 2 份木材建造新家，或 B 暂时住在帐篷里。",
				choices: [{
					key: "a",
					text: "获得 1 点心情，并用贴纸 7C 覆盖地图上的 12.4 标记。"
				}, {
					key: "b",
					text: "额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "12.5",
			en: {
				text: "A wizened old lady tells you the legend. \"The Cobblepots were a rich family. Ridiculously rich. But when the queen attempted to tax their fortune, they buried it in the countryside instead.\" Place 1 heart sticker on card 44.",
				choices: []
			},
			zh: {
				text: "一位瘦小的老妇人向你讲述了那个传说。「科布尔波特家族曾经非常富有，富得离谱。可当女王想对他们的财产征税时，他们就把财宝埋到了乡间。」在图鉴牌 44 上放置 1 枚爱心贴纸。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "12.6",
			en: {
				text: "Pouring over old tax records and newspaper clippings, you find the lodge's true purpose: It is an elaborate pyramid scheme. Either A threaten to expose them, or B keep their secret safe.",
				choices: [{
					key: "a",
					text: "\"We don't want any trouble. Here, take your money back!\" Gain 7 gold and cover 7.2 on the map with sticker 9C."
				}, {
					key: "b",
					text: "\"We appreciate your loyalty.\" Gain 1 gold."
				}]
			},
			zh: {
				text: "你仔细翻查旧税务记录和剪报，发现了小屋的真正用途：这是一个精心设计的金字塔式骗局。选择 A 威胁揭发他们，或 B 替他们保守秘密。",
				choices: [{
					key: "a",
					text: "「我们不想惹麻烦。拿着，把你的钱退给你！」获得 7 枚金币，并用贴纸 9C 覆盖地图上的 7.2 标记。"
				}, {
					key: "b",
					text: "「我们很感激你的忠诚。」获得 1 枚金币。"
				}]
			}
		},
		{
			type: "entry",
			id: "12.7",
			en: {
				text: "If you chose the Beakers sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "\"This arrived just in time!\" Place the Beakers sticker on the map near this resident. You may remove a Test Subject or Poisoned milestone. Then cover 12.7 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "\"This won't help my research.\" Cover 12.7 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了烧杯贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「这东西来得正是时候！」在地图上这名居民附近放置烧杯贴纸。你可以移除「试验对象」或「中毒」里程碑。然后用爱心贴纸覆盖图鉴牌 47 上的 12.7 标记。"
				}, {
					key: "b",
					text: "「这对我的研究没有帮助。」用你选定的礼物贴纸覆盖图鉴牌 47 上的 12.7 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "12.8",
			en: {
				text: "Cover 12.8 on the map with sticker 7Q. Then either A set up a trade agreement, or B spend 1 gold to go on a tropical vacation.",
				choices: [{
					key: "a",
					text: "You get a portion of all trade passing through town. Gain 1 wood, 1 gold, and 1 ore."
				}, {
					key: "b",
					text: "A week at the beach leaves you glowing! Gain 1 happiness."
				}]
			},
			zh: {
				text: "用贴纸 7Q 覆盖地图上的 12.8 标记。然后选择 A 签订一份贸易协定，或 B 花费 1 枚金币去热带度假。",
				choices: [{
					key: "a",
					text: "你可以从所有经过小镇的贸易中抽取一份。获得 1 份木材、1 枚金币和 1 份矿石。"
				}, {
					key: "b",
					text: "在海边度过一周，让你容光焕发！获得 1 点心情。"
				}]
			}
		}
	] },
	13: { blocks: [
		{
			type: "entry",
			id: "13.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "13.2",
			en: {
				text: "\"Canned food is gonna change the world! How much can we make in the first batch?\" Spend 0 to 3 food, then resolve the matching effect.\n0 Food: \"Don't waste my time.\" Perform another action.\n1 Food: \"A good start.\" Gain 2 gold and cover 13.2 on this page with a heart sticker.\n2 Food: \"Excellent!\" Gain 3 gold and cover 13.2 on this page with a heart sticker.\n3 Food: \"Yes! We're gonna be rich!\" Gain 5 gold and cover 13.2 on this page with a heart sticker.",
				choices: []
			},
			zh: {
				text: "「罐头食品将改变世界！第一批我们能做多少？」花费 0 至 3 份食物，然后结算对应的效果。\n0 份食物：「别浪费我的时间。」额外行动一次。\n1 份食物：「不错的开始。」获得 2 枚金币，并用爱心贴纸覆盖本页的 13.2。\n2 份食物：「太棒了！」获得 3 枚金币，并用爱心贴纸覆盖本页的 13.2。\n3 份食物：「对！我们要发财了！」获得 5 枚金币，并用爱心贴纸覆盖本页的 13.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "13.3",
			en: {
				text: "\"The canning process is generating large amounts of hazardous sludge. What should we do with it?\" Either A spend 1 gold to dispose of it safely, or B dump it in the river.",
				choices: [{
					key: "a",
					text: "\"Seems like a waste of money, but you're the one paying for it.\" Cover 13.3 on this page with a heart sticker."
				}, {
					key: "b",
					text: "\"No one will notice.\" Gain 1 gold and cover 13.3 on this page with a progress sticker. Then cover 13.1 on the map with sticker 12U."
				}]
			},
			zh: {
				text: "「罐装过程会产生大量有害污泥。我们该怎么处理？」选择 A 花费 1 枚金币安全处理，或 B 倒进河里。",
				choices: [{
					key: "a",
					text: "「看起来是白花钱，不过反正付钱的是你。」用爱心贴纸覆盖本页的 13.3。"
				}, {
					key: "b",
					text: "「没人会注意到的。」获得 1 枚金币，并用进度贴纸覆盖本页的 13.3。然后用贴纸 12U 覆盖地图上的 13.1 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "13.4",
			en: {
				text: "\"Orders are at an all-time high. How much food should we can?\" Spend 0 to 3 food, then resolve the matching effect.\n0 Food: \"Come back when you're better prepared.\" Perform another action.\n1 Food: It sells out immediately. Gain 2 gold and cover 13.4 on this page with a heart sticker.\n2 Food: You fulfill most of the orders. Gain 3 gold and cover 13.4 on this page with a heart sticker.\n3 Food: \"So much money!\" Gain 5 gold and cover 13.4 on this page with a heart sticker.",
				choices: []
			},
			zh: {
				text: "「订单量创下新高。我们该罐装多少食物？」花费 0 至 3 份食物，然后结算对应的效果。\n0 份食物：「等你准备得更充分再来吧。」额外行动一次。\n1 份食物：货物立刻售罄。获得 2 枚金币，并用爱心贴纸覆盖本页的 13.4。\n2 份食物：你完成了大部分订单。获得 3 枚金币，并用爱心贴纸覆盖本页的 13.4。\n3 份食物：「好多钱！」获得 5 枚金币，并用爱心贴纸覆盖本页的 13.4。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "13.5",
			en: {
				text: "Workers in the factory have been complaining about long hours and low wages. Either A spend 1 gold to give raises, or B save the money for yourself.",
				choices: [{
					key: "a",
					text: "They seem content for now. Cover 13.5 on this page with a heart sticker."
				}, {
					key: "b",
					text: "The workers are miserable, but at least you saved some money! Gain 1 gold and the Unrest milestone (red). Then cover 13.5 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "工厂里的工人一直在抱怨工时太长、工资太低。选择 A 花费 1 枚金币给他们加薪，或 B 把钱留给自己。",
				choices: [{
					key: "a",
					text: "他们暂时看起来还算满意。用爱心贴纸覆盖本页的 13.5。"
				}, {
					key: "b",
					text: "工人们苦不堪言，但至少你省下了一些钱！获得 1 枚金币和「动荡」里程碑（红色）。然后用进度贴纸覆盖本页的 13.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "13.6",
			en: {
				text: "\"People can't get enough of our blueberry sludge, but profits are down! We could make more money if we water down the formula and add some filler.\" Either A add filler, or B keep natural ingredients.",
				choices: [{
					key: "a",
					text: "\"They'll never know the difference!\" Gain 2 gold, then read 13.7."
				}, {
					key: "b",
					text: "\"Ok boss, but we're losing money.\" Cover 13.6 on this page with a heart sticker, then read 13.7."
				}]
			},
			zh: {
				text: "「大家对我们的蓝莓糊爱不释手，可利润却在下降！要是我们在配方里兑点水、加点填充物，就能多赚些钱。」选择 A 添加填充物，或 B 保留天然原料。",
				choices: [{
					key: "a",
					text: "「他们永远尝不出区别！」获得 2 枚金币，然后阅读故事 13.7。"
				}, {
					key: "b",
					text: "「好吧，老板，可我们正在亏钱。」用爱心贴纸覆盖本页的 13.6，然后阅读故事 13.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "13.7",
			en: {
				text: "Cover 13.1 on the map with sticker 11S. Then, if 4 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Blueberry Sludge has become a household name associated with quality products and responsible practices. Gain the Honest Company milestone (gold)."
				}, {
					key: "b",
					text: "Blueberry Sludge has become a famous brand, albeit one tarnished by controversy and poor business practices. It is, however, extremely profitable. Gain 2 gold and the Greedy Company milestone (silver)."
				}]
			},
			zh: {
				text: "用贴纸 11S 覆盖地图上的 13.1 标记。然后，如果本页有 4 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「蓝莓糊」已成为家喻户晓的名字，与优质产品和负责任的做法联系在一起。获得「诚信公司」里程碑（金色）。"
				}, {
					key: "b",
					text: "「蓝莓糊」成了一个知名品牌，尽管丑闻和不良商业做法让它蒙上了污点。不过，它的利润极其丰厚。获得 2 枚金币和「贪婪公司」里程碑（银色）。"
				}]
			}
		}
	] },
	14: { blocks: [
		{
			type: "entry",
			id: "14.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "14.2",
			en: {
				text: "The professor is excited to share her research with you. \"My medical breakthrough can cure any ailment...\" Either A listen silently, or B spend 1 gold to fund further research.",
				choices: [{
					key: "a",
					text: "\"It only works on earthworms for now.\" Cover 14.2 on this page with a progress sticker."
				}, {
					key: "b",
					text: "\"This funding will make a big difference!\" Place 2 stickers on this page: a heart sticker covering 14.2 and a progress sticker covering 14.3."
				}]
			},
			zh: {
				text: "教授兴冲冲地向你介绍她的研究。「我的医学突破能治愈任何疾病……」选择 A 安静地听，或 B 花费 1 枚金币资助她继续研究。",
				choices: [{
					key: "a",
					text: "「目前它只对蚯蚓有效。」用进度贴纸覆盖本页的 14.2。"
				}, {
					key: "b",
					text: "「这笔资助会带来巨大的改变！」在本页放置 2 枚贴纸：用爱心贴纸覆盖 14.2，用进度贴纸覆盖 14.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "14.3",
			en: {
				text: "\"My medicine should work on humans, but I need more time. Come back tomorrow.\" Either A be patient, or B say, \"It MUST start today!\"",
				choices: [{
					key: "a",
					text: "Cover 14.3 on this page with a heart sticker."
				}, {
					key: "b",
					text: "\"I suppose we could skip right to human trials.\" Cover 14.3 on this page with a progress sticker, then read 14.4."
				}]
			},
			zh: {
				text: "「我的药应该对人体有效，但我还需要更多时间。明天再来吧。」选择 A 耐心等待，或 B 说「必须今天就开始！」",
				choices: [{
					key: "a",
					text: "用爱心贴纸覆盖本页的 14.3。"
				}, {
					key: "b",
					text: "「我想我们可以直接跳到人体试验。」用进度贴纸覆盖本页的 14.3，然后阅读故事 14.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "14.4",
			en: {
				text: "\"Ok. Let's see if my medicine works on humans; would you like to volunteer?\" Choose Yes or No.\nYes: \"Here's your injection! We'll run some tests tomorrow.\" Gain the Test Subject milestone (red). Then place 2 stickers on this page: a heart sticker covering 14.4 and a progress sticker covering 14.5.\nNo: \"Fine, I'll use it on my husband.\" Cover 14.4 on this page with a progress sticker.",
				choices: []
			},
			zh: {
				text: "「好。我们来试试这药对人体有没有效；你愿意当志愿者吗？」选择「是」或「否」。\n是：「这是你的针剂！我们明天做一些测试。」获得「试验对象」里程碑（红色）。然后在本页放置 2 枚贴纸：用爱心贴纸覆盖 14.4，用进度贴纸覆盖 14.5。\n否：「好吧，那我拿我丈夫来试。」用进度贴纸覆盖本页的 14.4。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "14.5",
			en: {
				text: "\"My husband seems to be completely immune to sickness! With no side effects!\" Place 2 stickers on this page: a heart sticker covering 14.5 and a progress sticker covering 14.6.",
				choices: []
			},
			zh: {
				text: "「我丈夫似乎对疾病完全免疫！而且没有任何副作用！」在本页放置 2 枚贴纸：用爱心贴纸覆盖 14.5，用进度贴纸覆盖 14.6。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "14.6",
			en: {
				text: "\"Have you noticed any side effects?\" Either say A \"Constant headache,\" B \"Itchy feet,\" or C \"Nothing bad.\"",
				choices: [
					{
						key: "a",
						text: "\"That is disappointing.\" Cover 14.6 on this page with an upset sticker."
					},
					{
						key: "b",
						text: "\"Could be worse.\" Cover 14.6 on this page with a progress sticker."
					},
					{
						key: "c",
						text: "\"Excellent! And these tests show that your immune system is functioning at a remarkable level!\" Cover 14.6 on this page with a heart sticker."
					}
				]
			},
			zh: {
				text: "「你注意到有什么副作用吗？」你可以说 A「一直头痛」，B「脚发痒」，或 C「没什么不良感觉」。",
				choices: [
					{
						key: "a",
						text: "「真令人失望。」用不满贴纸覆盖本页的 14.6。"
					},
					{
						key: "b",
						text: "「还不算太糟。」用进度贴纸覆盖本页的 14.6。"
					},
					{
						key: "c",
						text: "「太好了！而且这些测试表明，你的免疫系统运作得非常好！」用爱心贴纸覆盖本页的 14.6。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "14.7",
			en: {
				text: "\"What do you think of selling my miracle cure?\" the professor asks. Either say A \"Let's do it!\" or B \"This doesn't seem safe.\"",
				choices: [{
					key: "a",
					text: "\"Excellent, I think I'll call it Invinci-Pill!\" Cover 14.7 on this page with a heart sticker, then read 14.8."
				}, {
					key: "b",
					text: "\"You're not even a scientist, so I'm not sure why I'm asking your opinion.\" Read 14.8."
				}]
			},
			zh: {
				text: "「你觉得把我的神奇疗法卖出去怎么样？」教授问道。你可以说 A「就这么办！」，或 B「这看起来不太安全。」",
				choices: [{
					key: "a",
					text: "「太好了，我想就叫它『无敌药丸』！」用爱心贴纸覆盖本页的 14.7，然后阅读故事 14.8。"
				}, {
					key: "b",
					text: "「你连科学家都不是，真不知道我为什么要问你的意见。」阅读故事 14.8。"
				}]
			}
		},
		{
			type: "entry",
			id: "14.8",
			en: {
				text: "Cover 14.1 on the map with sticker 9C. If 3 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "\"I've got enough doses for everyone in town!\" the professor announces with glee. \"And we'll make money selling it, too!\" Gain the Miracle Medicine milestone (silver)."
				}, {
					key: "b",
					text: "\"I admit that this medicine might not be safe. We can still make money selling the research, though.\" Gain 3 gold."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 14.1 标记。如果本页有 3 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「我手里的剂量够全镇的人用了！」教授兴高采烈地宣布，「我们还能靠卖它赚钱！」获得「灵丹妙药」里程碑（银色）。"
				}, {
					key: "b",
					text: "「我承认这种药可能不安全。不过我们仍然可以靠出售研究成果赚钱。」获得 3 枚金币。"
				}]
			}
		}
	] },
	15: { blocks: [
		{
			type: "entry",
			id: "15.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.2",
			en: {
				text: "\"Over the years, I've found tons of ways to make money. Now that we've got a baby, it's become even more important. My first gig will be selling shoes door-to-door. You can help!\" Gain 1 gold and cover 15.2 on this page with a heart sticker.",
				choices: []
			},
			zh: {
				text: "「这些年我找到了许多赚钱的法子。现在我们有了孩子，这就更重要了。我的第一份活儿是挨家挨户卖鞋。你可以来帮忙！」获得 1 枚金币，并用爱心贴纸覆盖本页的 15.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.3",
			en: {
				text: "\"I know a company that will give you money just for advertising their amazing vitamins. Do you want to participate?\" Cover 15.3 on this page with a heart sticker. Then you may place sticker 5F to gain 2 gold.",
				choices: []
			},
			zh: {
				text: "「我认识一家公司，只要你帮他们宣传神奇的维生素，他们就会付钱给你。你想参加吗？」用爱心贴纸覆盖本页的 15.3。然后你可以放置贴纸 5F，获得 2 枚金币。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.4",
			en: {
				text: "\"I've been selling lawn gnomes to the fine folks in the area. Do you want to sell some?\" Cover 15.4 on this page with a heart sticker. Then you may place sticker 12E to gain 1 gold.",
				choices: []
			},
			zh: {
				text: "「我一直在向这一带的好人家推销草坪侏儒像。你也想卖一些吗？」用爱心贴纸覆盖本页的 15.4。然后你可以放置贴纸 12E，获得 1 枚金币。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.5",
			en: {
				text: "\"Here's an easy job: Some rich folks offered us money to dump their garbage in our town. Is that ok with you?\" Cover 15.5 on this page with a heart sticker. Then you may place sticker 5G to gain 2 gold.",
				choices: []
			},
			zh: {
				text: "「有份轻松的活儿：几个有钱人愿意付钱，让我们把他们的垃圾倒在我们镇上。你觉得行吗？」用爱心贴纸覆盖本页的 15.5。然后你可以放置贴纸 5G，获得 2 枚金币。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.6",
			en: {
				text: "\"You'd be surprised just how much money you can make testing experimental medicines. Do you want to participate?\" Cover 15.1 on the map with sticker 9C. Then you may gain the Test Subject milestone (red) to gain 3 gold.",
				choices: []
			},
			zh: {
				text: "「你想象不到测试实验药物能赚多少钱。你想参加吗？」用贴纸 9C 覆盖地图上的 15.1 标记。然后你可以获得「试验对象」里程碑（红色），以此获得 3 枚金币。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.7",
			en: {
				text: "The bushes are plump with blueberries, but a young deer is feasting on them. Either A chase the deer off, or B watch from a distance.",
				choices: [{
					key: "a",
					text: "You scare the deer away, then fill your basket with berries. Gain 1 food. Then cover 15.7 on the map with sticker 9C."
				}, {
					key: "b",
					text: "Lose 1 food (if able). Then cover 15.7 on the map with sticker 3C."
				}]
			},
			zh: {
				text: "灌木上结满了饱满的蓝莓，可一只小鹿正在大快朵颐。选择 A 把鹿赶走，或 B 远远地看着。",
				choices: [{
					key: "a",
					text: "你把鹿吓跑了，然后摘了满满一篮浆果。获得 1 份食物。然后用贴纸 9C 覆盖地图上的 15.7 标记。"
				}, {
					key: "b",
					text: "失去 1 份食物（如果可以）。然后用贴纸 3C 覆盖地图上的 15.7 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "15.8",
			en: {
				text: "You try to tame the bear by offering it some fish. Spend 0 to 4 food, then roll the die. Read the effect matching the number rolled plus the amount of food spent:\n1-3: It growls at you and bares its teeth. No effect.\n4+: The bear lets you pet its head. (Note: Don't try this at home!) Cover 15.8 on the map with sticker 9C. Then gain the Bear Tamer milestone (silver).",
				choices: []
			},
			zh: {
				text: "你试着用一些鱼来驯服这只熊。花费 0 至 4 份食物，然后掷骰。阅读与掷骰结果加上花费食物数量相对应的效果：\n1 至 3：它朝你低吼，龇出牙齿。没有效果。\n4 及以上：熊允许你摸摸它的头。（注意：切勿在家中尝试！）用贴纸 9C 覆盖地图上的 15.8 标记。然后获得「驯熊师」里程碑（银色）。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.9",
			en: {
				text: "Being a chef is easy! All you have to do is mix ingredients together and pop them in a pan, right? Spend 0 to 4 food, then roll the die. Read the effect matching the number rolled plus the amount of food spent:\n1-2: Unfortunately, your food is barely edible. \"Burnt, tough, and tasteless,\" the reviews say. No one is willing to pay for their meals. No effect.\n3-5: The customers seem to enjoy their food. They pay well and leave with smiles on their faces. Gain 2 gold.\n6+: The patrons absolutely love your cooking, and your food becomes famous overnight! Gain 2 gold and card 55.",
				choices: []
			},
			zh: {
				text: "当厨师很简单！你要做的就是把食材混在一起，丢进锅里，对吧？花费 0 至 4 份食物，然后掷骰。阅读与掷骰结果加上花费食物数量相对应的效果：\n1 至 2：可惜，你做的食物几乎难以下咽。「焦糊、老硬、毫无味道。」食客们这样评价。没有人愿意为这顿饭付钱。没有效果。\n3 至 5：顾客们似乎很享受他们的食物。他们付钱爽快，面带笑容地离开。获得 2 枚金币。\n6 及以上：食客们对你的厨艺赞不绝口，你的食物一夜成名！获得 2 枚金币和图鉴牌 55。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "15.10",
			en: {
				text: "Place sticker 1F on this card (3A or 3B). Then place sticker 5Q covering a lone tree (triangle sticker with a tree icon) on the map, if able.",
				choices: []
			},
			zh: {
				text: "将贴纸 1F 放在此牌上（3A 或 3B）。然后，如果可以，放置贴纸 5Q，覆盖地图上的一棵孤树（带树木图标的三角形贴纸）。",
				choices: []
			}
		}
	] },
	16: { blocks: [
		{
			type: "entry",
			id: "16.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "16.2",
			en: {
				text: "Rex isn't home, but you notice a large briefcase and a knocked-over chair when you peek through the window. You sense that Rex is hiding something. Either A give him his privacy, or B break into his house.",
				choices: [{
					key: "a",
					text: "You head home, but can't shake the feeling that there is something wrong with that guy. Cover 16.2 on this page with a progress sticker."
				}, {
					key: "b",
					text: "You let yourself into the house and find a disaster scene. Broken glass and a fist sized hole in the wall! Cover both 16.2 and 16.3 on this page with progress stickers."
				}]
			},
			zh: {
				text: "雷克斯不在家，但你从窗口窥看时，注意到一只大公文包和一把翻倒的椅子。你感觉雷克斯在隐瞒什么。你可以选择 A 尊重他的隐私，或 B 闯进他家。",
				choices: [{
					key: "a",
					text: "你回了家，却怎么也甩不掉那种感觉：那个人有点不对劲。用进度贴纸覆盖本页的 16.2。"
				}, {
					key: "b",
					text: "你擅自进了屋，看到一片狼藉。碎玻璃，墙上还有一个拳头大小的洞！用进度贴纸覆盖本页的 16.2 和 16.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "16.3",
			en: {
				text: "You invite Rex to dinner to uncover more information about him. Either A ask about his job, or B ask about his hobbies.",
				choices: [{
					key: "a",
					text: "“You might say I'm an accountant, of sorts.” Cover both 16.3 and 16.4 on this page with progress stickers."
				}, {
					key: "b",
					text: "“I'm really into interpretive dance. I'm a bit of a klutz, but it's a good workout.” Cover both 16.3 and 16.4 on this page with progress stickers."
				}]
			},
			zh: {
				text: "你邀请雷克斯共进晚餐，想多了解他一些。选择 A 问他的工作，或 B 问他的爱好。",
				choices: [{
					key: "a",
					text: "「你可以说我是个会计，差不多吧。」用进度贴纸覆盖本页的 16.3 和 16.4。"
				}, {
					key: "b",
					text: "「我很喜欢跳创意舞蹈，我有点笨手笨脚，但这是很好的锻炼。」用进度贴纸覆盖本页的 16.3 和 16.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "16.4",
			en: {
				text: "You wonder about the signs of struggle you saw inside Rex's house and think you should do something about it. Either A confront Rex, or B ask the neighbors if they know anything.",
				choices: [{
					key: "a",
					text: "“Just a clumsy accident. Wait, you were in my house?” Cover 16.4 on this page with a progress sticker."
				}, {
					key: "b",
					text: "The only thing they can agree on is that Rex is involved with money. Cover 16.4 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "你想起在雷克斯家里看到的挣扎痕迹，觉得应该做点什么。选择 A 当面向雷克斯质问，或 B 问问邻居知不知道什么。",
				choices: [{
					key: "a",
					text: "「只是不小心弄的。等等，你进过我家？」用进度贴纸覆盖本页的 16.4。"
				}, {
					key: "b",
					text: "他们唯一能达成一致的是：雷克斯和钱有关。用进度贴纸覆盖本页的 16.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "16.5",
			en: {
				text: "Rex seems to know things that he shouldn't know. Perhaps he can provide useful information. Either A ask Rex if he knows your Father, or B ask Rex what he knows about the Lodge.",
				choices: [{
					key: "a",
					text: "“I've heard of him in financial circles. Big, rich businessman, right?” Cover 16.5 on this page with a progress sticker."
				}, {
					key: "b",
					text: "You see a flash of alarm in his face, but he quickly hides it. “I suggest you stay away from them.” Cover 16.5 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "雷克斯似乎知道一些他不该知道的事。也许他能提供有用的信息。选择 A 问雷克斯是否认识你的父亲，或 B 问雷克斯对小屋知道些什么。",
				choices: [{
					key: "a",
					text: "「我在金融圈听过他。又高大又有钱的商人，对吧？」用进度贴纸覆盖本页的 16.5。"
				}, {
					key: "b",
					text: "你看到他脸上闪过一丝惊慌，但他很快掩饰住了。「我建议你离他们远一点。」用进度贴纸覆盖本页的 16.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "16.6",
			en: {
				text: "You decide to learn about Rex in a more subtle way. Either ask him to help you A balance your bills, or B train for a karate tournament.",
				choices: [{
					key: "a",
					text: "He seems to be some sort of math wiz! Gain 2 gold and read 16.7."
				}, {
					key: "b",
					text: "“I can't help. I'm worthless in a fight.” Read 16.7."
				}]
			},
			zh: {
				text: "你决定用更委婉的方式了解雷克斯。选择请他帮你 A 核对账单，或 B 陪你为空手道比赛做训练。",
				choices: [{
					key: "a",
					text: "他似乎是某种数学天才！获得 2 枚金币，并阅读故事 16.7。"
				}, {
					key: "b",
					text: "「我帮不上忙。打架我一窍不通。」阅读故事 16.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "16.7",
			en: {
				text: "You know Rex is living a secret life, and you're ready to expose him. Cover 16.1 on the map with sticker 9C. Then guess that Rex is either A a Spy, B a Tax Agent, or C a Criminal. Read the matching effect in 9.9.",
				choices: [
					{
						key: "a",
						text: "Read 9.9"
					},
					{
						key: "b",
						text: "Read 9.9"
					},
					{
						key: "c",
						text: "Read 9.9"
					}
				]
			},
			zh: {
				text: "你知道雷克斯过着双重生活，也准备好揭穿他了。用贴纸 9C 覆盖地图上的 16.1 标记。然后猜测雷克斯是 A 间谍，B 税务员，或 C 罪犯，阅读故事 9.9 中对应的效果。",
				choices: [
					{
						key: "a",
						text: "阅读故事 9.9"
					},
					{
						key: "b",
						text: "阅读故事 9.9"
					},
					{
						key: "c",
						text: "阅读故事 9.9"
					}
				]
			}
		},
		{
			type: "entry",
			id: "16.8",
			en: {
				text: "You find another ore deposit, but you hear an eerie chittering sound up ahead. Gain 1 ore and cover 16.8 on card 35B with a heart sticker.",
				choices: []
			},
			zh: {
				text: "你又发现了一处矿藏，但前方传来一阵诡异的窸窣声。获得 1 份矿石，并用爱心贴纸覆盖图鉴牌 35B 上的 16.8。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "16.9",
			en: {
				text: "“Thanks fer lettin' me live here,” Bill says as he gives you a hand-written certificate with the words: “Official Best Friend.” You smile and thank him. “Flip it over!” he says. It was written on the back of an old bank bond. Gain 3 gold.",
				choices: []
			},
			zh: {
				text: "「多谢你让我住在这儿。」野比尔说着，递给你一张手写的证书，上面写着「官方最佳好友」。你笑着向他道谢。「翻过来看看！」他说。这字是写在一张旧银行债券背面的。获得 3 枚金币。",
				choices: []
			}
		}
	] },
	17: { blocks: [
		{
			type: "entry",
			id: "17.1",
			en: {
				text: "There still seems to be some ore here, so why was this mine abandoned? Gain 1 ore and cover 17.1 on card 35A with a heart sticker.",
				choices: []
			},
			zh: {
				text: "这里似乎还有矿石，那这座矿井为什么会被废弃？获得 1 份矿石，并用爱心贴纸覆盖图鉴牌 35A 上的 17.1。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.2",
			en: {
				text: "Is that a glint of gold? No, just a small brass key. That might be useful, though! Place 2 stickers on card 35A: a heart sticker covering 17.2 and a progress sticker (not a heart) covering the X.",
				choices: []
			},
			zh: {
				text: "那是金光一闪吗？不，只是一把小黄铜钥匙。不过也许用得上！在图鉴牌 35A 上放置 2 枚贴纸：一枚爱心贴纸覆盖 17.2，一枚进度贴纸（不是爱心）覆盖 X。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.3",
			en: {
				text: "You spy a broken minecart on the tracks up ahead. Either A search the cart, or B keep exploring.",
				choices: [{
					key: "a",
					text: "The cart is mostly empty, but there's something heavy at the bottom. Gain 1 ore and cover 17.3 on card 35A with a heart sticker."
				}, {
					key: "b",
					text: "Cover 17.3 on card 35A with a heart sticker. Perform another action."
				}]
			},
			zh: {
				text: "你发现前方轨道上有一辆损坏的矿车。选择 A 搜一搜矿车，或 B 继续探索。",
				choices: [{
					key: "a",
					text: "矿车几乎是空的，但底部有什么沉重的东西。获得 1 份矿石，并用爱心贴纸覆盖图鉴牌 35A 上的 17.3。"
				}, {
					key: "b",
					text: "用爱心贴纸覆盖图鉴牌 35A 上的 17.3，然后额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "17.4",
			en: {
				text: "Raw gold? This mine is gonna make you rich! Gain 1 gold and cover 17.4 on card 35A with a heart sticker.",
				choices: []
			},
			zh: {
				text: "原生金块？这座矿井要让你发财了！获得 1 枚金币，并用爱心贴纸覆盖图鉴牌 35A 上的 17.4。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.5",
			en: {
				text: "Your research warns you about a spider infestation that drove the miners off. It also tells you of a secret passage to avoid one of their nests. Cover 17.6 on card 35B with a heart sticker.",
				choices: []
			},
			zh: {
				text: "你的研究提醒你，这里曾有蜘蛛泛滥，把矿工都赶走了。研究还提到一条能避开其中一处蛛巢的秘密通道。用爱心贴纸覆盖图鉴牌 35B 上的 17.6。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.6",
			en: {
				text: "You see the shape of a huge spider crawl into view. It's the size of a cat! Maybe you shouldn't go this way? Either A turn back, or B try to sneak past the spider.",
				choices: [{
					key: "a",
					text: "Maybe there's another path? Perform another action."
				}, {
					key: "b",
					text: "You try to sneak past the spider, but it springs forward and sinks its fangs into your leg. You kick the creature away, and it disappears into the darkness. Cover 17.6 on card 35B with a heart sticker. Gain the Poisoned milestone (red) unless you have the Miracle Medicine milestone."
				}]
			},
			zh: {
				text: "你看见一只巨大蜘蛛的身影爬进视野。它有猫那么大！也许你该换条路？选择 A 原路返回，或 B 试着从蜘蛛旁边悄悄溜过去。",
				choices: [{
					key: "a",
					text: "也许还有别的路？额外行动一次。"
				}, {
					key: "b",
					text: "你想从蜘蛛旁边溜过去，它却猛地扑来，毒牙扎进你的腿。你把那东西踢开，它消失在黑暗里。用爱心贴纸覆盖图鉴牌 35B 上的 17.6。获得「中毒」（红色）里程碑，除非你已有「灵丹妙药」里程碑。"
				}]
			}
		},
		{
			type: "entry",
			id: "17.7",
			en: {
				text: "At first it appears to be a dead end, but then you see a gaping hole in the floor. An old rope ladder leads deeper into the darkness. Place 2 heart stickers on card 35B: one covering 17.7 and one covering the X.",
				choices: []
			},
			zh: {
				text: "起初像是死路，但你随后发现地板上有一个大洞。一架老旧的绳梯通向更深的黑暗。在图鉴牌 35B 上放置 2 枚爱心贴纸：一枚覆盖 17.7，一枚覆盖 X。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.8",
			en: {
				text: "You find a gold nugget on the floor, and as you're bending over, you feel a soft breeze coming from a hidden opening in the wall. A secret passage! Gain 1 gold, then place 2 heart stickers on card 35B: one covering 17.8 and one covering 17.6 (if able).",
				choices: []
			},
			zh: {
				text: "你在地板上发现一块金块，弯腰时又感到一阵微风从墙上的隐蔽开口吹来。一条秘密通道！获得 1 枚金币，然后在图鉴牌 35B 上放置 2 枚爱心贴纸：一枚覆盖 17.8，一枚覆盖 17.6（如果可以）。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.9",
			en: {
				text: "You hear a low growling sound, but luckily it's just your stomach. Cover 17.9 on card 35B with a heart sticker. You may spend 1 food to perform another action.",
				choices: []
			},
			zh: {
				text: "你听见低沉的咕噜声，幸好那只是你的肚子。用爱心贴纸覆盖图鉴牌 35B 上的 17.9。你可以花费 1 份食物，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.10",
			en: {
				text: "Another dead end? Well, at least there is some ore here! Gain 1 ore and cover 17.10 on card 35B with a heart sticker.",
				choices: []
			},
			zh: {
				text: "又是一条死路？好吧，至少这里有点矿石！获得 1 份矿石，并用爱心贴纸覆盖图鉴牌 35B 上的 17.10。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "17.11",
			en: {
				text: "Your torch is about to go out unless you have something else to burn. Cover 17.11 on card 35B with a heart sticker. You may spend 1 wood to read 16.8.",
				choices: []
			},
			zh: {
				text: "你的火把快熄灭了，除非你有别的东西可以烧。用爱心贴纸覆盖图鉴牌 35B 上的 17.11。你可以花费 1 份木材，阅读故事 16.8。",
				choices: []
			}
		}
	] },
	18: { blocks: [
		{
			type: "entry",
			id: "18.1",
			en: {
				text: "The nest is nearly 10 feet wide, spun from milky white strands. You see at least 5 large spiders, each the size of a bulldog, sleeping in it. Wait, do spiders sleep? Just in front of them you spy a temptingly large deposit of gold and ore. If you have the Poisoned milestone, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Your swollen leg nearly gives out, and you are only able to escape with some of the treasure. Discard card 35B. Then gain 1 ore, 1 gold, and the Explorer milestone (silver)."
				}, {
					key: "b",
					text: "You throw a few stones to distract the spiders, then blitz past them like an Olympic athlete. After a dodge and a couple of rolls, you escape with the treasure. Discard card 35B. Then gain 1 ore, 3 gold, and the Adventurer milestone (gold)."
				}]
			},
			zh: {
				text: "蛛巢足有 10 英尺宽，由乳白色的丝线织成。你至少看到 5 只大蜘蛛睡在里面，每只都有斗牛犬那么大。等等，蜘蛛会睡觉吗？就在它们跟前，你发现了一大片诱人的金子和矿石。如果你有「中毒」里程碑，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "你肿胀的腿几乎撑不住，只带着一部分宝藏逃了出来。弃掉图鉴牌 35B，然后获得 1 份矿石、1 枚金币和「探险家」里程碑（银色）。"
				}, {
					key: "b",
					text: "你扔出几块石头引开蜘蛛，然后像奥运选手一样冲了过去。一番闪避和翻滚之后，你带着宝藏逃了出来。弃掉图鉴牌 35B，然后获得 1 份矿石、3 枚金币和「冒险家」里程碑（金色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "18.2",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "18.3",
			en: {
				text: "“Just like old times, huh? You and me, doin' whatever we want! You should spend less time with chores and RELAX a little. Let's have ourselves a private feast and get stuffed!” Either A say, “I've got work to do,” or B spend 1 food to say, “Let's eat!”",
				choices: [{
					key: "a",
					text: "Cover 18.3 on this page with a progress sticker. Then perform another action."
				}, {
					key: "b",
					text: "You eat meats and pies until you can hardly move. It. Is. Glorious. Cover both 18.3 and 18.4 on this page with heart stickers."
				}]
			},
			zh: {
				text: "「就像从前一样，对吧？你和我，想干什么就干什么！你该少干点家务，好好放松一下。咱们来办一场私人盛宴，吃个痛快！」选择 A 说「我还有活要干」，或 B 花费 1 份食物说「开吃吧！」",
				choices: [{
					key: "a",
					text: "用进度贴纸覆盖本页的 18.3，然后额外行动一次。"
				}, {
					key: "b",
					text: "你大口吃着肉和派，直到几乎动弹不得。这。真。是。太棒了。用爱心贴纸覆盖本页的 18.3 和 18.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "18.4",
			en: {
				text: "Jessie claps you on the back. “Remember that one time when we painted the front of our house purple? Daddy was soo angry! We should do it to one of your neighbors. Maybe polka dots this time?” Either A pull the prank, or B find an excuse not to.",
				choices: [{
					key: "a",
					text: "“This is gonna be hilarious!” Cover 18.4 on this page with a heart sticker. Then cover a resident's house with sticker 11E. Place 1 upset sticker on a resident in that house."
				}, {
					key: "b",
					text: "She calls you a chicken, but at least you're setting a good example. Cover 18.4 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "杰西拍拍你的背。「还记得那次我们把自家房子正面刷成紫色吗？爸爸气坏了！我们该对你哪个邻居也来一次。这次也许可以刷波点？」选择 A 干这一票恶作剧，或 B 找个借口推掉。",
				choices: [{
					key: "a",
					text: "「这下肯定好玩！」用爱心贴纸覆盖本页的 18.4。然后用贴纸 11E 覆盖一位居民的房屋，并在那栋房子里的居民身上放置 1 枚不满贴纸。"
				}, {
					key: "b",
					text: "她说你是胆小鬼，但至少你树立了好榜样。用进度贴纸覆盖本页的 18.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "18.5",
			en: {
				text: "“You know that cows sleep standing up, right? Well, let's sneak into the field in the middle of the night and tip one over. You've not lived until you've been cow tipping!” Either A pull the prank, or B find an excuse not to.",
				choices: [{
					key: "a",
					text: "“That was hilarious! I've never heard a surprised MOO before.” Read 18.6."
				}, {
					key: "b",
					text: "Cover 18.5 on this page with a progress sticker. Then read 18.6."
				}]
			},
			zh: {
				text: "「你知道牛是站着睡觉的吧？那咱们半夜溜进牧场，推倒一头。没玩过推牛，你就不算活过！」选择 A 干这一票恶作剧，或 B 找个借口推掉。",
				choices: [{
					key: "a",
					text: "「太好玩了！我从没听过牛发出那么吃惊的『哞』声。」阅读故事 18.6。"
				}, {
					key: "b",
					text: "用进度贴纸覆盖本页的 18.5，然后阅读故事 18.6。"
				}]
			}
		},
		{
			type: "entry",
			id: "18.6",
			en: {
				text: "Cover 18.2 on the map with sticker 9C. If 2 or more progress stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Ya know,” Jessie says, “I'm not as lazy as everyone says. I can, like… do things.” Gain the Upstanding milestone (silver)."
				}, {
					key: "b",
					text: "“The Trouble Squad is back, baby!” Gain the Degenerate milestone (red) and 1 happiness."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 18.2 标记。如果本页有 2 枚或更多进度贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「你知道吗，」杰西说，「我没大家说的那么懒。我也能……做点事的。」获得「正直者」里程碑（银色）。"
				}, {
					key: "b",
					text: "「麻烦小队又回来了，宝贝！」获得「堕落者」里程碑（红色）和 1 点心情。"
				}]
			}
		},
		{
			type: "entry",
			id: "18.7",
			en: {
				text: "Your shelter has 2 main purposes: rescuing abused animals and helping them find a forever home. If you have the Pet Lover milestone, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "You find a cat eating out of a garbage can, its fur muddy and matted. After a few days at the rescue center, it seems much happier. Cover the Pet Lover milestone with Pet Rescuer (gold)."
				}, {
					key: "b",
					text: "Your neighbor was planning to buy a new pet, but you instead convince them to adopt an elderly rescue named Bosco. Cover 18.7 on the map with sticker 9C. Then place 1 pet sticker 11G."
				}]
			},
			zh: {
				text: "你的收容所有两个主要用途：救助受虐待的动物，帮它们找到永远的家。如果你有「宠物爱好者」里程碑，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "你发现一只猫在垃圾桶里翻东西吃，皮毛又脏又打结。在救助中心住了几天后，它看起来开心多了。用「宠物救助者」（金色）覆盖「宠物爱好者」里程碑。"
				}, {
					key: "b",
					text: "你的邻居本来打算买一只新宠物，但你说服对方收养了一只名叫博斯科的老年救助动物。用贴纸 9C 覆盖地图上的 18.7 标记，然后放置 1 枚宠物贴纸 11G。"
				}]
			}
		}
	] },
	19: { blocks: [
		{
			type: "entry",
			id: "19.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "19.2",
			en: {
				text: "“I get all my ore from the quarry now. After the incident, it's best to stay away from the mine.” Either ask A “What incident?” or B “What quarry?”",
				choices: [{
					key: "a",
					text: "“The last miner that went in never returned. They say it's haunted.” Cover 19.2 on this page with a heart sticker."
				}, {
					key: "b",
					text: "Bob shows you the quarry. Cover 19.2 on this page with a heart sticker. Then place sticker 7G."
				}]
			},
			zh: {
				text: "「我现在所有矿石都从采石场来。出了那件事之后，最好离矿井远一点。」你可以问 A「出了什么事？」，或 B「什么采石场？」",
				choices: [{
					key: "a",
					text: "「上一个进去的矿工再也没回来。他们都说那儿闹鬼。」用爱心贴纸覆盖本页的 19.2。"
				}, {
					key: "b",
					text: "鲍勃带你参观了采石场。用爱心贴纸覆盖本页的 19.2，然后放置贴纸 7G。"
				}]
			}
		},
		{
			type: "entry",
			id: "19.3",
			en: {
				text: "“I can get you some ore, if you're willing to pay for the work.” Either A spend 1 gold to pay Bob, or B mine it yourself.",
				choices: [{
					key: "a",
					text: "“Much obliged!” Gain 1 ore and cover 19.3 on this page with a heart sticker."
				}, {
					key: "b",
					text: "You are dripping with sweat, but it's better than spending money! Gain 1 ore and lose 2 food (if able). Then cover 19.3 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "「只要你肯付工钱，我就能给你弄到一些矿石。」你可以 A 花费 1 枚金币付给鲍勃，或 B 自己动手开采。",
				choices: [{
					key: "a",
					text: "「多谢！」获得 1 枚矿石，并用爱心贴纸覆盖本页的 19.3。"
				}, {
					key: "b",
					text: "你累得满头大汗，但总比花钱强！获得 1 枚矿石并失去 2 份食物（如果可以）。然后用爱心贴纸覆盖本页的 19.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "19.4",
			en: {
				text: "Heavy rain, slippery rocks, and a pickaxe. Mix these 3 ingredients and what do you get? A broken ankle. Poor Bob. Either A tell him to get well soon, or B spend 1 gold to buy him some crutches.",
				choices: [{
					key: "a",
					text: "“Thank you. The doctor said I should try to get some rest.” Cover 19.4 on this page with a heart sticker."
				}, {
					key: "b",
					text: "“That is so kind of you!” Gain 1 happiness and cover 19.4 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "大雨、湿滑的岩石，再加一把镐。把这 3 样凑在一起会得到什么？一只扭伤的脚踝。可怜的鲍勃。你可以 A 祝他早日康复，或 B 花费 1 枚金币给他买一副拐杖。",
				choices: [{
					key: "a",
					text: "「谢谢你。医生说我该好好休息一阵。」用爱心贴纸覆盖本页的 19.4。"
				}, {
					key: "b",
					text: "「你真是太好了！」获得 1 点心情，并用爱心贴纸覆盖本页的 19.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "19.5",
			en: {
				text: "Bob is back on his feet, and he has news! “I found dinosaur bones... I think. Quick, come see!” You arrive at the dig site and see a femur bone almost as tall as you. Either say A “Stop digging, lets call an expert,” or B “Keep mining; don't worry about that silly old bone!”",
				choices: [{
					key: "a",
					text: "The paleontologist should be here in a few days. Cover 19.5 on this page with a heart sticker."
				}, {
					key: "b",
					text: "“You got it, boss!” Gain 1 ore and cover 19.1 on the map with sticker 9D."
				}]
			},
			zh: {
				text: "鲍勃重新站起来了，而且他有大新闻！「我发现了恐龙骨头……我想是。快来看看！」你来到挖掘现场，看到一根几乎和你一样高的股骨。你可以说 A「别挖了，我们叫个专家来」，或 B「继续挖；别管那根无聊的老骨头！」",
				choices: [{
					key: "a",
					text: "古生物学家过几天就该到了。用爱心贴纸覆盖本页的 19.5。"
				}, {
					key: "b",
					text: "「遵命，老板！」获得 1 枚矿石，并用贴纸 9D 覆盖地图上的 19.1 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "19.6",
			en: {
				text: "“I'm Dr. Beckman. Nice to meet you.” The paleontologist has a stern face and round glasses. “Hmm, yes, it does appear to be a fossil. I can excavate it, but I'm afraid you must stop mining here.” Cover 19.1 on the map with sticker 9D. Either A agree to stop, or B keep mining.",
				choices: [{
					key: "a",
					text: "After weeks of careful digging, Dr. Beckman informs you that she's found a previously undiscovered species of dinosaur. “We're calling it Deciduous Beckmaneous.” Gain the Paleontologist milestone (silver)."
				}, {
					key: "b",
					text: "“You're destroying history!” she pleads, but you stay focused on those lovely, metallic rocks. Gain 1 ore."
				}]
			},
			zh: {
				text: "「我是贝克曼博士。很高兴认识你。」这位古生物学家神情严肃，戴着圆框眼镜。「嗯，是的，看来确实是一块化石。我可以把它发掘出来，但恐怕你们必须停止在这里开采。」用贴纸 9D 覆盖地图上的 19.1 标记。你可以 A 同意停工，或 B 继续开采。",
				choices: [{
					key: "a",
					text: "经过数周的仔细发掘，贝克曼博士告诉你，她发现了一个此前未被发现的恐龙物种。「我们把它命名为『落叶贝克曼龙』。」获得「古生物学家」里程碑（银色）。"
				}, {
					key: "b",
					text: "「你们这是在毁掉历史！」她恳求道，但你的注意力全在那些可爱的金属矿石上。获得 1 枚矿石。"
				}]
			}
		},
		{
			type: "entry",
			id: "19.7",
			en: {
				text: "Read the hint below. If you solve the puzzle, gain the card number shown.\nThere's only 1 way to match the flowers and not overlap stickers.\nIf you need an additional hint, spend 1 gold to read 23.8.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，获得所示的卡牌编号。\n只有 1 种摆法能让花朵一一对应，而且不叠放贴纸。\n如果你需要额外提示，花费 1 枚金币阅读故事 23.8。",
				choices: []
			}
		}
	] },
	20: { blocks: [
		{
			type: "entry",
			id: "20.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "20.2",
			en: {
				text: "“Welcome, curious soul! Have you come to buy a painting?” Either A say, “No thank you,” or B spend 1 gold to buy a painting.",
				choices: [{
					key: "a",
					text: "“Without art, the heart withers.” Cover 20.2 on this page with a progress sticker. Then read 20.3."
				}, {
					key: "b",
					text: "“You now own a piece of me, spread over canvas for the world to see.” Cover 20.2 on this page with a heart sticker. Then place sticker 12M."
				}]
			},
			zh: {
				text: "「欢迎，好奇的灵魂！你是来买画的吗？」你可以 A 说「不用了，谢谢」，或 B 花费 1 枚金币买一幅画。",
				choices: [{
					key: "a",
					text: "「没有艺术，心灵就会枯萎。」用进度贴纸覆盖本页的 20.2，然后阅读故事 20.3。"
				}, {
					key: "b",
					text: "「现在你拥有我的一部分，它铺展在画布上，供世人观赏。」用爱心贴纸覆盖本页的 20.2，然后放置贴纸 12M。"
				}]
			}
		},
		{
			type: "entry",
			id: "20.3",
			en: {
				text: "“I'm looking for the perfect inspiration for my next project.” Either suggest A the mine, or B the river.",
				choices: [{
					key: "a",
					text: "“A doorway into the earth! Yes, I will try to capture its secrets with my brush.” Cover 20.3 on this page with a progress sticker."
				}, {
					key: "b",
					text: "“Water is full of beauty. Always in motion. But is it running AWAY from something or simply TOWARD the ocean? This is a mystery.” Cover both 20.3 and 20.4 on this page with progress stickers."
				}]
			},
			zh: {
				text: "「我在为下一个作品寻找完美的灵感。」你可以建议 A 矿井，或 B 河流。",
				choices: [{
					key: "a",
					text: "「通往大地深处的一扇门！好，我要用画笔捕捉它的秘密。」用进度贴纸覆盖本页的 20.3。"
				}, {
					key: "b",
					text: "「水充满美感，永远在流动。可它究竟是在逃离什么，还是仅仅奔向大海？这是个谜。」用进度贴纸覆盖本页的 20.3 和 20.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "20.4",
			en: {
				text: "You find Elise's easel outside the mouth of the cave. But where is she? “Up here!” she calls from on top of the shed. “There is too much darkness inside, and I dare not paint it. I thought maybe I'd be safer up here.” Either A laugh, or B help her down.",
				choices: [{
					key: "a",
					text: "“I see a darkness in you, too,” she says. Cover both 20.4 and 20.5 on this page with progress stickers."
				}, {
					key: "b",
					text: "“Thank you, brave soul!” Place 2 stickers on this page: a heart sticker covering 20.4 and a progress sticker covering 20.5."
				}]
			},
			zh: {
				text: "你在洞口外发现了伊莉丝的画架。可她人在哪儿？「我在上面！」她从棚屋顶上喊道。「里面太暗了，我不敢进去画。我想待在上面也许更安全些。」你可以 A 笑出声，或 B 帮她下来。",
				choices: [{
					key: "a",
					text: "「我在你身上也看到了一片黑暗。」她说。用进度贴纸覆盖本页的 20.4 和 20.5。"
				}, {
					key: "b",
					text: "「谢谢你，勇敢的人！」在本页放置 2 枚贴纸：1 枚爱心贴纸覆盖 20.4，1 枚进度贴纸覆盖 20.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "20.5",
			en: {
				text: "“Do you think I captured the river's essence?” Elise asks. You look at the painting, and to your untrained eye, it looks really bad. There isn't even any blue in it! Either A compliment the painting, or B find an excuse to leave quickly.",
				choices: [{
					key: "a",
					text: "“I tricked you! This painting is entitled Nature's Overcoat; inspired by the leaves and bark. Thanks for being kind, though.” Cover 20.5 on this page with a heart sticker."
				}, {
					key: "b",
					text: "“Oh... I see.” Cover 20.5 on this page with a progress sticker. Perform another action."
				}]
			},
			zh: {
				text: "「你觉得我捕捉到河流的精髓了吗？」伊莉丝问。你看着那幅画，以你未经训练的眼光看，它真的很难看。里面连一点蓝色都没有！你可以 A 称赞这幅画，或 B 找个借口赶紧离开。",
				choices: [{
					key: "a",
					text: "「我骗到你了！这幅画叫《自然的外套》，灵感来自树叶和树皮。不过还是谢谢你的好意。」用爱心贴纸覆盖本页的 20.5。"
				}, {
					key: "b",
					text: "「哦……我明白了。」用进度贴纸覆盖本页的 20.5，然后额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "20.6",
			en: {
				text: "“Oh, sadness! My oil paints run dry, my brushes splinter, and fortune eludes me. Please! Fund my art so I can paint the town with smiles!” Either A spend 1 gold to buy art supplies, or B give Elise a pen.",
				choices: [{
					key: "a",
					text: "Cover 20.6 on this page with a heart sticker. Then, if 2 or more heart stickers on this page, gain the Kind milestone (silver)."
				}, {
					key: "b",
					text: "“Ink! Ink can be my new paint!” Cover 20.6 on this page with a progress sticker. Then, if 2 or more heart stickers on this page, gain the Kind milestone (silver)."
				}]
			},
			zh: {
				text: "「唉，好惨！我的油画颜料干了，画笔裂了，好运也总躲着我。求求你！资助我的艺术吧，让我用笑容画满整个小镇！」你可以 A 花费 1 枚金币买美术用品，或 B 送给伊莉丝一支钢笔。",
				choices: [{
					key: "a",
					text: "用爱心贴纸覆盖本页的 20.6。然后，如果本页有 2 枚或更多爱心贴纸，获得「善良」里程碑（银色）。"
				}, {
					key: "b",
					text: "「墨水！墨水可以当我的新颜料！」用进度贴纸覆盖本页的 20.6。然后，如果本页有 2 枚或更多爱心贴纸，获得「善良」里程碑（银色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "20.7",
			en: {
				text: "Cover 20.1 on the map with sticker 9D. “I am working on my masterpiece,” Elise says. “The culmination of my life's work. It will never be truly done, but also, it is done now.” Either say A “Looks finished to me,” or B “No rush, I can wait.”",
				choices: [{
					key: "a",
					text: "“Alas, you are right. This is all it will ever be.” Place sticker 12N."
				}, {
					key: "b",
					text: "“Yes, art cannot be rushed. I will start over for the fifth time.” Gain card 43."
				}]
			},
			zh: {
				text: "用贴纸 9D 覆盖地图上的 20.1 标记。「我正在创作我的杰作，」伊莉丝说。「我一生的心血结晶。它永远不会真正完成，但话说回来，它现在也算完成了。」你可以说 A「在我看来已经完成了」，或 B「不急，我可以等」。",
				choices: [{
					key: "a",
					text: "「唉，你说得对。它永远就只能是这个样子了。」放置贴纸 12N。"
				}, {
					key: "b",
					text: "「对，艺术不能被催促。我要从第五遍重新开始。」获得图鉴牌 43。"
				}]
			}
		}
	] },
	21: { blocks: [
		{
			type: "entry",
			id: "21.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "21.2",
			en: {
				text: "“There are two main philosophies when it comes to teaching. We can focus on challenging work with heavy testing, or we can encourage learning with fun activities. What do you think?” Either choose to focus on A tests, or B fun.",
				choices: [{
					key: "a",
					text: "Cover both 21.2 and 21.3 on this page with progress stickers."
				}, {
					key: "b",
					text: "Cover 21.2 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "「说到教学，主要有两种理念。我们可以偏重有难度、测验繁重的功课，也可以用有趣的活动鼓励学习。你怎么看？」你可以选择侧重 A 测验，或 B 趣味。",
				choices: [{
					key: "a",
					text: "用进度贴纸覆盖本页的 21.2 和 21.3。"
				}, {
					key: "b",
					text: "用爱心贴纸覆盖本页的 21.2。"
				}]
			}
		},
		{
			type: "entry",
			id: "21.3",
			en: {
				text: "You stop by the school to see how things are going. Two children chase each other around the building while a third is climbing the roof. This is getting out of control! Either A ask the teacher for clarity, or B reprimand the kids.",
				choices: [{
					key: "a",
					text: "“Beth and Ryan are training to be Olympic runners,” she says, “and Jimmy is on the roof learning how to install shingles. He wants to be a carpenter. We're letting them follow their passions.” Cover both 21.3 and 21.4 on this page with heart stickers."
				}, {
					key: "b",
					text: "“It sounds like you don't like this teaching style. Ok, your call. We'll move our focus to books and tests.” Cover 21.3 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "你顺路去学校看看情况。两个孩子绕着教学楼互相追逐，还有一个正在爬屋顶。这越来越失控了！你可以 A 向老师问个明白，或 B 训斥这些孩子。",
				choices: [{
					key: "a",
					text: "「贝丝和瑞安正在为参加奥运会赛跑而训练，」她说，「吉米在屋顶上学铺瓦片，他想当木匠。我们让他们追随自己的热情。」用爱心贴纸覆盖本页的 21.3 和 21.4。"
				}, {
					key: "b",
					text: "「听起来你不喜欢这种教学方式。好吧，你说了算。我们会把重心转到书本和测验上。」用进度贴纸覆盖本页的 21.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "21.4",
			en: {
				text: "The children sit silently at their desks, noses buried in math textbooks. The only sounds are the scribbling of pencil on paper as they solve equations. They look miserable. Either A give the teacher a nod of approval, or B add more hands-on activities.",
				choices: [{
					key: "a",
					text: "A smart child is neither seen nor heard. At least, that's what Father used to say. Cover both 21.4 and 21.5 on this page with progress stickers."
				}, {
					key: "b",
					text: "“I want the kids to be excited about learning,” you tell Mrs. Connors before turning to the kids. “Who wants to learn science by watching a pumpkin explode?” Cover 21.4 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "孩子们安静地坐在课桌前，埋头看数学课本。唯一的声响是他们解方程时铅笔划过纸面的沙沙声。他们看起来痛苦极了。你可以 A 向老师点头赞许，或 B 增加更多动手活动。",
				choices: [{
					key: "a",
					text: "聪明的孩子既不出声，也不露面。至少父亲以前是这么说的。用进度贴纸覆盖本页的 21.4 和 21.5。"
				}, {
					key: "b",
					text: "「我希望孩子们对学习充满热情，」你对康纳斯太太说，然后转向孩子们。「谁想通过看南瓜爆炸来学科学？」用爱心贴纸覆盖本页的 21.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "21.5",
			en: {
				text: "“312 times 783 equals 244,296,” the little girl says. “Very good, Veronica!” Mrs. Connors says. “But please stop interrupting gym class.” Either A reprimand the teacher, or B hand Veronica a dodge ball.",
				choices: [{
					key: "a",
					text: "“Mrs. Connors,” you say, “I think you should encourage her interest in math.” Cover 21.5 on this page with a progress sticker."
				}, {
					key: "b",
					text: "She takes the ball and grins mischievously. Cover both 21.5 and 21.6 on this page with heart stickers."
				}]
			},
			zh: {
				text: "「312 乘 783 等于 244,296。」小女孩说。「很好，维罗妮卡！」康纳斯太太说，「但请不要打断体育课。」你可以 A 训斥老师，或 B 递给维罗妮卡一个躲避球。",
				choices: [{
					key: "a",
					text: "「康纳斯太太，」你说，「我觉得你应该鼓励她对数学的兴趣。」用进度贴纸覆盖本页的 21.5。"
				}, {
					key: "b",
					text: "她接过球，调皮地咧嘴一笑。用爱心贴纸覆盖本页的 21.5 和 21.6。"
				}]
			}
		},
		{
			type: "entry",
			id: "21.6",
			en: {
				text: "The little girl says each letter, one at a time: “B-O-U-R-G-E-O-I-S.” Mrs. Connors smiles. “Very good, Veronica; that IS how you spell bourgeois. You just won the spelling bee!” Either A give silent approval, or B applaud.",
				choices: [{
					key: "a",
					text: "She met your expectations. No need for celebration. Read 21.7."
				}, {
					key: "b",
					text: "Veronica smiles. A rare sight indeed. Cover 21.6 on this page with a heart sticker, then read 21.7."
				}]
			},
			zh: {
				text: "小女孩一个字母一个字母地念道：「B-O-U-R-G-E-O-I-S。」康纳斯太太笑了。「很好，维罗妮卡，『bourgeois』就是这么拼的。你刚刚赢得了拼字比赛！」你可以 A 默默认可，或 B 鼓掌。",
				choices: [{
					key: "a",
					text: "她达到了你的期望，无须庆祝。阅读故事 21.7。"
				}, {
					key: "b",
					text: "维罗妮卡笑了，这可是难得一见的景象。用爱心贴纸覆盖本页的 21.6，然后阅读故事 21.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "21.7",
			en: {
				text: "Cover 21.1 on the map with sticker 9C. If 3 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "These kids love school, and you can tell that they will enjoy learning for the rest of their lives. Gain 1 happiness."
				}, {
					key: "b",
					text: "You know that one of these kids will be the next Albert Einstein or Marie Curie. Gain the Little Genius milestone (silver)."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 21.1 标记。如果本页有 3 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "这些孩子热爱学校，你能看出他们一生都会享受学习。获得 1 点心情。"
				}, {
					key: "b",
					text: "你知道这些孩子里有一个会成为下一个阿尔伯特·爱因斯坦或玛丽·居里。获得「小天才」里程碑（银色）。"
				}]
			}
		}
	] },
	22: { blocks: [
		{
			type: "entry",
			id: "22.1",
			en: {
				text: "“It's not quite finished, but I'm happy to give you a sneak peak if you... AHEM.” He holds out an open hand. Either A give him 1 gold, or B say, “No thanks.”",
				choices: [{
					key: "a",
					text: "Gain card 4."
				}, {
					key: "b",
					text: "“You should come back later.” Perform another action."
				}]
			},
			zh: {
				text: "「还没完全弄好，不过要是你……咳咳，我很乐意让你先睹为快。」他摊开手掌。你可以 A 给他 1 枚金币，或 B 说「不用了，谢谢」。",
				choices: [{
					key: "a",
					text: "获得图鉴牌 4。"
				}, {
					key: "b",
					text: "「你过些时候再来吧。」额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.2",
			en: {
				text: "Cover 22.2 on the map with sticker 9C. If a heart sticker is covering 23.3 on the next page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“We're expecting a baby!” she says. “Unfortunately, my husband wasted our money on his brother's silly hat idea.” Place 2 stickers near this resident: an upset sticker and a baby sticker 11P."
				}, {
					key: "b",
					text: "“We're expecting a baby!” she smiles excitedly. Place a baby sticker 11P on this resident."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 22.2 标记。如果下一页的 23.3 被爱心贴纸覆盖，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「我们要有宝宝了！」她说。「可惜我丈夫把我们的钱都砸在他兄弟那个傻帽子点子上去了。」在这位居民附近放置 2 枚贴纸：1 枚不满贴纸和 1 枚婴儿贴纸 11P。"
				}, {
					key: "b",
					text: "「我们要有宝宝了！」她兴奋地笑着说。在这位居民身上放置 1 枚婴儿贴纸 11P。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.3",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "22.4",
			en: {
				text: "“Guess what?! I... um... FOUND some money!” Jessie says. Either A let her keep the money, or B give it back to your neighbor.",
				choices: [{
					key: "a",
					text: "“Here's your cut!” Gain 1 gold and cover 22.4 on this page with a heart sticker."
				}, {
					key: "b",
					text: "Your neighbor thanks you. Cover 22.4 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「你猜怎么着？！我……呃……捡到钱了！」杰西说。你可以 A 让她留着这笔钱，或 B 把钱还给邻居。",
				choices: [{
					key: "a",
					text: "「这是你那份！」获得 1 枚金币，并用爱心贴纸覆盖本页的 22.4。"
				}, {
					key: "b",
					text: "邻居向你道谢。用进度贴纸覆盖本页的 22.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.5",
			en: {
				text: "“Let's steal your neighbor's shoes and throw them in the well!” Either A pull the prank, or B find an excuse not to do it.",
				choices: [{
					key: "a",
					text: "“That was awesome! Lets go find some more stuff to throw down the well!” Place 2 stickers: a heart sticker covering 22.5 on this page and an upset sticker on the map near a resident that isn't upset."
				}, {
					key: "b",
					text: "It feels good to stand up to Jessie. Cover 22.5 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「我们去偷邻居的鞋子，扔到井里吧！」你可以 A 照做这个恶作剧，或 B 找个借口不去。",
				choices: [{
					key: "a",
					text: "「太棒了！我们再找点别的东西扔进井里！」放置 2 枚贴纸：1 枚爱心贴纸覆盖本页的 22.5，以及 1 枚不满贴纸放在地图上没有不满的居民附近。"
				}, {
					key: "b",
					text: "拒绝杰西的感觉真好。用进度贴纸覆盖本页的 22.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.6",
			en: {
				text: "“I'm so tired of using the outhouse! You're in charge, so why aren't we living a life of luxury?” Either A live humbly, or B spend 1 gold to treat yourself.",
				choices: [{
					key: "a",
					text: "“I HATE this place. The toilet gave me a splinter!” Cover 22.6 on this page with a progress sticker. Then read 22.7."
				}, {
					key: "b",
					text: "“A solid gold toilet? I love it!” Read 22.7."
				}]
			},
			zh: {
				text: "「我真是受够用茅房了！你当家作主，我们怎么还过不上奢侈的日子？」你可以 A 简朴度日，或 B 花费 1 枚金币犒劳自己。",
				choices: [{
					key: "a",
					text: "「我讨厌这个地方。马桶给我扎了根木刺！」用进度贴纸覆盖本页的 22.6，然后阅读故事 22.7。"
				}, {
					key: "b",
					text: "「纯金马桶？我喜欢！」阅读故事 22.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.7",
			en: {
				text: "Cover 22.3 on the map with sticker 9C. If 2 or more progress stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Jessie pouts and crosses her arms. “Soo... this is my life now, huh? I guess it's not THAT bad.” Gain the Upstanding milestone (silver)."
				}, {
					key: "b",
					text: "“Welcome back to the dark side.” Gain the Degenerate milestone (red) and 1 happiness."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 22.3 标记。如果本页有 2 枚或更多进度贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "杰西撅起嘴，抱起双臂。「所以……这就是我现在的生活了，是吧？我想也没那么糟。」获得「正直者」里程碑（银色）。"
				}, {
					key: "b",
					text: "「欢迎回到黑暗面。」获得「堕落者」里程碑（红色）和 1 点心情。"
				}]
			}
		},
		{
			type: "entry",
			id: "22.8",
			en: {
				text: "Taxes are an easy way to make free money. And the best part is that there are NO downsides! Place 1 heart sticker on this card (card 13 or 14). Then gain 1 gold for each sticker on the card. Then, if 3 stickers on it, discard it and gain card 51.",
				choices: []
			},
			zh: {
				text: "征税是白拿钱的好办法，而且最棒的是完全没有坏处！在此牌（图鉴牌 13 或 14）上放置 1 枚爱心贴纸，然后按此牌上的贴纸数量，每枚获得 1 枚金币。然后，如果此牌上有 3 枚贴纸，弃掉此牌并获得图鉴牌 51。",
				choices: []
			}
		}
	] },
	23: { blocks: [
		{
			type: "entry",
			id: "23.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "23.2",
			en: {
				text: "Zach Johnson is full of contagious energy. He's either a genius or a lunatic. “I'll tell you all about my idea, but first we need investors. What better choice than family?” Either A say, “I can't help,” or B spend 1 wood to build a house for his brother's family.",
				choices: [{
					key: "a",
					text: "“Come back if you change your mind!” Perform another action."
				}, {
					key: "b",
					text: "“Let's get to work.” Cover 23.2 on this page with a heart sticker. Then place sticker 7D."
				}]
			},
			zh: {
				text: "扎克·约翰逊浑身都是富有感染力的活力。他要么是天才，要么是疯子。「我会把这个点子全告诉你，但首先我们需要投资人。还有比家人更好的选择吗？」你可以 A 说「我帮不上忙」，或 B 花费 1 份木材为他兄弟一家盖一栋房子。",
				choices: [{
					key: "a",
					text: "「你改主意了就回来找我！」额外行动一次。"
				}, {
					key: "b",
					text: "「我们动手吧。」用爱心贴纸覆盖本页的 23.2，然后放置贴纸 7D。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.3",
			en: {
				text: "“So here's my invention: hats... but for animals! Isn't it brilliant?” He smiles widely. “Now, help me convince my brother to invest.” Either say A “Easy, this idea sells itself!” or B “I don't think so.”",
				choices: [{
					key: "a",
					text: "You persuade Zach's brother to invest. Cover 23.3 on this page with a heart sticker."
				}, {
					key: "b",
					text: "“It's a good idea, I promise!” Cover 23.3 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「我的发明是这样的：帽子……不过是给动物戴的！是不是很妙？」他咧开嘴笑。「现在，帮我劝我兄弟投资。」你可以说 A「简单，这主意自己就会卖出去！」，或 B「我不这么认为。」",
				choices: [{
					key: "a",
					text: "你说服了扎克的兄弟投资。用爱心贴纸覆盖本页的 23.3。"
				}, {
					key: "b",
					text: "「这是个好主意，我保证！」用进度贴纸覆盖本页的 23.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.4",
			en: {
				text: "“I need some money to create a business plan; can you help?” Either A say, “I'm broke,” or B spend 1 gold to say, “Of course!”",
				choices: [{
					key: "a",
					text: "“It's gonna be hard to sell this idea to investors.” Cover 23.4 on this page with a progress sticker. Then perform another action."
				}, {
					key: "b",
					text: "He writes a 100 page plan entitled Chicken Hats: The Road to One Million Buck Buck Bucks! Cover 23.4 on this page with a heart sticker. Then read 23.5."
				}]
			},
			zh: {
				text: "「我需要一些钱来做商业计划，你能帮忙吗？」你可以 A 说「我没钱」，或 B 花费 1 枚金币说「当然！」",
				choices: [{
					key: "a",
					text: "「要把这个点子卖给投资人恐怕很难。」用进度贴纸覆盖本页的 23.4，然后额外行动一次。"
				}, {
					key: "b",
					text: "他写了一份 100 页的计划，题为《鸡帽：通往百万喔喔币之路！》。用爱心贴纸覆盖本页的 23.4，然后阅读故事 23.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.5",
			en: {
				text: "If 3 heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“I can't wait to start selling my animal hats! Thanks for your support, partner.” Cover 23.1 on the map with sticker 9C. Then gain the Investment milestone (bronze)."
				}, {
					key: "b",
					text: "“I haven't found any investors yet.” You may spend 1 gold to invest (read option A). Otherwise, perform another action."
				}]
			},
			zh: {
				text: "如果本页有 3 枚爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「我迫不及待要开始卖我的动物帽子了！谢谢你的支持，合伙人。」用贴纸 9C 覆盖地图上的 23.1 标记，然后获得「投资」里程碑（铜色）。"
				}, {
					key: "b",
					text: "「我还没找到任何投资人。」你可以花费 1 枚金币投资（阅读选项 A）。否则，额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.6",
			en: {
				text: "Your sister Jessie really wants to live in this empty house. Either A let her live here for free, or B charge a reasonable fee.",
				choices: [{
					key: "a",
					text: "“Thank you, thank you, thank you!” Gain 1 happiness. Then remove the Jessie resident from the map and cover 23.6 on the map with sticker 7P."
				}, {
					key: "b",
					text: "“Fine! I'll pay.” Gain 2 gold. Then remove the Jessie resident from the map and cover 23.6 on the map with sticker 7P."
				}]
			},
			zh: {
				text: "你的妹妹杰西非常想住进这栋空房子。你可以 A 让她免费住在这里，或 B 收取合理的费用。",
				choices: [{
					key: "a",
					text: "「谢谢，谢谢，谢谢你！」获得 1 点心情。然后将杰西居民从地图上移除，并用贴纸 7P 覆盖地图上的 23.6 标记。"
				}, {
					key: "b",
					text: "「好吧！我付钱。」获得 2 枚金币。然后将杰西居民从地图上移除，并用贴纸 7P 覆盖地图上的 23.6 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.7",
			en: {
				text: "If you chose the Tent sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Finally, a place to live!” Place the Tent sticker on the map near this resident. Then cover 23.7 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“I can't live inside this!” Cover 23.7 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了帐篷贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「终于有个地方住了！」在这位居民附近的地图上放置帐篷贴纸，然后用爱心贴纸覆盖图鉴牌 47 上的 23.7。"
				}, {
					key: "b",
					text: "「我可没法住在这东西里面！」用所选礼物贴纸覆盖图鉴牌 47 上的 23.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "23.8",
			en: {
				text: "Read the hint below. If you solve the puzzle, gain the card number shown.\nPlace the sticker with the blue flowers in the bottom right corner (blue flowers covering the white flowers). Then place the other stickers with their flowers covering the flowers on the card. Does the maze now form a number?",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，获得所示的卡牌编号。\n将带有蓝色花朵的贴纸放在右下角（蓝色花朵覆盖白色花朵），然后将其他贴纸的花朵分别覆盖在卡牌上的花朵上。迷宫现在是否组成了一个数字？",
				choices: []
			}
		}
	] },
	24: { blocks: [
		{
			type: "entry",
			id: "24.1",
			en: {
				text: "If you chose the Saw sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Finally, a two-person saw!” Place the Saw sticker on the map near this resident. Then cover 24.1 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“We can't chop down trees with this!” Cover 24.1 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了锯子贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「终于有一把双人锯了！」在这位居民附近的地图上放置锯子贴纸，然后用爱心贴纸覆盖图鉴牌 47 上的 24.1。"
				}, {
					key: "b",
					text: "「这东西可砍不了树！」用所选礼物贴纸覆盖图鉴牌 47 上的 24.1。"
				}]
			}
		},
		{
			type: "entry",
			id: "24.2",
			en: {
				text: "If you chose the Canned Food sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Isn't this huge? I'm glad our factory's mail order service is working!” Place the Canned Food sticker on the map near this resident. Then cover 24.2 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“This isn't what I ordered!” Cover 24.2 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了罐头贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「这么大一罐？还好我们工厂的邮购服务管用！」在这位居民附近的地图上放置罐头贴纸，然后用爱心贴纸覆盖图鉴牌 47 上的 24.2。"
				}, {
					key: "b",
					text: "「这可不是我订的东西！」用所选礼物贴纸覆盖图鉴牌 47 上的 24.2。"
				}]
			}
		},
		{
			type: "entry",
			id: "24.3",
			en: {
				text: "You've found homes for the packages, but were they correct? Choose a resident on card 47 that has a heart sticker: You may remove an upset sticker from them on the map. If 2 or more heart stickers on this card, gain 1 happiness. Regardless, then discard card 47.",
				choices: []
			},
			zh: {
				text: "你已经为包裹找到了归宿，但它们送对了吗？在图鉴牌 47 上选择一位带有爱心贴纸的居民：你可以从地图上移除该居民身上的 1 枚不满贴纸。如果此牌上有 2 枚或更多爱心贴纸，获得 1 点心情。无论结果如何，然后弃掉图鉴牌 47。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "24.4",
			en: {
				text: "You plant the beans, and somehow, a berry bush grows! Berries from beans? They were magical. Place 1 bush sticker 1H.",
				choices: []
			},
			zh: {
				text: "你种下豆子，不知怎么的，长出了一丛浆果灌木！豆子结出浆果？它们真有魔力。放置 1 枚灌木贴纸 1H。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "24.5",
			en: {
				text: "You find Pierre's favorite recipe at the library. You may spend 1 food or 1 gold to cook it for him (discard the event without effect). Otherwise, you must read 24.6.",
				choices: []
			},
			zh: {
				text: "你在图书馆找到了皮埃尔最爱的食谱。你可以花费 1 份食物或 1 枚金币为他做这道菜（无效果地弃掉该事件牌）。否则，你必须阅读故事 24.6。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "24.6",
			en: {
				text: "“Staying here was worse than the time I had walking pneumonia,” Pierre says. “What a horrid vacation!” Lose 1 happiness.",
				choices: []
			},
			zh: {
				text: "「住在这里，比我得上『步行肺炎』那回还难受，」皮埃尔说。「这算什么破假期！」失去 1 点心情。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "24.7",
			en: {
				text: "The leader of the 4H organization comes to appraise your ranch. If 9 or more animal stickers (not part of another sticker) on the map, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Bravo! This is a brilliant display of what a ranch SHOULD be. Please, accept this trophy.” Cover 24.7 on the map with sticker 9C. Then cover the Veteran Rancher milestone with Legendary Rancher (gold)."
				}, {
					key: "b",
					text: "“Impressive, but I've seen better.” You may spend 1 gold to place 1 farm animal sticker 11B. Otherwise, perform another action."
				}]
			},
			zh: {
				text: "4H 组织的负责人来评估你的牧场。如果地图上有 9 枚或更多动物贴纸（不属于其他贴纸的一部分），阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「太棒了！这才是一个牧场应有的样子。请收下这座奖杯。」用贴纸 9C 覆盖地图上的 24.7 标记，然后用「传奇牧场主」（金色）覆盖「资深牧场主」里程碑。"
				}, {
					key: "b",
					text: "「令人印象深刻，不过我见过更好的。」你可以花费 1 枚金币放置 1 枚农场动物贴纸 11B。否则，额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "24.8",
			en: {
				text: "Your village comes together to create its own flag! Place sticker 10K. Then use a flag background sticker 10P and/or deco stickers 10Q to customize your flag.",
				choices: []
			},
			zh: {
				text: "你的村庄齐心协力制作了自己的旗帜！放置贴纸 10K，然后使用旗帜背景贴纸 10P 和/或装饰贴纸 10Q 来装饰你的旗帜。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "24.9",
			en: {
				text: "If you chose the Whoopee Cushion sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“I can't wait to use this giant whoopee cushion on the neighbors!” Place the Whoopee Cushion sticker on the map near any resident. Then cover 24.9 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“I don't want this lame thing.” Cover 24.9 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了放屁坐垫贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「我等不及要把这个超大的放屁坐垫用在邻居身上了！」在地图上任意居民附近放置放屁坐垫贴纸，然后用爱心贴纸覆盖图鉴牌 47 上的 24.9。"
				}, {
					key: "b",
					text: "「我才不要这个没用的东西。」用所选礼物贴纸覆盖图鉴牌 47 上的 24.9。"
				}]
			}
		},
		{
			type: "entry",
			id: "24.10",
			en: {
				text: "“It was me,” Bill says. “I stole your money to buy food. I'm a terrible friend, so I understand if you don't wanna see me no more. Please, take these apples as my apology.”\nGain 2 food. You may remove the Wild Bill sticker from your map.",
				choices: []
			},
			zh: {
				text: "「是我干的，」野比尔说。「我偷了你的钱去买食物。我是个糟糕的朋友，所以你要是再也不想见我也是应该的。请收下这些苹果，算是我的道歉。」\n获得 2 份食物。你可以将野比尔贴纸从地图上移除。",
				choices: []
			}
		}
	] },
	25: { blocks: [
		{
			type: "entry",
			id: "25.1",
			en: {
				text: "You need a castle at any cost, even if you have to force the people to build it for you. Either A spend 2 ore and 3 gold to build a castle, B send residents into the quarry, or C bide your time.",
				choices: [
					{
						key: "a",
						text: "The castle has 6 bedrooms, 5 bathrooms, 2 kitchens, a throne room, and a dungeon. Place 1 heart sticker on card 51 and cover your house with sticker 8G."
					},
					{
						key: "b",
						text: "The work in the quarry is long and grueling. It's nice that you have people to do it for you. Gain 1 ore and 1 gold. Then place 1 upset sticker on the map near a resident that isn't upset. Do not place any stickers on card 51."
					},
					{
						key: "c",
						text: "Perform another action."
					}
				]
			},
			zh: {
				text: "你不惜一切代价也要建起一座城堡，哪怕要强迫民众替你建造。你可以 A 花费 2 份矿石和 3 枚金币建造城堡，B 把居民送进采石场，或 C 静待时机。",
				choices: [
					{
						key: "a",
						text: "这座城堡有 6 间卧室、5 间浴室、2 间厨房、一间王座厅和一座地牢。在图鉴牌 51 上放置 1 枚爱心贴纸，并用贴纸 8G 覆盖你的房屋。"
					},
					{
						key: "b",
						text: "采石场的活儿又漫长又艰苦。好在有人替你干这些活。获得 1 份矿石和 1 枚金币。然后在地图上一位尚未不满的居民附近放置 1 枚不满贴纸。图鉴牌 51 上不放置任何贴纸。"
					},
					{
						key: "c",
						text: "额外行动一次。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "25.2",
			en: {
				text: "You've got everything you need to rule, except a crown. Either A spend 4 gold to buy a crown, B tax residents, or C seek alternatives.",
				choices: [
					{
						key: "a",
						text: "You have a glorious crowning ceremony in your throne room. As your first official act, you decree that all residents must address you as “Your Highness.” Discard card 51 and cover your “Politics 2” milestone with Monarch (gold)."
					},
					{
						key: "b",
						text: "The money continues to roll in. Gain 2 gold and lose 1 happiness."
					},
					{
						key: "c",
						text: "Perhaps you can find gold somewhere else? Perform another action."
					}
				]
			},
			zh: {
				text: "你已经拥有了统治所需的一切，只差一顶王冠。你可以 A 花费 4 枚金币买一顶王冠，B 向居民征税，或 C 另寻他法。",
				choices: [
					{
						key: "a",
						text: "你在王座厅举行了盛大的加冕典礼。作为第一道正式法令，你宣布所有居民都必须称你为「陛下」。弃掉图鉴牌 51，并用「君主」（金色）覆盖你的「政治 2」里程碑。"
					},
					{
						key: "b",
						text: "钱财源源不断地涌来。获得 2 枚金币，失去 1 点心情。"
					},
					{
						key: "c",
						text: "也许你可以在别处找到金币？额外行动一次。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "25.3",
			en: {
				text: "Some people believe that a monarch needs to win the hearts of the people to succeed. Others believe that they only need obedience. Either A spend 2 gold to buy your residents' support, or B force them to pledge their loyalty.",
				choices: [{
					key: "a",
					text: "After your generous gift, they happily support you. Place 1 heart sticker on card 51."
				}, {
					key: "b",
					text: "Your neighbors swear an oath to you, but not everyone is happy about it. Place 2 stickers: a heart sticker on card 51 and an upset sticker on the map near a resident that isn't upset."
				}]
			},
			zh: {
				text: "有人认为，君主必须赢得民心才能成功；也有人认为，君主只需臣民服从。你可以 A 花费 2 枚金币收买居民的支持，或 B 强迫他们宣誓效忠。",
				choices: [{
					key: "a",
					text: "收到你慷慨的馈赠后，他们欣然支持你。在图鉴牌 51 上放置 1 枚爱心贴纸。"
				}, {
					key: "b",
					text: "邻里向你宣誓效忠，但并非人人都乐于如此。放置 2 枚贴纸：在图鉴牌 51 上放置 1 枚爱心贴纸，并在地图上一位尚未不满的居民附近放置 1 枚不满贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "25.4",
			en: {
				text: "You'll need lots of support to run for president. If 9 or more residents on the map are not upset, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "The people love you and support you running for president! Place 1 heart sticker on card 5."
				}, {
					key: "b",
					text: "Go shake some hands and kiss some babies! You may spend 2 gold to remove 1 upset sticker from the map. Otherwise, perform another action."
				}]
			},
			zh: {
				text: "竞选总统需要大量支持。如果地图上有 9 位或更多居民尚未不满，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "人民爱戴你，支持你竞选总统！在图鉴牌 5 上放置 1 枚爱心贴纸。"
				}, {
					key: "b",
					text: "去和民众握握手、抱抱孩子吧！你可以花费 2 枚金币，从地图上移除 1 枚不满贴纸。否则，额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "25.5",
			en: {
				text: "You have the support, now you need to win the election. You've got one shot at this. Either perform another action or spend 1 to 6 gold to roll the die. If your roll plus the amount of gold spent is 7 or higher, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "You win by a landslide! Place 1 heart sticker on card 5. Then cover the Governor milestone with President (gold)."
				}, {
					key: "b",
					text: "You lost the election to your rival, Mustache Steve! Discard card 5. You may take power by force (gain card 51)."
				}]
			},
			zh: {
				text: "你已经赢得了支持，现在需要赢下选举。你只有这一次机会。选择额外行动一次，或花费 1 至 6 枚金币掷骰。如果掷骰结果加上花费的金币数为 7 或更高，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "你以压倒性优势获胜！在图鉴牌 5 上放置 1 枚爱心贴纸。然后用「总统」（金色）覆盖「州长」里程碑。"
				}, {
					key: "b",
					text: "你输给了对手八字胡史蒂夫！弃掉图鉴牌 5。你可以用武力夺取政权（获得图鉴牌 51）。"
				}]
			}
		},
		{
			type: "entry",
			id: "25.6",
			en: {
				text: "As president, you need a house worthy of the title. Luckily, this job comes with zero responsibilities! Discard card 5 and cover your house with sticker 8F.",
				choices: []
			},
			zh: {
				text: "身为总统，你需要一栋与头衔相称的房子。幸运的是，这份工作毫无职责！弃掉图鉴牌 5，并用贴纸 8F 覆盖你的房屋。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "25.7",
			en: {
				text: "Your delicate desserts have earned your restaurant three Michelin stars. You're the talk of the town! Gain 1 gold and cover the Famous Chef milestone with Master Chef (gold).",
				choices: []
			},
			zh: {
				text: "你精致的甜点为餐厅赢得了米其林三星。你成了镇上人人谈论的话题！获得 1 枚金币，并用「厨艺大师」（金色）覆盖「名厨」里程碑。",
				choices: []
			}
		}
	] },
	26: { blocks: [
		{
			type: "entry",
			id: "26.1",
			en: {
				text: "Your telescope reveals the startling beauty of the planet Saturn. You feel inspired to share it. Either A invite residents to view it, or B sell tickets to view it.",
				choices: [{
					key: "a",
					text: "Your neighbors agree that the view is breathtaking. Gain 1 happiness and cover 26.1 on card 41 with a heart sticker."
				}, {
					key: "b",
					text: "The line of people spills out the door. Gain 2 gold and cover 26.1 on card 41 with a heart sticker."
				}]
			},
			zh: {
				text: "你的望远镜揭开了土星惊人的美丽。你忍不住想与人分享。你可以 A 邀请居民前来观赏，或 B 卖票供人观赏。",
				choices: [{
					key: "a",
					text: "邻居们都觉得这番景象美得令人屏息。获得 1 点心情，并用爱心贴纸覆盖图鉴牌 41 上的 26.1。"
				}, {
					key: "b",
					text: "排队的人一直排到了门外。获得 2 枚金币，并用爱心贴纸覆盖图鉴牌 41 上的 26.1。"
				}]
			}
		},
		{
			type: "entry",
			id: "26.2",
			en: {
				text: "Could it be? Did you just find concrete evidence of extra-terrestrials? No, wait... Jessie tricked you. It's just a UFO sticker. Cover 26.2 on card 41 with a heart sticker.",
				choices: []
			},
			zh: {
				text: "难道说？你刚刚找到了外星人存在的确凿证据？不，等等……是杰西捉弄了你。那只是一张飞碟贴纸。用爱心贴纸覆盖图鉴牌 41 上的 26.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.3",
			en: {
				text: "You see a large asteroid making its way towards Earth! You share your findings with the science community, and they estimate that it will be a near miss. Gain the Astronomer milestone (silver) and cover 26.3 on card 41 with a heart sticker.",
				choices: []
			},
			zh: {
				text: "你看到一颗巨大的小行星正朝地球飞来！你把观测结果告知科学界，他们估计它只会与地球擦肩而过。获得「天文学家」里程碑（银色），并用爱心贴纸覆盖图鉴牌 41 上的 26.3。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.4",
			en: {
				text: "You spy a distant galaxy and it makes you realize just how big the universe is. You are a speck of dust on a speck of dust. Cover 26.4 on card 41 with a heart sticker. Perform another action.",
				choices: []
			},
			zh: {
				text: "你望见一个遥远的星系，这才意识到宇宙有多么浩瀚。你不过是尘埃之上的尘埃。用爱心贴纸覆盖图鉴牌 41 上的 26.4，然后额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.5",
			en: {
				text: "You finally have a post office, but there's a problem! There's a pile of packages with missing addresses. You'll need to figure out who they belong to. Gain card 47.",
				choices: []
			},
			zh: {
				text: "镇上终于有了邮局，但麻烦也随之而来！一堆包裹的收件地址缺失了。你需要弄清它们各自属于谁。获得图鉴牌 47。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.6",
			en: {
				text: "There is some amazing talent at this baking competition, from the local favorite, Grandma Pearlson, to the world-renowned French baker, Pierre Dubois. It's intimidating, but you bake your heart out and hope for the best. Roll the die. Read the effect matching the number rolled plus the amount of food spent:\n1-3: You bake double chocolate brownies. They are tasty, but not good enough to win against the pros. Perform another action (but not on card 28).\n4-6: The judges declare your macaroons are to die for, but they weren't QUITE as good as Pierre's crème brûlée. Gain 1 food and 1 gold. (Do not discard card 28.)\n7+: You bake a 3-layer cake: moist, delicious, and extravagant enough for the queen's wedding. You win unanimously! Gain 2 gold and discard card 28. Then cover the Famous Baker milestone with Expert Baker (gold).",
				choices: []
			},
			zh: {
				text: "这场烘焙比赛高手云集，既有本地人气选手珀尔森奶奶，也有享誉世界的法国烘焙师皮埃尔·杜布瓦。对手令人生畏，但你仍倾尽全力烘焙，盼望能有好结果。掷骰。阅读与「掷骰结果加上花费的食物数」对应的效果：\n1-3：你烤了双层巧克力布朗尼。味道不错，但还不足以战胜这些高手。额外行动一次（但不能在图鉴牌 28 上行动）。\n4-6：评委宣布你的马卡龙好吃极了，但比起皮埃尔的焦糖布丁还差那么一点。获得 1 份食物和 1 枚金币。（不要弃掉图鉴牌 28。）\n7+：你烤了一个三层蛋糕：松软、美味，华丽得足以登上女王的婚宴。你全票获胜！获得 2 枚金币并弃掉图鉴牌 28。然后用「烘焙专家」（金色）覆盖「著名烘焙师」里程碑。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.7",
			en: {
				text: "You make a trip to the big city library and find an old newspaper clipping about the Cobblepot family misfiled under “Copperpot.” Gain card 45. Do not discard card 44 yet.",
				choices: []
			},
			zh: {
				text: "你去大城市图书馆查找旧报纸，发现一篇关于科布尔波特家族的旧剪报被错误地归在「科珀波特」名下。获得图鉴牌 45。暂时不要弃掉图鉴牌 44。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.8",
			en: {
				text: "Read the hint below. If you solve the puzzle, read the story it points to.\nHidden at the edges of the map are a circle icon and a square icon. What is inside them?",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，就阅读它指向的故事。\n地图的边缘藏着圆形图标和方形图标。它们里面是什么？",
				choices: []
			}
		},
		{
			type: "entry",
			id: "26.9",
			en: {
				text: "Place sticker 1A anywhere. Then either A vote on what to name your village, B give it a silly name, or C boost morale by letting your residents name it.",
				choices: [
					{
						key: "a",
						text: "Gain 1 happiness. Have each player suggest a name. All players vote on their favorite (you break ties). Write the name on the sticker with a pen or marker."
					},
					{
						key: "b",
						text: "Write a funny name on the sticker with a pen or marker. If someone laughs at it, gain 1 happiness. (If you are the only player, gain 1 happiness regardless.)"
					},
					{
						key: "c",
						text: "Remove 1 upset sticker from the map. If there are none, instead gain 1 happiness. Then roll the die and write the matching name on the sticker with a pen or marker: 1-2 “Jessieville,” 3-4 “Our Town,” 5-6 “Awesomeville.”"
					}
				]
			},
			zh: {
				text: "把贴纸 1A 放在任意位置。然后选择 A 投票决定村庄的名字，B 给它起个傻气的名字，或 C 让居民来命名以提振士气。",
				choices: [
					{
						key: "a",
						text: "获得 1 点心情。每位玩家各提出一个名字，所有玩家投票选出最喜欢的（平票时由你决定）。用笔或记号笔把这个名字写在贴纸上。"
					},
					{
						key: "b",
						text: "用笔或记号笔在贴纸上写下一个好笑的名字。如果有人被逗笑，获得 1 点心情。（如果你是唯一的玩家，无论是否有人笑，都获得 1 点心情。）"
					},
					{
						key: "c",
						text: "从地图上移除 1 枚不满贴纸。如果没有不满贴纸，则改为获得 1 点心情。然后掷骰，用笔或记号笔在贴纸上写下对应的名字：1-2 为「杰西村」，3-4 为「我们的镇」，5-6 为「超赞镇」。"
					}
				]
			}
		}
	] },
	27: { blocks: [
		{
			type: "entry",
			id: "27.1",
			en: {
				text: "Who cares about Mustache Steve? He's a nobody! You dream of bigger things, like becoming governor of the entire region! It will cost a lot of money to run, but you know you can do it! Either perform another action or spend 1 to 6 gold to roll the die. If your roll plus the amount of gold spent is 7 or higher, discard card 15 and gain card 5. Otherwise, no effect.",
				choices: []
			},
			zh: {
				text: "谁在乎八字胡史蒂夫？他不过是个无名小卒！你梦想着更大的成就，比如成为整个地区的州长！竞选需要花很多钱，但你相信自己能做到！选择额外行动一次，或花费 1 至 6 枚金币掷骰。如果掷骰结果加上花费的金币数为 7 或更高，弃掉图鉴牌 15 并获得图鉴牌 5。否则，没有效果。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "27.2",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "27.3",
			en: {
				text: "“We'll keep your money safe, and it will grow over time,” the banker says with a smile. He seems trustworthy. Either A pass for now, or B spend 2 gold to open a savings account.",
				choices: [{
					key: "a",
					text: "Perform another action."
				}, {
					key: "b",
					text: "Gain the Savings Account milestone (bronze) and cover 27.3 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "「我们会保管好你的钱，它还会随着时间增值，」银行家微笑着说。他看起来值得信赖。你可以 A 暂时放弃，或 B 花费 2 枚金币开一个储蓄账户。",
				choices: [{
					key: "a",
					text: "额外行动一次。"
				}, {
					key: "b",
					text: "获得「存款」里程碑（铜色），并用爱心贴纸覆盖本页的 27.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "27.4",
			en: {
				text: "The bank is closed today for some made-up “bank holiday.” You hope you haven't been scammed. Cover 27.4 on this page with a heart sticker. Perform another action (but not 27.2).",
				choices: []
			},
			zh: {
				text: "银行今天莫名放了个「银行假日」，暂停营业。你希望自己没有被骗。用爱心贴纸覆盖本页的 27.4。额外行动一次（但不能是 27.2）。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "27.5",
			en: {
				text: "You are relieved to see that the bank is open today! Either A withdraw all your money, B spend 1 gold to deposit more, or C leave it alone.",
				choices: [
					{
						key: "a",
						text: "“We told you we'd keep it safe. It looks like you even generated some interest!” Gain 4 gold. Then cover 27.2 on the map with sticker 9C."
					},
					{
						key: "b",
						text: "“You gotta spend money to make money.” Cover 27.5 on this page with a heart sticker. Then cover the Savings Account milestone with Big Savings Account (silver)."
					},
					{
						key: "c",
						text: "Cover 27.5 on this page with a heart sticker. Perform another action (but not 27.2)."
					}
				]
			},
			zh: {
				text: "你松了口气，看到银行今天开门了！你可以 A 取出全部存款，B 花费 1 枚金币存入更多，或 C 不去动它。",
				choices: [
					{
						key: "a",
						text: "「我们说过会保管好的。看样子你还赚了一些利息！」获得 4 枚金币。然后用贴纸 9C 覆盖地图上的 27.2 标记。"
					},
					{
						key: "b",
						text: "「要赚钱就得先花钱。」用爱心贴纸覆盖本页的 27.5。然后用「大额存款」（银色）覆盖「存款」里程碑。"
					},
					{
						key: "c",
						text: "用爱心贴纸覆盖本页的 27.5。额外行动一次（但不能是 27.2）。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "27.6",
			en: {
				text: "Interest rates are up and your money has grown. Are you ready to close your account? Either A withdraw all your money, or B leave it for now.",
				choices: [{
					key: "a",
					text: "It looks like your investment really paid off! If you have the Savings Account milestone, gain 4 gold (or 7 gold if you have the Big Savings Account milestone). Regardless, then cover 27.2 on the map with sticker 9C."
				}, {
					key: "b",
					text: "If you have the Savings Account milestone, cover it with Big Savings Account (silver). Otherwise, perform another action (but not this)."
				}]
			},
			zh: {
				text: "利率上涨，你的存款也增值了。你准备销户了吗？你可以 A 取出全部存款，或 B 暂时留着。",
				choices: [{
					key: "a",
					text: "看来你的投资真的得到了回报！如果你拥有「存款」里程碑，获得 4 枚金币（如果你拥有「大额存款」里程碑，则获得 7 枚金币）。无论哪种情况，然后用贴纸 9C 覆盖地图上的 27.2 标记。"
				}, {
					key: "b",
					text: "如果你拥有「存款」里程碑，用「大额存款」（银色）覆盖它。否则，额外行动一次（但不能是本条目）。"
				}]
			}
		},
		{
			type: "entry",
			id: "27.7",
			en: {
				text: "You regret letting Mustache Steve win the election and decide to take control of the village by force! Discard card 15, lose 1 happiness, and gain card 51.",
				choices: []
			},
			zh: {
				text: "你后悔让八字胡史蒂夫赢下了选举，决定用武力夺取村庄的控制权！弃掉图鉴牌 15，失去 1 点心情，并获得图鉴牌 51。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "27.8",
			en: {
				text: "Building a village is hard work! Maybe Father is right; maybe you're not cut out for this. You consider tossing a coin in the well, wishing for good luck. Either A draw up the bucket for a drink, or B spend 1 gold to make a wish.",
				choices: [{
					key: "a",
					text: "Perform another action."
				}, {
					key: "b",
					text: "Cover 27.8 on the map with sticker 9C. Then gain the Lucky milestone (bronze)."
				}]
			},
			zh: {
				text: "建设村庄是件苦差事！也许父亲说得对，也许你根本不适合干这个。你想往井里投一枚硬币，祈求好运。你可以 A 打一桶水上来喝，或 B 花费 1 枚金币许个愿。",
				choices: [{
					key: "a",
					text: "额外行动一次。"
				}, {
					key: "b",
					text: "用贴纸 9C 覆盖地图上的 27.8 标记。然后获得「幸运儿」里程碑（铜色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "27.9",
			en: {
				text: "The contract you signed was illegal in numerous ways. You argue it in court, and win! Remove the Loan milestone.",
				choices: []
			},
			zh: {
				text: "你签的那份合同在多个方面都不合法。你在法庭上据理力争，并赢得了官司！移除「贷款」里程碑。",
				choices: []
			}
		}
	] },
	28: { blocks: [
		{
			type: "entry",
			id: "28.1",
			en: {
				text: "“Isn't it obvious? The whole point of our organization is to make money! Now that you're at the top, you can enjoy the riches with us.” Gain 5 gold. (Reminder: the Lodge Master milestone will also provide gold each year.)",
				choices: []
			},
			zh: {
				text: "「这还用问吗？我们这个组织的全部目的就是赚钱！既然你已经爬到了顶层，就可以和我们一起享受这些财富。」获得 5 枚金币。（提醒：小屋大师里程碑每年也会提供金币。）",
				choices: []
			}
		},
		{
			type: "entry",
			id: "28.2",
			en: {
				text: "The clock strikes the hour, and the bell rings through the hills. “Do you have the briefcase?” the man in the trench coat asks. If there is a progress sticker on card 36, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Excellent. Thanks for your help!” Gain the Secret Spy milestone (silver). If 3 stickers on card 36, discard it. Otherwise, cover 28.2 on card 36 with a progress sticker."
				}, {
					key: "b",
					text: "“Come back on the hour when you have it.” Perform another action."
				}]
			},
			zh: {
				text: "钟声敲响整点，铃声在山间回荡。「你带公文包了吗？」穿风衣的男人问道。如果图鉴牌 36 上有进度贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「很好。谢谢你的帮助！」获得「秘密间谍」里程碑（银色）。如果图鉴牌 36 上有 3 枚贴纸，弃掉它；否则用进度贴纸覆盖图鉴牌 36 上的 28.2。"
				}, {
					key: "b",
					text: "「等你拿到东西，整点再来。」额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "28.3",
			en: {
				text: "“She told me to meet her here under the clock, but I forgot what time.” If there is a heart sticker on card 36, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Oh, there she is! She looks so stunning that I hardly recognized her. I'm coming, my love!” Gain 1 happiness. If 3 stickers on card 36, discard it. Otherwise, cover 28.3 on card 36 with a heart sticker."
				}, {
					key: "b",
					text: "“Oh, now I remember. She said 45. Thank you!” Cover 28.3 on card 36 with a heart sticker."
				}]
			},
			zh: {
				text: "「她让我在钟楼下等她，可我忘了是几点。」如果图鉴牌 36 上有爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「哦，她在那儿！她美得我差点认不出来。我来了，亲爱的！」获得 1 点心情。如果图鉴牌 36 上有 3 枚贴纸，弃掉它；否则用爱心贴纸覆盖图鉴牌 36 上的 28.3。"
				}, {
					key: "b",
					text: "「哦，我想起来了。她说的是 45 分。谢谢你！」用爱心贴纸覆盖图鉴牌 36 上的 28.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "28.4",
			en: {
				text: "A shifty fellow is sitting on a bench in front of the clock tower. “Here's the briefcase, as promised. Bring it to Agent Zero on the hour exactly. Got it?” Cover 28.4 on card 36 with a progress sticker.",
				choices: []
			},
			zh: {
				text: "一个鬼鬼祟祟的家伙坐在钟楼前的长椅上。「这是说好的公文包。务必在整点把它交给零号特工。明白了吗？」用进度贴纸覆盖图鉴牌 36 上的 28.4。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "28.5",
			en: {
				text: "“I told him to meet me under the clock,” the woman says, “but he must have forgotten what time.” If there is a heart sticker on card 36, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Oh, there he is. Late as always, but I love him anyways.” Gain 1 happiness. If 3 stickers on card 36, discard it. Otherwise, cover 28.5 on card 36 with a heart sticker."
				}, {
					key: "b",
					text: "“Oh wait, now I remember; I told him 15 past, not 45. I'll go freshen up.” Cover 28.5 on card 36 with a heart sticker."
				}]
			},
			zh: {
				text: "「我让他到钟楼下等我，」那女人说，「可他一定是忘了时间。」如果图鉴牌 36 上有爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「哦，他来了。还是老样子爱迟到，可我就是爱他。」获得 1 点心情。如果图鉴牌 36 上有 3 枚贴纸，弃掉它；否则用爱心贴纸覆盖图鉴牌 36 上的 28.5。"
				}, {
					key: "b",
					text: "「哦，等等，我想起来了；我跟他说的是 15 分，不是 45 分。我去补个妆。」用爱心贴纸覆盖图鉴牌 36 上的 28.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "28.6",
			en: {
				text: "The flowers! They spell out something, you're just not sure what. Solve the puzzle on card 48 by placing all the 10M stickers on it. If you solve the puzzle, immediately gain the card number indicated. If you need a hint, you may read 19.7.",
				choices: []
			},
			zh: {
				text: "这些花！它们拼出了什么东西，只是你还看不明白。把全部 10M 贴纸放到图鉴牌 48 上，解开上面的谜题。如果你解开了谜题，立即获得所标明编号的图鉴牌。如果你需要提示，可以阅读故事 19.7。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "28.7",
			en: {
				text: "You spend a few days researching finances and fraud. If you had the money, you could take them to court! You may spend 1 gold to read 27.9. Otherwise, you must read 28.8.",
				choices: []
			},
			zh: {
				text: "你花了几天时间研究财务与欺诈。如果你有钱，就可以把他们告上法庭！你可以花费 1 枚金币阅读故事 27.9。否则，你必须阅读故事 28.8。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "28.8",
			en: {
				text: "If your milestones have at least one gold crown icon, read option A. Otherwise, read option B.",
				choices: [{
					key: "a",
					text: "The debt collectors get permission to garnish your income. Cover one gold crown icon on a milestone with an upset sticker. The covered icon no longer provides gold."
				}, {
					key: "b",
					text: "You become violently ill and spend weeks in bed. Did someone just send you a message? Lose 1 happiness."
				}]
			},
			zh: {
				text: "如果你的里程碑上至少有 1 枚金币王冠图标，阅读选项 A。否则，阅读选项 B。",
				choices: [{
					key: "a",
					text: "讨债人获准扣押你的收入。用一张不满贴纸覆盖里程碑上的 1 枚金币王冠图标。被覆盖的图标不再提供金币。"
				}, {
					key: "b",
					text: "你病得很重，卧床数周。是不是有人刚刚给你捎了个信儿？失去 1 点心情。"
				}]
			}
		},
		{
			type: "entry",
			id: "28.9",
			en: {
				text: "You're a trend-setter, and your hard work has turned this boring village into a fashion haven! Cover the Fashionable milestone with Glamorous (gold).",
				choices: []
			},
			zh: {
				text: "你引领了潮流，你的辛勤付出把这座乏味的村庄变成了时尚胜地！用「魅力四射」（金色）覆盖「时尚达人」里程碑。",
				choices: []
			}
		}
	] },
	29: { blocks: [
		{
			type: "entry",
			id: "29.1",
			en: {
				text: "If you chose the Bassinet sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Finally! I hope this helps the baby sleep through the night.” Place the Bassinet sticker on the map near this resident. Then cover 29.1 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“The baby can't sleep in this!” Cover 29.1 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了摇篮贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「终于好了！希望这能让宝宝一觉睡到天亮。」把摇篮贴纸放在地图上这位居民附近。然后用爱心贴纸覆盖图鉴牌 47 上的 29.1。"
				}, {
					key: "b",
					text: "「宝宝没法睡在这个上面！」用你选择的礼物贴纸覆盖图鉴牌 47 上的 29.1。"
				}]
			}
		},
		{
			type: "entry",
			id: "29.2",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "29.3",
			en: {
				text: "A newspaper is exactly what your village needs! What do you want to print for your first cover story? Either A “Fireman Adopts Cat He Rescued from Tree,” or B “Can You Trust Your Neighbors?”",
				choices: [{
					key: "a",
					text: "Everyone loves a positive story! Cover 29.3 on this page with a heart sticker."
				}, {
					key: "b",
					text: "You sell tons of copies, but people seem a little more paranoid than usual. Gain 1 gold and cover 29.3 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "你的村庄正需要一份报纸！第一期的头版故事你想刊登什么？你可以 A 刊登「消防员收养了他从树上救下的小猫」，或 B 刊登「你能信任你的邻居吗？」",
				choices: [{
					key: "a",
					text: "人人都爱暖心的故事！用爱心贴纸覆盖本页的 29.3。"
				}, {
					key: "b",
					text: "报纸卖出了大量份数，但人们似乎比平时多了几分猜疑。获得 1 枚金币，并用进度贴纸覆盖本页的 29.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "29.4",
			en: {
				text: "Once again, food has gone missing. This could be a big story if you can find some answers. Lose 1 food. Then either A blindly speculate, or B spend 1 gold to hire a reporter to uncover the story.",
				choices: [{
					key: "a",
					text: "Your headline reads “Food Stolen by Aliens.” The community laughs at you. Cover 29.4 on this page with a progress sticker."
				}, {
					key: "b",
					text: "After some research, the reporter finds the culprit. “Mama Bear Steals Food for Cubs!” Cover 29.4 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "食物又一次不翼而飞。如果你能找到答案，这会是一篇大新闻。失去 1 份食物。然后选择 A 凭空猜测，或 B 花费 1 枚金币聘请一名记者查明真相。",
				choices: [{
					key: "a",
					text: "你的头条写着「食物被外星人偷走了」。整个社区都在笑话你。用进度贴纸覆盖本页的 29.4。"
				}, {
					key: "b",
					text: "经过一番调查，记者找到了元凶。「熊妈妈为幼崽偷食物！」用爱心贴纸覆盖本页的 29.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "29.5",
			en: {
				text: "Your newspaper is maturing, and it's time to solidify your reputation. Either A write get-rich-quick advice, B spend 2 gold to buy a groundbreaking story, or C decide later.",
				choices: [
					{
						key: "a",
						text: "“How to Plant a Money Tree” sells papers like mad, but the advice is hog-wash. Gain 1 gold and read 29.6."
					},
					{
						key: "b",
						text: "Your reporter produces a shocking but true exposé: “The Lodge Unmasked!” Cover 29.5 on this page with a heart sticker, then read 29.6."
					},
					{
						key: "c",
						text: "Perform another action."
					}
				]
			},
			zh: {
				text: "你的报纸日渐成熟，是时候巩固声誉了。你可以 A 撰写快速致富的专栏，B 花费 2 枚金币买下一篇重磅报道，或 C 稍后再决定。",
				choices: [
					{
						key: "a",
						text: "「如何种出摇钱树」让报纸销量疯涨，可那些建议全是胡扯。获得 1 枚金币，并阅读故事 29.6。"
					},
					{
						key: "b",
						text: "你的记者写出了一篇惊人却真实的曝光报道：「小屋的真面目！」用爱心贴纸覆盖本页的 29.5，然后阅读故事 29.6。"
					},
					{
						key: "c",
						text: "额外行动一次。"
					}
				]
			}
		},
		{
			type: "entry",
			id: "29.6",
			en: {
				text: "Cover 29.2 on the map with sticker 9C. If 2 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Your newspaper has earned a reputation for wholesome and honest news! Gain the Trustworthy News milestone (silver)."
				}, {
					key: "b",
					text: "Your newspaper has a reputation for printing ludicrous stories with little substance. Gain 2 gold and the Fake News milestone (red)."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 29.2 标记。如果本页有 2 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "你的报纸以健康、诚实的新闻赢得了声誉！获得「可信新闻」里程碑（银色）。"
				}, {
					key: "b",
					text: "你的报纸以刊登荒诞、空洞的故事闻名。获得 2 枚金币和「假新闻」里程碑（红色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "29.7",
			en: {
				text: "“Blimey! How did all this cheeky scrap get in my basket?” He hands you an armful of metal scraps, and the balloon starts rising back into the sky. “Up, up, and away!” Gain 1 ore.",
				choices: []
			},
			zh: {
				text: "「天哪！这些破铜烂铁怎么都跑到我的篮子里来了？」他递给你满怀的金属废料，气球又开始升回天空。「升空喽！」获得 1 份矿石。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "29.8",
			en: {
				text: "“Sure! This village looks lovely, and I could use a bit of R&R!” Place sticker 4Y.",
				choices: []
			},
			zh: {
				text: "「当然！这个村子看起来很可爱，我也正好需要休息放松一下！」放置贴纸 4Y。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "29.9",
			en: {
				text: "Read the hint below. If you solve the puzzle, gain the card it points to.\nYou need to use card 44 to solve card 45.\nIf you need an additional hint, spend 1 gold to read 32.2.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，获得它所指的图鉴牌。\n你需要使用图鉴牌 44 来解开图鉴牌 45。\n如果你需要额外提示，花费 1 枚金币阅读故事 32.2。",
				choices: []
			}
		}
	] },
	30: { blocks: [
		{
			type: "entry",
			id: "30.1",
			en: {
				text: "“You have learned much and proven your sharp mind. I happily bestow upon you the title of Master. When you are ready to learn our deepest secret, come see me.” Discard cards 4 and 31. Then cover the Lodge Apprentice milestone with Lodge Master (gold).",
				choices: []
			},
			zh: {
				text: "「你学到了很多，也证明了你敏锐的头脑。我欣然授予你大师的头衔。等你准备好了解我们最深的秘密时，来找我。」弃掉图鉴牌 4 和 31。然后用「小屋大师」（金色）覆盖「小屋学徒」里程碑。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "30.2",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "30.3",
			en: {
				text: "You accept a job as camp counselor. Your cabin is filled with rambunctious kids from the big city, and they're completely out of control. Either A enforce law and order, or B get to know them better.",
				choices: [{
					key: "a",
					text: "“I've got a zero tolerance policy for trouble-making,” you growl. You lean in toward the ringleader. “And I'm keeping an extra close eye on you, Cameron!” Gain 1 gold and cover 30.3 on this page with a progress sticker."
				}, {
					key: "b",
					text: "You learn that most of these kids have some sort of trouble at home. For example, Cameron's parents are going through a tough divorce. Gain 1 gold and cover 30.3 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "你接下了一份营地辅导员的工作。你的小屋里挤满了从大城市来的闹腾孩子，他们完全不受管束。你可以 A 严格维持秩序，或 B 试着更了解他们。",
				choices: [{
					key: "a",
					text: "「我对捣乱行为零容忍。」你低吼道。你凑近孩子王。「而且我会格外盯着你，卡梅伦！」获得 1 枚金币，并用进度贴纸覆盖本页的 30.3。"
				}, {
					key: "b",
					text: "你了解到这些孩子大多在家里遇到了麻烦。比如卡梅伦的父母正在经历一场艰难的离婚。获得 1 枚金币，并用爱心贴纸覆盖本页的 30.3。"
				}]
			}
		},
		{
			type: "entry",
			id: "30.4",
			en: {
				text: "The ten-year-olds are telling stories around the campfire when you notice that Cameron wet his pants. Either A let him handle it, or B go hand him a fresh pair of pants.",
				choices: [{
					key: "a",
					text: "Cameron's eyes grow wide, and he asks to be excused. You nod, and luckily the other kids don't seem to notice. Cover 30.4 on this page with a heart sticker."
				}, {
					key: "b",
					text: "The kids see you delivering him dry pants and realize what happened. They laugh and laugh. Cover 30.4 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "十岁的孩子们正围着篝火讲故事，你忽然发现卡梅伦尿裤子了。你可以 A 让他自己处理，或 B 过去给他一条干净的裤子。",
				choices: [{
					key: "a",
					text: "卡梅伦瞪大了眼睛，请求离开一下。你点了点头，幸好其他孩子似乎没有注意到。用爱心贴纸覆盖本页的 30.4。"
				}, {
					key: "b",
					text: "孩子们看到你给他送干裤子，明白了发生了什么。他们笑个不停。用进度贴纸覆盖本页的 30.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "30.5",
			en: {
				text: "Out of the blue, Cameron throws a water balloon at you. Either A throw one back, or B send him to the head counselor for punishment.",
				choices: [{
					key: "a",
					text: "Direct hit! “Aww, man!” Cameron bellows. “Now I'm soaking wet, too!” He's acting angry, but you can see the hint of a smile. Cover 30.5 on this page with a heart sticker, then read 30.6."
				}, {
					key: "b",
					text: "The head counselor pulls you aside. “I like your no-nonsense attitude. I'm retiring soon, and I'm considering you for my replacement.” Read 30.6."
				}]
			},
			zh: {
				text: "卡梅伦冷不防朝你扔来一个水球。你可以 A 扔回去，或 B 把他交给总辅导员处罚。",
				choices: [{
					key: "a",
					text: "正中目标！「哎呀，天哪！」卡梅伦大叫，「我现在也湿透了！」他装出一副生气的样子，但你能看到一丝笑意。用爱心贴纸覆盖本页的 30.5，然后阅读故事 30.6。"
				}, {
					key: "b",
					text: "总辅导员把你拉到一边。「我喜欢你这种不讲情面的作风。我快要退休了，正在考虑让你接替我的位置。」阅读故事 30.6。"
				}]
			}
		},
		{
			type: "entry",
			id: "30.6",
			en: {
				text: "Cover 30.2 on the map with sticker 9C. If 2 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "You formed a real connection with these kids, and you'll miss them when the summer ends. Gain 1 happiness and the Camp Counselor milestone (silver)."
				}, {
					key: "b",
					text: "You become known as “Sergeant Angry Pants” and are promoted to head counselor. Gain 1 gold and the Camp Counselor milestone (silver)."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 30.2 标记。如果本页有 2 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "你和这些孩子建立了真正的感情，夏天结束时你会想念他们。获得 1 点心情和「营地辅导员」里程碑（银色）。"
				}, {
					key: "b",
					text: "你得了「愤怒裤子中士」的名号，还被提升为总辅导员。获得 1 枚金币和「营地辅导员」里程碑（银色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "30.7",
			en: {
				text: "You visit the big city library looking for information. Unfortunately, most records and articles about the Cobblepots are missing. The only thing you find is an old deed confirming that your land was once owned by their family. Place 1 heart sticker on card 44.",
				choices: []
			},
			zh: {
				text: "你去大城市图书馆查找资料。可惜关于科布尔波特家族的大部分记录和文章都已缺失。你只找到一份旧地契，证明你的土地曾经属于他们家族。在图鉴牌 44 上放置 1 枚爱心贴纸。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "30.8",
			en: {
				text: "Using the letter and stone slab, you find the coordinates then grab a pickaxe. It takes hours of digging away at the cliff wall, but you eventually unearth a cavern full of lost treasure! The Cobblepot fortune is yours! Discard cards 52 and 22. Then cover the Treasure Hunter milestone with Finder of Secrets (gold). Finally, gain 3 gold and place sticker 12C on a cliff wall. Now that you know where the treasure is, you will gain gold at the start of each year (from the milestone).",
				choices: []
			},
			zh: {
				text: "你借助那封信和石板确定了坐标，然后拿起镐头。你在崖壁上挖掘了好几个小时，终于挖出一个装满失落宝藏的洞穴！科布尔波特宝藏归你了！弃掉图鉴牌 52 和 22。然后用「秘密发现者」（金色）覆盖「寻宝者」里程碑。最后，获得 3 枚金币，并把贴纸 12C 放在一处崖壁上。既然你已经知道宝藏的位置，每年开始时你都会获得金币（来自该里程碑）。",
				choices: []
			}
		}
	] },
	31: { blocks: [
		{
			type: "entry",
			id: "31.1",
			en: {
				text: "For each goal you've completed below, place 1 resource token in the matching box. For example, if you have 21 or more happiness, place 1 food token in the “Beloved” box.\nBELOVED\n· 21+ Happiness\n· 18+ ★ icons on milestones\n· 10+ Residents that are not upset\nNATURALIST\n· 10+ Animal stickers (its own sticker, not part of another sticker)\n· 6+ log icons on the map\n· 7+ Flower stickers (11A)\nTYCOON\n· 18+ Road stickers (including the bridge and fountain)\n· 4+ crown icons on milestones\n· 3+ axe icons on the map\nThen resolve the effect matching how many tokens on this page (any types).\n· 6 or more: read 6.5.\n· 3, 4, or 5: Read the story matching the box with the most tokens: Beloved (31.2), Naturalist (31.3), or Tycoon (31.4). If tied, read the rightmost tied story.\n· 2 or fewer: read 6.6.",
				choices: []
			},
			zh: {
				text: "你每完成下方的一个目标，就在对应的方框里放置 1 枚资源标记。例如，如果你有 21 点或更多心情，就在「受爱戴」方框中放置 1 枚食物标记。\n受爱戴\n· 21 点或更多心情\n· 里程碑上 18 个或更多★图标\n· 10 位或更多没有不满的居民\n自然主义者\n· 10 枚或更多动物贴纸（须为独立贴纸，不属于其他贴纸的一部分）\n· 地图上 6 个或更多原木图标\n· 7 枚或更多花朵贴纸 11A\n大亨\n· 18 枚或更多道路贴纸（包括桥和喷泉）\n· 里程碑上 4 个或更多王冠图标\n· 地图上 3 个或更多斧头图标\n然后按照本页标记的总数（不限种类）执行对应效果。\n· 6 枚或更多：阅读故事 6.5。\n· 3、4 或 5 枚：阅读标记最多的方框所对应的故事：受爱戴（31.2）、自然主义者（31.3）或大亨（31.4）。如果并列，阅读并列中位于最右侧的故事。\n· 2 枚或更少：阅读故事 6.6。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "31.2",
			en: {
				text: "“Well, it's not the most profitable place...” Father says, “but you've certainly built something impressive.”\n“Really?”\n“Indeed. It's quaint, but the people seem happy. They respect you, and I admire that. Now, if we could only find a way to make money off them...”\nYou shake your head. “Let's not ruin a good thing.”\nFather shrugs. “Your loss. Come find me if you change your mind.”\nBut you feel that you haven't lost anything. You're proud of the thriving community you've built.\nGain the Thriving Community milestone (gold), then read 36.2.",
				choices: []
			},
			zh: {
				text: "「嗯，这里算不上最赚钱的地方……」父亲说，「但你确实建起了了不起的东西。」\n「真的吗？」\n「当然。这里古雅小巧，但人们看起来很快乐。他们敬重你，这一点我很欣赏。唉，要是能想个办法从他们身上赚点钱就好了……」\n你摇了摇头。「还是别把好事搞砸了。」\n父亲耸耸肩。「那是你的损失。改变主意了就来找我。」\n但你觉得自己并没有损失什么。你为自己建起的繁荣社区感到自豪。\n获得「繁荣社区」里程碑（金色），然后阅读故事 36.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "31.3",
			en: {
				text: "“It hardly looks any different than it did ten years ago,” Father says, crossing his arms.\n“That's the point, Dad; we're not the only ones that live here.” In the distance, a deer nibbles at a bush near the tree-line.\nHe frowns. “Bah, but there was so much potential!”\n“But at what cost? No, I'm happy with what we've done here, AND what we've left undone.”\nFather grumbles, but all you hear is birdsong and the low roar of the river.\nGain the Conservationist milestone (gold), then read 36.2.",
				choices: []
			},
			zh: {
				text: "「这里和十年前几乎没什么两样。」父亲抱着手臂说。\n「这正是重点，爸；住在这里的不只有我们。」远处，一头鹿正在林线旁的灌木丛里啃食。\n他皱起眉头。「哼，可这里本来有那么多潜力！」\n「但那要付出什么代价？不，我为我们在这里做成的事感到高兴，也为我们没有做的事感到高兴。」\n父亲嘟囔了几句，但你听见的只有鸟鸣和河水低沉的轰鸣。\n获得「环保主义者」里程碑（金色），然后阅读故事 36.2。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "31.4",
			en: {
				text: "“I'm impressed,” Father says. “You've built a community out of nothing, a profitable one, too. And now we can begin tapping its full potential.”\n“We? Together?”\n“Yes! You and me, side by side!” He hugs your shoulder. “We'll become richer than you can possibly imagine!”\nGain the Business Mogul milestone (gold), then read 36.2.",
				choices: []
			},
			zh: {
				text: "「我很佩服你。」父亲说。「你白手起家建起了一个社区，而且还是个能赚钱的社区。现在我们可以开始挖掘它的全部潜力了。」\n「我们？一起？」\n「对！你和我，并肩携手！」他揽住你的肩膀。「我们会变得富得超乎你的想象！」\n获得「商业大亨」里程碑（金色），然后阅读故事 36.2。",
				choices: []
			}
		}
	] },
	32: { blocks: [
		{
			type: "entry",
			id: "32.1",
			en: {
				text: "A clover patch! If you could find a four-leaf clover, you'd be lucky indeed. Unfortunately, after spending an hour searching through the patch, you don't find one. Perhaps there is one elsewhere in town?\nIf you can find the four-leaf clover on the map or on a sticker right now, gain the Lucky milestone (bronze) and cover 32.1 on the map with sticker 9C. Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "一片三叶草地！要是能在这里找到一株四叶草，那你可真是走运了。可惜，你在草丛里翻找了一个钟头，也没能找到。也许镇上别的地方会有？\n如果你现在就能在地图上或某张贴纸上找到四叶草，获得「幸运儿」里程碑（铜色），并用贴纸 9C 覆盖地图上的 32.1 标记。否则，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "32.2",
			en: {
				text: "Read the hint below. If you solve the puzzle, gain the card it points to.\nIf you were to write the names from card 45 on card 44, what letters would the X's represent?",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，获得它指向的卡牌。\n如果把图鉴牌 45 上的名字写到图鉴牌 44 上，那些 X 代表的会是哪些字母？",
				choices: []
			}
		},
		{
			type: "entry",
			id: "32.3",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "32.4",
			en: {
				text: "“Disappointing,” Lady Abigail says. “This stage is quite small. I was hoping for something grander, like an opera house.” She sighs, then turns to you. “Who did you book for our first show?” Either say A “The Symphony,” or B “Big Band of Swing.”",
				choices: [{
					key: "a",
					text: "“Bach is simply divine!” Cover 32.4 on this page with a heart sticker."
				}, {
					key: "b",
					text: "“What is this NOISE?” Abigail asks as she covers her ears. Cover 32.4 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「真令人失望。」阿比盖尔女士说。「这个舞台太小了。我本来指望更气派一些，比如一座歌剧院。」她叹了口气，然后转向你。「我们首场演出请的是谁？」你可以说 A「交响乐团」，或 B「摇摆大乐团」。",
				choices: [{
					key: "a",
					text: "「巴赫简直就是神！」用爱心贴纸覆盖本页的 32.4。"
				}, {
					key: "b",
					text: "「这是什么噪音？」阿比盖尔捂着耳朵问道。用进度贴纸覆盖本页的 32.4。"
				}]
			}
		},
		{
			type: "entry",
			id: "32.5",
			en: {
				text: "“A play would be fabulous; perhaps Shakespeare?” Either hire A professional Shakespeare thespians, or B a low-brow improv comedy group.",
				choices: [{
					key: "a",
					text: "Lady Abigail sighs and puts her hand over her heart. “There will never be a finer tragedy than Romeo and Juliet.” Cover 32.5 on this page with a heart sticker."
				}, {
					key: "b",
					text: "The crowd loves it, and you sell tons of tickets. Lady Abigail, however, is visibly upset. “What is this drivel?” she complains. Gain 1 gold and cover 32.5 on this page with a progress sticker."
				}]
			},
			zh: {
				text: "「演一出戏会很棒，也许可以演莎士比亚？」选择 A 聘请专业的莎士比亚剧团，或 B 请一个低俗的即兴喜剧团。",
				choices: [{
					key: "a",
					text: "阿比盖尔女士叹了口气，把手放在胸口。「再没有比《罗密欧与朱丽叶》更精彩的悲剧了。」用爱心贴纸覆盖本页的 32.5。"
				}, {
					key: "b",
					text: "观众们很喜欢，你卖出了大量门票。然而阿比盖尔女士明显很不高兴。「这算什么胡言乱语？」她抱怨道。获得 1 枚金币，并用进度贴纸覆盖本页的 32.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "32.6",
			en: {
				text: "Cover 32.3 on the map with sticker 9C. If 2 heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“We've impressed the theatre community and now the BALLET is coming to town! My dreams are coming true!” Gain the Patron of the Arts milestone (silver)."
				}, {
					key: "b",
					text: "“You betrayed me!” Lady Abigail cries. “I thought we were bringing CULTURE to the people, not garbage!” She storms off. You shrug and welcome Ronny Donny Dingdong onto the stage. You pocket the profits and cheer along with the audience. Gain 2 gold and 1 happiness. Then place 1 upset sticker on the map near Lady Abigail."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 32.3 标记。如果本页有 2 枚爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「我们打动了戏剧界，现在芭蕾舞团要来镇上了！我的梦想成真了！」获得「艺术赞助人」里程碑（银色）。"
				}, {
					key: "b",
					text: "「你背叛了我！」阿比盖尔女士哭喊道。「我以为我们是给人们带来文化，不是垃圾！」她愤然离去。你耸耸肩，欢迎罗尼·唐尼·叮咚登台。你把利润收入囊中，和观众一起欢呼。获得 2 枚金币和 1 点心情。然后在阿比盖尔女士附近的地图上放置 1 枚不满贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "32.7",
			en: {
				text: "Over the next few days, Patch becomes increasingly aloof. One morning he wanders into the woods and never returns. It's ok though, you know he's with his own kind. Remove Patch (the wolf pup sticker) from the map.",
				choices: []
			},
			zh: {
				text: "接下来的几天里，帕奇越来越疏远。一天早晨，他走进树林，再也没有回来。不过这没关系，你知道他和同类在一起。将帕奇（狼崽贴纸）从地图上移除。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "32.8",
			en: {
				text: "You survey your property, looking for an obvious landmark where the Cobblepots might have hid the money, but nothing stands out. Maybe further downriver? Either A swim downriver, or B spend 1 wood to make a temporary raft.",
				choices: [{
					key: "a",
					text: "You're soaking wet, but you've completed your survey and found nothing. Place 1 heart sticker on card 44."
				}, {
					key: "b",
					text: "You build a raft and survey the river. You don't find any clues, but at least you've eliminated some options. Place 2 heart stickers on card 44."
				}]
			},
			zh: {
				text: "你勘察自己的土地，寻找科布尔波特一家可能藏钱的显眼地标，但没有任何东西引起注意。也许要到河的下游看看？选择 A 游向下游，或 B 花费 1 份木材造一只临时木筏。",
				choices: [{
					key: "a",
					text: "你浑身湿透，但完成了勘察，什么也没找到。在图鉴牌 44 上放置 1 枚爱心贴纸。"
				}, {
					key: "b",
					text: "你造了一只木筏，沿河勘察。你没有找到任何线索，但至少排除了一些可能。在图鉴牌 44 上放置 2 枚爱心贴纸。"
				}]
			}
		}
	] },
	33: { blocks: [
		{
			type: "entry",
			id: "33.1",
			en: {
				text: "Read the first story below that does not have a sticker on it.",
				choices: []
			},
			zh: {
				text: "阅读下方第一个尚未贴贴纸的故事。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "33.2",
			en: {
				text: "“I'm struggling to make ends meet; can you help?” Either A say, “I can't help, sorry,” or B spend 1 gold to hire Jordan to play reveille each morning.",
				choices: [{
					key: "a",
					text: "Jordan makes a sad WAH-WAH-WAHHH sound with their trumpet. Cover 33.2 on this page with a progress sticker."
				}, {
					key: "b",
					text: "“I'll make sure everyone wakes up early!” Cover 33.2 on this page with a heart sticker."
				}]
			},
			zh: {
				text: "「我快入不敷出了，你能帮帮我吗？」选择 A 说「抱歉，我帮不了你」，或 B 花费 1 枚金币聘请乔丹，每天早上吹起床号。",
				choices: [{
					key: "a",
					text: "乔丹用小号吹出一声难过的「哇——哇——哇——」。用进度贴纸覆盖本页的 33.2。"
				}, {
					key: "b",
					text: "「我会保证让每个人都早起！」用爱心贴纸覆盖本页的 33.2。"
				}]
			}
		},
		{
			type: "entry",
			id: "33.3",
			en: {
				text: "The neighbors keep complaining about Jordan practicing trumpet late at night. Either A reprimand Jordan, or B let them keep playing.",
				choices: [{
					key: "a",
					text: "“I really need practice, but I guess I can stop.” Cover 33.3 on this page with a progress sticker."
				}, {
					key: "b",
					text: "Jordan is playing well past midnight and the neighbors are not happy. Cover 33.3 on this page with a heart sticker. Then place 1 upset sticker on the map near a resident that isn't upset."
				}]
			},
			zh: {
				text: "邻居们一直抱怨乔丹深夜练习小号。选择 A 斥责乔丹，或 B 让乔丹继续演奏。",
				choices: [{
					key: "a",
					text: "「我真的很需要练习，不过我想我可以停下来。」用进度贴纸覆盖本页的 33.3。"
				}, {
					key: "b",
					text: "乔丹一直吹到半夜过后，邻居们很不高兴。用爱心贴纸覆盖本页的 33.3。然后在地图上一位没有不满的居民附近放置 1 枚不满贴纸。"
				}]
			}
		},
		{
			type: "entry",
			id: "33.4",
			en: {
				text: "“Would you like to hear the song I've been practicing?” Either say A “Nope,” or B “Sure.”",
				choices: [{
					key: "a",
					text: "Read 33.5."
				}, {
					key: "b",
					text: "It isn't as bad as you feared. In fact, it's quite impressive! Cover 33.4 on this page with a heart sticker, then read 33.5."
				}]
			},
			zh: {
				text: "「你想听听我一直在练的那首曲子吗？」选择 A 说「不想」，或 B 说「好啊」。",
				choices: [{
					key: "a",
					text: "阅读故事 33.5。"
				}, {
					key: "b",
					text: "没有你担心的那么糟。事实上，相当精彩！用爱心贴纸覆盖本页的 33.4，然后阅读故事 33.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "33.5",
			en: {
				text: "Cover 33.1 on the map with sticker 9C. “Oh no, I'm late for my concert!” If 2 or more heart stickers on this page, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "Jordan plays beautifully, and the music washes away your troubles. Either remove 1 red milestone or gain 1 happiness."
				}, {
					key: "b",
					text: "The music hurts your ears, so you sneak out of the performance early. Perform another action."
				}]
			},
			zh: {
				text: "用贴纸 9C 覆盖地图上的 33.1 标记。「糟了，我赶不上演出了！」如果本页有 2 枚或更多爱心贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "乔丹演奏得很美，音乐洗去了你的烦恼。选择移除 1 个红色里程碑，或获得 1 点心情。"
				}, {
					key: "b",
					text: "音乐刺耳，你提前悄悄溜出了演出。额外行动一次。"
				}]
			}
		},
		{
			type: "entry",
			id: "33.6",
			en: {
				text: "Read the hint below. If you solve the puzzle, do as the card instructs.\nOn a piece of paper, write the dates on card 4 in order (lowest to highest), and also rearrange the names on card 31 in the same order. What do the underlined letters mean?",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，就按卡牌上的指示行动。\n在纸上按从低到高的顺序写下图鉴牌 4 上的日期，再按同样的顺序重新排列图鉴牌 31 上的名字。带下划线的字母表示什么？",
				choices: []
			},
			uncertain: []
		},
		{
			type: "entry",
			id: "33.7",
			en: {
				text: "If you chose the Hat Rack sticker, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "“Finally, somewhere to store my animal hats!” Place the Hat Rack sticker on the map near this resident. Then cover 33.7 on card 47 with a heart sticker."
				}, {
					key: "b",
					text: "“I can't store my hats on that!” Cover 33.7 on card 47 with the chosen gift sticker."
				}]
			},
			zh: {
				text: "如果你选择了帽架贴纸，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "「终于有地方放我的动物帽子了！」在地图上这位居民附近放置帽架贴纸。然后用爱心贴纸覆盖图鉴牌 47 上的 33.7。"
				}, {
					key: "b",
					text: "「我才不能把帽子放在那上面！」用选定的礼物贴纸覆盖图鉴牌 47 上的 33.7。"
				}]
			}
		},
		{
			type: "entry",
			id: "33.8",
			en: {
				text: "Read the hint below.\nCount the number of X's and Y's on card 52. Then read story X.Y.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。\n数一数图鉴牌 52 上 X 和 Y 的数量。然后阅读故事 X.Y。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "33.9",
			en: {
				text: "Read the hint below.\nYou cannot solve this puzzle until you have card 4.\nIf you have card 4, read 8.7. Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。\n在你拿到图鉴牌 4 之前，无法解开这个谜题。\n如果你有图鉴牌 4，阅读故事 8.7。否则，额外行动一次。",
				choices: []
			}
		}
	] },
	34: { blocks: [
		{
			type: "entry",
			id: "34.1",
			en: {
				text: "In Cozy Stickerville, your decisions matter. Here's your first taste of a branching path that you've set in motion:\nIf you have built the Lodge, read option A, otherwise read B.",
				choices: [{
					key: "a",
					text: "The year ends with a BANG. Lightning crisscrosses the sky and strikes down the tallest tree in town. There's something unusual about it... Cover a sticker that has exactly 2 trees with a sticker 6V. You will be able to explore this next year. If you want to start year 2 right now, read “Year 2 Setup” on page 2."
				}, {
					key: "b",
					text: "You catch a stranger poking around town and confront her. “I was looking for the Cobblepot fortune,” she says. “They say it's buried nearby, but it's probably just some fool legend. Here, this was my only lead.” The stranger gives you a torn piece of paper, but it doesn't seem to make much sense. Gain card 44. You will be able to use this next year. If you want to start year 2 right now, read “Year 2 Setup” on page 2."
				}]
			},
			zh: {
				text: "在温馨贴纸小镇，你的决定举足轻重。这是你亲手开启的一条分支路线的第一次体验：\n如果你已经建成了小屋，阅读选项 A，否则阅读选项 B。",
				choices: [{
					key: "a",
					text: "这一年在轰然巨响中结束。闪电划过天际，劈倒了镇上最高的那棵树。这棵树有些不同寻常……用贴纸 6V 覆盖一枚恰好画有两棵树的贴纸。你可以在明年探索这里。如果你想现在就开始第 2 年，请阅读第 2 页的「第 2 年岁初设置」。"
				}, {
					key: "b",
					text: "你撞见一个陌生人在镇上四处打探，于是上前质问。她说：「我在找科布尔波特宝藏。据说就埋在附近，不过大概只是个愚蠢的传说。给，这是我唯一的线索。」陌生人递给你一张撕破的纸片，看起来没什么头绪。获得图鉴牌 44。你可以在明年使用它。如果你想现在就开始第 2 年，请阅读第 2 页的「第 2 年岁初设置」。"
				}]
			}
		},
		{
			type: "entry",
			id: "34.2",
			en: {
				text: "A golden idol sits suspiciously on a pedestal. Either A take the idol, or B leave it.",
				choices: [{
					key: "a",
					text: "You grab the idol and are rewarded with a poison dart to the leg. Gain 2 gold and cover 34.2 on card 35A with a heart sticker. Then gain the Poisoned milestone (red) unless you have the Miracle Medicine milestone."
				}, {
					key: "b",
					text: "Cover 34.2 on card 35A with a heart sticker."
				}]
			},
			zh: {
				text: "一尊黄金神像可疑地摆在基座上。选择 A 拿走神像，或 B 放着不管。",
				choices: [{
					key: "a",
					text: "你抓起神像，作为回报，一枚毒镖扎进了你的腿。获得 2 枚金币，并用爱心贴纸覆盖图鉴牌 35A 上的 34.2。然后获得「中毒」里程碑（红色），除非你拥有「灵丹妙药」里程碑。"
				}, {
					key: "b",
					text: "用爱心贴纸覆盖图鉴牌 35A 上的 34.2。"
				}]
			}
		},
		{
			type: "entry",
			id: "34.3",
			en: {
				text: "You hear a “CLICK” and look down to see that you are standing on the pressure plate of a booby trap! Either A try to disarm it, or B spend 1 food to get a burst of energy.",
				choices: [{
					key: "a",
					text: "You can't figure out how the trap works, and it drops a small boulder on your foot! You limp home and put some ice on it. Cover 34.3 on card 35A with a heart sticker."
				}, {
					key: "b",
					text: "You bolt down the corridor as a small boulder narrowly misses your head. Cover 34.3 on card 35A with a heart sticker. Then read 34.5."
				}]
			},
			zh: {
				text: "你听见「咔哒」一声，低头一看，自己正站在一处陷阱的压力板上！选择 A 试着拆除它，或 B 花费 1 份食物来获取一股爆发力。",
				choices: [{
					key: "a",
					text: "你弄不明白这陷阱是怎么运作的，一块小石头砸在了你的脚上！你一瘸一拐地回家，敷了些冰。用爱心贴纸覆盖图鉴牌 35A 上的 34.3。"
				}, {
					key: "b",
					text: "你沿着走廊飞奔，一块小石头擦着你的头飞过。用爱心贴纸覆盖图鉴牌 35A 上的 34.3。然后阅读故事 34.5。"
				}]
			}
		},
		{
			type: "entry",
			id: "34.4",
			en: {
				text: "A locked door. Luckily you've been studying lock-picking. If the X space on card 35A is visible, cover it with a progress sticker. Regardless, then read 34.5.",
				choices: []
			},
			zh: {
				text: "一扇上锁的门。幸好你一直在钻研开锁。如果图鉴牌 35A 上的 X 格可见，就用进度贴纸覆盖它。无论是否覆盖，然后阅读故事 34.5。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "34.5",
			en: {
				text: "You reach the end of the mine, but the final chamber is blocked by a heavy steel door. Do you have a key? Either A keep exploring, or B try to open the door.",
				choices: [{
					key: "a",
					text: "Perform another action."
				}, {
					key: "b",
					text: "If there is a progress sticker on card 35A: You easily unlock the door and find a room full of riches! Discard card 35A. Then gain 1 ore, 3 gold, and the Adventurer milestone (gold).\nOtherwise: You try to pick the lock, and set off another booby trap! The ceiling starts to collapse and you barely escape with your life. Discard card 35A. Then gain 1 gold and the Explorer milestone (silver)."
				}]
			},
			zh: {
				text: "你到达了矿井的尽头，但最后的石室被一扇沉重的钢门挡住。你有钥匙吗？选择 A 继续探索，或 B 试着打开这扇门。",
				choices: [{
					key: "a",
					text: "额外行动一次。"
				}, {
					key: "b",
					text: "如果图鉴牌 35A 上有进度贴纸：你轻松打开了锁，发现一个堆满财富的房间！弃掉图鉴牌 35A。然后获得 1 份矿石、3 枚金币和「冒险家」里程碑（金色）。\n否则：你试着撬锁，却触发了另一处陷阱！天花板开始坍塌，你勉强逃出生天。弃掉图鉴牌 35A。然后获得 1 枚金币和「探险家」里程碑（银色）。"
				}]
			}
		},
		{
			type: "entry",
			id: "34.6",
			en: {
				text: "The library has a book all about hedge mazes and how to hide them. Huh, that's rather niche, don't you think? Read 34.7. You can read the additional hint (26.8) without spending gold.",
				choices: []
			},
			zh: {
				text: "图书馆里有一本书，专门讲树篱迷宫以及如何隐藏它们。呵，这可真够冷门的，你不觉得吗？阅读故事 34.7。你可以不花金币就阅读额外提示（26.8）。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "34.7",
			en: {
				text: "Read the hint below. If you solve the puzzle, read the story it points to.\nLook closely at the map to find all the clues you need to solve this puzzle.\nIf you need an additional hint, spend 1 gold to read 26.8.",
				choices: []
			},
			zh: {
				text: "阅读下方的提示。如果你解开了谜题，就阅读它指向的故事。\n仔细观察地图，找出解开这个谜题所需的全部线索。\n如果你需要额外提示，花费 1 枚金币阅读故事 26.8。",
				choices: []
			}
		}
	] },
	35: { blocks: [
		{
			type: "entry",
			id: "35.1",
			en: {
				text: "Place a heart sticker on the fish below in the row/column matching the die result/amount of food on card 12a (unless it already has a sticker). For example, a roll of 3 with 2 food is a Carp. Regardless, then gain all food on card 12a. Then:\n· If 3 heart stickers on this page, gain the Fisher milestone (bronze).\n· If 6, cover the Fisher milestone with Veteran Fisher (silver).\n· If 9, cover the Veteran Fisher milestone with Pro Angler (gold).\n[Fish table: columns = food 1/2/3, rows = die result]\nSunfish, Carp, Bass\nPerch, Trout, Catfish\nStingray, Salmon, Sturgeon",
				choices: []
			},
			zh: {
				text: "按图鉴牌 12a 上的骰子结果与食物数量，在本页下方对应的行与列相交处找到那条鱼，并在其上放置 1 枚爱心贴纸（除非它已经贴有贴纸）。例如，掷出 3 且拥有 2 份食物，对应的就是鲤鱼。无论是否贴了贴纸，随后获得图鉴牌 12a 上的全部食物。然后：\n· 如果本页有 3 枚爱心贴纸，获得「渔夫」里程碑（铜色）。\n· 如果为 6 枚，用「资深渔夫」（银色）覆盖「渔夫」里程碑。\n· 如果为 9 枚，用「钓鱼高手」（金色）覆盖「资深渔夫」里程碑。\n（鱼图：列为食物 1／2／3 枚，行为骰子结果）\n太阳鱼、鲤鱼、鲈鱼\n河鲈、鳟鱼、鲶鱼\n魟鱼、鲑鱼、鲟鱼",
				choices: []
			}
		},
		{
			type: "entry",
			id: "35.2",
			en: {
				text: "If 5 or more political stickers (11C) on the map, read option A. Otherwise, read 35.5.",
				choices: [{
					key: "a",
					text: "The people elect you as the first mayor of this village! Gain card 13."
				}]
			},
			zh: {
				text: "如果地图上有 5 枚或更多政治贴纸 11C，阅读选项 A。否则，阅读故事 35.5。",
				choices: [{
					key: "a",
					text: "居民们推选你成为这个村庄的第一任市长！获得图鉴牌 13。"
				}]
			}
		},
		{
			type: "entry",
			id: "35.3",
			en: {
				text: "This is the perfect place for a fishing boat! You may spend 1 wood to cover 35.3 on the map with sticker 6Y and gain card 12. (Reminder: Use card 12a unless this is your second playthrough.) Otherwise, perform another action.",
				choices: []
			},
			zh: {
				text: "这里正是停放渔船的好地方！你可以花费 1 份木材，用贴纸 6Y 覆盖地图上的 35.3 标记，并获得图鉴牌 12。（提醒：除非这是你的第二遍游戏，否则使用图鉴牌 12a。）否则，额外行动一次。",
				choices: []
			}
		},
		{
			type: "entry",
			id: "35.4",
			en: {
				text: "You find some wild carrots growing in the field. A cute brown rabbit is nibbling at them. Either A chase the rabbit off, or B watch it eat.",
				choices: [{
					key: "a",
					text: "Gain 1 food and cover 35.4 on the map with sticker 9C."
				}, {
					key: "b",
					text: "Lose 1 food (if able). Then cover 35.4 on the map with sticker 3B."
				}]
			},
			zh: {
				text: "你发现田里长着一些野胡萝卜。一只可爱的棕色兔子正在啃食。选择 A 把兔子赶走，或 B 看着它吃。",
				choices: [{
					key: "a",
					text: "获得 1 份食物，并用贴纸 9C 覆盖地图上的 35.4 标记。"
				}, {
					key: "b",
					text: "失去 1 份食物（如果可以）。然后用贴纸 3B 覆盖地图上的 35.4 标记。"
				}]
			}
		},
		{
			type: "entry",
			id: "35.5",
			en: {
				text: "You didn't rally enough people to your cause, and Mustache Steve wins the popular vote. Either A accept defeat, or B declare the vote invalid.",
				choices: [{
					key: "a",
					text: "You accept defeat with grace, even though this means that out-of-town creep is the new mayor. Gain card 15."
				}, {
					key: "b",
					text: "Congratulations, now YOU are the new mayor! Not everyone is happy about this. Gain card 14."
				}]
			},
			zh: {
				text: "你没能为自己的主张争取到足够多的支持者，八字胡史蒂夫赢得了普选。选择 A 接受失败，或 B 宣布选举无效。",
				choices: [{
					key: "a",
					text: "你体面地接受了失败，尽管这意味着那个外乡讨厌鬼成了新市长。获得图鉴牌 15。"
				}, {
					key: "b",
					text: "恭喜，现在你就是新市长了！并非所有人都为此高兴。获得图鉴牌 14。"
				}]
			}
		},
		{
			type: "entry",
			id: "35.6",
			en: {
				text: "An empty intersection, but your torch is running low. Cover 35.6 on card 35A with a heart sticker. You may spend 1 wood to perform another action.",
				choices: []
			},
			zh: {
				text: "一个空荡荡的十字路口，但你的火把快燃尽了。用爱心贴纸覆盖图鉴牌 35A 上的 35.6。你可以花费 1 份木材，额外行动一次。",
				choices: []
			}
		}
	] },
	36: { blocks: [
		{
			type: "entry",
			id: "36.1",
			en: {
				text: "Place a heart sticker on the fish below in the row/column matching the die result/amount of food on card 12A (unless it already has a sticker). For example, a roll of 3 with 2 food is a Carp. Regardless, then gain all food on card 12A. Then:\n· If 3 heart stickers on this page, gain the Fisher milestone (bronze).\n· If 6, cover the Fisher milestone with Veteran Fisher (silver).\n· If 9, cover the Veteran Fisher milestone with Pro Angler (gold).\nFish table (rows: die result, columns: food 1/2/3):\nSunfish, Carp, Bass\nPerch, Trout, Catfish\nZebrafish, Salmon, Sturgeon",
				choices: []
			},
			zh: {
				text: "按图鉴牌 12A 上的骰子结果与食物数量，在本页下方对应的行与列相交处找到那条鱼，并在其上放置 1 枚爱心贴纸（除非它已经贴有贴纸）。例如，掷出 3 且拥有 2 份食物，对应的就是鲤鱼。无论是否贴了贴纸，随后获得图鉴牌 12A 上的全部食物。然后：\n· 如果本页有 3 枚爱心贴纸，获得「渔夫」里程碑（铜色）。\n· 如果为 6 枚，用「资深渔夫」（银色）覆盖「渔夫」里程碑。\n· 如果为 9 枚，用「钓鱼高手」（金色）覆盖「资深渔夫」里程碑。\n（鱼图：列为食物 1／2／3 枚，行为骰子结果）\n太阳鱼、鲤鱼、鲈鱼\n河鲈、鳟鱼、鲶鱼\n斑马鱼、鲑鱼、鲟鱼",
				choices: []
			}
		},
		{
			type: "entry",
			id: "36.2",
			en: {
				text: "Congratulations on finishing all 10 years!\nYour completed village is now ready to welcome visitors.\nScan the QR code with your phone or visit the following website: UnexpectedGames.com/csvtourism\nYou can play a second time using the other side of the map to see how differently the story could have gone. Use the following rules to prepare for your second playthrough:\n· Some buildings and residents used in your first village cannot be placed in your second village. To track this, place all 7X stickers over the invalid options. Find the 16 event cards with a pink flower in the bottom left corner. Place a 7X sticker over the building, resident, or choice used in your first village. Year 1 has four of these cards, and most other years have one or two.\nIf you are unsure of which option to cover, find which sticker you still have in the sticker book and cover the other option.\nThen return all cards back to their appropriate decks and organize your catalog deck in order by number.\n· Use the other side of the map for your second game. When setting up your first year, use the 8 remaining starting stickers on page 9 of the sticker book.\n· When using a catalog card with an A or B in its card number, (for example 12A), use the B version of the card instead of A.",
				choices: []
			},
			zh: {
				text: "恭喜你完成了全部 10 年！\n你建成的村庄现在已准备好迎接访客。\n用手机扫描二维码，或访问以下网站：UnexpectedGames.com/csvtourism\n你可以使用地图的另一面再玩一次，看看故事还能如何发展。请按以下规则为第二遍游戏做准备：\n· 第一座村庄中使用过的一些建筑和居民无法在第二座村庄中放置。为了记录这一点，请用 7X 贴纸覆盖所有不可用的选项。找出左下角印有粉色花朵图标的 16 张事件牌。用 7X 贴纸覆盖你在第一座村庄中使用过的建筑、居民或选项。第 1 年有 4 张这类牌，其余年份大多有一两张。\n如果不确定该覆盖哪个选项，就看看贴纸册里还剩哪张贴纸，覆盖另一个选项。\n然后把所有卡牌放回各自对应的牌堆，并按编号顺序整理你的图鉴牌堆。\n· 第二局游戏请使用地图的另一面。设置第 1 年时，使用贴纸册第 9 页上剩余的 8 枚起始贴纸。\n· 使用编号中带有 A 或 B 的图鉴牌时（例如 12A），请使用该牌的 B 版本，而不是 A 版本。",
				choices: []
			}
		},
		{
			type: "note",
			en: { text: "Examples of placing sticker 7X on event cards" },
			zh: { text: "在事件牌上放置贴纸 7X 的示例。" }
		}
	] }
}, sr = {
	1: {
		name: {
			en: "DILL",
			zh: "迪尔"
		},
		en: { printed: "Dill is a novice farmer who would love to plant cucumbers in town!\nPlace sticker 8A.\nKeep this card in play.\nPLANT CUCUMBER PATCH: Discard this and place sticker 6M." },
		zh: { printed: "迪尔是个新手农夫，很希望能在地里种上黄瓜！\n放置贴纸 8A。\n将此牌留在场上。\n种植黄瓜地：弃掉此牌并放置贴纸 6M。" },
		uncertain: []
	},
	2: {
		name: null,
		en: { printed: "“I dream of starting my own canned food company. I’ve got some investors, but I need a little more money to build the factory.”\nPlace sticker 6B.\nKeep this card in play.\nBUILD FACTORY: Discard this and place sticker 11R overlapping a river (even if you don't have a bridge)." },
		zh: { printed: "「我梦想创办一家自己的罐头食品公司。我已经有了一些投资人，但还需要一点钱来建工厂。」\n放置贴纸 6B。\n将此牌留在场上。\n建造工厂：弃掉此牌，并放置贴纸 11R，使其叠放在河流上（即使你还没有桥）。" },
		uncertain: []
	},
	4: {
		name: null,
		en: { printed: "The tombs are empty, for now.\nAlong the back wall hangs an ornate brass plaque — or at least half of one.\nSomething looks wrong about the dates.\n1822 - SECOND AWAKENING\n1915 - MODERN ORDER\n1904 - IRVING REBELLION\n1801 - THE FOUNDING\n1883 - FIRST ABBEY\nCover 22.1 on the map with sticker 9C.\nKeep this card in play. You'll need another card to use it." },
		zh: { printed: "墓穴暂时空无一物。\n后墙上挂着一块华丽的黄铜铭牌——至少是半块。\n上面的日期看起来有些不对劲。\n1822 - 第二次觉醒\n1915 - 现代秩序\n1904 - 欧文叛乱\n1801 - 创立\n1883 - 第一修道院\n用贴纸 9C 覆盖地图上的 22.1。\n将此牌留在场上。你需要另一张牌才能使用它。" },
		uncertain: []
	},
	5: {
		name: null,
		en: { printed: "You take the governorship and start planning your next ambition.\nCover your “Politics 1” milestone with Governor (silver).\nKeep this card in play.\nGRAND AMBITION: Read the story based on the number of stickers on this card:\n0: 25.4\n1: 25.5\n2: 25.6" },
		zh: { printed: "你接任了州长，并开始筹划你的下一个抱负。\n用州长（银）覆盖你的「政治 1」里程碑。\n将此牌留在场上。\n宏大抱负：根据此牌上的贴纸数量阅读故事：\n0 枚：25.4\n1 枚：25.5\n2 枚：25.6" },
		uncertain: []
	},
	6: {
		name: null,
		en: { printed: "Keep this card in play.\nDECIPHER LANGUAGE: Place all 1D stickers on the proper spaces of this card. If they are already placed, instead place all 5P stickers." },
		zh: { printed: "将此牌留在场上。\n解读语言：将所有 1D 贴纸放置到此牌对应的格位上。若这些贴纸已经放置，则改为放置所有 5P 贴纸。" },
		uncertain: []
	},
	7: {
		name: null,
		en: { printed: "The first step to creating a functional government is electing a mayor. You'd like to win fair and square, but that will involve winning the hearts of the people.\nPlace sticker 6F.\nKeep this card in play.\nRUN FOR MAYOR: Place 2 political stickers 11C. You may spend 1 gold to place 1 additional. Then, if you think you have enough support, discard this and read 35.2. Otherwise, keep this in play." },
		zh: { printed: "建立一个运转良好的政府，第一步是选出一位市长。你希望堂堂正正地赢下选举，但这需要赢得民心。\n放置贴纸 6F。\n将此牌留在场上。\n竞选市长：放置 2 枚政治贴纸 11C。你可以花费 1 枚金币额外放置 1 枚。然后，若你认为支持已经足够，弃掉此牌并阅读故事 35.2；否则将此牌留在场上。" },
		uncertain: []
	},
	8: {
		name: null,
		en: { printed: "Place sticker 10A.\nKeep this card in play.\nADOPT FARM ANIMALS: Place 2 farm animal stickers 11B. Then, if 4 have been placed, discard this and gain card 17.\nBUY SEEDS: Place sticker 6N or 6P. Then, if both have been placed, discard this and gain card 16." },
		zh: { printed: "放置贴纸 10A。\n将此牌留在场上。\n领养农场动物：放置 2 枚农场动物贴纸 11B。然后，若已放置 4 枚，弃掉此牌并获得图鉴牌 17。\n购买种子：放置贴纸 6N 或 6P。然后，若两者均已放置，弃掉此牌并获得图鉴牌 16。" },
		uncertain: []
	},
	9: {
		name: null,
		en: { printed: "The market is a great place to buy and sell goods. It also brings the village closer together!\nPlace sticker 6D.\nKeep this card in play.\nBUY AND SELL: Exchange up to 3 resources for resources of any type(s) except ore." },
		zh: { printed: "集市是买卖货物的好地方。它也让村民之间的关系更加紧密！\n放置贴纸 6D。\n将此牌留在场上。\n买卖：将至多 3 份资源兑换为除矿石以外任意类型的资源。" },
		uncertain: []
	},
	10: {
		name: null,
		en: { printed: "Beautify the town and make money from your neighbors. Win/win.\nPlace sticker 7B.\nKeep this card in play.\nSELL CARPENTRY: Gain 2 gold and place 1 carpentry sticker 11D. Then, if 3 have been placed, discard this." },
		zh: { printed: "美化小镇，还能从邻居身上赚钱。双赢。\n放置贴纸 7B。\n将此牌留在场上。\n出售木工制品：获得 2 枚金币并放置 1 枚木工贴纸 11D。然后，若已放置 3 枚，弃掉此牌。" },
		uncertain: []
	},
	11: {
		name: null,
		en: { printed: "Bees buzz about their business, making liquid gold.\nPlace the honey tree sticker 6G.\nKeep this card in play.\nBUILD APIARY: Discard this and place sticker 5B on the same sticker as the honey tree.\nDECEMBER\nEND OF THE YEAR: Discard this and place sticker 11N on the same sticker as the honey tree." },
		zh: { printed: "蜜蜂们忙碌地飞来飞去，酿造着液态黄金。\n放置蜂蜜树贴纸 6G。\n将此牌留在场上。\n建造蜂房：弃掉此牌，将贴纸 5B 放置在蜂蜜树贴纸所在的同一位置。\n十二月\n岁末：弃掉此牌，将贴纸 11N 放置在蜂蜜树贴纸所在的同一位置。" },
		uncertain: []
	},
	13: {
		name: {
			en: "MAYOR AMBITION",
			zh: "市长抱负"
		},
		en: { printed: "Gain the Mayor milestone (bronze).\nKeep this card in play.\nRUN FOR GOVERNOR: If you have 5 or more happiness, read 9.3.\nRAISE TAXES: If you have 9 or more residents, read 22.8." },
		zh: { printed: "获得市长里程碑（铜）。\n将此牌留在场上。\n竞选州长：若你的心情达到 5 或以上，阅读故事 9.3。\n征税：若你的居民数达到 9 或以上，阅读故事 22.8。" },
		uncertain: []
	},
	14: {
		name: {
			en: "DICTATOR AMBITION",
			zh: "独裁者抱负"
		},
		en: { printed: "Gain the Dictator milestone (bronze).\nKeep this card in play.\nTIGHTEN YOUR GRIP: If you have 7 or more residents, read 22.8.\nRUN FOR GOVERNOR: If you have 7 or more happiness, read 9.3." },
		zh: { printed: "获得独裁者里程碑（铜）。\n将此牌留在场上。\n收紧掌控：若你的居民达到 7 名或以上，阅读故事 22.8。\n竞选州长：若你的心情达到 7 点或以上，阅读故事 9.3。" },
		uncertain: []
	},
	15: {
		name: null,
		en: { printed: "You can't believe Mustache Steve is the mayor. He's so annoying!\nWhat are you going to do?\nGain the Runner Up milestone (bronze).\nKeep this card in play.\nBECOME MORE POPULAR: If you have 6 or more happiness, read 27.1.\nSEIZE POWER: If you have 8 or more residents, read 27.7." },
		zh: { printed: "你简直不敢相信大胡子史蒂夫当上了市长。他太烦人了！\n你打算怎么办？\n获得亚军里程碑（铜）。\n将此牌留在场上。\n变得更受欢迎：若你的心情达到 6 点或以上，阅读故事 27.1。\n夺取权力：若你的居民达到 8 名或以上，阅读故事 27.7。" },
		uncertain: []
	},
	16: {
		name: {
			en: "FARM HAND AMBITION",
			zh: "农场帮工抱负"
		},
		en: { printed: "Gain the Farm Hand milestone (bronze).\nKeep this card in play.\nFRUITS AND VEGGIES: If 7 or more apple icons on the map, discard this and gain card 26.\nFURRY FRIENDS: If 5 or more animal stickers on the map, discard this and gain card 27.\n(Only count each animal that is on its own sticker, not part of another sticker.)" },
		zh: { printed: "获得农场帮工里程碑（铜）。\n将此牌留在场上。\n蔬果：若地图上的苹果图标达到 7 个或以上，弃掉此牌并获得图鉴牌 26。\n毛茸茸的朋友：若地图上的动物贴纸达到 5 枚或以上，弃掉此牌并获得图鉴牌 27。\n（只计入单独贴在一张贴纸上的动物，不计入作为其他贴纸一部分的动物。）" },
		uncertain: []
	},
	17: {
		name: {
			en: "RANCHER AMBITION",
			zh: "牧场主雄心"
		},
		en: { printed: "Gain the Rancher milestone (bronze).\nKeep this card in play.\nFRUITS AND VEGGIES: If 5 or more apple icons on the map, discard this and gain card 26.\nFURRY FRIENDS: If 7 or more animal stickers on the map, discard this and gain card 27. (Only count each animal that is on its own sticker, not part of another sticker.)" },
		zh: { printed: "获得牧场主里程碑（铜）。\n将此牌留在场上。\n蔬果：若地图上有 5 个或更多苹果图标，弃掉此牌并获得图鉴牌 26。\n毛茸茸的朋友：若地图上有 7 枚或更多动物贴纸，弃掉此牌并获得图鉴牌 27。（只计入各自独立贴纸上的动物，不计入其他贴纸上的动物。）" },
		uncertain: []
	},
	18: {
		name: null,
		en: { printed: "One tree is burned to a crisp, but the other has strange markings on it that almost look like... writing? You'll need something to decipher it.\nCover 18 on the map with sticker 9C.\nKeep this card in play." },
		zh: { printed: "一棵树被烧得焦黑，另一棵树上却有些奇怪的痕迹，看上去几乎像是……文字？你需要有样东西来解读它。\n用贴纸 9C 覆盖地图上的 18。\n将此牌留在场上。" },
		uncertain: []
	},
	19: {
		name: null,
		en: { printed: "Meow, bark, purr, and woof. These are the most important words in your vocabulary.\nPlace sticker 4A.\nKeep this card in play.\nSELL PETS: Gain 1 gold and place 2 pet stickers 11G. Then, if 4 have been placed, discard this and gain card 23." },
		zh: { printed: "喵、汪、呼噜、嗷呜。这些是你词汇表里最重要的词。\n放置贴纸 4A。\n将此牌留在场上。\n出售宠物：获得 1 枚金币并放置 2 枚宠物贴纸 11G。然后，若已放置 4 枚，弃掉此牌并获得图鉴牌 23。" },
		uncertain: []
	},
	20: {
		name: null,
		en: { printed: "You're gonna need both arms (and maybe a wheelbarrow) to carry these pastries.\nPlace sticker 4B.\nKeep this card in play.\nSELL GIANT PASTRY: Gain 2 gold and place 1 pastry sticker 11F (on the map or on another sticker). Then, if 2 have been placed, discard this and gain card 24." },
		zh: { printed: "你得用上两条胳膊（也许还得来一辆独轮车）才搬得动这些糕点。\n放置贴纸 4B。\n将此牌留在场上。\n出售巨型糕点：获得 2 枚金币并放置 1 枚糕点贴纸 11F（可放在地图上，也可放在另一张贴纸上）。然后，若已放置 2 枚，弃掉此牌并获得图鉴牌 24。" },
		uncertain: []
	},
	21: {
		name: null,
		en: { printed: "\"I love being a teacher, so I don't mind the commute,\" Mrs. Conners says, \"but it would be easier if my family had a home in town.\"\nPlace sticker 4D.\nKeep this card in play.\nBUILD LARGE HOME: Discard this and place sticker 4E." },
		zh: { printed: "「我喜欢当老师，所以不介意通勤，」康纳斯太太说，「但如果我的家人在镇上有一座房子，那就方便多了。」\n放置贴纸 4D。\n将此牌留在场上。\n建造大房子：弃掉此牌并放置贴纸 4E。" },
		uncertain: []
	},
	22: {
		name: null,
		en: { printed: "With this letter, you should be able to find the Cobblepot Fortune!\nKeep this card in play.\nDearest Herbert,\nIn case you ever need to find it again, dig at coordinates X.Y. I'm counting on you!\n—Beatrice\nCRACK THE CODE: Solve the puzzle and read the story it points to. If the story does not start with the word \"Using,\" you are incorrect.\nIf you need a hint, read 11.7." },
		zh: { printed: "凭这封信，你应该就能找到科布尔波特宝藏了！\n将此牌留在场上。\n亲爱的赫伯特：\n万一你以后还需要找到它，就在坐标 X.Y 处挖掘。全靠你了！\n——比阿特丽斯\n破解密码：解开谜题，并阅读它指向的故事。若故事不是以「Using」一词开头，说明你的答案有误。\n如需提示，阅读故事 11.7。" },
		uncertain: []
	},
	23: {
		name: null,
		en: { printed: "Cats and dogs are nice, but some people want more unique pets. Llamas, parrots, and pigs; oh my!\nKeep this card in play.\nSELL EXOTIC PET: Gain 2 gold and place 1 exotic pet sticker 12F. Then, if 2 have been placed, discard this and gain card 57." },
		zh: { printed: "猫和狗固然不错，但有些人想要更独特的宠物。羊驼、鹦鹉，还有猪；天哪！\n将此牌留在场上。\n出售异域宠物：获得 2 枚金币并放置 1 枚异域宠物贴纸 12F。然后，若已放置 2 枚，弃掉此牌并获得图鉴牌 57。" },
		uncertain: []
	},
	24: {
		name: null,
		en: { printed: "Bigger is better. This is especially true for anything covered in frosting.\nGain the Famous Baker milestone (silver).\nKeep this card in play.\nSELL GIANT CAKE: Gain 2 gold and place 1 cake sticker 12G (on the map or on another sticker). Then, if 2 have been placed, discard this, and gain card 28." },
		zh: { printed: "越大越好。对于任何裹着糖霜的东西来说，更是如此。\n获得著名烘焙师里程碑（银）。\n将此牌留在场上。\n出售巨型蛋糕：获得 2 枚金币并放置 1 枚蛋糕贴纸 12G（可放在地图上，也可放在另一张贴纸上）。然后，若已放置 2 枚，弃掉此牌，并获得图鉴牌 28。" },
		uncertain: []
	},
	25: {
		name: null,
		en: { printed: "\"Will you be my friend?\" the wooden doll asks. \"We'll be best friends forever!\"\nNicholas is an amazing ventriloquist!\nPlace sticker 8P.\nKeep this card in play.\nSELL TOY: Gain 3 gold and place 1 toy sticker 11Q. Then, if 2 have been placed, discard this and gain 1 happiness." },
		zh: { printed: "「你会做我的朋友吗？」木偶问道。「我们会永远是最好的朋友！」\n尼古拉斯是一位了不起的口技演员！\n放置贴纸 8P。\n将此牌留在场上。\n出售玩具：获得 3 枚金币并放置 1 枚玩具贴纸 11Q。然后，若已放置 2 枚，弃掉此牌并获得 1 点心情。" },
		uncertain: []
	},
	26: {
		name: null,
		en: { printed: "Your farm has swelled in size, and now you're running out of room to store your harvest.\nCover your \"Farming 1\" milestone with Green Thumb (silver).\nKeep this card in play.\nBUILD SILO: Gain 1 food and place sticker 4X. Limit once (do not discard).\nFEED THE PEOPLE: If you have built the Silo, discard this and cover the Green Thumb milestone with Master of Agriculture (gold)." },
		zh: { printed: "你的农场不断扩大，如今已经快没有地方存放收成了。\n用园艺高手（银）覆盖你的「农耕 1」里程碑。\n将此牌留在场上。\n建造筒仓：获得 1 份食物并放置贴纸 4X。限一次（不要弃掉此牌）。\n供养民众：若你已建造筒仓，弃掉此牌，并用农业大师（金）覆盖园艺高手里程碑。" },
		uncertain: []
	},
	27: {
		name: null,
		en: { printed: "You feel a connection with the farm animals and find peace in the work.\nCover your \"Farming 1\" milestone with Veteran Rancher (silver).\nKeep this card in play.\nBUILD DAIRY FARM: Discard this and place sticker 10D." },
		zh: { printed: "你与农场动物之间建立了联系，并在这份劳作中找到了平静。\n用资深牧场主（银）覆盖你的「农耕 1」里程碑。\n将此牌留在场上。\n建造奶牛场：弃掉此牌并放置贴纸 10D。" },
		uncertain: []
	},
	28: {
		name: null,
		en: { printed: "Your popularity as a local baker has earned you a spot in the nearby city's International Bake Off!\nKeep this card in play.\nBAKING COMPETITION: How much do you want to invest in this competition? Spend 0 to 5 food, then read 26.6." },
		zh: { printed: "你作为本地烘焙师的名气，为你赢得了附近城市国际烘焙大赛的参赛资格！\n将此牌留在场上。\n烘焙比赛：你想在这场比赛中投入多少？花费 0 至 5 份食物，然后阅读故事 26.6。" },
		uncertain: []
	},
	29: {
		name: null,
		en: { printed: "Gain the Dating milestone (bronze).\nKeep this card in play.\nDATE FARMER DILL: Read the story based on the number of stickers on this card:\n0: 10.7\n1: 11.1\n2: 11.2\n3: 11.3\n4: 11.4\n5: 11.5" },
		zh: { printed: "获得恋爱中里程碑（铜）。\n将此牌留在场上。\n与农夫迪尔约会：根据此牌上的贴纸数量阅读对应故事：\n0 枚：10.7\n1 枚：11.1\n2 枚：11.2\n3 枚：11.3\n4 枚：11.4\n5 枚：11.5" },
		uncertain: []
	},
	30: {
		name: null,
		en: { printed: "Gain the Matchmaker milestone (silver) and cover 10.1 on the map with sticker 9C.\nKeep this card in play.\nASK ABOUT RELATIONSHIP: Read the story based on the number of stickers on this card:\n0: 11.6\n1: 12.1\n2: 12.2\n3: 12.3" },
		zh: { printed: "获得媒人里程碑（银），并用贴纸 9C 覆盖地图上的 10.1 标记。\n将此牌留在场上。\n询问感情状况：根据此牌上的贴纸数量阅读对应故事：\n0 枚：11.6\n1 枚：12.1\n2 枚：12.2\n3 枚：12.3" },
		uncertain: []
	},
	31: {
		name: null,
		en: { printed: "The room contains sculptures of famous members throughout the ages.\nOn the wall you see a large brass plaque, but you'll need the other half to make sense of it.\nKeep this card in play.\nRACHEL YEARTH\nTOM NELSON\nPRESTON IRVING\nSTEWART OLSON\nIRENE TROMBLY\nCRACK THE CODE: Follow the instructions hidden on these cards. If you need a hint, read 33.9." },
		zh: { printed: "房间里陈列着历代著名成员的雕像。\n墙上挂着一块巨大的黄铜铭牌，但你需要找到另一半才能看懂它。\n将此牌留在场上。\n雷切尔·耶思（RACHEL YEARTH）\n汤姆·纳尔逊（TOM NELSON）\n普雷斯顿·欧文（PRESTON IRVING）\n斯图尔特·奥尔森（STEWART OLSON）\n艾琳·特龙布利（IRENE TROMBLY）\n破解密码：按照这些卡牌上隐藏的指示操作。如需提示，阅读故事 33.9。" },
		uncertain: []
	},
	32: {
		name: null,
		en: { printed: "Place sticker 4K.\nKeep this card in play.\nBUY FISHING GEAR: Buy 1 of the following. After buying both, discard this.\n· Shiny Lure: Place sticker 1B on card 12A or 12B.\n· Fancy Pole: Place sticker 1C on card 12A or 12B." },
		zh: { printed: "放置贴纸 4K。\n将此牌留在场上。\n购买渔具：从下列物品中购买 1 件。两件都购买后，弃掉此牌。\n· 闪亮假饵：在图鉴牌 12A 或 12B 上放置贴纸 1B。\n· 精美鱼竿：在图鉴牌 12A 或 12B 上放置贴纸 1C。" },
		uncertain: []
	},
	33: {
		name: null,
		en: { printed: "Cover the Market with sticker 8K.\nKeep this card in play.\nBUY AND SELL: Exchange up to 4 resources for resources of any type(s). To gain ore in this way, you must exchange 2 resources for 1 ore." },
		zh: { printed: "用贴纸 8K 覆盖市场。\n将此牌留在场上。\n买卖：将至多 4 份资源兑换为任意类型的资源。若要以这种方式获得矿石，你必须用 2 份资源兑换 1 份矿石。" },
		uncertain: []
	},
	34: {
		name: null,
		en: { printed: "The library is stuffed with knowledge on every conceivable topic: science, history, cooking, and even arcane mysteries.\nPlace sticker 7H.\nKeep this card in play; you can use it at any time.\nRESEARCH TOPICS: Before reading a story entry that is underlined, you may instead read the entry immediately before it. For example, if a card or sticker tells you to read 3.2, you may instead read 3.1." },
		zh: { printed: "图书馆里塞满了各种门类的知识：科学、历史、烹饪，甚至还有神秘的秘术。\n放置贴纸 7H。\n将此牌留在场上；你可以随时使用它。\n研究课题：在阅读带下划线的故事条目之前，你可以改读紧挨在它前面的那一条。例如，若有卡牌或贴纸让你阅读故事 3.2，你可以改读故事 3.1。" },
		uncertain: []
	},
	36: {
		name: null,
		en: { printed: "Place sticker 10F.\nKeep this card in play.\nA TIMELY APPOINTMENT: Check the clock in real life. Read the story above matching the minute hand exactly.\n(For example, if it is 4:00, read 28.2. If it is 4:01, you cannot perform this action.)" },
		zh: { printed: "放置贴纸 10F。\n将此牌留在场上。\n准时赴约：查看现实中的时钟。根据分针准确所指的位置，阅读上方对应的故事。\n（例如，若时间为 4:00，则阅读故事 28.2；若时间为 4:01，则不能执行此行动。）" },
		uncertain: []
	},
	37: {
		name: {
			en: "BIRDWATCHING",
			zh: "观鸟"
		},
		en: { printed: "Place sticker 4Q.\nKeep this card in play.\nBIRDWATCHING: At any time, if you see a bird on the map matching a bird on this card, place a heart sticker on that bird on this card.\nIf all 4 birds on this card have a sticker, discard this and gain card 38." },
		zh: { printed: "放置贴纸 4Q。\n将此牌留在场上。\n观鸟：任何时候，若你在地图上看到与此牌上某只鸟相同的鸟，就在此牌对应的那只鸟上放置 1 枚爱心贴纸。\n若此牌上的 4 只鸟都已放置贴纸，弃掉此牌并获得图鉴牌 38。" },
		uncertain: []
	},
	38: {
		name: {
			en: "BIRDWATCHING 2",
			zh: "观鸟 2"
		},
		en: { printed: "Gain the Birder milestone (bronze).\nKeep this card in play.\nBIRDWATCHING 2: At any time, if you see a bird on the map matching a bird on this card, place a heart sticker on that bird on this card.\nIf all 4 birds on this card have a sticker, discard this and gain card 39." },
		zh: { printed: "获得观鸟者里程碑（铜）。\n将此牌留在场上。\n观鸟 2：任何时候，若你在地图上看到与此牌上某只鸟相同的鸟，就在此牌对应的那只鸟上放置 1 枚爱心贴纸。\n若此牌上的 4 只鸟都已放置贴纸，弃掉此牌并获得图鉴牌 39。" },
		uncertain: []
	},
	39: {
		name: {
			en: "BIRDWATCHING 3",
			zh: "观鸟 3"
		},
		en: { printed: "Cover the Birder milestone with Avian Enthusiast (silver).\nKeep this card in play.\nBIRDWATCHING 3: At any time, if you see a bird on the map matching a bird on this card, place a heart sticker on that bird on this card.\nIf all 4 birds on this card have a sticker, discard this and cover the Avian Enthusiast milestone with Ornithologist (gold)." },
		zh: { printed: "用鸟类爱好者（银）覆盖观鸟者里程碑。\n将此牌留在场上。\n观鸟 3：任何时候，若你在地图上看到与此牌上某只鸟相同的鸟，就在此牌对应的那只鸟上放置 1 枚爱心贴纸。\n若此牌上的 4 只鸟都已放置贴纸，弃掉此牌，并用鸟类学家（金）覆盖鸟类爱好者里程碑。" },
		uncertain: []
	},
	40: {
		name: null,
		en: { printed: "Everywhere you look, you see drab clothes and boring outfits.\nIt's a fashion emergency, code thread!\nPlace sticker 4R.\nKeep this card in play.\nSELL CLOTHING: Gain 1 gold and cover a resident on the map with a matching sticker from 3A. Then, if 2 have been placed, discard this and gain card 49." },
		zh: { printed: "放眼望去，到处都是灰暗的衣服和乏味的装束。\n这是一场时尚紧急事件，代号「线头」！\n放置贴纸 4R。\n将此牌留在场上。\n出售衣物：获得 1 枚金币，并用贴纸 3A 中相匹配的一枚覆盖地图上的一位居民。然后，若已放置 2 枚，弃掉此牌并获得图鉴牌 49。" },
		uncertain: []
	},
	41: {
		name: null,
		en: { printed: "Place sticker 8H.\nKeep this card in play.\nSTARGAZING: Read a story above with no sticker on it. Then, if 4 stickers on this card, discard it." },
		zh: { printed: "放置贴纸 8H。\n将此牌留在场上。\n观星：阅读上方一个没有贴纸的故事。然后，若此牌上已有 4 枚贴纸，弃掉此牌。" },
		uncertain: []
	},
	42: {
		name: null,
		en: { printed: "Keep this card in play.\nLONG-TERM GOALS\n- 21+ Happiness\n- 18+ star icons on milestones\n- 10+ Residents (not upset)\n- 10+ Animal stickers\n- 6+ wood icons\n- 7+ Flower stickers (11A)\n- 18+ Roads (including the bridge)\n- 4+ crown icons on milestones\n- 3+ axe icons" },
		zh: { printed: "将此牌留在场上。\n长期目标\n· 心情达到 21 点或以上\n· 里程碑上的 ★ 图标达到 18 个或以上\n· 居民达到 10 名或以上（不包括处于不满状态的居民）\n· 动物贴纸达到 10 枚或以上\n· 木材图标达到 6 个或以上\n· 花朵贴纸达到 7 枚或以上（11A）\n· 道路达到 18 条或以上（包括桥）\n· 里程碑上的王冠图标达到 4 个或以上\n· 斧头图标达到 3 个或以上" },
		uncertain: []
	},
	43: {
		name: null,
		en: { printed: "“This canvas is not my masterpiece. My masterpiece needs time, like a stone carved by wind over endless eons.”\nKeep this card in play.\nEND OF THE YEAR: Discard this, place sticker 6U, and gain 1 happiness." },
		zh: { printed: "「这幅画不是我的杰作。我的杰作需要时间，就像被风在无尽岁月中雕琢的石头。」\n将此牌留在场上。\n岁末结算：弃掉此牌，放置贴纸 6U，并获得 1 点心情。" },
		uncertain: []
	},
	44: {
		name: null,
		en: { printed: "Keep this card in play.\nRESEARCH LOCAL LEGEND: Read the story based on the number of stickers on this card:\n0: 12.5\n1: 32.8\n2: 30.7\n3: 26.7" },
		zh: { printed: "将此牌留在场上。\n研究本地传说：根据此牌上的贴纸数量阅读故事：\n0 枚：12.5\n1 枚：32.8\n2 枚：30.7\n3 枚：26.7" },
		uncertain: []
	},
	45: {
		name: null,
		en: { printed: "The newspaper clipping lists the names of some family members that went missing.\nKeep this card in play.\nMISSING PEOPLE\nGraham Cobblepot\nBeatrice Cobblepot\nNicolas Trundle\nFredrick Cobblepot III\nFaith Yeats\nFOLLOW THE CLUES: Solve the puzzle and gain the card it points to. If the first word on the card is not \"The,\" you are incorrect. If you need a hint, read 29.9." },
		zh: { printed: "这则剪报列出了几位失踪家族成员的名字。\n将此牌留在场上。\n失踪者\n格雷厄姆·科布尔波特\n比阿特丽斯·科布尔波特\n尼古拉斯·特朗德尔\n弗雷德里克·科布尔波特三世\n费丝·叶茨\n循迹追踪：解开谜题，并获得它指向的卡牌。若该牌的第一个词不是「The」，则答案有误。如果需要提示，阅读故事 29.9。" },
		uncertain: []
	},
	46: {
		name: null,
		en: { printed: "The curiosity shop is filled with strange statues and expensive knickknacks.\nPlace sticker 4P.\nKeep this card in play.\nSELL CURIOS: Gain 3 gold and place 1 curio sticker 12Q. Then, if 2 have been placed, discard this." },
		zh: { printed: "这家古玩店里摆满了古怪的雕像和昂贵的摆设。\n放置贴纸 4P。\n将此牌留在场上。\n出售古玩：获得 3 枚金币并放置 1 枚古玩贴纸 12Q。然后，若已放置 2 枚，弃掉此牌。" },
		uncertain: []
	},
	47: {
		name: null,
		en: { printed: "Place sticker 4W.\nKeep this card in play.\nDELIVER PACKAGE: Choose a resident on the map and a gift sticker (12S). After choosing both, read the resident's story entry above. Then, if 3 stickers on this card, read 24.3." },
		zh: { printed: "放置贴纸 4W。\n将此牌留在场上。\n递送包裹：在地图上选择一位居民和 1 枚礼物贴纸 12S。两者都选定后，阅读上方该居民对应的故事条目。然后，若此牌上已有 3 枚贴纸，阅读故事 24.3。" },
		uncertain: []
	},
	48: {
		name: null,
		en: { printed: "The maze seems simple enough to solve, but you sense that it hides a deeper secret.\nPlace sticker 8D.\nKeep this card in play." },
		zh: { printed: "这座迷宫看上去简单得足以解开，但你感觉它隐藏着更深的秘密。\n放置贴纸 8D。\n将此牌留在场上。" },
		uncertain: []
	},
	49: {
		name: null,
		en: { printed: "Thanks to your efforts, this village is becoming fashionable. With a little more work, it could become glamorous!\nGain the Fashionable milestone (silver).\nKeep this card in play.\nSELL HAT: Gain 2 gold and place a hat sticker 12K. Then, if 3 have been placed (from this and/or other effects), discard this and read 28.9." },
		zh: { printed: "多亏了你的努力，这个村子渐渐变得时尚起来。再多下点功夫，它就能变得魅力四射！\n获得时尚达人里程碑（银）。\n将此牌留在场上。\n出售帽子：获得 2 枚金币并放置 1 枚帽子贴纸 12K。然后，若已放置 3 枚（来自此牌和／或其他效果），弃掉此牌并阅读故事 28.9。" },
		uncertain: []
	},
	50: {
		name: null,
		en: { printed: "The names are a code! It leads you to a P.O. box containing a handwritten letter.\nGain the Treasure Hunter milestone (bronze) and discard cards 44 and 45.\nKeep this card in play.\n“My Dearest Beatrice,\nFrom a distance, the hedge maze blends right into the landscape! Use your sharp eyes to find it.\n—Herbert”\nFIND THE MAZE: Solve the puzzle to read story □.○. If the story does not start with the word \"From,\" you are incorrect. If you need a hint, read 34.7." },
		zh: { printed: "这些名字是一组密码！它把你引向一个邮政信箱，里面有一封手写的信。\n获得寻宝者里程碑（铜），并弃掉图鉴牌 44 与 45。\n将此牌留在场上。\n「我最亲爱的比阿特丽斯：\n从远处看，树篱迷宫与周围的景色融为一体！用你敏锐的目光找到它。\n——赫伯特」\n寻找迷宫：解开谜题以阅读故事 □.○。若该故事不是以「From」一词开头，则答案有误。如果需要提示，阅读故事 34.7。" },
		uncertain: []
	},
	51: {
		name: null,
		en: { printed: "The world needs more kings and queens. Starting with you!\nCover your \"Politics\" milestone with Tyrant (silver).\nGain the Unrest milestone (red) unless you already have it.\nKeep this card in play.\nBECOMING MONARCH: Read the story based on the number of stickers on this card:\n0: 25.3\n1: 25.1\n2: 25.2" },
		zh: { printed: "这个世界需要更多的国王和女王。就从你开始！\n用暴君（银）覆盖你的「政治」里程碑。\n若你还没有动荡里程碑，获得动荡里程碑（红）。\n将此牌留在场上。\n成为君主：根据此牌上的贴纸数量阅读故事：\n0 枚：25.3\n1 枚：25.1\n2 枚：25.2" },
		uncertain: []
	},
	52: {
		name: null,
		en: { printed: "A hidden passage leads to the center of the hedge maze. Inside, you find letters carved into a granite slate, but a vital clue is missing.\nDiscard card 48 and cover 28.6 on the map with sticker 10H.\nKeep this card in play." },
		zh: { printed: "一条隐蔽的通道通向树篱迷宫的中心。你在里面发现一块花岗岩石板，上面刻着字母，但缺失了一条关键线索。\n弃掉图鉴牌 48，并用贴纸 10H 覆盖地图上的 28.6。\n将此牌留在场上。" },
		uncertain: []
	},
	53: {
		name: null,
		en: { printed: "“This village really needs the arts. Concerts, plays, ballet! Help me bring some culture here.”\nPlace sticker 8T.\nKeep this card in play.\nBUILD OUTDOOR STAGE: Discard this and place sticker 8Q." },
		zh: { printed: "「这个村子太需要艺术了。音乐会、戏剧、芭蕾！帮我给这里带来一点文化气息吧。」\n放置贴纸 8T。\n将此牌留在场上。\n建造露天舞台：弃掉此牌并放置贴纸 8Q。" },
		uncertain: []
	},
	54: {
		name: null,
		en: { printed: "Nicholas holds up a wooden doll and pretends that it's talking. “My friends and I really want a new home. Can you help?”\nPlace sticker 8R.\nKeep this card in play.\nBUILD TOY SHOP: Discard this and gain card 25." },
		zh: { printed: "尼古拉斯举起一个木娃娃，装作它在说话。「我和我的朋友们都很想要一个新家。你能帮忙吗？」\n放置贴纸 8R。\n将此牌留在场上。\n建造玩具店：弃掉此牌并获得图鉴牌 25。" },
		uncertain: []
	},
	55: {
		name: {
			en: "CHEF AMBITION",
			zh: "名厨雄心"
		},
		en: { printed: "Cover 15.9 on the map with sticker 9C. Then gain the Famous Chef milestone (silver).\nKeep this card in play.\nMASTERING DESSERT: Discard this and read 25.7.\n*Reduce this cost by 1 food for each cake sticker (12G) on the map." },
		zh: { printed: "用贴纸 9C 覆盖地图上的 15.9。然后获得名厨里程碑（银）。\n将此牌留在场上。\n精通甜点：弃掉此牌并阅读故事 25.7。\n＊地图上每有 1 枚蛋糕贴纸 12G，此花费减少 1 份食物。" },
		uncertain: []
	},
	56: {
		name: null,
		en: { printed: "Five pounds of sugar in a single lollipop? Sign me up!\nPlace sticker 8B.\nKeep this card in play.\nSELL GIANT CANDY: Gain 3 gold and place 1 candy sticker 11H (on the map or on another sticker). Then, if 2 have been placed, discard this and gain 1 happiness." },
		zh: { printed: "一根棒棒糖里就有五磅糖？算我一个！\n放置贴纸 8B。\n将此牌留在场上。\n出售巨型糖果：获得 3 枚金币并放置 1 枚糖果贴纸 11H（放在地图上或另一张贴纸上）。然后，若已放置 2 枚，弃掉此牌并获得 1 点心情。" },
		uncertain: []
	},
	57: {
		name: null,
		en: { printed: "Buying new pets is fun, but there are so many stray animals already in need of a home! You'd love to open your own pet shelter to help them.\nGain the Pet Lover milestone (silver).\nKeep this card in play.\nBUILD PET SHELTER: Discard this and place sticker 4U." },
		zh: { printed: "购买新宠物很有趣，但已经有太多流浪动物需要一个家！你很愿意开办一家自己的宠物收容所来帮助它们。\n获得宠物爱好者里程碑（银）。\n将此牌留在场上。\n建造宠物收容所：弃掉此牌并放置贴纸 4U。" },
		uncertain: []
	},
	"3a": {
		name: null,
		en: { printed: "Cover 3 on the map with sticker 9C.\nKeep this card in play.\nGATHER FALLEN BRANCHES: Gain 1 wood.\nHUNT FOR WOOD (1 food): Roll the die:\n1: Just a few branches. Gain 1 wood.\n2-4: A good-sized log. Gain 2 wood.\n5: You find a fallen tree and cut it up. Gain 3 wood.\n6: Read story 6.2." },
		zh: { printed: "用贴纸 9C 覆盖地图上的 3。\n将此牌留在场上。\n拾取落枝：获得 1 份木材。\n寻找木柴（1 食物）：掷骰。\n1：只有几根树枝。获得 1 份木材。\n2–4：一段大小合适的圆木。获得 2 份木材。\n5：你发现一棵倒下的树，把它砍成木柴。获得 3 份木材。\n6：阅读故事 6.2。" },
		uncertain: []
	},
	"3b": {
		name: null,
		en: { printed: "Cover 3 on the map with sticker 9C.\nKeep this card in play.\nGATHER FALLEN BRANCHES: Gain 1 wood.\nHUNT FOR WOOD (1 food): Roll the die:\n1: Just a few branches. Gain 1 wood.\n2-4: A good-sized log. Gain 2 wood.\n5: You find a fallen tree and cut it up. Gain 3 wood.\n6: Read story 6.2." },
		zh: { printed: "用贴纸 9C 覆盖地图上的 3。\n将此牌留在场上。\n拾取落枝：获得 1 份木材。\n寻找木柴（1 食物）：掷骰。\n1：只有几根树枝。获得 1 份木材。\n2–4：一段大小合适的圆木。获得 2 份木材。\n5：你发现一棵倒下的树，把它砍成木柴。获得 3 份木材。\n6：阅读故事 6.2。" },
		uncertain: []
	},
	"12a": {
		name: null,
		en: { printed: "Keep this card in play.\nGO FISHING: Roll the die:\n1: Gain 1 food and discard all food from this card.\n2-6: Place 1 food on this card from the supply (limit 3). Then choose one:\n- Reel in the fish. Read 36.1.\n- Keep fishing. Roll the die again." },
		zh: { printed: "将此牌留在场上。\n钓鱼：掷骰。\n1：获得 1 份食物，并弃掉此牌上的所有食物。\n2–6：从供应区在此牌上放置 1 份食物（上限 3 份）。然后二选一：\n· 收线。阅读故事 36.1。\n· 继续钓鱼。重新掷骰。" },
		uncertain: []
	},
	"12b": {
		name: null,
		en: { printed: "Keep this card in play.\nGO FISHING: Roll the die:\n1: Gain 1 food and discard all food from this card.\n2-6: Place 1 food on this card from the supply (limit 3). Then choose one:\n- Reel in the fish. Read 35.1.\n- Keep fishing. Roll the die again." },
		zh: { printed: "将此牌留在场上。\n钓鱼：掷骰。\n1：获得 1 份食物，并弃掉此牌上的所有食物。\n2–6：从供应区在此牌上放置 1 份食物（上限 3 份）。然后二选一：\n· 收线。阅读故事 35.1。\n· 继续钓鱼。重新掷骰。" },
		uncertain: []
	},
	"35a": {
		name: null,
		en: { printed: "Place sticker 7F.\nKeep this card in play.\nEXPLORE THE MINE: Choose a space on this card adjacent to a heart. Read the story entry shown in that space." },
		zh: { printed: "放置贴纸 7F。\n将此牌留在场上。\n探索矿井：选择此牌上与爱心相邻的一个格子。阅读该格中所示的故事条目。" },
		uncertain: []
	},
	"35b": {
		name: null,
		en: { printed: "Place sticker 7F.\nKeep this card in play.\nEXPLORE THE MINE: Choose a space on this card adjacent to a heart. Read the story entry shown in that space." },
		zh: { printed: "放置贴纸 7F。\n将此牌留在场上。\n探索矿井：选择此牌上与爱心相邻的一个格子。阅读该格中所示的故事条目。" },
		uncertain: []
	}
}, cr = {
	starting: "games.cozistickerville.phStarting",
	morning: "games.cozistickerville.phMorning",
	choice: "games.cozistickerville.phChoice",
	afternoon: "games.cozistickerville.phAfternoon",
	placing: "games.cozistickerville.phPlacing",
	yearEnd: "games.cozistickerville.phYearEnd",
	done: "games.cozistickerville.phDone"
}, lr = [
	{
		key: "wood",
		label: "games.cozistickerville.wood"
	},
	{
		key: "food",
		label: "games.cozistickerville.food"
	},
	{
		key: "gold",
		label: "games.cozistickerville.gold"
	},
	{
		key: "ore",
		label: "games.cozistickerville.ore"
	}
], ur = {
	wood: {
		background: "#eaa153",
		mark: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#7d4c28",
				d: "M5 16 8 12l1-5 2-1 1 4 3-5 4 1 2 4-9 10-4-1Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#eeb67a",
				d: "m15 5 4 1 2 4-3 2-4-3Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#5c3925",
				d: "m8 16 6-6m-3 8 5-6m1-5 2 2"
			})
		] })
	},
	food: {
		background: "#6d8a55",
		mark: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#ae392c",
				d: "M12 9c-3-3-8-1-8 4 0 4 3 8 6 7l2-1 2 1c3 1 6-3 6-7 0-5-5-7-8-4Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#77a449",
				d: "M12 8c0-3 3-5 6-4-1 3-3 4-6 4Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				d: "m12 9-2-5"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#ffd68a",
				strokeWidth: "2",
				d: "m7.5 12-.5 2"
			})
		] })
	},
	gold: {
		background: "#f6c761",
		mark: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("circle", {
			cx: "12",
			cy: "12",
			r: "8",
			fill: "#f8d77e",
			stroke: "#835522"
		}), /* @__PURE__ */ h("path", {
			fill: "#e4a543",
			stroke: "#835522",
			d: "m6 10 3 2 3-4 3 4 3-2-2 6H8Z"
		})] })
	},
	ore: {
		background: "#85adbf",
		mark: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#56595b",
				d: "m6 12 1-4 4-3 3 2 3-1 2 3 1 3Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#a6754d",
				d: "M4 12h16l-2 6H6Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#503c2e",
				d: "M8 15h8"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "8",
				cy: "19",
				r: "1.3",
				fill: "#292824"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "19",
				r: "1.3",
				fill: "#292824"
			})
		] })
	}
};
function dr({ kind: e }) {
	let { background: t, mark: n } = ur[e];
	return /* @__PURE__ */ g("svg", {
		width: "18",
		height: "18",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h("circle", {
			cx: "12",
			cy: "12",
			r: "10.8",
			fill: t,
			stroke: "#5e4533",
			strokeWidth: "1.1"
		}), /* @__PURE__ */ h("g", {
			stroke: "#352b22",
			strokeWidth: "1.15",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: n
		})]
	});
}
var fr = Pt.flatMap((e) => {
	let t = Ft(e.id);
	return t?.[0] === e.id ? [t.map((e) => x[e])] : [];
});
function pr({ open: e, title: t, onClose: n, children: r }) {
	let i = d();
	return /* @__PURE__ */ h(tr, {
		open: e,
		title: t,
		closeLabel: i("games.cozistickerville.close"),
		onClose: n,
		children: /* @__PURE__ */ h("div", {
			className: "cz-dialog-scroll",
			children: r
		})
	});
}
function mr(e) {
	return R.find((t) => t.page === Math.floor(Number(e)))?.file;
}
function hr({ checkpoint: e }) {
	let t = d(), [n, r] = l(null), [i, a] = l(!1);
	async function o() {
		if (e && !i) {
			a(!0), r("games.cozistickerville.saving");
			try {
				let t = await Pn(e);
				r(t === "saved" ? "games.cozistickerville.saved" : "games.cozistickerville.saveNewer");
			} catch {
				r("games.cozistickerville.saveError");
			} finally {
				a(!1);
			}
		}
	}
	return /* @__PURE__ */ g("div", {
		className: "cz-save",
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "cz-btn cz-save-btn",
			disabled: !e || i,
			onClick: () => void o(),
			children: t(n === "games.cozistickerville.saving" ? "games.cozistickerville.saving" : "games.cozistickerville.save")
		}), n && n !== "games.cozistickerville.saving" && n !== "games.cozistickerville.save" && /* @__PURE__ */ h("span", {
			role: "status",
			className: "cz-save-status",
			children: t(n)
		})]
	});
}
function gr(e) {
	let t = e.public, n = e.private?.checkpoint ?? null, r = d(), i = u((e) => e.locale) === "zh" ? 0 : 1, a = (e) => i === 0 ? e.zh : e.en, o = e.send, [c, te] = l(null), [ne, f] = l(null), [p, re] = l(null), [ie, ae] = l(null), [v, y] = l(!1), [b, oe] = l(null), [se, ce] = l(null), [S, le] = l(null), [ue, de] = l(""), [C, w] = l(""), [fe, T] = l(""), E = t.prompt, pe = typeof E?.must?.number == "string" ? E.must.number : "", D = `${t.campaignId}:${t.side}`, O = t.currentEvent ? _[t.currentEvent] : void 0, k = O ? `${D}:${O.id}` : null, [A, j] = l({
		key: k,
		open: !!k && t.phase === "choice",
		read: t.phase !== "choice",
		large: !1
	});
	A.key !== k && j({
		key: k,
		open: !!k && (t.phase === "choice" || t.phase === "afternoon"),
		read: !1,
		large: !1
	});
	let me = A.key === k, he = !!O && me && A.open, M = !!O && me && !A.read && (t.phase === "choice" || t.phase === "afternoon"), ge = M && t.phase === "afternoon" ? "morning" : t.phase, P = E && E.kind !== "place" ? E : null, _e = P && `${D}:${t.year}:${t.currentEvent}:${P.kind}:${P.code ?? ""}`, [ve, I] = l(null), ye = !!_e && ve !== _e && !he && !M && !p, be = new Set(t.startingPairs), L = (e) => !be.has(e) && !Ft(e)?.some((e) => be.has(e)), R = t.phase === "starting" && c?.campaign === D && L(c.id) ? c.id : null, z = !R && E?.kind === "place" ? E : void 0, B = R ? x[R] : Ve(z?.code ?? ""), xe = B && nt(t, B, pe), V = `${D}:${t.phase}:${t.year}:${B?.id ?? ""}:${t.placed.length}:${JSON.stringify(z)}`, H = s(() => {
		let e = /* @__PURE__ */ new Map();
		if (!B) return e;
		let n = {
			side: t.side,
			placed: t.placed,
			bridge: t.bridge
		};
		for (let t = 0; t < F.rows; t++) for (let r = 0; r < F.cols; r++) e.set(Un({
			col: r,
			row: t
		}), ot(n, B, r, t, z));
		return e;
	}, [
		t.side,
		t.placed,
		t.bridge,
		B,
		z
	]), Se = ne?.scope === V && H.get(Un(ne.cell))?.ok ? ne.cell : null, Ce = t.phase === "afternoon" && !M && t.action > 0;
	function we(e) {
		f(e ? {
			scope: V,
			cell: e
		} : null);
	}
	function Te() {
		Se && B && (we(null), R ? (te(null), o({
			type: "placeStarting",
			id: R,
			...Se
		})) : E?.kind === "place" && o({
			type: "placePending",
			...Se
		}));
	}
	let Ee = /* @__PURE__ */ g("div", {
		className: "cz-banner",
		children: [/* @__PURE__ */ g("div", {
			className: "cz-banner-row",
			children: [
				/* @__PURE__ */ h("div", {
					className: "cz-title",
					children: /* @__PURE__ */ h("h1", { children: r("games.cozistickerville.name") })
				}),
				/* @__PURE__ */ g("div", {
					className: "cz-banner-meta",
					children: [
						/* @__PURE__ */ h("span", { children: r("games.cozistickerville.year", { n: t.year }) }),
						/* @__PURE__ */ h("span", {
							className: "cz-phase",
							children: r(cr[ge] ?? "games.cozistickerville.phMorning")
						}),
						t.phase !== "starting" && /* @__PURE__ */ h("span", { children: r("games.cozistickerville.deckCount", { n: t.deckCount }) }),
						ge === "afternoon" && /* @__PURE__ */ h("span", { children: r("games.cozistickerville.actionLeft", { n: t.action }) })
					]
				}),
				/* @__PURE__ */ h(hr, { checkpoint: n })
			]
		}), /* @__PURE__ */ g("div", {
			className: "cz-stats",
			children: [
				/* @__PURE__ */ g("div", {
					className: "cz-hearts",
					title: r("games.cozistickerville.hearts"),
					children: [/* @__PURE__ */ h(Dn, {
						size: 18,
						fill: "currentColor",
						"aria-hidden": "true"
					}), /* @__PURE__ */ h("b", { children: t.happiness })]
				}),
				lr.map(({ key: e, label: n }) => /* @__PURE__ */ g("div", {
					className: `cz-res is-${e}`,
					title: r(n),
					"aria-label": `${r(n)} ${t.resources[e]}`,
					children: [/* @__PURE__ */ h(dr, { kind: e }), /* @__PURE__ */ h("b", { children: t.resources[e] })]
				}, e)),
				t.upset > 0 && /* @__PURE__ */ g("div", {
					className: "cz-res is-upset",
					title: r("games.cozistickerville.upset"),
					children: [/* @__PURE__ */ h(Tn, {
						size: 18,
						"aria-hidden": "true"
					}), /* @__PURE__ */ h("b", { children: t.upset })]
				})
			]
		})]
	}), De = /* @__PURE__ */ h(er, {
		side: t.side,
		placed: t.placed,
		happiness: t.happiness,
		milestones: t.milestones,
		coveredMilestoneIcons: t.coveredMilestoneIcons,
		lang: i === 0 ? "zh" : "en",
		draft: B ? {
			scope: V,
			sticker: B,
			pending: Se,
			hits: H,
			choose: we,
			confirm: Te
		} : void 0,
		stories: Ce ? t.stickerActions.filter((e) => e.enabled).map((e) => ({
			code: e.code,
			label: e.label[i],
			read: () => o({
				type: "useSticker",
				code: e.code
			})
		})) : void 0
	}, D), U = t.phase === "morning" || t.phase === "choice" || t.phase === "afternoon", Oe = () => j((e) => ({
		...e,
		open: !0,
		large: !1
	})), ke = () => j((e) => ({
		...e,
		open: !1,
		large: !1
	})), Ae = () => j((e) => ({
		...e,
		read: !0,
		open: !1,
		large: !1
	})), je = O && /* @__PURE__ */ h("button", {
		type: "button",
		className: "cz-event",
		onClick: Oe,
		"aria-label": r("games.cozistickerville.reviewEvent"),
		children: /* @__PURE__ */ h("img", {
			src: Q(O.file),
			alt: "",
			draggable: !1
		})
	}), Me = t.phase === "starting" && /* @__PURE__ */ h("div", {
		className: "cz-start-strip",
		children: /* @__PURE__ */ h("div", {
			className: "cz-start-cards",
			children: fr.map((e) => /* @__PURE__ */ h("div", {
				className: "cz-start-pair",
				children: e.map((e, t) => /* @__PURE__ */ g("div", {
					className: "cz-pair-item",
					children: [t > 0 && /* @__PURE__ */ h("span", {
						className: "cz-pair-or",
						children: r("games.cozistickerville.pairOr")
					}), /* @__PURE__ */ g("button", {
						type: "button",
						className: `cz-start-card${R === e.id ? " is-selected" : ""}`,
						disabled: !L(e.id),
						"aria-pressed": R === e.id,
						onClick: () => {
							we(null), te(R === e.id ? null : {
								campaign: D,
								id: e.id
							});
						},
						children: [/* @__PURE__ */ h("img", {
							src: Q(e.file),
							alt: "",
							draggable: !1
						}), /* @__PURE__ */ h("span", { children: e.code })]
					})]
				}, e.id))
			}, e[0]?.id))
		})
	}), Ne;
	Ne = t.phase === "starting" ? /* @__PURE__ */ g("div", {
		className: "cz-work-content",
		children: [
			/* @__PURE__ */ h("h2", { children: r("games.cozistickerville.phStarting") }),
			/* @__PURE__ */ h("p", { children: r("games.cozistickerville.setupCount", {
				done: t.startingPairs.length,
				total: 8
			}) }),
			B && /* @__PURE__ */ g("figure", {
				className: "cz-current-sticker",
				children: [/* @__PURE__ */ h("img", {
					src: Q(B.file),
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ h("figcaption", { children: B.code })]
			}),
			/* @__PURE__ */ h("p", { children: r(Se ? "games.cozistickerville.adjustSticker" : B ? "games.cozistickerville.pickPosition" : "games.cozistickerville.pairHint") })
		]
	}) : U ? /* @__PURE__ */ g("div", {
		className: `cz-day cz-day--${ge}`,
		children: [M ? /* @__PURE__ */ g("div", {
			className: "cz-event-resume",
			children: [je, /* @__PURE__ */ h("button", {
				type: "button",
				className: "cz-btn cz-primary",
				onClick: Oe,
				children: r("games.cozistickerville.continueEvent")
			})]
		}) : t.phase === "morning" ? /* @__PURE__ */ g("button", {
			type: "button",
			className: "cz-deck",
			onClick: () => o({ type: "draw" }),
			children: [/* @__PURE__ */ h("span", {
				className: "cz-deck-back",
				"aria-hidden": "true",
				children: /* @__PURE__ */ h(An, { size: 26 })
			}), /* @__PURE__ */ h("span", { children: r("games.cozistickerville.draw") })]
		}) : je, t.phase === "afternoon" && !M && /* @__PURE__ */ g("div", {
			className: "cz-day-actions",
			children: [t.inPlay.length > 0 && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cz-btn",
				onClick: () => re("buildings"),
				children: r("games.cozistickerville.inPlayTitle")
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "cz-btn cz-primary",
				onClick: () => o({ type: "endTurn" }),
				children: r("games.cozistickerville.endTurn")
			})]
		})]
	}) : t.phase === "placing" || t.phase === "yearEnd" ? P ? /* @__PURE__ */ h("div", {
		className: "cz-actions",
		children: /* @__PURE__ */ h("button", {
			type: "button",
			className: "cz-btn cz-primary",
			onClick: () => I(null),
			children: r("games.cozistickerville.continueDecision")
		})
	}) : E?.kind === "place" ? /* @__PURE__ */ g("div", {
		className: "cz-actions cz-placement",
		children: [B && /* @__PURE__ */ g("button", {
			type: "button",
			className: "cz-sticker-preview",
			"aria-haspopup": "dialog",
			"aria-label": r("games.cozistickerville.enlargeSticker", { code: B.code }),
			onClick: () => le(V),
			children: [/* @__PURE__ */ h("img", {
				src: Q(B.file),
				alt: "",
				draggable: !1
			}), /* @__PURE__ */ h(jn, {
				className: "cz-sticker-preview-icon",
				size: 17,
				"aria-hidden": "true"
			})]
		}), /* @__PURE__ */ g("div", {
			className: "cz-placement-controls",
			children: [/* @__PURE__ */ h("p", {
				className: "cz-hint",
				children: pe ? r(xe === "whole" ? "games.cozistickerville.pendingCoverWholeHint" : xe === "label" ? E.cover ? "games.cozistickerville.pendingCoverNumberHint" : "games.cozistickerville.pendingOnNumberHint" : "games.cozistickerville.pendingCoverHint", {
					code: E.code ?? "",
					num: pe,
					n: E.n ?? 0
				}) : r("games.cozistickerville.pendingHint", {
					code: E.code ?? "",
					n: E.n ?? 0
				})
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "cz-btn",
				onClick: () => {
					we(null), o({ type: "skipPlace" });
				},
				children: r("games.cozistickerville.skipPlace")
			})]
		})]
	}) : /* @__PURE__ */ g("div", {
		className: "cz-actions",
		children: [/* @__PURE__ */ h("div", {
			className: "cz-hint",
			children: r("games.cozistickerville.yearEndHint")
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "cz-btn cz-primary",
			onClick: () => o({ type: "endYear" }),
			children: r("games.cozistickerville.endYear")
		})]
	}) : /* @__PURE__ */ h("div", {
		className: "cz-actions cz-finale",
		children: /* @__PURE__ */ h("div", {
			className: "cz-hint",
			children: r("games.cozistickerville.score", { n: t.happiness + t.milestones.length + t.catalog.length })
		})
	});
	let Pe = M && t.phase === "choice", Fe = M && t.phase !== "choice" && !!O?.opts, Ie = O ? rr(O.id) : void 0, Le = O ? ar[O.id] : void 0, Re = Pe ? t.choices : Fe && O ? ir(O.id) : [], ze = Le ? Le[i === 0 ? "zh" : "en"] : null, Be = ze?.flavor ?? (Pe && !Le && Ie ? Ie.story[i] : null), He = (ze?.panel ?? "").split(/\n{2,}/).map((e) => e.trim()).filter(Boolean), W = He.filter((e) => !e.includes("\n")), Ue = He.filter((e) => e.includes("\n")), G = ie && t.story.includes(ie) ? ie : t.story[0], We = G ? G.split(".")[0] : void 0, Ge = We && Ye(t, We), Ke = We === "8" || We === "33", qe = (e) => {
		let n = sr[e]?.[i === 0 ? "zh" : "en"].printed;
		return e !== "3a" && e !== "3b" || !t.cardAttachments[e] ? n : n?.replace(/^1[:：][^\n]*\n2[–-]4[:：][^\n]*/mu, r("games.cozistickerville.hatchetRoll"));
	}, Je = mr(G), Xe = P?.code?.startsWith("st:") ? P.code.slice(3) : void 0, Ze = mr(Xe), Qe = (Xe ? or[Xe.split(".")[0]]?.blocks.find((e) => e.id === Xe) : void 0)?.[i === 0 ? "zh" : "en"].text, $e = r(P?.code?.endsWith(":card") ? "games.cozistickerville.cardNumber" : "games.cozistickerville.storyNumber"), et = Xe ? r("games.cozistickerville.storyEntry", { entry: Xe }) : P?.kind === "exchange" ? r("games.cozistickerville.exchangeTitle") : P?.kind === "pickRes" ? r("games.cozistickerville.pickResHint") : P?.kind === "pickCard" ? r("games.cozistickerville.pickCardHint") : P?.kind === "pickPlace" ? r("games.cozistickerville.pickPlaceHint") : P?.kind === "pickOpt" && P.code === "ms:red" ? r("games.cozistickerville.removeRedMilestone") : r("games.cozistickerville.continueDecision"), tt = (e) => o({
		type: "resolvePrompt",
		key: e
	}), rt = (e) => {
		oe(null), y(!1), re(e);
	}, it = () => re(null), at = (e) => {
		let t = _[e], n = ar[e]?.title;
		return n ? a(n) : r("games.cozistickerville.eventCardName", {
			year: t?.year,
			card: t?.num
		});
	}, st = !he && p === "buildings", ct = se && t.inPlay.includes(se) ? _[se] : void 0;
	return /* @__PURE__ */ g("div", {
		className: "cz-root",
		children: [
			/* @__PURE__ */ h(ee, {
				adaptive: !0,
				scroll: !1,
				className: "cz-screen",
				banner: Ee,
				children: /* @__PURE__ */ g("div", {
					className: "cz-table",
					children: [
						De,
						/* @__PURE__ */ h("aside", {
							className: U ? "cz-work cz-work--day" : "cz-work",
							children: Ne
						}),
						/* @__PURE__ */ g("div", {
							className: "cz-dock",
							children: [Me, /* @__PURE__ */ g("nav", {
								className: "cz-tray",
								"aria-label": r("games.cozistickerville.townTabs"),
								children: [
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => rt("log"),
										children: [/* @__PURE__ */ h(On, { "aria-hidden": "true" }), r("games.cozistickerville.openLog")]
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => rt("mile"),
										children: [/* @__PURE__ */ h(Cn, { "aria-hidden": "true" }), r("games.cozistickerville.openMile")]
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => rt("story"),
										children: [/* @__PURE__ */ h(wn, { "aria-hidden": "true" }), r("games.cozistickerville.openStory")]
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-tab",
										onClick: () => rt("catalog"),
										children: [/* @__PURE__ */ h(kn, { "aria-hidden": "true" }), r("games.cozistickerville.openCatalog")]
									})
								]
							})]
						})
					]
				})
			}),
			B && z && /* @__PURE__ */ h(tr, {
				open: S === V,
				kind: "sticker",
				title: r("games.cozistickerville.stickerTitle", { code: B.code }),
				closeLabel: r("games.cozistickerville.close"),
				onClose: () => le(null),
				children: /* @__PURE__ */ h("div", {
					className: "cz-sticker-detail",
					children: /* @__PURE__ */ h("img", {
						src: Q(B.file),
						alt: "",
						draggable: !1
					})
				})
			}),
			/* @__PURE__ */ g(tr, {
				open: he,
				kind: "event",
				title: r(M ? "games.cozistickerville.todayEvent" : "games.cozistickerville.reviewEvent"),
				closeLabel: r("games.cozistickerville.returnMap"),
				onClose: ke,
				children: [O && /* @__PURE__ */ g("div", {
					className: "cz-event-dialog",
					children: [
						/* @__PURE__ */ g("div", {
							className: "cz-event-head",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-event-thumb",
								onClick: () => j((e) => ({
									...e,
									large: !0
								})),
								"aria-label": r("games.cozistickerville.viewOriginalCard"),
								children: /* @__PURE__ */ h("img", {
									src: Q(O.file),
									alt: r("games.cozistickerville.eventCardName", {
										year: O.year,
										card: O.num
									}),
									draggable: !1
								})
							}), /* @__PURE__ */ g("div", {
								className: "cz-event-headbody",
								children: [Be ? /* @__PURE__ */ g("div", {
									className: "cz-event-flavor",
									children: [/* @__PURE__ */ h("span", {
										className: "cz-event-flavor-label",
										children: r("games.cozistickerville.eventFlavorLabel")
									}), /* @__PURE__ */ h("p", { children: Be })]
								}) : W[0] ? /* @__PURE__ */ h("p", {
									className: "cz-event-lead",
									children: W[0]
								}) : null, M && !Pe && !Fe && !W[0] && /* @__PURE__ */ h("p", {
									className: "cz-event-note",
									children: r("games.cozistickerville.eventKept")
								})]
							})]
						}),
						ze && (O.kind === "keep" && Ue.length > 0 ? /* @__PURE__ */ g("div", {
							className: "cz-event-options",
							children: [W.slice(+!Be).map((e, t) => /* @__PURE__ */ h("p", {
								className: "cz-event-lead",
								children: e
							}, `hint-${t}`)), Ue.map((e, t) => {
								let [n, ...i] = e.split("\n");
								return /* @__PURE__ */ g("div", {
									className: "cz-event-option",
									children: [/* @__PURE__ */ g("div", {
										className: "cz-event-option-head",
										children: [/* @__PURE__ */ h("strong", { children: n }), /* @__PURE__ */ h("span", {
											className: "cz-event-option-badge",
											children: r("games.cozistickerville.eventKeepOption")
										})]
									}), i.length > 0 && /* @__PURE__ */ h("p", { children: i.join("\n") })]
								}, `opt-${t}`);
							})]
						}) : /* @__PURE__ */ h("p", {
							className: "cz-event-rules",
							children: ze.panel
						})),
						Fe && /* @__PURE__ */ h("p", {
							className: "cz-event-note",
							children: r(O.id === "y5-04" ? "games.cozistickerville.eventFoodShort" : "games.cozistickerville.eventNoOptions")
						}),
						M && !Pe && !Fe && !ze && O.keepText && /* @__PURE__ */ h("p", {
							className: "cz-event-extra",
							children: a(O.keepText)
						}),
						!M && A.picked && /* @__PURE__ */ g("p", {
							className: "cz-event-note",
							children: [r("games.cozistickerville.eventPicked", {
								key: A.picked.key,
								choice: A.picked.label
							}), A.picked.effect !== A.picked.label && /* @__PURE__ */ h("small", { children: A.picked.effect })]
						}),
						!!Re.length && /* @__PURE__ */ h("div", {
							className: "cz-dialog-choices",
							children: Re.map((e) => {
								let t = ze?.options[e.key] ?? Ie?.options[e.key]?.[i] ?? e.label[i];
								return /* @__PURE__ */ g("button", {
									type: "button",
									className: "cz-btn cz-choice",
									disabled: !e.enabled,
									onClick: () => {
										j((n) => ({
											...n,
											read: !0,
											open: !1,
											large: !1,
											picked: {
												key: e.key.toUpperCase(),
												label: t,
												effect: e.label[i]
											}
										})), o({
											type: "choice",
											opt: e.key
										});
									},
									children: [/* @__PURE__ */ h("span", {
										className: "cz-choice-key",
										children: e.key.toUpperCase()
									}), /* @__PURE__ */ h("span", {
										className: "cz-choice-label",
										children: Fe && O.id === "y5-04" ? r("games.cozistickerville.eventBreakfastOption") : t
									})]
								}, e.key);
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "cz-event-foot",
							children: [M && !Pe && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-primary cz-event-done",
								onClick: Ae,
								children: r("games.cozistickerville.enterAfternoon")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-event-viewsrc",
								onClick: () => j((e) => ({
									...e,
									large: !0
								})),
								children: r("games.cozistickerville.viewOriginalCard")
							})]
						})
					]
				}), O && A.large && /* @__PURE__ */ g("div", {
					className: "cz-event-zoom",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": r("games.cozistickerville.eventCardName", {
						year: O.year,
						card: O.num
					}),
					onClick: () => j((e) => ({
						...e,
						large: !1
					})),
					children: [/* @__PURE__ */ h("img", {
						src: Q(O.file),
						alt: "",
						draggable: !1
					}), /* @__PURE__ */ h("button", {
						type: "button",
						className: "cz-btn cz-event-zoom-close",
						onClick: () => j((e) => ({
							...e,
							large: !1
						})),
						children: r("games.cozistickerville.close")
					})]
				})]
			}),
			/* @__PURE__ */ h(tr, {
				open: ye,
				kind: "decision",
				title: et,
				closeLabel: r("games.cozistickerville.returnMap"),
				onClose: () => I(_e),
				children: P && /* @__PURE__ */ g("div", {
					className: `cz-decision-body cz-decision--${P.kind}`,
					children: [Qe ? /* @__PURE__ */ g("div", {
						className: "cz-decision-story",
						children: [/* @__PURE__ */ h("article", {
							className: "cz-story-text",
							children: Qe.split("\n").filter(Boolean).map((e, t) => /* @__PURE__ */ h("p", { children: e }, t))
						}), Ze && /* @__PURE__ */ g("details", {
							className: "cz-decision-story-source",
							children: [/* @__PURE__ */ h("summary", {
								className: "cz-btn cz-reading-zoom",
								children: r("games.cozistickerville.viewStoryPage")
							}), /* @__PURE__ */ h("img", {
								src: Q(Ze),
								alt: et,
								loading: "lazy",
								draggable: !1
							})]
						})]
					}, Xe) : Ze && /* @__PURE__ */ h("div", {
						className: "cz-decision-art",
						children: /* @__PURE__ */ h("img", {
							src: Q(Ze),
							alt: et
						})
					}), /* @__PURE__ */ g("div", {
						className: "cz-decision-options",
						children: [
							P.kind === "exchange" && /* @__PURE__ */ h("p", { children: r("games.cozistickerville.exchangeHint", { n: P.n ?? 0 }) }),
							P.kind === "puzzle" ? /* @__PURE__ */ g("div", {
								className: "cz-inline-input",
								children: [/* @__PURE__ */ h("input", {
									value: fe,
									maxLength: 12,
									onChange: (e) => T(e.target.value),
									"aria-label": $e,
									placeholder: $e
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "cz-btn cz-primary",
									disabled: !fe.trim(),
									onClick: () => tt(fe.trim()),
									children: r("games.cozistickerville.confirm")
								})]
							}) : P.kind === "name" ? /* @__PURE__ */ g("div", {
								className: "cz-inline-input",
								children: [/* @__PURE__ */ h("input", {
									value: ue,
									maxLength: 40,
									onChange: (e) => de(e.target.value),
									"aria-label": r("games.cozistickerville.villageName")
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "cz-btn cz-primary",
									disabled: !ue.trim(),
									onClick: () => tt(ue.trim()),
									children: r("games.cozistickerville.confirm")
								})]
							}) : P.kind === "clock" ? /* @__PURE__ */ g("div", {
								className: "cz-inline-input",
								children: [/* @__PURE__ */ h("input", {
									type: "time",
									value: C,
									onChange: (e) => w(e.target.value),
									"aria-label": r("games.cozistickerville.clock")
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "cz-btn cz-primary",
									disabled: !C,
									onClick: () => tt(C),
									children: r("games.cozistickerville.confirm")
								})]
							}) : P.kind === "pickOpt" || P.kind === "exchange" ? /* @__PURE__ */ h("div", {
								className: "cz-dialog-choices",
								children: t.promptOptions.filter((e) => P.kind !== "exchange" || e.key !== "done").map((e) => /* @__PURE__ */ h("button", {
									type: "button",
									className: "cz-btn cz-choice",
									disabled: !e.enabled,
									onClick: () => tt(e.key),
									children: /* @__PURE__ */ h("span", {
										className: "cz-choice-label",
										children: e.label[i]
									})
								}, e.key))
							}) : /* @__PURE__ */ h("div", {
								className: "cz-decision-objects",
								children: (P.pick ?? []).map((e) => {
									let t = P.kind === "pickPlace" ? Ve(e) : void 0, n = P.kind === "pickCard" ? N[e] : void 0, i = P.kind === "pickRes" ? lr.find((t) => t.key === e) : void 0, a = t?.file ?? n?.file;
									return /* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-btn",
										onClick: () => tt(e),
										children: [
											a && /* @__PURE__ */ h("img", {
												src: Q(a),
												alt: "",
												draggable: !1
											}),
											i && /* @__PURE__ */ h(dr, { kind: i.key }),
											t?.code ?? (i ? r(i.label) : e)
										]
									}, e);
								})
							}),
							P.kind === "exchange" && t.promptOptions.some((e) => e.key === "done") && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-primary cz-event-done",
								onClick: () => tt("done"),
								children: r("games.cozistickerville.finishExchange")
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ h(pr, {
				open: st,
				title: r("games.cozistickerville.inPlayTitle"),
				onClose: () => {
					ce(null), it();
				},
				children: /* @__PURE__ */ h("ul", {
					className: "cz-building-list",
					children: t.inPlay.map((e) => {
						let n = _[e];
						if (!n) return null;
						let s = at(e), c = (ar[e]?.[i === 0 ? "zh" : "en"].panel ?? (n.keepText && a(n.keepText)))?.replace(/^(?:将此牌留在场上。|Keep this card in play\.)\s*/u, ""), l = t.keepActions.filter((t) => t.id === e);
						return /* @__PURE__ */ g("li", {
							className: "cz-building",
							children: [/* @__PURE__ */ g("button", {
								className: "cz-building-thumb",
								type: "button",
								"aria-haspopup": "dialog",
								"aria-label": `${r("games.cozistickerville.enlargeCard")} · ${s}`,
								onClick: () => ce(e),
								children: [/* @__PURE__ */ h("img", {
									src: Q(n.file),
									alt: "",
									loading: "lazy",
									draggable: !1
								}), /* @__PURE__ */ h(jn, {
									size: 16,
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ g("div", {
								className: "cz-building-body",
								children: [
									/* @__PURE__ */ h("h3", { children: s }),
									c && /* @__PURE__ */ h("div", {
										className: "cz-building-effects",
										children: c.split(/\n{2,}/).map((e, t) => /* @__PURE__ */ h("p", { children: e }, t))
									}),
									l.length > 0 && /* @__PURE__ */ h("div", {
										className: "cz-building-actions",
										children: l.map((t) => /* @__PURE__ */ h("button", {
											type: "button",
											className: "cz-btn cz-card-action",
											disabled: !Ce || !t.enabled,
											onClick: () => {
												ce(null), it(), o({
													type: "useKeep",
													id: e,
													key: t.key
												});
											},
											children: t.label[i]
										}, t.key))
									})
								]
							})]
						}, e);
					})
				})
			}),
			st && ct && /* @__PURE__ */ h(tr, {
				open: !0,
				title: at(ct.id),
				closeLabel: r("games.cozistickerville.close"),
				onClose: () => ce(null),
				children: /* @__PURE__ */ h("div", {
					className: "cz-building-art",
					children: /* @__PURE__ */ h("img", {
						src: Q(ct.file),
						alt: at(ct.id),
						draggable: !1
					})
				})
			}),
			/* @__PURE__ */ h(pr, {
				open: !he && p === "log",
				title: r("games.cozistickerville.logTitle"),
				onClose: it,
				children: t.log.length === 0 ? /* @__PURE__ */ h("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyLog")
				}) : /* @__PURE__ */ h("ul", {
					className: "cz-log",
					children: t.log.slice().reverse().map((e, t) => /* @__PURE__ */ h("li", { children: e[i] }, t))
				})
			}),
			/* @__PURE__ */ h(pr, {
				open: !he && p === "catalog",
				title: r("games.cozistickerville.catalogTitle"),
				onClose: it,
				children: t.catalog.length === 0 ? /* @__PURE__ */ h("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyCatalog")
				}) : /* @__PURE__ */ h("div", {
					className: "cz-catalog-grid",
					children: t.catalog.map((e) => /* @__PURE__ */ g("article", {
						className: `cz-catalog-card${b === e ? " is-enlarged" : ""}`,
						children: [
							N[e] && /* @__PURE__ */ h("button", {
								className: "cz-card-image",
								type: "button",
								"aria-label": r("games.cozistickerville.enlargeCard"),
								"aria-pressed": b === e,
								onClick: () => oe(b === e ? null : e),
								children: /* @__PURE__ */ h("img", {
									src: Q(N[e].file),
									alt: e,
									draggable: !1
								})
							}),
							/* @__PURE__ */ h("span", {
								className: "cz-card-id",
								children: r("games.cozistickerville.catalogEntry", { entry: e })
							}),
							sr[e]?.name && /* @__PURE__ */ h("strong", {
								className: "cz-card-name",
								children: sr[e].name[i === 0 ? "zh" : "en"]
							}),
							(e === "3a" || e === "3b") && t.cardAttachments[e] && /* @__PURE__ */ h("p", {
								className: "cz-card-id",
								children: r("games.cozistickerville.hatchetAttached")
							}),
							sr[e] && /* @__PURE__ */ h("p", {
								className: "cz-card-text",
								children: qe(e)
							}),
							/* @__PURE__ */ g("div", {
								className: "cz-card-counters",
								children: [
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-btn cz-counter",
										onClick: () => o({
											type: "cardSticker",
											label: e,
											kind: "heart"
										}),
										children: ["♥ ", t.cardStickers[e]?.heart ?? 0]
									}),
									/* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-btn cz-counter",
										onClick: () => o({
											type: "cardSticker",
											label: e,
											kind: "progress"
										}),
										children: ["● ", t.cardStickers[e]?.progress ?? 0]
									}),
									t.cardFood[e] != null && /* @__PURE__ */ g("span", {
										className: "cz-card-food",
										children: ["食物 ", t.cardFood[e]]
									}),
									[
										"37",
										"38",
										"39"
									].includes(e) && /* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-btn cz-counter",
										onClick: () => o({
											type: "birdWatch",
											label: e
										}),
										children: [
											"观鸟 ",
											t.cardStickers[e]?.heart ?? 0,
											"/4"
										]
									})
								]
							}),
							Ce ? t.catalogActions.filter((t) => t.id === e).map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-card-action",
								disabled: !e.enabled,
								onClick: () => {
									re(null), o({
										type: "useCard",
										key: e.key
									});
								},
								children: e.label[i]
							}, e.key)) : N[e] && (N[e].actions ?? (N[e].action ? [N[e].action] : [])).map((e, t) => /* @__PURE__ */ h("p", {
								className: "cz-card-text",
								children: a(e.label)
							}, t))
						]
					}, e))
				})
			}),
			/* @__PURE__ */ h(pr, {
				open: !he && p === "story",
				title: r("games.cozistickerville.storyTitle"),
				onClose: it,
				children: t.story.length === 0 ? /* @__PURE__ */ h("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyStory")
				}) : /* @__PURE__ */ g("div", {
					className: "cz-story-reader",
					children: [
						/* @__PURE__ */ g("div", {
							className: "cz-story-toolbar",
							children: [/* @__PURE__ */ h("div", {
								className: "cz-story-tabs",
								children: t.story.map((e) => {
									let n = t.storyEntryStickers[e];
									return /* @__PURE__ */ g("button", {
										type: "button",
										className: `cz-btn${G === e ? " cz-primary" : ""}`,
										"aria-label": n ? `${e} · ${r(n === "heart" ? "games.cozistickerville.storyHeartMark" : "games.cozistickerville.storyProgressMark")}` : void 0,
										"aria-pressed": G === e,
										onClick: () => {
											ae(e), y(!1);
										},
										children: [e, n && /* @__PURE__ */ g("span", {
											"aria-hidden": "true",
											children: [" ", n === "heart" ? "♥" : "●"]
										})]
									}, e);
								})
							}), Je && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-reading-zoom",
								"aria-pressed": v,
								onClick: () => y(!v),
								children: r(v ? "games.cozistickerville.hideStoryPage" : "games.cozistickerville.viewStoryPage")
							})]
						}),
						Ge && /* @__PURE__ */ g("div", {
							className: "cz-story-page-stickers",
							children: [/* @__PURE__ */ h("span", { children: r("games.cozistickerville.storyPageStickers", {
								heart: Ge.heart,
								progress: Ge.progress
							}) }), We && !Ke && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-counter",
								"aria-label": r("games.cozistickerville.cardHeart"),
								onClick: () => o({
									type: "pageSticker",
									page: We,
									kind: "heart"
								}),
								children: "♥ +"
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "cz-btn cz-counter",
								"aria-label": r("games.cozistickerville.cardProgress"),
								onClick: () => o({
									type: "pageSticker",
									page: We,
									kind: "progress"
								}),
								children: "● +"
							})] })]
						}),
						(() => {
							let e = G ? or[String(Math.floor(Number(G)))] : void 0, n = e?.blocks.find((e) => e.id === G)?.[i === 0 ? "zh" : "en"], a = e?.blocks.findIndex((e) => e.id === G) ?? -1, s = a > 0 ? e.blocks[a - 1] : void 0;
							return n ? /* @__PURE__ */ g("div", {
								className: "cz-story-text-reader",
								children: [
									/* @__PURE__ */ g("article", {
										className: "cz-story-text",
										children: [n.text.split("\n").map((e, t) => /* @__PURE__ */ h("p", { children: e }, t)), !!n.choices?.length && /* @__PURE__ */ h("div", {
											className: "cz-story-choices",
											children: n.choices.map((e) => /* @__PURE__ */ g("div", {
												className: "cz-story-choice",
												children: [/* @__PURE__ */ h("span", {
													className: "cz-choice-key",
													children: e.key.toUpperCase()
												}), /* @__PURE__ */ h("span", { children: e.text })]
											}, e.key))
										})]
									}),
									t.catalog.includes("34") && s?.id && /* @__PURE__ */ g("button", {
										type: "button",
										className: "cz-btn",
										onClick: () => o({
											type: "readPrev",
											entry: s.id
										}),
										children: ["研究课题：改读 ", s.id]
									}),
									v && Je && /* @__PURE__ */ h("figure", {
										className: "cz-story-card is-enlarged",
										children: /* @__PURE__ */ h("img", {
											src: Q(Je),
											alt: r("games.cozistickerville.storyEntry", { entry: G }),
											draggable: !1
										})
									})
								]
							}) : Je && /* @__PURE__ */ h("figure", {
								className: `cz-story-card${v ? " is-enlarged" : ""}`,
								children: /* @__PURE__ */ h("img", {
									src: Q(Je),
									alt: r("games.cozistickerville.storyEntry", { entry: G }),
									draggable: !1
								})
							});
						})()
					]
				})
			}),
			/* @__PURE__ */ h(pr, {
				open: !he && p === "mile",
				title: r("games.cozistickerville.milestonesTitle"),
				onClose: it,
				children: t.milestones.length === 0 ? /* @__PURE__ */ h("p", {
					className: "cz-empty",
					children: r("games.cozistickerville.emptyMile")
				}) : /* @__PURE__ */ h("ul", {
					className: "cz-milestones",
					children: t.milestones.map((e) => {
						let [, n] = e.split("|"), a = n === "gold" ? "games.cozistickerville.milestoneGold" : n === "silver" ? "games.cozistickerville.milestoneSilver" : n === "red" ? "games.cozistickerville.milestoneRed" : "games.cozistickerville.milestoneBronze";
						return /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ h(Rn, {
							entry: e,
							covered: t.coveredMilestoneIcons,
							lang: i === 0 ? "zh" : "en"
						}), /* @__PURE__ */ h("span", {
							className: "cz-milestone-group",
							children: r(a)
						})] }, e);
					})
				})
			})
		]
	});
}
//#endregion
//#region src/game/bot.ts
function _r(e, t, n) {
	let r = x[t];
	if (!r) return null;
	let i = null;
	for (let t = 0; t <= F.rows - r.rows; t++) for (let a = 0; a <= F.cols - r.cols; a++) if (ot(e, r, a, t, n).ok) {
		if (!e.placed.some((e) => {
			let n = x[e.id];
			return !!n && a < e.col + n.cols && e.col < a + r.cols && t < e.row + n.rows && e.row < t + r.rows;
		})) return {
			col: a,
			row: t
		};
		i ??= {
			col: a,
			row: t
		};
	}
	return i;
}
var vr = (e) => {
	let t = e.public;
	if (t.phase === "done") return null;
	let n = t.prompt;
	if (n) {
		if (n.kind === "pickOpt") {
			let e = t.promptOptions.find((e) => e.enabled) ?? t.promptOptions[0];
			return e ? { action: {
				type: "resolvePrompt",
				key: e.key
			} } : null;
		}
		if (n.kind === "exchange") return { action: {
			type: "resolvePrompt",
			key: t.promptOptions.find((e) => e.enabled && e.key !== "done")?.key ?? "done"
		} };
		if (n.kind === "clock") return { action: {
			type: "resolvePrompt",
			key: "12:00"
		} };
		if (n.kind === "name") return { action: {
			type: "resolvePrompt",
			key: "小村"
		} };
		if (n.kind === "pickRes" || n.kind === "pickCard" || n.kind === "pickPlace") {
			let e = n.pick?.[0];
			return e ? { action: {
				type: "resolvePrompt",
				key: e
			} } : null;
		}
		let e = Ve(n.code ?? "");
		if (!e) return null;
		let r = _r(t, e.id, n);
		return r ? { action: {
			type: "placePending",
			col: r.col,
			row: r.row
		} } : { action: { type: "skipPlace" } };
	}
	if (t.phase === "starting") {
		if (t.startingPairs.length >= 8) return null;
		let e = new Set(t.startingPairs), n = Pt.filter((t) => !e.has(t.id) && !Ft(t.id)?.some((n) => n !== t.id && e.has(n)));
		for (let e of n) {
			let n = _r(t, e.id);
			if (n) return { action: {
				type: "placeStarting",
				id: e.id,
				col: n.col,
				row: n.row
			} };
		}
		return null;
	}
	if (t.phase === "morning") return { action: { type: "draw" } };
	if (t.phase === "choice") {
		let e = t.choices.find((e) => e.enabled);
		return e ? { action: {
			type: "choice",
			opt: e.key
		} } : null;
	}
	if (t.phase === "afternoon") {
		if (t.action > 0) {
			let e = t.keepActions.find((e) => e.enabled);
			if (e) return { action: {
				type: "useKeep",
				id: e.id,
				key: e.key
			} };
			let n = t.catalogActions.find((e) => e.enabled);
			if (n) return { action: {
				type: "useCard",
				key: n.key
			} };
			let r = t.stickerActions.find((e) => e.enabled);
			if (r) return { action: {
				type: "useSticker",
				code: r.code
			} };
		}
		return { action: { type: "endTurn" } };
	}
	return t.phase === "yearEnd" ? { action: { type: "endYear" } } : null;
};
//#endregion
//#region src/game/game-over.tsx
function yr(e) {
	let t = e.public, n = d(), r = u((e) => e.locale) === "zh" ? "zh" : "en", [i, a] = l(!1), o = t.ending ? xe.find((e) => e.key === t.ending) : void 0, s = e.result.scores?.[e.myRid] ?? t.happiness + t.milestones.length + t.catalog.length;
	return /* @__PURE__ */ g("div", {
		className: `cz-root cz-over${i ? " is-reviewing" : ""}`,
		children: [/* @__PURE__ */ g("header", {
			className: "cz-over-header",
			children: [/* @__PURE__ */ h("h1", { children: n("games.cozistickerville.name") }), /* @__PURE__ */ h("span", { children: n("games.cozistickerville.year", { n: t.year }) })]
		}), /* @__PURE__ */ g("div", {
			className: "cz-over-spread",
			children: [/* @__PURE__ */ g("div", {
				className: "cz-over-map",
				children: [/* @__PURE__ */ h(er, {
					side: t.side,
					placed: t.placed,
					happiness: t.happiness,
					milestones: t.milestones,
					coveredMilestoneIcons: t.coveredMilestoneIcons,
					lang: r,
					readOnly: !0
				}), /* @__PURE__ */ h("button", {
					type: "button",
					className: "cz-btn cz-primary cz-over-review",
					onClick: () => a(!i),
					children: n(i ? "games.cozistickerville.closeTown" : "games.cozistickerville.revisitTown")
				})]
			}), /* @__PURE__ */ g("div", {
				className: "cz-over-card",
				hidden: i,
				children: [
					/* @__PURE__ */ h("p", {
						className: "cz-over-kicker",
						children: n("games.cozistickerville.finalTitle")
					}),
					o && /* @__PURE__ */ g("section", {
						className: "cz-over-ending",
						children: [/* @__PURE__ */ h("h2", { children: o.title[r] }), /* @__PURE__ */ h("p", { children: o.text[r] })]
					}),
					/* @__PURE__ */ g("div", {
						className: "cz-over-score",
						children: [/* @__PURE__ */ h("span", { children: n("games.cozistickerville.scoreLabel") }), /* @__PURE__ */ h("strong", { children: s })]
					}),
					/* @__PURE__ */ g("dl", {
						className: "cz-over-breakdown",
						children: [
							/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("dt", { children: n("games.cozistickerville.hearts") }), /* @__PURE__ */ h("dd", { children: t.happiness })] }),
							/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("dt", { children: n("games.cozistickerville.openMile") }), /* @__PURE__ */ h("dd", { children: t.milestones.length })] }),
							/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("dt", { children: n("games.cozistickerville.openCatalog") }), /* @__PURE__ */ h("dd", { children: t.catalog.length })] })
						]
					}),
					e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ g("div", {
						className: "cz-over-btns",
						children: [e.onPlayAgain && /* @__PURE__ */ h("button", {
							type: "button",
							className: "cz-btn cz-primary",
							onClick: e.onPlayAgain,
							children: n("session.result.playAgain")
						}), e.onBackToLobby && /* @__PURE__ */ h("button", {
							type: "button",
							className: "cz-btn",
							onClick: e.onBackToLobby,
							children: n("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ h("p", {
						className: "cz-over-wait",
						children: n("session.result.waitHost")
					})
				]
			})]
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function br({ value: e, onChange: t }) {
	let n = d(), r = D.safeParse(e), i = r.success ? r.data : D.parse({}), [a, o] = l(""), [s, c] = l(!1);
	async function u() {
		c(!0), o("");
		try {
			let e = await Nn();
			e ? (t({
				...i,
				checkpoint: e
			}), o(n("games.cozistickerville.checkpoint"))) : o(n("games.cozistickerville.emptyArchive"));
		} catch {
			o(n("games.cozistickerville.loadError"));
		} finally {
			c(!1);
		}
	}
	return /* @__PURE__ */ g("section", {
		className: "cz-archive flex flex-col gap-3",
		children: [
			/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h3", {
				className: "font-bold",
				children: n("games.cozistickerville.sidePick")
			}), /* @__PURE__ */ h("div", {
				className: "mt-2 flex gap-2",
				children: ["A", "B"].map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					"aria-pressed": i.side === e,
					disabled: !!i.checkpoint,
					onClick: () => t({
						...i,
						side: e
					}),
					children: n("games.cozistickerville.side", { s: e })
				}, e))
			})] }),
			/* @__PURE__ */ h("h3", {
				className: "font-bold",
				children: n("games.cozistickerville.archive")
			}),
			/* @__PURE__ */ h("button", {
				className: "cz-archive-load",
				type: "button",
				disabled: s,
				onClick: () => void u(),
				children: n(s ? "games.cozistickerville.loading" : "games.cozistickerville.load")
			}),
			i.checkpoint && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("p", { children: n("games.cozistickerville.year", { n: i.checkpoint.year }) }), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => {
					t({
						...i,
						checkpoint: null
					}), o("");
				},
				children: n("games.cozistickerville.newCampaign")
			})] }),
			/* @__PURE__ */ h("p", {
				role: "status",
				children: a
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var xr = {
	definition: fn,
	View: gr,
	bot: vr,
	OverView: yr,
	Options: br,
	locales: {
		zh: {
			name: "温馨贴纸小镇",
			desc: "在双面村庄地图上贴满居民与建筑，经营十年温馨小镇。",
			rules: "目标：\n用十年时间建设温馨贴纸小镇，让居民幸福生活，并在结束时获得尽可能高的小镇评分。本作为单人游戏，没有失败条件；根据最终心情与达成的内容，你会读到五个结局之一。\n\n地图与贴纸：\n地图分为正反两面，开局时选择其中一面。两面地图都由草地、水域与岩地组成，一条河流把草地分成两岸，折痕把地图分成若干版块；完成一局后，可以在另一面地图上再玩一次。贴纸分为地形贴纸与透明贴纸：地形贴纸带有草地、水域或岩地背景，必须贴在背景相符的地形上；透明贴纸没有背景，可以叠放在任意贴纸上。放置地形贴纸时，贴纸的格子必须与地图网格对齐，全部格子都要落在相符的地形内，并且所有草地贴纸都必须位于河流的同一侧；建成桥梁后，本局余下时间不受此限制。任何地形贴纸都不能跨越折痕。地形贴纸不能覆盖其他地形贴纸，只有效果明确允许覆盖时，才能盖在其他贴纸上。\n\n开局：\n从第九页的起始贴纸中，每一对只能选择一枚，一共把八枚贴纸放到地图上。八枚起始贴纸放置完成后，按地图上的图标获得一次岁初收入，随后第一年开始。起始心情为两颗心。\n\n每年流程：\n每年使用一组十二张事件牌作为牌库，并按随机顺序排列。每天清晨，你从牌库抽取一张事件牌，然后按下列步骤进行：\n· 若事件牌印有选项，你从可支付的选项中选取一项，支付其费用并立即结算效果。\n· 若事件牌没有选项且符合留场条件，将它留在场上，再进入午后。若不符合，弃掉该牌并按牌上说明处理。\n结算完成后进入午后，你可以执行一次午后行动：\n· 使用一张留场建筑牌上印有的行动。\n· 使用一张图鉴牌上印有的行动。\n· 使用一枚已放置贴纸印有的“阅读故事”行动。\n你也可以不执行行动，直接结束这一天。执行一次行动后，本日随即结束；若效果给予额外行动，你可以在同一天继续行动。若牌库还有牌，就进入下一天；若牌库已空，则进入岁末。\n\n岁初收入：\n放置完起始贴纸后，以及从第二年起每年开始时，按地图上未被遮住的图标获得资源：每个木材图标获得一份木材，每个食物图标获得一份食物，里程碑上的每枚未覆盖的金币王冠图标提供一枚金币。矿石不能通过这种方式获得。被地形贴纸遮住的贴纸不再提供图标与行动。\n\n资源、心情与不满：\n木材、食物、金币与矿石的数量受供应限制：木材、食物与金币最多各十二个，矿石最多六个。心情沿地图上的心情轨道记录，最多三十颗心。部分效果会增加或移除不满标记；不满本身没有固定规则，只在明确引用它的效果中起作用。\n\n岁初设置：\n第一年开始前，按故事书的岁初设置执行。从第二年开始，每年开始先结算当年的岁初设置，再抽取当年第一张事件牌：\n· 第二年：获得图鉴牌 42。\n· 第三年：若你拥有“Hunger”里程碑，失去 1 颗心；否则获得 1 金币。\n· 第四年：若你已放置起始贴纸 9L，则把 7N 覆盖在指定位置，并失去 2 份食物；否则获得 1 份食物。\n· 第五年：放置贴纸 5C；若无法放置，则改为放置贴纸 5D。\n· 第六年：若你拥有“Lodge”里程碑，放置贴纸 4T；否则获得图鉴牌 22。\n· 第七年：若你拥有“Degenerate”或“Upstanding”里程碑，获得 1 份矿石；否则阅读故事 18.3。\n· 第八年：若你拥有“Lucky”里程碑，可以免费放置花朵贴纸 11A，或花费 1 金币放置道路贴纸 3E；否则把贴纸 10E 放在悬崖边。\n· 第九年：若你已放置贴纸 8H，获得 2 金币；否则放置贴纸 7E，并把事件牌 Y6-12 移出本局。\n· 第十年：没有额外的岁初设置。\n\n岁末与终局：\n每年结束时，先依次结算留场建筑与图鉴牌上标注的岁末效果，再进入下一年。第十年结束后计算小镇评分：评分为心情、里程碑数量与图鉴牌数量之和，并根据心情落在哪一档给出对应结局。\n\n保存：\n使用“保存小镇”把进度写入本机档案；只有界面显示已保存，才代表写入成功。开局选项可以载入已有档案；若档案被其他页面更新，请重新载入最新档案。\n\n改编说明：\n本电子版把原版的纸质贴纸与故事书改编为可交互的地图、卡牌与故事弹层。以下细节采用固定分支或近似处理：\n· 卡面贴纸数量按图鉴牌上实际放置的爱心与进度贴纸结算。\n· 竞选州长（故事 9.3、27.1）固定为花费 3 金币并掷骰，掷出 4 至 6 即成功。\n· 烘焙比赛（故事 26.6）按选定的食物数量结算掷骰与奖励，但不限制卡 28 能否带来额外行动。\n· 岁初设置中的指定位置以任意合法位置近似：第四年的 7N 与第八年的 10E 可以放在任何合法位置，第八年的悬崖相邻关系不单独判定。\n· 居民数量按地图贴纸插画中的人物精确统计。\n· 卡 36 按玩家输入的当前时间与分针位置结算；卡 22、31、45、50 的谜题仍以阅读对应的提示故事条目结算。\n起始贴纸按贴纸编号顺序两两成对，具体结果以牌面与故事条目的文字为准。",
			invalid: "这个操作当前不可执行。",
			errOob: "超出地图边界。",
			errBg: "贴纸背景与地形不符。",
			errOverlap: "这里已经有贴纸了。",
			errRiver: "草地贴纸必须放在同一条河岸。",
			errPair: "这一对起始贴纸只能选择其中一个。",
			errFold: "贴纸不能压在折痕上。",
			sidePick: "选择地图",
			actionLeft: "剩余行动 {{n}}",
			upset: "不满",
			pickResHint: "选择一种资源。",
			pickCardHint: "选择一张图鉴牌。",
			pickPlaceHint: "选择要放置的贴纸。",
			exchangeHint: "可兑换 {{n}} 份资源；兑换矿石时，每 1 枚矿石需要 2 份资源。",
			phStarting: "起始布置",
			phMorning: "清晨",
			phChoice: "抉择",
			phAfternoon: "午后",
			phPlacing: "放置",
			phYearEnd: "岁末",
			phDone: "落幕",
			draw: "抽取事件",
			endTurn: "结束这一天",
			endYear: "进入下一年",
			choose: "选择结果",
			year: "第 {{n}} 年",
			hearts: "心情",
			resources: "资源",
			placedCount: "已放置 {{n}}",
			deckCount: "牌库 {{n}}",
			startHint: "选择一组起始贴纸，放到相符的地形上。已完成 {{done}} / {{total}}。",
			startEmpty: "请从下方选择一张起始贴纸。",
			pendingHint: "在地图上放置贴纸 {{code}}，剩余 {{n}} 张。",
			pendingCoverHint: "用贴纸 {{code}} 覆盖地图上编号 {{num}} 的贴纸，剩余 {{n}} 张。",
			pendingCoverWholeHint: "用贴纸 {{code}} 盖住编号 {{num}} 的整张贴纸，剩余 {{n}} 张。",
			pendingCoverNumberHint: "把贴纸 {{code}} 对准高亮区域，盖住印刷编号 {{num}}。剩余 {{n}} 张。",
			pendingOnNumberHint: "把贴纸 {{code}} 放在编号 {{num}} 的贴纸高亮区域内，剩余 {{n}} 张。",
			errTarget: "请选择高亮位置，让贴纸盖住所需目标。",
			skipPlace: "跳过此贴纸",
			confirmPlace: "确认贴上",
			cancelPlace: "取消放置",
			placeRemaining: "待放置 {{code}} ×{{n}}",
			morningHint: "清晨：从牌库抽取一张事件牌。",
			afternoonHint: "午后：使用卡牌或贴纸上的行动，或直接结束这一天。",
			yearEndHint: "本年结束，确认后进入下一年。",
			eventTitle: "事件",
			todayEvent: "今日事件",
			reviewEvent: "回看事件",
			continueEvent: "继续处理事件",
			eventCardName: "第 {{year}} 年事件牌 {{card}}",
			eventFlavorLabel: "清晨 · 事件",
			enterAfternoon: "进入午后",
			returnMap: "返回地图",
			enlargeCard: "放大牌面",
			enlargeSticker: "放大贴纸 {{code}}",
			stickerTitle: "贴纸 {{code}}",
			fitCard: "查看全图",
			viewOriginalCard: "查看原卡",
			enlargePage: "放大页面",
			eventKept: "这张牌放入留场建筑。",
			eventKeepOption: "午后可执行",
			storyPageStickers: "本页贴纸：爱心 {{heart}}，进度 {{progress}}",
			storyHeartMark: "爱心贴纸",
			storyProgressMark: "进度贴纸",
			hatchetAttached: "已装斧头贴纸 1E",
			hatchetRoll: "1–4：使用斧头，获得 2 份木材。",
			removeRedMilestone: "选择移除一个红色里程碑",
			eventNoOptions: "本次事件没有可用选项。",
			eventFoodShort: "食物不足，无法选择。",
			eventBreakfastOption: "花费 2 份食物，额外行动一次",
			eventPicked: "已选 {{key}} · {{choice}}",
			storyEntry: "故事 {{entry}}",
			catalogEntry: "图鉴 {{entry}}",
			cardNumber: "图鉴牌编号",
			storyNumber: "故事编号",
			continueDecision: "继续选择",
			exchangeTitle: "资源兑换",
			finishExchange: "结束兑换",
			milestoneGold: "金色",
			milestoneSilver: "银色",
			milestoneBronze: "铜色",
			milestoneRed: "红色",
			noEvent: "尚未抽取事件",
			logTitle: "小镇记事",
			inPlayTitle: "留场建筑",
			catalogTitle: "图鉴",
			storyTitle: "故事",
			milestonesTitle: "里程碑",
			save: "保存小镇",
			saving: "正在保存…",
			saved: "已保存",
			saveError: "保存失败，请重试。",
			saveNewer: "档案已被另一页面更新，请载入最新档案。",
			load: "载入小镇档案",
			loading: "正在读取档案…",
			loadError: "读取失败，请重试。",
			emptyArchive: "尚无小镇档案。",
			newCampaign: "开始新小镇",
			archive: "小镇档案",
			checkpoint: "已选中小镇档案，开局后从保存位置继续。",
			confirmNew: "保存将替换现有小镇档案，是否继续？",
			cancel: "取消",
			confirm: "确认",
			close: "关闭",
			resume: "继续档案",
			zoomIn: "放大",
			zoomOut: "缩小",
			zoomReset: "全图",
			pairOr: "或",
			pairHint: "每对贴纸选择一枚。",
			setupCount: "已放置 {{done}} / {{total}}",
			pickPosition: "在地图上选择一个标出的落点。",
			adjustSticker: "可拖动贴纸调整落点。",
			townTabs: "小镇资料",
			revisitTown: "回看小镇",
			closeTown: "返回结局",
			scoreLabel: "小镇评分",
			mapHint: "拖动平移地图，使用按钮缩放。",
			wood: "木材",
			food: "食物",
			gold: "金币",
			ore: "矿石",
			side: "地图 {{s}} 面",
			finalTitle: "小镇故事落幕",
			score: "小镇评分 {{n}}",
			again: "重新开始",
			back: "返回大厅",
			openLog: "记事",
			openCatalog: "图鉴",
			openStory: "故事",
			openMile: "里程碑",
			emptyLog: "还没有记下任何事。",
			emptyCatalog: "还未获得图鉴牌。",
			emptyStory: "还未阅读故事。",
			emptyMile: "还未达成里程碑。",
			useCard: "使用",
			startCount: "{{n}} 张",
			turnLabel: "行动",
			place: "放置",
			villageName: "村庄名称",
			clock: "当前时间",
			viewStoryPage: "查看原页",
			hideStoryPage: "收起原页",
			cardHeart: "爱心贴纸",
			cardProgress: "进度贴纸",
			cardFood: "牌上食物"
		},
		en: {
			name: "Cozy Stickerville",
			desc: "Fill a double-sided village map with residents and buildings across ten cozy years.",
			rules: "Goal:\nBuild the cozy town of Stickerville over ten years, keep its residents happy, and finish with the highest town score you can. This is a solo game with no way to lose; your final hearts and achievements lead you to one of five endings.\n\nMap and stickers:\nThe map has two sides, and you choose one at setup. Both sides are made of grass, water, and rock; a river splits the grass into two banks, and folds divide the map into panels. After finishing a game you may play again on the other side. Stickers come in terrain stickers and clear stickers: a terrain sticker carries a grass, water, or rock background and must be placed on matching terrain, while a clear sticker has no background and may be stacked on any sticker. When you place a terrain sticker, its cells must line up with the map grid, every cell must fall on matching terrain, and all grass stickers must stay on one bank of the river; after a bridge is built this restriction no longer applies. No terrain sticker may straddle a fold. A terrain sticker may not cover another terrain sticker, and it may cover another sticker only when an effect explicitly allows it.\n\nSetup:\nFrom the page-nine starting stickers, you choose exactly one of each pair and place eight stickers on the map. Once all eight are placed, you gain one year-setup income from the icons on the map, and year 1 begins. You start with two hearts.\n\nYearly flow:\nEach year uses twelve event cards, shuffled into its deck. Every morning you draw one event card, then follow these steps:\n· If the card prints options, choose one you can afford, pay its cost, and resolve its effect immediately.\n· If the card has no options and meets the conditions for staying in play, keep it and enter the afternoon. Otherwise, discard it and follow its instructions.\nAfter resolution the afternoon begins, and you may take one afternoon action:\n· use an action printed on a kept building card;\n· use an action printed on a catalog card;\n· use a “read story” action printed on a placed sticker.\nYou may also end the day without taking an action. Your day ends after one action; if an effect grants an extra action, you may keep acting that day. If the deck still has cards, the next day begins; otherwise the year ends.\n\nYear-setup income:\nAfter the starting stickers are placed, and at the start of every year from year 2 onward, you gain resources from the uncovered icons on the map: one wood for each wood icon, one food for each food icon, and one gold for each uncovered gold crown icon on your milestones. Ore is never gained this way. Stickers hidden under a terrain sticker no longer provide icons or actions.\n\nResources, hearts, and upset:\nWood, food, gold, and ore are limited by the supply: wood, food, and gold cap at twelve each, and ore caps at six. Hearts are tracked on the map’s happiness track, up to thirty. Some effects add or remove upset stickers; upset has no fixed rule of its own and matters only in effects that explicitly refer to it.\n\nYear setup:\nBefore year 1 begins, follow the storybook’s year setup. From year 2 onward, resolve the year’s setup before drawing that year’s first event card:\n· Year 2: gain catalog card 42.\n· Year 3: if you have the Hunger milestone, lose 1 heart; otherwise gain 1 gold.\n· Year 4: if the starting sticker 9L is on the map, cover the indicated spot with 7N and lose 2 food; otherwise gain 1 food.\n· Year 5: place sticker 5C; if it cannot be placed, place sticker 5D instead.\n· Year 6: if you have a Lodge milestone, place sticker 4T; otherwise gain catalog card 22.\n· Year 7: if you have the Degenerate or Upstanding milestone, gain 1 ore; otherwise read story 18.3.\n· Year 8: if you have the Lucky milestone, either place the flower sticker 11A for free or spend 1 gold to place the road sticker 3E; otherwise place sticker 10E by the cliff.\n· Year 9: if sticker 8H is on the map, gain 2 gold; otherwise place sticker 7E and remove event card Y6-12 from this game.\n· Year 10: there is no further setup.\n\nYear end and finale:\nAt each year end, resolve the year-end effects printed on kept buildings and catalog cards in turn, then begin the next year. After year 10 you tally the town score: hearts plus the number of milestones plus the number of catalog cards, and your hearts decide which of the five endings you read.\n\nSaving:\nUse “Save town” to write your progress to this device’s archive; it is only saved once the interface says so. The setup options can load an existing archive; if another page updates the archive, load the newest one again.\n\nAdaptation note:\nThis digital edition turns the physical stickers and storybook into an interactive map, cards, and story sheets. The following details use fixed branches or approximations:\n· Card sticker counts use the heart and progress stickers actually placed on the catalog card.\n· Running for governor (stories 9.3 and 27.1) is always a 3-gold roll that succeeds on 4 to 6.\n· The baking competition (story 26.6) resolves the roll and reward for the chosen amount of food but does not prevent card 28 from granting an extra action.\n· The indicated spots in year setup are approximated by any legal placement: 7N in year 4 and 10E in year 8 may go anywhere legal, and year 8 does not check cliff-side adjacency.\n· Resident counts are read from the people shown in the artwork of uncovered stickers.\n· Card 36 uses the current time entered by the player and the exact minute-hand position; cards 22, 31, 45, and 50 still resolve their puzzles by reading the corresponding hint story entries.\nStarting stickers pair up in sticker-number order, and the printed text on cards and story entries remains the reference for each result.",
			invalid: "That action is not available right now.",
			errOob: "That placement is outside the map.",
			errBg: "This sticker’s background does not match the terrain.",
			errOverlap: "A sticker already covers that spot.",
			errRiver: "Grass stickers must stay on the same river bank.",
			errPair: "You may pick only one sticker from each starting pair.",
			errFold: "Stickers cannot straddle a map fold.",
			sidePick: "Choose a map",
			actionLeft: "Actions left {{n}}",
			upset: "Upset",
			pickResHint: "Choose a resource.",
			pickCardHint: "Choose a catalog card.",
			pickPlaceHint: "Choose a sticker to place.",
			exchangeHint: "Exchange up to {{n}} resources; each ore costs 2 resources.",
			phStarting: "Setup",
			phMorning: "Morning",
			phChoice: "Choice",
			phAfternoon: "Afternoon",
			phPlacing: "Placing",
			phYearEnd: "Year end",
			phDone: "Finale",
			draw: "Draw event",
			endTurn: "End the day",
			endYear: "Begin next year",
			choose: "Choose an option",
			year: "Year {{n}}",
			hearts: "Hearts",
			resources: "Resources",
			placedCount: "Placed {{n}}",
			deckCount: "Deck {{n}}",
			startHint: "Pick one sticker from each pair and place it on matching terrain. Done {{done}} / {{total}}.",
			startEmpty: "Pick a starting sticker below.",
			pendingHint: "Place sticker {{code}} on the map; {{n}} remaining.",
			pendingCoverHint: "Cover the sticker numbered {{num}} with {{code}}; {{n}} remaining.",
			pendingCoverWholeHint: "Use {{code}} to cover the entire sticker numbered {{num}}. {{n}} remaining.",
			pendingCoverNumberHint: "Fit {{code}} over the highlighted area to cover the printed {{num}}. {{n}} remaining.",
			pendingOnNumberHint: "Place {{code}} in a highlighted area on sticker {{num}}. {{n}} remaining.",
			errTarget: "Place the sticker on a highlighted space to cover the required target.",
			skipPlace: "Skip this sticker",
			confirmPlace: "Confirm placement",
			cancelPlace: "Cancel placement",
			placeRemaining: "To place {{code}} ×{{n}}",
			morningHint: "Morning: draw an event card from the deck.",
			afternoonHint: "Afternoon: use an action from a card or placed sticker, or end the day.",
			yearEndHint: "The year is over. Confirm to begin the next year.",
			eventTitle: "Event",
			todayEvent: "Today’s event",
			reviewEvent: "Review event",
			continueEvent: "Continue event",
			eventCardName: "Year {{year}}, event card {{card}}",
			eventFlavorLabel: "Morning · Event",
			enterAfternoon: "Enter the afternoon",
			returnMap: "Back to map",
			enlargeCard: "Enlarge card",
			enlargeSticker: "Enlarge sticker {{code}}",
			stickerTitle: "Sticker {{code}}",
			fitCard: "Fit to view",
			viewOriginalCard: "View original card",
			enlargePage: "Enlarge page",
			eventKept: "Keep this card in play.",
			eventKeepOption: "Afternoon action",
			storyPageStickers: "Stickers on this page: hearts {{heart}}, progress {{progress}}",
			storyHeartMark: "Heart sticker",
			storyProgressMark: "Progress sticker",
			hatchetAttached: "Hatchet sticker 1E attached",
			hatchetRoll: "1–4: Use the hatchet to gain 2 wood.",
			removeRedMilestone: "Choose a red milestone to remove",
			eventNoOptions: "No options are available for this event.",
			eventFoodShort: "You do not have enough food for this choice.",
			eventBreakfastOption: "Spend 2 food to take one additional action",
			eventPicked: "Selected {{key}} · {{choice}}",
			storyEntry: "Story {{entry}}",
			catalogEntry: "Catalog card {{entry}}",
			cardNumber: "Catalog card number",
			storyNumber: "Story number",
			continueDecision: "Continue selection",
			exchangeTitle: "Resource exchange",
			finishExchange: "Finish exchange",
			milestoneGold: "Gold",
			milestoneSilver: "Silver",
			milestoneBronze: "Bronze",
			milestoneRed: "Red",
			noEvent: "No event drawn yet",
			logTitle: "Town chronicle",
			inPlayTitle: "Kept buildings",
			catalogTitle: "Catalog",
			storyTitle: "Story",
			milestonesTitle: "Milestones",
			save: "Save town",
			saving: "Saving…",
			saved: "Saved",
			saveError: "Save failed. Please try again.",
			saveNewer: "The archive was updated in another tab. Load the newest archive.",
			load: "Load town archive",
			loading: "Reading archive…",
			loadError: "Could not read the archive. Please try again.",
			emptyArchive: "No town archive yet.",
			newCampaign: "Start a new town",
			archive: "Town archive",
			checkpoint: "A town archive is selected; the game resumes from the saved position.",
			confirmNew: "Saving will replace the existing town archive. Continue?",
			cancel: "Cancel",
			confirm: "Confirm",
			close: "Close",
			resume: "Resume archive",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			zoomReset: "Full map",
			pairOr: "or",
			pairHint: "Choose one sticker from each pair.",
			setupCount: "Placed {{done}} / {{total}}",
			pickPosition: "Choose a marked spot on the map.",
			adjustSticker: "Drag the sticker to adjust its position.",
			townTabs: "Town records",
			revisitTown: "Explore the town",
			closeTown: "Return to ending",
			scoreLabel: "Town score",
			mapHint: "Drag to pan the map; use the buttons to zoom.",
			wood: "Wood",
			food: "Food",
			gold: "Gold",
			ore: "Ore",
			side: "Map side {{s}}",
			finalTitle: "The town story concludes",
			score: "Town score {{n}}",
			again: "Play again",
			back: "Back to lobby",
			openLog: "Log",
			openCatalog: "Catalog",
			openStory: "Story",
			openMile: "Milestones",
			emptyLog: "Nothing recorded yet.",
			emptyCatalog: "No catalog cards yet.",
			emptyStory: "No stories read yet.",
			emptyMile: "No milestones reached yet.",
			useCard: "Use",
			startCount: "{{n}}",
			turnLabel: "Action",
			place: "Place",
			villageName: "Village name",
			clock: "Current time",
			viewStoryPage: "View page",
			hideStoryPage: "Hide page",
			cardHeart: "Heart sticker",
			cardProgress: "Progress sticker",
			cardFood: "Food on card"
		}
	}
};
//#endregion
export { xr as default };
