import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { createPortal as r } from "react-dom";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { avatarNameAt as a, useGameT as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconHistory as l, IconPlayers as u } from "@bgparty/sdk/icons";
import { DeltaNumber as d, PhaseBanner as f, PlayerStrip as p } from "@bgparty/sdk/ui";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { seatName as h } from "@bgparty/sdk/ui/player-strip";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { PLAYER_COLORS as _ } from "@bgparty/sdk/player-colors";
import { gameAssetUrl as v } from "@bgparty/sdk/assets";
import { useFxAnchor as y } from "@bgparty/sdk/fx/anchors";
import { HintRing as b } from "@bgparty/sdk/ui/hint-ring";
import { jsx as x, jsxs as S } from "react/jsx-runtime";
import { FlySprite as ee } from "@bgparty/sdk/fx/primitives";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
//#region src/game/data.ts
var w = (e, t, n, r, i, a = 0, o = !1) => ({
	key: e,
	faction: t,
	kind: n,
	subtypes: r,
	cost: i,
	defense: a,
	guard: o
}), T = [
	w("taxation", "imperial", "action", "Action", 1),
	w("recruit", "imperial", "action", "Action", 2),
	w("closeRanks", "imperial", "action", "Action", 3),
	w("rallyTheTroops", "imperial", "action", "Action", 4),
	w("command", "imperial", "action", "Action", 5),
	w("wordOfPower", "imperial", "action", "Action,Spell", 6),
	w("domination", "imperial", "action", "Action", 7),
	w("profit", "guild", "action", "Action", 1),
	w("intimidation", "guild", "action", "Action,Rogue", 2),
	w("bribe", "guild", "action", "Action", 3),
	w("deathThreat", "guild", "action", "Action,Assassin", 3),
	w("hitJob", "guild", "action", "Action,Assassin", 4),
	w("deception", "guild", "action", "Action", 5),
	w("smashAndGrab", "guild", "action", "Action,Rogue", 6),
	w("fireBomb", "guild", "action", "Action", 8),
	w("deathTouch", "necros", "action", "Action,Curse", 1),
	w("influence", "necros", "action", "Action", 2),
	w("theRot", "necros", "action", "Action,Curse", 3),
	w("darkEnergy", "necros", "action", "Action,Spell", 4),
	w("darkReward", "necros", "action", "Action", 5),
	w("lifeDrain", "necros", "action", "Action,Curse", 6),
	w("spark", "wild", "action", "Action,Spell", 1),
	w("elvenGift", "wild", "action", "Action,Elf", 2),
	w("elvenCurse", "wild", "action", "Action,Elf Curse", 3),
	w("naturesBounty", "wild", "action", "Action", 4),
	w("wolfForm", "wild", "action", "Action,Wolf", 5),
	w("rampage", "wild", "action", "Action,Orc", 6),
	w("tithePriest", "imperial", "champion", "Champion,Human Priest", 2, 3),
	w("manAtArms", "imperial", "champion", "Champion,Human Warrior", 3, 4, !0),
	w("masterWeyan", "imperial", "champion", "Champion,Human Monk", 4, 4, !0),
	w("darianWarMage", "imperial", "champion", "Champion,Human Mage", 4, 5),
	w("cristovTheJust", "imperial", "champion", "Champion,Human Paladin", 5, 5, !0),
	w("krakaHighPriest", "imperial", "champion", "Champion,Human Priest", 6, 6),
	w("arkusImperialDragon", "imperial", "champion", "Champion,Dragon", 8, 6, !0),
	w("streetThug", "guild", "champion", "Champion,Human Rogue", 3, 4),
	w("rasmusTheSmuggler", "guild", "champion", "Champion,Human Rogue", 4, 5),
	w("parovTheEnforcer", "guild", "champion", "Champion,Human Rogue", 5, 5, !0),
	w("myrosGuildMage", "guild", "champion", "Champion,Human Mage", 5, 3, !0),
	w("borgOgreMercenary", "guild", "champion", "Champion,Ogre Warrior", 6, 6, !0),
	w("rakeMasterAssassin", "guild", "champion", "Champion,Human Assassin", 7, 7),
	w("deathCultist", "necros", "champion", "Champion,Human", 2, 3, !0),
	w("cultPriest", "necros", "champion", "Champion,Human", 3, 4),
	w("raylaEndweaver", "necros", "champion", "Champion,Human Mage", 4, 4),
	w("varrickTheNecromancer", "necros", "champion", "Champion,Human Necromancer", 5, 3),
	w("lysTheUnseen", "necros", "champion", "Champion,Vampire", 6, 5, !0),
	w("krythosMasterVampire", "necros", "champion", "Champion,Vampire", 7, 6),
	w("tyrannorTheDevourer", "necros", "champion", "Champion,Demon", 8, 6, !0),
	w("wolfShaman", "wild", "champion", "Champion,Human Priest", 2, 4),
	w("orcGrunt", "wild", "champion", "Champion,Orc", 3, 3, !0),
	w("broelynLoreweaver", "wild", "champion", "Champion,Elf Mage", 4, 6),
	w("direWolf", "wild", "champion", "Champion,Giant Wolf", 5, 5, !0),
	w("cronTheBerserker", "wild", "champion", "Champion,Human Warrior", 6, 6),
	w("torgenRocksplitter", "wild", "champion", "Champion,Troll Warrior", 7, 7, !0),
	w("grakStormGiant", "wild", "champion", "Champion,Giant", 8, 7, !0),
	w("gold", "none", "item", "Item,Currency,Coin", 0),
	w("ruby", "none", "item", "Item,Currency,Gem", 0),
	w("shortsword", "none", "item", "Item,Melee Weapon,Sword", 0),
	w("dagger", "none", "item", "Item,Melee Weapon,Dagger", 0),
	w("fireGem", "none", "item", "Item,Currency,Gem", 2)
], E = Object.fromEntries(T.map((e) => [e.key, e])), D = [
	["arkusImperialDragon", 1],
	["closeRanks", 1],
	["command", 1],
	["darianWarMage", 1],
	["domination", 1],
	["cristovTheJust", 1],
	["krakaHighPriest", 1],
	["manAtArms", 2],
	["masterWeyan", 1],
	["rallyTheTroops", 1],
	["recruit", 3],
	["tithePriest", 2],
	["taxation", 3],
	["wordOfPower", 1],
	["borgOgreMercenary", 1],
	["bribe", 3],
	["deathThreat", 1],
	["deception", 1],
	["fireBomb", 1],
	["hitJob", 1],
	["intimidation", 2],
	["myrosGuildMage", 1],
	["parovTheEnforcer", 1],
	["profit", 3],
	["rakeMasterAssassin", 1],
	["rasmusTheSmuggler", 1],
	["smashAndGrab", 1],
	["streetThug", 2],
	["cultPriest", 2],
	["darkEnergy", 1],
	["darkReward", 1],
	["deathCultist", 2],
	["deathTouch", 3],
	["raylaEndweaver", 1],
	["influence", 3],
	["krythosMasterVampire", 1],
	["lifeDrain", 1],
	["lysTheUnseen", 1],
	["theRot", 2],
	["tyrannorTheDevourer", 1],
	["varrickTheNecromancer", 1],
	["broelynLoreweaver", 1],
	["cronTheBerserker", 1],
	["direWolf", 1],
	["elvenCurse", 2],
	["elvenGift", 3],
	["grakStormGiant", 1],
	["naturesBounty", 1],
	["orcGrunt", 2],
	["rampage", 1],
	["torgenRocksplitter", 1],
	["spark", 3],
	["wolfForm", 1],
	["wolfShaman", 2]
], te = [
	"gold",
	"gold",
	"gold",
	"gold",
	"gold",
	"gold",
	"gold",
	"ruby",
	"shortsword",
	"dagger"
], O = (e) => E[e]?.faction ?? "none", ne = {
	id: "herorealms",
	uuid: "7f31f98d-496e-4612-945f-0c14dbe4905c",
	tier: "alpha",
	nameKey: "games.herorealms.name",
	descKey: "games.herorealms.desc",
	rulesKey: "games.herorealms.rules",
	icon: "⚔️",
	iconImg: "games/herorealms.webp",
	accent: "#c9a227",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	hotseat: "cover",
	search: {
		py: "ying xiong ling yu",
		init: "yxly"
	},
	releasedAt: "2026-11-23T01:20:00+08:00",
	mechanics: [
		"deck-bag-building",
		"hand-management",
		"engine-building"
	],
	interactionTags: [],
	rulesUrl: { en: "https://cdn.1j1ju.com/medias/68/25/3e-hero-realms-rulebook.pdf" }
}, k = t.object({}).default({}), A = t.object({
	uid: t.int().nonnegative(),
	id: t.string().min(1)
}), j = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("ally"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("expend"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("sacrifice"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("buy"),
		index: t.int().min(0).max(4)
	}),
	t.object({ type: t.literal("buyGem") }),
	t.object({
		type: t.literal("attackPlayer"),
		target: t.string(),
		n: t.int().positive()
	}),
	t.object({
		type: t.literal("attackChampion"),
		uid: t.int().nonnegative(),
		n: t.int().positive()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("chooseCard"),
		uid: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("chooseOption"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("answer"),
		yes: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), M = t.enum([
	"mode",
	"stun",
	"prepare",
	"targetPlayer",
	"oppDiscard",
	"sacrifice",
	"discardSelf",
	"yesno",
	"pickTop"
]), N = t.object({
	kind: M,
	rid: t.string(),
	source: t.string(),
	count: t.int().nonnegative(),
	options: t.array(t.string()),
	players: t.array(t.string()),
	flag: t.string()
}), P = t.object({
	uid: t.int().nonnegative(),
	id: t.string(),
	dmg: t.int().nonnegative(),
	expended: t.boolean()
}), re = t.object({
	phase: t.enum([
		"main",
		"end",
		"done"
	]),
	active: t.string(),
	turnNo: t.int(),
	busy: t.boolean(),
	market: t.array(t.string().nullable()),
	marketDeck: t.int().nonnegative(),
	fireGems: t.int().nonnegative(),
	sacrifice: t.array(t.string()),
	players: t.array(t.object({
		rid: t.string(),
		health: t.int(),
		hand: t.int(),
		deck: t.int(),
		discard: t.int(),
		gold: t.int(),
		combat: t.int(),
		play: t.array(A),
		champions: t.array(P),
		allyUsed: t.array(t.int()),
		defeated: t.boolean()
	})),
	prompt: N.nullable(),
	events: t.array(t.object({
		seq: t.int(),
		kind: t.string(),
		rid: t.string(),
		card: t.string().nullable(),
		n: t.int(),
		target: t.string().nullable()
	}))
}), F = t.object({
	hand: t.array(A),
	discard: t.array(A),
	candidates: t.array(t.object({
		uid: t.int().nonnegative(),
		id: t.string(),
		from: t.enum([
			"hand",
			"discard",
			"play",
			"champion",
			"market"
		])
	})),
	canAnswer: t.boolean()
}), I = { code: "games.herorealms.invalid" }, L = (e) => e.players[e.turnIndex], R = (e) => e.players.filter((t) => !e.p[t].defeated);
function z(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function B(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function V(e, t, n, r = null, i = 0, a = null) {
	e.events.push({
		seq: e.seq++,
		kind: t,
		rid: n,
		card: r,
		n: i,
		target: a
	}), e.events.length > 120 && e.events.shift();
}
function H(e, t, n) {
	let r = e.p[t];
	for (let t = 0; t < n; t++) {
		if (!r.deck.length) {
			if (!r.discard.length) break;
			r.deck = z(e, r.discard), r.discard = [];
		}
		r.hand.push(r.deck.pop());
	}
}
var ie = (e) => e.champions.length, ae = (e) => e.champions.filter((e) => E[e.id]?.guard).length, U = (e) => e.champions.some((e) => E[e.id]?.guard && !e.expended);
function oe(e) {
	for (let t of e.champions) t.expended = !1, t.dmg = 0;
}
var se = {
	taxation: [{
		op: "health",
		n: 6
	}],
	recruit: [{
		op: "gold",
		n: 1
	}],
	closeRanks: [{
		op: "health",
		n: 6
	}],
	rallyTheTroops: [{ op: "prepareChampion" }],
	wordOfPower: [{
		op: "health",
		n: 5
	}],
	domination: [{ op: "prepareChampion" }],
	profit: [{
		op: "combat",
		n: 4
	}],
	intimidation: [{
		op: "gold",
		n: 2
	}],
	bribe: [{ op: "acquireTopAction" }],
	deathThreat: [{ op: "stun" }],
	hitJob: [{ op: "stun" }],
	deception: [{ op: "acquireHand" }],
	deathTouch: [{
		op: "combat",
		n: 2
	}],
	theRot: [{
		op: "combat",
		n: 3
	}],
	darkEnergy: [{
		op: "draw",
		n: 1
	}],
	darkReward: [{
		op: "combat",
		n: 6
	}],
	lifeDrain: [{
		op: "draw",
		n: 1
	}],
	spark: [{
		op: "combat",
		n: 2
	}],
	elvenGift: [{
		op: "combat",
		n: 4
	}],
	elvenCurse: [{
		op: "combat",
		n: 3
	}],
	naturesBounty: [{ op: "oppDiscard" }],
	cristovTheJust: [{
		op: "draw",
		n: 1
	}],
	krakaHighPriest: [{
		op: "healthPerChampion",
		per: 2
	}],
	arkusImperialDragon: [{
		op: "health",
		n: 6
	}],
	rasmusTheSmuggler: [{ op: "acquireTop" }],
	parovTheEnforcer: [{
		op: "draw",
		n: 1
	}],
	myrosGuildMage: [{
		op: "combat",
		n: 4
	}],
	cultPriest: [{
		op: "combat",
		n: 4
	}],
	raylaEndweaver: [{
		op: "draw",
		n: 1
	}],
	varrickTheNecromancer: [{
		op: "draw",
		n: 1
	}],
	tyrannorTheDevourer: [{
		op: "draw",
		n: 1
	}],
	orcGrunt: [{
		op: "draw",
		n: 1
	}],
	broelynLoreweaver: [{ op: "oppDiscard" }],
	direWolf: [{
		op: "combat",
		n: 4
	}],
	cronTheBerserker: [{
		op: "draw",
		n: 1
	}],
	grakStormGiant: [{
		op: "drawThenDiscard",
		n: 1
	}]
}, ce = {
	tithePriest: [{
		op: "choice",
		options: [{
			label: "opt.gold1",
			ops: [{
				op: "gold",
				n: 1
			}]
		}, {
			label: "opt.healthPerChampion",
			ops: [{
				op: "healthPerChampion",
				per: 1
			}]
		}]
	}],
	manAtArms: [{
		op: "combat",
		n: 2
	}, {
		op: "combatPerGuard",
		per: 1
	}],
	masterWeyan: [{
		op: "combat",
		n: 3
	}, {
		op: "combatPerChampion",
		per: 1
	}],
	darianWarMage: [{
		op: "choice",
		options: [{
			label: "opt.combat3",
			ops: [{
				op: "combat",
				n: 3
			}]
		}, {
			label: "opt.health4",
			ops: [{
				op: "health",
				n: 4
			}]
		}]
	}],
	cristovTheJust: [{
		op: "combat",
		n: 2
	}, {
		op: "health",
		n: 3
	}],
	krakaHighPriest: [{
		op: "health",
		n: 2
	}, {
		op: "draw",
		n: 1
	}],
	arkusImperialDragon: [{
		op: "combat",
		n: 5
	}, {
		op: "draw",
		n: 1
	}],
	streetThug: [{
		op: "choice",
		options: [{
			label: "opt.gold1",
			ops: [{
				op: "gold",
				n: 1
			}]
		}, {
			label: "opt.combat2",
			ops: [{
				op: "combat",
				n: 2
			}]
		}]
	}],
	rasmusTheSmuggler: [{
		op: "gold",
		n: 2
	}],
	parovTheEnforcer: [{
		op: "combat",
		n: 3
	}],
	myrosGuildMage: [{
		op: "gold",
		n: 3
	}],
	borgOgreMercenary: [{
		op: "combat",
		n: 4
	}],
	rakeMasterAssassin: [{
		op: "combat",
		n: 4
	}, { op: "mayStun" }],
	deathCultist: [{
		op: "combat",
		n: 2
	}],
	cultPriest: [{
		op: "choice",
		options: [{
			label: "opt.gold1",
			ops: [{
				op: "gold",
				n: 1
			}]
		}, {
			label: "opt.combat1",
			ops: [{
				op: "combat",
				n: 1
			}]
		}]
	}],
	raylaEndweaver: [{
		op: "combat",
		n: 3
	}],
	varrickTheNecromancer: [{ op: "championFromDiscardToTop" }],
	lysTheUnseen: [{
		op: "combat",
		n: 2
	}, {
		op: "sacrificeFor",
		combat: 2
	}],
	krythosMasterVampire: [{
		op: "combat",
		n: 3
	}, {
		op: "sacrificeFor",
		combat: 3
	}],
	tyrannorTheDevourer: [{
		op: "combat",
		n: 4
	}, {
		op: "sacrifice",
		count: 2
	}],
	wolfShaman: [{
		op: "combat",
		n: 2
	}, {
		op: "combatPerWild",
		per: 1
	}],
	orcGrunt: [{
		op: "combat",
		n: 2
	}],
	broelynLoreweaver: [{
		op: "gold",
		n: 2
	}],
	direWolf: [{
		op: "combat",
		n: 3
	}],
	cronTheBerserker: [{
		op: "combat",
		n: 5
	}],
	torgenRocksplitter: [{
		op: "combat",
		n: 4
	}, { op: "oppDiscard" }],
	grakStormGiant: [{
		op: "combat",
		n: 6
	}, {
		op: "mayDrawThenDiscard",
		n: 1
	}]
}, le = {
	wordOfPower: [{
		op: "combat",
		n: 5
	}],
	influence: [{
		op: "combat",
		n: 3
	}],
	naturesBounty: [{
		op: "combat",
		n: 4
	}],
	wolfForm: [{ op: "oppDiscard" }],
	fireBomb: [{
		op: "combat",
		n: 5
	}],
	fireGem: [{
		op: "combat",
		n: 3
	}]
}, ue = {
	taxation: [{
		op: "gold",
		n: 2
	}],
	recruit: [
		{
			op: "gold",
			n: 2
		},
		{
			op: "health",
			n: 3
		},
		{
			op: "healthPerChampion",
			per: 1
		}
	],
	closeRanks: [{
		op: "combat",
		n: 5
	}, {
		op: "combatPerChampion",
		per: 2
	}],
	rallyTheTroops: [{
		op: "combat",
		n: 5
	}, {
		op: "health",
		n: 5
	}],
	command: [
		{
			op: "gold",
			n: 2
		},
		{
			op: "combat",
			n: 3
		},
		{
			op: "health",
			n: 4
		},
		{
			op: "draw",
			n: 1
		}
	],
	wordOfPower: [{
		op: "draw",
		n: 2
	}],
	domination: [
		{
			op: "combat",
			n: 6
		},
		{
			op: "health",
			n: 6
		},
		{
			op: "draw",
			n: 1
		}
	],
	profit: [{
		op: "gold",
		n: 2
	}],
	intimidation: [{
		op: "combat",
		n: 5
	}],
	bribe: [{
		op: "gold",
		n: 3
	}],
	deathThreat: [{
		op: "combat",
		n: 1
	}, {
		op: "draw",
		n: 1
	}],
	hitJob: [{
		op: "combat",
		n: 7
	}],
	deception: [{
		op: "gold",
		n: 2
	}, {
		op: "draw",
		n: 1
	}],
	smashAndGrab: [{
		op: "combat",
		n: 6
	}, { op: "mayPickTopFromDiscard" }],
	fireBomb: [
		{
			op: "combat",
			n: 8
		},
		{ op: "stun" },
		{
			op: "draw",
			n: 1
		}
	],
	deathTouch: [{
		op: "combat",
		n: 2
	}, { op: "sacrifice" }],
	influence: [{
		op: "gold",
		n: 3
	}],
	theRot: [{
		op: "combat",
		n: 4
	}, { op: "sacrifice" }],
	darkEnergy: [{
		op: "combat",
		n: 7
	}],
	darkReward: [{
		op: "gold",
		n: 3
	}, { op: "sacrifice" }],
	lifeDrain: [{
		op: "combat",
		n: 8
	}, { op: "sacrifice" }],
	spark: [{
		op: "combat",
		n: 3
	}, { op: "oppDiscard" }],
	elvenGift: [{
		op: "gold",
		n: 2
	}, {
		op: "mayDrawThenDiscard",
		n: 1
	}],
	elvenCurse: [{
		op: "combat",
		n: 6
	}, { op: "oppDiscard" }],
	naturesBounty: [{
		op: "gold",
		n: 4
	}],
	wolfForm: [{
		op: "combat",
		n: 8
	}, { op: "oppDiscard" }],
	rampage: [
		{
			op: "combat",
			n: 6
		},
		{
			op: "mayDrawThenDiscard",
			n: 1
		},
		{
			op: "mayDrawThenDiscard",
			n: 1
		}
	],
	gold: [{
		op: "gold",
		n: 1
	}],
	ruby: [{
		op: "gold",
		n: 2
	}],
	shortsword: [{
		op: "combat",
		n: 2
	}],
	dagger: [{
		op: "combat",
		n: 1
	}],
	fireGem: [{
		op: "gold",
		n: 2
	}]
};
function W(e, t, n, r, i, a, o = {}) {
	e.prompt = {
		kind: t,
		rid: n,
		owner: r,
		source: i,
		count: 0,
		options: [],
		players: [],
		flag: "",
		rest: a,
		follow: null,
		...o
	};
}
function G(e, t, n) {
	let r = e.p[t], i = r.champions.findIndex((e) => e.uid === n);
	if (i < 0) return;
	let [a] = r.champions.splice(i, 1);
	r.discard.push({
		uid: a.uid,
		id: a.id
	}), V(e, "stun", t, a.id, 0, t);
}
function K(e, t) {
	let n = [];
	for (let r of e.players) {
		let i = e.p[r];
		if (i.defeated || r === t) continue;
		let a = U(i);
		for (let e of i.champions) (r === t || !a || E[e.id]?.guard) && n.push({
			rid: r,
			uid: e.uid
		});
	}
	return n;
}
function de(e, t, n) {
	for (let r of e.players) {
		if (r === t) continue;
		let i = e.p[r], a = i.champions.find((e) => e.uid === n);
		if (a) return U(i) && !E[a.id]?.guard ? null : r;
	}
	return null;
}
function q(e, t, n, r) {
	let i = e.p[t];
	for (n = [...n]; n.length;) {
		let a = n.shift();
		if (a.op === "gold") i.gold += a.n;
		else if (a.op === "combat") i.combat += a.n;
		else if (a.op === "health") i.health += a.n;
		else if (a.op === "draw") H(e, t, a.n);
		else if (a.op === "combatPerChampion") {
			let e = i.champions.some((e) => e.uid === r);
			i.combat += a.per * Math.max(0, ie(i) - +!!e);
		} else if (a.op === "combatPerGuard") {
			let e = +!!E[i.champions.find((e) => e.uid === r)?.id ?? ""]?.guard;
			i.combat += a.per * Math.max(0, ae(i) - e);
		} else if (a.op === "combatPerWild") {
			let e = i.play.find((e) => e.uid === r)?.id ?? i.champions.find((e) => e.uid === r)?.id ?? "", t = [...i.play, ...i.champions.map((e) => ({
				uid: e.uid,
				id: e.id
			}))].filter((e) => O(e.id) === "wild").length - +(O(e) === "wild");
			i.combat += a.per * Math.max(0, t);
		} else if (a.op === "healthPerChampion") i.health += a.per * ie(i);
		else if (a.op === "acquireTop") e.acquireTop += 1;
		else if (a.op === "acquireTopAction") e.acquireTopAction += 1;
		else if (a.op === "mayPickTopFromDiscard") {
			if (!i.discard.length) continue;
			W(e, "yesno", t, t, "", n.slice(), { follow: [{ op: "pickTopFromDiscard" }] });
			return;
		} else if (a.op === "acquireHand") e.acquireHand += 1;
		else if (a.op === "oppDiscard") {
			let n = R(e).filter((n) => n !== t && e.p[n].hand.length > 0);
			if (!n.length) continue;
			if (n.length === 1) {
				W(e, "oppDiscard", n[0], t, "", []);
				return;
			}
			W(e, "targetPlayer", t, t, "", [{ op: "oppDiscard" }], { players: n });
			return;
		} else if (a.op === "stun") {
			let r = K(e, t);
			if (!r.length) continue;
			if (r.length === 1) {
				G(e, r[0].rid, r[0].uid);
				continue;
			}
			W(e, "stun", t, t, "", n.slice());
			return;
		} else if (a.op === "mayStun") {
			if (!K(e, t).length) continue;
			W(e, "yesno", t, t, "", n.slice(), { follow: [{ op: "stun" }] });
			return;
		} else if (a.op === "sacrifice" || a.op === "sacrificeFor") {
			if (!(i.hand.length + i.discard.length > 0)) continue;
			let r = a.op === "sacrificeFor" ? [{
				op: "combat",
				n: a.combat
			}] : null;
			W(e, "sacrifice", t, t, "", n.slice(), {
				count: a.count ?? 1,
				follow: r
			});
			return;
		} else if (a.op === "drawThenDiscard") {
			H(e, t, a.n);
			let r = Math.min(a.n, i.hand.length);
			if (!r) continue;
			W(e, "discardSelf", t, t, "", n.slice(), { count: r });
			return;
		} else if (a.op === "mayDrawThenDiscard") {
			W(e, "yesno", t, t, "", n.slice(), { follow: [{
				op: "drawThenDiscard",
				n: a.n
			}] });
			return;
		} else if (a.op === "pickTopFromDiscard") {
			if (!i.discard.length) continue;
			W(e, "pickTop", t, t, "", n.slice(), {
				count: 1,
				flag: "any"
			});
			return;
		} else if (a.op === "championFromDiscardToTop") {
			if (!i.discard.some((e) => E[e.id]?.kind === "champion")) continue;
			W(e, "pickTop", t, t, "", n.slice(), {
				count: 1,
				flag: "champion"
			});
			return;
		} else if (a.op === "prepareChampion") {
			let r = i.champions.filter((e) => e.expended);
			if (!r.length) continue;
			if (r.length === 1) {
				r[0].expended = !1;
				continue;
			}
			W(e, "prepare", t, t, "", n.slice());
			return;
		} else if (a.op === "choice") {
			W(e, "mode", t, t, "", n.slice(), {
				options: a.options.map((e) => e.label),
				choices: a.options
			});
			return;
		}
	}
}
var fe = new Set(Object.keys(se));
new Set(Object.keys(le));
function pe(e) {
	let t = L(e), n = e.p[t];
	n.turnNo += 1, n.gold = 0, n.combat = 0, n.allyUsed = [], n.play = [], oe(n), e.phase = "main", e.acquireTop = 0, e.acquireTopAction = 0, e.acquireHand = 0, V(e, "turn", t, null, n.turnNo);
}
function me(e, t) {
	let n = e.p[t];
	n.defeated || (n.defeated = !0, n.health = 0, e.eliminated.push(t), V(e, "defeat", t));
}
function he(e) {
	e.phase = "done", e.prompt = null;
}
function ge(e) {
	R(e).length <= 1 && he(e);
}
function _e(e) {
	for (let t = 1; t <= e.players.length; t++) {
		let n = (e.turnIndex + t) % e.players.length;
		if (!e.p[e.players[n]].defeated) return n;
	}
	return e.turnIndex;
}
function ve(e) {
	let t = L(e), n = e.p[t];
	n.gold = 0, n.combat = 0, n.discard.push(...n.play), n.play = [], n.discard.push(...n.hand), n.hand = [], oe(n);
	for (let t of e.players) for (let n of e.p[t].champions) n.dmg = 0;
	if (n.allyUsed = [], H(e, t, 5), e.acquireTop = 0, e.acquireTopAction = 0, e.acquireHand = 0, R(e).length <= 1) {
		he(e);
		return;
	}
	e.turnIndex = _e(e), pe(e);
}
function ye(e, t, n, r) {
	let i = e.p[t];
	i.gold -= r;
	let a = {
		uid: e.uid++,
		id: n
	};
	return e.acquireTop > 0 ? (e.acquireTop--, i.deck.push(a)) : e.acquireTopAction > 0 && E[n]?.kind === "action" ? (e.acquireTopAction--, i.deck.push(a)) : e.acquireHand > 0 ? (e.acquireHand--, i.hand.push(a)) : i.discard.push(a), a;
}
function be(e, t, n) {
	let r = [];
	for (let [e, t] of D) for (let n = 0; n < t; n++) r.push(e);
	let i = {
		seed: n,
		cursor: 1,
		uid: 1,
		players: t,
		p: {},
		market: [],
		marketDeck: [],
		fireGems: 16,
		sacrifice: [],
		turnIndex: 0,
		phase: "main",
		prompt: null,
		events: [],
		seq: 1,
		beat: !1,
		eliminated: [],
		acquireTop: 0,
		acquireTopAction: 0,
		acquireHand: 0
	};
	i.marketDeck = B(i, r);
	for (let e = 0; e < 5; e++) i.market.push(i.marketDeck.pop() ?? null);
	for (let e = 0; e < t.length; e++) {
		let n = t[e], r = z(i, te.map((e) => ({
			uid: i.uid++,
			id: e
		})));
		i.p[n] = {
			health: 50,
			deck: r,
			hand: [],
			discard: [],
			play: [],
			champions: [],
			allyUsed: [],
			gold: 0,
			combat: 0,
			turnNo: 0,
			defeated: !1
		}, H(i, n, t.length === 2 ? e === 0 ? 3 : 5 : e === 0 ? 3 : e === 1 ? 4 : 5);
	}
	return pe(i), { state: i };
}
function xe(e, t, n) {
	let r = e.p[t], i = r.hand.findIndex((e) => e.uid === n);
	if (i < 0) return !1;
	let [a] = r.hand.splice(i, 1);
	return r.discard.push(a), V(e, "discard", t, a.id), !0;
}
function Se(e, t, n) {
	n.id === "fireGem" ? (e.fireGems += 1, V(e, "sacrifice", t, n.id)) : (e.sacrifice.push(n.id), V(e, "sacrifice", t, n.id));
}
function Ce(e, t, n) {
	let r = e.prompt;
	if (r.rid !== n) return I;
	let i = e.p[n];
	if (t.type === "chooseOption") {
		if (r.kind === "mode") {
			let n = r.choices?.[t.index];
			if (!n) return I;
			let i = r.rest;
			return e.prompt = null, q(e, r.owner, [...n.ops, ...i], -1), { state: e };
		}
		if (r.kind === "targetPlayer") {
			let n = r.players[t.index];
			if (!n) return I;
			let i = r.rest;
			return e.prompt = null, W(e, "oppDiscard", n, r.owner, "", i), { state: e };
		}
		return I;
	}
	if (t.type === "answer") {
		if (r.kind !== "yesno" && r.kind !== "sacrifice") return I;
		let n = r.rest, i = r.kind === "yesno" ? r.follow : null;
		return e.prompt = null, t.yes && i ? q(e, r.owner, [...i, ...n], -1) : q(e, r.owner, n, -1), { state: e };
	}
	if (t.type !== "chooseCard") return I;
	if (r.kind === "stun") {
		let n = K(e, r.owner).find((e) => e.uid === t.uid);
		if (!n) return I;
		let i = r.rest;
		return e.prompt = null, G(e, n.rid, n.uid), q(e, r.owner, i, -1), { state: e };
	}
	if (r.kind === "prepare") {
		let n = i.champions.find((e) => e.uid === t.uid && e.expended);
		if (!n) return I;
		let a = r.rest;
		return e.prompt = null, n.expended = !1, q(e, r.owner, a, -1), { state: e };
	}
	if (r.kind === "sacrifice") {
		let a, o = null, s = i.hand.findIndex((e) => e.uid === t.uid);
		if (s >= 0) a = i.hand.splice(s, 1)[0], o = "hand";
		else {
			let e = i.discard.findIndex((e) => e.uid === t.uid);
			e >= 0 && (a = i.discard.splice(e, 1)[0], o = "discard");
		}
		if (!a || !o) return I;
		let c = r.rest, l = r.follow;
		if (e.prompt = null, Se(e, n, a), l) q(e, r.owner, [...l, ...c], -1);
		else if (r.count > 1 && i.hand.length + i.discard.length > 0) return W(e, "sacrifice", n, r.owner, "", c, { count: r.count - 1 }), { state: e };
		else q(e, r.owner, c, -1);
		return { state: e };
	}
	if (r.kind === "discardSelf") {
		if (!xe(e, n, t.uid)) return I;
		let a = r.rest;
		return e.prompt = null, r.count > 1 && i.hand.length ? (W(e, "discardSelf", n, r.owner, "", a, { count: r.count - 1 }), { state: e }) : (q(e, r.owner, a, -1), { state: e });
	}
	if (r.kind === "oppDiscard") {
		if (!xe(e, n, t.uid)) return I;
		let i = r.rest;
		return e.prompt = null, q(e, r.owner, i, -1), { state: e };
	}
	if (r.kind === "pickTop") {
		let a = i.discard.findIndex((e) => e.uid === t.uid && (r.flag !== "champion" || E[e.id]?.kind === "champion"));
		if (a < 0) return I;
		let [o] = i.discard.splice(a, 1);
		i.deck.push(o), V(e, "toDeck", n, o.id);
		let s = r.rest;
		return e.prompt = null, q(e, r.owner, s, -1), { state: e };
	}
	return I;
}
function we(e, t, n) {
	let r = structuredClone(e), i = n.by;
	if (t.type === "tick") return r.beat = !1, { state: r };
	if (!r.p[i] || r.phase === "done") return I;
	if (r.prompt) return Ce(r, t, i);
	if (i !== L(r)) return I;
	let a = r.p[i], o = [];
	if (t.type === "play") {
		if (r.phase !== "main") return I;
		let e = a.hand.findIndex((e) => e.uid === t.uid);
		if (e < 0) return I;
		let [n] = a.hand.splice(e, 1), s = E[n.id];
		if (!s) return I;
		s.kind === "champion" ? (a.champions.push({
			uid: n.uid,
			id: n.id,
			dmg: 0,
			expended: !1
		}), V(r, "play", i, n.id)) : (a.play.push(n), V(r, "play", i, n.id)), o.push({
			kind: "hrMove",
			rid: i,
			data: {
				from: `hand:${i}:${n.uid}`,
				to: s.kind === "champion" ? `champ:${i}` : `play:${i}`,
				card: n.id
			}
		}), s.kind !== "champion" && q(r, i, ue[n.id] ?? [], n.uid);
	} else if (t.type === "ally") {
		if (r.phase !== "main") return I;
		let e = [...a.play, ...a.champions.map((e) => ({
			uid: e.uid,
			id: e.id
		}))].find((e) => e.uid === t.uid);
		if (!e) return I;
		let n = se[e.id];
		if (!n || !n.length || a.allyUsed.includes(e.uid)) return I;
		let o = O(e.id);
		if (o === "none" || [...a.play, ...a.champions].filter((e) => O(e.id) === o).length < 2) return I;
		a.allyUsed.push(e.uid), V(r, "ally", i, e.id), q(r, i, n, e.uid);
	} else if (t.type === "expend") {
		if (r.phase !== "main") return I;
		let e = a.champions.find((e) => e.uid === t.uid);
		if (!e || e.expended) return I;
		e.expended = !0, V(r, "expend", i, e.id), o.push({
			kind: "hrExpend",
			rid: i,
			data: { uid: e.uid }
		}), q(r, i, ce[e.id] ?? [], e.uid);
	} else if (t.type === "sacrifice") {
		if (r.phase !== "main") return I;
		let e = null, n = a.play.findIndex((e) => e.uid === t.uid);
		if (n >= 0) e = a.play.splice(n, 1)[0];
		else {
			let n = a.champions.findIndex((e) => e.uid === t.uid);
			if (n >= 0) {
				let t = a.champions.splice(n, 1)[0];
				e = {
					uid: t.uid,
					id: t.id
				};
			}
		}
		if (!e) return I;
		let s = le[e.id];
		if (!s) return I;
		Se(r, i, e), o.push({
			kind: "hrMove",
			rid: i,
			data: {
				from: `play:${i}`,
				to: "sacrifice",
				card: e.id
			}
		}), q(r, i, s, e.uid);
	} else if (t.type === "buy") {
		if (r.phase !== "main") return I;
		let e = r.market[t.index];
		if (!e) return I;
		let n = E[e]?.cost ?? 0;
		if (a.gold < n) return I;
		r.market[t.index] = r.marketDeck.pop() ?? null;
		let s = ye(r, i, e, n);
		V(r, "buy", i, e), o.push({
			kind: "hrMove",
			rid: i,
			data: {
				from: `market:${t.index}`,
				to: `discard:${i}`,
				card: e,
				uid: s.uid
			}
		});
	} else if (t.type === "buyGem") {
		if (r.phase !== "main" || r.fireGems < 1 || a.gold < 2) return I;
		--r.fireGems;
		let e = ye(r, i, "fireGem", 2);
		V(r, "buy", i, "fireGem"), o.push({
			kind: "hrMove",
			rid: i,
			data: {
				from: "gems",
				to: `discard:${i}`,
				card: "fireGem",
				uid: e.uid
			}
		});
	} else if (t.type === "attackPlayer") {
		if (r.phase !== "main") return I;
		let e = r.p[t.target];
		if (!e || t.target === i || e.defeated || U(e) || a.combat < t.n) return I;
		a.combat -= t.n, e.health -= t.n, V(r, "attack", i, null, t.n, t.target), o.push({
			kind: "hrHit",
			rid: i,
			data: {
				target: t.target,
				n: t.n
			}
		}), e.health <= 0 && me(r, t.target), ge(r);
	} else if (t.type === "attackChampion") {
		if (r.phase !== "main") return I;
		let e = de(r, i, t.uid);
		if (!e || a.combat < t.n) return I;
		let n = r.p[e].champions.find((e) => e.uid === t.uid);
		a.combat -= t.n, n.dmg += t.n, V(r, "attackChampion", i, n.id, t.n, e), o.push({
			kind: "hrHit",
			rid: i,
			data: {
				target: e,
				uid: t.uid,
				n: t.n
			}
		}), n.dmg >= (E[n.id]?.defense ?? 0) && G(r, e, n.uid), ge(r);
	} else if (t.type === "endTurn") {
		if (r.phase !== "main") return I;
		ve(r), o.push({
			kind: "hrEndTurn",
			rid: i,
			data: { next: L(r) }
		});
	} else return I;
	return r.beat = o.length > 0, {
		state: r,
		fx: o
	};
}
function Te(e, t, n) {
	let r = e.p[n];
	return r ? t.kind === "sacrifice" ? [...r.hand.map((e) => ({
		uid: e.uid,
		id: e.id,
		from: "hand"
	})), ...r.discard.map((e) => ({
		uid: e.uid,
		id: e.id,
		from: "discard"
	}))] : t.kind === "discardSelf" || t.kind === "oppDiscard" ? r.hand.map((e) => ({
		uid: e.uid,
		id: e.id,
		from: "hand"
	})) : t.kind === "pickTop" ? r.discard.filter((e) => t.flag !== "champion" || E[e.id]?.kind === "champion").map((e) => ({
		uid: e.uid,
		id: e.id,
		from: "discard"
	})) : t.kind === "stun" ? K(e, t.owner).map((t) => ({
		uid: t.uid,
		id: e.p[t.rid].champions.find((e) => e.uid === t.uid)?.id ?? "",
		from: "champion"
	})) : t.kind === "prepare" ? r.champions.filter((e) => e.expended).map((e) => ({
		uid: e.uid,
		id: e.id,
		from: "champion"
	})) : [] : [];
}
var Ee = {
	meta: ne,
	saveCompatibility: { version: "1" },
	schemas: {
		action: j,
		publicView: re,
		privateView: F,
		config: k
	},
	setup: be,
	reduce: we,
	viewFor(e, t) {
		let n = e.prompt, r = e.p[t];
		return {
			public: {
				phase: e.phase,
				active: L(e),
				turnNo: r?.turnNo ?? 0,
				busy: e.beat,
				market: [...e.market],
				marketDeck: e.marketDeck.length,
				fireGems: e.fireGems,
				sacrifice: [...e.sacrifice],
				players: e.players.map((t) => {
					let n = e.p[t];
					return {
						rid: t,
						health: n.health,
						hand: n.hand.length,
						deck: n.deck.length,
						discard: n.discard.length,
						gold: n.gold,
						combat: n.combat,
						play: n.play.map((e) => ({
							uid: e.uid,
							id: e.id
						})),
						champions: n.champions.map((e) => ({
							uid: e.uid,
							id: e.id,
							dmg: e.dmg,
							expended: e.expended
						})),
						allyUsed: [...n.allyUsed],
						defeated: n.defeated
					};
				}),
				prompt: n ? {
					kind: n.kind,
					rid: n.rid,
					source: n.source,
					count: n.count,
					options: n.options,
					players: n.players,
					flag: n.flag
				} : null,
				events: [...e.events]
			},
			private: {
				hand: structuredClone(r?.hand ?? []),
				discard: structuredClone(r?.discard ?? []),
				candidates: n && r ? Te(e, n, t) : [],
				canAnswer: !!n && n.rid === t && (n.kind === "yesno" || n.kind === "sacrifice")
			}
		};
	},
	nextTickIn(e) {
		return e.beat ? 420 : null;
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = R(e);
		return {
			phase: "done",
			winner: t,
			ranking: [...t, ...[...e.eliminated].reverse()],
			scores: Object.fromEntries(e.players.map((t) => [t, e.p[t].health]))
		};
	}
};
//#endregion
//#region src/game/card.tsx
function J({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = y(e);
	return /* @__PURE__ */ x("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function De() {
	return /* @__PURE__ */ x("div", {
		className: "hr-card hr-card-back",
		"aria-hidden": "true",
		children: /* @__PURE__ */ S("svg", {
			viewBox: "0 0 100 150",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ x("rect", {
					x: "4",
					y: "4",
					width: "92",
					height: "142",
					rx: "4",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.2",
					opacity: ".55"
				}),
				/* @__PURE__ */ x("path", {
					d: "M50 26 L64 52 L58 52 L58 96 L42 96 L42 52 L36 52 Z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ x("path", {
					d: "M30 96 L70 96",
					stroke: "currentColor",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ x("circle", {
					cx: "50",
					cy: "70",
					r: "24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: ".8",
					opacity: ".45"
				})
			]
		})
	});
}
function Y({ id: e }) {
	let t = o("herorealms");
	if (e === null) return /* @__PURE__ */ x(De, {});
	let n = E[e];
	return /* @__PURE__ */ S("div", {
		className: "hr-card",
		"data-faction": n?.faction ?? "none",
		"data-kind": n?.kind ?? "action",
		children: [
			/* @__PURE__ */ S("div", {
				className: "hr-card-frame",
				children: [
					/* @__PURE__ */ x("div", {
						className: "hr-card-nameplate",
						children: /* @__PURE__ */ x("strong", {
							className: "hr-card-name",
							children: t(`cards.${e}.name`)
						})
					}),
					/* @__PURE__ */ x("div", {
						className: "hr-card-art",
						children: /* @__PURE__ */ x("img", {
							src: v(`games/herorealms/art/${e}.webp`),
							alt: "",
							draggable: !1,
							loading: "lazy"
						})
					}),
					/* @__PURE__ */ x("p", {
						className: "hr-card-text",
						children: t(`cards.${e}.text`)
					}),
					/* @__PURE__ */ S("div", {
						className: "hr-card-foot",
						children: [/* @__PURE__ */ x("span", {
							className: "hr-faction",
							children: t(`faction.${n?.faction ?? "none"}`)
						}), n?.guard && /* @__PURE__ */ x("span", {
							className: "hr-guard",
							children: t("guard")
						})]
					})
				]
			}),
			n && n.cost > 0 ? /* @__PURE__ */ x("span", {
				className: "hr-cost",
				"aria-hidden": "true",
				children: n.cost
			}) : null,
			n?.defense ? /* @__PURE__ */ x("span", {
				className: "hr-def",
				"aria-label": `${t("defense")} ${n.defense}`,
				children: n.defense
			}) : null
		]
	});
}
function X({ id: e, count: t, onClick: n, inspect: r, legal: i = !1, selected: a = !1, dead: s = !1, anchor: c, action: l }) {
	let u = o("herorealms"), { ref: d, hidden: f } = y(c ?? null), p = u(`cards.${e}.name`);
	return /* @__PURE__ */ S("div", {
		className: "hr-card-item",
		ref: d,
		"data-selected": a,
		"data-dead": s,
		children: [
			/* @__PURE__ */ S("button", {
				className: "hr-card-hit",
				onClick: n ?? r,
				"aria-label": l ? `${l} ${p}` : p,
				"aria-pressed": a,
				style: { visibility: f ? "hidden" : void 0 },
				children: [/* @__PURE__ */ x(Y, { id: e }), i && /* @__PURE__ */ x(b, {
					radius: 7,
					flash: !1
				})]
			}),
			t !== void 0 && /* @__PURE__ */ S("span", {
				className: "hr-count",
				children: ["×", t]
			}),
			/* @__PURE__ */ x("button", {
				className: "hr-inspect",
				onClick: r,
				"aria-label": u("inspect", { card: p }),
				children: "i"
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
function Oe(e) {
	g();
	let t = e.public, n = e.private;
	return /* @__PURE__ */ x(ke, {
		...e,
		pub: t,
		priv: n ?? {
			hand: [],
			discard: [],
			candidates: [],
			canAnswer: !1
		}
	});
}
function ke({ pub: e, priv: t, myRid: u, members: g, send: v }) {
	let y = o("herorealms"), b = s((e) => e.locale), ee = c(), [C, w] = n({
		seat: u,
		detail: null,
		history: !1,
		pile: null
	}), T = C.seat === u ? C : {
		seat: u,
		detail: null,
		history: !1,
		pile: null
	}, D = T.detail, te = T.history, ne = T.pile, k = (e) => w((t) => t.seat === u ? {
		...t,
		...e
	} : {
		seat: u,
		detail: null,
		history: !1,
		pile: null,
		...e
	}), A = (e) => k({ detail: e }), j = (e) => k({ history: e }), M = (e) => k({ pile: e }), N = (t) => {
		let n = g.find((e) => e.rid === t);
		if (n) return /^(?:Player|玩家)\s*\d+$/i.test(n.name) ? a(b, n.avatar) : h(n, b);
		let r = Math.max(0, e.players.findIndex((e) => e.rid === t));
		return ee(_[r % _.length].nameKey);
	}, P = e.players.find((e) => e.rid === u), re = e.players.filter((e) => e.rid !== u), F = e.prompt, I = e.active === u && !e.busy && e.phase !== "done", L = I && !F, R = P?.gold ?? 0, z = P?.combat ?? 0, B = (t) => {
		let n = e.market[t];
		return !!n && L && R >= (E[n]?.cost ?? 0);
	}, V = (e) => e.champions.some((e) => E[e.id]?.guard && !e.expended), H = (e, t) => e.champions.filter((e) => O(e.id) === t).length + e.play.filter((e) => O(e.id) === t).length, ie = (e, t, n, r) => {
		if (!L || V(e) && !E[n]?.guard) {
			A(n);
			return;
		}
		let i = (E[n]?.defense ?? 0) - r, a = Math.min(z, Math.max(0, i));
		if (a <= 0) {
			A(n);
			return;
		}
		v({
			type: "attackChampion",
			uid: t,
			n: a
		});
	}, ae = (e) => {
		!L || V(e) || z <= 0 || v({
			type: "attackPlayer",
			target: e.rid,
			n: z
		});
	}, U = e.phase === "done" ? y("done") : e.busy ? y("resolving") : F ? F.rid === u ? y("choose") : y("waitingOther", { name: N(F.rid) }) : I ? y("yourTurn") : y("waiting", { name: N(e.active) });
	return /* @__PURE__ */ S(m, {
		scroll: !1,
		className: "hr-screen",
		actionsHeight: "hr-actions-height",
		banner: /* @__PURE__ */ S("div", {
			className: "hr-banner",
			children: [/* @__PURE__ */ x(f, {
				tone: e.phase === "done" ? "done" : I ? "accent" : "info",
				accent: "#c9a227",
				text: U,
				chip: y("turn", { n: e.turnNo })
			}), /* @__PURE__ */ S("div", {
				className: "hr-banner-row",
				children: [/* @__PURE__ */ x(p, {
					variant: "mini",
					scroll: !0,
					members: g,
					myRid: u,
					anchorOf: (e) => `seat:${e}`,
					action: (t) => e.phase !== "done" && t === e.active ? "pending" : null,
					status: (t) => /* @__PURE__ */ S("span", { children: [
						y("health"),
						" ",
						e.players.find((e) => e.rid === t)?.health ?? 0
					] })
				}), /* @__PURE__ */ x("button", {
					className: "hr-icon-btn",
					onClick: () => j(!0),
					"aria-label": y("history"),
					children: /* @__PURE__ */ x(l, { size: 20 })
				})]
			})]
		}),
		overlay: /* @__PURE__ */ x(Ne, {
			pub: e,
			priv: t,
			myRid: u,
			send: v,
			inspect: A,
			name: N
		}),
		actions: /* @__PURE__ */ x(Pe, {
			pub: e,
			send: v,
			ready: L
		}),
		children: [/* @__PURE__ */ x("div", {
			className: "hr-table",
			children: /* @__PURE__ */ S("div", {
				className: "hr-table-content",
				children: [
					/* @__PURE__ */ x("section", {
						className: "hr-opponents",
						children: re.map((t) => /* @__PURE__ */ S("div", {
							className: "hr-opp",
							"data-defeated": t.defeated,
							"data-active": t.rid === e.active,
							children: [
								/* @__PURE__ */ S("button", {
									className: "hr-opp-head",
									onClick: () => ae(t),
									"aria-label": y("attackPlayer", { name: N(t.rid) }),
									children: [
										/* @__PURE__ */ x("span", {
											className: "hr-opp-name",
											children: N(t.rid)
										}),
										/* @__PURE__ */ x("span", {
											className: "hr-opp-seal",
											"aria-hidden": "true",
											children: t.health
										}),
										V(t) && /* @__PURE__ */ x("span", {
											className: "hr-guard-tag",
											children: y("guard")
										})
									]
								}),
								/* @__PURE__ */ S(J, {
									name: `champ:${t.rid}`,
									className: "hr-opp-champs",
									children: [t.champions.map((e) => /* @__PURE__ */ x(X, {
										id: e.id,
										anchor: `champ:${t.rid}:${e.uid}`,
										dead: e.expended,
										legal: L && z > 0 && (!V(t) || !!E[e.id]?.guard),
										action: L && z > 0 && (!V(t) || E[e.id]?.guard) ? y("attack") : y("view"),
										onClick: () => ie(t, e.uid, e.id, e.dmg),
										inspect: () => A(e.id)
									}, e.uid)), !t.champions.length && /* @__PURE__ */ x("span", {
										className: "hr-empty",
										children: y("empty")
									})]
								}),
								/* @__PURE__ */ S("div", {
									className: "hr-opp-foot",
									children: [
										/* @__PURE__ */ S("span", {
											className: "hr-counter",
											children: [
												/* @__PURE__ */ x("i", {
													className: "hr-ico hr-ico-hand",
													"aria-hidden": "true"
												}),
												y("hand"),
												" ",
												t.hand
											]
										}),
										/* @__PURE__ */ S("span", {
											className: "hr-counter",
											children: [
												/* @__PURE__ */ x("i", {
													className: "hr-ico hr-ico-deck",
													"aria-hidden": "true"
												}),
												y("deck"),
												" ",
												t.deck
											]
										}),
										/* @__PURE__ */ S(J, {
											name: `discard:${t.rid}`,
											className: "hr-opp-stat hr-counter",
											children: [
												/* @__PURE__ */ x("i", {
													className: "hr-ico hr-ico-discard",
													"aria-hidden": "true"
												}),
												y("discard"),
												" ",
												t.discard
											]
										})
									]
								})
							]
						}, t.rid))
					}),
					/* @__PURE__ */ S("div", {
						className: "hr-main",
						children: [/* @__PURE__ */ S("section", {
							className: "hr-market",
							children: [/* @__PURE__ */ S("div", {
								className: "hr-section-head",
								children: [/* @__PURE__ */ x("h2", { children: y("market") }), /* @__PURE__ */ S("span", {
									className: "hr-meta",
									children: [
										y("marketDeck"),
										" · ",
										e.marketDeck
									]
								})]
							}), /* @__PURE__ */ S("div", {
								className: "hr-market-row",
								children: [e.market.map((e, t) => e ? /* @__PURE__ */ x(X, {
									id: e,
									anchor: `market:${t}`,
									legal: B(t),
									action: B(t) ? y("buy") : y("view"),
									onClick: () => B(t) ? v({
										type: "buy",
										index: t
									}) : A(e),
									inspect: () => A(e)
								}, `${t}:${e}`) : /* @__PURE__ */ x("div", {
									className: "hr-slot-empty",
									children: /* @__PURE__ */ x("span", { children: y("marketEmpty") })
								}, `${t}:empty`)), /* @__PURE__ */ x("div", {
									className: "hr-gem",
									children: /* @__PURE__ */ x(X, {
										id: "fireGem",
										anchor: "gems",
										count: e.fireGems,
										legal: L && R >= 2,
										action: y(L && R >= 2 ? "buyGem" : "view"),
										onClick: () => L && R >= 2 ? v({ type: "buyGem" }) : A("fireGem"),
										inspect: () => A("fireGem")
									})
								})]
							})]
						}), /* @__PURE__ */ x("section", {
							className: "hr-battle-zone",
							children: /* @__PURE__ */ S("div", {
								className: "hr-battle",
								children: [
									/* @__PURE__ */ S("div", {
										className: "hr-zone hr-zone-champ",
										children: [/* @__PURE__ */ x("h3", { children: y("champions") }), /* @__PURE__ */ S(J, {
											name: `champ:${u}`,
											className: "hr-champ-row",
											children: [(P?.champions ?? []).map((e) => /* @__PURE__ */ S("div", {
												className: "hr-champ",
												"data-expended": e.expended,
												children: [/* @__PURE__ */ x(X, {
													id: e.id,
													anchor: `champ:${u}:${e.uid}`,
													dead: e.expended,
													action: L && !e.expended ? y("expend") : y("view"),
													onClick: () => L && !e.expended ? v({
														type: "expend",
														uid: e.uid
													}) : A(e.id),
													inspect: () => A(e.id)
												}), /* @__PURE__ */ S("div", {
													className: "hr-champ-btns",
													children: [
														e.dmg > 0 && /* @__PURE__ */ x("span", {
															className: "hr-dmg",
															children: e.dmg
														}),
														L && !e.expended && /* @__PURE__ */ x("button", {
															onClick: () => v({
																type: "expend",
																uid: e.uid
															}),
															children: y("expend")
														}),
														L && !(P?.allyUsed ?? []).includes(e.uid) && H(P, O(e.id)) >= 2 && O(e.id) !== "none" && /* @__PURE__ */ x("button", {
															onClick: () => v({
																type: "ally",
																uid: e.uid
															}),
															children: y("ally")
														})
													]
												})]
											}, e.uid)), !P?.champions.length && /* @__PURE__ */ x("span", {
												className: "hr-empty",
												children: y("empty")
											})]
										})]
									}),
									/* @__PURE__ */ x("div", {
										className: "hr-battle-seam",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ S("div", {
										className: "hr-zone hr-zone-play",
										children: [/* @__PURE__ */ x("h3", { children: y("playArea") }), /* @__PURE__ */ S(J, {
											name: `play:${u}`,
											className: "hr-play-row",
											children: [(P?.play ?? []).map((e) => /* @__PURE__ */ x(X, {
												id: e.id,
												anchor: `play:${u}:${e.uid}`,
												legal: L && !!Z[e.id],
												action: L && Z[e.id] ? y("sacrificeAction") : y("view"),
												onClick: () => L && Z[e.id] ? v({
													type: "sacrifice",
													uid: e.uid
												}) : A(e.id),
												inspect: () => A(e.id)
											}, e.uid)), !P?.play?.length && /* @__PURE__ */ x("span", {
												className: "hr-empty",
												children: y("empty")
											})]
										})]
									})
								]
							})
						})]
					}),
					/* @__PURE__ */ S("section", {
						className: "hr-mine",
						children: [/* @__PURE__ */ S(J, {
							name: "sacrifice",
							className: "hr-res",
							children: [
								/* @__PURE__ */ S("span", {
									className: "hr-res-gold",
									children: [
										/* @__PURE__ */ x("i", {
											className: "hr-ico hr-ico-gold",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ x("small", { children: y("gold") }),
										/* @__PURE__ */ x(d, { value: R })
									]
								}),
								/* @__PURE__ */ S("span", {
									className: "hr-res-combat",
									children: [
										/* @__PURE__ */ x("i", {
											className: "hr-ico hr-ico-combat",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ x("small", { children: y("combat") }),
										/* @__PURE__ */ x(d, { value: z })
									]
								}),
								/* @__PURE__ */ S("span", {
									className: "hr-res-health",
									children: [
										/* @__PURE__ */ x("i", {
											className: "hr-ico hr-ico-health",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ x("small", { children: y("health") }),
										/* @__PURE__ */ x("b", { children: P?.health ?? 0 })
									]
								}),
								/* @__PURE__ */ S(J, {
									name: `discard:${u}`,
									className: "hr-res-stat",
									children: [
										/* @__PURE__ */ x("i", {
											className: "hr-ico hr-ico-discard",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ x("small", { children: y("discard") }),
										/* @__PURE__ */ x("b", { children: P?.discard ?? 0 })
									]
								}),
								/* @__PURE__ */ S("button", {
									className: "hr-pile-btn",
									onClick: () => M("sacrifice"),
									children: [
										y("sacrifice"),
										" · ",
										e.sacrifice.length
									]
								})
							]
						}), /* @__PURE__ */ S("div", {
							className: "hr-zone hr-hand-zone",
							children: [/* @__PURE__ */ x("h3", { children: y("hand") }), /* @__PURE__ */ S(J, {
								name: `hand:${u}`,
								className: "hr-hand-row",
								children: [t.hand.map((e) => /* @__PURE__ */ x(X, {
									id: e.id,
									anchor: `hand:${u}:${e.uid}`,
									action: y(L ? "playCard" : "view"),
									onClick: () => L ? v({
										type: "play",
										uid: e.uid
									}) : A(e.id),
									inspect: () => A(e.id)
								}, e.uid)), !t.hand.length && /* @__PURE__ */ x("span", {
									className: "hr-empty",
									children: y("empty")
								})]
							})]
						})]
					})
				]
			})
		}), r(/* @__PURE__ */ S("div", {
			className: "hr-sheets",
			children: [
				/* @__PURE__ */ x(i, {
					open: D !== null,
					onClose: () => A(null),
					title: y("detail"),
					label: y("detail"),
					children: D !== null && /* @__PURE__ */ S("div", {
						className: "hr-detail",
						children: [/* @__PURE__ */ x(Y, { id: D }), /* @__PURE__ */ x(je, {
							id: D,
							pub: e,
							priv: t,
							myRid: u,
							ready: L,
							gold: R,
							send: v,
							close: () => A(null)
						})]
					})
				}),
				/* @__PURE__ */ x(i, {
					open: te,
					onClose: () => j(!1),
					title: y("history"),
					label: y("history"),
					children: /* @__PURE__ */ x("ol", {
						className: "hr-history",
						children: e.events.map((e) => /* @__PURE__ */ x("li", { children: Ae(y, e, N) }, e.seq))
					})
				}),
				/* @__PURE__ */ x(i, {
					open: ne !== null,
					onClose: () => M(null),
					title: y("sacrifice"),
					label: y("sacrifice"),
					children: /* @__PURE__ */ S("div", {
						className: "hr-pile-grid",
						children: [e.sacrifice.map((e, t) => /* @__PURE__ */ x(X, {
							id: e,
							inspect: () => A(e)
						}, `${e}:${t}`)), !e.sacrifice.length && /* @__PURE__ */ x("span", {
							className: "hr-empty",
							children: y("empty")
						})]
					})
				})
			]
		}), document.body)]
	});
}
var Z = {
	wordOfPower: !0,
	influence: !0,
	naturesBounty: !0,
	wolfForm: !0,
	fireBomb: !0
};
function Ae(e, t, n) {
	let r = e, i = t.card ? r(`cards.${t.card}.name`) : "";
	return r(`event.${t.kind}`, {
		name: n(t.rid),
		card: i,
		n: t.n,
		target: t.target ? n(t.target) : ""
	});
}
function je({ id: e, pub: t, priv: n, myRid: r, ready: i, gold: a, send: s, close: c }) {
	let l = o("herorealms"), u = t.players.find((e) => e.rid === r), d = n.hand.find((t) => t.id === e), f = u?.champions.find((t) => t.id === e), p = t.market.indexOf(e), m = E[e]?.cost ?? 0, h = [];
	return i && d && h.push({
		label: l("playCard"),
		run: () => s({
			type: "play",
			uid: d.uid
		})
	}), i && f && !f.expended && h.push({
		label: l("expend"),
		run: () => s({
			type: "expend",
			uid: f.uid
		})
	}), i && p >= 0 && a >= m && h.push({
		label: `${l("buy")} · ${m}`,
		run: () => s({
			type: "buy",
			index: p
		})
	}), i && e === "fireGem" && a >= 2 && h.push({
		label: `${l("buyGem")} · 2`,
		run: () => s({ type: "buyGem" })
	}), h.length ? /* @__PURE__ */ x("div", {
		className: "hr-detail-actions",
		children: h.map((e) => /* @__PURE__ */ x("button", {
			className: "hr-primary",
			onClick: () => {
				e.run(), c();
			},
			children: e.label
		}, e.label))
	}) : null;
}
function Me(e, t) {
	return t.kind === "discardSelf" ? e(t.count === 1 ? "prompt.discardSelfOne" : "prompt.discardSelfMany", { n: t.count }) : e(`prompt.${t.kind}`, { n: t.count });
}
function Ne({ pub: e, priv: t, myRid: n, send: r, inspect: i, name: a }) {
	let s = o("herorealms"), c = e.prompt;
	if (e.phase === "done" || !c || c.rid !== n) return null;
	let l = s;
	return /* @__PURE__ */ S("div", {
		className: "hr-prompt-tray",
		children: [
			/* @__PURE__ */ x("div", {
				className: "hr-prompt-title",
				children: Me(l, c)
			}),
			c.kind === "mode" && /* @__PURE__ */ x("div", {
				className: "hr-options",
				children: c.options.map((e, t) => /* @__PURE__ */ x("button", {
					className: "hr-primary",
					onClick: () => r({
						type: "chooseOption",
						index: t
					}),
					children: l(e)
				}, e))
			}),
			c.kind === "targetPlayer" && /* @__PURE__ */ x("div", {
				className: "hr-options",
				children: c.players.map((e, t) => /* @__PURE__ */ x("button", {
					className: "hr-primary",
					onClick: () => r({
						type: "chooseOption",
						index: t
					}),
					children: a(e)
				}, e))
			}),
			c.kind === "yesno" && /* @__PURE__ */ S("div", {
				className: "hr-options",
				children: [/* @__PURE__ */ x("button", {
					className: "hr-primary",
					onClick: () => r({
						type: "answer",
						yes: !0
					}),
					children: s("yes")
				}), /* @__PURE__ */ x("button", {
					className: "hr-secondary",
					onClick: () => r({
						type: "answer",
						yes: !1
					}),
					children: s("skip")
				})]
			}),
			c.kind === "sacrifice" && /* @__PURE__ */ x("div", {
				className: "hr-options",
				children: /* @__PURE__ */ x("button", {
					className: "hr-secondary",
					onClick: () => r({
						type: "answer",
						yes: !1
					}),
					children: s("skip")
				})
			}),
			(c.kind === "discardSelf" || c.kind === "oppDiscard" || c.kind === "sacrifice" || c.kind === "pickTop" || c.kind === "stun" || c.kind === "prepare") && /* @__PURE__ */ S("div", {
				className: "hr-cands",
				children: [t.candidates.map((e) => /* @__PURE__ */ x(X, {
					id: e.id,
					action: s("chooseCard"),
					onClick: () => r({
						type: "chooseCard",
						uid: e.uid
					}),
					inspect: () => i(e.id)
				}, e.uid)), !t.candidates.length && /* @__PURE__ */ x("span", {
					className: "hr-empty",
					children: s("empty")
				})]
			})
		]
	});
}
function Pe({ pub: e, send: t, ready: n }) {
	let r = o("herorealms");
	return e.phase === "done" ? /* @__PURE__ */ x("div", { className: "hr-actions" }) : /* @__PURE__ */ x("div", {
		className: "hr-actions",
		children: n && /* @__PURE__ */ x("button", {
			className: "hr-primary hr-end-turn",
			onClick: () => t({ type: "endTurn" }),
			children: r("endTurn")
		})
	});
}
//#endregion
//#region src/game/bot.ts
var Fe = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.rid, a = n.players.find((e) => e.rid === i);
	if (!a || a.defeated || n.phase === "done") return null;
	let o = n.players.filter((e) => e.rid !== i && !e.defeated), s = (e) => n.players.find((t) => t.champions.some((t) => t.uid === e)), c = (e) => e.champions.some((e) => E[e.id]?.guard && !e.expended), l = n.prompt;
	if (l) {
		if (l.rid !== i) return null;
		if (l.kind === "mode") {
			let e = l.options.findIndex((e) => e.includes("combat"));
			return { action: {
				type: "chooseOption",
				index: e >= 0 ? e : 0
			} };
		}
		if (l.kind === "targetPlayer") {
			let e = l.players.map((e) => n.players.find((t) => t.rid === e)).sort((e, t) => e.health - t.health);
			return { action: {
				type: "chooseOption",
				index: l.players.indexOf(e[0].rid)
			} };
		}
		if (l.kind === "yesno") return { action: {
			type: "answer",
			yes: !0
		} };
		if (l.kind === "sacrifice") {
			let e = [...r.candidates].sort((e, t) => (E[e.id]?.cost ?? 0) - (E[t.id]?.cost ?? 0))[0];
			return !e || (E[e.id]?.cost ?? 0) > 1 ? { action: {
				type: "answer",
				yes: !1
			} } : { action: {
				type: "chooseCard",
				uid: e.uid
			} };
		}
		if (l.kind === "discardSelf" || l.kind === "oppDiscard") {
			let e = [...r.candidates].sort((e, t) => (E[e.id]?.cost ?? 0) - (E[t.id]?.cost ?? 0));
			return e[0] ? { action: {
				type: "chooseCard",
				uid: e[0].uid
			} } : null;
		}
		if (l.kind === "pickTop") {
			let e = [...r.candidates].sort((e, t) => (E[t.id]?.cost ?? 0) - (E[e.id]?.cost ?? 0));
			return e[0] ? { action: {
				type: "chooseCard",
				uid: e[0].uid
			} } : null;
		}
		if (l.kind === "stun") {
			let e = r.candidates.filter((e) => s(e.uid)?.rid !== i).sort((e, t) => (E[t.id]?.defense ?? 0) - (E[e.id]?.defense ?? 0))[0];
			return e ? { action: {
				type: "chooseCard",
				uid: e.uid
			} } : null;
		}
		return l.kind === "prepare" && r.candidates[0] ? { action: {
			type: "chooseCard",
			uid: r.candidates[0].uid
		} } : null;
	}
	if (n.active !== i || n.busy) return null;
	if (r.hand.length) return { action: {
		type: "play",
		uid: r.hand[0].uid
	} };
	let u = a.champions.find((e) => !e.expended);
	if (u) return { action: {
		type: "expend",
		uid: u.uid
	} };
	let d = [...a.champions.map((e) => ({
		uid: e.uid,
		id: e.id
	})), ...a.play.map((e) => ({
		uid: e.uid,
		id: e.id
	}))], f = d.find((e) => fe.has(e.id) && !a.allyUsed.includes(e.uid) && O(e.id) !== "none" && d.filter((t) => O(t.id) === O(e.id)).length >= 2);
	if (f) return { action: {
		type: "ally",
		uid: f.uid
	} };
	if (a.gold > 0) {
		let e = -1, t = -1;
		if (n.market.forEach((n, r) => {
			if (!n) return;
			let i = E[n]?.cost ?? 0;
			i > a.gold || (i > t || i === t && E[n]?.kind === "champion") && (e = r, t = i);
		}), e >= 0) return { action: {
			type: "buy",
			index: e
		} };
		if (a.gold >= 2 && n.fireGems > 0) return { action: { type: "buyGem" } };
	}
	if (a.combat > 0) {
		for (let e of o) {
			let t = c(e);
			for (let n of e.champions) {
				if (t && !E[n.id]?.guard) continue;
				let e = (E[n.id]?.defense ?? 0) - n.dmg;
				if (e > 0 && e <= a.combat) return { action: {
					type: "attackChampion",
					uid: n.uid,
					n: e
				} };
			}
		}
		let e = o.find((e) => !c(e));
		if (e) return { action: {
			type: "attackPlayer",
			target: e.rid,
			n: a.combat
		} };
	}
	return { action: { type: "endTurn" } };
}, Q = 66, $ = 99, Ie = {
	hrMove(e, t) {
		let n = e.data;
		if (!n || !n.card) return {
			ms: 0,
			node: null
		};
		let r = t.anchor(n.from), i = t.anchor(n.to);
		if (!r || !i) return {
			ms: 0,
			node: null
		};
		let a = t.queued > 0 ? 150 : 360;
		return {
			ms: a,
			node: /* @__PURE__ */ x(ee, {
				from: {
					x: r.x + r.w / 2 - Q / 2,
					y: r.y + r.h / 2 - $ / 2,
					w: Q,
					h: $
				},
				to: {
					x: i.x + i.w / 2 - Q / 2,
					y: i.y + i.h / 2 - $ / 2,
					w: Q,
					h: $
				},
				ms: a,
				children: /* @__PURE__ */ x("div", {
					className: "hr-screen hr-flyer",
					children: /* @__PURE__ */ x(Y, { id: n.card })
				})
			})
		};
	},
	hrHit() {
		return {
			ms: 260,
			node: null
		};
	},
	hrExpend() {
		return {
			ms: 0,
			node: null
		};
	},
	hrEndTurn() {
		return {
			ms: 0,
			node: null
		};
	}
};
//#endregion
//#region src/game/game-over.tsx
function Le(e) {
	let t = o("herorealms"), n = s((e) => e.locale), r = c(), i = e.public, l = (t) => e.members.find((e) => e.rid === t)?.colorIndex ?? Math.max(0, i.players.findIndex((e) => e.rid === t)), d = (e) => _[l(e) % _.length].hex, f = (t) => {
		let i = e.members.find((e) => e.rid === t);
		return i ? /^(?:Player|玩家)\s*\d+$/i.test(i.name) ? a(n, i.avatar) : h(i, n) : r(_[l(t) % _.length].nameKey);
	}, p = e.result.ranking ?? i.players.map((e) => e.rid), m = e.result.scores ?? {}, g = (e) => i.players.find((t) => t.rid === e)?.health ?? m[e] ?? 0;
	return /* @__PURE__ */ S("div", {
		className: "hr-end",
		children: [/* @__PURE__ */ x("div", {
			className: "hr-end-board",
			inert: !0,
			children: /* @__PURE__ */ x(Oe, {
				public: e.public,
				private: e.private,
				members: e.members,
				myRid: e.myRid,
				send: () => {}
			})
		}), /* @__PURE__ */ x("div", {
			className: "hr-end-overlay",
			children: /* @__PURE__ */ S("section", {
				className: "hr-end-panel",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": t("result"),
				children: [
					/* @__PURE__ */ x(C, {}),
					/* @__PURE__ */ x("span", {
						className: "hr-end-seal",
						"aria-hidden": "true",
						children: t("result")
					}),
					/* @__PURE__ */ S("h1", {
						className: "hr-end-winner",
						children: [
							t("winner"),
							" · ",
							f(p[0])
						]
					}),
					/* @__PURE__ */ x("ol", {
						className: "hr-end-list",
						children: p.map((e, n) => /* @__PURE__ */ S("li", {
							"data-first": n === 0,
							children: [
								/* @__PURE__ */ x("span", {
									className: "hr-end-ribbon",
									style: { background: d(e) },
									"aria-hidden": !0
								}),
								/* @__PURE__ */ x("span", {
									className: "hr-end-place",
									children: t("place", { n: n + 1 })
								}),
								/* @__PURE__ */ x("span", {
									className: "hr-end-avatar",
									style: { background: d(e) },
									"aria-hidden": !0,
									children: /* @__PURE__ */ x(u, { size: 13 })
								}),
								/* @__PURE__ */ x("span", {
									className: "hr-end-name",
									children: f(e)
								}),
								/* @__PURE__ */ x("span", {
									className: "hr-end-health",
									children: t("healthLeft", { n: Math.max(0, g(e)) })
								})
							]
						}, e))
					}),
					/* @__PURE__ */ S("div", {
						className: "hr-end-actions",
						children: [e.onPlayAgain && /* @__PURE__ */ x("button", {
							className: "hr-primary",
							onClick: e.onPlayAgain,
							children: t("playAgain")
						}), e.onBackToLobby && /* @__PURE__ */ x("button", {
							className: "hr-secondary",
							onClick: e.onBackToLobby,
							children: t("backToLobby")
						})]
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/index.tsx
var Re = {
	definition: Ee,
	View: Oe,
	bot: Fe,
	fx: Ie,
	OverView: Le,
	locales: {
		zh: {
			name: "英雄领域",
			desc: "用金币招募勇士、铸就牌组，在四方阵营的角力中击溃对手。White Wizard Games 2016 年基础版。",
			rules: "目标：\n每名玩家以 50 点生命开始。率先将其他所有玩家的生命降至 0 的玩家获胜，最后存活者即为胜者。\n\n准备：\n将 80 张市场牌洗混组成市场牌库，翻开 5 张作为市场。将 16 张火焰宝石正面朝上堆放在市场旁。每名玩家以 1 张短剑、1 张匕首、1 张红宝石和 7 张金币组成个人牌库（共 10 张），洗混后抽取起始手牌。二人局中，先手玩家抽 3 张、后手玩家抽 5 张；三人及以上时，先手抽 3 张、第二家抽 4 张、其余各抽 5 张。\n\n回合流程：\n每回合依次进行主要阶段、弃牌阶段和抽牌阶段。\n主要阶段中，你可以按任意顺序、不限次数地执行以下行动：\n· 从手牌打出行动牌、物品牌或勇士牌。\n· 使用场上牌的耗用、盟友或牺牲能力。\n· 花费金币，从市场或火焰宝石堆获得卡牌。\n· 花费战斗，攻击对手或其勇士。\n打出的行动牌和物品牌立即结算其主要能力，本回合留在场上，于弃牌阶段进入弃牌堆。勇士牌打出后留在场上，以竖直的准备状态表示尚可使用。\n弃牌阶段：清空剩余的金币与战斗，将场上的行动牌、物品牌和手牌放入弃牌堆，并准备你所有已耗用的勇士，同时清除其上本回合受到的伤害。\n抽牌阶段：抽 5 张牌，然后回合结束。若牌库不足，先将弃牌堆洗混组成新的牌库，再继续抽取。\n\n获得、战斗与勇士：\n获得卡牌时支付其右上角的费用，将卡牌放入弃牌堆，并立即用市场牌库顶牌补满市场空位。火焰宝石的费用为 2，可以反复获得。\n战斗可以分配给你攻击的对手或其勇士，伤害可任意拆分。对勇士造成的伤害在本回合内累计，达到其防御值即将其击晕并放入拥有者的弃牌堆；未达到防御值的伤害在回合结束时清除。\n守卫勇士能保护其拥有者：只要一名玩家场上有已准备好的守卫，该玩家便不能被对手攻击，其非守卫勇士也不能被对手攻击或被指定为目标。守卫本身仍可被攻击或被指定为目标。\n\n盟友与牺牲：\n若你场上（包括勇士）有至少两张同一阵营的牌，便可使用该阵营牌的盟友能力。每张牌的盟友能力每回合只能使用一次。\n带有牺牲能力的牌可从场上牺牲，置入公共牺牲堆。火焰宝石被牺牲时改为放回火焰宝石堆。\n\n胜利：\n当一名玩家的生命降至 0 或更低时即被淘汰，其勇士与场上牌不再参与游戏。最后存活的玩家获胜。",
			invalid: "当前无法执行这个操作，请重新选择。",
			yourTurn: "你的回合",
			waiting: "等待 {{name}}",
			turn: "第 {{n}} 回合",
			phase: "主要阶段",
			resolving: "正在结算",
			done: "对局结束",
			gold: "金币",
			combat: "战斗",
			health: "生命",
			hand: "手牌",
			deck: "牌库",
			discard: "弃牌堆",
			market: "市场",
			marketDeck: "市场牌库",
			gems: "火焰宝石",
			sacrifice: "牺牲堆",
			champions: "勇士",
			play: "场上",
			playArea: "本回合打出的牌",
			you: "你",
			empty: "暂无卡牌",
			marketEmpty: "市场牌库已空",
			endTurn: "结束回合",
			buy: "获得",
			buyGem: "获得火焰宝石",
			playCard: "打出",
			expend: "耗用",
			ally: "盟友",
			sacrificeAction: "牺牲",
			confirm: "确认",
			skip: "跳过",
			yes: "是",
			no: "否",
			close: "关闭",
			detail: "卡牌详情",
			history: "对局记录",
			inspect: "查看 {{card}}",
			view: "查看",
			cost: "费用",
			defense: "防御",
			guard: "守卫",
			attack: "攻击",
			attackPlayer: "攻击 {{name}}",
			attackChampion: "攻击勇士",
			amount: "数量",
			choose: "请选择",
			chooseCard: "请选择一张牌",
			chooseOption: "请选择一项",
			chooseChampion: "请选择一名勇士",
			chooseOpponent: "请选择一名对手",
			waitingOther: "等待 {{name}} 作出选择",
			deckCount: "牌库 {{n}}",
			discardCount: "弃牌 {{n}}",
			handCount: "手牌 {{n}}",
			prompt: {
				mode: "请选择要结算的效果",
				stun: "请选择要击晕的勇士",
				prepare: "请选择要准备的勇士",
				targetPlayer: "请选择一名对手",
				oppDiscard: "请选择要弃掉的牌",
				sacrifice: "你可以牺牲一张牌",
				discardSelfOne: "请弃 {{n}} 张牌",
				discardSelfMany: "请弃 {{n}} 张牌",
				yesno: "是否使用这个效果",
				pickTop: "请选择要置于牌库顶的牌"
			},
			opt: {
				gold1: "获得 1 金币",
				gold2: "获得 2 金币",
				gold3: "获得 3 金币",
				combat1: "获得 1 战斗",
				combat2: "获得 2 战斗",
				combat3: "获得 3 战斗",
				health4: "获得 4 生命",
				healthPerChampion: "每名勇士获得 1 生命"
			},
			event: {
				turn: "{{name}} 开始了第 {{n}} 回合",
				play: "{{name}} 打出了 {{card}}",
				ally: "{{name}} 使用了 {{card}} 的盟友能力",
				expend: "{{name}} 耗用了 {{card}}",
				sacrifice: "{{name}} 牺牲了 {{card}}",
				buy: "{{name}} 获得了 {{card}}",
				attack: "{{name}} 攻击 {{target}}，造成 {{n}} 点伤害",
				attackChampion: "{{name}} 攻击 {{target}} 的 {{card}}，造成 {{n}} 点伤害",
				stun: "{{name}} 的 {{card}} 被击晕",
				discard: "{{name}} 弃掉了 {{card}}",
				toDeck: "{{name}} 将 {{card}} 置于牌库顶",
				defeat: "{{name}} 被淘汰",
				end: "对局结束"
			},
			cards: {
				taxation: {
					name: "征税",
					text: "获得 2 金币。\n帝国盟友：获得 6 生命。"
				},
				recruit: {
					name: "募兵",
					text: "获得 2 金币和 3 生命。你每有一名勇士，额外获得 1 生命。\n帝国盟友：获得 1 金币。"
				},
				closeRanks: {
					name: "列阵",
					text: "获得 5 战斗。你每有一名勇士，额外获得 2 战斗。\n帝国盟友：获得 6 生命。"
				},
				rallyTheTroops: {
					name: "集结部队",
					text: "获得 5 战斗和 5 生命。\n帝国盟友：准备一名勇士。"
				},
				command: {
					name: "号令",
					text: "获得 2 金币、3 战斗和 4 生命。抽一张牌。"
				},
				wordOfPower: {
					name: "力量之言",
					text: "抽两张牌。\n帝国盟友：获得 5 生命。\n牺牲：获得 5 战斗。"
				},
				domination: {
					name: "统治",
					text: "获得 6 战斗和 6 生命。抽一张牌。\n帝国盟友：准备一名勇士。"
				},
				profit: {
					name: "牟利",
					text: "获得 2 金币。\n公会盟友：获得 4 战斗。"
				},
				intimidation: {
					name: "恐吓",
					text: "获得 5 战斗。\n公会盟友：获得 2 金币。"
				},
				bribe: {
					name: "贿赂",
					text: "获得 3 金币。\n公会盟友：本回合你下一次获得的行动牌置于牌库顶。"
				},
				deathThreat: {
					name: "死亡威胁",
					text: "获得 1 战斗。抽一张牌。\n公会盟友：击晕目标勇士。"
				},
				hitJob: {
					name: "暗杀委托",
					text: "获得 7 战斗。\n公会盟友：击晕目标勇士。"
				},
				deception: {
					name: "欺瞒",
					text: "获得 2 金币。抽一张牌。\n公会盟友：本回合你下一次获得的牌加入手牌。"
				},
				smashAndGrab: {
					name: "打砸抢",
					text: "获得 6 战斗。你可以将弃牌堆中的一张牌置于牌库顶。"
				},
				fireBomb: {
					name: "火焰炸弹",
					text: "获得 8 战斗。击晕目标勇士。抽一张牌。\n牺牲：获得 5 战斗。"
				},
				deathTouch: {
					name: "死亡之触",
					text: "获得 2 战斗。你可以牺牲手牌或弃牌堆中的一张牌。\n死灵盟友：获得 2 战斗。"
				},
				influence: {
					name: "影响力",
					text: "获得 3 金币。\n牺牲：获得 3 战斗。"
				},
				theRot: {
					name: "腐化",
					text: "获得 4 战斗。你可以牺牲手牌或弃牌堆中的一张牌。\n死灵盟友：获得 3 战斗。"
				},
				darkEnergy: {
					name: "黑暗能量",
					text: "获得 7 战斗。\n死灵盟友：抽一张牌。"
				},
				darkReward: {
					name: "黑暗奖赏",
					text: "获得 3 金币。你可以牺牲手牌或弃牌堆中的一张牌。\n死灵盟友：获得 6 战斗。"
				},
				lifeDrain: {
					name: "吸取生命",
					text: "获得 8 战斗。你可以牺牲手牌或弃牌堆中的一张牌。\n死灵盟友：抽一张牌。"
				},
				spark: {
					name: "火花",
					text: "获得 3 战斗。目标对手弃一张牌。\n荒野盟友：获得 2 战斗。"
				},
				elvenGift: {
					name: "精灵赠礼",
					text: "获得 2 金币。你可以抽一张牌；若如此做，弃一张牌。\n荒野盟友：获得 4 战斗。"
				},
				elvenCurse: {
					name: "精灵诅咒",
					text: "获得 6 战斗。目标对手弃一张牌。\n荒野盟友：获得 3 战斗。"
				},
				naturesBounty: {
					name: "自然恩赐",
					text: "获得 4 金币。\n荒野盟友：目标对手弃一张牌。\n牺牲：获得 4 战斗。"
				},
				wolfForm: {
					name: "狼形态",
					text: "获得 8 战斗。目标对手弃一张牌。\n牺牲：目标对手弃一张牌。"
				},
				rampage: {
					name: "横冲直撞",
					text: "获得 6 战斗。你可以至多抽两张牌，然后弃掉等量的牌。"
				},
				tithePriest: {
					name: "什一税祭司",
					text: "耗用：获得 1 金币，或你每有一名勇士获得 1 生命。"
				},
				manAtArms: {
					name: "武装侍从",
					text: "守卫。\n耗用：获得 2 战斗，你每有一名其他守卫额外获得 1 战斗。"
				},
				masterWeyan: {
					name: "韦扬大师",
					text: "耗用：获得 3 战斗，你每有一名其他勇士额外获得 1 战斗。"
				},
				darianWarMage: {
					name: "达里安战争法师",
					text: "耗用：获得 3 战斗或 4 生命。"
				},
				cristovTheJust: {
					name: "正义者克里斯托夫",
					text: "守卫。\n耗用：获得 2 战斗和 3 生命。\n帝国盟友：抽一张牌。"
				},
				krakaHighPriest: {
					name: "克拉卡大祭司",
					text: "耗用：获得 2 生命。抽一张牌。\n帝国盟友：你每有一名勇士获得 2 生命。"
				},
				arkusImperialDragon: {
					name: "帝国巨龙阿尔库斯",
					text: "耗用：获得 5 战斗。抽一张牌。\n帝国盟友：获得 6 生命。"
				},
				streetThug: {
					name: "街头恶棍",
					text: "耗用：获得 1 金币或 2 战斗。"
				},
				rasmusTheSmuggler: {
					name: "走私者拉斯穆斯",
					text: "耗用：获得 2 金币。\n公会盟友：本回合你下一次获得的牌置于牌库顶。"
				},
				parovTheEnforcer: {
					name: "执法者帕罗夫",
					text: "耗用：获得 3 战斗。\n公会盟友：抽一张牌。"
				},
				myrosGuildMage: {
					name: "公会法师迈罗斯",
					text: "耗用：获得 3 金币。\n公会盟友：获得 4 战斗。"
				},
				borgOgreMercenary: {
					name: "食人魔佣兵博格",
					text: "耗用：获得 4 战斗。"
				},
				rakeMasterAssassin: {
					name: "刺客大师雷克",
					text: "耗用：获得 4 战斗。你可以击晕目标勇士。"
				},
				deathCultist: {
					name: "死亡邪教徒",
					text: "耗用：获得 2 战斗。"
				},
				cultPriest: {
					name: "邪教祭司",
					text: "耗用：获得 1 金币或 1 战斗。\n死灵盟友：获得 4 战斗。"
				},
				raylaEndweaver: {
					name: "织终者蕾拉",
					text: "耗用：获得 3 战斗。\n死灵盟友：抽一张牌。"
				},
				varrickTheNecromancer: {
					name: "死灵法师瓦里克",
					text: "耗用：将弃牌堆中的一名勇士置于牌库顶。\n死灵盟友：抽一张牌。"
				},
				lysTheUnseen: {
					name: "无形者莱斯",
					text: "耗用：获得 2 战斗。你可以牺牲手牌或弃牌堆中的一张牌；若如此做，额外获得 2 战斗。"
				},
				krythosMasterVampire: {
					name: "吸血鬼大师克里索斯",
					text: "耗用：获得 3 战斗。你可以牺牲手牌或弃牌堆中的一张牌；若如此做，额外获得 3 战斗。"
				},
				tyrannorTheDevourer: {
					name: "吞噬者泰拉诺",
					text: "耗用：获得 4 战斗。你可以牺牲手牌或弃牌堆中的至多两张牌。\n死灵盟友：抽一张牌。"
				},
				wolfShaman: {
					name: "狼萨满",
					text: "耗用：获得 2 战斗，你每有一张其他荒野牌额外获得 1 战斗。"
				},
				orcGrunt: {
					name: "兽人步兵",
					text: "耗用：获得 2 战斗。\n荒野盟友：抽一张牌。"
				},
				broelynLoreweaver: {
					name: "织识者布罗琳",
					text: "耗用：获得 2 金币。\n荒野盟友：目标对手弃一张牌。"
				},
				direWolf: {
					name: "恐狼",
					text: "耗用：获得 3 战斗。\n荒野盟友：获得 4 战斗。"
				},
				cronTheBerserker: {
					name: "狂战士克罗恩",
					text: "耗用：获得 5 战斗。\n荒野盟友：抽一张牌。"
				},
				torgenRocksplitter: {
					name: "裂石者托尔根",
					text: "耗用：获得 4 战斗。目标对手弃一张牌。"
				},
				grakStormGiant: {
					name: "风暴巨人格拉克",
					text: "耗用：获得 6 战斗。你可以抽一张牌；若如此做，弃一张牌。\n荒野盟友：抽一张牌，然后弃一张牌。"
				},
				gold: {
					name: "金币",
					text: "获得 1 金币。"
				},
				ruby: {
					name: "红宝石",
					text: "获得 2 金币。"
				},
				shortsword: {
					name: "短剑",
					text: "获得 2 战斗。"
				},
				dagger: {
					name: "匕首",
					text: "获得 1 战斗。"
				},
				fireGem: {
					name: "火焰宝石",
					text: "获得 2 金币。\n牺牲：获得 3 战斗。"
				}
			},
			faction: {
				imperial: "帝国",
				guild: "公会",
				necros: "死灵",
				wild: "荒野",
				none: "基础"
			},
			kind: {
				action: "行动",
				champion: "勇士",
				item: "物品"
			},
			result: "对局结果",
			winner: "胜者",
			playAgain: "再来一局",
			backToLobby: "返回大厅",
			place: "第 {{n}} 名",
			healthLeft: "剩余生命 {{n}}"
		},
		en: {
			name: "Hero Realms",
			desc: "Recruit champions and build your deck to crush your rivals across four factions. White Wizard Games base set, 2016.",
			rules: "Goal:\nEach player starts with 50 health. Reduce all other players to 0 health to win; the last player standing wins.\n\nSetup:\nShuffle the 80-card Market Deck and deal 5 cards face-up as the Market. Stack the 16 Fire Gems face-up beside the Market. Each player builds a personal deck of 1 Shortsword, 1 Dagger, 1 Ruby, and 7 Gold (10 cards), shuffles it, and draws an opening hand. In a two-player game the first player draws 3 cards and the second draws 5. With three or more players, the first draws 3, the second draws 4, and everyone else draws 5.\n\nTurn:\nEach turn has a Main Phase, a Discard Phase, and a Draw Phase.\nDuring your Main Phase you may, in any order and any number of times, take the following actions:\n· Play an Action, Item, or Champion from your hand.\n· Use the Expend, Ally, or Sacrifice abilities of cards in play.\n· Spend Gold to acquire cards from the Market or the Fire Gem pile.\n· Spend Combat to attack opponents or their Champions.\nActions and Items resolve immediately and stay in play until the Discard Phase. Champions stay in play and are prepared (upright) when ready to use again.\nDiscard Phase: lose remaining Gold and Combat, put all played Actions, Items, and your hand into your discard pile, and prepare all expended Champions, clearing damage dealt to them this turn.\nDraw Phase: draw 5 cards, then your turn ends. If your deck runs out, shuffle your discard pile into a new deck and continue drawing.\n\nAcquiring, Combat, and Champions:\nPay a card's cost in the upper-right corner to acquire it, place it in your discard pile, and immediately refill the Market from the top of the Market Deck. Fire Gems cost 2 and may be acquired repeatedly.\nCombat may be split freely between an opponent and their Champions. Damage to a Champion accumulates during the turn; once it reaches the Champion's Defense, the Champion is stunned and goes to its owner's discard pile. Damage below Defense is cleared at end of turn.\nGuards protect their owner: while a player has a prepared Guard, that player cannot be attacked, and their non-Guard Champions cannot be attacked or targeted by an opponent. Guards themselves can still be attacked or targeted.\n\nAlly and Sacrifice:\nIf you have at least two cards of the same faction in play (including Champions), you may use that faction's Ally abilities. Each card's Ally ability may be used once per turn.\nCards with a Sacrifice ability may be sacrificed from play into the shared Sacrifice Pile. A sacrificed Fire Gem returns to the Fire Gem pile instead.\n\nVictory:\nA player at 0 health or less is eliminated and their Champions and cards leave the game. The last player standing wins.",
			invalid: "That action is not available right now. Please choose again.",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			phase: "Main Phase",
			resolving: "Resolving",
			done: "Game over",
			gold: "Gold",
			combat: "Combat",
			health: "Health",
			hand: "Hand",
			deck: "Deck",
			discard: "Discard",
			market: "Market",
			marketDeck: "Market Deck",
			gems: "Fire Gems",
			sacrifice: "Sacrifice Pile",
			champions: "Champions",
			play: "In play",
			playArea: "Played this turn",
			you: "You",
			empty: "No cards",
			marketEmpty: "Market deck empty",
			endTurn: "End turn",
			buy: "Acquire",
			buyGem: "Acquire Fire Gem",
			playCard: "Play",
			expend: "Expend",
			ally: "Ally",
			sacrificeAction: "Sacrifice",
			confirm: "Confirm",
			skip: "Skip",
			yes: "Yes",
			no: "No",
			close: "Close",
			detail: "Card details",
			history: "Game log",
			inspect: "View {{card}}",
			view: "View",
			cost: "Cost",
			defense: "Defense",
			guard: "Guard",
			attack: "Attack",
			attackPlayer: "Attack {{name}}",
			attackChampion: "Attack Champion",
			amount: "Amount",
			choose: "Choose",
			chooseCard: "Choose a card",
			chooseOption: "Choose an option",
			chooseChampion: "Choose a Champion",
			chooseOpponent: "Choose an opponent",
			waitingOther: "Waiting for {{name}} to choose",
			deckCount: "Deck {{n}}",
			discardCount: "Discard {{n}}",
			handCount: "Hand {{n}}",
			prompt: {
				mode: "Choose how to resolve this effect",
				stun: "Choose a Champion to stun",
				prepare: "Choose a Champion to prepare",
				targetPlayer: "Choose an opponent",
				oppDiscard: "Choose a card to discard",
				sacrifice: "You may sacrifice a card",
				discardSelfOne: "Discard {{n}} card",
				discardSelfMany: "Discard {{n}} cards",
				yesno: "Use this effect?",
				pickTop: "Choose a card to put on top of your deck"
			},
			opt: {
				gold1: "Gain 1 Gold",
				gold2: "Gain 2 Gold",
				gold3: "Gain 3 Gold",
				combat1: "Gain 1 Combat",
				combat2: "Gain 2 Combat",
				combat3: "Gain 3 Combat",
				health4: "Gain 4 Health",
				healthPerChampion: "Gain 1 Health per Champion"
			},
			event: {
				turn: "{{name}} started turn {{n}}",
				play: "{{name}} played {{card}}",
				ally: "{{name}} used the Ally ability of {{card}}",
				expend: "{{name}} expended {{card}}",
				sacrifice: "{{name}} sacrificed {{card}}",
				buy: "{{name}} acquired {{card}}",
				attack: "{{name}} attacked {{target}} for {{n}}",
				attackChampion: "{{name}} attacked {{target}}'s {{card}} for {{n}}",
				stun: "{{name}}'s {{card}} was stunned",
				discard: "{{name}} discarded {{card}}",
				toDeck: "{{name}} put {{card}} on top of their deck",
				defeat: "{{name}} was eliminated",
				end: "Game over"
			},
			cards: {
				taxation: {
					name: "Taxation",
					text: "Gain 2 Gold.\nImperial Ally: Gain 6 Health."
				},
				recruit: {
					name: "Recruit",
					text: "Gain 2 Gold and 3 Health. Gain 1 additional Health for each Champion you have in play.\nImperial Ally: Gain 1 Gold."
				},
				closeRanks: {
					name: "Close Ranks",
					text: "Gain 5 Combat. Gain 2 additional Combat for each Champion you have in play.\nImperial Ally: Gain 6 Health."
				},
				rallyTheTroops: {
					name: "Rally the Troops",
					text: "Gain 5 Combat and 5 Health.\nImperial Ally: Prepare a Champion."
				},
				command: {
					name: "Command",
					text: "Gain 2 Gold, 3 Combat, and 4 Health. Draw a card."
				},
				wordOfPower: {
					name: "Word of Power",
					text: "Draw two cards.\nImperial Ally: Gain 5 Health.\nSacrifice: Gain 5 Combat."
				},
				domination: {
					name: "Domination",
					text: "Gain 6 Combat and 6 Health. Draw a card.\nImperial Ally: Prepare a Champion."
				},
				profit: {
					name: "Profit",
					text: "Gain 2 Gold.\nGuild Ally: Gain 4 Combat."
				},
				intimidation: {
					name: "Intimidation",
					text: "Gain 5 Combat.\nGuild Ally: Gain 2 Gold."
				},
				bribe: {
					name: "Bribe",
					text: "Gain 3 Gold.\nGuild Ally: Put the next Action you acquire this turn on top of your deck."
				},
				deathThreat: {
					name: "Death Threat",
					text: "Gain 1 Combat. Draw a card.\nGuild Ally: Stun target Champion."
				},
				hitJob: {
					name: "Hit Job",
					text: "Gain 7 Combat.\nGuild Ally: Stun target Champion."
				},
				deception: {
					name: "Deception",
					text: "Gain 2 Gold. Draw a card.\nGuild Ally: Put the next card you acquire this turn into your hand."
				},
				smashAndGrab: {
					name: "Smash and Grab",
					text: "Gain 6 Combat. You may put a card from your discard pile on top of your deck."
				},
				fireBomb: {
					name: "Fire Bomb",
					text: "Gain 8 Combat. Stun target Champion. Draw a card.\nSacrifice: Gain 5 Combat."
				},
				deathTouch: {
					name: "Death Touch",
					text: "Gain 2 Combat. You may sacrifice a card in your hand or discard pile.\nNecros Ally: Gain 2 Combat."
				},
				influence: {
					name: "Influence",
					text: "Gain 3 Gold.\nSacrifice: Gain 3 Combat."
				},
				theRot: {
					name: "The Rot",
					text: "Gain 4 Combat. You may sacrifice a card in your hand or discard pile.\nNecros Ally: Gain 3 Combat."
				},
				darkEnergy: {
					name: "Dark Energy",
					text: "Gain 7 Combat.\nNecros Ally: Draw a card."
				},
				darkReward: {
					name: "Dark Reward",
					text: "Gain 3 Gold. You may sacrifice a card in your hand or discard pile.\nNecros Ally: Gain 6 Combat."
				},
				lifeDrain: {
					name: "Life Drain",
					text: "Gain 8 Combat. You may sacrifice a card in your hand or discard pile.\nNecros Ally: Draw a card."
				},
				spark: {
					name: "Spark",
					text: "Gain 3 Combat. Target opponent discards a card.\nWild Ally: Gain 2 Combat."
				},
				elvenGift: {
					name: "Elven Gift",
					text: "Gain 2 Gold. You may draw a card. If you do, discard a card.\nWild Ally: Gain 4 Combat."
				},
				elvenCurse: {
					name: "Elven Curse",
					text: "Gain 6 Combat. Target opponent discards a card.\nWild Ally: Gain 3 Combat."
				},
				naturesBounty: {
					name: "Nature's Bounty",
					text: "Gain 4 Gold.\nWild Ally: Target opponent discards a card.\nSacrifice: Gain 4 Combat."
				},
				wolfForm: {
					name: "Wolf Form",
					text: "Gain 8 Combat. Target opponent discards a card.\nSacrifice: Target opponent discards a card."
				},
				rampage: {
					name: "Rampage",
					text: "Gain 6 Combat. You may draw up to two cards, then discard that many cards."
				},
				tithePriest: {
					name: "Tithe Priest",
					text: "Expend: Gain 1 Gold, or gain 1 Health for each Champion you have in play."
				},
				manAtArms: {
					name: "Man-at-Arms",
					text: "Guard.\nExpend: Gain 2 Combat, plus 1 Combat for each other Guard you have in play."
				},
				masterWeyan: {
					name: "Master Weyan",
					text: "Expend: Gain 3 Combat, plus 1 Combat for each other Champion you have in play."
				},
				darianWarMage: {
					name: "Darian, War Mage",
					text: "Expend: Gain 3 Combat or 4 Health."
				},
				cristovTheJust: {
					name: "Cristov, the Just",
					text: "Guard.\nExpend: Gain 2 Combat and 3 Health.\nImperial Ally: Draw a card."
				},
				krakaHighPriest: {
					name: "Kraka, High Priest",
					text: "Expend: Gain 2 Health. Draw a card.\nImperial Ally: Gain 2 Health for each Champion you have in play."
				},
				arkusImperialDragon: {
					name: "Arkus, Imperial Dragon",
					text: "Expend: Gain 5 Combat. Draw a card.\nImperial Ally: Gain 6 Health."
				},
				streetThug: {
					name: "Street Thug",
					text: "Expend: Gain 1 Gold or 2 Combat."
				},
				rasmusTheSmuggler: {
					name: "Rasmus, the Smuggler",
					text: "Expend: Gain 2 Gold.\nGuild Ally: Put the next card you acquire this turn on top of your deck."
				},
				parovTheEnforcer: {
					name: "Parov, the Enforcer",
					text: "Expend: Gain 3 Combat.\nGuild Ally: Draw a card."
				},
				myrosGuildMage: {
					name: "Myros, Guild Mage",
					text: "Expend: Gain 3 Gold.\nGuild Ally: Gain 4 Combat."
				},
				borgOgreMercenary: {
					name: "Borg, Ogre Mercenary",
					text: "Expend: Gain 4 Combat."
				},
				rakeMasterAssassin: {
					name: "Rake, Master Assassin",
					text: "Expend: Gain 4 Combat. You may stun target Champion."
				},
				deathCultist: {
					name: "Death Cultist",
					text: "Expend: Gain 2 Combat."
				},
				cultPriest: {
					name: "Cult Priest",
					text: "Expend: Gain 1 Gold or 1 Combat.\nNecros Ally: Gain 4 Combat."
				},
				raylaEndweaver: {
					name: "Rayla, Endweaver",
					text: "Expend: Gain 3 Combat.\nNecros Ally: Draw a card."
				},
				varrickTheNecromancer: {
					name: "Varrick, the Necromancer",
					text: "Expend: Put a Champion from your discard pile on top of your deck.\nNecros Ally: Draw a card."
				},
				lysTheUnseen: {
					name: "Lys, the Unseen",
					text: "Expend: Gain 2 Combat. You may sacrifice a card in your hand or discard pile. If you do, gain an additional 2 Combat."
				},
				krythosMasterVampire: {
					name: "Krythos, Master Vampire",
					text: "Expend: Gain 3 Combat. You may sacrifice a card in your hand or discard pile. If you do, gain an additional 3 Combat."
				},
				tyrannorTheDevourer: {
					name: "Tyrannor, the Devourer",
					text: "Expend: Gain 4 Combat. You may sacrifice up to two cards in your hand and/or discard pile.\nNecros Ally: Draw a card."
				},
				wolfShaman: {
					name: "Wolf Shaman",
					text: "Expend: Gain 2 Combat, plus 1 Combat for each other Wild card you have in play."
				},
				orcGrunt: {
					name: "Orc Grunt",
					text: "Expend: Gain 2 Combat.\nWild Ally: Draw a card."
				},
				broelynLoreweaver: {
					name: "Broelyn, Loreweaver",
					text: "Expend: Gain 2 Gold.\nWild Ally: Target opponent discards a card."
				},
				direWolf: {
					name: "Dire Wolf",
					text: "Expend: Gain 3 Combat.\nWild Ally: Gain 4 Combat."
				},
				cronTheBerserker: {
					name: "Cron, the Berserker",
					text: "Expend: Gain 5 Combat.\nWild Ally: Draw a card."
				},
				torgenRocksplitter: {
					name: "Torgen Rocksplitter",
					text: "Expend: Gain 4 Combat. Target opponent discards a card."
				},
				grakStormGiant: {
					name: "Grak, Storm Giant",
					text: "Expend: Gain 6 Combat. You may draw a card. If you do, discard a card.\nWild Ally: Draw a card, then discard a card."
				},
				gold: {
					name: "Gold",
					text: "Gain 1 Gold."
				},
				ruby: {
					name: "Ruby",
					text: "Gain 2 Gold."
				},
				shortsword: {
					name: "Shortsword",
					text: "Gain 2 Combat."
				},
				dagger: {
					name: "Dagger",
					text: "Gain 1 Combat."
				},
				fireGem: {
					name: "Fire Gem",
					text: "Gain 2 Gold.\nSacrifice: Gain 3 Combat."
				}
			},
			faction: {
				imperial: "Imperial",
				guild: "Guild",
				necros: "Necros",
				wild: "Wild",
				none: "Basic"
			},
			kind: {
				action: "Action",
				champion: "Champion",
				item: "Item"
			},
			result: "Result",
			winner: "Winner",
			playAgain: "Play again",
			backToLobby: "Back to lobby",
			place: "Place {{n}}",
			healthLeft: "{{n}} health left"
		}
	}
};
//#endregion
export { Re as default };
