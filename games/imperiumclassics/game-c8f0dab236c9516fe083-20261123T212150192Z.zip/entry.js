import { z as e } from "zod";
import { useEffect as t, useRef as n, useState as r } from "react";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as l, seatName as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { AVATARS as m } from "@bgparty/sdk/avatars";
import { IconExpand as h, IconLog as g } from "@bgparty/sdk/icons";
import { OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/game/data/cards.ts
var y = [
	{
		id: "?FAM?A",
		zh: "众王之王",
		en: "King of Kings",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "powA",
		pc: 1,
		text: [[
			"当你将要获取本牌时，改为结算本牌。\n然后将本牌翻面。",
			"*这会触发游戏结束。*",
			"若{barbarian}，获取6{progress}。",
			"若{empire}，获取3{progress}并免费发展。"
		], [
			"When you would gain this card, instead resolve it. Then flip this card.",
			"THIS TRIGGERS GAME END.",
			"If {barbarian}, gain 6{progress}.",
			"If {empire}, gain 3{progress} and develop for free."
		]],
		rel: ["KOK_B"]
	},
	{
		id: "?FAM?B",
		zh: "众王之王",
		en: "King of Kings",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "powB",
		pc: 1,
		text: [[
			"当你将要获取本牌时，改为结算本牌。\n可以有多位玩家结算本牌。",
			"若{barbarian}，获取4{progress}。",
			"若{empire}，免费发展。"
		], [
			"When you would gain this card, instead resolve it. Multiple players can resolve this card.",
			"If {barbarian}, gain 4{progress}.",
			"If {empire}, develop for free."
		]],
		rel: ["KOK_A"]
	},
	{
		id: "UNR1",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR2",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR3",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR4",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR5",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR6",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR7",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR8",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR9",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 3,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR10",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 3,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR11",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 4,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UNR12",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "common",
		vp: -2,
		hdr: "none",
		pc: 4,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "1FAM1",
		zh: "颂扬",
		en: "Praiseworthy",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，7VP，否则3VP", "7VP if in history, 3VP otherwise"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["选择：将本牌放入你的历史\n*或*突破{uncivilised}/{civilised}/{region}/{tributary}。"], ["Choose: put this card into your history OR break through for {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "1FAM2",
		zh: "雄伟",
		en: "Great",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，6VP，否则2VP", "6VP if in history, 2VP otherwise"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。获取1行动。", "你*可以*将本牌放入你的历史。"], ["Free play. Gain 1 action.", "You MAY put this card into your history."]]
	},
	{
		id: "1FAM3",
		zh: "恶名",
		en: "Notorious",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["其他玩家每有\n1{unrest}计分，1VP", "1VP per {unrest} scored by other players"],
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [[
			"免费打出。",
			"从每位其他玩家处窃取1{progress}。",
			"如有玩家不能支付，则该玩家拿取{unrest}。"
		], [
			"Free play.",
			"Steal 1{progress} from each other player.",
			"Anyone unable to pay takes {unrest}."
		]]
	},
	{
		id: "1FAM4",
		zh: "霸业",
		en: "Marvellous",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 9,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。\n如有可能，抽取你的牌库顶的1张牌，并选择：\n弃置它，*或*将它放回牌库顶，*或*将它放入你的历史。"], ["Free play. Draw the top card of your deck if able and choose: discard it OR return it to the top OR put it into your history."]]
	},
	{
		id: "1FAM5",
		zh: "光荣",
		en: "Glorious",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 6,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [[
			"免费打出。若{barbarian}，抽取最多4张牌。",
			"若{empire}，免费发展。",
			"将本牌放入你的历史。"
		], [
			"Free play. If {barbarian}, draw up to 4 cards.",
			"If {empire}, develop at no cost.",
			"Put this card into your history."
		]]
	},
	{
		id: "1FAM6",
		zh: "凯旋",
		en: "Triumphant",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 11,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["不能被打出。", "不能用于进驻。"], ["Cannot be played.", "Cannot be garrisoned."]]
	},
	{
		id: "1FAM7",
		zh: "凯旋",
		en: "Triumphant",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 11,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["不能被打出。", "不能用于进驻。"], ["Cannot be played.", "Cannot be garrisoned."]]
	},
	{
		id: "1FAM8",
		zh: "敬畏",
		en: "Awe-inspiring",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 7,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["被动：你的手牌上限增加1。"], ["Passive: increase your hand size by 1."]]
	},
	{
		id: "1UNC1",
		zh: "常备军",
		en: "Standing Army",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 4,
		text: [["被动：当另一位玩家打出1{attack}时，\n除非他给予你1{progress}，否则忽略其效果。"], ["Passive: when another player plays an {attack}, ignore the effects unless they give you 1{progress}."]]
	},
	{
		id: "1UNC2",
		zh: "翡翠面具",
		en: "Jade Mask",
		s: ["uncivilised"],
		t: ["mask"],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "1UNC3",
		zh: "长老",
		en: "Elders",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["选择：购得{uncivilised}，*或*突破{uncivilised}且\n所有其他玩家获取1{progress}。"], ["Choose: acquire {uncivilised} OR break through for {uncivilised} and all other players gain 1{progress}."]]
	},
	{
		id: "1UNC4",
		zh: "村镇",
		en: "Town",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，2VP", "2VP if in history"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：所有玩家*可以*获取2{material}。", "至日：你*可以*获取2{progress}。若你如此做，\n选择：舍弃本牌，*或*将本牌放入你的历史。"], ["Exhaust: all players MAY gain 2{material}.", "Solstice: you MAY gain 2{progress}. If you do, choose: abandon this card OR put it into your history."]]
	},
	{
		id: "1UNC5",
		zh: "村镇",
		en: "Town",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，2VP", "2VP if in history"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：所有玩家*可以*获取2{material}。", "至日：你*可以*获取2{progress}。若你如此做，\n选择：舍弃本牌，*或*将本牌放入你的历史。"], ["Exhaust: all players MAY gain 2{material}.", "Solstice: you MAY gain 2{progress}. If you do, choose: abandon this card OR put it into your history."]]
	},
	{
		id: "1UNC6",
		zh: "圣祠",
		en: "Shrine",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：支付1{material}以抽取1张牌。", "至日：你*可以*弃置1张牌以\n从你的弃牌堆中放回1{unrest}。"], ["Exhaust: pay 1{material} to draw a card.", "Solstice: you MAY discard a card to return an {unrest} from your discard pile."]]
	},
	{
		id: "1UNC7",
		zh: "入侵",
		en: "Invasion",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [["支付3{material}。所有其他玩家拿取{unrest}。", "选择：突破{tributary}，*或*突破{region}且每位\n其他玩家召回1{region}。"], ["Pay 3{material}. All other players take {unrest}.", "Choose: break through for {tributary} OR break through for {region} and each other player recalls a {region}."]]
	},
	{
		id: "1UNC8",
		zh: "神秘主义",
		en: "Mysticism",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：获取1行动。", "至日：选择：拿取{unrest}，*或*弃置2张牌。"], ["Exhaust: gain 1 action.", "Solstice: choose: take {unrest} OR discard 2 cards."]]
	},
	{
		id: "1UNC9",
		zh: "神谕",
		en: "Oracle",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 0,
		vpt: ["每{fame}2VP", "2VP per {fame}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。抽取2张牌并弃置其中1张。"], ["Free play. Draw 2 cards and discard one of them."]]
	},
	{
		id: "1UNC10",
		zh: "农业",
		en: "Agriculture",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{fertile}2VP", "2VP per {fertile}"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：在本回合的剩余时间内，\n将1{fertile}视为3{production}。"], ["Exhaust: treat 1 {fertile} as 3 {production} for the rest of the turn."]]
	},
	{
		id: "1UNC11",
		zh: "船只",
		en: "Boats",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{fertile}/{river}1VP", "1VP per {fertile}/{river}"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：选择：召回1{river}以获取2{material}和1{population}，\n*或*召回1{fertile}以获取1行动。"], ["Exhaust: choose: recall a {river} to gain 2{material} and 1{population} OR recall a {fertile} to gain 1 action."]]
	},
	{
		id: "1UNC12",
		zh: "桔槔",
		en: "Shaduf",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{river}2VP", "2VP per {river}"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：当你从在场的{river}获取{material}时，\n耗竭本牌以获取1{progress}。"], ["Exhaust: when you gain {material} from a {river} in play, exhaust this card to gain 1{progress}."]]
	},
	{
		id: "1UNC13",
		zh: "仪式与典礼",
		en: "Rituals & Ceremonies",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "c",
		pc: 3,
		text: [["免费打出。选择：放回1{unrest}，\n*或*获取1{progress}且你*可以*放回1{exhaust}到你的国体牌。"], ["Free play. Choose: return an {unrest} OR gain 1{progress} and you MAY return an {exhaust} to your state card."]]
	},
	{
		id: "1UNC14",
		zh: "使节",
		en: "Ambassador",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 3,
		text: [["耗竭：结算一位对手的{pinned}牌上的1个耗竭关键词\n（如同是你的一样）。"], ["Exhaust: resolve the exhaust keyword on an opponent's {pinned} card as though it were your own."]]
	},
	{
		id: "1UNC15",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "1UNC16",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "1UNC17",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "1UNC18",
		zh: "赌博",
		en: "Gambling",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [[
			"免费打出。支付1{material}并声明以下花色\n之一：{uncivilised}、{civilised}、{region}或{tributary}。",
			"展示主牌库顶的1张牌。",
			"若它与声明的花色匹配，\n将它加入你的手牌。否则，将它放逐。"
		], [
			"Free play. Pay 1{material} and declare one of the following: {uncivilised}, {civilised}, {region}, or {tributary}.",
			"Reveal the top card of the main deck.",
			"If it matches the declared type, add it to your hand. Otherwise, exile it."
		]]
	},
	{
		id: "1UNC19",
		zh: "港口",
		en: "Port",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：每有1{river}在你的游戏区中，就获取1{material}。\n你*可以*支付3{material}以从你的弃牌堆中\n抽取1张你选择的牌。"], ["Exhaust: gain 1{material} per {river} in your play area. You MAY pay 3{material} to draw a card of your choice from your discard pile."]]
	},
	{
		id: "1UNC20",
		zh: "外交",
		en: "Diplomacy",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["支付3{material}以突破{tributary}。"], ["Pay 3{material} to break through for {tributary}."]]
	},
	{
		id: "1UNC21",
		zh: "领导",
		en: "Leadership",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。选择：抽取1张牌，\n*或*从你的手牌或弃牌堆中\n将1张牌放入你的历史。"], ["Free play. Choose: draw a card OR put a card from your hand or discard pile into your history."]]
	},
	{
		id: "1UNC22",
		zh: "失落古卷",
		en: "Lost Scroll",
		s: ["uncivilised", "civilised"],
		t: ["scroll"],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		box: "c",
		pc: 3,
		text: [["免费打出。你*可以*从你的弃牌堆中\n放回1张牌到你的牌库顶。", "所有玩家*可以*抽取1张牌。"], ["Free play. You MAY return a card from your discard pile to the top of your deck.", "All players MAY draw a card."]]
	},
	{
		id: "1CIV1",
		zh: "戏剧与诗歌",
		en: "Drama & Poetry",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "c",
		pc: 4,
		text: [["免费打出。从每位其他玩家处窃取1{progress}。\n每位玩家*可以*弃置1张牌以放回1{unrest}。"], ["Free play. Steal 1{progress} from each other player. Each player MAY discard a card to return an {unrest}."]]
	},
	{
		id: "1CIV2",
		zh: "教育",
		en: "Education",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。你*可以*从你的手牌中\n将1张牌放入你的历史。", "你*可以*从你的弃牌堆中将1张牌\n放入你的历史。"], ["Free play. You MAY put a card from your hand into your history.", "You MAY put a card from your discard pile into your history."]]
	},
	{
		id: "1CIV3",
		zh: "放债者",
		en: "Moneylenders",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每10{material}1VP", "1VP per 10{material}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。支付3{material}以获取1行动。"], ["Free play. Pay 3{material} to gain 1 action."]]
	},
	{
		id: "1CIV4",
		zh: "腐败",
		en: "Corruption",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [[
			"所有玩家获取2{material}。",
			"所有其他玩家拿取{unrest}。",
			"获取1{progress}。"
		], [
			"All players gain 2{material}.",
			"All other players take {unrest}.",
			"Gain 1{progress}."
		]]
	},
	{
		id: "1CIV5",
		zh: "投石车",
		en: "Onager",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{city}。",
			"每舍弃1{city}就获取2{material}。",
			"你*可以*购得{region}/{tributary}。"
		], [
			"Each other player abandons a {city}.",
			"Gain 2{material} per abandoned {city}.",
			"You MAY acquire {region}/{tributary}."
		]]
	},
	{
		id: "1CIV6",
		zh: "首都",
		en: "Metropolis",
		s: ["civilised"],
		t: ["metropolis"],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "1CIV7",
		zh: "首都",
		en: "Metropolis",
		s: ["civilised"],
		t: ["metropolis"],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "c",
		pc: 4,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "1CIV8",
		zh: "药学",
		en: "Pharmacy",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["至日：选择：获取1{population}，\n*或*支付2{population}以获取1{progress}。"], ["Solstice: choose: gain 1{population} OR pay 2{population} to gain 1{progress}."]]
	},
	{
		id: "1CIV9",
		zh: "奇观",
		en: "Wonder",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "c",
		pc: 3,
		text: [["耗竭：当你放回{unrest}时，耗竭本牌以获取2{progress}。"], ["Exhaust: when you return an {unrest}, exhaust this card to gain 2{progress}."]]
	},
	{
		id: "1CIV10",
		zh: "铸币",
		en: "Coinage",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：抽取1张牌。", "至日：获取2{material}。"], ["Exhaust: draw a card.", "Solstice: gain 2{material}."]]
	},
	{
		id: "1CIV11",
		zh: "出口",
		en: "Exports",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每10张牌1VP", "1VP per 10 cards"],
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [["所有玩家获取2{material}。", "从你的手牌或弃牌堆中给予\n每位其他玩家1张牌。"], ["All players gain 2{material}.", "Give each other player a card from your hand or discard pile."]]
	},
	{
		id: "1CIV12",
		zh: "城市发展",
		en: "Urban Development",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每{city}/{metropolis}2VP", "2VP per {city}/{metropolis}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["每有1{city}/{metropolis}在你的游戏区中，\n就获取1{material}和1{population}。"], ["Gain 1{material} and 1{population} per {city}/{metropolis} in your play area."]]
	},
	{
		id: "1CIV13",
		zh: "佣兵",
		en: "Mercenaries",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每4{population}1VP", "1VP per 4{population}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。支付1{population}以获取1行动。"], ["Free play. Pay 1{population} to gain 1 action."]]
	},
	{
		id: "1CIV14",
		zh: "神殿",
		en: "Temple",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每5{progress}1VP", "1VP per 5{progress}"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：弃置1张牌以获取1{progress}。", "至日：从你的弃牌堆中放回1{unrest}。"], ["Exhaust: discard a card to gain 1{progress}.", "Solstice: return an {unrest} from your discard pile."]]
	},
	{
		id: "1CIV15",
		zh: "重甲骑兵",
		en: "Cataphract",
		s: ["civilised"],
		t: ["knight"],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "c",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{region}。",
			"你*可以*购得{region}/{tributary}。",
			"你*可以*将本牌进驻到1{region}以触发\n那张牌的打出效果。"
		], [
			"Each other player abandons a {region}.",
			"You MAY acquire {region}/{tributary}.",
			"You MAY garrison this card in a {region} to trigger that card's play effect."
		]]
	},
	{
		id: "1REG1",
		zh: "荒原",
		en: "Wilderness",
		s: ["region"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 3,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"被动：你*可以*召回本牌以回避1{attack}的效果。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Passive: you MAY recall this card to avoid the effect of an {attack}."
		]]
	},
	{
		id: "1REG2",
		zh: "丛林",
		en: "Jungle",
		s: ["region"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"获取1{population}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{population}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG3",
		zh: "山脉",
		en: "Mountain",
		s: ["region"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"获取3{material}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 3{material}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG4",
		zh: "海岸",
		en: "Coast",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"抽取1张牌。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Draw a card.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG5",
		zh: "泛滥平原",
		en: "Floodplain",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中将1张牌\n放入你的历史。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You MAY put a card from your discard pile into your history.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG6",
		zh: "森林",
		en: "Forest",
		s: ["region"],
		t: [
			"production",
			"production",
			"fertile"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["从市场中放逐1张牌。", "你*可以*进驻1张牌。"], ["Exile a card from the market.", "You MAY garrison a card."]]
	},
	{
		id: "1REG7",
		zh: "绿洲",
		en: "Oasis",
		s: ["region"],
		t: [
			"production",
			"production",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["从市场中放逐1张牌。", "你*可以*进驻1张牌。"], ["Exile a card from the market.", "You MAY garrison a card."]]
	},
	{
		id: "1REG8",
		zh: "丘陵",
		en: "Hills",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"获取1{population}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{population}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG9",
		zh: "湿地",
		en: "Marsh",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"获取2{material}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 2{material}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG10",
		zh: "草原",
		en: "Steppe",
		s: ["region"],
		t: [
			"production",
			"production",
			"fertile"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["从市场中放逐1张牌。", "你*可以*进驻1张牌。"], ["Exile a card from the market.", "You MAY garrison a card."]]
	},
	{
		id: "1REG11",
		zh: "河流",
		en: "River",
		s: ["region"],
		t: [
			"production",
			"production",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中将1张牌\n放入你的历史。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You MAY put a card from your discard pile into your history.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG12",
		zh: "海岬",
		en: "Cape",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"被动：你*可以*召回本牌以回避1{attack}的效果。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Passive: you MAY recall this to avoid the effect of an {attack}."
		]]
	},
	{
		id: "1REG13",
		zh: "林地",
		en: "Woodland",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中抽取1张你选择的牌，\n并将其放到你的抽牌库顶。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You MAY draw a card of your choice from your discard pile and place it on the top of your draw deck.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "1REG14",
		zh: "神圣山口",
		en: "Sacred Pass",
		s: ["region"],
		t: [],
		st: "b",
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["耗竭：你*可以*查看你的国家牌库顶的1张牌。\n然后你*可以*舍弃本牌以从你的手牌中\n将1张牌与你的国家牌库顶的1张牌交换。"], ["Exhaust: you MAY look at the top card of your nation deck. You MAY then abandon this card to swap a card from your hand with the top of your nation deck."]]
	},
	{
		id: "1TRI1",
		zh: "亚美尼亚",
		en: "Armenians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["购得{uncivilised}。", "将本牌放入你的历史。"], ["Acquire {uncivilised}.", "Put this card into your history."]]
	},
	{
		id: "1TRI2",
		zh: "亚述",
		en: "Assyrians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。获取1{population}。"], ["Free play. Gain 1{population}."]]
	},
	{
		id: "1TRI3",
		zh: "埃及",
		en: "Egyptians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{civilised}1VP", "1VP per {civilised}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [[
			"若{barbarian}，将你的国家牌库顶的1张牌\n放入你的弃牌堆。",
			"若{empire}，发展。",
			"将本牌放入你的历史。"
		], [
			"If {barbarian}, put the top card of your nation deck into your discard pile.",
			"If {empire}, develop.",
			"Put this card into your history."
		]]
	},
	{
		id: "1TRI4",
		zh: "爱奥尼亚",
		en: "Ionians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。从你的手牌或弃牌堆中放回最多2{unrest}。", "将本牌放入你的历史。"], ["Free play. Return up to 2 {unrest} from your hand or discard pile.", "Put this card into your history."]]
	},
	{
		id: "1TRI5",
		zh: "大秦",
		en: "Qin",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每有3{pinned}在场（不包括{region}），1VP", "1VP per 3 {pinned} cards in play excluding {region}"],
		hdr: "pin",
		box: "c",
		pc: 1,
		text: [["被动：你的手牌上限增加1。"], ["Passive: increase your hand size by 1."]]
	},
	{
		id: "1TRI6",
		zh: "奥尔梅克",
		en: "Olmecs",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 3,
		text: [["免费打出。放回1{exhaust}到你的国体牌。"], ["Free play. Return an {exhaust} to your state card."]]
	},
	{
		id: "1TRI7",
		zh: "苏美尔",
		en: "Sumerians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["不能被打出。"], ["Cannot be played."]]
	},
	{
		id: "1TRI8",
		zh: "阿克苏姆",
		en: "Aksumites",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{tributary}1VP", "1VP per {tributary}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["获取4{material}。"], ["Gain 4{material}."]]
	},
	{
		id: "1TRI9",
		zh: "米诺斯",
		en: "Minoans",
		s: ["tributary"],
		t: [],
		st: "b",
		loc: "common",
		vp: 0,
		vpt: ["每4{progress}1VP", "1VP per 4{progress}"],
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["免费打出。将1张牌放到你的牌库顶并获取2{progress}。"], ["Free play. Place a card on top of your deck and gain 2{progress}."]]
	},
	{
		id: "1TRI10",
		zh: "孔雀王朝",
		en: "Mauryans",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每有2张牌\n在历史中，\n1VP", "1VP per 2 cards in history"],
		hdr: "pin",
		box: "c",
		pc: 4,
		text: [["至日：选择：获取2{material}，*或*从你的弃牌堆中\n放回1{region}到你的手牌中。"], ["Solstice: choose: gain 2{material} OR return a {region} from your discard pile to your hand."]]
	},
	{
		id: "1TRI11",
		zh: "赫梯",
		en: "Hittites",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "c",
		pc: 1,
		text: [["突破{region}。", "将本牌放入你的历史。"], ["Break through for {region}.", "Put this card into your history."]]
	},
	{
		id: "2FAM1",
		zh: "至高",
		en: "Imperial",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，8VP，否则2VP", "8VP if in history, 2VP otherwise"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["选择：突破{uncivilised}/{civilised}/{region}/{tributary}\n（你可以选择1张被放逐的牌），\n*或*将本牌放入你的历史。"], ["Choose: break through for {uncivilised}/{civilised}/{region}/{tributary} (you MAY choose an exiled card) OR put this card into your history."]]
	},
	{
		id: "2FAM2",
		zh: "独立",
		en: "Independent",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。获取3{material}和2{population}。"], ["Free play. Gain 3{material} and 2{population}."]]
	},
	{
		id: "2FAM3",
		zh: "壮丽",
		en: "Magnificent",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 5,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。抽取1张牌。", "你*可以*放回1{unrest}。"], ["Free play. Draw a card.", "You MAY return an {unrest}."]]
	},
	{
		id: "2FAM4",
		zh: "杰出",
		en: "Outstanding",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 7,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。\n从你的弃牌堆中将最多2张牌放入你的历史。"], ["Free play. Put up to 2 cards from your discard pile into your history."]]
	},
	{
		id: "2FAM5",
		zh: "骄傲",
		en: "Proud",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若已进驻，\n12VP。\n若在历史中，\n8VP。\n否则3VP", "12 VP if garrisoned, 8VP if in history, 3VP otherwise"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [[
			"不能被打出。",
			"^",
			"^"
		], [
			"Cannot be played.",
			"^",
			"^"
		]]
	},
	{
		id: "2FAM6",
		zh: "骄傲",
		en: "Proud",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若已进驻，\n12VP。\n若在历史中，\n8VP。\n否则3VP", "12 VP if garrisoned, 8VP if in history, 3VP otherwise"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [[
			"不能被打出。",
			"^",
			"^"
		], [
			"Cannot be played.",
			"^",
			"^"
		]]
	},
	{
		id: "2FAM7",
		zh: "显赫",
		en: "Eminent",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 8,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。抽取2张牌。"], ["Free play. Draw 2 cards."]]
	},
	{
		id: "2FAM8",
		zh: "赞誉",
		en: "Acclaimed",
		s: ["fame"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{variable}牌\n（包括本牌）\n1VP", "1VP per {variable} card (including this one)"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [[
			"突破1{variable}牌。",
			"将本牌放入你的历史。",
			"^"
		], [
			"Break through for a {variable} card.",
			"Put this card into your history.",
			"^"
		]]
	},
	{
		id: "2UNC1",
		zh: "开采",
		en: "Mining",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 4,
		text: [["耗竭：舍弃1{region}以获取1{progress}。", "若被舍弃的牌没有{production}，获取额外1{progress}。"], ["Exhaust: abandon a {region} to gain 1{progress}.", "If the abandoned card has no {production}, gain an additional {progress}."]]
	},
	{
		id: "2UNC2",
		zh: "翡翠面具",
		en: "Jade Mask",
		s: ["uncivilised"],
		t: ["mask"],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "2UNC3",
		zh: "长老",
		en: "Elders",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["选择：购得{uncivilised}，*或*突破{uncivilised}且\n所有其他玩家获取1{progress}。"], ["Choose: acquire {uncivilised} OR break through for {uncivilised} and all other players gain 1{progress}."]]
	},
	{
		id: "2UNC4",
		zh: "刺探",
		en: "Espionage",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [["将1张牌放到你的抽牌库顶以\n购得{uncivilised}/{civilised}/{region}/{tributary}。", "每位其他玩家召回1{pinned}。"], ["Place a card on the top of your draw deck to acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Each other player recalls a {pinned}."]]
	},
	{
		id: "2UNC5",
		zh: "入侵",
		en: "Invasion",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [["支付3{material}。每位其他玩家拿取{unrest}。", "选择：突破{tributary}，*或*突破{region}且每位\n其他玩家召回1{region}。"], ["Pay 3{material}. Each other player takes {unrest}.", "Choose: break through for {tributary} OR break through for {region} and each other player recalls a {region}."]]
	},
	{
		id: "2UNC6",
		zh: "丰碑",
		en: "Monument",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：免费打出1{unrest}。"], ["Exhaust: free play an {unrest}."]]
	},
	{
		id: "2UNC7",
		zh: "法典",
		en: "Code of Laws",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：抽取1张牌。"], ["Exhaust: draw a card."]]
	},
	{
		id: "2UNC8",
		zh: "信仰",
		en: "Religion",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：获取1行动。", "至日：选择：拿取{unrest}，*或*支付3{material}。"], ["Exhaust: gain 1 action.", "Solstice: choose: take {unrest} OR pay 3{material}."]]
	},
	{
		id: "2UNC9",
		zh: "神谕",
		en: "Oracle",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 0,
		vpt: ["每{fame}2VP", "2VP per {fame}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。抽取2张牌并弃置其中1张。"], ["Free play. Draw 2 cards and discard one of them."]]
	},
	{
		id: "2UNC10",
		zh: "驯化",
		en: "Domestication",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{fertile}2VP", "2VP per {fertile}"],
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：当你从在场的{fertile}获取{material}时，\n耗竭本牌以获取1{progress}。"], ["Exhaust: when you gain {material} from a {fertile} in play, exhaust this card to gain 1{progress}."]]
	},
	{
		id: "2UNC11",
		zh: "水车",
		en: "Water Mill",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{fertile}/{river}1VP", "1VP per {fertile}/{river}"],
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：选择：召回1{fertile}以获取2{material}和1{population}，\n*或*召回1{river}以获取1行动。"], ["Exhaust: choose: recall a {fertile} to gain 2{material} and 1{population} OR recall a {river} to gain 1 action."]]
	},
	{
		id: "2UNC12",
		zh: "暗渠",
		en: "Qanat",
		s: ["uncivilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{river}2VP", "2VP per {river}"],
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：在本回合的剩余时间内，\n将1{river}视为3{production}。"], ["Exhaust: treat 1 {river} as 3 {production} for the rest of the turn."]]
	},
	{
		id: "2UNC13",
		zh: "仪式与典礼",
		en: "Rituals & Ceremonies",
		s: ["uncivilised"],
		t: [],
		st: "b",
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "l",
		pc: 3,
		text: [["免费打出。选择：放回1{unrest}，\n*或*获取1{progress}且你*可以*放回1{exhaust}到你的国体牌。"], ["Free play. Choose: return an {unrest} OR gain 1{progress} and you MAY return an {exhaust} to your state card."]]
	},
	{
		id: "2UNC14",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 3,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2UNC15",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2UNC16",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2UNC17",
		zh: "城市",
		en: "City",
		s: ["uncivilised", "civilised"],
		t: ["city"],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2UNC18",
		zh: "道路建设",
		en: "Road Building",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["被动：你的“征服”牌失去{barbarian}图标。", "至日：获取2{material}。"], ["Passive: your [Conquer] cards lose the {barbarian} icon.", "Solstice: gain 2{material}."]]
	},
	{
		id: "2UNC19",
		zh: "艺术",
		en: "Art",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["至日：若{barbarian}，你*可以*支付1{material}以放回1{unrest}。\n若{empire}，你*可以*支付3{material}以获取1{progress}。"], ["Solstice: if {barbarian}, you MAY pay 1{material} to return an {unrest}. If {empire}, you MAY pay 3{material} to gain 1{progress}."]]
	},
	{
		id: "2UNC20",
		zh: "外交",
		en: "Diplomacy",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["支付3{material}以突破{tributary}。"], ["Pay 3{material} to break through for {tributary}."]]
	},
	{
		id: "2UNC21",
		zh: "领导",
		en: "Leadership",
		s: ["uncivilised", "civilised"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。选择：抽取1张牌，\n*或*从你的手牌或弃牌堆中\n将1张牌放入你的历史。"], ["Free play. Choose: draw a card OR put a card from your hand or discard pile into your history."]]
	},
	{
		id: "2UNC22",
		zh: "失落古卷",
		en: "Lost Scroll",
		s: ["uncivilised", "civilised"],
		t: ["scroll"],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		box: "l",
		pc: 3,
		text: [["免费打出。你*可以*从你的弃牌堆中\n放回1张牌到你的牌库顶。", "所有玩家*可以*抽取1张牌。"], ["Free play. You MAY return a card from your discard pile to the top of your deck.", "All players MAY draw a card."]]
	},
	{
		id: "2CIV1",
		zh: "戏剧与诗歌",
		en: "Drama & Poetry",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "l",
		pc: 4,
		text: [["免费打出。从每位其他玩家处窃取1{progress}。\n每位玩家*可以*弃置1张牌以放回1{unrest}。"], ["Free play. Steal 1{progress} from each other player. Each player MAY discard a card to return an {unrest}."]]
	},
	{
		id: "2CIV2",
		zh: "教育",
		en: "Education",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。你*可以*从你的手牌中\n将1张牌放入你的历史。", "你*可以*从你的弃牌堆中将1张牌\n放入你的历史。"], ["Free play. You MAY put a card from your hand into your history.", "You MAY put a card from your discard pile into your history."]]
	},
	{
		id: "2CIV3",
		zh: "放债者",
		en: "Moneylenders",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每10{material}1VP", "1VP per 10{material}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。支付3{material}以获取1行动。"], ["Free play. Pay 3{material} to gain 1 action."]]
	},
	{
		id: "2CIV4",
		zh: "腐败",
		en: "Corruption",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [[
			"所有玩家获取2{material}。",
			"所有其他玩家拿取{unrest}。",
			"获取1{progress}。"
		], [
			"All players gain 2{material}.",
			"All other players take {unrest}.",
			"Gain 1{progress}."
		]]
	},
	{
		id: "2CIV5",
		zh: "投石车",
		en: "Onager",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{city}。",
			"每舍弃1{city}就获取2{material}。",
			"你*可以*购得{region}/{tributary}。"
		], [
			"Each other player abandons a {city}.",
			"Gain 2{material} per abandoned {city}.",
			"You MAY acquire {region}/{tributary}."
		]]
	},
	{
		id: "2CIV6",
		zh: "首都",
		en: "Metropolis",
		s: ["civilised"],
		t: ["metropolis"],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2CIV7",
		zh: "天文学",
		en: "Astronomy",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：当你购得{region}时，耗竭本牌以获取1{progress}。", "至日：你*可以*从你的弃牌堆中\n放回1{region}到你的手牌。"], ["Exhaust: when you acquire {region}, exhaust this card to gain 1{progress}.", "Solstice: you MAY return a {region} from your discard pile to your hand."]]
	},
	{
		id: "2CIV8",
		zh: "制图学",
		en: "Cartography",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "l",
		pc: 3,
		text: [["被动：你可以购得被放逐的{region}/{tributary}牌\n（如同它们在市场中一样）。", "记住，当你购得1张被放逐的{tributary}牌时，\n你必须拿取{unrest}。"], ["Passive: you can acquire exiled {region}/{tributary} cards as though they were in the market.", "Remember that when you acquire an exiled {tributary} card, you must take {unrest}."]]
	},
	{
		id: "2CIV9",
		zh: "石工",
		en: "Masonry",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每{city}/{metropolis}在你的游戏区中，2VP", "2VP per {city}/{metropolis} in your play area"],
		hdr: "pin",
		box: "l",
		pc: 4,
		text: [["被动：你能够免费打出{city}和{metropolis}牌。"], ["Passive: you can free play {city} and {metropolis} cards."]]
	},
	{
		id: "2CIV10",
		zh: "行政系统",
		en: "Civil Service",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "至日：获取2{material}。"], ["Passive: increase your hand size by 1.", "Solstice: gain 2{material}."]]
	},
	{
		id: "2CIV11",
		zh: "出口",
		en: "Exports",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每10张牌1VP", "1VP per 10 cards"],
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [["所有玩家获取2{material}。", "从你的手牌或弃牌堆中给予\n每位其他玩家1张牌。"], ["All players gain 2{material}.", "Give each other player a card from your hand or discard pile."]]
	},
	{
		id: "2CIV12",
		zh: "城市发展",
		en: "Urban Development",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每{city}/{metropolis}2VP", "2VP per {city}/{metropolis}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["每有1{city}/{metropolis}在你的游戏区中，\n就获取1{material}和1{population}。"], ["Gain 1{material} and 1{population} per {city}/{metropolis} in your play area."]]
	},
	{
		id: "2CIV13",
		zh: "佣兵",
		en: "Mercenaries",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每4{population}1VP", "1VP per 4{population}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["免费打出。支付1{population}以获取1行动。"], ["Free play. Pay 1{population} to gain 1 action."]]
	},
	{
		id: "2CIV14",
		zh: "圆形竞技场",
		en: "Amphitheatre",
		s: ["civilised"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每5{progress}1VP", "1VP per 5{progress}"],
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：从你的弃牌堆中放回1{unrest}以获取1{progress}。", "至日：弃置1张牌。"], ["Exhaust: return an {unrest} from your discard pile to gain 1{progress}.", "Solstice: discard a card."]]
	},
	{
		id: "2CIV15",
		zh: "重甲骑兵",
		en: "Cataphract",
		s: ["civilised"],
		t: ["knight"],
		st: "e",
		loc: "common",
		vp: 2,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{region}。",
			"你*可以*购得{region}/{tributary}。",
			"你*可以*将本牌进驻到1{region}以触发\n那张牌的打出效果。"
		], [
			"Each other player abandons a {region}.",
			"You MAY acquire {region}/{tributary}.",
			"You MAY garrison this card in a {region} to trigger that card's play effect."
		]]
	},
	{
		id: "2REG1",
		zh: "庇佑之岛",
		en: "Fortunate Isle",
		s: ["region"],
		t: [],
		st: "b",
		loc: "common",
		vp: 2,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["购得{uncivilised}/{civilised}/{region}/{tributary}。", "放逐本牌。"], ["Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Exile this card."]]
	},
	{
		id: "2REG2",
		zh: "雨林",
		en: "Rainforest",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"获取1{population}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{population}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG3",
		zh: "山脉",
		en: "Mountain",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"获取2{material}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 2{material}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG4",
		zh: "半岛",
		en: "Peninsula",
		s: ["region"],
		t: [
			"production",
			"production",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"抽取2张牌。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Draw 2 cards.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG5",
		zh: "湖泊",
		en: "Lakes",
		s: ["region"],
		t: [
			"production",
			"river",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中将1张牌\n放入你的历史。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You MAY put a card from your discard pile into your history.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG6",
		zh: "高原",
		en: "Highlands",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"至日：获取2{population}并弃置1张牌。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Solstice: gain 2{population} and discard a card."
		]]
	},
	{
		id: "2REG7",
		zh: "神圣园林",
		en: "Sacred Grove",
		s: ["region"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每有1位玩家{progress}少于你，2VP", "2VP per player with fewer {progress} than you"],
		hdr: "none",
		box: "l",
		pc: 3,
		text: [["获取1{progress}。你*可以*从的手牌中\n将1张牌放入你的历史。", "将本牌放入你的历史。"], ["Gain 1{progress}. You MAY put a card from your hand into your history.", "Put this card into your history."]]
	},
	{
		id: "2REG8",
		zh: "低地",
		en: "Lowlands",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"至日：获取3{material}并弃置1张牌。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Solstice: gain 3{material} and discard a card."
		]]
	},
	{
		id: "2REG9",
		zh: "荒沼",
		en: "Moor",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中放回1张\n你选择的牌到你的抽牌库顶。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You may return a card of your choice from your discard pile to the top of your draw deck.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG10",
		zh: "平原",
		en: "Plain",
		s: ["region"],
		t: [
			"production",
			"production",
			"fertile"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"获取1{progress}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{progress}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG11",
		zh: "群岛",
		en: "Archipelago",
		s: ["region"],
		t: [
			"production",
			"fertile",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"你*可以*从你的弃牌堆中将1张牌\n放入你的历史。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"You MAY put a card from your discard pile into your history.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2REG12",
		zh: "驻防区",
		en: "Fortified Region",
		s: ["region"],
		t: [],
		st: null,
		loc: "common",
		vp: 1,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"耗竭：当另一位玩家打出1{attack}时，\n你*可以*耗竭本牌并支付1{population}以回避\n其效果（即使是另一位玩家的回合）。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Exhaust: when another player plays an {attack}, you MAY exhaust this card and pay 1{population} to avoid its effects (even if it's another player's turn)."
		]]
	},
	{
		id: "2REG13",
		zh: "草原",
		en: "Grassland",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。",
			"至日：抽取1张牌并弃置1张牌。"
		], [
			"Exile a card from the market.",
			"You MAY garrison a card.",
			"Solstice: draw a card and discard a card."
		]]
	},
	{
		id: "2REG14",
		zh: "海岛",
		en: "Island",
		s: ["region"],
		t: [
			"production",
			"fertile",
			"river"
		],
		st: null,
		loc: "common",
		vp: 0,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [[
			"抽取1张牌。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Draw a card.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "2TRI1",
		zh: "伊特鲁里亚",
		en: "Etruscans",
		s: ["tributary"],
		t: [],
		st: "b",
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["获取2{progress}。"], ["Gain 2{progress}."]]
	},
	{
		id: "2TRI2",
		zh: "斯基泰",
		en: "Scythians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "pin",
		box: "l",
		pc: 1,
		text: [["耗竭：当另一位玩家打出1{attack}时，\n你*可以*耗竭本牌以回避其效果\n（即使是另一位玩家的回合）。"], ["Exhaust: when another player plays an {attack}, you MAY exhaust this card to avoid its effects (even if it's another player's turn)."]]
	},
	{
		id: "2TRI3",
		zh: "维京",
		en: "Vikings",
		s: ["tributary"],
		t: [],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每2{uncivilised}牌1VP", "1VP per 2 {uncivilised} cards"],
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [[
			"获取2{material}。",
			"从每位其他玩家处窃取2{material}。",
			"如有玩家不能支付，则该玩家拿取{unrest}。"
		], [
			"Gain 2{material}.",
			"Steal 2{material} from each other player.",
			"Anyone unable to pay takes {unrest}."
		]]
	},
	{
		id: "2TRI4",
		zh: "腓尼基",
		en: "Phoenicians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["购得{civilised}。", "将本牌放入你的历史。"], ["Acquire {civilised}.", "Put this card into your history."]]
	},
	{
		id: "2TRI5",
		zh: "罗马",
		en: "Romans",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "none",
		box: "l",
		pc: 3,
		text: [[
			"舍弃1{region}以抽取顶部的{fame}牌。",
			"放逐本牌。",
			"所有其他玩家获取1{progress}。"
		], [
			"Abandon a {region} to draw the top {fame} card.",
			"Exile this card.",
			"All other players gain 1{progress}."
		]]
	},
	{
		id: "2TRI6",
		zh: "希腊",
		en: "Greeks",
		s: ["tributary"],
		t: ["metropolis"],
		st: "e",
		loc: "common",
		vp: 0,
		vpt: ["每10张牌1VP", "1VP per 10 cards"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "2TRI7",
		zh: "迦太基",
		en: "Carthaginians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每10{material}1VP", "1VP per 10{material}"],
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [["获取2{material}并抽取1张牌。", "从你的手牌或弃牌堆中给予\n每位其他玩家1张牌。"], ["Gain 2{material} and draw a card.", "Give each other player a card from your hand or discard pile."]]
	},
	{
		id: "2TRI8",
		zh: "波斯",
		en: "Persians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{tributary}1VP", "1VP per {tributary}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["支付2{population}以突破{tributary}。", "将本牌放入你的历史。"], ["Pay 2{population} to break through for {tributary}.", "Put this card into your history."]]
	},
	{
		id: "2TRI9",
		zh: "凯尔特",
		en: "Celts",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 3,
		hdr: "atk",
		box: "l",
		pc: 1,
		text: [["突破{uncivilised}。", "每位其他玩家拿取{unrest}。"], ["Break through for {uncivilised}.", "Each other player takes {unrest}."]]
	},
	{
		id: "2TRI10",
		zh: "马其顿",
		en: "Macedonians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每4{region}1VP", "1VP per 4 {region}"],
		hdr: "none",
		box: "l",
		pc: 1,
		text: [["购得{region}两次（包括从被放逐的牌中）。", "将本牌放入你的历史。"], ["Acquire {region} twice (including from exiled cards).", "Put this card into your history."]]
	},
	{
		id: "2TRI11",
		zh: "匈奴",
		en: "Xiongnu",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "common",
		vp: 0,
		vpt: ["每{fame}1VP", "1VP per {fame}"],
		hdr: "atk",
		box: "l",
		pc: 4,
		text: [["从每位其他玩家处窃取1{progress}。"], ["Steal 1{progress} from each other player."]]
	},
	{
		id: "CAR1A",
		zh: "迦太基",
		en: "Carthaginians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每6{material}1VP", "1VP per 6{material}"],
		hdr: "powA",
		nat: "carthaginians",
		pc: 1,
		text: [["被动：当你将要放置1{progress}到市场中的一张牌上时，\n改为放置1{material}。", "耗竭：当你从市场中获取1张其上放有{material}的卡牌时，\n获取的{material}加倍。"], ["Passive: when you would place 1{progress} on a card in the market, instead place 1{material}.", "Exhaust: when you gain a card from the market with {material} on it, double the {material} gained."]]
	},
	{
		id: "CAR1B",
		zh: "迦太基",
		en: "Carthaginians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每3{material}1VP", "1VP per 3{material}"],
		hdr: "powB",
		nat: "carthaginians",
		pc: 1,
		text: [["被动：当你将要放置1{progress}到市场中的一张牌上时，\n改为放置2{material}。"], ["Passive: when you would place 1{progress} on a card in the market, instead place 2{material}."]]
	},
	{
		id: "CAR2",
		zh: "迦太基城",
		en: "City of Carthage",
		s: [],
		t: ["city"],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "CAR3",
		zh: "战象",
		en: "Elephants",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "atk",
		nat: "carthaginians",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{region}。",
			"你*可以*突破{region}/{tributary}。",
			"将本牌放入你的历史。"
		], [
			"Each other player abandons a {region}.",
			"You MAY break through for {region}/{tributary}.",
			"Put this card into your history."
		]]
	},
	{
		id: "CAR4",
		zh: "战象",
		en: "Elephants",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "atk",
		nat: "carthaginians",
		pc: 1,
		text: [[
			"每位其他玩家舍弃1{region}。",
			"你*可以*突破{region}/{tributary}。",
			"将本牌放入你的历史。"
		], [
			"Each other player abandons a {region}.",
			"You MAY break through for {region}/{tributary}.",
			"Put this card into your history."
		]]
	},
	{
		id: "CAR5",
		zh: "霸权",
		en: "Hegemony",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			1,
			0
		],
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["支付2{material}以购得{uncivilised}/{civilised}/{region}/{tributary}。", "所有玩家*可以*抽取1张牌。"], ["Pay 2{material} to acquire {uncivilised}/{civilised}/{region}/{tributary}.", "All players MAY draw a card."]]
	},
	{
		id: "CAR6",
		zh: "汉尼拔",
		en: "Hannibal",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			0,
			4,
			0
		],
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [[
			"你*可以*购得{uncivilised}/{civilised}/{region}/{tributary}。",
			"你*可以*抽取1张牌。",
			"你*可以*从你的历史抽取1张牌。",
			"将本牌放入你的历史。"
		], [
			"You MAY acquire {uncivilised}/{civilised}/{region}/{tributary}.",
			"You MAY draw a card.",
			"You MAY draw a card from your history.",
			"Put this card into your history."
		]]
	},
	{
		id: "CAR7",
		zh: "商船",
		en: "Trading Ships",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			4,
			1,
			0
		],
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["耗竭：你*可以*召回1{river}或1{fertile}以购得\n市场中的1张其上放有{material}的卡牌。"], ["Exhaust: you MAY recall a {river} or a {fertile} to acquire a card in the market that has {material} on it."]]
	},
	{
		id: "CAR8",
		zh: "垄断",
		en: "Monopoly",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每5{material}1VP", "1VP per 5{material}"],
		dev: [
			7,
			0,
			0
		],
		hdr: "atk",
		nat: "carthaginians",
		pc: 1,
		text: [["获取2{material}并抽取1张牌。", "从你的手牌或弃牌堆中给予\n每位其他玩家1张牌。"], ["Gain 2{material} and draw a card.", "Give each other player a card from your hand or discard pile."]]
	},
	{
		id: "CAR9",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "CAR10",
		zh: "商队",
		en: "Caravans",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["耗竭：支付3{material}并弃置1张牌以购得\n市场中的1张其上放有{material}的牌。"], ["Exhaust: pay 3{material} and discard a card to acquire a card in the market that has {material} on it."]]
	},
	{
		id: "CAR11",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "CAR12",
		zh: "伊比利亚",
		en: "Iberia",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "CAR13",
		zh: "柏柏尔",
		en: "Berbers",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["获取2{population}。"], ["Gain 2{population}."]]
	},
	{
		id: "CAR14",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "CAR15",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "CAR16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "CAR17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "CAR18",
		zh: "狄多，迦太基女王",
		en: "Dido, Queen of Carthage",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [[
			"获取1{population}。",
			"你*可以*购得{region}并立即免费打出它。",
			"将本牌放入你的历史。"
		], [
			"Gain 1{population}.",
			"You MAY acquire {region} and free play it immediately.",
			"Put this card into your history."
		]]
	},
	{
		id: "CAR19",
		zh: "迦太基商人",
		en: "Carthaginian Traders",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["免费打出。添加1{material}到市场中的1张牌上。", "你*可以*从你的手牌或弃牌堆中\n将1张牌放入你的历史。"], ["Free play. Add 1{material} to a card in the market.", "You MAY put a card from your hand or discard pile into your history."]]
	},
	{
		id: "CAR20",
		zh: "巴利亚里群岛",
		en: "Balearic Islands",
		s: ["region"],
		t: [
			"production",
			"production",
			"river"
		],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "CAR21",
		zh: "毛里塔尼亚",
		en: "Mauretania",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "carthaginians",
		pc: 1,
		text: [["获取2{material}。", "你*可以*进驻1张牌。"], ["Gain 2{material}.", "You MAY garrison a card."]]
	},
	{
		id: "CAR22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CAR23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "carthaginians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL1A",
		zh: "凯尔特",
		en: "Celts",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{uncivilised}1VP", "1VP per {uncivilised}"],
		hdr: "powA",
		nat: "celts",
		pc: 1,
		text: [["耗竭：当你购得{uncivilised}*或*突破{uncivilised}时，耗竭本牌。", "每位其他玩家拿取{unrest}。"], ["Exhaust: when you acquire {uncivilised} or break through for {uncivilised}, exhaust this card.", "Each other player takes {unrest}."]]
	},
	{
		id: "CEL1B",
		zh: "凯尔特",
		en: "Celts",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{uncivilised}2VP", "2VP per {uncivilised}"],
		hdr: "powB",
		nat: "celts",
		pc: 1
	},
	{
		id: "CEL2",
		zh: "凯尔特黄金",
		en: "Celtic Gold",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["每位其他玩家获取1{material}。", "每有1{fertile}在你的游戏区中，就获取4{material}。"], ["Each other player gains 1{material}.", "Gain 4{material} per {fertile} in your play area."]]
	},
	{
		id: "CEL3",
		zh: "凯尔特创新",
		en: "Celtic Innovation",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			2,
			2,
			0
		],
		hdr: "atk",
		nat: "celts",
		pc: 1,
		text: [["你*可以*购得{uncivilised}/{civilised}。", "每位其他玩家拿取{unrest}。"], ["You MAY acquire {uncivilised}/{civilised}.", "Each other player takes {unrest}."]]
	},
	{
		id: "CEL4",
		zh: "链甲",
		en: "Chainmail",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			3,
			1,
			0
		],
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["被动：当你打出1{attack}时，获取1{progress}。"], ["Passive: when you play an {attack}, gain 1{progress}."]]
	},
	{
		id: "CEL5",
		zh: "战车",
		en: "Chariots",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			0,
			3,
			0
		],
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["被动：你可以购得被放逐的{region}。", "你的“征服”和{attack}牌失去{barbarian}图标。"], ["Passive: you may acquire exiled {region}.", "Your [Conquer] and {attack} cards lose the {barbarian} icon."]],
		rel: ["CEL8", "CEL17"]
	},
	{
		id: "CEL6",
		zh: "欧甘字母",
		en: "Ogham Script",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			2,
			2,
			0
		],
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "耗竭：你*可以*从你的手牌中将1张牌\n放入你的历史。你*可以*从你的弃牌堆中\n将1张牌放入你的历史。"], ["Passive: increase your hand size by 1.", "Exhaust: you MAY put a card from your hand into your history. You MAY put a card from your discard pile into your history."]]
	},
	{
		id: "CEL7",
		zh: "维钦托利",
		en: "Vercingetorix",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每{uncivilised}1VP", "1VP per {uncivilised}"],
		dev: [
			4,
			0,
			0
		],
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["你*可以*购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["You MAY acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "CEL8",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "CEL9",
		zh: "阿莫里卡",
		en: "Armorica",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "CEL10",
		zh: "贝尔吉卡",
		en: "Belgica",
		s: ["region"],
		t: ["river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["你*可以*抽取1张牌。", "你*可以*进驻1张牌。"], ["You MAY draw a card.", "You MAY garrison a card."]]
	},
	{
		id: "CEL11",
		zh: "不列颠尼亚",
		en: "Britannia",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "CEL12",
		zh: "希伯尼亚",
		en: "Hibernia",
		s: ["region"],
		t: ["fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["你*可以*从你的弃牌堆中抽取1张牌。", "你*可以*进驻1张牌。"], ["You MAY draw a card from your discard pile.", "You MAY garrison a card."]]
	},
	{
		id: "CEL13",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL14",
		zh: "德鲁伊",
		en: "Druids",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：获取1{progress}，*或*支付1{population}以突破{uncivilised}，\n*或*放回1{unrest}以获取1{population}。"], ["Choose: gain 1{progress} OR pay 1{population} to break through for {uncivilised} OR return an {unrest} to gain 1{population}."]]
	},
	{
		id: "CEL15",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "CEL16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "CEL17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "CEL18",
		zh: "布迪卡",
		en: "Boudicca",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "celts",
		pc: 1,
		text: [[
			"获取1{progress}。",
			"每位其他玩家舍弃1{region}。",
			"将本牌放入你的历史。"
		], [
			"Gain 1{progress}.",
			"Each other player abandons a {region}.",
			"Put this card into your history."
		]]
	},
	{
		id: "CEL19",
		zh: "劫掠牲畜",
		en: "Cattle Raid",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "celts",
		pc: 1,
		text: [["获取2{material}。\n从每位至少有1{region}在场的玩家处窃取1{material}。", "从每位{empire}玩家处窃取1{progress}。"], ["Gain 2{material}. Steal 1{material} from each player with at least one {region} in play.", "Steal 1{progress} from each {empire} player."]]
	},
	{
		id: "CEL20",
		zh: "凯丽德温的大锅",
		en: "Cauldron of Cerridwen",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["耗竭：支付1{progress}以获取2{population}。"], ["Exhaust: pay 1{progress} to gain 2{population}."]]
	},
	{
		id: "CEL21",
		zh: "凯尔提卡",
		en: "Celtica",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "celts",
		pc: 1,
		text: [["你*可以*从你的弃牌堆中选择1张牌\n放到你的牌库顶。", "你*可以*进驻1张牌。"], ["You MAY place a card of your choice from your discard pile on the top of your deck.", "You MAY garrison a card."]]
	},
	{
		id: "CEL22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 3,
		text: [["设置：若“凯尔特”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Celts are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL25",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 3,
		text: [["设置：若“凯尔特”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Celts are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL26",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 4,
		text: [["设置：若“凯尔特”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Celts are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL27",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 4,
		text: [["设置：若“凯尔特”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Celts are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "CEL28",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "celts",
		pc: 4,
		text: [["设置：若“凯尔特”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Celts are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "GRE1A",
		zh: "希腊",
		en: "Greeks",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每7张牌1VP", "1VP per 7 cards"],
		hdr: "powA",
		nat: "greeks",
		pc: 1,
		text: [["耗竭：花费2行动以突破{uncivilised}/{civilised}。"], ["Exhaust: spend 2 actions to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "GRE1B",
		zh: "希腊",
		en: "Greeks",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每3张牌1VP", "1VP per 3 cards"],
		hdr: "powB",
		nat: "greeks",
		pc: 1
	},
	{
		id: "GRE2",
		zh: "奥林匹克运动会",
		en: "Olympic Games",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["抽取2张牌。\n从你的手牌中将1张牌放入你的历史。"], ["Draw 2 cards. Put a card from your hand into your history."]]
	},
	{
		id: "GRE3",
		zh: "希腊繁荣",
		en: "Greek Prosperity",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			2,
			0
		],
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{production}，\n*或*你每有1{city}/{metropolis}在场就抽取1张牌。"], ["Choose: gain 1{material} per {production} OR gain 1{population} per {region} OR draw a card per {city}/{metropolis} in play."]]
	},
	{
		id: "GRE4",
		zh: "伯里克利",
		en: "Pericles",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			0
		],
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["免费打出。购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Free play. Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "GRE5",
		zh: "科林斯城",
		en: "City of Corinth",
		s: [],
		t: ["city"],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			0
		],
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "GRE6",
		zh: "科学",
		en: "Science",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			0
		],
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "你的“进步”牌失去{barbarian}图标。"], ["Passive: increase your hand size by 1.", "Your [Advance] cards lose the {barbarian} icon."]],
		rel: ["GRE16"]
	},
	{
		id: "GRE7",
		zh: "希腊创新",
		en: "Greek Innovation",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			0
		],
		hdr: "atk",
		nat: "greeks",
		pc: 1,
		text: [["将2张牌放到你的牌库顶以\n购得{uncivilised}/{civilised}/{region}/{tributary}。", "每位其他玩家召回1{pinned}。"], ["Place 2 cards on top of your deck to acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Each other player recalls a {pinned}."]]
	},
	{
		id: "GRE8",
		zh: "直接选举",
		en: "Direct Democracy",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			0
		],
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["被动：打出1{unrest}的{material}或卡牌费用减少1（最低为1）。", "耗竭：免费打出1{unrest}。"], ["Passive: reduce the cost in {material} or cards to play an {unrest} by 1 (to a minimum of 1).", "Exhaust: free play an {unrest}."]]
	},
	{
		id: "GRE9",
		zh: "灯塔",
		en: "Lighthouse",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			5,
			0,
			0
		],
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["耗竭：选择：\n从你的弃牌堆中将1{attack}放到你的牌库顶，\n*或*将1张被放逐的牌与市场中的1张牌交换。"], ["Exhaust: choose: place an {attack} from your discard pile on the top of your deck OR swap an exiled card with a card in the market."]]
	},
	{
		id: "GRE10",
		zh: "哲学",
		en: "Philosophy",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每5张牌1VP", "1VP per 5 cards"],
		dev: [
			6,
			0,
			0
		],
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["舍弃1{pinned}（不能是{region}）以突破{uncivilised}/{civilised}。"], ["Abandon a {pinned} (not a {region}) to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "GRE11",
		zh: "雅典城",
		en: "City of Athens",
		s: [],
		t: ["city"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "GRE12",
		zh: "色萨利平原",
		en: "Plains of Thessaly",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["获取1{material}。", "你*可以*进驻1张牌。"], ["Gain 1{material}.", "You MAY garrison a card."]]
	},
	{
		id: "GRE13",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "GRE14",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "GRE15",
		zh: "希腊佣兵",
		en: "Greek Mercenaries",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "greeks",
		pc: 1,
		text: [[
			"获取1{progress}。抽取1张牌。",
			"从每位其他玩家处窃取2{material}。",
			"每位其他玩家获取1{population}。"
		], [
			"Gain 1{progress}. Draw a card.",
			"Steal 2{material} from each other player.",
			"Each other player gains 1{population}."
		]]
	},
	{
		id: "GRE16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "GRE17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "GRE18",
		zh: "移民",
		en: "Settlers",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付1{population}以购得{region}，\n*或*获取1{progress}，*或*放回1{unrest}。"], ["Choose: pay 1{population} to acquire {region} OR gain 1{progress} OR return an {unrest}."]]
	},
	{
		id: "GRE19",
		zh: "斯巴达城",
		en: "City of Sparta",
		s: [],
		t: ["city"],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "GRE20",
		zh: "伯罗奔尼撒",
		en: "Peloponnese",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "GRE21",
		zh: "福罗厄森林",
		en: "Forest of Pholoe",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "greeks",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "GRE22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "GRE23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "greeks",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAC1A",
		zh: "马其顿",
		en: "Macedonians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每2{region}1VP", "1VP per 2 {region}"],
		hdr: "powA",
		nat: "macedonians",
		pc: 1,
		text: [["被动：当你从你的弃牌堆中打出1{region}时，获取2{material}。"], ["Passive: when you play a {region} from your discard pile, gain 2{material}."]],
		rel: ["MAC17"]
	},
	{
		id: "MAC1B",
		zh: "马其顿",
		en: "Macedonians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{region}1VP", "1VP per {region}"],
		hdr: "powB",
		nat: "macedonians",
		pc: 1
	},
	{
		id: "MAC2",
		zh: "亚历山大",
		en: "Alexander",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [[
			"抽取1张牌。",
			"你*可以*突破{region}/{tributary}。",
			"将本牌放入你的历史。"
		], [
			"Draw a card.",
			"You MAY break through for {region}/{tributary}.",
			"Put this card into your history."
		]]
	},
	{
		id: "MAC3",
		zh: "发展",
		en: "Development",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			1,
			0
		],
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：发展，*或*支付2{material}以购得{uncivilised}/{civilised}。"], ["Choose: develop OR pay 2{material} to acquire {uncivilised}/{civilised}."]]
	},
	{
		id: "MAC4",
		zh: "帕曼纽",
		en: "Parmenion",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			2,
			0
		],
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["你*可以*购得{region}/{tributary}并立即免费打出它。", "将本牌放入你的历史。"], ["You MAY acquire {region}/{tributary} and immediately free play it.", "Put this card into your history."]]
	},
	{
		id: "MAC5",
		zh: "伙友骑兵",
		en: "Companion Cavalry",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			0,
			3,
			0
		],
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["被动：你的“征服”牌失去{barbarian}图标。", "耗竭：当你打出1{region}时，耗竭本牌以抽取1张牌。"], ["Passive: your [Conquer] cards lose the {barbarian} icon.", "Exhaust: when you play a {region}, exhaust this card to draw a card."]],
		rel: ["MAC14", "MAC15"]
	},
	{
		id: "MAC6",
		zh: "亚历山大大帝",
		en: "Alexander the Great",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			4,
			2,
			0
		],
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [[
			"除非“亚历山大”在你的历史中，\n否则不能被打出。",
			"免费打出。你*可以*购得{region}两次\n（包括从被放逐的牌中）。",
			"将本牌放入你的历史。"
		], [
			"Cannot be played unless [Alexander] is in your history.",
			"Free play. You MAY acquire {region} twice, including from exiled cards.",
			"Put this card into your history."
		]],
		rel: ["MAC2"]
	},
	{
		id: "MAC7",
		zh: "镶嵌壁画",
		en: "Mosaics",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			1,
			0
		],
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["耗竭：支付1{material}以从你的弃牌堆中\n抽取1张牌。"], ["Exhaust: pay 1{material} to draw a card from your discard pile."]]
	},
	{
		id: "MAC8",
		zh: "埃及的亚历山大城",
		en: "Alexandria in Egypt",
		s: [],
		t: ["metropolis"],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			4,
			1,
			0
		],
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "MAC9",
		zh: "阿里亚纳的亚历山大城",
		en: "Alexandria in Ariana",
		s: [],
		t: ["city"],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每2{region}1VP", "1VP per 2 {region}"],
		dev: [
			4,
			2,
			0
		],
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "MAC10",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "MAC11",
		zh: "攸克西亚",
		en: "Uxians",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "atk",
		nat: "macedonians",
		pc: 1,
		text: [["从每位其他玩家处窃取2{material}。", "你*可以*放回1{exhaust}到你的国体牌。"], ["Steal 2{material} from each other player.", "You may return an {exhaust} to your state card."]]
	},
	{
		id: "MAC12",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "MAC13",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "MAC14",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "MAC15",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "MAC16",
		zh: "腓力二世",
		en: "Philip II",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "MAC17",
		zh: "方阵",
		en: "Phalanx",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["耗竭：从你的弃牌堆中打出1{region}\n（照常花费1行动）。"], ["Exhaust: play a {region} from your discard pile (spending an action as normal)."]]
	},
	{
		id: "MAC18",
		zh: "阿利阿克蒙山谷",
		en: "Haliacmon Valley",
		s: ["region"],
		t: ["fertile", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "MAC19",
		zh: "奥雷斯蒂斯",
		en: "Orestis",
		s: ["region"],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["获取2{material}。", "你*可以*进驻1张牌。"], ["Gain 2{material}.", "You MAY garrison a card."]]
	},
	{
		id: "MAC20",
		zh: "佩拉冈尼亚",
		en: "Pelagonia",
		s: ["region"],
		t: ["fertile"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "macedonians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "MAC21",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAC22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAC23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "macedonians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "PER1A",
		zh: "波斯",
		en: "Persians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每3{tributary}1VP", "1VP per 3 {tributary}"],
		hdr: "powA",
		nat: "persians",
		pc: 1,
		text: [["耗竭：花费1行动，将2张牌放到你的牌库顶，\n并支付1{population}以突破{tributary}。"], ["Exhaust: spend an action, place 2 cards on the top of your deck, and pay 1{population} to break through for {tributary}."]]
	},
	{
		id: "PER1B",
		zh: "波斯",
		en: "Persians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{tributary}1VP", "1VP per {tributary}"],
		hdr: "powB",
		nat: "persians",
		pc: 1
	},
	{
		id: "PER2",
		zh: "波斯波利斯城",
		en: "City of Persepolis",
		s: [],
		t: ["city"],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "PER3",
		zh: "攻城槌",
		en: "Battering Ram",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			4,
			0
		],
		hdr: "atk",
		nat: "persians",
		pc: 1,
		text: [["每位其他玩家舍弃1{city}。", "你*可以*突破{region}/{tributary}。"], ["Each other player abandons a {city}.", "You MAY break through for {region}/{tributary}."]]
	},
	{
		id: "PER4",
		zh: "发展",
		en: "Development",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：发展，*或*支付2{material}以购得{uncivilised}/{civilised}。"], ["Choose: develop OR pay 2{material} to acquire {uncivilised}/{civilised}."]]
	},
	{
		id: "PER5",
		zh: "风车",
		en: "Windmills",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			4,
			0,
			0
		],
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["免费打出。耗竭：在本回合的剩余时间内，\n将1{fertile}视为3{production}。"], ["Free play. Exhaust: treat 1 {fertile} as 3 {production} for the rest of the turn."]]
	},
	{
		id: "PER6",
		zh: "总督",
		en: "Satrap",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["免费打出。支付3{material}以获取1行动。"], ["Free play. Pay 3{material} to gain 1 action."]]
	},
	{
		id: "PER7",
		zh: "波斯黄金",
		en: "Persian Gold",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			7,
			0,
			0
		],
		hdr: "atk",
		nat: "persians",
		pc: 1,
		text: [[
			"所有玩家获取2{material}。",
			"你获取1{progress}。",
			"每位其他玩家拿取{unrest}。"
		], [
			"All players gain 2{material}.",
			"You gain 1{progress}.",
			"Each other player takes {unrest}."
		]]
	},
	{
		id: "PER8",
		zh: "巴比伦",
		en: "Babylonians",
		s: ["tributary"],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			0,
			5,
			0
		],
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["免费打出。购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Free play. Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "PER9",
		zh: "大流士一世",
		en: "Darius I",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每{tributary}1VP", "1VP per {tributary}"],
		dev: [
			3,
			2,
			0
		],
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "PER10",
		zh: "阿拉霍西亚",
		en: "Arachosia",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["你*可以*从你的弃牌堆中将1张牌\n放入你的历史。", "你*可以*进驻1张牌。"], ["You MAY put a card from your discard pile into your history.", "You MAY garrison a card."]]
	},
	{
		id: "PER11",
		zh: "尼萨平原",
		en: "Nisaean Plain",
		s: ["region"],
		t: ["fertile", "fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "PER12",
		zh: "米底王国",
		en: "Median Empire",
		s: ["tributary"],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["获取4{material}。", "将本牌放入你的历史。"], ["Gain 4{material}.", "Put this card into your history."]]
	},
	{
		id: "PER13",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "PER14",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "PER15",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "PER16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "PER17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "PER18",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "PER19",
		zh: "巴克特里亚",
		en: "Bactria",
		s: ["region"],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["获取3{material}。", "你*可以*进驻1张牌。"], ["Gain 3{material}.", "You MAY garrison a card."]]
	},
	{
		id: "PER20",
		zh: "扎格罗斯",
		en: "Zagros",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "persians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "PER21",
		zh: "吕底亚",
		en: "Lydians",
		s: ["tributary"],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["获取2{population}。", "将本牌放入你的历史。"], ["Gain 2{population}.", "Put this card into your history."]]
	},
	{
		id: "PER22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "PER23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "persians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ROM1A",
		zh: "罗马",
		en: "Romans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每4{population}1VP", "1VP per 4{population}"],
		hdr: "powA",
		nat: "romans",
		pc: 1,
		text: [["被动：每当你从{fame}牌库查看任意数量的卡牌时，\n额外查看1张牌，然后获取1{progress}。"], ["Passive: whenever you look at any number of cards from the {fame} deck, look at one additional card, then gain 1{progress}."]],
		rel: ["ROM14"]
	},
	{
		id: "ROM1B",
		zh: "罗马",
		en: "Romans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每2{population}1VP", "1VP per 2{population}"],
		hdr: "powB",
		nat: "romans",
		pc: 1
	},
	{
		id: "ROM2",
		zh: "尤利乌斯·凯撒",
		en: "Julius Caesar",
		s: [],
		t: [],
		st: "e",
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["免费打出。选择：抽取2张牌，\n*或*你*可以*购得{region}/{tributary}。", "将本牌放入你的历史。"], ["Free play. Choose: draw 2 cards, OR you MAY acquire {region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "ROM3",
		zh: "军事工程学",
		en: "Military Engineering",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			1,
			0
		],
		hdr: "atk",
		nat: "romans",
		pc: 1,
		text: [["每位其他玩家弃置2张牌。", "你*可以*突破{civilised}。"], ["Each other player discards 2 cards.", "You MAY break through for {civilised}."]]
	},
	{
		id: "ROM4",
		zh: "罗马入侵",
		en: "Roman Invasion",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "atk",
		nat: "romans",
		pc: 1,
		text: [["你*可以*购得{region}/{tributary}。", "每位其他玩家舍弃1{region}。"], ["You MAY acquire {region}/{tributary}.", "Each other player abandons a {region}."]]
	},
	{
		id: "ROM5",
		zh: "军团",
		en: "Legions",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "你的“征服”牌失去{barbarian}图标。"], ["Passive: increase your hand size by 1.", "Your [Conquer] cards lose the {barbarian} icon."]],
		rel: ["ROM17"]
	},
	{
		id: "ROM6",
		zh: "元老院",
		en: "The Senate",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			0,
			0
		],
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["你*可以*购得{civilised}。", "你*可以*从你的手牌中将1张牌\n放入你的历史。"], ["You MAY acquire {civilised}.", "You MAY put a card from your hand into your history."]]
	},
	{
		id: "ROM7",
		zh: "罗马，永恒之城",
		en: "Rome, the Eternal City",
		s: [],
		t: ["metropolis"],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			3,
			3,
			0
		],
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [[
			"仅当“罗马城”在场时才能打出。",
			"将“罗马城”放入你的历史。",
			"至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"
		], [
			"Only playable if [City of Rome] is in play.",
			"Put [City of Rome] into your history.",
			"Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."
		]],
		rel: ["ROM19"]
	},
	{
		id: "ROM8",
		zh: "图拉真大帝",
		en: "Emperor Trajan",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每3{population}1VP", "1VP per 3{population}"],
		dev: [
			2,
			1,
			0
		],
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "ROM9",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "ROM10",
		zh: "面包与马戏",
		en: "Bread and Circuses",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["至日：弃置1张牌。\n你*可以*从你的手牌中放回1{unrest}。\n你*可以*从你的弃牌堆中放回1{unrest}。"], ["Solstice: discard a card. You MAY return an {unrest} from your hand. You MAY return an {unrest} from your discard pile."]]
	},
	{
		id: "ROM11",
		zh: "阿基坦高卢",
		en: "Gallia Aquitania",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "ROM12",
		zh: "雷蒂亚",
		en: "Raetia",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["获取1{material}。", "你*可以*进驻1张牌。"], ["Gain 1{material}.", "You MAY garrison a card."]]
	},
	{
		id: "ROM13",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ROM14",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "ROM15",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "ROM16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "ROM17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "ROM18",
		zh: "三头同盟",
		en: "Triumvirate",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["突破{uncivilised}。", "将本牌放入你的历史。"], ["Break through for {uncivilised}.", "Put this card into your history."]]
	},
	{
		id: "ROM19",
		zh: "罗马城",
		en: "City of Rome",
		s: [],
		t: ["city"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "ROM20",
		zh: "达尔马提亚",
		en: "Dalmatia",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "romans",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "ROM21",
		zh: "罗马扩张",
		en: "Roman Expansion",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "romans",
		pc: 1,
		text: [[
			"购得{region}。你*可以*再次购得{region}。",
			"每位其他玩家召回1{region}。",
			"将本牌放入你的历史。"
		], [
			"Acquire {region}. You MAY acquire {region} again.",
			"Each other player recalls a {region}.",
			"Put this card into your history."
		]]
	},
	{
		id: "ROM22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ROM23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "romans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "SCY1A",
		zh: "斯基泰",
		en: "Scythians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每6{material}1VP", "1VP per 6{material}"],
		hdr: "powA",
		nat: "scythians",
		pc: 1,
		text: [["耗竭：花费1行动并拿取{unrest}以突破{region}。"], ["Exhaust: spend an action and take {unrest} to break through for {region}."]]
	},
	{
		id: "SCY1B",
		zh: "斯基泰",
		en: "Scythians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每3{material}/3{region}1VP", "1VP per 3{material} / 3 {region}"],
		hdr: "powB",
		nat: "scythians",
		pc: 1
	},
	{
		id: "SCY2",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "SCY3",
		zh: "阿提亚斯",
		en: "Ateas",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			0,
			4,
			0
		],
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [[
			"你*可以*购得{region}。",
			"你*可以*放回1{unrest}。",
			"将本牌放入你的历史。"
		], [
			"You MAY acquire {region}.",
			"You MAY return an {unrest}.",
			"Put this card into your history."
		]]
	},
	{
		id: "SCY4",
		zh: "库尔干",
		en: "Kurgans",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "耗竭：从你的弃牌堆中将1张牌放入你的历史。"], ["Passive: increase your hand size by 1.", "Exhaust: put a card from your discard pile into your history."]]
	},
	{
		id: "SCY5",
		zh: "盖洛诺斯城",
		en: "City of Gelonus",
		s: [],
		t: ["city"],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			3,
			0
		],
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "SCY6",
		zh: "金银珠宝",
		en: "Jewellery",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: 7,
		dev: [
			7,
			0,
			0
		],
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["不能被打出。", "不能用于进驻。"], ["Cannot be played.", "Cannot be garrisoned."]]
	},
	{
		id: "SCY7",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "SCY8",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "SCY9",
		zh: "塔木加",
		en: "Tamga",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		vpt: ["每2{region}1VP", "1VP per 2 {region}"],
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["耗竭：弃置1张牌以抽取2张牌。"], ["Exhaust: discard a card to draw 2 cards."]]
	},
	{
		id: "SCY10",
		zh: "黑海大平原",
		en: "Pontic Steppe",
		s: ["region"],
		t: ["production", "fertile"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "SCY11",
		zh: "塔里木盆地",
		en: "Tarim Basin",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["你*可以*抽取1张牌。", "你*可以*进驻1张牌。"], ["You MAY draw a card.", "You MAY garrison a card."]]
	},
	{
		id: "SCY12",
		zh: "高加索",
		en: "Caucasia",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "SCY13",
		zh: "劫掠",
		en: "Raiders",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "atk",
		nat: "scythians",
		pc: 1,
		text: [[
			"免费打出。抽取2张牌。",
			"所有其他玩家召回1{region}。",
			"从每位{empire}玩家处窃取1{population}。"
		], [
			"Free play. Draw 2 cards.",
			"All other players recall a {region}.",
			"Steal 1{population} from each {empire} player."
		]]
	},
	{
		id: "SCY14",
		zh: "游牧民",
		en: "Nomads",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "你每有1{production}在场，就获取1{material}。"], ["All players MAY draw a card.", "Gain 1{material} per {production} you have in play."]]
	},
	{
		id: "SCY15",
		zh: "游牧民",
		en: "Nomads",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "你每有1{production}在场，就获取1{material}。"], ["All players MAY draw a card.", "Gain 1{material} per {production} you have in play."]]
	},
	{
		id: "SCY16",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "SCY17",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "SCY18",
		zh: "喀尔巴阡山脉",
		en: "Carpathian Mountains",
		s: ["region"],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "SCY19",
		zh: "天山",
		en: "Tian Shan",
		s: ["region"],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "SCY20",
		zh: "弓骑兵",
		en: "Mounted Archers",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["耗竭：当另一位玩家打出1{attack}时，\n你*可以*耗竭本牌以回避其效果\n（即使是另一位玩家的回合）。", "至日：你*可以*支付1{material}以获取1{population}。"], ["Exhaust: when another player plays an {attack}, you MAY exhaust this card to avoid its effects (even if it's another player's turn).", "Solstice: you MAY pay 1{material} to gain 1{population}."]]
	},
	{
		id: "SCY21",
		zh: "帐篷",
		en: "Tents",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "scythians",
		pc: 1,
		text: [["耗竭：当你打出1{region}时，耗竭本牌以获取1{population}。", "至日：你*可以*召回1{region}。"], ["Exhaust: when you play a {region}, exhaust this card to gain 1{population}.", "Solstice: you MAY recall a {region}."]]
	},
	{
		id: "SCY22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "SCY23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "SCY24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "scythians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "VIK1A",
		zh: "维京",
		en: "Vikings",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{variable}牌1VP", "1VP per {variable} card"],
		hdr: "powA",
		nat: "vikings",
		pc: 1,
		text: [[
			"被动：将要放入你的历史的卡牌改为弃置。",
			"当你拿取{unrest}时，查看你的国家牌库顶的1张牌。\n你*可以*将它放到国家牌库底。",
			"耗竭：当你放回1{unrest}时，耗竭本牌以抽取2张牌。"
		], [
			"Passive: cards that would be placed into your history are instead discarded.",
			"When you take {unrest}, look at the top card of your nation deck. You MAY place it at the bottom of the nation deck.",
			"Exhaust: when you return an {unrest}, exhaust this card to draw 2 cards."
		]]
	},
	{
		id: "VIK1B",
		zh: "维京",
		en: "Vikings",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{variable}牌2VP", "2VP per {variable} card"],
		hdr: "powB",
		nat: "vikings",
		pc: 1,
		text: [["被动：将要放入你的历史的卡牌改为弃置。", "当你拿取{unrest}时，查看你的国家牌库顶的1张牌。\n你*可以*将它放到国家牌库底。"], ["Passive: cards that would be placed into your history are instead discarded.", "When you take {unrest}, look at the top card of your nation deck. You MAY place it at the bottom of the nation deck."]]
	},
	{
		id: "VIK2",
		zh: "哈拉尔德·哈德拉达",
		en: "Harald Hardrada",
		s: [],
		t: [],
		st: "b",
		loc: "accession",
		vp: 0,
		vpt: ["每{variable}牌2VP", "2VP per {variable} card"],
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [[
			"*拿取本牌会触发游戏结束。*",
			"拿取顶部的{fame}牌。",
			"你*可以*突破{region}。"
		], [
			"TAKING THIS CARD TRIGGERS THE GAME END.",
			"Take the top {fame} card.",
			"You MAY break through for {region}."
		]]
	},
	{
		id: "VIK3",
		zh: "冰岛",
		en: "Iceland",
		s: ["region"],
		t: ["production"],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["你*可以*进驻1张牌。", "选择：获取2{material}，\n*或*查看你的国家牌库顶的1张牌，\n然后你*可以*洗匀国家牌库。"], ["You MAY garrison a card.", "Choose: gain 2{material} OR look at the top card of your nation deck, then you MAY shuffle the nation deck."]]
	},
	{
		id: "VIK4",
		zh: "梳洗",
		en: "Combs",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		vpt: ["每3{population}1VP", "1VP per 3{population}"],
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["耗竭：忽略你在本回合中打出的\n下一张牌上的{empire}图标。"], ["Exhaust: ignore the {empire} icon on the next card you play this turn."]]
	},
	{
		id: "VIK5",
		zh: "格陵兰岛",
		en: "Graenland",
		s: ["region"],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["你*可以*进驻1张牌。", "选择：获取1{population}，\n*或*查看你的国家牌库顶的1张牌，\n然后你*可以*洗匀国家牌库。"], ["You MAY garrison a card.", "Choose: gain 1{population} OR look at the top card of your nation deck, then you MAY shuffle the nation deck."]]
	},
	{
		id: "VIK6",
		zh: "法罗群岛",
		en: "Føroyar",
		s: ["region"],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["你*可以*进驻1张牌。", "选择：从市场中放逐1张牌，\n*或*获取1{population}。"], ["You MAY garrison a card.", "Choose: exile a card from the market OR gain 1{population}."]]
	},
	{
		id: "VIK7",
		zh: "文兰",
		en: "Vinland",
		s: ["region"],
		t: [
			"production",
			"river",
			"fertile"
		],
		st: "b",
		loc: "nation",
		vp: 0,
		vpt: ["若在场，6VP", "6VP if in play"],
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["除非“长船”和“格陵兰岛”同时在场，\n否则不能被打出。", "选择：放回1{unrest}，*或*你*可以*进驻1张牌。"], ["Cannot be played unless both [Longships] and [Graenland] are in play.", "Choose: return an {unrest} OR you MAY garrison a card."]],
		rel: ["VIK5", "VIK10"]
	},
	{
		id: "VIK8",
		zh: "传奇故事",
		en: "Sagas",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		vpt: ["本牌每有1张\n已进驻牌\n1VP", "1VP per garrisoned card here"],
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["至日：你*可以*进驻1张牌。"], ["Solstice: you MAY garrison a card."]]
	},
	{
		id: "VIK9",
		zh: "都柏林城",
		en: "City of Dubh Linn",
		s: [],
		t: ["city"],
		st: "b",
		loc: "nation",
		vp: 0,
		vpt: ["每6{material}1VP", "1VP per 8{material}"],
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "VIK10",
		zh: "长船",
		en: "Longships",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["被动：你可以购得被放逐的{region}牌。\n当你如此做时，获取1{population}。", "耗竭：当你打出1{attack}时，耗竭本牌以获取2{material}。"], ["Passive: you can acquire exiled {region} cards. When you do, gain 1{population}.", "Exhaust: when you play an {attack}, exhaust this card to gain 2{material}."]]
	},
	{
		id: "VIK11",
		zh: "滑雪",
		en: "Skis",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 2,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["耗竭：当你打出1{region}时，耗竭本牌以\n选择：抽取1张牌，*或*获取2{material}。"], ["Exhaust: when you play a {region}, exhaust this card to choose: draw a card OR gain 2{material}."]]
	},
	{
		id: "VIK12",
		zh: "步行者罗洛",
		en: "Rollo the Walker",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["拿取顶部的{fame}牌。", "放逐本牌。"], ["Take the top {fame} card.", "Exile this card."]]
	},
	{
		id: "VIK13",
		zh: "出海掠夺",
		en: "Go a'Viking",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "atk",
		nat: "vikings",
		pc: 1,
		text: [[
			"免费打出。",
			"从每位其他玩家处窃取2{material}。",
			"如有玩家不能支付，则该玩家拿取{unrest}。"
		], [
			"Free play.",
			"Steal 2{material} from each other player.",
			"Anyone unable to pay takes {unrest}."
		]]
	},
	{
		id: "VIK14",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "VIK15",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "VIK16",
		zh: "女酋长",
		en: "Gothja",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [[
			"查看你的国家牌库顶的1张牌。",
			"你*可以*洗匀国家牌库。",
			"选择：放回1{unrest}并获取1{population}，*或*抽取2张牌。"
		], [
			"Look at the top card of your nation deck.",
			"You MAY shuffle the nation deck.",
			"Choose: return an {unrest} and gain 1{population} OR draw 2 cards."
		]]
	},
	{
		id: "VIK17",
		zh: "斯堪的纳维亚",
		en: "Scandinavia",
		s: ["region"],
		t: ["production"],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "vikings",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "VIK18",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "VIK19",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "VIK20",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "VIK21",
		zh: "红发埃里克",
		en: "Erik the Red",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["舍弃“斯堪的纳维亚”并支付1{population}\n以寻找1{region}并将其加入你的手牌。", "放逐本牌。"], ["Abandon [Scandinavia] and pay 1{population} to find a {region} and add it to your hand.", "Exile this card."]],
		rel: [
			"VIK17",
			"VIK3",
			"VIK5",
			"VIK6",
			"VIK7"
		]
	},
	{
		id: "VIK22",
		zh: "约姆斯维京",
		en: "Jomsviking",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "vikings",
		pc: 1,
		text: [["支付1{population}和2{material}以购得{region}/{tributary}。", "每位其他玩家弃置1张牌。"], ["Pay 1{population} and 2{material} to acquire {region}/{tributary}.", "Each other player discards a card."]]
	},
	{
		id: "VIK23",
		zh: "全体议会",
		en: "Althing",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "vikings",
		pc: 1,
		text: [["从每位其他玩家处窃取1{material}。", "选择：获取1{progress}，*或*放回1{unrest}。"], ["Steal 1{material} from each other player.", "Choose: gain 1{progress} OR return an {unrest}."]]
	},
	{
		id: "VIK24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "vikings",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "VIK25",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "vikings",
		pc: 3,
		text: [["设置：若“维京”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Vikings are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "VIK26",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "vikings",
		pc: 4,
		text: [["设置：若“维京”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Vikings are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ART1A",
		zh: "亚瑟王朝",
		en: "Arthurians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "powA",
		nat: "arthurians",
		pc: 1,
		text: [["耗竭：弃置1张牌以从你的弃牌堆中抽取1{knight}。", "至日：弃置1张牌并获取1{progress}。"], ["Exhaust: discard a card to draw a {knight} from your discard pile.", "Solstice: discard a card and gain 1{progress}."]]
	},
	{
		id: "ART1B",
		zh: "亚瑟王朝",
		en: "Arthurians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 6,
		hdr: "powB",
		nat: "arthurians",
		pc: 1,
		text: [["至日：弃置1张牌并获取1{progress}。"], ["Solstice: discard a card and gain 1{progress}."]]
	},
	{
		id: "ART2",
		zh: "亚瑟王廷",
		en: "King Arthur's Court",
		s: [],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{civilised}1VP", "1VP per {civilised}"],
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [[
			"被动：已进驻本牌的{development}牌视为当前任务。",
			"耗竭：若“卡美洛城”在场，\n弃置1张牌以放回1{unrest}。",
			"至日：若没有当前任务，\n你*可以*拿取{unrest}以进驻1个迫近任务。"
		], [
			"Passive: a {development} card that is garrisoned here is considered the active quest.",
			"Exhaust: if [Camelot] is in play, discard a card to return an {unrest}.",
			"Solstice: if there is no active quest, you MAY take {unrest} to garrison an impending quest."
		]],
		rel: ["ART11"]
	},
	{
		id: "ART3",
		zh: "圣杯",
		en: "Graal",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: 8,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [[
			"免费打出。*触发游戏结束*。",
			"你*可以*从你的历史抽取1张牌。",
			"你*可以*购得1张被放逐的牌（不能是{knight}）。",
			"[除非本牌是最后一个迫近任务，]\n[否则不能在任务区中成为目标。]"
		], [
			"Free play. TRIGGERS GAME END.",
			"You MAY draw a card from your history.",
			"You MAY acquire an exiled card (not a{knight}).",
			"[Cannot be targeted in the quest area unless it is the last impending quest.]"
		]]
	},
	{
		id: "ART4",
		zh: "湖上骑士兰斯洛特",
		en: "Lawnslot Llyn (Sir Lancelot)",
		s: [],
		t: ["knight"],
		st: null,
		loc: "dev",
		vp: 2,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [[
			"寻找“桂妮薇尔”并将其放入你的历史。",
			"拿取顶部的{fame}牌。",
			"放逐本牌。"
		], [
			"Find [Guennuvar] and put it into your history.",
			"Take the top {fame} card.",
			"Exile this card."
		]],
		rel: ["ART24"]
	},
	{
		id: "ART5",
		zh: "图鲁夫·图鲁维斯",
		en: "Twrch Trwyth",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: -4,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["耗竭：支付1{progress}以免费打出1{empire}。", "至日：你*可以*弃置1{knight}以选择：\n放逐1个迫近任务（“圣杯”除外），\n*或*从你的手牌或弃牌堆中放回最多2{unrest}。"], ["Exhaust: pay 1{progress} to free play an {empire}.", "Solstice: you MAY discard a {knight} to choose: exile an impending quest (except [Graal]) OR return up to 2 {unrest} from your hand or discard."]]
	},
	{
		id: "ART6",
		zh: "诗人塔利埃辛",
		en: "Taliesin the Bard",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 1,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["寻找1{knight}并将其放入你的历史\n以查看{fame}牌库顶的2张牌。", "拿取其中1张牌。"], ["Find a {knight} and put it to your history to look at the top 2 cards of the {fame} deck.", "Take one of those cards."]]
	},
	{
		id: "ART7",
		zh: "湖中剑",
		en: "Excalibur",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: 2,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["舍弃“湖之仙女薇薇安”*或*“阿瓦隆”\n以突破{tributary}/{civilised}。"], ["Abandon [Viviane of the Lake] OR [Ynys Afallach] to break through for {tributary}/{civilised}."]],
		rel: ["ART10", "ART13"]
	},
	{
		id: "ART8",
		zh: "卡姆兰之战",
		en: "Gwaith Camlan",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 2,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [[
			"*被获取时放入场中。*",
			"不能被舍弃或召回。",
			"至日：将1{knight}放入你的历史\n（已进驻的或从你的手牌中），\n*或*拿取2{unrest}。"
		], [
			"PUT INTO PLAY WHEN GAINED.",
			"Cannot be abandoned or recalled.",
			"Solstice: put a {knight} into your history (garrisoned or from your hand) or take 2 {unrest}."
		]]
	},
	{
		id: "ART9",
		zh: "贝德维尔爵士",
		en: "Bedwyr",
		s: [],
		t: ["knight"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["你*可以*从你的弃牌堆中将“湖中剑”\n放回你的牌库顶。", "你*可以*将本牌进驻到1{region}以触发\n那张牌的打出效果。"], ["You MAY return [Excalibur] from your discard pile to the top of your deck.", "You MAY garrison this card in a {region} to trigger that card's play effect."]],
		rel: ["ART7"]
	},
	{
		id: "ART10",
		zh: "湖之仙女薇薇安",
		en: "Viviane of the Lake",
		s: ["region"],
		t: ["river"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["获取1{progress}。", "至日：选择：召回已进驻本牌的1{knight}，\n*或*抽取1张牌。"], ["Gain 1{progress}.", "Solstice: choose: recall a {knight} garrisoned here or draw a card."]]
	},
	{
		id: "ART11",
		zh: "卡美洛城",
		en: "City of Camelot",
		s: [],
		t: ["city"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "ART12",
		zh: "不列颠尼亚弗拉维亚",
		en: "Britannia Flavia",
		s: ["region"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["抽取1张牌。", "你*可以*进驻1张牌。"], ["Draw a card.", "You MAY garrison a card."]]
	},
	{
		id: "ART13",
		zh: "阿瓦隆",
		en: "Ynys Afallach (Avalon)",
		s: ["region"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [[
			"从你的弃牌堆中放回1{knight}到你的手牌。",
			"你*可以*进驻1张牌。",
			"至日：你*可以*支付1{progress}以召回本牌。"
		], [
			"Return a {knight} from your discard pile to your hand.",
			"You MAY garrison a card.",
			"Solstice: you MAY pay 1{progress} to recall this card."
		]]
	},
	{
		id: "ART14",
		zh: "高文爵士",
		en: "Gwalchmei (Sir Gawain)",
		s: [],
		t: ["knight"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["拿取{unrest}以每有1{knight}已进驻就获取1{progress}。", "你*可以*将本牌进驻到1{region}以触发\n那张牌的打出效果。"], ["Take {unrest} to gain 1{progress} per garrisoned {knight}.", "You MAY garrison this card in a {region} to trigger that card's play effect."]]
	},
	{
		id: "ART15",
		zh: "贝蒂拉克夫人",
		en: "Lady Bertilak",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		vpt: ["若在历史中，2VP", "2VP if in history"],
		hdr: "atk",
		nat: "arthurians",
		pc: 1,
		text: [["免费打出。舍弃{knight}已进驻的1{region}。\n抽取2张牌。", "每位其他玩家弃置2张牌。"], ["Free play. Abandon a {region} with a {knight} garrisoned. Draw 2 cards.", "Each other player discards 2 cards."]]
	},
	{
		id: "ART16",
		zh: "莫里甘娜",
		en: "Morigena",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，2VP", "2VP if in history"],
		hdr: "atk",
		nat: "arthurians",
		pc: 1,
		text: [["所有玩家拿取{unrest}。", "你*可以*舍弃“梅林”已进驻的1{region}\n以将当前任务和你的国家牌库顶的\n1张牌都放入你的弃牌堆。"], ["All players take {unrest}.", "You MAY abandon a {region} with garrisoned [Myrddin Wyllt] to put both the active quest and the top card of your nation deck in your discard pile."]],
		rel: ["ART23"]
	},
	{
		id: "ART17",
		zh: "帕西瓦尔爵士",
		en: "Peredur (Sir Percival)",
		s: [],
		t: ["knight"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["选择：放回1{unrest}且你*可以*进驻到\n1{region}以触发那张牌的打出效果，\n*或*在你的弃牌堆或抽牌库中\n寻找“圣杯”并放逐本牌。"], ["Choose: return an {unrest} and you MAY garrison in a {region} to trigger that card's play effect OR find [Graal] in your discard pile or draw deck and exile this card."]],
		rel: ["ART3"]
	},
	{
		id: "ART18",
		zh: "凯爵士",
		en: "Cai (Sir Kay)",
		s: [],
		t: ["knight"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["你*可以*从你的弃牌堆放回\n1{region}到你的牌库顶。", "你*可以*将本牌进驻到1{region}以触发\n那张牌的打出效果。"], ["You MAY return a {region} from your discard pile to the top of your deck.", "You MAY garrison this card in a {region} to trigger that card's play effect."]]
	},
	{
		id: "ART19",
		zh: "亚瑟王",
		en: "King Arthur",
		s: [],
		t: ["knight"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["舍弃{knight}已进驻的1{region}以购得{region}/{tributary}。"], ["Abandon a {region} with a {knight} garrisoned to acquire {region}/{tributary}."]]
	},
	{
		id: "ART20",
		zh: "尤瑟·潘德拉贡",
		en: "Uthyr Pendragon",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["突破{uncivilised}。", "将本牌放入你的历史。"], ["Break through for {uncivilised}.", "Put this card into your history."]]
	},
	{
		id: "ART21",
		zh: "第一不列颠尼亚",
		en: "Britannia Prima",
		s: ["region"],
		t: ["fertile"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["抽取1张牌。", "你*可以*进驻1张牌。"], ["Draw a card.", "You MAY garrison a card."]]
	},
	{
		id: "ART22",
		zh: "第二不列颠尼亚",
		en: "Britannia Secunda",
		s: ["region"],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "arthurians",
		pc: 1,
		text: [["抽取1张牌。", "你*可以*进驻1张牌。"], ["Draw a card.", "You MAY garrison a card."]]
	},
	{
		id: "ART23",
		zh: "梅林",
		en: "Myrddin Wyllt (Merlin)",
		s: [],
		t: ["knight"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["舍弃已进驻到{region}的3{knight}\n以抽取当前任务到你的手牌。"], ["Abandon 3 {knight} garrisoned in {region} to draw the active quest into your hand."]]
	},
	{
		id: "ART24",
		zh: "桂妮薇尔",
		en: "Guennuvar",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["所有其他玩家获取1{progress}。", "选择：购得{uncivilised}/{civilised}，*或*舍弃“亚瑟王”\n以免费打出1张{empire}牌。"], ["All other players gain 1{progress}.", "Choose: acquire {uncivilised}/{civilised} OR abandon [King Arthur] to free play an {empire} card."]],
		rel: ["ART19"]
	},
	{
		id: "ART25",
		zh: "卡法尔",
		en: "Cafall",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["免费打出。抽取2张牌并放回\n1张牌到你的牌库顶。", "若“图鲁夫·图鲁维斯”在场或\n它是当前任务，你*可以*放逐它。"], ["Free play. Draw 2 cards and return a card to the top of your deck.", "You MAY exile [Twrch Trwyth] if it is in play or it is the active quest."]],
		rel: ["ART5"]
	},
	{
		id: "ART26",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["设置：若“亚瑟王朝”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Arthurians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ART27",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "arthurians",
		pc: 1,
		text: [["设置：若“亚瑟王朝”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Arthurians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ART28",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "arthurians",
		pc: 3,
		text: [["设置：若“亚瑟王朝”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Arthurians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ART29",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "arthurians",
		pc: 4,
		text: [["设置：若“亚瑟王朝”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Arthurians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ATL1A",
		zh: "亚特兰蒂斯",
		en: "Atlanteans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每2{region}1VP", "1VP per 2 {region}"],
		hdr: "powA",
		nat: "atlanteans",
		pc: 1,
		text: [["被动：将要放入你的历史的卡牌改为弃置。", "耗竭：当1张牌沉没时，耗竭本牌以\n从你的弃牌堆中将1张牌放到你的牌库顶。"], ["Passive: cards that would be placed into your history are instead discarded.", "Exhaust: when a card is sunk, exhaust this card to put a card from your discard pile on top of your deck."]]
	},
	{
		id: "ATL1B",
		zh: "亚特兰蒂斯",
		en: "Atlanteans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{region}1VP", "1VP per {region}"],
		hdr: "powB",
		nat: "atlanteans",
		pc: 1,
		text: [["被动：将要放入你的历史的卡牌改为弃置。"], ["Passive: cards that would be placed into your history are instead discarded."]]
	},
	{
		id: "ATL2",
		zh: "先进文化",
		en: "Advanced Culture",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每{region}1VP", "1VP per {region}"],
		dev: [
			5,
			0,
			1
		],
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["购得{uncivilised}/{civilised}。"], ["Acquire {uncivilised}/{civilised}."]]
	},
	{
		id: "ATL3",
		zh: "波塞冬宫殿",
		en: "Palace of Poseidon",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 5,
		dev: [
			3,
			2,
			1
		],
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [[
			"仅当“亚特兰蒂斯山”在场时才能打出。免费打出。",
			"被动：你的手牌上限增加1。",
			"若“亚特兰蒂斯山”离场，沉没本牌。"
		], [
			"Can only be played if [Mountain of Atlantis] is in play. Free play.",
			"Passive: increase your hand size by 1.",
			"If [Mountain of Atlantis] leaves play, sink this card."
		]],
		rel: ["ATL10"]
	},
	{
		id: "ATL4",
		zh: "亚特兰蒂斯扩展",
		en: "Spread of Atlantis",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			4,
			2,
			0
		],
		hdr: "atk",
		nat: "atlanteans",
		pc: 1,
		text: [["所有其他玩家召回1{region}。", "突破{region}/{tributary}。"], ["All other players recall a {region}.", "Break through for {region}/{tributary}."]]
	},
	{
		id: "ATL5",
		zh: "发展",
		en: "Development",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			4,
			0,
			0
		],
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["选择：发展，*或*购得{civilised}。"], ["Choose: develop OR acquire {civilised}."]]
	},
	{
		id: "ATL6",
		zh: "护城河与城墙",
		en: "Moats and Walls",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			1,
			1
		],
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [["耗竭：免费打出1{unrest}。"], ["Exhaust: free play an {unrest}."]]
	},
	{
		id: "ATL7",
		zh: "神话与传说",
		en: "Myths and Legends",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			0,
			0,
			2
		],
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [[
			"沉没在场的1{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。",
			"获取1{progress}。"
		], [
			"Sink a {region} in play to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards.",
			"Gain 1{progress}."
		]]
	},
	{
		id: "ATL8",
		zh: "金山银海",
		en: "Vast Wealth",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 1,
		dev: [
			5,
			0,
			0
		],
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [["被动：发展费用减少2{material}（最低为0）。", "耗竭：当你放回1{unrest}时，耗竭本牌以获取3{material}。"], ["Passive: reduce development cost by 2{material} (to a minimum of 0).", "Exhaust: when you return an {unrest}, exhaust this card to gain 3{material}."]]
	},
	{
		id: "ATL9",
		zh: "克莱托",
		en: "Kleito",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			0,
			2
		],
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["选择：购得{uncivilised}/{civilised}/{region}/{tributary}，\n*或*若“波塞冬宫殿”在场，突破{uncivilised}/{civilised}/{region}/{tributary}两次。", "沉没本牌。"], ["Choose: acquire {uncivilised}/{civilised}/{region}/{tributary} OR if [Palace of Poseidon] is in play, break through {uncivilised}/{civilised}/{region}/{tributary} twice.", "Sink this card."]],
		rel: ["ATL3"]
	},
	{
		id: "ATL10",
		zh: "亚特兰蒂斯山",
		en: "Mountain of Atlantis",
		s: ["region"],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		dev: [
			0,
			2,
			0
		],
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [["获取1{progress}。", "你*可以*进驻1张牌。"], ["Gain 1{progress}.", "You MAY garrison a card."]]
	},
	{
		id: "ATL11",
		zh: "忒弥斯库拉",
		en: "Themiscyra",
		s: ["region"],
		t: ["fertile", "production"],
		st: "e",
		loc: "dev",
		vp: 0,
		dev: [
			0,
			2,
			0
		],
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [[
			"获取1{progress}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{progress}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "ATL12",
		zh: "洪水",
		en: "Flood",
		s: [],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["沉没本牌和在场的1{region}\n以购得{uncivilised}/{civilised}/{region}/{tributary}。"], ["Sink this card and a {region} in play to acquire {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "ATL13",
		zh: "洪水",
		en: "Flood",
		s: [],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["沉没本牌和在场的1{region}\n以购得{uncivilised}/{civilised}/{region}/{tributary}。"], ["Sink this card and a {region} in play to acquire {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "ATL14",
		zh: "洪水",
		en: "Flood",
		s: [],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["沉没本牌和在场的1{region}\n以购得{uncivilised}/{civilised}/{region}/{tributary}。"], ["Sink this card and a {region} in play to acquire {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "ATL15",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "ATL16",
		zh: "极北之地",
		en: "Thule",
		s: ["region"],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [[
			"获取1{population}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{population}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "ATL17",
		zh: "金苹果园",
		en: "Hesperides",
		s: ["region"],
		t: ["production"],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [[
			"获取1{material}。",
			"从市场中放逐1张牌。",
			"你*可以*进驻1张牌。"
		], [
			"Gain 1{material}.",
			"Exile a card from the market.",
			"You MAY garrison a card."
		]]
	},
	{
		id: "ATL18",
		zh: "极乐之地",
		en: "Elysian Fields",
		s: ["region"],
		t: ["production", "production"],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "atlanteans",
		pc: 1,
		text: [["从市场中放逐1张牌。", "你*可以*进驻1张牌。"], ["Exile a card from the market.", "You MAY garrison a card."]]
	},
	{
		id: "ATL19",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ATL20",
		zh: "亚特兰蒂斯舰队",
		en: "Atlantean Fleet",
		s: [],
		t: [],
		st: "e",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "atlanteans",
		pc: 1,
		text: [["免费打出。选择：从你的弃牌堆中沉没1张牌\n并从每位其他玩家处窃取1{progress}，\n*或*突破{uncivilised}/{civilised}/{region}/{tributary}并沉没本牌。"], ["Free play. Choose: sink a card from your discard pile to steal 1{progress} from each player OR break through for {uncivilised}/{civilised}/{region}/{tributary} and sink this card."]]
	},
	{
		id: "ATL21",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "ATL22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "atlanteans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "EGY1A",
		zh: "埃及",
		en: "Egyptians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{civilised}2VP", "2VP per {civilised}"],
		hdr: "powA",
		nat: "egyptians",
		pc: 1,
		text: [["耗竭：选择：花费1行动并拿取{unrest}以发展，\n*或*支付1{population}并拿取{unrest}以获取1行动。"], ["Exhaust: choose: spend an action and take {unrest} to develop OR pay 1{population} and take {unrest} to gain an action."]]
	},
	{
		id: "EGY1B",
		zh: "埃及",
		en: "Egyptians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{civilised}3VP", "3VP per {civilised}"],
		hdr: "powB",
		nat: "egyptians",
		pc: 1,
		text: [["被动：你的手牌上限增加1。"], ["Passive: increase your hand size by 1."]]
	},
	{
		id: "EGY2",
		zh: "统一",
		en: "Unification",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["获取2{progress}。", "将本牌放入你的历史。"], ["Gain 2{progress}.", "Put this card into your history."]]
	},
	{
		id: "EGY3",
		zh: "发展",
		en: "Development",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			1,
			0
		],
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["选择：发展，*或*支付2{material}以购得{uncivilised}/{civilised}。"], ["Choose: develop OR pay 2{material} to acquire {uncivilised}/{civilised}."]]
	},
	{
		id: "EGY4",
		zh: "尸体防腐",
		en: "Embalming",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			4,
			0,
			0
		],
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["被动：每当你支付{population}时，\n你*可以*从你的手牌中将1张牌放入你的历史。", "耗竭：抽取1张牌。"], ["Passive: anytime you pay {population}, you MAY put a card from your hand into your history.", "Exhaust: draw a card."]]
	},
	{
		id: "EGY5",
		zh: "方尖碑",
		en: "Obelisk",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			2,
			0
		],
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["耗竭：免费打出1{unrest}。", "至日：弃置1张牌。获取1{progress}。"], ["Exhaust: free play an {unrest}.", "Solstice: discard a card. Gain 1{progress}."]]
	},
	{
		id: "EGY6",
		zh: "拉美西斯二世",
		en: "Ramesses II",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			4,
			2,
			0
		],
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["免费打出。购得{uncivilised}/{civilised}/{region}/{tributary}。", "将本牌放入你的历史。"], ["Free play. Acquire {uncivilised}/{civilised}/{region}/{tributary}.", "Put this card into your history."]]
	},
	{
		id: "EGY7",
		zh: "埃及扩张",
		en: "Egyptian Expansion",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			0,
			4,
			0
		],
		hdr: "atk",
		nat: "egyptians",
		pc: 1,
		text: [["每位其他玩家舍弃1{region}。", "你*可以*购得{region}/{tributary}。"], ["Each other player abandons a {region}.", "You MAY acquire {region}/{tributary}."]]
	},
	{
		id: "EGY8",
		zh: "医学",
		en: "Medicine",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			4,
			1,
			0
		],
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["被动：发展费用减少1{population}。"], ["Passive: reduce development costs by 1{population}."]]
	},
	{
		id: "EGY9",
		zh: "金字塔",
		en: "Pyramids",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 4,
		dev: [
			2,
			3,
			0
		],
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["被动：打出1{unrest}的{material}或卡牌费用减少1（最低为1）。", "耗竭：抽取1张牌。"], ["Passive: reduce the cost in {material} or cards to play an {unrest} by 1 (to a minimum of 1).", "Exhaust: draw a card."]]
	},
	{
		id: "EGY10",
		zh: "埃及遗产",
		en: "Egyptian Legacy",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每{civilised}1VP", "1VP per {civilised}"],
		dev: [
			5,
			0,
			0
		],
		hdr: "atk",
		nat: "egyptians",
		pc: 1,
		text: [["每位其他玩家拿取{unrest}并弃置1张牌。\n获取2{progress}。"], ["Each other player takes {unrest} and discards a card. Gain 2{progress}."]]
	},
	{
		id: "EGY11",
		zh: "红土地",
		en: "Red Land",
		s: ["region"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["获取1{progress}。", "你*可以*进驻1张牌。"], ["Gain 1{progress}.", "You MAY garrison a card."]]
	},
	{
		id: "EGY12",
		zh: "库施",
		en: "Kushites",
		s: ["tributary"],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["获取2{progress}。"], ["Gain 2{progress}."]]
	},
	{
		id: "EGY13",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "EGY14",
		zh: "尼罗河泛滥",
		en: "Flood of the Nile",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["舍弃1{river}以选择：获取5{material}，\n*或*若{empire}，突破{uncivilised}/{civilised}。"], ["Abandon a {river} to choose: gain 5{material} OR if {empire} break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "EGY15",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "EGY16",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "EGY17",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "EGY18",
		zh: "埃及入侵",
		en: "Egyptian Incursion",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "egyptians",
		pc: 1,
		text: [["支付1{population}和2{material}以购得{region}/{tributary}。", "每位其他玩家召回1{region}。"], ["Pay 1{population} and 2{material} to acquire {region}/{tributary}.", "Each other player recalls a {region}."]]
	},
	{
		id: "EGY19",
		zh: "埃及象形文字",
		en: "Egyptian Hieroglyphics",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["至日：你*可以*从你的手牌或弃牌堆中\n将1张牌放入你的历史。"], ["Solstice: you MAY put a card from your hand or discard pile into your history."]]
	},
	{
		id: "EGY20",
		zh: "尼罗河下游",
		en: "Lower Nile",
		s: ["region"],
		t: ["river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "EGY21",
		zh: "尼罗河谷",
		en: "Nile Valley",
		s: ["region"],
		t: [
			"production",
			"river",
			"fertile"
		],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "egyptians",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "EGY22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "EGY23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "egyptians",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAU1A",
		zh: "孔雀王朝",
		en: "Mauryans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每有1{region}在场，1VP", "1VP per {region} in play"],
		hdr: "powA",
		nat: "mauryans",
		pc: 1,
		text: [["耗竭：当你打出1{region}时，耗竭本牌以获取1{progress}。", "至日：你*可以*支付1{material}以从你的弃牌堆中\n将1{region}放回你的手牌。"], ["Exhaust: when you play a {region}, exhaust this card to gain 1{progress}.", "Solstice: you MAY pay 1{material} to return a {region} from your discard pile to your hand."]]
	},
	{
		id: "MAU1B",
		zh: "孔雀王朝",
		en: "Mauryans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每有1张牌\n在历史中，\n2VP", "2VP per card in history"],
		hdr: "powB",
		nat: "mauryans",
		pc: 1
	},
	{
		id: "MAU2",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "MAU3",
		zh: "数学",
		en: "Mathematics",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每有1{pinned}在场（不包括{region}），1VP", "1VP per {pinned} in play, excluding {region}"],
		dev: [
			4,
			1,
			0
		],
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "你的“进步”牌失去{barbarian}图标。"], ["Passive: increase your hand size by 1.", "Your [Advance] cards lose the {barbarian} icon."]],
		rel: ["MAU17"]
	},
	{
		id: "MAU4",
		zh: "大干道",
		en: "Grand Trunk Road",
		s: ["region", "region"],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			3,
			0
		],
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["被动：视为2{region}。", "耗竭：所有玩家获取1{material}，你获取{progress}。"], ["Passive: counts as two {region}.", "Exhaust: all players gain 1{material}, you gain 1{progress}."]]
	},
	{
		id: "MAU5",
		zh: "阿育王",
		en: "Ashoka",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 1,
		dev: [
			0,
			3,
			0
		],
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["拿取顶部的{fame}牌。", "展示你的手牌、抽牌库与弃牌堆，\n并将所有{attack}以及本牌放入你的历史。"], ["Take the top {fame} card.", "Reveal your hand, draw deck, and discard pile and put all {attack} and this card into your history."]]
	},
	{
		id: "MAU6",
		zh: "佛教",
		en: "Buddhism",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每有1张牌\n在历史中，\n1VP", "1VP per card in history"],
		dev: [
			0,
			4,
			0
		],
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["被动：打出1{unrest}的{material}或卡牌费用减少1（最低为1）。", "至日：获取1{progress}，*或*从你的弃牌堆中放回1{unrest}。"], ["Passive: reduce the cost in {material} or cards to play an {unrest} by 1 (to a minimum of 1).", "Solstice: gain 1{progress} OR return an {unrest} from your discard pile."]]
	},
	{
		id: "MAU7",
		zh: "阿育王诏书",
		en: "Edicts of Ashoka",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			0,
			0
		],
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["仅当“阿育王”在你的历史中时才能打出。", "耗竭：从你的手牌中将1张牌放入你的历史\n以选择：抽取1张牌，*或*从你的弃牌堆中放回1{unrest}，\n*或*以上两者。"], ["Only playable if [Ashoka] is in your history.", "Exhaust: put a card from your hand into your history to choose: draw a card OR return an {unrest} from your discard pile OR both."]],
		rel: ["MAU5"]
	},
	{
		id: "MAU8",
		zh: "冲压钱币",
		en: "Punch-marked Coins",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			1,
			0
		],
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["耗竭：抽取1张牌并获取1{progress}。"], ["Exhaust: draw a card and gain 1{progress}."]]
	},
	{
		id: "MAU9",
		zh: "政事论",
		en: "Arthashastra",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["至日：弃置任意数量的{unrest}。", "每弃置1张牌，选择：\n抽取1张牌，*或*获取1{progress}。"], ["Solstice: discard any number of {unrest}.", "For each card discarded, choose: draw a card OR gain 1{progress}."]]
	},
	{
		id: "MAU10",
		zh: "难陀王朝",
		en: "Nanda Dynasty",
		s: ["tributary"],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["仅当“政事论”在场时才能打出。", "获取2{population}。"], ["Only playable if [Arthashastra] is in play.", "Gain 2{population}."]],
		rel: ["MAU9"]
	},
	{
		id: "MAU11",
		zh: "华氏城",
		en: "City of Pataliputra",
		s: [],
		t: ["city"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以选择：\n获取1{material}，*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "MAU12",
		zh: "印度战象",
		en: "Indian Elephants",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "atk",
		nat: "mauryans",
		pc: 1,
		text: [["每位其他玩家召回1{region}。", "你*可以*突破{region}/{tributary}。"], ["Each other player recalls a {region}.", "You MAY break through for {region}/{tributary}."]]
	},
	{
		id: "MAU13",
		zh: "印度战象",
		en: "Indian Elephants",
		s: [],
		t: [],
		st: "b",
		loc: "nation",
		vp: 0,
		hdr: "atk",
		nat: "mauryans",
		pc: 1,
		text: [["每位其他玩家召回1{region}。", "你*可以*突破{region}/{tributary}。"], ["Each other player recalls a {region}.", "You MAY break through for {region}/{tributary}."]]
	},
	{
		id: "MAU14",
		zh: "犍陀罗",
		en: "Gandhara",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "MAU15",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAU16",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAU17",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "MAU18",
		zh: "旃陀罗笈多",
		en: "Chandragupta",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["购得{region}。寻找1张“印度战象”\n并将其放入你的弃牌堆。", "将本牌放入你的历史。"], ["Acquire {region}. Find an [Indian Elephants] and put it in your discard pile.", "Put this card into your history."]],
		rel: ["MAU12", "MAU13"]
	},
	{
		id: "MAU19",
		zh: "阇那迦",
		en: "Chanakya",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：购得{uncivilised}并购得{civilised}，\n*或*寻找“政事论”并将其放入你的弃牌堆。", "将本牌放入你的历史。"], ["Choose: acquire {uncivilised} and acquire {civilised} OR find [Arthashastra] and put it in your discard pile.", "Put this card into your history."]],
		rel: ["MAU9"]
	},
	{
		id: "MAU20",
		zh: "摩揭陀",
		en: "Magadha",
		s: ["region"],
		t: ["production"],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "MAU21",
		zh: "印度河谷",
		en: "Indus Valley",
		s: ["region"],
		t: [
			"production",
			"fertile",
			"river"
		],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "mauryans",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "MAU22",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "MAU23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MAU24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "mauryans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MIN1A",
		zh: "米诺斯",
		en: "Minoans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "powA",
		nat: "minoans",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以获取1{progress}。"], ["Solstice: you MAY discard a card to gain 1{progress}."]]
	},
	{
		id: "MIN1B",
		zh: "米诺斯",
		en: "Minoans",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每{progress}1VP", "1VP per {progress}"],
		hdr: "powB",
		nat: "minoans",
		pc: 1
	},
	{
		id: "MIN2",
		zh: "米诺斯王",
		en: "King Minos",
		s: [],
		t: [],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["获取1{progress}。你*可以*发展。", "将本牌放入你的历史。"], ["Gain 1{progress}. You MAY develop.", "Put this card into your history."]]
	},
	{
		id: "MIN3",
		zh: "米诺斯商人",
		en: "Minoan Traders",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			1,
			1
		],
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["每位其他玩家获取2{material}。", "选择：每有1{production}在你的游戏区中就获取1{material}，\n*或*每有1{region}在你的游戏区中就获取1{population}，\n*或*每有1{city}/{metropolis}在你的游戏区中就获取1{progress}。"], ["Each other player gains 2{material}.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} OR gain 1{progress} per {city}/{metropolis} in your play area."]]
	},
	{
		id: "MIN4",
		zh: "排水系统",
		en: "Drainage System",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			2,
			2,
			1
		],
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["至日：获取1{population}。"], ["Solstice: gain 1{population}."]]
	},
	{
		id: "MIN5",
		zh: "建筑学",
		en: "Architecture",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			5,
			0,
			2
		],
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["被动：发展费用减少1{progress}。"], ["Passive: reduce development costs by 1{progress}."]]
	},
	{
		id: "MIN6",
		zh: "壁画",
		en: "Frescos",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			1,
			2
		],
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["至日：你*可以*弃置1张牌以\n抽取1张牌并获取1{progress}。"], ["Solstice: you MAY discard a card to draw a card and gain 1{progress}."]]
	},
	{
		id: "MIN7",
		zh: "迷宫",
		en: "Labyrinth",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			3,
			2,
			2
		],
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["至日：你*可以*支付1{population}以获取1{progress}。"], ["Solstice: you MAY pay 1{population} to gain 1{progress}."]]
	},
	{
		id: "MIN8",
		zh: "米诺斯扩张",
		en: "Minoan Expansion",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			0,
			4,
			0
		],
		hdr: "atk",
		nat: "minoans",
		pc: 1,
		text: [["每位其他玩家舍弃1{region}。", "你*可以*购得{uncivilised}/{civilised}/{region}/{tributary}。"], ["Each other player abandons a {region}.", "You MAY acquire {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "MIN9",
		zh: "印石",
		en: "Seal Stones",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: 0,
		vpt: ["每{progress}1VP", "1VP per {progress}"],
		dev: [
			3,
			1,
			3
		],
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["不能被打出。"], ["Cannot be played."]]
	},
	{
		id: "MIN10",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "MIN11",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MIN12",
		zh: "书写系统",
		en: "Writing Systems",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["耗竭：从你的弃牌堆中将1张牌放入你的历史\n以抽取1张牌。"], ["Exhaust: put a card from your discard pile into your history to draw a card."]]
	},
	{
		id: "MIN13",
		zh: "克诺索斯",
		en: "Knossos",
		s: [],
		t: ["metropolis"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["至日：选择：获取1{material}，\n*或*获取1{population}，*或*抽取1张牌。"], ["Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card."]]
	},
	{
		id: "MIN14",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "MIN15",
		zh: "征服",
		en: "Conquer",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付2{population}以购得{region}/{tributary}，\n*或*支付3{population}以突破{region}/{tributary}。"], ["Choose: pay 2{population} to acquire {region}/{tributary} OR pay 3{population} to break through for {region}/{tributary}."]]
	},
	{
		id: "MIN16",
		zh: "陶器",
		en: "Pottery",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["至日：选择：支付2{material}并在本牌上放置1{progress}，\n*或*舍弃本牌并获取本牌上的所有{progress}。"], ["Solstice: choose: pay 2{material} and place 1{progress} on this card OR abandon this card and gain all {progress} on it."]]
	},
	{
		id: "MIN17",
		zh: "锡拉岛",
		en: "Thera",
		s: ["region"],
		t: ["production"],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["获取1{progress}。", "你*可以*进驻1张牌。"], ["Gain 1{progress}.", "You MAY garrison a card."]]
	},
	{
		id: "MIN18",
		zh: "克里特岛",
		en: "Crete",
		s: ["region"],
		t: [
			"production",
			"river",
			"fertile"
		],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "MIN19",
		zh: "塞浦路斯岛",
		en: "Cyprus",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "minoans",
		pc: 1,
		text: [["你*可以*进驻1张牌。"], ["You MAY garrison a card."]]
	},
	{
		id: "MIN20",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "MIN21",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MIN22",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "MIN23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "minoans",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "OLM1A",
		zh: "奥尔梅克",
		en: "Olmecs",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "powA",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：选择：从你的弃牌堆中将1{mask}放入你的历史，\n*或*弃置3{mask}以购得{uncivilised}/{civilised}/{region}/{tributary}。"], ["Exhaust: choose: put a {mask} from your discard pile into your history OR discard 3 {mask} to acquire {uncivilised}/{civilised}/{region}/{tributary}."]]
	},
	{
		id: "OLM1B",
		zh: "奥尔梅克",
		en: "Olmecs",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "powB",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：将1{mask}放入你的历史以获取2{progress}。"], ["Exhaust: put a {mask} into your history to gain 2{progress}."]]
	},
	{
		id: "OLM2",
		zh: "圣洛伦索特诺奇提特兰",
		en: "San Lorenzo Tenochtitlán",
		s: [],
		t: ["metropolis"],
		st: null,
		loc: "accession",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：放回1张牌到你的牌库顶以选择：\n从你的弃牌堆中放回1{mask}到你的手牌，\n*或*获取1{population}和1{material}。"], ["Exhaust: return a card to the top of your deck to choose: return a {mask} from your discard to your hand OR gain 1{population} and 1{material}."]]
	},
	{
		id: "OLM3",
		zh: "阶梯金字塔",
		en: "Step Pyramids",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：当1张牌的效果要求你弃置{mask}时，\n耗竭本牌以少弃置1{mask}。", "至日：你*可以*从你的弃牌堆中抽取1{mask}。"], ["Exhaust: when a card effect requires you to discard {mask}, exhaust this card to discard 1 {mask} fewer.", "Solstice: you MAY draw a {mask} from your discard pile."]]
	},
	{
		id: "OLM4",
		zh: "祭祀仪式",
		en: "Ritual Sacrifice",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [[
			"除非“阶梯金字塔”在场，否则不能被打出。",
			"弃置2{mask}并支付2{population}以查看{fame}牌库顶的3张牌。",
			"拿取其中1张牌。"
		], [
			"Cannot be played unless [Step Pyramids] is in play.",
			"Discard 2 {mask} and pay 2{population} to look at the top 3 cards of {fame} deck.",
			"Take one of those cards."
		]],
		rel: ["OLM3"]
	},
	{
		id: "OLM5",
		zh: "奥尔梅克商人",
		en: "Olmec Traders",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "atk",
		nat: "olmecs",
		pc: 1,
		text: [[
			"获取3{material}。",
			"从你的手牌或弃牌堆中给予\n每位其他玩家1张牌。",
			"你给予{mask}的任何玩家还要拿取{unrest}。"
		], [
			"Gain 3{material}.",
			"Give each other player a card from your hand or discard pile.",
			"Any player you give a {mask} also takes {unrest}."
		]]
	},
	{
		id: "OLM6",
		zh: "特雷斯萨波特斯",
		en: "Tres Zapotes",
		s: ["region"],
		t: ["production", "fertile"],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["你*可以*从你的弃牌堆中放回最多2{mask}到你的手牌。", "你*可以*进驻1张牌。"], ["You MAY return up to 2 {mask} from your discard pile to your hand.", "You MAY garrison a card."]]
	},
	{
		id: "OLM7",
		zh: "巨石头像",
		en: "Stone Heads",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["被动：当1张牌的效果要求你弃置{mask}时，\n你*可以*改为舍弃已进驻在此的牌。", "至日：你*可以*在此进驻1张牌。"], ["Passive: when a card effect requires you to discard {mask}, you MAY instead abandon cards garrisoned here.", "Solstice: you MAY garrison a card here."]]
	},
	{
		id: "OLM8",
		zh: "排水系统",
		en: "Drainage System",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 3,
		dev: [
			4,
			2,
			0
		],
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["至日：获取1{population}。"], ["Solstice: gain 1{population}."]]
	},
	{
		id: "OLM9",
		zh: "可可",
		en: "Cacao",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["所有玩家*可以*从自己的手牌或弃牌堆中放回1{unrest}。", "每放回1{unrest}，获取1{progress}。"], ["All players MAY return an {unrest} from their hand or discard pile.", "Gain 1{progress} for each {unrest} returned."]]
	},
	{
		id: "OLM10",
		zh: "奥尔梅克象形文字",
		en: "Olmec Hieroglyphics",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭以选择：放回1{exhaust}到你的国体牌，\n*或*花费1行动以从你的弃牌堆中\n放回1张牌到你的手牌。"], ["Exhaust to choose: return an {exhaust} to your state card OR spend an action to return a card from your discard pile to your hand."]]
	},
	{
		id: "OLM11",
		zh: "历法",
		en: "Calendar",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：弃置2{mask}并花费1行动以选择：\n你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["Exhaust: discard 2 {mask} and spend an action to choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "OLM12",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "nation",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM13",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "nation",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM14",
		zh: "磁石指南针",
		en: "Lodestone Compass",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：弃置2{mask}并花费1行动以购得{region}/{tributary}。"], ["Exhaust: discard 2 {mask} and spend an action to acquire {region}/{tributary}."]]
	},
	{
		id: "OLM15",
		zh: "球赛",
		en: "Ball Games",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["耗竭：弃置2{mask}并花费1行动以购得{uncivilised}/{civilised}。"], ["Exhaust: discard 2 {mask} and spend an action to acquire {uncivilised}/{civilised}."]]
	},
	{
		id: "OLM16",
		zh: "拉古纳德洛斯塞罗斯",
		en: "Laguna de los Cerros",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "OLM17",
		zh: "拉文塔",
		en: "La Venta",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "olmecs",
		pc: 1,
		text: [["获取2{material}。", "你*可以*进驻1张牌。"], ["Gain 2{material}.", "You MAY garrison a card."]]
	},
	{
		id: "OLM18",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM19",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM20",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM21",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM22",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM23",
		zh: "石制面具",
		en: "Stone Mask",
		s: [],
		t: ["mask"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["如有可能，抽取最多3张牌。", "然后放回1张牌到你的牌库顶。"], ["Draw up to 3 cards if able.", "Then return a card to the top of your deck."]]
	},
	{
		id: "OLM24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "olmecs",
		pc: 1,
		text: [["设置：若“奥尔梅克”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Olmecs are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "OLM25",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "olmecs",
		pc: 3,
		text: [["设置：若“奥尔梅克”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Olmecs are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "OLM26",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "olmecs",
		pc: 4,
		text: [["设置：若“奥尔梅克”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Olmecs are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "QIN1A",
		zh: "大秦",
		en: "Qin",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每有1{pinned}在场（不包括{region}），1VP", "1VP per {pinned} in play, excluding {region}"],
		hdr: "powA",
		nat: "qin",
		pc: 1,
		text: [["被动：当你将要放置{progress}到市场中的一张牌上时，\n改为放置1{population}。", "耗竭：如果你从市场中获取1张其上放有{population}的牌，\n获取的{population}加倍。"], ["Passive: when you would place {progress} on a card in the market, instead place 1{population}.", "Exhaust: if you gain a card from the market with {population} on it, double the {population} gained."]]
	},
	{
		id: "QIN1B",
		zh: "大秦",
		en: "Qin",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每有1{pinned}在场（不包括{region}），2VP", "2VP per {pinned} in play, excluding {region}"],
		hdr: "powB",
		nat: "qin",
		pc: 1,
		text: [["被动：当你将要放置{progress}到市场中的一张牌上时，\n改为放置1{population}。"], ["Passive: when you would place {progress} on a card in the market, instead place 1{population}."]]
	},
	{
		id: "QIN2",
		zh: "长城·壹",
		en: "Long Walls I",
		s: [],
		t: [],
		st: "e",
		loc: "accession",
		vp: 0,
		vpt: ["每有1张“长城”在场，1VP", "1VP per [Long Walls] in play"],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["被动：打出1{unrest}的{material}费用减少2（最低为1）。"], ["Passive: reduce the cost in {material} to play an {unrest} by 2 (to a minimum of 1)."]],
		rel: [
			"QIN3",
			"QIN4",
			"QIN5"
		]
	},
	{
		id: "QIN3",
		zh: "长城·贰",
		en: "Long Walls II",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每有1张“长城”在场，1VP", "1VP per [Long Walls] in play"],
		dev: [
			2,
			2,
			0
		],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["被动：召回任意1张“长城”以\n回避1{attack}的效果。"], ["Passive: recall any [Long Walls] to avoid the effect of an {attack}."]],
		rel: [
			"QIN2",
			"QIN4",
			"QIN5"
		]
	},
	{
		id: "QIN4",
		zh: "长城·叁",
		en: "Long Walls III",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每有1张“长城”在场，1VP", "1VP per [Long Walls] in play"],
		dev: [
			2,
			2,
			0
		],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["耗竭：支付1{population}以抽取1张牌。"], ["Exhaust: pay 1{population} to draw a card."]],
		rel: [
			"QIN2",
			"QIN3",
			"QIN5"
		]
	},
	{
		id: "QIN5",
		zh: "长城·肆",
		en: "Long Walls IV",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["每有1张“长城”在场，1VP", "1VP per [Long Walls] in play"],
		dev: [
			2,
			2,
			0
		],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["耗竭：若你有至少3张“长城”在场，\n耗竭本牌并放回1张牌到你的牌库顶\n以获取1行动。"], ["Exhaust: if you have at least 3 [Long Walls] in play, exhaust this card and return a card to the top of your deck to gain 1 action."]],
		rel: [
			"QIN2",
			"QIN3",
			"QIN4"
		]
	},
	{
		id: "QIN6",
		zh: "秦始皇",
		en: "Emperor Qin Shi Huang",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		dev: [
			3,
			2,
			0
		],
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [[
			"除非“受命于天”在场且“秦武王”\n在你的历史中，否则不能被打出。",
			"免费打出。拿取顶部的{fame}牌。",
			"将本牌放入你的历史。"
		], [
			"Cannot be played unless [Mandate of Heaven] is in play and [King Wu of Qin] is in your history.",
			"Free play. Draw the top {fame} card.",
			"Put this card into your history."
		]],
		rel: ["QIN22", "QIN8"]
	},
	{
		id: "QIN7",
		zh: "算术",
		en: "Mathematics",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			1,
			0
		],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["被动：你的手牌上限增加1。", "你的“进步”牌失去{barbarian}图标。"], ["Passive: increase your hand size by 1.", "Your [Advance] cards lose the {barbarian} icon."]],
		rel: ["QIN19"]
	},
	{
		id: "QIN8",
		zh: "秦武王",
		en: "King Wu of Qin",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 0,
		vpt: ["若在历史中，2VP", "2VP if in history"],
		dev: [
			3,
			2,
			0
		],
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [[
			"除非“受命于天”在场且“秦庄公”\n在你的历史中，否则不能被打出。",
			"支付最多3{progress}。每支付1{progress}，\n购得{uncivilised}/{civilised}/{region}/{tributary}。",
			"将本牌放入你的历史。"
		], [
			"Cannot be played unless [Mandate of Heaven] is in play and [Duke Zhuang of Qin] is in your history.",
			"Pay up to 3{progress}. For each {progress} paid, acquire {uncivilised}/{civilised}/{region}/{tributary}.",
			"Put this card into your history."
		]],
		rel: ["QIN22", "QIN21"]
	},
	{
		id: "QIN9",
		zh: "冶金",
		en: "Metallurgy",
		s: [],
		t: [],
		st: "e",
		loc: "dev",
		vp: 2,
		dev: [
			3,
			1,
			0
		],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["至日：选择：获取1{progress}，*或*从你的\n弃牌堆中放回{region}到你的手牌。"], ["Solstice: choose: gain 1{progress} OR return a {region} from your discard pile to your hand."]]
	},
	{
		id: "QIN10",
		zh: "兵马俑",
		en: "Terracotta Warriors",
		s: [],
		t: [],
		st: null,
		loc: "dev",
		vp: 0,
		vpt: ["若已进驻，\n7VP。\n若在历史中，3VP", "7VP if garrisoned, 3VP if in history"],
		dev: [
			7,
			0,
			0
		],
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [["不能被打出。", "^"], ["Cannot be played.", "^"]]
	},
	{
		id: "QIN11",
		zh: "东周",
		en: "Eastern Zhou",
		s: ["region"],
		t: ["production"],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["获取1{population}。", "你*可以*进驻1张牌。"], ["Gain 1{population}.", "You MAY garrison a card."]]
	},
	{
		id: "QIN12",
		zh: "荣耀",
		en: "Glory",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [[
			"本牌不能用于进驻。",
			"舍弃3{region}以查看{fame}牌库顶的2张牌。",
			"拿取其中1张牌。"
		], [
			"This card cannot be garrisoned.",
			"Abandon 3 {region} to look at the top 2 cards of the {fame} deck.",
			"Take one of those cards."
		]]
	},
	{
		id: "QIN13",
		zh: "书写系统",
		en: "Writing Systems",
		s: [],
		t: [],
		st: null,
		loc: "nation",
		vp: 0,
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["耗竭：从你的弃牌堆中将1张牌放入你的历史\n以抽取1张牌。"], ["Exhaust: put a card from your discard pile into your history to draw a card."]]
	},
	{
		id: "QIN14",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "nation",
		vp: -2,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "QIN15",
		zh: "儒家思想",
		en: "Confucianism",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["舍弃“法家思想”。", "耗竭：花费1行动并弃置2张牌以选择：\n购得其上放有{population}的{tributary}/{uncivilised}/{civilised}，\n*或*从你的弃牌堆中放回最多2{unrest}。"], ["Abandon [Legalism].", "Exhaust: spend an action and discard 2 cards to choose: acquire {tributary}/{uncivilised}/{civilised} with {population} on it OR return up to 2 {unrest} from your discard pile."]],
		rel: ["QIN16"]
	},
	{
		id: "QIN16",
		zh: "法家思想",
		en: "Legalism",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["舍弃“儒家思想”。", "耗竭：支付3{population}以购得{region}/{tributary}。"], ["Abandon [Confucianism].", "Exhaust: pay 3{population} to acquire {region}/{tributary}."]],
		rel: ["QIN15"]
	},
	{
		id: "QIN17",
		zh: "纵横家",
		en: "School of Diplomacy",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "atk",
		nat: "qin",
		pc: 1,
		text: [["舍弃最多3{region}。\n每舍弃1{region}，你*可以*购得{region}/{tributary}。", "若{barbarian}，所有其他玩家召回1{region}。"], ["Abandon up to 3 {region}. For each {region} abandoned, you MAY acquire {region}/{tributary}.", "If {barbarian}, all other players recall a {region}."]]
	},
	{
		id: "QIN18",
		zh: "西周",
		en: "Western Zhou",
		s: ["region"],
		t: ["production", "river"],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["获取1{material}。", "你*可以*进驻1张牌。"], ["Gain 1{material}.", "You MAY garrison a card."]]
	},
	{
		id: "QIN19",
		zh: "进步",
		en: "Advance",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [["选择：支付3{material}以购得{uncivilised}/{civilised}，\n*或*支付5{material}以突破{uncivilised}/{civilised}。"], ["Choose: pay 3{material} to acquire {uncivilised}/{civilised} OR pay 5{material} to break through for {uncivilised}/{civilised}."]]
	},
	{
		id: "QIN20",
		zh: "繁荣",
		en: "Prosperity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [["所有玩家*可以*抽取1张牌。", "选择：你每有1{production}在场就获取1{material}，\n*或*你每有1{region}在场就获取1{population}。"], ["All players MAY draw 1 card.", "Choose: gain 1{material} per {production} OR gain 1{population} per {region} you have in play."]]
	},
	{
		id: "QIN21",
		zh: "秦庄公",
		en: "Duke Zhuang of Qin",
		s: [],
		t: [],
		st: "b",
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [[
			"除非“受命于天”在场，否则不能被打出。",
			"从你的手牌或弃牌堆中放回最多2{unrest}。\n突破{region}/{tributary}。",
			"将本牌放入你的历史。"
		], [
			"Cannot be played unless [Mandate of Heaven] is in play.",
			"Return up to 2 {unrest} from your hand or discard pile. Break through for {region}/{tributary}.",
			"Put this card into your history."
		]],
		rel: ["QIN22"]
	},
	{
		id: "QIN22",
		zh: "受命于天",
		en: "Mandate of Heaven",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若不在场，-2VP", "-2VP if not in play"],
		hdr: "pin",
		nat: "qin",
		pc: 1,
		text: [["耗竭：从供应区中添加1{population}\n到市场中的1张牌上，\n然后你*可以*舍弃本牌。", "至日：弃置2张牌。"], ["Exhaust: add 1{population} from the supply to a card in the market, then you MAY abandon this card.", "Solstice: discard 2 cards."]]
	},
	{
		id: "QIN23",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "deck",
		vp: -2,
		hdr: "none",
		nat: "qin",
		pc: 1,
		text: [["选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "QIN24",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "qin",
		pc: 3,
		text: [["设置：若“大秦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Qin are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "QIN25",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "qin",
		pc: 4,
		text: [["设置：若“大秦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Qin are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UTO1A",
		zh: "乌托邦",
		en: "Utopians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每4{population}1VP", "1VP per 4{population}"],
		hdr: "powA",
		nat: "utopians",
		pc: 1,
		text: [["被动：当你的牌库抽空时，拿取{unrest}。", "至日：所有其他玩家*可以*放回1{unrest}。\n每放回1{unrest}，你获取1{population}。"], ["Passive: when your deck is empty, take {unrest}.", "Solstice: all other players MAY return an {unrest}. You gain 1{population} for each {unrest} returned."]]
	},
	{
		id: "UTO1B",
		zh: "乌托邦",
		en: "Utopians",
		s: ["power"],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		vpt: ["每3{population}1VP", "1VP per 3{population}"],
		hdr: "powB",
		nat: "utopians",
		pc: 1,
		text: [["被动：当你的牌库抽空时，拿取{unrest}。"], ["Passive: when your deck is empty, take {unrest}."]]
	},
	{
		id: "UTO2A",
		zh: "香格里拉之景",
		en: "Visions of Shangri-la",
		s: [],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：当你放回1{unrest}时，\n耗竭本牌并花费1行动以获取1{progress}。", "至日：选择：支付你的所有{progress}\n（最少为5）以将本牌翻面，\n*或*弃置1张牌，然后抽取1张牌。"], ["Exhaust: when you return an {unrest}, exhaust this card and spend an action to gain 1{progress}.", "Solstice: choose: pay all your {progress} (minimum 5) to flip this card OR discard a card, then draw a card."]],
		rel: ["UTO2B"]
	},
	{
		id: "UTO2B",
		zh: "香格里拉之路",
		en: "Path to Shangri-la",
		s: [],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：舍弃1{region}以获取1{population}和1{progress}。", "至日：选择：支付你的所有{progress}（最少为5）\n以将本牌替换为“香格里拉之门”，\n*或*你*可以*从你的弃牌堆中抽取1{region}。"], ["Exhaust: abandon a {region} to gain 1{population} and 1{progress}.", "Solstice: choose: pay all your {progress} (minimum 5) to replace this card with [Gates of Shangri-La] OR you MAY draw a {region} from your discard pile."]],
		rel: ["UTO3A", "UTO3AX"]
	},
	{
		id: "UTO3A",
		zh: "香格里拉之门",
		en: "Gates of Shangri-la",
		s: [],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [[
			"当放到场上时，\n将你的国体牌翻到{empire}面。",
			"耗竭：将1张牌放入你的历史以获取1{progress}。",
			"至日：选择：支付你的所有{progress}\n（最少为5）以将本牌翻面，*或*抽取1张牌。"
		], [
			"When put into play, flip your state card to its {empire} side.",
			"Exhaust: put a card into your history to gain 1{progress}.",
			"Solstice: choose: pay all your {progress} (minimum 5) to flip this card OR draw a card."
		]],
		rel: ["UTO3B"]
	},
	{
		id: "UTO3B",
		zh: "香格里拉",
		en: "Shangri-la",
		s: [],
		t: [],
		st: null,
		loc: "power",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [[
			"被动：当你将要获取{material}时，\n改为每位其他玩家获取1{progress}且你获取2{population}。",
			"耗竭：获取1{material}。",
			"至日：若你拥有至少24{population}，*触发游戏结束。*"
		], [
			"Passive: when you would gain {material}, instead each other player instead gain 1{progress} and you gain 2{population}.",
			"Exhaust: gain 1{material}.",
			"Solstice: if you have at least 24{population} GAME END IS TRIGGERED."
		]]
	},
	{
		id: "UTO4",
		zh: "禅寺",
		en: "Monastery",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["放逐牌堆中\n每4张牌1VP", "1VP per 4 cards in exile"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：进驻1{scroll}到本牌以\n从你的手牌中放逐1张牌（不能是{unrest}）\n并获取2{population}。若它是{attack}，还获取1{progress}。", "至日：抽取1张牌，\n*或*舍弃本牌并放回1{unrest}。"], ["Exhaust: garrison a {scroll} here to exile a card from your hand (not a {unrest}) and gain 2{population}. If it was an {attack}, also gain 1{progress}.", "Solstice: draw a card OR abandon this card and return an {unrest}."]]
	},
	{
		id: "UTO5",
		zh: "传送门",
		en: "Portals",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["每{region}1VP", "1VP per {region}"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：进驻1{scroll}到本牌以购得{region}。", "至日：选择：召回1{region}，\n*或*舍弃本牌并获取1{population}。"], ["Exhaust: garrison a {scroll} here to acquire {region}.", "Solstice: choose: recall a {region} OR abandon this card and gain 1{population}."]]
	},
	{
		id: "UTO6",
		zh: "道场",
		en: "Daochang",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["每{tributary}1VP", "1VP per {tributary}"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [[
			"被动：当另一位玩家打出1{attack}时，\n你*可以*支付1{population}以回避其效果。",
			"耗竭：进驻1{scroll}到本牌以购得{tributary}。",
			"至日：选择：拿取{unrest}，\n*或*舍弃本牌并获取1{material}。"
		], [
			"Passive: when another player plays an {attack}, you MAY pay 1{population} to avoid its effect.",
			"Exhaust: garrison a {scroll} here to acquire {tributary}.",
			"Solstice: choose: take {unrest} OR abandon this card and gain 1{material}."
		]]
	},
	{
		id: "UTO7",
		zh: "失落古籍",
		en: "Lost Tomes",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["每{fame}2VP", "2VP per {fame}"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：进驻1{scroll}到本牌以\n从你的手牌或弃牌堆中将1张牌放入你的历史。", "至日：若有2{scroll}已进驻本牌，\n你*可以*舍弃本牌以抽取{fame}牌库顶的1张牌。"], ["Exhaust: garrison a {scroll} here to put a card from your hand or discard into your history.", "Solstice: if there are 2 {scroll} garrisoned here, you MAY abandon this card to draw the top card of the {fame} deck."]]
	},
	{
		id: "UTO8",
		zh: "智慧树",
		en: "Tree of Knowledge",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["每{civilised}1VP", "1VP per {civilised}"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：进驻1{scroll}到本牌以购得{uncivilised}/{civilised}。", "至日：选择：弃置1张牌，\n*或*舍弃本牌并抽取1张牌。"], ["Exhaust: garrison a {scroll} here to acquire {uncivilised}/{civilised}.", "Solstice: choose: discard a card OR abandon this card and draw a card."]]
	},
	{
		id: "UTO9",
		zh: "仁爱",
		en: "Charity",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["获取1{progress}。", "每位其他玩家*可以*获取2{material}。"], ["Gain 1{progress}.", "Each other player MAY gain 2{material}."]]
	},
	{
		id: "UTO10",
		zh: "冥想",
		en: "Meditation",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。从你的弃牌堆中\n放回1张牌到你的牌堆顶。", "所有其他玩家*可以*抽取1张牌。"], ["Free play. Return a card from your discard pile to the top of your deck.", "All other players MAY draw a card."]]
	},
	{
		id: "UTO11",
		zh: "山中静修",
		en: "Mountain Retreat",
		s: [],
		t: [],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["每{uncivilised}1VP", "1VP per {uncivilised}"],
		hdr: "pin",
		nat: "utopians",
		pc: 1,
		text: [["耗竭：进驻1{unrest}到本牌以\n从你的弃牌堆中抽取1{scroll}。", "至日：抽取1张牌，\n*或*舍弃本牌，放回所有已进驻的{unrest}。"], ["Exhaust: garrison an {unrest} here to draw a {scroll} from your discard pile.", "Solstice: draw a card OR abandon this card, returning any garrisoned {unrest}."]]
	},
	{
		id: "UTO12",
		zh: "神圣古卷",
		en: "Sacred Scroll",
		s: [],
		t: ["scroll"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。所有玩家*可以*抽取1张牌。"], ["Free play. All players MAY draw a card."]]
	},
	{
		id: "UTO13",
		zh: "神圣古卷",
		en: "Sacred Scroll",
		s: [],
		t: ["scroll"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。所有玩家*可以*抽取1张牌。"], ["Free play. All players MAY draw a card."]]
	},
	{
		id: "UTO14",
		zh: "神圣古卷",
		en: "Sacred Scroll",
		s: [],
		t: ["scroll"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。所有玩家*可以*抽取1张牌。"], ["Free play. All players MAY draw a card."]]
	},
	{
		id: "UTO15",
		zh: "神圣古卷",
		en: "Sacred Scroll",
		s: [],
		t: ["scroll"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。所有玩家*可以*抽取1张牌。"], ["Free play. All players MAY draw a card."]]
	},
	{
		id: "UTO16",
		zh: "神圣古卷",
		en: "Sacred Scroll",
		s: [],
		t: ["scroll"],
		st: null,
		loc: "deck",
		vp: 0,
		vpt: ["若在历史中，1VP", "1VP if in history"],
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["免费打出。所有玩家*可以*抽取1张牌。"], ["Free play. All players MAY draw a card."]]
	},
	{
		id: "UTO17",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["设置：若“乌托邦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Utopians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UTO18",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["设置：若“乌托邦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Utopians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UTO19",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "utopians",
		pc: 1,
		text: [["设置：若“乌托邦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Utopians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UTO20",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "utopians",
		pc: 3,
		text: [["设置：若“乌托邦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Utopians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	},
	{
		id: "UTO21",
		zh: "动乱",
		en: "Unrest",
		s: ["unrest"],
		t: [],
		st: null,
		loc: "supply",
		vp: -2,
		hdr: "none",
		nat: "utopians",
		pc: 4,
		text: [["设置：若“乌托邦”在场，\n将本牌加入动乱牌堆。", "选择：支付1{population}，*或*弃置2张牌，\n*或*支付3{material}。若你如此做，\n将本牌放回动乱牌堆。"], ["Setup: add to the unrest pile if the Utopians are in play.", "Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile."]]
	}
], b = Object.fromEntries(y.map((e) => [e.id, e])), x = [
	"carthaginians",
	"celts",
	"greeks",
	"macedonians",
	"persians",
	"romans",
	"scythians",
	"vikings",
	"arthurians",
	"atlanteans",
	"egyptians",
	"mauryans",
	"minoans",
	"olmecs",
	"qin",
	"utopians"
], S = (e) => y.filter(e), C = (e) => S(e).map((e) => e.id), w = (e) => {
	let t = y.find((t) => t.nat === e && t.loc === "power" && t.hdr === "powA"), n = y.find((t) => t.nat === e && t.loc === "power" && t.hdr === "powB");
	if (!t || !n) throw Error("missing power card " + e);
	return [t.id, n.id];
}, T = (e) => y.find((t) => t.nat === e && t.loc === "accession")?.id ?? null;
function E(e, t, n, r = {}) {
	let i = w(e);
	return {
		id: e,
		zh: b[i[0]].zh,
		en: b[i[0]].en,
		power: i,
		extra: [],
		accession: T(e),
		side: "b",
		historyKind: "normal",
		quests: !1,
		journey: !1,
		exhaustTokens: 5,
		supplyUnrest: C((t) => t.nat === e && t.loc === "supply"),
		descZh: t,
		descEn: n,
		...r
	};
}
var D = {
	carthaginians: E("carthaginians", "以商路与市场积累财富，用航海与贸易网络把资源转化为胜利。", "Build wealth through trade and the market, turning sea routes into victory.", {}),
	celts: E("celts", "以蛮族扩张与劫掠压制对手，靠不断的征服推进文明。", "Expand as barbarians and raid rivals, advancing through constant conquest.", {}),
	greeks: E("greeks", "以文化与城邦发展取胜，重视发展区的建设与知识的积累。", "Prevail through culture and city-states, investing in development.", {}),
	macedonians: E("macedonians", "以亚历山大式的远征快速扩张疆域，靠区域数量取得优势。", "Campaign like Alexander, expanding territory for a wide empire.", {}),
	persians: E("persians", "以藩属与贡赋统治辽阔疆土，靠属国网络累积胜利点。", "Rule a vast realm through tributaries and satrapies.", {}),
	romans: E("romans", "以军团与征服迅速扩张，再用名声与荣耀巩固帝国。", "Expand rapidly with legions, then consolidate through fame.", {}),
	scythians: E("scythians", "以骑射与草原资源周旋，靠物资积累与区域控制取胜。", "Master the steppe, balancing resources and territory.", {}),
	vikings: E("vikings", "没有历史与帝国，靠远征、掠夺与声望扬名，以可变分数取胜。", "No history and no empire: raid, explore, and win through renown.", {
		historyKind: "zenith",
		exhaustTokens: 5
	}),
	arthurians: E("arthurians", "以圆桌骑士与任务为核心，通过完成任务累积传说。", "Lead the knights of the Round Table and complete quests.", {
		extra: ["ART2"],
		quests: !0
	}),
	atlanteans: E("atlanteans", "开局即为帝国，靠沉没与洪泛管理牌库，以区域与文明得分。", "Begin as an empire and manage your deck through sinking and the flooded pile.", {
		side: "e",
		historyKind: "flooded"
	}),
	egyptians: E("egyptians", "以尼罗河的富饶与纪念碑建设累积文明，靠文明卡取得高分。", "Draw on the Nile and raise monuments to accumulate civilisation.", {}),
	mauryans: E("mauryans", "以孔雀王朝的扩张与阿育王的治理并进，靠区域与历史得分。", "Expand the Mauryan empire and govern wisely, scoring regions and history.", {}),
	minoans: E("minoans", "以海上贸易与宫殿经济稳步发展，靠进度与文明积累得分。", "Prosper through sea trade and palace economy.", {}),
	olmecs: E("olmecs", "以面具崇拜与祭祀推动文明，靠面具与历史累积胜利。", "Harness masks and ritual to advance your civilisation.", {}),
	qin: E("qin", "以法家治国与长城防御巩固统治，靠在场建筑与人口取胜。", "Rule through legalism and the Long Walls, scoring pinned cards and population.", {}),
	utopians: E("utopians", "没有发展区与国家牌堆，踏上通往香格里拉的旅程，以人口与旅程终点取胜。", "No development area or nation deck: journey toward Shangri-La.", {
		extra: ["UTO2A", "UTO3A"],
		journey: !0,
		exhaustTokens: 3
	})
};
x.map((e) => D[e]);
function ee(e) {
	return C((t) => t.nat === e && t.loc === "deck");
}
function te(e) {
	return C((t) => t.nat === e && t.loc === "nation");
}
function ne(e) {
	return C((t) => t.nat === e && t.loc === "dev");
}
//#endregion
//#region src/game/effects.ts
var re = {
	region: "region",
	uncivilised: "uncivilised",
	civilised: "civilised",
	tributary: "tributary",
	fame: "fame",
	unrest: "unrest",
	power: "power"
}, ie = {
	production: "production",
	fertile: "fertile",
	river: "river",
	ocean: "ocean",
	city: "city",
	metropolis: "metropolis",
	knight: "knight",
	scroll: "scroll",
	mask: "mask",
	hunt: "hunt",
	miracle: "miracle",
	merchant: "merchant"
}, O = (e) => e.replace(/\s+/g, " ").trim(), k = (e) => e && e[0].toUpperCase() + e.slice(1);
function A(e) {
	let t = [...e.matchAll(/\{([a-z]+)\}/g)].map((e) => e[1]), n = {}, r = t.map((e) => re[e]).filter(Boolean), i = t.map((e) => ie[e]).filter(Boolean);
	if (r.length && (n.s = r), i.length && (n.t = i), !r.length && !i.length) {
		let e = t.filter((e) => e === "pinned" || e === "attack").map((e) => e === "pinned" ? "pin" : "atk");
		e.length && (n.h = e);
	}
	return Object.keys(n).length ? n : void 0;
}
var ae = (e) => [...e.matchAll(/\{([a-z]+)\}/g)].map((e) => re[e[1]]).filter(Boolean), j = (e, t, n) => ({
	k: "gain",
	...e ? { m: e } : {},
	...t ? { p: t } : {},
	...n ? { pr: n } : {}
}), M = (e) => ({
	k: "may",
	eff: e
}), N = (...e) => ({
	k: "choose",
	opts: e.map(([e, t]) => ({
		id: e,
		eff: t
	}))
}), P = (e, t) => ({
	k: "pay",
	cost: e,
	eff: t
}), F = (e, t, n = !1) => ({
	k: "each",
	who: e,
	eff: t,
	may: n
}), oe = (e, t, n) => ({
	k: "if",
	cond: {
		c: "state",
		v: e
	},
	then: t,
	...n ? { else: n } : {}
}), I = (e, t) => ({
	k: "special",
	id: e,
	...t === void 0 ? {} : { n: t }
}), L = (e, t = "acquire", n = {}) => ({
	k: "acquire",
	suits: ae(e),
	mode: t,
	...n
}), R = (e, t, n, r = {}) => ({
	k: "pick",
	n: e,
	from: r.from ?? "hand",
	to: n,
	...t ? { sel: t } : {},
	...r.optional ? { optional: !0 } : {},
	...r.all ? { all: !0 } : {},
	...r.min === void 0 ? {} : { min: r.min },
	...r.then ? { then: r.then } : {}
}), se = {
	"^": [],
	"Setup: add to the unrest pile if the Celts are in play.": [],
	"Setup: add to the unrest pile if the Utopians are in play.": [],
	"Setup: add to the unrest pile if the Arthurians are in play.": [],
	"Setup: add to the unrest pile if the Olmecs are in play.": [],
	"Setup: add to the unrest pile if the Vikings are in play.": [],
	"Setup: add to the unrest pile if the Qin are in play.": [],
	"Choose: Pay 1{population} OR discard 2 cards OR pay 3{material}. If you do, return this card to the unrest pile.": [N(["population", [P({ p: 1 }, [I("returnSelfToUnrest")])]], ["discard", [P({ cards: 2 }, [I("returnSelfToUnrest")])]], ["material", [P({ m: 3 }, [I("returnSelfToUnrest")])]])],
	"Take one of those cards.": [I("takeLooked")],
	"Reveal the top card of the main deck.": [],
	"If it matches the declared type, add it to your hand. Otherwise, exile it.": [],
	"Draw the top card of your deck if able and choose: discard it OR return it to the top OR put it into your history.": [I("drawTopChoose")],
	"Free play. Draw the top card of your deck if able and choose: discard it OR return it to the top OR put it into your history.": [I("drawTopChoose")],
	"When you would gain this card, instead resolve it. Then flip this card.": [I("kingOfKings")],
	"When you would gain this card, instead resolve it. Multiple players can resolve this card.": [I("kingOfKingsB")],
	"THIS TRIGGERS GAME END.": [{ k: "endGame" }],
	"TAKING THIS CARD TRIGGERS THE GAME END.": [{ k: "endGame" }],
	"TRIGGERS GAME END.": [{ k: "endGame" }],
	"Gain 1{material} and 1{population} per {city}/{metropolis} in your play area.": [{
		k: "gainPer",
		n: 1,
		sel: { t: ["city", "metropolis"] },
		zone: "play",
		res: "m"
	}, {
		k: "gainPer",
		n: 1,
		sel: { t: ["city", "metropolis"] },
		zone: "play",
		res: "p"
	}],
	"Gain 1{progress} for each {unrest} returned.": [I("gainPerUnrestReturned")],
	"Gain 2{material} per abandoned {city}.": [{
		k: "gainPer",
		n: 2,
		sel: { t: ["city"] },
		zone: "abandoned",
		res: "m"
	}],
	"Gain 1{progress} per garrisoned {knight}.": [{
		k: "gainPer",
		n: 1,
		sel: { t: ["knight"] },
		zone: "garrisoned",
		res: "pr"
	}],
	"Take {unrest} to gain 1{progress} per garrisoned {knight}.": [{
		k: "pay",
		cost: { unrest: 1 },
		eff: [{
			k: "gainPer",
			n: 1,
			sel: { t: ["knight"] },
			zone: "garrisoned",
			res: "pr"
		}]
	}],
	"If the abandoned card has no {production}, gain an additional {progress}.": [I("abandonBonus")],
	"For each card discarded, choose: draw a card OR gain 1{progress}.": [I("forEachDiscarded")],
	"Discard any number of {unrest}.": [{
		k: "discardAny",
		sel: { s: ["unrest"] }
	}],
	"Return up to 2 {unrest} before scoring.": [I("returnUnrestBeforeScoring")],
	"Exile a card from the market.": [{
		k: "exile",
		from: "market",
		sel: void 0
	}],
	"Free play. Add 1{material} to a card in the market.": [P({}, [{
		k: "token",
		res: "m",
		n: 1,
		to: "market"
	}])],
	"You MAY acquire an exiled card (not a{knight}).": [M([I("acquireExileNotKnight")])],
	"Passive: you can acquire exiled {region}/{tributary} cards as though they were in the market.": [],
	"Passive: you can acquire exiled {region} cards. When you do, gain 1{population}.": [],
	"Passive: you may acquire exiled {region}.": [],
	"Remember that when you acquire an exiled {tributary} card, you must take {unrest}.": [],
	"You MAY acquire {region} twice, including from exiled cards.": [M([I("acquireRegionTwiceExile")])],
	"Acquire {region} twice (including from exiled cards).": [I("acquireRegionTwiceExile")],
	"Free play. You MAY acquire {region} twice, including from exiled cards.": [I("acquireRegionTwiceExile")],
	"You MAY acquire {region}/{tributary} and immediately free play it.": [M([I("acquireFreePlay|region,tributary")])],
	"You MAY acquire {region} and free play it immediately.": [M([I("acquireFreePlay|region")])],
	"swap an exiled card with a card in the market": [],
	"Swap an exiled card with a card in the market.": [{ k: "swapExileMarket" }],
	"You MAY garrison this card in a {region} to trigger that card's play effect.": [I("garrisonTriggerRegion")],
	"Choose: return an {unrest} and you MAY garrison in a {region} to trigger that card's play effect OR find [Graal] in your discard pile or draw deck and exile this card.": [N(["return", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}, I("garrisonTriggerRegion")]], ["graal", [I("findGraalExileSelf")]])],
	"Put this card into your history.": [I("thisToHistory")],
	"You MAY put this card into your history.": [M([I("thisToHistory")])],
	"Reveal your hand, draw deck, and discard pile and put all {attack} and this card into your history.": [I("revealAttacksToHistory")],
	"Find [Guennuvar] and put it into your history.": [{
		k: "find",
		name: "Guennuvar",
		dest: "history"
	}],
	"Find [Graal] in your discard pile or draw deck and exile this card.": [I("findGraalExileSelf")],
	"You MAY return [Excalibur] from your discard pile to the top of your deck.": [{
		k: "find",
		name: "Excalibur",
		dest: "deckTop",
		from: "discard"
	}],
	"Put [City of Rome] into your history.": [{
		k: "find",
		name: "City of Rome",
		dest: "history",
		from: "all"
	}],
	"Find a {knight} and put it to your history to look at the top 2 cards of the {fame} deck.": [I("findKnightHistoryFame")],
	"Steal 1{progress} from each other player. Each player MAY discard a card to return an {unrest}.": [{
		k: "steal",
		pr: 1,
		from: "each"
	}, I("discardToReturnUnrestAll")],
	"Free play. Steal 1{progress} from each other player. Each player MAY discard a card to return an {unrest}.": [{
		k: "steal",
		pr: 1,
		from: "each"
	}, I("discardToReturnUnrestAll")],
	"Pay 3{material}. All other players take {unrest}.": [P({ m: 3 }, [F("others", [{
		k: "unrestTake",
		n: 1
	}])])],
	"Pay 3{material}. Each other player takes {unrest}.": [P({ m: 3 }, [F("others", [{
		k: "unrestTake",
		n: 1
	}])])],
	"Anyone unable to pay takes {unrest}.": [I("anyoneUnablePayUnrest")],
	"Gain 1{material} per {production} you have in play.": [{
		k: "gainPer",
		n: 1,
		sel: { t: ["production"] },
		zone: "play",
		res: "m"
	}],
	"Gain 4{material} per {fertile} in your play area.": [{
		k: "gainPer",
		n: 4,
		sel: { t: ["fertile"] },
		zone: "play",
		res: "m"
	}],
	"Gain 2{material}. Steal 1{material} from each player with at least one {region} in play.": [j(2), {
		k: "steal",
		m: 1,
		from: "each",
		unrestIfUnable: !1,
		needRegion: !0
	}],
	"Steal 1{progress} from each {empire} player.": [{
		k: "steal",
		pr: 1,
		from: "empire"
	}],
	"Steal 1{population} from each {empire} player.": [{
		k: "steal",
		p: 1,
		from: "empire"
	}],
	"Acquire {region}. You MAY acquire {region} again.": [L("{region}"), M([L("{region}")])],
	"Acquire {region}. Find an [Indian Elephants] and put it in your discard pile.": [L("{region}"), {
		k: "find",
		name: "Indian Elephants",
		dest: "discard",
		from: "all"
	}],
	"Choose: acquire {uncivilised} and acquire {civilised} OR find [Arthashastra] and put it in your discard pile.": [N(["acquire", [L("{uncivilised}"), L("{civilised}")]], ["find", [{
		k: "find",
		name: "Arthashastra",
		dest: "discard",
		from: "all"
	}]])],
	"Choose: gain 1{material} per {production} OR gain 1{population} per {region} OR draw a card per {city}/{metropolis} in play.": [N(["material", [{
		k: "gainPer",
		n: 1,
		sel: { t: ["production"] },
		zone: "play",
		res: "m"
	}]], ["population", [{
		k: "gainPer",
		n: 1,
		sel: { s: ["region"] },
		zone: "play",
		res: "p"
	}]], ["draw", [I("drawPerCityMetropolis")]])],
	"Choose: gain 1{material} per {production} OR gain 1{population} per {region} OR gain 1{progress} per {city}/{metropolis} in your play area.": [N(["material", [{
		k: "gainPer",
		n: 1,
		sel: { t: ["production"] },
		zone: "play",
		res: "m"
	}]], ["population", [{
		k: "gainPer",
		n: 1,
		sel: { s: ["region"] },
		zone: "play",
		res: "p"
	}]], ["progress", [{
		k: "gainPer",
		n: 1,
		sel: { t: ["city", "metropolis"] },
		zone: "play",
		res: "pr"
	}]])],
	"Discard 2 {mask} and pay 2{population} to look at the top 3 cards of {fame} deck.": [P({
		discardMask: 2,
		p: 2
	}, [{
		k: "fame",
		n: 3,
		top: !0
	}])],
	"Choose: pay 2{material} and place 1{progress} on this card OR abandon this card and gain all {progress} on it.": [N(["pay", [P({ m: 2 }, [{
		k: "token",
		res: "pr",
		n: 1,
		to: "self"
	}])]], ["abandon", [I("abandonSelfGainProgress")]])],
	"Abandon up to 3 {region}. For each {region} abandoned, you MAY acquire {region}/{tributary}.": [I("abandonUpTo3Acquire")],
	"Return up to 2 {unrest} from your hand or discard pile. Break through for {region}/{tributary}.": [{
		k: "unrestReturn",
		n: 2,
		from: "handOrDiscard"
	}, L("{region}/{tributary}", "break")],
	"Add 1{population} from the supply to a card in the market, then you MAY abandon this card.": [P({}, [{
		k: "token",
		res: "p",
		n: 1,
		to: "market"
	}]), M([I("abandonSelf")])],
	"When you would gain {material}, instead each other player instead gain 1{progress} and you gain 2{population}.": [],
	"Passive: when you would gain {material}, instead each other player instead gain 1{progress} and you gain 2{population}.": [],
	"Choose: break through for {uncivilised}/{civilised}/{region}/{tributary} (you MAY choose an exiled card) OR put this card into your history.": [N(["break", [L("{uncivilised}/{civilised}/{region}/{tributary}", "break", { exiled: !0 })]], ["history", [I("thisToHistory")]])],
	"Choose: put this card into your history OR break through for {uncivilised}/{civilised}/{region}/{tributary}.": [N(["history", [I("thisToHistory")]], ["break", [L("{uncivilised}/{civilised}/{region}/{tributary}", "break")]])],
	"Choose: exile a card from the market OR gain 1{population}.": [N(["exile", [{
		k: "exile",
		from: "market",
		sel: void 0
	}]], ["gain", [j(0, 1)]])],
	"Choose: return an {unrest} OR you MAY garrison a card.": [N(["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}]], ["garrison", [M([{ k: "garrison" }])]])],
	"Choose: gain 2{material} OR look at the top card of your nation deck, then you MAY shuffle the nation deck.": [N(["material", [j(2)]], ["look", [{
		k: "peek",
		from: "nation",
		n: 1
	}, { k: "shuffleNation" }]])],
	"Choose: gain 1{population} OR look at the top card of your nation deck, then you MAY shuffle the nation deck.": [N(["population", [j(0, 1)]], ["look", [{
		k: "peek",
		from: "nation",
		n: 1
	}, { k: "shuffleNation" }]])],
	"Choose: gain 1{progress} OR pay 1{population} to break through for {uncivilised} OR return an {unrest} to gain 1{population}.": [N(["progress", [j(0, 0, 1)]], ["break", [P({ p: 1 }, [L("{uncivilised}", "break")])]], ["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}, j(0, 1)]])],
	"Choose: pay 1{population} to acquire {region} OR gain 1{progress} OR return an {unrest}.": [N(["acquire", [P({ p: 1 }, [L("{region}")])]], ["progress", [j(0, 0, 1)]], ["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}]])],
	"Choose: develop OR acquire {civilised}.": [N(["develop", [{ k: "develop" }]], ["acquire", [L("{civilised}")]])],
	"Choose: gain 1{progress} OR return an {unrest}.": [N(["progress", [j(0, 0, 1)]], ["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}]])],
	"Choose: return an {unrest} and gain 1{population} OR draw 2 cards.": [N(["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}, j(0, 1)]], ["draw", [{
		k: "draw",
		n: 2
	}]])],
	"Choose: draw 2 cards, OR you MAY acquire {region}/{tributary}.": [N(["draw", [{
		k: "draw",
		n: 2
	}]], ["acquire", [M([L("{region}/{tributary}")])]])],
	"Choose: break through for {tributary} OR break through for {region} and each other player recalls a {region}.": [N(["tributary", [L("{tributary}", "break")]], ["region", [L("{region}", "break"), F("others", [{
		k: "recall",
		n: 1,
		sel: { s: ["region"] },
		optional: !0
	}])]])],
	"Choose: acquire {uncivilised} OR break through for {uncivilised} and all other players gain 1{progress}.": [N(["acquire", [L("{uncivilised}")]], ["break", [L("{uncivilised}", "break"), F("others", [j(0, 0, 1)])]])],
	"Choose: develop OR pay 2{material} to acquire {uncivilised}/{civilised}.": [N(["develop", [{ k: "develop" }]], ["acquire", [P({ m: 2 }, [L("{uncivilised}/{civilised}")])]])],
	"Choose: put a {mask} from your discard pile into your history OR discard 3 {mask} to acquire {uncivilised}/{civilised}/{region}/{tributary}.": [N(["history", [R(1, { t: ["mask"] }, "history", { from: "discard" })]], ["acquire", [P({ discardMask: 3 }, [L("{uncivilised}/{civilised}/{region}/{tributary}")])]])],
	"Choose: pay all your {progress} (minimum 5) to flip this card OR discard a card, then draw a card.": [N(["flip", [P({ progressAll: { min: 5 } }, [I("flipSelf")])]], ["discard", [{
		k: "discard",
		n: 1
	}, {
		k: "draw",
		n: 1
	}]])],
	"Choose: pay all your {progress} (minimum 5) to flip this card OR draw a card.": [N(["flip", [P({ progressAll: { min: 5 } }, [I("flipSelf")])]], ["draw", [{
		k: "draw",
		n: 1
	}]])],
	"Choose: pay all your {progress} (minimum 5) to replace this card with [Gates of Shangri-La] OR you MAY draw a {region} from your discard pile.": [N(["replace", [P({ progressAll: { min: 5 } }, [I("replaceSelf|Gates of Shangri-La")])]], ["draw", [M([R(1, { s: ["region"] }, "hand", { from: "discard" })])]])],
	"Choose: recall a {knight} garrisoned here or draw a card.": [N(["recall", [I("recallGarrisonedHere|knight")]], ["draw", [{
		k: "draw",
		n: 1
	}]])],
	"Choose: recall a {region} OR abandon this card and gain 1{population}.": [N(["recall", [{
		k: "recall",
		n: 1,
		sel: { s: ["region"] },
		optional: !0
	}]], ["abandon", [I("abandonSelf"), j(0, 1)]])],
	"Choose: take {unrest} OR abandon this card and gain 1{material}.": [N(["unrest", [{
		k: "unrestTake",
		n: 1
	}]], ["abandon", [I("abandonSelf"), j(1)]])],
	"Choose: discard a card OR abandon this card and draw a card.": [N(["discard", [{
		k: "discard",
		n: 1
	}]], ["abandon", [I("abandonSelf"), {
		k: "draw",
		n: 1
	}]])],
	"Choose: take {unrest} OR discard 2 cards.": [N(["unrest", [{
		k: "unrestTake",
		n: 1
	}]], ["discard", [{
		k: "discard",
		n: 2
	}]])],
	"Choose: take {unrest} OR pay 3{material}.": [N(["unrest", [{
		k: "unrestTake",
		n: 1
	}]], ["material", [P({ m: 3 }, [])]])],
	"Choose: gain 2{material} OR return a {region} from your discard pile to your hand.": [N(["material", [j(2)]], ["region", [R(1, { s: ["region"] }, "hand", { from: "discard" })]])],
	"Choose: gain 1{progress} OR return a {region} from your discard pile to your hand.": [N(["progress", [j(0, 0, 1)]], ["region", [R(1, { s: ["region"] }, "hand", { from: "discard" })]])],
	"Choose: gain 2{material} OR return an {unrest} from your discard pile.": [N(["material", [j(2)]], ["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "discard"
	}]])],
	"Choose: return an {unrest} OR gain 1{progress} and you MAY return an {exhaust} to your state card.": [N(["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}]], ["progress", [j(0, 0, 1), M([I("returnExhaustToken")])]])],
	"Choose: draw a card OR put a card from your hand or discard pile into your history.": [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["history", [R(1, void 0, "history", { from: "handOrDiscard" })]])],
	"Choose: acquire {uncivilised}/{civilised} OR abandon [King Arthur] to free play an {empire} card.": [N(["acquire", [L("{uncivilised}/{civilised}")]], ["arthur", [I("abandonArthurFreeEmpire")]])],
	"Choose: acquire {uncivilised}/{civilised}/{region}/{tributary} OR if [Palace of Poseidon] is in play, break through {uncivilised}/{civilised}/{region}/{tributary} twice.": [N(["acquire", [L("{uncivilised}/{civilised}/{region}/{tributary}")]], ["break", [I("breakTwicePalace")]])],
	"Choose: sink a card from your discard pile to steal 1{progress} from each player OR break through for {uncivilised}/{civilised}/{region}/{tributary} and sink this card.": [N(["sink", [R(1, void 0, "history", { from: "discard" }), {
		k: "steal",
		pr: 1,
		from: "each"
	}]], ["break", [L("{uncivilised}/{civilised}/{region}/{tributary}", "break"), I("sinkSelf")]])],
	"Choose: spend an action and take {unrest} to develop OR pay 1{population} and take {unrest} to gain an action.": [N(["develop", [P({
		actions: 1,
		unrest: 1
	}, [{ k: "develop" }])]], ["action", [P({
		p: 1,
		unrest: 1
	}, [{
		k: "actions",
		n: 1
	}])]])],
	"Exhaust to choose: return an {exhaust} to your state card OR spend an action to return a card from your discard pile to your hand.": [N(["return", [I("returnExhaustToken")]], ["action", [P({ actions: 1 }, [R(1, void 0, "hand", { from: "discard" })])]])],
	"Exhaust: choose: place an {attack} from your discard pile on the top of your deck OR swap an exiled card with a card in the market.": [N(["top", [R(1, { h: ["atk"] }, "deckTop", { from: "discard" })]], ["swap", [{ k: "swapExileMarket" }]])],
	"Exhaust: choose: put a {mask} from your discard pile into your history OR discard 3 {mask} to acquire {uncivilised}/{civilised}/{region}/{tributary}.": [N(["history", [R(1, { t: ["mask"] }, "history", { from: "discard" })]], ["acquire", [P({ discardMask: 3 }, [L("{uncivilised}/{civilised}/{region}/{tributary}")])]])],
	"Exhaust: choose: recall a {river} to gain 2{material} and 1{population} OR recall a {fertile} to gain 1 action.": [N(["river", [{
		k: "recall",
		n: 1,
		sel: { t: ["river"] }
	}, j(2, 1)]], ["fertile", [{
		k: "recall",
		n: 1,
		sel: { t: ["fertile"] }
	}, {
		k: "actions",
		n: 1
	}]])],
	"Exhaust: choose: recall a {fertile} to gain 2{material} and 1{population} OR recall a {river} to gain 1 action.": [N(["fertile", [{
		k: "recall",
		n: 1,
		sel: { t: ["fertile"] }
	}, j(2, 1)]], ["river", [{
		k: "recall",
		n: 1,
		sel: { t: ["river"] }
	}, {
		k: "actions",
		n: 1
	}]])],
	"Exhaust: choose: spend an action and take {unrest} to develop OR pay 1{population} and take {unrest} to gain an action.": [N(["develop", [P({
		actions: 1,
		unrest: 1
	}, [{ k: "develop" }])]], ["action", [P({
		p: 1,
		unrest: 1
	}, [{
		k: "actions",
		n: 1
	}])]])],
	"Exhaust: put a {mask} into your history to gain 2{progress}.": [P({ historyPut: {
		n: 1,
		from: "hand"
	} }, [j(0, 0, 2)])],
	"Exhaust: spend an action, place 2 cards on the top of your deck, and pay 1{population} to break through for {tributary}.": [P({
		actions: 1,
		topDeck: 2,
		p: 1
	}, [L("{tributary}", "break")])],
	"Exhaust: spend 2 actions to break through for {uncivilised}/{civilised}.": [P({ actions: 2 }, [L("{uncivilised}/{civilised}", "break")])],
	"Exhaust: spend an action and take {unrest} to break through for {region}.": [P({
		actions: 1,
		unrest: 1
	}, [L("{region}", "break")])],
	"Exhaust: if [Camelot] is in play, discard a card to return an {unrest}.": [xe("Camelot", [P({ cards: 1 }, [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}])])],
	"Exhaust: pay 1{progress} to free play an {empire}.": [P({ progress: 1 }, [I("freePlayEmpire")])],
	"Exhaust: if [Mountain of Atlantis] is in play, discard a card to return an {unrest}.": [xe("Mountain of Atlantis", [P({ cards: 1 }, [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}])])],
	"Exhaust: if you have at least 3 [Long Walls] in play, exhaust this card and return a card to the top of your deck to gain 1 action.": [I("longWallsThreeAction")],
	"Exhaust: if you gain a card from the market with {population} on it, double the {population} gained.": [],
	"Exhaust: when you gain a card from the market with {material} on it, double the {material} gained.": [],
	"Exhaust: when you play a {region}, exhaust this card to choose: draw a card OR gain 2{material}.": [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["material", [j(2)]])],
	"Exhaust: when a card effect requires you to discard {mask}, exhaust this card to discard 1 {mask} fewer.": [],
	"Exhaust: resolve the exhaust keyword on an opponent's {pinned} card as though it were your own.": [I("copyOpponentPinnedExhaust")],
	"Exhaust: ignore the {empire} icon on the next card you play this turn.": [I("ignoreEmpireNext")],
	"Exhaust: add 1{population} from the supply to a card in the market, then you MAY abandon this card.": [P({}, [{
		k: "token",
		res: "p",
		n: 1,
		to: "market"
	}]), M([I("abandonSelf")])],
	"If {barbarian}, you MAY pay 1{material} to return an {unrest}. If {empire}, you MAY pay 3{material} to gain 1{progress}.": [oe("b", [M([P({ m: 1 }, [{
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}])])]), oe("e", [M([P({ m: 3 }, [j(0, 0, 1)])])])],
	"If {barbarian}, all other players recall a {region}.": [oe("b", [F("others", [{
		k: "recall",
		n: 1,
		sel: { s: ["region"] },
		optional: !0
	}])])],
	"If [Mountain of Atlantis] leaves play, sink this card.": [],
	"Solstice: choose: pay 2{material} and place 1{progress} on this card OR abandon this card and gain all {progress} on it.": [I("solsticeMinoanToken")],
	"Solstice: if there is no active quest, you MAY take {unrest} to garrison an impending quest.": [I("garrisonImpendingQuest")],
	"Solstice: if you have at least 24{population} GAME END IS TRIGGERED.": [{
		k: "if",
		cond: {
			c: "res",
			p: 24
		},
		then: [{ k: "endGame" }]
	}],
	"Solstice: all other players MAY return an {unrest}. You gain 1{population} for each {unrest} returned.": [I("othersUnrestReturnGain")],
	"Solstice: you MAY discard a card to choose: gain 1{material} OR gain 1{population} OR draw a card.": [M([P({ cards: 1 }, [N(["material", [j(1)]], ["population", [j(0, 1)]], ["draw", [{
		k: "draw",
		n: 1
	}]])])])],
	"Solstice: choose: gain 1{material} OR gain 1{population} OR draw a card.": [N(["material", [j(1)]], ["population", [j(0, 1)]], ["draw", [{
		k: "draw",
		n: 1
	}]])],
	"Solstice: you MAY gain 2{progress}. If you do, choose: abandon this card OR put it into your history.": [M([j(0, 0, 2), N(["abandon", [I("abandonSelf")]], ["history", [I("thisToHistory")]])])],
	"Solstice: you MAY discard a {knight} to choose: exile an impending quest (except [Graal]) OR return up to 2 {unrest} from your hand or discard.": [I("knightExileQuestOrUnrest")],
	"Solstice: put a {knight} into your history (garrisoned or from your hand) or take 2 {unrest}.": [I("knightToHistoryOrUnrest")],
	"Solstice: you MAY pay 1{progress} to recall this card.": [M([P({ progress: 1 }, [I("recallSelf")])])],
	"Solstice: you MAY discard a card to return an {unrest} from your discard pile.": [M([P({ cards: 1 }, [{
		k: "unrestReturn",
		n: 1,
		from: "discard"
	}])])],
	"Solstice: you MAY draw a {mask} from your discard pile.": [M([R(1, { t: ["mask"] }, "hand", { from: "discard" })])],
	"Solstice: you MAY garrison a card here.": [M([{
		k: "garrison",
		here: !0
	}])],
	"Solstice: choose: gain 1{progress} OR return a {region} from your discard pile to your hand.": [N(["progress", [j(0, 0, 1)]], ["region", [R(1, { s: ["region"] }, "hand", { from: "discard" })]])],
	"Solstice: choose: gain 2{material} OR return a {region} from your discard pile to your hand.": [N(["material", [j(2)]], ["region", [R(1, { s: ["region"] }, "hand", { from: "discard" })]])],
	"Solstice: choose: take {unrest} OR discard 2 cards.": [N(["unrest", [{
		k: "unrestTake",
		n: 1
	}]], ["discard", [{
		k: "discard",
		n: 2
	}]])],
	"Solstice: choose: gain 1{population} OR pay 2{population} to gain 1{progress}.": [N(["population", [j(0, 1)]], ["progress", [P({ p: 2 }, [j(0, 0, 1)])]])],
	"Solstice: draw a card OR abandon this card and return an {unrest}.": [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["abandon", [I("abandonSelf"), {
		k: "unrestReturn",
		n: 1,
		from: "handOrDiscard"
	}]])],
	"Solstice: draw a card OR abandon this card, returning any garrisoned {unrest}.": [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["abandon", [I("abandonSelfReturnGarrisonUnrest")]])],
	"Solstice: discard a card and gain 1{progress}.": [P({ cards: 1 }, [j(0, 0, 1)])],
	"Solstice: discard a card. Gain 1{progress}.": [P({ cards: 1 }, [j(0, 0, 1)])],
	"Solstice: discard a card. You MAY return an {unrest} from your hand. You MAY return an {unrest} from your discard pile.": [
		{
			k: "discard",
			n: 1
		},
		M([{
			k: "unrestReturn",
			n: 1,
			from: "hand"
		}]),
		M([{
			k: "unrestReturn",
			n: 1,
			from: "discard"
		}])
	],
	"Solstice: gain 2{population} and discard a card.": [j(0, 2), {
		k: "discard",
		n: 1
	}],
	"Solstice: gain 3{material} and discard a card.": [j(3), {
		k: "discard",
		n: 1
	}],
	"Solstice: draw a card and discard a card.": [{
		k: "draw",
		n: 1
	}, {
		k: "discard",
		n: 1
	}],
	"Solstice: return an {unrest} from your discard pile.": [{
		k: "unrestReturn",
		n: 1,
		from: "discard"
	}],
	"Solstice: discard 2 cards.": [{
		k: "discard",
		n: 2
	}],
	"Solstice: discard a card.": [{
		k: "discard",
		n: 1
	}],
	"Solstice: gain 2{material}.": [j(2)],
	"Solstice: gain 1{population}.": [j(0, 1)],
	"Solstice: gain 2{progress}.": [j(0, 0, 2)],
	"Solstice: you MAY pay 1{material} to gain 1{population}.": [M([P({ m: 1 }, [j(0, 1)])])],
	"Solstice: you MAY pay 1{material} to return a {region} from your discard pile to your hand.": [M([P({ m: 1 }, [R(1, { s: ["region"] }, "hand", { from: "discard" })])])],
	"Solstice: you MAY pay 1{population} to gain 1{progress}.": [M([P({ p: 1 }, [j(0, 0, 1)])])],
	"Solstice: you MAY recall a {region}.": [M([{
		k: "recall",
		n: 1,
		sel: { s: ["region"] },
		optional: !0
	}])],
	"Solstice: you MAY return a {region} from your discard pile to your hand.": [M([R(1, { s: ["region"] }, "hand", { from: "discard" })])],
	"Solstice: you MAY put a card from your hand or discard pile into your history.": [M([R(1, void 0, "history", { from: "handOrDiscard" })])],
	"Solstice: you MAY discard a card to gain 1{progress}.": [M([P({ cards: 1 }, [j(0, 0, 1)])])],
	"Solstice: you MAY discard a card to draw a card and gain 1{progress}.": [M([P({ cards: 1 }, [{
		k: "draw",
		n: 1
	}, j(0, 0, 1)])])],
	"When put into play, flip your state card to its {empire} side.": [{
		k: "flip",
		to: "e"
	}],
	"Cannot be played.": [],
	"Cannot be garrisoned.": [],
	"This card cannot be garrisoned.": [],
	"Cannot be abandoned or recalled.": [],
	"This card cannot be abandoned or recalled.": [],
	"PUT INTO PLAY WHEN GAINED.": [],
	"Put into play when gained.": [],
	"Pick up and examine the indicated card or cards without showing other players.": [],
	"Any player you give a {mask} also takes {unrest}.": [],
	"Break through for a {variable} card.": [L("{uncivilised}/{civilised}/{region}/{tributary}", "break")],
	"Abandon a {pinned} (not a {region}) to break through for {uncivilised}/{civilised}.": [P({ abandon: {
		n: 1,
		sel: {
			h: ["pin"],
			x: ["region"]
		}
	} }, [L("{uncivilised}/{civilised}", "break")])],
	"If {barbarian}, put the top card of your nation deck into your discard pile.": [oe("b", [{
		k: "nationTop",
		dest: "discard"
	}])],
	"Abandon [Viviane of the Lake] OR [Ynys Afallach] to break through for {tributary}/{civilised}.": [P({ abandon: {
		n: 1,
		sel: {},
		named: ["Viviane of the Lake", "Ynys Afallach"]
	} }, [L("{tributary}/{civilised}", "break")])],
	"Put a {knight} into your history (garrisoned or from your hand) or take 2 {unrest}.": [I("knightToHistoryOrUnrest")],
	"You MAY abandon a {region} with garrisoned [Myrddin Wyllt] to put both the active quest and the top card of your nation deck in your discard pile.": [M([I("abandonMyrddinRegion")])],
	"Abandon 3 {knight} garrisoned in {region} to draw the active quest into your hand.": [I("drawActiveQuest")],
	"You MAY exile [Twrch Trwyth] if it is in play or it is the active quest.": [M([I("exileTwrch")])],
	"Each other player takes {unrest} and discards a card.": [F("others", [{
		k: "unrestTake",
		n: 1
	}, {
		k: "discard",
		n: 1
	}])],
	"All players gain 1{material}, you gain 1{progress}.": [F("all", [j(1)]), j(0, 0, 1)],
	"Put a card from your hand into your history to choose: draw a card OR return an {unrest} from your discard pile OR both.": [P({ historyPut: {
		n: 1,
		from: "hand"
	} }, [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["unrest", [{
		k: "unrestReturn",
		n: 1,
		from: "discard"
	}]], ["both", [{
		k: "draw",
		n: 1
	}, {
		k: "unrestReturn",
		n: 1,
		from: "discard"
	}]])])],
	"If there are 2 {scroll} garrisoned here, you MAY abandon this card to draw the top card of the {fame} deck.": [I("scrollGarrisonFame")],
	"Draw a card OR abandon this card, returning any garrisoned {unrest}.": [N(["draw", [{
		k: "draw",
		n: 1
	}]], ["abandon", [I("abandonSelfReturnGarrisonUnrest")]])],
	"You gain 1{population} for each {unrest} returned.": [I("gainPerUnrestReturned")],
	"If it was an {attack}, also gain 1{progress}.": [I("ifAttackProgress")],
	"Pay up to 3{progress}. For each {progress} paid, acquire {uncivilised}/{civilised}/{region}/{tributary}.": [I("payProgressAcquire")],
	"For each {progress} paid, acquire {uncivilised}/{civilised}/{region}/{tributary}.": [],
	"Pay 1{material} and declare one of the following: {uncivilised}, {civilised}, {region}, or {tributary}.": [I("gamble")],
	"Treat 1 {fertile} as 3 {production} for the rest of the turn.": [I("treatAsProduction|fertile")],
	"Treat 1 {river} as 3 {production} for the rest of the turn.": [I("treatAsProduction|river")],
	"Exhaust: treat 1 {fertile} as 3 {production} for the rest of the turn.": [I("treatAsProduction|fertile")],
	"Exhaust: treat 1 {river} as 3 {production} for the rest of the turn.": [I("treatAsProduction|river")],
	"If there is no active quest, you MAY take {unrest} to garrison an impending quest.": [I("garrisonImpendingQuest")],
	"You MAY discard a {knight} to choose: exile an impending quest (except [Graal]) OR return up to 2 {unrest} from your hand or discard.": [I("knightExileQuestOrUnrest")],
	"Exhaust: you MAY recall a {river} or a {fertile} to acquire a card in the market that has {material} on it.": [M([P({ recall: {
		n: 1,
		sel: { t: ["river", "fertile"] }
	} }, [L("", "acquire", { token: "m" })])])],
	"Exhaust: pay 3{material} and discard a card to acquire a card in the market that has {material} on it.": [P({
		m: 3,
		cards: 1
	}, [L("", "acquire", { token: "m" })])],
	"Exhaust: spend an action and discard 2 cards to choose: acquire {tributary}/{uncivilised}/{civilised} with {population} on it OR return up to 2 {unrest} from your discard pile.": [P({
		actions: 1,
		cards: 2
	}, [N(["acquire", [L("{tributary}/{uncivilised}/{civilised}", "acquire", { token: "p" })]], ["unrest", [{
		k: "unrestReturn",
		n: 2,
		from: "discard"
	}]])])]
}, ce = [];
function le(e) {
	let t = Ee.get(e);
	if (t) return t;
	let n = b[e], r = {
		play: [],
		free: !1,
		exhaust: [],
		solstice: [],
		passive: [],
		onGain: [],
		endGame: !1,
		playReq: [],
		staticText: [],
		triggers: [],
		mods: {}
	};
	if (!n) return Ee.set(e, r), r;
	let i = n.text?.[1] ?? [], a = "play", o = null;
	for (let t of i) {
		let n = k(O(t));
		if (n && n !== "^" && !n.startsWith("Setup:")) {
			if (n.startsWith("Passive:")) {
				r.passive.push(n);
				continue;
			}
			if (!/^(Cannot|Only playable|Can only be played)/.test(n)) {
				let e = se[n];
				if (e) {
					n.startsWith("Free play.") && (r.free = !0), (n.startsWith("Exhaust:") ? r.exhaust : n.startsWith("Solstice:") ? r.solstice : n.startsWith("Free play.") ? r.play : a === "solstice" ? r.solstice : a === "exhaust" ? r.exhaust : r.play).push(...e);
					continue;
				}
			}
			if (/GAME END/.test(n)) {
				r.endGame = !0, /^Free play\./.test(n) && (r.free = !0);
				continue;
			}
			if (n.startsWith("Solstice:")) {
				a = "solstice", o = null, me(k(n.slice(9).trim()), r, e, a);
				continue;
			}
			if (n.startsWith("Exhaust:")) {
				let t = k(n.slice(8).trim()), i = ue(t, r, !0);
				if (i) {
					o = typeof i == "object" ? i : null, a = "exhaust";
					continue;
				}
				a = "exhaust", o = null, me(t, r, e, a);
				continue;
			}
			if (n.startsWith("Free play.")) {
				r.free = !0, a = "play", o = null;
				let t = k(n.slice(10).trim());
				if (!t) continue;
				if (t.startsWith("Exhaust:")) {
					let n = k(t.slice(8).trim()), i = ue(n, r, !0);
					if (i) {
						o = typeof i == "object" ? i : null, a = "exhaust";
						continue;
					}
					me(n, r, e, "exhaust");
					continue;
				}
				if (t.startsWith("Solstice:")) {
					me(k(t.slice(9).trim()), r, e, "solstice");
					continue;
				}
				me(t, r, e, "play");
				continue;
			}
			if (n.startsWith("Cannot be played") || n.startsWith("Only playable") || n.startsWith("Can only be played")) {
				r.playReq.push(n);
				continue;
			}
			if (n.startsWith("When you would gain this card")) {
				let t = z(n, e);
				pe(r.onGain, t, e, n, "play");
				continue;
			}
			if (/^(Cannot be garrisoned|This card cannot be garrisoned|Cannot be abandoned or recalled|This card cannot be abandoned or recalled)\.?$/.test(n)) {
				r.staticText.push(n);
				continue;
			}
			if (/^\[Cannot be targeted/.test(n)) {
				r.staticText.push(n);
				continue;
			}
			{
				let e = ue(n, r, !1);
				if (e) {
					o = typeof e == "object" ? e : null;
					continue;
				}
			}
			if (!(/^Your \[(?:Advance|Conquer)\]/.test(n) || /^Your \[Conquer\] and \{attack\} cards/.test(n)) && !/^When another player plays an \{attack\}/.test(n) && !/^When you gain a card from the market with \{(material|population)\} on it, double/.test(n) && !/^If you gain a card from the market with \{population\} on it, double/.test(n) && !/^When you gain a card from the market with \{population\} on it, double/.test(n) && !/^When a card effect requires you to discard \{mask\}, exhaust this card to discard 1 \{mask\} fewer/.test(n) && !/^If \[Mountain of Atlantis\] leaves play, sink this card/.test(n) && !/^Any player you give a \{mask\} also takes \{unrest\}/.test(n) && !/^Remember that when you acquire an exiled/.test(n)) {
				if (o) {
					o.eff.push(...z(n, e) ?? []);
					continue;
				}
				me(n, r, e, a);
			}
		}
	}
	let s = de([...r.passive, ...i.map((e) => k(O(e)))]);
	return s && (r.shield = s), Object.assign(r.mods, fe(r.passive)), Ee.set(e, r), r;
}
function ue(e, t, n) {
	let r, i = (e, r, i = {}) => {
		let a = {
			on: e,
			eff: (r ? z(r, "") : []) ?? [],
			exhaust: n,
			...i
		};
		return t.triggers.push(a), a;
	};
	return r = e.match(/^When you return an \{unrest\}, exhaust this card(?: and spend an action)? to (.+)$/), r ? i("returnUnrest", r[1], { actions: /spend an action/.test(e) ? 1 : void 0 }) : (r = e.match(/^When you play a \{region\} from your discard pile, (?:exhaust this card to )?(.+)$/), r ? i("playRegionFromDiscard", r[1]) : (r = e.match(/^When you play a \{region\}, exhaust this card to (.+)$/), r ? i("playRegion", r[1]) : (r = e.match(/^When you play an \{attack\}, exhaust this card to (.+)$/), r ? i("playAttack", r[1]) : (r = e.match(/^When you acquire (\{region\}|\{uncivilised\}), exhaust this card to (.+)$/), r ? i(r[1] === "{region}" ? "acquireRegion" : "acquireUncivilised", r[2]) : /^When you acquire \{uncivilised\} or break through for \{uncivilised\}, exhaust this card\.?$/.test(e) ? i("acquireUncivilised", void 0) : (r = e.match(/^When you gain \{material\} from a \{(river|fertile)\} in play, exhaust this card to (.+)$/), r ? i("gainMaterialFrom", r[2], { src: r[1] }) : (r = e.match(/^When a card is sunk, exhaust this card to (.+)$/), r ? i("sunk", r[1]) : (r = e.match(/^When you take \{unrest\}, look at the top card of your nation deck\. You MAY place it at the bottom of the nation deck\.?$/), r ? (t.mods.unrestPeekNation = !0, "noop") : /^When another player plays an \{attack\}/.test(e) || /^When you would gain this card/.test(e) ? "noop" : null)))))));
}
function de(e) {
	let t = e.join(" ");
	if (/exhaust this card and pay 1\{population\} to avoid/.test(t)) return "exhaustPayPop";
	if (/MAY exhaust this card to avoid/.test(t) || /exhaust this card to avoid its effects/.test(t)) return "exhaust";
	if (/MAY pay 1\{population\} to avoid/.test(t)) return "payPop";
	if (/ignore the effects unless they give you 1\{progress\}/.test(t)) return "ignoreUnlessProgress";
	if (/recall any \[Long Walls\]/.test(t)) return "recallLongWalls";
	if (/recall this card to avoid|recall this to avoid/.test(t)) return "recallSelf";
}
function fe(e) {
	let t = {};
	for (let n of e) /increase your hand size by 1/.test(n) && (t.handSize = 1), /reduce development cost by 2\{material\}/.test(n) && (t.devM = 2), /reduce development costs by 1\{population\}/.test(n) && (t.devP = 1), /reduce development costs by 1\{progress\}/.test(n) && (t.devPr = 1), /reduce the cost in \{material\} to play an \{unrest\} by 2/.test(n) && (t.unrestCostM = 2), /reduce the cost in \{material\} or cards to play an \{unrest\} by 1/.test(n) && (t.unrestCostAny = 1), /counts as two \{region\}/.test(n) && (t.regionsCount = 2), /cards that would be placed into your history are instead discarded/.test(n) && (t.historyToDiscard = !0), /when your deck is empty, take \{unrest\}/.test(n) && (t.deckEmptyUnrest = !0), /you can free play \{city\} and \{metropolis\} cards/.test(n) && (t.freePlayCity = !0), /you can acquire exiled \{region\}\/\{tributary\}/.test(n) ? t.acquireExile = ["region", "tributary"] : /may acquire exiled \{region\}/.test(n) && (t.acquireExile = ["region"]), /when you play an \{attack\}, gain 1\{progress\}/.test(n) && (t.attackProgress = !0), /when you play a \{region\} from your discard pile, gain 2\{material\}/.test(n) && (t.regionDiscardGainM = 2), /anytime you pay \{population\}, you MAY put a card from your hand into your history/.test(n) && (t.payPopHistory = !0), /a \{development\} card that is garrisoned here is considered the active quest/.test(n) && (t.questHost = !0), /look at one additional card, then gain 1\{progress\}/.test(n) && (t.lookFameExtra = !0), /when you would place 1\{progress\} on a card in the market, instead place 1\{material\}/.test(n) && (t.marketToken = "m"), /when you would place 1\{progress\} on a card in the market, instead place 2\{material\}/.test(n) && (t.marketToken = "m2"), /when you would place \{progress\} on a card in the market, instead place 1\{population\}/.test(n) && (t.marketToken = "p"), /when you would gain \{material\}, instead each other player instead gain 1\{progress\} and you gain 2\{population\}/.test(n) && (t.materialToProgress = !0), /when a card effect requires you to discard \{mask\}, you MAY instead abandon cards garrisoned here/.test(n) && (t.maskFromGarrison = !0), /can acquire exiled \{region\} cards\. When you do, gain 1\{population\}/.test(n) && (t.acquireExilePop = 1), /recall any \[Long Walls\] to avoid/.test(n) && (t.attackShieldLongWalls = !0);
	return t;
}
function pe(e, t, n, r, i) {
	if (t === null) {
		ce.push({
			id: n,
			line: r,
			mode: i
		});
		return;
	}
	e.push(...t);
}
function me(e, t, n, r) {
	let i = k(O(e));
	if (!i) return;
	let a = r === "exhaust" ? t.exhaust : r === "solstice" ? t.solstice : t.play, o = se[i];
	if (o) {
		a.push(...o);
		return;
	}
	let s = he(i);
	if (s.length > 1) {
		let e = Ce(s[0]);
		if (e && /^(Pay|Discard|Spend|Put|Place|Return|Abandon|Sink|Garrison|Exile)/.test(s[0])) {
			let t = [], r = !0;
			for (let e of s.slice(1)) {
				let i = z(e, n);
				if (i === null) {
					r = !1;
					break;
				}
				t.push(...i);
			}
			if (r) {
				a.push(P(e, t));
				return;
			}
		}
	}
	for (let e of s) {
		let t = se[e];
		if (t) {
			a.push(...t);
			continue;
		}
		let i = z(e, n);
		i === null && (i = _e(e, n)), pe(a, i, n, e, r);
	}
}
function he(e) {
	return e.split(/(?<=\.)\s+(?=[A-Z[])/).map((e) => e.trim()).filter(Boolean);
}
function ge(e, t) {
	let n = [], r = 0, i = 0;
	for (let a = 0; a < e.length; a++) e[a] === "(" ? r++ : e[a] === ")" ? r-- : r === 0 && e.startsWith(t, a) && (n.push(e.slice(i, a)), i = a + t.length, a = i - 1);
	return n.push(e.slice(i)), n.map((e) => e.trim());
}
function _e(e, t) {
	for (let n of [" and ", ", then "]) {
		let r = ge(e, n);
		if (r.length < 2) continue;
		let i = [], a = !0;
		for (let e of r) {
			let n = z(e, t);
			if (n === null) {
				a = !1;
				break;
			}
			i.push(...n);
		}
		if (a) return i;
	}
	return null;
}
var ve = {
	material: "m",
	population: "p",
	progress: "pr"
}, ye = /^(?:You )?[Gg]ain (\d+)\{(material|population|progress)\}(?:,? and (\d+)\{(material|population|progress)\})?(?:,? and (\d+)\{(material|population|progress)\})?\.?$/;
function be(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let t = 1; t < e.length; t += 2) {
		let a = Number(e[t]), o = ve[e[t + 1]];
		o && a && (o === "m" ? n += a : o === "p" ? r += a : i += a);
	}
	return n && t.push(j(n)), r && t.push(j(0, r)), i && t.push(j(0, 0, i)), t;
}
function xe(e, t) {
	return {
		k: "if",
		cond: {
			c: "has",
			id: e,
			zone: "play"
		},
		then: t
	};
}
function z(e, t) {
	let n = k(k(O(e)).replace(/^Then /, ""));
	if (!n) return [];
	let r = se[n];
	if (r) return r;
	let i;
	if (i = n.match(/^If \{(barbarian|empire)\},? (.+)$/), i) {
		let e = z(i[2], t);
		if (e) return [oe(i[1] === "barbarian" ? "b" : "e", e)];
	}
	if (i = n.match(/^If \[([^\]]+)\] is in play, (.+)$/), i) {
		let e = z(i[2], t);
		if (e) return [xe(i[1], e)];
	}
	for (let [e, r, a] of [
		[
			/^All players MAY (.+)$/,
			"all",
			!0
		],
		[
			/^Each player MAY (.+)$/,
			"all",
			!0
		],
		[
			/^All other players MAY (.+)$/,
			"others",
			!0
		],
		[
			/^Each other player MAY (.+)$/,
			"others",
			!0
		],
		[
			/^All players (.+)$/,
			"all",
			!1
		],
		[
			/^Each player (.+)$/,
			"all",
			!1
		],
		[
			/^All other players (.+)$/,
			"others",
			!1
		],
		[
			/^Each other player (.+)$/,
			"others",
			!1
		]
	]) if (i = n.match(e), i) {
		let e = z(Se(i[1]), t);
		if (e) return [F(r, e, a)];
	}
	if (i = n.match(/^Choose: (.+)$/), i) {
		let e = ge(i[1], " OR ");
		if (e.length > 1) {
			let n = [], r = !0;
			for (let i of e) {
				let e = z(i, t);
				if (!e) {
					r = !1;
					break;
				}
				n.push([i, e]);
			}
			if (r) return [N(...n)];
		}
	}
	if (i = n.match(/^You [Mm]ay (.+)$/), i) {
		let e = z(i[1], t);
		if (e) return [M(e)];
	}
	if (i = n.match(/^You MAY (.+)$/), i) {
		let e = z(i[1], t);
		if (e) return [M(e)];
	}
	let a = ge(n, " to ");
	for (let e = 1; e < a.length; e++) {
		let n = a.slice(0, e).join(" to "), r = a.slice(e).join(" to "), i = Ce(n);
		if (!i) continue;
		let o = z(r, t);
		if (o) return [P(i, o)];
	}
	if (i = n.match(ye), i) return be(i);
	if (i = n.match(/^Gain (\d+) \{unrest\}\.?$/), i) return [{
		k: "unrestTake",
		n: Number(i[1])
	}];
	if (i = n.match(/^Gain (\d+) (?:actions?|action)\.?$/), i) return [{
		k: "actions",
		n: Number(i[1])
	}];
	if (i = n.match(/^Gain (\d+)\{(material|population|progress)\} per \{([a-z]+)\}(?: you have)?(?: in (?:your )?play(?: area)?)?\.?$/), i) {
		let e = A("{" + i[3] + "}");
		if (e) return [{
			k: "gainPer",
			n: Number(i[1]),
			sel: e,
			zone: "play",
			res: ve[i[2]]
		}];
	}
	if (/^Draw a card\.?$/.test(n)) return [{
		k: "draw",
		n: 1
	}];
	if (i = n.match(/^Draw (\d+) cards?\.?$/), i) return [{
		k: "draw",
		n: Number(i[1])
	}];
	if (i = n.match(/^Draw up to (\d+) cards?(?: if able)?\.?$/), i) return [{
		k: "drawUpTo",
		n: Number(i[1])
	}];
	if (i = n.match(/^Draw a card from your (discard pile|history)\.?$/), i) return [R(1, void 0, "hand", { from: i[1] === "history" ? "history" : "discard" })];
	if (/^Discard a card\.?$/.test(n)) return [{
		k: "discard",
		n: 1
	}];
	if (i = n.match(/^Discard (\d+) cards?\.?$/), i) return [{
		k: "discard",
		n: Number(i[1])
	}];
	if (i = n.match(/^(?:You MAY )?(Acquire|Break through for) (\{[a-z]+\}(?:\/\{[a-z]+\})*)( twice.*)?\.?$/), i) {
		let e = L(i[2], i[1] === "Break through for" ? "break" : "acquire");
		return i[0].startsWith("You MAY") ? [M([e])] : [e];
	}
	if (/^Break through for \{region\}\.?$/.test(n)) return [L("{region}", "break")];
	if (i = n.match(/^(You MAY )?Put (?:a card|up to (\d+) cards?) from your (hand or discard pile|hand or discard|hand|discard pile) into your history\.?$/), i) {
		let e = [R(Number(i[2] ?? 1), void 0, "history", {
			from: i[3] === "hand" ? "hand" : i[3] === "discard pile" ? "discard" : "handOrDiscard",
			min: 0
		})];
		return i[1] ? [M(e)] : e;
	}
	if (/^Take \{unrest\}\.?$/.test(n)) return [{
		k: "unrestTake",
		n: 1
	}];
	if (i = n.match(/^Take (\d+) \{unrest\}\.?$/), i) return [{
		k: "unrestTake",
		n: Number(i[1])
	}];
	if (i = n.match(/^(You MAY )?Return (?:an|up to (\d+)) \{unrest\}(?: from your (discard pile|hand or discard pile|hand or discard|hand))?\.?$/), i) {
		let e = [{
			k: "unrestReturn",
			n: Number(i[2] ?? 1),
			from: i[3] === "discard pile" ? "discard" : i[3] === "hand" ? "hand" : "handOrDiscard"
		}];
		return i[1] ? [M(e)] : e;
	}
	if (i = n.match(/^Return any number of cards from your hand to the unrest pile\.?$/), i) return [{
		k: "unrestTake",
		n: 0
	}];
	if (/^Gain an action\.?$/.test(n)) return [{
		k: "actions",
		n: 1
	}];
	if (/^Develop\.?$/.test(n)) return [{ k: "develop" }];
	if (/^Develop for free\.?$/.test(n) || /^develop at no cost\.?$/i.test(n)) return [{
		k: "develop",
		free: !0
	}];
	if (/^Take the top \{fame\} card\.?$/.test(n) || /^Draw the top \{fame\} card\.?$/.test(n)) return [{
		k: "fame",
		n: 1,
		take: !0
	}];
	if (i = n.match(/^Draw (?:the )?top (\d+) \{fame\} cards?\.?$/), i) return [{
		k: "fame",
		n: Number(i[1]),
		take: !0
	}];
	if (i = n.match(/^Look at the top (\d+) cards? of (?:the )?\{fame\} deck\.?$/), i) return [{
		k: "fame",
		n: Number(i[1]),
		top: !0
	}];
	if (i = n.match(/^(You MAY )?garrison a card( here)?\.?$/i), i) {
		let e = [{
			k: "garrison",
			n: 1,
			...i[2] ? { here: !0 } : {}
		}];
		return i[1] ? [M(e)] : e;
	}
	if (i = n.match(/^(You MAY )?[Rr]ecall (?:a|an|up to (\d+)) (\{[a-z]+\})\.?$/), i) {
		let e = [{
			k: "recall",
			n: Number(i[2] ?? 1),
			sel: A(i[3]) ?? {},
			optional: !0
		}];
		return i[1] ? [M(e)] : e;
	}
	if (/^Sink this card\.?$/.test(n)) return [{
		k: "sink",
		n: 1,
		self: !0
	}];
	if (/^Exile this card\.?$/.test(n)) return [{
		k: "exile",
		from: "play",
		self: !0
	}];
	if (i = n.match(/^Exile a card from your (hand|discard pile)( \(not a \{unrest\}\))?\.?$/), i) return [{
		k: "exile",
		from: i[1] === "hand" ? "hand" : "discard",
		sel: i[2] ? { x: ["unrest"] } : void 0
	}];
	if (/^Flip this card\.?$/.test(n)) return [I("flipSelf")];
	if (i = n.match(/^Steal (\d+)\{(material|population|progress)\} from (each other player|each player|each \{empire\} player|each player with at least one \{region\} in play)\.?$/), i) {
		let e = {
			k: "steal",
			[ve[i[2]]]: Number(i[1]),
			from: "each"
		};
		return i[3].includes("empire") && (e.from = "empire"), i[3].includes("with at least") && (e.needRegion = !0), [e];
	}
	if (/^Give each other player a card from your hand or discard pile\.?$/.test(n)) return [{
		k: "give",
		n: 1,
		from: "handOrDiscard"
	}];
	if (/^Swap an exiled card with a card in the market\.?$/.test(n)) return [{ k: "swapExileMarket" }];
	if (i = n.match(/^Return a card(?: of your choice)? from your discard pile to the top of your (?:draw )?deck\.?$/), i) return [R(1, void 0, "deckTop", { from: "discard" })];
	if (i = n.match(/^You MAY place a card of your choice from your discard pile on the top of your deck\.?$/), i) return [M([R(1, void 0, "deckTop", { from: "discard" })])];
	if (i = n.match(/^Return a card from your discard pile to the top of your deck\.?$/), i) return [R(1, void 0, "deckTop", { from: "discard" })];
	if (i = n.match(/^Place (?:a|an) (\{[a-z]+\}) from your discard pile on the top of your deck\.?$/), i) return [R(1, A(i[1]), "deckTop", { from: "discard" })];
	if (i = n.match(/^Find a (\{[a-z]+\}) and add it to your hand\.?$/), i) return [{
		k: "find",
		sel: A(i[1]),
		dest: "hand",
		from: "deck"
	}];
	if (i = n.match(/^You MAY return a (\{[a-z]+\}) from your discard pile to the top of your deck\.?$/), i) return [M([R(1, A(i[1]), "deckTop", { from: "discard" })])];
	if (i = n.match(/^Abandon \[([^\]]+)\]\.?$/), i) return [I("abandonNamed|" + i[1])];
	if (/^[Rr]ecall this card\.?$/.test(n)) return [I("recallSelf")];
	if (i = n.match(/^Abandon (?:a|an|up to (\d+)) (\{[a-z]+\})\.?$/), i) return [{
		k: "abandon",
		n: Number(i[1] ?? 1),
		sel: A(i[2]) ?? {}
	}];
	if (i = n.match(/^Abandon (?:a|an|up to (\d+)) (\{[a-z]+\}) \(not a (\{[a-z]+\})\)\.?$/), i) {
		let e = A(i[2]) ?? {}, t = A(i[3]);
		return t && (e.x = t.s), [{
			k: "abandon",
			n: Number(i[1] ?? 1),
			sel: e
		}];
	}
	if (i = n.match(/^Free play (?:an?|up to (\d+)) (\{[a-z]+\})\.?$/), i) return [{
		k: "freePlay",
		sel: A(i[2])
	}];
	if (i = n.match(/^Draw (\d+) cards? and (?:discard one of them|discard a card)\.?$/), i) return [{
		k: "draw",
		n: Number(i[1])
	}, {
		k: "discard",
		n: 1
	}];
	if (i = n.match(/^Draw (\d+) cards? and return a card to the top of your deck\.?$/), i) return [{
		k: "draw",
		n: Number(i[1])
	}, R(1, void 0, "deckTop", { optional: !0 })];
	if (/^Look at the top card of your nation deck\.?$/.test(n)) return [{
		k: "peek",
		from: "nation",
		n: 1
	}];
	if (/^You MAY shuffle the nation deck\.?$/.test(n)) return [M([{ k: "shuffleNation" }])];
	if (/^Ignore the \{empire\} icon on the next card you play this turn\.?$/.test(n)) return [I("ignoreEmpireNext")];
	if (/^You may return an \{exhaust\} to your state card\.?$/.test(n)) return [M([I("returnExhaustToken")])];
	if (/^Return an \{exhaust\} to your state card\.?$/.test(n)) return [I("returnExhaustToken")];
	if (i = n.match(/^You MAY return up to (\d+) \{mask\} from your discard pile to your hand\.?$/), i) return [M([R(Number(i[1]), { t: ["mask"] }, "hand", {
		from: "discard",
		min: 0
	})])];
	if (/^You MAY draw an? \{mask\} from your discard pile\.?$/.test(n)) return [M([R(1, { t: ["mask"] }, "hand", { from: "discard" })])];
	if (/^Return an? \{knight\} from your discard pile to your hand\.?$/.test(n)) return [R(1, { t: ["knight"] }, "hand", { from: "discard" })];
	if (/^Discard a card to draw an? \{knight\} from your discard pile\.?$/.test(n)) return [P({ cards: 1 }, [R(1, { t: ["knight"] }, "hand", { from: "discard" })])];
	if (i = n.match(/^Add (\d+)\{(material|population|progress)\} to a card in the market\.?$/), i) return [{
		k: "token",
		res: ve[i[2]],
		n: Number(i[1]),
		to: "market"
	}];
	if (/^Play a \{region\} from your discard pile \(spending an action as normal\)\.?$/.test(n)) return [I("playRegionFromDiscard")];
	if (n.includes(" OR ") && !n.startsWith("Choose:")) {
		let e = ge(n, " OR ");
		if (e.length > 1) {
			let n = [], r = !0;
			for (let i of e) {
				let e = z(i, t);
				if (!e) {
					r = !1;
					break;
				}
				n.push([i, e]);
			}
			if (r) return [N(...n)];
		}
	}
	return /^Return a card to the top of your deck\.?$/.test(n) ? [R(1, void 0, "deckTop", { optional: !0 })] : /^You MAY (?:then )?abandon this card to swap a card from your hand with the top of your nation deck\.?$/.test(n) ? [M([I("abandonSelf"), { k: "swapHandNation" }])] : /^Abandon this card\.?$/.test(n) ? [I("abandonSelf")] : (i = n.match(/^You MAY (?:pay \d+\{material\} to )?return a \{region\} from your discard pile to your hand\.?$/), i ? [M([R(1, { s: ["region"] }, "hand", { from: "discard" })])] : /^Return a \{region\} from your discard pile to your hand\.?$/.test(n) ? [R(1, { s: ["region"] }, "hand", { from: "discard" })] : (i = n.match(/^You MAY pay \d+\{material\} to draw a card of your choice from your discard pile\.?$/), i ? [M([P({ m: 3 }, [R(1, void 0, "hand", { from: "discard" })])])] : /^You MAY draw a card of your choice from your discard pile and place it on the top of your draw deck\.?$/.test(n) ? [M([R(1, void 0, "deckTop", { from: "discard" })])] : /^Draw a card of your choice from your discard pile\.?$/.test(n) ? [R(1, void 0, "hand", { from: "discard" })] : /^Draw a \{scroll\} from your discard pile\.?$/.test(n) ? [R(1, { t: ["scroll"] }, "hand", { from: "discard" })] : /^Place a card on top of your deck and gain 2\{progress\}\.?$/.test(n) ? [R(1, void 0, "deckTop"), j(0, 0, 2)] : /^Return a \{mask\} from your discard(?: pile)? to your hand\.?$/.test(n) ? [R(1, { t: ["mask"] }, "hand", { from: "discard" })] : (i = n.match(/^Put a card into your history to gain 1\{progress\}\.?$/), i ? [P({ historyPut: {
		n: 1,
		from: "hand"
	} }, [j(0, 0, 1)])] : /^(Only playable|Cannot be played|Cannot be garrisoned|This card cannot|\[Cannot be targeted)/.test(n) ? [] : null)));
}
function Se(e) {
	return e.replace(/^abandons\b/i, "abandon").replace(/^discards\b/i, "discard").replace(/^recalls\b/i, "recall").replace(/^gains\b/i, "gain").replace(/^takes\b/i, "take").replace(/^draws\b/i, "draw").replace(/^acquires\b/i, "acquire").replace(/^develops\b/i, "develop").replace(/^exiles\b/i, "exile").replace(/^sinks\b/i, "sink").replace(/^returns\b/i, "return").replace(/^steals\b/i, "steal").replace(/\btheir\b/g, "your");
}
function Ce(e) {
	let t = k(k(O(e)).replace(/^Then /, ""));
	if (!t) return null;
	let n;
	for (let e of [
		" and ",
		", place ",
		", and "
	]) {
		if (e === ", place " || e === ", and ") continue;
		let n = ge(t, e);
		if (n.length > 1) {
			let e = null;
			for (let t of n) {
				let n = Ce(t);
				if (!n) {
					e = null;
					break;
				}
				e = e ? Te(e, n) : n;
			}
			if (e) return e;
		}
	}
	if (ge(t, ", ").length > 1) {
		let e = null;
		for (let n of ge(t, ", ")) {
			let t = Ce(n.replace(/^and /, ""));
			if (!t) {
				e = null;
				break;
			}
			e = e ? Te(e, t) : t;
		}
		if (e) return e;
	}
	if (n = t.match(/^Pay (\d+)\{(material|population|progress)\}(?: and (\d+)\{(material|population|progress)\})?\.?$/), n) {
		let e = {};
		return e[ve[n[2]]] = Number(n[1]), n[3] && n[4] && (e[ve[n[4]]] = Number(n[3])), we(e);
	}
	return n = t.match(/^Pay up to (\d+)\{(material|population|progress)\}\.?$/), n ? { [ve[n[2]]]: Number(n[1]) } : (n = t.match(/^Pay all your \{progress\} \(minimum (\d+)\)\.?$/), n ? { progressAll: { min: Number(n[1]) } } : (n = t.match(/^Pay (\d+)\{progress\}\.?$/), n ? { progress: Number(n[1]) } : (n = t.match(/^Spend (?:an|(\d+)) actions?\.?$/), n ? { actions: Number(n[1] ?? 1) } : /^Take \{unrest\}\.?$/.test(t) ? { unrest: 1 } : /^Discard a card\.?$/.test(t) ? { cards: 1 } : (n = t.match(/^Discard (\d+) cards?\.?$/), n ? { cards: Number(n[1]) } : (n = t.match(/^Discard (\d+) \{mask\}\.?$/), n ? { discardMask: Number(n[1]) } : (n = t.match(/^Abandon (?:a|(\d+)) (\{[a-z]+\})( with a \{knight\} garrisoned)?\.?$/), n ? { abandon: {
		n: Number(n[1] ?? 1),
		sel: A(n[2]) ?? {},
		...n[3] ? { named: "*" } : {}
	} } : (n = t.match(/^Abandon (?:\w+ )?\[([^\]]+)\]\.?$/), n ? { abandon: {
		n: 1,
		sel: {},
		named: n[1]
	} } : (n = t.match(/^Sink this card(?: and a (\{[a-z]+\}) in play)?\.?$/), n ? { sink: n[1] ? {
		n: 2,
		self: !0,
		sel: A(n[1])
	} : {
		n: 1,
		self: !0
	} } : (n = t.match(/^Sink (?:a|an) (\{[a-z]+\}) in play\.?$/), n ? { sink: {
		n: 1,
		sel: A(n[1])
	} } : (n = t.match(/^Place (?:a|(\d+)) cards? on (?:the )?top of your (?:draw )?deck\.?$/), n ? { topDeck: Number(n[1] ?? 1) } : /^Return a card to the top of your deck\.?$/.test(t) ? { returnTop: 1 } : (n = t.match(/^Return (?:an|up to (\d+)) \{unrest\} from your (discard pile|hand or discard pile|hand or discard)\.?$/), n ? { unrestReturn: {
		n: Number(n[1] ?? 1),
		from: n[2] === "discard pile" ? "discard" : "handOrDiscard"
	} } : /^Return an? \{exhaust\} to your state card\.?$/.test(t) ? { actions: 0 } : (n = t.match(/^Put a card from your (hand|discard pile|hand or discard pile) into your history\.?$/), n ? { historyPut: {
		n: 1,
		from: n[1] === "hand" ? "hand" : n[1] === "discard pile" ? "discard" : "handOrDiscard"
	} } : (n = t.match(/^Put a (\{[a-z]+\}) into your history\.?$/), n || (n = t.match(/^Put a card into your history\.?$/), n) ? { historyPut: {
		n: 1,
		from: "hand"
	} } : (n = t.match(/^Return a \{region\} from your discard pile to your hand\.?$/), n ? { recall: {
		n: 1,
		sel: { s: ["region"] }
	} } : (n = t.match(/^garrison (?:a|an) (\{[a-z]+\}) here\.?$/i), n ? { garrison: {
		n: 1,
		sel: A(n[1]),
		here: !0
	} } : (n = t.match(/^Exile a card from your hand( \(not a \{unrest\}\))?\.?$/), n ? { exileHand: {
		n: 1,
		sel: n[1] ? { x: ["unrest"] } : void 0
	} } : (n = t.match(/^[Rr]ecall (?:a|an) (\{[a-z]+\})\.?$/), n ? { recall: {
		n: 1,
		sel: A(n[1])
	} } : null)))))))))))))))));
}
function we(e) {
	return Object.keys(e).length ? e : {};
}
function Te(e, t) {
	return {
		...e,
		...t
	};
}
var Ee = /* @__PURE__ */ new Map(), B = (e, t) => e.players[t], V = (e) => b[e], H = (e) => le(e), De = (e, t) => e.order.filter((e) => e !== t);
function Oe(e) {
	e.rng = e.rng + 1831565813 >>> 0;
	let t = e.rng;
	return t = Math.imul(t ^ t >>> 15, t | 1), t ^= t + Math.imul(t ^ t >>> 7, t | 61), ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function U(e, t) {
	let n = t.slice();
	for (let t = n.length - 1; t > 0; t--) {
		let r = Math.floor(Oe(e) * (t + 1));
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function W(e, t, n, r, i) {
	let a = { key: t };
	n !== void 0 && (a.rid = n), r !== void 0 && (a.card = r), i !== void 0 && (a.n = i), e.log.push(a), e.log.length > 200 && e.log.splice(0, e.log.length - 200);
}
function ke(e) {
	return e.hdr === "pin" ? "pin" : e.hdr === "atk" ? "atk" : null;
}
function G(e, t) {
	if (!t) return !0;
	let n = V(e);
	if (!n || t.s && !t.s.some((e) => n.s.includes(e)) || t.x && t.x.some((e) => n.s.includes(e)) || t.t && !t.t.some((e) => n.t.includes(e))) return !1;
	if (t.h) {
		let e = ke(n);
		if (!e || !t.h.includes(e)) return !1;
	}
	return !0;
}
var Ae = (e) => !!V(e)?.vpt, je = /* @__PURE__ */ new Set([
	"handSize",
	"devM",
	"devP",
	"devPr"
]);
function Me(e, t) {
	let n = B(e, t), r = {}, i = (e) => {
		for (let t of Object.keys(e)) {
			let n = e[t];
			je.has(t) ? r[t] = Number(r[t] ?? 0) + Number(n) : Array.isArray(n) ? r[t] = [.../* @__PURE__ */ new Set([...Array.isArray(r[t]) ? r[t] : [], ...n])] : r[t] = n;
		}
	}, a = n.power, o = n.nationId === "utopians" && a.length > 1 ? [
		...n.play,
		a[0],
		a[a.length - 1]
	] : [...n.play, ...a];
	for (let e of o) i(H(e).mods);
	return n.mods.fertileAsProd && (r.treatFertile = n.mods.fertileAsProd), n.mods.riverAsProd && (r.treatRiver = n.mods.riverAsProd), n.mods.ignoreEmpire && (r.ignoreEmpire = !0), r;
}
function Ne(e, t) {
	let n = B(e, t), r = Number(Me(e, t).handSize ?? 0);
	for (let e of n.hand) r += Number(H(e).mods.handSize ?? 0);
	return Math.max(0, n.handSize + r);
}
function Pe(e, t, n) {
	return !!Me(e, t)[n];
}
var Fe = (e) => Object.keys(e.garrisons);
function Ie(e, t, n) {
	switch (n) {
		case "hand": return t.hand;
		case "discard": return t.discard;
		case "handOrDiscard": return [...t.hand, ...t.discard];
		case "play": return t.play;
		case "dev": return t.dev;
		case "history": return t.history;
		case "flooded": return t.flooded;
		case "deckTop": return t.deck.slice(0, 1);
		case "nationTop": return t.nation.slice(0, 1);
		case "garrison": return Fe(t).flatMap((e) => t.garrisons[e]);
		case "market": return e.market.map((e) => e.id);
		default: return [];
	}
}
function K(e, t, n, r) {
	let i = (e) => {
		let t = e.indexOf(n);
		t >= 0 && e.splice(t, 1);
	};
	switch (r) {
		case "hand":
		case "play":
		case "dev":
		case "discard":
		case "history":
		case "flooded":
			i(t[r]);
			break;
		case "handOrDiscard":
			i(t.hand), i(t.discard);
			break;
		case "deckTop":
		case "nationTop":
			i(r === "deckTop" ? t.deck : t.nation);
			break;
		case "garrison": for (let e of Fe(t)) i(t.garrisons[e]);
	}
}
function Le(e, t, n, r, i) {
	switch (r) {
		case "hand":
			t.hand.push(n);
			break;
		case "discard":
			t.discard.push(n);
			break;
		case "history":
			Re(e, t, n);
			break;
		case "flooded":
			t.flooded.push(n);
			break;
		case "deckTop":
			t.deck.unshift(n);
			break;
		case "deckBottom":
			t.deck.push(n);
			break;
		case "play":
			t.play.push(n);
			break;
		case "dev":
			t.dev.push(n);
			break;
		case "exile":
			e.exile.push(n);
			break;
		case "supply":
		case "unrest":
			e.unrestPile.push(n);
			break;
		case "nationTop":
			t.nation.unshift(n);
			break;
		case "garrisonHere": {
			let e = i ?? t.play[t.play.length - 1];
			e ? (t.garrisons[e] ??= []).push(n) : t.discard.push(n);
			break;
		}
		case "garrisonSelf":
			t.garrisons[n] ??= [], t.play.push(n);
			break;
		default: t.discard.push(n);
	}
}
function Re(e, t, n) {
	let r = D[t.nationId].historyKind;
	r === "flooded" ? t.flooded.push(n) : r === "zenith" ? t.discard.push(n) : t.history.push(n);
}
function ze(e, t, n, r, i, a) {
	let o = r === "play" ? t.garrisons[n] : void 0;
	if (o && delete t.garrisons[n], r === "market" ? e.market = e.market.filter((e) => e.id !== n) : K(e, t, n, r), Le(e, t, n, i, a), o) for (let n of o) i === "exile" ? e.exile.push(n) : Le(e, t, n, i);
}
function q(e, t, n, r, i) {
	if (n > 0 && Pe(e, t.rid, "materialToProgress")) {
		for (let r of De(e, t.rid)) q(e, B(e, r), 0, 0, n);
		t.res.p += n * 2;
		return;
	}
	n && (t.res.m += n), r && (t.res.p += r), i && (t.res.pr += i);
}
function Be(e, t, n, r) {
	let i = Math.min(e.res.pr, r), a = Math.min(e.res.p, n);
	return e.res.m >= t + (r - i) + (n - a) * 2;
}
function Ve(e, t, n, r) {
	let i = Math.min(e.res.pr, r), a = Math.min(e.res.p, n), o = t + (r - i) + (n - a) * 2;
	return e.res.m < o ? !1 : (e.res.pr -= i, e.res.p -= a, e.res.m -= o, !0);
}
function He(e, t, n) {
	for (let r = 0; r < n; r++) {
		let n = e.unrestPile.pop();
		if (!n) {
			e.collapse = !0;
			break;
		}
		t.hand.push(n), W(e, "log.takeUnrest", t.rid, n), J(e, t.rid, "takeUnrest", { card: n });
	}
	We(e), !e.collapse && Pe(e, t.rid, "unrestPeekNation") && t.nation.length && (e.looked = t.nation.slice(0, 1), e.lookedBy = t.rid, W(e, "log.peek", t.rid, void 0, 1), Z(e, {
		owner: t.rid,
		kind: "confirm",
		n: 1,
		optional: !0,
		follow: [{
			k: "special",
			id: "nationTopToBottom"
		}]
	}));
}
function Ue(e, t, n, r) {
	return (r === "hand" ? t.hand : r === "discard" ? t.discard : [...t.hand, ...t.discard]).includes(n) ? (K(e, t, n, r), e.unrestPile.push(n), e.flags.unrestReturned = (e.flags.unrestReturned ?? 0) + 1, W(e, "log.returnUnrest", t.rid, n), J(e, t.rid, "returnUnrest", { card: n }), !0) : !1;
}
function We(e) {
	!e.collapse && e.unrestPile.length === 0 && (e.collapse = !0, W(e, "log.collapse"));
}
function Ge(e) {
	e.endTriggered || (e.endTriggered = !0, e.lastTurn === null && (e.lastTurn = e.round + 1), W(e, "log.endTriggered"));
}
function Ke(e) {
	!e.endTriggered && e.decks.main.length === 0 && Ge(e);
}
function qe(e, t) {
	return t.dev.filter((n) => !!V(n)?.dev && at(e, t, n));
}
function Je(e, t) {
	let n = D[t.nationId];
	if (t.side === "b") {
		if (n.journey || !t.nation.length || t.flags.nationTok || t.actions <= 0) return !1;
		let r = t.nation.shift();
		return --t.actions, t.flags.nationTok = 1, !t.nation.length && r === t.accession ? (t.accession = null, t.nationId === "vikings" ? (t.discard.push(r), W(e, "log.accession", t.rid, r), Ge(e)) : t.nationId === "arthurians" ? Xe(e, t, r) : (t.discard.push(r), t.side = "e", W(e, "log.accession", t.rid, r))) : t.discard.push(r), !1;
	}
	if (n.journey || !t.dev.length || t.flags.devTok || t.actions <= 0 || !t.discard.length) return !1;
	let r = qe(e, t);
	if (!r.length) return !1;
	let i = {
		owner: t.rid,
		kind: "option",
		n: 1,
		optional: !0,
		opts: [{ id: "skip" }, ...r.map((e) => ({
			id: e,
			label: e
		}))],
		follow: [{
			k: "special",
			id: "resumeDraw"
		}]
	};
	return i.eff = [[], ...r.map((e) => [{
		k: "special",
		id: "developReshuffle|" + e
	}])], Z(e, i), !0;
}
function Ye(e, t) {
	t.deck.length || (t.discard.length && (t.deck = U(e, t.discard)), t.discard = []);
}
function Xe(e, t, n) {
	t.play.push(n), W(e, "log.nadir", t.rid, n);
}
function Ze(e, t) {
	if (t.deck.length === 0) {
		if (Je(e, t)) return e.pendingDraw = {
			rid: t.rid,
			n: 1
		}, !1;
		Ye(e, t);
	}
	if (t.deck.length === 0) return Pe(e, t.rid, "deckEmptyUnrest") && He(e, t, 1), !1;
	let n = t.deck.shift();
	return t.hand.push(n), W(e, "log.draw", t.rid), !0;
}
function Qe(e, t, n) {
	for (let r = 0; r < n; r++) if (!Ze(e, t)) {
		e.pendingDraw && e.pendingDraw.rid === t.rid && (e.pendingDraw.n += n - r - 1);
		break;
	}
}
var $e = {
	region: "region",
	uncivilised: "uncivilised",
	civilised: "civilised",
	main1: null,
	main2: null
};
function et(e, t) {
	$e[t];
	let n;
	if (t === "region" || t === "uncivilised" || t === "civilised" ? (n = e.decks[t].shift(), n ||= e.decks.main.shift()) : n = e.decks.main.shift(), !n) {
		e.market = e.market.filter((e) => e.slot !== t);
		return;
	}
	let r = {
		id: n,
		slot: t,
		unrest: null,
		tok: {
			m: 0,
			p: 0,
			pr: 0
		}
	}, i = V(n);
	if (i?.s.some((e) => e === "region" || e === "uncivilised" || e === "civilised")) {
		let t = e.unrestPile.pop();
		if (t && (r.unrest = t, We(e)), e.collapse) return;
	}
	i && !i.s.includes("region") && (r.tok.pr += 1), e.market.push(r), Ke(e);
}
function tt(e, t, n, r) {
	let i = e.market.find((e) => e.slot === n);
	if (!i) return null;
	let a = i.id;
	e.market = e.market.filter((e) => e !== i), t.hand.push(a);
	let o = { ...i.tok };
	return q(e, t, o.m, o.p, o.pr), o.m && W(e, "log.gainToken", t.rid, a, o.m), i.unrest && (r ? e.unrestPile.push(i.unrest) : t.hand.push(i.unrest)), et(e, n), W(e, "log.acquire", t.rid, a), J(e, t.rid, nt(a), { card: a }), a;
}
function nt(e) {
	return V(e)?.s.includes("region") ? "acquireRegion" : "acquireUncivilised";
}
function rt(e, t, n, r) {
	let i = r === "play" ? t.garrisons[n] : void 0;
	if (i && delete t.garrisons[n], K(e, t, n, r), D[t.nationId].historyKind === "flooded" ? t.flooded.push(n) : t.discard.push(n), i) for (let e of i) D[t.nationId].historyKind === "flooded" ? t.flooded.push(e) : t.discard.push(e);
	W(e, "log.sink", t.rid, n), J(e, t.rid, "sunk", { card: n });
}
function it(e, t, n) {
	let r = V(n)?.dev ?? [
		0,
		0,
		0
	], i = Me(e, t.rid);
	return [
		Math.max(0, r[0] - Number(i.devM ?? 0)),
		Math.max(0, r[1] - Number(i.devP ?? 0)),
		Math.max(0, r[2] - Number(i.devPr ?? 0))
	];
}
function at(e, t, n) {
	let [r, i, a] = it(e, t, n);
	return Be(t, r, i, a);
}
function ot(e, t, n, r = !1) {
	if (!t.dev.includes(n)) return !1;
	if (!r) {
		let [r, i, a] = it(e, t, n);
		if (!Ve(t, r, i, a)) return !1;
	}
	return K(e, t, n, "dev"), t.discard.push(n), W(e, "log.develop", t.rid, n), t.dev.length === 0 && D[t.nationId].quests === !1 && Ge(e), !0;
}
function J(e, t, n, r) {
	let i = B(e, t), a = [...i.play, ...i.power];
	for (let o of a) {
		let a = H(o);
		for (let s of a.triggers) {
			if (s.on !== n || s.src && r.src !== s.src || n === "playRegionFromDiscard" && r.card && i.discard.includes(r.card) || s.exhaust && (i.exhausts <= 0 || i.exhausted.includes(o))) continue;
			let a = [];
			s.exhaust && a.push({
				k: "special",
				id: "exhaustToken|" + o
			}), s.actions && a.push({
				k: "spend",
				actions: s.actions
			}), a.push(...s.eff), s.optional ? Y(e, t, [{
				k: "may",
				eff: a
			}]) : Y(e, t, a);
		}
	}
}
function Y(e, t, n, r) {
	n.length && e.stack.push({
		owner: t,
		tasks: n.slice(),
		source: r
	});
}
function X(e) {
	let t = 0;
	for (; !e.decision && e.stack.length && !(t++ > 1e5);) {
		let t = e.stack[e.stack.length - 1];
		if (!t.tasks.length) {
			e.stack.pop();
			continue;
		}
		let n = t.tasks.shift();
		dt(e, t.owner, n, t.source);
	}
	We(e), e.collapse && e.phase !== "done" && On(e);
}
function Z(e, t) {
	e.decision = t, e.serial++;
}
function st(e, t, n) {
	let r = e.decision;
	if (!r) return { code: "err.noDecision" };
	if (r.owner !== t) return { code: "err.notYourDecision" };
	if (r.kind === "option") {
		let t = r.opts?.find((e) => e.id === n.opt);
		if (!t && (!r.optional || n.opt !== void 0 && n.opt !== "skip")) return { code: "err.badChoice" };
		if (!t) return e.decision = null, r.follow?.length && Y(e, r.owner, r.follow, r.source), X(e), null;
		if (e.decision = null, r.mode === "break" && r.suits) return ct(e, r.owner, t.id, r), X(e), null;
		let i = r.opts.find((e) => e.id === t.id), a = r.opts.indexOf(i), o = r.eff?.[a] ?? [];
		return o.length && Y(e, r.owner, o, r.source), r.follow?.length && Y(e, r.owner, r.follow, r.source), X(e), null;
	}
	if (r.kind === "confirm") return e.decision = null, n.confirm && r.follow?.length && Y(e, r.owner, r.follow, r.source), X(e), null;
	if (r.kind === "cards") {
		let t = n.cards ?? [], i = r.from ? Ie(e, B(e, r.owner), r.from) : [], a = [...new Set(t)];
		if (a.length > r.n) return { code: "err.tooMany" };
		if (a.length < (r.min ?? (r.optional ? 0 : r.n))) return { code: "err.tooFew" };
		for (let e of a) if (!i.includes(e) || !G(e, r.sel)) return { code: "err.badChoice" };
		e.decision = null;
		let o = B(e, r.owner);
		e.lastPicks = a.slice();
		for (let t of a) r.to === "unrest" && r.from ? V(t)?.s.includes("unrest") ? Ue(e, o, t, r.from === "handOrDiscard" ? "handOrDiscard" : r.from) : (K(e, o, t, r.from), e.unrestPile.push(t), W(e, "log.returnUnrest", r.owner, t)) : r.sink ? rt(e, o, t, r.from) : r.giveTo ? (K(e, o, t, r.from), B(e, r.giveTo).hand.push(t), W(e, "log.give", r.owner)) : ze(e, o, t, r.from, r.to, r.source), r.countFollow?.length && Y(e, r.owner, r.countFollow, r.source);
		return r.follow?.length && Y(e, r.owner, r.follow, r.source), r.then?.length && Y(e, r.owner, r.then, r.source), X(e), null;
	}
	if (r.kind === "market") {
		let t = n.market;
		if (!t) return r.optional ? (e.decision = null, r.follow?.length && Y(e, r.owner, r.follow, r.source), X(e), null) : { code: "err.badChoice" };
		e.decision = null;
		let i = ut(e, r, t);
		return i && r.free && Ut(e, r.owner, i, !0, "hand"), r.follow?.length && Y(e, r.owner, r.follow, r.source), X(e), null;
	}
	return { code: "err.badChoice" };
}
function ct(e, t, n, r) {
	let i = [];
	for (let t of e.market) V(t.id)?.s.includes(n) && i.push({ id: "mkt:" + t.slot });
	let a = n === "region" ? "region" : n === "uncivilised" ? "uncivilised" : n === "civilised" ? "civilised" : null;
	if (a && e.decks[a].length && i.push({ id: "deck:" + a }), (!a || e.decks[a].length === 0) && i.push({ id: "search" }), r.exiled) for (let t of e.exile) G(t, { s: [n] }) && i.push({ id: "exile:" + t });
	Z(e, {
		owner: t,
		kind: "market",
		n: 1,
		mode: "break",
		suits: [n],
		suit: n,
		opts: i,
		source: r.source,
		follow: r.follow,
		free: r.free,
		token: r.token
	});
}
function lt(e, t, n, r = 1) {
	if (n && n !== "pr") return {
		res: n,
		n: r
	};
	let i = String(Me(e, t).marketToken ?? "");
	return i === "m" ? {
		res: "m",
		n: r
	} : i === "m2" ? {
		res: "m",
		n: r * 2
	} : i === "p" ? {
		res: "p",
		n: r
	} : {
		res: "pr",
		n: r
	};
}
function ut(e, t, n) {
	let r = B(e, t.owner);
	if (t.mode === "token" || t.mode === "tokenPlace") {
		if (!n.startsWith("mkt:")) return null;
		let r = n.slice(4), i = e.market.find((e) => e.slot === r);
		if (!i) return null;
		let a = lt(e, t.owner, t.mode === "tokenPlace" ? t.token ?? "pr" : "pr", t.mode === "tokenPlace" ? Math.max(1, t.n) : 1);
		return i.tok[a.res] += a.n, W(e, "log.marketToken", t.owner, i.id, a.n), null;
	}
	if (n.startsWith("deck:")) {
		let i = n.slice(5), a = e.decks[i].shift();
		return a && (r.hand.push(a), W(e, "log.breakThrough", t.owner, a), J(e, t.owner, "breakUncivilised", { card: a })), a ?? null;
	}
	if (n === "search") {
		let n = t.suit, i = [], a;
		for (; e.decks.main.length;) {
			let t = e.decks.main.shift();
			if (n && V(t)?.s.includes(n)) {
				a = t;
				break;
			}
			i.push(t);
		}
		return a ? (e.decks.main = U(e, [...i, ...e.decks.main]), r.hand.push(a), W(e, "log.breakThrough", t.owner, a), J(e, t.owner, "breakUncivilised", { card: a })) : (e.decks.main = U(e, [...i, ...e.decks.main]), q(e, r, 2, 0, 0), W(e, "log.breakFail", t.owner)), Ke(e), a ?? null;
	}
	if (n.startsWith("exile:")) {
		let i = n.slice(6);
		return e.exile.includes(i) ? (e.exile = e.exile.filter((e) => e !== i), r.hand.push(i), W(e, "log.acquire", t.owner, i), i) : null;
	}
	if (n.startsWith("mkt:")) {
		let i = n.slice(4);
		if (t.mode === "exile") {
			let n = e.market.find((e) => e.slot === i);
			return n ? (e.market = e.market.filter((e) => e !== n), e.exile.push(n.id), n.unrest && e.unrestPile.push(n.unrest), et(e, i), W(e, "log.exile", t.owner, n.id), n.id) : null;
		}
		if (t.mode === "break") {
			let n = e.market.find((e) => e.slot === i);
			if (n) {
				let a = n.id;
				e.market = e.market.filter((e) => e !== n), r.hand.push(a);
				let o = { ...n.tok };
				return q(e, r, o.m, o.p, o.pr), n.unrest && e.unrestPile.push(n.unrest), et(e, i), W(e, "log.breakThrough", t.owner, a), J(e, t.owner, "breakUncivilised", { card: a }), a;
			}
		} else return tt(e, r, i, !1);
	}
	return null;
}
function dt(e, t, n, r) {
	let i = B(e, t);
	switch (n.k) {
		case "gain":
			q(e, i, n.m ?? 0, n.p ?? 0, n.pr ?? 0);
			break;
		case "gainPer": {
			let t = ft(e, i, n.sel, n.zone);
			n.res === "p" ? q(e, i, 0, t * n.n, 0) : n.res === "pr" ? q(e, i, 0, 0, t * n.n) : q(e, i, t * n.n, 0, 0);
			break;
		}
		case "steal":
			pt(e, t, n);
			break;
		case "garrison":
			At(e, t, n, r);
			break;
		case "give":
			jt(e, t, n);
			break;
		case "find":
			qt(e, t, n);
			break;
		case "discardAny":
			Tt(e, t, n.sel);
			break;
		case "token":
			Yt(e, t, n.res, n.n ?? 1, n.to);
			break;
		case "draw":
			Qe(e, i, n.n);
			break;
		case "drawUpTo": {
			let t = Math.min(n.n, i.deck.length);
			t > 0 && Qe(e, i, t);
			break;
		}
		case "discard":
			wt(e, t, n.n);
			break;
		case "mill": {
			let e = n.n;
			for (let t = 0; t < e; t++) {
				let e = i.deck.shift();
				e && i.discard.push(e);
			}
			break;
		}
		case "nationTop": {
			let e = i.nation.shift();
			e && (n.dest === "bottom" ? i.nation.push(e) : i.discard.push(e));
			break;
		}
		case "acquire":
			zt(e, t, n, r);
			break;
		case "develop":
			Bt(e, t, n.free);
			break;
		case "freePlay":
			Vt(e, t, n.sel);
			break;
		case "playFrom":
			Ht(e, t, n);
			break;
		case "exile":
			Jt(e, t, n, r);
			break;
		case "pick":
			vt(e, t, n, r);
			break;
		case "abandon":
			yt(e, t, n, r);
			break;
		case "recall":
			xt(e, t, n);
			break;
		case "sink":
			St(e, t, n);
			break;
		case "unrestTake":
			He(e, i, n.n ?? 1);
			break;
		case "unrestReturn":
			Et(e, t, n.n ?? 1, n.from ?? "handOrDiscard");
			break;
		case "fame":
			Kt(e, t, n);
			break;
		case "actions":
			i.actions += n.n;
			break;
		case "spendActions":
			i.actions = Math.max(0, i.actions - n.n);
			break;
		case "flip":
			Xt(e, t, n.to);
			break;
		case "peek":
			Zt(e, t, n.from, n.n);
			break;
		case "lookedTake":
			Qt(e, t, n);
			break;
		case "lookedRest":
			$t(e, t, n.dest);
			break;
		case "shuffleNation":
			i.nation = U(e, i.nation);
			break;
		case "swapHandNation":
			en(e, t);
			break;
		case "choose":
			Mt(e, t, n, r);
			break;
		case "may":
			Nt(e, t, n.eff, r);
			break;
		case "if":
			_t(e, i, n.cond) ? Y(e, t, n.then, r) : n.else && Y(e, t, n.else, r);
			break;
		case "each":
			Pt(e, t, n);
			break;
		case "pay":
			Lt(e, t, n);
			break;
		case "swapExileMarket":
			tn(e, t);
			break;
		case "endGame":
			n.collapse ? e.collapse = !0 : Ge(e);
			break;
		case "gainMarket":
			nn(e, t, n.sel);
			break;
		case "marketToken":
			Yt(e, t, "pr", n.n ?? 1, "market");
			break;
		case "quest":
			rn(e, t, n.n ?? 1);
			break;
		case "journey": break;
		case "special":
			an(e, t, n.id, n.n, r);
			break;
		case "spend":
			i.res.m = Math.max(0, i.res.m - (n.m ?? 0)), i.res.p = Math.max(0, i.res.p - (n.p ?? 0)), i.res.pr = Math.max(0, i.res.pr - (n.pr ?? 0)), i.actions = Math.max(0, i.actions - (n.actions ?? 0));
			break;
		case "progressPay":
			i.res.pr = 0;
			break;
		case "topDeckCost":
			Ot(e, t, n.n);
			break;
		case "discardMask":
			Dt(e, t, n.n);
			break;
		case "garrisonCost":
			At(e, t, {
				k: "garrison",
				n: n.n,
				sel: n.sel,
				here: n.here
			}, r);
			break;
		case "returnTopCost": kt(e, t, n.n);
	}
}
function ft(e, t, n, r) {
	return r === "play" ? t.play.filter((e) => G(e, n)).length : r === "garrisoned" ? Object.values(t.garrisons).flat().filter((e) => G(e, n)).length : t.discard.filter((e) => G(e, n)).length;
}
function pt(e, t, n) {
	let r = n.from === "empire" ? De(e, t).filter((t) => B(e, t).side === "e") : De(e, t), i = `${t}|${n.m ?? 0}|${n.p ?? 0}|${n.pr ?? 0}|${+!!n.unrestIfUnable}`;
	for (let t of r) {
		let r = B(e, t);
		(!n.needRegion || r.play.some((e) => V(e)?.s.includes("region"))) && Y(e, t, [{
			k: "special",
			id: "stealTo|" + i
		}]);
	}
}
function mt(e, t, n) {
	let r = B(e, t), i = [], a = /* @__PURE__ */ new Set();
	for (let e of [...r.play, ...r.power]) {
		let t = H(e).shield;
		if (!t) continue;
		if (t === "ignoreUnlessProgress") {
			if (!n) return "ignore";
			continue;
		}
		if (t === "recallSelf") {
			if (!r.play.includes(e) || a.has("recall:" + e)) continue;
			a.add("recall:" + e), i.push({
				id: "recall|" + e,
				eff: [{
					k: "special",
					id: "avoidRecall|" + e
				}]
			});
			continue;
		}
		if (t === "recallLongWalls") {
			for (let e of r.play.filter((e) => (V(e)?.en ?? "").startsWith("Long Walls"))) a.has("recall:" + e) || (a.add("recall:" + e), i.push({
				id: "recall|" + e,
				eff: [{
					k: "special",
					id: "avoidRecall|" + e
				}]
			}));
			continue;
		}
		let o = r.exhausts > 0 && !r.exhausted.includes(e);
		(t === "exhaust" || t === "exhaustPayPop") && o && !a.has("exhaust:" + e) && (a.add("exhaust:" + e), i.push({
			id: "exhaust|" + e,
			eff: [{
				k: "special",
				id: "exhaustToken|" + e
			}]
		})), (t === "payPop" || t === "exhaustPayPop") && Be(r, 0, 1, 0) && !a.has("payPop") && (a.add("payPop"), i.push({
			id: "payPop",
			eff: [{
				k: "special",
				id: "avoidPayPop"
			}]
		}));
	}
	return i;
}
var ht = (e, t, n, r, i) => `stealDo|${e}|${t}|${n}|${r}|${+!!i}`;
function gt(e, t, n, r, i, a, o) {
	let s = B(e, t), c = B(e, n);
	if (!(s.res.m >= r && s.res.p >= i && s.res.pr >= a)) {
		o ? He(e, s, 1) : e.flags["stealFail:" + t] = 1;
		return;
	}
	s.res.m -= r, s.res.p -= i, s.res.pr -= a, c.res.m += r, c.res.p += i, c.res.pr += a, W(e, "log.steal", n, t, r + i + a);
}
function _t(e, t, n) {
	switch (n.c) {
		case "state": return t.side === n.v;
		case "res": return (n.m === void 0 || t.res.m >= n.m) && (n.p === void 0 || t.res.p >= n.p) && (n.pr === void 0 || t.res.pr >= n.pr);
		case "count": return (n.zone === "history" ? t.history : n.zone === "all" ? [
			...t.play,
			...t.history,
			...t.hand,
			...t.discard,
			...t.deck,
			...t.flooded
		] : t.play).filter((e) => G(e, {
			s: n.s,
			t: n.t
		})).length >= n.n;
		case "has": return (n.zone === "hand" ? t.hand : n.zone === "history" ? t.history : n.zone === "dev" ? t.dev : n.zone === "any" ? [
			...t.hand,
			...t.play,
			...t.history,
			...t.discard,
			...t.deck,
			...t.flooded,
			...t.dev,
			...Object.values(t.garrisons).flat()
		] : t.play).some((e) => V(e)?.en === n.id || e === n.id);
		case "garrisoned": {
			let e = Object.values(t.garrisons).flat();
			return n.id ? e.some((e) => V(e)?.en === n.id || e === n.id) : e.length >= (n.n ?? 1);
		}
		case "unrestPileEmpty": return e.unrestPile.length === 0;
		case "nationEmpty": return t.nation.length === 0;
		default: return !1;
	}
}
function vt(e, t, n, r) {
	let i = Ie(e, B(e, t), n.from).filter((e) => G(e, n.sel));
	if (!i.length) {
		n.then?.length && Y(e, t, n.then, r);
		return;
	}
	let a = n.all ? i.length : Math.min(n.n, i.length);
	Z(e, {
		owner: t,
		kind: "cards",
		n: a,
		min: n.optional ? Math.min(n.min ?? 0, a) : a,
		optional: n.optional,
		from: n.from,
		to: n.to,
		sel: n.sel,
		all: n.all,
		source: r,
		then: n.then,
		follow: n.follow
	});
}
function yt(e, t, n, r) {
	let i = B(e, t).play.filter((e) => G(e, n.sel) && !bt(e));
	if (!i.length) return;
	let a = Math.min(n.n, i.length);
	Z(e, {
		owner: t,
		kind: "cards",
		n: a,
		min: n.optional ? 0 : a,
		optional: n.optional,
		from: "play",
		to: "discard",
		sel: n.sel,
		source: r
	});
}
var bt = (e) => /\bCannot be abandoned or recalled\b|This card cannot be abandoned or recalled/.test((V(e)?.text?.[1] ?? []).join(" "));
function xt(e, t, n) {
	let r = B(e, t).play.filter((e) => G(e, n.sel) && !bt(e));
	if (!r.length) return;
	let i = Math.min(n.n, r.length);
	Z(e, {
		owner: t,
		kind: "cards",
		n: i,
		min: n.optional ? 0 : i,
		optional: n.optional,
		from: "play",
		to: "hand",
		sel: n.sel
	});
}
function St(e, t, n) {
	let r = B(e, t);
	if (n.self) {
		rt(e, r, Ct(e), "play");
		return;
	}
	let i = r.play.filter((e) => G(e, n.sel));
	i.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n.n, i.length),
		min: n.optional ? 0 : Math.min(n.n, i.length),
		optional: n.optional,
		from: "play",
		to: "discard",
		sink: !0
	});
}
function Ct(e) {
	return e.stack[e.stack.length - 1]?.source ?? "";
}
function wt(e, t, n) {
	let r = B(e, t), i = Math.min(n, r.hand.length);
	i <= 0 || Z(e, {
		owner: t,
		kind: "cards",
		n: i,
		from: "hand",
		to: "discard"
	});
}
function Tt(e, t, n) {
	let r = B(e, t).hand.filter((e) => G(e, n));
	r.length && Z(e, {
		owner: t,
		kind: "cards",
		n: r.length,
		min: 0,
		optional: !0,
		from: "hand",
		to: "discard",
		sel: n
	});
}
function Et(e, t, n, r) {
	let i = B(e, t), a = (r === "hand" ? i.hand : r === "discard" ? i.discard : [...i.hand, ...i.discard]).filter((e) => V(e)?.s.includes("unrest"));
	a.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n, a.length),
		min: 0,
		optional: !0,
		from: r,
		to: "unrest",
		sel: { s: ["unrest"] }
	});
}
function Dt(e, t, n) {
	let r = B(e, t).hand.filter((e) => V(e)?.t.includes("mask"));
	r.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n, r.length),
		from: "hand",
		to: "discard",
		sel: { t: ["mask"] }
	});
}
function Ot(e, t, n) {
	let r = B(e, t);
	r.hand.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n, r.hand.length),
		from: "hand",
		to: "deckTop"
	});
}
function kt(e, t, n) {
	let r = B(e, t);
	r.play.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n, r.play.length),
		from: "play",
		to: "deckTop"
	});
}
function At(e, t, n, r) {
	let i = B(e, t), a = n.here ? r : void 0, o = i.hand.filter((e) => G(e, n.sel));
	o.length && Z(e, {
		owner: t,
		kind: "cards",
		n: Math.min(n.n ?? 1, o.length),
		min: 0,
		optional: !0,
		from: "hand",
		to: "garrisonHere",
		sel: n.sel,
		source: a
	});
}
function jt(e, t, n) {
	let r = B(e, t), i = n.from ?? "handOrDiscard";
	if ((i === "hand" ? r.hand : i === "handOrDiscard" ? [...r.hand, ...r.discard] : r.discard).length) for (let n of De(e, t)) Y(e, t, [{
		k: "special",
		id: "giveAsk|" + n + "|" + i
	}]);
}
function Mt(e, t, n, r) {
	let i = {
		owner: t,
		kind: "option",
		n: 1,
		source: r,
		opts: n.opts.map((e, t) => ({
			id: "o" + t,
			label: e.id
		}))
	};
	i.eff = n.opts.map((e) => e.eff), Z(e, i);
}
function Nt(e, t, n, r) {
	Z(e, {
		owner: t,
		kind: "confirm",
		n: 1,
		follow: n,
		source: r
	});
}
function Pt(e, t, n) {
	let r = n.who === "all" ? e.order.slice() : De(e, t);
	for (let t = r.length - 1; t >= 0; t--) {
		let i = r[t];
		Y(e, i, n.may ? [{
			k: "may",
			eff: n.eff
		}] : n.eff);
	}
}
function Ft(e, t) {
	let n = [];
	return e.actions && n.push({
		k: "spend",
		actions: e.actions
	}), e.progressAll && n.push({
		k: "progressPay",
		min: e.progressAll.min
	}), e.progress && n.push({
		k: "spend",
		pr: e.progress
	}), e.unrest && n.push({
		k: "unrestTake",
		n: e.unrest
	}), e.cards && n.push({
		k: "discard",
		n: e.cards
	}), e.topDeck && n.push({
		k: "topDeckCost",
		n: e.topDeck
	}), e.discardMask && n.push({
		k: "discardMask",
		n: e.discardMask
	}), e.abandon && (e.abandon.named && t.play.filter((t) => Array.isArray(e.abandon.named) ? e.abandon.named.some((e) => V(t)?.en === e) : V(t)?.en === e.abandon.named), e.abandon.named ? (n.push({
		k: "abandon",
		n: e.abandon.n,
		sel: {}
	}), n[n.length - 1] = {
		k: "special",
		id: "abandonNamedCost|" + JSON.stringify(e.abandon)
	}) : n.push({
		k: "abandon",
		n: e.abandon.n,
		sel: e.abandon.sel
	})), e.sink && (e.sink.self ? n.push({
		k: "sink",
		n: e.sink.n,
		self: !0,
		sel: e.sink.sel
	}) : n.push({
		k: "sink",
		n: e.sink.n,
		sel: e.sink.sel
	})), e.unrestReturn && n.push({
		k: "unrestReturn",
		n: e.unrestReturn.n,
		from: e.unrestReturn.from
	}), e.historyPut && n.push({
		k: "pick",
		n: e.historyPut.n,
		from: e.historyPut.from,
		to: "history",
		min: e.historyPut.n
	}), e.garrison && n.push({
		k: "garrisonCost",
		n: e.garrison.n,
		sel: e.garrison.sel,
		here: e.garrison.here
	}), e.returnTop && n.push({
		k: "returnTopCost",
		n: e.returnTop
	}), e.exileHand && n.push({
		k: "exile",
		from: "hand",
		sel: e.exileHand.sel,
		self: !1
	}), e.recall && n.push({
		k: "recall",
		n: e.recall.n,
		sel: e.recall.sel ?? {}
	}), n;
}
function It(e, t, n) {
	if (!Be(t, n.m ?? 0, n.p ?? 0, n.pr ?? 0) || n.progress !== void 0 && !Be(t, 0, 0, n.progress) || n.progressAll && t.res.pr < n.progressAll.min || (n.actions ?? 0) > t.actions) return !1;
	let r = (e, n) => (e === "hand" ? t.hand : e === "discard" ? t.discard : [...t.hand, ...t.discard]).filter(n).length;
	return !(n.cards && t.hand.length < n.cards || n.topDeck && t.hand.length < n.topDeck || n.discardMask && t.hand.filter((e) => V(e)?.t.includes("mask")).length < n.discardMask || n.abandon && (n.abandon.named ? t.play.filter((e) => Array.isArray(n.abandon.named) ? n.abandon.named.some((t) => V(e)?.en === t) : V(e)?.en === n.abandon.named).length : t.play.filter((e) => G(e, n.abandon.sel)).length) < n.abandon.n || n.sink && (n.sink.self ? 1 : t.play.filter((e) => G(e, n.sink.sel)).length) < n.sink.n || n.unrestReturn && r(n.unrestReturn.from ?? "handOrDiscard", (e) => !!V(e)?.s.includes("unrest")) < n.unrestReturn.n || n.historyPut && r(n.historyPut.from, () => !0) < n.historyPut.n || n.garrison && t.hand.filter((e) => G(e, n.garrison.sel)).length < n.garrison.n || n.returnTop && t.play.length < n.returnTop || n.exileHand && t.hand.filter((e) => G(e, n.exileHand.sel)).length < n.exileHand.n || n.recall && t.play.filter((e) => G(e, n.recall.sel)).length < n.recall.n);
}
function Lt(e, t, n) {
	let r = B(e, t);
	if (!It(e, r, n.cost)) {
		n.optional || W(e, "log.cannotPay", t);
		return;
	}
	Ve(r, n.cost.m ?? 0, n.cost.p ?? 0, n.cost.pr ?? 0) && (n.cost.progress && Ve(r, 0, 0, n.cost.progress), Y(e, t, [...Ft(n.cost, r), ...n.eff]));
}
function Rt(e, t, n) {
	let r = [];
	if (n.token) for (let t of e.market) (t.tok[n.token] ?? 0) > 0 && r.push({ id: "mkt:" + t.slot });
	else for (let t of e.market) {
		let e = V(t.id);
		e && (e.t.includes("knight") || (!n.suits.length || n.suits.some((t) => e.s.includes(t))) && r.push({ id: "mkt:" + t.slot }));
	}
	if (n.exiled || Pe(e, t, "acquireExile")) for (let t of e.exile) (!n.suits.length || n.suits.some((e) => V(t)?.s.includes(e))) && r.push({ id: "exile:" + t });
	return r;
}
function zt(e, t, n, r) {
	let i = n.n ?? 1, a = i > 1 ? [{
		...n,
		n: i - 1
	}] : [];
	if (n.mode === "break") {
		let i = n.suits.map((e) => ({
			id: e,
			label: e
		}));
		Z(e, {
			owner: t,
			kind: "option",
			n: 1,
			mode: "break",
			suits: n.suits,
			opts: i,
			source: r,
			free: n.free,
			token: n.token,
			exiled: n.exiled,
			follow: a
		});
		return;
	}
	let o = Rt(e, t, n);
	if (!o.length) {
		W(e, "log.noAcquire", t), a.length && Y(e, t, a, r);
		return;
	}
	Z(e, {
		owner: t,
		kind: "market",
		n: 1,
		mode: n.mode ?? "acquire",
		suits: n.suits,
		token: n.token,
		free: n.free,
		opts: o,
		source: r,
		follow: a
	});
}
function Bt(e, t, n) {
	let r = B(e, t), i = r.dev.filter((t) => n || at(e, r, t));
	if (!i.length) {
		W(e, "log.noDevelop", t);
		return;
	}
	let a = {
		owner: t,
		kind: "option",
		n: 1,
		opts: i.map((e, t) => ({
			id: "d" + t,
			label: e
		}))
	};
	a.eff = i.map((e) => [{
		k: "special",
		id: "developPick|" + (n ? "1" : "0") + "|" + e
	}]), Z(e, a);
}
function Vt(e, t, n) {
	let r = B(e, t).hand.filter((e) => G(e, n));
	if (!r.length) return;
	let i = {
		owner: t,
		kind: "option",
		n: 1,
		opts: r.map((e, t) => ({
			id: "f" + t,
			label: e
		}))
	};
	i.eff = r.map((e) => [{
		k: "special",
		id: "freePlayCard|" + e
	}]), Z(e, i);
}
function Ht(e, t, n) {
	let r = B(e, t), i = n.from, a = (i === "hand" ? r.hand : r.discard).filter((e) => G(e, n.sel) && V(e)?.loc === "deck");
	if (!a.length) return;
	let o = {
		owner: t,
		kind: "option",
		n: 1,
		opts: a.map((e, t) => ({
			id: "p" + t,
			label: e
		}))
	};
	o.eff = a.map((e) => [{
		k: "special",
		id: "playFromZone|" + i + "|" + e
	}]), Z(e, o);
}
function Ut(e, t, n, r, i = "hand") {
	let a = B(e, t), o = V(n);
	if (!o) return;
	K(e, a, n, i), a.play.push(n), W(e, r ? "log.freePlay" : "log.play", t, n);
	let s = H(n), c = [];
	c.push(...s.play), s.triggers.length, c.push({
		k: "special",
		id: "finishPlay|" + n
	}), Y(e, t, c, n), o.s.includes("region") && J(e, t, "playRegion", { card: n }), o.hdr === "atk" && J(e, t, "playAttack", { card: n }), Pe(e, t, "attackProgress") && o.hdr === "atk" && q(e, a, 0, 0, 1);
}
function Wt(e, t, n) {
	e.decks.fame = e.decks.fame.filter((e) => e !== n), t.hand.push(n), W(e, "log.fame", t.rid, n);
}
function Gt(e, t, n) {
	if (n === "?FAM?A") {
		if (e.flags.kokA) return;
		e.flags.kokA = 1, W(e, "log.kok", t.rid, n), t.side === "b" ? t.res.pr += 6 : (t.res.pr += 3, Y(e, t.rid, [{
			k: "develop",
			free: !0
		}])), e.koK = "?FAM?B", e.fameHidden = !0, Ge(e);
		return;
	}
	t.flags.kokB || (t.flags.kokB = 1, W(e, "log.kok", t.rid, n), t.side === "b" ? t.res.pr += 4 : Y(e, t.rid, [{
		k: "develop",
		free: !0
	}]), e.fameHidden = !0, Ge(e));
}
function Kt(e, t, n) {
	let r = B(e, t), i = +!!Pe(e, t, "lookFameExtra");
	if (n.top) {
		let a = n.n + i;
		if (i && q(e, r, 0, 0, 1), !e.decks.fame.length) {
			Gt(e, r, e.koK);
			return;
		}
		let o = e.decks.fame.slice(0, a);
		e.looked = o, e.lookedBy = t;
		let s = {
			owner: t,
			kind: "option",
			n: 1,
			opts: o.map((e, t) => ({
				id: "f" + t,
				label: e
			}))
		};
		s.eff = o.map((e, t) => [{
			k: "special",
			id: "takeLookedFame|" + t
		}]), Z(e, s);
		return;
	}
	for (let t = 0; t < n.n; t++) {
		if (!e.decks.fame.length) {
			Gt(e, r, e.koK);
			break;
		}
		Wt(e, r, e.decks.fame.shift());
	}
}
function qt(e, t, n) {
	let r = B(e, t), i = n.from === "deck" ? ["deck"] : n.from === "discard" ? ["discard"] : [
		"hand",
		"discard",
		"deck",
		"nation"
	], a = (e) => e === "hand" ? r.hand : e === "discard" ? r.discard : e === "deck" ? r.deck : r.nation, o, s;
	for (let e of i) if (o = a(e).find((e) => n.name ? V(e)?.en === n.name || e === n.name : G(e, n.sel)), o) {
		s = e;
		break;
	}
	if (!o || !s) return;
	let c = i.slice(0, i.indexOf(s) + 1);
	K(e, r, o, s === "hand" ? "hand" : s === "discard" ? "discard" : s === "deck" ? "deckTop" : "nationTop"), Le(e, r, o, n.dest), W(e, "log.find", t), c.includes("deck") && (r.deck = U(e, r.deck)), c.includes("nation") && (r.nation = U(e, r.nation));
}
function Jt(e, t, n, r) {
	let i = B(e, t);
	if (n.self) {
		let n = r ?? Ct(e);
		n && i.play.includes(n) && (i.play = i.play.filter((e) => e !== n), e.exile.push(n), W(e, "log.exile", t, n));
		return;
	}
	if (n.from === "market") {
		let n = e.market.filter((e) => e.tok.m + e.tok.p + e.tok.pr === 0).map((e) => ({ id: "mkt:" + e.slot }));
		if (!n.length) return;
		Z(e, {
			owner: t,
			kind: "market",
			n: 1,
			mode: "exile",
			opts: n,
			source: r
		});
		return;
	}
	Ie(e, i, n.from).filter((e) => G(e, n.sel)).length && Z(e, {
		owner: t,
		kind: "cards",
		n: 1,
		min: 0,
		optional: !0,
		from: n.from,
		to: "exile",
		sel: n.sel,
		source: r
	});
}
function Yt(e, t, n, r, i) {
	if (i === "self") {
		q(e, B(e, t), n === "m" ? r : 0, n === "p" ? r : 0, n === "pr" ? r : 0);
		return;
	}
	e.market.length && Z(e, {
		owner: t,
		kind: "market",
		n: r,
		mode: "tokenPlace",
		token: n,
		opts: e.market.map((e) => ({ id: "mkt:" + e.slot }))
	});
}
function Xt(e, t, n) {
	let r = B(e, t);
	r.side = n || (r.side === "b" ? "e" : "b"), W(e, "log.flip", t);
}
function Zt(e, t, n, r) {
	let i = B(e, t);
	e.looked = (n === "deck" ? i.deck : i.nation).slice(0, r), e.lookedBy = t, W(e, "log.peek", t, void 0, r);
}
function Qt(e, t, n) {
	let r = e.looked, i = Math.min(n.n ?? 1, r.length), a = B(e, t);
	for (let t = 0; t < i; t++) {
		let i = r[t];
		a.deck = a.deck.filter((e) => e !== i), a.nation = a.nation.filter((e) => e !== i), Le(e, a, i, n.dest ?? "hand");
	}
}
function $t(e, t, n) {
	let r = e.looked, i = B(e, t);
	for (let e of r) i.deck = i.deck.filter((t) => t !== e), i.nation = i.nation.filter((t) => t !== e);
	n === "discard" ? i.discard.push(...r) : n === "deckTop" ? i.deck.unshift(...r) : n === "deckBottom" ? i.deck.push(...r) : i.deck = U(e, [...i.deck, ...r]), e.looked = [], e.lookedBy = null;
}
function en(e, t) {
	let n = B(e, t);
	if (!n.hand.length || !n.nation.length) return;
	let r = n.hand.pop(), i = n.nation.shift();
	n.hand.push(i), n.nation.unshift(r);
}
function tn(e, t) {
	let n = B(e, t);
	if (!e.exile.length || !e.market.length) return;
	let r = e.exile.pop(), i = e.market[0];
	e.market = e.market.filter((e) => e !== i), n.hand.push(i.id), e.exile.push(i.id), e.market.push({
		...i,
		id: r
	}), W(e, "log.swap", t);
}
function nn(e, t, n) {
	let r = B(e, t), i = e.market.find((e) => G(e.id, n));
	if (!i) return;
	let a = i.id;
	e.market = e.market.filter((e) => e !== i), r.hand.push(a);
	let o = { ...i.tok };
	q(e, r, o.m, o.p, o.pr), i.unrest && r.hand.push(i.unrest), et(e, i.slot);
}
function rn(e, t, n) {
	let r = B(e, t);
	r.quest && (r.res.pr += n);
}
function an(e, t, n, r, i) {
	let a = B(e, t), [o, ...s] = n.split("|");
	switch (o) {
		case "exhaustToken": {
			let e = s[0];
			a.exhausts > 0 && !a.exhausted.includes(e) && (--a.exhausts, a.exhausted.push(e));
			break;
		}
		case "returnExhaustToken":
			a.exhausted.length && (a.exhausted.pop(), a.exhausts += 1);
			break;
		case "handSize":
			a.handSize += 1;
			break;
		case "thisToHistory":
			i && ze(e, a, i, "play", "history");
			break;
		case "finishPlay": {
			let e = s[0];
			a.play.includes(e) && V(e)?.hdr !== "pin" && (a.play = a.play.filter((t) => t !== e), a.discard.push(e));
			break;
		}
		case "freePlayCard":
			Ut(e, t, s[0], !0, a.hand.includes(s[0]) ? "hand" : "discard");
			break;
		case "playFromZone": {
			let n = s[0];
			Ut(e, t, s[1], !0, n), Pe(e, t, "regionDiscardGainM") && V(s[1])?.s.includes("region") && q(e, B(e, t), 2, 0, 0);
			break;
		}
		case "developPick":
			ot(e, a, s[1] ?? s[0], s[0] === "1");
			break;
		case "returnSelfToUnrest":
			if (!i) break;
			a.hand = a.hand.filter((e) => e !== i), a.play = a.play.filter((e) => e !== i), e.unrestPile.push(i), e.flags.unrestReturned = (e.flags.unrestReturned ?? 0) + 1, W(e, "log.returnUnrest", t, i), J(e, t, "returnUnrest", { card: i });
			break;
		case "abandonSelf":
			i && Q(e, a, i);
			break;
		case "sinkSelf":
			i && rt(e, a, i, "play");
			break;
		case "recallSelf":
			i && (a.play = a.play.filter((e) => e !== i), a.hand.push(i));
			break;
		case "flipSelf":
			sn(e, a, i);
			break;
		case "replaceSelf":
			ln(e, a, s[0], i);
			break;
		case "abandonSelfGainProgress": {
			if (!i) break;
			let t = a.cardTok[i] ?? 0;
			delete a.cardTok[i], Q(e, a, i), t && q(e, a, 0, 0, t);
			break;
		}
		case "abandonSelfReturnGarrisonUnrest": {
			if (!i) break;
			let t = a.garrisons[i] ?? [], n = t.filter((e) => V(e)?.s.includes("unrest")), r = t.filter((e) => !V(e)?.s.includes("unrest"));
			e.unrestPile.push(...n), a.garrisons[i] = r, Q(e, a, i);
			break;
		}
		case "abandonNamed": {
			let t = s.join("|"), n = a.play.find((e) => V(e)?.en === t || e === t);
			n && Q(e, a, n);
			break;
		}
		case "abandonNamedCost": {
			let t = JSON.parse(s.join("|")), n = Array.isArray(t.named) ? t.named : t.named ? [t.named] : [], r = a.play.filter((e) => !n.length || n.some((t) => V(e)?.en === t || e === t)).slice(0, t.n);
			for (let t of r) Q(e, a, t);
			break;
		}
		case "gainPerCityPopulation": {
			let t = a.play.filter((e) => V(e)?.t.some((e) => e === "city" || e === "metropolis")).length;
			q(e, a, t, t, 0);
			break;
		}
		case "gainPerUnrestReturned": {
			let t = e.flags.unrestReturned ?? 0;
			e.flags.unrestReturned = 0, t && q(e, a, 0, 0, t);
			break;
		}
		case "drawPerCityMetropolis": {
			let t = a.play.filter((e) => V(e)?.t.some((e) => e === "city" || e === "metropolis")).length;
			Qe(e, a, t);
			break;
		}
		case "kingOfKings":
		case "kingOfKingsB":
			Gt(e, a, e.koK);
			break;
		case "resumeDraw": {
			let n = e.pendingDraw;
			e.pendingDraw = null, n && n.rid === t && (Ye(e, a), Qe(e, a, n.n));
			break;
		}
		case "developReshuffle": {
			let n = s[0];
			!a.flags.devTok && a.actions > 0 && a.dev.includes(n) && ot(e, a, n, !1) && (--a.actions, a.flags.devTok = 1);
			let r = e.pendingDraw;
			e.pendingDraw = null, r && r.rid === t && (Ye(e, a), Qe(e, a, r.n));
			break;
		}
		case "nationTopToBottom": {
			let t = e.looked[0];
			e.looked = [], t && a.nation.includes(t) && (a.nation = a.nation.filter((e) => e !== t), a.nation.push(t));
			break;
		}
		case "stealTo": {
			let [n, r, i, a, o] = s, c = mt(e, t, Number(a) > 0);
			if (c === "ignore") break;
			let l = {
				k: "special",
				id: ht(n, Number(r), Number(i), Number(a), o === "1")
			};
			if (!c.length) {
				Y(e, t, [l]);
				break;
			}
			Z(e, {
				owner: t,
				kind: "option",
				n: 1,
				optional: !0,
				opts: [{ id: "take" }, ...c.map((e) => ({ id: e.id }))],
				eff: [[l], ...c.map((e) => e.eff)]
			});
			break;
		}
		case "stealDo": {
			let [n, r, i, a, o] = s;
			gt(e, t, n, Number(r), Number(i), Number(a), o === "1");
			break;
		}
		case "avoidRecall": {
			let n = s[0];
			if (!a.play.includes(n)) break;
			a.play = a.play.filter((e) => e !== n), a.hand.push(n), W(e, "log.recall", t, n);
			break;
		}
		case "avoidPayPop":
			Ve(a, 0, 1, 0);
			break;
		case "gamble": {
			if (a.res.m < 1) break;
			--a.res.m;
			let n = [
				"uncivilised",
				"civilised",
				"region",
				"tributary"
			].map((e) => ({ id: e })), r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: n,
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "gambleReveal|" + e.id
			}]), Z(e, r);
			break;
		}
		case "gambleReveal": {
			let n = s[0];
			if (!e.decks.main.length) {
				Ge(e);
				break;
			}
			let r = e.decks.main.shift(), i = !!V(r)?.s.includes(n);
			i ? a.hand.push(r) : e.exile.push(r), W(e, i ? "log.gambleHit" : "log.gambleMiss", t, r), Ke(e);
			break;
		}
		case "takeLooked": {
			let t = e.looked;
			if (t.length) {
				let n = t[0];
				e.decks.fame = e.decks.fame.filter((e) => e !== n), Wt(e, a, n);
			}
			break;
		}
		case "takeLookedFame": {
			let t = Number(s[0] ?? 0), n = e.looked[t];
			if (n) {
				e.decks.fame = e.decks.fame.filter((e) => e !== n), Wt(e, a, n);
				let r = e.looked.filter((e, n) => n !== t);
				e.decks.fame = [...r, ...e.decks.fame];
			}
			e.looked = [], e.lookedBy = null;
			break;
		}
		case "giveAsk": {
			let n = s[0], r = s[1] ?? "handOrDiscard";
			if (!Ie(e, a, r).length) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: 1,
				from: r,
				to: "hand",
				giveTo: n
			});
			break;
		}
		case "drawTopChoose": {
			let n = a.deck.shift();
			if (!n) break;
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: [
					{ id: "discard" },
					{ id: "top" },
					{ id: "history" }
				]
			};
			r.eff = [
				[{
					k: "special",
					id: "putLooked|discard|" + n
				}],
				[{
					k: "special",
					id: "putLooked|deckTop|" + n
				}],
				[{
					k: "special",
					id: "putLooked|history|" + n
				}]
			], Z(e, r);
			break;
		}
		case "putLooked": {
			let t = s[0], n = s[1];
			Le(e, a, n, t);
			break;
		}
		case "gainPerUnrestReturnedCount": break;
		case "returnUnrestBeforeScoring":
			e.flags.returnUnrestScoring = 1;
			break;
		case "acquireExileNotKnight":
			dn(e, t);
			break;
		case "acquireFreePlay":
			s.join("|").split(",").map((e) => ({ s: [e] })), zt(e, t, {
				k: "acquire",
				suits: s.join("|").split(","),
				mode: "acquire",
				free: !0
			});
			break;
		case "acquireRegionTwiceExile":
			zt(e, t, {
				k: "acquire",
				suits: ["region"],
				mode: "acquire",
				exiled: !0,
				n: 2
			});
			break;
		case "garrisonTriggerRegion": {
			if (!i) break;
			let n = a.play.filter((e) => e !== i && V(e)?.s.includes("region"));
			if (!n.length) break;
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				optional: !0,
				opts: n.map((e) => ({ id: e })),
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "garrisonHereTrigger|" + e
			}]), Z(e, r);
			break;
		}
		case "garrisonHereTrigger": {
			let n = s[0];
			if (!i || !a.play.includes(i) || !a.play.includes(n)) break;
			a.play = a.play.filter((e) => e !== i), (a.garrisons[n] ??= []).push(i), W(e, "log.garrison", t, i), Y(e, t, H(n).play, n);
			break;
		}
		case "findGraalExileSelf": {
			let t = [...a.discard, ...a.deck].find((e) => V(e)?.en === "Graal" || e === "Graal");
			t && (a.discard = a.discard.filter((e) => e !== t), a.deck = a.deck.filter((e) => e !== t), a.hand.push(t)), i && (a.play = a.play.filter((e) => e !== i), e.exile.push(i));
			break;
		}
		case "revealAttacksToHistory":
			for (let t of [
				"hand",
				"deck",
				"discard"
			]) {
				let n = a[t].filter((e) => V(e)?.hdr === "atk");
				for (let r of n) a[t] = a[t].filter((e) => e !== r), Re(e, a, r);
			}
			i && (a.play = a.play.filter((e) => e !== i), Re(e, a, i));
			break;
		case "findKnightHistoryFame": {
			let n = [
				...a.play,
				...a.hand,
				...a.discard
			].find((e) => V(e)?.t.includes("knight"));
			n && (a.play = a.play.filter((e) => e !== n), a.hand = a.hand.filter((e) => e !== n), a.discard = a.discard.filter((e) => e !== n), Re(e, a, n)), Kt(e, t, {
				k: "fame",
				n: 2,
				top: !0
			});
			break;
		}
		case "anyoneUnablePayUnrest":
			for (let n of De(e, t)) if (e.flags["stealFail:" + n] && (delete e.flags["stealFail:" + n], He(e, B(e, n), 1), e.collapse)) break;
			break;
		case "discardToReturnUnrestAll":
			for (let t of e.order) Y(e, t, [{
				k: "may",
				eff: [{
					k: "discard",
					n: 1
				}, {
					k: "unrestReturn",
					n: 1,
					from: "handOrDiscard"
				}]
			}]);
			break;
		case "forEachDiscarded": {
			let n = e.lastPicks ?? [];
			e.lastPicks = [];
			for (let r = n.length - 1; r >= 0; r--) Y(e, t, [{
				k: "choose",
				opts: [{
					id: "draw",
					eff: [{
						k: "draw",
						n: 1
					}]
				}, {
					id: "progress",
					eff: [{
						k: "gain",
						pr: 1
					}]
				}]
			}]);
			break;
		}
		case "abandonBonus": {
			let t = (e.lastPicks ?? []).filter((e) => !V(e)?.t.includes("production")).length;
			t && q(e, a, 0, 0, t);
			break;
		}
		case "ifAttackProgress":
			(e.lastPicks ?? []).some((e) => V(e)?.hdr === "atk") && q(e, a, 0, 0, 1);
			break;
		case "payProgressAcquire": {
			let n = {
				owner: t,
				kind: "option",
				n: 1,
				opts: [
					{ id: "0" },
					{ id: "1" },
					{ id: "2" },
					{ id: "3" }
				]
			};
			n.eff = [
				0,
				1,
				2,
				3
			].map((e) => e === 0 ? [] : [{
				k: "progressPay",
				min: e
			}, ...Array.from({ length: e }, () => ({
				k: "acquire",
				suits: [
					"uncivilised",
					"civilised",
					"region",
					"tributary"
				],
				mode: "acquire"
			}))]), Z(e, n);
			break;
		}
		case "treatAsProduction":
			s[0] === "fertile" ? a.mods.fertileAsProd = 3 : a.mods.riverAsProd = 3;
			break;
		case "ignoreEmpireNext":
			a.mods.ignoreEmpire = !0;
			break;
		case "longWallsThreeAction":
			if (a.play.filter((e) => (V(e)?.en ?? "").startsWith("Long Walls")).length < 3 || !a.hand.length) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: 1,
				from: "hand",
				to: "deckTop",
				follow: [{
					k: "special",
					id: "gainAction"
				}]
			});
			break;
		case "gainAction":
			a.actions += 1;
			break;
		case "copyOpponentPinnedExhaust": {
			let n = [];
			for (let r of De(e, t)) for (let t of B(e, r).play) V(t)?.hdr === "pin" && H(t).exhaust.length && n.push({ id: r + "|" + t });
			if (!n.length) break;
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: n,
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "copyExhaust|" + e.id
			}]), Z(e, r);
			break;
		}
		case "copyExhaust": {
			let n = s[s.length - 1];
			Y(e, t, H(n).exhaust, n);
			break;
		}
		case "solsticeMinoanToken": {
			if (!i) break;
			let n = {
				owner: t,
				kind: "option",
				n: 1,
				opts: [{ id: "pay" }, { id: "abandon" }],
				source: i
			};
			n.eff = [[{
				k: "pay",
				cost: { m: 2 },
				eff: [{
					k: "special",
					id: "addCardTok|" + i
				}]
			}], [{
				k: "special",
				id: "abandonGainTok|" + i
			}]], Z(e, n);
			break;
		}
		case "addCardTok": {
			let n = s[0];
			a.cardTok[n] = (a.cardTok[n] ?? 0) + (r ?? 1), W(e, "log.cardToken", t, n, r ?? 1);
			break;
		}
		case "abandonGainTok": {
			let t = s[0], n = a.cardTok[t] ?? 0;
			delete a.cardTok[t], Q(e, a, t), n && q(e, a, 0, 0, n);
			break;
		}
		case "unrestPeekNationBottom": break;
		case "scrollGarrisonFame":
			if (!i || (a.garrisons[i] ?? []).filter((e) => V(e)?.t.includes("scroll")).length < 2) break;
			Z(e, {
				owner: t,
				kind: "confirm",
				n: 1,
				optional: !0,
				follow: [{
					k: "special",
					id: "abandonDrawFame|" + i
				}],
				source: i
			});
			break;
		case "abandonDrawFame": {
			let n = s[0];
			Q(e, a, n), Kt(e, t, {
				k: "fame",
				n: 1
			});
			break;
		}
		case "garrisonImpendingQuest":
			if (a.quest || !a.dev.length) break;
			Z(e, {
				owner: t,
				kind: "confirm",
				n: 1,
				optional: !0,
				follow: [{
					k: "unrestTake",
					n: 1
				}, {
					k: "special",
					id: "garrisonQuestPick"
				}]
			});
			break;
		case "garrisonQuestPick": {
			if (a.quest || !a.dev.length) break;
			let n = a.dev.map((e) => ({ id: e })), r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: n,
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "garrisonQuest|" + e.id
			}]), Z(e, r);
			break;
		}
		case "garrisonQuest": {
			let n = s[0];
			if (a.quest || !a.dev.includes(n)) break;
			a.dev = a.dev.filter((e) => e !== n), (a.garrisons.ART2 ??= []).push(n), a.quest = n, W(e, "log.quest", t, n);
			break;
		}
		case "drawActiveQuest":
			if (Object.keys(a.garrisons).filter((e) => V(e)?.s.includes("region")).flatMap((e) => (a.garrisons[e] ?? []).filter((e) => V(e)?.t.includes("knight"))).length < 3 || !a.quest) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: 3,
				from: "garrison",
				to: "discard",
				sel: { t: ["knight"] },
				follow: [{
					k: "special",
					id: "drawQuestHome"
				}]
			});
			break;
		case "drawQuestHome": {
			let n = a.quest;
			if (!n) break;
			for (let e of Object.keys(a.garrisons)) a.garrisons[e] = a.garrisons[e].filter((e) => e !== n);
			a.quest = null, a.hand.push(n), W(e, "log.quest", t, n);
			break;
		}
		case "knightToHistoryOrUnrest": {
			let n = [];
			for (let e of a.hand) V(e)?.t.includes("knight") && n.push({ id: "hand|" + e });
			for (let [e, t] of Object.entries(a.garrisons)) for (let r of t) V(r)?.t.includes("knight") && n.push({ id: "gar|" + e + "|" + r });
			n.push({ id: "unrest" });
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: n,
				source: i
			};
			r.eff = n.map((e) => e.id === "unrest" ? [{
				k: "unrestTake",
				n: 2
			}] : [{
				k: "special",
				id: "knightHist|" + e.id
			}]), Z(e, r);
			break;
		}
		case "knightHist":
			if (s[0] === "hand") {
				let n = s[1];
				if (!a.hand.includes(n)) break;
				a.hand = a.hand.filter((e) => e !== n), Re(e, a, n), W(e, "log.history", t, n);
			} else {
				let n = s[1], r = s[2], i = a.garrisons[n] ?? [];
				if (!i.includes(r)) break;
				a.garrisons[n] = i.filter((e) => e !== r), Re(e, a, r), W(e, "log.history", t, r);
			}
			break;
		case "knightExileQuestOrUnrest":
			if (!a.hand.some((e) => V(e)?.t.includes("knight"))) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: 1,
				min: 0,
				optional: !0,
				from: "hand",
				to: "discard",
				sel: { t: ["knight"] },
				follow: [{
					k: "choose",
					opts: [{
						id: "exile",
						eff: [{
							k: "special",
							id: "exileImpendingNotGraal"
						}]
					}, {
						id: "unrest",
						eff: [{
							k: "unrestReturn",
							n: 2,
							from: "handOrDiscard"
						}]
					}]
				}]
			});
			break;
		case "exileTwrch": {
			let n = Object.keys(b).find((e) => (V(e)?.en ?? "").startsWith("Twrch Trwyth") && V(e)?.nat === a.nationId);
			if (!n) break;
			let r = [
				"play",
				"dev",
				"hand",
				"discard",
				"flooded",
				"history"
			].find((e) => a[e].includes(n));
			if (!r && a.quest !== n) break;
			for (let e of Object.keys(a.garrisons)) a.garrisons[e] = a.garrisons[e].filter((e) => e !== n);
			r && K(e, a, n, r), e.exile.push(n), a.quest === n && (a.quest = null), W(e, "log.exile", t, n);
			break;
		}
		case "abandonMyrddinRegion": {
			let t = (e) => (V(e)?.en ?? "").startsWith("Myrddin Wyllt"), n = a.play.find((e) => V(e)?.s.includes("region") && (a.garrisons[e] ?? []).some(t));
			if (!n) break;
			Q(e, a, n);
			let r = a.quest;
			if (r) {
				for (let e of Object.keys(a.garrisons)) a.garrisons[e] = a.garrisons[e].filter((e) => e !== r);
				a.quest = null, a.discard.push(r);
			}
			let i = a.nation.shift();
			i && a.discard.push(i);
			break;
		}
		case "abandonArthurFreeEmpire": {
			let n = a.play.find((e) => (V(e)?.en ?? "").startsWith("King Arthur"));
			if (!n) break;
			Q(e, a, n), on(e, t);
			break;
		}
		case "freePlayEmpire":
			on(e, t);
			break;
		case "freePlayEmpirePick": {
			let n = s[0];
			a.hand.includes(n) && Ut(e, t, n, !0, "hand");
			break;
		}
		case "breakTwicePalace":
			zt(e, t, {
				k: "acquire",
				suits: [
					"uncivilised",
					"civilised",
					"region",
					"tributary"
				],
				mode: "break",
				n: 2
			});
			break;
		case "utopianJourneyA":
			un(e, a, i);
			break;
		case "utopianJourneyB":
			un(e, a, i);
			break;
		case "othersUnrestReturnGain": {
			e.flags.unrestReturned = 0, Y(e, t, [{
				k: "special",
				id: "gainPerUnrestReturnedPop"
			}]);
			let n = De(e, t);
			for (let t = n.length - 1; t >= 0; t--) Y(e, n[t], [{
				k: "may",
				eff: [{
					k: "unrestReturn",
					n: 1,
					from: "handOrDiscard"
				}]
			}]);
			break;
		}
		case "gainPerUnrestReturnedPop": {
			let t = e.flags.unrestReturned ?? 0;
			e.flags.unrestReturned = 0, t && q(e, a, 0, t, 0);
			break;
		}
		case "playRegionFromDiscard": {
			if (a.actions <= 0) break;
			let n = a.discard.filter((e) => V(e)?.s.includes("region"));
			if (!n.length) break;
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				optional: !0,
				opts: n.map((e) => ({ id: e })),
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "playFromDiscard|" + e
			}]), Z(e, r);
			break;
		}
		case "playFromDiscard": {
			let n = s[0];
			if (a.actions <= 0 || !a.discard.includes(n)) break;
			--a.actions, ze(e, a, n, "discard", "play"), W(e, "log.play", t, n), J(e, t, "playRegionFromDiscard", { card: n }), Pe(e, t, "regionDiscardGainM") && q(e, a, 2, 0, 0), Y(e, t, [{
				k: "special",
				id: "finishPlay|" + n
			}]), Y(e, t, H(n).play, n);
			break;
		}
		case "recallGarrisonedHere": {
			if (!i) break;
			let n = s[0] === "knight" ? { t: ["knight"] } : {}, r = (a.garrisons[i] ?? []).filter((e) => G(e, n));
			if (!r.length) break;
			let o = {
				owner: t,
				kind: "option",
				n: 1,
				opts: r.map((e) => ({ id: e })),
				source: i
			};
			o.eff = r.map((e) => [{
				k: "special",
				id: "recallHere|" + e
			}]), Z(e, o);
			break;
		}
		case "recallHere": {
			let n = s[0], r = Object.keys(a.garrisons).find((e) => (a.garrisons[e] ?? []).includes(n));
			if (!r) break;
			a.garrisons[r] = a.garrisons[r].filter((e) => e !== n), a.hand.push(n), W(e, "log.recall", t, n);
			break;
		}
		case "exileImpendingNotGraal": {
			let n = a.dev.filter((e) => !(V(e)?.en ?? "").startsWith("Graal")).map((e) => ({ id: e }));
			if (!n.length) break;
			let r = {
				owner: t,
				kind: "option",
				n: 1,
				opts: n,
				source: i
			};
			r.eff = n.map((e) => [{
				k: "special",
				id: "exileImpending|" + e.id
			}]), Z(e, r);
			break;
		}
		case "exileImpending": {
			let n = s[0];
			if (!a.dev.includes(n)) break;
			a.dev = a.dev.filter((e) => e !== n), e.exile.push(n), W(e, "log.exile", t, n);
			break;
		}
		case "abandonUpTo3Acquire": {
			let n = a.play.filter((e) => V(e)?.s.includes("region"));
			if (!n.length) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: Math.min(3, n.length),
				min: 0,
				optional: !0,
				from: "play",
				to: "discard",
				sel: { s: ["region"] },
				follow: [{
					k: "special",
					id: "abandonCountAcquire"
				}]
			});
			break;
		}
		case "abandonCountAcquire": {
			let n = e.lastPicks?.length ?? 0;
			for (let r = 0; r < n; r++) Y(e, t, [{
				k: "may",
				eff: [{
					k: "acquire",
					suits: ["region", "tributary"],
					mode: "acquire"
				}]
			}]);
			break;
		}
		case "sinkPicked": {
			let t = e.pendingCards ?? [];
			for (let n of t) rt(e, a, n, "play");
			break;
		}
		case "garrison": break;
		case "revoltAsk":
			if (!a.hand.length) break;
			Z(e, {
				owner: t,
				kind: "cards",
				n: a.hand.length,
				min: 0,
				optional: !0,
				from: "hand",
				to: "unrest",
				all: !0
			});
			break;
		case "cleanupToken":
			if (!e.market.length) break;
			Z(e, {
				owner: t,
				kind: "market",
				n: 1,
				mode: "tokenPlace",
				opts: e.market.map((e) => ({ id: "mkt:" + e.slot }))
			});
			break;
		case "cleanupReset":
			a.exhausted = [], a.actions = 3, a.exhausts = D[a.nationId].exhaustTokens, a.mods = {}, delete a.flags.nationTok, delete a.flags.devTok;
			for (let t of Object.keys(e.flags)) t.startsWith("stealFail:") && delete e.flags[t];
			e.lastPicks = [], e.looked = [], e.lookedBy = null;
			break;
		case "cleanupDiscard":
			Tt(e, t);
			break;
		case "cleanupDraw": {
			let n = Math.max(0, Ne(e, t) - a.hand.length);
			n > 0 && Qe(e, a, n);
			break;
		}
		case "cleanupEnd":
			vn(e);
			break;
		case "solsticeEnd":
			if (e.collapse) {
				On(e);
				break;
			}
			if (e.endTriggered && e.round >= (e.lastTurn ?? Infinity)) {
				Dn(e);
				break;
			}
			e.round += 1, e.actor = e.order[0], e.phase = "start", e.turnMode = "activate", e.turns += 1, W(e, "log.turnStart", e.actor);
	}
}
function on(e, t) {
	let n = B(e, t).hand.filter((e) => V(e)?.st === "e");
	if (!n.length) return;
	let r = {
		owner: t,
		kind: "option",
		n: 1,
		optional: !0,
		opts: n.map((e) => ({ id: e }))
	};
	r.eff = n.map((e) => [{
		k: "special",
		id: "freePlayEmpirePick|" + e
	}]), Z(e, r);
}
function Q(e, t, n) {
	if (!t.play.includes(n)) return;
	t.play = t.play.filter((e) => e !== n), t.discard.push(n);
	let r = t.garrisons[n];
	r && (delete t.garrisons[n], t.discard.push(...r)), W(e, "log.abandon", t.rid, n);
}
function sn(e, t, n) {
	if (!n) return;
	let r = t.power.indexOf(n), i = V(n)?.rel?.[0];
	if (r >= 0 && i) {
		cn(e, t, r, i);
		return;
	}
	if (i && t.play.includes(n)) {
		t.play = t.play.map((e) => e === n ? i : e);
		return;
	}
	W(e, "log.flipCard", t.rid, n);
}
function cn(e, t, n, r) {
	let i = [];
	for (let e = 0; e < t.power.length; e++) e !== n && t.power[e] !== r && i.push(t.power[e]);
	let a = Math.min(n, i.length);
	i.splice(a, 0, r), t.power = i, r.startsWith("UTO3") && (t.journey = 1), Y(e, t.rid, H(r).play, r);
}
function ln(e, t, n, r) {
	if (!r) return;
	let i = t.power.indexOf(r);
	if (i < 0) return;
	let a = V(r)?.rel ?? [], o = n.toLowerCase(), s = a.find((e) => (V(e)?.en ?? e).toLowerCase() === o || e.toLowerCase() === o) ?? Object.keys(b).find((e) => ((V(e)?.en ?? "").toLowerCase() === o || e.toLowerCase() === o) && V(e)?.nat === t.nationId && V(e)?.loc === "power");
	s && cn(e, t, i, s);
}
function un(e, t, n) {
	sn(e, t, n);
}
function dn(e, t) {
	let n = e.exile.filter((e) => !V(e)?.t.includes("knight")).map((e) => ({ id: "exile:" + e }));
	n.length && Z(e, {
		owner: t,
		kind: "market",
		n: 1,
		mode: "acquire",
		suits: [],
		opts: n
	});
}
function fn(e) {
	let t = V(e);
	return t ? t.s.includes("fame") ? "fame" : t.s.includes("unrest") ? "unrest" : t.s.includes("region") ? "region" : t.s.includes("civilised") ? "civilised" : t.s.includes("uncivilised") ? "uncivilised" : t.s.includes("tributary") ? "tributary" : "other" : "other";
}
var pn = (e) => e.startsWith("bot:") || e.startsWith("aibot:");
function mn(e, t, n) {
	let r = {
		config: e,
		seed: n >>> 0,
		rng: n >>> 0,
		players: {},
		order: [],
		round: 1,
		actor: "",
		phase: "start",
		turnMode: "activate",
		koK: "?FAM?A",
		solo: {
			level: e.soloLevel || 3,
			bot: !!e.solo
		},
		market: [],
		decks: {
			region: [],
			uncivilised: [],
			civilised: [],
			main: [],
			fame: []
		},
		exile: [],
		unrestPile: [],
		fameHidden: !1,
		endTriggered: !1,
		collapse: !1,
		lastTurn: null,
		turns: 0,
		decision: null,
		stack: [],
		log: [],
		looked: [],
		lookedBy: null,
		pendingDraw: null,
		flags: {},
		scored: null,
		ranking: [],
		winner: [],
		serial: 1
	}, i = t.length, a = e.commons === "l" ? "l" : "c", o = e.nations ?? [], s = [];
	for (let e = 0; e < i; e++) {
		let t = o[e];
		s.push(t && D[t] && !s.includes(t) ? t : null);
	}
	let c = U(r, x.filter((e) => !s.includes(e))), l = s.map((e) => e ?? c.shift()), u = new Set(l.map((e) => D[e].en)), d = y.filter((e) => e.loc === "common" && e.box === a && e.pc <= i), f = y.filter((e) => e.loc === "common" && e.box === (a === "c" ? "l" : "c") && e.pc <= i), p = y.filter((e) => e.loc === "common" && !e.box && e.pc <= i && !e.s.includes("fame") && !e.s.includes("unrest")), m = [], h = /* @__PURE__ */ new Set(), g = (e) => {
		let t = fn(e);
		return t === "fame" || t === "unrest" || t === "other";
	};
	for (let e of [...d, ...p]) if (!g(e.id)) {
		if (u.has(e.en)) {
			let t = f.find((t) => !g(t.id) && fn(t.id) === fn(e.id) && !u.has(t.en) && !h.has(t.id) && !m.includes(t.id));
			t && (m.push(t.id), h.add(t.id));
			continue;
		}
		m.push(e.id);
	}
	let _ = i === 2 ? 6 : i === 3 ? 7 : 8, v = {
		region: [],
		uncivilised: [],
		civilised: [],
		tributary: []
	};
	for (let e of m) {
		let t = fn(e);
		t !== "fame" && t !== "unrest" && t !== "other" && v[t].push(e);
	}
	let b = U(r, v.region), S = U(r, v.uncivilised), C = U(r, v.civilised);
	r.decks.region = b.slice(0, _), r.decks.uncivilised = S.slice(0, _), r.decks.civilised = C.slice(0, _), r.decks.main = U(r, [
		...b.slice(_),
		...S.slice(_),
		...C.slice(_),
		...v.tributary
	]);
	let w = U(r, y.filter((e) => e.s.includes("fame") && e.box === a).map((e) => e.id));
	w.splice(0, i === 2 ? 2 : +(i === 3)), r.decks.fame = w, r.unrestPile = U(r, y.filter((e) => !e.s.includes("unrest") || e.pc > i ? !1 : e.loc === "common" || e.loc === "supply" && l.includes(e.nat)).map((e) => e.id));
	let T = Math.floor(Oe(r) * i);
	r.order = t.map((e, n) => t[(n + T) % i]);
	for (let n = 0; n < i; n++) {
		let i = t[n], a = D[l[n]], o = a.accession, s = U(r, te(a.id));
		o && s.push(o);
		let c = [e.powerSide === "a" ? a.power[0] : a.power[1]];
		for (let e of [...a.extra].reverse()) c.push(e);
		let u = {
			rid: i,
			npc: pn(i),
			nationId: a.id,
			side: a.side,
			power: c,
			deck: U(r, ee(a.id)),
			hand: [],
			discard: [],
			play: [],
			history: [],
			flooded: [],
			dev: [...ne(a.id)],
			nation: s,
			garrisons: {},
			actions: 3,
			exhausts: a.exhaustTokens,
			exhausted: [],
			res: {
				m: 3,
				p: 2,
				pr: 1
			},
			handSize: 5,
			mods: {},
			quest: null,
			journey: 0,
			accession: o,
			flags: {},
			cardTok: {}
		};
		r.players[i] = u, Qe(r, u, 5);
	}
	for (let e of [
		"region",
		"uncivilised",
		"civilised"
	]) {
		let t = r.decks[e].shift();
		t && r.market.push({
			id: t,
			slot: e,
			unrest: null,
			tok: {
				m: 0,
				p: 0,
				pr: 0
			}
		});
	}
	for (let e of ["main1", "main2"]) {
		let t = r.decks.main.shift();
		t && r.market.push({
			id: t,
			slot: e,
			unrest: null,
			tok: {
				m: 0,
				p: 0,
				pr: 0
			}
		});
	}
	for (let e of r.market) {
		let t = V(e.id);
		if (t) {
			if (t.s.some((e) => e === "region" || e === "uncivilised" || e === "civilised")) {
				let t = r.unrestPile.pop();
				t && (e.unrest = t);
			}
			t.s.includes("region") || (e.tok.pr += 1);
		}
	}
	return r.actor = r.order[0], W(r, "log.gameStart"), Ke(r), r;
}
function hn() {
	return [
		{
			k: "special",
			id: "cleanupToken"
		},
		{
			k: "special",
			id: "cleanupReset"
		},
		{
			k: "special",
			id: "cleanupDiscard"
		},
		{
			k: "special",
			id: "cleanupDraw"
		},
		{
			k: "special",
			id: "cleanupEnd"
		}
	];
}
function gn(e, t, n) {
	let r = B(e, t), i = V(n);
	if (!i) return !1;
	let a = H(n);
	if (i.st && i.st !== r.side && !r.mods.ignoreEmpire) return !1;
	for (let e of a.playReq) {
		if (/^Cannot be played\.?$/.test(e)) return !1;
		let t = [...e.matchAll(/\[([^\]]+)\]/g)];
		if (!t.length) continue;
		let n = [], i = [];
		for (let t of e.matchAll(/\bnot in play\b|\bin\s+(?:your\s+)?(play(?:\s+area)?|history)\b/gi)) n.push(t.index ?? 0), i.push(/^not in play$/i.test(t[0]) ? "notPlay" : /history/i.test(t[1] ?? "") ? "history" : "play");
		for (let e of t) {
			let t = e.index ?? 0, a = n.findIndex((e) => e > t), o = a >= 0 ? i[a] : n.length ? i[n.length - 1] : null, s = e[1], c = (e) => e.some((e) => e === s || (V(e)?.en ?? "").startsWith(s));
			if (!(o === "history" ? c(r.history) : o === "play" ? c(r.play) : o === "notPlay" ? !c(r.play) : c(r.history) || c(r.play))) return !1;
		}
	}
	return !0;
}
function _n(e) {
	e.phase = "solstice", Y(e, e.order[0], [{
		k: "special",
		id: "solsticeEnd"
	}]);
	for (let t = e.order.length - 1; t >= 0; t--) {
		let n = e.order[t], r = B(e, n), i = r.nationId === "utopians" && r.power.length > 1 ? [
			r.power[0],
			r.power[r.power.length - 1],
			...r.play
		] : [...r.power, ...r.play], a = [];
		for (let e of i) a.push(...H(e).solstice);
		a.length && Y(e, n, a);
	}
	W(e, "log.solstice");
}
function vn(e) {
	let t = e.order.indexOf(e.actor);
	if (t === e.order.length - 1) {
		_n(e);
		return;
	}
	e.actor = e.order[t + 1], e.phase = "start", e.turnMode = "activate", e.turns += 1, W(e, "log.turnStart", e.actor);
}
function yn(e, t, n) {
	if (e.phase === "done") return { code: "err.gameOver" };
	if (e.decision) return t.type === "decide" ? st(e, n, t) : { code: "err.awaitDecision" };
	let r = e.players[n];
	if (!r) return { code: "err.notPlayer" };
	if (n !== e.actor) return { code: "err.notYourTurn" };
	if (t.type === "mode") return e.phase === "start" ? (e.turnMode = t.mode, t.mode === "activate" ? (e.phase = "activate", W(e, "log.modeActivate", n), null) : t.mode === "innovate" ? (W(e, "log.modeInnovate", n), r.discard.push(...r.hand), r.hand = [], Y(e, n, [{
		k: "acquire",
		suits: [
			"region",
			"uncivilised",
			"civilised"
		],
		mode: "break"
	}, ...hn()]), X(e), null) : (W(e, "log.modeRevolt", n), Y(e, n, [{
		k: "special",
		id: "revoltAsk"
	}, ...hn()]), X(e), null)) : { code: "err.badPhase" };
	if (t.type === "play") {
		if (e.phase !== "activate") return { code: "err.badPhase" };
		let i = t.card;
		if (!r.hand.includes(i)) return { code: "err.notInHand" };
		if (!gn(e, n, i)) return { code: "err.cannotPlay" };
		let a = H(i);
		if (!a.free) {
			if (r.actions <= 0) return { code: "err.noAction" };
			--r.actions;
		}
		return a.endGame && Ge(e), Ut(e, n, i, a.free, "hand"), X(e), null;
	}
	if (t.type === "exhaust") {
		if (e.phase !== "activate") return { code: "err.badPhase" };
		let i = t.card;
		if (!r.play.includes(i) && !r.power.includes(i)) return { code: "err.notInPlay" };
		if (r.exhausted.includes(i)) return { code: "err.alreadyExhausted" };
		if (r.exhausts <= 0) return { code: "err.noExhaust" };
		let a = H(i);
		if (!a.exhaust.length) return { code: "err.noExhaustAbility" };
		let o = a.exhaust[0];
		return o.k === "pay" && !It(e, r, o.cost) ? { code: "err.cannotPay" } : (--r.exhausts, r.exhausted.push(i), W(e, "log.exhaust", n, i), Y(e, n, a.exhaust, i), X(e), null);
	}
	return t.type === "endTurn" ? e.phase === "activate" ? (W(e, "log.turnEnd", n), Y(e, n, hn()), X(e), null) : { code: "err.badPhase" } : { code: "err.badChoice" };
}
function bn(e) {
	return [
		...e.hand,
		...e.play,
		...e.deck,
		...e.discard,
		...e.history,
		...e.flooded,
		...e.power,
		...Object.values(e.garrisons).flat()
	];
}
function xn(e) {
	return e.hand.length + e.play.length + e.deck.length + e.discard.length + e.history.length + e.flooded.length;
}
function Sn(e) {
	return e.res.pr + Object.values(e.cardTok).reduce((e, t) => e + t, 0);
}
function Cn(e, t) {
	return e.filter((e) => V(e)?.s.some((e) => t.includes(e))).length;
}
function wn(e, t, n) {
	let r = V(n);
	if (!r?.vpt) return 0;
	let i = r.vpt.find((e) => /^\s*-?\d/.test(e)) ?? r.vpt[0] ?? "", a = bn(t), o = Object.values(t.garrisons).flat(), s = (e) => /^in (your )?play area$|^in play$/.test(e) ? t.play.includes(n) : /^garrisoned$/.test(e) ? o.includes(n) : /^in (your )?history$/.test(e) ? t.history.includes(n) : /^not in play$/.test(e) ? !t.play.includes(n) : !1, c = [...i.matchAll(/(-?\d+)\s*VP if ([^,]+?)(?=,|$)/g)];
	if (c.length) {
		for (let e of c) if (s(e[2].trim())) return Math.min(10, Number(e[1]));
		let e = i.match(/(-?\d+)\s*VP otherwise/);
		return e ? Math.min(10, Number(e[1])) : 0;
	}
	let l = i.match(/^(-?\d+)\s*VP per (\d+)\s*\{material\}\s*\/\s*(\d+)\s*\{region\}$/);
	if (l) {
		let e = Number(l[1]), n = Math.floor(t.res.m / Number(l[2])), r = Math.floor(Cn(a, ["region"]) / Number(l[3]));
		return Math.min(10, (n + r) * e);
	}
	let u = i.match(/^(-?\d+)\s*VP per (\d+)?\s*(.+)$/);
	if (!u) {
		let e = i.match(/^(-?\d+)\s*VP$/);
		return e ? Math.min(10, Number(e[1])) : 0;
	}
	let d = Number(u[1]), f = u[2] ? Number(u[2]) : 1, p = u[3].trim(), m;
	if (/^cards?$/i.test(p)) m = xn(t);
	else if (/^cards? in history$/i.test(p)) m = t.history.length;
	else if (/^cards? in exile$/i.test(p)) m = e.exile.length;
	else if (/^\{variable\} card( \(including this one\))?$/.test(p)) m = a.filter((e) => Ae(e)).length;
	else if (/^\{region\} in play$/.test(p)) m = Cn(t.play, ["region"]);
	else if (/^\{pinned\}.*excluding \{region\}$/.test(p)) m = t.play.filter((e) => V(e)?.hdr === "pin" && !V(e)?.s.includes("region")).length;
	else if (/^\{city\}\/\{metropolis\} in your play area$/.test(p)) m = t.play.filter((e) => V(e)?.t.some((e) => e === "city" || e === "metropolis")).length;
	else if (/^\{city\}\/\{metropolis\}$/.test(p)) m = a.filter((e) => V(e)?.t.some((e) => e === "city" || e === "metropolis")).length;
	else if (/^garrisoned card here$/.test(p)) m = (t.garrisons[n] ?? []).length;
	else if (/^\{unrest\} scored by other players$/.test(p)) m = e.order.filter((e) => e !== t.rid).reduce((t, n) => t + Cn(bn(B(e, n)), ["unrest"]), 0);
	else if (/^players? with fewer \{progress\} than you$/.test(p)) m = e.order.filter((n) => n !== t.rid && Sn(B(e, n)) < Sn(t)).length;
	else if (/^\{material\}$/.test(p)) m = t.res.m;
	else if (/^\{population\}$/.test(p)) m = t.res.p;
	else if (/^\{progress\}$/.test(p)) m = Sn(t);
	else if (/^\{civilised\}$/.test(p)) m = Cn(a, ["civilised"]);
	else if (/^\{uncivilised\} cards?$|^\{uncivilised\}$/.test(p)) m = Cn(a, ["uncivilised"]);
	else if (/^\{region\}$/.test(p)) m = Cn(a, ["region"]);
	else if (/^\{tributary\}$/.test(p)) m = Cn(a, ["tributary"]);
	else if (/^\[([^\]]+)\] in play$/.test(p)) {
		let e = p.match(/^\[([^\]]+)\] in play$/)[1];
		m = t.play.filter((t) => (V(t)?.en ?? "").startsWith(e)).length;
	} else if (/^\{fame\}$/.test(p)) m = Cn(a, ["fame"]);
	else if (/^\{fertile\}$/.test(p)) m = a.filter((e) => V(e)?.t.includes("fertile")).length;
	else if (/^\{river\}$/.test(p)) m = a.filter((e) => V(e)?.t.includes("river")).length;
	else if (/^\{fertile\}\/\{river\}$/.test(p)) m = a.filter((e) => {
		let t = V(e)?.t;
		return !!t?.includes("fertile") || !!t?.includes("river");
	}).length;
	else return 0;
	return Math.min(10, Math.floor(m / f) * d);
}
function Tn(e, t) {
	let n = [...new Set(bn(t))], r = Sn(t);
	for (let i of n) {
		let n = V(i);
		n && (r += n.vp ?? 0, r += wn(e, t, i));
	}
	return r;
}
function En(e, t, n) {
	return e.order.slice().sort((r, i) => {
		let a = t[i] - t[r];
		return a === 0 ? e.order.indexOf(r) - e.order.indexOf(i) : n ? a : -a;
	});
}
function Dn(e) {
	let t = {};
	for (let n of e.order) t[n] = Tn(e, B(e, n));
	e.scored = t, e.ranking = En(e, t, !0);
	let n = t[e.ranking[0]];
	e.winner = e.ranking.filter((e) => t[e] === n), e.phase = "done", e.decision = null, e.stack = [], W(e, "log.gameEnd");
}
function On(e) {
	let t = {}, n = {};
	for (let r of e.order) t[r] = xn(B(e, r)), n[r] = Tn(e, B(e, r));
	e.scored = n;
	let r = Math.min(...e.order.map((e) => t[e])), i = e.order.filter((e) => t[e] === r);
	e.ranking = e.order.slice().sort((r, i) => t[r] - t[i] || n[i] - n[r] || e.order.indexOf(r) - e.order.indexOf(i));
	let a = Math.max(...i.map((e) => n[e]));
	e.winner = i.filter((e) => n[e] === a), e.phase = "done", e.decision = null, e.stack = [], W(e, "log.collapse");
}
function kn(e) {
	return e.phase === "done" ? {
		phase: e.collapse ? "collapsed" : "done",
		winner: e.winner,
		ranking: e.ranking,
		scores: e.scored ?? {}
	} : { phase: e.phase };
}
function An(e, t) {
	let n = {};
	for (let r of e.order) {
		let i = B(e, r);
		n[r] = {
			rid: r,
			npc: i.npc,
			nationId: i.nationId,
			side: i.side,
			power: i.power,
			res: { ...i.res },
			actions: i.actions,
			exhausts: i.exhausts,
			exhausted: i.exhausted.slice(),
			handCount: i.hand.length,
			deckCount: i.deck.length,
			discardCount: i.discard.length,
			play: i.play.slice(),
			dev: i.dev.slice(),
			historyCount: i.history.length,
			floodedCount: i.flooded.length,
			garrisons: Object.fromEntries(Object.entries(i.garrisons).map(([e, t]) => [e, t.slice()])),
			nationCount: i.nation.length,
			nationTop: r === t && i.nation.length ? i.nation[0] : null,
			accession: i.accession,
			quest: i.quest,
			journey: i.journey,
			cardTok: { ...i.cardTok },
			handSize: i.handSize
		};
	}
	let r = e.decision, i = r ? {
		owner: r.owner,
		kind: r.kind,
		n: r.n,
		min: r.min,
		optional: r.optional,
		from: r.from,
		to: r.to,
		sel: r.sel,
		all: r.all,
		opts: r.owner === t ? r.opts : r.opts?.map((e) => ({ id: e.id })),
		suits: r.suits,
		mode: r.mode,
		source: r.source,
		suit: r.suit,
		token: r.token,
		free: r.free,
		exiled: r.exiled
	} : null, a = {
		serial: e.serial,
		round: e.round,
		actor: e.actor,
		phase: e.phase,
		turnMode: e.turnMode,
		order: e.order.slice(),
		config: e.config,
		players: n,
		market: e.market.map((e) => ({
			id: e.id,
			slot: e.slot,
			unrest: !!e.unrest,
			tok: { ...e.tok }
		})),
		decks: {
			region: e.decks.region.length,
			uncivilised: e.decks.uncivilised.length,
			civilised: e.decks.civilised.length,
			main: e.decks.main.length,
			fame: e.decks.fame.length
		},
		exile: e.exile.slice(),
		unrestCount: e.unrestPile.length,
		koK: e.koK,
		fameHidden: e.fameHidden,
		endTriggered: e.endTriggered,
		collapse: e.collapse,
		decision: i,
		log: e.log.slice(-60),
		scored: e.scored,
		ranking: e.ranking.slice(),
		winner: e.winner.slice()
	}, o = B(e, t), s = e.phase === "activate" && e.actor === t && !e.decision, c = s ? o.hand.filter((n) => gn(e, t, n)) : [], l = s && o.exhausts > 0 ? [...o.play, ...o.power].filter((t) => {
		if (o.exhausted.includes(t)) return !1;
		let n = H(t).exhaust;
		if (!n.length) return !1;
		let r = n[0];
		return !(r.k === "pay" && !It(e, o, r.cost));
	}) : [], u = e.decision && e.decision.owner === t && e.decision.kind === "cards" && e.decision.from ? Ie(e, o, e.decision.from).filter((t) => G(t, e.decision.sel)) : [];
	return {
		public: a,
		private: o ? {
			rid: t,
			hand: o.hand.slice(),
			deck: [],
			nation: [],
			discard: o.discard.slice(),
			history: o.history.slice(),
			flooded: o.flooded.slice(),
			looked: e.lookedBy === t ? e.looked.slice() : [],
			playable: c,
			exhaustable: l,
			candidates: u
		} : {
			rid: t,
			hand: [],
			deck: [],
			nation: [],
			discard: [],
			history: [],
			flooded: [],
			looked: [],
			playable: [],
			exhaustable: [],
			candidates: []
		}
	};
}
//#endregion
//#region src/game/meta.ts
var jn = {
	id: "imperiumclassics",
	uuid: "c728f8e9-f73c-427f-bbcc-a84067e14e96",
	tier: "alpha",
	mechanics: [
		"deck-bag-building",
		"engine-building",
		"set-collection",
		"action-points"
	],
	interactionTags: [],
	nameKey: "games.imperiumclassics.name",
	descKey: "games.imperiumclassics.desc",
	rulesKey: "games.imperiumclassics.rules",
	icon: "👑",
	iconImg: "games/imperiumclassics.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#b45309",
	releasedAt: "2026-11-23T20:13:15+08:00",
	search: {
		py: "di guo jing dian yu chuan qi",
		init: "dgjdycq"
	},
	hotseat: "cover"
}, Mn = e.enum([
	"region",
	"uncivilised",
	"civilised",
	"tributary",
	"fame",
	"unrest",
	"power"
]), Nn = e.object({
	m: e.number(),
	p: e.number(),
	pr: e.number()
}), Pn = e.object({
	nations: e.array(e.string()).optional(),
	commons: e.enum(["c", "l"]).optional(),
	powerSide: e.enum(["a", "b"]).optional(),
	solo: e.boolean().optional(),
	soloLevel: e.number().int().min(1).max(5).optional()
}).default({}).transform((e) => ({
	nations: e.nations ?? [],
	commons: e.commons ?? "c",
	powerSide: e.powerSide ?? "b",
	solo: e.solo ?? !1,
	soloLevel: e.soloLevel ?? 3
})), Fn = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("mode"),
		mode: e.enum([
			"activate",
			"innovate",
			"revolt"
		])
	}),
	e.object({
		type: e.literal("play"),
		card: e.string()
	}),
	e.object({
		type: e.literal("exhaust"),
		card: e.string()
	}),
	e.object({ type: e.literal("endTurn") }),
	e.object({
		type: e.literal("decide"),
		cards: e.array(e.string()).optional(),
		opt: e.string().optional(),
		market: e.string().optional(),
		n: e.number().int().optional(),
		confirm: e.boolean().optional(),
		suit: Mn.optional()
	})
]), In = e.enum([
	"region",
	"uncivilised",
	"civilised",
	"main1",
	"main2"
]), Ln = e.object({
	rid: e.string(),
	npc: e.boolean(),
	nationId: e.string(),
	side: e.enum(["b", "e"]),
	power: e.array(e.string()),
	res: Nn,
	actions: e.number().int(),
	exhausts: e.number().int(),
	exhausted: e.array(e.string()),
	handCount: e.number().int(),
	deckCount: e.number().int(),
	discardCount: e.number().int(),
	play: e.array(e.string()),
	dev: e.array(e.string()),
	historyCount: e.number().int(),
	floodedCount: e.number().int(),
	garrisons: e.record(e.string(), e.array(e.string())),
	nationCount: e.number().int(),
	nationTop: e.string().nullable(),
	accession: e.string().nullable(),
	quest: e.string().nullable(),
	journey: e.number().int(),
	cardTok: e.record(e.string(), e.number()),
	handSize: e.number().int()
}), Rn = e.object({
	owner: e.string(),
	kind: e.enum([
		"cards",
		"option",
		"market",
		"confirm",
		"number"
	]),
	n: e.number().int(),
	min: e.number().int().optional(),
	optional: e.boolean().optional(),
	from: e.string().optional(),
	to: e.string().optional(),
	sel: e.any().optional(),
	all: e.boolean().optional(),
	opts: e.array(e.object({
		id: e.string(),
		label: e.string().optional()
	})).optional(),
	suits: e.array(Mn).optional(),
	mode: e.string().optional(),
	source: e.string().optional(),
	suit: Mn.optional(),
	token: e.enum([
		"m",
		"p",
		"pr"
	]).optional(),
	free: e.boolean().optional(),
	exiled: e.boolean().optional()
}), zn = e.object({
	key: e.string(),
	rid: e.string().optional(),
	card: e.string().optional(),
	n: e.number().optional()
}), Bn = e.object({
	serial: e.number().int(),
	round: e.number().int(),
	actor: e.string(),
	phase: e.enum([
		"start",
		"activate",
		"cleanup",
		"solstice",
		"done"
	]),
	turnMode: e.enum([
		"activate",
		"innovate",
		"revolt"
	]),
	order: e.array(e.string()),
	config: e.object({
		nations: e.array(e.string()),
		commons: e.enum(["c", "l"]),
		powerSide: e.enum(["a", "b"]),
		solo: e.boolean(),
		soloLevel: e.number().int()
	}),
	players: e.record(e.string(), Ln),
	market: e.array(e.object({
		id: e.string(),
		slot: In,
		unrest: e.boolean(),
		tok: Nn
	})),
	decks: e.object({
		region: e.number().int(),
		uncivilised: e.number().int(),
		civilised: e.number().int(),
		main: e.number().int(),
		fame: e.number().int()
	}),
	exile: e.array(e.string()),
	unrestCount: e.number().int(),
	koK: e.string(),
	fameHidden: e.boolean(),
	endTriggered: e.boolean(),
	collapse: e.boolean(),
	decision: Rn.nullable(),
	log: e.array(zn),
	scored: e.record(e.string(), e.number()).nullable(),
	ranking: e.array(e.string()),
	winner: e.array(e.string())
}), Vn = e.object({
	rid: e.string(),
	hand: e.array(e.string()),
	deck: e.array(e.string()),
	nation: e.array(e.string()),
	discard: e.array(e.string()),
	history: e.array(e.string()),
	flooded: e.array(e.string()),
	looked: e.array(e.string()),
	playable: e.array(e.string()),
	exhaustable: e.array(e.string()),
	candidates: e.array(e.string())
});
//#endregion
//#region src/game/rules.ts
function Hn(e, t, n) {
	return {
		state: mn(e, t, n),
		fx: []
	};
}
function Un(e, t, n) {
	let r = structuredClone(e), i = yn(r, t, n.by);
	return i ? {
		code: `games.imperiumclassics.${i.code}`,
		params: i.params
	} : { state: r };
}
function Wn(e, t) {
	return An(e, t);
}
function Gn(e) {
	return kn(e);
}
var Kn = {
	meta: jn,
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	schemas: {
		action: Fn,
		publicView: Bn,
		privateView: Vn,
		config: Pn
	},
	setup: Hn,
	reduce: Un,
	viewFor: Wn,
	status: Gn
}, qn = {
	region: "games.imperiumclassics.suitName.region",
	uncivilised: "games.imperiumclassics.suitName.uncivilised",
	civilised: "games.imperiumclassics.suitName.civilised",
	tributary: "games.imperiumclassics.suitName.tributary",
	fame: "games.imperiumclassics.suitName.fame",
	unrest: "games.imperiumclassics.suitName.unrest",
	power: "games.imperiumclassics.suitName.power"
}, Jn = {
	production: "games.imperiumclassics.typeName.production",
	fertile: "games.imperiumclassics.typeName.fertile",
	river: "games.imperiumclassics.typeName.river",
	ocean: "games.imperiumclassics.typeName.ocean",
	city: "games.imperiumclassics.typeName.city",
	metropolis: "games.imperiumclassics.typeName.metropolis",
	knight: "games.imperiumclassics.typeName.knight",
	scroll: "games.imperiumclassics.typeName.scroll",
	mask: "games.imperiumclassics.typeName.mask",
	hunt: "games.imperiumclassics.typeName.hunt",
	miracle: "games.imperiumclassics.typeName.miracle",
	merchant: "games.imperiumclassics.typeName.merchant"
}, Yn = {
	material: "games.imperiumclassics.tok.material",
	population: "games.imperiumclassics.tok.population",
	progress: "games.imperiumclassics.tok.progress",
	region: "games.imperiumclassics.tok.region",
	uncivilised: "games.imperiumclassics.tok.uncivilised",
	civilised: "games.imperiumclassics.tok.civilised",
	tributary: "games.imperiumclassics.tok.tributary",
	fame: "games.imperiumclassics.tok.fame",
	unrest: "games.imperiumclassics.tok.unrest",
	production: "games.imperiumclassics.tok.production",
	fertile: "games.imperiumclassics.tok.fertile",
	river: "games.imperiumclassics.tok.river",
	ocean: "games.imperiumclassics.tok.ocean",
	city: "games.imperiumclassics.tok.city",
	metropolis: "games.imperiumclassics.tok.metropolis",
	knight: "games.imperiumclassics.tok.knight",
	scroll: "games.imperiumclassics.tok.scroll",
	mask: "games.imperiumclassics.tok.mask",
	hunt: "games.imperiumclassics.tok.hunt",
	miracle: "games.imperiumclassics.tok.miracle",
	merchant: "games.imperiumclassics.tok.merchant",
	barbarian: "games.imperiumclassics.tok.barbarian",
	empire: "games.imperiumclassics.tok.empire",
	attack: "games.imperiumclassics.tok.attack",
	pinned: "games.imperiumclassics.tok.pinned",
	exhaust: "games.imperiumclassics.tok.exhaust",
	development: "games.imperiumclassics.tok.development",
	variable: "games.imperiumclassics.tok.variable"
}, Xn = {
	abandon: "games.imperiumclassics.optLabel.abandon",
	acquire: "games.imperiumclassics.optLabel.acquire",
	break: "games.imperiumclassics.optLabel.break",
	develop: "games.imperiumclassics.optLabel.develop",
	discard: "games.imperiumclassics.optLabel.discard",
	draw: "games.imperiumclassics.optLabel.draw",
	exile: "games.imperiumclassics.optLabel.exile",
	fertile: "games.imperiumclassics.optLabel.fertile",
	flip: "games.imperiumclassics.optLabel.flip",
	history: "games.imperiumclassics.optLabel.history",
	material: "games.imperiumclassics.optLabel.material",
	pay: "games.imperiumclassics.optLabel.pay",
	population: "games.imperiumclassics.optLabel.population",
	progress: "games.imperiumclassics.optLabel.progress",
	recall: "games.imperiumclassics.optLabel.recall",
	replace: "games.imperiumclassics.optLabel.replace",
	return: "games.imperiumclassics.optLabel.return",
	river: "games.imperiumclassics.optLabel.river",
	sink: "games.imperiumclassics.optLabel.sink",
	top: "games.imperiumclassics.optLabel.top",
	tributary: "games.imperiumclassics.optLabel.tributary",
	unrest: "games.imperiumclassics.optLabel.unrest"
}, Zn = {
	hand: "games.imperiumclassics.zoneName.hand",
	discard: "games.imperiumclassics.zoneName.discard",
	handOrDiscard: "games.imperiumclassics.zoneName.handOrDiscard",
	play: "games.imperiumclassics.zoneName.play",
	dev: "games.imperiumclassics.zoneName.dev",
	market: "games.imperiumclassics.zoneName.market",
	deckTop: "games.imperiumclassics.zoneName.deckTop",
	nationTop: "games.imperiumclassics.zoneName.nationTop",
	history: "games.imperiumclassics.zoneName.history",
	flooded: "games.imperiumclassics.zoneName.flooded",
	garrison: "games.imperiumclassics.zoneName.garrison",
	unrest: "games.imperiumclassics.zoneName.unrest",
	deckBottom: "games.imperiumclassics.zoneName.deckBottom",
	garrisonHere: "games.imperiumclassics.zoneName.garrisonHere",
	exile: "games.imperiumclassics.zoneName.exile",
	supply: "games.imperiumclassics.zoneName.supply"
}, Qn = {
	region: "games.imperiumclassics.ui.regionDeck",
	uncivilised: "games.imperiumclassics.ui.uncivilisedDeck",
	civilised: "games.imperiumclassics.ui.civilisedDeck"
};
function $n(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(er, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function er({ pub: e, priv: t, members: n, myRid: l, send: m }) {
	let h = a(), g = i((e) => e.locale), [_, v] = r([]), [y, x] = r(e.serial), [S, C] = r(null);
	y !== e.serial && (x(e.serial), v([]));
	let w = e.players[l];
	if (!w) return null;
	let T = e.decision, E = !!T && T.owner === l, ee = e.actor === l, te = ee && !T && e.phase === "activate", ne = E ? t?.candidates ?? [] : [], re = (e) => o[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].hex, ie = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, g) : e;
	}, O = (e) => {
		let t = b[e];
		return t ? g === "zh" ? t.zh : t.en : e;
	}, k = (e) => {
		let t = D[e];
		return t ? g === "zh" ? t.zh : t.en : e;
	}, A = (e) => e && Zn[e] ? h(Zn[e]) : "", ae = (e) => m({
		type: "mode",
		mode: e
	}), j = (e) => {
		C(null), m({
			type: "play",
			card: e
		});
	}, M = (e) => {
		C(null), m({
			type: "exhaust",
			card: e
		});
	}, N = (e) => {
		T && v((t) => {
			if (t.includes(e)) return t.filter((t) => t !== e);
			let n = T.n;
			return t.length >= n ? t : [...t, e];
		});
	}, P = () => {
		T && m({
			type: "decide",
			cards: _
		});
	}, F = () => {
		T && (T.kind === "confirm" ? m({
			type: "decide",
			confirm: !1
		}) : T.kind === "cards" ? m({
			type: "decide",
			cards: []
		}) : m({ type: "decide" }));
	}, oe = () => m({
		type: "decide",
		confirm: !0
	}), I = (t) => {
		if (!E || !T || T.kind !== "market") {
			C(t);
			return;
		}
		let n = e.market.find((e) => e.id === t);
		n && T.opts?.some((e) => e.id === "mkt:" + n.slot) && m({
			type: "decide",
			market: "mkt:" + n.slot
		});
	}, L = (e, n) => {
		if (E && T) {
			if (T.kind === "cards") {
				ne.includes(e) && N(e);
				return;
			}
			if (T.kind === "option") {
				let t = T.opts?.find((t) => t.label === e);
				t && m({
					type: "decide",
					opt: t.id
				});
				return;
			}
			if (T.kind === "market") {
				I(e);
				return;
			}
			return;
		}
		if (n === "hand" && te && t?.playable.includes(e)) {
			j(e);
			return;
		}
		if ((n === "play" || n === "power") && te && t?.exhaustable.includes(e)) {
			M(e);
			return;
		}
		C(e);
	}, R = T ? E ? tr(T, h, A) : h("games.imperiumclassics.ui.waitDecision", { name: ie(T.owner) }) : e.phase === "done" ? h("games.imperiumclassics.ui.endTitle") : ee ? e.phase === "start" ? h("games.imperiumclassics.ui.startPrompt") : e.phase === "activate" ? h("games.imperiumclassics.ui.activatePrompt") : e.phase === "solstice" ? h("games.imperiumclassics.ui.solsticePrompt") : h("games.imperiumclassics.ui.awaitingOthers") : h("games.imperiumclassics.ui.waitTurn", { name: ie(e.actor) }), se = E || ee && e.phase !== "done" ? "accent" : "info", ce = E && T?.kind === "cards", le = !!T && _.length >= (T.min ?? (T.optional ? 0 : T.n)), ue = E && !!T && (T.optional || T.kind === "confirm" || T.kind === "cards" && (T.min ?? 0) === 0), de = e.order.filter((e) => e !== l);
	return /* @__PURE__ */ p("div", {
		className: "ic-screen",
		children: [/* @__PURE__ */ f(c, {
			adaptive: !0,
			className: "ic-game",
			scroll: !0,
			actionsHeight: "ic-actions-slot",
			banner: /* @__PURE__ */ p("div", {
				className: "ic-banner",
				children: [/* @__PURE__ */ f(s, {
					tone: se,
					text: R,
					chip: h("games.imperiumclassics.ui.round", { n: e.round }),
					accent: jn.accent,
					sub: e.endTriggered && e.phase !== "done" ? h("games.imperiumclassics.ui.endTriggered") : void 0
				}), /* @__PURE__ */ p("div", {
					className: "ic-counters scrollbar-none",
					children: [
						/* @__PURE__ */ p("span", {
							className: "ic-counter",
							children: [/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--pr" }), w.res.pr]
						}),
						/* @__PURE__ */ p("span", {
							className: "ic-counter",
							children: [/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--m" }), w.res.m]
						}),
						/* @__PURE__ */ p("span", {
							className: "ic-counter",
							children: [/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--p" }), w.res.p]
						}),
						/* @__PURE__ */ f("span", {
							className: "ic-counter ic-counter--sep",
							children: h("games.imperiumclassics.ui.actionsLeft", { n: w.actions })
						}),
						/* @__PURE__ */ f("span", {
							className: "ic-counter",
							children: h("games.imperiumclassics.ui.exhaustLeft", { n: w.exhausts })
						}),
						/* @__PURE__ */ p("span", {
							className: "ic-counter ic-counter--sep",
							children: [
								h("games.imperiumclassics.ui.unrestPile"),
								" ",
								e.unrestCount
							]
						}),
						/* @__PURE__ */ p("span", {
							className: "ic-counter",
							children: [
								h("games.imperiumclassics.ui.mainDeck"),
								" ",
								e.decks.main
							]
						})
					]
				})]
			}),
			actions: /* @__PURE__ */ f("div", {
				className: "ic-actions scrollbar-none",
				children: /* @__PURE__ */ p("div", {
					className: "ic-actions__row",
					children: [
						ce && T && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
							className: "ic-actions__count",
							children: h("games.imperiumclassics.ui.selectedCount", {
								n: _.length,
								total: T.n
							})
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn ic-btn--primary",
							disabled: !le,
							onClick: P,
							children: h("games.imperiumclassics.ui.confirm")
						})] }),
						E && T?.kind === "confirm" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
							className: "ic-actions__count",
							children: h("games.imperiumclassics.ui.confirmPrompt")
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn ic-btn--primary",
							onClick: oe,
							children: h("games.imperiumclassics.ui.confirm")
						})] }),
						ue && /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn",
							onClick: F,
							children: h("games.imperiumclassics.ui.skip")
						}),
						!T && ee && e.phase === "start" && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn ic-btn--primary",
								onClick: () => ae("activate"),
								children: h("games.imperiumclassics.ui.btnActivate")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn",
								onClick: () => ae("innovate"),
								children: h("games.imperiumclassics.ui.btnInnovate")
							}),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn",
								onClick: () => ae("revolt"),
								children: h("games.imperiumclassics.ui.btnRevolt")
							})
						] }),
						!T && ee && e.phase === "activate" && /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn ic-btn--primary",
							onClick: () => m({ type: "endTurn" }),
							children: h("games.imperiumclassics.ui.endTurn")
						}),
						!T && !ee && e.phase !== "done" && /* @__PURE__ */ f("span", {
							className: "ic-actions__count",
							children: h("games.imperiumclassics.ui.waitTurn", { name: ie(e.actor) })
						}),
						T && !E && /* @__PURE__ */ f("span", {
							className: "ic-actions__count",
							children: h("games.imperiumclassics.ui.waitDecision", { name: ie(T.owner) })
						})
					]
				})
			}),
			children: /* @__PURE__ */ p("div", {
				className: "ic-board",
				children: [
					/* @__PURE__ */ f("section", {
						className: "ic-opponents",
						"aria-label": h("games.imperiumclassics.ui.playArea"),
						children: de.map((t) => /* @__PURE__ */ f(ar, {
							rid: t,
							p: e.players[t],
							actor: e.actor === t,
							color: re(t),
							name: ie(t),
							member: n.find((e) => e.rid === t),
							myRid: l,
							nation: k(e.players[t]?.nationId ?? "")
						}, t))
					}),
					/* @__PURE__ */ p("section", {
						className: "ic-market",
						"aria-label": h("games.imperiumclassics.ui.market"),
						children: [
							/* @__PURE__ */ f("h2", {
								className: "ic-title",
								children: h("games.imperiumclassics.ui.market")
							}),
							/* @__PURE__ */ f("div", {
								className: "ic-market__row",
								children: e.market.map((e) => {
									let t = E && T?.kind === "market" && !!T.opts?.some((t) => t.id === "mkt:" + e.slot);
									return /* @__PURE__ */ p("div", {
										className: `ic-market-card${t ? " is-target" : ""}`,
										children: [/* @__PURE__ */ f(or, {
											id: e.id,
											small: !0,
											selected: !1,
											onClick: () => L(e.id, "market"),
											disabled: !1,
											badge: /* @__PURE__ */ f(rr, { tok: e.tok })
										}), e.unrest && /* @__PURE__ */ f("span", {
											className: "ic-market-unrest",
											"aria-label": h("games.imperiumclassics.ui.unrestPile"),
											children: h("games.imperiumclassics.tok.unrest")
										})]
									}, e.id + e.slot);
								})
							}),
							E && T?.kind === "market" && /* @__PURE__ */ f(nr, {
								decision: T,
								market: e.market,
								cardName: O,
								onChoose: (e) => m({
									type: "decide",
									market: e
								}),
								t: h
							}),
							E && T?.kind === "option" && T.suits && T.mode === "break" && /* @__PURE__ */ f(nr, {
								decision: T,
								market: e.market,
								cardName: O,
								onChoose: (e) => m({
									type: "decide",
									opt: e
								}),
								t: h
							})
						]
					}),
					E && T?.kind === "option" && !(T.mode === "break" && T.suits) && /* @__PURE__ */ f(nr, {
						decision: T,
						market: e.market,
						cardName: O,
						onChoose: (e) => m({
							type: "decide",
							opt: e
						}),
						t: h
					}),
					E && T?.kind === "cards" && /* @__PURE__ */ p("section", {
						className: "ic-candidates",
						"aria-label": A(T.from),
						children: [/* @__PURE__ */ f("h2", {
							className: "ic-title",
							children: A(T.from)
						}), /* @__PURE__ */ p("div", {
							className: "ic-candidate__row",
							children: [ne.map((e) => /* @__PURE__ */ f(or, {
								id: e,
								selected: _.includes(e),
								onClick: () => N(e),
								disabled: !1
							}, e)), ne.length === 0 && /* @__PURE__ */ f("span", {
								className: "ic-empty",
								children: h("games.imperiumclassics.ui.emptyZone")
							})]
						})]
					}),
					/* @__PURE__ */ p("section", {
						className: "ic-mine",
						"aria-label": h("games.imperiumclassics.ui.yourNation"),
						children: [
							/* @__PURE__ */ p("div", {
								className: "ic-mine__head",
								children: [
									/* @__PURE__ */ f("span", {
										className: "ic-nation",
										children: k(w.nationId)
									}),
									/* @__PURE__ */ f("span", {
										className: "ic-side",
										children: w.side === "b" ? h("games.imperiumclassics.ui.sideBarbarian") : h("games.imperiumclassics.ui.sideEmpire")
									}),
									/* @__PURE__ */ p("span", {
										className: "ic-mine__counts",
										children: [
											h("games.imperiumclassics.ui.deck"),
											" ",
											w.deckCount,
											" · ",
											h("games.imperiumclassics.ui.discard"),
											" ",
											w.discardCount,
											" · ",
											h("games.imperiumclassics.ui.devArea"),
											" ",
											w.dev.length,
											" · ",
											h("games.imperiumclassics.ui.nation"),
											" ",
											w.nationCount,
											" · ",
											h("games.imperiumclassics.ui.history"),
											" ",
											w.historyCount,
											w.floodedCount >= 0 && w.nationId === "atlanteans" ? ` · ${h("games.imperiumclassics.ui.flooded")} ${w.floodedCount}` : ""
										]
									})
								]
							}),
							/* @__PURE__ */ f(ir, {
								title: h("games.imperiumclassics.ui.power"),
								ids: w.power,
								exhausted: w.exhausted,
								onOpen: (e) => L(e, "power")
							}),
							/* @__PURE__ */ f(ir, {
								title: h("games.imperiumclassics.ui.playArea"),
								ids: w.play,
								exhausted: w.exhausted,
								onOpen: (e) => L(e, "play")
							}),
							/* @__PURE__ */ f(ir, {
								title: h("games.imperiumclassics.ui.devArea"),
								ids: w.dev,
								onOpen: (e) => L(e, "other")
							}),
							Object.keys(w.garrisons).length > 0 && /* @__PURE__ */ p("div", {
								className: "ic-garrisons",
								children: [/* @__PURE__ */ f("span", {
									className: "ic-row-title",
									children: h("games.imperiumclassics.ui.garrison")
								}), Object.values(w.garrisons).flat().map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "ic-mini-card",
									onClick: () => C(e),
									children: O(e)
								}, e))]
							}),
							t && t.history.length > 0 && /* @__PURE__ */ p("div", {
								className: "ic-garrisons",
								children: [/* @__PURE__ */ f("span", {
									className: "ic-row-title",
									children: h("games.imperiumclassics.ui.history")
								}), t.history.map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "ic-mini-card",
									onClick: () => C(e),
									children: O(e)
								}, e))]
							}),
							t && t.flooded.length > 0 && /* @__PURE__ */ p("div", {
								className: "ic-garrisons",
								children: [/* @__PURE__ */ f("span", {
									className: "ic-row-title",
									children: h("games.imperiumclassics.ui.flooded")
								}), t.flooded.map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "ic-mini-card",
									onClick: () => C(e),
									children: O(e)
								}, e))]
							})
						]
					}),
					/* @__PURE__ */ p("section", {
						className: "ic-hand",
						"aria-label": h("games.imperiumclassics.ui.hand"),
						children: [/* @__PURE__ */ p("h2", {
							className: "ic-title",
							children: [
								h("games.imperiumclassics.ui.hand"),
								" ",
								/* @__PURE__ */ f("b", { children: t?.hand.length ?? w.handCount })
							]
						}), /* @__PURE__ */ p("div", {
							className: "ic-hand__row",
							children: [(t?.hand ?? []).map((e) => {
								let n = te && !!t?.playable.includes(e), r = ce && ne.includes(e);
								return /* @__PURE__ */ f(or, {
									id: e,
									selected: _.includes(e),
									playable: n,
									candidate: r,
									onClick: () => L(e, "hand"),
									disabled: !1
								}, e);
							}), (t?.hand.length ?? 0) === 0 && /* @__PURE__ */ f("span", {
								className: "ic-empty",
								children: h("games.imperiumclassics.ui.emptyZone")
							})]
						})]
					}),
					t?.looked && t.looked.length > 0 && /* @__PURE__ */ p("section", {
						className: "ic-looked",
						children: [/* @__PURE__ */ f("h2", {
							className: "ic-title",
							children: h("games.imperiumclassics.ui.lookedTitle")
						}), /* @__PURE__ */ f("div", {
							className: "ic-candidate__row",
							children: t.looked.map((e) => {
								let t = E && T?.kind === "option" ? T.opts?.find((t) => t.label === e) : void 0;
								return /* @__PURE__ */ f(or, {
									id: e,
									onClick: () => t ? m({
										type: "decide",
										opt: t.id
									}) : C(e),
									disabled: !1
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ p("details", {
						className: "ic-log",
						children: [/* @__PURE__ */ f("summary", { children: h("games.imperiumclassics.ui.logTitle") }), /* @__PURE__ */ f("ul", { children: e.log.slice().reverse().map((e, t) => {
							let n = e.key === "log.steal", r = e.card ? n ? "" : O(e.card) : void 0, i = n && e.card ? ie(e.card) : void 0;
							return /* @__PURE__ */ f("li", { children: h("games.imperiumclassics." + e.key, {
								name: e.rid ? ie(e.rid) : "",
								card: r ?? "",
								target: i ?? "",
								n: e.n ?? 0
							}) }, t);
						}) })]
					})
				]
			})
		}), S && /* @__PURE__ */ p("div", {
			className: "ic-detail",
			role: "dialog",
			"aria-label": O(S),
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "ic-detail__shade",
				"aria-label": h("games.imperiumclassics.ui.close"),
				onClick: () => C(null)
			}), /* @__PURE__ */ p("div", {
				className: "ic-detail__panel",
				children: [
					/* @__PURE__ */ p("div", {
						className: "ic-detail__head",
						children: [/* @__PURE__ */ f("span", { children: O(S) }), /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-detail__close",
							onClick: () => C(null),
							"aria-label": h("games.imperiumclassics.ui.close"),
							children: "✕"
						})]
					}),
					/* @__PURE__ */ f(or, {
						id: S,
						full: !0,
						onClick: () => void 0,
						disabled: !1
					}),
					/* @__PURE__ */ p("div", {
						className: "ic-detail__actions",
						children: [te && t?.playable.includes(S) && /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn ic-btn--primary",
							onClick: () => j(S),
							children: h("games.imperiumclassics.ui.play")
						}), te && t?.exhaustable.includes(S) && /* @__PURE__ */ f("button", {
							type: "button",
							className: "ic-btn ic-btn--primary",
							onClick: () => M(S),
							children: h("games.imperiumclassics.ui.exhaust")
						})]
					})
				]
			})]
		})]
	});
}
function tr(e, t, n) {
	if (e.kind === "cards") {
		let r = n(e.from);
		return e.min !== void 0 && e.min < e.n ? t("games.imperiumclassics.ui.pickCardsRange", {
			min: e.min,
			n: e.n,
			zone: r
		}) : e.optional && (e.min ?? 0) === 0 ? t("games.imperiumclassics.ui.pickCardsUpTo", {
			n: e.n,
			zone: r
		}) : t("games.imperiumclassics.ui.pickCards", {
			n: e.n,
			zone: r
		});
	}
	if (e.kind === "market") return e.mode === "break" ? t("games.imperiumclassics.ui.pickMarketBreak") : e.mode === "exile" ? t("games.imperiumclassics.ui.pickMarketExile") : e.mode === "token" || e.mode === "tokenPlace" ? t("games.imperiumclassics.ui.pickMarketToken", { res: t(e.token === "m" ? "games.imperiumclassics.ui.material" : e.token === "p" ? "games.imperiumclassics.ui.population" : "games.imperiumclassics.ui.progress") }) : (e.suits?.length, t("games.imperiumclassics.ui.pickMarketAcquire"));
	if (e.kind === "option") {
		if (e.mode === "break") return t("games.imperiumclassics.ui.pickSuit");
		let n = e.opts?.map((e) => e.label) ?? [];
		return n.length && n.every((e) => !!e && !!b[e]) ? t("games.imperiumclassics.ui.pickFromZone") : t("games.imperiumclassics.ui.pickOption");
	}
	return e.kind === "confirm" ? t("games.imperiumclassics.ui.confirmPrompt") : t("games.imperiumclassics.ui.pickOption");
}
function nr({ decision: e, market: t, cardName: n, onChoose: r, t: i }) {
	let a = e.opts ?? [], o = (e) => e.label && b[e.label] ? "card" : e.id.startsWith("mkt:") ? "market" : e.id.startsWith("deck:") || e.id === "search" || e.id.startsWith("exile:") ? "source" : "text";
	return /* @__PURE__ */ p("div", {
		className: "ic-options",
		children: [a.map((e) => {
			let a = o(e);
			if (a === "card") return /* @__PURE__ */ f(or, {
				id: e.label,
				onClick: () => r(e.id),
				disabled: !1
			}, e.id);
			if (a === "market") {
				let a = e.id.slice(4), o = t.find((e) => e.slot === a);
				return o ? /* @__PURE__ */ p("button", {
					type: "button",
					className: "ic-btn",
					onClick: () => r(e.id),
					children: [
						i("games.imperiumclassics.ui.pickMarketAcquire"),
						" · ",
						n(o.id)
					]
				}, e.id) : null;
			}
			if (a === "source") {
				let t = e.id === "search" ? i("games.imperiumclassics.ui.searchMainDeck") : e.id.startsWith("deck:") ? i("games.imperiumclassics.ui.drawFromDeck", { deck: i(Qn[e.id.slice(5)] ?? "games.imperiumclassics.ui.regionDeck") }) : n(e.id.slice(6));
				return /* @__PURE__ */ f("button", {
					type: "button",
					className: "ic-btn",
					onClick: () => r(e.id),
					children: t
				}, e.id);
			}
			let s = e.label ?? e.id, c = Xn[s] ?? (qn[s] ? qn[s] : void 0);
			return /* @__PURE__ */ f("button", {
				type: "button",
				className: "ic-btn",
				onClick: () => r(e.id),
				children: c ? i(c) : s
			}, e.id);
		}), a.length === 0 && /* @__PURE__ */ f("span", {
			className: "ic-empty",
			children: i("games.imperiumclassics.ui.emptyZone")
		})]
	});
}
function rr({ tok: e }) {
	let t = [];
	return e.pr && t.push(/* @__PURE__ */ f("span", {
		className: "ic-tok-chip ic-dot--pr",
		children: e.pr
	}, "pr")), e.m && t.push(/* @__PURE__ */ f("span", {
		className: "ic-tok-chip ic-dot--m",
		children: e.m
	}, "m")), e.p && t.push(/* @__PURE__ */ f("span", {
		className: "ic-tok-chip ic-dot--p",
		children: e.p
	}, "p")), t.length ? /* @__PURE__ */ f("span", {
		className: "ic-tokens",
		children: t
	}) : null;
}
function ir({ title: e, ids: t, exhausted: n, onOpen: r }) {
	let i = a();
	return t.length ? /* @__PURE__ */ p("div", {
		className: "ic-card-row",
		children: [
			/* @__PURE__ */ f("span", {
				className: "ic-row-title",
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "ic-card-row__cards",
				children: t.map((e) => /* @__PURE__ */ f(or, {
					id: e,
					small: !0,
					onClick: () => r(e),
					disabled: !1,
					exhausted: !!n?.includes(e)
				}, e))
			}),
			t.length === 0 && /* @__PURE__ */ f("span", {
				className: "ic-empty",
				children: i("games.imperiumclassics.ui.emptyZone")
			})
		]
	}) : null;
}
function ar({ rid: e, p: t, actor: n, color: r, name: o, member: s, myRid: c, nation: u }) {
	let d = a(), m = i((e) => e.locale);
	if (!t) return null;
	let h = Object.values(t.garrisons).flat();
	return /* @__PURE__ */ p("div", {
		className: `ic-opp${n ? " is-turn" : ""}`,
		style: { "--seat-color": r },
		children: [s && /* @__PURE__ */ f(l, {
			m: s,
			myRid: c,
			action: n ? "pending" : null,
			anchorName: `seat:${e}`,
			box: "ic-opp__avatar",
			img: "ic-opp__avatar-img"
		}), /* @__PURE__ */ p("div", {
			className: "ic-opp__info",
			children: [
				/* @__PURE__ */ f("span", {
					className: "ic-opp__name",
					title: o,
					children: o
				}),
				/* @__PURE__ */ p("span", {
					className: "ic-opp__nation",
					children: [
						u,
						" · ",
						t.side === "b" ? d("games.imperiumclassics.ui.sideBarbarian") : d("games.imperiumclassics.ui.sideEmpire")
					]
				}),
				/* @__PURE__ */ p("span", {
					className: "ic-opp__res",
					children: [
						/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--m" }),
						t.res.m,
						" ",
						/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--p" }),
						t.res.p,
						" ",
						/* @__PURE__ */ f("i", { className: "ic-dot ic-dot--pr" }),
						t.res.pr
					]
				}),
				/* @__PURE__ */ p("span", {
					className: "ic-opp__counts",
					children: [
						d("games.imperiumclassics.ui.hand"),
						" ",
						t.handCount,
						" · ",
						d("games.imperiumclassics.ui.deck"),
						" ",
						t.deckCount,
						" · ",
						d("games.imperiumclassics.ui.discard"),
						" ",
						t.discardCount,
						" · ",
						d("games.imperiumclassics.ui.playArea"),
						" ",
						t.play.length
					]
				}),
				h.length > 0 && /* @__PURE__ */ p("span", {
					className: "ic-opp__counts",
					children: [
						d("games.imperiumclassics.ui.garrison"),
						" ",
						h.map((e) => (m === "zh" ? b[e]?.zh : b[e]?.en) ?? e).join(m === "zh" ? "、" : ", ")
					]
				})
			]
		})]
	});
}
function or({ id: e, small: t, full: n, selected: r, playable: o, candidate: s, exhausted: c, badge: l, onClick: u, disabled: d }) {
	let m = a(), h = i((e) => e.locale), g = b[e];
	if (!g) return null;
	let _ = h === "zh" ? g.zh : g.en, v = g.text ? h === "zh" ? g.text[0] : g.text[1] : [], y = g.vpt ? h === "zh" ? g.vpt[0] : g.vpt[1] : null, x = g.vp ? g.vp : y ? "?" : "", S = g.s.find((e) => e !== "power") ?? g.s[0] ?? "power", C = ["ic-card"];
	return t && C.push("ic-card--small"), n && C.push("ic-card--full"), r && C.push("is-selected"), o && C.push("is-playable"), s && C.push("is-candidate"), c && C.push("is-exhausted"), d && C.push("is-disabled"), /* @__PURE__ */ p("button", {
		type: "button",
		className: C.join(" "),
		onClick: u,
		disabled: d,
		"aria-pressed": r || void 0,
		"aria-label": `${_}${x === "" ? "" : " " + x}`,
		children: [
			/* @__PURE__ */ f("span", { className: `ic-card__suit ic-suit--${S}` }),
			/* @__PURE__ */ p("span", {
				className: "ic-card__head",
				children: [/* @__PURE__ */ f("span", {
					className: "ic-card__name",
					children: _
				}), x !== "" && /* @__PURE__ */ f("span", {
					className: "ic-card__vp",
					"aria-label": m("games.imperiumclassics.ui.vp"),
					children: x
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: "ic-card__meta",
				children: [
					g.s.filter((e) => e !== "power").map((e) => /* @__PURE__ */ f("i", {
						className: "ic-chip",
						children: qn[e] ? m(qn[e]) : e
					}, e)),
					g.hdr === "pin" && /* @__PURE__ */ f("i", {
						className: "ic-chip ic-chip--pin",
						children: m("games.imperiumclassics.tok.pinned")
					}),
					g.hdr === "atk" && /* @__PURE__ */ f("i", {
						className: "ic-chip ic-chip--atk",
						children: m("games.imperiumclassics.tok.attack")
					})
				]
			}),
			v.length > 0 && /* @__PURE__ */ p("span", {
				className: "ic-card__text",
				children: [v.map((e, t) => /* @__PURE__ */ f("span", {
					className: "ic-card__line",
					children: /* @__PURE__ */ f(sr, { text: e })
				}, t)), y && /* @__PURE__ */ f("span", {
					className: "ic-card__line ic-card__line--vpt",
					children: /* @__PURE__ */ f(sr, { text: y })
				})]
			}),
			(g.dev || g.t.length > 0) && /* @__PURE__ */ p("span", {
				className: "ic-card__foot",
				children: [g.t.map((e) => /* @__PURE__ */ f("i", {
					className: "ic-chip ic-chip--type",
					children: Jn[e] ? m(Jn[e]) : e
				}, e)), g.dev && /* @__PURE__ */ p("i", {
					className: "ic-chip ic-chip--dev",
					children: [
						m("games.imperiumclassics.ui.devCost"),
						" ",
						g.dev[0],
						"/",
						g.dev[1],
						"/",
						g.dev[2]
					]
				})]
			}),
			l && /* @__PURE__ */ f("span", {
				className: "ic-card__badge",
				children: l
			}),
			c && /* @__PURE__ */ f("span", {
				className: "ic-card__exhausted",
				children: m("games.imperiumclassics.ui.exhaustDone")
			})
		]
	});
}
function sr({ text: e }) {
	let t = a(), n = e.split(/(\{[^{}]+\})/);
	return /* @__PURE__ */ f(d, { children: n.map((e, n) => {
		if (e.startsWith("{") && e.endsWith("}")) {
			let r = e.slice(1, -1), i = Yn[r];
			return /* @__PURE__ */ f("b", {
				className: `ic-tok${cr(r)}`,
				children: i ? t(i) : r
			}, n);
		}
		return /* @__PURE__ */ f("span", { children: e.replace(/\*/g, "") }, n);
	}) });
}
function cr(e) {
	return e === "material" || e === "population" || e === "progress" ? ` ic-tok--${e}` : e === "region" || e === "uncivilised" || e === "civilised" || e === "tributary" || e === "fame" || e === "unrest" ? ` ic-tok--suit ic-tok--${e}` : "";
}
//#endregion
//#region src/game/bot.ts
var lr = {
	region: 2.3,
	uncivilised: 2.7,
	civilised: 3.1,
	tributary: 1.5,
	fame: 3.4,
	unrest: -2,
	power: 0
}, ur = {
	acquire: 4,
	break: 3.4,
	develop: 3,
	draw: 2.4,
	progress: 2.2,
	fame: 2.8,
	population: 1.6,
	material: 1.2,
	fertile: 1.4,
	river: 1.4,
	tributary: 1,
	flip: 1.5,
	recall: 1.1,
	replace: 1,
	search: 2.2,
	top: .6,
	return: .4,
	history: .3,
	pay: -.4,
	abandon: -1.3,
	discard: -1.5,
	sink: -1.1,
	exile: -.9,
	unrest: -1.6,
	skip: 0
};
function $(e) {
	if (!e) return 0;
	let t = b[e];
	if (!t) return 0;
	let n = t.vp ?? 0;
	t.vpt && (n += 1.5), t.dev && (n += 1.3), t.nat && (n += .8);
	for (let e of t.s) n += lr[e] ?? 0;
	return t.t.length && (n += .3), n;
}
function dr(e) {
	return (e.m ?? 0) * .3 + (e.p ?? 0) * .55 + (e.pr ?? 0) * 1.1 + (e.cards ?? 0) * .7 + (e.actions ?? 0) * 1.1 + (e.abandon?.n ?? 0) * .6 + (e.sink?.n ?? 0) * .7 + (e.topDeck ?? 0) * .6 + (e.discardMask ?? 0) * .8 + (e.unrestReturn?.n ?? 0) * .25 + (e.historyPut?.n ?? 0) * .6 + (e.garrison?.n ?? 0) * .5 + (e.returnTop ?? 0) * .6 + (e.exileHand?.n ?? 0) * .6 + (e.progress ?? 0) * .9 + (e.progressAll?.min ?? 0) * .9 + (e.recall?.n ?? 0) * .5;
}
function fr(e, t = 0) {
	if (!e || !e.length || t > 3) return 0;
	let n = 0;
	for (let r of e) switch (r.k) {
		case "gain":
			n += (r.m ?? 0) * .35 + (r.p ?? 0) * .6 + (r.pr ?? 0) * 1.1;
			break;
		case "gainPer":
			n += 1.1 * Math.max(1, r.n);
			break;
		case "steal":
			n += ((r.m ?? 0) + (r.p ?? 0)) * .4 + (r.pr ?? 0) * 1.5;
			break;
		case "garrison":
			n += .5 * (r.n ?? 1);
			break;
		case "give":
			n -= .2;
			break;
		case "find":
			n += 1;
			break;
		case "discardAny":
			n -= .3;
			break;
		case "token":
			n += (r.n ?? 1) * .7;
			break;
		case "draw":
			n += r.n * .85;
			break;
		case "drawUpTo":
			n += r.n * .55;
			break;
		case "discard":
			n -= r.n * .55;
			break;
		case "mill":
			n += r.n * .3;
			break;
		case "nationTop":
			n += .4;
			break;
		case "acquire":
			n += 2.6;
			break;
		case "develop":
			n += r.free ? 3 : 2.3;
			break;
		case "freePlay":
			n += 2.1;
			break;
		case "playFrom":
			n += 1.8;
			break;
		case "exile":
			n -= .25;
			break;
		case "pick":
			n += .5 + fr(r.then, t + 1) * .5 + fr(r.follow, t + 1) * .5;
			break;
		case "abandon":
			n -= r.n * .6;
			break;
		case "recall":
			n += r.n * .9;
			break;
		case "sink":
			n -= r.n * .7;
			break;
		case "unrestTake":
			n -= (r.n ?? 1) * 1.5;
			break;
		case "unrestReturn":
			n += (r.n ?? 1) * 1.3;
			break;
		case "fame":
			n += Math.max(1, r.n) * 2.1;
			break;
		case "actions":
			n += r.n * 1.1;
			break;
		case "spendActions":
			n -= r.n * 1.1;
			break;
		case "flip":
			n += 1.2;
			break;
		case "peek":
			n += .5;
			break;
		case "lookedTake":
			n += 1.2;
			break;
		case "lookedRest": break;
		case "shuffleNation":
			n += .3;
			break;
		case "swapHandNation":
			n += .2;
			break;
		case "choose":
			n += Math.max(0, ...r.opts.map((e) => fr(e.eff, t + 1)));
			break;
		case "may":
			n += fr(r.eff, t + 1) * .55;
			break;
		case "if":
			n += fr(r.then, t + 1) * .6;
			break;
		case "each":
			n += fr(r.eff, t + 1) * .7;
			break;
		case "pay":
			n += fr(r.eff, t + 1) - dr(r.cost);
			break;
		case "swapExileMarket":
			n += .5;
			break;
		case "endGame":
			n += .2;
			break;
		case "gainMarket":
			n += 1.4;
			break;
		case "marketToken":
			n += .7;
			break;
		case "special":
			n += .4;
			break;
		case "quest":
			n += 1;
			break;
		case "journey":
			n += 1;
			break;
		case "spend":
			n -= dr({
				m: r.m,
				p: r.p,
				pr: r.pr,
				actions: r.actions
			});
			break;
		case "progressPay":
			n -= r.min * .9;
			break;
		case "topDeckCost":
			n -= r.n * .6;
			break;
		case "discardMask":
			n -= r.n * .8;
			break;
		case "garrisonCost":
			n -= r.n * .5;
			break;
		case "returnTopCost": n -= r.n * .6;
	}
	return n;
}
function pr(e, t) {
	let n = $(t), r = e.market.find((e) => e.id === t);
	return r && (n += r.tok.m * .3 + r.tok.p * .5 + r.tok.pr * .9, r.unrest && --n), n;
}
function mr(e, t) {
	let n = t.label ?? t.id;
	if (b[n]) return t.id.startsWith("d") ? $(n) + .6 : t.id.startsWith("f") ? $(n) + 1.2 : t.id.startsWith("p") ? $(n) + .8 : $(n);
	if (n.startsWith("mkt:")) {
		let t = n.slice(4), r = e.market.find((e) => e.slot === t);
		return r ? pr(e, r.id) : 0;
	}
	return n.startsWith("exile:") ? $(n.slice(6)) : n.startsWith("deck:") ? 2.6 : ur[n] ?? .2;
}
function hr(e, t) {
	let n = t.opts ?? [];
	if (!n.length) return {
		type: "decide",
		opt: "skip"
	};
	let r = n[0], i = -Infinity;
	for (let a of n) {
		let n = a.label ?? a.id, o = mr(e, a);
		t.mode === "break" && (n === "region" || n === "uncivilised" || n === "civilised") && (o = e.decks[n] > 0 ? 4 : 1), o > i && (r = a, i = o);
	}
	return t.optional && i < .15 ? {
		type: "decide",
		opt: "skip"
	} : {
		type: "decide",
		opt: r.id
	};
}
function gr(e, t) {
	let n = t.opts ?? [];
	if (!n.length) return { type: "decide" };
	let r = n[0], i = -Infinity;
	for (let a of n) {
		let n;
		if (a.id.startsWith("mkt:")) {
			let t = a.id.slice(4), r = e.market.find((e) => e.slot === t);
			n = r ? pr(e, r.id) : 0;
		} else if (a.id.startsWith("exile:")) n = $(a.id.slice(6));
		else if (a.id.startsWith("deck:")) {
			let e = a.id.slice(5);
			n = e === "civilised" ? 3.2 : e === "uncivilised" ? 2.9 : 2.5;
		} else n = 2.3;
		t.mode === "exile" ? n = -n : t.mode === "break" && (n += .9), n > i && (r = a, i = n);
	}
	return t.optional && i < .15 ? { type: "decide" } : {
		type: "decide",
		market: r.id
	};
}
function _r(e, t) {
	let n = [...new Set(e.candidates)];
	if (!n.length) return {
		type: "decide",
		cards: []
	};
	let r = t.to, i = t.n, a = t.min ?? (t.optional ? 0 : i), o = n.slice().sort((e, t) => $(t) - $(e));
	if (r === "unrest") {
		let e = o.filter((e) => b[e]?.s.includes("unrest")).slice(0, Math.min(i, n.length));
		return {
			type: "decide",
			cards: e.length >= a ? e : []
		};
	}
	if (r === "exile") {
		let e = o.filter((e) => b[e]?.s.includes("unrest")).slice(0, i);
		return e.length ? {
			type: "decide",
			cards: e
		} : {
			type: "decide",
			cards: []
		};
	}
	if (r === "hand" || r === "play" || r === "garrison" || r === "garrisonHere" || r === "history" || r === "flooded" || r === "deckBottom") {
		if (i === 0) return {
			type: "decide",
			cards: []
		};
		let e = Math.min(i, n.length);
		return t.optional && a === 0 && $(o[0]) <= 0 ? {
			type: "decide",
			cards: []
		} : {
			type: "decide",
			cards: o.slice(0, Math.max(a, e))
		};
	}
	let s = o.slice().reverse(), c = Math.min(Math.max(a, 0), n.length);
	return {
		type: "decide",
		cards: s.slice(0, c)
	};
}
function vr(e, t, n) {
	if (n.kind === "option") return hr(e, n);
	if (n.kind === "market") return gr(e, n);
	if (n.kind === "cards") return _r(t, n);
	if (n.kind === "confirm") {
		let t = n.source ?? "";
		return n.optional && t.includes("garrisonImpendingQuest") ? {
			type: "decide",
			confirm: e.unrestCount > 1
		} : {
			type: "decide",
			confirm: !0
		};
	}
	return {
		type: "decide",
		confirm: !0
	};
}
function yr(e) {
	let t = le(e), n = fr(t.play);
	t.free && (n += .3);
	let r = b[e];
	return r?.hdr === "pin" && (n += Math.max(0, r.vp ?? 0) * .5), n;
}
function br(e, t) {
	let n = t.hand;
	if (!n.length) return "innovate";
	let r = n.filter((e) => b[e]?.s.includes("unrest")).length, i = n.filter((t) => {
		let n = b[t];
		return n && (!n.st || n.st === e.side);
	}), a = i.filter((e) => yr(e) > .4).length;
	return r >= 2 && a <= 1 ? "revolt" : !i.length || a === 0 ? "innovate" : "activate";
}
function xr(e, t, n) {
	let r = e.players[n].actions, i = t.exhaustable.map((e) => ({
		id: e,
		score: fr(le(e).exhaust) - .4
	})).filter((e) => e.score > .25).sort((e, t) => t.score - e.score);
	if (i.length) return {
		type: "exhaust",
		card: i[0].id
	};
	let a = /* @__PURE__ */ new Set(), o = 0, s = !1;
	for (let t = e.log.length - 1; t >= 0; t--) {
		let r = e.log[t];
		if (r.key === "log.turnStart" && r.rid === n) {
			s = !0;
			break;
		}
		r.rid === n && r.card && (r.key === "log.play" || r.key === "log.freePlay") && (a.add(r.card), r.key === "log.freePlay" && o++);
	}
	let c = s && o < 10, l = t.playable.filter((e) => le(e).free ? c && !a.has(e) : r > 0).map((e) => ({
		id: e,
		score: yr(e)
	})).filter((e) => e.score > .3).sort((e, t) => t.score - e.score);
	return l.length ? {
		type: "play",
		card: l[0].id
	} : { type: "endTurn" };
}
var Sr = (e, t) => {
	let n = e.public, r = e.private, i = n.players[t.rid];
	return !i || !r || n.phase === "done" ? null : n.decision ? n.decision.owner === t.rid ? { action: vr(n, r, n.decision) } : null : n.actor === t.rid ? n.phase === "start" ? { action: {
		type: "mode",
		mode: br(i, r)
	} } : n.phase === "activate" ? { action: xr(n, r, t.rid) } : null : null;
};
//#endregion
//#region src/game/game-over.tsx
function Cr(e) {
	let s = a(), c = i((e) => e.locale), l = e.public, [d, _] = r(!0), [v, y] = r(null), b = n(null), x = n(null), S = n(null);
	t(() => {
		if (!v) return;
		S.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => y(null), 5e3);
		return () => clearTimeout(e);
	}, [v]);
	let C = (e) => {
		y(null), _(e), requestAnimationFrame(() => (e ? b : x).current?.focus({ preventScroll: !0 }));
	}, w = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? u(n, c) : t;
	}, T = (e) => {
		let t = D[l.players[e]?.nationId];
		return t ? c === "zh" ? t.zh : t.en : "";
	}, E = (e) => {
		let t = l.players[e];
		return t ? t.handCount + t.play.length + t.deckCount + t.discardCount + t.historyCount + t.floodedCount : 0;
	}, ee = (t) => e.result.scores?.[t] ?? l.scored?.[t] ?? 0, te = e.result.winner.map(w).join(" · "), ne = !!e.onPlayAgain || !!e.onBackToLobby;
	return /* @__PURE__ */ p("div", {
		className: "ic-over",
		children: [
			/* @__PURE__ */ f("div", {
				className: "ic-over__board",
				inert: d,
				children: /* @__PURE__ */ f($n, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			d && /* @__PURE__ */ f("div", {
				className: "ic-over__shade",
				children: /* @__PURE__ */ p("section", {
					className: "ic-over__panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": s(l.collapse ? "games.imperiumclassics.ui.collapseTitle" : "games.imperiumclassics.ui.endTitle"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), C(!1));
					},
					children: [
						/* @__PURE__ */ p("header", {
							className: "ic-over__head",
							children: [/* @__PURE__ */ p("span", {
								className: "ic-over__brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: jn.icon
								}), s(jn.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: b,
								className: "ic-over__close",
								"aria-label": s("games.imperiumclassics.over.viewBoard"),
								title: s("games.imperiumclassics.over.viewBoard"),
								onClick: () => C(!1),
								children: /* @__PURE__ */ f(h, { size: 18 })
							})]
						}),
						/* @__PURE__ */ f("h1", { children: s(l.collapse ? "games.imperiumclassics.ui.collapseTitle" : "games.imperiumclassics.ui.endTitle") }),
						l.collapse && /* @__PURE__ */ f("p", {
							className: "ic-over__note",
							children: s("games.imperiumclassics.over.collapseNote")
						}),
						/* @__PURE__ */ f("p", {
							className: "ic-over__winner",
							children: s(e.result.winner.length > 1 ? "games.imperiumclassics.ui.winnerTie" : "games.imperiumclassics.ui.winnerText", { name: te })
						}),
						e.hintCount !== void 0 && /* @__PURE__ */ f("p", {
							className: "ic-over__hint",
							children: s("session.hint.usedCount", { n: e.hintCount })
						}),
						/* @__PURE__ */ f("ol", {
							className: "ic-over__list",
							"aria-label": s("games.imperiumclassics.ui.scoreTitle"),
							children: e.result.ranking.map((t, n) => {
								let r = e.members.find((e) => e.rid === t), i = o[(r?.colorIndex ?? 0) % o.length], a = e.result.autopilot?.[t] ?? 0;
								return /* @__PURE__ */ p("li", {
									className: e.result.winner.includes(t) ? "is-winner" : "",
									children: [
										/* @__PURE__ */ f("span", {
											className: "ic-over__rank",
											children: n + 1
										}),
										/* @__PURE__ */ f("span", {
											className: "ic-over__avatar",
											style: { backgroundColor: i.hex },
											children: r && /* @__PURE__ */ f("img", {
												src: m[r.avatar % m.length],
												alt: "",
												draggable: !1
											})
										}),
										/* @__PURE__ */ p("span", {
											className: "ic-over__who",
											children: [/* @__PURE__ */ p("b", { children: [
												e.result.winner.includes(t) && /* @__PURE__ */ f("span", {
													"aria-hidden": "true",
													children: "♛ "
												}),
												w(t),
												t === e.myRid && /* @__PURE__ */ f("small", { children: s("lobby.you") }),
												a > 0 && /* @__PURE__ */ f("small", { children: s("session.autopilot.share", { n: Math.round(a * 100) }) })
											] }), /* @__PURE__ */ p("span", { children: [T(t), l.collapse ? ` · ${s("games.imperiumclassics.over.cards", { n: E(t) })}` : ` · ${s("games.imperiumclassics.over.progress", { n: l.players[t]?.res.pr ?? 0 })} · ${s("games.imperiumclassics.over.cards", { n: E(t) })}`] })]
										}),
										/* @__PURE__ */ f("b", {
											className: "ic-over__score",
											children: ee(t)
										})
									]
								}, t);
							})
						}),
						ne ? /* @__PURE__ */ p("div", {
							className: "ic-over__actions",
							inert: v !== null,
							children: [e.onPlayAgain && /* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn ic-btn--primary",
								onClick: () => y("again"),
								children: s("session.result.playAgain")
							}), e.onBackToLobby && /* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn",
								onClick: () => y("lobby"),
								children: s("session.result.backToLobby")
							})]
						}) : /* @__PURE__ */ f("p", {
							className: "ic-over__wait",
							children: s("session.result.waitHost")
						}),
						v && /* @__PURE__ */ p("div", {
							className: "ic-over__confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || y(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: S,
								className: "ic-btn ic-btn--danger",
								onClick: () => {
									let t = v === "again" ? e.onPlayAgain : e.onBackToLobby;
									y(null), t?.();
								},
								children: s(v === "again" ? "games.imperiumclassics.over.confirmAgain" : "games.imperiumclassics.over.confirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "ic-btn",
								onClick: () => {
									y(null), b.current?.focus({ preventScroll: !0 });
								},
								children: s("games.imperiumclassics.over.cancel")
							})]
						})
					]
				})
			}),
			!d && /* @__PURE__ */ f("div", {
				className: "ic-over__restore",
				children: /* @__PURE__ */ p("button", {
					type: "button",
					ref: x,
					className: "ic-btn ic-btn--primary",
					onClick: () => C(!0),
					children: [/* @__PURE__ */ f(g, { size: 16 }), s("games.imperiumclassics.over.showResult")]
				})
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
var wr = 4;
function Tr({ value: e, onChange: t }) {
	let n = a(), r = i((e) => e.locale), o = Pn.safeParse(e), s = o.success ? o.data : Pn.parse(void 0), c = Array.from({ length: wr }, (e, t) => s.nations[t] ?? ""), l = (e, n) => {
		let r = c.slice();
		for (r[e] = n; r.length && !r[r.length - 1];) r.pop();
		t({
			...s,
			nations: r
		});
	}, u = (e) => {
		let t = D[e];
		return r === "zh" ? t.zh : t.en;
	};
	return /* @__PURE__ */ p("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ f(v, {
				title: n("games.imperiumclassics.opt.box"),
				columns: 2,
				children: ["c", "l"].map((e) => /* @__PURE__ */ f(_, {
					name: "ic-box",
					value: e,
					checked: s.commons === e,
					label: n(e === "c" ? "games.imperiumclassics.opt.boxClassics" : "games.imperiumclassics.opt.boxLegends"),
					onChange: () => t({
						...s,
						commons: e
					})
				}, e))
			}),
			/* @__PURE__ */ f("p", {
				className: "text-xs text-ink/65",
				children: n("games.imperiumclassics.opt.boxHint")
			}),
			/* @__PURE__ */ f(v, {
				title: n("games.imperiumclassics.opt.powerSide"),
				columns: 2,
				children: ["b", "a"].map((e) => /* @__PURE__ */ f(_, {
					name: "ic-power",
					value: e,
					checked: s.powerSide === e,
					label: n(e === "b" ? "games.imperiumclassics.opt.powerB" : "games.imperiumclassics.opt.powerA"),
					onChange: () => t({
						...s,
						powerSide: e
					})
				}, e))
			}),
			/* @__PURE__ */ f("p", {
				className: "text-xs text-ink/65",
				children: n("games.imperiumclassics.opt.powerHint")
			}),
			/* @__PURE__ */ f(v, {
				title: n("games.imperiumclassics.opt.nation"),
				columns: 2,
				children: Array.from({ length: wr }, (e, t) => /* @__PURE__ */ p("label", {
					className: "grid gap-1 text-sm",
					children: [/* @__PURE__ */ f("span", {
						className: "font-bold",
						children: n("games.imperiumclassics.opt.seat", { n: t + 1 })
					}), /* @__PURE__ */ p("select", {
						className: "w-full rounded border-2 border-ink/30 bg-surface p-2",
						value: c[t],
						onChange: (e) => l(t, e.target.value),
						children: [
							/* @__PURE__ */ f("option", {
								value: "",
								children: n("games.imperiumclassics.opt.random")
							}),
							/* @__PURE__ */ f("optgroup", {
								label: n("games.imperiumclassics.opt.boxClassics"),
								children: x.slice(0, 8).map((e) => /* @__PURE__ */ f("option", {
									value: e,
									children: u(e)
								}, e))
							}),
							/* @__PURE__ */ f("optgroup", {
								label: n("games.imperiumclassics.opt.boxLegends"),
								children: x.slice(8).map((e) => /* @__PURE__ */ f("option", {
									value: e,
									children: u(e)
								}, e))
							})
						]
					})]
				}, t))
			}),
			/* @__PURE__ */ f("p", {
				className: "text-xs text-ink/65",
				children: n("games.imperiumclassics.opt.nationHint")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var Er = {
	definition: Kn,
	View: $n,
	bot: Sr,
	OverView: Cr,
	Options: Tr,
	locales: {
		zh: {
			name: "帝国：经典与传奇",
			desc: "带领一个文明从蛮荒走向帝国，构筑牌组、扩张领土，在终局赢得最高胜利点",
			rules: "目标:\n每位玩家领导一个文明，从蛮荒时代起步，通过建设、扩张与科技进步走向帝国时代。游戏结束时，拥有最多胜利点的玩家获胜。\n准备:\n· 为每名玩家选择一个文明，并取出该文明的全部卡牌。每名玩家取得自己的势力卡、发展区、国家牌堆与动乱牌；亚瑟王与乌托邦另有附加卡。\n· 每名玩家获得3个材料、2个人口、1个进度、5个消耗标记与3个行动标记。乌托邦玩家只获得3个消耗标记。行动标记与消耗标记放在状态卡上。\n· 状态卡以蛮族面朝上；亚特兰蒂斯以帝国面朝上。\n· 将公共牌按花色分类。使用所选盒（经典或传奇）的公共牌；与出场文明同名的公共牌，用另一盒中同花色的牌替换。\n· 按人数移除公共牌中人数需求高于当前人数的牌。将名声牌洗匀后叠放在众王之王牌上组成名声牌堆；三人局移除牌堆顶1张，两人局移除2张。\n· 从公共牌中取出区域、未开化、文明三类，分别组成6张（两人局）、7张（三人局）或8张（四人局）的专门牌堆；其余牌与附属牌组成主牌堆。\n· 将动乱牌集中为动乱牌堆，包含公共动乱牌与出场文明的动乱牌。\n· 在市场上放置5张牌：区域、未开化、文明各1张，主牌堆2张。在每张区域、未开化或文明牌下压1张动乱牌；在每张没有区域图标的牌上放1个进度。\n· 将众王之王牌以A面朝上放在名声牌堆旁；随机放置节气牌，节气牌左侧的玩家为起始玩家。\n· 每名玩家从自己的牌堆抽5张牌作为起始手牌。\n回合:\n每回合依次进行：选择一种行动方式（启动、革新或反抗）并结算，然后进入清理阶段。所有玩家完成回合后，由左侧玩家继续。当节气牌右侧的玩家完成回合时，本轮结束，所有玩家先结算各自场面与势力卡上的节气能力，再开始新一轮。\n启动:\n· 玩家可以使用行动与消耗能力，顺序与次数不限，直到不愿或不能再进行。\n· 使用行动时，从状态卡移除1个行动标记，从手牌打出1张牌并结算其效果。除驻留牌外，打出的牌在结算后进入弃牌堆。\n· 若牌面标有蛮族或帝国图标，只有状态卡显示相同图标时才能打出。\n· 使用消耗能力时，将1个消耗标记放到一张未横置的、位于场面或势力卡上的牌上，然后结算该能力。同一张牌一回合只能消耗一次，且只能在启动方式中使用。\n· 若消耗能力要求支付费用而资源不足，则不能使用该能力。\n革新:\n· 先将手牌全部放入弃牌堆，然后从区域、未开化或文明中突破获得1张牌，最后进入清理阶段。\n· 革新时不能使用行动或消耗能力。\n反抗:\n· 将任意张手牌放回动乱牌堆，然后进入清理阶段。\n· 反抗时不能使用行动或消耗能力。\n市场与购得:\n· 购得时，从市场选择1张符合花色的牌加入手牌，不支付费用。取得该牌上放置的材料、人口与进度标记；若该牌下压着动乱牌，动乱牌也加入手牌。\n· 购得市场牌后，从对应专门牌堆补充1张；专门牌堆用尽时从主牌堆补充。若补充的是区域、未开化或文明牌，则从其下压1张动乱牌。\n· 突破时，从市场选择1张声明花色的牌，或从对应专门牌堆顶取1张牌。若专门牌堆为空，则从主牌堆逐张翻开，直到找到该花色的牌，其余翻开的牌洗回主牌堆；找不到时改为获得2个材料。\n· 通过突破获得市场牌时，牌下压着的动乱牌返回动乱牌堆，不加入手牌。\n发展:\n· 支付发展牌上标示的费用，将发展区中的该牌放入弃牌堆。若发展区没有放置行动标记，每回合也可以支付费用发展1张。\n· 亚瑟王的任务牌在发展区时视为待完成任务。亚特兰蒂斯与乌托邦没有发展区。\n驻留与历史:\n· 驻留牌在结算后留在场面，不进入弃牌堆。\n· 进驻的牌放在驻留牌下方，视为被进驻；被进驻的牌不属于场面，不能被打出、弃置或使用其能力，但终局仍然计分。\n· 放入历史的牌放在势力卡下方并离开游戏区域，通常不能再次使用，但终局仍然计分。维京没有历史，放入历史的牌改为放入弃牌堆。\n· 亚特兰蒂斯以淹没区代替历史：沉没或放入历史的牌放在势力卡下方并离开游戏区域，通常不能互动，但终局仍然计分。淹没区不视为历史，以“在历史中”为条件的牌或能力不使用淹没牌，淹没牌也不满足要求历史牌的条件。\n清理:\n· 在市场中任意1张牌上放置1个进度。迦太基改为放置1个或2个材料，秦改为放置1个人口。\n· 移除状态卡、场面牌、国家牌堆、发展区与势力卡上的全部行动标记与消耗标记，然后重新放置3个行动标记与5个消耗标记；乌托邦只重新放置3个消耗标记。\n· 可以弃置任意张手牌。\n· 从牌堆抽牌，直到手牌达到5张；手牌已达到或超过5张时不抽牌。\n重洗牌堆与成为帝国:\n· 牌堆为空且需要抽牌时，先检查状态卡。若状态卡为蛮族，且国家牌堆没有行动标记、状态卡上至少有一个行动标记：将国家牌堆顶牌放入弃牌堆，并把状态卡上的1个行动标记移到国家牌堆。若放入的是登基牌，则将状态卡翻为帝国面。\n· 亚特兰蒂斯不以蛮族开始；维京与亚瑟王永不翻面；乌托邦没有国家牌堆。\n· 若状态卡为帝国，且发展区没有行动标记、状态卡上至少有一个行动标记：可以支付1张发展牌的费用并将其放入弃牌堆，视为发展该牌，然后把1个行动标记移到发展区。\n· 将弃牌堆洗匀作为新牌堆，然后继续抽牌。\n节气:\n· 每轮结束时，所有玩家结算场面与势力卡上的节气能力，顺序自选；能结算的部分必须尽量结算，除非牌面写明可选。\n· 乌托邦的旅程卡视为额外的势力卡，其节气能力用于推进旅程。\n终局:\n满足以下任一条件时触发终局：\n· 主牌堆没有牌。\n· 某位玩家发展了发展区中的最后一张牌（亚瑟王的任务牌除外）。\n· 众王之王翻面。\n· 维京将哈拉尔·哈德拉达放入弃牌堆。\n· 亚瑟王打出圣杯。\n· 乌托邦在香格里拉旅程卡上触发节气能力且拥有至少24个进度。\n· 触发终局后，完成当前轮，再进行最后一轮，并在该轮结束时结算节气能力。\n· 动乱牌堆没有牌时立即触发崩溃，游戏在当前行动尚未结算完毕时结束。崩溃时，手牌、场面、牌堆、弃牌堆与历史（或淹没区）中牌数最少的玩家获胜；并列时比较胜利点。\n计分:\n· 每个进度标记计1分。\n· 手牌、场面、抽牌堆、弃牌堆、历史（或淹没区）中的每张牌，以及势力卡，均按牌面标示计分；国家牌堆与发展区中的牌不计分。\n· 固定胜利点直接计入。\n· 条件胜利点在满足条件时计入。\n· 可变胜利点按牌面说明计算，每张牌最多计10分。\n· 分数最高者获胜，并列的玩家共享胜利。",
			log: {
				gameStart: "对局开始。",
				turnStart: "轮到 {{name}}。",
				turnEnd: "{{name}} 结束了行动。",
				modeActivate: "{{name}} 选择启动。",
				modeInnovate: "{{name}} 选择革新。",
				modeRevolt: "{{name}} 选择反抗。",
				play: "{{name}} 打出 {{card}}。",
				exhaust: "{{name}} 消耗 {{card}}。",
				draw: "{{name}} 抽了1张牌。",
				acquire: "{{name}} 购得 {{card}}。",
				breakThrough: "{{name}} 突破获得 {{card}}。",
				breakFail: "{{name}} 未找到目标花色的牌，改为获得2个材料。",
				develop: "{{name}} 发展了 {{card}}。",
				garrison: "{{name}} 进驻了 {{card}}。",
				abandon: "{{name}} 舍弃了 {{card}}。",
				recall: "{{name}} 召回了 {{card}}。",
				sink: "{{name}} 沉没了 {{card}}。",
				history: "{{name}} 将 {{card}} 放入历史。",
				exile: "{{name}} 放逐了 {{card}}。",
				fame: "{{name}} 获得名声牌 {{card}}。",
				kok: "{{name}} 结算了众王之王 {{card}}。",
				peek: "{{name}} 查看了 {{n}} 张牌。",
				find: "{{name}} 从牌堆中找到1张牌。",
				give: "{{name}} 将1张牌交给了另一名玩家。",
				steal: "{{name}} 从 {{target}} 处夺取了 {{n}} 个资源。",
				gainToken: "{{name}} 取得 {{card}} 上的 {{n}} 个资源标记。",
				marketToken: "市场中的 {{card}} 获得 {{n}} 个资源标记。",
				cardToken: "{{name}} 在 {{card}} 上放置了 {{n}} 个进度标记。",
				quest: "{{name}} 的任务 {{card}} 生效。",
				accession: "{{name}} 触发登基：{{card}}。",
				nadir: "{{name}} 的最低点牌 {{card}} 进入场面。",
				flip: "{{name}} 将状态卡翻为帝国面。",
				flipCard: "{{name}} 翻面了 {{card}}。",
				endTriggered: "终局条件已触发，完成本轮后再进行最后一轮。",
				gameEnd: "游戏结束。",
				collapse: "动乱牌堆耗尽，游戏立即结束。",
				solstice: "结算节气。",
				cannotPay: "{{name}} 无法支付费用。",
				noAcquire: "{{name}} 没有可购得的牌。",
				noDevelop: "{{name}} 没有可发展的牌。",
				swap: "{{name}} 交换了牌。",
				takeUnrest: "{{name}} 取得了动乱牌 {{card}}。",
				returnUnrest: "{{name}} 将 {{card}} 放回动乱牌堆。",
				freePlay: "{{name}} 免费打出 {{card}}。",
				gambleHit: "{{name}} 猜中花色，获得 {{card}}。",
				gambleMiss: "{{name}} 猜错花色，{{card}} 被放逐。"
			},
			opt: {
				box: "公共牌盒",
				boxClassics: "经典",
				boxLegends: "传奇",
				boxHint: "两个牌盒的文明都可以使用；公共牌取自所选牌盒，与出场文明同名的牌用另一盒替换。",
				powerSide: "势力卡面",
				powerA: "A 面",
				powerB: "B 面",
				powerHint: "势力卡选定一面后本局不再翻面；初次接触推荐使用 B 面。",
				nation: "文明",
				seat: "第 {{n}} 席",
				random: "随机",
				nationHint: "按席位顺序分配文明，随机席位由其余文明补齐。"
			},
			ui: {
				round: "第 {{n}} 轮",
				yourTurn: "轮到你行动。",
				waitTurn: "等待 {{name}} 行动。",
				yourDecision: "作出选择。",
				waitDecision: "等待 {{name}} 作出选择。",
				startPrompt: "选择本回合的行动方式。",
				activatePrompt: "打出手牌或消耗场面上的牌；完成后结束回合。",
				solsticePrompt: "正在结算节气能力。",
				btnActivate: "启动",
				btnInnovate: "革新",
				btnRevolt: "反抗",
				endTurn: "结束回合",
				confirm: "确认",
				skip: "跳过",
				cancel: "取消",
				close: "关闭",
				play: "打出",
				exhaust: "消耗",
				exhaustDone: "已消耗",
				freePlay: "免费打出",
				material: "材料",
				population: "人口",
				progress: "进度",
				actionsLeft: "行动 {{n}}",
				exhaustLeft: "消耗 {{n}}",
				hand: "手牌",
				playArea: "场面",
				devArea: "发展区",
				nation: "国家牌堆",
				deck: "牌堆",
				discard: "弃牌堆",
				history: "历史",
				flooded: "淹没区",
				garrison: "进驻",
				power: "势力卡",
				market: "市场",
				regionDeck: "区域牌堆",
				uncivilisedDeck: "未开化牌堆",
				civilisedDeck: "文明牌堆",
				mainDeck: "主牌堆",
				fameDeck: "名声牌堆",
				unrestPile: "动乱牌堆",
				exile: "放逐区",
				sideBarbarian: "蛮族",
				sideEmpire: "帝国",
				vp: "胜利点",
				variableVp: "可变胜利点",
				devCost: "发展费用",
				handCount: "{{n}} 张",
				deckCount: "{{n}} 张",
				yourNation: "你的文明",
				emptyZone: "暂无牌",
				lookedTitle: "查看中的牌",
				logTitle: "行动记录",
				pickCards: "选择 {{n}} 张牌（{{zone}}）",
				pickCardsRange: "选择 {{min}} 至 {{n}} 张牌（{{zone}}）",
				pickCardsUpTo: "至多选择 {{n}} 张牌（{{zone}}）",
				selectedCount: "已选 {{n}} / {{total}}",
				pickMarketBreak: "选择突破来源",
				pickMarketAcquire: "选择要购得的牌",
				pickMarketExile: "选择要放逐的市场牌",
				pickMarketToken: "选择要放置{{res}}的市场牌",
				pickSuit: "选择要突破的花色",
				pickOption: "选择一项",
				confirmPrompt: "是否执行？",
				drawFromDeck: "从{{deck}}取1张",
				searchMainDeck: "从主牌堆检索",
				pickDevelop: "选择要发展的牌",
				pickFreePlay: "选择要免费打出的牌",
				pickFromZone: "选择一张牌",
				endTitle: "对局结束",
				collapseTitle: "动乱耗尽，对局立即结束",
				scoreTitle: "计分",
				winnerText: "{{name}} 获胜",
				winnerTie: "{{name}} 并列获胜",
				endTriggered: "终局条件已触发，完成本轮后再进行最后一轮。",
				awaitingOthers: "等待其他玩家完成本轮。"
			},
			over: {
				collapseNote: "动乱牌堆耗尽，按手牌、场面、牌堆、弃牌与历史（或淹没区）中的总牌数判定，牌数最少的玩家获胜。",
				progress: "进度 {{n}}",
				cards: "牌数 {{n}}",
				viewBoard: "查看盘面",
				showResult: "显示结算",
				confirmAgain: "确认重新开局",
				confirmLobby: "确认返回大厅",
				cancel: "取消"
			},
			tok: {
				material: "材料",
				population: "人口",
				progress: "进度",
				region: "区域",
				uncivilised: "未开化",
				civilised: "文明",
				tributary: "附属",
				fame: "名声",
				unrest: "动乱",
				production: "生产",
				fertile: "肥沃",
				river: "河流",
				ocean: "海洋",
				city: "城市",
				metropolis: "大都会",
				knight: "骑士",
				scroll: "卷轴",
				mask: "面具",
				hunt: "狩猎",
				miracle: "奇迹",
				merchant: "商人",
				barbarian: "蛮族",
				empire: "帝国",
				attack: "攻击",
				pinned: "驻留",
				exhaust: "消耗",
				development: "发展",
				variable: "可变"
			},
			suitName: {
				region: "区域",
				uncivilised: "未开化",
				civilised: "文明",
				tributary: "附属",
				fame: "名声",
				unrest: "动乱",
				power: "势力"
			},
			typeName: {
				production: "生产",
				fertile: "肥沃",
				river: "河流",
				ocean: "海洋",
				city: "城市",
				metropolis: "大都会",
				knight: "骑士",
				scroll: "卷轴",
				mask: "面具",
				hunt: "狩猎",
				miracle: "奇迹",
				merchant: "商人"
			},
			optLabel: {
				abandon: "舍弃",
				acquire: "购得",
				break: "突破",
				develop: "发展",
				discard: "弃置",
				draw: "抽牌",
				exile: "放逐",
				fertile: "肥沃牌",
				flip: "翻面",
				history: "历史",
				material: "材料",
				pay: "支付",
				population: "人口",
				progress: "进度",
				recall: "召回",
				replace: "替换",
				return: "返还",
				river: "河流牌",
				sink: "沉没",
				top: "牌堆顶",
				tributary: "附属牌",
				unrest: "动乱"
			},
			zoneName: {
				hand: "手牌",
				discard: "弃牌堆",
				handOrDiscard: "手牌或弃牌堆",
				play: "场面",
				dev: "发展区",
				market: "市场",
				deckTop: "牌堆顶",
				nationTop: "国家牌堆顶",
				history: "历史",
				flooded: "淹没区",
				garrison: "进驻区",
				unrest: "动乱牌堆",
				deckBottom: "牌堆底",
				garrisonHere: "本牌下方",
				exile: "放逐区",
				supply: "供应区"
			},
			err: {
				alreadyExhausted: "这张牌本回合已经消耗过。",
				awaitDecision: "请先完成当前选择。",
				badChoice: "这个选择无效。",
				badPhase: "当前阶段不能进行这个操作。",
				cannotPay: "资源不足，无法支付费用。",
				cannotPlay: "这张牌现在不能打出。",
				gameOver: "对局已经结束。",
				noAction: "没有剩余的行动。",
				noDecision: "当前没有需要作出的选择。",
				noExhaust: "没有剩余的消耗标记。",
				noExhaustAbility: "这张牌没有消耗能力。",
				notInHand: "这张牌不在手牌中。",
				notInPlay: "这张牌不在场面中。",
				notPlayer: "你不是本局玩家。",
				notYourDecision: "这不是你需要作出的选择。",
				notYourTurn: "现在轮不到你。",
				tooFew: "选择的牌太少。",
				tooMany: "选择的牌太多。"
			}
		},
		en: {
			name: "Imperium: Classics & Legends",
			desc: "Lead a civilization from barbarism to empire, building its deck and territory to score the most victory points",
			rules: "Goal:\nEach player leads one civilization. Starting as a barbarian people, you build, expand, and advance until you become an empire. When the game ends, the player with the most victory points wins.\nSetup:\n· Each player chooses one civilization and takes all of its cards: its power card, development area, nation deck, and unrest cards. The Arthurians and Utopians also take their additional cards.\n· Each player takes 3 material, 2 population, 1 progress, 5 exhaustion tokens, and 3 action tokens. A Utopian player takes only 3 exhaustion tokens. Place the action and exhaustion tokens on your state card.\n· The state card starts on its barbarian side; the Atlanteans start on their empire side.\n· Sort the commons cards by suit. Use the commons from the chosen box (Classics or Legends). Replace each commons card that shares a name with a chosen nation with a card of the same suit from the other box.\n· Remove commons cards whose player count is higher than the number of players. Shuffle the fame cards and stack them on the King of Kings card to form the fame deck; in a three-player game remove the top 1 card, and in a two-player game remove the top 2.\n· Take the region, uncivilised, and civilised cards from the commons and form three specialty decks of 6 cards (two players), 7 cards (three players), or 8 cards (four players). The remaining cards and the tributary cards form the main deck.\n· Gather all unrest cards, both the common unrest and the unrest belonging to the chosen civilizations, into the unrest pile.\n· Place 5 cards in the market: one region, one uncivilised, one civilised, and two from the main deck. Tuck one unrest card underneath each region, uncivilised, and civilised card in the market; place 1 progress on each market card without a region icon.\n· Place the King of Kings card face up with its A side up beside the fame deck, and place the solstice card at random. The player to the left of the solstice card starts the game.\n· Each player draws 5 cards from their draw deck as a starting hand.\nTurn:\nOn your turn, choose one way to act (activate, innovate, or revolt), resolve it, and then clean up. After every player has taken a turn, play passes to the left. When the player to the right of the solstice card finishes their turn, the round ends: every player first resolves the solstice abilities in their play area and on their power card, and then the next round begins.\nActivate:\n· You may take actions and use exhaust abilities in any order and in any number until you no longer can or want to.\n· To take an action, remove 1 action token from your state card, play 1 card from your hand, and resolve its effect. Unless the card is pinned, place it in your discard pile after resolving it.\n· A card showing a barbarian or empire icon may only be played while your state card shows the same icon.\n· To use an exhaust ability, place 1 exhaustion token on an unexhausted card in your play area or on your power card, then resolve that ability. Each card may be exhausted only once per turn, and only while you activate.\n· If an exhaust ability has a cost you cannot pay, you cannot use that ability.\nInnovate:\n· First place all cards in your hand into your discard pile, then break through for a region, uncivilised, or civilised card, and finally clean up.\n· You cannot take actions or use exhaust abilities while you innovate.\nRevolt:\n· Return any number of cards from your hand to the unrest pile, then clean up.\n· You cannot take actions or use exhaust abilities while you revolt.\nMarket and acquiring:\n· To acquire, choose 1 card of the indicated suit from the market and add it to your hand without paying a cost. Gain any material, population, and progress tokens on that card; if an unrest card is underneath it, add that unrest card to your hand as well.\n· After a market card is taken, draw a replacement from the matching specialty deck, or from the main deck when that specialty deck is empty. If the replacement is a region, uncivilised, or civilised card, tuck 1 unrest card underneath it.\n· To break through, either choose 1 card of the declared suit from the market or take the top card of the matching specialty deck. If that specialty deck is empty, reveal cards from the top of the main deck one by one until you find a card of the declared suit and shuffle all other revealed cards back into the main deck; if you find none, gain 2 material instead.\n· When you break through for a market card, return any unrest underneath it to the unrest pile instead of taking it.\nDevelop:\n· Pay the development cost shown on a development card to place it from your development area into your discard pile. If there is no action token in your development area, you may also develop 1 card this way once per turn.\n· Arthurian quest cards in the development area are impending quests. The Atlanteans and Utopians have no development area.\nGarrison and history:\n· Pinned cards stay in your play area after resolving instead of going to your discard pile.\n· A garrisoned card is placed underneath a pinning card and is not considered to be in your play area. It cannot be played, discarded, or used for its abilities, but it still scores at the end of the game.\n· Cards placed in your history go underneath your power card and leave play. They normally cannot be used again, but they still score at the end of the game. The Vikings have no history; cards that would enter their history go to their discard pile instead.\n· The Atlanteans use a flooded pile instead of history: sunk cards and cards that would enter history go underneath their power card and leave play. Flooded cards normally cannot be interacted with, but they still score at the end of the game. A flooded pile is not a history: cards and abilities that check for cards in your history do not use flooded cards, and flooded cards do not satisfy requirements for cards in your history.\nClean up:\n· Place 1 progress on any 1 card in the market. The Carthaginians place 1 or 2 material instead, and the Qin place 1 population.\n· Remove all action and exhaustion tokens from your state card, your play area, your nation deck, your development area, and your power card, then place 3 action tokens and 5 exhaustion tokens back on your state card; the Utopians place only 3 exhaustion tokens.\n· You may discard any number of cards from your hand.\n· Draw cards up to a hand size of 5; if you already hold 5 or more cards, draw none.\nReshuffling and becoming an empire:\n· When you need to draw and your draw deck is empty, first check your state card. If it shows barbarian and there is no action token on your nation deck while at least one action token is on your state card, place the top card of your nation deck into your discard pile and move 1 action token from your state card to your nation deck. If that card is the accession card, flip your state card to its empire side.\n· The Atlanteans do not start as barbarians; the Vikings and Arthurians never flip their state card; the Utopians have no nation deck.\n· If your state card shows empire and there is no action token in your development area while at least one action token is on your state card, you may pay the development cost of 1 development card to place it into your discard pile as a development, then move 1 action token from your state card to your development area.\n· Shuffle your discard pile into a new draw deck, then continue drawing.\nSolstice:\n· At the end of each round, every player resolves the solstice abilities in their play area and on their power card in any order they choose. Resolve as much of each ability as possible unless the card says it is optional.\n· The Utopian journey card counts as an additional power card, and its solstice ability advances the journey.\nGame end:\nThe game ends when any of these conditions is met:\n· The main deck has no cards left.\n· A player develops the last card in their development area (Arthurian quest cards excluded).\n· The King of Kings card is flipped face down.\n· The Vikings place Harald Hardrada into their discard pile.\n· The Arthurians play the Graal.\n· The Utopians trigger the solstice ability on their Shangri-La journey card while having at least 24 progress.\n· After the game end is triggered, finish the current round, play one final round, and resolve solstice abilities at the end of that round.\n· Collapse is triggered immediately when the unrest pile has no cards left, ending the game before the current action finishes resolving. On a collapse, the player with the fewest cards among hand, play area, deck, discard pile, and history (or flooded pile) wins; ties are broken by victory points.\nScoring:\n· Each progress token is worth 1 victory point.\n· Every card in your hand, play area, draw deck, discard pile, and history (or flooded pile), as well as your power card, scores what it shows; cards in your nation deck and development area do not score.\n· Fixed victory points are added directly.\n· Conditional victory points count when their condition is met.\n· Variable victory points follow the card text and are capped at 10 points per card.\n· The player with the most victory points wins, and tied players share the victory.",
			log: {
				gameStart: "The game begins.",
				turnStart: "{{name}} takes a turn.",
				turnEnd: "{{name}} ends their actions.",
				modeActivate: "{{name}} chooses to activate.",
				modeInnovate: "{{name}} chooses to innovate.",
				modeRevolt: "{{name}} chooses to revolt.",
				play: "{{name}} plays {{card}}.",
				exhaust: "{{name}} exhausts {{card}}.",
				draw: "{{name}} draws 1 card.",
				acquire: "{{name}} acquires {{card}}.",
				breakThrough: "{{name}} breaks through for {{card}}.",
				breakFail: "{{name}} finds no card of the declared suit and gains 2 material instead.",
				develop: "{{name}} develops {{card}}.",
				garrison: "{{name}} garrisons {{card}}.",
				abandon: "{{name}} abandons {{card}}.",
				recall: "{{name}} recalls {{card}}.",
				sink: "{{name}} sinks {{card}}.",
				history: "{{name}} puts {{card}} into history.",
				exile: "{{name}} exiles {{card}}.",
				fame: "{{name}} gains the fame card {{card}}.",
				kok: "{{name}} resolves the King of Kings {{card}}.",
				peek: "{{name}} looks at {{n}} cards.",
				find: "{{name}} finds 1 card in their deck.",
				give: "{{name}} gives 1 card to another player.",
				steal: "{{name}} steals {{n}} resources from {{target}}.",
				gainToken: "{{name}} gains {{n}} resource tokens from {{card}}.",
				marketToken: "{{card}} in the market gains {{n}} resource tokens.",
				cardToken: "{{name}} places {{n}} progress tokens on {{card}}.",
				quest: "{{name}} activates the quest {{card}}.",
				accession: "{{name}} triggers an accession: {{card}}.",
				nadir: "{{name}} places the nadir card {{card}} into play.",
				flip: "{{name}} flips their state card to its empire side.",
				flipCard: "{{name}} flips {{card}}.",
				endTriggered: "The game end has been triggered; finish this round and play one final round.",
				gameEnd: "The game ends.",
				collapse: "The unrest pile is empty and the game ends immediately.",
				solstice: "Resolve solstice abilities.",
				cannotPay: "{{name}} cannot pay the cost.",
				noAcquire: "{{name}} has no card to acquire.",
				noDevelop: "{{name}} has no card to develop.",
				swap: "{{name}} swaps cards.",
				takeUnrest: "{{name}} takes the unrest card {{card}}.",
				returnUnrest: "{{name}} returns {{card}} to the unrest pile.",
				freePlay: "{{name}} plays {{card}} for free.",
				gambleHit: "{{name}} guesses the suit correctly and gains {{card}}.",
				gambleMiss: "{{name}} guesses the suit incorrectly and {{card}} is exiled."
			},
			opt: {
				box: "Commons box",
				boxClassics: "Classics",
				boxLegends: "Legends",
				boxHint: "Nations from both boxes are available. Commons come from the chosen box; cards naming a chosen nation are replaced from the other box.",
				powerSide: "Power card side",
				powerA: "Side A",
				powerB: "Side B",
				powerHint: "The power card keeps this side for the whole game; side B is recommended for new players.",
				nation: "Nations",
				seat: "Seat {{n}}",
				random: "Random",
				nationHint: "Nations are assigned in seat order; random seats are filled from the remaining nations."
			},
			ui: {
				round: "Round {{n}}",
				yourTurn: "Your turn.",
				waitTurn: "Waiting for {{name}}.",
				yourDecision: "Make your choice.",
				waitDecision: "Waiting for {{name}} to choose.",
				startPrompt: "Choose how to act this turn.",
				activatePrompt: "Play cards or use exhaust abilities, then end your turn.",
				solsticePrompt: "Resolving solstice abilities.",
				btnActivate: "Activate",
				btnInnovate: "Innovate",
				btnRevolt: "Revolt",
				endTurn: "End turn",
				confirm: "Confirm",
				skip: "Skip",
				cancel: "Cancel",
				close: "Close",
				play: "Play",
				exhaust: "Exhaust",
				exhaustDone: "Exhausted",
				freePlay: "Free play",
				material: "Material",
				population: "Population",
				progress: "Progress",
				actionsLeft: "Actions {{n}}",
				exhaustLeft: "Exhaust {{n}}",
				hand: "Hand",
				playArea: "Play area",
				devArea: "Development area",
				nation: "Nation deck",
				deck: "Deck",
				discard: "Discard pile",
				history: "History",
				flooded: "Flooded pile",
				garrison: "Garrisoned",
				power: "Power card",
				market: "Market",
				regionDeck: "Region deck",
				uncivilisedDeck: "Uncivilised deck",
				civilisedDeck: "Civilised deck",
				mainDeck: "Main deck",
				fameDeck: "Fame deck",
				unrestPile: "Unrest pile",
				exile: "Exile",
				sideBarbarian: "Barbarian",
				sideEmpire: "Empire",
				vp: "Victory points",
				variableVp: "Variable victory points",
				devCost: "Development cost",
				handCount: "{{n}} cards",
				deckCount: "{{n}} cards",
				yourNation: "Your civilization",
				emptyZone: "No cards",
				lookedTitle: "Cards you are looking at",
				logTitle: "Action log",
				pickCards: "Choose {{n}} cards ({{zone}})",
				pickCardsRange: "Choose {{min}} to {{n}} cards ({{zone}})",
				pickCardsUpTo: "Choose up to {{n}} cards ({{zone}})",
				selectedCount: "Chosen {{n}} / {{total}}",
				pickMarketBreak: "Choose a source to break through",
				pickMarketAcquire: "Choose a card to acquire",
				pickMarketExile: "Choose a market card to exile",
				pickMarketToken: "Choose a market card for {{res}}",
				pickSuit: "Choose a suit to break through",
				pickOption: "Choose one",
				confirmPrompt: "Do you want to do this?",
				drawFromDeck: "Take 1 from the {{deck}}",
				searchMainDeck: "Search the main deck",
				pickDevelop: "Choose a card to develop",
				pickFreePlay: "Choose a card to play for free",
				pickFromZone: "Choose a card",
				endTitle: "Game over",
				collapseTitle: "The unrest pile is empty; the game ends immediately",
				scoreTitle: "Scores",
				winnerText: "{{name}} wins",
				winnerTie: "{{name}} tie for the win",
				endTriggered: "The game end has been triggered. Finish this round, then play one final round.",
				awaitingOthers: "Waiting for the other players to finish this round."
			},
			over: {
				collapseNote: "The unrest pile is empty. Rank by the fewest cards among hand, play area, deck, discard pile, and history (or flooded pile); the fewest cards wins.",
				progress: "Progress {{n}}",
				cards: "Cards {{n}}",
				viewBoard: "View board",
				showResult: "Show result",
				confirmAgain: "Confirm new game",
				confirmLobby: "Confirm back to lobby",
				cancel: "Cancel"
			},
			tok: {
				material: "material",
				population: "population",
				progress: "progress",
				region: "region",
				uncivilised: "uncivilised",
				civilised: "civilised",
				tributary: "tributary",
				fame: "fame",
				unrest: "unrest",
				production: "production",
				fertile: "fertile",
				river: "river",
				ocean: "ocean",
				city: "city",
				metropolis: "metropolis",
				knight: "knight",
				scroll: "scroll",
				mask: "mask",
				hunt: "hunt",
				miracle: "miracle",
				merchant: "merchant",
				barbarian: "barbarian",
				empire: "empire",
				attack: "attack",
				pinned: "pinned",
				exhaust: "exhaust",
				development: "development",
				variable: "variable"
			},
			suitName: {
				region: "Region",
				uncivilised: "Uncivilised",
				civilised: "Civilised",
				tributary: "Tributary",
				fame: "Fame",
				unrest: "Unrest",
				power: "Power"
			},
			typeName: {
				production: "Production",
				fertile: "Fertile",
				river: "River",
				ocean: "Ocean",
				city: "City",
				metropolis: "Metropolis",
				knight: "Knight",
				scroll: "Scroll",
				mask: "Mask",
				hunt: "Hunt",
				miracle: "Miracle",
				merchant: "Merchant"
			},
			optLabel: {
				abandon: "Abandon",
				acquire: "Acquire",
				break: "Break through",
				develop: "Develop",
				discard: "Discard",
				draw: "Draw a card",
				exile: "Exile",
				fertile: "A fertile card",
				flip: "Flip",
				history: "History",
				material: "Material",
				pay: "Pay",
				population: "Population",
				progress: "Progress",
				recall: "Recall",
				replace: "Replace",
				return: "Return",
				river: "A river card",
				sink: "Sink",
				top: "Top of deck",
				tributary: "A tributary card",
				unrest: "Unrest"
			},
			zoneName: {
				hand: "hand",
				discard: "discard pile",
				handOrDiscard: "hand or discard pile",
				play: "play area",
				dev: "development area",
				market: "market",
				deckTop: "top of deck",
				nationTop: "top of nation deck",
				history: "history",
				flooded: "flooded pile",
				garrison: "garrisoned cards",
				unrest: "unrest pile",
				deckBottom: "bottom of deck",
				garrisonHere: "under this card",
				exile: "exile",
				supply: "supply"
			},
			err: {
				alreadyExhausted: "This card is already exhausted this turn.",
				awaitDecision: "Finish the current choice first.",
				badChoice: "That choice is not valid.",
				badPhase: "You cannot do that in this phase.",
				cannotPay: "You do not have enough resources to pay the cost.",
				cannotPlay: "This card cannot be played right now.",
				gameOver: "The game is already over.",
				noAction: "You have no actions left.",
				noDecision: "There is no choice to make right now.",
				noExhaust: "You have no exhaustion tokens left.",
				noExhaustAbility: "This card has no exhaust ability.",
				notInHand: "This card is not in your hand.",
				notInPlay: "This card is not in play.",
				notPlayer: "You are not a player in this game.",
				notYourDecision: "This is not your choice to make.",
				notYourTurn: "It is not your turn.",
				tooFew: "Too few cards selected.",
				tooMany: "Too many cards selected."
			}
		}
	}
};
//#endregion
export { Er as default };
