import { z as e } from "zod";
import { Fragment as t, useMemo as n, useState as r } from "react";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as s } from "@bgparty/sdk/ui/player-strip";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { gameAssetUrl as f } from "@bgparty/sdk/assets";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/game/meta.ts
var h = {
	id: "kronologic",
	uuid: "1a17a190-24ab-44ac-bf9e-11da4d5c2e47",
	tier: "alpha",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.kronologic.name",
	descKey: "games.kronologic.desc",
	rulesKey: "games.kronologic.rules",
	icon: "🕰️",
	iconImg: "games/kronologic.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1, 2],
	accent: "#8c2f39",
	releasedAt: "2026-11-23T17:31:00+08:00",
	search: {
		py: "shi kong shen tan ba li",
		init: "skst"
	},
	hotseat: "cover"
}, g = {
	poison: [
		{
			setup: [
				0,
				1,
				3,
				3,
				5,
				3
			],
			sched: [
				[
					0,
					1,
					2,
					1,
					0,
					1
				],
				[
					1,
					2,
					3,
					4,
					3,
					4
				],
				[
					3,
					4,
					5,
					4,
					5,
					3
				],
				[
					3,
					4,
					5,
					3,
					2,
					3
				],
				[
					5,
					3,
					5,
					3,
					5,
					4
				],
				[
					3,
					5,
					4,
					3,
					5,
					3
				]
			],
			ans: [
				2,
				4,
				2
			],
			ref: 8
		},
		{
			setup: [
				5,
				2,
				0,
				5,
				0,
				1
			],
			sched: [
				[
					5,
					4,
					3,
					5,
					3,
					2
				],
				[
					2,
					1,
					2,
					1,
					2,
					3
				],
				[
					0,
					1,
					2,
					3,
					2,
					1
				],
				[
					5,
					3,
					2,
					3,
					5,
					3
				],
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					1,
					2,
					3,
					2,
					3,
					2
				]
			],
			ans: [
				0,
				5,
				1
			],
			ref: 7
		},
		{
			setup: [
				0,
				2,
				1,
				0,
				1,
				2
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					2,
					1,
					2,
					3,
					5,
					4
				],
				[
					1,
					2,
					3,
					4,
					3,
					2
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					1,
					2,
					1,
					2,
					3,
					4
				],
				[
					2,
					1,
					2,
					1,
					2,
					1
				]
			],
			ans: [
				0,
				0,
				1
			],
			ref: 7
		},
		{
			setup: [
				4,
				0,
				2,
				0,
				0,
				2
			],
			sched: [
				[
					4,
					5,
					3,
					2,
					1,
					2
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					2,
					3,
					2,
					3,
					2,
					3
				],
				[
					0,
					1,
					0,
					1,
					2,
					3
				],
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					2,
					3,
					4,
					5,
					3,
					2
				]
			],
			ans: [
				2,
				2,
				5
			],
			ref: 11
		},
		{
			setup: [
				5,
				3,
				2,
				1,
				3,
				5
			],
			sched: [
				[
					5,
					3,
					4,
					5,
					3,
					5
				],
				[
					3,
					4,
					5,
					4,
					3,
					2
				],
				[
					2,
					3,
					4,
					3,
					5,
					4
				],
				[
					1,
					2,
					3,
					5,
					4,
					5
				],
				[
					3,
					4,
					3,
					5,
					3,
					4
				],
				[
					5,
					4,
					3,
					4,
					3,
					4
				]
			],
			ans: [
				0,
				5,
				6
			],
			ref: 12
		}
	],
	phantom: [
		{
			setup: [
				4,
				3,
				1,
				4,
				4,
				0
			],
			sched: [
				[
					4,
					5,
					3,
					4,
					5,
					3
				],
				[
					3,
					4,
					3,
					4,
					5,
					4
				],
				[
					1,
					0,
					1,
					2,
					1,
					0
				],
				[
					4,
					5,
					3,
					4,
					3,
					2
				],
				[
					4,
					5,
					4,
					3,
					4,
					5
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				]
			],
			ans: [2],
			ref: 22
		},
		{
			setup: [
				3,
				4,
				1,
				0,
				5,
				3
			],
			sched: [
				[
					3,
					2,
					3,
					2,
					3,
					5
				],
				[
					4,
					5,
					3,
					5,
					4,
					5
				],
				[
					1,
					2,
					3,
					4,
					5,
					4
				],
				[
					0,
					1,
					0,
					1,
					2,
					1
				],
				[
					5,
					4,
					5,
					4,
					5,
					3
				],
				[
					3,
					5,
					3,
					5,
					4,
					5
				]
			],
			ans: [3],
			ref: 12
		},
		{
			setup: [
				0,
				5,
				2,
				3,
				0,
				0
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					5,
					3,
					5,
					3,
					2,
					3
				],
				[
					2,
					3,
					2,
					3,
					5,
					3
				],
				[
					3,
					2,
					3,
					2,
					1,
					2
				],
				[
					0,
					1,
					2,
					1,
					0,
					1
				],
				[
					0,
					1,
					2,
					1,
					2,
					3
				]
			],
			ans: [3],
			ref: 22
		},
		{
			setup: [
				5,
				2,
				1,
				4,
				0,
				0
			],
			sched: [
				[
					5,
					3,
					4,
					3,
					4,
					3
				],
				[
					2,
					3,
					5,
					3,
					5,
					3
				],
				[
					1,
					0,
					1,
					0,
					1,
					0
				],
				[
					4,
					3,
					2,
					3,
					4,
					3
				],
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					0,
					1,
					2,
					1,
					2,
					1
				]
			],
			ans: [2],
			ref: 13
		},
		{
			setup: [
				0,
				2,
				4,
				2,
				1,
				3
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					2,
					3,
					5,
					3,
					4,
					5
				],
				[
					4,
					5,
					3,
					4,
					5,
					3
				],
				[
					2,
					3,
					5,
					3,
					4,
					3
				],
				[
					1,
					2,
					1,
					2,
					1,
					2
				],
				[
					3,
					5,
					3,
					4,
					5,
					4
				]
			],
			ans: [4],
			ref: 22
		}
	],
	jewels: [
		{
			setup: [
				0,
				2,
				2,
				5,
				4,
				4
			],
			sched: [
				[
					0,
					1,
					2,
					1,
					2,
					3
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					2,
					3,
					2,
					3,
					4,
					5
				],
				[
					5,
					3,
					5,
					4,
					3,
					4
				],
				[
					4,
					3,
					4,
					5,
					3,
					4
				],
				[
					4,
					5,
					3,
					5,
					3,
					2
				]
			],
			ans: [4, 4],
			ref: 9
		},
		{
			setup: [
				4,
				2,
				1,
				3,
				1,
				5
			],
			sched: [
				[
					4,
					3,
					4,
					5,
					3,
					2
				],
				[
					2,
					3,
					5,
					4,
					3,
					4
				],
				[
					1,
					2,
					1,
					2,
					3,
					2
				],
				[
					3,
					4,
					5,
					3,
					2,
					3
				],
				[
					1,
					0,
					1,
					2,
					1,
					0
				],
				[
					5,
					3,
					2,
					3,
					5,
					4
				]
			],
			ans: [3, 3],
			ref: 7
		},
		{
			setup: [
				1,
				5,
				4,
				4,
				0,
				1
			],
			sched: [
				[
					1,
					0,
					1,
					2,
					3,
					2
				],
				[
					5,
					4,
					3,
					2,
					3,
					4
				],
				[
					4,
					3,
					5,
					4,
					5,
					3
				],
				[
					4,
					5,
					4,
					3,
					4,
					5
				],
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					1,
					0,
					1,
					2,
					3,
					2
				]
			],
			ans: [1, 4],
			ref: 8
		},
		{
			setup: [
				3,
				2,
				2,
				4,
				5,
				2
			],
			sched: [
				[
					3,
					4,
					3,
					2,
					1,
					2
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					4,
					3,
					2,
					1,
					2,
					3
				],
				[
					5,
					4,
					5,
					3,
					5,
					3
				],
				[
					2,
					3,
					2,
					3,
					2,
					3
				]
			],
			ans: [0, 2],
			ref: 7
		},
		{
			setup: [
				3,
				3,
				1,
				3,
				5,
				1
			],
			sched: [
				[
					3,
					4,
					5,
					4,
					3,
					4
				],
				[
					3,
					2,
					3,
					5,
					3,
					2
				],
				[
					1,
					2,
					3,
					2,
					1,
					2
				],
				[
					3,
					2,
					3,
					2,
					1,
					0
				],
				[
					5,
					3,
					4,
					5,
					4,
					3
				],
				[
					1,
					2,
					3,
					2,
					3,
					5
				]
			],
			ans: [2, 2],
			ref: 7
		}
	]
}, _ = [
	[1],
	[0, 2],
	[1, 3],
	[
		2,
		4,
		5
	],
	[3, 5],
	[3, 4]
], v = {
	poison: [
		{
			gold: 8,
			silver: 14
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 11,
			silver: 17
		},
		{
			gold: 12,
			silver: 18
		}
	],
	phantom: [
		{
			gold: 22,
			silver: 28
		},
		{
			gold: 12,
			silver: 18
		},
		{
			gold: 22,
			silver: 28
		},
		{
			gold: 13,
			silver: 19
		},
		{
			gold: 22,
			silver: 28
		}
	],
	jewels: [
		{
			gold: 9,
			silver: 15
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 8,
			silver: 14
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 7,
			silver: 13
		}
	]
}, y = e.enum([
	"poison",
	"phantom",
	"jewels"
]), b = e.int().min(1).max(5), x = e.object({
	scenario: y.default("poison"),
	level: b.default(1)
}).default({
	scenario: "poison",
	level: 1
}), S = e.int().min(0).max(5), C = e.int().min(1).max(6), w = e.int().min(0).max(5), ee = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("ask"),
		loc: S,
		kind: e.enum(["time", "char"]),
		time: C.optional(),
		char: w.optional()
	}),
	e.object({
		type: e.literal("solve"),
		char: w,
		loc: S.optional(),
		time: C.optional()
	}),
	e.object({
		type: e.literal("mark"),
		loc: S,
		time: C,
		char: w,
		on: e.boolean()
	}),
	e.object({
		type: e.literal("note"),
		text: e.string().max(2e3)
	}),
	e.object({ type: e.literal("giveUp") })
]), T = e.object({
	seat: e.int().min(0),
	loc: S,
	kind: e.enum(["time", "char"]),
	time: C.optional(),
	char: w.optional(),
	shared: e.int().min(0).max(6)
}), te = T.extend({
	privChars: e.array(w),
	privTimes: e.array(C)
}), E = e.object({
	outcome: e.enum([
		"win",
		"lose",
		"gaveUp"
	]),
	winners: e.array(e.int().min(0)),
	answer: e.array(e.int().min(0).max(5)),
	solution: e.array(e.array(S).length(6)).length(6),
	counts: e.array(e.int().nonnegative()),
	medals: e.array(e.enum([
		"gold",
		"silver",
		"bronze",
		"none"
	]))
}).nullable(), ne = e.object({
	scenario: y,
	level: b,
	investigation: e.int().min(1).max(5),
	setup: e.array(S).length(6),
	players: e.array(e.string()),
	phase: e.enum(["ask", "done"]),
	active: e.int().min(0),
	eliminated: e.array(e.int().min(0)),
	queries: e.array(T),
	result: E
}), D = e.object({
	clues: e.array(te),
	marks: e.record(e.string(), e.array(w)),
	text: e.string()
}), O = (e) => ({ code: e });
function re(e, t) {
	let n = e.puzzle.ans;
	return e.scenario === "phantom" ? t.char === n[0] : e.scenario === "jewels" ? t.char === n[0] && t.loc === n[1] : t.char === n[0] && t.loc === n[1] && t.time === n[2];
}
function k(e, t) {
	if (e.players.length !== 1) return "none";
	let n = e.queries.filter((e) => e.seat === t).length, r = v[e.scenario][e.level - 1];
	return n <= r.gold ? "gold" : n <= r.silver ? "silver" : "bronze";
}
function A(e) {
	let t = e.active;
	for (let n = 0; n < e.players.length; n++) if (t = (t + 1) % e.players.length, !e.eliminated.includes(t)) {
		e.active = t;
		return;
	}
}
var j = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: h,
	schemas: {
		action: ee,
		publicView: ne,
		privateView: D,
		config: x
	},
	setup(e, t) {
		let n = e.scenario, r = Math.min(5, Math.max(1, e.level));
		return {
			state: {
				players: t,
				scenario: n,
				level: r,
				puzzle: g[n][r - 1],
				queries: [],
				active: 0,
				eliminated: [],
				marks: {},
				notes: {},
				phase: "ask",
				result: null
			},
			fx: [{
				kind: "setup",
				data: {
					scenario: n,
					level: r
				}
			}]
		};
	},
	reduce(e, t, n) {
		if (e.phase === "done") return O("games.kronologic.errorDone");
		let r = e.players.indexOf(n.by);
		if (r < 0) return O("games.kronologic.errorTurn");
		if (t.type === "note") {
			let r = structuredClone(e);
			return r.notes[n.by] = t.text, { state: r };
		}
		if (t.type === "mark") {
			let r = structuredClone(e), i = `${t.loc}:${t.time}`, a = r.marks[n.by] ??= {}, o = new Set(a[i] ?? []);
			return t.on ? o.add(t.char) : o.delete(t.char), o.size ? a[i] = [...o].sort() : delete a[i], { state: r };
		}
		if (r !== e.active) return O("games.kronologic.errorTurn");
		if (t.type === "giveUp") {
			let t = structuredClone(e);
			return t.phase = "done", t.result = {
				outcome: "gaveUp",
				winners: [],
				answer: t.puzzle.ans,
				solution: t.puzzle.sched,
				counts: t.players.map((e, n) => t.queries.filter((e) => e.seat === n).length),
				medals: t.players.map((e, n) => k(t, n))
			}, {
				state: t,
				fx: [{
					kind: "reveal",
					data: { answer: t.puzzle.ans }
				}]
			};
		}
		if (t.type === "ask") {
			if (t.kind === "time" && (t.time === void 0 || t.time < 1 || t.time > 6) || t.kind === "char" && (t.char === void 0 || t.char < 0 || t.char > 5)) return O("games.kronologic.errorAsk");
			let n = structuredClone(e), i;
			if (t.kind === "time") {
				let e = t.time, a = [];
				for (let r = 0; r < 6; r++) n.puzzle.sched[r][e - 1] === t.loc && a.push(r);
				i = {
					seat: r,
					loc: t.loc,
					kind: "time",
					time: e,
					shared: a.length,
					privChars: a,
					privTimes: []
				};
			} else {
				let e = t.char, a = [];
				for (let r = 0; r < 6; r++) n.puzzle.sched[e][r] === t.loc && a.push(r);
				i = {
					seat: r,
					loc: t.loc,
					kind: "char",
					char: e,
					shared: a.length,
					privChars: [],
					privTimes: a.map((e) => e + 1)
				};
			}
			return n.queries.push(i), i.privChars.length === 0 && i.privTimes.length === 0 ? {
				state: n,
				fx: [{
					kind: "again",
					data: { seat: r }
				}]
			} : (n.players.length > 1 && A(n), {
				state: n,
				fx: [{
					kind: "reveal",
					data: { seat: r }
				}]
			});
		}
		if (e.scenario === "poison" && (t.loc === void 0 || t.time === void 0) || e.scenario === "jewels" && t.loc === void 0) return O("games.kronologic.errorSolve");
		let i = structuredClone(e);
		if (re(e, t)) return i.phase = "done", i.result = {
			outcome: "win",
			winners: [r],
			answer: i.puzzle.ans,
			solution: i.puzzle.sched,
			counts: i.players.map((e, t) => i.queries.filter((e) => e.seat === t).length),
			medals: i.players.map((e, t) => k(i, t))
		}, {
			state: i,
			fx: [{
				kind: "win",
				rid: n.by,
				data: { seat: r }
			}]
		};
		i.eliminated.push(r);
		let a = i.players.map((e, t) => t).filter((e) => !i.eliminated.includes(e));
		return a.length ? (i.active = a.find((e) => e > r) ?? a[0], {
			state: i,
			fx: [{
				kind: "eliminated",
				data: { seat: r }
			}]
		}) : (i.phase = "done", i.result = {
			outcome: "lose",
			winners: [],
			answer: i.puzzle.ans,
			solution: i.puzzle.sched,
			counts: i.players.map((e, t) => i.queries.filter((e) => e.seat === t).length),
			medals: i.players.map((e, t) => k(i, t))
		}, {
			state: i,
			fx: [{
				kind: "eliminated",
				data: { seat: r }
			}, {
				kind: "reveal",
				data: { answer: i.puzzle.ans }
			}]
		});
	},
	viewFor(e, t) {
		let n = e.players.indexOf(t);
		return {
			public: {
				scenario: e.scenario,
				level: e.level,
				investigation: e.level,
				setup: e.puzzle.setup,
				players: e.players,
				phase: e.phase,
				active: e.active,
				eliminated: e.eliminated,
				queries: e.queries.map((e) => ({
					seat: e.seat,
					loc: e.loc,
					kind: e.kind,
					...e.time === void 0 ? {} : { time: e.time },
					...e.char === void 0 ? {} : { char: e.char },
					shared: e.shared
				})),
				result: e.result
			},
			private: {
				clues: e.queries.filter((e) => e.seat === n),
				marks: e.marks[t] ?? {},
				text: e.notes[t] ?? ""
			}
		};
	},
	status(e) {
		if (e.phase !== "done" || !e.result) return { phase: e.phase };
		let t = e.result.winners.map((t) => e.players[t]);
		return {
			phase: "done",
			winner: t,
			ranking: [...t, ...e.players.filter((e) => !t.includes(e))]
		};
	}
}, M = [
	"A",
	"B",
	"C",
	"D",
	"J",
	"S"
], N = [
	"#2f5d5a",
	"#6b2f5a",
	"#3a3330",
	"#1f4e79",
	"#a9671a",
	"#7b2230"
];
//#endregion
//#region src/game/chit.tsx
function P({ char: e, className: t }) {
	return /* @__PURE__ */ u("i", {
		className: `kronologic-chit${t ? ` ${t}` : ""}`,
		style: { background: N[e] },
		"aria-hidden": !0,
		children: M[e]
	});
}
//#endregion
//#region src/game/icons.tsx
var F = {
	viewBox: "0 0 64 64",
	"aria-hidden": !0,
	focusable: !1
};
function I({ children: e, ...t }) {
	return /* @__PURE__ */ u("svg", {
		...F,
		...t,
		fill: "currentColor",
		children: e
	});
}
function L(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [
			/* @__PURE__ */ u("rect", {
				x: "30.5",
				y: "3.5",
				width: "3",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("path", { d: "M22 15 a10 10 0 0 1 20 0 Z" }),
			/* @__PURE__ */ u("path", { d: "M11 27 L32 12.5 L53 27 Z" }),
			/* @__PURE__ */ u("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M6 26 H58 V58 H6 Z\r\n      M11 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M21 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M31 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M41 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M51 52 V43 a3 3 0 0 0 6 0 V52 Z"
			}),
			/* @__PURE__ */ u("rect", {
				x: "3",
				y: "58",
				width: "58",
				height: "4",
				rx: "1"
			})
		]
	});
}
function ie(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [
			/* @__PURE__ */ u("rect", {
				x: "7",
				y: "52",
				width: "50",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "10.5",
				y: "45",
				width: "43",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "14",
				y: "38",
				width: "36",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "17.5",
				y: "31",
				width: "29",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "21",
				y: "24",
				width: "22",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "24.5",
				y: "17",
				width: "15",
				height: "6",
				rx: "1.2"
			})
		]
	});
}
function R(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [
			/* @__PURE__ */ u("rect", {
				x: "12",
				y: "8",
				width: "40",
				height: "5",
				rx: "1"
			}),
			/* @__PURE__ */ u("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M11 21 a7 7 0 1 0 14 0 a7 7 0 1 0 -14 0 M15 21 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0"
			}),
			/* @__PURE__ */ u("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M39 21 a7 7 0 1 0 14 0 a7 7 0 1 0 -14 0 M43 21 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0"
			}),
			/* @__PURE__ */ u("path", { d: "M12 27 H52 L49 33 H15 Z" }),
			/* @__PURE__ */ u("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M23 33 H41 V53 H23 Z M26.5 36 V51 H28 V36 Z M31.25 36 V51 H32.75 V36 Z M36 36 V51 H37.5 V36 Z"
			}),
			/* @__PURE__ */ u("rect", {
				x: "18",
				y: "53",
				width: "28",
				height: "4",
				rx: "1"
			}),
			/* @__PURE__ */ u("rect", {
				x: "13",
				y: "57",
				width: "38",
				height: "5",
				rx: "1"
			})
		]
	});
}
function z(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [/* @__PURE__ */ u("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 24 a3 3 0 0 1 3 -3 h18 a3 3 0 0 1 3 3 v8 c0 9 -5.4 16 -12 16 s-12 -7 -12 -16 z\r\n      M14 29 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M21.6 29 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M15 37.5 q5 5 10 0 q-5 2.6 -10 0"
		}), /* @__PURE__ */ u("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M32 20 a3 3 0 0 1 3 -3 h18 a3 3 0 0 1 3 3 v8 c0 9 -5.4 16 -12 16 s-12 -7 -12 -16 z\r\n      M38 25 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M45.6 25 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M39 38 q5 -5 10 0 q-5 -2.6 -10 0"
		})]
	});
}
function B(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [
			/* @__PURE__ */ u("ellipse", {
				cx: "21",
				cy: "50",
				rx: "9.5",
				ry: "6.4",
				transform: "rotate(-20 21 50)"
			}),
			/* @__PURE__ */ u("rect", {
				x: "28.4",
				y: "13",
				width: "3.8",
				height: "36",
				rx: "1.6"
			}),
			/* @__PURE__ */ u("path", { d: "M32.2 13 C 47 17 48 30 40 39 C 44 28 40 20 32.2 19.6 Z" })
		]
	});
}
function ae(e) {
	return /* @__PURE__ */ d(I, {
		...e,
		children: [
			/* @__PURE__ */ u("circle", {
				cx: "35",
				cy: "12",
				r: "4.6"
			}),
			/* @__PURE__ */ u("path", {
				d: "M33.5 17.5 C 32.5 24 30.5 28.5 29 33.5",
				stroke: "currentColor",
				strokeWidth: "6.4",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ u("path", {
				d: "M33.5 20.5 C 40 17.5 45 14.5 51 13.5",
				stroke: "currentColor",
				strokeWidth: "4.6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ u("path", {
				d: "M32.5 22.5 C 26.5 25 22 23.5 17.5 21",
				stroke: "currentColor",
				strokeWidth: "4.6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ u("path", {
				d: "M29 33.5 L 26.6 52",
				stroke: "currentColor",
				strokeWidth: "6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ u("path", {
				d: "M29 32.5 C 38 34 45.5 30 52 22.5",
				stroke: "currentColor",
				strokeWidth: "6",
				strokeLinecap: "round",
				fill: "none"
			})
		]
	});
}
var oe = [
	L,
	ie,
	R,
	z,
	B,
	ae
];
function V({ loc: e, className: t }) {
	let n = oe[e] ?? L;
	return /* @__PURE__ */ u(n, { className: t });
}
function se({ className: e }) {
	return /* @__PURE__ */ d("svg", {
		...F,
		className: e,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "3.6",
		strokeLinecap: "round",
		children: [/* @__PURE__ */ u("circle", {
			cx: "21",
			cy: "21",
			r: "12.5"
		}), /* @__PURE__ */ u("line", {
			x1: "30.5",
			y1: "30.5",
			x2: "41",
			y2: "41",
			strokeWidth: "4.8"
		})]
	});
}
//#endregion
//#region src/game/keys.ts
var H = [
	"games.kronologic.loc0",
	"games.kronologic.loc1",
	"games.kronologic.loc2",
	"games.kronologic.loc3",
	"games.kronologic.loc4",
	"games.kronologic.loc5"
], U = [
	"games.kronologic.char0",
	"games.kronologic.char1",
	"games.kronologic.char2",
	"games.kronologic.char3",
	"games.kronologic.char4",
	"games.kronologic.char5"
], W = {
	poison: "games.kronologic.scenarioPoison",
	phantom: "games.kronologic.scenarioPhantom",
	jewels: "games.kronologic.scenarioJewels"
}, ce = {
	gold: "games.kronologic.medalGold",
	silver: "games.kronologic.medalSilver",
	bronze: "games.kronologic.medalBronze",
	none: "games.kronologic.medalNone"
};
//#endregion
//#region src/game/card.tsx
function le({ clue: e, revealed: t = !1 }) {
	let n = a(), r = e.kind === "time", i = r ? n("games.kronologic.atTime", { time: e.time ?? 1 }) : n(U[e.char ?? 0]);
	return /* @__PURE__ */ d("article", {
		className: "kronologic-cluecard",
		"data-reveal": t || void 0,
		children: [/* @__PURE__ */ d("h3", { children: [
			/* @__PURE__ */ u(V, { loc: e.loc }),
			n(H[e.loc]),
			" · ",
			i
		] }), /* @__PURE__ */ d("div", {
			className: "kronologic-clue-readings",
			children: [/* @__PURE__ */ d("div", {
				className: "kronologic-clue-public",
				children: [/* @__PURE__ */ u("b", { children: n("games.kronologic.publicClue") }), /* @__PURE__ */ u("span", { children: n(r ? "games.kronologic.timePresent" : "games.kronologic.timeVisits", { n: e.shared }) })]
			}), /* @__PURE__ */ d("div", {
				className: "kronologic-clue-private",
				children: [/* @__PURE__ */ u("b", { children: n("games.kronologic.privateClue") }), r ? e.privChars.length > 0 ? /* @__PURE__ */ u("ul", {
					"aria-label": n("games.kronologic.privatePeople"),
					children: e.privChars.map((e) => /* @__PURE__ */ d("li", { children: [/* @__PURE__ */ u(P, { char: e }), n(U[e])] }, e))
				}) : /* @__PURE__ */ u("span", { children: n("games.kronologic.noPrivateTime") }) : /* @__PURE__ */ u("span", { children: e.privTimes.length > 0 ? n("games.kronologic.privateTimes", { list: e.privTimes.join(n("games.kronologic.listSep")) }) : n("games.kronologic.noPrivateChar") })]
			})]
		})]
	});
}
//#endregion
//#region src/game/opera-scene.tsx
var G = "games/kronologic/", K = 720, q = 334, ue = [
	[
		15,
		82,
		98,
		190
	],
	[
		131,
		64,
		133,
		226
	],
	[
		282,
		50,
		128,
		254
	],
	[
		428,
		102,
		108,
		150
	],
	[
		554,
		64,
		151,
		98
	],
	[
		554,
		180,
		151,
		110
	]
], de = [
	[
		113,
		173,
		18,
		12
	],
	[
		264,
		172,
		18,
		12
	],
	[
		410,
		172,
		18,
		12
	],
	[
		536,
		126,
		18,
		12
	],
	[
		536,
		220,
		18,
		12
	],
	[
		617,
		162,
		13,
		18
	]
];
function fe() {
	return {
		"--kron-paper-grain": `url("${f(G + "paper.webp")}")`,
		"--kron-velvet-grain": `url("${f(G + "velvet.webp")}")`
	};
}
function pe({ title: e, setup: t, selected: n, locName: r, charName: i, listSeparator: a, onPick: o }) {
	return /* @__PURE__ */ d("div", {
		className: "kronologic-mapframe",
		role: "group",
		"aria-label": e,
		children: [
			/* @__PURE__ */ u("img", {
				className: "kronologic-map-art",
				src: f(G + "opera-scene.webp"),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ u("svg", {
				className: "kronologic-passages",
				viewBox: "0 0 720 334",
				"aria-hidden": "true",
				children: de.map(([e, t, n, r]) => /* @__PURE__ */ u("rect", {
					x: e,
					y: t,
					width: n,
					height: r,
					rx: 1
				}, `${e}:${t}`))
			}),
			ue.map(([e, s, c, l], f) => {
				let p = t.flatMap((e, t) => e === f ? [t] : []);
				return /* @__PURE__ */ d("button", {
					type: "button",
					className: "kronologic-room",
					style: {
						left: `${e / K * 100}%`,
						top: `${s / q * 100}%`,
						width: `${c / K * 100}%`,
						height: `${l / q * 100}%`
					},
					"data-side": f >= 4 || void 0,
					"aria-pressed": n === f,
					"aria-label": [r(f), ...p.map(i)].join(a),
					onClick: () => o(f),
					children: [/* @__PURE__ */ d("span", {
						className: "kronologic-roomlabel",
						children: [/* @__PURE__ */ u("span", {
							className: "kronologic-roommedallion",
							children: /* @__PURE__ */ u(V, { loc: f })
						}), /* @__PURE__ */ u("span", {
							className: "kronologic-roomtag",
							children: r(f)
						})]
					}), p.length > 0 && /* @__PURE__ */ u("span", {
						className: "kronologic-roomtokens",
						"aria-hidden": "true",
						children: p.map((e) => /* @__PURE__ */ u(P, {
							char: e,
							className: "kronologic-mapchit"
						}, e))
					})]
				}, f);
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
var me = [
	0,
	1,
	2,
	3,
	4,
	5
], J = [
	0,
	1,
	2,
	3,
	4,
	5
], Y = [
	1,
	2,
	3,
	4,
	5,
	6
];
function he({ kind: e, value: t, label: n, selected: r, asked: i, onPick: a }) {
	return /* @__PURE__ */ u("button", {
		type: "button",
		className: "kronologic-placard",
		"data-kind": e,
		"data-selected": r || void 0,
		"data-asked": i || void 0,
		"aria-pressed": r,
		"aria-label": n,
		onClick: a,
		children: e === "time" ? /* @__PURE__ */ u("span", { children: t }) : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("b", { children: M[t] }), /* @__PURE__ */ u("span", { children: n })] })
	});
}
function X(e) {
	c();
	let f = e.public, p = e.private ?? {
		clues: [],
		marks: {},
		text: ""
	}, m = a(), h = f.players.indexOf(e.myRid), [g, _] = r(null), [y, b] = r("time"), [x, S] = r(1), [C, w] = r(0), [ee, T] = r(!1), [te, E] = r(!1), [ne, D] = r(!1), [O, re] = r({
		rid: e.myRid,
		clueCount: p.clues.length,
		queryCount: f.queries.length
	}), [k, A] = r(null), [j, M] = r(null), [N, F] = r(null), [I, L] = r(!1);
	O.rid !== e.myRid && (re({
		rid: e.myRid,
		clueCount: p.clues.length,
		queryCount: f.queries.length
	}), _(null), b("time"), S(1), w(0), D(!1), T(!1), A(null), M(null), F(null), L(!1));
	let ie = e.members.find((e) => e.rid === f.players[f.active])?.name ?? "", R = f.phase !== "done" && f.active === h && !f.eliminated.includes(h), z = f.phase === "done", B = n(() => new Set(f.queries.map((e) => e.kind === "time" ? `t:${e.loc}:${e.time}` : `c:${e.loc}:${e.char}`)), [f.queries]), ae = n(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of f.queries) t.kind === "time" && t.time !== void 0 && e.set(`${t.loc}:${t.time}`, t.shared);
		return e;
	}, [f.queries]), oe = n(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of f.queries) e.set(t.seat, (e.get(t.seat) ?? 0) + 1);
		return e;
	}, [f.queries]), ce = g !== null && B.has(y === "time" ? `t:${g}:${x}` : `c:${g}:${x}`), G = (e) => m(H[e]), K = (e) => m(U[e]), q = z ? "done" : f.eliminated.includes(h) ? "warn" : R ? "accent" : "info", ue = z ? f.result?.outcome === "win" ? m("games.kronologic.resultWin", { name: e.members.find((e) => e.rid === f.players[f.result.winners[0] ?? 0])?.name ?? "" }) : f.result?.outcome === "gaveUp" ? m("games.kronologic.resultGiveUp") : m("games.kronologic.resultLose") : f.eliminated.includes(h) ? m("games.kronologic.eliminated") : R ? m("games.kronologic.yourTurn") : m("games.kronologic.waitTurn", { name: ie }), de = (e) => e.kind === "time" ? m("games.kronologic.sharedCount", {
		loc: G(e.loc),
		time: e.time ?? 0,
		n: e.shared
	}) : m("games.kronologic.sharedVisits", {
		char: K(e.char ?? 0),
		loc: G(e.loc),
		n: e.shared
	}), X = v[f.scenario][f.level - 1], ge = g === null ? m("games.kronologic.selectLocation") : y === "time" ? m("games.kronologic.inquiryTime", {
		loc: G(g),
		time: x
	}) : m("games.kronologic.inquiryCharacter", {
		loc: G(g),
		char: K(x)
	}), Z = p.clues.slice(-2).reverse(), _e = /* @__PURE__ */ d("button", {
		type: "button",
		className: "kronologic-link",
		onClick: () => D(!0),
		children: [
			m("games.kronologic.myClues"),
			" · ",
			/* @__PURE__ */ u("b", {
				"data-reveal": p.clues.length > O.clueCount || void 0,
				children: p.clues.length
			}, p.clues.length)
		]
	}), Q = /* @__PURE__ */ d("button", {
		type: "button",
		className: "kronologic-link",
		onClick: () => E(!0),
		children: [
			m("games.kronologic.allQueries"),
			" · ",
			/* @__PURE__ */ u("b", {
				"data-reveal": f.queries.length > O.queryCount || void 0,
				children: f.queries.length
			}, f.queries.length)
		]
	}), ve = () => {
		g !== null && e.send(y === "time" ? {
			type: "ask",
			loc: g,
			kind: "time",
			time: x
		} : {
			type: "ask",
			loc: g,
			kind: "char",
			char: x
		});
	}, ye = (t, n) => {
		let r = !(p.marks[`${t}:${n}`] ?? []).includes(C);
		e.send({
			type: "mark",
			loc: t,
			time: n,
			char: C,
			on: r
		});
	}, $ = k !== null && (f.scenario === "phantom" || j !== null) && (f.scenario !== "poison" || N !== null);
	return /* @__PURE__ */ d("div", {
		className: "kronologic-root",
		style: fe(),
		children: [
			/* @__PURE__ */ u(o, {
				adaptive: !0,
				className: "kronologic-layout",
				actionsHeight: "kronologic-actions-slot",
				banner: /* @__PURE__ */ d("header", {
					className: "kronologic-banner",
					children: [
						/* @__PURE__ */ d("div", {
							className: "kronologic-masthead",
							children: [/* @__PURE__ */ u("h1", { children: m("games.kronologic.name") }), /* @__PURE__ */ d("div", {
								className: "kronologic-casechips",
								children: [
									/* @__PURE__ */ u("span", { children: m("games.kronologic.investigationNo", { n: f.investigation }) }),
									/* @__PURE__ */ u("span", { children: m(W[f.scenario]) }),
									f.players.length === 1 && /* @__PURE__ */ u("span", { children: m("games.kronologic.parHint", {
										gold: X.gold,
										silver: X.silver
									}) })
								]
							})]
						}),
						/* @__PURE__ */ u("div", {
							className: "kronologic-roster",
							children: /* @__PURE__ */ u(s, {
								members: e.members.filter((e) => f.players.includes(e.rid)),
								myRid: e.myRid,
								variant: "plate",
								status: (e) => /* @__PURE__ */ u("span", { children: m("games.kronologic.questionsCount", { n: oe.get(f.players.indexOf(e)) ?? 0 }) }),
								dimmed: (e) => f.eliminated.includes(f.players.indexOf(e))
							})
						}),
						/* @__PURE__ */ u("span", {
							className: "kronologic-turn",
							"data-tone": q,
							role: "status",
							children: ue
						})
					]
				}),
				actions: /* @__PURE__ */ d("div", {
					className: "kronologic-actions",
					children: [
						/* @__PURE__ */ d("div", {
							className: "kronologic-inquiry",
							"aria-live": "polite",
							children: [
								g === null ? /* @__PURE__ */ u(se, {}) : /* @__PURE__ */ u(V, { loc: g }),
								/* @__PURE__ */ u("span", { children: ge }),
								ce && /* @__PURE__ */ u("small", { children: m("games.kronologic.askedTag") })
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "kronologic-kind",
							role: "group",
							"aria-label": m("games.kronologic.selectKind"),
							children: [/* @__PURE__ */ u("button", {
								type: "button",
								"data-selected": y === "time",
								"aria-pressed": y === "time",
								onClick: () => {
									y !== "time" && (b("time"), S(1));
								},
								children: m("games.kronologic.pickTime")
							}), /* @__PURE__ */ u("button", {
								type: "button",
								"data-selected": y === "char",
								"aria-pressed": y === "char",
								onClick: () => {
									y !== "char" && (b("char"), S(0));
								},
								children: m("games.kronologic.pickChar")
							})]
						}),
						/* @__PURE__ */ u("div", {
							className: "kronologic-placards",
							role: "group",
							"aria-label": m(y === "time" ? "games.kronologic.pickTime" : "games.kronologic.pickChar"),
							children: (y === "time" ? Y : J).map((e) => /* @__PURE__ */ u(he, {
								kind: y,
								value: e,
								label: y === "time" ? m("games.kronologic.atTime", { time: e }) : K(e),
								selected: x === e,
								asked: g !== null && B.has(y === "time" ? `t:${g}:${e}` : `c:${g}:${e}`),
								onPick: () => S(e)
							}, e))
						}),
						/* @__PURE__ */ d("div", {
							className: "kronologic-composer-actions",
							children: [/* @__PURE__ */ u("button", {
								type: "button",
								className: "kronologic-btn-ask",
								disabled: !R || g === null,
								onClick: ve,
								children: m("games.kronologic.confirmAsk")
							}), /* @__PURE__ */ u("button", {
								type: "button",
								className: "kronologic-btn-solve",
								disabled: !R,
								onClick: () => {
									L(!1), T(!0);
								},
								children: m("games.kronologic.solve")
							})]
						})
					]
				}),
				children: /* @__PURE__ */ d("div", {
					className: "kronologic-main",
					children: [/* @__PURE__ */ d("div", {
						className: "kronologic-desk",
						children: [/* @__PURE__ */ d("section", {
							className: "kronologic-panel kronologic-mapwrap",
							"aria-label": m("games.kronologic.operaTitle"),
							children: [
								/* @__PURE__ */ d("header", {
									className: "kronologic-sectionhead",
									children: [/* @__PURE__ */ u("h2", { children: m("games.kronologic.operaTitle") }), /* @__PURE__ */ u("span", { children: m("games.kronologic.setupTitle") })]
								}),
								/* @__PURE__ */ u(pe, {
									title: m("games.kronologic.selectLocation"),
									setup: f.setup,
									selected: g,
									locName: G,
									charName: K,
									listSeparator: m("games.kronologic.listSep"),
									onPick: _
								}),
								/* @__PURE__ */ d("nav", {
									className: "kronologic-map-links",
									children: [_e, Q]
								})
							]
						}), /* @__PURE__ */ d("section", {
							className: "kronologic-panel kronologic-notes",
							"aria-label": m("games.kronologic.notesTitle"),
							children: [
								/* @__PURE__ */ d("header", {
									className: "kronologic-sectionhead",
									children: [/* @__PURE__ */ u("h2", { children: m("games.kronologic.notesTitle") }), /* @__PURE__ */ u("span", { children: m("games.kronologic.notesPrivate") })]
								}),
								/* @__PURE__ */ u("div", {
									className: "kronologic-brushes",
									role: "group",
									"aria-label": m("games.kronologic.markHint"),
									children: J.map((e) => /* @__PURE__ */ d("button", {
										type: "button",
										className: "kronologic-brush",
										"data-selected": C === e,
										"aria-pressed": C === e,
										onClick: () => w(e),
										title: K(e),
										"aria-label": K(e),
										children: [/* @__PURE__ */ u(P, { char: e }), /* @__PURE__ */ u("span", { children: K(e) })]
									}, e))
								}),
								/* @__PURE__ */ d("div", {
									className: "kronologic-grid",
									role: "group",
									"aria-label": m("games.kronologic.notesTitle"),
									children: [
										/* @__PURE__ */ u("span", { "aria-hidden": !0 }),
										Y.map((e) => /* @__PURE__ */ u("span", {
											className: "kronologic-gridhead",
											children: e
										}, e)),
										me.map((e) => /* @__PURE__ */ d(t, { children: [/* @__PURE__ */ d("span", {
											className: "kronologic-rowhead",
											children: [/* @__PURE__ */ u(V, { loc: e }), /* @__PURE__ */ u("span", { children: G(e) })]
										}), Y.map((t) => {
											let n = p.marks[`${e}:${t}`] ?? [], r = ae.get(`${e}:${t}`);
											return /* @__PURE__ */ d("button", {
												type: "button",
												className: "kronologic-cell",
												"data-query": e === g && y === "time" && t === x || void 0,
												onClick: () => ye(e, t),
												disabled: h < 0 || z,
												"aria-label": m("games.kronologic.cellTitle", {
													loc: G(e),
													time: t
												}),
												"aria-pressed": n.includes(C),
												children: [r !== void 0 && /* @__PURE__ */ d("span", {
													className: "kronologic-count",
													children: ["×", r]
												}), /* @__PURE__ */ u("span", {
													className: "kronologic-marks",
													children: n.map((e) => /* @__PURE__ */ u(P, {
														char: e,
														className: "kronologic-mark"
													}, e))
												})]
											}, t);
										})] }, e))
									]
								})
							]
						})]
					}), /* @__PURE__ */ d("section", {
						className: "kronologic-panel kronologic-cluewall",
						"aria-label": m("games.kronologic.clueCards"),
						children: [/* @__PURE__ */ d("header", {
							className: "kronologic-sectionhead",
							children: [
								/* @__PURE__ */ u("h2", { children: m("games.kronologic.clueArchive") }),
								_e,
								Q
							]
						}), /* @__PURE__ */ u("div", {
							className: "kronologic-cluerow",
							children: Z.length === 0 ? /* @__PURE__ */ u("p", { children: m("games.kronologic.noClues") }) : Z.map((t, n) => {
								let r = p.clues.length - n;
								return /* @__PURE__ */ u(le, {
									clue: t,
									revealed: r > O.clueCount
								}, `${e.myRid}:${r}`);
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ u(i, {
				open: ne,
				onClose: () => D(!1),
				label: m("games.kronologic.myClues"),
				title: m("games.kronologic.myClues"),
				children: /* @__PURE__ */ u("div", {
					className: "kronologic-sheet kronologic-cluelist",
					children: p.clues.length === 0 ? /* @__PURE__ */ u("p", { children: m("games.kronologic.noClues") }) : [...p.clues].reverse().map((e, t) => /* @__PURE__ */ u(le, { clue: e }, p.clues.length - t))
				})
			}),
			/* @__PURE__ */ u(i, {
				open: ee,
				onClose: () => T(!1),
				label: m("games.kronologic.solveTitle"),
				title: m("games.kronologic.solveTitle"),
				children: /* @__PURE__ */ d("div", {
					className: "kronologic-sheet",
					children: [
						/* @__PURE__ */ u("p", {
							className: "kronologic-sheet-hint",
							children: m("games.kronologic.solveHint")
						}),
						/* @__PURE__ */ u("p", {
							className: "kronologic-sheet-scenario",
							children: m(W[f.scenario])
						}),
						/* @__PURE__ */ u("h3", { children: m("games.kronologic.answerChar") }),
						/* @__PURE__ */ u("div", {
							className: "kronologic-choices",
							children: J.map((e) => /* @__PURE__ */ d("button", {
								type: "button",
								"data-selected": k === e,
								onClick: () => A(e),
								"aria-pressed": k === e,
								children: [/* @__PURE__ */ u(P, { char: e }), K(e)]
							}, e))
						}),
						f.scenario !== "phantom" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("h3", { children: m("games.kronologic.answerLoc") }), /* @__PURE__ */ u("div", {
							className: "kronologic-choices",
							children: me.map((e) => /* @__PURE__ */ d("button", {
								type: "button",
								"data-selected": j === e,
								onClick: () => M(e),
								"aria-pressed": j === e,
								children: [/* @__PURE__ */ u(V, {
									loc: e,
									className: "kronologic-choice-icon"
								}), G(e)]
							}, e))
						})] }),
						f.scenario === "poison" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("h3", { children: m("games.kronologic.answerTime") }), /* @__PURE__ */ u("div", {
							className: "kronologic-choices kronologic-choices-num",
							children: Y.map((e) => /* @__PURE__ */ u("button", {
								type: "button",
								"data-selected": N === e,
								onClick: () => F(e),
								"aria-pressed": N === e,
								children: e
							}, e))
						})] }),
						/* @__PURE__ */ d("div", {
							className: "kronologic-sheet-actions",
							children: [
								/* @__PURE__ */ u("button", {
									type: "button",
									className: "kronologic-btn-ask",
									disabled: !$,
									onClick: () => {
										e.send({
											type: "solve",
											char: k,
											...j === null ? {} : { loc: j },
											...N === null ? {} : { time: N }
										}), T(!1);
									},
									children: m("games.kronologic.submitAnswer")
								}),
								/* @__PURE__ */ u("button", {
									type: "button",
									className: "btn-quiet",
									onClick: () => T(!1),
									children: m("games.kronologic.cancel")
								}),
								/* @__PURE__ */ u("button", {
									type: "button",
									className: "kronologic-giveup",
									"data-armed": I || void 0,
									onClick: () => {
										if (!I) {
											L(!0);
											return;
										}
										e.send({ type: "giveUp" }), T(!1), L(!1);
									},
									children: m(I ? "games.kronologic.confirmGiveUp" : "games.kronologic.giveUp")
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ u(i, {
				open: te,
				onClose: () => E(!1),
				label: m("games.kronologic.allQueries"),
				title: m("games.kronologic.allQueries"),
				children: f.queries.length === 0 ? /* @__PURE__ */ u("p", {
					className: "kronologic-sheet-hint",
					children: m("games.kronologic.emptyQueries")
				}) : /* @__PURE__ */ u("ul", {
					className: "kronologic-log",
					children: f.queries.map((t, n) => /* @__PURE__ */ d("li", { children: [/* @__PURE__ */ u("b", { children: e.members.find((e) => e.rid === f.players[t.seat])?.name ?? "" }), /* @__PURE__ */ u("span", { children: de(t) })] }, n))
				})
			})
		]
	});
}
function ge(e) {
	let t = [[e]];
	for (let e = 0; e < 5; e++) {
		let e = [];
		for (let n of t) for (let t of _[n[n.length - 1]]) e.push([...n, t]);
		t = e;
	}
	return t;
}
var Z = Array.from({ length: 6 }, (e, t) => ge(t)), _e = [
	0,
	1,
	2,
	3,
	4,
	5
], Q = ({ public: e, private: t }) => {
	if (e.phase === "done") return null;
	let n = t?.clues ?? [], r = new Set(n.map(ve)), i = e.scenario, a;
	if (a = i === "poison" ? xe(e, n, r) : i === "phantom" ? Se(e, n, r) : Ce(e, n, r), a) return { action: a.kind === "time" ? {
		type: "ask",
		loc: a.loc,
		kind: "time",
		time: a.index
	} : {
		type: "ask",
		loc: a.loc,
		kind: "char",
		char: a.index
	} };
	let o = we(e, n);
	if (o) return { action: ye(i, o) };
	let s = be(r);
	return s ? { action: s.kind === "time" ? {
		type: "ask",
		loc: s.loc,
		kind: "time",
		time: s.index
	} : {
		type: "ask",
		loc: s.loc,
		kind: "char",
		char: s.index
	} } : null;
};
function ve(e) {
	return e.kind === "time" ? `t:${e.loc}:${e.time}` : `c:${e.loc}:${e.char}`;
}
function ye(e, t) {
	return e === "phantom" ? {
		type: "solve",
		char: t[0]
	} : e === "jewels" ? {
		type: "solve",
		char: t[0],
		loc: t[1]
	} : {
		type: "solve",
		char: t[0],
		loc: t[1],
		time: t[2]
	};
}
function $(e, t, n) {
	return {
		loc: e,
		kind: t,
		index: n
	};
}
function be(e) {
	for (let t = 0; t < 6; t++) for (let n = 1; n <= 6; n++) if (!e.has(`t:${t}:${n}`)) return $(t, "time", n);
	for (let t = 0; t < 6; t++) for (let n = 0; n < 6; n++) if (!e.has(`c:${t}:${n}`)) return $(t, "char", n);
	return null;
}
function xe(e, t, n) {
	for (let e of t) if (e.kind === "time" && e.shared === 2 && e.privChars.filter((e) => e !== 3).length === 1) return null;
	for (let e = 0; e < 6; e++) if (!n.has(`c:${e}:3`)) return $(e, "char", 3);
	let r = [
		,
		,
		,
		,
		,
		,
	].fill(void 0);
	for (let e of t) if (e.kind === "char" && e.char === 3) for (let t of e.privTimes) r[t - 1] = e.loc;
	for (let t = 0; t < 6; t++) {
		let i = r[t] ?? (Z[e.setup[3]].every((e) => e[t] === 0) ? 0 : void 0);
		if (i !== void 0 && !n.has(`t:${i}:${t + 1}`)) return $(i, "time", t + 1);
	}
	let i = Z[e.setup[3]].filter((e) => {
		for (let n of t) if (n.kind === "char" && n.char === 3) {
			for (let t of n.privTimes) if (e[t - 1] !== n.loc) return !1;
			if (e.filter((e) => e === n.loc).length !== n.shared) return !1;
		}
		return !0;
	});
	for (let e = 0; e < 6; e++) {
		let t = [...new Set(i.map((t) => t[e]))];
		for (let r of t) if (!n.has(`t:${r}:${e + 1}`)) return $(r, "time", e + 1);
	}
	return null;
}
function Se(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set();
	for (let e of t) if (e.kind === "time" && (e.shared === 1 && e.privChars.length === 1 && r.set(e.privChars[0], (r.get(e.privChars[0]) ?? 0) + 1), e.shared > 1)) for (let t of e.privChars) i.add(t);
	let a = [...r.entries()].filter(([e]) => !i.has(e)).sort((e, t) => t[1] - e[1])[0]?.[0];
	if (a === void 0) {
		for (let e = 1; e <= 6; e++) for (let t = 0; t < 6; t++) if (!n.has(`t:${t}:${e}`)) return $(t, "time", e);
		return null;
	}
	for (let e = 0; e < 6; e++) if (!n.has(`c:${e}:${a}`)) return $(e, "char", a);
	let o = [
		,
		,
		,
		,
		,
		,
	].fill(void 0);
	for (let e of t) if (e.kind === "char" && e.char === a) for (let t of e.privTimes) o[t - 1] = e.loc;
	for (let e = 0; e < 6; e++) if (o[e] !== void 0 && !n.has(`t:${o[e]}:${e + 1}`)) return $(o[e], "time", e + 1);
	return null;
}
function Ce(e, t, n) {
	let r = -1;
	for (let t = 0; t < 6; t++) e.setup[t] === 5 && (r = t);
	if (r < 0) return null;
	let i = 5;
	for (let e = 2; e <= 6; e++) {
		let a = t.find((t) => t.kind === "time" && t.time === e && t.privChars.includes(r));
		if (a) {
			i = a.loc, a.shared === 2 && (r = a.privChars.find((e) => e !== r) ?? r);
			continue;
		}
		for (let t of _[i]) if (!n.has(`t:${t}:${e}`)) return $(t, "time", e);
		return null;
	}
	return null;
}
function we(e, t) {
	let n = e.scenario;
	if (n === "poison") {
		for (let e of t) if (e.kind === "time" && e.shared === 2) {
			let t = e.privChars.filter((e) => e !== 3);
			if (t.length === 1) return [
				t[0],
				e.loc,
				e.time
			];
		}
		return null;
	}
	if (n === "phantom") {
		let e = _e.map((e) => {
			let n = !0, r = 0;
			for (let i of t) {
				if (i.kind === "char" && i.char === e) for (let e of i.privTimes) {
					r++;
					let a = t.find((t) => t.kind === "time" && t.time === e && t.loc === i.loc);
					a && a.shared !== 1 && (n = !1);
				}
				i.kind === "time" && i.shared > 1 && i.privChars.includes(e) && (n = !1);
			}
			return {
				char: e,
				ok: n,
				times: r
			};
		}).filter((e) => e.ok && e.times === 6);
		return e.length === 1 ? [e[0].char] : null;
	}
	let r = -1;
	for (let t = 0; t < 6; t++) e.setup[t] === 5 && (r = t);
	if (r < 0) return null;
	let i = 5;
	for (let e = 2; e <= 6; e++) {
		let n = t.find((t) => t.kind === "time" && t.time === e && t.privChars.includes(r));
		if (!n) return null;
		i = n.loc, n.shared === 2 && (r = n.privChars.find((e) => e !== r) ?? r);
	}
	return [r, i];
}
var Te = (e, t, n) => e.type === "ask" ? e.kind === "time" ? n("games.kronologic.hintAskTime", {
	loc: n(H[e.loc]),
	time: e.time ?? 1
}) : n("games.kronologic.hintAskChar", {
	loc: n(H[e.loc]),
	char: n(U[e.char ?? 0])
}) : e.type === "solve" ? n("games.kronologic.hintSolve") : n("games.kronologic.hintOther"), Ee = [
	0,
	1,
	2,
	3,
	4,
	5
], De = [
	0,
	1,
	2,
	3,
	4,
	5
], Oe = [
	1,
	2,
	3,
	4,
	5,
	6
];
function ke({ result: e, public: n, members: r, myRid: i, onPlayAgain: o, onBackToLobby: c }) {
	let f = a(), p = n, m = p.result, h = o ?? c, g = (e) => r.find((t) => t.rid === p.players[e])?.name ?? "", _ = (e) => f(U[e]), v = (e) => f(H[e]), y = m?.answer ?? [], b = m ? p.scenario === "poison" ? [
		{
			label: f("games.kronologic.culprit"),
			char: y[0]
		},
		{
			label: f("games.kronologic.location"),
			loc: y[1]
		},
		{
			label: f("games.kronologic.time"),
			time: y[2]
		}
	] : p.scenario === "phantom" ? [{
		label: f("games.kronologic.phantom"),
		char: y[0]
	}] : [{
		label: f("games.kronologic.holder"),
		char: y[0]
	}, {
		label: f("games.kronologic.location"),
		loc: y[1]
	}] : [], x = m ? p.scenario === "poison" ? f("games.kronologic.reasonPoison", {
		char: _(y[0]),
		loc: v(y[1]),
		time: y[2]
	}) : p.scenario === "phantom" ? f("games.kronologic.reasonPhantom", { char: _(y[0]) }) : f("games.kronologic.reasonJewels", {
		char: _(y[0]),
		loc: v(y[1])
	}) : "", S = m ? p.scenario === "poison" ? {
		loc: y[1],
		time: y[2]
	} : p.scenario === "jewels" ? {
		loc: y[1],
		time: 6
	} : null : null, C = m && p.scenario === "phantom" ? y[0] : null;
	return /* @__PURE__ */ d("div", {
		className: "kronologic-root kronologic-over",
		style: fe(),
		children: [
			/* @__PURE__ */ u("header", {
				className: "kronologic-banner kronologic-over-banner",
				children: /* @__PURE__ */ d("div", {
					className: "kronologic-masthead",
					children: [/* @__PURE__ */ u("h1", { children: f("games.kronologic.name") }), /* @__PURE__ */ d("div", {
						className: "kronologic-casechips",
						children: [/* @__PURE__ */ u("span", { children: f("games.kronologic.investigationNo", { n: p.investigation }) }), /* @__PURE__ */ u("span", { children: f(W[p.scenario]) })]
					})]
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "kronologic-dossier",
				children: [
					/* @__PURE__ */ d("section", {
						className: "kronologic-panel kronologic-verdict",
						"aria-label": f("games.kronologic.caseReport"),
						children: [
							/* @__PURE__ */ d("header", {
								className: "kronologic-verdict-head",
								children: [/* @__PURE__ */ u("h2", { children: f("games.kronologic.caseReport") }), /* @__PURE__ */ u("span", {
									className: "kronologic-stamp",
									children: f("games.kronologic.caseClosed")
								})]
							}),
							/* @__PURE__ */ u("p", {
								className: "kronologic-over-result",
								children: m?.outcome === "win" ? f("games.kronologic.resultWin", { name: g(m.winners[0] ?? 0) }) : m?.outcome === "gaveUp" ? f("games.kronologic.resultGiveUp") : f("games.kronologic.resultLose")
							}),
							m && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("dl", {
								className: "kronologic-verdicts",
								style: { gridTemplateColumns: `repeat(${b.length}, minmax(0, 1fr))` },
								children: b.map((e) => /* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("dt", { children: e.label }), /* @__PURE__ */ u("dd", { children: e.char === void 0 ? e.loc === void 0 ? e.time : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(V, { loc: e.loc }), v(e.loc)] }) : /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(P, { char: e.char }), _(e.char)] }) })] }, e.label))
							}), /* @__PURE__ */ u("p", {
								className: "kronologic-reason",
								children: x
							})] })
						]
					}),
					m && /* @__PURE__ */ d("section", {
						className: "kronologic-tl",
						"aria-label": f("games.kronologic.truthTimeline"),
						children: [
							/* @__PURE__ */ u("h2", {
								className: "kronologic-subtitle",
								children: f("games.kronologic.truthTimeline")
							}),
							/* @__PURE__ */ d("div", {
								className: "kronologic-tl-grid",
								role: "group",
								"aria-label": f("games.kronologic.truthTimeline"),
								children: [
									/* @__PURE__ */ u("span", { "aria-hidden": !0 }),
									Oe.map((e) => /* @__PURE__ */ u("span", {
										className: "kronologic-tl-hcell",
										children: e
									}, e)),
									Ee.map((e) => /* @__PURE__ */ d(t, { children: [/* @__PURE__ */ d("span", {
										className: "kronologic-tl-head",
										children: [/* @__PURE__ */ u(V, { loc: e }), /* @__PURE__ */ u("span", { children: v(e) })]
									}), Oe.map((t) => {
										let n = De.filter((n) => m.solution[n][t - 1] === e);
										return /* @__PURE__ */ u("span", {
											className: "kronologic-tl-cell",
											"data-key": S?.loc === e && S?.time === t || void 0,
											"aria-label": n.length ? n.map(_).join(f("games.kronologic.listSep")) : void 0,
											children: n.map((e) => /* @__PURE__ */ u(P, {
												char: e,
												className: `kronologic-tl-chit${C === e ? " kronologic-tl-chit-key" : ""}`
											}, e))
										}, t);
									})] }, e))
								]
							}),
							/* @__PURE__ */ u("ul", {
								className: "kronologic-tl-legend",
								children: De.map((e) => /* @__PURE__ */ d("li", { children: [/* @__PURE__ */ u(P, { char: e }), _(e)] }, e))
							})
						]
					}),
					m && /* @__PURE__ */ d("section", {
						className: "kronologic-over-record",
						"aria-label": f("games.kronologic.investigators"),
						children: [/* @__PURE__ */ u("h2", {
							className: "kronologic-subtitle",
							children: f("games.kronologic.investigators")
						}), /* @__PURE__ */ u(s, {
							members: r.filter((e) => p.players.includes(e.rid)),
							myRid: i,
							variant: "plate",
							status: (t) => {
								let n = p.players.indexOf(t), r = m.medals[n];
								return /* @__PURE__ */ d("span", {
									className: "kronologic-over-status",
									children: [
										e.winner.includes(t) && /* @__PURE__ */ u("b", {
											className: "kronologic-over-solved",
											children: f("games.kronologic.solvedMark")
										}),
										/* @__PURE__ */ u("span", { children: f("games.kronologic.questionsCount", { n: m.counts[n] ?? 0 }) }),
										p.players.length === 1 && r && /* @__PURE__ */ d("span", {
											className: "kronologic-medal",
											"data-medal": r,
											children: [/* @__PURE__ */ u(se, { className: "kronologic-medal-icon" }), f(ce[r])]
										})
									]
								});
							},
							dimmed: (e) => p.eliminated.includes(p.players.indexOf(e))
						})]
					})
				]
			}),
			h && /* @__PURE__ */ d("div", {
				className: "kronologic-over-actions",
				children: [o && /* @__PURE__ */ u("button", {
					type: "button",
					className: "kronologic-btn-ask",
					onClick: o,
					children: f("session.result.playAgain")
				}), c && /* @__PURE__ */ u("button", {
					type: "button",
					className: "kronologic-btn-solve",
					onClick: c,
					children: f("session.result.backToLobby")
				})]
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
var Ae = [
	{
		key: "poison",
		label: "games.kronologic.scenarioPoison",
		desc: "games.kronologic.scenarioPoisonDesc"
	},
	{
		key: "phantom",
		label: "games.kronologic.scenarioPhantom",
		desc: "games.kronologic.scenarioPhantomDesc"
	},
	{
		key: "jewels",
		label: "games.kronologic.scenarioJewels",
		desc: "games.kronologic.scenarioJewelsDesc"
	}
];
function je({ value: e, onChange: t }) {
	let n = a(), r = x.safeParse(e), i = r.success ? r.data : x.parse(void 0);
	return /* @__PURE__ */ d("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ u(m, {
				title: n("games.kronologic.optScenario"),
				columns: 3,
				children: Ae.map((e) => /* @__PURE__ */ u(p, {
					name: "kronologic-scenario",
					value: e.key,
					checked: i.scenario === e.key,
					label: n(e.label),
					hint: n(e.desc),
					accent: h.accent,
					onChange: () => t({
						...i,
						scenario: e.key
					})
				}, e.key))
			}),
			/* @__PURE__ */ u(m, {
				title: n("games.kronologic.optLevel"),
				columns: 3,
				children: [
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ u(p, {
					name: "kronologic-level",
					value: String(e),
					checked: i.level === e,
					label: n("games.kronologic.optLevelValue", { n: e }),
					accent: h.accent,
					onChange: () => t({
						...i,
						level: e
					})
				}, e))
			}),
			/* @__PURE__ */ u("p", {
				className: "text-xs opacity-60",
				children: n("games.kronologic.optHint")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var Me = {
	definition: j,
	View: X,
	bot: Q,
	describe: Te,
	OverView: ke,
	Options: je,
	locales: {
		zh: {
			name: "时空神探：巴黎1920",
			desc: "在巴黎歌剧院的一夜之间，用地点与时刻的线索还原六名角色的行踪，破解三桩悬案",
			rules: (/* @__PURE__ */ "目标：.· 六名角色在同一个夜晚先后出现在巴黎歌剧院的六个地点。每名角色在每个时刻都恰好位于一个地点，并且在两个相邻时刻之间必定移动到另一个相邻地点，不会连续两次停留在同一地点。.· 所有角色在每个时刻都在场。每起调查都有唯一确定的真相，玩家需要通过提问还原角色的行踪并回答调查提出的问题。.准备：.· 每位玩家准备一张推理笔记。笔记左侧按地点排列，上方按时刻排列，每个格子对应一个地点与一个时刻。.· 时刻 1 时六名角色各自所在的地点对所有人公开，作为推理的起点。.· 地图上有六处可以调查的地点：大堂、大楼梯、画廊、舞台、音乐厅和舞厅。.提问：.· 轮到你时，在地图上选择一个地点，再选择一个时刻或一名角色，组成一个问题。.· 选择时刻牌时，公开信息是「该地点在该时刻共有几名角色」，私密信息是「该时刻在场的所有角色」。.· 选择角色牌时，公开信息是「该角色当晚到访该地点的总次数」，私密信息是「该角色全部到访的时刻」。.· 公开信息必须当众宣布；私密信息只告诉你自己，请记在自己的笔记上。数字版会由助手把这张卡的全部私密信息直接记入你的线索栏，避免抄写遗漏。.· 如果该处没有任何角色，或者该角色从未到访该地点，私密信息为空，此时公开信息与私密信息完全相同。遇到这种情况，你在所有人记录完毕后立即再提问一次；单人游戏中这次提问同样计入次数。.· 每个问题只询问一个地点与一个时刻（或一个角色）的组合。同一个组合被其他玩家问过时，你仍然可以再次询问：公开信息不会改变，但私密信息会单独记入你的线索栏。公开提问记录可以帮你避开已经问过的组合。.调查一：毒杀疑云：.· 侦探在第二天清晨被发现死于家中，前一天晚上他正在巴黎歌剧院参加慈善晚会。凶手必须在某个时刻与侦探单独相处，才能下毒。.· 需要回答：凶手是谁、在哪个地点、在哪个时刻。.调查二：歌剧魅影：.· 歌剧院接连发生事故，人们传言是幽灵作祟。幽灵行踪隐秘，是当晚唯一一名在每个时刻都独自待在一个房间里的角色。.· 需要回答：幽灵是谁。.调查三：歌女珠宝：.· 女歌手的名贵钻石项链在演出当晚失窃。时刻 1 时项链出现在舞厅，被当时独自留在舞厅的那名角色取走并带离。.· 此后每个时刻，若同一地点恰好只有持有者与另一名角色两人，项链就转交给对方；若持有者独自一人，或者同一地点有三名及以上角色，项链仍由持有者保管。.· 需要回答：时刻 6 时谁持有项链，以及警方应该在哪个地点拦截。.作答：.· 轮到你时，如果已经确定答案，可以直接作答。.· 答案正确即赢得本起调查；答案错误则被淘汰，不能再提问或作答，也不能透露他人答案的对错。.· 所有玩家都被淘汰时，本起调查以失败结束。单人游戏中答错立即结束本局。.单人评级：.· 单人模式按提问次数评级：金放大镜、银放大镜、铜放大镜。每起调查会显示内置求解器给出的参考提问次数；不超过参考次数获得金放大镜，超出参考次数六次以内获得银放大镜，其余获得铜放大镜。该参考值用于数字版自评，并非纸面版的官方评级表。.· 单人游戏中遇到「立即再提问」时，这次提问同样计入总数。.笔记：.· 在推理笔记中，你可以为任意格子标记可能位于该处的角色，标记只对自己可见。.· 标记不会改变答案，也不会消耗提问次数，可随时修改。".split(".")).join("\n"),
			scenarioPoison: "毒杀疑云",
			scenarioPhantom: "歌剧魅影",
			scenarioJewels: "歌女珠宝",
			scenarioPoisonDesc: "找出与侦探单独相处并下毒的凶手、地点与时刻。",
			scenarioPhantomDesc: "找出在每个时刻都独处的幽灵。",
			scenarioJewelsDesc: "推演项链在众人之间转手的经过，找出时刻 6 的持有者与地点。",
			loc0: "大堂",
			loc1: "大楼梯",
			loc2: "画廊",
			loc3: "舞台",
			loc4: "音乐厅",
			loc5: "舞厅",
			char0: "女冒险家",
			char1: "男爵夫人",
			char2: "司机",
			char3: "侦探",
			char4: "记者",
			char5: "女仆",
			yourTurn: "轮到你调查",
			waitTurn: "等待{{name}}提问",
			goAgain: "你获得一次额外提问",
			eliminated: "你已被淘汰",
			gameOver: "本起调查已结束",
			setupTitle: "时刻 1 的位置",
			setupHint: "所有角色在时刻 1 的地点公开，可作为推理起点。",
			selectLocation: "在地图上选择地点",
			selectKind: "选择时刻或角色",
			pickTime: "时刻",
			pickChar: "角色",
			operaTitle: "巴黎歌剧院",
			inquiryTime: "{{loc}} · 时刻 {{time}}",
			inquiryCharacter: "{{loc}} · {{char}}",
			notesPrivate: "标记仅自己可见",
			publicClue: "公开",
			privateClue: "私密",
			privatePeople: "在场角色",
			clueArchive: "线索档案",
			caseReport: "结案报告",
			askTimeTitle: "询问{{loc}}在{{time}}时刻",
			askCharTitle: "询问{{char}}到访{{loc}}的次数",
			confirmAsk: "提问",
			askAgain: "再问一次",
			sharedCount: "{{loc}}在时刻 {{time}} 共有 {{n}} 名角色",
			sharedVisits: "{{char}}当晚到访{{loc}}共 {{n}} 次",
			privateChars: "在场角色：{{list}}",
			privateTimes: "到访时刻：{{list}}",
			dupWarn: "已问过，答案不会改变",
			noPrivateTime: "该地点在该时刻没有角色",
			noPrivateChar: "该角色从未到访该地点",
			listSep: "、",
			clauseSep: "，",
			myClues: "我的线索",
			noClues: "提问后，私密信息会记录在这里。",
			notesTitle: "推理笔记",
			notesHint: "点选格子可标记可能位于该处的角色。",
			cellTitle: "{{loc}} · 时刻 {{time}}",
			markHint: "选择要标记的角色",
			clearCell: "清除本格",
			solve: "作答",
			solveTitle: "提交答案",
			solveHint: "答案错误将被淘汰，请确认后再提交。",
			answerChar: "角色",
			answerLoc: "地点",
			answerTime: "时刻",
			submitAnswer: "确认提交",
			cancel: "取消",
			giveUp: "放弃本局",
			confirmGiveUp: "确认放弃",
			questionsCount: "提问 {{n}} 次",
			yourQuestions: "你提问 {{n}} 次",
			parHint: "金 ≤ {{gold}} 次 · 银 ≤ {{silver}} 次",
			medalGold: "金放大镜",
			medalSilver: "银放大镜",
			medalBronze: "铜放大镜",
			medalNone: "—",
			resultWin: "{{name}} 破解了本起调查",
			resultLose: "所有调查者都被淘汰",
			resultGiveUp: "本起调查已放弃",
			solution: "真相",
			culprit: "凶手",
			location: "地点",
			time: "时刻",
			phantom: "幽灵",
			holder: "持有者",
			questionsOf: "提问次数",
			investigationNo: "调查 {{n}}",
			level: "难度 {{n}}",
			errorAsk: "请选择合法的问题",
			errorDup: "这个问题已经问过了，答案不会改变",
			errorTurn: "现在还不能行动",
			errorSolve: "请完整填写答案",
			errorDone: "本起调查已经结束",
			hintAskTime: "询问{{loc}}在时刻 {{time}}",
			hintAskChar: "询问{{char}}到访{{loc}}的次数",
			hintSolve: "提交答案",
			hintOther: "继续调查",
			optScenario: "剧本",
			optLevel: "调查",
			optLevelValue: "第 {{n}} 起",
			optHint: "不同剧本的提问目标与胜负条件不同；调查编号越高，参考答案次数越多。",
			markCount: "已标记 {{n}} 个",
			allQueries: "公开提问记录",
			emptyQueries: "还没有人提问。",
			mastheadOver: "巴黎 · 1920 · 刑事档案",
			rosterTitle: "调查者",
			locationCards: "地点卡",
			locationCardsHint: "卡面标注时刻 1 的在场角色。",
			clueCards: "线索卡",
			clueCardLabel: "线索",
			queryCardLabel: "提问",
			verdictCardLabel: "答案",
			inquiryEmpty: "选择一张地点卡，再配一张时刻牌或角色牌。",
			inquiryEmptyHint: "也可以直接点选平面图上的房间。",
			atTime: "时刻 {{time}}",
			timePresent: "{{n}} 名角色在场",
			timeVisits: "到访 {{n}} 次",
			askedTag: "已问过",
			clueEmptyCard: "提问后，私密线索会收录在这里。",
			reasonTitle: "结论依据",
			reasonPoison: "在时刻 {{time}}，{{char}}与侦探在{{loc}}单独相处，因此有机会下毒。",
			reasonPhantom: "{{char}}在六个时刻都独自待在一个房间，是唯一始终独处的角色。",
			reasonJewels: "项链在时刻 1 由独自留在舞厅的角色取走，此后按在场人数转手。时刻 6 时，{{char}}在{{loc}}持有项链。",
			truthTimeline: "真相时间线",
			investigators: "调查记录",
			caseClosed: "结案",
			solvedMark: "破解"
		},
		en: {
			name: "Kronologic: Paris 1920",
			desc: "Trace six characters through one night at the Paris Opera to solve three mysteries",
			rules: (/* @__PURE__ */ "Goal:(· Six characters visit six locations of the Paris Opera during one evening. At every Time each character is in exactly one location, and between two consecutive Times every character moves to an adjacent location, never staying in the same place twice in a row.(· All characters are present at every Time. Each Investigation has exactly one true solution; question the cards to reconstruct the movements, then answer the questions of the Investigation.(Setup:(· Each player takes a note sheet. Locations are listed down one side and Times across the top, so every cell stands for one location at one Time.(· The location of each character at Time 1 is public and is the starting point of the deduction.(· You can investigate six locations on the map: the Grand Foyer, the Grand Staircase, the Gallery, the Stage, the Music Hall and the Dance Hall.(Asking questions:(· On your turn, choose a location on the map and pair it with a time or a character.(· With a Time placard, the shared information is how many characters are in that location at that Time; the private information is the identity of every character present there.(· With a Character placard, the shared information is how many times that character visited that location during the evening; the private information is every Time of those visits.(· Announce the shared information aloud; keep the private information to yourself. The digital version records the complete private information of the card in your clue list so nothing is lost while copying.(· If there is no character there, or the character never visited that location, the private information is empty, so the shared and private information are identical. In that case you immediately ask again after everyone has taken notes; in a solo game this extra question still counts.(· A question combines one location with one Time or one character. If another player has already asked that combination, you may still ask it yourself: the shared information stays the same, but the private information is recorded in your own clue list. Use the public question log to avoid repeating combinations you do not need.(Investigation I, Poison in High Society:(· The Detective was found poisoned the next morning. He was at the Paris Opera the evening before, and the assassin had to be alone with him at some Time in order to poison him.(· Answer who poisoned the Detective, in which location, and at which Time.(Investigation II, The Phantom of the Opera:(· Strange accidents plague the Opera. The phantom is the only character who is alone in a room at every Time of the evening.(· Answer who the phantom is.(Investigation III, The Singer’s Jewels:(· A famous diamond necklace disappears during the evening. At Time 1 the necklace is in the Dance Hall and is taken by the character who is alone there at that moment.(· At each later Time, if the holder is together with exactly one other character, the necklace changes hands to that character; if the holder is alone, or if three or more characters are present, the holder keeps it.(· Answer who holds the jewels at Time 6 and in which location the police should intervene.(Answering:(· On your turn, you may submit your solution as soon as you are ready.(· A correct answer wins the Investigation. A wrong answer eliminates you: you can no longer ask or answer, and you must not reveal whether anyone else was right.(· If every player is eliminated, the Investigation is lost. In a solo game a wrong answer ends the attempt immediately.(Solo rating:(· In a solo game your number of questions earns a Gold, Silver or Bronze magnifying glass. Each Investigation shows a reference number of questions computed by the built-in solver: at or below the reference earns Gold, up to six questions above it earns Silver, and anything higher earns Bronze. This reference is the digital self-rating and is not the printed official score table.(· In a solo game the extra question from an empty private answer still counts.(Notes:(· On the note sheet you may mark any characters that might be in a cell; marks are visible only to you.(· Marks never change the answer or consume questions, and may be changed at any time.".split("(")).join("\n"),
			scenarioPoison: "Poison in High Society",
			scenarioPhantom: "The Phantom of the Opera",
			scenarioJewels: "The Singer’s Jewels",
			scenarioPoisonDesc: "Find who was alone with the Detective, and where and when it happened.",
			scenarioPhantomDesc: "Find the phantom who is alone at every Time.",
			scenarioJewelsDesc: "Trace the necklace from hand to hand and name its holder and location at Time 6.",
			loc0: "Grand Foyer",
			loc1: "Grand Staircase",
			loc2: "Gallery",
			loc3: "Stage",
			loc4: "Music Hall",
			loc5: "Dance Hall",
			char0: "The Adventuress",
			char1: "The Baroness",
			char2: "The Chauffeur",
			char3: "The Detective",
			char4: "The Journalist",
			char5: "The Servant",
			yourTurn: "Your turn to investigate",
			waitTurn: "Waiting for {{name}}",
			goAgain: "You may ask one more question",
			eliminated: "You have been eliminated",
			gameOver: "This Investigation is over",
			setupTitle: "Locations at Time 1",
			setupHint: "Every character’s Time 1 location is public; start your deduction here.",
			selectLocation: "Choose a location on the map",
			selectKind: "Choose a Time or a Character",
			pickTime: "Time",
			pickChar: "Character",
			operaTitle: "Paris Opera",
			inquiryTime: "{{loc}} · Time {{time}}",
			inquiryCharacter: "{{loc}} · {{char}}",
			notesPrivate: "Your marks are private",
			publicClue: "Public",
			privateClue: "Private",
			privatePeople: "Characters present",
			clueArchive: "Clue archive",
			caseReport: "Case report",
			askTimeTitle: "Ask about {{loc}} at {{time}}",
			askCharTitle: "Ask how often {{char}} visited {{loc}}",
			confirmAsk: "Ask",
			askAgain: "Ask again",
			sharedCount: "{{loc}} holds {{n}} characters at Time {{time}}",
			sharedVisits: "{{char}} visited {{loc}} {{n}} time(s) tonight",
			privateChars: "Characters present: {{list}}",
			privateTimes: "Visits at: {{list}}",
			dupWarn: "Already asked; the answer will not change",
			noPrivateTime: "No character is there at that Time",
			noPrivateChar: "That character never visited this location",
			listSep: ", ",
			clauseSep: "; ",
			myClues: "My clues",
			noClues: "Private information from your questions appears here.",
			notesTitle: "Deduction notes",
			notesHint: "Tap a cell to mark characters that might be there.",
			cellTitle: "{{loc}} · Time {{time}}",
			markHint: "Choose a character to mark",
			clearCell: "Clear this cell",
			solve: "Answer",
			solveTitle: "Submit your answer",
			solveHint: "A wrong answer eliminates you; please check before submitting.",
			answerChar: "Character",
			answerLoc: "Location",
			answerTime: "Time",
			submitAnswer: "Confirm answer",
			cancel: "Cancel",
			giveUp: "Give up",
			confirmGiveUp: "Confirm give up",
			questionsCount: "{{n}} questions",
			yourQuestions: "You asked {{n}} questions",
			parHint: "Gold ≤ {{gold}} · Silver ≤ {{silver}}",
			medalGold: "Gold magnifying glass",
			medalSilver: "Silver magnifying glass",
			medalBronze: "Bronze magnifying glass",
			medalNone: "—",
			resultWin: "{{name}} solved this Investigation",
			resultLose: "Every investigator has been eliminated",
			resultGiveUp: "This Investigation was abandoned",
			solution: "The truth",
			culprit: "Assassin",
			location: "Location",
			time: "Time",
			phantom: "Phantom",
			holder: "Holder",
			questionsOf: "Questions",
			investigationNo: "Investigation {{n}}",
			level: "Level {{n}}",
			errorAsk: "Choose a valid question",
			errorDup: "This question has already been asked; the answer cannot change",
			errorTurn: "You cannot act right now",
			errorSolve: "Complete your answer",
			errorDone: "This Investigation is already over",
			hintAskTime: "Ask about {{loc}} at Time {{time}}",
			hintAskChar: "Ask how often {{char}} visited {{loc}}",
			hintSolve: "Submit an answer",
			hintOther: "Continue investigating",
			optScenario: "Scenario",
			optLevel: "Investigation",
			optLevelValue: "No. {{n}}",
			optHint: "Each scenario has a different question and victory condition; higher investigation numbers mean more reference questions.",
			markCount: "{{n}} marked",
			allQueries: "Public questions",
			emptyQueries: "Nobody has asked yet.",
			mastheadOver: "PARIS · 1920 · CRIMINAL DOSSIER",
			rosterTitle: "Investigators",
			locationCards: "Location cards",
			locationCardsHint: "Each card shows who is there at Time 1.",
			clueCards: "Clue cards",
			clueCardLabel: "Clue",
			queryCardLabel: "Query",
			verdictCardLabel: "Answer",
			inquiryEmpty: "Choose a Location card, then pair it with a Time or Character placard.",
			inquiryEmptyHint: "You can also select a room on the floor plan.",
			atTime: "Time {{time}}",
			timePresent: "{{n}} present",
			timeVisits: "{{n}} visits",
			askedTag: "Asked",
			clueEmptyCard: "Private clues are filed here once you ask.",
			reasonTitle: "Reasoning",
			reasonPoison: "At Time {{time}}, {{char}} was alone with the Detective in the {{loc}}, creating the opportunity to poison him.",
			reasonPhantom: "{{char}} stays alone in a room at every Time, the only character who is always by themselves.",
			reasonJewels: "The necklace was taken in the Dance Hall at Time 1 by the character alone there, then passed on according to how many were present. At Time 6, {{char}} holds it in the {{loc}}.",
			truthTimeline: "The true timeline",
			investigators: "Investigator record",
			caseClosed: "CASE CLOSED",
			solvedMark: "Solved"
		}
	}
};
//#endregion
export { Me as default };
