import { z as e } from "zod";
import { Fragment as t, useMemo as n, useState as r } from "react";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { useT as a } from "@bgparty/sdk/i18n";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { OptionRadio as d, OptionSection as f } from "@bgparty/sdk/ui/game-options";
//#region src/game/meta.ts
var p = {
	id: "kronologic",
	uuid: "1a17a190-24ab-44ac-bf9e-11da4d5c2e47",
	tier: "alpha",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.kronologic.name",
	descKey: "games.kronologic.desc",
	rulesKey: "games.kronologic.rules",
	icon: "🕰️",
	iconImg: "games/kronologic.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1, 2],
	accent: "#8c2f39",
	releasedAt: "2026-11-23T17:31:00+08:00",
	search: {
		py: "shi kong shen tan ba li",
		init: "skst"
	},
	hotseat: "cover"
}, m = {
	poison: [
		{
			setup: [
				0,
				1,
				3,
				3,
				5,
				3
			],
			sched: [
				[
					0,
					1,
					2,
					1,
					0,
					1
				],
				[
					1,
					2,
					3,
					4,
					3,
					4
				],
				[
					3,
					4,
					5,
					4,
					5,
					3
				],
				[
					3,
					4,
					5,
					3,
					2,
					3
				],
				[
					5,
					3,
					5,
					3,
					5,
					4
				],
				[
					3,
					5,
					4,
					3,
					5,
					3
				]
			],
			ans: [
				2,
				4,
				2
			],
			ref: 8
		},
		{
			setup: [
				5,
				2,
				0,
				5,
				0,
				1
			],
			sched: [
				[
					5,
					4,
					3,
					5,
					3,
					2
				],
				[
					2,
					1,
					2,
					1,
					2,
					3
				],
				[
					0,
					1,
					2,
					3,
					2,
					1
				],
				[
					5,
					3,
					2,
					3,
					5,
					3
				],
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					1,
					2,
					3,
					2,
					3,
					2
				]
			],
			ans: [
				0,
				5,
				1
			],
			ref: 7
		},
		{
			setup: [
				0,
				2,
				1,
				0,
				1,
				2
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					2,
					1,
					2,
					3,
					5,
					4
				],
				[
					1,
					2,
					3,
					4,
					3,
					2
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					1,
					2,
					1,
					2,
					3,
					4
				],
				[
					2,
					1,
					2,
					1,
					2,
					1
				]
			],
			ans: [
				0,
				0,
				1
			],
			ref: 7
		},
		{
			setup: [
				4,
				0,
				2,
				0,
				0,
				2
			],
			sched: [
				[
					4,
					5,
					3,
					2,
					1,
					2
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				],
				[
					2,
					3,
					2,
					3,
					2,
					3
				],
				[
					0,
					1,
					0,
					1,
					2,
					3
				],
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					2,
					3,
					4,
					5,
					3,
					2
				]
			],
			ans: [
				2,
				2,
				5
			],
			ref: 11
		},
		{
			setup: [
				5,
				3,
				2,
				1,
				3,
				5
			],
			sched: [
				[
					5,
					3,
					4,
					5,
					3,
					5
				],
				[
					3,
					4,
					5,
					4,
					3,
					2
				],
				[
					2,
					3,
					4,
					3,
					5,
					4
				],
				[
					1,
					2,
					3,
					5,
					4,
					5
				],
				[
					3,
					4,
					3,
					5,
					3,
					4
				],
				[
					5,
					4,
					3,
					4,
					3,
					4
				]
			],
			ans: [
				0,
				5,
				6
			],
			ref: 12
		}
	],
	phantom: [
		{
			setup: [
				4,
				3,
				1,
				4,
				4,
				0
			],
			sched: [
				[
					4,
					5,
					3,
					4,
					5,
					3
				],
				[
					3,
					4,
					3,
					4,
					5,
					4
				],
				[
					1,
					0,
					1,
					2,
					1,
					0
				],
				[
					4,
					5,
					3,
					4,
					3,
					2
				],
				[
					4,
					5,
					4,
					3,
					4,
					5
				],
				[
					0,
					1,
					2,
					3,
					5,
					4
				]
			],
			ans: [2],
			ref: 22
		},
		{
			setup: [
				3,
				4,
				1,
				0,
				5,
				3
			],
			sched: [
				[
					3,
					2,
					3,
					2,
					3,
					5
				],
				[
					4,
					5,
					3,
					5,
					4,
					5
				],
				[
					1,
					2,
					3,
					4,
					5,
					4
				],
				[
					0,
					1,
					0,
					1,
					2,
					1
				],
				[
					5,
					4,
					5,
					4,
					5,
					3
				],
				[
					3,
					5,
					3,
					5,
					4,
					5
				]
			],
			ans: [3],
			ref: 12
		},
		{
			setup: [
				0,
				5,
				2,
				3,
				0,
				0
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					5,
					3,
					5,
					3,
					2,
					3
				],
				[
					2,
					3,
					2,
					3,
					5,
					3
				],
				[
					3,
					2,
					3,
					2,
					1,
					2
				],
				[
					0,
					1,
					2,
					1,
					0,
					1
				],
				[
					0,
					1,
					2,
					1,
					2,
					3
				]
			],
			ans: [3],
			ref: 22
		},
		{
			setup: [
				5,
				2,
				1,
				4,
				0,
				0
			],
			sched: [
				[
					5,
					3,
					4,
					3,
					4,
					3
				],
				[
					2,
					3,
					5,
					3,
					5,
					3
				],
				[
					1,
					0,
					1,
					0,
					1,
					0
				],
				[
					4,
					3,
					2,
					3,
					4,
					3
				],
				[
					0,
					1,
					2,
					3,
					5,
					3
				],
				[
					0,
					1,
					2,
					1,
					2,
					1
				]
			],
			ans: [2],
			ref: 13
		},
		{
			setup: [
				0,
				2,
				4,
				2,
				1,
				3
			],
			sched: [
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					2,
					3,
					5,
					3,
					4,
					5
				],
				[
					4,
					5,
					3,
					4,
					5,
					3
				],
				[
					2,
					3,
					5,
					3,
					4,
					3
				],
				[
					1,
					2,
					1,
					2,
					1,
					2
				],
				[
					3,
					5,
					3,
					4,
					5,
					4
				]
			],
			ans: [4],
			ref: 22
		}
	],
	jewels: [
		{
			setup: [
				0,
				2,
				2,
				5,
				4,
				4
			],
			sched: [
				[
					0,
					1,
					2,
					1,
					2,
					3
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					2,
					3,
					2,
					3,
					4,
					5
				],
				[
					5,
					3,
					5,
					4,
					3,
					4
				],
				[
					4,
					3,
					4,
					5,
					3,
					4
				],
				[
					4,
					5,
					3,
					5,
					3,
					2
				]
			],
			ans: [4, 4],
			ref: 9
		},
		{
			setup: [
				4,
				2,
				1,
				3,
				1,
				5
			],
			sched: [
				[
					4,
					3,
					4,
					5,
					3,
					2
				],
				[
					2,
					3,
					5,
					4,
					3,
					4
				],
				[
					1,
					2,
					1,
					2,
					3,
					2
				],
				[
					3,
					4,
					5,
					3,
					2,
					3
				],
				[
					1,
					0,
					1,
					2,
					1,
					0
				],
				[
					5,
					3,
					2,
					3,
					5,
					4
				]
			],
			ans: [3, 3],
			ref: 7
		},
		{
			setup: [
				1,
				5,
				4,
				4,
				0,
				1
			],
			sched: [
				[
					1,
					0,
					1,
					2,
					3,
					2
				],
				[
					5,
					4,
					3,
					2,
					3,
					4
				],
				[
					4,
					3,
					5,
					4,
					5,
					3
				],
				[
					4,
					5,
					4,
					3,
					4,
					5
				],
				[
					0,
					1,
					2,
					3,
					2,
					3
				],
				[
					1,
					0,
					1,
					2,
					3,
					2
				]
			],
			ans: [1, 4],
			ref: 8
		},
		{
			setup: [
				3,
				2,
				2,
				4,
				5,
				2
			],
			sched: [
				[
					3,
					4,
					3,
					2,
					1,
					2
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					2,
					3,
					4,
					3,
					2,
					1
				],
				[
					4,
					3,
					2,
					1,
					2,
					3
				],
				[
					5,
					4,
					5,
					3,
					5,
					3
				],
				[
					2,
					3,
					2,
					3,
					2,
					3
				]
			],
			ans: [0, 2],
			ref: 7
		},
		{
			setup: [
				3,
				3,
				1,
				3,
				5,
				1
			],
			sched: [
				[
					3,
					4,
					5,
					4,
					3,
					4
				],
				[
					3,
					2,
					3,
					5,
					3,
					2
				],
				[
					1,
					2,
					3,
					2,
					1,
					2
				],
				[
					3,
					2,
					3,
					2,
					1,
					0
				],
				[
					5,
					3,
					4,
					5,
					4,
					3
				],
				[
					1,
					2,
					3,
					2,
					3,
					5
				]
			],
			ans: [2, 2],
			ref: 7
		}
	]
}, h = [
	[1],
	[0, 2],
	[1, 3],
	[
		2,
		4,
		5
	],
	[3, 5],
	[3, 4]
], g = {
	poison: [
		{
			gold: 8,
			silver: 14
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 11,
			silver: 17
		},
		{
			gold: 12,
			silver: 18
		}
	],
	phantom: [
		{
			gold: 22,
			silver: 28
		},
		{
			gold: 12,
			silver: 18
		},
		{
			gold: 22,
			silver: 28
		},
		{
			gold: 13,
			silver: 19
		},
		{
			gold: 22,
			silver: 28
		}
	],
	jewels: [
		{
			gold: 9,
			silver: 15
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 8,
			silver: 14
		},
		{
			gold: 7,
			silver: 13
		},
		{
			gold: 7,
			silver: 13
		}
	]
}, _ = e.enum([
	"poison",
	"phantom",
	"jewels"
]), v = e.int().min(1).max(5), y = e.object({
	scenario: _.default("poison"),
	level: v.default(1)
}).default({
	scenario: "poison",
	level: 1
}), b = e.int().min(0).max(5), x = e.int().min(1).max(6), S = e.int().min(0).max(5), C = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("ask"),
		loc: b,
		kind: e.enum(["time", "char"]),
		time: x.optional(),
		char: S.optional()
	}),
	e.object({
		type: e.literal("solve"),
		char: S,
		loc: b.optional(),
		time: x.optional()
	}),
	e.object({
		type: e.literal("mark"),
		loc: b,
		time: x,
		char: S,
		on: e.boolean()
	}),
	e.object({
		type: e.literal("note"),
		text: e.string().max(2e3)
	}),
	e.object({ type: e.literal("giveUp") })
]), w = e.object({
	seat: e.int().min(0),
	loc: b,
	kind: e.enum(["time", "char"]),
	time: x.optional(),
	char: S.optional(),
	shared: e.int().min(0).max(6)
}), te = w.extend({
	privChars: e.array(S),
	privTimes: e.array(x)
}), T = e.object({
	outcome: e.enum([
		"win",
		"lose",
		"gaveUp"
	]),
	winners: e.array(e.int().min(0)),
	answer: e.array(e.int().min(0).max(5)),
	solution: e.array(e.array(b).length(6)).length(6),
	counts: e.array(e.int().nonnegative()),
	medals: e.array(e.enum([
		"gold",
		"silver",
		"bronze",
		"none"
	]))
}).nullable(), ne = e.object({
	scenario: _,
	level: v,
	investigation: e.int().min(1).max(5),
	setup: e.array(b).length(6),
	players: e.array(e.string()),
	phase: e.enum(["ask", "done"]),
	active: e.int().min(0),
	eliminated: e.array(e.int().min(0)),
	queries: e.array(w),
	result: T
}), E = e.object({
	clues: e.array(te),
	marks: e.record(e.string(), e.array(S)),
	text: e.string()
}), D = (e) => ({ code: e });
function re(e, t) {
	let n = e.puzzle.ans;
	return e.scenario === "phantom" ? t.char === n[0] : e.scenario === "jewels" ? t.char === n[0] && t.loc === n[1] : t.char === n[0] && t.loc === n[1] && t.time === n[2];
}
function O(e, t) {
	if (e.players.length !== 1) return "none";
	let n = e.queries.filter((e) => e.seat === t).length, r = g[e.scenario][e.level - 1];
	return n <= r.gold ? "gold" : n <= r.silver ? "silver" : "bronze";
}
function ie(e) {
	let t = e.active;
	for (let n = 0; n < e.players.length; n++) if (t = (t + 1) % e.players.length, !e.eliminated.includes(t)) {
		e.active = t;
		return;
	}
}
var k = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: p,
	schemas: {
		action: C,
		publicView: ne,
		privateView: E,
		config: y
	},
	setup(e, t) {
		let n = e.scenario, r = Math.min(5, Math.max(1, e.level));
		return {
			state: {
				players: t,
				scenario: n,
				level: r,
				puzzle: m[n][r - 1],
				queries: [],
				active: 0,
				eliminated: [],
				marks: {},
				notes: {},
				phase: "ask",
				result: null
			},
			fx: [{
				kind: "setup",
				data: {
					scenario: n,
					level: r
				}
			}]
		};
	},
	reduce(e, t, n) {
		if (e.phase === "done") return D("games.kronologic.errorDone");
		let r = e.players.indexOf(n.by);
		if (r < 0) return D("games.kronologic.errorTurn");
		if (t.type === "note") {
			let r = structuredClone(e);
			return r.notes[n.by] = t.text, { state: r };
		}
		if (t.type === "mark") {
			let r = structuredClone(e), i = `${t.loc}:${t.time}`, a = r.marks[n.by] ??= {}, o = new Set(a[i] ?? []);
			return t.on ? o.add(t.char) : o.delete(t.char), o.size ? a[i] = [...o].sort() : delete a[i], { state: r };
		}
		if (r !== e.active) return D("games.kronologic.errorTurn");
		if (t.type === "giveUp") {
			let t = structuredClone(e);
			return t.phase = "done", t.result = {
				outcome: "gaveUp",
				winners: [],
				answer: t.puzzle.ans,
				solution: t.puzzle.sched,
				counts: t.players.map((e, n) => t.queries.filter((e) => e.seat === n).length),
				medals: t.players.map((e, n) => O(t, n))
			}, {
				state: t,
				fx: [{
					kind: "reveal",
					data: { answer: t.puzzle.ans }
				}]
			};
		}
		if (t.type === "ask") {
			if (t.kind === "time" && (t.time === void 0 || t.time < 1 || t.time > 6) || t.kind === "char" && (t.char === void 0 || t.char < 0 || t.char > 5)) return D("games.kronologic.errorAsk");
			let n = structuredClone(e), i;
			if (t.kind === "time") {
				let e = t.time, a = [];
				for (let r = 0; r < 6; r++) n.puzzle.sched[r][e - 1] === t.loc && a.push(r);
				i = {
					seat: r,
					loc: t.loc,
					kind: "time",
					time: e,
					shared: a.length,
					privChars: a,
					privTimes: []
				};
			} else {
				let e = t.char, a = [];
				for (let r = 0; r < 6; r++) n.puzzle.sched[e][r] === t.loc && a.push(r);
				i = {
					seat: r,
					loc: t.loc,
					kind: "char",
					char: e,
					shared: a.length,
					privChars: [],
					privTimes: a.map((e) => e + 1)
				};
			}
			return n.queries.push(i), i.privChars.length === 0 && i.privTimes.length === 0 ? {
				state: n,
				fx: [{
					kind: "again",
					data: { seat: r }
				}]
			} : (n.players.length > 1 && ie(n), {
				state: n,
				fx: [{
					kind: "reveal",
					data: { seat: r }
				}]
			});
		}
		if (e.scenario === "poison" && (t.loc === void 0 || t.time === void 0) || e.scenario === "jewels" && t.loc === void 0) return D("games.kronologic.errorSolve");
		let i = structuredClone(e);
		if (re(e, t)) return i.phase = "done", i.result = {
			outcome: "win",
			winners: [r],
			answer: i.puzzle.ans,
			solution: i.puzzle.sched,
			counts: i.players.map((e, t) => i.queries.filter((e) => e.seat === t).length),
			medals: i.players.map((e, t) => O(i, t))
		}, {
			state: i,
			fx: [{
				kind: "win",
				rid: n.by,
				data: { seat: r }
			}]
		};
		i.eliminated.push(r);
		let a = i.players.map((e, t) => t).filter((e) => !i.eliminated.includes(e));
		return a.length ? (i.active = a.find((e) => e > r) ?? a[0], {
			state: i,
			fx: [{
				kind: "eliminated",
				data: { seat: r }
			}]
		}) : (i.phase = "done", i.result = {
			outcome: "lose",
			winners: [],
			answer: i.puzzle.ans,
			solution: i.puzzle.sched,
			counts: i.players.map((e, t) => i.queries.filter((e) => e.seat === t).length),
			medals: i.players.map((e, t) => O(i, t))
		}, {
			state: i,
			fx: [{
				kind: "eliminated",
				data: { seat: r }
			}, {
				kind: "reveal",
				data: { answer: i.puzzle.ans }
			}]
		});
	},
	viewFor(e, t) {
		let n = e.players.indexOf(t);
		return {
			public: {
				scenario: e.scenario,
				level: e.level,
				investigation: e.level,
				setup: e.puzzle.setup,
				players: e.players,
				phase: e.phase,
				active: e.active,
				eliminated: e.eliminated,
				queries: e.queries.map((e) => ({
					seat: e.seat,
					loc: e.loc,
					kind: e.kind,
					...e.time === void 0 ? {} : { time: e.time },
					...e.char === void 0 ? {} : { char: e.char },
					shared: e.shared
				})),
				result: e.result
			},
			private: {
				clues: e.queries.filter((e) => e.seat === n),
				marks: e.marks[t] ?? {},
				text: e.notes[t] ?? ""
			}
		};
	},
	status(e) {
		if (e.phase !== "done" || !e.result) return { phase: e.phase };
		let t = e.result.winners.map((t) => e.players[t]);
		return {
			phase: "done",
			winner: t,
			ranking: [...t, ...e.players.filter((e) => !t.includes(e))]
		};
	}
}, A = {
	viewBox: "0 0 64 64",
	"aria-hidden": !0,
	focusable: !1
};
function j({ children: e, ...t }) {
	return /* @__PURE__ */ l("svg", {
		...A,
		...t,
		fill: "currentColor",
		children: e
	});
}
function M(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [
			/* @__PURE__ */ l("rect", {
				x: "30.5",
				y: "3.5",
				width: "3",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("path", { d: "M22 15 a10 10 0 0 1 20 0 Z" }),
			/* @__PURE__ */ l("path", { d: "M11 27 L32 12.5 L53 27 Z" }),
			/* @__PURE__ */ l("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M6 26 H58 V58 H6 Z\r\n      M11 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M21 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M31 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M41 52 V43 a3 3 0 0 0 6 0 V52 Z\r\n      M51 52 V43 a3 3 0 0 0 6 0 V52 Z"
			}),
			/* @__PURE__ */ l("rect", {
				x: "3",
				y: "58",
				width: "58",
				height: "4",
				rx: "1"
			})
		]
	});
}
function ae(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [
			/* @__PURE__ */ l("rect", {
				x: "7",
				y: "52",
				width: "50",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("rect", {
				x: "10.5",
				y: "45",
				width: "43",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("rect", {
				x: "14",
				y: "38",
				width: "36",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("rect", {
				x: "17.5",
				y: "31",
				width: "29",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("rect", {
				x: "21",
				y: "24",
				width: "22",
				height: "6",
				rx: "1.2"
			}),
			/* @__PURE__ */ l("rect", {
				x: "24.5",
				y: "17",
				width: "15",
				height: "6",
				rx: "1.2"
			})
		]
	});
}
function N(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [
			/* @__PURE__ */ l("rect", {
				x: "12",
				y: "8",
				width: "40",
				height: "5",
				rx: "1"
			}),
			/* @__PURE__ */ l("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M11 21 a7 7 0 1 0 14 0 a7 7 0 1 0 -14 0 M15 21 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0"
			}),
			/* @__PURE__ */ l("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M39 21 a7 7 0 1 0 14 0 a7 7 0 1 0 -14 0 M43 21 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0"
			}),
			/* @__PURE__ */ l("path", { d: "M12 27 H52 L49 33 H15 Z" }),
			/* @__PURE__ */ l("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M23 33 H41 V53 H23 Z M26.5 36 V51 H28 V36 Z M31.25 36 V51 H32.75 V36 Z M36 36 V51 H37.5 V36 Z"
			}),
			/* @__PURE__ */ l("rect", {
				x: "18",
				y: "53",
				width: "28",
				height: "4",
				rx: "1"
			}),
			/* @__PURE__ */ l("rect", {
				x: "13",
				y: "57",
				width: "38",
				height: "5",
				rx: "1"
			})
		]
	});
}
function P(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [/* @__PURE__ */ l("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 24 a3 3 0 0 1 3 -3 h18 a3 3 0 0 1 3 3 v8 c0 9 -5.4 16 -12 16 s-12 -7 -12 -16 z\r\n      M14 29 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M21.6 29 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M15 37.5 q5 5 10 0 q-5 2.6 -10 0"
		}), /* @__PURE__ */ l("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M32 20 a3 3 0 0 1 3 -3 h18 a3 3 0 0 1 3 3 v8 c0 9 -5.4 16 -12 16 s-12 -7 -12 -16 z\r\n      M38 25 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M45.6 25 a2.7 2.7 0 1 0 5.4 0 a2.7 2.7 0 1 0 -5.4 0\r\n      M39 38 q5 -5 10 0 q-5 -2.6 -10 0"
		})]
	});
}
function F(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [
			/* @__PURE__ */ l("ellipse", {
				cx: "21",
				cy: "50",
				rx: "9.5",
				ry: "6.4",
				transform: "rotate(-20 21 50)"
			}),
			/* @__PURE__ */ l("rect", {
				x: "28.4",
				y: "13",
				width: "3.8",
				height: "36",
				rx: "1.6"
			}),
			/* @__PURE__ */ l("path", { d: "M32.2 13 C 47 17 48 30 40 39 C 44 28 40 20 32.2 19.6 Z" })
		]
	});
}
function oe(e) {
	return /* @__PURE__ */ u(j, {
		...e,
		children: [
			/* @__PURE__ */ l("circle", {
				cx: "35",
				cy: "12",
				r: "4.6"
			}),
			/* @__PURE__ */ l("path", {
				d: "M33.5 17.5 C 32.5 24 30.5 28.5 29 33.5",
				stroke: "currentColor",
				strokeWidth: "6.4",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ l("path", {
				d: "M33.5 20.5 C 40 17.5 45 14.5 51 13.5",
				stroke: "currentColor",
				strokeWidth: "4.6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ l("path", {
				d: "M32.5 22.5 C 26.5 25 22 23.5 17.5 21",
				stroke: "currentColor",
				strokeWidth: "4.6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ l("path", {
				d: "M29 33.5 L 26.6 52",
				stroke: "currentColor",
				strokeWidth: "6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ l("path", {
				d: "M29 32.5 C 38 34 45.5 30 52 22.5",
				stroke: "currentColor",
				strokeWidth: "6",
				strokeLinecap: "round",
				fill: "none"
			})
		]
	});
}
var se = [
	M,
	ae,
	N,
	P,
	F,
	oe
];
function I({ loc: e, className: t }) {
	let n = se[e] ?? M;
	return /* @__PURE__ */ l(n, { className: t });
}
function ce({ className: e }) {
	return /* @__PURE__ */ u("svg", {
		...A,
		className: e,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "3.6",
		strokeLinecap: "round",
		children: [/* @__PURE__ */ l("circle", {
			cx: "21",
			cy: "21",
			r: "12.5"
		}), /* @__PURE__ */ l("line", {
			x1: "30.5",
			y1: "30.5",
			x2: "41",
			y2: "41",
			strokeWidth: "4.8"
		})]
	});
}
function L({ className: e }) {
	return /* @__PURE__ */ u("svg", {
		viewBox: "0 0 24 24",
		className: e,
		"aria-hidden": !0,
		focusable: !1,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.5",
		strokeLinecap: "round",
		children: [/* @__PURE__ */ l("path", { d: "M2.5 22 C 2.5 10.5 10.5 2.5 22 2.5" }), /* @__PURE__ */ l("path", {
			d: "M3.5 22 C 3.5 12 11.5 4 21.5 3.5",
			opacity: "0.45"
		})]
	});
}
//#endregion
//#region src/game/card.tsx
function R({ flavor: e, label: t, selected: n, dim: r, onClick: i, ariaLabel: a, ariaPressed: o, className: s, children: ee }) {
	let d = /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(L, { className: "kronologic-card-corner kronologic-card-corner-tl" }),
		/* @__PURE__ */ l(L, { className: "kronologic-card-corner kronologic-card-corner-tr" }),
		/* @__PURE__ */ l(L, { className: "kronologic-card-corner kronologic-card-corner-bl" }),
		/* @__PURE__ */ l(L, { className: "kronologic-card-corner kronologic-card-corner-br" }),
		/* @__PURE__ */ l("span", {
			className: "kronologic-card-tab",
			children: t
		}),
		/* @__PURE__ */ l("span", {
			className: "kronologic-card-body",
			children: ee
		})
	] }), f = `kronologic-card${s ? ` ${s}` : ""}`;
	return i ? /* @__PURE__ */ l("button", {
		type: "button",
		className: f,
		"data-flavor": e,
		"data-selected": n || void 0,
		"data-dim": r || void 0,
		"aria-label": a,
		"aria-pressed": o,
		onClick: i,
		children: d
	}) : /* @__PURE__ */ l("div", {
		className: f,
		"data-flavor": e,
		"data-selected": n || void 0,
		"data-dim": r || void 0,
		"aria-label": a,
		role: a ? "group" : void 0,
		children: d
	});
}
//#endregion
//#region src/game/tokens.ts
var z = [
	"A",
	"B",
	"C",
	"D",
	"J",
	"S"
], B = [
	"#2f5d5a",
	"#6b2f5a",
	"#3a3330",
	"#1f4e79",
	"#a9671a",
	"#7b2230"
];
//#endregion
//#region src/game/chit.tsx
function V({ char: e, className: t }) {
	return /* @__PURE__ */ l("i", {
		className: `kronologic-chit${t ? ` ${t}` : ""}`,
		style: { background: B[e] },
		"aria-hidden": !0,
		children: z[e]
	});
}
//#endregion
//#region src/game/keys.ts
var H = [
	"games.kronologic.loc0",
	"games.kronologic.loc1",
	"games.kronologic.loc2",
	"games.kronologic.loc3",
	"games.kronologic.loc4",
	"games.kronologic.loc5"
], U = [
	"games.kronologic.char0",
	"games.kronologic.char1",
	"games.kronologic.char2",
	"games.kronologic.char3",
	"games.kronologic.char4",
	"games.kronologic.char5"
], W = {
	poison: "games.kronologic.scenarioPoison",
	phantom: "games.kronologic.scenarioPhantom",
	jewels: "games.kronologic.scenarioJewels"
}, le = {
	gold: "games.kronologic.medalGold",
	silver: "games.kronologic.medalSilver",
	bronze: "games.kronologic.medalBronze",
	none: "games.kronologic.medalNone"
}, G = [
	0,
	1,
	2,
	3,
	4,
	5
], K = [
	0,
	1,
	2,
	3,
	4,
	5
], q = [
	1,
	2,
	3,
	4,
	5,
	6
], ue = {
	0: {
		x: 20,
		y: 78,
		w: 118,
		h: 172
	},
	1: {
		x: 150,
		y: 92,
		w: 138,
		h: 144
	},
	2: {
		x: 300,
		y: 62,
		w: 92,
		h: 196
	},
	3: {
		x: 404,
		y: 104,
		w: 96,
		h: 114
	},
	4: {
		x: 512,
		y: 64,
		w: 188,
		h: 80
	},
	5: {
		x: 512,
		y: 152,
		w: 188,
		h: 104
	}
}, J = 720, Y = 264;
function de({ char: e, name: t }) {
	return /* @__PURE__ */ u("span", {
		className: "kronologic-namechit",
		children: [/* @__PURE__ */ l(V, { char: e }), t]
	});
}
function fe({ kind: e, value: t, label: n, selected: r, asked: i, onPick: a }) {
	return /* @__PURE__ */ l("button", {
		type: "button",
		className: "kronologic-placard",
		"data-kind": e,
		"data-selected": r || void 0,
		"data-asked": i || void 0,
		"aria-pressed": r,
		"aria-label": n,
		onClick: a,
		children: e === "time" ? /* @__PURE__ */ l("span", { children: t }) : /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("b", { children: z[t] }), /* @__PURE__ */ l("span", { children: n })] })
	});
}
function pe(e) {
	let d = e.public, f = e.private ?? {
		clues: [],
		marks: {},
		text: ""
	}, m = a(), h = d.players.indexOf(e.myRid), [_, v] = r(null), [y, b] = r("time"), [x, S] = r(1), [C, w] = r(0), [te, T] = r(!1), [ne, E] = r(!1), [D, re] = r(null), [O, ie] = r(null), [k, A] = r(null), [j, M] = r(!1), ae = e.members.find((e) => e.rid === d.players[d.active])?.name ?? "", N = d.phase !== "done" && d.active === h && !d.eliminated.includes(h), P = d.phase === "done", F = n(() => new Set(d.queries.map((e) => e.kind === "time" ? `t:${e.loc}:${e.time}` : `c:${e.loc}:${e.char}`)), [d.queries]), oe = n(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of d.queries) t.kind === "time" && t.time !== void 0 && e.set(`${t.loc}:${t.time}`, t.shared);
		return e;
	}, [d.queries]), se = n(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of d.queries) e.set(t.seat, (e.get(t.seat) ?? 0) + 1);
		return e;
	}, [d.queries]), L = _ !== null && F.has(y === "time" ? `t:${_}:${x}` : `c:${_}:${x}`), z = (e) => m(H[e]), B = (e) => m(U[e]), le = P ? "done" : d.eliminated.includes(h) ? "warn" : N ? "accent" : "info", pe = P ? d.result?.outcome === "win" ? m("games.kronologic.resultWin", { name: e.members.find((e) => e.rid === d.players[d.result.winners[0] ?? 0])?.name ?? "" }) : d.result?.outcome === "gaveUp" ? m("games.kronologic.resultGiveUp") : m("games.kronologic.resultLose") : d.eliminated.includes(h) ? m("games.kronologic.eliminated") : N ? m("games.kronologic.yourTurn") : m("games.kronologic.waitTurn", { name: ae }), X = n(() => {
		let e = /* @__PURE__ */ new Map();
		return d.setup.forEach((t, n) => {
			let r = e.get(t) ?? [];
			r.push(n), e.set(t, r);
		}), e;
	}, [d.setup]), Z = (e) => {
		if (e.kind === "time") {
			let t = m("games.kronologic.sharedCount", {
				loc: z(e.loc),
				time: e.time ?? 0,
				n: e.shared
			}), n = e.privChars.length === 0 ? m("games.kronologic.noPrivateTime") : m("games.kronologic.privateChars", { list: e.privChars.map(B).join(m("games.kronologic.listSep")) });
			return `${t}${m("games.kronologic.clauseSep")}${n}`;
		}
		let t = m("games.kronologic.sharedVisits", {
			char: B(e.char ?? 0),
			loc: z(e.loc),
			n: e.shared
		}), n = e.privTimes.length === 0 ? m("games.kronologic.noPrivateChar") : m("games.kronologic.privateTimes", { list: e.privTimes.join(m("games.kronologic.listSep")) });
		return `${t}${m("games.kronologic.clauseSep")}${n}`;
	}, me = (e) => e.kind === "time" ? m("games.kronologic.sharedCount", {
		loc: z(e.loc),
		time: e.time ?? 0,
		n: e.shared
	}) : m("games.kronologic.sharedVisits", {
		char: B(e.char ?? 0),
		loc: z(e.loc),
		n: e.shared
	}), Q = g[d.scenario][d.level - 1], he = _ === null ? m("games.kronologic.selectLocation") : y === "time" ? m("games.kronologic.askTimeTitle", {
		loc: z(_),
		time: x
	}) : m("games.kronologic.askCharTitle", {
		loc: z(_),
		char: B(x)
	}), ge = () => {
		_ !== null && e.send(y === "time" ? {
			type: "ask",
			loc: _,
			kind: "time",
			time: x
		} : {
			type: "ask",
			loc: _,
			kind: "char",
			char: x
		});
	}, $ = (t, n) => {
		let r = !(f.marks[`${t}:${n}`] ?? []).includes(C);
		e.send({
			type: "mark",
			loc: t,
			time: n,
			char: C,
			on: r
		});
	}, _e = D !== null && (d.scenario === "phantom" || O !== null) && (d.scenario !== "poison" || k !== null);
	return /* @__PURE__ */ u("div", {
		className: "kronologic-root",
		children: [
			/* @__PURE__ */ l(s, {
				adaptive: !0,
				className: "kronologic-layout",
				actionsHeight: "kronologic-actions-slot",
				banner: /* @__PURE__ */ u("div", {
					className: "kronologic-banner",
					children: [/* @__PURE__ */ u("div", {
						className: "kronologic-masthead",
						children: [/* @__PURE__ */ u("div", {
							className: "kronologic-masthead-id",
							children: [/* @__PURE__ */ l("span", {
								className: "kronologic-eyebrow",
								children: m("games.kronologic.mastheadOver")
							}), /* @__PURE__ */ l("h1", { children: m("games.kronologic.name") })]
						}), /* @__PURE__ */ u("div", {
							className: "kronologic-casechips",
							children: [
								/* @__PURE__ */ l("span", {
									className: "kronologic-casechip",
									children: m("games.kronologic.investigationNo", { n: d.investigation })
								}),
								/* @__PURE__ */ l("span", {
									className: "kronologic-casechip",
									children: m(W[d.scenario])
								}),
								d.players.length === 1 && /* @__PURE__ */ l("span", {
									className: "kronologic-casechip",
									children: m("games.kronologic.parHint", {
										gold: Q.gold,
										silver: Q.silver
									})
								})
							]
						})]
					}), /* @__PURE__ */ l(o, {
						tone: le,
						text: pe,
						accent: p.accent
					})]
				}),
				actions: /* @__PURE__ */ u("div", {
					className: "kronologic-actions",
					children: [/* @__PURE__ */ u(R, {
						flavor: "inquiry",
						label: m("games.kronologic.queryCardLabel"),
						className: "kronologic-inquiry",
						ariaLabel: he,
						children: [_ === null ? /* @__PURE__ */ u(c, { children: [
							/* @__PURE__ */ l(ce, { className: "kronologic-inquiry-mark" }),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-hint",
								children: m("games.kronologic.inquiryEmpty")
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-note",
								children: m("games.kronologic.inquiryEmptyHint")
							})
						] }) : y === "time" ? /* @__PURE__ */ u(c, { children: [
							/* @__PURE__ */ l(I, {
								loc: _,
								className: "kronologic-inquiry-icon"
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-loc",
								children: z(_)
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-label",
								children: m("games.kronologic.pickTime")
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-value",
								children: x
							})
						] }) : /* @__PURE__ */ u(c, { children: [
							/* @__PURE__ */ l(I, {
								loc: _,
								className: "kronologic-inquiry-icon"
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-loc",
								children: z(_)
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-inquiry-label",
								children: m("games.kronologic.pickChar")
							}),
							/* @__PURE__ */ u("span", {
								className: "kronologic-inquiry-char",
								children: [/* @__PURE__ */ l(V, { char: x }), B(x)]
							})
						] }), _ !== null && L && /* @__PURE__ */ l("span", {
							className: "kronologic-asked",
							children: m("games.kronologic.askedTag")
						})]
					}), /* @__PURE__ */ l("div", {
						className: "kronologic-composer",
						children: /* @__PURE__ */ u("div", {
							className: "kronologic-composer-line",
							children: [
								/* @__PURE__ */ u("div", {
									className: "kronologic-kind",
									role: "group",
									"aria-label": m("games.kronologic.selectKind"),
									children: [/* @__PURE__ */ l("button", {
										type: "button",
										"data-selected": y === "time",
										"aria-pressed": y === "time",
										onClick: () => {
											b("time"), S(1);
										},
										children: m("games.kronologic.pickTime")
									}), /* @__PURE__ */ l("button", {
										type: "button",
										"data-selected": y === "char",
										"aria-pressed": y === "char",
										onClick: () => {
											b("char"), S(0);
										},
										children: m("games.kronologic.pickChar")
									})]
								}),
								/* @__PURE__ */ l("div", {
									className: "kronologic-placards",
									role: "group",
									"aria-label": m(y === "time" ? "games.kronologic.pickTime" : "games.kronologic.pickChar"),
									children: (y === "time" ? q : K).map((e) => /* @__PURE__ */ l(fe, {
										kind: y,
										value: e,
										label: y === "time" ? m("games.kronologic.atTime", { time: e }) : B(e),
										selected: x === e,
										asked: _ !== null && F.has(y === "time" ? `t:${_}:${e}` : `c:${_}:${e}`),
										onPick: () => S(e)
									}, e))
								}),
								/* @__PURE__ */ u("div", {
									className: "kronologic-composer-actions",
									children: [/* @__PURE__ */ l("button", {
										type: "button",
										className: "kronologic-btn-ask",
										disabled: !N || _ === null,
										onClick: ge,
										children: m("games.kronologic.confirmAsk")
									}), /* @__PURE__ */ l("button", {
										type: "button",
										className: "kronologic-btn-solve",
										disabled: !N,
										onClick: () => {
											M(!1), T(!0);
										},
										children: m("games.kronologic.solve")
									})]
								})
							]
						})
					})]
				}),
				children: /* @__PURE__ */ u("div", {
					className: "kronologic-main",
					children: [
						/* @__PURE__ */ l("section", {
							className: "kronologic-roster",
							"aria-label": m("games.kronologic.rosterTitle"),
							children: /* @__PURE__ */ l(ee, {
								members: e.members.filter((e) => d.players.includes(e.rid)),
								myRid: e.myRid,
								variant: "plate",
								status: (e) => /* @__PURE__ */ l("span", {
									className: "kronologic-roster-status",
									children: m("games.kronologic.questionsCount", { n: se.get(d.players.indexOf(e)) ?? 0 })
								}),
								action: (e) => d.phase !== "done" && e === d.players[d.active] ? "pending" : null,
								dimmed: (e) => d.eliminated.includes(d.players.indexOf(e))
							})
						}),
						/* @__PURE__ */ u("div", {
							className: "kronologic-desk",
							children: [/* @__PURE__ */ u("section", {
								className: "kronologic-panel kronologic-mapwrap",
								"aria-label": m("games.kronologic.setupTitle"),
								children: [/* @__PURE__ */ u("header", {
									className: "kronologic-sectionhead",
									children: [/* @__PURE__ */ l("h2", { children: m("games.kronologic.setupTitle") }), /* @__PURE__ */ l("p", { children: m("games.kronologic.setupHint") })]
								}), /* @__PURE__ */ u("div", {
									className: "kronologic-mapframe",
									children: [/* @__PURE__ */ u("svg", {
										className: "kronologic-map",
										viewBox: `0 0 ${J} ${Y}`,
										role: "group",
										"aria-label": m("games.kronologic.setupTitle"),
										children: [
											/* @__PURE__ */ l("rect", {
												x: "6",
												y: "50",
												width: "708",
												height: "208",
												rx: "14",
												className: "kronologic-floor"
											}),
											G.map((e) => {
												let t = ue[e], n = X.get(e) ?? [];
												return /* @__PURE__ */ u("g", {
													className: "kronologic-room",
													"data-selected": _ === e || void 0,
													role: "button",
													tabIndex: 0,
													"aria-pressed": _ === e,
													"aria-label": `${z(e)}${n.length ? ` · ${n.map(B).join(m("games.kronologic.listSep"))}` : ""}`,
													onClick: () => v(e),
													onKeyDown: (t) => {
														(t.key === "Enter" || t.key === " ") && (t.preventDefault(), v(e));
													},
													children: [
														/* @__PURE__ */ l("rect", {
															x: t.x - 4,
															y: t.y - 4,
															width: t.w + 8,
															height: t.h + 8,
															rx: "12",
															className: "kronologic-roomhalo"
														}),
														/* @__PURE__ */ l("rect", {
															x: t.x,
															y: t.y,
															width: t.w,
															height: t.h,
															rx: "8",
															className: "kronologic-roombox"
														}),
														/* @__PURE__ */ l("g", {
															transform: `translate(${t.x + t.w / 2 - 15}, ${t.y + 10})`,
															children: /* @__PURE__ */ l(I, {
																loc: e,
																className: "kronologic-roomicon"
															})
														})
													]
												}, e);
											}),
											/* @__PURE__ */ u("g", {
												className: "kronologic-doors",
												"aria-hidden": !0,
												children: [
													/* @__PURE__ */ l("rect", {
														x: "134",
														y: "160",
														width: "20",
														height: "12"
													}),
													/* @__PURE__ */ l("rect", {
														x: "284",
														y: "154",
														width: "20",
														height: "12"
													}),
													/* @__PURE__ */ l("rect", {
														x: "388",
														y: "150",
														width: "20",
														height: "12"
													}),
													/* @__PURE__ */ l("rect", {
														x: "496",
														y: "110",
														width: "20",
														height: "12"
													}),
													/* @__PURE__ */ l("rect", {
														x: "496",
														y: "196",
														width: "20",
														height: "12"
													}),
													/* @__PURE__ */ l("rect", {
														x: "584",
														y: "142",
														width: "20",
														height: "12"
													})
												]
											})
										]
									}), G.map((e) => {
										let t = ue[e], n = X.get(e) ?? [];
										return /* @__PURE__ */ u("div", {
											className: "kronologic-roomlayer",
											"data-selected": _ === e || void 0,
											style: {
												left: `${t.x / J * 100}%`,
												top: `${t.y / Y * 100}%`,
												width: `${t.w / J * 100}%`,
												height: `${t.h / Y * 100}%`
											},
											children: [/* @__PURE__ */ l("span", {
												className: "kronologic-roomtag",
												children: z(e)
											}), n.length > 0 && /* @__PURE__ */ l("span", {
												className: "kronologic-roomtokens",
												children: n.map((e) => /* @__PURE__ */ l(V, {
													char: e,
													className: "kronologic-mapchit"
												}, e))
											})]
										}, e);
									})]
								})]
							}), /* @__PURE__ */ u("section", {
								className: "kronologic-panel kronologic-notes",
								"aria-label": m("games.kronologic.notesTitle"),
								children: [
									/* @__PURE__ */ u("header", {
										className: "kronologic-sectionhead",
										children: [/* @__PURE__ */ l("h2", { children: m("games.kronologic.notesTitle") }), /* @__PURE__ */ l("p", { children: m("games.kronologic.notesHint") })]
									}),
									/* @__PURE__ */ l("div", {
										className: "kronologic-brushes",
										role: "group",
										"aria-label": m("games.kronologic.markHint"),
										children: K.map((e) => /* @__PURE__ */ u("button", {
											type: "button",
											className: "kronologic-brush",
											"data-selected": C === e,
											"aria-pressed": C === e,
											onClick: () => w(e),
											title: B(e),
											"aria-label": B(e),
											children: [/* @__PURE__ */ l(V, { char: e }), /* @__PURE__ */ l("span", { children: B(e) })]
										}, e))
									}),
									/* @__PURE__ */ u("div", {
										className: "kronologic-grid",
										role: "group",
										"aria-label": m("games.kronologic.notesTitle"),
										children: [
											/* @__PURE__ */ l("span", { "aria-hidden": !0 }),
											q.map((e) => /* @__PURE__ */ l("span", {
												className: "kronologic-gridhead",
												children: e
											}, e)),
											G.map((e) => /* @__PURE__ */ u(t, { children: [/* @__PURE__ */ u("span", {
												className: "kronologic-rowhead",
												children: [/* @__PURE__ */ l(I, { loc: e }), /* @__PURE__ */ l("span", { children: z(e) })]
											}), q.map((t) => {
												let n = f.marks[`${e}:${t}`] ?? [], r = oe.get(`${e}:${t}`);
												return /* @__PURE__ */ u("button", {
													type: "button",
													className: "kronologic-cell",
													"data-brush": n.includes(C) || void 0,
													onClick: () => $(e, t),
													"aria-label": m("games.kronologic.cellTitle", {
														loc: z(e),
														time: t
													}),
													"aria-pressed": n.includes(C),
													children: [r !== void 0 && /* @__PURE__ */ l("span", {
														className: "kronologic-count",
														children: r
													}), /* @__PURE__ */ l("span", {
														className: "kronologic-marks",
														children: n.map((e) => /* @__PURE__ */ l(V, {
															char: e,
															className: "kronologic-mark"
														}, e))
													})]
												}, t);
											})] }, e))
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ u("div", {
							className: "kronologic-fold",
							children: [/* @__PURE__ */ u("section", {
								className: "kronologic-panel kronologic-tray",
								"aria-label": m("games.kronologic.locationCards"),
								children: [/* @__PURE__ */ u("header", {
									className: "kronologic-sectionhead",
									children: [/* @__PURE__ */ l("h2", { children: m("games.kronologic.locationCards") }), /* @__PURE__ */ l("p", { children: m("games.kronologic.locationCardsHint") })]
								}), /* @__PURE__ */ l("div", {
									className: "kronologic-cardrow",
									role: "group",
									"aria-label": m("games.kronologic.selectLocation"),
									children: G.map((e) => /* @__PURE__ */ u(R, {
										flavor: "location",
										label: String(e + 1).padStart(2, "0"),
										selected: _ === e,
										onClick: () => v(e),
										ariaLabel: z(e),
										ariaPressed: _ === e,
										className: "kronologic-loccard",
										children: [
											/* @__PURE__ */ l(I, {
												loc: e,
												className: "kronologic-locicon"
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-locname",
												children: z(e)
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-occupants-label",
												children: m("games.kronologic.atTime", { time: 1 })
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-occupants",
												children: (X.get(e) ?? []).map((e) => /* @__PURE__ */ l(V, { char: e }, e))
											})
										]
									}, e))
								})]
							}), /* @__PURE__ */ u("section", {
								className: "kronologic-panel kronologic-cluewall",
								"aria-label": m("games.kronologic.clueCards"),
								children: [/* @__PURE__ */ u("header", {
									className: "kronologic-sectionhead",
									children: [/* @__PURE__ */ l("h2", { children: m("games.kronologic.clueCards") }), /* @__PURE__ */ u("button", {
										type: "button",
										className: "kronologic-link",
										onClick: () => E(!0),
										children: [
											m("games.kronologic.allQueries"),
											" · ",
											d.queries.length
										]
									})]
								}), /* @__PURE__ */ l("div", {
									className: "kronologic-cardrow",
									children: f.clues.length === 0 ? /* @__PURE__ */ l(R, {
										flavor: "empty",
										label: "—",
										className: "kronologic-cluecard",
										children: /* @__PURE__ */ l("span", {
											className: "kronologic-clue-empty",
											children: m("games.kronologic.clueEmptyCard")
										})
									}) : f.clues.map((e, t) => /* @__PURE__ */ l(R, {
										flavor: "clue",
										label: m("games.kronologic.clueCardLabel"),
										className: "kronologic-cluecard",
										ariaLabel: Z(e),
										children: e.kind === "time" ? /* @__PURE__ */ u(c, { children: [
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-when",
												children: m("games.kronologic.atTime", { time: e.time ?? 0 })
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-loc",
												children: z(e.loc)
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-count",
												children: m("games.kronologic.timePresent", { n: e.shared })
											}),
											e.privChars.length === 0 ? /* @__PURE__ */ l("span", {
												className: "kronologic-clue-note",
												children: m("games.kronologic.noPrivateTime")
											}) : /* @__PURE__ */ l("span", {
												className: "kronologic-clue-names",
												children: e.privChars.map((e) => /* @__PURE__ */ l(de, {
													char: e,
													name: B(e)
												}, e))
											})
										] }) : /* @__PURE__ */ u(c, { children: [
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-loc",
												children: z(e.loc)
											}),
											/* @__PURE__ */ u("span", {
												className: "kronologic-clue-char",
												children: [/* @__PURE__ */ l(V, { char: e.char ?? 0 }), /* @__PURE__ */ l("b", { children: B(e.char ?? 0) })]
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-count",
												children: m("games.kronologic.timeVisits", { n: e.shared })
											}),
											/* @__PURE__ */ l("span", {
												className: "kronologic-clue-note",
												children: e.privTimes.length === 0 ? m("games.kronologic.noPrivateChar") : m("games.kronologic.privateTimes", { list: e.privTimes.join(" · ") })
											})
										] })
									}, t))
								})]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ l(i, {
				open: te,
				onClose: () => T(!1),
				label: m("games.kronologic.solveTitle"),
				title: m("games.kronologic.solveTitle"),
				children: /* @__PURE__ */ u("div", {
					className: "kronologic-sheet",
					children: [
						/* @__PURE__ */ l("p", {
							className: "kronologic-sheet-hint",
							children: m("games.kronologic.solveHint")
						}),
						/* @__PURE__ */ l("p", {
							className: "kronologic-sheet-scenario",
							children: m(W[d.scenario])
						}),
						/* @__PURE__ */ l("h3", { children: m("games.kronologic.answerChar") }),
						/* @__PURE__ */ l("div", {
							className: "kronologic-choices",
							children: K.map((e) => /* @__PURE__ */ u("button", {
								type: "button",
								"data-selected": D === e,
								onClick: () => re(e),
								"aria-pressed": D === e,
								children: [/* @__PURE__ */ l(V, { char: e }), B(e)]
							}, e))
						}),
						d.scenario !== "phantom" && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("h3", { children: m("games.kronologic.answerLoc") }), /* @__PURE__ */ l("div", {
							className: "kronologic-choices",
							children: G.map((e) => /* @__PURE__ */ u("button", {
								type: "button",
								"data-selected": O === e,
								onClick: () => ie(e),
								"aria-pressed": O === e,
								children: [/* @__PURE__ */ l(I, {
									loc: e,
									className: "kronologic-choice-icon"
								}), z(e)]
							}, e))
						})] }),
						d.scenario === "poison" && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("h3", { children: m("games.kronologic.answerTime") }), /* @__PURE__ */ l("div", {
							className: "kronologic-choices kronologic-choices-num",
							children: q.map((e) => /* @__PURE__ */ l("button", {
								type: "button",
								"data-selected": k === e,
								onClick: () => A(e),
								"aria-pressed": k === e,
								children: e
							}, e))
						})] }),
						/* @__PURE__ */ u("div", {
							className: "kronologic-sheet-actions",
							children: [
								/* @__PURE__ */ l("button", {
									type: "button",
									className: "kronologic-btn-ask",
									disabled: !_e,
									onClick: () => {
										e.send({
											type: "solve",
											char: D,
											...O === null ? {} : { loc: O },
											...k === null ? {} : { time: k }
										}), T(!1);
									},
									children: m("games.kronologic.submitAnswer")
								}),
								/* @__PURE__ */ l("button", {
									type: "button",
									className: "btn-quiet",
									onClick: () => T(!1),
									children: m("games.kronologic.cancel")
								}),
								/* @__PURE__ */ l("button", {
									type: "button",
									className: "kronologic-giveup",
									"data-armed": j || void 0,
									onClick: () => {
										if (!j) {
											M(!0);
											return;
										}
										e.send({ type: "giveUp" }), T(!1), M(!1);
									},
									children: m(j ? "games.kronologic.confirmGiveUp" : "games.kronologic.giveUp")
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ l(i, {
				open: ne,
				onClose: () => E(!1),
				label: m("games.kronologic.allQueries"),
				title: m("games.kronologic.allQueries"),
				children: d.queries.length === 0 ? /* @__PURE__ */ l("p", {
					className: "kronologic-sheet-hint",
					children: m("games.kronologic.emptyQueries")
				}) : /* @__PURE__ */ l("ul", {
					className: "kronologic-log",
					children: d.queries.map((t, n) => /* @__PURE__ */ u("li", { children: [/* @__PURE__ */ l("b", { children: e.members.find((e) => e.rid === d.players[t.seat])?.name ?? "" }), /* @__PURE__ */ l("span", { children: me(t) })] }, n))
				})
			})
		]
	});
}
function X(e) {
	let t = [[e]];
	for (let e = 0; e < 5; e++) {
		let e = [];
		for (let n of t) for (let t of h[n[n.length - 1]]) e.push([...n, t]);
		t = e;
	}
	return t;
}
var Z = Array.from({ length: 6 }, (e, t) => X(t)), me = [
	0,
	1,
	2,
	3,
	4,
	5
], Q = ({ public: e, private: t }) => {
	if (e.phase === "done") return null;
	let n = t?.clues ?? [], r = new Set(n.map(he)), i = e.scenario, a;
	if (a = i === "poison" ? ve(e, n, r) : i === "phantom" ? ye(e, n, r) : be(e, n, r), a) return { action: a.kind === "time" ? {
		type: "ask",
		loc: a.loc,
		kind: "time",
		time: a.index
	} : {
		type: "ask",
		loc: a.loc,
		kind: "char",
		char: a.index
	} };
	let o = xe(e, n);
	if (o) return { action: ge(i, o) };
	let s = _e(r);
	return s ? { action: s.kind === "time" ? {
		type: "ask",
		loc: s.loc,
		kind: "time",
		time: s.index
	} : {
		type: "ask",
		loc: s.loc,
		kind: "char",
		char: s.index
	} } : null;
};
function he(e) {
	return e.kind === "time" ? `t:${e.loc}:${e.time}` : `c:${e.loc}:${e.char}`;
}
function ge(e, t) {
	return e === "phantom" ? {
		type: "solve",
		char: t[0]
	} : e === "jewels" ? {
		type: "solve",
		char: t[0],
		loc: t[1]
	} : {
		type: "solve",
		char: t[0],
		loc: t[1],
		time: t[2]
	};
}
function $(e, t, n) {
	return {
		loc: e,
		kind: t,
		index: n
	};
}
function _e(e) {
	for (let t = 0; t < 6; t++) for (let n = 1; n <= 6; n++) if (!e.has(`t:${t}:${n}`)) return $(t, "time", n);
	for (let t = 0; t < 6; t++) for (let n = 0; n < 6; n++) if (!e.has(`c:${t}:${n}`)) return $(t, "char", n);
	return null;
}
function ve(e, t, n) {
	for (let e of t) if (e.kind === "time" && e.shared === 2 && e.privChars.filter((e) => e !== 3).length === 1) return null;
	for (let e = 0; e < 6; e++) if (!n.has(`c:${e}:3`)) return $(e, "char", 3);
	let r = [
		,
		,
		,
		,
		,
		,
	].fill(void 0);
	for (let e of t) if (e.kind === "char" && e.char === 3) for (let t of e.privTimes) r[t - 1] = e.loc;
	for (let t = 0; t < 6; t++) {
		let i = r[t] ?? (Z[e.setup[3]].every((e) => e[t] === 0) ? 0 : void 0);
		if (i !== void 0 && !n.has(`t:${i}:${t + 1}`)) return $(i, "time", t + 1);
	}
	let i = Z[e.setup[3]].filter((e) => {
		for (let n of t) if (n.kind === "char" && n.char === 3) {
			for (let t of n.privTimes) if (e[t - 1] !== n.loc) return !1;
			if (e.filter((e) => e === n.loc).length !== n.shared) return !1;
		}
		return !0;
	});
	for (let e = 0; e < 6; e++) {
		let t = [...new Set(i.map((t) => t[e]))];
		for (let r of t) if (!n.has(`t:${r}:${e + 1}`)) return $(r, "time", e + 1);
	}
	return null;
}
function ye(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set();
	for (let e of t) if (e.kind === "time" && (e.shared === 1 && e.privChars.length === 1 && r.set(e.privChars[0], (r.get(e.privChars[0]) ?? 0) + 1), e.shared > 1)) for (let t of e.privChars) i.add(t);
	let a = [...r.entries()].filter(([e]) => !i.has(e)).sort((e, t) => t[1] - e[1])[0]?.[0];
	if (a === void 0) {
		for (let e = 1; e <= 6; e++) for (let t = 0; t < 6; t++) if (!n.has(`t:${t}:${e}`)) return $(t, "time", e);
		return null;
	}
	for (let e = 0; e < 6; e++) if (!n.has(`c:${e}:${a}`)) return $(e, "char", a);
	let o = [
		,
		,
		,
		,
		,
		,
	].fill(void 0);
	for (let e of t) if (e.kind === "char" && e.char === a) for (let t of e.privTimes) o[t - 1] = e.loc;
	for (let e = 0; e < 6; e++) if (o[e] !== void 0 && !n.has(`t:${o[e]}:${e + 1}`)) return $(o[e], "time", e + 1);
	return null;
}
function be(e, t, n) {
	let r = -1;
	for (let t = 0; t < 6; t++) e.setup[t] === 5 && (r = t);
	if (r < 0) return null;
	let i = 5;
	for (let e = 2; e <= 6; e++) {
		let a = t.find((t) => t.kind === "time" && t.time === e && t.privChars.includes(r));
		if (a) {
			i = a.loc, a.shared === 2 && (r = a.privChars.find((e) => e !== r) ?? r);
			continue;
		}
		for (let t of h[i]) if (!n.has(`t:${t}:${e}`)) return $(t, "time", e);
		return null;
	}
	return null;
}
function xe(e, t) {
	let n = e.scenario;
	if (n === "poison") {
		for (let e of t) if (e.kind === "time" && e.shared === 2) {
			let t = e.privChars.filter((e) => e !== 3);
			if (t.length === 1) return [
				t[0],
				e.loc,
				e.time
			];
		}
		return null;
	}
	if (n === "phantom") {
		let e = me.map((e) => {
			let n = !0, r = 0;
			for (let i of t) {
				if (i.kind === "char" && i.char === e) for (let e of i.privTimes) {
					r++;
					let a = t.find((t) => t.kind === "time" && t.time === e && t.loc === i.loc);
					a && a.shared !== 1 && (n = !1);
				}
				i.kind === "time" && i.shared > 1 && i.privChars.includes(e) && (n = !1);
			}
			return {
				char: e,
				ok: n,
				times: r
			};
		}).filter((e) => e.ok && e.times === 6);
		return e.length === 1 ? [e[0].char] : null;
	}
	let r = -1;
	for (let t = 0; t < 6; t++) e.setup[t] === 5 && (r = t);
	if (r < 0) return null;
	let i = 5;
	for (let e = 2; e <= 6; e++) {
		let n = t.find((t) => t.kind === "time" && t.time === e && t.privChars.includes(r));
		if (!n) return null;
		i = n.loc, n.shared === 2 && (r = n.privChars.find((e) => e !== r) ?? r);
	}
	return [r, i];
}
var Se = (e, t, n) => e.type === "ask" ? e.kind === "time" ? n("games.kronologic.hintAskTime", {
	loc: n(H[e.loc]),
	time: e.time ?? 1
}) : n("games.kronologic.hintAskChar", {
	loc: n(H[e.loc]),
	char: n(U[e.char ?? 0])
}) : e.type === "solve" ? n("games.kronologic.hintSolve") : n("games.kronologic.hintOther"), Ce = [
	0,
	1,
	2,
	3,
	4,
	5
], we = [
	0,
	1,
	2,
	3,
	4,
	5
], Te = [
	1,
	2,
	3,
	4,
	5,
	6
];
function Ee({ result: e, public: n, members: r, myRid: i, onPlayAgain: o, onBackToLobby: s }) {
	let d = a(), f = n, p = f.result, m = o ?? s, h = (e) => r.find((t) => t.rid === f.players[e])?.name ?? "", g = (e) => d(U[e]), _ = (e) => d(H[e]), v = p?.answer ?? [], y = p ? f.scenario === "poison" ? [
		{
			label: d("games.kronologic.culprit"),
			char: v[0]
		},
		{
			label: d("games.kronologic.location"),
			loc: v[1]
		},
		{
			label: d("games.kronologic.time"),
			time: v[2]
		}
	] : f.scenario === "phantom" ? [{
		label: d("games.kronologic.phantom"),
		char: v[0]
	}] : [{
		label: d("games.kronologic.holder"),
		char: v[0]
	}, {
		label: d("games.kronologic.location"),
		loc: v[1]
	}] : [], b = p ? f.scenario === "poison" ? d("games.kronologic.reasonPoison", {
		char: g(v[0]),
		loc: _(v[1]),
		time: v[2]
	}) : f.scenario === "phantom" ? d("games.kronologic.reasonPhantom", { char: g(v[0]) }) : d("games.kronologic.reasonJewels", {
		char: g(v[0]),
		loc: _(v[1])
	}) : "", x = p ? f.scenario === "poison" ? {
		loc: v[1],
		time: v[2]
	} : f.scenario === "jewels" ? {
		loc: v[1],
		time: 6
	} : null : null, S = p && f.scenario === "phantom" ? v[0] : null;
	return /* @__PURE__ */ l("div", {
		className: "kronologic-root kronologic-over",
		children: /* @__PURE__ */ u("div", {
			className: "kronologic-dossier",
			children: [
				/* @__PURE__ */ u("header", {
					className: "kronologic-over-head",
					children: [/* @__PURE__ */ u("div", {
						className: "kronologic-over-id",
						children: [/* @__PURE__ */ l("span", {
							className: "kronologic-eyebrow",
							children: d("games.kronologic.mastheadOver")
						}), /* @__PURE__ */ l("h1", { children: d("games.kronologic.name") })]
					}), /* @__PURE__ */ u("div", {
						className: "kronologic-over-meta",
						children: [
							/* @__PURE__ */ l("span", {
								className: "kronologic-casechip",
								children: d("games.kronologic.investigationNo", { n: f.investigation })
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-casechip",
								children: d(W[f.scenario])
							}),
							/* @__PURE__ */ l("span", {
								className: "kronologic-stamp",
								children: d("games.kronologic.caseClosed")
							})
						]
					})]
				}),
				/* @__PURE__ */ l("p", {
					className: "kronologic-over-result",
					children: p?.outcome === "win" ? d("games.kronologic.resultWin", { name: h(p.winners[0] ?? 0) }) : p?.outcome === "gaveUp" ? d("games.kronologic.resultGiveUp") : d("games.kronologic.resultLose")
				}),
				/* @__PURE__ */ l("div", {
					className: "kronologic-verdicts",
					children: y.map((e) => /* @__PURE__ */ u(R, {
						flavor: "verdict",
						label: d("games.kronologic.verdictCardLabel"),
						className: "kronologic-verdictcard",
						children: [/* @__PURE__ */ l("span", {
							className: "kronologic-verdict-label",
							children: e.label
						}), e.char === void 0 ? e.loc === void 0 ? /* @__PURE__ */ l("span", {
							className: "kronologic-verdict-num",
							children: e.time
						}) : /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(I, {
							loc: e.loc,
							className: "kronologic-verdict-icon"
						}), /* @__PURE__ */ l("span", {
							className: "kronologic-verdict-name",
							children: _(e.loc)
						})] }) : /* @__PURE__ */ u("span", {
							className: "kronologic-verdict-char",
							children: [/* @__PURE__ */ l(V, { char: e.char }), /* @__PURE__ */ l("b", { children: g(e.char) })]
						})]
					}, e.label))
				}),
				p && /* @__PURE__ */ u("section", {
					className: "kronologic-reason",
					"aria-label": d("games.kronologic.reasonTitle"),
					children: [/* @__PURE__ */ l("h2", {
						className: "kronologic-subtitle",
						children: d("games.kronologic.reasonTitle")
					}), /* @__PURE__ */ l("p", { children: b })]
				}),
				p && /* @__PURE__ */ u("section", {
					className: "kronologic-tl",
					"aria-label": d("games.kronologic.truthTimeline"),
					children: [/* @__PURE__ */ l("h2", {
						className: "kronologic-subtitle",
						children: d("games.kronologic.truthTimeline")
					}), /* @__PURE__ */ u("div", {
						className: "kronologic-tl-grid",
						role: "group",
						"aria-label": d("games.kronologic.truthTimeline"),
						children: [
							/* @__PURE__ */ l("span", { "aria-hidden": !0 }),
							Te.map((e) => /* @__PURE__ */ l("span", {
								className: "kronologic-tl-hcell",
								children: e
							}, e)),
							Ce.map((e) => /* @__PURE__ */ u(t, { children: [/* @__PURE__ */ u("span", {
								className: "kronologic-tl-head",
								children: [/* @__PURE__ */ l(I, { loc: e }), /* @__PURE__ */ l("span", { children: _(e) })]
							}), Te.map((t) => {
								let n = we.filter((n) => p.solution[n][t - 1] === e);
								return /* @__PURE__ */ l("span", {
									className: "kronologic-tl-cell",
									"data-key": x?.loc === e && x?.time === t || void 0,
									children: n.map((e) => /* @__PURE__ */ l(V, {
										char: e,
										className: `kronologic-tl-chit${S === e ? " kronologic-tl-chit-key" : ""}`
									}, e))
								}, t);
							})] }, e))
						]
					})]
				}),
				p && /* @__PURE__ */ u("section", {
					className: "kronologic-over-record",
					"aria-label": d("games.kronologic.investigators"),
					children: [/* @__PURE__ */ l("h2", {
						className: "kronologic-subtitle",
						children: d("games.kronologic.investigators")
					}), /* @__PURE__ */ l(ee, {
						members: r.filter((e) => f.players.includes(e.rid)),
						myRid: i,
						variant: "plate",
						status: (t) => {
							let n = f.players.indexOf(t), r = p.medals[n];
							return /* @__PURE__ */ u("span", {
								className: "kronologic-over-status",
								children: [
									e.winner.includes(t) && /* @__PURE__ */ l("b", {
										className: "kronologic-over-solved",
										children: d("games.kronologic.solvedMark")
									}),
									/* @__PURE__ */ l("span", { children: d("games.kronologic.questionsCount", { n: p.counts[n] ?? 0 }) }),
									f.players.length === 1 && r && /* @__PURE__ */ u("span", {
										className: "kronologic-medal",
										"data-medal": r,
										children: [/* @__PURE__ */ l(ce, { className: "kronologic-medal-icon" }), d(le[r])]
									})
								]
							});
						},
						dimmed: (e) => f.eliminated.includes(f.players.indexOf(e))
					})]
				}),
				m && /* @__PURE__ */ u("div", {
					className: "kronologic-over-actions",
					children: [o && /* @__PURE__ */ l("button", {
						type: "button",
						className: "kronologic-btn-ask",
						onClick: o,
						children: d("session.result.playAgain")
					}), s && /* @__PURE__ */ l("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: d("session.result.backToLobby")
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/game/options.tsx
var De = [
	{
		key: "poison",
		label: "games.kronologic.scenarioPoison",
		desc: "games.kronologic.scenarioPoisonDesc"
	},
	{
		key: "phantom",
		label: "games.kronologic.scenarioPhantom",
		desc: "games.kronologic.scenarioPhantomDesc"
	},
	{
		key: "jewels",
		label: "games.kronologic.scenarioJewels",
		desc: "games.kronologic.scenarioJewelsDesc"
	}
];
function Oe({ value: e, onChange: t }) {
	let n = a(), r = y.safeParse(e), i = r.success ? r.data : y.parse(void 0);
	return /* @__PURE__ */ u("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ l(f, {
				title: n("games.kronologic.optScenario"),
				columns: 3,
				children: De.map((e) => /* @__PURE__ */ l(d, {
					name: "kronologic-scenario",
					value: e.key,
					checked: i.scenario === e.key,
					label: n(e.label),
					hint: n(e.desc),
					accent: p.accent,
					onChange: () => t({
						...i,
						scenario: e.key
					})
				}, e.key))
			}),
			/* @__PURE__ */ l(f, {
				title: n("games.kronologic.optLevel"),
				columns: 3,
				children: [
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ l(d, {
					name: "kronologic-level",
					value: String(e),
					checked: i.level === e,
					label: n("games.kronologic.optLevelValue", { n: e }),
					accent: p.accent,
					onChange: () => t({
						...i,
						level: e
					})
				}, e))
			}),
			/* @__PURE__ */ l("p", {
				className: "text-xs opacity-60",
				children: n("games.kronologic.optHint")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var ke = {
	definition: k,
	View: pe,
	bot: Q,
	describe: Se,
	OverView: Ee,
	Options: Oe,
	locales: {
		zh: {
			name: "时空神探：巴黎1920",
			desc: "在巴黎歌剧院的一夜之间，用地点与时刻的线索还原六名角色的行踪，破解三桩悬案",
			rules: (/* @__PURE__ */ "目标：.· 六名角色在同一个夜晚先后出现在巴黎歌剧院的六个地点。每名角色在每个时刻都恰好位于一个地点，并且在两个相邻时刻之间必定移动到另一个相邻地点，不会连续两次停留在同一地点。.· 所有角色在每个时刻都在场。每起调查都有唯一确定的真相，玩家需要通过提问还原角色的行踪并回答调查提出的问题。.准备：.· 每位玩家准备一张推理笔记。笔记左侧按地点排列，上方按时刻排列，每个格子对应一个地点与一个时刻。.· 时刻 1 时六名角色各自所在的地点对所有人公开，作为推理的起点。.· 六张地点卡分别对应大堂、大楼梯、画廊、舞台、音乐厅与舞厅。.提问：.· 轮到你时，选择一张地点卡，再选择一张时刻牌或一张角色牌，组成一个问题。.· 选择时刻牌时，公开信息是「该地点在该时刻共有几名角色」，私密信息是「该时刻在场的所有角色」。.· 选择角色牌时，公开信息是「该角色当晚到访该地点的总次数」，私密信息是「该角色全部到访的时刻」。.· 公开信息必须当众宣布；私密信息只告诉你自己，请记在自己的笔记上。数字版会由助手把这张卡的全部私密信息直接记入你的线索栏，避免抄写遗漏。.· 如果该处没有任何角色，或者该角色从未到访该地点，私密信息为空，此时公开信息与私密信息完全相同。遇到这种情况，你在所有人记录完毕后立即再提问一次；单人游戏中这次提问同样计入次数。.· 每个问题只询问一个地点与一个时刻（或一个角色）的组合。同一个组合被其他玩家问过时，你仍然可以再次询问：公开信息不会改变，但私密信息会单独记入你的线索栏。公开提问记录可以帮你避开已经问过的组合。.调查一：毒杀疑云：.· 侦探在第二天清晨被发现死于家中，前一天晚上他正在巴黎歌剧院参加慈善晚会。凶手必须在某个时刻与侦探单独相处，才能下毒。.· 需要回答：凶手是谁、在哪个地点、在哪个时刻。.调查二：歌剧魅影：.· 歌剧院接连发生事故，人们传言是幽灵作祟。幽灵行踪隐秘，是当晚唯一一名在每个时刻都独自待在一个房间里的角色。.· 需要回答：幽灵是谁。.调查三：歌女珠宝：.· 女歌手的名贵钻石项链在演出当晚失窃。时刻 1 时项链出现在舞厅，被当时独自留在舞厅的那名角色取走并带离。.· 此后每个时刻，若同一地点恰好只有持有者与另一名角色两人，项链就转交给对方；若持有者独自一人，或者同一地点有三名及以上角色，项链仍由持有者保管。.· 需要回答：时刻 6 时谁持有项链，以及警方应该在哪个地点拦截。.作答：.· 轮到你时，如果你已经确定答案，可以随时作答。作答不需要消耗地点卡。.· 答案正确即赢得本起调查；答案错误则被淘汰，不能再提问或作答，也不能透露他人答案的对错。.· 所有玩家都被淘汰时，本起调查以失败结束。单人游戏中答错立即结束本局。.单人评级：.· 单人模式按提问次数评级：金放大镜、银放大镜、铜放大镜。每起调查会显示内置求解器给出的参考提问次数；不超过参考次数获得金放大镜，超出参考次数六次以内获得银放大镜，其余获得铜放大镜。该参考值用于数字版自评，并非纸面版的官方评级表。.· 单人游戏中遇到「立即再提问」时，这次提问同样计入总数。.笔记：.· 在推理笔记中，你可以为任意格子标记可能位于该处的角色，标记只对自己可见。.· 标记不会改变答案，也不会消耗提问次数，可随时修改。".split(".")).join("\n"),
			scenarioPoison: "毒杀疑云",
			scenarioPhantom: "歌剧魅影",
			scenarioJewels: "歌女珠宝",
			scenarioPoisonDesc: "找出与侦探单独相处并下毒的凶手、地点与时刻。",
			scenarioPhantomDesc: "找出在每个时刻都独处的幽灵。",
			scenarioJewelsDesc: "推演项链在众人之间转手的经过，找出时刻 6 的持有者与地点。",
			loc0: "大堂",
			loc1: "大楼梯",
			loc2: "画廊",
			loc3: "舞台",
			loc4: "音乐厅",
			loc5: "舞厅",
			char0: "女冒险家",
			char1: "男爵夫人",
			char2: "司机",
			char3: "侦探",
			char4: "记者",
			char5: "女仆",
			yourTurn: "轮到你调查",
			waitTurn: "等待{{name}}提问",
			goAgain: "你获得一次额外提问",
			eliminated: "你已被淘汰",
			gameOver: "本起调查已结束",
			setupTitle: "时刻 1 的位置",
			setupHint: "所有角色在时刻 1 的地点公开，可作为推理起点。",
			selectLocation: "选择地点卡",
			selectKind: "选择时刻或角色",
			pickTime: "时刻",
			pickChar: "角色",
			askTimeTitle: "询问{{loc}}在{{time}}时刻",
			askCharTitle: "询问{{char}}到访{{loc}}的次数",
			confirmAsk: "提问",
			askAgain: "再问一次",
			sharedCount: "{{loc}}在时刻 {{time}} 共有 {{n}} 名角色",
			sharedVisits: "{{char}}当晚到访{{loc}}共 {{n}} 次",
			privateChars: "在场角色：{{list}}",
			privateTimes: "到访时刻：{{list}}",
			dupWarn: "已问过，答案不会改变",
			noPrivateTime: "该地点在该时刻没有角色",
			noPrivateChar: "该角色从未到访该地点",
			listSep: "、",
			clauseSep: "，",
			myClues: "我的线索",
			noClues: "提问后，私密信息会记录在这里。",
			notesTitle: "推理笔记",
			notesHint: "点选格子可标记可能位于该处的角色。",
			cellTitle: "{{loc}} · 时刻 {{time}}",
			markHint: "选择要标记的角色",
			clearCell: "清除本格",
			solve: "作答",
			solveTitle: "提交答案",
			solveHint: "答案错误将被淘汰，请确认后再提交。",
			answerChar: "角色",
			answerLoc: "地点",
			answerTime: "时刻",
			submitAnswer: "确认提交",
			cancel: "取消",
			giveUp: "放弃本局",
			confirmGiveUp: "确认放弃",
			questionsCount: "提问 {{n}} 次",
			yourQuestions: "你提问 {{n}} 次",
			parHint: "金 ≤ {{gold}} 次 · 银 ≤ {{silver}} 次",
			medalGold: "金放大镜",
			medalSilver: "银放大镜",
			medalBronze: "铜放大镜",
			medalNone: "—",
			resultWin: "{{name}} 破解了本起调查",
			resultLose: "所有调查者都被淘汰",
			resultGiveUp: "本起调查已放弃",
			solution: "真相",
			culprit: "凶手",
			location: "地点",
			time: "时刻",
			phantom: "幽灵",
			holder: "持有者",
			questionsOf: "提问次数",
			investigationNo: "调查 {{n}}",
			level: "难度 {{n}}",
			errorAsk: "请选择合法的问题",
			errorDup: "这个问题已经问过了，答案不会改变",
			errorTurn: "现在还不能行动",
			errorSolve: "请完整填写答案",
			errorDone: "本起调查已经结束",
			hintAskTime: "询问{{loc}}在时刻 {{time}}",
			hintAskChar: "询问{{char}}到访{{loc}}的次数",
			hintSolve: "提交答案",
			hintOther: "继续调查",
			optScenario: "剧本",
			optLevel: "调查",
			optLevelValue: "第 {{n}} 起",
			optHint: "不同剧本的提问目标与胜负条件不同；调查编号越高，参考答案次数越多。",
			markCount: "已标记 {{n}} 个",
			allQueries: "公开提问记录",
			emptyQueries: "还没有人提问。",
			mastheadOver: "巴黎 · 1920 · 刑事档案",
			rosterTitle: "调查者",
			locationCards: "地点卡",
			locationCardsHint: "卡面标注时刻 1 的在场角色。",
			clueCards: "线索卡",
			clueCardLabel: "线索",
			queryCardLabel: "提问",
			verdictCardLabel: "答案",
			inquiryEmpty: "选择一张地点卡，再配一张时刻牌或角色牌。",
			inquiryEmptyHint: "也可以直接点选平面图上的房间。",
			atTime: "时刻 {{time}}",
			timePresent: "{{n}} 名角色在场",
			timeVisits: "到访 {{n}} 次",
			askedTag: "已问过",
			clueEmptyCard: "提问后，私密线索会收录在这里。",
			reasonTitle: "结论依据",
			reasonPoison: "在时刻 {{time}}，{{char}}与侦探在{{loc}}单独相处，因此有机会下毒。",
			reasonPhantom: "{{char}}在六个时刻都独自待在一个房间，是唯一始终独处的角色。",
			reasonJewels: "项链在时刻 1 由独自留在舞厅的角色取走，此后按在场人数转手。时刻 6 时，{{char}}在{{loc}}持有项链。",
			truthTimeline: "真相时间线",
			investigators: "调查记录",
			caseClosed: "结案",
			solvedMark: "破解"
		},
		en: {
			name: "Kronologic: Paris 1920",
			desc: "Trace six characters through one night at the Paris Opera to solve three mysteries",
			rules: (/* @__PURE__ */ "Goal:(· Six characters visit six locations of the Paris Opera during one evening. At every Time each character is in exactly one location, and between two consecutive Times every character moves to an adjacent location, never staying in the same place twice in a row.(· All characters are present at every Time. Each Investigation has exactly one true solution; question the cards to reconstruct the movements, then answer the questions of the Investigation.(Setup:(· Each player takes a note sheet. Locations are listed down one side and Times across the top, so every cell stands for one location at one Time.(· The location of each character at Time 1 is public and is the starting point of the deduction.(· The six Location cards are the Grand Foyer, the Grand Staircase, the Gallery, the Stage, the Music Hall and the Dance Hall.(Asking questions:(· On your turn, choose a Location card, then pair it with either a Time placard or a Character placard.(· With a Time placard, the shared information is how many characters are in that location at that Time; the private information is the identity of every character present there.(· With a Character placard, the shared information is how many times that character visited that location during the evening; the private information is every Time of those visits.(· Announce the shared information aloud; keep the private information to yourself. The digital version records the complete private information of the card in your clue list so nothing is lost while copying.(· If there is no character there, or the character never visited that location, the private information is empty, so the shared and private information are identical. In that case you immediately ask again after everyone has taken notes; in a solo game this extra question still counts.(· A question combines one location with one Time or one character. If another player has already asked that combination, you may still ask it yourself: the shared information stays the same, but the private information is recorded in your own clue list. Use the public question log to avoid repeating combinations you do not need.(Investigation I, Poison in High Society:(· The Detective was found poisoned the next morning. He was at the Paris Opera the evening before, and the assassin had to be alone with him at some Time in order to poison him.(· Answer who poisoned the Detective, in which location, and at which Time.(Investigation II, The Phantom of the Opera:(· Strange accidents plague the Opera. The phantom is the only character who is alone in a room at every Time of the evening.(· Answer who the phantom is.(Investigation III, The Singer’s Jewels:(· A famous diamond necklace disappears during the evening. At Time 1 the necklace is in the Dance Hall and is taken by the character who is alone there at that moment.(· At each later Time, if the holder is together with exactly one other character, the necklace changes hands to that character; if the holder is alone, or if three or more characters are present, the holder keeps it.(· Answer who holds the jewels at Time 6 and in which location the police should intervene.(Answering:(· On your turn you may answer at any moment; answering does not use a Location card.(· A correct answer wins the Investigation. A wrong answer eliminates you: you can no longer ask or answer, and you must not reveal whether anyone else was right.(· If every player is eliminated, the Investigation is lost. In a solo game a wrong answer ends the attempt immediately.(Solo rating:(· In a solo game your number of questions earns a Gold, Silver or Bronze magnifying glass. Each Investigation shows a reference number of questions computed by the built-in solver: at or below the reference earns Gold, up to six questions above it earns Silver, and anything higher earns Bronze. This reference is the digital self-rating and is not the printed official score table.(· In a solo game the extra question from an empty private answer still counts.(Notes:(· On the note sheet you may mark any characters that might be in a cell; marks are visible only to you.(· Marks never change the answer or consume questions, and may be changed at any time.".split("(")).join("\n"),
			scenarioPoison: "Poison in High Society",
			scenarioPhantom: "The Phantom of the Opera",
			scenarioJewels: "The Singer’s Jewels",
			scenarioPoisonDesc: "Find who was alone with the Detective, and where and when it happened.",
			scenarioPhantomDesc: "Find the phantom who is alone at every Time.",
			scenarioJewelsDesc: "Trace the necklace from hand to hand and name its holder and location at Time 6.",
			loc0: "Grand Foyer",
			loc1: "Grand Staircase",
			loc2: "Gallery",
			loc3: "Stage",
			loc4: "Music Hall",
			loc5: "Dance Hall",
			char0: "The Adventuress",
			char1: "The Baroness",
			char2: "The Chauffeur",
			char3: "The Detective",
			char4: "The Journalist",
			char5: "The Servant",
			yourTurn: "Your turn to investigate",
			waitTurn: "Waiting for {{name}}",
			goAgain: "You may ask one more question",
			eliminated: "You have been eliminated",
			gameOver: "This Investigation is over",
			setupTitle: "Locations at Time 1",
			setupHint: "Every character’s Time 1 location is public; start your deduction here.",
			selectLocation: "Choose a Location card",
			selectKind: "Choose a Time or a Character",
			pickTime: "Time",
			pickChar: "Character",
			askTimeTitle: "Ask about {{loc}} at {{time}}",
			askCharTitle: "Ask how often {{char}} visited {{loc}}",
			confirmAsk: "Ask",
			askAgain: "Ask again",
			sharedCount: "{{loc}} holds {{n}} characters at Time {{time}}",
			sharedVisits: "{{char}} visited {{loc}} {{n}} time(s) tonight",
			privateChars: "Characters present: {{list}}",
			privateTimes: "Visits at: {{list}}",
			dupWarn: "Already asked; the answer will not change",
			noPrivateTime: "No character is there at that Time",
			noPrivateChar: "That character never visited this location",
			listSep: ", ",
			clauseSep: "; ",
			myClues: "My clues",
			noClues: "Private information from your questions appears here.",
			notesTitle: "Deduction notes",
			notesHint: "Tap a cell to mark characters that might be there.",
			cellTitle: "{{loc}} · Time {{time}}",
			markHint: "Choose a character to mark",
			clearCell: "Clear this cell",
			solve: "Answer",
			solveTitle: "Submit your answer",
			solveHint: "A wrong answer eliminates you; please check before submitting.",
			answerChar: "Character",
			answerLoc: "Location",
			answerTime: "Time",
			submitAnswer: "Confirm answer",
			cancel: "Cancel",
			giveUp: "Give up",
			confirmGiveUp: "Confirm give up",
			questionsCount: "{{n}} questions",
			yourQuestions: "You asked {{n}} questions",
			parHint: "Gold ≤ {{gold}} · Silver ≤ {{silver}}",
			medalGold: "Gold magnifying glass",
			medalSilver: "Silver magnifying glass",
			medalBronze: "Bronze magnifying glass",
			medalNone: "—",
			resultWin: "{{name}} solved this Investigation",
			resultLose: "Every investigator has been eliminated",
			resultGiveUp: "This Investigation was abandoned",
			solution: "The truth",
			culprit: "Assassin",
			location: "Location",
			time: "Time",
			phantom: "Phantom",
			holder: "Holder",
			questionsOf: "Questions",
			investigationNo: "Investigation {{n}}",
			level: "Level {{n}}",
			errorAsk: "Choose a valid question",
			errorDup: "This question has already been asked; the answer cannot change",
			errorTurn: "You cannot act right now",
			errorSolve: "Complete your answer",
			errorDone: "This Investigation is already over",
			hintAskTime: "Ask about {{loc}} at Time {{time}}",
			hintAskChar: "Ask how often {{char}} visited {{loc}}",
			hintSolve: "Submit an answer",
			hintOther: "Continue investigating",
			optScenario: "Scenario",
			optLevel: "Investigation",
			optLevelValue: "No. {{n}}",
			optHint: "Each scenario has a different question and victory condition; higher investigation numbers mean more reference questions.",
			markCount: "{{n}} marked",
			allQueries: "Public questions",
			emptyQueries: "Nobody has asked yet.",
			mastheadOver: "PARIS · 1920 · CRIMINAL DOSSIER",
			rosterTitle: "Investigators",
			locationCards: "Location cards",
			locationCardsHint: "Each card shows who is there at Time 1.",
			clueCards: "Clue cards",
			clueCardLabel: "Clue",
			queryCardLabel: "Query",
			verdictCardLabel: "Answer",
			inquiryEmpty: "Choose a Location card, then pair it with a Time or Character placard.",
			inquiryEmptyHint: "You can also select a room on the floor plan.",
			atTime: "Time {{time}}",
			timePresent: "{{n}} present",
			timeVisits: "{{n}} visits",
			askedTag: "Asked",
			clueEmptyCard: "Private clues are filed here once you ask.",
			reasonTitle: "Reasoning",
			reasonPoison: "At Time {{time}}, {{char}} was alone with the Detective in the {{loc}}, creating the opportunity to poison him.",
			reasonPhantom: "{{char}} stays alone in a room at every Time, the only character who is always by themselves.",
			reasonJewels: "The necklace was taken in the Dance Hall at Time 1 by the character alone there, then passed on according to how many were present. At Time 6, {{char}} holds it in the {{loc}}.",
			truthTimeline: "The true timeline",
			investigators: "Investigator record",
			caseClosed: "CASE CLOSED",
			solvedMark: "Solved"
		}
	}
};
//#endregion
export { ke as default };
